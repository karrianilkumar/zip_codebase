// next.config.js
// /** @type {import('next').NextConfig} */
// const nextConfig = {
//     reactStrictMode: false,
//     typescript: {
//       // !! WARN !!
//       // Dangerously allow production builds to successfully complete even if
//       // your project has type errors.
//       // !! WARN !!
//       ignoreBuildErrors: true,
//     },
//   };
  
//   export default nextConfig;

// next.config.js

import CompressionPlugin from 'compression-webpack-plugin';
import { BundleAnalyzerPlugin } from 'webpack-bundle-analyzer';

const nextConfig = {
  reactStrictMode: false,
  swcMinify: true, // Enable SWC minification for smaller JavaScript bundles

  typescript: {
    ignoreBuildErrors: true,
  },

  // ✅ Add this block here
  eslint: {
    ignoreDuringBuilds: true,
  },


  webpack(config, { isServer }) {
    if (!isServer) {
      config.plugins.push(
        new CompressionPlugin({
          algorithm: 'brotliCompress',
          filename: '[path][base].br',
          test: /\.(js|css|html|svg|tsx|ts)$/,
          threshold: 8192,
          minRatio: 0.8,
          deleteOriginalAssets: false,
        }),
        new CompressionPlugin({
          algorithm: 'gzip',
          filename: '[path][base].gz',
          test: /\.(js|css|html|svg|tsx|ts)$/,
          threshold: 8192,
          minRatio: 0.8,
          deleteOriginalAssets: false,
        })
      );

      if (process.env.ANALYZE === 'true') {
        config.plugins.push(
          new BundleAnalyzerPlugin({
            analyzerMode: 'server',
            openAnalyzer: true,
          })
        );
      }

      config.cache = {
        type: 'filesystem',
      };

      config.module.rules.push({
        test: /\.(jpg|jpeg|png|gif|svg)$/,
        use: [
          {
            loader: 'url-loader',
            options: {
              limit: 8192,
              fallback: 'file-loader',
            },
          },
          {
            loader: 'image-webpack-loader',
            options: {
              mozjpeg: { quality: 75 },
              optipng: { optimizationLevel: 7 },
              pngquant: { quality: [0.65, 0.90], speed: 4 },
              gifsicle: { optimizationLevel: 3 },
              svgo: { plugins: [{ removeViewBox: false }] },
            },
          },
        ],
      });
    }
    return config;
  },

  images: {
    domains: ['example.com'],
    deviceSizes: [320, 420, 768, 1024, 1200, 1920, 2048],
    imageSizes: [16, 32, 48, 64, 128, 256, 384],
    formats: ['image/webp'],
  },

  async headers() {
    return [
      {
        source: '/_next/static/:path*',
        headers: [
          { key: 'Cache-Control', value: 'public, max-age=31536000, immutable' },
        ],
      },
      {
        source: '/images/:path*',
        headers: [
          { key: 'Cache-Control', value: 'public, max-age=86400' },
        ],
      },
    ];
  },
};

export default nextConfig;
