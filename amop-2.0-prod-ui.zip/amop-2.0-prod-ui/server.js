const { createServer } = require('https');
const { parse } = require('url');
const next = require('next');
const fs = require('fs');
const dev = process.env.NODE_ENV !== 'production';
const app = next({ dev });
const handle = app.getRequestHandler();

// Load SSL certificate and key
const httpsOptions = {
  key: fs.readFileSync('./cert/private-key.key'),            // Path to your private key file
  cert: fs.readFileSync('./cert/certificate.crt'),           // Path to your certificate file
  ca: fs.readFileSync('./cert/certificate-chain.crt'),       // Path to your certificate chain file
};

app.prepare().then(() => {
  createServer(httpsOptions, (req, res) => {
    const parsedUrl = parse(req.url, true);
    handle(req, res, parsedUrl);
  }).listen(443,'0.0.0.0', (err) => {
    if (err) throw err;
    console.log('> Ready on https://prod.amop.services:443');
  });
});
