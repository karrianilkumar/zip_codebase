import { axiosClientInstance } from "@/api/axios";
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { AUTHENTICATION_ROUTES } from "@/common/constants/route-constant";
import { PartnerInfo } from "@/types/auth/auth-types";
import axios from "axios";

export interface ServiceAccount {
  tax_profile: any;
  client_id: any;
  id?: string;
  clientId: string;
  role: string;
  partner?: string;
  tenant?: string;
  settings: {
    name: string;
    value: string;
  }[];
  clientSecret?: string;
  email?: string;
  phone?: string;
}

// export const getServiceAccounts = async (
//   page: number,
//   limit: number,
// ): Promise<{
//   results: ServiceAccount[];
//   totalResults: number;
//   page: number;
// }> => {
//   const response = await axiosClientInstance.get(
//     AUTHENTICATION_ROUTES.API_AUTH_SERVICE_ACCOUNT,
//     {
//       params: {
//         page,
//         limit,
//       },
//     },
//   );
//   return response.data;
// // };


// export const createServiceAccount = async (
//   serviceAccount: ServiceAccount,
// ): Promise<ServiceAccount> => {
//   const response = await axiosClientInstance.post(
//     AUTHENTICATION_ROUTES.API_AUTH_SERVICE_ACCOUNT,
//     serviceAccount,
//   );
//   return response.data;
// };

// export const updateServiceAccount = async (
//   serviceAccount: ServiceAccount,
// ): Promise<ServiceAccount> => {
//   const { id, ...rest } = serviceAccount;
//   console.log(id,rest,"Show the parameters")

//   const response = await axiosClientInstance.put(
//     `${AUTHENTICATION_ROUTES.API_AUTH_SERVICE_ACCOUNT}/${id}`,
//     rest,
//   );
//   return response.data;
// };

// export const getPartners = async (): Promise<PartnerInfo[]> => {
//   let page = 1;
//   let limit = 100;
//   let partners: PartnerInfo[] = [];
//   let totalResults = 0;
//   do {
//     const response = await axiosClientInstance.get(
//       AUTHENTICATION_ROUTES.API_AUTH_PARTNERS,
//       {
//         params: {
//           page,
//           limit,
//         },
//       },
//     );
//     partners = partners.concat(response.data.results);
//     page++;
//   } while (partners.length < totalResults);

//   return partners;
// };



// export const deleteServiceAccount = async (id: string): Promise<void> => {
//   await axiosClientInstance.delete(
//     `${AUTHENTICATION_ROUTES.API_AUTH_SERVICE_ACCOUNT}/${id}`,
//   );
// };

export const useServiceAccounts = () => {
  const { username, partner, role, token, selectedDb,firstLastName,sessionId} = useAuth();

  const getServiceAccounts = async (page: number, limit: number): Promise<{
    flag: string;
    results: ServiceAccount[];
    totalResults: number;
    page: number;
    tenants:any[];
    roles:any[];
    tax_profiles:any[];
  }> => {
    console.log((page -1)*limit, "Show offset value");
    try {
      // Validate the required values
      if (!username || !role || !token || !selectedDb) {
        throw new Error("Missing required context values.");
      }

      // Construct payload
      const payload = {
        username: username,
        firstLastName: firstLastName,
        role_name: role,
        tenant_name: partner || "default_value",
        path: "/get_service_account",
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        sessionID: sessionId,
        offset: (page - 1) * limit,
      };

      console.log("Payload  for get service providers:", payload);

      // Make the API call
      const response = await axios.post(
        ENV_ROUTES.USER_AUTHENTICATION,
        { data: payload }
      );

      console.log("Response received:", response);
      const resp = JSON.parse(response.data.body);
      return resp;
    } catch (error) {
      console.error("Error in getServiceAccounts:", error);
      if (axios.isAxiosError(error)) {
        console.error("Axios error details:", {
          status: error.response?.status,
          data: error.response?.data,
        });
      }
      throw new Error("Failed to fetch service accounts. Please try again later.");
    }
  };

  return { getServiceAccounts };
};
export const useDeleteServiceAccounts = () => {
  const { username, partner, role, token, selectedDb, firstLastName,sessionId} = useAuth();
  const deleteServiceAccount = async (
    client_id: string,
  ): Promise<void> => {
    try {
      // Construct payload for deletion
      const payload = {
        path: "/process_service_account",
        username: username,
        firstLastName: firstLastName,
        tenant_name: partner || "default_value",
        access_token: token,
        db_name: selectedDb,
        sessionID: sessionId,
        request_received_at: getCurrentDateTime(),
        "1.0": true,
        client_id: client_id,
        role: role,
        flag: "delete",
      };
      console.log("Delete Payload:", payload);
  
      // Make the API call
      const response = await axios.post(ENV_ROUTES.USER_AUTHENTICATION, {
        data: payload,
      });
  
      console.log("Delete response:", response);
      if (response.status !== 200) {
        throw new Error("Failed to delete the service account.");
      }
    } catch (error) {
      console.error("Error in deleteServiceAccount:", error);
      if (axios.isAxiosError(error)) {
        console.error("Axios error details:", {
          status: error.response?.status,
          data: error.response?.data,
        });
      }
      throw new Error("Failed to delete the service account. Please try again.");
    }
  };
  return { deleteServiceAccount};
}

export const useUpdateServiceAccounts =()=>{
  const { username, partner, role, token, selectedDb, firstLastName,sessionId } = useAuth();
  const updateServiceAccount = async (  
    serviceAccount: ServiceAccount,
  ): Promise<ServiceAccount> => {
    console.log("show the edit parameters values after save",serviceAccount)
    const { clientId, clientSecret, email, phone, tax_profile, tenant, role  } = serviceAccount;
    
    // Construct the payload for the update request
    const payload = {
      path: "/process_service_account",
      username: username, // Add fallback value if username is missing
      firstLastName: firstLastName,
      db_name: selectedDb, // Fallback to default db if selectedDb is missing
      sessionID: sessionId,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      "1.0": true,
      client_id: clientId , // Assuming the client_id is available in the serviceAccount object
      client_secret: clientSecret , // Add fallback for client_secret
      tenant_name: partner || "default_tenant", // Fallback for tenant
      tenant: tenant, // Fallback for tenant
      role: role, // Fallback for role
      email: email,// Fallback for email
      phone: phone , // Fallback for phone
      tax_profile: tax_profile, // Fallback for tax_profile
      flag: "update", // Flag indicating the update action
    };
  
    try {
      console.log("Update Payload:", payload);
      
      // Make the API call
      const response = await axios.post(ENV_ROUTES.USER_AUTHENTICATION, { data: payload });
  
      console.log("Update response:", response);
      const resp = JSON.parse(response.data.body);
  
      return resp;
    } catch (error) {
      console.error("Error in updateServiceAccount:", error);
      if (axios.isAxiosError(error)) {
        console.error("Axios error details:", {
          status: error.response?.status,
          data: error.response?.data,
        });
      }
      throw new Error("Failed to update the service account. Please try again.");
    }
  };
  return { updateServiceAccount};
}
export const useCreateServiceAccount = () => {
  const { username, partner, token, selectedDb, firstLastName,sessionId} = useAuth();

  const createServiceAccount = async (
    serviceAccount: ServiceAccount,
  ): Promise<ServiceAccount> => {
    console.log("show the create parameters values after save",serviceAccount);
    const { clientId, clientSecret, email, phone, tax_profile, tenant, role } =
      serviceAccount;

    // Construct the payload for the create request
    const payload = {
      path: "/create_service_account",
      username: username, 
      firstLastName: firstLastName,
      db_name: selectedDb, 
      sessionID: sessionId,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      "1.0": true,
      client_id: clientId, 
      client_secret: clientSecret, 
      tenant_name: partner || "default_tenant", 
      tenant: tenant, 
      role: role, 
      email: email, 
      phone: phone, 
      tax_profile: tax_profile, 
    };

    try {
      console.log("Create Payload:", payload);

      // Make the API call
      const response = await axios.post(
        ENV_ROUTES.USER_AUTHENTICATION,
        { data: payload },
      );

      console.log("Create response:", response);
      const resp = JSON.parse(response.data.body);

      return resp;
    } catch (error) {
      console.error("Error in createServiceAccount:", error);
      if (axios.isAxiosError(error)) {
        console.error("Axios error details:", {
          status: error.response?.status,
          data: error.response?.data,
        });
      }
      throw new Error("Failed to create the service account. Please try again.");
    }
  };

  return { createServiceAccount };
};
