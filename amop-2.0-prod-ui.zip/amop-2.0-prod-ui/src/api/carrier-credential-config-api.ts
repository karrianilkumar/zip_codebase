import {
  INVENTORY_API,
  INVENTORY_API_ERROR,
} from "@/common/constants/api-constants";
import { axiosClientInstance } from "./axios";
import { isAxiosError } from "axios";

export const getCarrierCredentialConfig = async (options: {}) => {
  try {
    const response = await axiosClientInstance.get(
      INVENTORY_API.INTEGRATION_AUTHENTICATION,
      {
        params: options,
      },
    );
    return response.data?.results[0] || {};
  } catch (error: any) {
    throw new Error(INVENTORY_API_ERROR.GET_INTEGRATION_AUTHENTICATION, {
      cause: {
        status: error?.response?.status,
        code: error?.code,
      },
    });
  }
};

export const createCarrierCredentialConfig = async (data: object) => {
  try {
    const response = await axiosClientInstance.post(
      INVENTORY_API.INTEGRATION_AUTHENTICATION,
      data,
    );
    return response.data;
  } catch (error: any) {
    if (isAxiosError(error)) {
      throw new Error(error.response?.data?.message);
    }
    throw new Error(INVENTORY_API_ERROR.SAVE_INTEGRATION_AUTHENTICATION, {
      cause: {
        status: error?.response?.status,
        code: error?.code,
      },
    });
  }
};

export const updateCarrierCredentialConfig = async (data: any) => {
  try {
    const { id, ...restData } = data;
    const response = await axiosClientInstance.put(
      `${INVENTORY_API.INTEGRATION_AUTHENTICATION}/${id}`,
      restData,
    );
    return response.data;
  } catch (error: any) {
    if (isAxiosError(error)) {
      throw new Error(error.response?.data?.message);
    }
    throw new Error(INVENTORY_API_ERROR.SAVE_INTEGRATION_AUTHENTICATION, {
      cause: {
        status: error?.response?.status,
        code: error?.code,
      },
    });
  }
};
