import {
  INVENTORY_API,
  INVENTORY_API_ERROR,
} from "@/common/constants/api-constants";
import { axiosClientInstance } from "./axios";

export const getTotalByTimeData = async (options: {}) => {
  try {
    const response = await axiosClientInstance.get(
      INVENTORY_API.DASHBOARD_TOTAL_TIME,
      {
        params: options,
      },
    );
    return response.data;
  } catch (error: any) {
    throw new Error(INVENTORY_API_ERROR.DASHBOARD_TOTAL_TIME, {
      cause: {
        status: error?.response?.status,
        code: error?.code,
      },
    });
  }
};

export const getDashboardStatistic = async (
  enpoint: string,
  errorMessage: string,
  options: {},
) => {
  try {
    const response = await axiosClientInstance.get(enpoint, {
      params: options,
    });
    return response.data.data;
  } catch (error: any) {
    throw new Error(errorMessage, {
      cause: {
        status: error?.response?.status,
        code: error?.code,
      },
    });
  }
};
