import {
  DEVICE_API,
  DEVICE_API_ERROR,
  INVENTORY_API,
  INVENTORY_API_ERROR,
  PROVISION_API,
  PROVISION_API_ERROR,
} from "@/common/constants/api-constants";
import { axiosClientInstance } from "./axios";

export const getInventoryData = async (options: {}) => {
  try {
    const response = await axiosClientInstance.get(INVENTORY_API.DEVICE_LIST, {
      params: options,
    });
    return response.data;
  } catch (error: any) {
    throw new Error(INVENTORY_API_ERROR.DEVICE_LIST, {
      cause: {
        status: error?.response?.status,
        code: error?.code,
      },
    });
  }
};

export const getProvisionData = async (options: {}) => {
  try {
    const response = await axiosClientInstance.get(PROVISION_API.PROVISIONING, {
      params: options,
    });
    return response.data;
  } catch (error: any) {
    throw new Error(PROVISION_API_ERROR.PROVISIONING_GET, {
      cause: {
        status: error?.response?.status,
        code: error?.code,
      },
    });
  }
};

export const getInventoryItemOptions = async () => {
  try {
    const response = await axiosClientInstance.get(
      INVENTORY_API.DEVICE_OPTIONS,
    );
    return response.data;
  } catch (error: any) {
    throw new Error(INVENTORY_API_ERROR.DEVICE_OPTIONS, {
      cause: {
        status: error?.response?.status,
        code: error?.code,
      },
    });
  }
};

export const postArchiveDevice = async (deviceIds: string[]) => {
  try {
    const response = await axiosClientInstance.post(DEVICE_API.ARCHIVE, {
      deviceIds,
    });
    return response.data;
  } catch (error: any) {
    throw new Error(DEVICE_API_ERROR.ARCHIVE, {
      cause: {
        status: error?.response?.status,
        code: error?.code,
      },
    });
  }
};

export const getDeviceManufacture = async () => {
  try {
    const response = await axiosClientInstance.get(INVENTORY_API.SETTINGS);
    return response.data;
  } catch (error: any) {
    throw new Error(INVENTORY_API_ERROR.DEVICE_MANUFACTURE, {
      cause: {
        status: error?.response?.status,
        code: error?.code,
      },
    });
  }
};
