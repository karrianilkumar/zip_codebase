import { axiosClientInstance } from "@/api/axios";
import { ReportSubscriptionType } from "@/types/report/report-subscription-types";

export const getSubscribers = async (
  page: number,
  limit: number,
): Promise<{
  results: ReportSubscriptionType[];
  totalResults: number;
  page: number;
}> => {
  return axiosClientInstance
    .get("/api/taxes/reports/subscribe", {
      params: {
        page,
        limit,
      },
    })
    .then((response) => response.data);
};

export const saveSubscribers = async (
  newData: ReportSubscriptionType,
): Promise<void> => {
  return axiosClientInstance
    .put("/api/taxes/reports/subscribe", newData)
    .then((response) => response.data);
};

export const deleteSubscriber = async (id: string): Promise<void> => {
  return axiosClientInstance
    .delete(`/api/taxes/reports/subscribe/${id}`)
    .then((response) => response.data);
};
