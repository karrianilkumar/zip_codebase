import { INVENTORY_API } from "@/common/constants/api-constants";
import { axiosClientInstance } from "./axios";

export async function getPartnerIntegrationSetting(name: string) {
  const prefix = `integration.${name}.`;
  const { data, status } = await axiosClientInstance.get(
    INVENTORY_API.PARTNER_SETTINGS,
    {
      params: {
        prefix,
      },
      // consider 404 as success
      validateStatus: (status) => status < 500 || status === 404,
    },
  );
  if (status === 404) {
    return {};
  }

  const { settings = [] } = data || {};
  return settings
    .filter((setting: any) => setting.key.startsWith(prefix))
    .reduce((acc: any, setting: any) => {
      const key = setting.key.replace(prefix, "");
      return {
        ...acc,
        [key]: setting.value,
      };
    }, {});
}

export async function updatePartnerIntegrationSetting(name: string, data: any) {
  const prefix = `integration.${name}.`;
  const settings = Object.entries(data).map(([key, value]) => ({
    key: `${prefix}${key}`,
    value,
  }));

  const response = await axiosClientInstance.put(
    INVENTORY_API.PARTNER_SETTINGS_UPDATE,
    {
      settings,
    },
  );
  return response.data;
}
