import React, { useEffect, useState } from "react";
import { DatePicker, Modal, Popover, Select, Spin } from "antd";
import axios from "axios";
import { Bar, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ComposedChart } from "recharts";
import { ENV_ROUTES } from "../components/routes/route_constants";
import moment from "moment";
import { useAuth } from "../components/auth_context";

import { ChevronLeftIcon, ChevronRightIcon, InformationCircleIcon } from "@heroicons/react/24/outline";
import dayjs from "dayjs";



interface CompareChartsProps {
  isOpen: boolean;
  onClose: () => void;
  chartTitle: string;
  chartPath: string;
  serviceProvider: string;
  chart: string
}

const CompareCharts: React.FC<CompareChartsProps> = ({
  isOpen,
  onClose,
  chartTitle,
  chartPath,
  serviceProvider

}) => {
  const [loading, setLoading] = useState(false);

  const [chartsData, setChartsData] = useState<any>({});
  const { username, partner, role, token, selectedDb, firstLastName, sessionId, metaData } = useAuth();
  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
  const presentYear = new Date().getFullYear();
  const presentMonth = dayjs().month();
  const [selectedMonths, setSelectedMonths] = useState<string[]>([dayjs().format("MMMM")]);
  const [areMonthsSelected, setAreMonthsSelected] = useState(false);
  const [isCalendarVisible, setIsCalendarVisible] = useState(false);
  const [hoveredBar, setHoveredBar] = useState(null);


  const fetchData = async () => {

    setLoading(true);
    try {
      const url = ENV_ROUTES.DASHBOARD;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_compare_cards",
        role_name: role,
        parent_module: "Dashboard",
        module_name: "Dashboard",
        year: currentYear,
        months: selectedMonths,
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        dropdown: "Customer Rate Plan",
        modified_by: firstLastName,
        chart_title: chartTitle,
        chart_path: chartPath,
        service_provider: serviceProvider
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
          onOk: onClose

        });
      } else {
        const chart_data = parsedData?.month_dates || {}
        setChartsData(chart_data)

      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
        onOk: onClose

      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      // Default to the current month when modal opens
      const currentMonth = moment().format("MMMM");
      setSelectedMonths([currentMonth]);
      fetchData();
    }
  }, [isOpen]);

  const handleCalendarClick = (title: string) => {
    if (!isCalendarVisible) {
      setIsCalendarVisible(true);
    }
  };
  // Helper function to assign unique colors to statuses
  const getColorForStatus = (status: string) => {
    const colors: Record<string, string> = {
      Activated: '#4caf50',
      'Activation Ready': '#2196f3',
      Deactivated: '#f44336',
      'Test Ready': '#ff9800',
      Inventory: '#9c27b0',
      Suspended: "#67e8f9",
      "Pre-active": "#a78bfa",
      Active: "#4ade80",
      "Pending Activation": "#d0ed57",
      "Pending Esn / Meid Change": "#34d399",
      "Terminated": "#FFB6C1",
      "Online": "#34d399",
      "Stopped": "#b4b4f9",
      "Unactive": "6D712E",
     "Waiting" :"#00C49F",

    };
    return colors[status] || '#607d8b'; // Default color for undefined statuses
  };

  const handleCloseCalendar = async () => {
    setSelectedMonths([]);
    setIsCalendarVisible(false);
    setCurrentYear(presentYear)

  };
  const handleYearChange = (direction: "left" | "right") => {

    if (direction === "left") {
      setCurrentYear((prevYear) => prevYear - 1);
      setSelectedMonths([]);
    } else if (direction === "right" && currentYear + 1 <= presentYear) {
      setCurrentYear((prevYear) => prevYear + 1);
      setSelectedMonths([]);
    }

  };

  // const handleHover = () => {
  //   if (areMonthsSelected) {
  //     // If months are already selected, deselect them
  //     setSelectedMonths([]);
  //   } else {
  //     // If months are not selected, select all
  //     const pastMonths = Array.from({ length: 12 }, (_, index) =>
  //       dayjs().month(index).format("MMMM")
  //     );
  //     setSelectedMonths(pastMonths);
  //   }

  //   // Toggle the state
  //   setAreMonthsSelected(!areMonthsSelected);
  // };

  const handleSingleClick = () => {
    // Select all months on single click
    if (!areMonthsSelected) {
      const pastMonths = Array.from({ length: 12 }, (_, index) =>
        dayjs().month(index).format("MMMM")
      );
      setSelectedMonths(pastMonths);
      setAreMonthsSelected(true);
    }
    else {
      setSelectedMonths([]);
      setAreMonthsSelected(false);
    }
  };

  // const handleDoubleClick = () => {
  //   // Deselect all months on double click
  //   setSelectedMonths([]);
  //   setAreMonthsSelected(false);
  // };


  // const handleMonthClick = (monthName: string, monthIndex: number) => {
  //   if (
  //     currentYear > presentYear ||
  //     (currentYear === presentYear && monthIndex > presentMonth)
  //   ) {
  //     return; // Prevent selecting future months
  //   }

  //   setSelectedMonths((prev) =>
  //     prev.includes(monthName)
  //       ? prev.filter((month) => month !== monthName) // Deselect if already selected
  //       : [...prev, monthName] // Select otherwise
  //   );
  // };

  const handleMonthClick = (monthName: string, monthIndex: number) => {
    if (
      currentYear > presentYear ||
      (currentYear === presentYear && monthIndex > presentMonth)
    ) {
      return; // Prevent selecting future months
    }

    setSelectedMonths((prev) => {
      const updatedMonths = prev.includes(monthName)
        ? prev.filter((month) => month !== monthName) // Deselect if already selected
        : [...prev, monthName]; // Select otherwise

      // Sort months based on their order
      return updatedMonths.sort(
        (a, b) =>
          new Date(`${a} 1`).getMonth() - new Date(`${b} 1`).getMonth()
      );
    });
  };



  const openCompareCharts = () => {
    setIsCalendarVisible(false)
    fetchData()
  }

  const renderChart = (data: any) => {
    if (!data || Object.keys(data).length === 0) {
      return <div className="h-[350px]">No data available to display.</div>;
    }

    // Transform the data to fit the Recharts format
    const chartData = Object.keys(data).map((month) => {
      const monthData = data[month]?.data?.data || [];
      // const activatedCount = monthData.find((item: any) => item.status === 'active')?.count || 0;
      const activatedCount = monthData
        .filter((item: any) => item.status?.toLowerCase() === "active")
        .reduce((sum: any, item: { count: any; }) => sum + (item.count || 0), 0);


      const transformed = {
        month,

        ActivatedCount: activatedCount,
        ...Object.fromEntries(monthData.map((item: any) => [item.status, item.count])),
      };

      return transformed;
    });

    // Extract all unique statuses for dynamic bar rendering
    const allStatuses = Array.from(
      new Set(
        Object.values(data)
          .flatMap((month: any) => month.data?.data.map((item: any) => item.status))
      )
    );

    // Dynamically calculate chart width based on number of months
    const chartWidth = Math.max(chartData.length * 100, 1200); // 120px per month, minimum width 1000px

    return (
      <div style={{ width: "100%", overflowX: "hidden" }}>
        <ResponsiveContainer width={chartWidth} height={400}>
          <ComposedChart
            data={chartData}
            margin={{ top: 20, right: 20, bottom: 20, left: 20 }}
            barCategoryGap="10%"
            barGap={5}
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="month" />
            <YAxis />

            {/* <Tooltip
              content={({ payload }) => {
                if (!payload || payload.length === 0) {
                  return null; // Return null if payload is undefined or empty
                }

                const isSingleMonthSelected = selectedMonths.length === 1;

                // Filter payload to include only data for a single service provider if one month is selected
                const filteredPayload = isSingleMonthSelected
                  ? [payload[0]] // Example: Display only the first service provider's data
                  : payload.filter((entry) => entry.name !== "ActivatedCount"); // Exclude ActivatedCount in multi-month view

                return (
                  <div
                    style={{
                      backgroundColor: "#fff",
                      border: "1px solid #ccc",
                      padding: "10px",
                      borderRadius: "4px",
                    }}
                  >
                    {filteredPayload.map((entry, index) => {
                      const statusName = String(entry.name || "Unknown");
                      const statusColor = getColorForStatus(statusName); // Get color for the status
                      return (
                        <div key={`tooltip-item-${index}`} style={{ marginBottom: "5px" }}>
                          <p style={{ margin: 0, color: statusColor }}>
                            {statusName}: {entry.value}
                          </p>
                        </div>
                      );
                    })}
                  </div>
                );
              }}
            /> */}
            <Tooltip
              content={({ payload, label }) => {
                if (!payload || payload.length === 0) {
                  return null; // Return nothing if there's no data
                }
                // Filter out entries with name "ActivatedCount"
                const filteredPayload = payload.filter((entry) => entry.name !== "ActivatedCount");

                return (
                  <div
                    style={{
                      backgroundColor: "#fff",
                      border: "1px solid #ccc",
                      padding: "10px",
                      borderRadius: "4px",
                    }}
                  >
                    <p style={{ fontWeight: "bold", marginBottom: "5px" }}>{label}</p>
                    {filteredPayload.map((entry, index) => (
                      <div key={`tooltip-item-${index}`} style={{ marginBottom: "5px" }}>
                        <p style={{ margin: 0, color: entry.color }}>
                          {entry.name}: {entry.value}
                        </p>
                      </div>
                    ))}
                  </div>
                );
              }}
            />

            <Legend
              content={({ payload }) => {
                if (!payload) return null; // Return nothing if there's no data

                return (
                  <div style={{ display: "flex", flexWrap: "wrap", gap: "10px" }}>
                    {payload
                      .filter((entry) => entry.value !== "ActivatedCount" && entry.value !== "YourIconLabel") // Exclude specific items
                      .map((entry, index) => (
                        <div
                          key={`legend-item-${index}`}
                          style={{
                            display: "flex",
                            alignItems: "center",
                            fontSize: "14px",
                            color: entry.color, // Apply respective color to the text
                          }}
                        >
                          {/* Legend Icon */}
                          <div
                            style={{
                              width: "12px",
                              height: "12px",
                              backgroundColor: entry.color,
                              marginRight: "5px",
                              borderRadius: "50%",
                            }}
                          ></div>
                          {/* Legend Text */}
                          <span>{entry.value}</span>
                        </div>
                      ))}
                  </div>
                );
              }}
            />
            {allStatuses.map((status: string) => (
              <Bar key={status} dataKey={status} fill={getColorForStatus(status)} barSize={70} />
            ))}
            <Line type="monotone" dataKey="ActivatedCount" stroke="#8884d8" strokeWidth={2} dot={false} />
          </ComposedChart>
        </ResponsiveContainer>
      </div>
    );
  };


  return (
    <Modal
      title={<div className="justify-between flex">
        <div>
          <h2 className="font-bold text-2xl">{chartTitle}</h2>
        </div>
        <div>
          {/* Calendar Icon in the top right corner */}
          <button
            onClick={() => handleCalendarClick(chartTitle)}
          >
            <i className="fi fi-sr-flip-horizontal" style={{ fontSize: "24px", color: "#2196f3", marginRight: "20px" }}></i>
          </button>
        </div>
      </div>}
      open={isOpen}
      onCancel={onClose}
      footer={null}
      width={1200}
      style={{ maxHeight: '80vh', overflow: "hidden" }}
      centered
    >
      {loading ? (
        <div className="flex justify-center items-center w-full h-full" style={{ height: '60vh' }}>
          <Spin size="large" className="w-32 h-32" />
        </div>
      ) : (
        <>
          {/* Modal for selecting multiple months */}
          <div className="relative">
            {/* Inline Calendar Popup */}
            {isCalendarVisible && (
              <div className="absolute right-4 w-96 bg-white shadow-lg border border-gray-200 rounded-lg z-50">
                {/* Calendar Header */}
                <div className="flex justify-between items-center p-4 bg-gray-100 rounded-t-lg">
                  <ChevronLeftIcon
                    className="h-5 w-5 text-gray-600 cursor-pointer hover:text-gray-800"
                    onClick={() => handleYearChange("left")}
                  />
                  <div className="flex items-center justify-center gap-2">
                    <span
                      className="text-xl font-semibold cursor-pointer"
                      onClick={handleSingleClick}
                    >
                      {currentYear}
                    </span>
                    <Popover
                      content={<div>Click to select or deselect all months </div>}
                      trigger="hover"
                      placement="right"
                    >
                      <InformationCircleIcon
                        className="w-5 h-5 text-green-600 cursor-pointer mt-1"
                      />
                    </Popover>

                  </div>
                  <ChevronRightIcon
                    className={`h-5 w-5 ${currentYear + 1 > presentYear
                      ? "text-gray-400 cursor-not-allowed"
                      : "text-gray-600 cursor-pointer hover:text-gray-800"
                      }`}
                    onClick={() => handleYearChange("right")}
                  />
                </div>
                {/* Month Selection */}
                <div className="grid grid-cols-3 gap-4 p-4">
                  {Array.from({ length: 12 }, (_, index) => {
                    const monthName = dayjs().month(index).format("MMMM");
                    const isFutureMonth = currentYear === presentYear && index > dayjs().month();
                    const isDisabled = isFutureMonth;

                    return (
                      <button
                        key={monthName}
                        className={`rounded-lg px-4 py-2 font-medium transition-all ${selectedMonths.includes(monthName)
                          ? "active"
                          : "deactive"
                          } ${isDisabled ? "cursor-not-allowed text-gray-400" : "cursor-pointer"}`}
                        onClick={() => !isDisabled && handleMonthClick(monthName, index)}
                        disabled={isDisabled}
                      >
                        {monthName}
                      </button>
                    );
                  })}
                </div>

                {/* Footer */}
                <div className="flex justify-end items-center p-4 space-x-2 bg-gray-100 rounded-b-lg">
                  <button
                    className="cancel-btn"
                    onClick={() => handleCloseCalendar()}
                  >
                    Cancel
                  </button>
                  <button
                    className={`save-btn  ${selectedMonths.length === 0 ? "opacity-50 cursor-not-allowed" : "active"
                      }`}
                    onClick={() => openCompareCharts()}
                    disabled={selectedMonths.length === 0}
                  >
                    Compare
                  </button>
                </div>
              </div>
            )}
          </div>
          <div className="overflow-auto">
            {renderChart(chartsData || {})}
          </div>
        </>
      )}
    </Modal>
  );
};

export default CompareCharts;


