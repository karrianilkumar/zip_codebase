"use client";
import React, { lazy, Suspense, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "../components/auth_context";
import { useLogoStore } from "../stores/logoStore";
import CompareCharts from "./compareCharts";
// import { Tooltip } from "antd/lib";

import {
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  ResponsiveContainer,
  Cell,
  PieChart,
  Pie,
  LineChart,
  Line,
  ScatterChart,
  Scatter,
} from "recharts";
import { ENV_ROUTES } from "../components/routes/route_constants";
import axios from "axios";
import { getCurrentDateTime } from "../components/header_constants";
import { Button, DatePicker, Modal, notification, Select, Spin } from "antd";
import { ChevronDownIcon, ChevronLeftIcon, ChevronRightIcon, InformationCircleIcon } from "@heroicons/react/24/outline";
import moment, { months } from "moment";
import dayjs, { Dayjs } from "dayjs";
import { ArrowsAltOutlined, BarChartOutlined, DotChartOutlined, DownloadOutlined, LineChartOutlined, MergeCellsOutlined, ShrinkOutlined } from "@ant-design/icons";
import { title } from "process";

const DashbaordCards = lazy(() => import("@/app/dashboard/dashboard_cards"));
const DashboardTables = lazy(() => import("@/app/dashboard/dasboard_table"));

const { RangePicker } = DatePicker;
interface FilterOptions {
  options: any[];
}
interface Message {
  [key: string]: number;
}

interface ChartDataItem {
  provider: string;
  messages: Message;
}


const HomePage: React.FC = () => {
  const router = useRouter();
  const { username, partner, role, selectedDb,metaData, token, firstLastName, sessionId, setSelectedPartner } = useAuth();
  const [loading, setLoading] = useState(false);
  const [chartsData, setChartsData] = useState<any>([]);
  const setTitle = useLogoStore((state) => state.setTitle);
  const [filterOptions, setFilterOptions] = useState<FilterOptions>({
    options: [],
  });
  const [compareChartTitle, setCompareChartTitle] = useState("");
  const [selectedFilter, setSelectedFilter] = useState("All Service Providers");
  const [selectedButton, setSelectedButton] = useState<string | null>("Today");
  const [startDate, setStartDate] = useState<string>(
    moment().format("YYYY-MM-DD")
  );


  const [endDate, setEndDate] = useState<string>(moment().format("YYYY-MM-DD"));
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([
    null,
    null,
  ]);

  const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
  const presentYear = new Date().getFullYear();
  const presentMonth = dayjs().month();
  const { RangePicker } = DatePicker;
  const [selectedMonths, setSelectedMonths] = useState<any[]>([]);
  const [isCalendarVisible, setIsCalendarVisible] = useState(false);
  const [compareChartsOpen, setCompareChartsOpen] = useState(false)

  //new charts states
  const [multiLineChartData, setMultiLineChartData] = useState([]);
  const [lineChartData, setLineChartData] = useState([]);
  const [scatterDataForM2M, setScatterDataForM2M] = useState([]);
  const [barDataForCarrier, setBarDataForCarrier] = useState([]);
  const [barDataForCustomer, setBarDataForCustomer] = useState([]);
  const [horizontalBarChartData, setHorizontalBarChartData] = useState([]);
  const [scatterChartForMobility, setScatterChartForMobility] = useState([]);
  const [
    horizontalBarChartDataForGroupPool,
    setHorizontalBarChartDataForGroupPool,
  ] = useState([]);
  const [expandedChart, setExpandedChart] = useState(null);
  //Usage Details
  const [loadingUsageDetails, setLoadingUsageDetails] = useState(true);
  const [loadingMultiLineChart, setLoadingMultiLineChart] = useState(true);
  const [loadingScatterDataForM2M, setLoadingScatterDataForM2M] = useState(true);
  const [loadingBarDataForCarrier, setLoadingBarDataForCarrier] = useState(true);
  const [loadingBarDataForCustomer, setLoadingBarDataForCustomer] = useState(true);
  const [loadingHorizontalBarChartData, setLoadingHorizontalBarChartData] = useState(true);
  const [loadingScatterChartForMobility, setLoadingScatterChartForMobility] = useState(true);
  const [loadingHorizontalBarChartDataForGroupPool, setLoadingHorizontalBarChartDataForGroupPool] = useState(true);
  const [dashboardFeatures, setDashboardFeatures] = useState<string[]>([]);

  const [downloadLoading, setDownloadLoading] = useState<{ [key: string]: boolean }>({});
  
  const COLORS = ["#4ade80", "#67e8f9", "#6a8bcc"];
  const COLORSForBarTwo = [
    "#8884d8",
    "#82ca9d",
    "#ffc658",
    "#ff7300",
    "#0088fe",
    "#00C49F",
    "#FFBB28",
    "#FF8042",
    "#a4de6c",
    "#d0ed57",
    "#FFB6C1",
  ];
  const stackeDBarColors = [
    "#4ade80", // light green
    "#67e8f9", // sky blue
    "#6a8bcc", // medium blue
    "#facc15", // yellow
    "#f97316", // orange
    "#a78bfa", // lavender
    "#f472b6", // pink
    "#34d399", // teal
    "#c084fc", // purple
    "#ff8c00", // dark orange
    "#b4b4f9", // light purple
  ];

  // Inside your component
const [isSmallMediumScreen, setIsSmallMediumScreen] = useState(false);

useEffect(() => {
  const handleResize = () => {
    setIsSmallMediumScreen(window.innerWidth <= 1000); // Customize breakpoint if needed
  };

  handleResize(); // Set on mount
  window.addEventListener("resize", handleResize);

  return () => window.removeEventListener("resize", handleResize);
}, []);

  // useEffect(() => {
  //   router.push("/dashboard");
  // }, [router]);

  // useEffect(() => {
  //   setTitle("Dashboard");
  // });

  // useEffect(() => {
  //   setSelectedPartner(true);
  //   console.log("App mounted, fetching SSM parameters");
  //   setLoading(true);
  //   fetchSSMParameters()
  //     .then(() => {
  //       console.log("SSM parameters fetched successfully");
  //     })
  //     .catch((err) => {
  //       console.error("Error fetching SSM parameters:", err);
  //     })
  //     .finally(() => {
  //       setLoading(false);
  //       // setSelectedPartner(true);
  //     });
  // }, []);

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "bold",
    padding: "16px",
  };

  // const handleCalendarClick = (title: string) => {
  //   setCompareChartTitle(title);
  //   setCompareChartsOpen(true)
  //   setIsCalendarVisible(false);
  // };



const fetchDashboardFeatures = async () => {
  try {
    const url = ENV_ROUTES.MODULE_MANAGEMENT;
    const data = {
      tenant_name: partner || "default_value",
      username,
      firstLastName,
      path: "/get_dashboard_features",
      role_name: role,
      Partner: partner,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
    };

    const response = await axios.post(url, { data });
    const parsed = JSON.parse(response.data.body);

  if (parsed.flag && parsed?.module_features) {
  setDashboardFeatures(parsed?.module_features);
  localStorage.setItem(
    "dashboardFeatures",
    JSON.stringify(parsed?.module_features)
  );
  console.log("Dashboard 1.0 features:", parsed?.module_features);
}


  } catch (error) {
    console.error("Error fetching dashboard features:", error);
  }
};



  const downloadBlob = (base64Blob: string ,title:string) => {
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    const blobObject = new Blob([byteArray], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blobObject);
    link.download = `${title}.xlsx`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleDownloadTemplate = async (chartPath: any ,title:string) => {
    // setLoading(true);
    setDownloadLoading((prev) => ({ ...prev, [title]: true }));
    const url = ENV_ROUTES.DASHBOARD;
    const serviceProvidersFilter =
    selectedFilter === "All Service Providers" ? "All" : selectedFilter;
    const data = {
      partner,
      role_name: role,
      action: "download",
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      path: chartPath,
      service_providers: serviceProvidersFilter,
    };

    try {
      const response = await axios.post(url, { data });
      const resp = JSON.parse(response.data.body);
      if (response.data.statusCode === 200) {
        const blob = resp?.blob || '';
        if (resp.flag === true) {
          notification.success({
            message: "Success",
            description: "Successfully exported the record!",
            style: messageStyle,
            placement: "top",
          });
          downloadBlob(blob,title);
          // await fetchNewChartsData(selectedFilter, startDate, endDate);
        } else {
          console.log("Error message:", resp.message);
          Modal.error({
            title: "Export Error",
            content: resp.message,
            centered: true,
          });
        }
      } else {
        console.log("Unexpected status code:", response.data.statusCode);
        Modal.error({
          title: "Export Error",
          content: resp.message,
          centered: true,
        });
      }
    } catch (error) {
      console.error("An error occurred while downloading the template:", error);
      Modal.error({
        title: "Export Error",
        content: "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      // setLoading(false);
      setDownloadLoading((prev) => ({ ...prev, [title]: false }));
    }
  };


  const handleYearChange = (direction: "left" | "right") => {

    if (direction === "left") {
      setCurrentYear((prevYear) => prevYear - 1);
      setSelectedMonths([]);
    } else if (direction === "right" && currentYear + 1 <= presentYear) {
      setCurrentYear((prevYear) => prevYear + 1);
      setSelectedMonths([]);
    }

  };

  const handleMonthClick = (monthName: string, monthIndex: number) => {
    if (
      currentYear > presentYear ||
      (currentYear === presentYear && monthIndex > presentMonth)
    ) {
      return; // Prevent selecting future months
    }

    setSelectedMonths((prev) =>
      prev.includes(monthName)
        ? prev.filter((month) => month !== monthName) // Deselect if already selected
        : [...prev, monthName] // Select otherwise
    );
  };


  const handleChartClick = (chartType: any) => {
    switch (chartType) {
      case "bar":
        router.push("/sim_management/inventory");
        break;
      case "pie":
        router.push("/sim_management/inventory");
        break;
      case "bar_two":
        router.push("/sim_management/rev_assurance");
        break;
      case "stackedBar":
        router.push("/sim_management/bulk_change");
        break;
      default:
        break;
    }
  };

  // const fetchRevAssuranceRecordDiscrepancyData = async (
  //   startDate: any,
  //   endDate: any,
  //   selectedFilter: any
  // ) => {
  //   setLoading(true);
  //   try {
  //     const url = ENV_ROUTES.DASHBOARD;
  //     const serviceProvidersFilter =
  //       selectedFilter === "All service providers" ? "All" : selectedFilter;

  //     const requestData = {
  //       partner: partner,
  //       start_date: startDate,
  //       end_date: endDate,
  //       service_provider: serviceProvidersFilter,
  //       path: "/rev_assurance_record_discrepancy_card",
  //       access_token: token,
  //       db_name: selectedDb,
  //     };

  //     const response = await axios.post(url, { data: requestData });
  //     const parsedBody = JSON.parse(response.data.body);
  //     const data = parsedBody;
  //     const transformedData = data.data.map((item: any) => {
  //       return {
  //         provider: item.provider,
  //         ...item.messages, // Spread the messages object directly
  //       };
  //     }); // Flatten the array of arrays

  //     const revAssuranceData = {
  //       flag: data.flag,
  //       title: data.title,
  //       chart_type: data.chart_type,
  //       data: transformedData,
  //       xField: data.xField,
  //       yField: data.yField,
  //       height: data.height,
  //       width: data.width,
  //     };

  //     setChartsData((prevChartsData: any) => [
  //       ...prevChartsData,
  //       revAssuranceData,
  //     ]);
  //     return revAssuranceData;
  //   } catch (error: any) {
  //     console.error("Error fetching Rev Assurance Record Discrepancy data:", error);

  //     // Check for 504 error or any specific error type
  //     if (axios.isAxiosError(error) && error.response?.status === 504) {
  //       Modal.error({
  //         title: "Request Timed Out",
  //         content:
  //           "The request to fetch Rev Assurance Record Discrepancy data timed out.",
  //         centered: true,
  //       });
  //     } else {
  //       // Handle other potential errors
  //       Modal.error({
  //         title: "Error",
  //         content:
  //           "An unexpected error occurred while fetching Rev Assurance Record Discrepancy data.",
  //         centered: true,
  //       });
  //     }
  //   } finally {
  //     setLoading(false);
  //   }
  // };

  const fetchData = async (
    startDate: any,
    endDate: any,
    selectedFilter: any
  ) => {
    // setLoading(true);
    try {
      const url = ENV_ROUTES.DASHBOARD;
      const requestPaths = [
        { path: "/device_status_chart" },
        { path: "/activated_vs_deactivated_pie_chart" },
        { path: "/service_provider_change_request_stack_bar" },
      ];

      const serviceProvidersFilter =
        selectedFilter === "All Service Providers" ? "All" : selectedFilter;

      const promises = requestPaths.map(({ path }) => {
        const requestData = {
          partner: partner,
          role_name: role,
          start_date: startDate,
          end_date: endDate,
          service_provider: serviceProvidersFilter,
          path,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          username: username,
          filter:selectedButton || null,
        };

        return axios.post(url, { data: requestData }).then((response) => {
          const parsedBody = JSON.parse(response.data.body);
          const { data } = parsedBody;
          return {
            title: data.title,
            chart_type: data.chart_type,
            data: data.data,
            angleField: data.angleField,
            colorField: data.colorField,
            radius: data.radius,
            innerRadius: data.innerRadius,
            height: data.height,
            width: data.width,
            xField: data.xField,
            yField: data.yField,
            smooth: data.smooth,
            isStacked: data.isStacked,
          };
        });
      });
      const results = await Promise.allSettled(promises);
      const successfulResults = results
        .filter((result) => result.status === "fulfilled")
        .map((result) => result.value);
        // ✅ Filter charts based on allowed dashboard features
// ✅ Filter graphs based on allowed features
const storedFeatures = JSON.parse(localStorage.getItem("dashboardFeatures") || "[]");

const filteredResults = successfulResults.filter((chart) => {
  const title = chart.title?.trim();
  const featureName = `${title}-Dashboard`;
  return storedFeatures.includes(featureName);
});

setChartsData(filteredResults);



    } catch (error) {
      console.error("Error fetching data in dashboard:", error);
    } finally {
      // setLoading(false);
    }
  };
  const fetchNewChartsData = async (startDate: any, endDate: any, selectedFilter: any) => {
    const url = ENV_ROUTES.DASHBOARD;
    const serviceProvidersFilter =
      selectedFilter === "All Service Providers" ? "All" : selectedFilter;

    console.log(serviceProvidersFilter,"and",selectedFilter)
  
    const requestData = {
      tenant_name: partner || "default_value",
      username: username,
      role_name: role,
      parent_module: "Sim Management",
      module_name: "Dashboard",
      request_received_at: getCurrentDateTime(),
      partner,
      service_providers: serviceProvidersFilter,
      access_token: token,
      db_name: selectedDb,
      ...metaData,
    };
  
    // Function to make individual API requests
    const fetchDataForPath = async (path: string) => {
      try {
        const response = await axios.post(url, {
          data: { ...requestData, path },
        });
        return JSON.parse(response.data.body);
      } catch (error) {
        console.error(`Error fetching data for ${path}:`, error);
        return null; // Return null for failed requests
      }
    };
  
    // Define all fetch operations
    const operations = [
      fetchDataForPath("/get_device_status_card").then((data) => {
        if (data) {
          const deviceStatusData = data.device_status_card_data.map((item: any) => ({
            month: item.month,
            Active: item.Active,
            ActivationReady: item.ActivationReady,
            Inventory: item.Inventory,
            TestReady: item.TestReady,
            Deactivated: item.Deactivated,
            TotalTNs: item.TotalTNs,
          }));
          setMultiLineChartData(deviceStatusData);
          setLoadingMultiLineChart(false);
          
        }
      }),
      fetchDataForPath("/get_high_usage_chart_data").then((data) => {
        if (data) {
          const scatterDataForM2M = data.high_usage_chart_card_data.map((item: any) => ({
            usage: item.usage,
            session: item.session,
            iccid:item.iccid
          }));
          setScatterDataForM2M(scatterDataForM2M);
          setLoadingScatterDataForM2M(false);
        }
      }),
      fetchDataForPath("/get_usage_details_card").then((data) => {
        if (data) {
          const lineChartData = data.usage_details_card.map((item: any) => ({
            name: item.name,
            usagePerTN: item.usagePerTN,
            dataUsageByMonth: item.dataUsageByMonth,
          }));
          setLineChartData(lineChartData);
          setLoadingUsageDetails(false);
        }
      }),
      fetchDataForPath("/get_carrier_rate_plan_data").then((data) => {
        if (data) {
          const barDataForCarrier = data.rate_plan_data.map((item: any) => ({
            dataLimit: item.dataLimit,
            tnCount: item.tnCount,
          }));
          setBarDataForCarrier(barDataForCarrier);
          setLoadingBarDataForCarrier(false);

        }
      }),
      fetchDataForPath("/get_customer_rate_plan_data").then((data) => {
        if (data) {
          const barDataForCustomer = data.rate_plan_data.map((item: any) => ({
            dataLimit: item.dataLimit,
            tnCount: item.tnCount,
          }));
          setBarDataForCustomer(barDataForCustomer);
          setLoadingBarDataForCustomer(false);
        }
      }),
      // fetchDataForPath("/mobility_high_usage_chart").then((data) => {
      //   if (data) {
      //     const scatterChartForMobility = data.mobility_high_usage_chart.map((item: any) => ({
      //       usage: item.usage,
      //       percentUsed: item.percentUsed,
      //     }));
      //     setScatterChartForMobility(scatterChartForMobility);
      //     setLoadingScatterChartForMobility(false);
      //   }
      // }),
      fetchDataForPath("/mobility_usage_per_customer_pool").then((data) => {
        if (data) {
          const horizontalBarChartData = data.mobility_usage_per_customer_pool.map((item: any) => ({
            name: item.name,
            value: item.value,
          }));
          setHorizontalBarChartData(horizontalBarChartData);
          setLoadingHorizontalBarChartData(false);
        }
      }),
      fetchDataForPath("/mobility_usage_per_group_pool").then((data) => {
        if (data) {
          const horizontalBarChartDataForGroupPool = data.mobility_usage_per_group_pool.map(
            (item: any) => ({
              name: item.name,
              value: item.value,
            })
          );
          setHorizontalBarChartDataForGroupPool(horizontalBarChartDataForGroupPool);
          setLoadingHorizontalBarChartDataForGroupPool(false);
        }
      }),
    ];
  
    try {
      // Execute all operations concurrently
      await Promise.all(operations);
    } catch (error) {
      console.error("Error fetching chart data:", error);
    }
  };
  
  


  // useEffect(() => {
  //   fetchFilterOptions();
  //   fetchData(startDate, endDate, selectedFilter);
  //   fetchNewChartsData(startDate, endDate, selectedFilter)
  // }, [startDate, endDate, selectedFilter]);
  useEffect(() => {
    const initializeDashboard = async () => {
      setSelectedPartner(true); // Keep this as it is for setting the partner state
      console.log("App mounted, fetching SSM parameters");
      setLoading(true); // Start loading state
  
      try {
        // Fetch SSM Parameters first
        // await fetchSSMParameters();
        console.log("SSM parameters fetched successfully");
        await fetchDashboardFeatures(); // 👈 call the new API

        // Proceed to fetch the filter options and data after SSM parameters are ready
        await fetchFilterOptions(); // Fetch the filter options
  
        // Fetch data with the selected start and end dates, and the selected filter
        await fetchData(startDate, endDate, selectedFilter);
        await fetchNewChartsData(startDate, endDate, selectedFilter);
      } catch (error) {
        console.error("Error during initialization:", error);
      } finally {
        setLoading(false); // Stop loading state
      }
    };
  
    // Call the initialization function
    initializeDashboard();
  }, [startDate, endDate, selectedFilter]); // Dependencies to re-run the effect when dates or filters change

  const handleCalendarClick = (title: string) => {
    setCompareChartTitle(title);
    setCompareChartsOpen(true)
    setIsCalendarVisible(false);
  };
  const titlePathMap: any = {
    "Device Status": "/device_status_chart",
    "Activated vs Deactivated": "/activated_vs_deactivated_pie_chart",
    "Change Request Types per Service Provider": "/service_provider_change_request_stack_bar",
    "Rev assurance-record discrepancies": "/rev_assurance_record_discrepancy_card",
  }
  

  // useEffect(() => {
  //   fetchRevAssuranceRecordDiscrepancyData(startDate, endDate, selectedFilter);
  // }, [startDate, endDate, selectedFilter]);

  const renderCustomizedLabel = ({
    cx,
    cy,
    midAngle,
    innerRadius,
    outerRadius,
    percent,
  }: any) => {
    const RADIAN = Math.PI / 180;
    const radius = innerRadius + (outerRadius - innerRadius) * 0.35;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    
    return (
      <text
        x={x}
        y={y}
        fill="white"
        textAnchor="middle"
        dominantBaseline="central"
        fontSize="16"
      >
        {`${(percent * 100).toFixed(0)}%`}
      </text>
    );
  };

  const handleButtonClick = (
    range: "Today" | "Current Week" | "Current Month"
  ) => {
    setSelectedButton(range);

    if (range === "Today") {
      setDateRange([null, null]);
      const today = moment().format("YYYY-MM-DD");
      setStartDate(today);
      setEndDate(today);
    } else if (range === "Current Week") {
      setDateRange([null, null]);
      setStartDate(moment().startOf("week").format("YYYY-MM-DD"));
      setEndDate(moment().endOf("week").format("YYYY-MM-DD"));
    } else if (range === "Current Month") {
      setDateRange([null, null]);
      setStartDate(moment().startOf("month").format("YYYY-MM-DD"));
      setEndDate(moment().endOf("month").format("YYYY-MM-DD"));
    }
  };

  const handleDateRangeChange = (
    dates: [Dayjs | null, Dayjs | null] | null,
    dateStrings: [string, string]
  ) => {
    setSelectedButton(null);
    if (dates && dates[0] && dates[1]) {
      setDateRange([dates[0], dates[1]]);
      setStartDate(dates[0].format("YYYY-MM-DD"));
      setEndDate(dates[1].format("YYYY-MM-DD"));
      setSelectedButton("");
    } else {
      setDateRange([null, null]);
      setSelectedButton("Today");
    }
  };

  useEffect(() => {
    let startDate = "";
    let endDate = "";

    if (selectedButton === "Today") {
      startDate = moment().format("YYYY-MM-DD");
      endDate = moment().format("YYYY-MM-DD");
    } else if (selectedButton === "Current Week") {
      startDate = moment().startOf("week").format("YYYY-MM-DD");
      endDate = moment().endOf("week").format("YYYY-MM-DD");
    } else if (selectedButton === "Current Month") {
      startDate = moment().startOf("month").format("YYYY-MM-DD");
      endDate = moment().endOf("month").format("YYYY-MM-DD");
    } else if (dateRange[0] && dateRange[1]) {
      startDate = dateRange[0].format("YYYY-MM-DD");
      endDate = dateRange[1].format("YYYY-MM-DD");
    }

    fetchData(startDate, endDate, selectedFilter);
  }, [selectedButton, dateRange, selectedFilter]);

  const fetchFilterOptions = async () => {
    try {
      const url = ENV_ROUTES.DASHBOARD;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_service_providers",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Dashboard",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      const serviceProviders = parsedData.service_providers
        .sort((a: string, b: string) => a.localeCompare(b))
        .map((provider: any) => ({
          value: provider,
          label: provider,
        }));
      setFilterOptions({ options: serviceProviders });
    } catch (error) {
      console.error(error);
    }
  };
  const closeCompareCharts = () => {
    setSelectedMonths([]);
    setCurrentYear(presentYear)
    setCompareChartsOpen(false)
  }

  const handleFilterChange = async (value: any) => {
    setSelectedFilter(value);
    await fetchData(startDate, endDate, value);
  };

  const formatStackedBarData = (data: any[]) => {
    if (!data || data.length === 0) {
      // show static data if response data is zero
      const staticData = [
        {
          service_provider: "Jasper",
          Active: 0,
          "Assign Customer": 0,
          "Change ICCID/MEI": 0,
        },
        {
          service_provider: "POD 19",
          Active: 0,
          "Assign Customer": 0,
          "Change ICCID/MEI": 0,
        },
        {
          service_provider: "Telegence",
          Active: 0,
          "Assign Customer": 0,
          "Change ICCID/MEI": 0,
        },
        {
          service_provider: "Rogers",
          Active: 0,
          "Assign Customer": 0,
          "Change ICCID/MEI": 0,
        },
        {
          service_provider: "Teal",
          Active: 0,
          "Assign Customer": 0,
          "Change ICCID/MEI": 0,
        },
        {
          service_provider: "T-Mobile",
          Active: 0,
          "Assign Customer": 0,
          "Change ICCID/MEI": 0,
        },
      ];

      const staticCategories = [
        "Active",
        "Assign Customer",
        "Change ICCID/MEI",
      ];

      return {
        data: staticData,
        categories: staticCategories,
      };
    }

    const result = [];
    const categories = new Set();

    // Create a map to aggregate counts for each service provider and change request type
    const dataMap: any = {};

    data.forEach((item) => {
      const { service_provider, change_request_type, count } = item;
      categories.add(change_request_type);

      // Initialize entry if service_provider doesn't exist in map
      if (!dataMap[service_provider]) {
        dataMap[service_provider] = { service_provider };
      }
      // Set or add the count to the respective change request type
      dataMap[service_provider][change_request_type] = count;
    });

    // Convert map to array format
    for (const key in dataMap) {
      result.push(dataMap[key]);
    }

    return {
      data: result,
      categories: Array.from(categories),
    };
  };
 

  const renderControls = () => {
    const availableOptions = filterOptions.options.filter(
      (option: any) => option.value !== selectedFilter
    ); 
    const isSmallScreen = typeof window !== "undefined" && window.innerWidth < 700;

    if (isSmallScreen) {
      return (
        <div className="flex flex-col gap-4 mx-3 my-2">
          {/* First Row: Select and RangePicker */}
          <div className="flex justify-between items-center gap-2">
            <Select
              style={{
                width: "100%",
                maxWidth: 200,
                fontWeight: "450",
                height: "47px",
                fontFamily: "Calibri, sans-serif",
                borderRadius: "8px",
              }}
              value={selectedFilter}
              onChange={handleFilterChange}
              options={availableOptions}
              notFoundContent="No options available"
              showSearch
              suffixIcon={<ChevronDownIcon className="w-4 h-4 text-gray-600" />}
              className="flex-1"
            />
            <RangePicker
              value={dateRange}
              onChange={handleDateRangeChange}
              style={{
                width: "100%",
                maxWidth: 250,
                height: "47px",
                borderRadius: "8px",
              }}
              disabledDate={(current) =>
                current && current > dayjs().endOf("day")
              }
              popupClassName="custom-range-popup"
              className="flex-1 small-screen-range-picker"
            />
          </div>
          {/* Second Row: Select label and Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            <span
              style={{
                fontFamily: "Calibri, sans-serif",
                fontSize: "16px",
              }}
              className="mr-2"
            >
              Select:
            </span>
            <button
              className={
                selectedButton === "Today"
                  ? "save-btn"
                  : "email-dashboard-btns"
              }
              onClick={() => handleButtonClick("Today")}
              style={{
                fontFamily: "Calibri, sans-serif",
                fontSize: "14px",
                padding: "8px 12px",
              }}
            >
              Today
            </button>
            <button
              className={
                selectedButton === "Current Week"
                  ? "save-btn"
                  : "email-dashboard-btns"
              }
              onClick={() => handleButtonClick("Current Week")}
              style={{
                fontFamily: "Calibri, sans-serif",
                fontSize: "14px",
                padding: "8px 12px",
              }}
            >
              Current Week
            </button>
            <button
              className={
                selectedButton === "Current Month"
                  ? "save-btn"
                  : "email-dashboard-btns"
              }
              onClick={() => handleButtonClick("Current Month")}
              style={{
                fontFamily: "Calibri, sans-serif",
                fontSize: "14px",
                padding: "8px 12px",
              }}
            >
              Current Month
            </button>
          </div>
        </div>
        
      );
    }
 
  
    return (
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "flex-end",
          marginBottom: "10px",
          marginTop: "10px",
          marginRight: "12px",
        }}
        className="flex flex-wrap gap-2"
      >
        <Select
          style={{
            width: 200,
            fontWeight: "450",
            height: "47px",
            fontFamily: "Calibri, sans-serif",
            borderRadius: "8px",
          }}
          value={selectedFilter}
          onChange={handleFilterChange}
          options={availableOptions}
          notFoundContent="No options available"
          showSearch
          suffixIcon={<ChevronDownIcon className="w-4 h-4 text-gray-600" />}
        />
        <span
          style={{
            marginLeft: 10,
            marginRight: 20,
            fontFamily: "Calibri, sans-serif",
            fontSize: "16px",
            marginTop: "-2px",
          }}
        >
          Select:
        </span>
        <button
          className={
            selectedButton === "Today" ? "save-btn" : "email-dashboard-btns"
          }
          onClick={() => handleButtonClick("Today")}
          style={{
            marginRight: 10,
            fontFamily: "Calibri, sans-serif",
            fontSize: "16px",
            padding: "10px",
            marginTop: "-2px",
          }}
        >
          Today
        </button>
        <button
          className={
            selectedButton === "Current Week"
              ? "save-btn"
              : "email-dashboard-btns"
          }
          onClick={() => handleButtonClick("Current Week")}
          style={{
            marginRight: 10,
            fontFamily: "Calibri, sans-serif",
            fontSize: "16px",
            padding: "10px",
            marginTop: "-2px",
          }}
        >
          Current Week
        </button>
        <button
          className={
            selectedButton === "Current Month"
              ? "save-btn"
              : "email-dashboard-btns"
          }
          onClick={() => handleButtonClick("Current Month")}
          style={{
            marginRight: 10,
            fontFamily: "Calibri, sans-serif",
            fontSize: "16px",
            padding: "10px",
            marginTop: "-2px",
          }}
        >
          Current Month
        </button>
        <RangePicker
          value={dateRange}
          onChange={handleDateRangeChange}
          style={{
            marginLeft: "2px",
            marginRight: "5px",
            height: "47px",
            borderRadius: "8px",
          }}
          popupClassName="custom-range-popup"
          disabledDate={(current) => current && current > dayjs().endOf("day")}
        />
      </div>
    );
  
  };

 const formatXAxisLabel = (value:any) => {
  if (!value) return "";

  // Split by any group of non-word characters (space, special chars, etc)
  let parts = value.trim().split(/[\s\-\_]+/).filter(Boolean);

  // If 4 parts or less, show whole
  if (parts.length <= 3) return parts.join(" ");

  // First line → first 2 parts
  const firstLine = parts.slice(0, 2).join(" ");

  // Rest goes to second line
  let secondLineParts = parts.slice(2);

  // If too many, compress each part to first 2 characters
  if (secondLineParts.length > 3) {
    secondLineParts = secondLineParts
      .slice(0, 3)
      .map((p:any) => p.substring(0, 2)) // First 2 chars only
      .join(" ") + "...";
  } else {
    // Otherwise join normally
    secondLineParts = secondLineParts.join(" ");
  }

  return `${firstLine}\n${secondLineParts}`;
};



  const renderChart = (chart: any) => {
    switch (chart.chart_type) {
      case "bar":
        return (
              <ResponsiveContainer width="100%" height={400}>
                <BarChart
                  data={chart.data}
                  margin={{ top: 20, right: 30, left: 20, bottom: 60 }}
                  onClick={() => handleChartClick("bar")}
                >
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis
                dataKey="status"
                axisLine={false}
                tickLine={false}
                interval={0}
                height={ 100} // give enough room for vertical labels
                angle={ -50 }   // vertical on small screens
                textAnchor={ "end" }
                tick={{
                  fontSize: isSmallMediumScreen ? 14 : 16,
                }}
                label={{
                  value: "Status",
                  position: "insideBottom",
                  offset: -20,
                }}
              />
                  <YAxis
                    axisLine={false}
                    tickLine={false}
                    // domain={[0, 600]}
                    // ticks={[0, 100, 200, 300, 400, 500, 600]}
                    // label={{
                    //   value: "No. of Records",
                    //   angle: -90,
                    //   position: "left",
                    //   offset: -10,
                    //   dy: -35,
                    // }}
                  />
                  <Tooltip cursor={{fill: 'transparent'}} />
                  <Bar dataKey="count" fill="#2196f3" radius={[0, 0, 0, 0]} filter="none"  isAnimationActive={false}   onMouseEnter={() => {}}
  onMouseLeave={() => {}}/>
                </BarChart>
              </ResponsiveContainer>   
        );

      case "bar_two": {
        const flattenedData = (chart.data || []).map((item: any) => item);
        const uniqueStatuses = Array.from(
          new Set(
            chart.data.flatMap((item: any) =>
              Object.keys(item).filter((key) => key !== "provider")
            )
          )
        ) as string[];

        const containsData = flattenedData.length > 0;
        const defaultData = [{ provider: "No data", count: 0 }];
        return (
          <div style={{ width: "90vw", maxWidth: "100%" }}>
            <ResponsiveContainer width="100%" height={450}>
              <BarChart
                data={containsData ? flattenedData : defaultData}
                margin={{ top: 20, right: 30, left: 20, bottom: 70 }}
                barSize={20}
                onClick={() => handleChartClick("bar_two")}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                <XAxis
                  dataKey="provider"
                  axisLine={false}
                  tickLine={false}
                  label={{
                    value: "Service Provider",
                    position: "bottom",
                    offset: 40,
                  }}
                  interval={0}
                />
                <YAxis
                  axisLine={false}
                  tickLine={false}
                  domain={[0, "auto"]}
                  label={{
                    value: "No. of records",
                    angle: -90,
                    position: "insideLeft",
                    offset: 0,
                  }}
                />
                <Tooltip />
                <Legend
                  align="center"
                  verticalAlign="bottom"
                  iconType="square"
                  wrapperStyle={{
                    display: "flex",
                    width: "100%",
                    maxHeight: 80,
                    textAlign: "center",
                    paddingBottom: 8,
                    marginTop: "5px",
                    fontSize: 15,
                    flexWrap: "wrap",
                    justifyContent: "center",
                  }}
                />
                {containsData
                  ? uniqueStatuses.map((status, index) => (
                    <Bar
                      key={status}
                      dataKey={status}
                      name={status}
                      fill={COLORSForBarTwo[index % COLORSForBarTwo.length]}
                      radius={[0, 0, 0, 0]}
                    />
                  ))
                  : <Bar dataKey="count" fill="#e0e0e0" />}
              </BarChart>
            </ResponsiveContainer>
          </div>
        );
      }


      case "pie": {
        const hasNonZeroData =
          chart.data &&
          chart.data.some((item: { count: number }) => item.count > 0);

        const transformedData =
          chart.data?.map((item: { status: string; count: number }) => ({
            name: item.status,
            value: item.count,
          })) || [];

        return (
          <div
            style={{
              height: "280px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
            onClick={() => handleChartClick("pie")}
          >
            {hasNonZeroData ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={transformedData}
                    cx="50%"
                    cy="50%"
                    innerRadius={80}
                    outerRadius={130}
                    fill="#8884d8"
                    paddingAngle={0}
                    minAngle={6}
                    dataKey="value"
                    nameKey="name"
                    label={renderCustomizedLabel}
                    labelLine={false}
                  >
                    {transformedData.map((entry: any, index: number) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={COLORS[index % COLORS.length]}
                      />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend
                    layout="horizontal"
                    align="center"
                    verticalAlign="bottom"
                    iconType="square"
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={[{ name: "No data", value: 1 }]}
                    cx="50%"
                    cy="50%"
                    innerRadius={80}
                    outerRadius={120}
                    fill="#f0f0f0"
                    dataKey="value"
                    labelLine={false}
                    isAnimationActive={false}
                  />
                  <text
                    x="50%"
                    y="50%"
                    textAnchor="middle"
                    fill="#8884d8"
                    style={{
                      fontSize: "16px",
                      fontFamily: "Calibri, sans-serif",
                    }}
                  >
                    No Data
                  </text>
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        );
      }

      case "stackedBar":
        const formattedData = formatStackedBarData(chart.data);
        const hasData = Array.isArray(chart.data) && chart.data.length > 0;
        // ✅ Calculate providerCount OUTSIDE the JSX
        const providerCount = formattedData?.data?.length || 0;
        return (
          <div style={{ width: "90vw", maxWidth: "100%" }}>
            <ResponsiveContainer width="100%" height={400}>
              <BarChart
                data={formattedData.data}
                margin={{ top: 20, right: 30, left: 20, bottom: isSmallMediumScreen ? 10 : 60 }}
                onClick={() => handleChartClick("stackedBar")}
              >
                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                
                <XAxis
                  dataKey="service_provider"
                  axisLine={false}
                  tickLine={false}
                  height={isSmallMediumScreen ? 150 : 40}
                  angle={isSmallMediumScreen ? -60 : 0}
                  textAnchor={isSmallMediumScreen ? "end" : "middle"}
                  tickFormatter={(value) => {
                    console.log("Original XAxis value:", value);
                    const providerCount = formattedData?.data?.length || 0;
                    console.log("Total number of providers:", providerCount);
                    
                    // If 4 or fewer providers → return as-is (or with non-breaking spaces)
                    // if (providerCount <= 4) {
                    //   console.log("Simple format");
                    //   return isSmallMediumScreen
                    //     ? value.replace(/ /g, "\u00A0") // Prevent word-break
                    //     : value;
                    // }
                    
                    // Otherwise use multi-line formatter
                    console.log("Multi-line format");
                    return formatXAxisLabel(value);
                  }}
                  interval={0}
                  tick={{
                    fontSize: providerCount <= 4 ? (isSmallMediumScreen ? 12 : 16) : 9,
                    width: providerCount <= 4 ? 5 : 15,
                    fontWeight:providerCount<=4?'normal':'600',
                    style: { whiteSpace: "pre-line" }
                  }}
                />



                <YAxis
                  axisLine={false}
                  tickLine={false}
                  domain={[0, "dataMax + 10"]}
                  label={{
                    value: "No. of Change Requests",
                    angle: -90,
                    position: "insideLeft",
                    offset: -8,
                    style: { textAnchor: "middle" },
                  }}
                  interval={0}
                />
                <Tooltip cursor={{fill: 'transparent'}}/>
                <Legend
                  className="stacked-bar-legend"
                  align="center"
                  verticalAlign="bottom"
                  iconType="square"
                  wrapperStyle={{
                    width: "fit-content",
                    textAlign: "center",
                    paddingTop: isSmallMediumScreen ? 0 : 20,
                    // paddingBottom: 6,
                    marginTop:isSmallMediumScreen ? 2 : 50,
                    maxHeight: isSmallMediumScreen ? "auto" : 50,
                    fontSize: isSmallMediumScreen ? 14 : 15,
                    flexWrap: "wrap",
                    justifyContent: "center",
                  }}
                  payload={formattedData.categories.map((category, index) => ({
                    value: category,
                    type: "square",
                    color: stackeDBarColors[index % stackeDBarColors.length],
                  }))}
                />
                {formattedData.categories.map((category, index) => (
                  <Bar
                    key={index}
                    dataKey={category as string}
                    stackId="a"
                    fill={stackeDBarColors[index % stackeDBarColors.length]}
                  />
                ))}
              </BarChart>
            </ResponsiveContainer>
          </div>
        );

      default:
        return null;
    }
  };

  const toggleExpand = (chartIndex: any) => {
    setExpandedChart(expandedChart === chartIndex ? null : chartIndex);
  };
  
  const isExpanded = (index: any) => expandedChart === index;

  const renderNewCharts = () => {
    const fullScreenStyle: React.CSSProperties = {
      position: "fixed",
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      zIndex: 1000,
      // backgroundColor: "white",
    };
    if (loading) {
      return (
        <div className="flex justify-center items-center h-screen">
          <Spin size="large" />
        </div>
      );
    }

    return (
      <>
        <div className="flex flex-col items-center justify-center min-h-screen mb-10">
          <div className="p-6 w-full rounded-xl space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* BiAxial Line Chart */}
              {dashboardFeatures.includes("Usage Details-Dashboard") && (
              <div
                className={`bg-white p-4 rounded-lg shadow-md graph ${
                  isExpanded(0) ? "full-screen" : ""
                }`}
                style={isExpanded(0) ? fullScreenStyle : {}}
              >
                <div className="bg-gray-100 chart-title flex justify-between items-center p-4">
                  <div className="flex items-center">
                    <LineChartOutlined className="cursor-pointer mr-2" />
                    <h2 className="font-semibold">Usage Details</h2>
                  </div>
                  <div className="flex items-center">
                    <div>
                      {downloadLoading["Usage Details"]?(
                        <div className="h-5 w-5 border-2 border-gray-500 border-t-transparent rounded-full animate-spin"></div>
                      ):(
                        <DownloadOutlined
                          className="cursor-pointer mr-2"
                          onClick={() =>
                      handleDownloadTemplate("/get_usage_details_card","Usage Details")
                    }/>
                      )}
                    </div>
                    
                    <div
                      className="cursor-pointer"
                      onClick={() => toggleExpand(0)}
                    >
                      {expandedChart === 0 ? (
                        <ShrinkOutlined />
                      ) : (
                        <ArrowsAltOutlined />
                      )}
                    </div>
                  </div>
                </div>

                <ResponsiveContainer
                  width="100%"
                  height={isExpanded(0) ? "90%" : 300}
                >
                  {loadingUsageDetails ? (
                    <div className="flex flex-row justify-center items-center pt-32">
                    <Spin size="large" />
                  </div>  ) : (
                  lineChartData && lineChartData.length > 0 ? (
                    <LineChart data={lineChartData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      {/* Left Y-Axis */}
                      <YAxis yAxisId="left" />
                      {/* Right Y-Axis */}
                      <YAxis yAxisId="right" orientation="right" />
                      <Tooltip />
                      <Legend />
                      {/* Line for "Usage per TN (MB)" */}
                      <Line
                        yAxisId="left"
                        type="monotone"
                        dataKey="usagePerTN"
                        stroke="green"
                        strokeWidth={3}
                        dot={{ r: 4 }}
                      />
                      {/* Line for "Data Usage by Month (MB)" */}
                      <Line
                        yAxisId="right"
                        type="monotone"
                        dataKey="dataUsageByMonth"
                        stroke="blue"
                        strokeWidth={3}
                        dot={{ r: 4 }}
                      />
                    </LineChart>
                  ) : (
                    <LineChart
                      data={[{ name: "", usagePerTN: 0, dataUsageByMonth: 0 }]}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      {/* Left Y-Axis */}
                      <YAxis yAxisId="left" />
                      {/* Right Y-Axis */}
                      <YAxis yAxisId="right" orientation="right" />
                      <Tooltip />
                      <Legend />
                      {/* Empty Lines for visibility of graph layout */}
                      <Line
                        yAxisId="left"
                        type="monotone"
                        dataKey="usagePerTN"
                        stroke="green"
                        strokeWidth={3}
                        dot={{ r: 4 }}
                      />
                      <Line
                        yAxisId="right"
                        type="monotone"
                        dataKey="dataUsageByMonth"
                        stroke="blue"
                        strokeWidth={3}
                        dot={{ r: 4 }}
                      />
                    </LineChart>
                  )
                  )}
                </ResponsiveContainer>
              </div>
              )}

              {/* Multi line chart */}
              {dashboardFeatures.includes("Device status-Dashboard") && (
              <div
                className={`bg-white p-4 rounded-lg shadow-md graph ${
                  isExpanded(1) ? "full-screen" : ""
                }`}
                style={isExpanded(1) ? fullScreenStyle : {}}
              >
                <div className="bg-gray-100 chart-title flex justify-between items-center p-4">
                  <div className="flex items-center">
                    <LineChartOutlined className="cursor-pointer mr-2" />
                    <h2 className="font-semibold">Device status</h2>
                  </div>
                  <div className="flex items-center">
                  <div>
                      {downloadLoading["Device status"]?(
                        <div className="h-5 w-5 border-2 border-gray-500 border-t-transparent rounded-full animate-spin"></div>
                      ):(
                        <DownloadOutlined
                          className="cursor-pointer mr-2"
                          onClick={() =>
                            handleDownloadTemplate("/get_device_status_card","Device status")
                    }/>
                      )}
                    </div>
                    <div
                      className="cursor-pointer"
                      onClick={() => toggleExpand(1)}
                    >
                      {expandedChart === 1 ? (
                        <ShrinkOutlined />
                      ) : (
                        <ArrowsAltOutlined />
                      )}
                    </div>
                  </div>
                </div>

                <ResponsiveContainer
                  width="100%"
                  height={isExpanded(1) ? "90%" : 300}
                  // style={{ marginBottom: "2px" }}
                >
                  {loadingMultiLineChart ? (
                    <div className="flex flex-row justify-center items-center pt-32">
                    <Spin size="large" />
                  </div>  ) :
                   (
                  multiLineChartData && multiLineChartData.length > 0 ? (
                    <LineChart
                      data={multiLineChartData}
                      // margin={{  bottom: 10, top: 10, right: 6  }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      {/* Multiple Lines for different data categories */}
                      <Line
                        type="monotone"
                        dataKey="Active"
                        stroke="#00b200"
                        strokeWidth={3}
                      />
                      <Line
                        type="monotone"
                        dataKey="ActivationReady"
                        stroke="#00e7e7"
                        strokeWidth={3}
                      />
                      <Line
                        type="monotone"
                        dataKey="Inventory"
                        stroke="#6e6e6e"
                        strokeWidth={3}
                      />
                      <Line
                        type="monotone"
                        dataKey="TestReady"
                        stroke="#ffd700"
                        strokeWidth={3}
                      />
                      <Line
                        type="monotone"
                        dataKey="Deactivated"
                        stroke="#ff0000"
                        strokeWidth={3}
                      />
                      <Line
                        type="monotone"
                        dataKey="TotalTNs"
                        stroke="#6abff8"
                        strokeWidth={3}
                      />
                    </LineChart>
                  ) : (
                    <LineChart
                      data={[
                        {
                          month: "",
                          Active: 0,
                          ActivationReady: 0,
                          Inventory: 0,
                          TestReady: 0,
                          Deactivated: 0,
                          TotalTNs: 0,
                        },
                      ]}
                      margin={{ top: 10, right: 6 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="month" />
                      <YAxis />
                      <Tooltip />
                      <Legend />
                      {/* Empty Lines for visibility of graph layout */}
                      <Line
                        type="monotone"
                        dataKey="Active"
                        stroke="#00b200"
                        strokeWidth={3}
                      />
                      <Line
                        type="monotone"
                        dataKey="ActivationReady"
                        stroke="#00e7e7"
                        strokeWidth={3}
                      />
                      <Line
                        type="monotone"
                        dataKey="Inventory"
                        stroke="#6e6e6e"
                        strokeWidth={3}
                      />
                      <Line
                        type="monotone"
                        dataKey="TestReady"
                        stroke="#ffd700"
                        strokeWidth={3}
                      />
                      <Line
                        type="monotone"
                        dataKey="Deactivated"
                        stroke="#ff0000"
                        strokeWidth={3}
                      />
                      <Line
                        type="monotone"
                        dataKey="TotalTNs"
                        stroke="#6abff8"
                        strokeWidth={3}
                      />
                    </LineChart>
                  ))}
                </ResponsiveContainer>
              </div>
              )}

              {/* Scatter Chart for m2m */}
              {dashboardFeatures.includes("High Data Usage-Dashboard") && (
              <div
                className={`bg-white p-4 rounded-lg shadow-md graph ${
                  isExpanded(2) ? "full-screen" : ""
                }`}
                style={isExpanded(2) ? fullScreenStyle : {}}
              >
                <div className="bg-gray-100 chart-title flex justify-between items-center p-4">
                  <div className="flex items-center">
                    <DotChartOutlined className="cursor-pointer mr-2" />
                    <h2 className="font-semibold">High Data Usage</h2>
                  </div>
                  <div className="flex items-center">
                  <div>
                      {downloadLoading["High Data Usage"]?(
                        <div className="h-5 w-5 border-2 border-gray-500 border-t-transparent rounded-full animate-spin"></div>
                      ):(
                        <DownloadOutlined
                          className="cursor-pointer mr-2"
                          onClick={() =>
                            handleDownloadTemplate("/get_high_usage_chart_data","High Data Usage")
                    }/>
                      )}
                    </div>
                    <div
                      className="cursor-pointer"
                      onClick={() => toggleExpand(2)}
                    >
                      {expandedChart === 2 ? (
                        <ShrinkOutlined />
                      ) : (
                        <ArrowsAltOutlined />
                      )}
                    </div>
                  </div>
                </div>

                <ResponsiveContainer
                  width="100%"
                  height={isExpanded(2) ? "90%" : 300}
                >
                  {
                  loadingScatterDataForM2M ? (
                    <div className="flex flex-row justify-center items-center pt-32">
                    <Spin size="large" />
                  </div>  ) : (
                  scatterDataForM2M && scatterDataForM2M.length > 0 ? (
                    <ScatterChart
                      margin={{ top: 20, right: 20, bottom: 20, left: 40 }}
                    >
                      <XAxis
                        type="number"
                        dataKey="usage"
                        name="Usage"
                        unit=" MB"
                        label={{
                          value: "Usage (MB)",
                          position: "bottom",
                          offset: 0,
                        }}
                      />
                      <YAxis
                        type="number"
                        dataKey="session"
                        name="Session"
                        label={{
                          value: "Session",
                          angle: -90,
                          position: "insideLeft",
                        }}
                      />
                      {/* <Tooltip cursor={{ strokeDasharray: "3 3" }} /> */}
                      <Tooltip
                        cursor={{ strokeDasharray: "3 3" }}
                        content={({ payload }) => {
                        if (payload && payload.length > 0) {
                          const { usage, session, iccid } = payload[0].payload;  // Access the full payload for iccid
                          return (
                            <div>
                              <p><strong>Usage:</strong> {usage} MB</p>
                              <p><strong>Session:</strong> {session !== null ? session : "0"}</p>  {/* Show 0 instead of N/A */}
                              <p><strong>ICCID:</strong> {iccid}</p>  {/* Display ICCID */}
                            </div>
                          );
                        }
                        return null;
                        }}
                      />
                      <Scatter
                        name="Usage"
                        data={scatterDataForM2M}
                        fill="#0000FF"
                      />
                    </ScatterChart>
                  ) : (
                    <ScatterChart
                      margin={{ top: 20, right: 20, bottom: 20, left: 40 }}
                    >
                      <XAxis
                        type="number"
                        dataKey="usage"
                        name="Usage"
                        unit=" MB"
                        label={{
                          value: "Usage (MB)",
                          position: "bottom",
                          offset: 0,
                        }}
                      />
                      <YAxis
                        type="number"
                        dataKey="session"
                        name="Session"
                        label={{
                          value: "Session",
                          angle: -90,
                          position: "insideLeft",
                        }}
                      />
                      <Tooltip cursor={{ strokeDasharray: "3 3" }} />
                      <Scatter
                        name="No Data"
                        data={[{ usage: 0, session: 0 }]}
                        fill="#0000FF"
                      />
                    </ScatterChart>
                  ))}
                </ResponsiveContainer>
              </div>
              )}

              {/* Simple Bar Chart for carrier*/}

            {dashboardFeatures.includes("Total TNs by Rate Plan(Carrier)-Dashboard") && (
              <div
                className={`bg-white p-4 rounded-lg shadow-md graph ${
                  isExpanded(3) ? "full-screen" : ""
                }`}
                style={isExpanded(3) ? fullScreenStyle : {}}
              >
                <div className="bg-gray-100 chart-title flex justify-between items-center p-4">
                  <div className="flex items-center">
                    <BarChartOutlined className="cursor-pointer mr-2" />
                    <h2 className="font-semibold">
                      Total TNs by Rate Plan (Carrier)
                    </h2>
                  </div>
                  <div className="flex items-center">
                  <div>
                      {downloadLoading["Total TNs by Rate Plan (Carrier)"]?(
                        <div className="h-5 w-5 border-2 border-gray-500 border-t-transparent rounded-full animate-spin"></div>
                      ):(
                        <DownloadOutlined
                          className="cursor-pointer mr-2"
                          onClick={() =>
                            handleDownloadTemplate("/get_carrier_rate_plan_data","Total TNs by Rate Plan (Carrier)")
                    }/>
                      )}
                    </div>
                    <div
                      className="cursor-pointer"
                      onClick={() => toggleExpand(3)}
                    >
                      {expandedChart === 3 ? (
                        <ShrinkOutlined />
                      ) : (
                        <ArrowsAltOutlined />
                      )}
                    </div>
                  </div>
                </div>

                <ResponsiveContainer
                  width="100%"
                  height={isExpanded(3) ? "90%" : 300}
                >
                  {loadingBarDataForCarrier ? (
                    <div className="flex flex-row justify-center items-center pt-32">
                    <Spin size="large" />
                  </div>  ) : (
                  barDataForCarrier && barDataForCarrier.length > 0 ? (
                    <BarChart
                      data={barDataForCarrier}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis
                        dataKey="dataLimit"
                        label={{
                          value: "Data Limit (MB)",
                          position: "bottom",
                          offset: 20,
                        }}
                      />
                      <YAxis
                        label={{
                          value: "TN Count",
                          angle: -90,
                          position: "insideLeft",
                        }}
                      />
                      <Tooltip cursor={{fill: 'transparent'}}/>
                      <Bar dataKey="tnCount" fill="#0000FF" />
                    </BarChart>
                  ) : (
                    <BarChart
                      data={[{ dataLimit: "No Data", tnCount: 0 }]} // Placeholder data to show layout
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" vertical={false} />
                      <XAxis
                        dataKey="dataLimit"
                        label={{
                          value: "Data Limit (MB)",
                          position: "bottom",
                          offset: 20,
                        }}
                      />
                      <YAxis
                        label={{
                          value: "TN Count",
                          angle: -90,
                          position: "insideLeft",
                        }}
                      />
                      <Tooltip />
                      <Bar dataKey="tnCount" fill="#0000FF" />
                    </BarChart>
                  ))}
                </ResponsiveContainer>
              </div>
            )}

              {/* Simple Bar Chart for customer*/}
            {dashboardFeatures.includes("Total TNs by Rate Plan(Customer)-Dashboard") && (
              <div
                className={`bg-white p-4 rounded-lg shadow-md graph ${
                  isExpanded(4) ? "full-screen" : ""
                }`}
                style={isExpanded(4) ? fullScreenStyle : {}}
              >
                <div className="bg-gray-100 chart-title flex justify-between items-center p-4">
                  <div className="flex items-center">
                    <BarChartOutlined className="cursor-pointer mr-2" />
                    <h2 className="font-semibold">
                      Total TNs by Rate Plan (Customer)
                    </h2>
                  </div>
                  <div className="flex items-center">
                  <div>
                      {downloadLoading["Total TNs by Rate Plan (Customer)"]?(
                        <div className="h-5 w-5 border-2 border-gray-500 border-t-transparent rounded-full animate-spin"></div>
                      ):(
                        <DownloadOutlined
                          className="cursor-pointer mr-2"
                          onClick={() =>
                            handleDownloadTemplate("/get_customer_rate_plan_data","Total TNs by Rate Plan (Customer)")
                    }/>
                      )}
                    </div>
                    <div
                      className="cursor-pointer"
                      onClick={() => toggleExpand(4)}
                    >
                      {expandedChart === 4 ? (
                        <ShrinkOutlined />
                      ) : (
                        <ArrowsAltOutlined />
                      )}
                    </div>
                  </div>
                </div>

                <ResponsiveContainer
                  width="100%"
                  height={isExpanded(4) ? "90%" : 300}
                >
                  {loadingBarDataForCustomer ? (
                    <div className="flex flex-row justify-center items-center pt-32">
                    <Spin size="large" />
                  </div>  ) : (
                  barDataForCustomer && barDataForCustomer.length > 0 ? (
                    <BarChart
                      data={barDataForCustomer}
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis
                        dataKey="dataLimit"
                        label={{
                          value: "Data Limit (MB)",
                          position: "bottom",
                          offset: 0,
                        }}
                      />
                      <YAxis
                        label={{
                          value: "TN Count",
                          angle: -90,
                          position: "insideLeft",
                        }}
                      />
                      <Tooltip cursor={{fill: 'transparent'}}/>
                      <Bar dataKey="tnCount">
                        {barDataForCustomer.map((entry: any, index: any) => (
                          <Cell
                            key={`cell-${index}`}
                            fill={
                              entry.dataLimit === "5" ? "#00BFFF" : "#0000FF"
                            }
                          />
                        ))}
                      </Bar>
                    </BarChart>
                  ) : (
                    <BarChart
                      data={[{ dataLimit: "No Data", tnCount: 0 }]} // Placeholder data to show layout
                      margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis
                        dataKey="dataLimit"
                        label={{
                          value: "Data Limit (MB)",
                          position: "bottom",
                          offset: 0,
                        }}
                      />
                      <YAxis
                        label={{
                          value: "TN Count",
                          angle: -90,
                          position: "insideLeft",
                        }}
                      />
                      <Tooltip />
                      <Bar dataKey="tnCount" fill="#FF0000" />
                    </BarChart>
                  ))}
                </ResponsiveContainer>
              </div>
            )}
            
              {/* Horizontal Bar Chart */}
            {dashboardFeatures.includes("High Data Usage per Customer Pool-At&T-Telegence-Dashboard") && (

              <div
                className={`bg-white p-4 rounded-lg shadow-md graph ${
                  isExpanded(5) ? "full-screen" : ""
                }`}
                style={isExpanded(5) ? fullScreenStyle : {}}
              >
                <div className="bg-gray-100 chart-title flex justify-between items-center p-4">
                  <div className="flex items-center">
                    <BarChartOutlined className="cursor-pointer mr-2" />
                    <h2 className="font-semibold">
                      High Data Usage per Customer Pool - AT&T - Telegence
                    </h2>
                  </div>
                  <div className="flex items-center">
                  <div>
                      {downloadLoading["High Data Usage per Customer Pool - AT&T - Telegence"]?(
                        <div className="h-5 w-5 border-2 border-gray-500 border-t-transparent rounded-full animate-spin"></div>
                      ):(
                        <DownloadOutlined
                          className="cursor-pointer mr-2"
                          onClick={() =>
                            handleDownloadTemplate(
                              "/mobility_usage_per_customer_pool",
                              "High Data Usage per Customer Pool - AT&T - Telegence"
                            )
                    }/>
                      )}
                    </div>
                    <div
                      className="cursor-pointer"
                      onClick={() => toggleExpand(5)}
                    >
                      {expandedChart === 5 ? (
                        <ShrinkOutlined />
                      ) : (
                        <ArrowsAltOutlined />
                      )}
                    </div>
                  </div>
                </div>

                <ResponsiveContainer
                  width="100%"
                  height={isExpanded(5) ? "90%" : 300}
                >
                  {loadingHorizontalBarChartData ? (
                    <div className="flex flex-row justify-center items-center pt-32">
                    <Spin size="large" />
                  </div>  ) : 
                  (horizontalBarChartData &&
                  horizontalBarChartData.length > 0 ? (
                    <BarChart
                      data={horizontalBarChartData}
                      layout="vertical"
                      margin={{ top: 5, right: isSmallMediumScreen?5: 30, left: isSmallMediumScreen?0:150, bottom: 5 }}
                    >
                      <XAxis
                        type="number"
                        tickFormatter={(value) => `${value}%`}
                      />
                      <YAxis dataKey="name" type="category" width={140} />
                      <Tooltip formatter={(value) => `${value}%`} cursor={{fill: 'transparent'}}/>
                      <Bar dataKey="value" fill="#FF0000" />
                    </BarChart>
                  ) : (
                    <BarChart
                      data={[{ name: "No Data", value: 0 }]} // Placeholder data to show layout
                      layout="vertical"
                      margin={{ top: 5, right: 30, left: 150, bottom: 5 }}
                    >
                      <XAxis
                        type="number"
                        tickFormatter={(value) => `${value}%`}
                      />
                      <YAxis dataKey="name" type="category" width={140} />
                      <Tooltip cursor={{fill: 'transparent'}}/>
                      <Bar dataKey="value" fill="#FF0000" />
                    </BarChart>
                  ))}
                </ResponsiveContainer>
              </div>
            )}

              {/* Scatter Chart for mobility */}
              {/* <div
                className={`bg-white p-4 rounded-lg shadow-md ${
                  isExpanded(6) ? "full-screen" : ""
                }`}
                style={isExpanded(6) ? fullScreenStyle : {}}
              >
                <div className="bg-gray-100 flex justify-between items-center p-4">
                  <div className="flex items-center">
                    <DotChartOutlined className="cursor-pointer mr-2" />
                    <h2 className="font-semibold">Mobility - High Usage</h2>
                  </div>
                  <div className="flex items-center">
                  <div>
                      {downloadLoading["Mobility - High Usage"]?(
                        <div className="h-5 w-5 border-2 border-gray-500 border-t-transparent rounded-full animate-spin"></div>
                      ):(
                        <DownloadOutlined
                          className="cursor-pointer mr-2"
                          onClick={() =>
                            handleDownloadTemplate("/mobility_high_usage_chart","Mobility - High Usage")
                    }/>
                      )}
                    </div>
                    <div
                      className="cursor-pointer"
                      onClick={() => toggleExpand(6)}
                    >
                      {expandedChart === 6 ? (
                        <ShrinkOutlined />
                      ) : (
                        <ArrowsAltOutlined />
                      )}
                    </div>
                  </div>
                </div>

                <ResponsiveContainer
                  width="100%"
                  height={isExpanded(6) ? "90%" : 300}
                >
                  {loadingScatterChartForMobility ? (
                    <div className="flex flex-row justify-center items-center pt-32">
                    <Spin size="large" />
                  </div>  ) : (
                  scatterChartForMobility &&
                  scatterChartForMobility.length > 0 ? (
                    <ScatterChart
                      margin={{ top: 20, right: 20, bottom: 20, left: 40 }}
                    >
                      <CartesianGrid />
                      <XAxis
                        type="number"
                        dataKey="usage"
                        name="Usage"
                        unit=" MB"
                        label={{
                          value: "Usage (MB)",
                          position: "bottom",
                          offset: 0,
                        }}
                        tickFormatter={(value) => value.toLocaleString()}
                      />
                      <YAxis
                        type="number"
                        dataKey="percentUsed"
                        name="% Used"
                        label={{
                          value: "% Used",
                          angle: -90,
                          position: "insideLeft",
                        }}
                      />
                      <Tooltip
                        cursor={{ strokeDasharray: "3 3" }}
                        formatter={(value, name) => [
                          value.toLocaleString(),
                          name,
                        ]}
                      />
                      <Scatter
                        name="Usage"
                        data={scatterChartForMobility}
                        fill="#FF0000"
                      />
                    </ScatterChart>
                  ) : (
                    <ScatterChart
                      margin={{ top: 20, right: 20, bottom: 20, left: 40 }}
                    >
                      <CartesianGrid />
                      <XAxis
                        type="number"
                        dataKey="usage"
                        name="Usage"
                        unit=" MB"
                        label={{
                          value: "Usage (MB)",
                          position: "bottom",
                          offset: 0,
                        }}
                        tickFormatter={(value) => value.toLocaleString()}
                      />
                      <YAxis
                        type="number"
                        dataKey="percentUsed"
                        name="% Used"
                        label={{
                          value: "% Used",
                          angle: -90,
                          position: "insideLeft",
                        }}
                      />
                      <Tooltip cursor={{ strokeDasharray: "3 3" }} />
                      <Scatter
                        name="No Data"
                        data={[{ usage: 0, percentUsed: 0 }]}
                        fill="#FF0000"
                      />
                    </ScatterChart>
                  ))}
                </ResponsiveContainer>
              </div> */}

              {/* Horizontal Bar Chart for group pool*/}
              {/* <div
                className={`bg-white p-4 rounded-lg ${
                  isExpanded(7) ? "full-screen" : ""
                } shadow-md`}
                style={isExpanded(7) ? fullScreenStyle : {}}
              >
                <div className="bg-gray-100 flex justify-between items-center p-4">
                  <div className="flex items-center">
                    <BarChartOutlined className="cursor-pointer mr-2" />
                    <h2 className="font-semibold"> */}
                      {/* Mobility usage per group pool */}
                      {/* High Data Usage per Group / Pool - AT&T - Telegence
                    </h2>
                  </div>
                  <div className="flex items-center">
                    <DownloadOutlined
                      className="cursor-pointer mr-2"
                      onClick={() =>
                        handleDownloadTemplate("/mobility_usage_per_group_pool","High Data Usage per Group / Pool - AT&T - Telegence")
                      }
                    />
                    <div
                      className="cursor-pointer"
                      onClick={() => toggleExpand(7)}
                    >
                      {expandedChart === 7 ? (
                        <ShrinkOutlined />
                      ) : (
                        <ArrowsAltOutlined />
                      )}
                    </div>
                  </div>
                </div> */}

                {/* <ResponsiveContainer
                  width="100%"
                  height={isExpanded(7) ? "90%" : 300}
                >
                  {loadingHorizontalBarChartDataForGroupPool ? (
                    <div className="flex flex-row justify-center items-center pt-32">
                    <Spin size="large" />
                  </div>  ) : (
                  horizontalBarChartDataForGroupPool &&
                  horizontalBarChartDataForGroupPool.length > 0 ? (
                    <BarChart
                      data={horizontalBarChartDataForGroupPool}
                      layout="vertical"
                      margin={{ top: 5, right: 30, left: 150, bottom: 5 }}
                    >
                      <XAxis
                        type="number"
                        tickFormatter={(value) => `${value}%`}
                      />
                      <YAxis dataKey="name" type="category" width={140} />
                      <Tooltip formatter={(value) => `${value}%`} cursor={{fill: 'transparent'}}/>
                      <Bar dataKey="value" fill="#0000FF" />
                    </BarChart>
                  ) : (
                    <BarChart
                      data={[{ name: "No Data", value: 0 }]} // Placeholder data to render the structure
                      layout="vertical"
                      margin={{ top: 5, right: 30, left: 150, bottom: 5 }}
                    >
                      <XAxis
                        type="number"
                        domain={[0, 100]}
                        tickFormatter={(value) => `${value}%`}
                      />
                      <YAxis dataKey="name" type="category" width={140} />
                      <Tooltip formatter={(value) => `${value}%`} cursor={{fill: 'transparent'}}/>
                      <Bar dataKey="value" fill="#0000FF" />
                    </BarChart>
                  ))}
                </ResponsiveContainer> */}
              {/* </div> */}
            </div>
          </div>
        </div>
      </>
    );
  };

  return (
    <>
      {loading ? (
        <div className="flex justify-center items-center h-screen">
          <Spin size="large" />
        </div>
      ) : (
        <>
          <Suspense>
            {renderControls()}
            <DashbaordCards
              selectedServiceProvider={selectedFilter}
              startDate={startDate}
              endDate={endDate}
              serviceProvider={selectedFilter === "All Service Providers" ? "All" : selectedFilter}
              dashboardFeatures={dashboardFeatures}
            />
            {/* Charts Section */}
            <div className="flex flex-wrap justify-center gap-[10px] m-[10px]">
              {chartsData.map((chart: any, index: any) => {
                const isStackedBar =
                  chart.chart_type === "stackedBar" ||
                  chart.chart_type === "bar_two" || chart.chart_type === "bar";

                return (
                  <div
                    key={index}
                    className="chart-container graph"
                    style={{
                      flex: isStackedBar ? "1 1 100%" : "1 1 45%",
                      maxWidth: isStackedBar ? "100%" : "600px",
                      minWidth: "320px",
                      margin: "10px",
                      borderRadius: "10px",
                      boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
                      // backgroundColor: "#fff",
                      paddingBottom: "8px",
                      cursor: "pointer",
                      height: isStackedBar ? "500px" : "350px",
                    }}
                  // onClick={() => handleChartClick(chart.chart_type)}
                  >
                    <h3
                      className="text-[19px] mb-[5px] pb-[2px]"
                      style={{
                        fontFamily: "Calibri, sans-serif",
                        marginLeft: "22px",
                        marginTop: "10px",
                        position: "relative",
                      }}
                    >
                      {chart.title}

                      {/* Calendar Icon in the top right corner */}
                      {(chart.title).toLowerCase() === "device status" && (
                        <button
                          style={{
                            position: "absolute",
                            top: "0px",
                            right: "10px",
                            cursor: "pointer",
                            zIndex: 10,
                          }}
                          onClick={() => handleCalendarClick(chart.title)}
                        // onMouseEnter={() => handleCalendarClick(chart.title)}
                        >
                          {/* <MergeCellsOutlined style={{ fontSize: "24px", color: "#2196f3" }} /> */}
                          <i className="fi fi-sr-flip-horizontal" style={{ fontSize: "24px", color: "#2196f3" }}></i>
                        </button>
                      )}

                      {/* Modal for selecting multiple months */}




                    </h3>
                    <div
                      style={{
                        height: `${chart.height}px`,
                        width: "100%",
                      }}
                      onClick={() => handleChartClick(chart.chart_type)}
                    >
                      {renderChart(chart)}
                    </div>
                  </div>
                );
              })}
            </div>
            {renderNewCharts()}
            {/* Tables Section */}
            <div className="m-[10px]">
              <DashboardTables
                selectedServiceProvider={selectedFilter}
                startDate={startDate}
                endDate={endDate}
                serviceProvider={selectedFilter === "All Service Providers" ? "All" : selectedFilter}
                dashboardFeatures={dashboardFeatures}
              />

            </div>
          </Suspense>
          {compareChartsOpen &&
            <CompareCharts
              isOpen={compareChartsOpen}
              onClose={closeCompareCharts}
              chartTitle={compareChartTitle}
              chartPath={compareChartTitle ? titlePathMap[compareChartTitle] : "/device_status_chart"}
              serviceProvider={selectedFilter === "All Service Providers" ? "All" : selectedFilter} chart={""}
            />}

        </>
      )}
    </>
  );
};


export default HomePage;