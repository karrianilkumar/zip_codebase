import React, { useEffect, useState } from "react";
import { Modal, Spin, Table } from "antd";
import type { ColumnsType } from "antd/es/table";
import axios from "axios";
import { useAuth } from "../components/auth_context";
import { ENV_ROUTES } from "../components/routes/route_constants";
import { getCurrentDateTime } from "../components/header_constants";

interface TableDataResponse<T> {
  columns: ColumnsType<T>;
  data: T[];
}

interface SyncStatusData {
  key: string;
  no: number;
  syncName: string;
  syncType: string;
  status: string;
  dateTime: string;
}

interface UserLogData {
  key: string;
  no: number;
  userName: string;
  loginTime: string;
  logoutTime: string;
}

interface DasboardTableProps {
  selectedServiceProvider: string;
  startDate: string;
  endDate: string;
  serviceProvider: string;
  dashboardFeatures?: string[];
}


const DashboardTables: React.FC<DasboardTableProps> = ({ selectedServiceProvider, startDate, endDate, serviceProvider, dashboardFeatures = [], }) => {
  const { username, role, token, partner, selectedDb,metaData, firstLastName, sessionId} = useAuth();
  const [loading, setLoading] = useState(false);
  const [syncTableData, setSyncTableData] =
    useState<TableDataResponse<SyncStatusData> | null>(null);
  const [userTableData, setUserTableData] =
    useState<TableDataResponse<UserLogData> | null>(null);
    const [features, setFeatures] = useState<string[]>(dashboardFeatures);

useEffect(() => {
  if (dashboardFeatures.length === 0) {
    const stored = JSON.parse(localStorage.getItem("dashboardFeatures") || "[]");
    setFeatures(stored);
  } else {
    setFeatures(dashboardFeatures);
  }
}, [dashboardFeatures]);


  const fetchSyncTableData = async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.DASHBOARD;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        start_date: startDate,
        end_date: endDate,
        service_provider: serviceProvider,
        path: "/daily_sync_card", //
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Dashboard",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      } else {

        if (parsedData.columns && parsedData.data) {
          setSyncTableData({
            columns: parsedData.columns,
            data: parsedData.data,
          });
        } else {
          console.error("Expected columns and data in parsedData are missing");
        }

      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchUserlogTableData = async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.DASHBOARD;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        start_date: startDate,
        end_date: endDate,
        service_provider: serviceProvider,
        path: "/live_sessions_table",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Dashboard",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      } else {

        if (parsedData.columns && parsedData.data) {
          setUserTableData({
            columns: parsedData.columns,
            data: parsedData.data,
          });
        }
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchAllData = async () => {
    setLoading(true);
    await Promise.all([fetchSyncTableData(), fetchUserlogTableData()]);
    setLoading(false);
  };

  // useEffect(() => {
  //   fetchAllData();
  // }, [selectedServiceProvider, startDate, endDate]); 
  useEffect(() => {
    const fetchDataWithSSM = async () => {
      try {
        // console.log("Fetching SSM parameters...");
        // await fetchSSMParameters(); // Ensure SSM parameters are fetched first
        // console.log("SSM parameters fetched successfully");
  
        // Call your main data fetching function
        await fetchAllData();
      } catch (error) {
        console.error("Error fetching SSM parameters or data:", error);
      }
    };
  
    fetchDataWithSSM();
  }, [selectedServiceProvider, startDate, endDate]);
  

  const paginationConfig = {
    pageSize: 50,
    showSizeChanger: false, 
  };

  return (
        <div className="dashboard-tables">
          {features.includes("Sync Status-Dashboard") && (
          <div className="table-section graph">
            <h2 style={{fontFamily: "Calibri, sans-serif" }}>Sync Status</h2>
            <div className="over">
            <Table
              columns={syncTableData?.columns || []}
              dataSource={syncTableData?.data || []}
              loading={loading}
              pagination={paginationConfig}
              size="middle"
              scroll={{ y: 300 }}
            />
            </div>
          </div>
          )}
          {features.includes("User Log-Dashboard") && (
          <div className="table-section graph" style={{ marginTop: "2rem" }}>
            <h2 style={{fontFamily: "Calibri, sans-serif" }}>User Log</h2>
            <Table
              columns={userTableData?.columns || []}
              dataSource={userTableData?.data || []}
              pagination={paginationConfig}
              loading={loading}
              size="middle"
              scroll={{ y: 300 }}
            />
          </div>
          )}

          {/* <style jsx>{`
            .dashboard-tables {
              padding: 20px;
            }
            .table-section {
              background: white;
              padding: 20px;
              border-radius: 8px;
              box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            }
            h2 {
              margin-bottom: 16px;
              font-size: 20px;
              font-weight: 600;
            }
      :global(.custom-table) {
        font-family: Calibri, sans-serif;
      }
      :global(.custom-table .ant-table) {
        font-family: Calibri, sans-serif;
      }
      :global(.custom-table .ant-table-thead > tr > th) {
        font-family: Calibri, sans-serif;
      }
      :global(.custom-table .ant-table-tbody > tr > td) {
        font-family: Calibri, sans-serif;
      }
      :global(.custom-table .ant-pagination-item),
      :global(.custom-table .ant-pagination-prev),
      :global(.custom-table .ant-pagination-next),
      :global(.custom-table .ant-pagination-jump-prev),
      :global(.custom-table .ant-pagination-jump-next) {
        font-family: Calibri, sans-serif;
      }
        }
          `}</style> */}
        </div>
    //   )}
    // </>
  );
};

export default DashboardTables;
