"use client";
import React, {
    useEffect,
    useState,
    lazy,
    Suspense,
    useCallback,
} from "react";
import { Modal, Spin, DatePicker, notification, message, Upload } from "antd";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import dayjs, { Dayjs } from "dayjs";
import { useMutation } from "@tanstack/react-query";
import { DownloadOutlined, UploadOutlined } from "@ant-design/icons";
import { useRevStore } from "@/app/stores/revStore";
import moment from "moment";
import Select from 'react-select';
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { ArrowDownTrayIcon } from "@heroicons/react/24/outline";
import OptimizationTableComponent from "@/app/components/optimizationTableComponent/page";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { useCustomerRatePlanStore } from "@/app/stores/customerRateplanStore";
import { useOptimizationStore } from "@/app/stores/optimizationStore";
type ExportData = {
    path: string;
    username: string | null;
    module_name: string;
    request_received_at: string;
    start_date: string;
    end_date: string;
    Partner: string | null;
    access_token: string | null;
    db_name: string | null;
};

const RevTableComponent = lazy(
    () => import("@/app/components/revTableComponent/page")
);
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));
const TableSearch = lazy(() => import("@/app/components/entire_table_search"));
const AdvancedMultiFilter = lazy(
    () => import("@/app/components/advanced_search")
);

const CustomerCharges: React.FC = () => {
    const { RangePicker } = DatePicker;
    const [isExportModalOpen, setExportModalOpen] = useState(false);
    const [searchTerm, setSearchTerm] = useState("");
    const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
    const { username, partner, role, token, selectedDb,metaData, firstLastName,sessionId,setStoredPagination,setAdvancedStoredPagination , advancedStoredpagination ,storedpagination,tenantId, combineAdnvaceStoredpagination, setCombineAdnvaceStoredpagination,dynamicColumns,setDynamicColumns} = useAuth();
    const [pagination, setPagination] = useState<any>({});
    const [tableData, setTableData] = useState<any>([]);
    const [features, setFeatures] = useState<string[]>([]);
    const [headers, setHeaders] = useState<any[]>([]);
    const [headerMap, setHeaderMap] = useState<any>({});

    const [filteredData, setFilteredData] = useState([]);
    const [showAdvanced, setShowAdvanced] = useState(false);
    // const {showAdvanced, setShowAdvanced} = useCustomerRatePlanStore();
    const { setRevRows, setRevHeaders, setRevHeaderMap } = useRevStore();
    const [loading, setLoading] = useState(true);
    const [exportLoading, setExportLoading] = useState(false);
    const { addExport, removeExport,exports } = exportLoadingStore();
    const exportKey = "charge history";
    // const [exportSaveLoading, setExportSaveLoading] = useState(false);
    const [customerSessionsMap, setCustomerSessionsMap] = useState<any>({})
    const [customerOptions, setCustomerOptions] = useState<any[]>([])
    const [sessionOptions, setSessionOptions] = useState<any[]>([])
    const [billPeriodOptions, setBillPeriodOptions] = useState<any[]>([])
    const [selectedCustomers, setSelectedCustomers] = useState<any[]>([]);
    const [selectedSessions, setSelectedSessions] = useState<any[]>([]);
    const [selectedBillPeriods, setSelectedBillPeriods] = useState<any[]>([]);
    const [exportCustomerError, setExportCustomerError] = useState<boolean>(false);
    const [errorMessage, setErrorMessage] = useState<boolean>(false);
    const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
    const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([null, null]);
    const {optimizationRow} = useOptimizationStore()
    


    type HeaderMap = Record<string, [string, number]>;

    const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
        const entries = Object.entries(headerMap) as [string, [string, number]][];
        entries.sort((a, b) => a[1][1] - b[1][1]);
        return Object.fromEntries(entries) as HeaderMap;
    }, []);

    const fetchExportData = async () => {
        setExportCustomerError(false)
        setErrorMessage(false)
        setCustomerOptions([])
        setSelectedCustomers([])
        setSessionOptions([])
        setSelectedSessions([])
        setCustomerSessionsMap({})
        setSelectedBillPeriods([])
        setBillPeriodOptions([])
        try {
            // setExportLoading(true);
            const url = ENV_ROUTES.CHARGES_HISTORY
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/customers_sessions_customer_charges_export_dropdown_data",
                role_name: role,
                module_name: "Charge history",
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching Charge history data. Please try again.',
                    centered: true,
                });
            } else {
                const customerSessionsMap_ = parsedData?.customer_sessions || {}
                setCustomerSessionsMap(customerSessionsMap_)
                const customerOptions_ = Object.keys(customerSessionsMap_) || []
                setCustomerOptions(customerOptions_)

            }
        } catch (error) {
            console.error("Error fetching data:", error);
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        } finally {
            // setExportLoading(false);
        }
    };
    useEffect(() => {
          setDynamicColumns((prev:any)=>({...prev,"Charge history":visibleColumns}))
        }, [visibleColumns]);
    const fetchData = async () => {
        setStoredPagination(null);
        setAdvancedStoredPagination(null);
        setCombineAdnvaceStoredpagination(null)
        try {
            setLoading(true);
            const url = ENV_ROUTES.CHARGES_HISTORY
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_charge_history_data",
                role_name: role,
                module_name: "Charge history",
                parent_module: "Optimization",
                feature_module_name: "Charge History",
                mod_pages: {
                    start: 0,
                    end: 100,
                },
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                ...(optimizationRow && 
                    { 
                       session_id: optimizationRow.session_id,
                       action:"navigation"
                    }),
            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                const headersMap_ = parsedData?.headers_map?.["Charge history"]?.header_map || {}
                const sortedheaderMap = sortHeaderMap(headersMap_)
                setHeaderMap(sortedheaderMap)
                setRevHeaderMap(sortedheaderMap)
                const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : []
                setHeaders(headers_)
                setRevHeaders(headers_)
                const dynamic_cols=dynamicColumns?.["Charge history"] && dynamicColumns["Charge history"].length>0 ?dynamicColumns["Charge history"] :headers_ || headers_
                setVisibleColumns(dynamic_cols)
                const tableData_ = parsedData?.customer_charges_data || []
                setTableData(tableData_)
                setRevRows([])
                const features_ = parsedData?.headers_map?.["Charge history"]?.module_features || []
                setFeatures(features_)
                const pagination_ = parsedData?.pages || {}
                setPagination(pagination_)
            }
        } catch (error) {
            console.error("Error fetching data:", error);
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchData();
    }, [partner]);

    const pollExportStatus = async () => {
        try {

            const export_url = ENV_ROUTES.CHARGES_HISTORY;
            const export_data = {
                tenant_name: partner || "default_value",
                username,
                path: "/get_export_status",
                role_name: role,
                parent_module: "Optimization",
                module_name: "Charge History",
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
            };

            const export_response = await axios.post(export_url, { data: export_data });
            const export_parsedData = JSON.parse(export_response.data.body);

            if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
                const s3Url = export_parsedData?.export_status_data?.url || null;
                if (s3Url) {
                    // window.location.href = s3Url;
                    // notification.success({
                    //     message: "Success",
                    //     description: "Successfully exported!",
                    //     style: messageStyle,
                    //     placement: "top",
                    // });
                    fetch(s3Url)
                                    .then(response => response.blob())
                                    .then(blob => {
                                      const url = window.URL.createObjectURL(blob);
                                      const a = document.createElement('a');
                                      a.href = url;
                                      a.download = 'Charge History.zip';
                                      a.click();
                                      a.remove();
                                      window.URL.revokeObjectURL(url);
                                      notification.success({
                                        message: "Success",
                                        description: "Successfully exported the record!",
                                        style: messageStyle,
                                        placement: "top",
                                      });
                                    })
                                  .catch((err) => {
                                    console.log("error",err)
                                    Modal.error({
                                      title: "Export Error",
                                      content: "An error occurred while exporting data. Please try again.",
                                      centered: true,
                                    });
                                  });
                } else {
                    Modal.error({
                        title: "Export Error",
                        content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
                        centered: true,
                    });
                }
                return true; // Stop polling
            }

            if (export_parsedData?.export_status_data?.status_flag === "Failure") {
                Modal.error({
                    title: "Export Error",
                    content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
                    centered: true,
                });
                return true; // Stop polling
            }
            if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
                      Modal.info({
                        title: "Export Error",
                        content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
                        centered: true,
                      });
                      return true; // Stop polling
                    }

            return false; // Continue polling
        } catch (error) {
            Modal.error({
                title: "Export Error",
                content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
                centered: true,
            });
            return true; // Stop polling
        }
    };
    const startPolling = async () => {
        let isPollingComplete = false;

        while (!isPollingComplete) {
            isPollingComplete = await pollExportStatus();
            if (!isPollingComplete) {
                await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
            }
        }
    };

    const exportWithoutSearch =async (key: string, heading: string)=> {
        try {
            // addExport(key, heading);
                const url = ENV_ROUTES.CHARGES_HISTORY;
                const data = {
                    path: "/export_customer_charges",
                    username: username,
                    firstLastName: firstLastName,
                    module_name: "Charge history",
                    request_received_at: getCurrentDateTime(),
                    customer_name: selectedCustomers || null,
                    session_ids: selectedSessions.length > 0 ? selectedSessions : sessionOptions,
                    bill_period: selectedBillPeriods.length > 0 ? selectedBillPeriods : billPeriodOptions,
                    Partner: partner,
                    access_token: token,
                    db_name: selectedDb,
                ...metaData,
                    sessionID: sessionId,
                };
                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);
                if (parsedData.flag === true) {
                    await startPolling();
    
                } else {
                    await startPolling();
                }
    
            } catch (error) {
                await startPolling();
            } finally {
                // setExportSaveLoading(false);
                // removeExport(key);
            }
    }

    const handleExport = async (key: string, heading: string)=> {
        try {
            addExport(key, heading);
        
            let parsedData;
            let url;
            let data: any;
            let response;
            if(combineAdnvaceStoredpagination){
                url = ENV_ROUTES.OPEN_SEARCH;
                data = {
                  path: "/search_export",
                  search: "combined",
                  filters: advancedMultiFilters,
                  search_word: searchTerm,
                  search_all_columns: "True",
                  tenant_id: tenantId,
                  pages: {
                    start: 0,
                    end: 100,
                  },
                  partner: partner,
                  username: username,
                  db_name: selectedDb,
                ...metaData,
                  sessionID: sessionId,
                  index_name: "optimization_smi_result",
                  module_name: "Charge History",
                }
                console.log("combineAdnvaceStoredpagination",data)
                response = await axios.post(url, { data });
                parsedData = JSON.parse(response.data.body);
              }
            else if  (advancedStoredpagination && !storedpagination) {
              url = ENV_ROUTES.OPEN_SEARCH;
              data = {
                path: "/search_export",
                search: "advanced",
                filters: advancedMultiFilters,
                index_name: "optimization_smi_result",
                module_name: "Charge History",
                pages: { start: 0, end: 100 },
                partner,
                username: username,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                tenant_id: tenantId,
              };
              response = await axios.post(url, { data });
              parsedData = JSON.parse(response.data.body);
            } 
            else if (storedpagination && !advancedStoredpagination) {
              url = ENV_ROUTES.OPEN_SEARCH;
              data = {
                path: "/search_export",
                search_word: searchTerm,
                search_all_columns: "True",
                index_name: "optimization_smi_result",
                module_name: "Charge History",
                search: "whole",
                pages: { start: 0, end: 100 },
                partner,
                username: username,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                tenant_id: tenantId,
              };
              response = await axios.post(url, { data });
              parsedData = JSON.parse(response.data.body);
            } else {
              await exportWithoutSearch(key,heading);
              return;
            }
        
            if (parsedData.flag) {
              const s3Url = parsedData?.download_url || null;
              if (s3Url) {
                // window.location.href = s3Url;
                // notification.success({
                //   message: "Success",
                //   description: "Successfully exported the  record!",
                //   style: messageStyle,
                //   placement: "top",
                // });
                fetch(s3Url)
                                .then(response => response.blob())
                                .then(blob => {
                                  const url = window.URL.createObjectURL(blob);
                                  const a = document.createElement('a');
                                  a.href = url;
                                  a.download = 'Charge History.zip';
                                  a.click();
                                  a.remove();
                                  window.URL.revokeObjectURL(url);
                                  notification.success({
                                    message: "Success",
                                    description: "Successfully exported the record!",
                                    style: messageStyle,
                                    placement: "top",
                                  });
                                })
                              .catch((err) => {
                                console.log("error",err)
                                Modal.error({
                                  title: "Export Error",
                                  content: "An error occurred while exporting data. Please try again.",
                                  centered: true,
                                });
                              });
              } else {
                Modal.error({
                  title: "Export Error",
                  content: parsedData.message || "An error occurred while exporting data. Please try again.",
                  centered: true,
                });
              }
            } else {
              Modal.error({
                title: "Export Error",
                content: parsedData.message || "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            }
          } catch (error) {
                await startPolling()
                removeExport(key);
          } finally {
                setExportLoading(false)
                removeExport(key);
          }
       
    };

    const handleCustomerChange = (selectedOptions: any) => {
        const selectedCustomerList = selectedOptions.map((option: any) => option.value);
        setSelectedCustomers(selectedCustomerList);

        // Collect sessions and bill periods for all selected customers
        let allSessions: any[] = [];
        let allBillPeriods: any[] = [];

        selectedCustomerList.forEach((customer: string) => {
            const customerSessions = customerSessionsMap[customer];
            allSessions = [...allSessions, ...customerSessions.map((item: any) => item.session_id)];
            allBillPeriods = [...allBillPeriods, ...customerSessions.map((item: any) => item.billing_period_end_date)];
        });

        setSessionOptions(allSessions);
        setBillPeriodOptions(allBillPeriods);

        // Reset selected sessions and bill periods
        setSelectedSessions([]);
        setSelectedBillPeriods([]);
        setErrorMessage(false); // Reset error message
    };

    const handleSessionChange = (selectedOptions: any) => {
        setSelectedSessions(selectedOptions.map((option: any) => option.value));
        checkSelectedMappings(selectedOptions.map((option: any) => option.value), selectedBillPeriods);
    };

    const handleBillPeriodChange = (selectedOptions: any) => {
        setSelectedBillPeriods(selectedOptions.map((option: any) => option.value));
        checkSelectedMappings(selectedSessions, selectedOptions.map((option: any) => option.value));
    };

    // Check if the selected sessions and bill periods belong to the same customer
    const checkSelectedMappings = (selectedSessions: any, selectedBillPeriods: any) => {
        if (selectedSessions.length === 1 && selectedBillPeriods.length === 1) {
            const selectedSession = selectedSessions[0];
            const selectedBillPeriod = selectedBillPeriods[0];

            // Loop through all selected customers to check if the session and bill period match
            const matchingCustomer = selectedCustomers.find((customer: string) => {
                const customerSessions = customerSessionsMap[customer];
                return customerSessions.some(
                    (session: any) => session.session_id === selectedSession && session.billing_period_end_date === selectedBillPeriod
                );
            });

            if (!matchingCustomer) {
                setErrorMessage(true);
            } else {
                setErrorMessage(false);  // Reset error if they belong to the same mapping
            }
        }
        else {
            setErrorMessage(false)
        }
    };

    const exportMutation = useMutation<any, Error, ExportData>({
        mutationFn: async (exportData) => {
            const url = ENV_ROUTES.CHARGES_HISTORY;
            const response = await axios.post(
                url,
                { data: exportData },
                {
                    headers: {
                        "Content-Type": "application/json",
                    },
                }
            );
            return JSON.parse(response.data.body);
        },
        onSuccess: (data) => {
            if (data.flag === true) {
                notification.success({
                    message: "Success",
                    description: "Successfully exported the record!",
                    style: messageStyle,
                    placement: "top",
                });
                downloadZipBlob(data.blob);
            } else {
                Modal.error({
                    title: "Export Error",
                    content: data.message,
                    centered: true,
                });
            }
            handleExportModalClose();
        },
        onError: (error) => {
            console.error("Error downloading the file:", error);
            Modal.error({
                title: "Export Error",
                content:
                    "An error occurred while exporting the file. Please try again.",
            });
        },
    });

    const handleFilter = useCallback((advancedFilters: any) => {
        console.log(advancedFilters);
        setAdvancedFilters(advancedFilters)
      }, []);

    const handleReset = useCallback((EmptyFilters: any) => {
        setFilteredData(EmptyFilters);
    }, []);

    const messageStyle = {
        fontSize: "14px",
        fontWeight: "bold",
        padding: "16px",
    };

    const handleExportModalOpen = () => {
        fetchExportData()
        setExportModalOpen(true);
    };

    const handleExportModalClose = () => {
        setExportModalOpen(false);
    };

    const validExport = (key:string, heading:string) => {

        let isValid = true;

        if (selectedCustomers.length === 0) {
            isValid = false
            setExportCustomerError(true)
        }
        if (errorMessage) {
            isValid = false
        }
        if (isValid) {
            handleExport(key, heading)
        }
        console.log("isValid", exportCustomerError, errorMessage, isValid)
    };

    const downloadZipBlob = (base64Blob: string) => {
        // Convert base64 string to binary data
        const byteCharacters = atob(base64Blob);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);

        // Create a Blob from the byteArray with a type of zip
        const blobObject = new Blob([byteArray], {
            type: "application/zip",
        });

        // Create a download link and trigger it to download the .zip file
        const link = document.createElement("a");
        link.href = URL.createObjectURL(blobObject);
        link.download = "Charge history.zip"; // Ensure to download as .zip
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };
    const disableFutureDates = (current: any) => {
        console.log("future dates:", current && current > dayjs().endOf('day'));
        return current && current > dayjs().endOf('day');
    };


    if (loading) {
        return (
            <div className="flex justify-center items-center h-screen">
                <Spin size="large" />
            </div>
        );
    }

    return (
        <>
            <Suspense
                fallback={
                    <div className="flex justify-center items-center h-screen">
                        <Spin size="large" />
                    </div>
                }
            >
                <div className="relative">
                <div className="pr-4 pl-4  pt-2 flex md:flex-row md:items-center md:justify-between mt-1 mb-4 space-y-4">
          {/* Search and Advanced Filter Container */}
          <div className="flex space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last ">
                            {features.includes("Search-Charge history") && (
                                <TableSearch
                                    searchTerm={searchTerm}
                                    setSearchTerm={setSearchTerm}
                                    tableName={"optimization_smi_result"}
                                    headerMap={headerMap}
                                // loader={loading}
                                />
                            )}
                            {features.includes("Advanced filter-Charge history") && (
                                <AdvancedMultiFilter
                                    showAdvanced={showAdvanced}
                                    setShowAdvanced={setShowAdvanced}
                                    onFilter={handleFilter}
                                    onReset={handleReset}
                                    headers={headers}
                                    headerMap={headerMap}
                                    tableName={"optimization_smi_result"}
                                />
                            )}
                        </div>
                         {/* Export and ColumnFilter Container */}
            <div className="flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2  md:order-none order-first pb-2 md:pb-4">
                            {features.includes("Export-Charge history") && (
                                <button className="save-btn"
                                onClick={() => {
                                    if (!exports.some((exportItem) => exportItem.popupHeading === "Charge History")) {
                                      handleExport("ChargeHistory", "Charge History");
                                    }
                                  }} >
                                    <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                                    <span>Export</span>
                                </button>
                            )}
                            <ColumnFilter
                                headers={headers}
                                visibleColumns={visibleColumns}
                                setVisibleColumns={setVisibleColumns}
                                headerMap={headerMap}
                            />

                        </div>
                    </div>

                    <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
                        <OptimizationTableComponent
                            headers={headers}
                            headerMap={headerMap}
                            initialData={tableData}
                            searchQuery={searchTerm}
                            visibleColumns={visibleColumns}
                            itemsPerPage={100}
                            moduleName="Charge history"
                            pagination={pagination}
                            advancedFilters={filteredData}
                            height = {showAdvanced?280:230}
                        />
                    </div>
                    <Modal
                        title={
                            <span className="font-semibold text-xl space-y-3">
                                Export Output
                            </span>
                        }
                        visible={isExportModalOpen}
                        onCancel={() => {
                            handleExportModalClose();
                            setDateRange([null, null]);
                        }}
                        footer={null}
                        centered
                        afterClose={() => setDateRange([null, null])}
                        style={{ top: "-4%" }}
                    >
                        {exportLoading ? (
                            <div className="flex justify-center items-center h-56">
                                <Spin size="large" />
                            </div>
                        ) : (

                            <div className="flex flex-col space-y-4">
                                <div>
                                    <label>
                                        Customers<span className="text-red-500">*</span>
                                    </label>
                                    <Select
                                        options={customerOptions.map((option: string) => ({
                                            label: option,
                                            value: option,
                                        }))}
                                        onChange={handleCustomerChange}
                                        value={selectedCustomers.map((customer: string) => ({ label: customer, value: customer }))}
                                        isMulti
                                        isClearable
                                    />
                                    {exportCustomerError && <span className="text-red-500">Please select customer</span>}
                                </div>

                                <div>
                                    <label>Sessions</label>
                                    <Select
                                        options={sessionOptions.map((option: string) => ({
                                            label: option,
                                            value: option,
                                        }))}
                                        onChange={handleSessionChange}
                                        value={selectedSessions.map((option: any) => ({ label: option, value: option }))}
                                        isMulti
                                        isDisabled={selectedCustomers.length === 0}
                                    />
                                </div>

                                <div>
                                    <label>Bill Periods</label>
                                    <Select
                                        options={billPeriodOptions.map((option: string) => ({
                                            label: option,
                                            value: option,
                                        }))}
                                        onChange={handleBillPeriodChange}
                                        value={selectedBillPeriods.map((option: any) => ({ label: option, value: option }))}
                                        isMulti
                                        isDisabled={selectedCustomers.length === 0}
                                    />
                                </div>

                                {errorMessage && <span className="text-red-500">Select Session and Bill Period from the Same Mapping</span>}

                                <div className="flex space-x-4 justify-center">
                                    <button className="cancel-btn" onClick={handleExportModalClose}>
                                        Cancel
                                    </button>
                                    {/* <button className="save-btn" onClick={validExport}>
                                        Export
                                    </button> */}
                                </div>
                            </div>


                        )}

                    </Modal>
                </div>
                {/* {exportSaveLoading && (
                    <div className="export-processing-div">
                        Export processing...
                    </div>
                )} */}
            </Suspense>
            <div>
            </div>
        </>

    );

};

export default CustomerCharges;
