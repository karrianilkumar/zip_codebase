import React, { useState, useEffect } from 'react';
import { Modal, Button, Checkbox, Table, notification, Spin } from 'antd';
import { useAuth } from '../components/auth_context';
import { ENV_ROUTES } from '../components/routes/route_constants';
import { getCurrentDateTime } from '../components/header_constants';
import axios from 'axios';
import RevTableComponent from '../components/revTableComponent/page';
import { useRevStore } from '../stores/revStore';

interface RowUploadProps {
  visible: boolean;
  rows: any;
  onCancel: () => void;
  optimization_type: string | null;
}
const messageStyle = {
  fontSize: '14px',
  fontWeight: 'bold',
  padding: '16px',
};

const charges_header_map={
  "customer_name": [
   "Customer name",
   "1"
 ],
 "billing_period_start_date": [
   "Billing period start date",
   "2"
 ],
 "billing_period_end_date": [
  "Billing period end date",
   "3"
 ],
 "total_charge_amount": [
   "Total usage charges",
   "4"
 ],
 "sms_charge_total": [
   "Total SMS charges",
   "5"
 ],
 "device_count": [
   "Total devices",
   "6"
 ],

 "run_end_time": [
   "End date",
   "7"
 ]
}
const uasge_header_map= {
  "Customer name": [
   "Customer name",
   "1"
 ],
 "ICCID": [
   "ICCID",
   "2"
 ],
 "MSISDN": [
  "MSISDN",
   "3"
 ],
 "Data usage (MB)": [
   "Data usage (MB)",
   "4"
 ]
}
// const uasge_header_map= {
//   "customer_name": [
//    "Customer name",
//    "1"
//  ],
//  "iccid": [
//    "ICCID",
//    "2"
//  ],
//  "msisdn": [
//   "MSISDN",
//    "3"
//  ],
//  "data_usage": [
//    "Data usage (MB)",
//    "4"
//  ]
// }
const RowUploadModal: React.FC<RowUploadProps> = ({ visible, rows, onCancel, optimization_type }) => {
  const [pushCharges, setPushCharges] = useState(false);
  const [pushUsage, setPushUsage] = useState(false);
  const [title, setTitle] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const { username, role, partner, token, selectedDb,metaData, } = useAuth();
  const [showCharges, setShowCharges] = useState(true);
  const [pagination, setPagination] = useState<any>({});
  const [initialRows, setInitialRows] = useState<any>(rows);
  const [tableData, setTableData] = useState<any>([]);

  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const { revRows, setRevRows, setRevHeaders, setRevHeaderMap } = useRevStore();
  const fetchData = async () => {
    try {
      setLoading(true);
      const newIds = tableData.map((row: any) => {
        return optimization_type === "Carrier" ? row.instance_id || null : row.id || null;
      });
      const url = ENV_ROUTES.SIM_MANAGEMENT
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        path: "/get_usage_data",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        ids: newIds,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        setLoading(false);
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while submitting data. Please try again.",
          centered: true,
        });
      } else {
        setLoading(false);
        setHeaderMap(uasge_header_map)
        const headers_=Object.keys(uasge_header_map)
        setHeaders(headers_)
        const table_data=parsedData?.usage_data||[]
        setTableData(table_data)
      }
    } catch (error) {
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while submitting data. Please try again.",
        centered: true,
      });
    }
    finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (optimization_type) {
      const title_ = optimization_type === "Customer" ? "Customer charges upload" : "Rate plan upload"
      setTitle(title_)
      setHeaderMap(charges_header_map)
      const headers_=Object.keys(charges_header_map)
      setHeaders(headers_)
      setTableData(rows)
    }
  }, [visible]);


  useEffect(() => {
    if (!showCharges) {
      fetchData()
    }
    else{
      setHeaderMap(charges_header_map)
      const headers_=Object.keys(charges_header_map)
      setHeaders(headers_)
      setTableData(initialRows)
    }
  }, [showCharges]);

  const handleCheckboxChange = (setter: React.Dispatch<React.SetStateAction<boolean>>) => {
    setter(prevState => !prevState);
  };

  const submitData = async () => {
    try {
      setLoading(true);
      const newInstanceIds = revRows.map((row: any) => {
        return row.instance_id || null;
      });

      const newSessionIds = rows.map((row: any) => {
        return row.session_id || null;
      });

      const newICCIDs = revRows.map((row: any) => {
        return row.ICCID || null;
      });
      
      let push_type
      if(pushCharges){
        push_type = "Charges"
      }
      if(pushUsage){
        push_type = "Usage"
      }
      if(pushCharges && pushUsage){
        push_type = "Both"
      }
      let data;
      const url = ENV_ROUTES.SIM_MANAGEMENT
      if( optimization_type === "Carrier" ){
        data = {
          tenant_name: partner || "default_value",
          username: username,
          path: "/upload_carrier_rate_plan",
          role_name: role,
          Partner: partner,
          request_received_at: getCurrentDateTime(),
          access_token: token,
          db_name: selectedDb,
                ...metaData,
          ids: newInstanceIds,
        };
      }
      else{
        data = {
          tenant_name: partner || "default_value",
          username: username,
          path: "/upload_customer_charges_optimization_list_view",
          role_name: role,
          Partner: partner,
          request_received_at: getCurrentDateTime(),
          access_token: token,
          db_name: selectedDb,
                ...metaData,
          SessionId:newSessionIds,
          selectedInstances:showCharges?newInstanceIds:null,
          selectedUsageInstances:!showCharges?newICCIDs:null,
          pushType:push_type
        };
      }
      

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        setLoading(false);
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while submitting data. Please try again.",
          centered: true,
        });
      } else {
        setLoading(false);
        notification.success({
          message: 'Success',
          description: 'Successfully saved.',
          style: messageStyle,
          placement: 'top',
        });
      }
    } catch (error) {
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while submitting data. Please try again.",
        centered: true,
      });
    }
    finally {
      onCancel()
    }
  };

  const handleUpload = () => {
    submitData()
  };

  // Define the table columns
  const columns = [
    {
      title: 'Customer name',
      dataIndex: 'customer_name',
      key: 'customer_name',
    },
    {
      title: 'Billing period start date',
      dataIndex: 'billing_period_start_date',
      key: 'billing_period_start_date',
    },
    {
      title: 'Billing period end date',
      dataIndex: 'billing_period_end_date',
      key: 'billing_period_end_date',
    },
    {
      title: 'Total usage charges',
      dataIndex: 'total_charge_amount',
      key: 'total_charge_amount',
    },
    {
      title: 'Total SMS charges',
      dataIndex: 'sms_charge_total',
      key: 'sms_charge_total',
    },
    {
      title: 'Total devices',
      dataIndex: 'device_count',
      key: 'device_count',
    },
  ];

  const isCreateUploadDisable = () => {
    return (
      optimization_type === 'Customer'
      && (!pushCharges && !pushUsage)
    );
  };

  const toggleContent = (type: any) => {
    setShowCharges(type === 'charges');
  };

  const modalWidth =
    typeof window !== "undefined" ? (window.innerWidth * 2.5) / 4 : 0;
  const modalHeight =
    typeof window !== "undefined" ? (window.innerHeight * 2.5) / 4 : 0;

  return (
    <Modal
      title={title}
      visible={visible}
      onCancel={onCancel}
      width={modalWidth}
      styles={{ body: { height: modalHeight, padding: "4px" } }}
      footer={
        <div className="flex justify-center space-x-4">
          <button key="cancel" onClick={onCancel} className="cancel-btn">
            Cancel
          </button>
          <button key="upload"
            className={`${isCreateUploadDisable() ? 'cancel-btn' : 'save-btn'} disabled:cursor-not-allowed`}
            onClick={handleUpload}
            disabled={isCreateUploadDisable()}>
            Create & Upload
          </button>
        </div>
      }
    >
      <>
        {loading ? (
          <div className="flex justify-center items-center popup">
            <Spin size="large" />
          </div>
        ) : (
          <div className='popup'>
            < div className="overflow-x-auto h-full">
              {optimization_type !== "Carrier" && (
                <>
                  <div className='flex justify-between items-center p-4'>
                    {/* Toggle Buttons for Charges and Usage */}
                    <div className="space-x-4">
                      <button
                        className={`${showCharges ? "active" : "deactive"}`}
                        onClick={() => toggleContent('charges')}
                      >
                        Charges
                      </button>
                      <button
                        className={`${!showCharges ? "active" : "deactive"}`}
                        onClick={() => toggleContent('usage')}
                      >
                        Usage
                      </button>
                    </div>

                    {/* Checkboxes for Push Charges and Push Usage */}
                    <div className="flex justify-center space-x-4">
                      <Checkbox checked={pushCharges} onChange={() => handleCheckboxChange(setPushCharges)}>
                        Push charges
                      </Checkbox>
                      <Checkbox checked={pushUsage} onChange={() => handleCheckboxChange(setPushUsage)}>
                        Push usage
                      </Checkbox>
                    </div>
                  </div>

                </>
              )}
              <div className=" overflow-y-auto">

              <RevTableComponent
                            headers={headers}
                            headerMap={headerMap}
                            initialData={tableData}
                            // searchQuery={searchTerm}
                            visibleColumns={headers}
                            itemsPerPage={100}
                            // selectedDate={selectedDate} 
                            // handleDateChange={handleDateChange} 
                            moduleName="Optimization upload"
                            pagination={pagination}
                            // advancedFilters={filteredData}
                            onDateChange={() => { }}
                        />
              </div>
            </div>
          </div>
        )}
      </>

    </Modal >
  );
};

export default RowUploadModal;
