"use client";
import { useEffect, useLayoutEffect, useState } from "react";

import { Inter } from "next/font/google";
import "./globals.css";
import Header from "./components/header";
import SideNav from "./components/sideNav";
import { useSidebarStore } from "./stores/navBarStore";
import { AuthProvider, useAuth } from ".././app/components/auth_context";
import { Spin } from "antd";
import { Provider } from "./components/utilitis/provider";
import Login from "../app/components/login_page";
import dynamic from "next/dynamic";
import { usePathname, useRouter } from "next/navigation";
import PasswordUpdate from "./components/password_update";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { useLogoStore } from "./stores/logoStore";
// import { fetchSSMParameters } from "./components/routes/route_constants";

import ThemeLinkLoader from './components/ThemeLinkLoader';

const inter = Inter({ subsets: ["latin"] });
const ChooseTenant = dynamic(() => import("./components/choose_tenant"));
const LayoutContent: React.FC<{ children: React.ReactNode }> = ({
  children,
}) => {
  const { exports, revActions } = exportLoadingStore();

  const isExpanded = useSidebarStore((state: any) => state.isExpanded);
  const isDeploying = useSidebarStore((state: any) => state.isDeploying);
  const deployMsg = useSidebarStore((state: any) => state.deployMsg);

  const {
    isAuthenticated,
    setIsAuthenticated,
    selectedPartner,
    setSelectedPartner,
    setPartner,
    setModules,
    setRole,
    setUsername,
    setFirstLastName,
    setTenantName,
    setToken,
    setDbName,
    logout,
    setSelectedDb,
    setSelectedBillingDb,
    setTenantNames,
    setDynamicColumns,
    showPasswordUpdate,
    setIsSUbTenant,
    setIsSubTenantMap,
    setModulesVersionMap,
    setSessionId,
    setMetaData,
    
  } = useAuth();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const pathname = usePathname(); 
  const title = useLogoStore((state) => state.title);
  const setIsExpanded = useSidebarStore((state) => state.setIsExpanded);
const [isClosed, setIsClosed] = useState(false);
  
  useEffect(() => {
    document.title = `AMOP - ${title}`; // Dynamically set the title
  }, [title]); // Run the effect whenever `title` changes

  useEffect(() => {
    document.body.style.fontFamily = `"Calibri",Helvetica, Arial, sans-serif`;
    // document.body.style.fontFamily = `sans-serif`;
    if(window.innerWidth < 700){
      setIsExpanded(false)
    }
  }, []);

  useEffect(() => {
    const storedBannerClosed = localStorage.getItem('is_deploy_banner_close') || "false";
    const isBannerClosed = storedBannerClosed === "true"
    console.log("storedBannerClosed",storedBannerClosed,isBannerClosed)
    setIsClosed(isBannerClosed)
    const storedUsername = localStorage.getItem('username');
    const storedFirstLastName = localStorage.getItem('first_last_name');
    const storedTenant = localStorage.getItem('tenant_name');
    const storedRole = localStorage.getItem('role_name');
    const storedModules: any = JSON.parse(localStorage.getItem('modules') || '[]');
    const token = localStorage.getItem('access_token');
    const db_name = localStorage.getItem('db_name');
    const billing_db_name = localStorage.getItem('billing_db_name');
    const env_routes = localStorage.getItem('ENV_ROUTES');
    const session_id = localStorage.getItem('session_id');
    const tenant_names: any = JSON.parse(localStorage.getItem('tenant_names') || '[]');
    const dynamic_cols: any = JSON.parse(localStorage.getItem('dynamic_cols') || '{}');
    const isSubTenant_ = localStorage.getItem('is_sub_tenant') === 'true';
    const isSubTenantMap_: any = JSON.parse(localStorage.getItem('sub_tenant_map') || '{}');
    const switch_user_20_modules_json: any = JSON.parse(localStorage.getItem('switch_user_20_modules_json') || '{}');
    const meta_data: any = JSON.parse(localStorage.getItem('meta_data') || '{}');
    setMetaData(meta_data)
    setModulesVersionMap(switch_user_20_modules_json)
    setIsSubTenantMap(isSubTenantMap_)
    setIsSUbTenant(isSubTenant_)
    setSessionId(session_id)
    const sessionTimestamp = localStorage.getItem('session_timestamp');
  
    // Check if session is still valid (e.g., within 24 hours)
    const isSessionRecent = sessionTimestamp 
      ? (Date.now() - parseInt(sessionTimestamp)) < (24 * 60 * 60 * 1000) 
      : false;
  
    if (storedUsername && storedRole && token && isSessionRecent) {
      // User is authenticated
      setIsAuthenticated(true);
  
      // Set all available data
      setUsername(storedUsername);
      setFirstLastName(storedFirstLastName);
      setRole(storedRole);
      setModules(storedModules);
      setToken(token);
      setSelectedDb(db_name);
      setSelectedBillingDb(billing_db_name);
      setTenantNames(tenant_names);
      setDynamicColumns(dynamic_cols);

  
      // Handle tenant logic (choose partner)
      if (storedTenant) {
        setTenantName(storedTenant);
        setPartner(storedTenant);
      } else {
        setTenantName(''); // No tenant selected
      }
  
      // Handle selected partner
      if (!storedTenant || storedModules.length===0 || !db_name) {
        setSelectedPartner(false);
      } else {
        setSelectedPartner(true);
      }
  
      // Update session timestamp
      localStorage.setItem('session_timestamp', Date.now().toString());
    } else {
      // If critical session data is missing, redirect to login
      setIsAuthenticated(false);
    }
  
    setLoading(false);
  }, []);
 
  
  // Listen for logout events from other tabs
  useEffect(() => {
    const handleStorageChange = (event: StorageEvent) => {
      if (event.key === 'global_logout_timestamp' && isAuthenticated) {
        // Clear local storage and session storage
        localStorage.clear();
        sessionStorage.clear();

        // Reset authentication state
        setIsAuthenticated(false);
        setUsername(null);
        setFirstLastName(null);
        setPartner(null);
        setSelectedPartner(false);
        setTenantNames([]);
        setToken(null);
        setRole(null);
        setModules([]);
        setSelectedDb(null);
        setTenantName(null);
        setDbName(null);

        // Redirect to login page
        window.location.href = '/';
      }
    };

    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [isAuthenticated]);

  useEffect(() => {
    // Increment the open tab count
    const tabCount = parseInt(localStorage.getItem("open_tabs_count") || "0");
    const newTabCount = tabCount + 1;
    localStorage.setItem("open_tabs_count", newTabCount.toString());
  
    // Generate unique tab ID if not exists
    const tabId = sessionStorage.getItem("tab_id") || crypto.randomUUID();
    sessionStorage.setItem("tab_id", tabId);
    
    // Store tab's auth state
    sessionStorage.setItem("tab_auth_state", isAuthenticated.toString());
  
    const handleBeforeUnload = () => {
      const remainingTabCount = parseInt(localStorage.getItem("open_tabs_count") || "1") - 1;
      localStorage.setItem("open_tabs_count", remainingTabCount.toString());
      
      if (remainingTabCount === 0) {
        localStorage.clear();
        sessionStorage.clear();
      }
    };

    window.addEventListener("beforeunload", handleBeforeUnload);
    return () => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
    };
  }, [isAuthenticated]);
  
  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  if (error) {
    return <div>Error: {error}</div>;
  }

  const isPublicRoutes = pathname.startsWith("/auth");

  if (!isAuthenticated && !isPublicRoutes) {
    return <Login />;
  }

  if (!selectedPartner && !isPublicRoutes) {
    return <ChooseTenant />;
  }

  return (
    <div className="min-h-screen grid">
     <div className="export-container">
        {[
          ...exports.map((exportItem) => ({
            key: exportItem.key,
            id: exportItem.popupHeading,
            type: "export",
          })),
          ...revActions.map((action) => ({
            key: action.key,
            id: action.id,
            type: "service",
          })),
        ]
          .filter(
            (item, index, self) =>
              index ===
              self.findIndex(
                (e) => e.key === item.key && e.id === item.id
              )
          )
          .map((item) => {
            let message = "";

            if (item.type === "export") {
              if (item.id === "Partner Creation" || item.key === "bulkChangeInsert") {
                message = "Processing...";
              }
              else if(item.key === "Bills PDF" || item.id === "Bills PDF"){
                message = "Download Processing..."
              } 
              else if( item.key === "payment" || item.id === "Payment"){
                message = "Receipt Download Processing..."
              }
              else if(item.key === "payment_processing"){
                message = ""
              }
              else {
                message = "Export Processing...";
              }
            }
            else if(item.type === "dashboard"){
              message = " is Reloading...";
            }
            else {
              message = "In Revenue Assurance is Processing...";
            }

            return (
              <div key={item.key} className="export-processing-div">
                {item.id} {message}
              </div>
            );
          })}
      </div>
 {isDeploying && !isClosed && (
  <div className="deployment-container">
    <div className="deployment-processing-div relative">
      <button
        className="close-btn"
        onClick={() => {
          localStorage.setItem('is_deploy_banner_close', "true");
          setIsClosed(true)
        }}
      >
        ×
      </button>
      {deployMsg}
    </div>
  </div>
)}
      <div
        className={`fixed top-0 right-0 bg-white z-[999] ${
          isExpanded
            ? "left-[250px]"
            : "lg:left-[70px] left-0"
        }`}
        style={{ zIndex: 999 }}
      >
        <Header />
      </div>
      <div className="flex mt-[70px] bg-gray-50 overflow-hidden">
      {/* {(isExpanded || (!isExpanded && window.innerWidth >= 1024)) &&  */}
        <div
        className={`fixed bottom-0 top-0 bg-gray-800 text-white relative ${
    !isExpanded && window.innerWidth < 1024 ? 'hidden' : ''
  }`}
        // style={{ zIndex: 9999 }}
      >
        <SideNav />
      </div>
       {/* } */}
        
        <div
         className={`flex-1 overflow-y-auto overflow-x-hidden main-container ${
          isExpanded
            ? "ml-[250px]"
            : "lg:ml-[70px] ml-0"
        }`}
        >
          {showPasswordUpdate ? <PasswordUpdate /> : children}
        </div>
      </div>
    </div>
  );
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <AuthProvider>
      <html lang="en">
        <head>
          <ThemeLinkLoader />
          <link
            rel="stylesheet"
            href="https://cdn.jsdelivr.net/npm/@flaticon/flaticon-uicons/css/all/all.css"
          />
        
           {/* For QA hotjar integration script */}
          <script
            dangerouslySetInnerHTML={{
              __html: `
                (function(h,o,t,j,a,r){
                  h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};
                  h._hjSettings={hjid:5230969,hjsv:6};
                  a=o.getElementsByTagName('head')[0];
                  r=o.createElement('script');r.async=1;
                  r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;
                  a.appendChild(r);
                })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
              `,
            }}
          ></script>

          {/* For UAT hotjar integration script */}
          {/* <script
            dangerouslySetInnerHTML={{
              __html: `
                (function(h,o,t,j,a,r){ 
                h.hj=h.hj||function(){(h.hj.q=h.hj.q||[]).push(arguments)};  
                h._hjSettings={hjid:5230968,hjsv:6};       
                a=o.getElementsByTagName('head')[0];      
                r=o.createElement('script');r.async=1;   
                r.src=t+h._hjSettings.hjid+j+h._hjSettings.hjsv;  
                a.appendChild(r);    
                })(window,document,'https://static.hotjar.com/c/hotjar-','.js?sv=');
              `,
            }}
          ></script> */}
        </head>
        <body className={inter.className}>
          <Provider>
            <LayoutContent>{children}</LayoutContent>
          </Provider>
        </body>
      </html>
    </AuthProvider>
  );
}
