import { redirect } from "next/navigation";

export default function DeviceManagement() {
  return redirect("/device_management/inventory");
}
