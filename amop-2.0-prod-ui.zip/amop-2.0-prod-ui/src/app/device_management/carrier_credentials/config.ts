import { CarrierType } from "@/types/carrier-config.types";

export const CONFIGURABLE_CARRIER_CONFIGS = [CarrierType.Peplink];
