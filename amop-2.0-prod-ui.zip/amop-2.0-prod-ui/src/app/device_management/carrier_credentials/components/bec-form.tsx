import { Alert, Flex, Form, FormInstance, Input, message, Spin } from "antd";
import React, { FC, useCallback, useEffect } from "react";
import { useForm } from "antd/es/form/Form";
import { InfoCircleOutlined } from "@ant-design/icons";
import { useMutation, useQuery } from "@tanstack/react-query";
import {
  getPartnerIntegrationSetting,
  updatePartnerIntegrationSetting,
} from "@/api/partner-setting-api";
import Link from "next/link";

type BECFormProps = {
  form?: FormInstance;
};

type BECFormValues = {
  apiUrl: string;
  apiToken: string;
  apiKey: string;
  becAccountName: string;
};

const defaultValues: BECFormValues = {
  apiUrl: "https://api.becentral.io:5580/api",
  apiToken: "",
  apiKey: "",
  becAccountName: "",
};

const BECForm: FC<BECFormProps> = ({ form: parentForm }) => {
  const [form] = useForm<BECFormValues>(parentForm);

  const { data, isFetching, isError, error, isSuccess, refetch } = useQuery<
    object,
    Error
  >({
    queryKey: ["carrier-config", "bec"],
    queryFn: () => getPartnerIntegrationSetting("bec"),
    refetchOnWindowFocus: false,
  });

  const {
    isPending: isSubmitting,
    mutateAsync,
    isError: isSubmitError,
    error: submitError,
  } = useMutation<any, Error, any>({
    mutationKey: ["carrier-config", "bec"],
    mutationFn: (data: BECFormValues) =>
      updatePartnerIntegrationSetting("bec", data),
    onSuccess: async () => {
      await message.success("Configuration updated successfully");
      await refetch();
    },
  });

  const onSubmit = useCallback(
    async (values: BECFormValues) => {
      await mutateAsync(values);
    },
    [mutateAsync],
  );

  useEffect(() => {
    if (isSuccess) {
      const mergeWithDefault = Object.assign(defaultValues, data);
      form.setFieldsValue(mergeWithDefault);
    }
  }, [data, form, isSuccess]);

  return (
    <Form
      form={form}
      name="bec"
      layout="horizontal"
      labelCol={{ span: 8 }}
      wrapperCol={{ span: 16 }}
      colon={false}
      onFinish={onSubmit}
      disabled={isFetching || isError || isSubmitting}
      initialValues={defaultValues}
    >
      {(isFetching || isSubmitting) && (
        <Flex justify="center" className="py-2">
          <Spin />
        </Flex>
      )}
      {isError && (
        <Alert
          message="Error"
          description={error?.message}
          type="error"
          showIcon
        />
      )}
      {isSubmitError && (
        <Alert
          message="Failed to update BEC settings"
          description={submitError?.message}
          type="error"
          showIcon
        />
      )}
      <Form.Item
        label="API Key"
        name="apiKey"
        rules={[
          {
            required: true,
            message: "Please input your API Key!",
          },
        ]}
      >
        <Input.Password
          autoComplete="new-password"
          suffix={<InfoCircleOutlined />}
        />
      </Form.Item>
      <Form.Item
        label="API Token"
        name="apiToken"
        rules={[
          {
            required: true,
            message: "Please input your API Token!",
          },
        ]}
      >
        <Input.Password autoComplete="new-password" />
      </Form.Item>
      <Form.Item
        label="Base API URL"
        name="apiUrl"
        rules={[{ required: true, message: "Please input your Base API URL!" }]}
      >
        <Input autoComplete="new-password" />
      </Form.Item>
      <Form.Item
        label="Account Name"
        name="becAccountName"
        rules={[
          {
            required: true,
            message: "Please input your Account Name!",
          },
        ]}
        help={
          <>
            <p>Account Name or SubAccount</p>
            <p>Examples: Altaworx/, Altaworx/Earthlink/</p>
          </>
        }
      >
        <Input autoComplete="new-password" />
      </Form.Item>

      <Form.Item label={" "}>
        <Link href="https://becentral.io/MainPage/RESTAPI" target={"_blank"}>
          BEC API Documentation
        </Link>
      </Form.Item>
    </Form>
  );
};

export default BECForm;
