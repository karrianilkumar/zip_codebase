"use client";

import { Button, DatePicker, Tag } from "antd";
import Search from "antd/es/input/Search";
import React, { ChangeEvent, useRef, useState } from "react";
import {
  CalendarOutlined,
  DownloadOutlined,
  LoadingOutlined,
  PlusOutlined,
  SyncOutlined,
} from "@ant-design/icons";
import { initialDeviceManagementProvisionColumns } from "@/common/constants/table-constants";
import { ColumnsType } from "antd/es/table";
import { convertTableColumnsToTitleArray } from "@/common/helper/table-helper";
import {
  COLUMN_CHECKLIST_DROPDOWN,
  EXPORT,
  INVENTORY_TABLE_TEXT,
} from "@/common/constants/inventory-constants";
import { DropdownCheckboxButton } from "@/components/dropdown-checkbox-button";
import {
  DATE_PICKER_FORMAT,
  PROVISION_DEVICE_BUTTON,
  PROVISION_QUERY_KEY,
  PROVISION_TEXT,
  SEARCH_PLACEHOLDER_PROVISIONING,
} from "@/common/constants/provisioning-constants";
import { DeviceManagementProvisionDataType } from "@/types/provision-types";
import useProvisionTableStore from "@/stores/provision-table-store";
import useProvisionModalStore from "@/stores/provision-modal-store";
import { useQueryClient } from "@tanstack/react-query";
import { FeatureFlag } from "@/components/feature-flag/feature-flag";
import { DeviceManagementProvisioningFeatures } from "@/common/enums/module-feature-enum";

type Props = {
  handleChangeColumns: (columns: string[]) => void;
  visibleColumns: ColumnsType<DeviceManagementProvisionDataType>;
  onSearchFilterChanged?: (search: string) => void;
  initialSearch: string;
  onDateRangeChange: (dateRange: [string, string]) => void;
};

const { RangePicker } = DatePicker;

export const ProvisionTableSorting: React.FC<Props> = ({
  initialSearch,
  handleChangeColumns,
  visibleColumns,
  onSearchFilterChanged = () => {},
  onDateRangeChange,
}) => {
  const { queryIsFetching, setTriggerExport } = useProvisionTableStore();
  const { setOpenProvisionModal, provisionDeviceData } =
    useProvisionModalStore();
  const debounceRef = useRef<number>();
  const [_search, _setSearch] = useState(initialSearch);
  const dateRangeRef = useRef(["", ""]);

  const queryClient = useQueryClient();

  const handleClickExport = async () => {
    setTriggerExport(true);
  };

  const handleOpenProvisionModal = () => {
    setOpenProvisionModal(true);
  };

  const handleSearchChange = (ev: ChangeEvent<HTMLInputElement>) => {
    _setSearch(ev.target.value);
    if (debounceRef.current) {
      window.clearTimeout(debounceRef.current);
    }
    debounceRef.current = window.setTimeout(() => {
      onSearchFilterChanged(ev.target.value);
    }, 300);
  };

  const handleChangeDateRange = (
    values: any,
    formatString: [string, string],
  ) => {
    onDateRangeChange(formatString);
    dateRangeRef.current = formatString;
  };

  const handleRefresh = async () => {
    await queryClient.invalidateQueries({
      queryKey: [PROVISION_QUERY_KEY.GET_PROVISION],
    });
  };

  return (
    <div className="flex flex-col md:flex-row justify-between">
      <div className="flex flex-col sm:flex-row items-end sm:items-center w-full mb-3 sm:mb-0">
        <div className="flex flex-col mb-3 sm:mb-0 sm:mr-2">
          <FeatureFlag
            feature={DeviceManagementProvisioningFeatures.ProvisionDeviceForm}
          >
            <Button
              type="primary"
              icon={<PlusOutlined />}
              onClick={handleOpenProvisionModal}
              className="save-btn"
            >
              {PROVISION_DEVICE_BUTTON}
              {Object.keys(provisionDeviceData).length > 0 && (
                <span className="ml-3 -translate-y-0.5">
                  <Tag color="#87d068">{PROVISION_TEXT.PENDING}</Tag>
                </span>
              )}
            </Button>
          </FeatureFlag>
        </div>
        <div className="sm:hidden">
          <Button
            type="primary"
            icon={<SyncOutlined spin={queryIsFetching} />}
            onClick={handleRefresh}
            disabled={queryIsFetching}
            className="save-btn"
          />
        </div>
        <div className="hidden sm:flex">
          <Button
            type="primary"
            onClick={handleRefresh}
            className="w-full sm:w-auto sm:ml-2 text-xs sm:text-sm save-btn"
            disabled={queryIsFetching}
            icon={<SyncOutlined spin={queryIsFetching} />}
          >
            <span className="sm:inline">
              {queryIsFetching
                ? INVENTORY_TABLE_TEXT.fetching
                : INVENTORY_TABLE_TEXT.refresh}
            </span>
          </Button>
        </div>
      </div>
      <div className="w-full max-w-lg">
        <Search
          placeholder={SEARCH_PLACEHOLDER_PROVISIONING}
          value={_search}
          onChange={handleSearchChange}
          allowClear
          loading={!!(_search.length && queryIsFetching)}
          className="mb-3 w-full"
        />
        <div className="flex flex-wrap gap-2">
          <RangePicker
            format={DATE_PICKER_FORMAT}
            suffixIcon={
              queryIsFetching && dateRangeRef.current[0]?.length ? (
                <LoadingOutlined />
              ) : (
                <CalendarOutlined />
              )
            }
            onChange={handleChangeDateRange}
            className="flex-grow"
          />
          <DropdownCheckboxButton
            title={COLUMN_CHECKLIST_DROPDOWN}
            initialCheckList={convertTableColumnsToTitleArray(
              initialDeviceManagementProvisionColumns,
            )}
            initialCheckedList={convertTableColumnsToTitleArray(visibleColumns)}
            handleCheck={handleChangeColumns}
          />
          <Button
            type="primary"
            icon={<DownloadOutlined />}
            onClick={handleClickExport}
            className="flex-grow save-btn"
          >
            {EXPORT}
          </Button>
        </div>
      </div>
    </div>
  );
};
