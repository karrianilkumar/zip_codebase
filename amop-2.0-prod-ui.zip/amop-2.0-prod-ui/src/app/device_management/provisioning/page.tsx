import React from "react";
import { ScrollToTop } from "@/components/scroll-to-top";
import { ProvisionTableWrapper } from "./components/provision-table-wrapper";
import dynamic from "next/dynamic";
import { FeatureFlagProvider } from "@/components/feature-flag/feature-flag-provider";
import {
  DeviceManagementFeatures,
  ModuleFeatures,
} from "@/common/enums/module-feature-enum";
const ProvisionModalWrapper = dynamic(
  () =>
    import("./components/provision-modal-wrapper").then(
      (module) => module.ProvisionModalWrapper,
    ),
  { ssr: false },
);

export default function Provisioning() {
  return (
    <FeatureFlagProvider
      parentModule={ModuleFeatures.DeviceManagement}
      module={DeviceManagementFeatures.Provisioning}
    >
      <ProvisionTableWrapper />
      <ProvisionModalWrapper />
      <ScrollToTop visibilityHeight={400} />
    </FeatureFlagProvider>
  );
}
