import { Divider, Popover } from "antd";
import React, { memo, useMemo } from "react";
import { InfoCircleOutlined } from "@ant-design/icons";

const ScrollHint = memo(() => {
  const scrollHintContent = useMemo(
    () => (
      <div>
        <div className="font-semibold">
          Scroll Hint
          <InfoCircleOutlined style={{ marginLeft: "0.2rem" }} />
        </div>
        <Divider style={{ margin: "0.5rem 0 0.2rem" }} />
        <div>For Horizontal Scrolling, you can use Shortcuts:</div>
        <div className="font-semibold">
          <span
            style={{
              border: "1px solid #797979",
              padding: "0 0.2rem",
              borderRadius: "4px",
            }}
          >
            Shift
          </span>{" "}
          + Mouse Wheel
        </div>
      </div>
    ),
    [],
  );
  return (
    <Popover content={scrollHintContent}>
      <span className="text-[#797979] ml-2 cursor-pointer select-none">
        Scroll
        <InfoCircleOutlined className="ml-1" />
      </span>
    </Popover>
  );
});

ScrollHint.displayName = "ScrollHint";

export { ScrollHint };
