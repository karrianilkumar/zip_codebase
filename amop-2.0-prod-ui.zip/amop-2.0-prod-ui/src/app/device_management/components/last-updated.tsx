import {
  DEFAULT_TIMEZONE,
  FULL_TIME_FORMAT,
  TABLE_TEXT,
} from "@/common/constants/table-constants";
import { format } from "date-fns";
import { toZonedTime } from "date-fns-tz";
import React from "react";

type Props = {
  time: number | Date;
};

const TENANT_ZONE = "New York, US";

export const LastUpdated: React.FC<Props> = ({ time }) => {
  return (
    <div className="italic text-[#797979]">
      {TABLE_TEXT.LAST_UPDATED}:{" "}
      {format(toZonedTime(time, DEFAULT_TIMEZONE), FULL_TIME_FORMAT)} -{" "}
      {TENANT_ZONE}
    </div>
  );
};
