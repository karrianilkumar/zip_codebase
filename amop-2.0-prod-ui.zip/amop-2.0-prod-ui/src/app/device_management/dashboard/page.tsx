import { Col, Row } from "antd";
import { DevicesExpirationRow } from "./components/devices-expiration-row";
import { CarrierChart } from "./components/carrier-chart";
import { ModelChart } from "./components/model-chart";
import { NetworkTypeChart } from "./components/network-type-chart";
import { QuantityLicenseChart } from "./components/quantity-license-chart";
import { DeviceInventoryOverview } from "./components/device-inventory-overview";
import { FeatureFlagProvider } from "@/components/feature-flag/feature-flag-provider";
import {
  DeviceManagementFeatures,
  ModuleFeatures,
} from "@/common/enums/module-feature-enum";

export default function Dashboard() {
  return (
    <FeatureFlagProvider
      parentModule={ModuleFeatures.DeviceManagement}
      module={DeviceManagementFeatures.Dashboard}
    >
      <DeviceInventoryOverview />
      <Row gutter={16} className="mt-4">
        <Col xs={24} xl={12}>
          <CarrierChart />
        </Col>
        <Col xs={24} xl={12}>
          <ModelChart />
        </Col>
      </Row>
      <Row gutter={16}>
        <Col xs={24} xl={12}>
          <NetworkTypeChart />
        </Col>
        <Col xs={24} xl={12}>
          <QuantityLicenseChart />
        </Col>
      </Row>
      <DevicesExpirationRow />
    </FeatureFlagProvider>
  );
}
