export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div
      style={{
        margin: "24px 18px",
      }}
    >
      {children}
    </div>
  );
}
