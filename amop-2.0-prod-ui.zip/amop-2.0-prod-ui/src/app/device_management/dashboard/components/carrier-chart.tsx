"use client";

import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { getTotalByTimeData } from "@/api/statistic-api";
import { DeviceManagementStatisticTimeDataType } from "@/types/statistic-time-types";
import { BarChart } from "./bar-chart";

export const CarrierChart: React.FC = () => {
  const [paramState, setParamState] = useState({ granularity: "month" });

  const handleChangeTime = (value: string) => {
    setParamState({
      granularity: value,
    });
  };

  const { data } = useQuery({
    queryKey: ["carrier-statistic-time-data", paramState],
    queryFn: async () => {
      const data = await getTotalByTimeData({
        type: "devices_by_carrier",
        ...paramState,
      });
      return data as DeviceManagementStatisticTimeDataType[];
    },
    staleTime: 1000 * 60 * 5,
    retry: 1,
  });

  return (
    <BarChart
      data={data || []}
      granularity={paramState.granularity}
      title="Connected Devices by Carrier"
      tooltipDesc="Numbers of devices count by each carrier"
      handleChangeTime={handleChangeTime}
    />
  );
};
