import React, { useState } from "react";
import { Statistic, Divider, Row, Col } from "antd";
import { CustomPopover } from "@/components/custom-popover";
import { QuestionCircleOutlined } from "@ant-design/icons";
import { DASHBOARD_TEXT } from "@/common/constants/dashboard-constants";

const StatisticCard = ({
  title,
  value,
  total,
  titleTip,
  contentTip,
  activeTitle,
  totalTitle,
  statisticIconColor,
}: {
  title: string;
  value: number;
  total: number;
  titleTip?: string;
  contentTip?: string;
  activeTitle?: string;
  totalTitle?: string;
  statisticIconColor?: string;
}) => {
  const [openTip, setOpenTip] = useState(false);

  return (
    <div className="shadow-lg py-[0.8rem] px-4 rounded-lg bg-white">
      <div className="flex justify-evenly py-[0.8rem] px-0">
        <Statistic
          title={activeTitle || DASHBOARD_TEXT.ACTIVE}
          value={value}
          valueStyle={{ color: "#3f8600" }}
        />
        <Divider type="vertical" className="h-16" />
        <Statistic title={totalTitle || DASHBOARD_TEXT.TOTAL} value={total} />
      </div>
      <Divider style={{ margin: "0.5rem 0" }} />
      <div className="flex justify-between">
        <span
          className="base-text font-medium"
          style={{ color: statisticIconColor }}
        >
          {title}
        </span>
        <CustomPopover
          open={openTip}
          onOpenChange={() => setOpenTip(true)}
          title={titleTip}
          content={contentTip}
          handleClose={() => setOpenTip(false)}
        >
          <QuestionCircleOutlined
            className="pl-2 translate-y-[-2px] text-[1rem] cursor-pointer"
            style={{ color: "gray" }}
          />
        </CustomPopover>
      </div>
    </div>
  );
};

const DeviceInventoryStatistic = ({
  notDeleted,
  provisioned,
  activated,
  totalDevice,
  totalSim,
  quantityLicenseData,
}: {
  notDeleted: number;
  provisioned: number;
  activated: number;
  totalDevice: number;
  totalSim: number;
  quantityLicenseData: any;
}) => {
  return (
    <Row>
      <Col
        xl={6}
        lg={12}
        md={12}
        sm={12}
        xs={24}
        className="py-4 xl:pr-4 lg:pr-4 md:pr-4 sm:pr-4"
      >
        <StatisticCard
          title={DASHBOARD_TEXT.TOTAL_DEVICES}
          value={notDeleted}
          total={totalDevice}
          titleTip={DASHBOARD_TEXT.NOT_DELETED_DEVICES}
          contentTip={DASHBOARD_TEXT.DESCRIPTION_OF_NOT_DELETED_DEVICES}
          statisticIconColor="orange"
        />
      </Col>
      <Col xl={6} lg={12} md={12} sm={12} xs={24} className="py-4 xl:pr-4">
        <StatisticCard
          title={DASHBOARD_TEXT.ACTIVATED_SIMS}
          value={activated}
          total={totalSim}
          titleTip={DASHBOARD_TEXT.ACTIVATED_SIMS}
          contentTip={DASHBOARD_TEXT.DESCRIPTION_OF_ACTIVATED_SIMS}
          statisticIconColor="#6adf67"
        />
      </Col>
      <Col
        xl={6}
        lg={12}
        md={12}
        sm={12}
        xs={24}
        className="py-4 sm:pr-4 md:pr-4 lg:pr-4"
      >
        <StatisticCard
          title={DASHBOARD_TEXT.PROVISIONED_DEVICES}
          value={provisioned}
          total={totalDevice}
          titleTip={DASHBOARD_TEXT.PROVISIONED_DEVICES}
          contentTip={DASHBOARD_TEXT.DESCRIPTION_OF_PROVISIONED_DEVICES}
          activeTitle={DASHBOARD_TEXT.PROVISIONED}
          statisticIconColor="#0e9eff"
        />
      </Col>
      <Col xl={6} lg={12} md={12} sm={12} xs={24} className="py-4 ">
        <StatisticCard
          title={DASHBOARD_TEXT.QUANTITY_LICENSES_AVAILABLE}
          value={quantityLicenseData?.oneYearQuantity}
          total={quantityLicenseData?.threeYearQuantity}
          activeTitle={DASHBOARD_TEXT.ONE_YEAR_LICENSES}
          titleTip={DASHBOARD_TEXT.QUANTITY_LICENSES_AVAILABLE}
          contentTip={DASHBOARD_TEXT.DESCRIPTION_OF_QUANTITY_LICENSES_AVAILABLE}
          statisticIconColor="#9170ff"
          totalTitle={DASHBOARD_TEXT.THREE_YEAR_LICENSES}
        />
      </Col>
    </Row>
  );
};

export default DeviceInventoryStatistic;
