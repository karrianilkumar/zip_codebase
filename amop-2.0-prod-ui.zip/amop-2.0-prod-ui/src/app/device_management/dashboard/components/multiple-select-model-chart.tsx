import { getModelOptions } from "@/common/constants/line-chart-constants";
import useModelChartStore from "@/stores/model-chart-store";
import { SelectProps } from "antd";
import Select from "antd/es/select";
import React, { useEffect, useState } from "react";

type Props = {
  onSelect: (value: string[]) => void;
};

export const MultipleSelect: React.FC<Props> = ({ onSelect }) => {
  const { manufacturerModels } = useModelChartStore();
  const [selectedManufacturer, setSelectedManufacturer] = useState<
    string | null
  >(null);
  const [modelValue, setModelValue] = useState<string[]>([]);

  const manufacturerOptions = manufacturerModels.map(({ manufacturer }) => ({
    label: manufacturer,
    value: manufacturer,
  }));

  const modelOptions = getModelOptions(
    manufacturerModels,
    selectedManufacturer,
    modelValue,
  );

  const manufacturerSelectProps: SelectProps = {
    style: { width: "100%" },
    value: selectedManufacturer,
    options: manufacturerOptions,
    onChange: (value: string) => {
      setSelectedManufacturer(value);
      setModelValue([]);
    },
    placeholder: "Carrier",
    loading: !manufacturerModels.length,
  };

  const modelSelectProps: SelectProps = {
    mode: "multiple",
    value: modelValue,
    options: modelOptions,
    onChange: (newValue: string[]) => {
      onSelect(newValue);
      setModelValue(newValue);
    },
    placeholder: "Model",
    maxTagCount: "responsive",
    loading: !modelOptions.length,
  };

  useEffect(() => {
    if (manufacturerModels.length && !selectedManufacturer) {
      setSelectedManufacturer(manufacturerModels[0].manufacturer);
    }

    if (selectedManufacturer && modelValue.length === 0) {
      const manufacturer = manufacturerModels.find(
        (m) => m.manufacturer === selectedManufacturer,
      );

      if (manufacturer) {
        const firstModel = manufacturer.models[0];
        const newModelValue = firstModel ? [firstModel] : [];
        setModelValue(newModelValue);
        onSelect(newModelValue);
      }
    }
  }, [manufacturerModels, selectedManufacturer, modelValue, onSelect]);

  return (
    <div className="flex flex-col space-y-4 w-full">
      <div className="flex flex-row space-x-4 w-full">
        <Select {...manufacturerSelectProps} className="w-1/4" />
        <Select {...modelSelectProps} className="w-3/4" />
      </div>
    </div>
  );
};
