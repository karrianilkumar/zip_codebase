"use client";

import React, { useState } from "react";
import { DeviceManagementStatisticTimeDataType } from "@/types/statistic-time-types";
import { getTotalByTimeData } from "@/api/statistic-api";
import { useQuery } from "@tanstack/react-query";
import { BarChart } from "./bar-chart";

export const NetworkTypeChart: React.FC = () => {
  const [paramState, setParamState] = useState({ granularity: "month" });

  const handleChangeTime = (value: string) => {
    setParamState({
      granularity: value,
    });
  };

  const handleChangeFilters = (value: string[]) => {
    setParamState((prevState: any) => {
      if (value.length === 0) {
        return {
          granularity: prevState.granularity,
        };
      }
      if (value.includes("All")) {
        return {
          granularity: prevState.granularity,
        };
      }
      return {
        ...prevState,
        manufacturers: value,
      };
    });
  };

  const { data } = useQuery({
    queryKey: ["network-statistic-time-data", paramState],
    queryFn: async () => {
      const data = await getTotalByTimeData({
        type: "devices_by_network_type",
        ...paramState,
      });
      return data as DeviceManagementStatisticTimeDataType[];
    },
    staleTime: 1000 * 60 * 5,
    retry: 1,
  });

  return (
    <BarChart
      data={data || []}
      type="network"
      granularity={paramState.granularity}
      title="Connected Devices by Network Type"
      tooltipDesc="Number of devices connected by network type of its SIM card"
      handleChangeTime={handleChangeTime}
      handleChangeFilter={handleChangeFilters}
    />
  );
};
