"use client";

import { getTotalByTimeData } from "@/api/statistic-api";
import { DeviceManagementStatisticTimeDataType } from "@/types/statistic-time-types";
import { useQuery } from "@tanstack/react-query";
import React, { useState } from "react";
import { BarChart } from "./bar-chart";

type ParamStateType = {
  granularity: string;
  keys: string[];
};

export const ModelChart: React.FC = () => {
  const [paramState, setParamState] = useState<ParamStateType>({
    granularity: "month",
    keys: [],
  });

  const handleChangeTime = (value: string) => {
    setParamState((prevState: any) => {
      return {
        ...prevState,
        granularity: value,
      };
    });
  };

  const handleSelectModel = (value: string[]) => {
    setParamState((prevState: any) => {
      if (value.length === 0) {
        return {
          granularity: prevState.granularity,
        };
      }
      return {
        ...prevState,
        keys: value,
      };
    });
  };

  const { data } = useQuery({
    queryKey: ["model-statistic-time-data", paramState],
    queryFn: async () => {
      const data = await getTotalByTimeData({
        type: "devices_by_model",
        ...paramState,
      });
      return data as DeviceManagementStatisticTimeDataType[];
    },
    staleTime: 1000 * 60 * 5,
    retry: 1,
    enabled: paramState?.keys?.length ? true : false,
  });

  return (
    <BarChart
      data={data || []}
      granularity={paramState.granularity}
      title="Connected Devices by Model"
      tooltipDesc="Numbers of devices count by each device model"
      type="multiple"
      handleChangeTime={handleChangeTime}
      handleChangeFilter={handleSelectModel}
    />
  );
};
