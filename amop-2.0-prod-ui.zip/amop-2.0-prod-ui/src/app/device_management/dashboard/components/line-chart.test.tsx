import { cleanup, render, screen, waitFor } from "@testing-library/react";
import { LineChart } from "./line-chart";

describe("LineChart", () => {
  beforeAll(() => {
    // some error when cleanup with ApexChart but not related to our application
    jest.spyOn(console, "error").mockImplementation(() => {});
  });
  afterEach(skipApexCleanupError);
  afterAll(() => {
    jest.clearAllMocks();
  });

  it("should not breaking", () => {
    render(<LineChart data={[]} title="Hello" granularity="month" />);
    expect(screen.getByText("Hello")).toBeInTheDocument();
    expect(screen.getByText("Month")).toBeInTheDocument();
  });

  it("should show multiple select", async () => {
    render(
      <LineChart
        data={[
          {
            name: "Some thing",
            quantity: 10,
            time: new Date().toISOString(),
          },
        ]}
        type="multiple"
      />,
    );

    await waitFor(() =>
      expect(screen.getAllByRole("combobox")).toHaveLength(3),
    );
  });
});

function skipApexCleanupError() {
  try {
    cleanup();
  } catch (e) {}
}
