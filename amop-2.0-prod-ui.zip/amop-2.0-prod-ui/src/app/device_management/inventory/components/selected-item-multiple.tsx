import React from "react";
import { CloseOutlined } from "@ant-design/icons";
import { DeviceManagementInventoryDataType } from "@/types/inventory-types";
import useInventoryTableStore from "@/stores/inventory-table-store";
import { PROVISION_TEXT } from "@/common/constants/provisioning-constants";

type Props = {
  item: DeviceManagementInventoryDataType;
  handleRemoveItem: (item: DeviceManagementInventoryDataType) => void;
};

export const SelectedItemMultiple: React.FC<Props> = ({
  item,
  handleRemoveItem,
}) => {
  const { removeSelectedInventoryTableItem } = useInventoryTableStore();
  const handleClickRemove = () => {
    removeSelectedInventoryTableItem(item);
    handleRemoveItem(item);
  };
  return (
    <div className="border border-stone-300 mb-2 rounded p-2 relative mr-2">
      <CloseOutlined
        className="absolute right-2 cursor-pointer transition-all hover-red"
        style={{ color: "#a4a4a4" }}
        onClick={handleClickRemove}
      />
      <p>
        <span className="font-medium">{PROVISION_TEXT.PROVIDER_LABEL}: </span>
        {item?.provider}
      </p>
      <p>
        <span className="font-medium">{PROVISION_TEXT.MANUFACTURER}: </span>
        {item?.manufacturer?.name}
      </p>
      <p>
        <span className="font-medium">
          {PROVISION_TEXT.DEVICE_MODEL_LABEL}:{" "}
        </span>
        {item?.model}
      </p>
      <p>
        <span className="font-medium">{PROVISION_TEXT.IMEI}: </span>
        {item?.imei}
      </p>
      <p>
        <span className="font-medium">{PROVISION_TEXT.ICCID}: </span>
        {item?.iccid}
      </p>
      <p>
        <span className="font-medium">{PROVISION_TEXT.MACADDRESS}: </span>
        {item?.mac}
      </p>
      <p>
        <span className="font-medium">{PROVISION_TEXT.CUSTOMER_LABEL}: </span>
        {item?.customer}
      </p>
      {/*TODO: Handle provisioned device*/}
      {/* {item?.group && (
        <p className="text-right">
          <Tooltip title="This device has been provisioned. Please remove to continue." color="orange">
            <ExclamationCircleOutlined className="cursor-pointer" style={{ color: "#eda400", fontSize: "1rem" }} />
          </Tooltip>
        </p>
      )} */}
    </div>
  );
};
