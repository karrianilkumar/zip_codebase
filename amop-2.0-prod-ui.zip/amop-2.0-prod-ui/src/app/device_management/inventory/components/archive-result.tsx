import { Button, Result, Spin } from "antd";
import React, { useEffect, useState } from "react";
import { ArrowLeftOutlined } from "@ant-design/icons";
import Confetti from "react-dom-confetti";
import { DeviceManagementInventoryDataType } from "@/types/inventory-types";
import { ARCHIVE_TEXT } from "@/common/constants/inventory-constants";

type Props = {
  handleCloseModal: () => void;
  goToProvisioning?: boolean;
  handleBack?: (value: boolean) => void;
  onSuccess: boolean;
  onError?: boolean;
  onLoading?: boolean;
  data?: DeviceManagementInventoryDataType[];
};

export const ArchiveResult: React.FC<Props> = ({
  handleCloseModal,
  handleBack,
  onSuccess,
  onError,
  onLoading,
  data,
}) => {
  const [isLargeExploding, setIsLargeExploding] = useState(false);

  useEffect(() => {
    if (onSuccess) {
      setTimeout(() => {
        setIsLargeExploding(true);
      }, 500);
    }
  }, [onSuccess]);

  return (
    <div className="overflow-hidden">
      {onLoading && (
        <>
          <Result
            className="mt-20"
            status="info"
            title={`${ARCHIVE_TEXT.ARCHIVING} ${data?.length} ${ARCHIVE_TEXT.DEVICES}!`}
          ></Result>
          <div className="flex flex-col justify-center items-center h-full">
            <Spin size="large" />
          </div>
        </>
      )}
      {onSuccess && (
        <>
          <Result
            className="mt-20"
            status="success"
            title={`${ARCHIVE_TEXT.SUCCESSFULLY_ARCHIVED} ${data?.length} ${ARCHIVE_TEXT.DEVICES}!`}
            extra={[
              <Button
                size="large"
                type="primary"
                key="finish"
                onClick={handleCloseModal}
              >
                {ARCHIVE_TEXT.FINISH_AND_CLOSE}
              </Button>,
            ]}
          />

          <div className="flex justify-center mt-20">
            <Confetti active={isLargeExploding} />
          </div>
        </>
      )}
      {onError && (
        <>
          <Result
            className="mt-20"
            status="warning"
            title={ARCHIVE_TEXT.ARCHIVE_FAILED_RESULT_TITLE}
            subTitle={ARCHIVE_TEXT.ARCHIVE_FAILED_RESULT_SUB_TITLE}
            extra={[
              handleBack ? (
                <Button
                  size="large"
                  type="primary"
                  key="back"
                  onClick={() => handleBack(false)}
                  icon={<ArrowLeftOutlined />}
                >
                  {ARCHIVE_TEXT.BACK_TO_ARCHIVE_STEPS}
                </Button>
              ) : null,
              <Button
                className="w-32"
                size="large"
                type="primary"
                ghost
                key="finish"
                onClick={handleCloseModal}
              >
                {ARCHIVE_TEXT.CANCEL}
              </Button>,
            ]}
          />
        </>
      )}
    </div>
  );
};
