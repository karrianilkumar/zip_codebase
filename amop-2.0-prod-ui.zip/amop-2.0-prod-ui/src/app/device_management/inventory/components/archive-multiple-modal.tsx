"use client";

import { ModalWrapper } from "@/components/modal-wrapper";
import useArchiveMultipleModalStore from "@/stores/archive-multiple-modal-store";
import React from "react";
import { SelectedItemMultiple } from "./selected-item-multiple";
import { MODAL_WIDTH } from "@/common/constants/modal-size-constants";
import { Button, Spin } from "antd";
import { postArchiveDevice } from "@/api/device-api";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import {
  ARCHIVE_TEXT,
  INVENTORY_QUERY_KEY,
} from "@/common/constants/inventory-constants";
import { PROVISION_QUERY_KEY } from "@/common/constants/provisioning-constants";
import { ArchiveResult } from "./archive-result";
import useInventoryTableStore from "@/stores/inventory-table-store";

export const ArchiveMultipleModal = () => {
  const {
    onOpenArchiveMultipleModal,
    setOpenArchiveMultipleModal,
    selectedArchiveMultipleDeviceModal,
    removeSelectedArchiveMultipleDeviceModalItem,
    submitted,
    setSubmitted,
  } = useArchiveMultipleModalStore();
  const { setSelectedInventoryTableItemsKey, setSelectedInventoryTableItems } =
    useInventoryTableStore();
  const queryClient = useQueryClient();

  const {
    mutateAsync: postArchiveDeviceMutateAsync,
    isLoading,
    isSuccess,
    isError,
  } = useMutation({
    mutationFn: postArchiveDevice,
    onSuccess: () => {
      setSelectedInventoryTableItemsKey([]);
      setSelectedInventoryTableItems([]);
    },
  });

  const handleArchiveMultipleDevice = async () => {
    try {
      setSubmitted(true);
      const ids = selectedArchiveMultipleDeviceModal.map((item) => item.id);
      await postArchiveDeviceMutateAsync(ids);
      queryClient.invalidateQueries({ queryKey: [INVENTORY_QUERY_KEY.DEVICE] });
      queryClient.invalidateQueries({
        queryKey: [PROVISION_QUERY_KEY.GET_PROVISION],
      });
    } catch (error) {
      console.error(error);
    }
  };

  const handleCloseModal = () => {
    setOpenArchiveMultipleModal(false);
    setSubmitted(false);
  };

  const footer = (
    <div className="flex justify-between mt-2">
      <div className="text-left">
        <p className="mt-2 font-medium text-base">
          Number of Selected Device: {selectedArchiveMultipleDeviceModal.length}
        </p>
      </div>
      <div className="flex">
        <Button
          className="mr-2"
          onClick={() => setOpenArchiveMultipleModal(false)}
          disabled={isLoading}
        >
          Cancel
        </Button>
        <Button
          type={isLoading ? "default" : "primary"}
          onClick={handleArchiveMultipleDevice}
          disabled={
            isLoading || selectedArchiveMultipleDeviceModal.length === 0
          }
          className="min-w-[100px]"
        >
          {isLoading ? (
            <Spin size="small" className="align-self-center" />
          ) : (
            "Archive now"
          )}
        </Button>
      </div>
    </div>
  );

  return (
    <div>
      <ModalWrapper
        title={ARCHIVE_TEXT.ARCHIVE_DEVICES}
        openState={onOpenArchiveMultipleModal}
        onCloseModel={
          submitted
            ? handleCloseModal
            : () => setOpenArchiveMultipleModal(false)
        }
        footer={submitted ? "" : footer}
        width={MODAL_WIDTH.LARGE}
        className="min-h-[90vh]"
      >
        <div className="h-[80vh] overflow-y-auto">
          {submitted ? (
            <ArchiveResult
              data={selectedArchiveMultipleDeviceModal}
              handleCloseModal={handleCloseModal}
              onSuccess={isSuccess}
              onLoading={isLoading}
              handleBack={setSubmitted}
              onError={isError}
            />
          ) : (
            <div className="flex h-full">
              <div className="grow-0 shrink-0 basis-1/4 border-r-stone-300 border-r">
                <div className="font-medium text-base h-8">
                  Selected Devices
                </div>
                <div className="overflow-y-auto h-[calc(100%-2rem)]">
                  {selectedArchiveMultipleDeviceModal.map((item) => (
                    <SelectedItemMultiple
                      handleRemoveItem={
                        removeSelectedArchiveMultipleDeviceModalItem
                      }
                      key={item.id}
                      item={item}
                    />
                  ))}
                </div>
              </div>
              <div className="flex-grow-0 flex-shrink-0 basis-3/4">
                <div className="flex flex-col h-full justify-center items-center">
                  <div className="font-medium text-base h-8 mb-4 text-center">
                    Are you sure you want to Archive these Devices?
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </ModalWrapper>
    </div>
  );
};
