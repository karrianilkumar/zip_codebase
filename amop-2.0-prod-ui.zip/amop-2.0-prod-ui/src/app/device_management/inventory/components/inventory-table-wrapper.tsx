"use client";

import React, { useEffect, useState } from "react";
import { InventoryTableSorting } from "./inventory-table-sorting";
import { InventoryTable } from "./inventory-table";
import {
  convertStringArrayToString,
  convertTableColumnsToTitleArray,
} from "@/common/helper/table-helper";
import { useSearchParams } from "next/navigation";
import useInventoryTableStore from "@/stores/inventory-table-store";
import {
  ADM_INVENTORY_HIDE_COLUMNS,
  SEARCH_PARAM,
} from "@/common/constants/inventory-constants";

export const InventoryTableWrapper = () => {
  const { inventoryTableColumns } = useInventoryTableStore();
  const searchParams = useSearchParams();
  const [inventoryColumns, setInventoryColumns] = useState(
    inventoryTableColumns,
  );
  const [search, setSearch] = useState(searchParams.get(SEARCH_PARAM) ?? "");

  const handleChangeColumns = (columns: string[]) => {
    let visibleColumns = inventoryTableColumns.filter((item) =>
      columns.includes(item.title as string),
    );
    setInventoryColumns(visibleColumns);
    let hideColumns = inventoryTableColumns.filter(
      (originalItem) =>
        visibleColumns.findIndex(
          (visibleItem) => visibleItem.title === originalItem.title,
        ) == -1,
    );
    let hideColumnsString = convertTableColumnsToTitleArray(hideColumns);
    typeof window !== "undefined" &&
      window.localStorage.setItem(
        ADM_INVENTORY_HIDE_COLUMNS,
        convertStringArrayToString(hideColumnsString),
      );
  };

  useEffect(() => {
    let hideColumnsStringArrStorage: string[] =
      (typeof window !== "undefined" &&
        (window.localStorage.getItem(ADM_INVENTORY_HIDE_COLUMNS) ?? "").split(
          ",",
        )) ||
      [];
    let initialInventoryColumns = inventoryTableColumns;
    if (hideColumnsStringArrStorage.length) {
      initialInventoryColumns = inventoryTableColumns.filter(
        (column) =>
          !hideColumnsStringArrStorage.includes(column.title as string),
      );
    }
    setInventoryColumns(initialInventoryColumns);
  }, [inventoryTableColumns]);

  return (
    <div>
      <InventoryTableSorting
        handleChangeColumns={handleChangeColumns}
        visibleColumns={inventoryColumns}
        onSearchFilterChanged={setSearch}
        initialSearch={search}
      />
      <InventoryTable columnList={inventoryColumns} searchString={search} />
    </div>
  );
};
