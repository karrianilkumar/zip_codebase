"use client";

import { getDeviceManufacture, getInventoryData } from "@/api/device-api";
import {
  AMOP_URL,
  INVENTORY_QUERY_KEY,
  INVENTORY_TABLE_TEXT,
  LAST_CONNECT_DESC_PARAM,
} from "@/common/constants/inventory-constants";
import { DeviceManagementInventoryActionItemKeys } from "@/common/constants/table-constants";
import {
  convertToInventoryTableData,
  getInventoryIgnoreFieldsSearch,
  mapManufactureData,
} from "@/common/helper/table-helper";
import { inventoryTableExport, InventoryTableExportProps } from "@/lib/xlsx";
import useArchiveMultipleModalStore from "@/stores/archive-multiple-modal-store";
import useInventoryTableStore from "@/stores/inventory-table-store";
import useProvisionMultipleModalStore from "@/stores/provision-multiple-modal-store";
import useReloginConfirmationModalStore from "@/stores/re-login-confirmation-modal-store";
import { DeviceManagementInventoryDataType } from "@/types/inventory-types";
import { useQuery } from "@tanstack/react-query";
import { notification, Pagination, Table } from "antd";
import { ColumnsType, TableRowSelection } from "antd/es/table/interface";
import Image from "next/image";
import { MenuInfo } from "rc-menu/lib/interface";
import React, { useCallback, useEffect, useState } from "react";
import { ScrollHint } from "../../components/scroll-hint";
import { LastUpdated } from "@/app/device_management/components/last-updated";
import { InventoryTableItemAction } from "@/app/device_management/inventory/components/inventory-table-item-action";

type Props = {
  columnList: ColumnsType<DeviceManagementInventoryDataType>;
  searchString?: string;
};

export const InventoryTable: React.FC<Props> = ({
  columnList,
  searchString = "",
}) => {
  const { setSelectedProvisionMultipleDeviceModal } =
    useProvisionMultipleModalStore();
  const { setSelectedArchiveMultipleDeviceModal } =
    useArchiveMultipleModalStore();
  const {
    setQueryIsFetching,
    triggerExport,
    setTriggerExport,
    setSelectedInventoryTableItems,
    selectedInventoryTableItems,
    setSelectedInventoryTableItemsKey,
    selectedInventoryTableItemsKey,
    currentPage,
    setCurrentPage,
  } = useInventoryTableStore();
  const { setOpenReloginConfirmationModal } =
    useReloginConfirmationModalStore();
  const [pageSize, setPageSize] = useState(10);
  const [paramState, setParamState] = useState({} as any);

  const handleActionClick = (
    e: MenuInfo,
    record: DeviceManagementInventoryDataType,
  ) => {
    switch (e.key) {
      case DeviceManagementInventoryActionItemKeys.PROVISION_DEVICE:
        setSelectedProvisionMultipleDeviceModal([record]);
        break;
      case DeviceManagementInventoryActionItemKeys.ARCHIVE_DEVICE:
        setSelectedArchiveMultipleDeviceModal([record]);
        break;
      case DeviceManagementInventoryActionItemKeys.GO_TO_M2M_INVENTORY ||
        DeviceManagementInventoryActionItemKeys.GO_TO_MOBILITY_INVENTORY:
        const portalTypeId = record?.sim?.serviceProvider?.portalTypeId;
        if (typeof portalTypeId === "number") {
          window.location.href = AMOP_URL(record.iccid, portalTypeId);
        }
        break;
      default:
        break;
    }
  };

  const renderColumns = columnList.map((col) => {
    if (col.key === "action") {
      col.render = (text, record) => (
        <InventoryTableItemAction
          record={record}
          onClick={handleActionClick}
          key={record.id}
        />
      );
    }
    if (col.key === "simStatus") {
      col.render = (text, record) => {
        const colors: Record<string, any> = {
          active: "#28A745",
          Activated: "#1AB394",
          deactive: "#FFC107",
          Deactivated: "#ED5565",
          "Activation Ready": "#FFC107",
        };
        const iccid = record.iccid;
        const portalTypeId = record.sim?.serviceProvider?.portalTypeId;
        const isHasPortalTypeId = typeof portalTypeId === "number";
        const iconPath = `/assets/icons/up-right-from-square-solid.svg`;
        return (
          <a
            href={isHasPortalTypeId ? AMOP_URL(iccid, portalTypeId) : "#"}
            // target="_blank"
            rel="noopener noreferrer"
            className={`flex items-center text-${colors[text]}`}
            style={{ color: colors[text] }}
          >
            {text ? (
              <span className="font-semibold">
                {text?.length ? text[0]?.toUpperCase() + text.slice(1) : ""}
              </span>
            ) : (
              <span className="font-semibold">N/A</span>
            )}
            <Image
              src={iconPath}
              alt="Icon"
              className="ml-2"
              width={12}
              height={12}
            />
          </a>
        );
      };
    }
    return col;
  });

  const [api, contextHolder] = notification.useNotification({
    maxCount: 1,
    placement: "bottomRight",
  });

  const onSelectChange = (
    selectedRowKeys: React.Key[],
    selectedRows: DeviceManagementInventoryDataType[],
  ) => {
    setSelectedInventoryTableItemsKey(selectedRowKeys);
    setSelectedInventoryTableItems(selectedRows);
  };

  const { data: deviceManufactureList } = useQuery({
    queryKey: [INVENTORY_QUERY_KEY.DEVICE_MANUFACTURE],
    queryFn: async () => {
      try {
        const data = await getDeviceManufacture();
        return data.results;
      } catch (error) {
        api.error({
          message: INVENTORY_TABLE_TEXT.serverErrorMessage,
          description: INVENTORY_TABLE_TEXT.serverErrorDescription,
          duration: 4,
        });
      }
    },
  });

  const { data, isLoading, dataUpdatedAt, isFetching, isError } = useQuery({
    queryKey: [
      INVENTORY_QUERY_KEY.DEVICE,
      pageSize,
      currentPage,
      paramState,
      deviceManufactureList,
      searchString,
    ],
    queryFn: async () => {
      try {
        if (searchString.length) {
          paramState.search = searchString;
          paramState.ignoreFields = getInventoryIgnoreFieldsSearch(columnList);
        } else {
          delete paramState.search;
          delete paramState.ignoreFields;
        }
        let data = await getInventoryData({
          page: currentPage,
          limit: pageSize,
          sort: LAST_CONNECT_DESC_PARAM,
          ...paramState,
        });
        if (data && data.results) {
          data.results = mapManufactureData(
            data.results,
            deviceManufactureList,
          );
        }
        return data;
      } catch (error) {
        api.error({
          message: INVENTORY_TABLE_TEXT.serverErrorMessage,
          description: INVENTORY_TABLE_TEXT.serverErrorDescription,
          duration: 4,
        });
      }
    },
    staleTime: 1000 * 60 * 5,
    retry: 1,
  });

  const handlePageChange = (selectedPage: number, currentPageSize: number) => {
    setCurrentPage(selectedPage);
  };

  const handlePageSizeChange = (
    currentPage: number,
    selectedPageSize: number,
  ) => {
    setPageSize(selectedPageSize);
  };

  const rowSelection: TableRowSelection<DeviceManagementInventoryDataType> = {
    selectedRowKeys: selectedInventoryTableItemsKey,
    onChange: onSelectChange,
    selections: [Table.SELECTION_ALL, Table.SELECTION_NONE],
    preserveSelectedRowKeys: true,
  };

  const exportHandler = useCallback(async () => {
    let exportProps: InventoryTableExportProps = {
      fileName: INVENTORY_TABLE_TEXT.inventory,
      selectedRowData: selectedInventoryTableItems,
      visibleColumns: columnList,
      paramState,
    };
    let exportResult = await inventoryTableExport(exportProps);
    if (exportResult === undefined) {
      api.error({
        message: INVENTORY_TABLE_TEXT.errorMessage,
        description: INVENTORY_TABLE_TEXT.errorDescription,
        duration: 4,
      });
    }
    if (exportResult?.length) {
      api.success({
        message: INVENTORY_TABLE_TEXT.successMessage,
        description: `${INVENTORY_TABLE_TEXT.successDescription1} ${exportResult}${INVENTORY_TABLE_TEXT.successDescription2}`,
        duration: 4,
      });
    }
    setTriggerExport(false);
  }, [
    api,
    columnList,
    paramState,
    selectedInventoryTableItems,
    setTriggerExport,
  ]);

  useEffect(() => {
    if (triggerExport) {
      exportHandler();
    }
  }, [triggerExport, exportHandler]);

  useEffect(() => {
    if (isError) {
      api.error({
        message: INVENTORY_TABLE_TEXT.serverErrorMessage,
        description: INVENTORY_TABLE_TEXT.serverErrorDescription,
        duration: 4,
      });
    }
  }, [isError, api]);

  useEffect(() => {
    return () => {
      setSelectedInventoryTableItemsKey([]);
      setSelectedInventoryTableItems([]);
    };
  }, [setSelectedInventoryTableItems, setSelectedInventoryTableItemsKey]);

  useEffect(() => {
    setQueryIsFetching(isFetching);
  }, [isFetching, setQueryIsFetching]);

  useEffect(() => {
    if (searchString) {
      // reset page to 1 when search
      setCurrentPage(1);
    }
  }, [searchString, setCurrentPage]);

  return (
    <div>
      {contextHolder}
      <div>
        <Table
          loading={isLoading || isFetching}
          rowSelection={rowSelection}
          columns={renderColumns}
          dataSource={
            isLoading || isFetching
              ? []
              : convertToInventoryTableData(data?.results)
          }
          scroll={{ x: "max-content" }}
          pagination={false}
          onChange={(pagination, filters: any, sorter: any) => {
            let paramObject: any = {};
            if (sorter?.order) {
              let sortParam = `${sorter?.columnKey}:${(
                sorter?.order as string
              ).substring(0, sorter?.order.length - 3)}`;
              paramObject.sort = sortParam;
            }
            for (const [key, value] of Object.entries(filters)) {
              if (value !== null) {
                paramObject[key] = value;
              }
            }
            setCurrentPage(1);
            setParamState(paramObject);
          }}
        />
      </div>
      <div
        className={`flex justify-between mt-4 flex-wrap-reverse gap-4 ${
          isLoading ? "hidden" : "flex"
        }`}
      >
        <LastUpdated time={dataUpdatedAt} />
        <div className="flex items-center">
          <Pagination
            showSizeChanger
            pageSizeOptions={[5, 10, 20, 30, 40, 50]}
            pageSize={pageSize}
            onShowSizeChange={handlePageSizeChange}
            current={currentPage}
            total={data?.totalResults || 0}
            onChange={handlePageChange}
          />
          <ScrollHint />
        </div>
      </div>
    </div>
  );
};
