import React from "react";
import { ArchiveMultipleModal } from "./archive-multiple-modal";
import { ProvisionMultipleModal } from "./provision-multiple-modal";

export const InventoryModalWrapper = () => {
  return (
    <div>
      <ArchiveMultipleModal />
      <ProvisionMultipleModal />
    </div>
  );
};
