"use client";

import { Button, Dropdown, MenuProps } from "antd";
import Search from "antd/es/input/Search";
import React, { ChangeEvent, useRef, useState } from "react";
import { DownloadOutlined, SyncOutlined } from "@ant-design/icons";
import {
  DeviceManagementInventoryMultipleActionItemKeys,
  deviceManagementInventoryMultipleActionItem,
  initialDeviceManagementInventoryColumns,
} from "@/common/constants/table-constants";
import { ColumnsType } from "antd/es/table";
import useInventoryTableStore from "@/stores/inventory-table-store";
import { convertTableColumnsToTitleArray } from "@/common/helper/table-helper";
import { DeviceManagementInventoryDataType } from "@/types/inventory-types";
import {
  COLUMN_CHECKLIST_DROPDOWN,
  DEVICE,
  DEVICES,
  EXPORT,
  INVENTORY_QUERY_KEY,
  INVENTORY_TABLE_TEXT,
  SEARCH_PLACEHOLDER,
} from "@/common/constants/inventory-constants";
import useArchiveMultipleModalStore from "@/stores/archive-multiple-modal-store";
import useProvisionMultipleModalStore from "@/stores/provision-multiple-modal-store";
import { useQueryClient } from "@tanstack/react-query";
import { DropdownCheckboxButton } from "@/components/dropdown-checkbox-button";
import { useCommonFeatureStore } from "@/stores/common-feature-store";
import { FeatureFlag } from "@/components/feature-flag/feature-flag";
import { DeviceManagementInventoryFeatures } from "@/common/enums/module-feature-enum";

type Props = {
  handleChangeColumns: (columns: string[]) => void;
  visibleColumns: ColumnsType<DeviceManagementInventoryDataType>;
  onSearchFilterChanged?: (search: string) => void;
  initialSearch: string;
};

export const InventoryTableSorting: React.FC<Props> = ({
  initialSearch,
  handleChangeColumns,
  visibleColumns,
  onSearchFilterChanged = () => {},
}) => {
  const { hasFeature } = useCommonFeatureStore();
  const {
    queryIsFetching,
    setTriggerExport,
    selectedInventoryTableItems,
    setCurrentPage,
  } = useInventoryTableStore();
  const { setOpenArchiveMultipleModal, setSelectedArchiveMultipleDeviceModal } =
    useArchiveMultipleModalStore();
  const { setSelectedProvisionMultipleDeviceModal } =
    useProvisionMultipleModalStore();
  const debounceRef = useRef<number>();
  const [_search, _setSearch] = useState(initialSearch);
  const queryClient = useQueryClient();

  const refetch = () => {
    setCurrentPage(1);
    queryClient.invalidateQueries({ queryKey: [INVENTORY_QUERY_KEY.DEVICE] });
  };

  const handleClickExport = async () => {
    setTriggerExport(true);
  };

  const handleSearchChange = (ev: ChangeEvent<HTMLInputElement>) => {
    _setSearch(ev.target.value);
    if (debounceRef.current) {
      window.clearTimeout(debounceRef.current);
    }
    debounceRef.current = window.setTimeout(() => {
      onSearchFilterChanged(ev.target.value);
    }, 300);
  };

  const handleActionDropdownClick: MenuProps["onClick"] = (e) => {
    switch (e.key) {
      case DeviceManagementInventoryMultipleActionItemKeys.PROVISION_DEVICES:
        setSelectedProvisionMultipleDeviceModal(selectedInventoryTableItems);
        break;
      case DeviceManagementInventoryMultipleActionItemKeys.ARCHIVE_DEVICES:
        setSelectedArchiveMultipleDeviceModal(selectedInventoryTableItems);
        break;
      default:
        break;
    }
  };

  const actionItems = deviceManagementInventoryMultipleActionItem?.filter(
    (item) => {
      if (!item) {
        return false;
      }
      if (
        item.key ===
        DeviceManagementInventoryMultipleActionItemKeys.ARCHIVE_DEVICES
      ) {
        return hasFeature(DeviceManagementInventoryFeatures.Archive);
      } else if (
        item.key ===
        DeviceManagementInventoryMultipleActionItemKeys.PROVISION_DEVICES
      ) {
        return hasFeature(DeviceManagementInventoryFeatures.Provision);
      } else {
        return true;
      }
    },
  );

  return (
    <div className="my-2 flex flex-col lg:flex-row justify-between space-y-2 lg:space-y-0">
      <div className="flex justify-center lg:justify-start gap-2 items-center w-full">
        <Search
          placeholder={SEARCH_PLACEHOLDER}
          className="text-sm h-15 w-full lg:w-96"
          value={_search}
          onChange={handleSearchChange}
          allowClear
          size="middle"
          loading={!!(_search.length && queryIsFetching)}
        />
        <div>
          <div className="sm:hidden">
            <Button
              type="primary"
              icon={<SyncOutlined spin={queryIsFetching} />}
              onClick={() => refetch()}
              disabled={queryIsFetching}
              className="save-btn"
            />
          </div>

          <div className="hidden sm:flex">
            <Button
              type="primary"
              onClick={() => refetch()}
              disabled={queryIsFetching}
              icon={<SyncOutlined spin={queryIsFetching} />}
              className="save-btn"
            >
              {queryIsFetching
                ? INVENTORY_TABLE_TEXT.fetching
                : INVENTORY_TABLE_TEXT.refresh}
            </Button>
          </div>
        </div>
      </div>
      <div className="flex flex-wrap justify-center lg:justify-end gap-2 items-center w-full">
        {!!actionItems?.length && (
          <Dropdown
            menu={{
              items: actionItems,
              onClick: handleActionDropdownClick,
            }}
            disabled={selectedInventoryTableItems.length === 0}
          >
            <Button
              type="primary"
              size="middle"
              className="text-sm h-10 save-btn"
            >
              Actions ({selectedInventoryTableItems.length}
              {selectedInventoryTableItems.length > 1
                ? " " + DEVICES
                : " " + DEVICE}
              )
            </Button>
          </Dropdown>
        )}
        <DropdownCheckboxButton
          title={COLUMN_CHECKLIST_DROPDOWN}
          initialCheckList={convertTableColumnsToTitleArray(
            initialDeviceManagementInventoryColumns,
          )}
          initialCheckedList={convertTableColumnsToTitleArray(visibleColumns)}
          handleCheck={handleChangeColumns}
        />
        <FeatureFlag feature={DeviceManagementInventoryFeatures.Export}>
          <Button
            type="primary"
            className="text-sm h-10 save-btn"
            icon={<DownloadOutlined />}
            onClick={handleClickExport}
          >
            {EXPORT}
          </Button>
        </FeatureFlag>
      </div>
    </div>
  );
};
