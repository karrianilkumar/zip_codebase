'use client'
import React, { useState, useEffect } from "react";
import { Modal, Select, Button, Form, notification, Input, Spin, Checkbox } from "antd";
import type { SelectProps } from 'antd/es/select';
import { DropdownStyles } from "@/app/components/css/dropdown";
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { ChevronDownIcon } from "@heroicons/react/24/outline";

const { Option } = Select;

interface CreateRevIoCustomerProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

interface DropdownOption {
  label: string;
  value: string;
}

const CreateRevIoCustomer: React.FC<CreateRevIoCustomerProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const [form] = Form.useForm();
  const editableDrp = DropdownStyles;
  const [loading, setLoading] = useState(false);
  const [revIoAccounts, setRevIoAccounts] = useState<DropdownOption[]>([]);
  const [billProfiles, setBillProfiles] = useState<DropdownOption[]>([]);
  const [parentCustomers, setParentCustomers] = useState<DropdownOption[]>([]);
  const [useServiceAsBilling, setUseServiceAsBilling] = useState(true);
  const [useServiceAsListing, setUseServiceAsListing] = useState(true);
  const [showConfirmation, setShowConfirmation] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState(false);


  const { username, token, partner, role, selectedDb,metaData,firstLastName,sessionId} = useAuth();
  const formItemStyle = {
    marginBottom: '32px', // Increased bottom margin to accommodate error message
    '.ant-form-item-explain': {
      marginTop: '4px' // Space between dropdown and error message
    }
  };
  

  useEffect(() => {
    if (isOpen) {
      fetchDropdownData();
      // Initialize form fields when modal opens
      form.setFieldsValue({
        useServiceAddressAsBilling: true,
        useServiceAddressAsListing: true,
        status: "Prospect",
      });
      setUseServiceAsBilling(true);
      setUseServiceAsListing(true);
    } else {
      form.resetFields();
      setUseServiceAsBilling(true);
      setUseServiceAsListing(true);
    }
  }, [isOpen, form]);

  const fetchDropdownData = async () => {
    try {
      setLoading(true);
      const url = ENV_ROUTES.PEOPLE_MODULE;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/add_people_revcustomer_dropdown_data",
        role_name: role,
        parent_module: "People",
        module_name: "Rev.IO customer",
        feature_module_name:"Billing Platform Customers",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      console.log(parsedData,"Show the parsed Data")

      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message || "Error fetching data. Please try again.",
          centered: true,
        });
      }  else { 
        const responseData = parsedData?.response_data;
        console.log(responseData,"REspo")
        
        const accounts = responseData.rev_io_account?.map((item: string) => {
          const [name, id] = item.split(" - ");
          console.log(name,id,"Name Id" );
          return { label: name, value: name };
        }) || [];
        
        setRevIoAccounts(accounts);
        
        // Set default Billing Platform Account (first option)
        if (accounts.length > 0) {
          form.setFieldsValue({ revIoAccount: accounts[0].value });
        }
        
        setBillProfiles(
          responseData.rev_bill_profile?.map((item: string) => {
            const [name, id] = item.split(" - ");
            return { label: name, value: name };
          }) || []
        );
        
        console.log(responseData.customer_names,"Show the responseData");

        setParentCustomers(
          responseData.customer_names?.map((item: string) => {
            return { label: item, value: item };
          }) || []
        );
        console.log(parentCustomers, "show parent customers data");
      }

    } catch (error) {
      Modal.error({
        title: "Data Fetch Error",
        content: "Error fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const callCustomersLambdaSync = async () => {
          const url = ENV_ROUTES.OPTIMIZATION_SYNC_LAMBDA;
          const data = {
            path: "/lambda_sync_jobs_",
            key_name: "customers_sub_tenant_insert",
            tenant_name:partner
          };
      
          try {
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
          } catch (error) {
          }
      
        }

  const onFinish = async (values: any) => {
    setLoading(true);
    if (isSubmitting) return;
    setIsSubmitting(true); // Set submitting state to true
  

    const formData = {
      status: values.status,
      rev_io_account: values.revIoAccount,
      bill_profile: values.billProfile,
      parent_customer: values.parentCustomer,
      service_address: {
        first_name: values.serviceFirstName,
        middle_initial: values.serviceMiddleInitial,
        last_name: values.serviceLastName,
        company_name: values.serviceCompanyName,
        address_line_1: values.serviceAddressLine1,
        address_line_2: values.serviceAddressLine2,
        city: values.serviceCity,
        state: values.serviceState,
        postal_code: values.servicePostalCode,
        postal_code_extension: values.servicePostalCodeExtension,
        country_code: values.serviceCountryCode,
      },
      billing_address: useServiceAsBilling
        ? null
        : {
            first_name: values.billingFirstName,
            middle_initial: values.billingMiddleInitial,
            last_name: values.billingLastName,
            company_name: values.billingCompanyName,
            address_line_1: values.billingAddressLine1,
            address_line_2: values.billingAddressLine2,
            city: values.billingCity,
            state: values.billingState,
            postal_code: values.billingPostalCode,
            postal_code_extension: values.billingPostalCodeExtension,
            country_code: values.billingCountryCode,
          },
      listing_address: useServiceAsListing
        ? null
        : {
            first_name: values.listingFirstName,
            middle_initial: values.listingMiddleInitial,
            last_name: values.listingLastName,
            company_name: values.listingCompanyName,
            address_line_1: values.listingAddressLine1,
            address_line_2: values.listingAddressLine2,
            city: values.listingCity,
            state: values.listingState,
            postal_code: values.listingPostalCode,
            postal_code_extension: values.listingPostalCodeExtension,
            country_code: values.listingCountryCode,
          },
      use_service_address_as_billing_address: useServiceAsBilling,
      use_service_address_as_listing_address: useServiceAsListing,
      created_by: firstLastName,
      modified_by: firstLastName,
      modified_date:getCurrentDateTime(),
      created_date: getCurrentDateTime(),
    };

    const new_form = {
      status: values.status,
      rev_io_account: values.revIoAccount,
      bill_profile: values.billProfile,
      parent_customer: values.parentCustomer,
      
        service_address_first_name: values.serviceFirstName,
        service_address_middle_initial: values.serviceMiddleInitial,
        service_address_last_name: values.serviceLastName,
        service_address_company_name: values.serviceCompanyName,
        service_address_address_line_1: values.serviceAddressLine1,
        service_address_address_line_2: values.serviceAddressLine2,
        service_address_city: values.serviceCity,
        service_address_state: values.serviceState,
        service_address_postal_code: values.servicePostalCode,
        service_address_postal_code_extension: values.servicePostalCodeExtension,
        service_address_country_code: values.serviceCountryCode,
    
  
          billing_address_first_name: values.billingFirstName,
          billing_address_middle_initial: values.billingMiddleInitial,
          billing_address_last_name: values.billingLastName,
          billing_address_company_name: values.billingCompanyName,
          billing_address_address_line_1: values.billingAddressLine1,
          billing_address_address_line_2: values.billingAddressLine2,
          billing_address_city: values.billingCity,
          billing_address_state: values.billingState,
          billing_address_postal_code: values.billingPostalCode,
          billing_address_postal_code_extension: values.billingPostalCodeExtension,
          billing_address_country_code: values.billingCountryCode,
   
          listing_address_first_name: values.listingFirstName,
          listing_address_middle_initial: values.listingMiddleInitial,
          listing_address_last_name: values.listingLastName,
          listing_address_company_name: values.listingCompanyName,
          listing_address_address_line_1: values.listingAddressLine1,
          listing_address_address_line_2: values.listingAddressLine2,
          listing_address_city: values.listingCity,
          listing_address_state: values.listingState,
          listing_address_postal_code: values.listingPostalCode,
          listing_address_postal_code_extension: values.listingPostalCodeExtension,
          listing_address_country_code: values.listingCountryCode,
    
      use_service_address_as_billing_address: false,
      use_service_address_as_listing_address: false,
      created_by: firstLastName,
      modified_by: firstLastName,
      modified_date:getCurrentDateTime(),
      created_date: getCurrentDateTime(),
    };
    
    const api_payload_={
      service_address: {
    first_name: values?.serviceFirstName || "",
    middle_initial: values?.serviceMiddleInitial || "",
    last_name: values?.serviceLastName || "",
    company_name: values?.serviceCompanyName || "",
    line_1: values?.serviceAddressLine1 || "",
    line_2: values?.serviceAddressLine2 || "",
    city: values?.serviceCity || "",
    state_or_province: values?.serviceState || "",
    postal_code: values?.servicePostalCode || "",
    postal_code_extension: values?.servicePostalCodeExtension || "",
    country_code: values?.serviceCountryCode || "",
    created_date: getCurrentDateTime(),
   
  },
      billing_address: {
    first_name:!useServiceAsBilling? values?.billingFirstName || "": values?.serviceFirstName || "",
    middle_initial: !useServiceAsBilling? values?.billingMiddleInitial || "" : values?.serviceMiddleInitial || "",
    last_name: !useServiceAsBilling? values?.billingLastName || "" : values?.serviceLastName || "",
    company_name: !useServiceAsBilling? values?.billingCompanyName || "" : values?.serviceCompanyName || "",
    line_1: !useServiceAsBilling? values?.billingAddressLine1 || "" : values?.serviceAddressLine1 || "",
    line_2: !useServiceAsBilling? values?.listingAddressLine2 : values?.serviceAddressLine2 || "",
    city: !useServiceAsBilling? values?.billingCity || "" : values?.serviceCity || "",
    state_or_province: !useServiceAsBilling? values?.billingState || "" : values?.serviceState || "",
    postal_code: !useServiceAsBilling? values?.billingPostalCode || "" : values?.servicePostalCode || "",
    postal_code_extension: !useServiceAsBilling? values?.billingPostalCodeExtension : values?.servicePostalCodeExtension || "",
    country_code: !useServiceAsBilling? values?.billingCountryCode || "" : values?.serviceCountryCode || "",
    created_date: getCurrentDateTime(),
  },
  
  listing_address: {
    first_name: !useServiceAsListing? values?.listingFirstName || "" : values?.serviceFirstName || "",
    middle_initial: !useServiceAsListing? values?.listingMiddleInitial || "" : values?.serviceMiddleInitial || "",
    last_name: !useServiceAsListing? values?.listingLastName || "" : values?.serviceLastName || "",
    company_name: !useServiceAsListing? values?.listingCompanyName || "" : values?.serviceCompanyName || "",
    line_1: !useServiceAsListing? values?.listingAddressLine1 || "" : values?.serviceAddressLine1 || "",
    line_2: !useServiceAsListing? values?.listingAddressLine2 || "" : values?.serviceAddressLine2 || "",
    city: !useServiceAsListing? values?.listingCity || "" : values?.serviceCity || "",
    state_or_province: !useServiceAsListing? values?.listingState || "" : values?.serviceState || "",
    postal_code: !useServiceAsListing? values?.listingPostalCode || "" : values?.servicePostalCode || "",
    postal_code_extension: !useServiceAsListing? values?.listingPostalCodeExtension || "" : values?.servicePostalCodeExtension || "",
    country_code: !useServiceAsListing? values?.listingCountryCode || "" : values?.serviceCountryCode || "",
    created_date: getCurrentDateTime(),
  },
 
  status: "PENDING",
  finance: {
    bill_profile_id: values?.billProfile || "",
   
  }
    }
    const requestData = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/submit_update_info_people_revcustomer",
      module_name: "Rev.IO Customer",
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      new_data: formData,
      new_payload: new_form,
      api_payload:api_payload_,
      action: "create",
      access_token: token,
      db_name: selectedDb,
        ... metaData,
      sessionID: sessionId,
      table_name: "rev_io_customer",
    };

    try {
      const response = await axios.post(ENV_ROUTES.PEOPLE_MODULE, {
        data: requestData,
      });

      const parsedResponse = JSON.parse(response.data.body);

      if (parsedResponse.flag === false) {
        Modal.error({
          title: "Saving Error",
          content:
            parsedResponse.message ||
            "An error occurred while saving data. Please try again.",
          centered: true,
        });
      } else {
        callCustomersLambdaSync()
        notification.success({
          message: "Success",
          description: "Customer created successfully!",
          placement: "top",
        });
        onSuccess();
        onClose();
      }
    } catch (err) {
      console.error("Error saving data:", err);
      notification.error({
        message: "Error",
        description: "Failed to create the customer. Please try again.",
        placement: "top",
      });
    } finally {
      setLoading(false);
      setIsSubmitting(false); // Reset submitting state
    }
  };

  const handleSubmit = (e: { preventDefault: () => void; }) => {
    e?.preventDefault();
    form
      .validateFields() // Validate form fields first
      .then(() => {
        setShowConfirmation(true); // Show the custom popup if validation is successful
        console.log("form submited")
      })
      .catch((error) => {
        // Modal.error({
        //   title: "Please fill Mandatory fields",
        //   centered: true,
        // });
      });
  };

  const confirmSubmit = () => {
    
   // Only submit if not already submitting
   if (!isSubmitting) {
    setShowConfirmation(false);
    form.submit();
  }
  };

  const cancelConfirmation = () => {
    setShowConfirmation(false);
  };

  const renderLabel = (label: string, required: boolean) => (
    <span className="field-label">
      {label}{" "}
      {required && (
        <span className="required-indicator" style={{ color: "red" }}>
          *
        </span>
      )}
    </span>
  );

  const renderAddressFields = (prefix: string) => (
    <>
      <Form.Item
        label={renderLabel("First Name", true)}
        name={`${prefix}FirstName`}
        rules={[{ required: true, message: "First Name is required" }]}
      >
        <Input className="input" placeholder="Enter First Name" />
      </Form.Item>
      <Form.Item label="Middle Initial" name={`${prefix}MiddleInitial`} className="mt-1">
        <Input className="input" placeholder="Enter Middle Initial" />
      </Form.Item>
      <Form.Item
        label={renderLabel("Last Name", true)}
        name={`${prefix}LastName`}
        rules={[{ required: true, message: "Last name is Required" }]}
      >
        <Input className="input" placeholder="Enter Last Name" />
      </Form.Item>
      <Form.Item
        label={renderLabel("Company Name", true)}
        name={`${prefix}CompanyName`}
        rules={[{ required: true, message: "Company Name is Required" }]}
      >
        <Input  className="input" placeholder="Enter Company Name" />
      </Form.Item>
      <Form.Item
        label={renderLabel("Address Line 1", true)}
        name={`${prefix}AddressLine1`}
        rules={[{ required: true, message: "Address Line 1 is Required" }]}
      >
        <Input className="input" placeholder="Enter Address Line 1" />
      </Form.Item>
      <Form.Item label="Address Line 2" name={`${prefix}AddressLine2`} className="mt-1">
        <Input className="input" placeholder="Enter Address Line 2" />
      </Form.Item>
      <Form.Item
        label={renderLabel("City", true)}
        name={`${prefix}City`}
        rules={[{ required: true, message: "City is Required" }]}
      >
        <Input className="input" placeholder="Enter City" />
      </Form.Item>
      <Form.Item
        label={renderLabel("State", true)}
        name={`${prefix}State`}
        rules={[{ required: true, message: "State is Required" }]}
        className="mt-1"
      >
        <Input className="input" placeholder="Enter State" />
      </Form.Item>
      <Form.Item
        label={renderLabel("Postal Code", true)}
        name={`${prefix}PostalCode`}
        rules={[
          { required: true, message: "Postal Code is Required" },
          { 
            pattern: /^[0-9]{5}$/, // Regex pattern for exactly 5 numerical digits
            message: "Postal Code must be Exactly 5 Numerical Digits" 
          }
        ]}
      >
        <Input className="input" placeholder="Enter Postal Code"/>
      </Form.Item>
      <Form.Item label="Postal Code Extension" name={`${prefix}PostalCodeExtension`} className="mt-1">
        <Input className="input" placeholder="Enter Postal Code Extension" />
      </Form.Item>
      <Form.Item
        label={renderLabel("Country Code", true)}
        name={`${prefix}CountryCode`}
        rules={[{ required: true, message: "Country Code is Required" },
          { 
            pattern: /^[A-Z]{2}$/, 
            message: "Country Code must be Exactly 2 Uppercase Letters (e.g., US, GB, CA)" 
          }
        ]}
        
         
        
      >
        <Input className="input" placeholder="Enter Country Code" />
      </Form.Item>
    </>
  );

  const filterOption: SelectProps['filterOption'] = (input, option) => {
    const label = option?.label;
    
    return typeof label === 'string'
      ? label.toLowerCase().includes(input.toLowerCase())
      : false;
  };

  const modalHeight =
    typeof window !== "undefined" ? (window.innerHeight * 3) / 4 : 0;

  // return (
  //   <>
  //     <Modal
  //       title="Create Billing Platform Customer"
  //       visible={isOpen}
  //       onCancel={onClose}
  //       footer={null}
  //       centered
  //       width={800}
  //     >
  //       {loading ? (
  //         <div className="flex justify-center items-center" style={{height:modalHeight}}>
  //           <Spin size="large" />
  //         </div>
  //       ) : (
  //         <div style={{
  //           height: modalHeight,
  //           overflowY: "auto",
  //           overflowX: "hidden",
  //         }}>
  //           <Form
  //             form={form}
  //             layout="vertical"
  //             onFinish={onFinish}
  //             requiredMark={false}
  //             initialValues={{
  //               useServiceAddressAsBilling: true, // Set these checkboxes as checked by default
  //               useServiceAddressAsListing: true,
  //               status: "Prospect",
  //             }}
  //             onValuesChange={(changedValues, allValues) => {
  //               if (changedValues.useServiceAddressAsBilling !== undefined) {
  //                 setUseServiceAsBilling(changedValues.useServiceAddressAsBilling);
  //               }
  //               if (changedValues.useServiceAddressAsListing !== undefined) {
  //                 setUseServiceAsListing(changedValues.useServiceAddressAsListing);
  //               }
  //             }}
  //           >
  //             <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap:'16px' }}>
  //             <Form.Item
  //                 label={renderLabel("Status", true)}
  //                 name="status"
  //                 rules={[{ required: true, message: "Status is Required" }]}
  //               >
  //                 <Input placeholder="Enter Status" className="input" />
  //               </Form.Item>

  //               <Form.Item
  //                 label={renderLabel("Billing Platform Account",true)}
  //                 name="revIoAccount"
  //                 rules={[{ required: true, message: "Billing Platform Account is Required" }]}
  //                 style={{ marginBottom: '32px' }}
                 
  //               >
  //                 <Select
                 
  //                   placeholder="Select Billing Platform Account"
  //                   showSearch
  //                   filterOption={filterOption}
  //                   suffixIcon={
  //                     <ChevronDownIcon className="w-4 h-4 mt-3 text-gray-600" />
  //                   }
  //                   onChange={(value) => {
  //                     // console.log("Selected Rev.IO Account:", value);
  //                     form.setFieldsValue({ revIoAccount: value });
  //                   }}
  //                   className="mb-2"
                    
  //                 >
  //                   {revIoAccounts.map((account) => (
  //                     <Option key={account.value} value={account.value}>
  //                     {account.label}
  //                   </Option>
  //                   ))}
  //                 </Select>
  //               </Form.Item>

  //               <Form.Item
  //                 label="Bill Profile"
  //                 name="billProfile"
  //                 // className={`w-full ${DropdownStyles} mb-2`}
  //                 style={{ marginBottom: '32px' }}

  //               >
  //                 <Input
  //                   placeholder="Enter Bill Profile"
  //                   className="mb-2 input"
  //                   value={billProfiles} // Set the current value of the input
  //                   onChange={(e) => setBillProfiles(e.target.value)}
                    
  //                 />
                 
  //                 {/* <Select
  //                   placeholder="Select Bill Profile"
  //                   showSearch
  //                   filterOption={filterOption}
  //                   suffixIcon={
  //                     <ChevronDownIcon className="w-4 h-4 mt-3 text-gray-600" />
  //                   }
  //                   virtual={false}
  //                   className="mb-2"
  //                 >
  //                   {billProfiles.map((profile) => (
  //                     <Option key={profile.value} value={profile.value}>
  //                       {profile.label}
  //                     </Option>
  //                   ))}
  //                 </Select> */}
                
  //               </Form.Item>

  //               <Form.Item
  //                 label="Parent Customer"
  //                 name="parentCustomer"
  //                 style={{ marginBottom: '32px' }}
  //               >
  //                 <Select
  //                   placeholder="Select Parent Customer"
  //                   className="mb-2"
  //                   showSearch
  //                   suffixIcon={
  //                     <ChevronDownIcon className="w-4 h-4 mt-3 text-gray-600" />
  //                   }
  //                   virtual={false}
  //                 >
  //                   {parentCustomers.map((customer) => (
  //                     <Option key={customer.value} value={customer.value}>
  //                       {customer.label}
  //                     </Option>
  //                   ))}
  //                 </Select>
  //               </Form.Item>
  //             </div>

  //             <fieldset style={{ border: "1px solid #d9d9d9", padding: "20px", borderRadius: "4px", marginBottom: "20px" , marginTop:"15px" }}>
  //               <h2 style={{ fontSize: "16px", fontWeight: "bold" }}>Service Address</h2>
  //               <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
  //                 {renderAddressFields("service")}
  //               </div>
  //             </fieldset>

  //             <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
  //               <Form.Item name="useServiceAddressAsBilling" valuePropName="checked">
  //                 <Checkbox>
  //                   Use Service Address as Billing Address
  //                 </Checkbox>
  //               </Form.Item>

  //               <Form.Item name="useServiceAddressAsListing" valuePropName="checked">
  //                 <Checkbox>
  //                   Use Service Address as Listing Address
  //                 </Checkbox>
  //               </Form.Item>
  //             </div>

  //             {!useServiceAsBilling && (
  //               <fieldset style={{ border: "1px solid #d9d9d9", padding: "20px", borderRadius: "4px", marginBottom: "20px" }}>
  //                 <h2 style={{ fontSize: "16px", fontWeight: "bold" }}>Billing Address</h2>
  //                 <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
  //                   {renderAddressFields("billing")}
  //                 </div>
  //               </fieldset>
  //             )}

  //             {!useServiceAsListing && (
  //               <fieldset style={{ border: "1px solid #d9d9d9", padding: "20px", borderRadius: "4px", marginBottom: "20px" }}>
  //                 <h2 style={{ fontSize: "16px", fontWeight: "bold" }}>Listing Address</h2>
  //                 <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
  //                   {renderAddressFields("listing")}
  //                 </div>
  //               </fieldset>
  //             )}

  //             <div style={{ display: 'flex', justifyContent: 'center', gap: '10px' }} >
  //               <button onClick={onClose} className="cancel-btn">
  //                 Cancel
  //               </button>
  //               <button className="save-btn" onClick={handleSubmit} >
  //                 Submit
  //               </button>
  //             </div>
  //           </Form>
  //         </div>
  //       )}
  //     </Modal>

  //     <Modal
  //       title="Submit Data"
  //       visible={showConfirmation}
  //       onCancel={cancelConfirmation}
  //       centered
  //       footer={
  //         <div className="justify-center flex space-x-2">
  //           <Button key="cancel" className='cancel-btn' onClick={cancelConfirmation}>
  //             Cancel
  //           </Button>
  //           <Button key="confirm" className='save-btn' onClick={confirmSubmit}>
  //             OK
  //           </Button>
  //         </div>
  //       }
  //     >
  //       <p>Are you Sure you Want to Submit this Data?</p>
  //     </Modal>
  //   </>
  // );
  return (
    <>
      <Modal
        title="Create Billing Platform Customer"
        open={isOpen}
        onCancel={onClose}
        footer={null}
        centered
        width="90%"
        className="max-w-3xl sm:max-w-4xl md:max-w-[800px]" // Responsive modal width
      >
        {loading ? (
          <div className="flex justify-center items-center" style={{ height: modalHeight }}>
            <Spin size="large" />
          </div>
        ) : (
          <div
            style={{
              height: modalHeight,
              overflowY: 'auto',
              overflowX: 'hidden',
            }}
          >
            <Form
              form={form}
              layout="vertical"
              onFinish={onFinish}
              requiredMark={false}
              initialValues={{
                useServiceAddressAsBilling: true,
                useServiceAddressAsListing: true,
                status: 'Prospect',
              }}
              onValuesChange={(changedValues, allValues) => {
                if (changedValues.useServiceAddressAsBilling !== undefined) {
                  setUseServiceAsBilling(changedValues.useServiceAddressAsBilling);
                }
                if (changedValues.useServiceAddressAsListing !== undefined) {
                  setUseServiceAsListing(changedValues.useServiceAddressAsListing);
                }
              }}
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Form.Item
                  label={renderLabel('Status', true)}
                  name="status"
                  rules={[{ required: true, message: 'Status is Required' }]}
                >
                  <Input placeholder="Enter Status" className="input" />
                </Form.Item>

                <Form.Item
                  label={renderLabel('Billing Platform Account', true)}
                  name="revIoAccount"
                  rules={[{ required: true, message: 'Billing Platform Account is Required' }]}
                  className="mb-8"
                >
                  <Select
                    placeholder="Select Billing Platform Account"
                    showSearch
                    filterOption={filterOption}
                    suffixIcon={<ChevronDownIcon className="w-4 h-4 mt-3 text-gray-600" />}
                    onChange={(value) => {
                      form.setFieldsValue({ revIoAccount: value });
                    }}
                    className="mb-2"
                  >
                    {revIoAccounts.map((account) => (
                      <Option key={account.value} value={account.value}>
                        {account.label}
                      </Option>
                    ))}
                  </Select>
                </Form.Item>

                               <Form.Item
                  label="Bill Profile"
                  name="billProfile"
                  className="mb-8"
                >
                  <Select
                    placeholder="Select Bill Profile"
                    showSearch
                    filterOption={filterOption}
                    suffixIcon={<ChevronDownIcon className="w-4 h-4 mt-3 text-gray-600" />}
                    className="mb-2"
                  >
                    {billProfiles.map((profile) => (
                      <Option key={profile.value} value={profile.value}>
                        {profile.label}
                      </Option>
                    ))}
                  </Select>
                </Form.Item>

                <Form.Item
                  label="Parent Customer"
                  name="parentCustomer"
                  className="mb-8"
                >
                  <Select
                    placeholder="Select Parent Customer"
                    className="mb-2"
                    showSearch
                    suffixIcon={<ChevronDownIcon className="w-4 h-4 mt-3 text-gray-600" />}
                    virtual={false}
                  >
                    {parentCustomers.map((customer) => (
                      <Option key={customer.value} value={customer.value}>
                        {customer.label}
                      </Option>
                    ))}
                  </Select>
                </Form.Item>
              </div>

              <fieldset className="border border-gray-300 p-5 rounded-md mb-5 mt-4">
                <h2 className="text-base font-bold">Service Address</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {renderAddressFields('service')}
                </div>
              </fieldset>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Form.Item name="useServiceAddressAsBilling" valuePropName="checked">
                  <Checkbox>Use Service Address as Billing Address</Checkbox>
                </Form.Item>

                <Form.Item name="useServiceAddressAsListing" valuePropName="checked">
                  <Checkbox>Use Service Address as Listing Address</Checkbox>
                </Form.Item>
              </div>

              {!useServiceAsBilling && (
                <fieldset className="border border-gray-300 p-5 rounded-md mb-5">
                  <h2 className="text-base font-bold">Billing Address</h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {renderAddressFields('billing')}
                  </div>
                </fieldset>
              )}

              {!useServiceAsListing && (
                <fieldset className="border border-gray-300 p-5 rounded-md mb-5">
                  <h2 className="text-base font-bold">Listing Address</h2>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {renderAddressFields('listing')}
                  </div>
                </fieldset>
              )}

              <div className="flex justify-center gap-2">
                <button onClick={onClose} className="cancel-btn px-4 py-2">
                  Cancel
                </button>
                <button onClick={handleSubmit} className="save-btn px-4 py-2">
                  Submit
                </button>
              </div>
            </Form>
          </div>
        )}
      </Modal>

      <Modal
        title="Submit Data"
        open={showConfirmation}
        onCancel={cancelConfirmation}
        centered
        footer={
          <div className="flex justify-center space-x-2">
            <Button key="cancel" className="cancel-btn px-4 py-2" onClick={cancelConfirmation}>
              Cancel
            </Button>
            <Button key="confirm" className="save-btn px-4 py-2" onClick={confirmSubmit}>
              OK
            </Button>
          </div>
        }
        width="90%"
        className="max-w-sm sm:max-w-md"
      >
        <p>Are you sure you want to submit this data?</p>
      </Modal>
    </>
  );
};

export default CreateRevIoCustomer;
