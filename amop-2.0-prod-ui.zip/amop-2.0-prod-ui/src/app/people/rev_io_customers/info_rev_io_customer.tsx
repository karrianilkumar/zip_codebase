import React, { useEffect, useState } from "react";
import { Typography, Modal, Spin, Space } from "antd";
import { useRouter } from "next/navigation";
import axios from "axios";
import { useLogoStore } from "@/app/stores/logoStore";
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants"; // Assuming you have a utility for this
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { usePartnerStore } from "@/app/partner/partner_info/partnerStore";
const { Title } = Typography;

interface InfoRevIoModalProps {
  isOpen: boolean;
  onClose: () => void;
  rowData: any;
  generalFields: any;
}

const InfoRevIoPopup: React.FC<InfoRevIoModalProps> = ({
  isOpen,
  onClose,
  rowData,
  generalFields,
}) => {
  const router = useRouter();
  const { settabledata, username, role, token, partner, selectedDb,metaData,firstLastName,sessionId } = useAuth(); // Fetch necessary values from auth context
  const setTitle = useLogoStore((state) => state.setTitle);
  const [deviceCount, setDeviceCount] = useState("0"); // State to hold the device count
  const [loading, setLoading] = useState(false); // State to manage loading status
  const setPartnerUsers = usePartnerStore((state) => state.setPartnerUsers);
  const fetchTabData = async (tab: {
    module: string;
    setter: (data: any) => void;
    setLoaded: (loaded: boolean) => void;
  }) => {
    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName:firstLastName,
      path: "/get_partner_info",
      role_name: role,
      parent_module: "Partner",
      modules_list: ["Partner users"],
      feature_module_name: "Partner Info",
      pages: {
        "Customer groups": { start: 0, end: 100 },
        "Partner users": { start: 0, end: 100 },
      },
      access_token: token,
      db_name: selectedDb,
      ... metaData,
      sessionID: sessionId,
    };
  
    try {
      const response = await axios.post(
        ENV_ROUTES.MODULE_MANAGEMENT,
        { data }
      );
      if (response && response.status === 200) {
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag) {
          setPartnerUsers(parsedData);
          tab.setter(parsedData);
          tab.setLoaded(true);
        } else {
          tab.setter(parsedData.message);
          Modal.error({
            title: "Error",
            content: parsedData.message,
            centered: true,
          });
        }
      } else {
        Modal.error({
          title: "Error",
          content: "An error occurred during fetching data.",
          centered: true,
        });
      }
    } catch (error) {
      console.error("Error fetching", tab.module, ":", error);
      Modal.error({
        title: "Error",
        content: "An error occurred during fetching data.",
        centered: true,
      });
    }
  };

  const navigateToSimManagement = () => {
    setTitle("Inventory");
    settabledata([]);
    router.push("/sim_management/inventory");
  };

  const navigateToUsers =async () => {
    setTitle("Users");
    settabledata([]);
    await fetchTabData({
      module: "Partner users",
      setter: (data) => {
        // Handle the data here, for example:
        console.log(data);
        // or
        // setSomeState(data);
      },
      setLoaded: (loaded) => {
        // Handle the loaded state here, for example:
        console.log(loaded);
        // or
        // setSomeOtherState(loaded);
      },
    });
    router.push("/partner/partner_info/users/createUser");
  };

  // API call to fetch the device count
  const fetchDeviceCount = async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.PEOPLE_MODULE; // Replace with the actual backend endpoint
      const data = {
        tenant_name: partner || "Altaworx", // Replace with actual tenant name if dynamic
        username: username || "superadmin",
        path: "/submit_update_info_people_revcustomer",
        role_name: role || "Super Admin",
        parent_module: "People",
        module_name: "Rev.IO customer",
        action: "info",
        info_data: {
          id: rowData.id, // The ID you provided
        },
        request_received_at: getCurrentDateTime(),
        access_token: token || "access_token", // Provide a real token
        db_name: selectedDb || null, // Optional database name
        ... metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag) {
        setDeviceCount(parsedData.line_item_count || "0"); // Set the device count from response
      } else {
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "Failed to fetch device count. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false); // Ensure loading is set to false in the finally block
    }
  };

  // Trigger the API call when the component mounts
  useEffect(() => {
    if (isOpen) {
      fetchDeviceCount();
    }
  }, [isOpen]); // Fetches data when the modal is opened

  // return (
  //   <Modal
  //     visible={isOpen}
  //     onCancel={onClose}
  //     width={500}
  //     centered
  //     title={"Billing Platform customer info"}
  //     footer={null}
  //     styles={{ body: { height: 'auto', padding: '4px' } }}
  //   >
  //     {!loading ? (
  //         <>
  //         <div
  //           className="flex flex-row justify-center m-4"
  //         >
  //           {/* Top Left Section */}
  //           <div style={{ flex: 1, marginBottom:"10px"}}>
  //             <button
  //               className="save-btn w-[150px]"
  //               onClick={navigateToSimManagement}
               
  //             >
  //               SIM Management
  //             </button>
  //             </div>
  //             <div style={{ flex: 1}}>
  //             <button
  //               className="save-btn w-[150px]"
  //               onClick={navigateToUsers}
  //             >
  //               Add New Customer
  //             </button>
  //           </div>
  //         </div>
        
  //         <div
  //           className="flex flex-row justify-center m-4"
  //         >
  //           {/* Middle Left Section */}
  //           <div style={{ flex: 1 }}>
  //             <Title level={5}>Device Count</Title>
  //             <Space direction="vertical" >
  //               <input type="text" value={deviceCount} disabled   />
  //             </Space>
  //           </div>
        
  //           {/* Middle Right Section */}
  //           <div style={{ flex: 1 }}>
  //             <Title level={5}>Default Rate Plan</Title>
  //             <Space direction="vertical">
  //               <input type="text" value={rowData.customer_rate_plans} disabled />
  //             </Space>
  //           </div>
  //         </div>
        
  //       </>
  //     ) : (
  //       <div className="popup flex justify-center items-center w-full h-full">
  //         <Spin size="large" />
  //       </div>
  //     )}
  //   </Modal>
  // );
  return (
    <Modal
      visible={isOpen}
      onCancel={onClose}
      width="90%"
      className="max-w-[500px] sm:max-w-[500px]"
      centered
      title="Rev.IO Customer Info"
      footer={null}
      styles={{ body: { height: 'auto', padding: '16px' } }}
    >
      {!loading ? (
        <>
          <div className="flex flex-col sm:flex-row justify-center gap-4 m-4">
            {/* Top Section */}
            <div className="flex-1">
              <button
                className="save-btn w-full sm:w-[150px] py-2"
                onClick={navigateToSimManagement}
              >
                SIM Management
              </button>
            </div>
            <div className="flex-1">
              <button
                className="save-btn w-full sm:w-[150px] py-2"
                onClick={navigateToUsers}
              >
                Add New Customer
              </button>
            </div>
          </div>

          <div className="flex flex-col sm:flex-row justify-center gap-4 m-4">
            {/* Middle Section */}
            <div className="flex-1">
              <Title level={5}>Device Count</Title>
              <Space direction="vertical" className="w-full">
                <input
                  type="text"
                  value={deviceCount}
                  disabled
                  className="w-full p-2 border border-gray-300 rounded"
                />
              </Space>
            </div>

            <div className="flex-1">
              <Title level={5}>Default Rate Plan</Title>
              <Space direction="vertical" className="w-full">
                <input
                  type="text"
                  value={rowData.customer_rate_plans}
                  disabled
                  className="w-full p-2 border border-gray-300 rounded"
                />
              </Space>
            </div>
          </div>
        </>
      ) : (
        <div className="flex justify-center items-center w-full h-full">
          <Spin size="large" />
        </div>
      )}
    </Modal>
  );
};

export default InfoRevIoPopup;
