"use client";

import { PropsWithChildren } from "react";
import BreadcrumbWrapper from "@/components/breadcumb-wrapper";
import { usePathname } from "next/navigation";
import { FeatureFlagProvider } from "@/components/feature-flag/feature-flag-provider";
import {
  ModuleFeatures,
  ServiceQualificationFeatures,
} from "@/common/enums/module-feature-enum";

export default function ServiceQualificationRootLayout({
  children,
}: PropsWithChildren) {
  const pathname = usePathname();

  return (
    <div className="p-4 m-4 bg-white rounded adm-wrapper">
      <BreadcrumbWrapper path={pathname} />
      <div className="pt-4">
        <FeatureFlagProvider
          parentModule={ModuleFeatures.Qualification}
          module={ServiceQualificationFeatures.Qualification}
        >
          {children}
        </FeatureFlagProvider>
      </div>
    </div>
  );
}
