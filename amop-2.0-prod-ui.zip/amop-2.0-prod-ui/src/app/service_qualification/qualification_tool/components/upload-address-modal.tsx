import {
  downloadUploadTemplate,
  uploadQualification,
} from "@/api/qualification-api";
import { QUALIFICATION_QUERY_KEY } from "@/common/constants/qualification-constants";
import { DownloadOutlined, UploadOutlined } from "@ant-design/icons";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button, message, Modal, Typography, Upload, UploadProps } from "antd";
import { FC } from "react";
import { useQualifyNewAddressModalStore } from "./qualify-new-address-modal.store";
import "./upload-address-modal.css";

interface RcFile extends File {
  uid: string;
  lastModified: number;
  lastModifiedDate: Date;
  name: string;
  size: number;
  type: string;
  percent?: number;
}

const { Text } = Typography;

export const UploadAddressModal: FC<{
  visible: boolean;
  onClose: () => void;
}> = ({ visible, onClose }) => {
  const { closeModal: closeQualificationAddressModal } =
    useQualifyNewAddressModalStore();
  const queryClient = useQueryClient();

  const downloadTemplateMutation = useMutation({
    mutationFn: async () => {
      await downloadUploadTemplate();
    },
    onSuccess: () => {
      message.success("Template downloaded successfully.");
    },
    onError: (error: any) => {
      console.error("Failed download template", error);
      message.error("Failed to download template.");
    },
  });

  const handleDownloadTemplate = () => {
    downloadTemplateMutation.mutate();
  };

  const uploadMutation = useMutation<void, Error, { file: File }>({
    mutationFn: async ({ file }) => {
      try {
        await uploadQualification(file);
      } catch (error) {
        throw error;
      }
    },
    onSuccess: () => {
      onClose();
      closeQualificationAddressModal();
      queryClient.invalidateQueries({
        queryKey: [QUALIFICATION_QUERY_KEY.SERVICE_QUALIFICATION],
      });
    },
    onError: () => {},
  });

  const handleUpload: UploadProps["customRequest"] = async (options) => {
    const { onSuccess, onError, file } = options;
    const rcFile = file as RcFile;

    if (
      !(
        rcFile.type ===
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
        rcFile.type === "application/vnd.ms-excel"
      )
    ) {
      message.error("Only Excel files are allowed!");
      onError?.(new Error("Invalid file type"));
      return;
    }

    const maxSizeMB = 20;
    if (rcFile.size / 1024 / 1024 > maxSizeMB) {
      message.error("File must be smaller than 20MB!");
      onError?.(new Error("File too large"));
      return;
    }

    message.loading({
      content: "Your file is being uploaded...",
      key: "uploadStatus",
      duration: 0,
    });

    uploadMutation.mutate(
      { file: rcFile as File },
      {
        onSuccess: () => {
          onSuccess?.("OK");
          message.destroy("uploadStatus");
          message.success("Upload successful!");
        },
        onError: (error: any) => {
          onError?.(error);
          message.destroy("uploadStatus");
          if (error.response?.data?.message) {
            message.error(error.response.data.message);
          } else {
            message.error("Failed to upload file.");
          }
        },
      },
    );
  };

  return (
    <Modal
      title="Upload Address"
      open={visible}
      onCancel={onClose}
      footer={null}
      centered
      width={1000}
      className="upload-modal adm-wrapper"
      zIndex={1001}
    >
      <div className="modal-container">
        <div className="modal-header">
          <Text strong>Get Qualification Service Upload template:</Text>
          <Button
            type="default"
            icon={<DownloadOutlined />}
            onClick={handleDownloadTemplate}
            loading={downloadTemplateMutation.isPending}
          >
            Download Template
          </Button>
        </div>

        <Upload.Dragger
          name="file"
          customRequest={handleUpload}
          multiple={false}
          maxCount={1}
          accept=".xls,.xlsx"
          className="upload-dragger"
        >
          <div className="upload-area">
            <UploadOutlined className="upload-icon" />
            <p className="upload-text">
              Click or drag file to this area to upload. Use the Template
              Provided.
            </p>
            <p className="upload-hint">
              Only Excel Files are Allowed. Max size: 20MB.
            </p>
          </div>
        </Upload.Dragger>
      </div>
    </Modal>
  );
};
