import { Tooltip } from "antd";
import { RightCircleOutlined, StopOutlined } from "@ant-design/icons";
import { AMOP_CORE_URL,AMOP_BASE_URL } from "@/api/axios";
import Link from "next/link";

interface ActivationStatusCellProps {
  isQualified: boolean;
  qualificationId: number;
}

const ActivationStatusCell: React.FC<ActivationStatusCellProps> = ({
  isQualified,
  qualificationId,
}) => (
  <Tooltip
    title={
      isQualified ? "Proceed to Activation" : "Cannot Activate: Not Qualified"
    }
  >
    <div className="flex justify-center items-center">
      {isQualified ? (
        <Link
          // target="_blank"
          href={{
            pathname: `${AMOP_BASE_URL}/sim_management/bulk_change`,
            query: { qualificationId: qualificationId },
          }}
        >
          <RightCircleOutlined className="text-green-600 text-xl hover:text-green-800 cursor-pointer" />
        </Link>
      ) : (
        <StopOutlined className="text-gray-600 text-xl hover:text-gray-800 cursor-not-allowed" />
      )}
    </div>
  </Tooltip>
);

export const activationStatusCellRenderer = (
  isQualified: boolean,
  qualificationId: number,
) => (
  <ActivationStatusCell
    isQualified={isQualified}
    qualificationId={qualificationId}
  />
);
