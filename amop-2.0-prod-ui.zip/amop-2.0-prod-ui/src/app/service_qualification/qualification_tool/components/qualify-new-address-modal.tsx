import { createServiceQualification } from "@/api/qualification-api";
import { QUALIFICATION_QUERY_KEY } from "@/common/constants/qualification-constants";
import { UploadOutlined } from "@ant-design/icons";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button, Form, Input, Modal, notification, Select } from "antd";
import { RuleObject } from "antd/es/form";
import { FC } from "react";
import { useQualifyNewAddressModalStore } from "./qualify-new-address-modal.store";
import { UploadAddressModal } from "./upload-address-modal";

const validateStateCode = (_: RuleObject, value: string) => {
  if (!value || value.length !== 2) {
    return Promise.reject("State code must be 2 letters.");
  }
  return Promise.resolve();
};

const validateZipCode = (_: RuleObject, value: string) => {
  const zipCodePattern = /^\d{5}$/;
  if (!value || !zipCodePattern.test(value)) {
    return Promise.reject("Zip code must be a 5-digit number.");
  }
  return Promise.resolve();
};

const QualifyNewAddressForm: FC = () => {
  const queryClient = useQueryClient();
  const [form] = Form.useForm<QualifyFormValues>();
  const { isSubmitting, setIsSubmitting, closeModal, isFetching } =
    useQualifyNewAddressModalStore();

  const { mutateAsync: handleSubmit } = useMutation({
    mutationFn: async (formValues: QualifyFormValues) => {
      setIsSubmitting(true);
      await createServiceQualification(formValues);
    },
    onSuccess: async () => {
      setIsSubmitting(false);
      notification.success({
        message: "Submit Success",
        description: "Your address has been submitted successfully",
      });
      closeModal();
      await queryClient.invalidateQueries({
        queryKey: [QUALIFICATION_QUERY_KEY.SERVICE_QUALIFICATION],
      });
    },
    onError: (error) => {
      setIsSubmitting(false);
      notification.error({
        message: "Failed to qualify address",
        description: `Error: ${error}`,
      });
    },
  });

  return (
    <Form<QualifyFormValues>
      form={form}
      id="qualify-new-address"
      layout={"vertical"}
      initialValues={{
        siteId: "",
        serviceType: Object.keys(QualifyService)[0],
        addressLine: "",
        city: "",
        state: "",
        country: "US",
        postalCode: "",
      }}
      onFinish={handleSubmit}
    >
      <Form.Item label="Site ID" name="siteId">
        <Input placeholder="Location identifier. Example: AMOP Office, ..." />
      </Form.Item>
      <Form.Item label="Service" name="serviceType" required>
        <Select>
          {Object.entries(QualifyService).map(([value, label]) => (
            <Select.Option key={value} value={value}>
              {label}
            </Select.Option>
          ))}
        </Select>
      </Form.Item>
      <Form.Item
        label="Street Address"
        name="addressLine"
        required
        extra={"Please enter the street address in the format: 123 StreetName"}
      >
        <Input placeholder="Example: 445 StreetName" />
      </Form.Item>
      <Form.Item label="City" name="city" required>
        <Input placeholder="Example: Fairhope" />
      </Form.Item>
      <Form.Item
        label="State"
        name="state"
        required
        extra="State code must be 2 letters. Example: CA, NY, TX"
        rules={[
          { required: true, message: "Please enter the state code." },
          { validator: validateStateCode },
        ]}
      >
        <Input placeholder="Example: CA" />
      </Form.Item>
      <Form.Item label="Country" name="country" required>
        <Input />
      </Form.Item>
      <Form.Item
        label="Zip Code"
        name="postalCode"
        required
        rules={[
          { required: true, message: "Please enter your zip code." },
          { validator: validateZipCode },
        ]}
      >
        <Input placeholder="Example: 36000" />
      </Form.Item>
      <Form.Item>
        <Button
          type="primary"
          htmlType="submit"
          className="float-right"
          loading={isSubmitting}
        >
          Submit
        </Button>

        <Button onClick={closeModal} className="float-right mr-2">
          Cancel
        </Button>
      </Form.Item>
    </Form>
  );
};

export const QualifyNewAddressModal: FC = () => {
  const {
    open,
    isSubmitting,
    closeModal,
    uploadModalVisible,
    setUploadModalVisible,
  } = useQualifyNewAddressModalStore();

  const handleSwitchToUpload = () => {
    setUploadModalVisible(true);
  };

  const handleCloseUploadModal = () => {
    setUploadModalVisible(false);
  };

  return (
    <>
      <Modal
        className="adm-wrapper"
        title={
          <div className="flex justify-between items-center">
            <span>Address Qualification</span>
            <Button
              type="link"
              icon={<UploadOutlined />}
              onClick={handleSwitchToUpload}
              className="text-blue-500 mr-1"
            >
              Switch to upload
            </Button>
          </div>
        }
        open={open}
        destroyOnClose
        maskClosable={false}
        onCancel={closeModal}
        footer={null}
        confirmLoading={isSubmitting}
        keyboard={false}
        zIndex={1000}
      >
        <QualifyNewAddressForm />
      </Modal>

      <UploadAddressModal
        visible={uploadModalVisible}
        onClose={handleCloseUploadModal}
      />
    </>
  );
};

export type QualifyFormValues = {
  siteId: string;
  serviceType: keyof typeof QualifyService;
  addressLine: string;
  city: string;
  state: string;
  country: string;
  postalCode: string;
};

enum QualifyService {
  AIAB = "APEx Fixed Wireless (AIAB)",
}
