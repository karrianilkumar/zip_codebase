"use client";

import { QUALIFICATION_ROUTES } from "@/common/constants/route-constant";
import { ServiceQualification } from "@/types/qualification-types";
import { InfoCircleOutlined } from "@ant-design/icons";
import { Tooltip } from "antd";
import { useRouter } from "next/navigation";
import React from "react";

const QualificationDetailCell: React.FC<{
  qualification: ServiceQualification;
}> = ({ qualification }) => {
  const router = useRouter();

  return (
    <Tooltip title="View Qualification Details">
      <div
        className="flex justify-center items-center"
        onClick={() =>
          router.push(
            `${QUALIFICATION_ROUTES.SERVICE_QUALIFICATION_DETAILS}/${qualification.id}`,
          )
        }
      >
        <InfoCircleOutlined className="text-blue-600 text-xl hover:text-blue-800 cursor-pointer" />
      </div>
    </Tooltip>
  );
};

export const qualificationDetailCellRenderer = (
  value: ServiceQualification,
) => <QualificationDetailCell qualification={value} />;
