import dynamic from "next/dynamic";

const ServiceQualificationHistory = dynamic(
  () => import("./components/service-qualification-history"),
  { ssr: false },
);

export default function ServiceQualificationHistoryPage() {
  return <ServiceQualificationHistory />;
}
