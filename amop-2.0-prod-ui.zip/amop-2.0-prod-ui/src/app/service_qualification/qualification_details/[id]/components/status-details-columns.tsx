import { dateTimeCellRenderer } from "@/components/data-grid-cell-renderers/date-time-cell-renderer";
import { ServiceQualificationLog } from "@/types/qualification-types";
import { TableColumnType } from "antd";

export const statusDetailsColumns: TableColumnType<ServiceQualificationLog>[] =
  [
    {
      title: "Timestamp",
      dataIndex: "CreatedDate",
      key: "createdDate",
      render: dateTimeCellRenderer,
      width: 150,
    },
    {
      title: "Description",
      dataIndex: "Message",
      key: "message",
      width: 170,
    },
    {
      title: "Request",
      dataIndex: "Request",
      key: "request",
      render: (request: string) => {
        try {
          return JSON.stringify(JSON.parse(request), null, 2);
        } catch (error) {
          return request;
        }
      },
    },
    {
      title: "Response",
      dataIndex: "Response",
      key: "response",
      render: (response: string) => {
        try {
          if (!response) {
            return "OK";
          }
          return JSON.stringify(JSON.parse(response), null, 2);
        } catch (error) {
          return response;
        }
      },
    },
  ];
