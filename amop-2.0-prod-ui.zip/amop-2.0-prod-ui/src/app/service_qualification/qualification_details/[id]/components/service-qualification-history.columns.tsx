import { dateTimeCellRenderer } from "@/components/data-grid-cell-renderers/date-time-cell-renderer";
import { ServiceQualificationAddress } from "@/types/qualification-types";
import { TableColumnType } from "antd";

export const serviceQualificationDetailColumns: TableColumnType<ServiceQualificationAddress>[] =
  [
    {
      title: "Service Type",
      key: "serviceType",
      render: () => "AIAB",
    },
    {
      title: "Site Name",
      dataIndex: "SiteId",
      key: "siteId",
    },
    {
      title: "Site Address",
      key: "siteAddress",
      render: (text, record) =>
        `${record.StreetNumber} ${record.StreetName}, ${record.City}, ${record.State}, ${record.ZipCode}, ${record.Country}`,
      width: 300,
    },
    {
      title: "Status",
      key: "status",
      render: (text, record) => {
        return record.IsQualified ? (
          <span className="text-green-500 hover:text-green-700 cursor-pointer">
            Qualified
          </span>
        ) : (
          <span className="text-red-500 hover:text-red-700 cursor-pointer">
            Not Qualified
          </span>
        );
      },
    },
    {
      title: "Qualification Token",
      dataIndex: "QualificationToken",
      key: "qualificationToken",
    },
    {
      title: "Processed Date",
      dataIndex: "CreatedDate",
      key: "processedDate",
      render: dateTimeCellRenderer,
    },
    {
      title: "Processed By",
      dataIndex: "CreatedBy",
      key: "processedBy",
    },
  ];
