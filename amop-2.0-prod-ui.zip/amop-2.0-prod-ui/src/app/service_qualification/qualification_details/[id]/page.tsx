"use client";

import {
  getAddressesQualificationById,
  getServiceQualificationById,
} from "@/api/qualification-api";
import { QUALIFICATION_QUERY_KEY } from "@/common/constants/qualification-constants";
import {
  DEFAULT_TIMEZONE,
  FULL_TIME_FORMAT,
  TableName,
} from "@/common/constants/table-constants";
import { AmopDataGrid, useAmopDataGridStates } from "@/components/data-grid";
import useQualificationStore from "@/stores/qualification-store";
import { ServiceQualificationAddress } from "@/types/qualification-types";
import { useQuery } from "@tanstack/react-query";
import { Col, Row, Spin } from "antd";
import { format } from "date-fns";
import { toZonedTime } from "date-fns-tz";
import { useParams } from "next/navigation";
import { serviceQualificationDetailColumns } from "./components/service-qualification-history.columns";
import StatusDetailsPopup from "./components/status-details-popup";

const DETAIL_COLUMNS = {
  STATUS: "Status",
  PROCESSED_DATE: "Processed Date",
  UPLOADED: "Uploaded",
  PROCESSED: "Processed",
  ERRORS: "Errors",
};

type QualificationDetailParams = {
  id: string;
};

const ServiceQualificationDetail = () => {
  const params = useParams<QualificationDetailParams>();
  const { setIsOpenStatusPopup, setSelectedAddressQualification } =
    useQualificationStore();

  const [tableStates, { onChange }] = useAmopDataGridStates<any>({
    page: 1,
    pageSize: 10,
    filters: {},
    sorter: [],
  });

  const { data, isLoading } = useQuery({
    queryKey: [
      QUALIFICATION_QUERY_KEY.SERVICE_QUALIFICATION_DETAILS,
      params.id,
    ],
    queryFn: async ({ queryKey: [, id] }) => {
      return await getServiceQualificationById(id as string);
    },
  });

  const { data: addresses, isFetching: isFetchingAddresses } = useQuery({
    queryKey: [
      QUALIFICATION_QUERY_KEY.ADDRESS,
      params.id,
      tableStates,
    ] as const,
    queryFn: async ({ queryKey }) => {
      const [, id, query] = queryKey;
      return await getAddressesQualificationById(
        id as string,
        query.page,
        query.pageSize,
      );
    },
  });

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  const renderColumns = () => (
    <>
      {Object.values(DETAIL_COLUMNS).map((label) => (
        <div key={label} className="mb-2 font-bold">
          {label}
        </div>
      ))}
    </>
  );

  const renderValues = () => (
    <>
      <div className="mb-2">{data?.Status}</div>
      <div className="mb-2">
        {data?.CreatedDate
          ? format(
              toZonedTime(data?.CreatedDate, DEFAULT_TIMEZONE),
              FULL_TIME_FORMAT,
            )
          : "N/A"}
      </div>
      <div className="mb-2">{data?.Uploaded}</div>
      <div className="mb-2">{data?.Successful}</div>
      <div className="mb-2">{data?.Errors}</div>
    </>
  );

  const renderServiceQualificationDetailColumns =
    serviceQualificationDetailColumns.map((column) => {
      let modifiedColumn = { ...column };

      switch (column.key) {
        case "status":
          modifiedColumn = {
            ...modifiedColumn,
            onCell: (record: ServiceQualificationAddress) => {
              return {
                onClick: () => {
                  setIsOpenStatusPopup(true);
                  console.log("record", record);
                  setSelectedAddressQualification(record);
                },
              };
            },
          };
          break;
        default:
          break;
      }
      return modifiedColumn;
    });

  return (
    data && (
      <>
        <Row gutter={[16, 16]} className="p-4">
          <Col xs={12} className="p-2 rounded lg:hidden">
            {renderColumns()}
          </Col>
          <Col xs={12} className="p-2 rounded lg:hidden">
            {renderValues()}
          </Col>

          <Col xs={24} sm={12} md={6} className="p-2 rounded hidden lg:block">
            {renderColumns()}
          </Col>
          <Col xs={24} sm={12} md={6} className="p-2 rounded hidden lg:block">
            {renderValues()}
          </Col>
          <Col xs={24} sm={12} md={6}></Col>
          <Col xs={24} sm={12} md={6}></Col>
        </Row>
        <AmopDataGrid
          data={addresses?.results || []}
          total={addresses?.totalResults || 0}
          pageSize={tableStates.pageSize}
          onChange={onChange}
          currentPage={tableStates.page}
          loading={isFetchingAddresses}
          columns={renderServiceQualificationDetailColumns}
          tableName={TableName.QUALIFICATION_DETAILS}
          showSearchBox={false}
          rowSelection={undefined}
          sticky={{
            offsetHeader: 64,
          }}
          scroll={{ x: 1200 }}
        />
        <StatusDetailsPopup />
      </>
    )
  );
};

export default ServiceQualificationDetail;
