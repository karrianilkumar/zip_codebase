import { QUALIFICATION_ROUTES } from "@/common/constants/route-constant";
import { redirect } from "next/navigation";

export default function Home() {
  return redirect(QUALIFICATION_ROUTES.SERVICE_QUALIFICATION_HISTORY);
}
