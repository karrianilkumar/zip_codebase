'use client'
import React, { useState } from "react";
import { Button, Modal, message } from "antd";
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useRouter } from 'next/navigation';
import { useLogoStore } from "@/app/stores/logoStore";

interface ImpersonateUserProps {
  isOpen: boolean;
  onClose: () => void;
  rowData: any;
}

const ImpersonateUserModal: React.FC<ImpersonateUserProps> = ({
  isOpen,
  onClose,
  rowData,
}) => {
  const [loading, setLoading] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const { username, partner, role, token, selectedDb, metaData,setRole, setEmail, setUsername, setSessionId, LogoutChooseTenant, setFirstLastName, firstLastName,sessionId,setTenantNames,setModulesVersionMap} = useAuth();
  const router = useRouter();
  const setSwiched20User = useLogoStore((state) => state.setSwiched20User);
  const handleImpersonate = () => {
    setShowConfirm(true);
  };
  const handleChoosePartner = () => {
    LogoutChooseTenant();
  };

  const handleConfirmYes = async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.USER_AUTHENTICATION;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/impersonate_login_using_database",
        role_name: role,
        impersonate_data: {
          id: rowData.id,
          first_name: rowData.first_name,
          last_name: rowData.last_name,
          email: rowData.email,
          role: rowData.role,
          phone: rowData.phone,
          address: rowData.address,
          city: rowData.city,
          state: rowData.state,
          zip: rowData.zip,
        },
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
          ...metaData,
        sessionID: sessionId,
      };
      console.log(getCurrentDateTime(),"Show the log time request sent from ui to lambda");
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      console.log(getCurrentDateTime(),"Show the log time response sent from lambda to ui");
      if (parsedData.flag === false) {
        Modal.error({
          title: "Impersonation Error",
          content: parsedData.message || "Error impersonating user. Please try again.",
          centered: true,
        });
      } else {
        // if (parsedData.user_impersonate === true) {
        //   // Redirect user if impersonation is successful
        //   const redirectUrl = `https://sandbox.amop.services/User/Impersonate/0?username=${parsedData.user_name}&returnUrl=https://qa.amop.services/auth/callback`;
        //   router.push(redirectUrl);
        // } else {
          // Update auth context with impersonated user's details
          setRole(parsedData?.role || "");
          setEmail(parsedData?.email || "");
          setUsername(parsedData?.user_name || "");
          setFirstLastName(parsedData?.first_last_name || "");
          setSessionId(parsedData?.session_id || "");
          const tenant_names = parsedData?.["tenant_names"];
          setTenantNames(tenant_names);
          setSwiched20User(parsedData?.switch_user_2_0 || "False")
          localStorage.setItem('switch_user_2_0',parsedData?.switch_user_2_0 || "False");
          localStorage.setItem('username', parsedData?.user_name || "");
          localStorage.setItem('first_last_name',parsedData?.first_last_name || "");
          localStorage.setItem('role_name', parsedData?.role || "");
          localStorage.setItem('tenant_names', JSON.stringify(tenant_names || []));
          localStorage.setItem('switch_user_20_modules_json',(parsedData?.switch_user_20_modules_json || '{}'));
          localStorage.setItem('session_id',parsedData?.session_id || "")
          setModulesVersionMap(parsedData?.switch_user_20_modules_json || {});
          message.success("User impersonated successfully!");
          onClose();
          handleChoosePartner();
        // }
      }
    } catch (error) {
      Modal.error({
        title: "Impersonation Error",
        content: "Error impersonating user. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleConfirmNo = () => {
    setShowConfirm(false);
  };


  return (
    <Modal
      title={<div style={{ fontSize: 24, fontWeight: 600 }}>Impersonate User</div>}
      visible={isOpen}
      onCancel={onClose}
      footer={[
        <div key="footer" style={{ display: 'flex', justifyContent: 'center' }}>
          <Button key="back" className="cancel-btn" onClick={onClose} style={{ marginRight: 8 }}>
            Cancel
          </Button>
          <Button key="impersonate" className="save-btn" onClick={handleImpersonate}>
            Impersonate
          </Button>
        </div>
      ]}
    >
      {/* ... (rest of the modal content remains the same) */}
      <div className="flex flex-col">
          <div className="flex justify-between mb-4">
          <span className="text-lg font-bold">{rowData.first_name !== "None" ? rowData.first_name : ""} {rowData.last_name !== "None" ? rowData.last_name : ""}</span>
          </div>
          <div className="flex flex-col">
            <div className="flex mb-2">
              <span className="text-sm font-bold" style={{ width: 120, flexShrink: 0 }}>First Name:</span>
              <span className="text-sm"  >{rowData.first_name}</span>
            </div>
            <div className="flex  mb-2">
              <span className="text-sm font-bold" style={{ width: 120, flexShrink: 0 }}>Last Name:</span>
              <span className="text-sm"  >{rowData.last_name}</span>
            </div>
            <div className="flex mb-2">
              <span className="text-sm font-bold" style={{ width: 120, flexShrink: 0 }}>Email:</span>
              <span className="text-sm" >{rowData.email}</span>
            </div>
            <div className="flex mb-2">
              <span className="text-sm font-bold" style={{ width: 120, flexShrink: 0 }}>Role:</span>
              <span className="text-sm"  >{rowData.role}</span>
            </div>
            <div className="flex  mb-2">
              <span className="text-sm font-bold" style={{ width: 120, flexShrink: 0 }}>Phone:</span>
              <span className="text-sm" >{rowData.phone}</span>
            </div>
            <div className="flex mb-2">
              <span className="text-sm font-bold" style={{ width: 120, flexShrink: 0 }}>Address:</span>
              <span className="text-sm">{rowData.address}</span>
            </div>
            <div className="flex mb-2">
              <span className="text-sm font-bold" style={{ width: 120, flexShrink: 0 }}>City:</span>
              <span className="text-sm">{rowData.city}</span>
            </div>
            <div className="flex mb-2">
              <span className="text-sm font-bold" style={{ width: 120, flexShrink: 0 }}>State:</span>
              <span className="text-sm" >{rowData.state}</span>
            </div>
            <div className="flex mb-2">
              <span className="text-sm font-bold" style={{ width: 120, flexShrink: 0 }}>Postal Code:</span>
              <span className="text-sm" >{rowData.zip}</span>
            </div>
          </div>
        </div>
      {showConfirm && (
        <Modal
          title="Confirm Impersonation"
          visible={showConfirm}
          onCancel={handleConfirmNo}
          centered
          footer={[
            <div key="confirm-footer" style={{ display: 'flex', justifyContent: 'center' }}>
              <Button className="cancel-btn" onClick={handleConfirmNo} style={{ marginRight: 8 }}>
                No
              </Button>
              <Button className="save-btn" onClick={handleConfirmYes} loading={loading}>
                Yes
              </Button>
            </div>
          ]}
        >
          <p>Are you Sure you Want to Impersonate this User</p>
        </Modal>
      )}
    </Modal>
  );
};

export default ImpersonateUserModal;