"use client";

import React, { useState, useEffect, useCallback, lazy } from 'react';
import * as XLSX from 'xlsx';
import { PlusIcon, ArrowDownTrayIcon, ArrowUpTrayIcon } from '@heroicons/react/24/outline';
import ChartsPage from '../charts/page';
// import TableComponent from '@/app/components/TableComponent/page';
import ColumnFilter from '@/app/components/columnfilter';
import SearchInput from '@/app/components/Search-Input';
import { useRouter } from 'next/navigation';
import dynamic from 'next/dynamic';
import CreateUser from '../createUser/page';
import { usePartnerStore } from '../../partnerStore';
import { useUserStore } from '../createUser/createUserStore';
import dayjs, { Dayjs } from "dayjs";
import { getCurrentDateTime } from '@/app/components/header_constants';
import { useAuth } from '@/app/components/auth_context';
import axios from 'axios';
import { Button, message, DatePicker, Modal, notification, Upload, Spin } from 'antd';
import TableSearch from '@/app/components/entire_table_search';
import AdvancedMultiFilter from '@/app/components/advanced_search';
import { DownloadOutlined, UploadOutlined } from '@ant-design/icons';
import { useFeatureStore } from '@/app/sim_management/inventory/featureStore';
import { ENV_ROUTES } from '@/app/components/routes/route_constants';
import { exportLoadingStore } from '@/app/stores/ExportLoadingStore';
import { useCustomerRatePlanStore } from '@/app/stores/customerRateplanStore';
const { RangePicker } = DatePicker;

const TableComponent = lazy(() => import("@/app/components/TableComponent/page"));
interface ExcelData {
  [key: string]: any;
}
interface ExcelDataRow {
  [key: string]: any;
}
type HeaderMap = Record<string, [string, number]>;

const ListView: React.FC = () => {
  const [data, setData] = useState<ExcelDataRow[]>([]); // Initialize data with users_table
  const [isImportModalOpen, setImportModalOpen] = useState(false); // Import Modal State
  const [searchTerm, setSearchTerm] = useState('');
  const [showCreateUser, setShowCreateUser] = useState(false);
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const [headers, setHeaders] = useState<string[]>([]);
  const [headerMap, setHeadersMap] = useState<HeaderMap>({});
  const [createModalData, setCreateModalData] = useState<any[]>([]);
  const [templateColumns1, setTemplateColumns1] = useState<string[]>([]);
  const [templateColumns2, setTemplateColumns2] = useState<string[]>([]);
  const [templateColumns3, setTemplateColumns3] = useState<string[]>([]);

  const [templateData, setTemplateData] = useState<ExcelData[]>([]);

  const [generalFields, setGeneralFields] = useState<any>({});
  const { partnerData, setPartnerUsers } = usePartnerStore.getState();
  const usersData = partnerData["Partner users"] || {};
  const [isExportModalOpen, setExportModalOpen] = useState(false);

  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([null, null]);
  const { username, partner, role, settabledata, token, selectedDb,metaData, advancedStoredpagination, storedpagination, tenantId, tenantName, firstLastName,sessionId, combineAdnvaceStoredpagination, setCombineAdnvaceStoredpagination,dynamicColumns,setDynamicColumns} = useAuth();
  const [pagination, setPagination] = useState<any>({});
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  // const {showAdvanced, setShowAdvanced} = useCustomerRatePlanStore();
  const [isUploadModalVisible, setIsUploadModalVisible] = useState(false);
  const [appendChecked, setAppendChecked] = useState(false);
  const [overwriteChecked, setOverwriteChecked] = useState(false);
  const [isFileSelected, setIsFileSelected] = useState(false);
  const [uploadKey, setUploadKey] = useState(Date.now());
  const [loading, setLoading] = useState(true);
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
  //export functionality
  // const [exportLoading, setExportLoading] = useState(false);
  const { addExport, removeExport,exports } = exportLoadingStore();
  const exportKey = "Partner Users";
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});

  const handleFilter = (advancedFilters: any) => {
    console.log(advancedFilters)
    setAdvancedFilters(advancedFilters)
  };
  const sortPopup = (fields: any[]): any[] => {
    return fields.sort((a: any, b: any) => a?.id - b?.id);
  };
  const handleReset = (EmptyFilters: any) => {
    console.log(EmptyFilters)
    setFilteredData(EmptyFilters);
  };

  const sortHeaderMap = (headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  };
  useEffect(() => {
        setDynamicColumns((prev:any)=>({...prev,"Partner users":visibleColumns}))
      }, [visibleColumns]);
  useEffect(() => {
    const initializeData = () => {
      const features = usersData?.headers_map?.["Partner users"]?.['module_features'] || []
      setFeatures(features)
      const allowedActions_: any = []
      if (features.includes("Edit-Partner users")) {
        allowedActions_.push("tabsEdit")
      }
      if (features.includes("Impersonate-Partner users")) {
        allowedActions_.push("impersonateUser")
      }
      if (features.includes("Info-Partner users")) {
        allowedActions_.push("tabsInfo")
      }
      if(features.includes("Delete-Partner info")){
        allowedActions_.push("delete")
      }
      setAllowedActions(allowedActions_)
      const data = usersData?.data?.["Partner users"]?.users || [];
      setData(data);
      settabledata(data)
      const header_Map = sortHeaderMap(usersData?.headers_map?.["Partner users"]?.header_map || {});
      const createModalData_ = usersData?.headers_map?.["Partner users"]?.pop_up || [];
      const generalFields_ = usersData?.data?.["Partner users"] || {}
      const pagination_ = usersData?.data?.pages?.["Partner users"] || {}
       const sortedheaderMap = sortHeaderMap(header_Map)
      setPagination(pagination_)
      setHeadersMap(header_Map);
      const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : []
      setHeaders(headers_)
      const dynamic_cols=dynamicColumns?.["Partner users"] && dynamicColumns["Partner users"].length>0 ?dynamicColumns["Partner users"] :headers_ || headers_
      setVisibleColumns(dynamic_cols)
      setGeneralFields(generalFields_);
      setCreateModalData(sortPopup(createModalData_))
          if (role?.toLowerCase() === "super admin") {
            allowedActions_.push("resetPassword");
          }
          setAllowedActions(allowedActions_)
    };
    const fetchTemplateData = async () => {
      try {
        const response = await fetch('/create_user_template.xlsx');
        const arrayBuffer = await response.arrayBuffer();
        const data = new Uint8Array(arrayBuffer);
        const workbook = XLSX.read(data, { type: 'array' });

        // Assuming you have 3 worksheets to fetch
        const sheetNames = workbook.SheetNames;

        if (sheetNames.length < 3) {
          throw new Error('The Excel file must contain at least 3 sheets.');
        }

        // Helper function to extract column names from a sheet
        const extractColumns = (sheetName: string) => {
          const worksheet = workbook.Sheets[sheetName];
          const jsonData: any[] = XLSX.utils.sheet_to_json(worksheet, {
            header: 1,
            blankrows: false,
          });

          if (jsonData.length === 0) {
            throw new Error(`No data found in the Excel sheet: ${sheetName}`);
          }

          return jsonData[0]; // First row contains column names
        };

        // Fetch columns from each worksheet and set them in state
        const columns1 = extractColumns(sheetNames[0]);
        const columns2 = extractColumns(sheetNames[1]);
        const columns3 = extractColumns(sheetNames[2]);

        setTemplateColumns1(columns1);
        setTemplateColumns2(columns2);
        setTemplateColumns3(columns3);

      } catch (error) {
        console.error('Error fetching data from Excel:', error);
      }

    };
    fetchTemplateData()
    initializeData();
  }, [usersData]);


  const handleCreateClick = () => {
    setShowCreateUser(true);
  };
  const {
    setTenant,
    setRoleName,
    setSubTenant
  } = useUserStore();
  useEffect(() => {
    setTenant('')
    setSubTenant([])
    setRoleName('')
  }, []);
  const handleExportModalOpen = () => {
    setExportModalOpen(true);
  };

  const handleExportModalClose = () => {
    setExportModalOpen(false);
    setDateRange([null, null]); // Reset date range
  };
  const handleDownloadTemplate = async () => {
    setLoading(true);
    const url = ENV_ROUTES.SIM_MANAGEMENT
    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/download_bulk_upload_template",
      table_name: "users",
      module_name: "Users",
      role_name: role,
      Partner: partner,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
        ... metaData,
      sessionID: sessionId,
    };

    const response = await axios.post(url, { data });
    const resp = JSON.parse(response.data.body);
    const blob = resp.blob;
    console.log(resp);
    if (response.data.statusCode === 200) {
      if (resp.flag === true) {
        notification.success({
          message: 'Success',
          description: 'Successfully downloaded the template!',
          style: messageStyle,
          placement: 'top',
        });
        downloadBlob(blob);
        setLoading(false);
      } else {
        console.log('Error message:', resp.message);
        Modal.error({
          title: 'Export Error',
          content: resp.message,
          centered: true,
        });
      }
    } else {
      console.log('Unexpected status code:', response.data.statusCode);
      Modal.error({
        title: 'Export Error',
        content: resp.message,
        centered: true,
      });
    }
  };
  // const handleDownloadTemplate = () => {

  //   const exportData1 = [templateColumns1, ...templateData.map(row => templateColumns1.map(header => row[header]))];
  //   const worksheet1 = XLSX.utils.aoa_to_sheet(exportData1);
  //   const exportData2 = [templateColumns2, ...templateData.map(row => templateColumns2.map(header => row[header]))];
  //   const worksheet2 = XLSX.utils.aoa_to_sheet(exportData2);
  //   const exportData3 = [templateColumns3, ...templateData.map(row => templateColumns3.map(header => row[header]))];
  //   const worksheet3 = XLSX.utils.aoa_to_sheet(exportData3);
  //   const workbook = XLSX.utils.book_new();
  //   XLSX.utils.book_append_sheet(workbook, worksheet1, "User Info");
  //   XLSX.utils.book_append_sheet(workbook, worksheet2, "Edit User Role");
  //   XLSX.utils.book_append_sheet(workbook, worksheet3, "Customer Info");

  //   XLSX.writeFile(workbook, "Create Users.xlsx");
  //   setImportModalOpen(false);
  // };
  const handleImportModalOpen = () => {
    setImportModalOpen(true);
  };
  const handleImportModalClose = () => {
    setImportModalOpen(false);
  };
  const handleUploadClick = () => {
    setIsUploadModalVisible(true);

  }
  const handleUploadModalClose = () => {
    setIsUploadModalVisible(false);
  };
  const handleAppendChange = (e: any) => {
    setAppendChecked(e.target.checked);
    if (e.target.checked) setOverwriteChecked(false);
  };

  const handleOverwriteChange = (e: any) => {
    setOverwriteChecked(e.target.checked);
    if (e.target.checked) setAppendChecked(false);
  };
  const handleUpload = async (blob: string) => {
    try {
      setLoading(true)
      const url = ENV_ROUTES.SIM_MANAGEMENT
      let flag: string = appendChecked ? "append" : "overwrite";

      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/import_bulk_data",
        table_name: "users",
        insert_flag: flag,
        module_name: "Users",
        role_name: role,
        Partner: partner,

        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        blob: blob, // Include the Blob in the data
      };

      const response = await axios.post(url, { data });

      const resp = JSON.parse(response.data.body);
      if (response.data.statusCode === 200) {
        if (resp.flag === true) {
          setIsUploadModalVisible(false)
          notification.success({
            message: 'Success',
            description: 'Successfully uploaded the record',
            placement: 'top',
          });
          fetchData()
        } else {
          Modal.error({
            title: 'Import Error',
            content: resp.message,
            centered: true,
            onOk: handleErrorModalClose,
            onCancel: handleErrorModalClose
          });
        }
      } else {
        Modal.error({
          title: 'Import Error',
          content: resp.message,
          centered: true,
          onOk: handleErrorModalClose,
          onCancel: handleErrorModalClose
        });
      }
    } catch (error) {
      console.error('Error during file upload:', error);
      Modal.error({
        title: 'Import Error',
        content: 'There was an error uploading the file.',
        centered: true,
        onOk: handleErrorModalClose,
        onCancel: handleErrorModalClose
      });

    }
    finally {
      setLoading(false)
    }
  }
  const handleErrorModalClose = () => {
    setIsUploadModalVisible(false)
  }
  const handleChange = (info: any) => {
    if (info.file.status === 'done') {
      setIsFileSelected(true);
      let blob;
      const file = info.file.originFileObj; // Get the file object
      const reader = new FileReader();
      reader.onload = (e: any) => {
        // Get the file data URL (Base64 string)
        blob = e.target.result;
        console.log('File Base64 String:', blob);
        handleUpload(blob)
        setUploadKey(Date.now());
      };

      if (blob) {
      }

      reader.readAsDataURL(file); // Read the file as data URL
    } else if (info.file.status === 'error') {
      // Handle upload error
      message.error('Upload failed.');
    }
    else if (info.file.status === 'removed') {
      setIsFileSelected(false);
      setAppendChecked(false);
      setOverwriteChecked(false);
    }
  };
  const uploadProps = {
    key: uploadKey,
    accept: '.xlsx, .xls',
    beforeUpload: (file: any) => {
      // Check if file is an Excel file
      const isExcel = file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || file.type === 'application/vnd.ms-excel';
      if (!isExcel) {
        message.error('You can only upload Excel files!');
      }
      return isExcel;
    },
    onChange: handleChange,
  };
  // if (loading) {
  //   return (
  //     <div className="flex justify-center items-center h-screen">
  //       <Spin size="large" />
  //     </div>
  //   );
  // }


  const fetchData = (async () => {
    setLoading(true);
    setCombineAdnvaceStoredpagination(null);
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_partner_info",
        role_name: role,
        parent_module: "Partner",
        modules_list: ["Partner users"],
        feature_module_name: "Partner Info",
        pages: {
          "Customer groups": { start: 0, end: 100 },
          "Partner users": { start: 0, end: 100 }
        },
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,

      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching E911 Customers data. Please try again.',
          centered: true,
        });
      } else {
        setPartnerUsers(parsedData)
        const tableData = parsedData?.data?.["Partner users"]?.users || [];
        settabledata(tableData);
        setAllowedActions((prev) => {
          let actions = [...prev]; // keep previously assigned features
          if (role?.toLowerCase() === "super admin") {
            actions.push("resetPassword");
          }
          return actions;
        });
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  });
  // const handleExport = async () => {
  //   if (!dateRange || dateRange[0] === null || dateRange[1] === null) {
  //     Modal.error({ title: 'Error', content: 'Please select a date range.' });
  //     return;
  //   }

  //   const [startDate, endDate] = dateRange;

  //   const data = {
  //     path: "/export",
  //     username: username,
  //     table: "customers",
  //     module_name: "Users",
  //     request_received_at: getCurrentDateTime(),
  //     start_date: startDate.format("YYYY-MM-DD 00:00:00"), // Start of the day
  //     end_date: endDate.format("YYYY-MM-DD 23:59:59"),

  //     Partner: partner,
  //     access_token: token,
  //     db_name: selectedDb,
        // ... metaData,
  //   };

  //   try {
  //     const url = ENV_ROUTES.MODULE_MANAGEMENT;
  //     const response = await axios.post(url, { data: data }, {
  //       headers: {
  //         'Content-Type': 'application/json',
  //       },
  //     });

  //     const resp = JSON.parse(response.data.body);
  //     const blob = resp.blob;
  //     console.log(resp)
  //     // Close the modal after exporting
  //     if (response.data.statusCode === 200) {
  //       if (resp.flag === true) {
  //         notification.success({
  //           message: 'Success',
  //           description: 'Successfully exported the record!',
  //           style: messageStyle,
  //           placement: 'top',
  //         });

  //         // Trigger the download after a successful export
  //         downloadBlob(blob);
  //       } else {
  //         // Log and show error message
  //         console.log('Error message:', resp.message);
  //         Modal.error({
  //           title: 'Export Error',
  //           content: resp.message,
  //           centered: true,
  //         });

  //       }
  //     } else {
  //       // Handle unexpected status codes
  //       console.log('Unexpected status code:', response.data.statusCode);
  //       Modal.error({
  //         title: 'Export Error',
  //         content: resp.message,
  //         centered: true,
  //       });
  //     }

  //     handleExportModalClose();


  //   } catch (error) {
  //     // console.error("Error downloading the file:", error);
  //     // Modal.error({ title: 'Export Error', content: 'An error occurred while exporting the file. Please try again.' });
  //   }
  // };

  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }

  const ExportWithoutSearch = async () => {
    // setExportLoading(true)
    // const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
    //   return new Promise((resolve, reject) => {
    //     const timer = setTimeout(() => {
    //       reject(new Error("Request timed out"));
    //     }, timeout);

    //     promise
    //       .then((res) => {
    //         clearTimeout(timer);
    //         resolve(res);
    //       })
    //       .catch((err) => {
    //         clearTimeout(timer);
    //         reject(err);
    //       });
    //   });
    // };
    try {
      // setExportLoading(true)
      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Request timed out"));
          }, timeout);
  
          promise
            .then((res) => {
              clearTimeout(timer);
              resolve(res);
            })
            .catch((err) => {
              clearTimeout(timer);
              reject(err);
            });
        });
      };
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/export_to_s3_bucket",
        role_name: role,
        parent_module: "Partner",
        module_name: "Users",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        start_date: getFirstDayOfCurrentMonth(),
        end_date: getLastDayOfCurrentMonth(),
      };
      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000); // Timeout of 10 seconds
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }

      // Wait for 20 seconds before polling
      await new Promise((resolve) => setTimeout(resolve, 20000));
      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      // setExportLoading(false);
      // removeExport(exportKey); // Remove the export from the store
    }
  }
  const pollExportStatus = async () => {
    // Polling for the second API
  const export_url = ENV_ROUTES.MODULE_MANAGEMENT;
  const export_data = {
    tenant_name: partner || "default_value",
    username,
    path: "/get_export_status",
    role_name: role,
    parent_module: "Partner",
    module_name:"Users",
    request_received_at: getCurrentDateTime(),
    Partner: partner,
    access_token: token,
    db_name: selectedDb,
        ... metaData,
    sessionID: sessionId,
  };
    try {
      const export_response = await axios.post(export_url, { data: export_data });
      const export_parsedData = JSON.parse(export_response.data.body);

      if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
        const s3Url = export_parsedData?.export_status_data?.url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
                          .then(response => response.blob())
                          .then(blob => {
                            const url = window.URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = 'Users.xlsx';
                            a.click();
                            a.remove();
                            window.URL.revokeObjectURL(url);
                            notification.success({
                              message: "Success",
                              description: "Successfully exported the record!",
                              style: messageStyle,
                              placement: "top",
                            });
                          })
                        .catch((err) => {
                          console.log("error",err)
                          Modal.error({
                            title: "Export Error",
                            content: "An error occurred while exporting data. Please try again.",
                            centered: true,
                          });
                        });
        } else {
          Modal.error({
            title: "Export Error",
            content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
        return true; // Stop polling
      }

      if (export_parsedData?.export_status_data?.status_flag === "Failure") {
        Modal.error({
          title: "Export Error",
          content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
        return true; // Stop polling
      }
      if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
                Modal.info({
                  title: "Export Error",
                  content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
                  centered: true,
                });
                return true; // Stop polling
              }

      return false; // Continue polling
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
      return true; // Stop polling
    }
  };
  const startPolling = async () => {
    let isPollingComplete = false;

    while (!isPollingComplete) {
      isPollingComplete = await pollExportStatus();
      if (!isPollingComplete) {
        await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
      }
    }
  };


  const handleExport = async (key:string, heading:string) => {
    try {
      // setExportLoading(true)
      addExport(key, heading);
      let parsedData
      let url
      let data: any
      let response
      if(combineAdnvaceStoredpagination){
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
        ... metaData,
          sessionID: sessionId,
          module_name:"Users",
          index_name: "partner_users",
        }
        console.log("combineAdnvaceStoredpagination",data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
      else if (advancedStoredpagination && !storedpagination){
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          module_name:"Users",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name: "partner_users",
          pages: {
            start: 0,
            end: 100
          },
          partner:partner,
          username: username,
          db_name: selectedDb,
        ... metaData,
          sessionID: sessionId,
          tenant_id: tenantId,
          // }
        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

      }
      else if (storedpagination && !advancedStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          module_name:"Users",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "partner_users",
          search: "whole",
          pages: {
            start: 0,
            end: 100,
          },
          partner:partner,
          username: username,
          db_name: selectedDb,
        ... metaData,
          sessionID: sessionId,
          tenant_id: tenantId,

        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

      }
      else {
        // ExportWithoutSearch()
        await ExportWithoutSearch();
        return;
      }

      if (advancedStoredpagination || storedpagination || combineAdnvaceStoredpagination) {
        // if (parsedData.flag === true) {
        //   const s3Url = parsedData?.download_url || null;
        //   if (s3Url) {
        //     window.location.href = s3Url;
        //     setExportLoading(false)
        //     notification.success({
        //       message: 'Success',
        //       description: 'Successfully exported the record!',
        //       style: messageStyle,
        //       placement: 'top',
        //     });
        //   }
        //   else {
        //     setExportLoading(false)
        //     Modal.error({
        //       title: "Export Error",
        //       content: parsedData.message || "An error occurred while exporting data. Please try again.",
        //       centered: true,
        //     });
        //   }


        if (parsedData.flag) {
          const s3Url = parsedData?.download_url || null;
          if (s3Url) {
            // window.location.href = s3Url;
            // notification.success({
            //   message: "Success",
            //   description: "Successfully exported the  record!",
            //   style: messageStyle,
            //   placement: "top",
            // });
            fetch(s3Url)
                            .then(response => response.blob())
                            .then(blob => {
                              const url = window.URL.createObjectURL(blob);
                              const a = document.createElement('a');
                              a.href = url;
                              a.download = 'Users.xlsx';
                              a.click();
                              a.remove();
                              window.URL.revokeObjectURL(url);
                              notification.success({
                                message: "Success",
                                description: "Successfully exported the record!",
                                style: messageStyle,
                                placement: "top",
                              });
                            })
                          .catch((err) => {
                            console.log("error",err)
                            Modal.error({
                              title: "Export Error",
                              content: "An error occurred while exporting data. Please try again.",
                              centered: true,
                            });
                          });
          }


        } else {
          // setExportLoading(false)
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      } else {
        Modal.error({
          title: "Export Error",
          content: parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
      }

    } catch (error) {
      console.log("catch")
      await startPolling()
      // Modal.error({
      //   title: "Export Error",
      //   content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
      //   centered: true,
      // });
    } finally {
      // setExportLoading(false)
      removeExport(key);
    }
  };
  const messageStyle = {
    fontSize: '14px',  // Adjust font size
    fontWeight: 'bold', // Make the text bold
    padding: '16px',
    // Add padding
  };

  const downloadBlob = (base64Blob: string) => {
    // Decode the Base64 string
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    const blobObject = new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blobObject);
    link.download = 'Partner Users.xlsx'; // Set the file name to .xlsx
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };


  const disableFutureDates = (current: any) => {
    console.log("future dates:", current && current > dayjs().endOf('day'));
    return current && current > dayjs().endOf('day'); // Disable future dates
  };
  const handleFileUpload = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const data = new Uint8Array(e.target?.result as ArrayBuffer);
      const workbook = XLSX.read(data, { type: 'array' });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const jsonData: any[] = XLSX.utils.sheet_to_json(worksheet, {
        header: 1,
        blankrows: false,
      });

      const columnNames = jsonData[0];
      const filledData = jsonData.slice(1).map((row) => {
        const filledRow: any = {};
        columnNames.forEach((header: any, index: number) => {
          filledRow[header] = row[index] || '';
        });
        return filledRow;
      });

      setData(filledData);
      setVisibleColumns(columnNames);
      message.success(`${file.name} file uploaded successfully.`);
    };
    reader.readAsArrayBuffer(file);
    setImportModalOpen(false);

  };

  return (
    <div className="relative overflow-auto">
      {showCreateUser ? (
        <CreateUser onClose={()=>{setShowCreateUser(false)}}/>
      ) : (
        <>
          <div className="flex items-center justify-between">
            <ChartsPage />
          </div>
          <div className="pr-4 pl-4  pt-2 flex md:flex-row md:items-center md:justify-between mt-1 mb-4 space-y-4">
          {/* Search and Advanced Filter Container */}
          <div className="flex space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last ">
              {features.includes("Search-Partner users") && (
                <TableSearch
                  searchTerm={searchTerm}
                  setSearchTerm={setSearchTerm}
                  tableName={"partner_users"}
                  headerMap={headerMap}
                />
              )}
              {features.includes("Advanced search-Partner users") && (
                <AdvancedMultiFilter
                  showAdvanced={showAdvanced}
                  setShowAdvanced={setShowAdvanced}
                  onFilter={handleFilter}
                  onReset={handleReset}
                  headers={headers}
                  headerMap={headerMap}
                  tableName={"partner_users"} />
              )}
            </div>

             {/* Export and ColumnFilter Container */}
          <div className="hidden md:flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2  md:order-none order-first pb-2 md:pb-4">
              {features.includes("Create-Partner users") && (
                <button
                  className="save-btn"
                  onClick={handleCreateClick} // Show create user form on click
                >
                  <PlusIcon className="h-5 w-5 text-black-500 mr-1" />
                  Create
                </button>
              )}
              {features.includes("Upload-Partner users") && (
                <button className="save-btn" onClick={handleUploadClick}>
                  <ArrowUpTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                  <span>Upload</span>
                </button>
              )}
              <Modal
                title="Upload Files"
                visible={isUploadModalVisible}
                onCancel={handleUploadModalClose}
                footer={null} // No default footer buttons
                centered
                width={400}
              >
                 <div className="flex flex-col gap-4">
                           <div className="flex flex-col md:flex-row gap-4 justify-center m-auto p-4">
                             <Upload {...uploadProps} className="w-full md:w-auto">
                                 <button className="w-[200px] md:w-full upload-btn disabled:cursor-not-allowed">
                                 <span className="mr-2"><UploadOutlined /></span>
                                   Upload
                                 </button>
                             </Upload>
                                 <button
                                   onClick={handleDownloadTemplate}
                                   className=" w-[200px] md:w-full upload-btn disabled:cursor-not-allowed"
                                   // disabled={!appendChecked && !overwriteChecked}
                                 >
                                   <span className="mr-2"><DownloadOutlined /></span>
                                   Download Template
                                 </button>
                           </div>
                         </div>
              </Modal>
              {features.includes("Export-Partner users") && (
                <button className="save-btn"
                onClick={() => {
                  if (!exports.some((exportItem) => exportItem.popupHeading === "Partner Users")) {
                    handleExport("PrtnerUsers", "Partner Users");
                  }
                }}>
                  <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                  <span>Export</span>
                </button>
              )}
              <ColumnFilter headers={headers} visibleColumns={visibleColumns} setVisibleColumns={setVisibleColumns} headerMap={headerMap} />
            </div>
          </div>
          <div className=' mb-4 space-x-2'>

            {/* <AdvancedMultiFilter
              showAdvanced={showAdvanced}
              setShowAdvanced={setShowAdvanced}
              onFilter={handleFilter}
              onReset={handleReset}
              headers={headers}
              headerMap={headerMap}
              tableName={"partner_users"} /> */}
          </div>
          <div className={`${showAdvanced ? 'mt-[70px]' : ''}`}>
            <TableComponent
              headers={headers}
              headerMap={headerMap}
              initialData={data}
              searchQuery={searchTerm}
              visibleColumns={visibleColumns}
              itemsPerPage={100}
              allowedActions={allowedActions}
              popupHeading='User'
              createModalData={createModalData}
              pagination={pagination}
              generalFields={generalFields}
              advancedFilters={filteredData}
              height = {showAdvanced?360:300}
            />

          </div>
            {/* Sticky Footer for Small Screens */}
                                                  <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
                                                  {features.includes("Create-Partner users") && (
                                                    <button
                                                      className="save-btn"
                                                      onClick={handleCreateClick} // Show create user form on click
                                                    >
                                                      <PlusIcon className="h-5 w-5 text-black-500" />
                                                    </button>
                                                  )}
                                                  {features.includes("Upload-Partner users") && (
                                                    <button className="save-btn" onClick={handleUploadClick}>
                                                      <ArrowUpTrayIcon className="h-5 w-5 text-black-500 " />
                                                    </button>
                                                  )}
                                                  {features.includes("Export-Partner users") && (
                                                    <button className="save-btn"
                                                    onClick={() => {
                                                      if (!exports.some((exportItem) => exportItem.popupHeading === "Partner Users")) {
                                                        handleExport("PrtnerUsers", "Partner Users");
                                                      }
                                                    }}>
                                                      <ArrowDownTrayIcon className="h-5 w-5 text-black-500 " />
                                                    </button>
                                                  )}
                                                    <ColumnFilter
                                                      headers={headers}
                                                      visibleColumns={visibleColumns}
                                                      setVisibleColumns={setVisibleColumns}
                                                      headerMap={headerMap}
                                                    />
                                                  </div>   
          <Modal
            title="Export output"
            visible={isExportModalOpen}
            onCancel={() => {
              handleExportModalClose();
              setDateRange([null, null]); // Reset date range here for good measure
            }}
            footer={null}
            centered
            afterClose={() => setDateRange([null, null])}
          >
            <div className="flex flex-col space-y-4">
              <span>Select Date Range</span>
              <RangePicker
                value={dateRange[0] && dateRange[1] ? [dateRange[0], dateRange[1]] : null} // Bind the date range
                onChange={(dates) => {
                  console.log("Selected dates:", dates); // Debug log
                  if (dates && dates.length === 2) {
                    setDateRange([dates[0], dates[1]] as [Dayjs, Dayjs]);
                  } else {
                    setDateRange([null, null]); // Reset to null if dates are not both available
                  }
                }}
                format="YYYY-MM-DD"
                disabledDate={disableFutureDates}
                popupClassName="custom-range-popup"
              />
              <div className="flex justify-center space-x-2">
                <button onClick={handleExportModalClose} className='cancel-btn'>Cancel</button>
                {/* <button onClick={handleExport} className='save-btn' style={{ color: '#333' }}>Export</button> */}
              </div>
            </div>
          </Modal>
          {/* {exportLoading && (
            <div className="export-processing-div">
              Export Processing...
            </div>
          )} */}
        </>
      )}
    </div>
  );
};

export default ListView;
