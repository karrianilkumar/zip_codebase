"use client";
import { CheckIcon, XMarkIcon } from "@heroicons/react/16/solid";
import React, { useState, useEffect } from "react";
import Select, { SingleValue, StylesConfig } from "react-select";
import {
  NonEditableDropdownStyles,
  DropdownStyles,
} from "@/app/components/css/dropdown";
import { useUserStore } from "./createUserStore";
import { usePartnerStore } from "../../partnerStore";
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { List, Modal, notification, Spin } from "antd";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
// import { OptionType } from 'dayjs';

interface ExcelData {
  [key: string]: {
    Module: string[];
    Feature: {
      [key: string]: string[];
    };
  };
}

type Feature = {
  [module: string]: string[];
};

type ModuleData = {
  Module: string[];
  Feature: Feature;
};

type CategoryData = {
  [category: string]: ModuleData;
};

type Data = {
  [role: string]: CategoryData;
};

type OptionType = {
  value: string;
  label: string;
};

type Role = {
  rolename: string;
};

const editableDrp = DropdownStyles;
const nonEditableDrp = NonEditableDropdownStyles;

interface UserRoleProps {
  rowData?: any;
  editable?: boolean;
  setRowData: (row:any) => void;
}

const UserRole: React.FC<UserRoleProps> = ({ rowData, editable,setRowData }) => {
  const setPartnerModuleAccess = usePartnerStore(
    (state) => state.setPartnerModuleAccess
  );
  const [Selectedpartner, setPartner] = useState<string>("");
  const [map, setMap] = useState<ExcelData>({});
  const { username, partner: userPartner, token, selectedDb,metaData,settabledata, firstLastName,sessionId ,role:authRole , isSubTenant} = useAuth();

  const [role, setRole] = useState<SingleValue<OptionType>>(null);
  const [selectedModules, setSelectedModules] = useState<{
    [key: string]: string[];
  }>({});
  const [selectedFeatures, setSelectedFeatures] = useState<{
    [key: string]: string[];
  }>({});
  const [moduleColors, setModuleColors] = useState<{ [key: string]: string }>(
    {}
  );
  const [errorMessages, setErrorMessages] = useState<string[]>([]);
  const [response, setResponse] = useState<any>({});
  //Show Modal
  const [showModal, setShowModal] = useState(false);

  const [loading, setLoading] = useState(false);

  const { partnerData,setPartnerUsers } = usePartnerStore.getState();
  const PartnerModuleData = partnerData?.["Partner module access"] || {};
  const [subPartnersData, setSubPartnersData] = useState<string[]>([]); // State for sub-partners
  const [selectedSubPartner, setSelectedSubPartner] = useState<SingleValue<OptionType>>(null); // State for selected sub-partner
  const [previousSubPartner, setPreviousSubPartner] = useState<SingleValue<OptionType>>(null);
  const {
    tenant,
    role_name,
    sub_tenant,
    setTenant,
    setRoleName,
    setSubTenant,
    user_name,
    user_role_data,
    setIsUserRoleSubmitted,
    setUserRoleData,
  } = useUserStore();


  interface SubModuleData {
    [key: string]: string[];
  }
  
  interface ModuleFeaturesData {
    [key: string]: {
      [subModule: string]: string[];
    };
  }
  
  interface InputData {
    sub_module: SubModuleData;
    module_names: string[];
    module_features: ModuleFeaturesData;
  }
  
  interface ConvertedObject {
    id: string;
    role: string;
    module: string;
    sub_module: string;
    module_features: string;
  }
  const initialfetchData = async () => {
    console.log("initialfetchData") 
    setLoading(true);
    // Set loading to true before the request
    const selectedPartner = selectedSubPartner ? selectedSubPartner.value : tenant;
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        path: "/user_data",
        user_name: rowData?.username || "",
        Partner: userPartner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        role_name: rowData?.role || "",
        user_tenant_name : tenant,
      };

      const response = await axios.post(url, { data: data });
      const parsedData = JSON.parse(response.data.body);
      if (response.data.statusCode === 200 && parsedData.flag === true) {
        setUserRoleData(parsedData)
        setLoading(false)
      }
      else {
        setLoading(false)
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      }



    } catch (err) {
      console.error("Error fetching data:", err);
      Modal.error({
        title: 'Data Fetch Error',
        content: err instanceof Error ? err.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
 useEffect(()=>{
  if(!rowData){
    console.log(sub_tenant,"Show sub tenants")
    setSubPartnersData(sub_tenant);
    if(isSubTenant){
      const sub_partner=sub_tenant.length>0?{label:sub_tenant[0],value:sub_tenant[0]}:null
    setSelectedSubPartner(sub_partner); // Set default selected sub-partners
    }
    
  }

 },[])
  useEffect(() => {
    if (rowData) {
      setPartner(rowData["tenant_name"] ? rowData["tenant_name"] : null);
      setRole(rowData["role"] ? rowData["role"] : null);
       // Parse the subtenant_name from JSON string to array
       try {
      const subtenantValue = rowData?.["subtenant_name"] || "None";
      const parsedSubtenants =
        subtenantValue && subtenantValue !== "None"
          ? JSON.parse(subtenantValue)
          : [];        
        const sub_partner=parsedSubtenants.length>0?{label:parsedSubtenants[0],value:parsedSubtenants[0]}:null
        setSelectedSubPartner(sub_partner); // Set default selected sub-partners
        setSubPartnersData(parsedSubtenants); // Set available sub-partners
        fetchData(sub_partner);
      } catch (error) {
        console.error("Error parsing subtenant_name:", error);
        setSubPartnersData([]); // Reset to empty if parsing fails
      }
    }
    // initialfetchData()
  }, [rowData]);
 
  const fetchData = async (selectedOption: SingleValue<OptionType>) => {
    console.log("fetchData") 
    setLoading(true);
    const selectedPartner = selectedOption ? selectedOption.value : tenant;
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        path: "/user_data",
        user_name: rowData?.username || "",
        Partner: userPartner,
        SubPartner: selectedOption?.value || "", // Include selected sub-partner
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        user_tenant_name : selectedPartner,
        role_name: rowData?.role || ""
      };
  
      const response = await axios.post(url, { data: data });
      const parsedData = JSON.parse(response.data.body);
      if (response.data.statusCode === 200 && parsedData.flag === true) {
        setUserRoleData(parsedData);
      } else {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      }
    } catch (err) {
      console.error("Error fetching data:", err);
      Modal.error({
        title: 'Data Fetch Error',
        content: err instanceof Error ? err.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  
  const handleSetSubPartner = async (selectedOption: SingleValue<OptionType>) => {
    setPreviousSubPartner(selectedSubPartner); // Store the previous sub-partner
    setSelectedSubPartner(selectedOption); // Update selected sub-partner
    // Call the fetchData API whenever the selected option changes
    if (selectedOption) {
        await fetchData(selectedOption);
    }
  };

  
  const convertDataToFormat = (input: InputData): ConvertedObject[] => {
     // Check if input is defined and has the expected properties
     if (!input || !input.module_names) {
      console.error("Invalid input data:", input);
      return []; // Return an empty array or handle the error as needed
  }
    // Step 1: Prepare the modules in a JSON string format
    const modules = JSON.stringify(input.module_names);
  
    // Step 2: Prepare the sub_module object
    const subModuleObject: Record<string, string[]> = {};
    for (const moduleName of input.module_names) {
      // Use the provided sub-modules or an empty array if not available
      subModuleObject[moduleName] = input.sub_module[moduleName] || [];
    }
    const subModuleString = JSON.stringify(subModuleObject);
  
    // Step 3: Prepare the module_features object
    const moduleFeaturesObject: Record<string, Record<string, string[]>> = {};
    for (const moduleName in input.module_features) {
      moduleFeaturesObject[moduleName] = {};
      for (const subModule in input.module_features[moduleName]) {
        moduleFeaturesObject[moduleName][subModule] = input.module_features[moduleName][subModule];
      }
    }
    const moduleFeaturesString = JSON.stringify(moduleFeaturesObject);
  
    // Step 4: Return the result as an array with a single object
    const result: ConvertedObject = {
      id:"",
      role:role_name,
      module: modules,
      sub_module: subModuleString,
      module_features: moduleFeaturesString,
    };
    return [result];
  };
console.log("user_role_data",user_role_data)

const userSpecificData = user_role_data &&
user_role_data.user_specific_data && user_role_data.user_specific_data[0] ? user_role_data?.user_specific_data[0] : {}
console.log("userSpecificData",userSpecificData)
const allEmpty = Object.values(userSpecificData?.sub_module || {}).every(arr => Array.isArray(arr) && arr.length === 0);
console.log("allEmpty",allEmpty)

const isNoModulesEnabled =(userSpecificData?.module_names && userSpecificData.length === 0) || allEmpty
console.log("isNoModulesEnabled",isNoModulesEnabled)

  const rawData = rowData && 
                user_role_data?.role_module && 
                user_role_data.role_module.length > 0 && 
                !(isNoModulesEnabled)
  ?convertDataToFormat(user_role_data.user_specific_data[0])
  : PartnerModuleData?.data?.["Partner module access"]?.["role_module"];

  //   let rawData: any;

  const handleClearFields = () => {
    setPartner("");
    setRole(null);
    setSelectedModules({});
    setSelectedFeatures({});
    setMap({});
    setErrorMessages([]);
  };

  const transformData = (data: typeof rawData): Data => {
    const transformedData: Data = {};
    data?.forEach(
      (item: {
        role: any;
        module: string;
        sub_module: string;
        module_features: string;
      }) => {
        const role = item.role;
        const modules = item.module !== "None" ? JSON.parse(item.module) : [];
        const subModules =
          item.sub_module !== "None" ? JSON.parse(item.sub_module) : {};
        const moduleFeatures =
          item.module_features !== "None"
            ? JSON.parse(item.module_features)
            : {};

        if (!transformedData[role]) {
          transformedData[role] = {};
        }

        modules.forEach((module: string) => {
          transformedData[role][module] = {
            Module: subModules[module] || [],
            Feature: moduleFeatures[module] || {},
          };
        });
      }
    );

    return transformedData;
  };

  const mockRoleData: Data = transformData(rawData);

  const handleSetRole = (selectedOption: SingleValue<OptionType>) => {
    console.log("user_role_data",user_role_data)
    if (selectedOption) {
        const role = selectedOption.value;
        setRole(selectedOption);

        let selectedRoleData;

        if (!mockRoleData[role]) {
            selectedRoleData = generateDefaultRoleData();
        } else {
            selectedRoleData = combineRoleData(
                generateDefaultRoleData(),
                mockRoleData[role]
            );
        }
        setMap(selectedRoleData);

        // Initialize selected modules and features based on the selected role
        const initialSelectedModules: { [key: string]: string[] } = {};
        const initialSelectedFeatures: { [key: string]: string[] } = {};

        Object.keys(selectedRoleData).forEach((category) => {
            // if (role === "Super Admin") {
            //     // Select all modules and features for "Super Admin"
            //     initialSelectedModules[category] = selectedRoleData[category].Module.map((module) =>
            //         module.replace("-active", "")
            //     );

            //     Object.keys(selectedRoleData[category]?.Feature || {}).forEach((module) => {
            //         initialSelectedFeatures[category] =
            //             initialSelectedFeatures[category] || [];
            //         initialSelectedFeatures[category].push(
            //             ...selectedRoleData[category].Feature[module].map((feature) =>
            //                 feature.replace("-active", "")
            //             )
            //         );
            //     });
            // } else
            //  {
                // Regular initialization
                initialSelectedModules[category] = selectedRoleData[
                    category
                ].Module.filter((module) => module.includes("-active")).map((module) =>
                    module.replace("-active", "")
                );

                Object.keys(selectedRoleData[category]?.Feature || {}).forEach((module) => {
                    initialSelectedFeatures[category] =
                        initialSelectedFeatures[category] || [];
                    selectedRoleData[category].Feature[module].forEach((feature) => {
                        if (feature.includes("-active")) {
                            initialSelectedFeatures[category].push(
                                feature.replace("-active", "")
                            );
                        }
                    });
                });
            // }
        });

        setSelectedModules(initialSelectedModules);
        setSelectedFeatures(initialSelectedFeatures);
    }
};


  const generateDefaultRoleData = (): CategoryData => {
    let subModules, parentModules, moduleFeatures;

      subModules = PartnerModuleData?.data?.["Partner module access"]?.["module"] ||{};
      parentModules = PartnerModuleData?.data?.["Partner module access"]?.["tenant_module"] || [];
      moduleFeatures = PartnerModuleData?.data?.["Partner module access"]?.["module_features"] || [];
    const defaultRoleData: CategoryData = {};

    // Iterate through each parent module
    parentModules?.forEach((parentModule: string) => {
      defaultRoleData[parentModule] = {
        Module: [], // Initialize Module as an empty array
        Feature: {},
      };

      // Find children modules for the parent module
      const childrenModules = subModules[parentModule] || [];
      defaultRoleData[parentModule].Module = childrenModules; // Assign children modules

      // Populate features for each child module
      childrenModules.forEach((childModule: string) => {
        const features = moduleFeatures.find(
          (modFeat: { module: string; parent_module_name: string }) =>
              modFeat.module === childModule && modFeat.parent_module_name === parentModule
      );
        defaultRoleData[parentModule].Feature[childModule] = features
          ? JSON.parse(features.features)
          : []; // Parse features if available
      });
    });

    return defaultRoleData;
  };

  const combineRoleData = (
    defaultData: CategoryData,
    selectedRoleData: CategoryData
  ): CategoryData => {

    for (const [moduleKey, moduleValue] of Object.entries(defaultData)) {
      // Check if the module exists in the selected role data
      if (selectedRoleData[moduleKey]) {
        // Mark the module as active if it exists in selectedRoleData
        moduleValue.Module = moduleValue.Module.map((module: string) => {
          const isActive = selectedRoleData[moduleKey].Module.includes(
            module.replace("-active", "")
          );
          const newModuleName = isActive
            ? `${module.replace("-active", "")}-active`
            : module.replace("-active", "");
          return newModuleName;
        });

        // Get the selected features for the current module
        const selectedFeatures = selectedRoleData[moduleKey].Feature || {};

        // Process features for the current module
        for (const featureKey of Object.keys(moduleValue.Feature)) {
          // Check if features exist in selected role data
          for (const featureKey of Object.keys(moduleValue.Feature)) {
            if (selectedFeatures[featureKey]) {
              moduleValue.Feature[featureKey] = moduleValue.Feature[
                featureKey
              ].map((feature: string) => {
                const isActiveFeature = selectedFeatures[featureKey].includes(
                  feature.replace("-active", "")
                );
                return isActiveFeature
                  ? `${feature.replace("-active", "")}-active`
                  : feature;
              });
            }
          }
        }
      } else {
        // If the module doesn't exist in selectedRoleData, retain its original state
        moduleValue.Module = moduleValue.Module.map((module) =>
          module.replace("-active", "")
        );

        // Retain original features state as well
        for (const featureKey of Object.keys(moduleValue.Feature)) {
          moduleValue.Feature[featureKey] = moduleValue.Feature[
            featureKey
          ].filter((feature) => !feature.endsWith("-active"));
        }
      }
    }

    return defaultData; // Returns modified defaultData
  };

  const toggleModule = (category: string, module: string) => {
    setSelectedModules((prev) => {
        const modules = prev[category] || [];
        const isSelected = modules.includes(module);
        const features = map[category]?.Feature[module] || []; // All features related to the module

        // If the module is selected, select all its features
        if (!isSelected) {
            const newFeatures = features.map((feature) => feature.replace('-active', ''));
            setSelectedFeatures((prevFeatures) => {
                const currentFeatures = prevFeatures[category] || [];
                return {
                    ...prevFeatures,
                    [category]: [...new Set([...currentFeatures, ...newFeatures])], // Add all features and remove duplicates
                };
            });
        } else {
            // If the module is deselected, remove all its features
            setSelectedFeatures((prevFeatures) => {
                const currentFeatures = prevFeatures[category] || [];
                const updatedFeatures = currentFeatures.filter(
                    (f) => !features.map((feature) => feature.replace('-active', '')).includes(f)
                );
                return {
                    ...prevFeatures,
                    [category]: updatedFeatures,
                };
            });
        }

        // Update modules selection
        const updatedModules = isSelected
            ? modules.filter((m) => m !== module) // Deselect the module
            : [...modules, module]; // Select the module

        return {
            ...prev,
            [category]: updatedModules,
        };
    });
};

  const toggleFeature = (category: string, feature: string) => {
    setSelectedFeatures((prev) => {
      const features = prev[category] || [];
      const isSelected = features.includes(feature);

      const updatedFeatures = isSelected
        ? features.filter((f) => f !== feature) // Deselect feature
        : [...features, feature]; // Select feature

      // Update the selected features state
      const newFeaturesState = {
        ...prev,
        [category]: updatedFeatures,
      };

      // Check if all features of the module are selected or deselected
      setSelectedModules((prevModules) => {
        const moduleNames = Object.keys(map[category]?.Feature || {});
        // eslint-disable-next-line @next/next/no-assign-module-variable
        for (const module of moduleNames) {
          const moduleFeatures = map[category]?.Feature[module] || [];
          const featureNames = moduleFeatures.map((f) =>
            f.replace("-active", "")
          );
          const areAllSelected =
            featureNames.length > 0 &&
            featureNames.every((f) => newFeaturesState[category]?.includes(f));
          const areAllDeselected =
            featureNames.length === 0 &&
            featureNames.every((f) => !newFeaturesState[category]?.includes(f));
          const isNewModule =
            featureNames.length > 0 &&
            featureNames.some((f) => newFeaturesState[category]?.includes(f));
          if (areAllSelected) {
            if (!prevModules[category]?.includes(module)) {
              prevModules[category] = [
                ...(prevModules[category] || []),
                module,
              ];
            }
          } else if (areAllDeselected) {
            prevModules[category] =
              prevModules[category]?.filter((m) => m !== module) || [];
          } else if (isNewModule) {
            if (!prevModules[category]?.includes(module)) {
              prevModules[category] = [
                ...(prevModules[category] || []),
                module,
              ];
            }
          }
        }

        return { ...prevModules };
      });

      return newFeaturesState;
    });
  };

  const messageStyle = {
    fontSize: "14px", // Adjust font size
    fontWeight: "bold", // Make the text bold
    padding: "16px",
    // Add padding
  };

  useEffect(() => {
    if (role_name) {
      // Create your selectedOption to match the expected structure
      const selectedOption: OptionType = {
        value: role_name,
        label: role_name, // Assuming label is the same as value; adjust as needed
      };
      handleSetRole(selectedOption);
    }
  }, [role_name,user_role_data]);

  const handleSubmit = async () => {
    scrollToTop();
    const errors: string[] = [];

    if (!role) {
      errors.push("Role is required.");
    }

    setErrorMessages(errors);

    if (errors.length === 0) {
      const formattedData: { [key: string]: any } = {
        [role!.value]: {},
      };

      // Loop through selectedModules and selectedFeatures
      Object.keys(selectedModules).forEach((category) => {
        const selectedModulesForCategory = selectedModules[category];
        const selectedFeaturesForCategory = selectedFeatures[category] || [];

        formattedData[role!.value][category] = {
          Module: selectedModulesForCategory,
          Feature: {},
        };

        selectedModulesForCategory.forEach((module) => {
          // Retrieve related features from the map
          const relatedFeatures =
            map[category]?.Feature[module.replace("-active", "")];

          if (relatedFeatures) {
            // Normalize the selected features by removing the '-active' suffix
            const normalizedSelectedFeatures = selectedFeaturesForCategory.map(
              (feature) => feature.replace("-active", "")
            );

            // Filter normalized features against related features
            const filteredFeatures = normalizedSelectedFeatures.filter(
              (feature) => {
                // Check if the related feature contains the normalized feature
                return (
                  relatedFeatures.includes(feature) ||
                  relatedFeatures.includes(feature + "-active")
                );
              }
            );

            // Store filtered features in the formatted data
            formattedData[role!.value][category].Feature[module] =
              filteredFeatures;

            // Log the filtered features for debugging
          } else {
          }
        });
      });
     
        // Determine the selected partner based on whether the sub-partner has changed
        const selectedPartner = selectedSubPartner ? selectedSubPartner.value : tenant;
      const Changed_data = {
        "Selected role": role_name,
        "Selected Partner": selectedSubPartner?.value || tenant,
        data: formattedData,
        Username: user_name ? user_name : null,
        is_active: "True",
        is_deleted: "False",
      };

      try {
        setLoading(true);
        const url =ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: userPartner || "default_value",
          username: username ? username : "",
          path: "/update_partner_info",
          parent_module: "Partner",
          module_name: "Partner Users",
          template_name: "create_user",
          action: "update",
          changed_data: Changed_data,
          request_received_at: getCurrentDateTime(),
          Partner: userPartner,
          access_token: token,
          db_name:selectedDb,
          ... metaData,
          sessionID: sessionId,
          ...(rowData? { list_view_id: rowData?.id||"" } : {}),
        };
        
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (response.data.statusCode === 200 && parsedData.flag === true) {
          setIsUserRoleSubmitted(true)
          setLoading(false);
          notification.success({
            message: "Success",
            description: "Successfully Saved the record!",
            style: messageStyle,
            placement: "top", // Apply custom styles here
          });

          // setLoading(true)

          const data = {
            tenant_name: userPartner || "default_value",
            username: username ? username : "",
            path: "/get_partner_info",
            role_name: authRole,
            parent_module: "Partner",
            modules_list: ["Partner users"],
            feature_module_name: "Partner Info",
            pages: {
              "Customer groups": { start: 0, end: 100 },
              "Partner users": { start: 0, end: 100 },
            },
            access_token: token,
            db_name:selectedDb,
            ... metaData,
            sessionID: sessionId,
          };
          try {
            const response = await axios.post(
              ENV_ROUTES.MODULE_MANAGEMENT,
              { data }
            );
            if (response && response.status === 200) {
              const parseddata = JSON.parse(response.data.body);
              if (parseddata.flag) {
                setPartnerUsers(parseddata)
                const tableData = parseddata?.data?.["Partner users"]?.users || [];
              if(rowData){
                const foundRow = tableData.find((user: any) => user.id === rowData.id);
                // Step 4: Set the found row to form data
                if (foundRow) {
                setRowData(foundRow)
                }
              }
             
              settabledata(tableData);
              } else {
                Modal.error({
                  title: "Error",
                  content: parseddata.message,
                  centered: true,
                });
                setLoading(false);
              }
            } else {
              Modal.error({
                title: "Error",
                content: "An error occurred during fetching data.",
                centered: true,
              });
            }
          } catch (error) {
            console.error("Error fetching");
          }
        } else {
          setLoading(false);
          Modal.error({
            title: "Submit Error",
            content:
              parsedData.message ||
              "An error occurred while submitting the form. Please try again.",
            centered: true,
          });
        }
      } catch (err) {
        setLoading(false);
        console.error("Error fetching data:", err);
      }
    } else {
    }
    // setSelectedModules({});
    // setSelectedFeatures({});
  };
  //Handling modal save
  const handleConfirmSave = () => {
    handleSubmit();
    setShowModal(false);
  };
  //Handling modal cancel
  const handleCancelSave = () => {
    setShowModal(false);
  };

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "auto", // Optional: Smooth scroll animation
    });
  };
  
  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }
  return (
    <div>
      <div className="grid grid-cols-2 gap-4 mb-4">
        <div>
          <label className="field-label">Partner</label>
          <input
            type="text"
            value={tenant}
            className="non-editable-input"
            // onChange={(e) => setRoleName(e.target.value)} // Update role_name state
          />
        </div>
        <div>
          <label className="field-label">Sub Partner</label>
          <Select
            isDisabled={(!editable || isSubTenant)}
            value={selectedSubPartner}
            onChange={handleSetSubPartner}
            options={subPartnersData.map((value) => ({ value, label: value }))}
            // styles={editable ? editableDrp : nonEditableDrp}
            styles={(!editable || isSubTenant) ? nonEditableDrp : editableDrp}
          />
        </div>
        <div>
          <label className="field-label">Role</label>
          <input
            readOnly
            type="text"
            value={role_name}
            className="non-editable-input"
          />
        </div>
      </div>
      {role_name && (
        <>
          <h3 className="tabs-sub-headings">Module Info</h3>
          <div className="grid grid-cols-1 gap-4 mt-4">
            {Object.keys(map).map((category) => (
              <div
                key={category}
                className="col-span-1 border border-gray-300 p-4 rounded-lg"
              >
                <h4 className="text-xl font-medium text-blue-600 ml-2 mb-2 active-table-header">
                  {category}
                </h4>
                <div className="mb-2">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {map[category].Module.map((module) => {
                      const cleanedModule = module.replace("-active", ""); // Remove '-active' for display
                      const isSelected =
                        selectedModules[category]?.includes(cleanedModule);
                      const selectedStyle = isSelected ? 'active' : 'deactive';

                      const relatedFeatures =
                        map[category]?.Feature[cleanedModule] || [];

                      return (
                        <div
                          key={module}
                          className="border border-gray-300 p-4 rounded-lg mb-4"
                        >
                          <div className="flex items-center">
                            <span className="text-md font-b mr-2 text-black bulk-history-div">
                              Module:
                            </span>
                            <button
                              disabled={editable ? false : true}
                              className={`px-2 py-1 rounded-lg border ${selectedStyle}`}
                              onClick={() =>
                                toggleModule(category, cleanedModule)
                              }
                            >
                              {cleanedModule}
                            </button>
                          </div>
                          <div className="mt-2">
                            <span className="text-md font-b mr-2 text-black bulk-history-div">
                              Features:
                            </span>
                            <div className="flex flex-wrap gap-2 mt-2">
                              {relatedFeatures.map((feature) => {
                                const cleanedFeature = feature.replace(
                                  "-active",
                                  ""
                                ); // Remove '-active' for display
                                const isSelected =
                                  selectedFeatures[category]?.includes(
                                    cleanedFeature
                                  );
                                const selectedStyle = isSelected ? 'active' : 'deactive';

                                return (
                                  <button
                                    disabled={editable ? false : true}
                                    key={feature}
                                    className={`px-2 py-1 rounded-lg border ${selectedStyle}`}
                                    onClick={() =>
                                      toggleFeature(category, cleanedFeature)
                                    }
                                  >
                                    {cleanedFeature}
                                  </button>
                                );
                              })}
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
      {editable && (
        <div className="flex justify-end space-x-4 mt-2">
          {/* <button className="cancel-btn">
                    <XMarkIcon className="h-5 w-5 text-black-500 mr-2" />
                    <span>Cancel</span>
                </button> */}
          <button className="save-btn" onClick={() => setShowModal(true)}>
            {/* <CheckIcon className="h-5 w-5 text-black-500 mr-2" /> */}
            <span>Submit</span>
          </button>
        </div>
      )}
      {showModal && (
        <Modal
          title="Confirmation"
          open={showModal}
          onOk={handleConfirmSave}
          onCancel={handleCancelSave}
          centered
        >
          <p>Are you Sure you Want to Submit the Data</p>
        </Modal>
      )}
    </div>
  );
};

export default UserRole;
