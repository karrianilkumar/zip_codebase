// app/createUser/page.tsx

"use client";
import React, { useEffect, useState } from 'react';
import dynamic from 'next/dynamic';
import { useSidebarStore } from '@/app/stores/navBarStore';
import Page from '../page';
import { useUserStore } from './createUserStore';
import { Tooltip } from 'antd';
import { InformationCircleIcon } from '@heroicons/react/24/outline';
import { CloseOutlined } from '@ant-design/icons';
import { useAuth } from '@/app/components/auth_context';

// Dynamically import the UserInfo and TenantInfo components
const UserInfo = dynamic(() => import('./userInfo'));
const TenantInfo = dynamic(() => import('./tenantInfo'));
const UserRole = dynamic(() => import('./userrole'));

interface CreateUserProps {
  isPopup?: boolean;
  row?: any;
  editable?: boolean;
  isSmallScreen?:boolean;
  onClose: () => void;
}

const CreateUser: React.FC<CreateUserProps> = ({ isPopup, row, editable, isSmallScreen, onClose }) => {
  const [activeTab, setActiveTab] = useState('userInfo');
  const isExpanded = useSidebarStore((state: any) => state.isExpanded);
  const [hideCreateUser, setHideCreateUser] = useState(false);
  const [rowData, setRowData] = useState<any>(row)
  const { role } = useAuth();
  const [pageKey, setPageKey] = useState(0);
  const {
    tenant,
    role_name,
    sub_tenant,
    user_name,
    setTenant,
    setRoleName,
    setSubTenant,
    isUserInfoSubmitted,
    isUserRoleSubmitted,
    setIsUserInfoSubmitted,
    setIsUserRoleSubmitted
  } = useUserStore();
  useEffect(() => {
    setActiveTab('userInfo')
  }, [rowData]);

  const getIsEditable = () => {
    if (editable === undefined || editable === true) {
      return true
    }
    else {
      return false
    }
  };

  const handleCloseClick = () => {
    if (isSmallScreen) { 
    setPageKey(prev => prev + 1);
      console.log("pagekey",pageKey)
  }
    setTenant('')
    setSubTenant([])
    setRoleName('')
    // setHideCreateUser(true);
    onClose()
    setIsUserInfoSubmitted(false)
    setIsUserRoleSubmitted(false)
  };

  return (
    <div>
      {hideCreateUser ? (
        <Page key={pageKey}/>
      ) : (
        <div className="">

          <div className={`bg-white shadow-md tabs-color ${(isPopup && !isSmallScreen) ? '' : 'tabs'} ${isExpanded
            ? "left-[250px]"
            : "lg:left-[70px] left-0"
        }`} style={{ zIndex: '98' }}>
            <button
              className={`tab-headings ${activeTab === 'userInfo' ? 'active-tab-heading' : ''}`}
              onClick={() => setActiveTab('userInfo')}
            >
              User Info
            </button>
            <button
              className={`tab-headings ${activeTab === 'userrole' ? 'active-tab-heading' : ''} ${!isUserInfoSubmitted && !rowData ? 'inactive-tab-heading' : ''}`}
              onClick={() => setActiveTab('userrole')}
              disabled={!isUserInfoSubmitted && !rowData}
            >
              Edit User Role
            </button>
            {(role_name?.toLowerCase() !== "super admin") &&
              <button
                className={`tab-headings ${activeTab === 'tenantInfo' ? 'active-tab-heading' : ''} ${(!isUserInfoSubmitted || !isUserRoleSubmitted) && !rowData ? 'inactive-tab-heading' : ''}`}
                onClick={() => setActiveTab('tenantInfo')}
                disabled={(!isUserInfoSubmitted || !isUserRoleSubmitted) && !rowData}
              >
                Customer Info
              </button>
            }
            {(!isPopup || isSmallScreen) && (
              <div className={`absolute ${isSmallScreen?'right-[0%]':'right-[10%]'}  md:right-[5%] top-[5%] md:top-[20%] rounded-full w-[25px] text-[15px] md:text-[20px] flex space-x-4 `}>
                {!isSmallScreen && (
                  <Tooltip title="Submit the below form before moving to the next tab" placement="top">
                  <button>
                    <span>
                      <InformationCircleIcon className="h-6 w-6 text-blue-500" />
                    </span>
                  </button>
                </Tooltip>
                )}
                
                {/* <button
                  className="text-red-500"
                  onClick={handleCloseClick}>X</button> */}
                <CloseOutlined
                  className="text-gray-500 cursor-pointer"
                  onClick={handleCloseClick}
                />

              </div>
            )}


          </div>
          <div className={`shadow-md p-4 ${(isPopup && !isSmallScreen)? '' : 'md:mt-[-10px] pt-[150px] md:pt-[80px] relative z-51'}`} style={{zIndex:51}}>
            {activeTab === 'userInfo' && <UserInfo rowData={rowData} isPopup={isPopup} editable={getIsEditable()} setRowData={setRowData} />}
            {activeTab === 'tenantInfo' && <TenantInfo rowData={rowData} editable={getIsEditable()} setRowData={setRowData} />}
            {activeTab === 'userrole' && <UserRole rowData={rowData} editable={getIsEditable()} setRowData={setRowData} />}
          </div>
        </div>
      )}</div>

  );
};

export default CreateUser;
