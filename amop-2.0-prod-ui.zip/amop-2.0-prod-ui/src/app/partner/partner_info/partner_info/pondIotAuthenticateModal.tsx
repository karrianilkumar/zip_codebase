import React, { useState } from 'react';
import { Modal, Spin } from 'antd';
import { useAuth } from '@/app/components/auth_context';
import { ENV_ROUTES } from '@/app/components/routes/route_constants';
import axios from 'axios';
import { getCurrentDateTime } from '@/app/components/header_constants';

interface PondIotAuthenticateModalProps {
    isOpen: boolean;
    onCancel: () => void;
    connection: string;
    details: any;
    onSave: () => void;
    callSync: () => void;
}

const PondIotAuthenticateModal: React.FC<PondIotAuthenticateModalProps> = ({
    isOpen,
    onCancel,
    connection,
    details,
    onSave,
    callSync
}) => {
    const [isLoading, setIsLoading] = useState(false);
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [verifyPassword, setVerifyPassword] = useState('');
    const [apiKey, setApiKey] = useState('');
    const [distributorId, setDistributorId] = useState('');
    const [authToken, setAuthToken] = useState('');
    const [isConfirmOpen, setIsConfirmOpen] = useState(false);
    const [errors, setErrors] = useState<Record<string, string>>({});
    const {
        username: user_name,
        tenantNames,
        role,
        settabledata,
        setStoredPagination,
        token,
        partner,
        selectedDb,
        metaData,
        firstLastName,
        sessionId,
    } = useAuth();

    const handleValidation = () => {
        const newErrors: Record<string, string> = {};
        if (!username.trim()) newErrors.username = 'Username is mandatory';
        if (!password.trim()) newErrors.password = 'Password is mandatory';
        if (!verifyPassword.trim()) newErrors.verifyPassword = 'Verify Password is mandatory';
        if (!apiKey.trim()) newErrors.apiKey = 'API Key is mandatory';
        if (!distributorId.trim()) newErrors.distributorId = 'Distributor ID is mandatory';
        if (!authToken.trim()) newErrors.authToken = 'Authentication Token is mandatory';
        if (password && verifyPassword && password !== verifyPassword) {
            newErrors.verifyPassword = 'Password does not match';
        }
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = () => {
        if (handleValidation()) {
            setIsConfirmOpen(true);
        }
    };

    const handleConfirmSubmit = async () => {
        setIsConfirmOpen(false);
        if (Object.keys(errors).length > 0) return;

        setIsLoading(true);
        if (details) {
            details["username"] = username;
            details["password"] = password;
            details["oauth2_custom1"] = apiKey;
            details["oauth2_custom2"] = distributorId;
            details["token_value"] = authToken;
            details["modified_by"] = user_name;
            details['modified_date'] = getCurrentDateTime();
        }

        const data = {
            tenant_name: partner || "default_value",
            username: user_name,
            firstLastName: firstLastName,
            path: "/save_integration_details",
            role_based: role,
            parent_module: "Partner",
            module_name: "Partner info",
            partner: partner,
            action: "create",
            table_name: "serviceprovider",
            changed_data: details,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
            ...metaData,
            sessionID: sessionId,
            service_provider_name:connection || ""
        };

        try {
            let url = ENV_ROUTES.MODULE_MANAGEMENT;
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                Modal.error({
                    title: "Submit Error",
                    content: parsedData.message || "An error occurred while saving the data.",
                    centered: true,
                });
            } else {
                callSync()
                Modal.success({
                    title: "Success",
                    content: "Data submitted successfully!",
                });
            }
            handleCancel();
        } catch (error) {
            Modal.error({
                title: "Error",
                content: "There was an error submitting the data.",
            });
        } finally {
            setIsLoading(false);
            onSave()
        }
    };

    const handleCancel = () => {
        onCancel();
        setIsConfirmOpen(false);
    };

    const handleCancelConfirm = () => {
        setIsConfirmOpen(false);
    };

    return (
        <>
            <Modal
                title="Authentication"
                visible={isOpen}
                onCancel={onCancel}
                width={500}
                centered
                footer={
                    <div className="flex justify-center space-x-4">
                        <button onClick={onCancel} className="cancel-btn">
                            Cancel
                        </button>
                        <button className="save-btn" onClick={handleSubmit}>
                            Save
                        </button>
                    </div>
                }
            >
                {isLoading ? (
                    <div className="flex justify-center items-center" style={{ height: "295px" }}>
                        <Spin size="large" />
                    </div>
                ) : (
                    <div className="space-y-4">
                        <div className="flex items-center mb-4">
                            <label className="w-1/4 text-sm font-medium">
                                Username <span className="text-red-500">*</span>
                            </label>
                            <div className="inline w-3/4">
                                <input
                                    type="text"
                                    value={username}
                                    onChange={(e) => setUsername(e.target.value)}
                                    className="input"
                                    placeholder="Enter Username"
                                />
                                {errors.username && (
                                    <div className="text-red-500 text-xs mt-1">{errors.username}</div>
                                )}
                            </div>
                        </div>

                        <div className="flex items-center mb-4">
                            <label className="w-1/4 text-sm font-medium">
                                Password <span className="text-red-500">*</span>
                            </label>
                            <div className="inline w-3/4">
                                <input
                                    type="password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    className="input"
                                    placeholder="Enter Password"
                                />
                                {errors.password && (
                                    <div className="text-red-500 text-xs mt-1">{errors.password}</div>
                                )}
                            </div>
                        </div>

                        <div className="flex items-center mb-4">
                            <label className="w-1/4 text-sm font-medium">
                                Verify Password <span className="text-red-500">*</span>
                            </label>
                            <div className="inline w-3/4">
                                <input
                                    type="password"
                                    value={verifyPassword}
                                    onChange={(e) => setVerifyPassword(e.target.value)}
                                    className="input"
                                    placeholder="Re-enter Password"
                                />
                                {errors.verifyPassword && (
                                    <div className="text-red-500 text-xs mt-1">{errors.verifyPassword}</div>
                                )}
                            </div>
                        </div>

                        <div className="flex items-center mb-4">
                            <label className="w-1/4 text-sm font-medium">
                                API Key <span className="text-red-500">*</span>
                            </label>
                            <div className="inline w-3/4">
                                <input
                                    type="text"
                                    value={apiKey}
                                    onChange={(e) => setApiKey(e.target.value)}
                                    className="input"
                                    placeholder="Enter API Key"
                                />
                                {errors.apiKey && (
                                    <div className="text-red-500 text-xs mt-1">{errors.apiKey}</div>
                                )}
                            </div>
                        </div>

                        <div className="flex items-center mb-4">
                            <label className="w-1/4 text-sm font-medium">
                                Distributor ID <span className="text-red-500">*</span>
                            </label>
                            <div className="inline w-3/4">
                                <input
                                    type="text"
                                    value={distributorId}
                                    onChange={(e) => setDistributorId(e.target.value)}
                                    className="input"
                                    placeholder="Enter Distributor ID"
                                />
                                {errors.distributorId && (
                                    <div className="text-red-500 text-xs mt-1">{errors.distributorId}</div>
                                )}
                            </div>
                        </div>

                        <div className="flex items-center mb-4">
                            <label className="w-1/4 text-sm font-medium">
                                Authentication Token <span className="text-red-500">*</span>
                            </label>
                            <div className="inline w-3/4">
                                <input
                                    type="text"
                                    value={authToken}
                                    onChange={(e) => setAuthToken(e.target.value)}
                                    className="input"
                                    placeholder="Enter Authentication Token"
                                />
                                {errors.authToken && (
                                    <div className="text-red-500 text-xs mt-1">{errors.authToken}</div>
                                )}
                            </div>
                        </div>
                    </div>
                )}
            </Modal>

            <Modal
                title="Confirm Submission"
                visible={isConfirmOpen}
                onCancel={handleCancelConfirm}
                footer={
                    <div className="flex justify-center space-x-4">
                        <button onClick={handleCancelConfirm} className="cancel-btn">
                            Cancel
                        </button>
                        <button className="save-btn" onClick={handleConfirmSubmit}>
                            Confirm
                        </button>
                    </div>
                }
            >
                <p>Are you sure you want to submit the form?</p>
            </Modal>
        </>
    );
};

export default PondIotAuthenticateModal;
