import React, { useState } from 'react';
import { Modal, Spin } from 'antd';
import { ENV_ROUTES } from '@/app/components/routes/route_constants';
import axios from 'axios';
import { getCurrentDateTime } from '@/app/components/header_constants';
import { useAuth } from '@/app/components/auth_context';

interface CereTaxModalProps {
    isOpen: boolean;
    onCancel: () => void;
    connection: string;
    details: any;
    onSave: () => void;
    callSync: () => void;
}

const CereTaxAuthenticateModal: React.FC<CereTaxModalProps> = ({
    isOpen,
    onCancel,
    connection,
    details,
    onSave,
    callSync
}) => {
    const [isLoading, setIsLoading] = useState(false);
    const [apiKey, setApiKey] = useState("");
    const [errors, setErrors] = useState<string>('');
    const [isConfirmOpen, setIsConfirmOpen] = useState(false);
    const {
        username: user_name,
        tenantNames,
        role,
        settabledata,
        setStoredPagination,
        token,
        partner,
        selectedDb,
        metaData,
        firstLastName,
        sessionId,
    } = useAuth();

    const handleValidation = () => {
        if (!apiKey.trim()) {
            setErrors('X-API-Key is mandatory');
            return false;
        }
        setErrors('');
        return true;
    };

    const handleSubmit = () => {
        if (handleValidation()) {
            setIsConfirmOpen(true);
        }
    };

    const handleConfirmSubmit = async () => {
        setIsConfirmOpen(false);
        setIsLoading(true);
        if (details) {

            details["oauth2_custom1"] = apiKey
            details["modified_by"] = user_name
            details['modified_date'] = getCurrentDateTime()
            
        }

        const data = {
            tenant_name: partner || "default_value",
            username: user_name,
            firstLastName: firstLastName,
            path: "/save_integration_details",
            role_based: role,
            parent_module: "Partner",
            module_name: "Partner info",
            partner: partner,
            action: "create",
            table_name: "serviceprovider",
            changed_data: details,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
            ...metaData,
            sessionID: sessionId,
            service_provider_name:connection || ""
        };

        try {
            let url = ENV_ROUTES.MODULE_MANAGEMENT;
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                Modal.error({
                    title: "Submit Error",
                    content:
                        parsedData.message || "An error occurred while saving the data.",
                    centered: true,
                });
            } else {
                callSync()
                Modal.success({
                    title: "Success",
                    content: "Data submitted successfully!",
                });
            }
            handleCancel();
        } catch (error) {
            Modal.error({
                title: "Error",
                content: "There was an error submitting the data.",
            });
        } finally {
            setIsLoading(false);
            onSave()
        }

    };
    const handleCancel = () => {
        onCancel();
        setIsConfirmOpen(false);

    }
    const handleCancelConfirm = () => {
        setIsConfirmOpen(false);
    };

    return (
        <>
            <Modal
                title="CereTax Authentication"
                visible={isOpen}
                onCancel={onCancel}
                footer={
                    <div className="flex justify-center space-x-4">
                        <button onClick={onCancel} className="cancel-btn">
                            Cancel
                        </button>
                        <button className="save-btn" onClick={handleSubmit}>
                            Save
                        </button>
                    </div>
                }
            >
                {isLoading ? (
                    <>
                        <div
                            className="flex justify-center items-center"
                            style={{
                                height: "295px",
                            }}
                        >
                            <Spin size="large" />
                        </div>
                    </>
                ) : (
                    <>
                <div className="space-y-4">
                    <div className="flex items-center mb-4">
                        <label className="w-1/4 text-sm font-medium">
                            X-API-Key <span className="text-red-500">*</span>
                        </label>
                        <div className='inliine w-3/4'>
                        <input
                            type="text"
                            value={apiKey}
                            onChange={(e) => setApiKey(e.target.value)}
                            className="input"
                            placeholder="Enter X-API-Key"
                        />
                        {errors && (
                        <div className="text-red-500 text-xs mt-1">{errors}</div>
                    )}
                        </div>
                        
                    </div>
                    
                </div>
                </>
                )}
            </Modal>

            {/* Confirmation Modal */}
            <Modal
                title="Confirm Submission"
                visible={isConfirmOpen}
                centered
                onCancel={handleCancelConfirm}
                footer={
                    <div className="flex justify-center space-x-4">
                        <button onClick={handleCancelConfirm} className="cancel-btn">
                            Cancel
                        </button>
                        <button className="save-btn" onClick={handleConfirmSubmit}>
                            Confirm
                        </button>
                    </div>
                }
            >
                <p>Are you sure you want to submit the form</p>
            </Modal>
        </>
    );
};

export default CereTaxAuthenticateModal;
