import React, { useEffect, useState } from 'react';
import { Modal, Button, Spin } from 'antd';
import axios from 'axios';
import { ENV_ROUTES } from '@/app/components/routes/route_constants';
import { getCurrentDateTime } from '@/app/components/header_constants';
import { useAuth } from '@/app/components/auth_context';

interface AuthenticateModalProps {
  isOpen: boolean;
  onCancel: () => void;
  connection: string;
  details: any;
  onSave: () => void;
  callSync: () => void;
}

const AuthenticateModal: React.FC<AuthenticateModalProps> = ({
  isOpen,
  onCancel,
  connection,
  details,
  onSave,
  callSync
}) => {
  const [isLoading, setIsLoading] = useState(false);
  const [apiUsername, setApiUsername] = useState('');
  const [apiPassword, setApiPassword] = useState('');
  const [verifyApiPassword, setVerifyApiPassword] = useState('');
  const [uiUsername, setUiUsername] = useState('');
  const [uiPassword, setUiPassword] = useState('');
  const [verifyUiPassword, setVerifyUiPassword] = useState('');
  const [emailAddress, setEmailAddress] = useState('');
  const [emailAlias, setEmailAlias] = useState('');
  const [emailPassword, setEmailPassword] = useState('');
  const [verifyEmailPassword, setVerifyEmailPassword] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [showConfirmation, setShowConfirmation] = useState(false);
  const {
    username,
    tenantNames,
    role,
    settabledata,
    setStoredPagination,
    token,
    partner,
    selectedDb,
    metaData,
    firstLastName,
    sessionId,
  } = useAuth();


  // useEffect(() => {
  //   const settings = details.settings || []

  //   //Set API Username
  //   if (connection.toLocaleLowerCase() === 'at&t - cisco jasper') {
  //     const api_username_obj = settings.find((item: any) => {
  //       return item.setting_key === "JasperApiUsername"
  //     })
  //     const api_username = api_username_obj?.setting_value || ''
  //     setApiUsername(api_username)

  //     //Set API Password
  //     const api_pswd_obj = settings.find((item: any) => {
  //       return item.setting_key === 'JasperApiPassword'
  //     })
  //     const api_pswd = api_pswd_obj?.setting_value || ''
  //     setApiPassword(api_pswd)
  //     setVerifyApiPassword(api_pswd)

  //   }
  //   else {
  //     setApiUsername(details?.username || '')
  //     setApiPassword(details?.password || '')
  //     setApiPassword(details?.password || '')
  //   }

  //   //Set UI Username
  //   const ui_username_obj = settings.find((item: any) => {
  //     return item.setting_key === 'JasperUiUsername'
  //   })
  //   const ui_username = ui_username_obj?.setting_value || ''
  //   setUiUsername(ui_username)

  //   //Set UI Password
  //   const ui_pswd_obj = settings.find((item: any) => {
  //     return item.setting_key === 'JasperUiPassword'
  //   })
  //   const ui_pswd = ui_pswd_obj?.setting_value || ''
  //   setUiPassword(ui_pswd)
  //   setVerifyUiPassword(ui_pswd)

  //   //Set Email Address
  //   const email_address_obj = settings.find((item: any) => {
  //     return item.setting_key === 'JasperExportMailboxUsername'
  //   })
  //   const email_address = email_address_obj?.setting_value || ''
  //   setEmailAddress(email_address)

  //   //Set Email Alias
  //   const email_alias_obj = settings.find((item: any) => {
  //     return item.setting_key === 'JasperExportMailboxAlias'
  //   })
  //   const email_alias = email_alias_obj?.setting_value || ''
  //   setEmailAlias(email_alias)

  //   //Set Email Password
  //   const email_pswd_obj = settings.find((item: any) => {
  //     return item.setting_key === 'JasperExportMailboxPassword'
  //   })
  //   const email_pswd = email_pswd_obj?.setting_value || ''
  //   setEmailPassword(email_pswd)
  //   setVerifyEmailPassword(email_pswd)

  // }, []);

  const validateFields = () => {
    const newErrors: Record<string, string> = {};

    if (!apiUsername.trim()) newErrors.apiUsername = 'API Username is required';
    if (!apiPassword.trim()) newErrors.apiPassword = 'API Password is required';
    if (apiPassword !== verifyApiPassword)
      newErrors.verifyApiPassword = 'Password does not match';
    if (!uiUsername.trim()) newErrors.uiUsername = 'UI Username is required';
    if (!uiPassword.trim()) newErrors.uiPassword = 'UI Password is required';
    if (uiPassword !== verifyUiPassword)
      newErrors.verifyUiPassword = 'Password does not match';
    if (!emailAddress.trim()) newErrors.emailAddress = 'Email Address is required';
    if (!emailAlias.trim()) newErrors.emailAlias = 'Email Alias is required';
    if (!emailPassword.trim()) newErrors.emailPassword = 'Email Password is required';
    if (emailPassword !== verifyEmailPassword)
      newErrors.verifyEmailPassword = 'Password does not match';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (validateFields()) {
      setShowConfirmation(true);
    }
  };

  const confirmSubmit = async () => {
    console.log('Submitted with:', {
      apiUsername,
      uiUsername,
      emailAddress,
      emailAlias,
    });
    setShowConfirmation(false);
    // const errors = validateFields();
    // setErrors(errors);
    // If errors exist, abort the save process
    if (Object.keys(errors).length > 0) {
      return;
    }
    setIsLoading(true);
    const url = ENV_ROUTES.MODULE_MANAGEMENT;

    // Update settings in details object
    const updatedSettings = details.settings.map((item: any) => {
      switch (item.setting_key) {
        case "JasperApiUsername":
          if (connection.toLocaleLowerCase() === 'at&t - cisco jasper') {
            return { ...item, setting_value: apiUsername };
          }
          else {
            return { ...item }
          }
        case "JasperApiPassword":
          if (connection.toLocaleLowerCase() === 'at&t - cisco jasper') {
            return { ...item, setting_value: apiPassword };
          }
          else {
            return { ...item }
          }
        case "JasperUiUsername":
          return { ...item, setting_value: uiUsername };
        case "JasperUiPassword":
          return { ...item, setting_value: uiPassword };
        case "JasperExportMailboxUsername":
          return { ...item, setting_value: emailAddress };
        case "JasperExportMailboxAlias":
          return { ...item, setting_value: emailAlias };
        case "JasperExportMailboxPassword":
          return { ...item, setting_value: emailPassword };
        default:
          return item;
      }
    });

    if (connection.toLocaleLowerCase() !== 'at&t - cisco jasper') {
      details['username'] = apiUsername;
      details['password'] = apiPassword;
    }
    details["modified_by"] = username
    details['modified_date'] = getCurrentDateTime()

    const updatedDetails = { ...details, settings: updatedSettings };


    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/save_integration_details",
      role_based: role,
      parent_module: "Partner",
      module_name: "Partner info",
      partner: partner,
      action: "create",
      table_name: "serviceprovider",
      changed_data: updatedDetails,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
      service_provider_name:connection || "" 
    };

    try {
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: "Submit Error",
          content:
            parsedData.message || "An error occurred while saving the data.",
          centered: true,
        });
      } else {
        callSync()
        Modal.success({
          title: "Success",
          content: "Data submitted successfully!",
        });
      }
      handlecancel();
    } catch (error) {
      Modal.error({
        title: "Error",
        content: "There was an error submitting the data.",
      });
    } finally {
      setIsLoading(false);
      onSave()
    }
  };
  const handlecancel = () => {
    resetform()
    onCancel();

  }
  const resetform = () => {
    setApiUsername("")
    setApiPassword("")
    setVerifyApiPassword("")
    setUiUsername("")
    setUiPassword("")
    setEmailAddress("")
    setEmailAlias("")
    setEmailPassword("")
    setVerifyEmailPassword("")
  }

  return (
    <>
      <Modal
        title="Authentication"
        visible={isOpen}
        onCancel={onCancel}
        centered
        footer={
          <div className="flex justify-center">
            <button onClick={handlecancel} className="mr-2 cancel-btn">
              Cancel
            </button>
            <button className="save-btn" onClick={handleSubmit}>
              Save
            </button>
          </div>
        }
        width={600}
        bodyStyle={{
          maxHeight: '60vh',
          overflowY: 'auto',
          marginTop: '20px',
          marginBottom: '20px',
          paddingRight: '5px'
        }}
      >
        {isLoading ? (
          <>
            <div
              className="flex justify-center items-center"
              style={{
                height: "295px",
              }}
            >
              <Spin size="large" />
            </div>
          </>
        ) : (
          <>
            <div>
              <h3 className="font-semibold text-lg mb-4">API Credentials</h3>

              {/* API Username */}
              <div className="grid grid-cols-12 items-center gap-4 mb-4">
                <label className="col-span-4 text-sm font-medium">
                  API Username <span className="text-red-500">*</span>
                </label>
                <div className="col-span-8">
                  <input
                    type="text"
                    value={apiUsername}
                    onChange={(e) => setApiUsername(e.target.value)}
                    className="w-full border rounded px-3 py-2 input"
                    placeholder="Enter API Username"
                  />
                  {errors.apiUsername && (
                    <div className="text-red-500 text-xs mt-1">{errors.apiUsername}</div>
                  )}
                </div>
              </div>

              {/* API Password */}
              <div className="grid grid-cols-12 items-center gap-4 mb-4">
                <label className="col-span-4 text-sm font-medium">
                  API Password <span className="text-red-500">*</span>
                </label>
                <div className="col-span-8">
                  <input
                    type="password"
                    value={apiPassword}
                    onChange={(e) => setApiPassword(e.target.value)}
                    className="w-full border rounded px-3 py-2 input"
                    placeholder="Enter API Password"
                  />
                  {errors.apiPassword && (
                    <div className="text-red-500 text-xs mt-1">{errors.apiPassword}</div>
                  )}
                </div>
              </div>

              {/* Verify API Password */}
              <div className="grid grid-cols-12 items-center gap-4 mb-4">
                <label className="col-span-4 text-sm font-medium">
                  Verify API Password <span className="text-red-500">*</span>
                </label>
                <div className="col-span-8">
                  <input
                    type="password"
                    value={verifyApiPassword}
                    onChange={(e) => setVerifyApiPassword(e.target.value)}
                    className="w-full border rounded px-3 py-2 input"
                    placeholder="Re-enter API Password"
                  />
                  {errors.verifyApiPassword && (
                    <div className="text-red-500 text-xs mt-1">{errors.verifyApiPassword}</div>
                  )}
                </div>
              </div>

              <h3 className="font-semibold text-lg mt-6 mb-4">UI Credentials</h3>

              {/* UI Username */}
              <div className="grid grid-cols-12 items-center gap-4 mb-4">
                <label className="col-span-4 text-sm font-medium">
                  UI Username <span className="text-red-500">*</span>
                </label>
                <div className="col-span-8">
                  <input
                    type="text"
                    value={uiUsername}
                    onChange={(e) => setUiUsername(e.target.value)}
                    className="w-full border rounded px-3 py-2 input"
                    placeholder="Enter UI Username"
                  />
                  {errors.uiUsername && (
                    <div className="text-red-500 text-xs mt-1">{errors.uiUsername}</div>
                  )}
                </div>
              </div>

              {/* UI Password */}
              <div className="grid grid-cols-12 items-center gap-4 mb-4">
                <label className="col-span-4 text-sm font-medium">
                  UI Password <span className="text-red-500">*</span>
                </label>
                <div className="col-span-8">
                  <input
                    type="password"
                    value={uiPassword}
                    onChange={(e) => setUiPassword(e.target.value)}
                    className="w-full border rounded px-3 py-2 input"
                    placeholder="Enter UI Password"
                  />
                  {errors.uiPassword && (
                    <div className="text-red-500 text-xs mt-1">{errors.uiPassword}</div>
                  )}
                </div>
              </div>

              {/* Verify UI Password */}
              <div className="grid grid-cols-12 items-center gap-4 mb-4">
                <label className="col-span-4 text-sm font-medium">
                  Verify UI Password <span className="text-red-500">*</span>
                </label>
                <div className="col-span-8">
                  <input
                    type="password"
                    value={verifyUiPassword}
                    onChange={(e) => setVerifyUiPassword(e.target.value)}
                    className="w-full border rounded px-3 py-2 input"
                    placeholder="Re-enter UI Password"
                  />
                  {errors.verifyUiPassword && (
                    <div className="text-red-500 text-xs mt-1">{errors.verifyUiPassword}</div>
                  )}
                </div>
              </div>

              <h3 className="font-semibold text-lg mt-6 mb-4">Email Credentials</h3>

              {/* Email Address */}
              <div className="grid grid-cols-12 items-center gap-4 mb-4">
                <label className="col-span-4 text-sm font-medium">
                  Email Address <span className="text-red-500">*</span>
                </label>
                <div className="col-span-8">
                  <input
                    type="email"
                    value={emailAddress}
                    onChange={(e) => setEmailAddress(e.target.value)}
                    className="w-full border rounded px-3 py-2 input"
                    placeholder="Enter Email Address"
                  />
                  {errors.emailAddress && (
                    <div className="text-red-500 text-xs mt-1">{errors.emailAddress}</div>
                  )}
                </div>
              </div>

              {/* Email Alias */}
              <div className="grid grid-cols-12 items-center gap-4 mb-4">
                <label className="col-span-4 text-sm font-medium">
                  Email Alias <span className="text-red-500">*</span>
                </label>
                <div className="col-span-8">
                  <input
                    type="text"
                    value={emailAlias}
                    onChange={(e) => setEmailAlias(e.target.value)}
                    className="w-full border rounded px-3 py-2 input"
                    placeholder="Enter Email Alias"
                  />
                  {errors.emailAlias && (
                    <div className="text-red-500 text-xs mt-1">{errors.emailAlias}</div>
                  )}
                </div>
              </div>

              {/* Email Password */}
              <div className="grid grid-cols-12 items-center gap-4 mb-4">
                <label className="col-span-4 text-sm font-medium">
                  Email Password <span className="text-red-500">*</span>
                </label>
                <div className="col-span-8">
                  <input
                    type="password"
                    value={emailPassword}
                    onChange={(e) => setEmailPassword(e.target.value)}
                    className="w-full border rounded px-3 py-2 input"
                    placeholder="Enter Email Password"
                  />
                  {errors.emailPassword && (
                    <div className="text-red-500 text-xs mt-1">{errors.emailPassword}</div>
                  )}
                </div>
              </div>

              {/* Verify Email Password */}
              <div className="grid grid-cols-12 items-center gap-4 mb-4">
                <label className="col-span-4 text-sm font-medium">
                  Verify Email Password <span className="text-red-500">*</span>
                </label>
                <div className="col-span-8">
                  <input
                    type="password"
                    value={verifyEmailPassword}
                    onChange={(e) => setVerifyEmailPassword(e.target.value)}
                    className="w-full border rounded px-3 py-2 input"
                    placeholder="Re-enter Email Password"
                  />
                  {errors.verifyEmailPassword && (
                    <div className="text-red-500 text-xs mt-1">{errors.verifyEmailPassword}</div>
                  )}
                </div>
              </div>
            </div>
          </>
        )}
      </Modal>

      <Modal
        title="Confirm Submission"
        visible={showConfirmation}
        centered
        onCancel={() => setShowConfirmation(false)}
        footer={
          <div className="flex justify-center">
            <Button onClick={() => setShowConfirmation(false)} className="mr-2 cancel-btn">
              Cancel
            </Button>
            <Button className="save-btn" onClick={confirmSubmit}>
              Confirm
            </Button>
          </div>
        }
      >
        <p>Are you sure you want to submit the form?</p>
      </Modal>
    </>
  );
};

export default AuthenticateModal;
