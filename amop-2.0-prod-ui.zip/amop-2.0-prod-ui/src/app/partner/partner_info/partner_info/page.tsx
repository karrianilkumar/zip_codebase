"use client";
import React, { useState, useEffect, useRef, useCallback } from "react";
import { useLogoStore } from "@/app/stores/logoStore";
import EmailModal from "../EmailModal";
import { Checkbox, Modal, notification, Spin, Switch } from "antd";
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import { usePartnerStore } from "../partnerStore";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { useUserStore } from "../users/createUser/createUserStore";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import Select, { SingleValue } from "react-select";
import {
  NonEditableDropdownStyles,
  DropdownStyles,
} from "@/app/components/css/dropdown";
import moment from "moment-timezone";
import TableComponent from "@/app/components/TableComponent/page";
import { CheckCircleIcon, ChevronDownIcon, ChevronUpIcon, PlusCircleIcon, PlusIcon, XCircleIcon } from "@heroicons/react/24/outline";
import AddServiceProvider from "./addServiceProviderPopup";
import AuthenticateModal from "./authenticateModal";
import TelegenceAuthenticateModal from "./telegenceAuthenticateModal";
import DefaultAuthenticateModal from "./defaultAuthenticateModal";
import BandwidthAuthenticateModal from "./bandwidthAuthenticateModal";
import CereTaxAuthenticateModal from "./cereTaxModal";
import CyberReefAuthenticateModal from "./cyberReefAuthenticateModal";
import PondIotAuthenticateModal from "./pondIotAuthenticateModal";
import QualificationAuthenticateModal from "./qualificationAuthenticateModal";
import RevIotAuthenticateModal from "./revIoAuthenticateModal";
import KoreAuthenticateModal from "./koreAuthenticateModal";
import WebbingAuthenticateModal from "./webbingAuthenticateModal";

interface PartnerInfo {
  onSubmit: () => void;
}

const apiConnections = [
  { label: "AT&T - Cisco Jasper", authenticated: true },
  { label: "AT&T - POD19", authenticated: true },
  { label: "AT&T - Telegence - UAT ONLY", authenticated: true },
  { label: "Bandwidth.com", authenticated: false },
  { label: "CereTax", authenticated: true },
  { label: "CyberReef", authenticated: false },
  { label: "Intrado E911", authenticated: true },
  { label: "NetSapiens", authenticated: false },
  { label: "T-Mobile - Advantage", authenticated: false },
  { label: "T-Mobile Jasper", authenticated: true },
  { label: "Rogers Sandbox", authenticated: true },
  { label: "POND IoT", authenticated: false },
  { label: "Qualification", authenticated: true },
  { label: "Rev.IO", authenticated: true },
  { label: "Teal", authenticated: true },
  { label: "Verizon - ThingSpace IoT", authenticated: true },
  { label: "Verizon - ThingSpace PN", authenticated: true },

];

const PartnerInfo: React.FC<PartnerInfo> = ({ onSubmit }) => {
  // const timezoneOptions = moment.tz.names().map((timezone) => {
  //   const abbreviation = moment().tz(timezone).format('zz');
  //   const currentTime = moment().tz(timezone).format('HH:mm:ss');
  //   const [countryName, cityName] = timezone.split('/');
  //   const formattedCountryName = cityName ? `${countryName} / ${cityName}` : countryName;
  //   return {
  //     value: `(${abbreviation} +${currentTime}) ${formattedCountryName}`,
  //     label: `(${abbreviation} +${currentTime}) ${formattedCountryName}`,
  //   };
  // });
  const [logoError, setLogoError] = useState<string | null>(null);
  const [collapsedLogoError, setCollapsedLogoError] = useState<string | null>(null);
  const [darkModeCollapsedLogoError, setDarkModeCollapsedLogoError] = useState<string | null>(null);
  const [darkModeLogoError, setDarkModeLogoError] = useState<string | null>(null);
  const [emailError, setEmailError] = useState<string | null>(null);
  const [submitModalOpen, setSubmitModalOpen] = useState(false);
  const [logoModalOpen, setLogoModalOpen] = useState(false);
  const [isLogoUpdated, setIsLogoUpdated] = useState(false);
  const [emailList, setEmailList] = useState<string[]>([]);
  const [emailInput, setEmailInput] = useState<string>("");
  const [isEmailModalOpen, setIsEmailModalOpen] = useState<boolean>(false);
  const { username, partner, role, token, selectedDb,metaData, settabledata, firstLastName, sessionId, setLogoUrl, setCollapsedLogoUrl, setDarkModeLogoUrl, setDarkModeCollapsedLogoUrl } = useAuth();
  const { partnerData, setPartnerInfo, setPartnerUsers, setCustomerGroups } = usePartnerStore.getState();
  const [emails, setEmails] = useState<string | null>("");
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
  const partnerInfo =
    partnerData?.["Partner info"]?.data?.["Partner info"] || {};
  const {
    tenant,
    role_name,
    sub_tenant,
    user_name,
    setTenant,
    setRoleName,
    setSubTenant,
    emailsList,
    setEmailsList,
  } = useUserStore();
  const provider_options = ["Yes", "No"];
  const [serviceProvider, setServiceProvider] = useState<string | null>(null);
  const [serviceProviderError, setServiceProviderError] = useState<string>("");
  let logoUrl_: string;
  let collapsedLogoUrl_: string;
  let darkModeCollapsedLogoUrl_: string;
  let darkModeLogoUrl_: string;
  // const { setLogoUrl, logoUrl } = useLogoStore();
  const logoFileRef = useRef<HTMLInputElement>(null);
  const collapsedLogoFileRef = useRef<HTMLInputElement>(null);
  const darkModeCollapsedLogoFileRef = useRef<HTMLInputElement>(null);
  const darkModeLogoFileRef = useRef<HTMLInputElement>(null);
  const [providerToError, setProviderToError] = useState<string>("");
  const [tenantOptions, setTenantOptions] = useState<any[]>([]);
  const [providerTo, setProviderTo] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [fromEmail, setFromEmail] = useState(partnerInfo.from_email || "");
  const [sendgridApi, setSendgridApi] = useState(partnerInfo.sendgrid_api || "");
  const [fromEmailError, setFromEmailError] = useState("");

  // state for add service provider table
  const [addServiceVisibleColumns, setAddServiceVisibleColumns] = useState<
    string[]
  >([]);
  const [addServicePagination, setAddServicePagination] = useState<any>({});
  const [addServiceTableData, setAddServiceTableData] = useState<any>([]);
  const [addServiceHeaders, setAddServiceHeaders] = useState<any[]>([]);
  const [addServiceHeaderMap, setAddServiceHeaderMap] = useState<any>({});
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<string[]>([]);

  // State for billing address fields
  const [billingAddress1, setBillingAddress1] = useState("");
  const [billingAddress2, setBillingAddress2] = useState("");
  const [billingCity, setBillingCity] = useState("");
  const [billingState, setBillingState] = useState("");
  const [billingZip, setBillingZip] = useState("");
  const [billingZipError, setBillingZipError] = useState<string>("");
  const [billingNotes, setBillingNotes] = useState("");
  // const [
  //   crossProviderCustomerOptimization,
  //   setCrossProviderCustomerOptimization,
  // ] = useState(false);

  // State for physical address fields
  const [physicalAddress1, setPhysicalAddress1] = useState("");
  const [physicalAddress2, setPhysicalAddress2] = useState("");
  const [physicalApt, setPhysicalApt] = useState("");
  const [physicalCity, setPhysicalCity] = useState("");
  const [physicalState, setPhysicalState] = useState("");
  const [physicalZip, setPhysicalZip] = useState("");
  const [physicalZipError, setphysicalZipError] = useState<string>("");
  const [physicalCounty, setPhysicalCounty] = useState("");
  const [physicalCountry, setPhysicalCountry] = useState("");
  const [selectedTimezone, setSelectedTimezone] = useState("");
  const [timezoneOptions, setTimezoneOptions] = useState<
    { value: string; label: string }[]
  >([]);
  const [isPopupVisible, setIspopupVisible] = useState(false);

  //Authenticate popup variables
  const [isAuthenticateVisible, setIsAuthenticateVisible] = useState(false);
  const [isTelegenceAuthenticate, setIsTelegenceAuthenticate] = useState(false);
  const [isKoreAuthenticate, setIsKoreAuthenticate] = useState(false);
  const [isWebbingAuthenticate, setIsWebbingAuthenticate] = useState(false);
  const [isBandwidthAuthenticate, setIsBandwidthAuthenticate] = useState(false);
  const [isCereTaxAuthenticate, setIsCereTaxAuthenticate] = useState(false);
  const [isCyberReefAuthenticate, setIsCyberReefAuthenticate] = useState(false);
  const [isPondIOTAuthenticate, setIsPondIOTAuthenticate] = useState(false);
  const [isQualificationAuthenticate, setIsQualificationAuthenticate] = useState(false);
  const [isRevIOAuthenticate, setIsRevIOAuthenticate] = useState(false);
  const [isDefaultAuthenticate, setIsDefaultAuthenticate] = useState(false);
  const [selectedConncetion, setSelectedConnection] = useState<string>("");
  const [apiConnections, setApiConnections] = useState<any[]>([]);
  const [integrationDetails, setIntegrationDetails] = useState<any[]>([]);
  const [selectedIntegrationDetail, setSelectedIntegrationDetail] = useState<any>({});

  const isAgentPartnerAdmin = role?.toLowerCase() === "agent partner admin"
  const [phoneNumberFrequency, setphoneNumberFrequency] = useState<number>(3);

  const storedLogo: any = localStorage.getItem('logo');
  const storedCollapsedLogo: any = localStorage.getItem('collapsed_logo');
  const storedDarkModeCollapsedLogo: any = localStorage.getItem('dark_mode_collapsed_logo');
  const storedDarkModeLogo: any = localStorage.getItem('dark_mode_logo');

  const [openSections, setOpenSections] = useState<{
    [key: string]: boolean;
  }>({});

  const toggleSections = (key: string) => {
    setOpenSections((prev) => ({
      ...prev,
      [key]: !openSections[key]
    }));
  }

  useEffect(() => {
    let email_list = Array.isArray(partnerInfo?.email_id)
      ? partnerInfo.email_id
      : [];
    if (JSON.stringify(emailList) !== JSON.stringify(email_list)) {
      setEmailList(email_list);
      setEmailsList(email_list);
    }
    const service_provider_to = partnerInfo?.service_provider_to || "";
    setProviderTo(service_provider_to);
    const service_provider_status = partnerInfo?.service_provider_status
      ? "Yes"
      : "No";
    setServiceProvider(service_provider_status);

    const tenant_names = partnerInfo?.tenant_names || [];
    setTenantOptions(tenant_names);

    const billing_address_1 = partnerInfo?.billing_address_1 || "";
    setBillingAddress1(billing_address_1);
    const billing_address_2 = partnerInfo?.billing_address_2 || "";
    setBillingAddress2(billing_address_2);
    const billing_city = partnerInfo?.billing_city || "";
    setBillingCity(billing_city);
    const billing_state = partnerInfo?.billing_state || "";
    setBillingState(billing_state);
    const billing_zip_code = partnerInfo?.billing_zip_code || "";
    setBillingZip(billing_zip_code);
    const billing_notes = partnerInfo?.billing_notes || "";
    setBillingNotes(billing_notes);
    const cross_provider_customer_optimization =
      partnerInfo?.cross_provider_customer_optimization || "";
    // setCrossProviderCustomerOptimization(cross_provider_customer_optimization);
    const physical_address_1 = partnerInfo?.physical_address_1 || "";
    setPhysicalAddress1(physical_address_1);
    const physical_addresss_2 = partnerInfo?.physical_addresss_2 || "";
    setPhysicalAddress2(physical_addresss_2);
    const physical_apt_or_suite = partnerInfo?.physical_apt_or_suite || "";
    setPhysicalApt(physical_apt_or_suite);
    const physical_city = partnerInfo?.physical_city || "";
    setPhysicalCity(physical_city);
    const physical_state = partnerInfo?.physical_state || "";
    setPhysicalState(physical_state);
    const physical_zip_code = partnerInfo?.physical_zip_code || "";
    setPhysicalZip(physical_zip_code);
    const physical_country = partnerInfo?.physical_country || "";
    setPhysicalCountry(physical_country);
    const physical_county = partnerInfo?.physical_county || "";
    setPhysicalCounty(physical_county);
    const time_zone = partnerInfo?.time_zone || "";
    setSelectedTimezone(time_zone);
    const initial_ph_no_frequency = partnerInfo?.change_phone_number_frequency_setting
    console.log("initial_ph_no_frequency", initial_ph_no_frequency)
    setphoneNumberFrequency(
      initial_ph_no_frequency && initial_ph_no_frequency !== "None"
        ? Number(initial_ph_no_frequency)
        : 3
    );
  }, []);

  //Time zone
  useEffect(() => {
    const timezoneNames = moment.tz.names();
    const options = timezoneNames.map((timezone) => {
      const abbreviation = moment().tz(timezone).format("zz");
      const currentTime = moment().tz(timezone).format("HH:mm:ss");
      const [countryName, cityName] = timezone.split("/");
      const formattedCountryName = cityName
        ? `${countryName} / ${cityName}`
        : countryName;
      return {
        value: timezone,
        label: `(${abbreviation} +${currentTime}) ${formattedCountryName}`,
      };
    });
    setTimezoneOptions(options);
  }, []);

  useEffect(() => {
    const timeZoneFromResponse = partnerInfo?.time_zone || "";
    setSelectedTimezone(timeZoneFromResponse);
    const from_email = partnerInfo.from_email || ""
    setFromEmail(from_email)
    const sendgrid_api = partnerInfo.sendgrid_api || ""
    setSendgridApi(sendgrid_api)
  }, [partnerInfo]);
  useEffect(() => {
    const intervalId = setInterval(() => {
      setTimezoneOptions((prevOptions) =>
        prevOptions.map((option) => {
          const abbreviation = moment().tz(option.value).format("zz");
          const currentTime = moment().tz(option.value).format("HH:mm:ss");
          return {
            ...option,
            label: `(${abbreviation} +${currentTime}) ${option.label.split(") ")[1]
              }`,
          };
        })
      );
    }, 1000);

    return () => clearInterval(intervalId);
  }, []);

  type HeaderMap = Record<string, [string, number]>;
  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);

  // Effect to handle rowData changes (if required)
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        settabledata([])
        const url = ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/service_provider_list_view",
          role_name: role,
          parent_module: "Partner",
          feature_module_name: "Partner Info",
          mod_pages: {
            start: 0,
            end: 100,
          },
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
        ... metaData,
          sessionID: sessionId,
        };
        console.log(getCurrentDateTime(), "Show the log time request sent from ui to lambda");
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        console.log(getCurrentDateTime(), "Show the log time response sent from lambda to ui");
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const headersMap_ =
            parsedData?.headers_map?.["Service Provider"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setAddServiceHeaderMap(sortedheaderMap);
          const headers_ =
            Object.keys(sortedheaderMap).length > 0
              ? Object.keys(sortedheaderMap)
              : [];
          setAddServiceHeaders(headers_)
          setAddServiceVisibleColumns(headers_);
          const tableData_ = parsedData?.data || [];
          setAddServiceTableData(tableData_);
          const features_ =
            parsedData?.headers_map?.["Service Provider"]?.module_features ||
            [];
          setFeatures(features_);
          const allowedActions_: any = []
          if (features_.includes("Edit-Partner info")) {
            allowedActions_.push("editServiceProvider")
          }
          if (features_.includes("Delete-Partner info")) {
            allowedActions_.push("delete")
          }
          setAllowedActions(allowedActions_)

          const pagination_ = parsedData?.pages || {};
          setAddServicePagination(pagination_);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        Modal.error({
          title: "Data Fetch Error",
          content:
            error instanceof Error
              ? error.message
              : "An unexpected error occurred while fetching data. Please try again.",
          centered: true,
        });
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const fetchAuthenticateData = async () => {
    setLoading(true);
    try {
      settabledata([])
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_integration_data",
        role_name: role,
        parent_module: "Partner",
        feature_module_name: "Partner Info",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching API Connections data. Please try again.",
          centered: true,
        });
      } else {
        const connections = parsedData?.connections || [];
        setApiConnections(connections);
        const intergation_details = parsedData?.intergation_details || [];
        setIntegrationDetails(intergation_details);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchAuthenticateData()
  }, []);


  const handleLogoUpdate = () => {
    let isValid = true;
    const file = logoFileRef.current?.files?.[0];
    if (file) {
      console.log("file", file);
      const validTypes = ["image/png", "image/jpeg"];
      if (!validTypes.includes(file.type)) {
        setLogoError("Only .png and .jpg files are allowed.");
        isValid = false;
      } else if (file.size > 50000000) {
        setLogoError("File size must be less than 50 MB.");
        isValid = false;
      } else {
        setLogoError("");
      }
    }
    const collapsed_file = collapsedLogoFileRef.current?.files?.[0];
    if (collapsed_file) {
      console.log("file", collapsed_file);
      const validTypes = ["image/png", "image/jpeg"];
      if (!validTypes.includes(collapsed_file.type)) {
        setCollapsedLogoError("Only .png and .jpg files are allowed.");
        isValid = false;
      } else if (collapsed_file.size > 50000000) {
        setCollapsedLogoError("File size must be less than 50 MB.");
        isValid = false;
      } else {
        setCollapsedLogoError("");
      }
    }

    const dark_mode_collapsed_file = darkModeCollapsedLogoFileRef.current?.files?.[0];
    if (dark_mode_collapsed_file) {
      console.log("file", dark_mode_collapsed_file);
      const validTypes = ["image/png", "image/jpeg"];
      if (!validTypes.includes(dark_mode_collapsed_file.type)) {
        setDarkModeCollapsedLogoError("Only .png and .jpg files are allowed.");
        isValid = false;
      } else if (dark_mode_collapsed_file.size > 50000000) {
        setDarkModeCollapsedLogoError("File size must be less than 50 MB.");
        isValid = false;
      } else {
        setDarkModeCollapsedLogoError("");
      }
    }
    const darkmode_logo_file = darkModeLogoFileRef.current?.files?.[0];
    if (darkmode_logo_file) {
      console.log("file", darkmode_logo_file);
      const validTypes = ["image/png", "image/jpeg"];
      if (!validTypes.includes(darkmode_logo_file.type)) {
        setDarkModeLogoError("Only .png and .jpg files are allowed.");
        isValid = false;
      } else if (darkmode_logo_file.size > 50000000) {
        setDarkModeLogoError("File size must be less than 50 MB.");
        isValid = false;
      } else {
        setDarkModeLogoError("");
      }
    }
    if (isValid) {
      if (file || collapsed_file || darkmode_logo_file || dark_mode_collapsed_file) {
        setIsLogoUpdated(true)
      }
      setLogoModalOpen(false);
    }
  }

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    let isValid = true;
    if (billingZip) {
      const regex = /^\d{5}$/; // Only 5 numerical values

      if (!regex.test(billingZip)) {
        setBillingZipError("Zip code must be exactly 5 digits");
        isValid = false;
      } else {
        setBillingZipError("");
      }
    }
    if (physicalZip) {
      const regex = /^\d{5}$/; // Only 5 numerical values

      if (!regex.test(physicalZip)) {
        setphysicalZipError("Zip code must be exactly 5 digits");
        isValid = false;
      } else {
        setphysicalZipError("");
      }
    }
    if (!serviceProvider) {
      setServiceProviderError("Service provider is required");
      isValid = false;
    } else {
      setServiceProviderError("");
    }

    if (!providerTo && serviceProvider === "Yes") {
      setProviderToError("Service provider to is required");
      isValid = false;
    } else {
      setProviderToError("");
    }

    if (emailList.length === 0) {
      setEmailError("A valid email ID is required");
      isValid = false;
    } else {
      setEmailError("");
    }

    if (isValid) {
      setSubmitModalOpen(true);
    }
  };
  const messageStyle = {
    fontSize: "14px",
    fontWeight: "bold",
    padding: "16px",
  };

  const handleServiceProviderToChange = (selectedOption: any) => {
    setProviderTo(selectedOption.value);
  };

  const handleServiceProvider = (selectedOption: any) => {
    setServiceProvider(selectedOption.value);
    setProviderTo(null);
  };

  const handleEmailBlur = () => {
    if (isEmailValid && !emailList.includes(emailInput)) {
      setEmailList([...emailList, emailInput]);
    }
  };
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+(\.[^\s@]+)*$/;

  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    console.log("value", value);
    // Allow input only until .com, prevent typing anything beyond .com
    if (
      (!value.includes(".com") || value.endsWith(".com")) &&
      emailList.length === 0
    ) {
      setEmailInput(value);
    }
  };
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    console.log("emailList", emailList);
    // Check if backspace was pressed
    if (e.key === "Backspace" && emailList.length > 0) {
      // Prevent default behavior if there are emails in the list
      e.preventDefault();
    }
  };

  // Check if the email is valid and ends with ".com"
  const isEmailValid = emailRegex.test(emailInput);

  const handleAddEmail = (email: string) => {
    if (!emailList.includes(email)) {
      setEmailList([...emailList, email]);
    }
  };
  const handleModalAddEmail = () => {
    // Add the current email to the emailList if it's valid and clear the input
    // if (isEmailValid) {
    //   setEmailList([...emailList, emailInput]);
    // }
    setEmailInput("");
    setIsEmailModalOpen(true);
  };

  const handleServiceModal = () => {
    setIspopupVisible(true);
  };
  const handleCloseModal = () => {
    setIspopupVisible(false); // Close the modal
  };

  // Open the authenticate modals
  const handleAuthenticateModal = (connection: string) => {
    const value = connection.toLowerCase()
    setSelectedConnection(connection)

    //find the integration details to pass to authenticate modals for mapping
    // Find the matching apiConnection
    const matchingApiConnection = apiConnections.find(apiConn =>
      apiConn.label.toLowerCase() === value
    );

    if (matchingApiConnection) {
      const { integration_id, authentication_type ,service_provider_id } = matchingApiConnection;

      // Find the matching integrationDetail
      const matchingIntegrationDetail = integrationDetails.find(integrationDetail => {
        // Check if both values are provided, and if so, check both conditions
        if (authentication_type !== null && integration_id !== null) {
          return integrationDetail.integration_id === integration_id &&
            integrationDetail.authentication_type === authentication_type &&
            integrationDetail.service_provider_id === service_provider_id;
        }
        // If authentication_type is null, check only integration_id
        // return integrationDetail.integration_id === integration_id;
        return {}
      });

      if (matchingIntegrationDetail) {
        setSelectedIntegrationDetail(matchingIntegrationDetail)
        console.log("matchingIntegrationDetail", matchingIntegrationDetail)
        // Perform any action using matchingIntegrationDetail
      } else {
        setSelectedIntegrationDetail({})
        console.warn('No matching integration detail found for this connection.');    
      }
    } else {
      console.warn('No matching apiConnection found for this connection.');
    }
    const primaryConnections = ['at&t - cisco jasper', 'at&t - pod19']
    if (primaryConnections.includes(value) || value.includes('t-mobile') || value.includes('rogers')) {
      setIsAuthenticateVisible(true);
    }
    else if (value.includes('at&t - telegence') || value === 'netsapiens') {
      setIsTelegenceAuthenticate(true);
    }
    else if (value === 'kore') {
      setIsKoreAuthenticate(true);
    }
    else if (value === 'webbing') {
      setIsWebbingAuthenticate(true);
    }
    else if (value === 'bandwidth.com') {
      setIsBandwidthAuthenticate(true);
    }
    else if (value === 'ceretax') {
      setIsCereTaxAuthenticate(true);
    }
    else if (value === 'cyberreef') {
      setIsCyberReefAuthenticate(true);
    }
    else if (value === 'pond mobile') {
      setIsPondIOTAuthenticate(true);
    }
    else if (value === 'qualification') {
      setIsQualificationAuthenticate(true);
    }
    else if (value === 'rev.io') {
      setIsRevIOAuthenticate(true);
    }
    else {
      setIsDefaultAuthenticate(true)
    }
  };
  // Close the authenticate modals
  const closeAuthenticateModals = () => {
    setIsAuthenticateVisible(false);
    setIsTelegenceAuthenticate(false);
    setIsKoreAuthenticate(false);
    setIsWebbingAuthenticate(false);
    setIsDefaultAuthenticate(false);
    setIsBandwidthAuthenticate(false);
    setIsCereTaxAuthenticate(false);
    setIsCyberReefAuthenticate(false);
    setIsPondIOTAuthenticate(false);
    setIsQualificationAuthenticate(false);
    setIsRevIOAuthenticate(false);

  };

  const handleRemoveEmail = (index: number) => {
    const newEmailList = emailList.filter((_, i) => i !== index);
    setEmailList(newEmailList);
    setEmailsList(newEmailList);
  };

  const handleFormSubmit = () => {
    const file = logoFileRef.current?.files?.[0];
    const collapsedFile = collapsedLogoFileRef.current?.files?.[0];
    const darkModeFile = darkModeLogoFileRef.current?.files?.[0];
    const darkModeCollapsedFile = darkModeCollapsedLogoFileRef.current?.files?.[0];

    const validTypes = ["image/png", "image/jpeg"];

    // Reset previous errors
    setLogoError(null);
    setCollapsedLogoError(null);
    setDarkModeLogoError(null);
    setDarkModeCollapsedLogoError(null);

    // Validation flags
    let hasError = false;

    // Validate main logo
    if (file) {
      if (!validTypes.includes(file.type)) {
        setLogoError("Only .png and .jpg files are allowed.");
        hasError = true;
      } else if (file.size > 50 * 1024 * 1024) {
        setLogoError("File size must be less than 50 MB.");
        hasError = true;
      }
    }

    // Validate collapsed logo
    if (collapsedFile) {
      if (!validTypes.includes(collapsedFile.type)) {
        setCollapsedLogoError("Only .png and .jpg files are allowed.");
        hasError = true;
      } else if (collapsedFile.size > 50 * 1024 * 1024) {
        setCollapsedLogoError("File size must be less than 50 MB.");
        hasError = true;
      }
    }

    // Validate dark mode collapsed logo
    if (darkModeCollapsedFile) {
      if (!validTypes.includes(darkModeCollapsedFile.type)) {
        setDarkModeCollapsedLogoError("Only .png and .jpg files are allowed.");
        hasError = true;
      } else if (darkModeCollapsedFile.size > 50 * 1024 * 1024) {
        setDarkModeCollapsedLogoError("File size must be less than 50 MB.");
        hasError = true;
      }
    }

    // Validate dark mode logo
    if (darkModeFile) {
      if (!validTypes.includes(darkModeFile.type)) {
        setDarkModeLogoError("Only .png and .jpg files are allowed.");
        hasError = true;
      } else if (darkModeFile.size > 50 * 1024 * 1024) {
        setDarkModeLogoError("File size must be less than 50 MB.");
        hasError = true;
      }
    }

    if (hasError) return;

    // Helper to read file as base64
    const readFileAsBase64 = (file: File): Promise<string> => {
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
    };

    // Read and submit both logos
    const processLogos = async () => {
      try {
        if (file) {
          logoUrl_ = await readFileAsBase64(file);
          setLogoUrl(logoUrl_);
        }
        if (collapsedFile) {
          collapsedLogoUrl_ = await readFileAsBase64(collapsedFile);
          setCollapsedLogoUrl(collapsedLogoUrl_);
        }
        if (darkModeCollapsedFile) {
          darkModeCollapsedLogoUrl_ = await readFileAsBase64(darkModeCollapsedFile);
          setDarkModeCollapsedLogoUrl(darkModeCollapsedLogoUrl_);
        }
        if (darkModeFile) {
          darkModeLogoUrl_ = await readFileAsBase64(darkModeFile);
          setDarkModeLogoUrl(darkModeLogoUrl_);
        }

        setSubmitModalOpen(false);
        confirmSubmit();
      } catch (err) {
        console.error("Error reading file:", err);
      }
    };

    processLogos();
  };


  //Refetching data

  const fetchTabData = async (tab: {
    module: string;
    setter: (data: any) => void;
    setLoaded: (loaded: boolean) => void;
  }) => {
    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/get_partner_info",
      role_name: role,
      parent_module: "Partner",
      modules_list: [tab.module],
      feature_module_name: "Partner Info",
      pages: {
        "Customer groups": { start: 0, end: 100 },
        "Partner users": { start: 0, end: 100 },
      },
      access_token: token,
      db_name: selectedDb,
        ... metaData,
      sessionID: sessionId,
    };

    try {
      const response = await axios.post(
        ENV_ROUTES.MODULE_MANAGEMENT,
        { data }
      );
      if (response && response.status === 200) {
        const parseddata = JSON.parse(response.data.body);
        if (parseddata.flag) {
          tab.setter(parseddata);
          tab.setLoaded(true);
        } else {
          tab.setter(parseddata.message);
          Modal.error({
            title: "Error",
            content: parseddata.message,
            centered: true,
          });
        }
      }
    } catch (error) {
      console.error("Error fetching", tab.module, ":", error);
      // Modal.error({
      //   title: "Error",
      //   content: "An error occurred during submitting data.",
      //   centered: true,
      // });
    }
  };

  const fetchData = async () => {
    const tabs = [
      {
        module: "Partner info",
        setter: setPartnerInfo,
      },
      {
        module: "Customer groups",
        setter: setCustomerGroups,
      },
      {
        module: "Partner users",
        setter: setPartnerUsers,
      },
      // { module: "Notifications", setter: setNotifications, setLoaded: setNotificationsLoaded }
    ];
    const activeTabData: any = tabs[0]
    const activeTab = "Partner info"

    try {
      if (activeTabData) {
        // Fetch active tab data first
        await fetchTabData(activeTabData);
      } else {
        console.error("Active tab data not found");
      }

      // Fetch remaining tabs data in parallel
      const remainingTabs = tabs.filter(
        (tab) => tab.module.replace(/\s+/g, "").toLowerCase() !== activeTab
      );

      await Promise.all(
        remainingTabs.map((tab: any) => fetchTabData(tab))
      );
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false); // Set loading to false after fetching all data
    }
  };
  const SubmitUpdatePartnerInfo = async () => {
    const partner_address_ = {
      billing_address_1: billingAddress1,
      billing_address_2: billingAddress2,
      billing_city: billingCity,
      billing_state: billingState,
      billing_zip_code: billingZip,
      billing_notes: billingNotes,
      // cross_provider_customer_optimization: crossProviderCustomerOptimization,
      physical_address_1: physicalAddress1,
      physical_addresss_2: physicalAddress2,
      physical_apt_or_suite: physicalApt,
      physical_city: physicalCity,
      physical_state: physicalState,
      physical_zip_code: physicalZip,
      physical_country: physicalCountry,
      physical_county: physicalCounty,
      time_zone: selectedTimezone,
    };
    console.log(fromEmail, sendgridApi, "show the apis")
    try {
      setLoading(true);
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/update_partner_info",
        role_name: role,
        parent_module: "Partner",
        module_name: "Partner info",
        action: "update",
        changed_data: {
          change_phone_number_frequency_setting: phoneNumberFrequency || 3,
          email_ids: emailList,
          logo: logoUrl_ || storedLogo || null,
          collapsed_logo: collapsedLogoUrl_ || storedCollapsedLogo || null,
          dark_mode_collapsed_logo: darkModeCollapsedLogoUrl_ || storedDarkModeCollapsedLogo || null,
          dark_mode_logo: darkModeLogoUrl_ || storedDarkModeLogo || null,
          from_email: fromEmail,
          sendgrid_api: sendgridApi,
          ...partner_address_,

        },

        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
      };
      console.log(data, "show the data")
      console.log(
        getCurrentDateTime(),
        "Show the log time request sent from ui to lambda"
      );

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      console.log(
        getCurrentDateTime(),
        "Show the log time response sent from lambda to ui"
      );
      if (parsedData.flag === false) {
        setLoading(false);
        // Modal.error({
        //   title: "Submit Error",
        //   content:
        //     parsedData.message ||
        //     "An error occurred while submitting data. Please try again.",
        //   centered: true,
        // });
      } else {
        localStorage.setItem("logo", logoUrl_ || storedLogo || null)
        localStorage.setItem("collapsed_logo", collapsedLogoUrl_ || storedCollapsedLogo || null)
        localStorage.setItem("dark_mode_collapsed_logo", darkModeCollapsedLogoUrl_ || storedDarkModeCollapsedLogo || null)
        localStorage.setItem("dark_mode_logo", darkModeLogoUrl_ || storedDarkModeLogo || null)
        notification.success({
          message: "Success",
          description: "Successfully saved the form",
          style: messageStyle,
          placement: "top", // Apply custom styles here
        });
        setLoading(false);
        fetchData()
        // if (response && response.data.statusCode === 200) {
        //   try {
        //     const updatedUrl = ENV_ROUTES.MODULE_MANAGEMENT;
        //     const data = {
        //       tenant_name: partner || "default_value",
        //       username: username,
        //       firstLastName: firstLastName,
        //       path: "/get_partner_info",
        //       feature_module_name: "Partner Info",
        //       role_name: role,
        //       parent_module: "Partner",
        //       modules_list: ["Partner info"],
        //       pages: {
        //         "Customer groups": { start: 0, end: 100 },
        //         "Partner users": { start: 0, end: 100 },
        //       },
        //       access_token: token,
        //       db_name: selectedDb,
        // ... metaData,
        //       sessionID: sessionId,
        //     };
        //     const updatedResponse = await axios.post(updatedUrl, { data });
        //     const updatedPparsedData = JSON.parse(updatedResponse.data.body);
        //     if (updatedResponse && updatedResponse.data.statusCode === 200) {
        //       setPartnerInfo(updatedPparsedData);
        //       // notification.success({
        //       //   message: "Success",
        //       //   description: "Successfully saved the form",
        //       //   style: messageStyle,
        //       //   placement: "top", // Apply custom styles here
        //       // });
        //     } else {
        //       // Modal.error({
        //       //   title: "Submit Error",
        //       //   content:
        //       //     updatedPparsedData.message ||
        //       //     "An error occurred while submitting the form. Please try again.",
        //       //   centered: true,
        //       // });
        //     }
        //   } catch (error) {
        //     console.log(error);
        //     // Modal.error({
        //     //   title: "Submit Error",
        //     //   content:
        //     //     error instanceof Error
        //     //       ? error.message
        //     //       : "An unexpected error occurred while submitting data. Please try again.",
        //     //   centered: true,
        //     // });
        //   } finally {
        //     setLoading(false);
        //   }
        // } else {
        //   const parsedData = JSON.parse(response?.data.body);
        //   // Modal.error({
        //   //   title: "Submit Error",
        //   //   content:
        //   //     parsedData?.message ||
        //   //     "An error occurred while submitting the form. Please try again.",
        //   //   centered: true,
        //   // });
        // }
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Submit Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while submitting data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const SubmitCreateProviderMain = async () => {
    try {
      setLoading(true);
      const url = ENV_ROUTES.TENANT_ONBOARDING;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/create_provider_main",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        partner_name: partnerInfo.partner,
        sub_partner_name: partnerInfo.sub_partner,
        email_id: emailList,
        logo: logoUrl_ || storedLogo || null,
        collapsed_logo: collapsedLogoUrl_ || storedCollapsedLogo || null,
        dark_mode_collapsed_logo: darkModeCollapsedLogoUrl_ || storedDarkModeCollapsedLogo || null,
        dark_mode_logo: darkModeLogoUrl_ || storedDarkModeLogo || null,
        service_provider: serviceProvider,
        service_provider_to: providerTo,

      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        setLoading(false);
        // Modal.error({
        //   title: "Submit Error",
        //   content:
        //     parsedData.message ||
        //     "An error occurred while submitting data. Please try again.",
        //   centered: true,
        // });
      } else {
        setLoading(false);
        // notification.success({
        //   message: "Success",
        //   description: "Successfully saved.",
        //   style: messageStyle,
        //   placement: "top",
        // });
      }
    } catch (error) {
      setLoading(false);
      // Modal.error({
      //   title: "Submit Error",
      //   content:
      //     error instanceof Error
      //       ? error.message
      //       : "An unexpected error occurred while submitting data. Please try again.",
      //   centered: true,
      // });
    } finally {
      setLoading(false);
    }
  };
  const SubmitRemoveProvider = async () => {
    try {
      setLoading(true);
      const url = ENV_ROUTES.TENANT_ONBOARDING;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/remove_provider",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        partner_name: partnerInfo.partner,
        sub_partner_name: partnerInfo.sub_partner,
        email_id: emailList,
        logo: logoUrl_ || storedLogo || null,
        collapsed_logo: collapsedLogoUrl_ || storedCollapsedLogo || null,
        dark_mode_collapsed_logo: darkModeCollapsedLogoUrl_ || storedDarkModeCollapsedLogo || null,
        dark_mode_logo: darkModeLogoUrl_ || storedDarkModeLogo || null,
        service_provider: serviceProvider,
        service_provider_to: providerTo,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        setLoading(false);
        Modal.error({
          title: "Submit Error",
          content:
            parsedData.message ||
            "An error occurred while submitting data. Please try again.",
          centered: true,
        });
      } else {
        setLoading(false);
        notification.success({
          message: "Success",
          description: "Successfully saved.",
          style: messageStyle,
          placement: "top",
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Submit Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while submitting data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleTimezoneChange = (
    selectedOption: SingleValue<{ label: string; value: string }>
  ) => {
    setSelectedTimezone(selectedOption?.value ?? "");
  };

  const confirmSubmit = async () => {
    //Check if the service provider is changed from yes to no
    if (partnerInfo?.service_provider_status && serviceProvider === "No") {
      SubmitRemoveProvider();
      SubmitUpdatePartnerInfo();
    }

    //Check if the service provider is changed from no to yes
    else if (
      !partnerInfo?.service_provider_status &&
      serviceProvider === "Yes"
    ) {
      SubmitCreateProviderMain();
      SubmitUpdatePartnerInfo();
    }
    //if there is no change in service provider
    else {
      //check if the service provider to option is changed
      if (partnerInfo?.service_provider_to !== providerTo) {
        SubmitCreateProviderMain();
        SubmitUpdatePartnerInfo();
      }
      //if the service provider to option is not changed
      else {
        SubmitUpdatePartnerInfo();
      }
    }
    setSubmitModalOpen(false);
  };

  const handleInputChange = (field: any, value: any) => {
    if (field === "from_email") {
      console.log(value, "show the value")
      setFromEmail(value);
      if (value && !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(value)) {
        setFromEmailError("Invalid email address");
      } else {
        setFromEmailError("");
      }
    } else if (field === "sendgrid_api") {
      setSendgridApi(value);
      // Add validation for Sendgrid API key if needed
    }
  };
  const resetForm = () => {
    setEmailList([]);
    setLogoError(null);
    setEmailError(null);
    if (logoFileRef.current) {
      logoFileRef.current.value = "";
    }
    setBillingAddress1("");
    setBillingAddress2("");
    setBillingCity("");
    setBillingState("");
    setBillingZip("");
    setBillingNotes("");
    setBillingZipError("");
    // setCrossProviderCustomerOptimization(false);

    setphysicalZipError("");
    setPhysicalAddress1("");
    setPhysicalAddress2("");
    setPhysicalApt("");
    setPhysicalCity("");
    setPhysicalCountry("");
    setPhysicalCounty("");
    setPhysicalState("");
    setPhysicalZip("");
    setSelectedTimezone("");
  };

  const authenticateSync = async() =>{
    try {
          const url = ENV_ROUTES.OPTIMIZATION_SYNC_LAMBDA;
          const data = {
            key_name:"integration_authentication_sync",
            path:"/lambda_sync_jobs_",
            tenant_name:partner || "default_value",
          };
    
          const response = await axios.post(url, { data });
          const responseData = JSON.parse(response.data.body);
    
          if (responseData.flag === false) {
            console.error("Data Fetch Error: " + responseData.message);
          } else {
            console.log("Success: authenticate lambda sync successful.");
          }
        } catch (error) {
          console.error("Error fetching data:", error);
        }
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  const customDropdownStyles = {
    ...DropdownStyles,
    menu: (provided: any) => ({
      ...provided,
      zIndex: 11, // Ensure dropdown is above all other elements
    }),
    menuPortal: (provided: any) => ({
      ...provided,
      zIndex: 11, // Ensure portal renders above other elements
    }),
  };


  return (
    <div className="p-2">
      <div className="">

        <form onSubmit={handleSubmit}>
          <div className="tabs-sub-headings flex justify-between">
            <h3>Partner Info</h3>
            {(typeof window !== "undefined" && window.innerWidth < 700) && (
              <button
                type="button"
                onClick={() => toggleSections("partner_info")}
              >
                {openSections["partner_info"] ? (
                  <>
                    <ChevronUpIcon className="ml-2 w-4 h-4" />
                  </>
                ) : (
                  <>
                    <ChevronDownIcon className="ml-2 w-4 h-4" />
                  </>
                )}
              </button>
            )}

          </div>
          {(openSections?.["partner_info"] || (typeof window !== "undefined" && window.innerWidth > 700)) && (
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div>
                <label className="field-label">Partner Name</label>
                <input
                  type="text"
                  className="non-editable-input"
                  value={partnerInfo.partner || "NA"}
                  readOnly
                />
              </div>

              <div>
                <label className="field-label">Sub Partner Name</label>
                <input
                  type="text"
                  className="non-editable-input"
                  value={partnerInfo.sub_partner || "NA"}
                  readOnly
                />
              </div>

              <div>
                <label className="field-label">
                  Email IDs<span className="text-red-500">*</span>
                </label>
                <div className="flex items-center">
                  <input
                    type="text"
                    placeholder="Click on + to add Email"
                    className="input"
                    onBlur={handleEmailBlur}
                    value={`${emailInput ? `${emailInput}` : `${emailList.join("; ")}`
                      }`}
                    onChange={handleEmailChange}
                    onKeyDown={handleKeyDown} // Add onKeyDown event
                  />
                  <button
                    type="button"
                    className="save-btn email-plus"
                    onClick={handleModalAddEmail}
                    disabled={emailList.length === 0 && !isEmailValid}
                  >
                    +
                  </button>
                </div>
                <span className="text-red-500 mt-2">{emailError}</span>
              </div>

              <div>
                <label className="field-label">Logo</label>
                <button
                  type="button"
                  className="input mt-1"
                  onClick={() => setLogoModalOpen(true)}
                >
                  Update Logo
                </button>
                {isLogoUpdated && (<span className="text-sm">Logo Uploaded</span>)}
              </div>

              <div>
                <label className="field-label">From Email</label>
                <input
                  type="email"
                  className="input"
                  value={fromEmail}
                  onChange={(e) => handleInputChange("from_email", e.target.value)}
                  placeholder="Enter From Email"
                />
                {fromEmailError ? (
                  <p className="text-red-500 text-sm">{fromEmailError}</p>
                ) : fromEmail ? (
                  <p className="text-sm">Please enter a valid email address.</p>
                ) : null}
              </div>

              <div>
                <label className="field-label">Sendgrid API</label>
                <input
                  type="password"
                  className="input"
                  value={sendgridApi}
                  onChange={(e) => handleInputChange("sendgrid_api", e.target.value)}
                  placeholder="Enter Sendgrid API"
                />

              </div>
              <div>
                <label className="field-label">
                  Service Provider<span className="text-red-500">*</span>
                </label>
                <Select
                  options={provider_options.map((option) => ({
                    label: option,
                    value: option,
                  }))}
                  value={{ label: serviceProvider, value: serviceProvider }}
                  onChange={handleServiceProvider}
                  className=""
                  styles={DropdownStyles}
                  placeholder="Select Service Provider"
                />
                {serviceProviderError && (
                  <p className="text-red-500 text-sm">{serviceProviderError}</p>
                )}
              </div>
              <div>
                <label className="field-label">Service Provider to</label>
                <Select
                  options={tenantOptions.map((option) => ({
                    label: option,
                    value: option,
                  }))}
                  value={{ label: providerTo, value: providerTo }}
                  onChange={handleServiceProviderToChange}
                  className="disabled:cursor-not-allowed"
                  styles={
                    serviceProvider === "No" || !serviceProvider
                      ? NonEditableDropdownStyles
                      : DropdownStyles
                  }
                  placeholder="Select Service Provider"
                  isDisabled={serviceProvider === "No" || !serviceProvider}
                />
                {providerToError && (
                  <p className="text-red-500 text-sm">{providerToError}</p>
                )}
              </div>
              <div>
                <label className="field-label">Change Phone Number Frequency Setting</label>
                <input
                  type="number"
                  value={phoneNumberFrequency}
                  min="0"
                  step="1"
                  className="input"
                  onChange={(e) => {
                    const newFrequency = e.target.value === "" ? 0 : Number(e.target.value);
                    console.log("newTime", newFrequency, typeof newFrequency);
                    setphoneNumberFrequency(newFrequency);
                  }}
                />
              </div>
            </div>
          )}
          <div className="tabs-sub-headings flex justify-between">
            <h3>Partner Address</h3>
            {(typeof window !== "undefined" && window.innerWidth < 700) && (
              <button
                type="button"
                onClick={() => toggleSections("partner_address")}
              >
                {openSections["partner_address"] ? (
                  <>
                    <ChevronUpIcon className="ml-2 w-4 h-4" />
                  </>
                ) : (
                  <>
                    <ChevronDownIcon className="ml-2 w-4 h-4" />
                  </>
                )}
              </button>
            )}


          </div>
          {(openSections?.["partner_address"] || (typeof window !== "undefined" && window.innerWidth > 700)) && (
            <div className="grid grid-cols-2 gap-4 mb-6">
              {/* Billing Address */}
              <div>
                <h3 className="tabs-sub-sub-headings">Billing Address</h3>
                <div>
                  <label className="field-label">Address 1</label>
                  <input
                    type="text"
                    className="input mb-2"
                    value={billingAddress1}
                    onChange={(e) => setBillingAddress1(e.target.value)}
                  />
                </div>
                <div>
                  <label className="field-label">Address 2</label>
                  <input
                    type="text"
                    className="input mb-2"
                    value={billingAddress2}
                    onChange={(e) => setBillingAddress2(e.target.value)}
                  />
                </div>
                <div>
                  <label className="field-label">City</label>
                  <input
                    type="text"
                    className="input mb-2"
                    value={billingCity}
                    onChange={(e) => setBillingCity(e.target.value)}
                  />
                </div>
                <div>
                  <label className="field-label">State</label>
                  <input
                    type="text"
                    className="input mb-2"
                    value={billingState}
                    onChange={(e) => setBillingState(e.target.value)}
                  />
                </div>
                <div>
                  <label className="field-label">Zip Code</label>
                  <input
                    type="text"
                    className="input mb-2"
                    value={billingZip}
                    onChange={(e) => setBillingZip(e.target.value)}
                  />
                  {billingZipError && (
                    <p className="text-red-500 text-sm">{billingZipError}</p>
                  )}
                </div>
                <div>
                  <label className="field-label">Notes</label>
                  <textarea
                    id="comments"
                    value={billingNotes} // Use the comments state
                    onChange={(e) => setBillingNotes(e.target.value)} // Update comments state
                    rows={3} // Adjust the number of rows as needed
                    className="w-full border border-gray-300 rounded-md p-2 focus:outline-none focus:border-[#0ea5e9] focus:shadow-[0_0_0_1px_#1640ff]"
                  />
                </div>
              </div>

              {/* Physical Address */}
              <div>
                <h3 className="tabs-sub-sub-headings">Physical Address</h3>
                <div>
                  <label className="field-label">Address Line 1</label>
                  <input
                    type="text"
                    className="input mb-2"
                    value={physicalAddress1}
                    onChange={(e) => setPhysicalAddress1(e.target.value)}
                  />
                </div>
                <div>
                  <label className="field-label">Address Line 2</label>
                  <input
                    type="text"
                    className="input mb-2"
                    value={physicalAddress2}
                    onChange={(e) => setPhysicalAddress2(e.target.value)}
                  />
                </div>
                <div>
                  <label className="field-label">Apt or Suite</label>
                  <input
                    type="text"
                    className="input mb-2"
                    value={physicalApt}
                    onChange={(e) => setPhysicalApt(e.target.value)}
                  />
                </div>
                <div>
                  <label className="field-label">City</label>
                  <input
                    type="text"
                    className="input mb-2"
                    value={physicalCity}
                    onChange={(e) => setPhysicalCity(e.target.value)}
                  />
                </div>
                <div>
                  <label className="field-label">State</label>
                  <input
                    type="text"
                    className="input mb-2"
                    value={physicalState}
                    onChange={(e) => setPhysicalState(e.target.value)}
                  />
                </div>
                <div>
                  <label className="field-label">Zip Code</label>
                  <input
                    type="text"
                    className="input mb-2"
                    value={physicalZip}
                    onChange={(e) => setPhysicalZip(e.target.value)}
                  />
                  {physicalZipError && (
                    <p className="text-red-500 text-sm">{physicalZipError}</p>
                  )}
                </div>
                <div>
                  <label className="field-label">County</label>
                  <input
                    type="text"
                    className="input mb-2"
                    value={physicalCounty}
                    onChange={(e) => setPhysicalCounty(e.target.value)}
                  />
                </div>
                <div>
                  <label className="field-label">Country</label>
                  <input
                    type="text"
                    className="input mb-2"
                    value={physicalCountry}
                    onChange={(e) => setPhysicalCountry(e.target.value)}
                  />
                </div>
              </div>
            </div>
          )}
          <div className="tabs-sub-headings flex justify-between">
            <h3>Additional Information</h3>
            {(typeof window !== "undefined" && window.innerWidth < 700) && (
              <button
                type="button"
                onClick={() => toggleSections("additional_info")}
              >
                {openSections["additional_info"] ? (
                  <>
                    <ChevronUpIcon className="ml-2 w-4 h-4" />
                  </>
                ) : (
                  <>
                    <ChevronDownIcon className="ml-2 w-4 h-4" />
                  </>
                )}
              </button>
            )}

          </div>
          {(openSections?.["additional_info"] || (typeof window !== "undefined" && window.innerWidth > 700)) && (
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div>
                <label className="field-label">Time Zone</label>
                <Select
                  id="timezone-select"
                  value={timezoneOptions.find(
                    (option) => option.value === selectedTimezone
                  )}
                  onChange={handleTimezoneChange}
                  options={timezoneOptions}
                  isSearchable
                  placeholder="Select a Time Zone"
                  styles={customDropdownStyles}
                  menuPortalTarget={document.body}
                  menuPosition="fixed"
                />
              </div>
              {/* <div className="flex items-center mt-4">
              <label className="field-label">
                Cross Provider Customer Optimization
              </label>
              <Switch
                checked={crossProviderCustomerOptimization}
                onChange={(checked) =>
                  setCrossProviderCustomerOptimization(checked)
                }
                className="ml-4"
              />
            </div> */}
            </div>
          )}
          {(openSections?.["partner_info"] || !(typeof window !== "undefined" && window.innerWidth < 700)) && (
            <div className="flex justify-end space-x-4">
              <button className="save-btn mb-4" type="submit">
                Submit
              </button>
            </div>
          )}

        </form>

      </div>

      {!isAgentPartnerAdmin && (
        <>
          <div className="tabs-sub-headings flex justify-between">
            <h3>Service Providers</h3>
            {(typeof window !== "undefined" && window.innerWidth < 700) && (
              <button
                type="button"
                onClick={() => toggleSections("service_providers")}
              >
                {openSections["service_providers"] ? (
                  <>
                    <ChevronUpIcon className="ml-2 w-4 h-4" />
                  </>
                ) : (
                  <>
                    <ChevronDownIcon className="ml-2 w-4 h-4" />
                  </>
                )}
              </button>
            )}

          </div>
          {(openSections?.["service_providers"] || (typeof window !== "undefined" && window.innerWidth > 700)) && (
            <>
              <div
                style={{
                  display: "flex",
                  justifyContent: "flex-end",
                  marginBottom: "1rem",
                  marginTop: "1rem",
                }}
              >
                <button className="save-btn" type="submit" onClick={handleServiceModal}>
                  <PlusIcon className="h-5 w-5 text-black-500 mr-1" />
                  Add Service Provider
                </button>
              </div>
              <div style={{ marginBottom: "1rem" }}>
                <TableComponent
                  headers={addServiceHeaders}
                  initialData={addServiceTableData}
                  searchQuery={""}
                  visibleColumns={addServiceVisibleColumns}
                  itemsPerPage={100}
                  allowedActions={allowedActions}
                  popupHeading="service providers"
                  pagination={{}}
                  headerMap={addServiceHeaderMap}
                />
              </div>
            </>
          )}
        </>
      )}
      {!isAgentPartnerAdmin && (
        <>
          <div className="tabs-sub-headings flex justify-between">
            <h3>API Connections</h3>
            {(typeof window !== "undefined" && window.innerWidth < 700) && (
              <button
                type="button"
                onClick={() => toggleSections("api_connections")}
              >
                {openSections["api_connections"] ? (
                  <>
                    <ChevronUpIcon className="ml-2 w-4 h-4" />
                  </>
                ) : (
                  <>
                    <ChevronDownIcon className="ml-2 w-4 h-4" />
                  </>
                )}
              </button>
            )}

          </div>
          {(openSections?.["api_connections"] || (typeof window !== "undefined" && window.innerWidth > 700)) && (
            <div className="flex items-center p-4 md:p-8">
              {apiConnections.length > 0 && (
                <div className="grid grid-cols-2 gap-2 md:gap-4">
                  {apiConnections.map((connection: any, index) => (
                    <React.Fragment key={index}>
                      {/* Left Column: Label */}
                      <div className="text-left md:pr-4 text-[16px] md:text-[18px] font-semibold">{connection.label}</div>

                      {/* Right Column: Input Field */}
                      <div>
                        <button
                          className={`px-4 py-2 rounded-lg font-semibold flex items-center gap-2 w-[150px] md:w-[200px] ${connection.authenticated
                            ? 'bg-[#1a81c3] text-white'
                            : 'bg-[#ed4859] text-white'
                            }`}
                          onClick={() => { handleAuthenticateModal(connection.label) }}
                        >
                          {connection.authenticated ? (
                            <>
                              <CheckCircleIcon className=" h-5 w-5" />
                              Authenticated
                            </>
                          ) : (
                            <>
                              <PlusCircleIcon className=" h-5 w-5" />
                              Authenticate
                            </>
                          )}
                        </button>
                      </div>
                    </React.Fragment>
                  ))}
                </div>
              )}
            </div>
          )}
        </>
      )}

      <EmailModal
        isOpen={isEmailModalOpen}
        emailList={emailList}
        onClose={() => setIsEmailModalOpen(false)}
        onAddEmail={handleAddEmail}
        onRemoveEmail={handleRemoveEmail}
      />

      <AddServiceProvider isOpen={isPopupVisible} onClose={handleCloseModal} onSave={fetchAuthenticateData} />

      <Modal
        title={"Update Logos"}
        open={logoModalOpen}
        onOk={handleLogoUpdate}
        onCancel={() => {
          // resetForm();
          setLogoModalOpen(false)
        }}
        centered
      >
        <>
          <div className="grid grid-cols-1 gap-4 mb-6">
            <div>
              <label className="field-label">Partner Logo</label>
              <input
                type="file"
                className="input"
                accept=".png, .jpg"
                ref={logoFileRef}
              />
              {logoError && (
                <p className="text-red-500 text-sm">{logoError}</p>
                // ) : (
                //   <p className="text-sm">Only .png and .jpg Files are Allowed.</p>
              )}
            </div>
            <div>
              <label className="field-label">Dark Mode Logo</label>
              <input
                type="file"
                className="input"
                accept=".png, .jpg"
                ref={darkModeLogoFileRef}
              />
              {darkModeLogoError && (
                <p className="text-red-500 text-sm">{darkModeLogoError}</p>
                // ) : (
                //   <p className="text-sm">Only .png and .jpg Files are Allowed.</p>
              )}
            </div>
            <div>
              <label className="field-label">Collapsed Logo</label>
              <input
                type="file"
                className="input"
                accept=".png, .jpg"
                ref={collapsedLogoFileRef}
              />
              {collapsedLogoError && (
                <p className="text-red-500 text-sm">{collapsedLogoError}</p>
                // ) : (
                //   <p className="text-sm">Only .png and .jpg Files are Allowed.</p>
              )}
            </div>
            <div>
              <label className="field-label">Dark Mode Collapsed Logo</label>
              <input
                type="file"
                className="input"
                accept=".png, .jpg"
                ref={darkModeCollapsedLogoFileRef}
              />
              {darkModeCollapsedLogoError && (
                <p className="text-red-500 text-sm">{darkModeCollapsedLogoError}</p>
                // ) : (
                //   <p className="text-sm">Only .png and .jpg Files are Allowed.</p>
              )}
            </div>
          </div>
          <p className="text-sm">Only .png and .jpg Files are Allowed.</p>
        </>
      </Modal>
      <Modal
        title={<span className="font-semibold">Confirm Submission</span>}
        open={submitModalOpen}
        onOk={handleFormSubmit}
        onCancel={() => {
          // resetForm();
          setSubmitModalOpen(false);
        }}
        centered
      >
        <p>Do you want to Submit this form</p>
      </Modal>
      {/* Authenticate Modals */}
      {isAuthenticateVisible &&
        <AuthenticateModal
          isOpen={isAuthenticateVisible}
          onCancel={closeAuthenticateModals}
          connection={selectedConncetion}
          details={selectedIntegrationDetail}
          onSave={fetchAuthenticateData}
          callSync={authenticateSync}
        />
      }
      {isTelegenceAuthenticate &&
        <TelegenceAuthenticateModal
          isOpen={isTelegenceAuthenticate}
          onCancel={closeAuthenticateModals}
          connection={selectedConncetion}
          details={selectedIntegrationDetail}
          onSave={fetchAuthenticateData}
          callSync={authenticateSync}
        />
      }
      {isKoreAuthenticate &&
        <KoreAuthenticateModal
          isOpen={isKoreAuthenticate}
          onCancel={closeAuthenticateModals}
          connection={selectedConncetion}
          details={selectedIntegrationDetail}
          onSave={fetchAuthenticateData}
          callSync={authenticateSync}
        />
      }
      {isWebbingAuthenticate &&
        <WebbingAuthenticateModal
          isOpen={isWebbingAuthenticate}
          onCancel={closeAuthenticateModals}
          connection={selectedConncetion}
          details={selectedIntegrationDetail}
          onSave={fetchAuthenticateData}
          callSync={authenticateSync}
        />
      }
      {isBandwidthAuthenticate &&
        <BandwidthAuthenticateModal
          isOpen={isBandwidthAuthenticate}
          onCancel={closeAuthenticateModals}
          connection={selectedConncetion}
          details={selectedIntegrationDetail}
          onSave={fetchAuthenticateData}
          callSync={authenticateSync}
        />
      }
      {isCereTaxAuthenticate &&
        <CereTaxAuthenticateModal
          isOpen={isCereTaxAuthenticate}
          onCancel={closeAuthenticateModals}
          connection={selectedConncetion}
          details={selectedIntegrationDetail}
          onSave={fetchAuthenticateData}
          callSync={authenticateSync}
        />
      }
      {isCyberReefAuthenticate &&
        <CyberReefAuthenticateModal
          isOpen={isCyberReefAuthenticate}
          onCancel={closeAuthenticateModals}
          connection={selectedConncetion}
          details={selectedIntegrationDetail}
          onSave={fetchAuthenticateData}
          callSync={authenticateSync}
        />
      }
      {isPondIOTAuthenticate &&
        <PondIotAuthenticateModal
          isOpen={isPondIOTAuthenticate}
          onCancel={closeAuthenticateModals}
          connection={selectedConncetion}
          details={selectedIntegrationDetail}
          onSave={fetchAuthenticateData}
          callSync={authenticateSync}
        />
      }
      {isQualificationAuthenticate &&
        <QualificationAuthenticateModal
          isOpen={isQualificationAuthenticate}
          onCancel={closeAuthenticateModals}
          connection={selectedConncetion}
          details={selectedIntegrationDetail}
          onSave={fetchAuthenticateData}
          callSync={authenticateSync}
        />
      }
      {isRevIOAuthenticate &&
        <RevIotAuthenticateModal
          isOpen={isRevIOAuthenticate}
          onCancel={closeAuthenticateModals}
          connection={selectedConncetion}
          details={selectedIntegrationDetail}
          onSave={fetchAuthenticateData}
          callSync={authenticateSync}
        />
      }
      {isDefaultAuthenticate &&
        <DefaultAuthenticateModal
          isOpen={isDefaultAuthenticate}
          onCancel={closeAuthenticateModals}
          connection={selectedConncetion}
          details={selectedIntegrationDetail}
          onSave={fetchAuthenticateData}
          callSync={authenticateSync}
        />}

    </div>
  );
};

export default PartnerInfo;
