"use client";

import React, { useEffect, useState, useCallback } from "react";
import {
  PlusIcon,
  ArrowDownTrayIcon,
  ArrowUpTrayIcon,
} from "@heroicons/react/24/outline";
import TableComponent from "@/app/components/TableComponent/page";
import CreateModal from "@/app/components/createPopup";
import ColumnFilter from "@/app/components/columnfilter";
import { usePartnerStore } from "../partnerStore";
import {
  Button,
  DatePicker,
  Modal,
  notification,
  message,
  Upload,
  Spin,
} from "antd";
import dayjs, { Dayjs } from "dayjs";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import TableSearch from "@/app/components/entire_table_search";
import AdvancedMultiFilter from "@/app/components/advanced_search";
import { DownloadOutlined, UploadOutlined } from "@ant-design/icons";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { useCustomerRatePlanStore } from "@/app/stores/customerRateplanStore";

const { RangePicker } = DatePicker;

interface ExcelData {
  [key: string]: any;
}

type HeaderMap = Record<string, [string, number]>;

const CustomerGroups: React.FC = () => {
  const [data, setData] = useState<ExcelData[]>([]);
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([
    null,
    null,
  ]);
  const [isCreateModalOpen, setCreateModalOpen] = useState(false);
  const [newRowData, setNewRowData] = useState<any>({});
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, settabledata, token, selectedDb,metaData,advancedStoredpagination, storedpagination, tenantId, tenantName, firstLastName,sessionId, combineAdnvaceStoredpagination, setCombineAdnvaceStoredpagination,dynamicColumns,setDynamicColumns} = useAuth();
  const [headers, setHeaders] = useState<string[]>([]);
  const [headerMap, setHeadersMap] = useState<HeaderMap>({});
  const [createModalData, setCreateModalData] = useState<any[]>([]);
  const [generalFields, setGeneralFields] = useState<any>({});
  const { partnerData, setCustomerGroups } = usePartnerStore.getState();
  const customerGroupsData = partnerData["Customer groups"] || {};
  const [filteredData, setFilteredData] = useState([]);
  const [pagination, setPagination] = useState<any>({});
  const [showAdvanced, setShowAdvanced] = useState(false);
  // const {showAdvanced, setShowAdvanced} = useCustomerRatePlanStore();
  const [isUploadModalVisible, setIsUploadModalVisible] = useState(false);
  const [appendChecked, setAppendChecked] = useState(false);
  const [overwriteChecked, setOverwriteChecked] = useState(false);
  const [isFileSelected, setIsFileSelected] = useState(false);
  const [uploadKey, setUploadKey] = useState(Date.now());
  const [loading, setLoading] = useState(true);
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
  //export functionality
  // const [exportLoading, setExportLoading] = useState(false);
  const { addExport, removeExport,exports } = exportLoadingStore();
  const exportKey="Customer Groups"
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  
  const sortHeaderMap = (headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a?.[1][1] - b?.[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  };

  const sortPopup = (fields: any[]): any[] => {
    return fields.sort((a: any, b: any) => a?.id - b?.id);
  };

  //Remove columns based on role
        useEffect(() => {
          let removeHeaderList :any= []
          if (role?.toLowerCase() !== "super admin" && role?.toLowerCase() !== "partner admin") {
             removeHeaderList = Object.keys(headerMap).filter(
              (key) =>
                ["partner" , "sub partner"].includes(
                  headerMap[key][0]?.toLowerCase()
                )
            );
          }
          else{
            removeHeaderList = Object.keys(headerMap).filter(
              (key) =>
                ["partner"].includes(
                  headerMap[key][0]?.toLowerCase()
                )
            );
          }
          setHeaders((prevHeaders) =>
              prevHeaders.filter((header) => !removeHeaderList.includes(header))
            );
        }, [role,headerMap]);

  useEffect(() => {
        setDynamicColumns((prev:any)=>({...prev,"Customer groups":visibleColumns}))
      }, [visibleColumns]);

  useEffect(() => {
    const initializeData = () => {
      const features = customerGroupsData?.headers_map?.["Customer groups"]?.['module_features'] || []
          setFeatures(features)
          const allowedActions_:any=[]
          if(features.includes("Edit-Customer groups")){
            allowedActions_.push("edit")
          }
          if(features.includes("Delete-Customer groups")){
            allowedActions_.push("delete")
          }

      setAllowedActions(allowedActions_)
      const pagination_ =
        customerGroupsData?.data?.pages?.["Customer groups"] || {};
      console.log(pagination_);
      setPagination(pagination_);
      const data =
        customerGroupsData?.data?.["Customer groups"]?.customergroups || [];
      settabledata(data);
      setData(data);
      const header_Map = sortHeaderMap(
        customerGroupsData?.headers_map?.["Customer groups"]?.header_map || {}
      );
        const sortedheaderMap = sortHeaderMap(header_Map);
      const createModalData_ =
        customerGroupsData?.headers_map?.["Customer groups"]?.pop_up || [];
      const generalFields_ =
        customerGroupsData?.data?.["Customer groups"] || {};
      setHeadersMap(header_Map);
       const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : []
      setHeaders(headers_)
      console.log("headers_",headers_)
      const dynamic_cols=dynamicColumns?.["Customer groups"] && dynamicColumns["Customer groups"].length>0 ?dynamicColumns["Customer groups"] :headers_ || headers_
      setVisibleColumns(dynamic_cols)
      setGeneralFields(generalFields_);
      setCreateModalData(sortPopup(createModalData_));
    };

    initializeData();
  }, [customerGroupsData]);

  const handleFilter = (advancedFilters: any) => {
    // setFilteredData(advancedFilters);
    setAdvancedFilters(advancedFilters)
    
  };

  const handleReset = (EmptyFilters: any) => {
    setFilteredData(EmptyFilters);
  };

  const handleCreateModalOpen = () => {
    setCreateModalOpen(true);
  };

  const handleUploadClick = () => {
    setIsUploadModalVisible(true);
  };

  const handleUploadModalClose = () => {
    setIsUploadModalVisible(false);
  };

  const handleAppendChange = (e: any) => {
    setAppendChecked(e.target.checked);
    if (e.target.checked) setOverwriteChecked(false);
  };

  const handleOverwriteChange = (e: any) => {
    setOverwriteChecked(e.target.checked);
    if (e.target.checked) setAppendChecked(false);
  };
  const handleUpload = async (blob: string) => {
    try {
      setLoading(true);
      const url = ENV_ROUTES.SIM_MANAGEMENT
      let flag: string = appendChecked ? "append" : "overwrite";

      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/import_bulk_data",
        table_name: "customergroups",
        insert_flag: flag,
        module_name: "Customer Groups",
        role_name: role,
        Partner: partner,

        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
          ...metaData,
        sessionID: sessionId,
        blob: blob, // Include the Blob in the data
      };

      const response = await axios.post(url, { data });

      const resp = JSON.parse(response.data.body);
      if (response.data.statusCode === 200) {
        if (resp.flag === true) {
          setIsUploadModalVisible(false);
          notification.success({
            message: "Success",
            description: "Successfully uploaded the record",
            placement: "top",
          });
          fetchData();
        } else {
          Modal.error({
            title: "Import Error",
            content: resp.message,
            centered: true,
            onOk: handleErrorModalClose,
            onCancel: handleErrorModalClose,
          });
        }
      } else {
        Modal.error({
          title: "Import Error",
          content: resp.message,
          centered: true,
          onOk: handleErrorModalClose,
          onCancel: handleErrorModalClose,
        });
      }
    } catch (error) {
      console.error("Error during file upload:", error);
      Modal.error({
        title: "Import Error",
        content: "There was an error uploading the file.",
        centered: true,
        onOk: handleErrorModalClose,
        onCancel: handleErrorModalClose,
      });
    }
    finally{
      setLoading(false);
    }
  };

  const handleErrorModalClose = () => {
    setIsUploadModalVisible(false);
  };

  const handleChange = (info: any) => {
    if (info.file.status === "done") {
      setIsFileSelected(true);
      let blob;
      const file = info.file.originFileObj; // Get the file object
      const reader = new FileReader();
      reader.onload = (e: any) => {
        // Get the file data URL (Base64 string)
        blob = e.target.result;
        console.log("File Base64 String:", blob);
        handleUpload(blob);
        setUploadKey(Date.now());
      };

      if (blob) {
      }

      reader.readAsDataURL(file); // Read the file as data URL
    } else if (info.file.status === "error") {
      // Handle upload error
      message.error("Upload failed.");
    } else if (info.file.status === "removed") {
      setIsFileSelected(false);
      setAppendChecked(false);
      setOverwriteChecked(false);
    }
  };

  const uploadProps = {
    key: uploadKey,
    accept: ".xlsx, .xls",
    beforeUpload: (file: any) => {
      // Check if file is an Excel file
      const isExcel =
        file.type ===
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
        file.type === "application/vnd.ms-excel";
      if (!isExcel) {
        message.error("You can only upload Excel files!");
      }
      return isExcel;
    },
    onChange: handleChange,
  };

  const handleDownloadTemplate = async () => {
    setLoading(true);
    const url = ENV_ROUTES.SIM_MANAGEMENT
    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/download_bulk_upload_template",
      table_name: "customergroups",
      module_name: "Customer Groups",
      role_name: role,
      Partner: partner,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
          ...metaData,
      sessionID: sessionId,
    };

    const response = await axios.post(url, { data });
    const resp = JSON.parse(response.data.body);
    const blob = resp.blob;
    console.log(resp);
    if (response.data.statusCode === 200) {
      if (resp.flag === true) {
        notification.success({
          message: "Success",
          description: "Successfully downloaded the template!",
          style: messageStyle,
          placement: "top",
        });
        downloadBlob(blob);
        setLoading(false);
      } else {
        console.log("Error message:", resp.message);
        Modal.error({
          title: "Export Error",
          content: resp.message,
          centered: true,
        });
        setLoading(false);
      }
    } else {
      console.log("Unexpected status code:", response.data.statusCode);
      Modal.error({
        title: "Export Error",
        content: resp.message,
        centered: true,
      });
      setLoading(false);
    }
  };

  const handleCreateModalClose = () => {
    setCreateModalOpen(false);
    setNewRowData({});
  };

  const handleCreateRow = (newRow: any) => {
    const updatedData = [...data, newRow];
    handleCreateModalClose();
  };

  const handleExportModalOpen = () => {
    setExportModalOpen(true);
  };

  const handleExportModalClose = () => {
    setExportModalOpen(false);
    setDateRange([null, null]); // Reset date range
  };

  // const handleExport = async () => {
  //   if (!dateRange || dateRange[0] === null || dateRange[1] === null) {
  //     Modal.error({ title: "Error", content: "Please select a date range." });
  //     return;
  //   }

  //   const [startDate, endDate] = dateRange;

  //   const data = {
  //     path: "/export",
  //     username: username,
  //     table: "customers",
  //     module_name: "Customer Groups",
  //     request_received_at: getCurrentDateTime(),
  //     start_date: startDate.format("YYYY-MM-DD 00:00:00"), // Start of the day
  //     end_date: endDate.format("YYYY-MM-DD 23:59:59"),
  //     Partner: partner,
  //     access_token: token,
  //     db_name: selectedDb,
  //   };

  //   try {
  //     const url = ENV_ROUTES.MODULE_MANAGEMENT;
  //     const response = await axios.post(
  //       url,
  //       { data: data },
  //       {
  //         headers: {
  //           "Content-Type": "application/json",
  //         },
  //       }
  //     );

  //     const resp = JSON.parse(response.data.body);
  //     const blob = resp.blob;
  //     console.log(resp);
  //     if (response.data.statusCode === 200) {
  //       if (resp.flag === true) {
  //         notification.success({
  //           message: "Success",
  //           description: "Successfully exported the record!",
  //           style: messageStyle,
  //           placement: "top",
  //         });

  //         // Trigger the download after a successful export
  //         downloadBlob(blob);
  //       } else {
  //         // Log and show error message
  //         console.log("Error message:", resp.message);
  //         Modal.error({
  //           title: "Export Error",
  //           content: resp.message,
  //           centered: true,
  //         });
  //       }
  //     } else {
  //       // Handle unexpected status codes
  //       console.log("Unexpected status code:", response.data.statusCode);
  //       Modal.error({
  //         title: "Export Error",
  //         content: resp.message,
  //         centered: true,
  //       });
  //     }

  //     handleExportModalClose();
  //   } catch (error) {
  //     // console.error("Error downloading the file:", error);
  //     // Modal.error({ title: 'Export Error', content: 'An error occurred while exporting the file. Please try again.' });
  //   }
  // };

  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }

  const ExportWithoutSearch = async () => {
    // setExportLoading(true)
    // const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
    //   return new Promise((resolve, reject) => {
    //     const timer = setTimeout(() => {
    //       reject(new Error("Request timed out"));
    //     }, timeout);

    //     promise
    //       .then((res) => {
    //         clearTimeout(timer);
    //         resolve(res);
    //       })
    //       .catch((err) => {
    //         clearTimeout(timer);
    //         reject(err);
    //       });
    //   });
    // };
    try {
      // setExportLoading(true)
      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Request timed out"));
          }, timeout);
  
          promise
            .then((res) => {
              clearTimeout(timer);
              resolve(res);
            })
            .catch((err) => {
              clearTimeout(timer);
              reject(err);
            });
        });
      };
  
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/export_to_s3_bucket",
        role_name: role,
        parent_module: "Partner",
        module_name: "Customer Groups",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        firstLastName: firstLastName,
        access_token: token,
        db_name: selectedDb,
          ...metaData,
        sessionID: sessionId,
        start_date: getFirstDayOfCurrentMonth(),
        end_date: getLastDayOfCurrentMonth(),
      };
      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000); // Timeout of 10 seconds
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }

      // Wait for 20 seconds before polling
      await new Promise((resolve) => setTimeout(resolve, 20000));
      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      // setExportLoading(false);
       // removeExport(exportKey); // Remove the export from the store
    }
  }
  const pollExportStatus = async () => {
    // Polling for the second API
  const export_url = ENV_ROUTES.MODULE_MANAGEMENT;
  const export_data = {
    tenant_name: partner || "default_value",
    username,
    path: "/get_export_status",
    role_name: role,
    parent_module: "Partner",
    module_name:"Customer Groups",
    request_received_at: getCurrentDateTime(),
    Partner: partner,
    access_token: token,
    db_name: selectedDb,
          ...metaData,
    sessionID: sessionId,
  };
    try {
      const export_response = await axios.post(export_url, { data: export_data });
      const export_parsedData = JSON.parse(export_response.data.body);

      if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
        const s3Url = export_parsedData?.export_status_data?.url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
                          .then(response => response.blob())
                          .then(blob => {
                            const url = window.URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = 'Customer Groups.xlsx';
                            a.click();
                            a.remove();
                            window.URL.revokeObjectURL(url);
                            notification.success({
                              message: "Success",
                              description: "Successfully exported the record!",
                              style: messageStyle,
                              placement: "top",
                            });
                          })
                        .catch((err) => {
                          console.log("error",err)
                          Modal.error({
                            title: "Export Error",
                            content: "An error occurred while exporting data. Please try again.",
                            centered: true,
                          });
                        });
        } else {
          Modal.error({
            title: "Export Error",
            content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
        return true; // Stop polling
      }

      if (export_parsedData?.export_status_data?.status_flag === "Failure") {
        Modal.error({
          title: "Export Error",
          content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
        return true; // Stop polling
      }
      if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
                Modal.info({
                  title: "Export Error",
                  content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
                  centered: true,
                });
                return true; // Stop polling
              }

      return false; // Continue polling
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
      return true; // Stop polling
    }
  };
  const startPolling = async () => {
    let isPollingComplete = false;

    while (!isPollingComplete) {
      isPollingComplete = await pollExportStatus();
      if (!isPollingComplete) {
        await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
      }
    }
  };

  const handleExport = async (key:string, heading:string) => {
    try {
      // setExportLoading(true)
      addExport(key, heading);
      let parsedData
      let url
      let data: any
      let response
      if(combineAdnvaceStoredpagination){
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          module_name: "Customer Groups",
          index_name: "customer_groups",
          firstLastName:firstLastName
        }
        console.log("combineAdnvaceStoredpagination",data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
     else if (advancedStoredpagination && !storedpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          module_name: "Customer Groups",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name: "customer_groups",
          pages: {
            start: 0,
            end: 100
          },
          partner:partner,
          username: username,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          tenant_id: tenantId,
          firstLastName:firstLastName
          // }
        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

      }
      else if (storedpagination && !advancedStoredpagination){
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          module_name: "Customer Groups",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "customer_groups",
          search: "whole",
          pages: {
            start: 0,
            end: 100,
          },
          partner:partner,
          username: username,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          tenant_id: tenantId,
          firstLastName:firstLastName
        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

      }
      else {
        // ExportWithoutSearch()
        await ExportWithoutSearch();
        return;
      }

      if (advancedStoredpagination || storedpagination || combineAdnvaceStoredpagination) {
        // if (parsedData.flag === true) {
        //   const s3Url = parsedData?.download_url || null;
        //   if (s3Url) {
        //     window.location.href = s3Url;
        //     setExportLoading(false)
        //     notification.success({
        //       message: 'Success',
        //       description: 'Successfully exported the record!',
        //       style: messageStyle,
        //       placement: 'top',
        //     });
        //   }
        //   else {
        //     setExportLoading(false)
        //     Modal.error({
        //       title: "Export Error",
        //       content: parsedData.message || "An error occurred while exporting data. Please try again.",
        //       centered: true,
        //     });
        //   }


        if (parsedData.flag) {
          const s3Url = parsedData?.download_url || null;
          if (s3Url) {
            // window.location.href = s3Url;
            // notification.success({
            //   message: "Success",
            //   description: "Successfully exported the  record!",
            //   style: messageStyle,
            //   placement: "top",
            // });
            fetch(s3Url)
                            .then(response => response.blob())
                            .then(blob => {
                              const url = window.URL.createObjectURL(blob);
                              const a = document.createElement('a');
                              a.href = url;
                              a.download = 'Customer Groups.xlsx';
                              a.click();
                              a.remove();
                              window.URL.revokeObjectURL(url);
                              notification.success({
                                message: "Success",
                                description: "Successfully exported the record!",
                                style: messageStyle,
                                placement: "top",
                              });
                            })
                          .catch((err) => {
                            console.log("error",err)
                            Modal.error({
                              title: "Export Error",
                              content: "An error occurred while exporting data. Please try again.",
                              centered: true,
                            });
                          });
          }

        } else {
          // setExportLoading(false)
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      
    } else {
      Modal.error({
        title: "Export Error",
        content: parsedData.message || "An error occurred while exporting data. Please try again.",
        centered: true,
      });
    }

    } catch (error) {
      console.log("catch")
      await startPolling()
      // Modal.error({
      //   title: "Export Error",
      //   content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
      //   centered: true,
      // });
    } finally {
      // setExportLoading(false)
      removeExport(key);
    }
  };
  const fetchData = async () => {
    setCombineAdnvaceStoredpagination(null)
    setLoading(true);
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_partner_info",
        role_name: role,
        parent_module: "Partner",
        modules_list: ["Customer groups"],
        feature_module_name: "Partner Info",
        pages: {
          "Customer groups": { start: 0, end: 100 },
          "Partner users": { start: 0, end: 100 },
        },
        offset:0,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
          ...metaData,
        sessionID: sessionId,
      };
      console.log(getCurrentDateTime(),"Show the log time request sent from ui to lambda");
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      console.log(getCurrentDateTime(),"Show the log time response sent from lambda to ui");
      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching E911 Customers data. Please try again.",
          centered: true,
        });
        setLoading(false);
      } else {
        setCustomerGroups(parsedData);
        const tableData =
          parsedData?.data?.["Customer groups"]?.customergroups || [];
        settabledata(tableData);
        setLoading(false);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
      setLoading(false);
    } finally {
      setLoading(false);
    }
  };

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "bold",
    padding: "16px",
  };

  const downloadBlob = (base64Blob: string) => {
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);

    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }

    const byteArray = new Uint8Array(byteNumbers);
    const blobObject = new Blob([byteArray], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    const link = document.createElement("a");

    link.href = URL.createObjectURL(blobObject);
    link.download = "Customer Groups.xlsx";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const disableFutureDates = (current: any) => {
    console.log("future dates:", current && current > dayjs().endOf("day"));
    return current && current > dayjs().endOf("day");
  };


  return (
    <div className="relative">
      <div>
      <div className="pr-4 pl-4  pt-2 flex md:flex-row md:items-center md:justify-between mt-1 mb-4 space-y-4">
          {/* Search and Advanced Filter Container */}
          <div className="flex  space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last ">
          {features.includes("Search-Customer groups") && (
            <TableSearch
              searchTerm={searchTerm}
              setSearchTerm={setSearchTerm}
              tableName={"customer_groups"}
              headerMap={headerMap}
            />
          )}
          {features.includes("Advanced search-Customer groups") && (
            <AdvancedMultiFilter
              showAdvanced={showAdvanced}
              setShowAdvanced={setShowAdvanced}
              onFilter={handleFilter}
              onReset={handleReset}
              headers={headers}
              headerMap={headerMap}
              tableName={"customer_groups"}
            />
          )}
          </div>

          {/* Export and ColumnFilter Container */}
          <div className="hidden md:flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2  md:order-none order-first pb-2 md:pb-4">
          {features.includes("Create-Customer groups") && (
            <button className="save-btn" onClick={handleCreateModalOpen}>
              <PlusIcon className="h-5 w-5 text-black-500 mr-1" />
              Create
            </button>
          )}
          {features.includes("Upload-Customer groups") && (
            <button className="save-btn" onClick={handleUploadClick}>
              <ArrowUpTrayIcon className="h-5 w-5 text-black-500 mr-2" />
              <span>Upload</span>
            </button>
          )}
            <Modal
              title="Upload Files"
              visible={isUploadModalVisible}
              onCancel={handleUploadModalClose}
              footer={null} // No default footer buttons
              centered
              width={400}
            >
               <div className="flex flex-col gap-4">
                         <div className="flex flex-col md:flex-row gap-4 justify-center m-auto p-4">
                           <Upload {...uploadProps} className="w-full md:w-auto">
                               <button className="w-[200px] md:w-full upload-btn disabled:cursor-not-allowed">
                               <span className="mr-2"><UploadOutlined /></span>
                                 Upload
                               </button>
                           </Upload>
                               <button
                                 onClick={handleDownloadTemplate}
                                 className=" w-[200px] md:w-full upload-btn disabled:cursor-not-allowed"
                                 // disabled={!appendChecked && !overwriteChecked}
                               >
                                 <span className="mr-2"><DownloadOutlined /></span>
                                 Download Template
                               </button>
                         </div>
                       </div>
            </Modal>
            {features.includes("Export-Customer groups") && (
            <button className="save-btn"
            onClick={() => {
              if (!exports.some((exportItem) => exportItem.popupHeading === "Customer Groups")) {
                handleExport("CustomerGroups", "Customer Groups");
              }
            }}>
              <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
              <span>Export</span>
            </button>
            )}
             {/* {exportLoading && (
            <div className="export-processing-div">
              Export Processing...
            </div>
          )} */}
            <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
            />
          </div>
        </div>
        <div className=" mb-4 space-x-2"></div>
        <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
          <TableComponent
            headers={headers}
            headerMap={headerMap}
            initialData={data}
            searchQuery={searchTerm}
            visibleColumns={visibleColumns}
            itemsPerPage={100}
            allowedActions={allowedActions}
            popupHeading="Customer Group"
            createModalData={createModalData}
            generalFields={generalFields}
            pagination={pagination || {}}
            advancedFilters={filteredData}
            height = {showAdvanced?370:310}
          />
        </div>
        <CreateModal
          isOpen={isCreateModalOpen}
          onClose={handleCreateModalClose}
          onSave={handleCreateRow}
          columnNames={createModalData}
          heading="Customer Group"
          header={data.length > 0 ? Object.keys(data[0]) : []}
          generalFields={generalFields}
        />
        {/* Sticky Footer for Small Screens */}
        <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
        {features.includes("Create-Customer groups") && (
            <button className="save-btn" onClick={handleCreateModalOpen}>
              <PlusIcon className="h-5 w-5 text-black-500" />
            </button>
          )}
          {features.includes("Upload-Customer groups") && (
            <button className="save-btn" onClick={handleUploadClick}>
              <ArrowUpTrayIcon className="h-5 w-5 text-black-500" />
            </button>
          )} 
           {features.includes("Export-Customer groups") && (
            <button className="save-btn"
            onClick={() => {
              if (!exports.some((exportItem) => exportItem.popupHeading === "Customer Groups")) {
                handleExport("CustomerGroups", "Customer Groups");
              }
            }}>
              <ArrowDownTrayIcon className="h-5 w-5 text-black-500 " />
            </button>
            )}  
             <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
            />                                      
        </div>   
        <Modal
          title={
            <span className="font-semibold text-xl space-y-3">
              Export Output
            </span>
          }
          visible={isExportModalOpen}
          onCancel={() => {
            handleExportModalClose();
            setDateRange([null, null]);
          }}
          footer={null}
          centered
          afterClose={() => setDateRange([null, null])}
          style={{ top: "-4%" }}
        >
          <div className="flex flex-col space-y-4">
            <span>Select Date Range</span>
            <RangePicker
              value={
                dateRange[0] && dateRange[1]
                  ? [dateRange[0], dateRange[1]]
                  : null
              } // Bind the date range
              onChange={(dates) => {
                console.log("Selected dates:", dates); // Debug log
                if (dates && dates.length === 2) {
                  setDateRange([dates[0], dates[1]] as [Dayjs, Dayjs]);
                } else {
                  setDateRange([null, null]); // Reset to null if dates are not both available
                }
              }}
              format="YYYY-MM-DD"
              disabledDate={disableFutureDates}
              popupClassName="custom-range-popup"
            />
            <div
              style={{ marginTop: "2rem" }}
              className="flex  justify-center gap-2 space-x-2"
            >
              <button
                className="cancel-btn text-[16px] font-medium "
                onClick={handleExportModalClose}
                style={{ fontFamily: "Calibri" }}
              >
                <span>Cancel</span>
              </button>
              {/* <button
                className="save-btn text-[16px] font-medium"
                onClick={handleExport}
                style={{ fontFamily: "Calibri" }}
              >
                Export
              </button> */}
            </div>
          </div>
        </Modal>
      </div>
    </div>
  );
};

export default CustomerGroups;
