"use client";
import React, { useEffect, useState, lazy, Suspense } from 'react';
import { useSidebarStore } from '@/app/stores/navBarStore';
import { useLogoStore } from "@/app/stores/logoStore";
import { Spin } from 'antd';
import { useAuth } from '@/app/components/auth_context';


const EmailAuditing = lazy(() => import('./email_auditing'));
const EmailInfo = lazy(() => import('./email_template'));
const Dashboard = lazy(() => import('./email_dashboard'));
const DeviceNotifications = lazy(() => import('./device_notifications'))

const Email: React.FC = () => {
  const title = useLogoStore((state) => state.title);
  const setTitle = useLogoStore((state) => state.setTitle);
  const active_tab = localStorage.getItem("activeTab") || "email_dashboard"
  const active_tabs_list = ["email_dashboard", "email_auditing", "email_info", "device_notifications"]
  const [activeTab, setActiveTab] = useState(() => {
    // Check if active_tab is in active_tabs_list; default to 'customer' if not
    return active_tabs_list.includes(active_tab) ? active_tab : "email_dashboard";
  });

  const isExpanded = useSidebarStore((state: any) => state.isExpanded);
  const { settabledata } = useAuth();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    // Save activeTab state to localStorage on change
    localStorage.setItem("activeTab", activeTab);
  }, [activeTab]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }
  return (
    <>
      <div className="">
        <div className={`bg-white shadow-md mb-4 gap-4  tabs ${isExpanded
            ? "left-[250px]"
            : "lg:left-[70px] left-0"
        }`}>
          <button
            className={`tab-headings ${activeTab === 'email_dashboard' ? 'active-tab-heading' : ''}`}
            onClick={() => { settabledata; setActiveTab('email_dashboard') }}
          >
            Dashboard
          </button>
          <button
            className={`tab-headings ${activeTab === 'email_auditing' ? 'active-tab-heading' : ''}`}
            onClick={() => { settabledata; setActiveTab('email_auditing') }}
          >
            Email Audit
          </button>
          <button
            className={`tab-headings ${activeTab === 'email_info' ? 'active-tab-heading' : ''}`}
            onClick={() => { settabledata; setActiveTab('email_info') }}
          >
            Email Template
          </button>
          <button
            className={`tab-headings ${activeTab === 'device_notifications' ? 'active-tab-heading' : ''}`}
            onClick={() => { settabledata; setActiveTab('device_notifications') }}
          >
            Device Notifications
          </button>
        </div>
        <div className="h-[calc(100vh-150px)] pt-[70px]">
          {activeTab === 'email_auditing' && <EmailAuditing />}
          {activeTab === 'email_info' && <EmailInfo />}
          {activeTab === 'email_dashboard' && <Dashboard />}
          {activeTab === 'device_notifications' && <DeviceNotifications />}
        </div>
      </div>
    </>
  );
};

export default Email;
