"use client";

import React, { useCallback, useEffect, useRef, useState } from "react";
import * as XLSX from "xlsx";
import { getCurrentDateTime } from "@/app/components/header_constants";
import {
  PlusIcon,
  ArrowDownTrayIcon,
  AdjustmentsHorizontalIcon,
  ArrowUpTrayIcon,
} from "@heroicons/react/24/outline";
import {
  Button,
  message,
  Modal,
  notification,
  Popover,
  Spin,
  Upload,
} from "antd";
import TableComponent from "@/app/components/TableComponent/page";
import CreateModal from "@/app/components/createPopup";
import AdvancedMultiFilter from "@/app/components/advanced_search";
import TableSearch from "@/app/components/entire_table_search";
import { DownloadOutlined, UploadOutlined } from "@ant-design/icons";
import CreateEmailAuditTemplateModal from "./create_email_aduit_temp";
import ColumnFilter from "@/app/components/columnfilter";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useCustomerRatePlanStore } from "@/app/stores/customerRateplanStore";
// import { blob } from "stream/consumers";
// import { Blob } from "buffer";

interface ExcelData {
  [key: string]: any;
}

const EmailTemplate: React.FC = () => {
  const { emailConditionModal, setEmailConditionModal } = useCustomerRatePlanStore();
  const [data, setData] = useState<ExcelData[]>([]);
  const [isCreateEmailAuditOpen, setCreateEmailAuditOpen] = useState(false);
  const [isImportModalOpen, setImportModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const [filteredData, setFilteredData] = useState([]);
  const { username, partner, role, settabledata, token ,selectedDb,metaData, firstLastName,sessionId,dynamicColumns,setDynamicColumns} = useAuth();
  const [loading, setLoading] = useState(true);
  const [showAdvanced, setShowAdvanced] = useState(false);
  // const {showAdvanced, setShowAdvanced} = useCustomerRatePlanStore();
  const [isUploadModalVisible, setIsUploadModalVisible] = useState(false);
  const [appendChecked, setAppendChecked] = useState(false);
  const [overwriteChecked, setOverwriteChecked] = useState(false);
  const hasFetchedData = useRef(false);
  const [pagination, setPagination] = useState<any>({});
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<string[]>([]);

  const [isFileSelected, setIsFileSelected] = useState(false);
  const [uploadKey, setUploadKey] = useState(Date.now());
  const [headerMap, setHeaderMap] = useState<any>({});
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);

  const onsave = () =>{
    fetchData()
  }
  useEffect(() => {
        setDynamicColumns((prev:any)=>({...prev,"Email Template List":visibleColumns}))
      }, [visibleColumns]);
  const fetchData = async () => {
    setLoading(true);
    try {
      settabledata([])
      // addLog("UI API call");
      const url = ENV_ROUTES.NOTIFICATION_SERVICES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/email_template_list_view",
        role_name: role,
        parent_module: "Partner",
        module_name: "notification services",
        feature_module_name:"Notifications",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name:selectedDb,
        ...metaData,
        sessionID: sessionId,
      };
      console.log(getCurrentDateTime(),"Show the log time request sent from ui to lambda");
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      console.log(getCurrentDateTime(),"Show the log time response sent from lambda to ui");
      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching Inventory data. Please try again.",
          centered: true,
        });
      } else {
        const headersMap_ =
          parsedData?.headers_map?.["Email Template List"]?.header_map || {};
        const sortedheaderMap = sortHeaderMap(headersMap_);
        setHeaderMap(sortedheaderMap);
         const headers_ =
            Object.keys(sortedheaderMap).length > 0
              ? Object.keys(sortedheaderMap)
              : [];
          setHeaders(headers_);
          const dynamic_cols=dynamicColumns?.["Email Template List"] && dynamicColumns["Email Template List"].length>0 ?dynamicColumns["Email Template List"] :headers_ || headers_
          setVisibleColumns(dynamic_cols)
        const tableData_ = parsedData?.data || [];
        setData(tableData_);
        const features_ =
          parsedData?.headers_map?.["Email Template List"]?.module_features ||
          [];
        setFeatures(features_);
        const allowedActions_:any=[]
        if(features_.includes("Edit-Email Templates")){
          allowedActions_.push("editEmail")
        }
        if(features_.includes("Copy-Email Templates")){
          allowedActions_.push("copy")
        }
        setAllowedActions(allowedActions_)
        const createModalData_ =
          parsedData?.headers_map?.["Email Template List"]?.pop_up || [];

        const pagination_ = parsedData?.pages || {};
        setPagination(pagination_);

        const condition = parsedData?.email_condition;
        setEmailConditionModal(condition)
        console.log("condition...", condition)
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    if (!hasFetchedData.current) {
      fetchData();
      hasFetchedData.current = true;
    }
  }, [partner]);
  const handleFilter = (advancedFilters: any) => {
    setAdvancedFilters(advancedFilters)
  };

  const handleReset = (EmptyFilters: any) => {
    setFilteredData(EmptyFilters);
  };
  const handleUploadModalClose = () => {
    setAppendChecked(false);
    setOverwriteChecked(false);
    setIsUploadModalVisible(false);
    setUploadKey(Date.now());
    setIsFileSelected(false); 
  };

  const handleUploadClick = () => {
    setIsUploadModalVisible(true);
  };

  const handleCreateEmailAuditOpen = () => {
    setCreateEmailAuditOpen(true);
  };

  const handleCreateEmailAuditClose = () => {
    setCreateEmailAuditOpen(false);
    // setNewRowData({});
  };

  const handleErrorModalClose = () => {
    setIsUploadModalVisible(false);
  };

  const handleUpload = async (blob: any) => {
    try {
      const url =ENV_ROUTES.SIM_MANAGEMENT
      let flag: string = appendChecked ? "append" : "overwrite";

      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        insert_flag: flag,
        path: "/bulk_import_data",
        table_name: "email_templates",
        module_name: "customer rate plan",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name:selectedDb,
        ...metaData,
        sessionID: sessionId,
        blob: blob,
      };

      const response = await axios.post(url, { data });

      const resp = JSON.parse(response.data.body);
      if (response.data.statusCode === 200) {
        if (resp.flag === true) {
          setIsUploadModalVisible(false);
          notification.success({
            message: "Success",
            description: (
              <div>
                Successfully exported the record!<br />
                Templates are created for the adjustment of placeholders please edit the template.
              </div>
            ),
            placement: "top",
          });
          fetchData();
          handleUploadModalClose();
        } else {
          Modal.error({
            title: "Import Error",
            content: resp.message,
            centered: true,
            onOk: handleErrorModalClose,
            onCancel: handleErrorModalClose,
          });
        }
      } else {
        Modal.error({
          title: "Import Error",
          content: resp.message,
          centered: true,
          onOk: handleErrorModalClose,
          onCancel: handleErrorModalClose,
        });
      }
    } catch (error) {
      console.error("Error during file upload:", error);
      Modal.error({
        title: "Import Error",
        content: "There was an error uploading the file.",
        centered: true,
        onOk: handleErrorModalClose,
        onCancel: handleErrorModalClose,
      });
    }
  };

  const downloadBlob = (base64Blob: string) => {
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    const blobObject = new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blobObject);
    link.download = 'Email Template.xlsx';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const messageStyle = {
    fontSize: '14px',
    fontWeight: 'bold',
    padding: '16px',
  };

  const handleDownloadTemplate = async () => {
    setLoading(true);
    const url =ENV_ROUTES.SIM_MANAGEMENT
    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/download_bulk_upload_template",
      table_name: "email_templates",
      module_name: "Email Templates",
      role_name: role,
      Partner: partner,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
    };

    const response = await axios.post(url, { data });
    const resp = JSON.parse(response.data.body);
    const blob = resp.blob;
    if (response.data.statusCode === 200) {
      if (resp.flag === true) {
        notification.success({
          message: 'Success',
          description: 'Successfully exported the record!',
          style: messageStyle,
          placement: 'top',
        });
        downloadBlob(blob);
        fetchData();
        handleUploadModalClose();
        setLoading(false);
      } else {
        console.log('Error message:', resp.message);
        Modal.error({
          title: 'Export Error',
          content: resp.message,
          centered: true,
        });
      }
    } else {
      console.log('Unexpected status code:', response.data.statusCode);
      Modal.error({
        title: 'Export Error',
        content: resp.message,
        centered: true,
      });
    }
  };

  const handleImportModalOpen = () => {
    setImportModalOpen(true);
  };

  const handleImportModalClose = () => {
    setImportModalOpen(false);
  };

  const handleChange = (info: any) => {
    if (info.file.status === "done") {
      setIsFileSelected(true);
      let blob;
      const file = info.file.originFileObj; // Get the file object
      const reader = new FileReader();
      reader.onload = (e: any) => {
        // Get the file data URL (Base64 string)
        blob = e.target.result;
        handleUpload(blob);
        setUploadKey(Date.now());
      };

      if (blob) {
      }

      reader.readAsDataURL(file); // Read the file as data URL
    } else if (info.file.status === "error") {
      // Handle upload error
      message.error("Upload failed.");
    } else if (info.file.status === "removed") {
      setIsFileSelected(false);
    }
  };

  const uploadProps = {
    key: uploadKey,
    accept: ".xlsx, .xls",
    beforeUpload: (file: any) => {
      // Check if file is an Excel file
      const isExcel =
        file.type ===
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
        file.type === "application/vnd.ms-excel";
      if (!isExcel) {
        message.error("You can only upload Excel files!");
      }
      return isExcel;
    },
    onChange: handleChange,
  };
// {/* <Upload key={uploadKey} {...uploadProps}>
//     {/* You can include any children here, e.g., a button or text */}
//     Upload
// </Upload> */}
  

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }
  return (
    <div className="relative">
        <div className="pr-4 pl-4  pt-2 flex md:flex-row md:items-center md:justify-between mt-1 mb-4 space-y-4">
          {/* Search and Advanced Filter Container */}
          <div className="flex space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last ">
        {features.includes("Search-Email Templates") && (
          <TableSearch
            searchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
            tableName={"email_templates"}
            headerMap={headerMap}
          />
        )}
          {features.includes("Advanced filter-Email Templates") && (
          <AdvancedMultiFilter
            showAdvanced={showAdvanced}
            setShowAdvanced={setShowAdvanced}
            onFilter={handleFilter}
            onReset={handleReset}
            headers={headers}
            headerMap={headerMap}
            tableName={"email_templates"}
          />
          )}
        </div>

          {/* Export and ColumnFilter Container */}
          <div className="hidden md:flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2  md:order-none order-first pb-2 md:pb-4">
        {features.includes("Create-Email Templates") && (
          <button
            className="save-btn text-black-500"
            onClick={handleCreateEmailAuditOpen}
          >
            <PlusIcon className="h-5 w-5 text-black-500 mr-1 " />
            Create
          </button>
        )}
          {features.includes("Upload-Email Templates") && (
          <button className="save-btn" onClick={handleUploadClick}>
              <ArrowUpTrayIcon className="h-5 w-5 text-black-500 mr-2" />
              <span>Upload</span>
            </button>
          )}
            <Modal
              title="Upload Files"
              visible={isUploadModalVisible}
              onCancel={handleUploadModalClose}
              footer={null} // No default footer buttons
              centered
              width={400}
            >
                <div className="flex flex-col gap-4">
                          <div className="flex flex-col md:flex-row gap-4 justify-center m-auto p-4">
                            <Upload {...uploadProps} className="w-full md:w-auto">
                                <button className="w-[200px] md:w-full upload-btn disabled:cursor-not-allowed">
                                <span className="mr-2"><UploadOutlined /></span>
                                  Upload
                                </button>
                            </Upload>
                                <button
                                  onClick={handleDownloadTemplate}
                                  className=" w-[200px] md:w-full upload-btn disabled:cursor-not-allowed"
                                  // disabled={!appendChecked && !overwriteChecked}
                                >
                                  <span className="mr-2"><DownloadOutlined /></span>
                                  Download Template
                                </button>
                          </div>
                        </div>
            </Modal>
            <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
            />
        </div>
      </div>
      <div className=" mb-4 space-x-2"></div>

      <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
        <TableComponent
          headers={headers}
          initialData={data}
          searchQuery={searchTerm}
          visibleColumns={visibleColumns}
          itemsPerPage={100}
          allowedActions={allowedActions}
          popupHeading="Email Template"
          pagination={{}}
          advancedFilters={filteredData}
          headerMap={headerMap}
          height = {showAdvanced?360:300}
          onsave={onsave}

        />
      </div>

      <CreateEmailAuditTemplateModal
        // isOpen={isCreateEmailAuditOpen}
        onClose={handleCreateEmailAuditClose}
        visible={isCreateEmailAuditOpen}
        isOpen={false}
        rowData={undefined}
        action="create"
        onsave={onsave}
      />
       {/* Sticky Footer for Small Screens */}
       <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
       {features.includes("Create-Email Templates") && (
          <button
            className="save-btn text-black-500"
            onClick={handleCreateEmailAuditOpen}
          >
            <PlusIcon className="h-5 w-5 text-black-500 " />
          </button>
        )}
          {features.includes("Upload-Email Templates") && (
          <button className="save-btn" onClick={handleUploadClick}>
              <ArrowUpTrayIcon className="h-5 w-5 text-black-500" />
            </button>
          )}
             <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
            />                                      
        </div>   
    </div>
  );
};

export default EmailTemplate;
