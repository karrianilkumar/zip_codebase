"use client";

import React, { useEffect, useState } from "react";
import { Select, DatePicker, message } from "antd";
import { ChevronDownIcon } from "@heroicons/react/24/outline";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  PieChart,
  Pie,
  LineChart,
  Line,
  Legend,
  ResponsiveContainer,
  Cell,
} from "recharts";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import dayjs, { Dayjs } from "dayjs";
import moment from "moment";
import EmailsChartsPage from "./email_charts";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { getCurrentDateTime } from "@/app/components/header_constants";

const { Option } = Select;
const { RangePicker } = DatePicker;

const EmailDashboard: React.FC = () => {
  const [emailType, setEmailType] = useState("All");
  const [selectedButton, setSelectedButton] = useState("Today");
  const [loading, setLoading] = useState(true);
  const [chartsData, setChartsData] = useState<any>([]);
  const [selectedDate, setSelectedDate] = useState<moment.Moment | null>(null);
  const [startDate, setStartDate] = useState(moment().startOf("day"));
  const [endDate, setEndDate] = useState(moment().endOf("day"));
  const { username, partner, role, settabledata, token, selectedDb ,metaData,sessionId ,firstLastName} =
    useAuth();

  const COLORS = ["#0088FE", "#00C49F", "#FFBB28"];

  const fetchData = async (startDate: string, endDate: string) => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.NOTIFICATION_SERVICES;
      const requestPaths = [
        { path: "/email_status_pie_chart", title: "Successful Vs Error" },
        { path: "/email_triggers_by_day", title: "No. of emails" },
        { path: "/emails_per_trigger_type_weekly", title: "Email type" },
        { path: "/no_of_error_emails_weekly", title: "No. of errors" },
      ];

      const promises = requestPaths.map(({ path, title }) => {
        const requestData = {
          partner: partner,
          start_date: startDate,
          end_date: endDate,
          email_type: emailType,
          path,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          username:username,
          first_last_name:firstLastName
        };
        console.log(getCurrentDateTime(),"Show the log time request sent from ui to lambda");
        
        return axios.post(url, { data: requestData }).then((response) => {
          console.log(getCurrentDateTime(),"Show the log time response sent from lambda to ui");
          const parsedBody = JSON.parse(response.data.body);
          const { data } = parsedBody;
          return {
            title: data.title || title,
            chart_type: data.chart_type,
            data: data.data,
            angleField: data.angleField,
            colorField: data.colorField,
            radius: data.radius,
            innerRadius: data.innerRadius,
            height: data.height,
            width: data.width,
            xField: data.xField,
            yField: data.yField,
            smooth: data.smooth,
            isStacked: data.isStacked,
          };
        });
      });

      const results = await Promise.all(promises);
      setChartsData(results);
    } catch (error) {
      console.error("Error fetching data in dashboard:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleDatePickerChange = (date: moment.Moment | null) => {
    if (date) {
      setSelectedDate(date);
      // Keep start and end dates as moment objects
      setStartDate(date.startOf("day"));
      setEndDate(date.endOf("day"));
      setSelectedButton(""); // Clear the selected button since a custom date is selected
    }
  };

  useEffect(() => {
    let startDate = "";
    let endDate = "";
    if (selectedButton === "Today") {
      startDate = moment().format("YYYY-MM-DD");
      endDate = moment().format("YYYY-MM-DD");
    } else if (selectedButton === "Current Week") {
      startDate = moment().startOf("week").format("YYYY-MM-DD");
      endDate = moment().endOf("week").format("YYYY-MM-DD");
    } else if (selectedButton === "Current Month") {
      startDate = moment().startOf("month").format("YYYY-MM-DD");
      endDate = moment().endOf("month").format("YYYY-MM-DD");
    } else if (selectedDate) {
      startDate = selectedDate.startOf("day").format("YYYY-MM-DD");
      endDate = selectedDate.endOf("day").format("YYYY-MM-DD");
    }
    fetchData(startDate, endDate);
  }, [selectedButton, selectedDate, emailType]);

  const renderCustomizedLabel = ({
    cx,
    cy,
    midAngle,
    innerRadius,
    outerRadius,
    percent,
  }: any) => {
    const RADIAN = Math.PI / 180;
    const radius = (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

    return (
      <text
        x={x}
        y={y}
        fill="white"
        textAnchor={x > cx ? "start" : "end"}
        dominantBaseline="central"
      >
        {`${(percent * 100).toFixed(0)}%`}
      </text>
    );
  };

  const handleButtonClick = (
    range: "Today" | "Current Week" | "Current Month"
  ) => {
    setSelectedButton(range);

    if (range === "Today") {
      setStartDate(moment().startOf("day"));
      setEndDate(moment().endOf("day"));
    } else if (range === "Current Week") {
      setStartDate(moment().startOf("week"));
      setEndDate(moment().endOf("week"));
    } else if (range === "Current Month") {
      setStartDate(moment().startOf("month"));
      setEndDate(moment().endOf("month"));
    }
  };

  const handleEmailTypeChange = (value: string) => {
    setEmailType(value);
  };

  const formatStackedBarData = (data: any[]) => {
    const result: any[] = [];
    const categories = new Set<string>();

    // Collect unique categories
    data.forEach((item) => {
      if (item.value && typeof item.value === "object") {
        Object.keys(item.value).forEach((category) => categories.add(category));
      }
    });

    // Define a type for the baseEntry
    interface BaseEntry {
      day: any;
      [key: string]: any; // Allow dynamic keys
    }

    // Create result data structure
    data.forEach((item) => {
      const baseEntry: BaseEntry = { day: item.day };
      if (item.value && typeof item.value === "object") {
        Object.keys(item.value).forEach((category) => {
          baseEntry[category] = item.value[category] || 0;
        });
      }
      result.push(baseEntry);
    });

    return { data: result, categories: Array.from(categories) };
  };

  const renderControls = () => {
    const isSmallScreen = typeof window !== "undefined" && window.innerWidth < 700;
  
    if (isSmallScreen) {
      return (
        <div className="flex flex-col gap-4 mx-3 my-2">
          {/* First Row: Select and DatePicker */}
          <div className="flex justify-between items-center gap-2">
            <Select
              value={emailType}
              onChange={handleEmailTypeChange}
              style={{
                width: "100%",
                maxWidth: 200,
                fontWeight: "450",
                height: "47px",
                fontFamily: "Calibri, sans-serif",
                borderRadius: "8px",
                color: "black",
              }}
              suffixIcon={<ChevronDownIcon className="w-4 h-4 text-gray-600" />}
              className="flex-1"
            >
              <Option value="All">All</Option>
              <Option value="AWS">AWS</Option>
              <Option value="Application">Application</Option>
              <Option value="Billing">Billing</Option>
            </Select>
            <DatePicker
              value={selectedDate}
              onChange={handleDatePickerChange}
              style={{
                width: "100%",
                maxWidth: 250,
                height: "47px",
                borderRadius: "8px",
              }}
              disabledDate={(current) =>
                current && current > dayjs().endOf("day")
              }
              className="flex-1 small-screen-range-picker"
            />
          </div>
          {/* Second Row: Select label and Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            <span
              style={{
                fontFamily: "Calibri, sans-serif",
                fontSize: "16px",
              }}
              className="mr-2"
            >
              Select:
            </span>
            <button
              className={
                selectedButton === "Today" ? "save-btn" : "email-dashboard-btns"
              }
              onClick={() => handleButtonClick("Today")}
              style={{
                fontFamily: "Calibri, sans-serif",
                fontSize: "14px",
                padding: "8px 12px",
              }}
            >
              Today
            </button>
            <button
              className={
                selectedButton === "Current Week"
                  ? "save-btn"
                  : "email-dashboard-btns"
              }
              onClick={() => handleButtonClick("Current Week")}
              style={{
                fontFamily: "Calibri, sans-serif",
                fontSize: "14px",
                padding: "8px 12px",
              }}
            >
              Current Week
            </button>
            <button
              className={
                selectedButton === "Current Month"
                  ? "save-btn"
                  : "email-dashboard-btns"
              }
              onClick={() => handleButtonClick("Current Month")}
              style={{
                fontFamily: "Calibri, sans-serif",
                fontSize: "14px",
                padding: "8px 12px",
              }}
            >
              Current Month
            </button>
          </div>
        </div>
      );
    }
  
    return (
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "flex-end",
          marginBottom: "10px",
          marginTop: "10px",
          marginRight: "12px",
        }}
        className="flex flex-wrap gap-2"
      >
        <Select
          value={emailType}
          onChange={handleEmailTypeChange}
          style={{
            width: 200,
            fontWeight: "450",
            height: "47px",
            fontFamily: "Calibri, sans-serif",
            borderRadius: "8px",
            color: "black",
          }}
          suffixIcon={<ChevronDownIcon className="w-4 h-4 text-gray-600" />}
        >
          <Option value="All">All</Option>
          <Option value="AWS">AWS</Option>
          <Option value="Application">Application</Option>
          <Option value="Billing">Billing</Option>
        </Select>
        <span
          style={{
            marginLeft: 10,
            marginRight: 20,
            fontFamily: "Calibri, sans-serif",
            fontSize: "16px",
            marginTop: "-2px",
          }}
        >
          Select:
        </span>
        <button
          className={
            selectedButton === "Today" ? "save-btn" : "email-dashboard-btns"
          }
          onClick={() => handleButtonClick("Today")}
          style={{
            marginRight: 10,
            fontFamily: "Calibri, sans-serif",
            fontSize: "16px",
            padding: "10px",
            marginTop: "-2px",
          }}
        >
          Today
        </button>
        <button
          className={
            selectedButton === "Current Week" ? "save-btn" : "email-dashboard-btns"
          }
          onClick={() => handleButtonClick("Current Week")}
          style={{
            marginRight: 10,
            fontFamily: "Calibri, sans-serif",
            fontSize: "16px",
            padding: "10px",
            marginTop: "-2px",
          }}
        >
          Current Week
        </button>
        <button
          className={
            selectedButton === "Current Month" ? "save-btn" : "email-dashboard-btns"
          }
          onClick={() => handleButtonClick("Current Month")}
          style={{
            marginRight: 10,
            fontFamily: "Calibri, sans-serif",
            fontSize: "16px",
            padding: "10px",
            marginTop: "-2px",
          }}
        >
          Current Month
        </button>
        <DatePicker
          value={selectedDate}
          onChange={handleDatePickerChange}
          style={{
            marginLeft: "2px",
            marginRight: "5px",
            height: "47px",
            borderRadius: "8px",
          }}
          disabledDate={(current) => current && current > dayjs().endOf("day")}
        />
      </div>
    );
  };

  const renderChart = (chart: any) => {
    switch (chart.chart_type) {
      case "bar":
        return (
          <ResponsiveContainer
            width="95%"
            height="95%"
            style={{ marginLeft: "5px" }}
          >
            <BarChart data={chart.data}>
              <XAxis
                dataKey={chart.xField}
                axisLine={false}
                label={{ value: "Days", position: "bottom", offset: -7 }}
              />
              <YAxis
                axisLine={false}
                label={{
                  value: "No. of emails",
                  angle: -90,
                  position: "left",
                  offset: -10,
                  dy: -35,
                }}
              />
              <CartesianGrid
                strokeDasharray="3 3"
                horizontal={true}
                vertical={false}
              />
              <Tooltip cursor={false} />
              <Legend />

              <Bar dataKey={chart.yField} fill="#8884d8" />
            </BarChart>
          </ResponsiveContainer>
        );
      case "stacked-bar":
        const formattedData = formatStackedBarData(chart.data);
        return (
          <ResponsiveContainer
            width="95%"
            height="95%"
            style={{ marginLeft: "5px" }}
          >
            <BarChart data={formattedData.data}>
              <XAxis
                dataKey="day"
                axisLine={false}
                label={{ value: "Days", position: "bottom", offset: -7 }}
              />
              <YAxis
                axisLine={false}
                label={{
                  value: "Email type",
                  angle: -90,
                  position: "left",
                  offset: -10,
                  dy: -35,
                }}
              />
              <CartesianGrid
                strokeDasharray="3 3"
                horizontal={true}
                vertical={false}
              />
              <Tooltip cursor={false} />
              <Legend />
              {formattedData.categories.map(
                (category: string, index: number) => (
                  <Bar
                    key={index}
                    dataKey={category}
                    stackId="a"
                    fill={COLORS[index % COLORS.length]}
                  />
                )
              )}
            </BarChart>
          </ResponsiveContainer>
        );

      case "pie":
        const hasData = chart.data && chart.data.length > 0;
        return (
          <div
            style={{
              height: "280px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            {hasData ? (
              <ResponsiveContainer
                width="95%"
                height="95%"
                style={{ marginLeft: "5px" }}
              >
                <PieChart>
                  <Pie
                    data={chart.data}
                    dataKey={chart.angleField}
                    nameKey={chart.colorField}
                    outerRadius={110}
                    fill="#8884d8"
                    label={renderCustomizedLabel}
                    labelLine={false}
                  >
                    {chart.data.map((entry: any, index: number) => (
                      <Cell
                        key={`cell-${index}`}
                        fill={
                          entry.isError
                            ? "#FF0000"
                            : COLORS[index % COLORS.length]
                        }
                      />
                    ))}
                  </Pie>
                  <Tooltip />
                  <Legend
                    layout="horizontal"
                    verticalAlign="bottom"
                    align="center"
                    iconType="square"
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div style={{ textAlign: "center", color: "#8884d8" }}>
                No Data
              </div>
            )}
          </div>
        );

      case "bar_two":
        return (
          <ResponsiveContainer
            width="95%"
            height="95%"
            style={{ marginLeft: "5px" }}
          >
            <BarChart data={chart.data}>
              <XAxis
                dataKey={chart.xField}
                axisLine={false}
                label={{ value: "Days", position: "bottom", offset: -7 }}
              />
              <YAxis
                axisLine={false}
                label={{
                  value: "Errors",
                  angle: -90,
                  position: "left",
                  offset: -8,
                  dy: -20,
                }}
              />
              <CartesianGrid
                strokeDasharray="3 3"
                horizontal={true}
                vertical={false}
              />
              <Tooltip cursor={false} />
              <Legend />

              <Bar dataKey={chart.yField} fill="#8884d8" />
            </BarChart>
          </ResponsiveContainer>
        );
      default:
        return null;
    }
  };

  return (
    <>
      {renderControls()}
      <EmailsChartsPage
        selectedEmailType={emailType}
        startDate={startDate.format("YYYY-MM-DD")}
        endDate={endDate.format("YYYY-MM-DD")}
      />
      <div className="flex flex-wrap justify-center gap-[10px] m-[10px]">
        {chartsData.map((chart: any, index: any) => (
          <div
            key={index}
            className="chart-container graph"
            style={{
              flex: "1 1 45%", 
              maxWidth: "600px", 
              minWidth: "280px", 
              margin: "10px", 
              borderRadius: "10px",
              boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
              // backgroundColor: "#fff",
              paddingBottom: "8px",
            }}
          >
            <h3
              className="text-[17px] mb-[5px] pb-[2px]"
              style={{
                fontFamily: "Calibri, sans-serif",
                marginLeft: "22px",
                marginTop: "10px",
              }}
            >
              {chart.title}
            </h3>
            <div
              style={{
                height: `${chart.height}px`,
                width: "100%", // Makes the chart container fill the width of its parent
              }}
            >
              {renderChart(chart)}
            </div>
          </div>
        ))}
      </div>
    </>
  );
};

export default EmailDashboard;
