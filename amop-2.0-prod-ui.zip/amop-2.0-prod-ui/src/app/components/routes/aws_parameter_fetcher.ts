// import { SSMClient, GetParametersCommand } from "@aws-sdk/client-ssm";

// // Initialize the SSM Client
// const client = new SSMClient({
//   region: process.env.AWS_REGION || "us-east-1", 
//   credentials: {
//     accessKeyId: "AKIAQEFWAKZ7V73FTRFG",
//     secretAccessKey: "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",
//   },
// });

// // Function to fetch SSM parameters
// export const getParameters = async (names: string[]): Promise<{ [key: string]: string }> => {
//   console.log("Fetching SSM parameters for names:", names); // Log parameter names

//   const command = new GetParametersCommand({
//     Names: names,
//     WithDecryption: true,
//   });

//   try {
//     const data = await client.send(command);
//     console.log("Data received from SSM:", data); // Log fetched data

//     const parameters: { [key: string]: string } = {};
//     data.Parameters?.forEach(param => {
//       console.log("Processing parameter:", param.Name, param.Value); // Log each parameter
//       parameters[param.Name!] = param.Value!.trim();
//     });

//     console.log("Final parameters object:", parameters); // Log final parameters
//     return parameters;
//   } catch (error) {
//     console.error("Error fetching parameters from SSM:", error); // Log any errors
//     throw error;
//   }
// };
