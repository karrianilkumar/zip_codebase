// import { getParameters } from "./aws_parameter_fetcher";

const LAMBDA_URLS :any= process.env.AMOP_2_LAMBDA_URLS || {};

console.log("DASHBOARD",process.env.NEXT_PUBLIC_DASHBOARD)
console.log("NEXT_PUBLIC_AMOP_1_BASE_URL",process.env.NEXT_PUBLIC_AMOP_1_BASE_URL)

export const ENV_ROUTES: any = {
  DASHBOARD:process.env.NEXT_PUBLIC_DASHBOARD,
  NOTIFICATION_SERVICES:process.env.NEXT_PUBLIC_NOTIFICATION_SERVICES,
  SIM_MANAGEMENT: process.env.NEXT_PUBLIC_SIM_MANAGEMENT,
  AMOP_LOGIN: process.env.NEXT_PUBLIC_AMOP_LOGIN,
  GET_MODULES: process.env.NEXT_PUBLIC_GET_MODULES,
  MODULE_MANAGEMENT: process.env.NEXT_PUBLIC_MODULE_MANAGEMENT,
  OPEN_SEARCH: process.env.NEXT_PUBLIC_OPEN_SEARCH,
  USER_AUTHENTICATION: process.env.NEXT_PUBLIC_USER_AUTHENTICATION,
  CORE: process.env.NEXT_PUBLIC_CORE,
  TENANT_ONBOARDING: process.env.NEXT_PUBLIC_TENANT_ONBOARDING,
  AUTOMATION_RULE: process.env.NEXT_PUBLIC_AUTOMATION_RULE,
  OPTIMIZATION: process.env.NEXT_PUBLIC_OPTIMIZATION,
  CHARGES_HISTORY: process.env.NEXT_PUBLIC_CHARGES_HISTORY,
  PEOPLE_MODULE: process.env.NEXT_PUBLIC_PEOPLE_MODULE,
  DEVICE_MANAGEMENT: process.env.NEXT_PUBLIC_DEVICE_MANAGEMENT,
  SERVICE_QUALIFICATION: process.env.NEXT_PUBLIC_SERVICE_QUALIFICATION,
  REV_ASSURANCE : process.env.NEXT_PUBLIC_REV_ASSURANCE,
  BP_SERVICES_PRODUCTS: process.env.NEXT_PUBLIC_BP_SERVICES_PRODUCTS,
  BP_CUSTOMER_PROFILES: process.env.NEXT_PUBLIC_BP_CUSTOMER_PROFILES,
  BP_PAYMENT_INTEGRATION: process.env.NEXT_PUBLIC_BP_PAYMENT_INTEGRATION,
  BP_BILLING_PAYMENTS: process.env.NEXT_PUBLIC_BP_BILLING_PAYMENTS,
  OPTIMIZATION_SYNC_LAMBDA: process.env.NEXT_PUBLIC_OPTIMIZATION_SYNC_LAMBDA,
  SM_BULK_CHANGE: process.env.NEXT_PUBLIC_SM_BULK_CHANGE,
  AUTHORIZE_NET: process.env.NEXT_PUBLIC_AUTHORIZE_NET,
  BP_COLLECTIONS: process.env.NEXT_PUBLIC_BP_COLLECTIONS,
  BP_REPORTS: process.env.NEXT_PUBLIC_BP_REPORTS,
  BP_DASHBOARDS : process.env.NEXT_PUBLIC_BP_DASHBOARDS,
  CENTRALIZED_VIEW : process.env.NEXT_PUBLIC_CENTRALIZED_VIEW,
  BULKCHANGE_PROCESSOR : process.env.NEXT_PUBLIC_BULKCHANGE_PROCESSOR,

};

// export const fetchSSMParameters = async (): Promise<void> => {
//   const storedRoutes = localStorage.getItem("ENV_ROUTES");
//   if (storedRoutes) {
//     Object.assign(ENV_ROUTES, JSON.parse(storedRoutes));
//     return;
//   }
//   try {
//     const parameterNames = Object.keys(ENV_ROUTES).map(route => `/AMOP/UI/UAT/${route}`);

//     const chunks = [];
//     for (let i = 0; i < parameterNames.length; i += 10) {
//       chunks.push(parameterNames.slice(i, i + 10));
//     }

//     const parameters:any = {};
//     for (const chunk of chunks) {
//       const chunkParameters = await getParameters(chunk);
//       Object.assign(parameters, chunkParameters);
//     }

//     for (const key of Object.keys(ENV_ROUTES)) {
//       const paramName = `/AMOP/UI/UAT/${key}`;
//       ENV_ROUTES[key] = parameters[paramName] || "";
//     }

//     localStorage.setItem("ENV_ROUTES", JSON.stringify(ENV_ROUTES));
//   } catch (error) {
//     console.log("dashborad error for no ENV Routes",error)
//     // throw error;
//   }
// };