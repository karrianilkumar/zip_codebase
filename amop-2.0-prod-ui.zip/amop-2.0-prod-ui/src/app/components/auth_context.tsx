'use client'
import React, { createContext, useState, useContext, ReactNode, useEffect, useRef, useCallback } from 'react';
import axios from 'axios';
import { Modal } from 'antd';
import { getCurrentDateTime } from './header_constants';
import debounce from 'lodash/debounce';
import { ENV_ROUTES } from './routes/route_constants';
import { useRouter } from 'next/navigation';
import { usePathname } from "next/navigation";
import CryptoJS from 'crypto-js';
import { useLogoStore } from '../stores/logoStore';

interface AuthContextType {
  isAuthenticated: boolean;
  setIsAuthenticated:(value:boolean)=>void;
  isReset: boolean;
  error?: Error | null;

  login: (username: string, password: string) => void;
  logout: () => void;
  LogoutChooseTenant: () => void;
  partner: string | null;
  setPartner: (partnerName: string | null) => void;
  selectedPartner: boolean;
  tenantId:  string | number |null;
  setTenantId: (tenantId: string | null | number) => void;
  setSelectedPartner: (value: boolean) => void;
  username: string | null;
  setUsername: (username: string | null) => void;
  firstLastName: string | null;
  setFirstLastName: (firstLastName: string | null) => void;
  selectedPartnerModule: string | null;
  setSelectedPartnerModule: (partner: string | null) => void;
  Environment: string | null;
  setSelectedEnvironment: (Environment: string | null) => void;
  handleSelectedPartner: (partnerName: string) => void;
  showPasswordUpdate: boolean;
  setShowPasswordUpdate: (value: boolean) => void;
  showPassword: boolean;
  setShowPassword: (value: boolean) => void;
  isSubTenant: boolean;
  setIsSUbTenant: (value: boolean) => void;
  modulesVersionMap: any;
  setModulesVersionMap: (value: any) => void;
  isSubTenantMap: any;
  setIsSubTenantMap: (value: any) => void;
  tenantNames: string[];
  setTenantNames: (tenantNames: string[]) => void;
  selectedDb: string|null;
  setSelectedDb: (selectedDb: string|null) => void;
  selectedBillingDb: string|null;
  setSelectedBillingDb: (selectedBillingDb: string|null) => void;
  role: string | null;
  setRole: (role: string | null) => void;
  token: string | null;
  setToken: (token: string | null) => void;
  sessionId:string | null;
  setSessionId: (sessionId: string | null) => void;
  modules: any[]; // Add modules to context
  setModules: (modules: any[]) => void;
  serviceProviderList : any[];//setting service providers list in rev.io
  setServiceProviderList:(serviceProviderList:any[])=>void;
  selectedServiceProvider :number| string|null;//setting service provider value in rev.io
  setSelectedServiceProvider :(serviceProvider:number|string|null)=>void;
  firstModuleRoute :string|null;
  setFirstModuleRoute :(firstModuleRoute:string|null)=>void;
  loading: boolean;
   setLoading: (value: boolean) => void;
   tabledata: any[];
   settabledata: (data: any[]) => void;// Method to set modules
   storedpagination: any;
   setStoredPagination: (data: any) => void;// Method to set searchPagination
   advancedStoredpagination: any;
   setAdvancedStoredPagination: (data: any) => void;// Method to set searchAvancedPagination
   combineAdnvaceStoredpagination: any;
   setCombineAdnvaceStoredpagination: (data: any) => void;// Method to set searchAvancedPagination
   wholeSearchWord:string;
   setWholeSearchWord: (wholeSearchWord: string) => void;// Method to set search word
  email: string | null; // Added email property
  setEmail: (email: string | null) => void; // Added setEmail method
  tenantName:string|null;
  setTenantName:(tenant_name:string|null)=>void;
  dbName:string|null;
  setDbName:(dbName:string|null)=>void;
  password:string|null;
  setPassword:(password:string|null)=>void;
  dynamicColumns: any;
  setDynamicColumns: (dynamicColumns: any) => void;
  logoUrl: string | null;
  setLogoUrl: (logoUrl:string|null)=>void;
  collapsedLogoUrl: string | null;
  setCollapsedLogoUrl: (collapsedLogoUrl:string|null)=>void;
  darkModeCollapsedLogoUrl: string | null;
  setDarkModeCollapsedLogoUrl: (darkModeCollapsedLogoUrl:string|null)=>void;
  darkModeLogoUrl: string | null;
  setDarkModeLogoUrl: (darkMOdeLogoUrl:string|null)=>void;
  handleLoginUsingCode: (
    code: string,
    username: string,
    role?: string | null,
    tenantId?: string | null,
    tenantName?: string | null,
    
  ) => Promise<void>;
  metaData: any;
  setMetaData: (metaData: any) => void;
  
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);
export const BASE_URL = process.env.NEXT_PUBLIC_BASE_URL;

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const router = useRouter();
    const [partner, setPartner] = useState<string | null>(null);
  const [tenantId, setTenantId] = useState<string | number|null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isReset, setReset] = useState(false);
  const [selectedPartner, setSelectedPartner] = useState<boolean>(false);
  const [username, setUsername] = useState<string | null>(null);
  const [firstLastName, setFirstLastName] = useState<string | null>(null);
  const [selectedPartnerModule, setSelectedPartnerModule] = useState<string | null>(null);
  const [Environment, setSelectedEnvironment] = useState<string | null>(null);
  const [tabledata, settabledata] = useState<any[]>([]);
  const [showPasswordUpdate, setShowPasswordUpdate] = useState<boolean>(false);
  const [showPassword, setShowPassword] = useState<boolean>(false);
  const [isSubTenant, setIsSUbTenant] = useState<boolean>(false);
  const [modulesVersionMap, setModulesVersionMap] = useState<any>({});
  const [isSubTenantMap, setIsSubTenantMap] = useState<any>({});
  const [tenantNames, setTenantNames] = useState<string[]>([]);
  const [role, setRole] = useState<string | null>(null);
  const [selectedDb, setSelectedDb] = useState<string | null>(null);
  const [selectedBillingDb, setSelectedBillingDb] = useState<string | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [sessionId, setSessionId] = useState<string | null>(null);
  const [modules, setModules] = useState<any[]>([]);
  const [dynamicColumns, setDynamicColumns] = useState<any>({});
  const [logoUrl, setLogoUrl] = useState<string | null>(null);
  const [collapsedLogoUrl, setCollapsedLogoUrl] = useState<string | null>(null);
  const [darkModeCollapsedLogoUrl, setDarkModeCollapsedLogoUrl] = useState<string | null>(null);
  const [darkModeLogoUrl, setDarkModeLogoUrl] = useState<string | null>(null);
  const [serviceProviderList, setServiceProviderList]=useState<any[]>([]);
  const [selectedServiceProvider, setSelectedServiceProvider] = useState<number | string|null >(null);
  const [firstModuleRoute, setFirstModuleRoute] = useState<string| null>(null);
  const [loading, setLoading] = useState(false); // State to manage loading
  const [storedpagination, setStoredPagination] = useState<any>(null);
  const [advancedStoredpagination, setAdvancedStoredPagination] = useState<any>(null);
  const [combineAdnvaceStoredpagination, setCombineAdnvaceStoredpagination] = useState<any>(null);
  const [wholeSearchWord, setWholeSearchWord] = useState<string>("");
  const [email, setEmail] = useState<string | null>(null); // Added email state
  const [tenantName, setTenantName] = useState<string | null>(null);
  const [dbName, setDbName] = useState<string | null>(null);
  const [password, setPassword] = useState<string | null>(null);
  const [error, setError] = useState<Error | null>(null);
  const setSwiched20User = useLogoStore((state) => state.setSwiched20User);
  const [metaData, setMetaData] = useState<any>({});


  //Session timeout
  const [isWarningVisible, setIsWarningVisible] = useState(false);
  const logoutTimerRef = useRef<NodeJS.Timeout | null>(null);
  const warningTimerRef = useRef<NodeJS.Timeout | null>(null);

  const resetInactivityTimer = useCallback(() => {
    if (logoutTimerRef.current) clearTimeout(logoutTimerRef.current);
    if (warningTimerRef.current) clearTimeout(warningTimerRef.current);
    removeWarning();

    const ui_timeout = localStorage.getItem("ui_timeout");
    // default to 15 if nothing found
    const timeoutMinutes = ui_timeout ? Number(ui_timeout) : 15;
    const timeoutMs = timeoutMinutes * 60 * 1000;
    // Set timer for warning (after selected minutes of inactivity)
    warningTimerRef.current = setTimeout(() => {
      showWarning();
    }, timeoutMs);
  }, []);

  const debouncedResetTimer = useCallback(
    debounce(() => {
      if (isAuthenticated) {
        resetInactivityTimer();
      }
    }, 300),
    [isAuthenticated, resetInactivityTimer]
  );

  const showWarning = () => {
    setIsWarningVisible(true);
    const warningDiv = document.createElement('div');
    warningDiv.id = 'sessionWarning';
    warningDiv.style.position = 'fixed';
    warningDiv.style.bottom = '20px';
    warningDiv.style.right = '20px';
    warningDiv.style.backgroundColor = '#ffcc00';
    warningDiv.style.color = '#000';
    warningDiv.style.padding = '15px';
    warningDiv.style.borderRadius = '5px';
    warningDiv.style.zIndex = '1000';
    document.body.appendChild(warningDiv);

    let remainingTime = 60;
    const updateWarning = () => {
      warningDiv.innerText = `Your session will expire in ${remainingTime} seconds. Please interact with the page to stay logged in.`;
      remainingTime--;

      if (remainingTime >= 0 && isWarningVisible) {
        setTimeout(updateWarning, 1000);
      } else if (remainingTime < 0) {
        handleSessionExpiration();
      }
    };

    updateWarning();

    // Set timer for logout (after 1 more minute of inactivity)
    logoutTimerRef.current = setTimeout(handleSessionExpiration, 60000);
  };

  const removeWarning = () => {
    setIsWarningVisible(false);
    const warningElement = document.getElementById('sessionWarning');
    if (warningElement) {
      document.body.removeChild(warningElement);
    }
  };

  const handleSessionExpiration = () => {
    removeWarning();
    localStorage.clear(); // Clear session data
    logout();
    Modal.warning({
      title: 'Session Expired',
      content: 'Your session has expired due to inactivity. Please log in again.',
      onOk: () => {
        // window.location.href = '/login';
      }
    });
  };

  useEffect(() => {
    const userActivityEvents = ['mousedown', 'keydown', 'scroll', 'touchstart', 'mousemove'];

    if (isAuthenticated) {
      userActivityEvents.forEach(event => {
        window.addEventListener(event, debouncedResetTimer);
      });

      // Initial timer set
      resetInactivityTimer();
    }

    return () => {
      userActivityEvents.forEach(event => {
        window.removeEventListener(event, debouncedResetTimer);
      });
      if (logoutTimerRef.current) clearTimeout(logoutTimerRef.current);
      if (warningTimerRef.current) clearTimeout(warningTimerRef.current);
    };
  }, [isAuthenticated, debouncedResetTimer, resetInactivityTimer]);


  const login = async (username: string, password: string) => {
    setUsername(username);
    const SECRET_KEY = process.env.NEXT_PUBLIC_SECRET_KEY || "";
    const encrypted = CryptoJS.AES.encrypt(password, SECRET_KEY).toString();
   
    const data = {
        path: "/login_using_database",
        user_name: username,
        password: encrypted,
        request_received_at: getCurrentDateTime(),
    };
    setLoading(true);

    try {
        const url = ENV_ROUTES.USER_AUTHENTICATION;
        const response = await axios.post(url, { data: data }, {
            headers: {
                'Content-Type': 'application/json',
            },
        });

        if (response.status === 200) {
         
          const sessionId = sessionStorage.getItem("session_id") || crypto.randomUUID();
          sessionStorage.setItem("session_id", sessionId);
            const resp = JSON.parse(response.data.body);
            if (resp.flag === false) {
                Modal.error({
                    title: 'Login Error',
                    content: resp.message || 'An error occurred during login. Please try again.',
                    centered: true,
                });
                setIsAuthenticated(false);
            } else {
              console.log("message",resp.message)
              if (resp.message === "Successfully token is entered please move it to password reset page") {
                setIsAuthenticated(true)
                setSelectedPartner(true)
                setShowPasswordUpdate(true);
            }
                if (resp.message === "Token is Valid.") {
                    // setShowPasswordUpdate(true);
                    const role = resp["role"];
                    setRole(role);
                    setIsAuthenticated(true);
                    setReset(true);
                }
                if (resp["tenant_names"]) {
                    const tenant_names = resp["tenant_names"];
                    setTenantNames(tenant_names);
                    const user_name_= resp["user_name"];
                    setUsername(user_name_);
                    const first_last_name_= resp["first_last_name"];
                    setFirstLastName(first_last_name_);
                    setIsAuthenticated(true);
                    setReset(false);
                    const role = resp["role"];
                    setRole(role);
                    const token_=resp["access_token"]
                    setToken(token_)
                    const sessionId_=resp["session_id"]
                    setSessionId(sessionId_)
                    const email_=resp["email"];
                    setEmail(email_);
                    setDynamicColumns(resp?.dynamic_cols || {});
                    setSwiched20User(resp?.switch_user_2_0 || "False")
                    setModulesVersionMap(resp?.switch_user_20_modules_json || {});
                    localStorage.setItem('switch_user_2_0',resp?.switch_user_2_0 || "False");
                    localStorage.setItem('dynamic_cols',JSON.stringify(resp?.dynamic_cols || {}));
                    localStorage.setItem('switch_user_20_modules_json',(resp?.switch_user_20_modules_json || {}));
                    localStorage.setItem('username', user_name_);
                    localStorage.setItem('first_last_name',first_last_name_);
                    localStorage.setItem('access_token',token_);
                    localStorage.setItem('session_id',sessionId_)
                    localStorage.setItem('role_name', role);
                    localStorage.setItem('tenant_names', JSON.stringify(tenant_names || []));
                      // Add session timestamp when successfully logged in
                    localStorage.setItem('session_timestamp', Date.now().toString());

                    setIsSubTenantMap(resp?.tenant_sub_tenant_dict || {});
                    localStorage.setItem('sub_tenant_map', JSON.stringify(resp?.tenant_sub_tenant_dict || {}));

                }
            }
        } else {
            console.log('Login failed:', response.data);
            Modal.error({
                title: 'Login Error',
                content: response.data.message || 'Login failed. Please check your credentials and try again.',
                centered: true,
            });
            setIsAuthenticated(false);
        }
    } catch (error) {
        console.error('Error during login:', error);
        if (error instanceof Error) {
            Modal.error({
                title: 'Login Error',
                content: error.message || 'An unexpected error occurred during login. Please try again.',
                centered: true,
            });
        } else {
            Modal.error({
                title: 'Login Error',
                content: 'An unexpected error occurred during login. Please try again.',
                centered: true,
            });
        }
        setIsAuthenticated(false);
    } finally {
        setLoading(false); // Always stop the loader in the finally block
    }
};

  const LogoutChooseTenant = () => {
    localStorage.removeItem('tenant_name'); // Remove only 'tenant_name' key
    setPartner(null);
    setTenantId(null);
    setSelectedPartner(false);
    setShowPassword(false);
    setReset(false)
  };

  const handleLogout = async () => {
      const pathname = window.location.pathname;
      // const url = `/auth/logout?redirect=${pathname}&action=logout`;
      // window.location.href = url;
      const data = {
        path: "/logout",
        username: username,
        firstLastName: firstLastName,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        dynamic_cols:dynamicColumns
      };
      try {
        localStorage.clear(); // Clear session data
        const url = ENV_ROUTES.USER_AUTHENTICATION;
        const response = await axios.post(url, { data: data }, {
          headers: {
            'Content-Type': 'application/json',
          },
        });
        if (response.data.statusCode === 200) {
          localStorage.clear()
        }
        else {
          Modal.error({
            title: 'Login Error',
            content: 'An unexpected error occurred during login. Please try again.',
            centered: true,
          });
        }
      } catch (error) {
        console.error('Error during login:', error);
        if (error instanceof Error) {
          Modal.error({
            title: 'Login Error',
            content: error.message || 'An unexpected error occurred during login. Please try again.',
            centered: true,
          });
        } else {
          Modal.error({
            title: 'Login Error',
            content: 'An unexpected error occurred during login. Please try again.',
            centered: true,
          });
        }
      } finally {
      }
    };
  const logout = () => {
    // handleLogout()
    // Broadcast logout event to all tabs
    localStorage.setItem('global_logout_timestamp', Date.now().toString());
    // Clear storages
    localStorage.clear();
    sessionStorage.clear();    
    setIsAuthenticated(false);
    setUsername(null);
    setFirstLastName(null);
    setPartner(null);
    setTenantId(null);
    setSelectedPartner(false);
    setShowPassword(false);
    setIsSUbTenant(false)
    setIsSubTenantMap({})
    setModulesVersionMap({})
    setTenantNames([]);
    if (logoutTimerRef.current) clearTimeout(logoutTimerRef.current);
    if (warningTimerRef.current) clearTimeout(warningTimerRef.current);
    removeWarning();


    // Redirect to 1.0 Logout page after clearing the session data

    /// Show the loader while navigating to the logout page, avoid user click login button.
    setLoading(true);
    /// Redirect to the logout page, it will clear the session data in the 1.0 and redirect to the login page 2.0
    const amop1Url = process.env.NEXT_PUBLIC_AMOP_1_BASE_URL;
    const callbackUrl = encodeURIComponent(`${window.location.origin}`);
    console.log("callbackUrl",callbackUrl)
    window.location.href = `${amop1Url}/Login/Logout?returnUrl=${callbackUrl}&returnWithoutLogin=true`;
  };

  const handleSelectedPartner = async (partnerName: string) => {
    setSelectedPartner(true);
    setPartner(partnerName);
    localStorage.setItem('partner', partnerName);
  };

  const loadModules = async (
    username: string,
    role: string,
    authCode: string,
    tenantId: string,
    tenant_name:string |null,
  ) => {
    const data = {
      path: "/get_redirection_modules",
      role_name: role,
      username: username,
      auth_code: authCode,
      tenant_id: tenantId,
      tenant_name:tenant_name,
      // db_name: dbName,
      request_received_at: getCurrentDateTime(),
      "1.0": true,
    };
    setLoading(true);

    try {
      const url = ENV_ROUTES.USER_AUTHENTICATION || "/user_auth";
      const response = await axios.post(
        url,
        { data },
        {
          baseURL: BASE_URL,
        },
      );

      if (response.status === 200) {
        const parsedData = JSON.parse(response.data.body);

        if (parsedData.error) {
          // setError(parsedData.error);
        } else if (parsedData.flag === false) {
          // setError(parsedData.message || 'An error occurred while fetching modules.');
        } else {
          setIsAuthenticated(true);
          setSelectedPartner(true);
          setModules(parsedData?.Modules || []);
          setSelectedDb(parsedData?.db_name || null);
          setToken(parsedData?.access_token || "");
          setSelectedDb(parsedData?.db_name || null);
          setTenantNames(parsedData?.tenant_names || []);
          setFirstLastName(parsedData?.first_last_name || "");
          setIsSubTenantMap(parsedData?.tenant_sub_tenant_dict || {});
          setModulesVersionMap(parsedData?.switch_user_20_modules_json || {});

          localStorage.setItem('access_token', parsedData?.access_token || "");
          localStorage.setItem('tenant_names', JSON.stringify(parsedData?.tenant_names || []));
          localStorage.setItem('modules', JSON.stringify(parsedData?.Modules || []));
          localStorage.setItem('db_name', parsedData?.db_name || null);
          localStorage.setItem('db_name', parsedData?.db_name || null);
          localStorage.setItem('session_timestamp', Date.now().toString());
          localStorage.setItem('first_last_name',parsedData?.first_last_name || "");
          localStorage.setItem('sub_tenant_map', JSON.stringify(parsedData?.tenant_sub_tenant_dict || {}));
          localStorage.setItem('switch_user_20_modules_json', JSON.stringify(parsedData?.switch_user_20_modules_json || '{}'));
          const initial_timeout_frequency = parsedData?.ui_timeout
          const ui_timeout = initial_timeout_frequency && initial_timeout_frequency !== "None"
            ? Number(initial_timeout_frequency)
            : 15
          localStorage.setItem('ui_timeout', ui_timeout.toString())
          localStorage.setItem('is_deploy_banner_close', "false");
        }
      }
    } catch (error) {
      console.error("Error during login:", error);
      if (error instanceof Error) {
        Modal.error({
          title: "Cannot load modules",
          content:
            error.message ||
            "An unexpected error occurred during login. Please try again.",
          centered: true,
        });
        setError(error);
      } else {
        Modal.error({
          title: "Cannot load modules",
          content:
            "An unexpected error occurred during login. Please try again.",
          centered: true,
        });
        setError(new Error(error + ""));
      }
    } finally {
      setLoading(false);
    }
  };

  const handleLoginUsingCode = async (
    code: string,
    username: string,
    role?: string | null,
    tenantId?: string | null,
    tenantName?: string | null,
    
  ) => {
    // TODO: Remove hardcoded database name
    const loginDatabase = "altaworx_central";
    const _role = role || "";

    setDbName(loginDatabase);
    setEmail(username);
    setUsername(username);
    setFirstLastName(firstLastName);
    setRole(_role);
    setSelectedDb(loginDatabase);

    localStorage.setItem('username', username);
    localStorage.setItem('role_name', _role);
    localStorage.setItem('tenant_id', tenantId || "");
    localStorage.setItem('db_name', loginDatabase);

    if (tenantName) {
      await handleSelectedPartner(tenantName);
      localStorage.setItem('tenant_name', tenantName);
    }
    await loadModules(
      username,
      _role,
      code,
      tenantId || "",
      tenantName ||""
    );
  };

  return (
    <AuthContext.Provider
      value={{
        loading,
        error,
        setLoading,
        tabledata,settabledata,
        selectedPartnerModule,
        setSelectedPartnerModule,
        Environment,
        setSelectedEnvironment,
        isAuthenticated,
        setIsAuthenticated,
        isReset,
        login,
        logout,
        LogoutChooseTenant,
        partner,
        setPartner,
        tenantId,
        setTenantId,
        selectedPartner,
        setSelectedPartner,
        username,
        setUsername,
        firstLastName,
        setFirstLastName,
        handleSelectedPartner,
        showPasswordUpdate,
        setShowPasswordUpdate,
        showPassword,
        setShowPassword,
        isSubTenant,
        setIsSUbTenant,
        modulesVersionMap,
        setModulesVersionMap,
        tenantNames,
        setTenantNames,
        isSubTenantMap,
        setIsSubTenantMap,
        selectedDb,
        setSelectedDb,
        selectedBillingDb,
        setSelectedBillingDb,
        role,
        setRole,
        modules,
        setModules,
        dynamicColumns,
        setDynamicColumns,
        logoUrl,
        setLogoUrl,
        collapsedLogoUrl,
        setCollapsedLogoUrl,
        darkModeCollapsedLogoUrl,
        setDarkModeCollapsedLogoUrl,
        darkModeLogoUrl,
        setDarkModeLogoUrl,
        serviceProviderList,
        setServiceProviderList,
        selectedServiceProvider,
        setSelectedServiceProvider,
        firstModuleRoute,
        setFirstModuleRoute,
        storedpagination,
        setStoredPagination,
        advancedStoredpagination,
        setAdvancedStoredPagination,
        combineAdnvaceStoredpagination,
        setCombineAdnvaceStoredpagination,
        wholeSearchWord,
        setWholeSearchWord,
        token,
        setToken,
        sessionId,
        setSessionId,
        email,
        setEmail,
        tenantName,
        setTenantName,
        dbName,
        setDbName,
        password,
        setPassword,
        handleLoginUsingCode,
        metaData,
        setMetaData
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
