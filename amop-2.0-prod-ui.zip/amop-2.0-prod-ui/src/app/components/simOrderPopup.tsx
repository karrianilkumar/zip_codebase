"use client";
import React from "react";
import { Form, Input, Checkbox, Button, Select, Col, Row, Modal } from "antd";
import { ChevronDownIcon } from "@heroicons/react/24/outline";

const { Option } = Select;

interface SimFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  rowData: any;
  tableData?: any;
}

const DisplaySimOrder: React.FC<SimFormModalProps> = ({
  isOpen,
  onClose,
  rowData,
  tableData = [],
}) => {
  // Parse the sim_info string to a JSON array
  let simInfoArray = [];
  try {
    simInfoArray = JSON.parse(rowData.sim_info.replace(/'/g, '"'));
    console.log("simInfoArray",simInfoArray)
  } catch (error) {
    console.error("Failed to parse sim_info:", error);
  }
  const modalHeight =
    typeof window !== "undefined" ? (window.innerHeight * 3) / 4 : 0;

  return (
    <Modal
      visible={isOpen}
      onCancel={onClose}
      footer={null}
      title={
        <div className="mt-[-10px] ml-4">
          <span className="text-[18px]">SIM Order form Details</span>
        </div>
      }
          width={800}
          style={{
            top: '10vh', // 10% from the top of the screen
            height: '80vh', // 80% of the screen height
            padding: "5px",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
    >
      <div
        style={{
          padding: "10px",
          textAlign: "left",
          height: modalHeight,
          overflowY: "auto",
        }}
      >
        <Form layout="vertical">
          <Row gutter={16}>
            <Col span={12}>
              <Form.Item label={<span className="field-label">Company</span>}>
                <Input
                  className="non-editable-input"
                  value={rowData?.company || ""}
                  readOnly
                />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                label={<span className="field-label">Contact Name</span>}
              >
                <Input
                  className="non-editable-input"
                  value={rowData?.contact_name || ""}
                  readOnly
                />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item label={<span className="field-label">Email</span>}>
                <Input
                  className="non-editable-input"
                  value={rowData?.email || ""}
                  readOnly
                />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                label={
                  <span className="field-label">
                    Country<span className="text-red-500">*</span>
                  </span>
                }
              >
                <Input
                  className="non-editable-input"
                  value={rowData?.country || ""}
                  readOnly
                />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                label={
                  <span className="field-label">
                    Shipping Address<span className="text-red-500">*</span>
                  </span>
                }
              >
                <Input.TextArea
                  className="non-editable-input"
                  value={rowData?.shipping_address || ""}
                  readOnly
                  disabled
                  rows={3}
                />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                label={
                  <span className="field-label">Special Instructions</span>
                }
              >
                <Input.TextArea
                  className="non-editable-input"
                  value={rowData?.special_instructions || ""}
                  readOnly
                  disabled
                  rows={3}
                />
              </Form.Item>
            </Col>
            <Col span={24}>
              <Form.Item>
                <Checkbox checked={rowData?.expedite === "true"} disabled>
                  Expedite
                </Checkbox>
              </Form.Item>
            </Col>
          </Row>

          <div className={`grid grid-cols-1 xl:grid-cols-2 gap-4`}>
            {simInfoArray.map((sim: any, index: number) => (
              <div
                className={`form-block w-full ${
                  simInfoArray.length % 2 !== 0 &&
                  index === simInfoArray.length - 1
                    ? "sm:w-6/7"
                    : "sm:w-full"
                } mx-auto`}
                key={index}
              >
                <div className="grid grid-cols-1">
                  <Form.Item
                    label={
                      <span className="field-label">
                        Carrier<span className="text-red-500">*</span>
                      </span>
                    }
                  >
                    <Select
                      defaultValue={sim.carrier}
                      className="non-editableDrp "
                      suffixIcon={
                        <ChevronDownIcon className="w-5 h-5 mt-2 text-gray-600" />
                      }
                      disabled
                    >
                      <Option key={sim.carrier} value={sim.carrier}>
                        {sim.carrier}
                      </Option>
                    </Select>
                  </Form.Item>
                  <Form.Item
                    label={
                      <span className="field-label">
                        SIM Size<span className="text-red-500">*</span>
                      </span>
                    }
                  >
                    <Select
                      defaultValue={sim["SIM Size"]}
                      className="non-editableDrp"
                      suffixIcon={
                        <ChevronDownIcon className="w-5 h-5 mt-2 text-gray-600" />
                      }
                      disabled
                    >
                      <Option key={sim["SIM size"]} value={sim["SIM Size"]}>
                        {sim["SIM size"]}
                      </Option>
                    </Select>
                  </Form.Item>
                  <Form.Item
                    label={
                      <span className="field-label">
                        Quantity<span className="text-red-500">*</span>
                      </span>
                    }
                  >
                    <Input
                      className="non-editable-input"
                      value={sim.Quantity}
                      readOnly
                    />
                  </Form.Item>
                </div>
              </div>
            ))}
          </div>
        </Form>
      </div>
    </Modal>
  );
};

export default DisplaySimOrder;
