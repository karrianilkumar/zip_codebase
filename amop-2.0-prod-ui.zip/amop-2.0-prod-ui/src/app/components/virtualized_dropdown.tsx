import React, { useState, useCallback, useEffect } from "react";
import Select, { components } from "react-select";
import { FixedSizeList as List } from "react-window";

// Custom 'No options' message component
const NoOptionsMessage = (props: any) => {
  return (
    <components.NoOptionsMessage {...props}>
      <span className="text-gray-500">No Options</span>
    </components.NoOptionsMessage>
  );
};

// Component to display virtualized options in the dropdown
const VirtualizedOptionList = ({
  options,
  children,
  maxHeight,
  selectProps,
  ...props
}: any) => {
  const [optionCount, setOptionCount] = useState(20); // Initially load 20 options
  const height = 50; // Height of each option
  const totalHeight = Math.min(maxHeight, options.length * height);

  // Load more options dynamically when needed
  const loadMoreItems = () => {
    if (optionCount < options.length) {
      setOptionCount(optionCount + 20); // Load 20 more items
    }
  };

  // Option component to render each option
  const Option = ({ index, style }: any) => {
    const option = options[index]; // Get the correct option

    return (
      <div
        style={style}
        onClick={() => {
          selectProps.onChange(option); // Pass the full option object
        }}
      >
        {children[index]}
      </div>
    );
  };

  // Check if there are no options and render the "No options" message
  if (options.length === 0) {
    return (
      <div style={{ padding: 10, textAlign: "center" }}>
        <span className="text-gray-500">No Options</span>
      </div>
    );
  }

  // Row component to pass the option to List
  const Row = ({ index, style }: any) => (
    <Option key={index} index={index} style={style} />
  );

  return (
    <List
      height={totalHeight}
      itemCount={Math.min(optionCount, options.length)} // Show only the available options
      itemSize={height}
      width="100%"
      onItemsRendered={loadMoreItems} // Load more items as needed
    >
      {Row}
    </List>
  );
};

// Custom select component with virtualized options and a "No options" message
const VirtualizedSelect = (props: any) => {
  const [filteredOptions, setFilteredOptions] = useState(props.options || []);

  // Ensure that filteredOptions is set on the initial render
  useEffect(() => {
    setFilteredOptions(props.options || []);
  }, [props.options]);

  // Handle input change to filter options dynamically
  const handleInputChange = useCallback(
    (inputValue: string) => {
      // Check if props.options is valid and an array
      const validOptions = Array.isArray(props.options) ? props.options : [];
    
      const newFilteredOptions = validOptions.filter((option: any) =>
        option?.label?.toLowerCase().includes(inputValue?.toLowerCase()) || ""
      );
    
      setFilteredOptions(newFilteredOptions);
    },
    [props.options]
  );

  return (
    <Select
      {...props}
      options={filteredOptions} // Use the filtered options
      isClearable
      components={{
        MenuList: VirtualizedOptionList,
        NoOptionsMessage, // Still passing the NoOptionsMessage, though handled in VirtualizedOptionList
      }}
      onInputChange={handleInputChange}
    />
  );
};

export default VirtualizedSelect;
