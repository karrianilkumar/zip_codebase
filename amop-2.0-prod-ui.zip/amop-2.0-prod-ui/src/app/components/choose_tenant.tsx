// pages/choose_tenant.tsx
import React, { useEffect, useState } from 'react';
import Image from 'next/image';
import { Button, Modal, Spin } from 'antd';
import axios from 'axios';
import { useAuth } from './auth_context';
import { useRouter } from 'next/navigation';
import { getCurrentDateTime } from './header_constants';
import { useLogoStore } from '../stores/logoStore';
import { FaArrowDown, FaArrowUp } from 'react-icons/fa'; // Import arrow icons
import { ENV_ROUTES } from './routes/route_constants';
import { ChevronDownIcon, ChevronUpIcon } from '@heroicons/react/24/outline';

interface Partner {
  id: number;
  name: string;
  subPartners: SubPartner[];

}
interface SubPartner {
  id: number;
  name: string;
}
const ChooseTenant: React.FC = () => {
  const { setSelectedPartner, setPartner, setModules, token, setFirstModuleRoute, setTenantId,logoUrl,setLogoUrl, setIsSUbTenant ,isSubTenantMap, setMetaData} = useAuth(); // Extract both setters from context
  const [selectedPartnerName, setSelectedPartnerName] = useState<string | null>(null);
  const [showSubPartners, setShowSubPartners] = useState(false);
  const [openSubPartnerId, setOpenSubPartnerId] = useState<number | null>(null); // Tracks the open partner's ID
  const [loading, setLoading] = useState(false); // State to manage loading
  // const { setLogoUrl, logoUrl } = useLogoStore();
  const router = useRouter();
  const { username, tenantNames, role, setShowPassword, setShowPasswordUpdate, showPasswordUpdate, setSelectedDb, selectedDb,setSelectedBillingDb, firstLastName, sessionId, password } = useAuth()
  const partners = tenantNames as any[]
  const setTitle = useLogoStore((state) => state.setTitle);

  // const handleSelectedPartner = async (partnerName: string,parentPartner:string) => {
  //   setSelectedPartnerName(partnerName);
  //   const db_name=dbNames?.[parentPartner] || null
  //   setSelectedDb(db_name)
  //   localStorage.setItem('db_name', db_name);
  //   const data = {
  //     path: "/get_modules",
  //     role_name: role,
  //     username: username,
  //     tenant_name: partnerName,
  //     Partner: partnerName,
  //     request_received_at: getCurrentDateTime(),
  //     access_token: token,
  //     db_name: db_name,
  //   };
  //   setLoading(false)
  //   try {
  //     const url =ENV_ROUTES.MODULE_MANAGEMENT;
  //     const response = await axios.post(url, { data: data }, {
  //       headers: {
  //         'Content-Type': 'application/json'
  //       }
  //     }
  //     );

  //     if (response.status === 200) {
  //       setShowPasswordUpdate(false)
  //       if (!showPasswordUpdate) {
  //         setTitle("Home")
  //       }
  //       const parsedData = JSON.parse(response.data.body); // Parse the response body

  //       if (parsedData.error) {
  //         // Show error popup if there's an error in the response
  //         Modal.error({
  //           title: 'Module Fetch Error',
  //           content: parsedData.error || 'An error occurred while fetching modules. Please try again.',
  //         });
  //       } else if (parsedData.flag === false) {
  //         // Show error popup if the flag is false
  //         Modal.error({
  //           title: 'Module Fetch Error',
  //           content: parsedData.message || 'An error occurred while fetching modules. Please try again.',
  //         });
  //       } else {
  //         const logoUrl_ = parsedData?.logo
  //         setLogoUrl(logoUrl_ || null)
  //         setSelectedPartner(true);
  //         setModules(parsedData?.Modules || []); // Set the modules state
  //         setPartner(partnerName);
  //         localStorage.setItem('tenant_name', partnerName);
  //         console.log("modules",parsedData?.Modules)
  //         localStorage.setItem('modules', JSON.stringify(parsedData?.Modules || []));
  //         console.log(parsedData?.Modules,"Modules list")
  //         router.push('/dashboard');
  //       }
  //     } else {
  //       Modal.error({
  //         title: 'Module Fetch Error',
  //         content: response.data.message || 'Fetching modules failed. Please try again.',
  //       });
  //     }
  //   } catch (error) {
  //     // Type guard to check if error is an instance of Error
  //     if (error instanceof Error) {
  //       Modal.error({
  //         title: 'Module Fetch Error',
  //         content: error.message || 'An unexpected error occurred while fetching modules. Please try again.',

  //       });
  //     } else {
  //       Modal.error({
  //         title: 'Module Fetch Error',
  //         content: 'An unexpected error occurred while fetching modules. Please try again.',
  //       });
  //     }
  //     setLoading(false)
  //   }
  // };
  const handleSelectedPartner = async (
    partnerId: number | string,
    partnerName: string,
    parentPartner: string,
  ) => {
    setSelectedPartnerName(partnerName);
    setTenantId(partnerId)
    const data = {
      path: "/get_modules",
      role_name: role,
      username: username,
      firstLastName: firstLastName,
      sessionID: sessionId,
      tenant_name: partnerName,
      Partner: partnerName,
      request_received_at: getCurrentDateTime(),
      access_token: token,
    };

    setLoading(true);

    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const response = await axios.post(url, { data: data }, {
        headers: {
          'Content-Type': 'application/json',
        },
      });

      if (response.status === 200) {
        const parsedData = JSON.parse(response.data.body);

        if (parsedData.error) {
          setLoading(false);
          Modal.error({
            title: 'Module Fetch Error',
            content: parsedData.error || 'An error occurred while fetching modules. Please try again.',
          });
        } else if (parsedData.flag === false) {
          setLoading(false);
          Modal.error({
            title: 'Module Fetch Error',
            content: parsedData.message || 'An error occurred while fetching modules. Please try again.',
          });
        } else {
          const dbName = parsedData?.db_name || "";
          const billingDbName = dbName.includes("_beta")
            ? dbName.replace("_beta", "_billing_platform_beta")
            : dbName === "altaworx_test"
              ? "billing_platform"
              : `${dbName}_billing_platform`;
          const logoUrl_ = parsedData?.logo;
          // setLogoUrl(logoUrl_ || null);
          // setSelectedPartner(true);
          setModules(parsedData?.Modules || []);
          setSelectedDb(parsedData?.db_name || null);
          setSelectedBillingDb(billingDbName)
          setPartner(partnerName);
          const isSubTenantMap_: any = JSON.parse(localStorage.getItem('sub_tenant_map') || '{}');
          const isSubPartner_=isSubTenantMap_[partnerName] || false
          setIsSUbTenant(isSubPartner_)
          const meta_data_ = {
            db_config_details :parsedData?.db_config_details || {}
          }
          setMetaData(meta_data_);
          localStorage.setItem('meta_data',JSON.stringify(meta_data_));
          localStorage.setItem('tenant_name', partnerName);
          localStorage.setItem('tenant_id', partnerId + "");
          localStorage.setItem('modules', JSON.stringify(parsedData?.Modules || []));
          localStorage.setItem('db_name', parsedData?.db_name || null);
          localStorage.setItem("billing_db_name", billingDbName);
          localStorage.setItem('logo', parsedData?.logo || null);
          localStorage.setItem('collapsed_logo', parsedData?.collapsed_logo || null);
          localStorage.setItem('dark_mode_collapsed_logo', parsedData?.dark_mode_collapsed_logo || null);
          localStorage.setItem('dark_mode_logo', parsedData?.dark_mode_logo || null);
          localStorage.setItem('is_sub_tenant', (isSubPartner_ || false).toString());
          localStorage.setItem('bp_flag', parsedData?.billing_platform_flag || false);
          const initial_timeout_frequency = parsedData?.ui_timeout
          const ui_timeout = initial_timeout_frequency && initial_timeout_frequency !== "None"
            ? Number(initial_timeout_frequency)
            : 15
          localStorage.setItem('ui_timeout', ui_timeout.toString())
          // Extract the first module name
          const firstModule = parsedData?.Modules?.[0];
          let firstModulePath = '';
          
          if (firstModule) {
            // If there are sub-modules, route to the first child
            if (firstModule.children && firstModule.children.length > 0) {
              firstModulePath = `/${firstModule.parent_module_name.toLowerCase().replace(/\s+/g, '_')}/${firstModule.children[0].child_module_name.toLowerCase().replace(/\s+/g, '_')}`;
            } else {
              // Route to the parent module if no children exist
              firstModulePath = `/${firstModule.parent_module_name.toLowerCase().replace(/\s+/g, '_')}`;
            }
          }
          console.log(firstModulePath, "Print first module path");
          localStorage.setItem('is_deploy_banner_close', "false");
          // Route to the first module
          setFirstModuleRoute(firstModulePath);
          // router.push(firstModulePath);

          // Redirect to AMOP 1.0
          loginSyncToAmop1(partnerName, firstModulePath);
        }
      } else {
        setLoading(false);
        Modal.error({
          title: 'Module Fetch Error',
          content: response.data.message || 'Fetching modules failed. Please try again.',
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: 'Module Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching modules. Please try again.',
      });
    } finally {
      // setLoading(false);
    }
  };
  const loginSyncToAmop1 = (partnerName: any, firstModulePath: any) => {
    const form = document.createElement('form');
    form.style.display = 'none';
    form.method = 'POST';
    // form.action = 'https://sandbox.amop.services/Login/Sync';
    form.action = process.env.NEXT_PUBLIC_AMOP_1_BASE_URL + "/Login/Sync";
    const pswd = localStorage.getItem("pass_word") || "Amop@123"
    const inputs = [
      { name: 'username', value: username },
      { name: 'password', value: pswd },
      { name: 'tenantName', value: partnerName },
      // { name: 'returnUrl', value: document.location.origin }
      { name: 'returnUrl', value: `${document.location.origin}/${firstModulePath}` }

    ];

    inputs.forEach(inputData => {
      const input = document.createElement('input');
      input.type = 'hidden';
      input.name = inputData.name;
      input.value = inputData.value;
      form.appendChild(input);
    });

    document.body.appendChild(form);
    form.submit();
  };


  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  // const mainPartners = partners.slice(0, 10);
  // const altrorxPartner = partners.length > 9 ? partners[9] : null;
  const sortedPartners:any = [...partners].sort((a, b) => a.name.localeCompare(b.name));

  const mainPartners: Partner[] = [...sortedPartners];

  return (
    <div className="flex flex-col justify-center items-center w-full p-5">
      <div className="w-[250px] md:w-[300px] h-[50px] md:h-[55px] mb-2">
        <Image
          src="/amop_logo_header.png"
          alt="AMOP Core Logo"
          width={300}
          height={55}
          className="w-full h-full object-contain"
        />
      </div>

      <h1 className="text-2xl md:text-[28px] text-[#00C1F1] font-medium mb-4">Choose Partner</h1>

      <div className="w-full box-border px-2 md:px-6 flex justify-center">
        <div
           className={
    mainPartners.length >= 4
      ? "grid gap-5 grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 w-full"
      : "flex justify-center items-center gap-4"
  }>
          {mainPartners.map((partner: Partner) => (
            <div key={partner.id} className="">
              <div className="flex items-center w-full mb-4">

                <button
                  onClick={() =>
                    handleSelectedPartner(partner.id, partner.name, partner.name)
                  }
                  className={`flex items-center justify-center text-md border 
                ${selectedPartnerName === partner.name
                      ? "bg-transparent text-[#00C1F1]"
                      : "bg-[#00C1F1] text-white"
                    }`}
                  style={{
                    width:
                      partner.subPartners && partner.subPartners.length > 0 && mainPartners.length >= 4 ? "90%" : (partner.subPartners && partner.subPartners.length > 0) || mainPartners.length < 4
                        ? "350px"
                        : "100%",
                    height: "40px",
                    transition: "all 0.3s",
                    border: "1px solid #00C1F1",
                    borderTopRightRadius:
                      partner.subPartners && partner.subPartners.length > 0
                        ? "0"
                        : "8px",
                    borderBottomRightRadius:
                      partner.subPartners && partner.subPartners.length > 0
                        ? "0"
                        : "8px",
                    borderTopLeftRadius: "8px",
                    borderBottomLeftRadius: "8px",
                  }}
                >
                  {partner.name}
                </button>

                {partner.subPartners && partner.subPartners.length > 0 && (
                  <button
                    onClick={() =>
                      setOpenSubPartnerId(
                        openSubPartnerId === partner.id ? null : partner.id
                      )
                    }
                    style={{
                      width: "10%",
                      background: "#00C1F1",
                      border: "1px solid #00C1F1",
                      borderLeft: "1px solid #fff",
                      cursor: "pointer",
                      color: "white",
                      borderTopRightRadius: "8px",
                      borderBottomRightRadius: "8px",
                      height: "40px",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    {openSubPartnerId === partner.id ? (
                      <ChevronUpIcon className="w-5 h-5" />
                    ) : (
                      <ChevronDownIcon className="w-5 h-5" />
                    )}
                  </button>
                )}
              </div>

              {openSubPartnerId === partner.id &&
                partner.subPartners &&
                partner.subPartners.length > 0 && (
                <div className={`${mainPartners.length <= 4 ? "absolute " : ""}grid gap-2 mt-2 grid-cols-1 lg:grid-cols-2`}
                >
                    {partner.subPartners.map((subPartner: SubPartner) => (
                      <button
                        key={subPartner.id}
                        className={`flex items-center justify-center text-md border ${selectedPartnerName === subPartner.name
                          ? "bg-[#00C1F1] text-white"
                          : "bg-transparent text-[#00C1F1]"
                          }`}
                        onClick={() =>
                          handleSelectedPartner(
                            subPartner.id,
                            subPartner.name,
                            partner.name
                          )
                        }
                        style={{
                          minHeight: "40px",
                          padding: "10px",
                          transition: "all 0.3s",
                          borderRadius: "8px",
                          overflow: "hidden",
                          textOverflow: "ellipsis",
                        }}
                      >
                        {subPartner.name}
                      </button>
                    ))}
                  </div>
                )}
            </div>
          ))}
        </div>
      </div>
    </div>

  );
};

export default ChooseTenant;
