"use client";

import React, { useState, useEffect, useRef } from 'react';
import Pagination from '../pagination';
import { useRevStore } from '@/app/stores/revStore';
import EffectiveDate from '@/app/sim_management/revenue_assurance/effective-cell-renderer';
import { ArrowDownOutlined, ArrowUpOutlined } from '@ant-design/icons';
import { useAuth } from '../auth_context';
import { Spin, Tooltip } from 'antd';
import { useSearchStore } from '@/app/stores/searchStore';
interface TableComponentProps {
    headers: string[];
    headerMap: any;
    initialData: any[];
    searchQuery?: string;
    visibleColumns: string[];
    itemsPerPage: number;
    moduleName: string;
    allowedActions?: (
        | "download"
        | "upload"
        | "info-status"
    )[];
    pagination: {
        start: number;
        end: number;
        total: number;
    };
    onDateChange: (rowIndex: number, date: string | null) => void;
    advancedFilters?: any;
}

const DisconnectProductTable: React.FC<TableComponentProps> = ({
    headers,
    headerMap,
    initialData,
    visibleColumns,
    itemsPerPage,
    moduleName,
    pagination,
    onDateChange,
    allowedActions

}) => {
    const [rowData, setRowData] = useState(initialData);
    const [currentPage, setCurrentPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [selectedRows, setSelectedRows] = useState<number[]>([]);
    const [selectAll, setSelectAll] = useState(false);
    const [applyEffectiveDateAll, setApplyEffectiveDateAll] = useState(false);
    const [dates, setDates] = useState<{ [key: string]: string | null }>({});
    const [sortConfig, setSortConfig] = useState<{ key: string; direction: "ascending" | "descending"; } | null>(null);
    // Get revRows and setRevRows from the revStore
    const { setRevActionRows, setRevHeaders, isClosed, setIsClosed, showVarianceStatus } = useRevStore();
    const [loading, setLoading] = useState(false);
    const [isDownload, setIsDownload] = useState(false);
    const [downloadRowIndex, setDownloadRowIndex] = useState<number | null>(null);
    const [isUpload, setIsUpload] = useState(false);
    const [uploadRowIndex, setUploadRowIndex] = useState<number | null>(null);
    console.log("Show variance", showVarianceStatus);

    const {
        tabledata,
        storedpagination,
        advancedStoredpagination,
        setAdvancedStoredPagination,
        setStoredPagination,
        firstLastName
    } = useAuth();
    //Viewport height
    const [viewportHeight, setViewportHeight] = useState(window.innerHeight);

    useEffect(() => {
        const handleResize = () => {
            setViewportHeight(window.innerHeight);
        };

        // Add event listener for window resize
        window.addEventListener("resize", handleResize);

        // Cleanup event listener on component unmount
        return () => {
            window.removeEventListener("resize", handleResize);
        };
    }, []);


    useEffect(() => {
        setRowData(initialData);
        setSelectedRows([])
    }, [initialData]);


    useEffect(() => {
        setCurrentPage(1);
    }, [totalPages]);


    useEffect(() => {
        let pagination_: any
        if (moduleName === "Rev assurance") {
            pagination_ = storedpagination ? storedpagination : advancedStoredpagination ? advancedStoredpagination : pagination
        }
        else {
            pagination_ = pagination
        }
        // const pagination_ = pagination;
        const start = pagination_?.start || 1;
        const total = pagination_?.total || 1;
        const end = pagination_?.end || 1;
        const lastPageWithData_ = Math.floor(end / itemsPerPage);
        const totalPages_ = Math.ceil(total / itemsPerPage);
        const currentPage_ = Math.floor(start / itemsPerPage) + 1;
        setTotalPages(totalPages_);
        // setCurrentPage(currentPage_);
        // setLastPageWithData(lastPageWithData_);
    }, [tabledata, initialData, pagination, itemsPerPage, currentPage, storedpagination, advancedStoredpagination]);


    useEffect(() => {
        const updatedRows_ = selectedRows.map((i) => rowData[i])
        setRevActionRows(updatedRows_); // Store the selected rows in revStore
    }, [selectedRows]);


    //For sorting the table
    const handleSort = (key: string) => {
        let direction: "ascending" | "descending" = "ascending";
        if (
            sortConfig &&
            sortConfig.key === key &&
            sortConfig.direction === "ascending"
        ) {
            direction = "descending";
        }

        const sortedData = [...rowData].sort((a, b) => {
            let aValue = a[key];
            let bValue = b[key];

            // Special handling for the "Assigned rate plans" or "Assigned rate plan count" columns
            if (key === "carrier_rate_plans") {
                aValue = Array.isArray(aValue) ? aValue.length : JSON.parse(aValue)?.length || 0;
                bValue = Array.isArray(bValue) ? bValue.length : JSON.parse(bValue)?.length || 0;
            }

            // Convert 'None' to null for easier comparison
            const normalizeValue = (value: any) => {
                if (value === 'None') return null;
                return value;
            };

            aValue = normalizeValue(aValue);
            bValue = normalizeValue(bValue);

            // Function to split a string into alphabetical and numeric segments
            const splitIntoSegments = (str: string) => {
                return str.toLowerCase().match(/([a-z]+|\d+)/g) || [];
            };

            // Split values into segments
            const aSegments = typeof aValue === "string" ? splitIntoSegments(aValue) : [aValue];
            const bSegments = typeof bValue === "string" ? splitIntoSegments(bValue) : [bValue];

            // Compare each segment one by one
            for (let i = 0; i < Math.max(aSegments.length, bSegments.length); i++) {
                const aSegment = aSegments[i];
                const bSegment = bSegments[i];

                // If one segment is undefined, consider it smaller
                if (aSegment === undefined) return direction === "ascending" ? -1 : 1;
                if (bSegment === undefined) return direction === "ascending" ? 1 : -1;

                // Compare numeric segments numerically, and character segments lexicographically
                const isANumber = !isNaN(Number(aSegment));
                const isBNumber = !isNaN(Number(bSegment));

                if (isANumber && isBNumber) {
                    // Both segments are numbers; compare them numerically
                    const numA = Number(aSegment);
                    const numB = Number(bSegment);
                    if (numA < numB) return direction === "ascending" ? -1 : 1;
                    if (numA > numB) return direction === "ascending" ? 1 : -1;
                } else {
                    // At least one segment is not a number; compare them as strings
                    if (aSegment < bSegment) return direction === "ascending" ? -1 : 1;
                    if (aSegment > bSegment) return direction === "ascending" ? 1 : -1;
                }
            }

            return 0;
        });

        setSortConfig({ key, direction });
        setRowData(sortedData);
    };

    const handleCloseModal = () => {
        setIsDownload(false);
        setDownloadRowIndex(null);
        setIsUpload(false);
        setUploadRowIndex(null);
    }

    // Toggle row selection and store in revStore
    const toggleRowSelection = (index: number) => {
        setSelectAll(false);
        setIsClosed(false)
        let updatedSelectedRows: number[];

        if (selectedRows.includes(index)) {
            updatedSelectedRows = selectedRows.filter((i) => i !== index);
        } else {
            updatedSelectedRows = [...selectedRows, index];
        }
        setSelectedRows(updatedSelectedRows);
    };

    // Toggle all rows selection and store in revStore
    const toggleSelectAll = () => {
        setIsClosed(false)
        let updatedSelectedRows: number[];

        if (selectAll) {
            updatedSelectedRows = [];
        } else {
            updatedSelectedRows = rowData.map((_, index) => index);
        }

        setSelectedRows(updatedSelectedRows);
        setSelectAll(!selectAll);
    };

    //toggle to apply effective date to all rows
    const toggleEffectiveDate = (checked: boolean) => {
        setApplyEffectiveDateAll(checked)
    };

    const handleDateChange = (rowIndex: number, date: string | null) => {
        let updatedRowData = [...rowData];

        if (applyEffectiveDateAll) {
            updatedRowData = updatedRowData.map(row => ({
                ...row,
                ['Effective Date']: date,
            }));
            // Optional: If you want to notify that all dates changed, you can loop or modify `onDateChange`
            updatedRowData.forEach((_, idx) => onDateChange(idx, date));
        } else {
            updatedRowData[rowIndex]['Effective Date'] = date;
            onDateChange(rowIndex, date);
        }

        setRowData(updatedRowData);
    };


    //For custom cell rendering
    const renderCell = (row: any, column: string, rowIndex: number) => {
        if (column === 'Effective Date') {
            return (
                <EffectiveDate
                    selectedDate={row['Effective Date'] || null}
                    handleDateChange={(date) => handleDateChange(rowIndex, date)}
                />
            );
        }
        return row[column];
    };

    const getRowBgColor = (index: number, row: any) => {
        if (selectedRows.includes(index)) {
            return 'bg-blue-100';
        } else if (moduleName === 'Optimization' && row.run_status === 'Complete with Success') {
            return 'bg-green-100';
        } else if (moduleName === 'Optimization' && row.run_status === 'Complete with Errors') {
            return 'bg-red-100';
        }
        else if (moduleName === 'Optimization' &&
            (row.run_status === 'Comm Group Setup'
                || row.run_status === 'Enqueue Permutations'
                || row.run_status === 'Running Permutations'
                || row.run_status === 'Cleaning Up')) {
            return 'bg-yellow-100';
        }
        else {
            return "even-table-row"
        }

        return ''; // Default no background color
    };

    if (loading) {
        return (
            <div className="flex justify-center items-center h-screen">
                <Spin size="large" />
            </div>
        );
    }


    return (
        <div>
            <div className="overflow-x-auto">
                <div className="overflow-y-auto" style={{
                    height: moduleName === "Rev assurance"
                        ? `${viewportHeight - 330}px`
                        : "auto" // Apply auto height when moduleName matches
                }}>
                    <table className="table-auto w-full">
                        <thead className="sticky top-0 bg-gray-200 disconnect-table-header z-10">
                            <tr>
                                {/* <th className="px-6 py-3 border-b border-gray-300 text-left font-semibold table-header sticky top-0 ">
                                    {moduleName !== 'Customer charges' && (
                                        <input
                                            type="checkbox"
                                            checked={selectAll}
                                            onChange={toggleSelectAll}
                                            className='hover:cursor-pointer'
                                        />
                                    )}
                                </th> */}
                                {headers.map((header) => (
                                    headerMap && headerMap[header] && visibleColumns.includes(header) && (
                                        <th
                                            key={header}
                                            className="px-6 py-3 border-b border-gray-300 text-left font-semibold table-header sticky top-0"
                                            onClick={() => {
                                                if (headerMap[header][0] !== 'Effective Date') { handleSort(header) }
                                            }
                                            }
                                            style={{ cursor: "pointer" }}
                                        >
                                            {headerMap[header][0] === 'Effective Date' ? (
                                                <>
                                                    <input
                                                        type="checkbox"
                                                        checked={applyEffectiveDateAll}
                                                        onChange={(e) => toggleEffectiveDate(e.target.checked)}
                                                        className='hover:cursor-pointer mr-2'
                                                    />
                                                    {headerMap[header][0] || header}
                                                </>
                                            ) : (
                                                <>
                                                    {headerMap[header][0] || header}
                                                    {sortConfig && sortConfig.key === header ? (
                                                        sortConfig.direction === "ascending" ? (
                                                            <ArrowUpOutlined className="sorting-arrow" style={{ marginLeft: 8 }} />
                                                        ) : (
                                                            <ArrowDownOutlined className="sorting-arrow" style={{ marginLeft: 8 }} />
                                                        )
                                                    ) : (
                                                        <ArrowUpOutlined
                                                            style={{ marginLeft: 8, opacity: 0.5 }}
                                                        />
                                                    )}
                                                </>

                                            )}

                                        </th>
                                    )
                                ))}
                                {allowedActions && visibleColumns.length > 0 && (
                                    <th className="px-6 border-b border-gray-300 text-left font-semibold table-header">
                                        <span>Actions</span>
                                    </th>
                                )}

                            </tr>
                        </thead>
                        <tbody>
                            {rowData
                                .map((row, index) => (
                                    <tr
                                        key={index}
                                        className={getRowBgColor(index, row)}
                                    // onClick={() => toggleRowSelection(index)}
                                    >
                                        {/* <td className="px-6 py-3 border-b border-gray-300 table-cell">
                                            {moduleName !== 'Customer charges' && (

                                                <input
                                                    type="checkbox"
                                                    checked={selectedRows.includes(index)}
                                                    onChange={() => toggleRowSelection(index)}
                                                    className='hover:cursor-pointer'
                                                />
                                            )}


                                        </td> */}
                                        {headers.map((header, columnIndex) =>
                                            visibleColumns.includes(header) && headerMap[header] && (
                                                <td key={columnIndex} className="px-6 py-3 border-b border-gray-300 table-cell">
                                                    {row[header] != "None" ? (
                                                        <Tooltip
                                                            title={`${row[header]}`}
                                                            placement="topLeft"
                                                            overlayStyle={{ whiteSpace: 'normal', maxWidth: '60vw', wordWrap: 'break-word' }}
                                                            getPopupContainer={(triggerNode) => (triggerNode.parentNode as HTMLElement) || document.body} // Fallback to document.body
                                                        >
                                                            {renderCell(row, header, index)}
                                                        </Tooltip>
                                                    ) : (
                                                        renderCell(row, header, index)
                                                    )}
                                                </td>
                                            )
                                        )
                                        }
                                    </tr>
                                ))}
                        </tbody>
                    </table>
                </div>
            </div>
            <div className="flex justify-center mt-5">
                {/* {moduleName !== "Disconnect Service Product" && ( */}
                <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} moduleName={moduleName} />
                {/* )} */}
            </div>
        </div>
    );
};

export default DisconnectProductTable;
