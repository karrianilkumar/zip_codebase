import React, { useEffect, useState } from "react";
import { ChevronLeftIcon, ChevronRightIcon } from "@heroicons/react/24/outline";
import { DoubleLeftOutlined, DoubleRightOutlined, ForwardFilled, BackwardFilled, CaretRightFilled, CaretLeftFilled  } from "@ant-design/icons";
import { useAuth } from "./auth_context";
import { useSearchStore } from "../stores/searchStore";

interface PaginationProps {
  moduleName: string;
  initialData: any; 
  itemsPerPage: number; 
}
const NewPagination: React.FC<PaginationProps> = ({
  
  moduleName,initialData,itemsPerPage
}) => {
  const { storedpagination, advancedStoredpagination, combineAdnvaceStoredpagination  } = useAuth();
    const { setOptimizationErrorsData,optimizationErrorsData,withoutAPISearchData} = useSearchStore();
  const minPagesToShow = 5; // Minimum pages to show before ellipses
  const [totalPages, setTotalPages] = useState(0);
  const [tableData, setTabledata] = useState(initialData || []);
  // State to track screen width
  const [isSmallScreen, setIsSmallScreen] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);

  useEffect(() => {
    let tableData_ = withoutAPISearchData.length>0 ? withoutAPISearchData : initialData || [];
    setTabledata(tableData_);
    setOptimizationErrorsData(tableData_)
    const totalPages_=Math.ceil(tableData_.length / (itemsPerPage || 10))
    setTotalPages(totalPages_);
    setCurrentPage(1)
    // const initialFilteredData=tableData_.slice(0,totalPages_)
  }, [initialData,withoutAPISearchData]);

  useEffect(() => {
    const checkScreenSize = () => {
      setIsSmallScreen(window.innerWidth < 700);
    };
    
    // Initial check
    checkScreenSize();
    
    // Add event listener for window resize
    window.addEventListener('resize', checkScreenSize);
    
    // Clean up
    return () => window.removeEventListener('resize', checkScreenSize);
  }, []);

  //To handle and set the update pages when click on forward next
  const handleForwardNext = () => {
    setCurrentPage(currentPage + 5);
  };

  //To handle and set the update pages when click on backward prev
  const handleForwardPrev = () => {
    setCurrentPage(currentPage - 5);
  };

  //To handle and set the update pages when click on next
  const handleNext = () => {
    setCurrentPage(currentPage + 1);
  };

  //To handle and set the update pages when click on prev
  const handlePrev = () => {
    setCurrentPage(currentPage - 1);
  };

  const calculatePagesToShow = () => {
    const pagesToShow: (number | string)[] = [];
      // Check if the total number of pages is less than or equal to the minimum pages to show
      if (totalPages <= minPagesToShow) {
        // If total pages are less than or equal to minPagesToShow, show all pages
        for (let i = 1; i <= totalPages; i++) {
          pagesToShow.push(i);
        }
      }
      else {
        if (currentPage <= minPagesToShow) {
          const start_page = 1;
          const end_page = minPagesToShow + 1;
          for (let i = start_page; i < end_page; i++) {
            pagesToShow.push(i);
          }
          pagesToShow.push("...");
          pagesToShow.push(totalPages);
        }
        else if (currentPage > totalPages - minPagesToShow) {
          const start_page = totalPages - minPagesToShow + 1;
          const end_page = totalPages + 1;
          pagesToShow.push(1);
          pagesToShow.push("...");
          for (let i = start_page; i < end_page; i++) {
            if (i <= totalPages) {
              pagesToShow.push(i);
            }
          }
        }
        else {
          const start_page = currentPage - 2;
          const end_page = currentPage + 3;
          pagesToShow.push(1);
          pagesToShow.push("...");
          for (let i = start_page; i < end_page; i++) {
            if (i <= totalPages) {
              pagesToShow.push(i);
            }
          }
          pagesToShow.push("...");
          pagesToShow.push(totalPages);
        }
      }
    
    return pagesToShow;
  };
  const pageSize = 10;
    const handleNewPageChange = (page: number) => {
        setCurrentPage(page);
        const startIndex = (page - 1) * itemsPerPage;
        const endIndex = startIndex + itemsPerPage;

        const slicedData = tableData.slice(startIndex, endIndex);
        setOptimizationErrorsData(slicedData);
    };

  // The page numbers to display
  const pageNumbers = calculatePagesToShow();
  if (totalPages <= 0) {
    return null;
  }
  // Small screen view for non-excluded modules
  if (isSmallScreen) {
    return (
      <div className="flex justify-center pagination items-center">
        <span className="mr-2 text-sm font-semibold">
          {currentPage} of {totalPages}
        </span>
        <button
          onClick={handleForwardPrev}
          disabled={currentPage <= minPagesToShow}
          className={`w-[15px] text-gray-800 font-semibold h-full${
            currentPage <= minPagesToShow ? "opacity-50 cursor-not-allowed" : ""
          }`}
        >
          <BackwardFilled className="h-8 w-8" />
        </button>
        <button
          onClick={handlePrev}
          disabled={currentPage === 1}
          className={`w-[15px] text-gray-800 font-semibold h-full ${
            currentPage === 1 ? "opacity-50 cursor-not-allowed" : ""
          }`}
        >
          < CaretLeftFilled className="h-8 w-8" />
        </button>
        <span className="mr-2 ml-2 text-sm font-semibold">
         Prev
        </span>
        <span className="mr-2 text-sm font-semibold">
          Next
        </span>
        <button
          onClick={handleNext}
          disabled={currentPage === totalPages}
          className={`w-[15px] text-gray-800 font-semibold h-full ${
            currentPage === totalPages ? "opacity-50 cursor-not-allowed" : ""
          }`}
        >
          <CaretRightFilled className="h-8 w-8" />
        </button>
        <button
          onClick={handleForwardNext}
          disabled={currentPage > totalPages - minPagesToShow}
          className={`w-[15px] text-gray-800 font-semibold h-full ${
            currentPage > totalPages - minPagesToShow ? "opacity-50 cursor-not-allowed" : ""
          }`}
        >
          <ForwardFilled className="h-8 w-8" />
        </button>
      </div>
    );
  }



  // Regular view for larger screens (original functionality)
  return (
    <div className="flex justify-center mb-4 pagination">
      <button
        onClick={handleForwardPrev}
        disabled={currentPage <= minPagesToShow}
        className={`bg-white pagination-angular-btn hover:bg-gray-100 text-gray-800 font-semibold border border-gray-400 rounded shadow h-full px-1 ${
          currentPage <= minPagesToShow ? "opacity-50 cursor-not-allowed" : ""
        }`}
      >
        <DoubleLeftOutlined className="h-5 w-5" />
      </button>
      <button
        onClick={handlePrev}
        disabled={currentPage === 1}
        className={`bg-white pagination-angular-btn hover:bg-gray-100 text-gray-800 font-semibold border border-gray-400 rounded shadow h-full px-1 ${
          currentPage === 1 ? "opacity-50 cursor-not-allowed" : ""
        }`}
      >
        <ChevronLeftIcon className="h-5 w-5" />
      </button>
      {pageNumbers.map((page, index) => (
        <button
          key={index}
          onClick={() => typeof page === "number" && handleNewPageChange(page)}
          className={`hover:bg-gray-100 text-gray-800 font-semibold border border-gray-400 rounded shadow h-full px-2 pagination-btn ${
            page === currentPage ? "bg-[#bfdbfe] text-gray-800 !important" : ""
          } ${page === "..." ? "cursor-default" : ""}`}
          disabled={page === "..."}
        >
          {page}
        </button>
      ))}
      <button
        onClick={handleNext}
        disabled={currentPage === totalPages}
        className={`bg-white pagination-angular-btn hover:bg-gray-100 text-gray-800 font-semibold border border-gray-400 rounded shadow h-full px-1 ${currentPage === totalPages ? "opacity-50 cursor-not-allowed" : ""
        }`}
      >
        <ChevronRightIcon className="h-5 w-5" />
      </button>
      <button
        onClick={handleForwardNext}
        disabled={currentPage > totalPages - minPagesToShow}
        className={`bg-white pagination-angular-btn hover:bg-gray-100 text-gray-800 font-semibold border border-gray-400 rounded shadow h-full px-1 ${ currentPage > totalPages - minPagesToShow ? "opacity-50 cursor-not-allowed" : ""
        }`}
      >
        <DoubleRightOutlined className="h-5 w-5" />
      </button>
    </div>
  );
};

export default NewPagination;