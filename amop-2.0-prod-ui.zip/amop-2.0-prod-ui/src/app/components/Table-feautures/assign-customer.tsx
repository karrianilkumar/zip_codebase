import React, { useEffect, useState } from 'react';
import { Modal, Divider, Select, Button, Spin, DatePicker } from 'antd';
import { ChevronDownIcon } from '@heroicons/react/24/outline';
import { useAuth } from '@/app/components/auth_context';
import axios from 'axios';
import { ENV_ROUTES } from '@/app/components/routes/route_constants';
import { CloseOutlined } from '@ant-design/icons';
import { getCurrentDateTime } from '../header_constants';
import dayjs from 'dayjs';

const { Option } = Select;

interface AssignCustomerModalProps {
  visible: boolean;
  onCancel: () => void;
  onUpdate: (updatedRow: any,event_type:string,moduleStatus:boolean) => void;
  rowData?: any;
}

const AssignCustomerModal: React.FC<AssignCustomerModalProps> = ({ visible, onCancel, onUpdate, rowData }) => {
    // console.log(rowData?.customer_name,"rowdata customer name")
    const [assignCustomer, setAssignCustomer] = useState<string>(rowData?.customer_name||'');
    const [formData, setFormData] = useState<any>(rowData)
    const [loading, setLoading] = useState(true);
    const { username, partner, role, settabledata, token, selectedDb,metaData, firstLastName,sessionId} = useAuth();
    const [AssignCustomerOptions, setAssignCustomerOptions] = useState<any[]>([])
    const [customersMap, setCustomersMap] = useState<any>({})
    const [revIOModuleStatus, setRevIOModuleStatus] = useState<boolean>(false);
    const [isBPEnabled, setIsBPEnabled] = useState(false);

    //customer rate plans states
    const [customerRatePlan, setcustomerRatePlan] = useState<string>(rowData?.customer_rate_plan_name||'');
      const [ratePool, setRatepool] = useState<string>(rowData?.customer_rate_pool_name||'');
      const [CustomerRatePlanCodeOptions, setCustomerRatePlanCodeOptions] = useState<any[]>([])
      const [ratePools, setRatePools] = useState<any[]>([])
      const [activatedPlans, setActivatedPlans] = useState<any[]>([])
      const [activationDate, setActivationDate] = useState<string>('');
      const [effectiveDate, setEffectiveDate] = useState<string | null>(null);

  const handleCustomerRatePlanChange = (value: string) => {
    if (value) {
      const formData_ = formData
      formData_.customer_rate_plan_name = value
      setcustomerRatePlan(value);
      setFormData(formData_)
      if (activatedPlans.includes(value)) {
        setEffectiveDate(activationDate);
        const formData_ = formData
        formData_["effective_date"] = activationDate
        setFormData(formData_)
      }
    }
    else {
      setcustomerRatePlan("");
      setEffectiveDate(null);
    }
  };

  const handleCommPlanChange = (value: string) => {
    if (value) {
      const formData_ = formData
      formData_["customer_rate_pool_name"] = value
      setRatepool(value);
      setFormData(formData_)
    }
    else {
      setRatepool("");
    }
  };
    const handleAssignCustomer = (value: string) => {
      if (value) {
        const formData_ = formData
        let customer_name_=value.toLowerCase()
        if (customer_name_.endsWith(" -- bp") || customer_name_.endsWith(" -- revio")){
          customer_name_ = value.replace(" -- BP", "").replace(" -- RevIO", "");
        }
        else{
          customer_name_=value
        }
        formData_.customer_name = customer_name_
        const customer_id_=customersMap?.[value] || null
        formData_.customer_id = customer_id_
        setAssignCustomer(value);
        setFormData(formData_)
      }
      else{
        setAssignCustomer("");
      }
    };
  
    const handleUpdate = () => {
      onUpdate(formData, "Assign Customer",revIOModuleStatus);
    };  
    
    const fetchActivationDate = async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/carrier_activation_date_rata_plans",
        role_name: role,
        // parent_module: "Sim Management",
        module_name: "SimManagement Inventory",
        // feature_module_name: "Inventory",
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        sessionID: sessionId,
        iccid: rowData?.iccid || '',
        table_name: "sim_management_inventory"
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching Inventory data. Please try again.',
          centered: true,
          onOk: onCancel

        });
      } else {
        const activatedPlans_ = parsedData?.rate_plans || [];
        const activation_date = parsedData?.activation_date || null;
        setActivatedPlans(activatedPlans_)
        setActivationDate(activation_date)
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
        onOk: onCancel

      });
    } finally {
      setLoading(false);
    }
  };

    const fetchBPData = async () => {
      setLoading(true);
      try {
        const url =  ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/inventory_dropdowns_data",
          role_name: role,
          parent_module: "Sim Management",
          module_name: "SimManagement Inventory",
          feature_module_name:"Inventory",
          service_provider_id:rowData?.service_provider_id || 0,
          list_view_data_id: rowData?.id || 0,
          Partner: partner,
          access_token: token,
          db_name:selectedDb,
          sessionID: sessionId,
          dropdown: "Customer Rate Plan",
          modified_by: firstLastName,
          ... metaData,
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);

        if (parsedData.flag === false) {
          Modal.error({
            title: 'Data Fetch Error',
            content: parsedData.message || 'An error occurred while fetching Inventory data. Please try again.',
            centered: true,
            onOk: onCancel

          });
        } else {
          console.log("customerData", parsedData)
          const carrierOptions_ = parsedData?.rate_plan_list || []
          setCustomerRatePlanCodeOptions(carrierOptions_)
          const commOptions_ = parsedData?.rate_pool_list || []
          setRatePools(commOptions_)
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        Modal.error({
          title: 'Data Fetch Error',
          content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
          centered: true,
          onOk: onCancel

        });
      } finally {
        setLoading(false);
      }
    };
    const fetchBpFlag = async () => {
        setLoading(true);
        try {
          const url = ENV_ROUTES.MODULE_MANAGEMENT;
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/get_cross_provider_optimization_status",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "Active Customer Rate Plan",
            feature_module_name: "Customer Rate Plans",
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
            sessionID: sessionId,
            ... metaData,
          };
          const response = await axios.post(url, { data });
          const parsedData = JSON.parse(response.data.body);
          if (parsedData.flag === false) {
            Modal.error({
              title: 'Data Fetch Error',
              content: parsedData.message || 'An error occurred while fetching data. Please try again.',
              centered: true,
            });
            return false;
          } else {
            const billing_plaform_flag = parsedData?.billing_platform_flag || false;
            setIsBPEnabled(billing_plaform_flag);
            return billing_plaform_flag;
          }
        } catch (error) {
          console.error("Error fetching data:", error);
          Modal.error({
            title: 'Data Fetch Error',
            content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
            centered: true,
          });
          return false;
        } finally {
          setLoading(false);
        }
      };
    useEffect(() => {
      setAssignCustomer(rowData?.customer_name||'')
      const fetchData = async (bpFlag: boolean) => {
        setLoading(true);
        try {
          const url =  ENV_ROUTES.SIM_MANAGEMENT;
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/customers_dropdown_inventory",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "SimManagement Inventory",
            feature_module_name:"Inventory",
            Partner: partner,
            service_provider:rowData?.service_provider_display_name,
            service_provider_id:rowData?.service_provider_id,
            billing_platform_flag: bpFlag, // Use the flag passed as parameter
            access_token: token,
            db_name:selectedDb,
            ...metaData,
            sessionID: sessionId,
            dropdown: "Assign customer",
            modified_by: firstLastName
          };
  
          const response = await axios.post(url, { data });
          const parsedData = JSON.parse(response.data.body);
  
          if (parsedData.flag === false) {
            Modal.error({
              title: 'Data Fetch Error',
              content: parsedData.message || 'An error occurred while fetching Inventory data. Please try again.',
              centered: true,
              onOk: onCancel
  
            });
          } else {
            const customersMap_ = parsedData?.customer_name|| {}
            setCustomersMap(customersMap_)
            const customerOptions_=Object.keys(customersMap_) || []
            setAssignCustomerOptions(customerOptions_)
            setRevIOModuleStatus(parsedData?.module_status)
          }
        } catch (error) {
          console.error("Error fetching data:", error);
          Modal.error({
            title: 'Data Fetch Error',
            content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
            centered: true,
            onOk: onCancel
  
          });
        } finally {
          setLoading(false);
        }
      };
      const initializeData = async () => {
        if (visible === true) {
          // First fetch BP flag
          const bpFlag = await fetchBpFlag();
          
          // Then fetch customer data with the correct BP flag
          await fetchData(bpFlag);
          
          // If BP is enabled, fetch BP-specific data
          if (bpFlag) {
            await fetchBPData();
            await fetchActivationDate();
          }
        }
      };

      initializeData();
    }, [visible]);  
  
    const handleDateChange = (date: any, dateString: string | string[]) => {
    if (typeof dateString === 'string') {
      setEffectiveDate(dateString);
    } else {
      setEffectiveDate(dateString[0]);
    }
    const formData_ = formData
    formData_["effective_date"] = dateString
    setFormData(formData_)
  };
  
    return (
      <Modal
        title={
          <div className='mt-[-10px]'><span className='text-[19px]'>Assign Customer</span></div>}
        visible={visible}
        centered
        onCancel={onCancel}
        footer={[
          <div className="flex justify-center space-x-2 mt-12" key="buttons">
            <button key="cancel" onClick={onCancel} className="cancel-btn h-[30px] text-base" style={{ fontFamily: 'Calibri, sans-serif' }}>
              Cancel
            </button>
            <button key="update" onClick={handleUpdate} className="save-btn text-base border-none" style={{ fontFamily: 'Calibri, sans-serif' }}>
              Update
            </button>
          </div>,
        ]}
        width={500}
        style={{ height: '500px' }}
      > <>
          {loading ? (
            <div className="popup flex justify-center items-center w-full h-full">
              <Spin size="large" />
            </div>
          ) : (
            <div className="flex flex-col space-y-4">
              <div>
                <label htmlFor='customer-rate-plan' className="font-normal text-lg" style={{ fontFamily: 'Calibri, sans-serif' }}>Assign Customer</label>
                <Select
                  id='customer-rate-plan'
                  placeholder="Select Assign Customer"
                  onChange={handleAssignCustomer}
                  className="w-full mt-1 mb-2"
                  value={assignCustomer}
                  showSearch={true}
                  allowClear
                  clearIcon={
                    <CloseOutlined className="clear"/>
                  }
                  suffixIcon={<ChevronDownIcon className="w-5 mt-2 h-5 text-gray-600" />}                 >
                  {AssignCustomerOptions?.map((option,index) => (
                    <Option key={index} value={option}>
                      {option}
                    </Option>
                  ))}
                </Select>
              </div>
              {isBPEnabled && (
                <>
                <div>
                  <label htmlFor='customer-rate-plan' className="font-normal text-lg" style={{ fontFamily: 'Calibri, sans-serif' }}>Customer Rate Plan</label>
                  <Select
                    id='customer-rate-plan'
                    placeholder="Select a Customer Rate Plan"
                    onChange={handleCustomerRatePlanChange}
                    className="w-full mt-1 mb-2"
                    value={customerRatePlan}
                    showSearch
                    allowClear
                    clearIcon={
                      <CloseOutlined className="clear" />
                    }
                    suffixIcon={<ChevronDownIcon className="w-5 mt-2 h-5 text-gray-600" />}                 >
                    {CustomerRatePlanCodeOptions.map((option) => (
                      <Option key={option} value={option}>
                        {option}
                      </Option>
                    ))}
                  </Select>
                </div>
                <div>
                  <label htmlFor='comm-plan' className="font-normal text-lg" style={{ fontFamily: 'Calibri, sans-serif' }}>Customer Rate Pool</label>
                  <Select
                    id='comm-plan'
                    placeholder="Select a Communication Plan"
                    onChange={handleCommPlanChange}
                    className="w-full mt-1 mb-2"
                    value={ratePool}
                    showSearch
                    allowClear
                    clearIcon={
                      <CloseOutlined className="clear" />
                    }
                    suffixIcon={<ChevronDownIcon className="w-5 mt-2 h-5 text-gray-600" />}
                  >
                    <Option key="none" value="None">
                      None
                    </Option>
                    {ratePools.map((option, index) => (
                      <Option key={index} value={option}>
                        {option}
                      </Option>
                    ))}
                  </Select>
                </div>
                <div className="mt-2 ">
                  <label htmlFor='date-picker' className="font-normal text-lg" style={{ fontFamily: 'Calibri, sans-serif' }}>Effective Date </label>
                  <DatePicker
                    id='date-picker'
                    onChange={handleDateChange}
                    className="w-full mt-1 h-10"
                    value={effectiveDate ? dayjs(effectiveDate) : null} />
                    {isBPEnabled && <span className='text-sm'>The default Effective Date represents Carrier Activation Date of the Device.</span>}
                </div>
              </>
              )}
            </div>
          )}
        </>
      </Modal>
    );
};

export default AssignCustomerModal;
