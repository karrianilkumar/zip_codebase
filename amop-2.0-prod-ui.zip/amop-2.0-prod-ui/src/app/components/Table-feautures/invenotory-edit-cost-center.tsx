import React, { useState, useEffect } from "react";
import { Modal,Row, Col, Spin } from "antd";
import { useAuth } from "@/app/components/auth_context";
import { ENV_ROUTES } from "../routes/route_constants";
import axios from "axios";
import { getCurrentDateTime } from "../header_constants";
import Select from "react-select";

interface InventoryEditCostCenterModalProps {
  visible: boolean;
  onCancel: () => void;
  onUpdate: (updatedRow: any, event_type: string) => void;
  rowData?: any;
}

const InventoryEditCostCenterModal: React.FC<InventoryEditCostCenterModalProps> = ({
  visible,
  onCancel,
  onUpdate,
  rowData,
}) => {
 
  const [formData, setFormData] = useState<any>(rowData);
  const { username, token, partner, selectedDb,metaData, role, firstLastName, sessionId } = useAuth();
  const [loading, setLoading] = useState(false);
  const [costCenterOptions, setCostCenterOptions] = useState<any>([]);


  const fetchData = async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/fetch_cost_centers",
        role_name: role,
        parent_module: "Sim Management",
        module_name:"Inventory",
        feature_module_name: "Inventory",
        request_received_at: getCurrentDateTime(),
        service_provider_id:Number(rowData?.service_provider_id) || 1,
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);  
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        const cost_centers = parsedData?.cost_centers || []
        setCostCenterOptions(cost_centers)
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      setLoading(false);

    }
  };

  useEffect(() => {
    if (visible) {
      fetchData();
    }
  }, [visible]);
 
  const handleUpdate = () => {
    onUpdate(formData, "Edit Cost Center");
  };

  const handleCancel = () => {
    setFormData(rowData);
    onCancel();
  };

  useEffect(() => {
    if (visible) {
        setFormData(rowData);
      }
  }, [rowData, visible]);

  return (
    <Modal
      title={
        <div className="mt-[-10px]">
          <span className="text-[19px]">Edit Cost Center</span>
        </div>
      }
      visible={visible}
      centered
      onCancel={handleCancel}
      footer={[
        <div className="flex justify-center space-x-2 mt-12" key="buttons">
          <button
            key="cancel"
            onClick={onCancel}
            className="cancel-btn h-[30px] text-base"
            style={{ fontFamily: "Calibri, sans-serif" }}
          >
            Cancel
          </button>
          <button
            key="update"
            onClick={handleUpdate}
            className="save-btn  text-base border-none"
            style={{ fontFamily: "Calibri, sans-serif" }}
          >
            Update
          </button>
        </div>,
      ]}
      width={400}
      style={{ height: "500px" }}
    >
      <>
      {loading ? (
          <div className="popup flex justify-center items-center w-full h-full mt-4">
            <Spin size="large" />
          </div>
        ) : (
          <>
          <Row style={{marginBottom:16}}>
    {/* <Col span={8}>
      <label
        className="text-lg"
        htmlFor="iccid"
        style={{ fontFamily: "Calibri, sans-serif" }}
      >
        ICCID
      </label>
    </Col> */}
    {/* <Col span={16}>
      <Input
        className="mt-1"
        id="iccid"
        value={formData.iccid}
        onChange={(e) => setFormData({ ...formData, iccid: e.target.value })}
      />
    </Col> */}
  </Row>
  <Row>
        <Col span={8}>
          <label className="text-lg" htmlFor="cost_center" style={{ fontFamily: "Calibri, sans-serif" }}>
            Cost Center
          </label>
        </Col>
        <Col span={16}>
          {formData?.service_provider_display_name === "Kore" ? (
            <Select
              id="cost_center"
              className="mt-1"
              options={costCenterOptions.map((option:any)=>({value:option,label:option}))}
              value={{value:formData.cost_center,label:formData.cost_center}}
              onChange={(selectedOption) =>
                setFormData({ ...formData, cost_center: selectedOption ? selectedOption.value : "" })
              }
              isClearable
              placeholder="Select Cost Center"
              isLoading={loading}
            />
          ) : (
            <input
              className="input"
              id="cost_center"
              value={formData.cost_center}
              onChange={(e) => setFormData({ ...formData, cost_center: e.target.value })}
            />
          )}
        </Col>
      </Row>

          </>
        )
      }
      </>
     
    </Modal>
  );
};

export default InventoryEditCostCenterModal;
