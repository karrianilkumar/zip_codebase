import React, { useState, useEffect } from "react";
import { Modal, Divider, Select, Button, Input, Spin, Checkbox, DatePicker } from "antd";
import { ChevronDownIcon } from "@heroicons/react/24/outline";
import { useAuth } from "@/app/components/auth_context";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import axios from "axios";
import { text } from "stream/consumers";
import { CloseOutlined } from "@ant-design/icons";
import dayjs, { Dayjs } from "dayjs";
import { getCurrentDateTime } from "../header_constants";
const { Option } = Select;

interface UpdateStatusModalProps {
  visible: boolean;
  onCancel: () => void;
  onUpdate: (updatedRow: any, event_type: string) => void;
  rowData?: any;
}


// type FormData = Record<string, string | undefined>;

const UpdateStatusModal: React.FC<UpdateStatusModalProps> = ({
  visible,
  onCancel,
  onUpdate,
  rowData,
}) => {
  const [currentStatus, setCurrentStatus] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("");
  const [formData, setFormData] = useState<any>(rowData || {});
  const { username, partner, role, settabledata, token, selectedDb,metaData, firstLastName, sessionId } = useAuth();
  const [loading, setLoading] = useState<boolean>(false);
  const [parsedData, setParsedData] = useState<any>(null);
  const [newStatusOptions, setNewStatusOptions] = useState<string[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [imei, setImei] = useState("");
  const zipCodeRegex = /^\d{5}(-\d{4})?$/;

  const [selectedProfile, setSelectedProfile] = useState("");
  // const [selectedReasonCodeID, setSelectedReasonCodeID] = useState<string | null>(null);
  const [profileOptions, setProfileOptions] = useState<string[]>([]);
  const [stateOptions, setStateOptions] = useState<string[]>([]);
  const [ratePlanOptions, setRatePlanOptions] = useState<any[]>([]);
  const [ratePlanCodeOptions, setRatePlanCodOptions] = useState<any[]>([]);
  const [publicIPOptions, setPublicIPOPtions] = useState<string[]>(["Restricted", "Unrestricted"]);
  const [reasonCodeOptions, setReasonCodeOptions] = useState<any[]>([]);
  const [statusMap, setStatusMap] = useState<any>({});
  const [effectiveDateCheckbox, setEffectiveDateCheckbox] = useState<boolean>(false);
  const [effectiveDate, setEffectiveDate] = useState<Dayjs | null>(null);
  const isAdmin = role?.toLowerCase() === "super admin" || role?.toLowerCase() === "partner admin"
  useEffect(() => {
    if (visible) {
      setErrors({}); // Clear errors on modal open
      setSelectedStatus("");
      setSelectedProfile("");
      const currentUserName = rowData?.username || ""
      if (currentUserName && currentUserName !== 'None') {
        const nameParts = currentUserName.split(" ");
        setFormData((prevFormData: any) => ({ ...prevFormData, first_name: nameParts[0], last_name: nameParts.slice(1).join(" ") }));
      }
    }
  }, [visible]);

  const validateFields = (): boolean => {
    const newErrors: Record<string, string> = {};
    if (selectedStatus) {
      if (selectedStatus === "Active" && (((rowData?.service_provider_display_name || "").toUpperCase().includes("VERIZON"))|| (rowData?.service_provider_display_name || "").toUpperCase().includes("VZN") || (rowData?.service_provider_display_name).toLowerCase().includes("vzwcr") || (rowData?.service_provider_display_name).toLowerCase().includes("2215-so01"))) {
        if (!formData.first_name) newErrors.first_name = "First name is required";
        if (!formData.last_name) newErrors.last_name = "Last name is required";
        if (!formData.address) newErrors.address = "Address line is required";
        if (!formData.city) newErrors.city = "City is required";
        if (!formData.state) newErrors.state = "State is required";
        if (!formData.country) newErrors.country = "Country is required";
        console.log("formData.zip_code", formData.service_zip_code)
        if (!formData.service_zip_code || !zipCodeRegex.test(formData.service_zip_code)) {
          newErrors.service_zip_code = "Valid ZIP code is required";
        }
      }
      // if ((selectedStatus.toLowerCase() === "activate" || selectedStatus.toLowerCase() === "active") && (rowData?.service_provider_display_name || "").toLowerCase().includes("kore")) {
      //   if (!formData.imei) newErrors.imei = "IMEI is required";
      // }
      if ((selectedStatus.toLowerCase() === "activate" || selectedStatus.toLowerCase() === "active") && (rowData?.service_provider_display_name || "").toLowerCase().includes("kore")) {
        if (!selectedProfile) newErrors.selectedProfile = "Activation Profile is required";
      }
      if ((rowData?.service_provider_display_name || "").toLowerCase().includes("at&t - telegence")) {
        if (effectiveDateCheckbox && !effectiveDate) newErrors.effectiveDate = "Effective Date is required";
      }
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };


  // const handleChange = (value: string) => {
  //   if (value) {
  //     const formData_ = formData;
  //     formData_.sim_status = value;
  //     setSelectedStatus(value);
  //     setFormData(formData_);
  //   }
  // };

  const handleChange = (value: string): void => {
    setSelectedProfile("")
    setSelectedStatus(value);
    const status_id = statusMap?.[value] || null
    setFormData((prevFormData: any) => ({ ...prevFormData, sim_status: value, device_status_id: status_id }));
    if ((rowData?.service_provider_display_name).toUpperCase().includes("AT&T - TELEGENCE") || (value === "Deactivated" && ((rowData?.service_provider_display_name).toUpperCase().includes("VERIZON") || (rowData?.service_provider_display_name).toUpperCase().includes("VZN") || (rowData?.service_provider_display_name).toLowerCase().includes("vzwcr") || (rowData?.service_provider_display_name).toLowerCase().includes("2215-so01")))) {
      fetchreasonCodes(value)
    }
  };

  const handleIccidChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const imei_ = e.target.value || ""
    setImei(imei_);
    setFormData((prevFormData: any) => ({ ...prevFormData, imei: imei_ }));
  };

  const handleSelectActivationProfile = (selectedOption: any) => {
    if (selectedOption) {
      // const value = selectedOption?.value
      setSelectedProfile(selectedOption)
      setFormData((prevFormData: any) => ({ ...prevFormData, activation_profile: selectedOption }));
    }
    else {
      setSelectedProfile("")
    }
  };

  const getCurrentDateTimeFormatted = (): string => {
  const now = new Date();

  const pad = (num: number) => num.toString().padStart(2, '0');

  const month = pad(now.getMonth() + 1); // 10 → October
  const day = pad(now.getDate());        // 02
  const year = now.getFullYear();        // 2025

  const hours = pad(now.getHours());
  const minutes = pad(now.getMinutes());
  const seconds = pad(now.getSeconds());

  return `${month}-${day}-${year} ${hours}:${minutes}:${seconds}`;
};


  const handleUpdate = (): void => {
    let formdata_ :any = {... formData}
    if (validateFields()) {
      // if(formData?.effective_date){
        const effectiveDate_ = effectiveDate ? formData?.effective_date : getCurrentDateTimeFormatted() || getCurrentDateTimeFormatted()
        console.log("effectiveDate_",effectiveDate_)
        const updatedFormData:any = {
        ...formData,
        effective_date: effectiveDate_,
      };
        formdata_ = {... updatedFormData}
      // }

      if(isAdmin){
        const ratePlan_ = formData?.rate_plan_code || null;
        if (ratePlan_) {
          
    // Find the index of the selected rate plan in the options array
    const index = ratePlanOptions.indexOf(ratePlan_);
    if (index !== -1 && ratePlanCodeOptions[index]) {
      const newRatePlanCode = ratePlanCodeOptions[index];
      // Create a new formData object with updated carrier_rate_plan_name
      const updatedFormData = {
        ...formdata_,
        rate_plan_code: newRatePlanCode,
      };


      onUpdate(updatedFormData, "Update Status");
      return;
    }
  }
      }
      
      onUpdate(formdata_, "Update Status");
      setSelectedStatus("");
      setSelectedProfile("")
    }
  };

  const handleCancel = (): void => {
    onCancel();
    setSelectedStatus("");
    setSelectedProfile("")
  };

  const getDefaultReasonCode = (targetStatus: any) => {
        const selected_status=targetStatus.toLowerCase()
        switch (selected_status) {
            case "suspended":
                return {label:"Customer Request",value:"CR"};
            case "cancel subscriber":
                return {label:"Customer Cutting Back",value:"CB"};
            case "restore suspended":
                return {label:"Customer Request",value:"CR"};
            case "restore cancelled":
                return {label:"Customer Request",value:"CR"};
            default:
                return null; // or a suitable default value
        }
    };

  const fetchreasonCodes = async (new_status: any) => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/reason_codes_inventory",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "SimManagement Inventory",
        feature_module_name: "Inventory",
        service_provider_id: rowData?.service_provider_id,
        service_provider: rowData?.service_provider_display_name,
        status: new_status,
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const fetchedData = JSON.parse(response.data.body);
      setParsedData(fetchedData);

      if (fetchedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content: fetchedData.message || "An error occurred while fetching Inventory data. Please try again.",
          centered: true,
          onOk: handleCancel,
        });
      } else {
        setLoading(false);
        const reasonCodeMap = fetchedData.reason_codes || []
        const filteredReasonCodes = reasonCodeMap.map((reason: any) => ({
          label: reason.description,
          value: reason.reason_code,
        }));
        console.log("filteredReasonCodes", filteredReasonCodes)
        setReasonCodeOptions(filteredReasonCodes);
        if(rowData?.service_provider_display_name.toLowerCase().includes("telegence")){
          const reason_code = getDefaultReasonCode(new_status)
          setFormData((prevFormData: any) => ({ ...prevFormData, reason_code: reason_code?.value || "" }));
        }
        
      }
    } catch (error) {
      setLoading(false);
      console.error("Error fetching data:", error);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
        onOk: handleCancel,
      });
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/statuses_inventory",
          role_name: role,
          parent_module: "Sim Management",
          module_name: "SimManagement Inventory",
          feature_module_name: "Inventory",
          service_provider_id: rowData?.service_provider_id,
          service_provider: rowData?.service_provider_display_name,
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
        ... metaData,
          sessionID: sessionId,
        };

        const response = await axios.post(url, { data });
        const fetchedData = JSON.parse(response.data.body);
        setParsedData(fetchedData);

        if (fetchedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content: fetchedData.message || "An error occurred while fetching Inventory data. Please try again.",
            centered: true,
            onOk: handleCancel,
          });
        } else {
          setLoading(false);
          const statusMap_ = fetchedData?.update_status_values || {}
          setStatusMap(statusMap_)
          const status_options = Object.keys(statusMap_) || []
          const sortedOptions = (status_options || [])
            .filter((status: any) => status !== currentStatus) // Remove currentStatus if it exists
            .sort();

          // Check if service_provider includes "verizon" and remove "pending activation" if present
          const filteredOptions = ((rowData?.service_provider_display_name).toLowerCase().includes("verizon") || (rowData?.service_provider_display_name).toLowerCase().includes("vzn") || (rowData?.service_provider_display_name).toLowerCase().includes("vzwcr") || (rowData?.service_provider_display_name).toLowerCase().includes("2215-so01")) 
            ? sortedOptions.filter(
              (option: any) => !option.toLowerCase().includes("pending activation")
            )
            : sortedOptions;
          setNewStatusOptions(filteredOptions);
          const active_profile_dropdown = fetchedData?.activation_profiles || []
          setProfileOptions(active_profile_dropdown)
          const states = fetchedData?.state || []
          setStateOptions(states)
          const rate_plan_codes = fetchedData?.carrier_rate_plan || []
          setRatePlanOptions(rate_plan_codes)

          const ratePlanCodeOptions = fetchedData?.rate_plan_code_list || []
          setRatePlanCodOptions(ratePlanCodeOptions);

        }
      } catch (error) {
        setLoading(false);
        console.error("Error fetching data:", error);
        Modal.error({
          title: "Data Fetch Error",
          content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
          centered: true,
          onOk: handleCancel,
        });
      } finally {
        setLoading(false);
      }
    };

    if (visible) {
      fetchData();
    }
  }, [visible]);

  useEffect(() => {
    const status_ = rowData?.sim_status || "Deactivated";
    setCurrentStatus(status_);
    const imei_ = rowData?.imei || "";
    setImei(imei_);
  }, [rowData]);

   const disablePastDates = (current: any) => {
      return current && current < dayjs().startOf('day');
    };
  return (
    <Modal
      title={
        <div className="mt-[-10px]">
          <span className="text-[21px] updateStatus">Update Status</span>
        </div>
      }
      className={selectedStatus === "Active" ? "updateStatusHeight" : "updatedHeight"}
      visible={visible}
      centered
      onCancel={handleCancel}
      footer={[
        <div className="flex justify-center space-x-4 mt-6" key="buttons">
          <button
            key="cancel"
            onClick={onCancel}
            className="cancel-btn h-[30px] text-base"
            style={{ fontFamily: "Calibri, sans-serif" }}
          >
            Cancel
          </button>
          <button
            key="update"
            onClick={handleUpdate}
            className="save-btn  text-base border-none"
            style={{ fontFamily: "Calibri, sans-serif" }}
          >
            Update
          </button>
        </div>,
      ]}
      width={600}
      style={{ height: "500px" }}


    >
      <>
        {loading ? (
          <div className="popup flex justify-center items-center w-full h-full">
            <Spin size="large" />
          </div>
        ) : (
          <div className="flex flex-col space-y-4 mt-6" id={selectedStatus === "Active" ? "updateStatusPopup" : "updatedStatus"}>
            <div className="flex w-full">
              <div className="w-2/5">
                <label
                  className="text-lg font-calibri status"

                  htmlFor="current-status"
                >
                  Current Status
                </label>
              </div>

              <Input
                className="non-editable-input"
                id="current-status"
                value={currentStatus}
                readOnly
              />
            </div>

            <div className="flex w-full">
              <div className="w-2/5">
                <label
                  className="text-lg font-calibri mb-4 status"
                  htmlFor="new-status"
                // style={{ fontFamily: "Calibri, sans-serif" }}
                >
                  New Status
                </label>
              </div>
              <Select
                id="new-status"
                value={selectedStatus}
                // style={{ width: "100%", marginTop: "5px", marginBottom: '16px' }}
                style={{ width: "100%", marginBottom: '3px' }}
                onChange={handleChange}
                showSearch
                allowClear
                clearIcon={
                  <CloseOutlined className="clear" />
                }
                suffixIcon={
                  <ChevronDownIcon className="w-5 h-5 text-gray-600 arrow" />
                }
                notFoundContent="No options"
              >
                {newStatusOptions.map((status) => (
                  <Option key={status} value={status}>{status}</Option>
                ))}
              </Select>
            </div>

            {(rowData?.service_provider_display_name).toUpperCase().includes("AT&T - TELEGENCE") && (
              <>

                <div className="flex w-full">
                  <div className="w-2/5">
                    <label
                      className="text-lg font-calibri "

                      htmlFor="current-status"
                    >
                      Reason Code
                    </label>
                  </div>
                  <Select
                    id="reasonCode"
                    // className="w-5 h-5 text-gray-600" 
                    // placeholder="State"
                    showSearch
                    allowClear
                    style={{ width: "100%", marginBottom: '16px' }}
                    onChange={(value) => {
                      setFormData({ ...formData, reason_code: value })
                      console.log("reason_code", value)
                    }}
                    value={formData?.reason_code || ""}
                    suffixIcon={
                      <ChevronDownIcon className="w-5 h-5 text-gray-600 arrow" />
                    }
                  >
                    {reasonCodeOptions.map((code) => (
                      <Option key={code.value} value={code.value}>{code.label}</Option>
                    ))}
                  </Select>
                </div>

                  <div className="flex w-full">
                  <div className="w-2/5">
                    <label htmlFor="effectiveDateCheckbox" className="w-1/3 font-semibold">
                      Effective Date
                    </label>
                  </div>

                  <Checkbox
                    id="effectiveDateCheckbox"
                    checked={effectiveDateCheckbox}
                    onChange={(e) => {
                      setEffectiveDateCheckbox(e.target.checked)
                    if(!e.target.checked){
                      setEffectiveDate(null)
                    }}}
                  />
                </div>

                {/* Effective Date */}
                {effectiveDateCheckbox && (
                  <>
                    <div className="flex w-full">
                      <div className="w-2/5">
                        <label htmlFor="effectiveDate" className="w-1/3 font-semibold ">
                          Effective Date <span className="text-red-500">*</span>
                        </label>
                      </div>

                      <DatePicker
                        value={effectiveDate}
                        onChange={(date: Dayjs | null) => {
                          if (date) {
      // Format date as "MM-DD-YYYY HH:mm:ss"
      const formattedDate = date.format("MM-DD-YYYY HH:mm:ss");
      setEffectiveDate(date);
      setFormData({ ...formData, effective_date: formattedDate });
    } else {
      setEffectiveDate(null);
      setFormData({ ...formData, effective_date: "" });
    }
                        }}
                        className="input"
                        format="DD/MM/YYYY"
                        placeholder="DD/MM/YYYY"
                        disabledDate={disablePastDates}
                      />
                    </div>
                    {errors.effectiveDate && (
                      <div className="text-red-500 text-sm">
                        {errors.effectiveDate}
                      </div>
                    )}
                  </>
                )}
              </>
            )}
            {((rowData?.service_provider_display_name).toLowerCase() === "kore" && (selectedStatus?.toLowerCase() === "activate" || selectedStatus?.toLowerCase() === "active")) && (
              <>
                <div className="flex w-full">
                  <div className="w-2/5">
                    <label
                      className="text-lg font-calibri mb-4 status"
                      htmlFor="new-status"
                    // style={{ fontFamily: "Calibri, sans-serif" }}
                    >
                      Activation Profile<span className="text-red-500">*</span>
                    </label>
                  </div>
                  <Select
                    id="new-status"
                    value={selectedProfile}
                    // style={{ width: "100%", marginTop: "5px", marginBottom: '16px' }}
                    style={{ width: "100%", marginBottom: '3px' }}
                    onChange={handleSelectActivationProfile}
                    showSearch
                    allowClear
                    clearIcon={
                      <CloseOutlined className="clear" />
                    }
                    suffixIcon={
                      <ChevronDownIcon className="w-5 h-5 text-gray-600 arrow" />
                    }
                    notFoundContent="No options"
                  >
                    {profileOptions.map((profile) => (
                      <Option key={profile} value={profile}>{profile}</Option>
                    ))}
                  </Select>
                </div>
                <div className="errorMessage">
                  {errors.selectedProfile && <span className="text-red-500">{errors.selectedProfile}</span>}
                </div>
                {/* ICCID Textarea */}
                <div className="flex w-full mt-4">
                  <div className="w-2/5">
                    <label className="text-lg font-calibri mb-4 status" htmlFor="imei">
                      IMEI
                    </label>
                  </div>
                  <textarea
                    id="imei"
                    value={imei}
                    onChange={handleIccidChange}
                    className="w-full border rounded-md p-2 non-editable-input"
                    rows={3}
                    placeholder="Enter IMEI"
                    disabled
                  />
                </div>
                {/* <div className="errorMessage">
                  {errors.imei && <span className="text-red-500">{errors.imei}</span>}
                </div> */}
              </>
            )}
            {selectedStatus === "Active" && ((rowData?.service_provider_display_name).toUpperCase().includes("VERIZON") || (rowData?.service_provider_display_name).toUpperCase().includes("VZN") || (rowData?.service_provider_display_name).toLowerCase().includes("vzwcr") || (rowData?.service_provider_display_name).toLowerCase().includes("2215-so01")) && (
              <>
                <div className="space-y-4 ">
                  <div className="flex  w-full mt-2">
                    <div className="w-2/5">
                      <label className="text-lg font-calibri status" htmlFor="first-name">First Name<span className="text-red-500">*</span></label>
                    </div>
                    <Input
                      id="first-name"
                      className="input"
                      // placeholder="First name"
                      value={formData.first_name || ""}
                      required
                      onChange={(e) => setFormData({ ...formData, first_name: e.target.value })}
                    />
                  </div>
                  <div className="errorMessage">
                    {errors.first_name && <span className="text-red-500">{errors.first_name}</span>}
                  </div>

                  <div className="flex  w-full">
                    <div className="w-2/5">
                      <label className="text-lg font-calibri status" htmlFor="last-name">Last Name<span className="text-red-500">*</span></label>
                    </div>
                    <Input
                      id="last-name"
                      className="input"
                      // placeholder="Last name"
                      value={formData.last_name || ""}
                      required
                      onChange={(e) => setFormData({ ...formData, last_name: e.target.value })}
                    />
                  </div>
                  <div className="errorMessage">
                    {errors.last_name && <span className="text-red-500">{errors.last_name}</span>}
                  </div>

                  <div className="flex  w-full mb-4">
                    <div className="w-2/5">
                      <label className="text-lg font-calibri status" htmlFor="ratePlan">{isAdmin ? "Rate Plan Code" : "Customer Rate Plan"} </label>
                    </div>
                    <Select
                      id="ratePlan"
                      showSearch
                      allowClear
                      style={{ width: "100%", marginBottom: '16px' }}
                      onChange={(value) => setFormData({ ...formData, rate_plan_code: value })}
                      suffixIcon={<ChevronDownIcon className="w-5 h-5 text-gray-600 arrow" />}
                    >
                      {ratePlanOptions.map((plan) => {
                        const label = isAdmin ? plan : plan.rate_plan;
                        const value = isAdmin ? plan : plan.code;

                        return (
                          <Option key={label} value={value}>
                            {label}
                          </Option>
                        );
                      })}
                    </Select>
                  </div>
                  <div className="flex  w-full mb-4">
                    <div className="w-2/5">
                      <label className="text-lg font-calibri status" htmlFor="publicIP">Public IP Restriction</label>
                    </div>
                    <Select
                      id="publicIP"
                      // className="w-5 h-5 text-gray-600" 
                      // placeholder="State"
                      showSearch
                      allowClear
                      style={{ width: "100%", marginBottom: '16px' }}
                      onChange={(value) => setFormData({ ...formData, public_ip_restriction: value })}
                      suffixIcon={
                        <ChevronDownIcon className="w-5 h-5 text-gray-600 arrow" />
                      }
                    >
                      {publicIPOptions.map((ip) => (
                        <Option key={ip} value={ip}>{ip}</Option>
                      ))}
                    </Select>
                  </div>

                  <div className="flex  w-full">
                    <div className="w-2/5">
                      <label className="text-lg font-calibri status" htmlFor="address-line">Address Line<span className="text-red-500">*</span></label>
                    </div>
                    <Input
                      id="address-line"
                      className="input"
                      // placeholder="Address line"
                      value={formData.address || ""}
                      required
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    />
                  </div>
                  <div className="errorMessage">
                    {errors.address && <span className="text-red-500">{errors.address}</span>}

                  </div>

                  <div className="flex  w-full">
                    <div className="w-2/5">
                      <label className="text-lg font-calibri status" htmlFor="city">City<span className="text-red-500">*</span></label>
                    </div>
                    <Input
                      id="city"
                      className="input"
                      value={formData.city || ""}
                      // placeholder="City"
                      required
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    />
                  </div>
                  <div className="errorMessage">
                    {errors.city && <span className="text-red-500">{errors.city}</span>}
                  </div>

                  <div className="flex  w-full mb-4">
                    <div className="w-2/5">
                      <label className="text-lg font-calibri status" htmlFor="state">State<span className="text-red-500">*</span></label>
                    </div>
                    <Select
                      id="state"
                      // className="w-5 h-5 text-gray-600" 
                      // placeholder="State"
                      style={{ width: "100%", marginBottom: '16px' }}
                      onChange={(value) => setFormData({ ...formData, state: value })}
                      suffixIcon={
                        <ChevronDownIcon className="w-5 h-5 text-gray-600 arrow" />
                      }
                    >
                      {stateOptions.map((state: any) => (
                        <Option key={state.code} value={state.code}>
                          {state.name}
                        </Option>
                      ))}
                    </Select>
                  </div>
                  <div className="errorMessage">
                    {errors.state && <span className="text-red-500">{errors.state}</span>}
                  </div>



                  <div className="flex w-full">
                    <div className="w-2/5">
                      <label className="text-lg font-calibri status" htmlFor="country">Country<span className="text-red-500">*</span></label>
                    </div>
                    <Input
                      id="country"
                      className="input"
                      // placeholder="Country"
                      value={formData.country || ""}
                      required
                      onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                    />
                  </div>
                  <div className="errorMessage">
                    {errors.country && <span className="text-red-500">{errors.country}</span>}
                  </div>


                  <div className="flex  w-full">
                    <div className="w-2/5">
                      <label className="text-lg font-calibri status" htmlFor="zip-code">MDN zip Code<span className="text-red-500">*</span></label>
                    </div>
                    <Input
                      id="zip-code"
                      className="input"
                      value={formData.service_zip_code || ""}
                      required
                      // placeholder="MDN Zip Code"
                      onChange={(e) => setFormData({ ...formData, service_zip_code: e.target.value })}
                    />
                  </div>
                  <div className="errorMessage">
                    {errors.service_zip_code && <span className="text-red-500">{errors.service_zip_code}</span>}
                  </div>
                </div>
              </>
            )}
            {(selectedStatus === "Deactivated" && ((rowData?.service_provider_display_name).toUpperCase().includes("VERIZON") || (rowData?.service_provider_display_name).toUpperCase().includes("VZN") || (rowData?.service_provider_display_name).toLowerCase().includes("vzwcr") || (rowData?.service_provider_display_name).toLowerCase().includes("2215-so01"))) && (
              <>
                <div className="flex w-full">
                  <div className="w-2/5">
                    <label
                      className="text-lg font-calibri "

                      htmlFor="current-status"
                    >
                      Reason Code
                    </label>
                  </div>

                  <Select
                    id="reasonCode"
                    // className="w-5 h-5 text-gray-600" 
                    // placeholder="State"
                    showSearch
                    allowClear
                    style={{ width: "100%", marginBottom: '16px' }}
                    onChange={(value) => {
                      setFormData({ ...formData, reason_code: value })
                      console.log("reason_code", value)
                    }}
                    suffixIcon={
                      <ChevronDownIcon className="w-5 h-5 text-gray-600 arrow" />
                    }
                  >
                    {reasonCodeOptions.map((code) => (
                      <Option key={code.value} value={code.value}>{code.label}</Option>
                    ))}
                  </Select>


                </div>
              </>
            )}
          </div>
        )}
      </>
    </Modal>
  );
};

export default UpdateStatusModal;
