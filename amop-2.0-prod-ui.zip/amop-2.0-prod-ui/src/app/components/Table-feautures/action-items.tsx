import React, { useMemo, useState, useCallback, useRef, useEffect } from "react";
import {
  Dropdown,
  Menu,
  Modal,
  notification,
  Space,
  Spin,
  Tooltip,
} from "antd";
import { MoreOutlined } from "@ant-design/icons";
import UpdateStatusModal from "./update-status"; // Adjust path as per your application structure
import UpdateCarrierRatePlan from "./update-carrier-rate-plan";
import UpdateCustomerRatePlan from "./update-customer-rate-plan";
import UpdateFeaturesModal from "./update_features";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import AssignCustomerModal from "./assign-customer";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import EditCostCenter from "./edit-cost-center";
import InventoryEditCostCenterModal from "./invenotory-edit-cost-center";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import UpdatePhoneNumberModal from "./update-phone-number";


interface ActionItemsProps {
  initialData: any;
  currentPage: number;
  itemsPerPage: number;
  index: number;
  rowData?: any;
}

interface ItemType {
  key: string;
  label: string;
}
const simManagementInventoryActionItem = (
  record?: { [key: string]: any }, partner?: any, moduleFeatures?: any, rowData?: any) => {
  const results: ItemType[] = [];
  const isActivated = (rowData.sim_status && (rowData.sim_status.toUpperCase() === "ACTIVATED" || rowData.sim_status.toUpperCase() === "ACTIVE" || rowData.sim_status.toUpperCase() === "A" || rowData.sim_status.toUpperCase() === "ONLINE" || rowData.sim_status.toUpperCase() === "ACTIVATE"));

  if (record &&rowData?.service_provider_display_name) {
    if (rowData && rowData?.service_provider_display_name && (rowData?.service_provider_display_name.toUpperCase()).includes( "AT&T - TELEGENCE")) {
      const isACtiveOrRestore=isActivated || (rowData.sim_status && (rowData.sim_status.toUpperCase() === "RESTORE SUSPENDED"))
      
      if (moduleFeatures?.includes("Update status-inventory")) {
        results.push({
          key: "update-status",
          label: "Update Status",
        });
      }

      if (moduleFeatures?.includes("Edit cost center-Inventory")) {
        results.push({
          key: "inventory-edit-cost-center",
          label: "Edit Cost Center"
        });
      }

      if (isACtiveOrRestore && moduleFeatures?.includes("Update carrier rate plan-Inventory")) {
        results.push({
          key: "update-carrier-rate-plan",
          label: "Update Rate Plan",
        });
      }

      if (isACtiveOrRestore && moduleFeatures?.includes("Update customer rate plan-Inventory")) {
        results.push({
          key: "update-customer-rate-plan",
          label: "Update Customer Rate Plan",
        });
      }

      if (isACtiveOrRestore && moduleFeatures?.includes("Assign customer-Inventory")) {
        results.push({
          key: "assign-customer",
          label: "Assign Customer"
        })
      }
      if (isACtiveOrRestore && moduleFeatures?.includes("Update features-Inventory")) {
        results.push({
          key: "update-features",
          label: "Update Features"
        })
      }

      if (moduleFeatures?.includes("Edit cost center-Inventory")) {
        if (partner === "Titanium - AWX") {
          results.push({
            key: "update-cost-center",
            label: "Update Cost Center",
          });
        }
      }
      if (isACtiveOrRestore) {
      // if (isACtiveOrRestore && moduleFeatures?.includes("Change Phone Number-Inventory")) {

        results.push({
          key: "change-phone-number",
          label: "Change Phone Number"
        })
      }
    }
    else if (rowData && rowData?.service_provider_display_name && rowData?.service_provider_display_name.toUpperCase() === "EBONDING") {
      // const isActivated = (rowData.sim_status && (rowData.sim_status.toUpperCase() === "ACTIVATED" || rowData.sim_status.toUpperCase() === "ACTIVE"));

      if (moduleFeatures?.includes("Update status-inventory")) {
        results.push({
          key: "update-status",
          label: "Update Status",
        });
      }
      if (isActivated && moduleFeatures?.includes("Update carrier rate plan-Inventory")) {
        results.push({
          key: "update-carrier-rate-plan",
          label: "Update Rate Plan",
        });
      }

      if (isActivated && moduleFeatures?.includes("Update customer rate plan-Inventory")) {
        results.push({
          key: "update-customer-rate-plan",
          label: "Update Customer Rate Plan",
        });
      }

      if (isActivated && moduleFeatures?.includes("Assign customer-Inventory")) {
        results.push({
          key: "assign-customer",
          label: "Assign Customer"
        })
      }
      if (moduleFeatures?.includes("Edit cost center-Inventory")) {
        if (partner === "Titanium - AWX") {
          results.push({
            key: "update-cost-center",
            label: "Update Cost Center",
          });
        }
      }
    }
    else if (rowData && rowData?.service_provider_display_name && rowData?.service_provider_display_name.toUpperCase() === "Rogers") {
      // const isActivated = (rowData.sim_status && (rowData.sim_status.toUpperCase() === "ACTIVATED" || rowData.sim_status.toUpperCase() === "ACTIVE"));

      if (moduleFeatures?.includes("Update status-inventory")) {
        results.push({
          key: "update-status",
          label: "Update Status",
        });
      }
      if (isActivated && moduleFeatures?.includes("Update carrier rate plan-Inventory")) {
        results.push({
          key: "update-carrier-rate-plan",
          label: "Update Rate Plan",
        });
      }

      if (isActivated && moduleFeatures?.includes("Update customer rate plan-Inventory")) {
        results.push({
          key: "update-customer-rate-plan",
          label: "Update Customer Rate Plan",
        });
      }

      if (moduleFeatures?.includes("Edit cost center-Inventory")) {
        if (partner === "Titanium - AWX") {
          results.push({
            key: "update-cost-center",
            label: "Update Cost Center",
          });
        }
      }
    }
    else {
      // const isActivated = (rowData.sim_status && (rowData.sim_status.toUpperCase() === "ACTIVATED" || rowData.sim_status.toUpperCase() === "ACTIVE"));

      const isKoreProvider=(rowData?.service_provider_display_name).toLowerCase()==="kore"

      if (moduleFeatures?.includes("Update status-inventory")) {
        results.push({
          key: "update-status",
          label: "Update Status",
        });
      }

      if (moduleFeatures?.includes("Edit cost center-Inventory")) {
        results.push({
          key: "inventory-edit-cost-center",
          label: "Edit Cost Center"
        });
      }

      if (moduleFeatures?.includes("Update carrier rate plan-Inventory") && !isKoreProvider ) {
        results.push({
          key: "update-carrier-rate-plan",
          label: "Update Carrier Rate Plan",
        });
      }

      if (isActivated && moduleFeatures?.includes("Update customer rate plan-Inventory")) {
        results.push({
          key: "update-customer-rate-plan",
          label: "Update Customer Rate Plan",
        });
      }

      if (moduleFeatures?.includes("Assign customer-Inventory")) {
        results.push({
          key: "assign-customer",
          label: "Assign Customer"
        })
      }

      if (moduleFeatures?.includes("Edit cost center-Inventory")) {
        if (partner === "Titanium - AWX") {
          results.push({
            key: "update-cost-center",
            label: "Update Cost Center",
          });
        }
      }

    }

  }

  return results;
};

const ActionItems: React.FC<ActionItemsProps> = ({
  initialData,
  currentPage,
  itemsPerPage,
  index,
  rowData,
}) => {

  const [openUpdateStatusModal, setOpenUpdateStatusModal] =
    useState<boolean>(false);
  const [openInventoryEditCostCenterModal, setOpenInventoryEditCostCenterModal] = useState<boolean>(false)
  const [openUpdateCarrierRatePlan, setUpdateCarrierRatePlan] =
    useState<boolean>(false);
  const [openUpdateCustomerRatePlan, setUpdateCustomerRatePlan] =
    useState<boolean>(false);
  const [openAssignCustomerModal, setOpenAssignCustomer] = useState<boolean>(false);
  const [openUpdateFeaturesModal, setOpenUpdateFeatures] = useState<boolean>(false);
  const [openEditCostCenterModal, setEditCostCenter] = useState<boolean>(false);
  const [openChangePhoneNumberModal, setOpenChangePhoneNumberModal] =
    useState<boolean>(false);
  const { username, partner, role, settabledata, token, selectedDb,metaData, firstLastName,sessionId,isSubTenant} = useAuth();
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [tableData,setTableData]=useState<any>([])
  const { features: moduleFeatures} = useFeatureStore();
  const originaldata = JSON.stringify(rowData);
  const [isBPEnabled, setIsBPEnabled] = useState(false);

  const handleMenuClick = useCallback(
    (e: any) => {
      setOpen(!open);
      const indexPosition = (currentPage - 1) * itemsPerPage + index;

      switch (e.key) {
        case "update-status":
          setOpenUpdateStatusModal(true);
          break;
        case "inventory-edit-cost-center":
          setOpenInventoryEditCostCenterModal(true);
          break;
        case "update-carrier-rate-plan":
          setUpdateCarrierRatePlan(true);
          break;
        case "update-customer-rate-plan":
          setUpdateCustomerRatePlan(true);
          break;
        case "assign-customer":
          setOpenAssignCustomer(true);
          break;
        case "update-cost-center":
          setEditCostCenter(true);
          break;
        case "update-features":
          setOpenUpdateFeatures(true);
          break;
        case "change-phone-number":
          setOpenChangePhoneNumberModal(true);
          break;
        default:
          break;
      }
    },
    [open, currentPage, itemsPerPage, index]
  );

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "bold",
    padding: "16px",
    // Add padding
  };

  const menuItems = simManagementInventoryActionItem(initialData[0], partner, moduleFeatures, rowData);
const fetchBpFlag = async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_cross_provider_optimization_status",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Active Customer Rate Plan",
        feature_module_name: "Customer Rate Plans",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        const billing_plaform_flag = parsedData?.billing_platform_flag || false;
        setIsBPEnabled(billing_plaform_flag);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };


  useEffect(() => {
    if (openAssignCustomerModal || openUpdateCustomerRatePlan) {
      fetchBpFlag();
    }
  }, [openAssignCustomerModal, openUpdateCustomerRatePlan]);
  
  const fetchData = async () => {
    let parsedData:any
    const url = ENV_ROUTES.SIM_MANAGEMENT;
    const data = {
      tenant_name: partner || "default_value",
      username,
      path: "/get_inventory_data",
      role_name: role,
      parent_module: "Sim Management",
      module_name: "SimManagement Inventory",
      feature_module_name: "Inventory",
      mod_pages: {
        start: 0,
        end: 100,
      },
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
    };
  
    try {
      const response = await axios.post(url, { data });
      parsedData = JSON.parse(response.data.body);
  
      if (parsedData.flag === true) {
        notification.success({
          message: "Success",
          description: "Updated successfully",
          style: messageStyle,
          placement: "top",
        });
      
        setLoading(false)
        closeModals();
        requestIdleCallback(() => {
          settabledata(parsedData?.inventory_data || []);
          console.log("table response:", getCurrentDateTime());
        });
  
      } else {
        Modal.error({
          title: "Data Update Error",
          content: parsedData.message || "An error occurred while updating Inventory data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      setLoading(false);
      Modal.error({
        title: "Data Update Error",
        content: error instanceof Error ? error.message : "An error occurred while updating Inventory data. Please try again.",
        centered: true,
      });
    } finally {
      closeModals()
      setLoading(false)
    }
  };
  // settabledata(parsedData?.inventory_data || [])


  const callSyncLambda = async () =>{
    const isTelegenceProvider=(rowData?.service_provider_display_name).toLowerCase().includes("at&t - telegence")
    try {
      const url = ENV_ROUTES.OPTIMIZATION_SYNC_LAMBDA;
      const data = {
        key_name:"m2m_inventory_live_sync_from_20",
        path:"/lambda_sync_jobs_",
        tenant_name:partner || "default_value",
        service_provider_id:rowData?.service_provider_id || "",
        device_id:rowData?.device_id || "",
        mobility_device_id:rowData?.mobility_device_id || "",
      };

      const response = await axios.post(url, { data });
      const responseData = JSON.parse(response.data.body);

      if (responseData.flag === false) {
        console.error("Data Fetch Error: " + responseData.message);
      } else {
        console.log("Success: Inventory lambda sync successful.");
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }

  }

  const sendUpdatedData = async (updatedRow: any, event_type: any, moduleStatus?:boolean) => {
    let oldData = JSON.parse(originaldata);
    const isKoreProvider=(rowData?.service_provider_display_name).toLowerCase()==="kore"
    const isVerizonProvider=((rowData?.service_provider_display_name).toLowerCase().includes("verizon") || (rowData?.service_provider_display_name).toLowerCase().includes("vzn") || (rowData?.service_provider_display_name).toLowerCase().includes("vzwcr") || (rowData?.service_provider_display_name).toLowerCase().includes("2215-so01")) 
    const isTelgencerovider=(rowData?.service_provider_display_name).toLowerCase().includes("telegence")
    setLoading(true);
    let data: any = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/update_inventory_data",
      role_name: role,
      module_name: "SimManagement Inventory",
      feature_module_name: "Inventory",
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
      table_name: "sim_management_inventory",
      old_data: oldData,
      carrier_api_status:true,
      change_event_type: event_type,
      request_received_at: getCurrentDateTime(),
      template_name: "Inventory Status Update",
      ...(event_type === "Assign Customer" && { billing_platform_flag: isBPEnabled }),
    };
    try {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      if (event_type === "Update Status") {

        const getCurrentDateTimeFormatted = (): string => {
          const now = new Date();

          const pad = (num: number) => num.toString().padStart(2, '0');

          const month = pad(now.getMonth() + 1); // 10 → October
          const day = pad(now.getDate());        // 02
          const year = now.getFullYear();        // 2025

          const hours = pad(now.getHours());
          const minutes = pad(now.getMinutes());
          const seconds = pad(now.getSeconds());

          return `${month}-${day}-${year} ${hours}:${minutes}:${seconds}`;
        };
        const isVerizonActive = isVerizonProvider && updatedRow?.sim_status==="Active"
        const isVerizonDecactive = isVerizonProvider && (updatedRow?.sim_status==="Deactive" || updatedRow?.sim_status==="Deactivated")
        const verizonActiveDetails = {
          FirstName:updatedRow?.first_name || "",
          LastName:updatedRow?.last_name || "",
          BillingAccountNo:rowData?.billing_account_number || "",
          StreetNo:updatedRow?.address || "",
          StreetName:updatedRow?.address || "",
          StreetDirection:updatedRow?.address || "",
          City:updatedRow?.city || "",
          State:updatedRow?.state || "",
          ZipCode:updatedRow?.service_zip_code || "",
          IMEI:rowData?.imei || "",
          ReasonCode: "" ,
          EffectiveDate:isTelgencerovider ?  updatedRow?.effective_date : getCurrentDateTimeFormatted(),
          SubscriberNo: rowData?.msisdn || "",
        };
        const verizonDeactiveDetails = {
          imei:updatedRow?.imei || "",
          revAccountNumber:updatedRow?.rev_customer_id || "",
          reasonCode:updatedRow?.reason_code || "CB" 
        }
        const telegence_additional_details_={
          FirstName:updatedRow?.first_name || "",
          LastName:updatedRow?.last_name || "",
          BillingAccountNo:rowData?.billing_account_number || "",
          StreetNo:updatedRow?.address || "",
          StreetName:updatedRow?.address || "",
          StreetDirection:updatedRow?.address || "",
          City:updatedRow?.city || "",
          State:updatedRow?.state || "",
          ZipCode:updatedRow?.service_zip_code || "",
          IMEI:rowData?.imei || "",
          ReasonCode:updatedRow?.reason_code || "CB" ,
          EffectiveDate: updatedRow?.effective_date || getCurrentDateTimeFormatted(),
          SubscriberNo: rowData?.msisdn || "",
          RevAccountNumber: rowData?.account_number || "",
          
        }
        let telegence_additional_details: any = "";

        if (isTelgencerovider) {
          telegence_additional_details = telegence_additional_details_;
        } else if (isVerizonActive) {
          telegence_additional_details = verizonActiveDetails;
        } else if (isVerizonDecactive) {
          telegence_additional_details = verizonDeactiveDetails;
        }
        data["changed_data"] = {
          id: rowData.id,
          sim_status: updatedRow.sim_status,
          device_status_id:updatedRow?.device_status_id || null,
          iccid:oldData.iccid,
          modified_by: firstLastName,
          public_ip_restriction:updatedRow?.public_ip_restriction || "",
          reason_code:updatedRow?.reason_code || "",
          ...(updatedRow?.activation_profile && { activation_profile: updatedRow.activation_profile }),
          ...(isKoreProvider?{imei:updatedRow.imei}:{imei:rowData.imei}),
          telegence_additional_details,
        };
        if (updatedRow.sim_status === "Activated") {
          data["changed_data"]["date_activated"] = getCurrentDateTime();
        }
        data["changed_data"]["last_used_date"] = getCurrentDateTime();
        data["history"] = {
          service_provider: oldData.service_provider_display_name,
          sim_management_inventory_id: oldData.id,
          imei:isKoreProvider?updatedRow.imei: oldData.imei,
          msisdn: oldData.msisdn,
          previous_value: oldData.sim_status,
          current_value: updatedRow.sim_status,
          date_of_change: getCurrentDateTime(),
          change_event_type: event_type,
          changed_by: firstLastName,
          // tenant_name: partner || "default_value",
          customer_account_name: oldData?.customer_name || "",
          ...(updatedRow?.activation_profile && { activation_profile: updatedRow.activation_profile }),
        };
      }
      if (event_type === "Edit Cost Center") {
        data["changed_data"] = {
          id: rowData.id,
          iccid: updatedRow.iccid,
          cost_center: updatedRow.cost_center || "",
          modified_by: firstLastName,
        };
        data["history"] = {
          service_provider: oldData.service_provider_display_name,
          sim_management_inventory_id: oldData.id,
          iccid: oldData.iccid,
          msisdn: oldData.msisdn,
          previous_value: oldData.cost_center,
          current_value: updatedRow.cost_center,
          date_of_change: getCurrentDateTime(),
          change_event_type: event_type,
          changed_by: firstLastName,
          // tenant_name: partner || "default_value",
          customer_account_name: oldData?.customer_name || "",
        };
      }
      if (event_type === "Update Carrier Rate Plan") {
        console.log("updatedRow",updatedRow)
        data["changed_data"] = {
          id: rowData.id,
          effective_date: updatedRow.effective_date,
          carrier_rate_plan_name: updatedRow.carrier_rate_plan_name || "",
          communication_plan: updatedRow.communication_plan || "",
          modified_by: firstLastName,
        };
        data["history"] = {
          service_provider: oldData.service_provider_display_name,
          sim_management_inventory_id: oldData.id,
          iccid: oldData.iccid,
          msisdn: oldData.msisdn,
          previous_value: oldData.carrier_rate_plan_name,
          current_value: updatedRow.carrier_rate_plan_name,
          date_of_change: getCurrentDateTime(),
          change_event_type: event_type,
          changed_by: firstLastName,
          // tenant_name: partner || "default_value",
          customer_account_name: oldData?.customer_name || "",
        };
      }
      if (event_type === "Update Customer Rate Plan") {
        let customerData = updatedRow?.isRevCustomer ? {rev_customer_id:updatedRow.customer_id || ""} : {customer_id: updatedRow.customer_id || "" }
        data["changed_data"] = {
          id: rowData.id,
          effective_date: updatedRow.effective_date,
          customer_rate_plan_name: updatedRow.customer_rate_plan_name || "",
          customer_rate_pool_name: updatedRow.customer_rate_pool_name !== "None" ? updatedRow.customer_rate_pool_name : "",
          modified_by: firstLastName,
          ...(isSubTenant ? { sub_tenant_customer_rate_plan_name: updatedRow.customer_rate_plan_name || "" } : { sub_tenant_carrier_rate_plan_name: updatedRow.customer_rate_plan_name || "" }),
          ...(isBPEnabled ? {
            customer_name: updatedRow.customer_name,
          ...(moduleStatus ? customerData : { customer_id: updatedRow.customer_id || "" }),
          } : {})
        };
        data["history"] = {
          service_provider: oldData.service_provider_display_name,
          sim_management_inventory_id: oldData.id,
          iccid: oldData.iccid,
          msisdn: oldData.msisdn,
          previous_value: oldData.customer_rate_plan_name,
          current_value: updatedRow.customer_rate_plan_name,
          date_of_change: getCurrentDateTime(),
          change_event_type: event_type,
          changed_by: firstLastName,
          // tenant_name: partner || "default_value",
          customer_account_name: oldData?.customer_name || "",
        };
      }
      if (event_type === "Assign Customer") {
        data["changed_data"] = {
          id: rowData.id,
          customer_name: updatedRow.customer_name,
          // customer_id: updatedRow.customer_id,
          modified_by: firstLastName,
          ...(moduleStatus ? { account_number: updatedRow.customer_id || "" } : { customer_id: updatedRow.customer_id || "" }),
          ...(isBPEnabled ? {
            customer_rate_plan_name: updatedRow.customer_rate_plan_name || "",
            customer_rate_pool_name: updatedRow.customer_rate_pool_name !== "None" ? updatedRow.customer_rate_pool_name : "",
            effective_date: updatedRow?.effective_date || "",
          } : {})
        };
        data["history"] = {
          service_provider: oldData.service_provider_display_name,
          sim_management_inventory_id: oldData.id,
          iccid: oldData.iccid,
          msisdn: oldData.msisdn,
          previous_value: oldData.customer_name,
          current_value: updatedRow.customer_name,
          date_of_change: getCurrentDateTime(),
          change_event_type: event_type,
          changed_by: firstLastName,
          // tenant_name: partner || "default_value",
          customer_account_name: oldData?.customer_name || "",
        };
      }
      if (event_type === "Update feature") {
        data["changed_data"] = {
          id: rowData.id,
          effective_date: updatedRow.effective_date,
          telegence_features: updatedRow.telegence_features || "",
          modified_by: firstLastName,
          configuration_change_details: updatedRow?.configuration_change_details || {},
          mobility_configuration_ids: updatedRow?.mobility_configuration_ids || []
        };
        data["history"] = {
          service_provider: oldData.service_provider_display_name,
          sim_management_inventory_id: oldData.id,
          iccid: oldData.iccid,
          msisdn: oldData.msisdn,
          previous_value: oldData.soc,
          current_value: updatedRow.soc,
          date_of_change: getCurrentDateTime(),
          change_event_type: event_type,
          changed_by: firstLastName,
          // tenant_name: partner || "default_value",
          customer_account_name: oldData?.customer_name || "",
        };
      }
      if (event_type === "Change Phone Number") {
        data["changed_data"] = {
          id: rowData.id,
          effective_date: updatedRow.effective_date,
          modified_by: firstLastName,
          old_msisdn: rowData?.msisdn || "",
          msisdn: rowData?.msisdn || ""
        };
        data["history"] = {
          service_provider: oldData.service_provider_display_name,
          sim_management_inventory_id: oldData.id,
          iccid: oldData.iccid,
          msisdn: oldData.msisdn,
          previous_value: oldData.msisdn,
          current_value: oldData.msisdn,
          date_of_change: getCurrentDateTime(),
          change_event_type: event_type,
          changed_by: firstLastName,
          // tenant_name: partner || "default_value",
          customer_account_name: oldData?.customer_name || "",
        };
      }

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        setLoading(false);
        if(parsedData.error_type && parsedData.error_type=="Warning"){
          console.log("parsedData.error_type",parsedData.error_type)
          Modal.warning({
            title: 'Warning',
            content: parsedData.message || 'An error occurred while submitting data. Please try again.',
            centered: true,
          });
        }
        else{
          Modal.error({
            title: "Data Update Error",
            content:parsedData.message ||"An error occurred while updating Inventory data. Please try again.",
            centered: true,
          });
        }
        
      } else {
        callSyncLambda()
        fetchData();
      }
    } catch (error) {
      setLoading(false);
      console.error("Error fetching data:", error);
      // Modal.error({
      //   title: "Data Update Error",
      //   content:
      //     error instanceof Error
      //       ? error.message
      //       : "An unexpected error occurred while updating data. Please try again.",
      //   centered: true,
      // });
    }
  };
  const closeModals = () => {
    setOpenUpdateStatusModal(false);
    setOpenInventoryEditCostCenterModal(false)
    setUpdateCarrierRatePlan(false);
    setUpdateCustomerRatePlan(false);
    setOpenAssignCustomer(false);
    setOpenChangePhoneNumberModal(false)

  }
  const updateChanges = (updatedRow: any, event_type: any, moduleStatus?:boolean) => {
    sendUpdatedData(updatedRow, event_type, moduleStatus);
  };
  const menu = useMemo(
    () => (
      <Menu onClick={handleMenuClick} className="bg-white shadow-lg rounded-lg">
        {menuItems?.map((item) => {
          if (!item) return null;

          return <Menu.Item key={item.key}>{item.label}</Menu.Item>;
        })}
      </Menu>
    ),
    [menuItems, handleMenuClick]
  );

  return (
    <>
      {loading ? (
        <>
          <Modal
            title={
              <div>
                <span className="font-semibold  text-xl">Updating....</span>
                <hr className="border-gray-300 mt-2 mb-8" />
              </div>
            }
            centered
            open={true}
            width={600}
            height={500}
            // style={{ height: '500px' }}
            onCancel={()=>{setLoading(false); closeModals}}
            footer={null}
          >
            <div className="popup flex justify-center items-center w-full h-full">
              <Spin size="large" />
            </div>
          </Modal>
        </>
      ) : (
        <>
          <Dropdown
            overlay={menu}
            trigger={["click"]}
            open={open}
            placement="bottomLeft"
            onOpenChange={(visible) => setOpen(visible)}
          >
            <Space onClick={handleMenuClick}>
              <Tooltip title="Click to update the record">
                <MoreOutlined rotate={90} className="text-blue-500" />
              </Tooltip>
            </Space>
          </Dropdown>

          <UpdateStatusModal
            rowData={rowData || {}}
            visible={openUpdateStatusModal}
            onCancel={() => setOpenUpdateStatusModal(false)}
            onUpdate={updateChanges}
          />
          <UpdateCarrierRatePlan
            rowData={rowData || {}}
            visible={openUpdateCarrierRatePlan}
            onCancel={() => setUpdateCarrierRatePlan(false)}
            onUpdate={updateChanges}
          />
          <UpdateCustomerRatePlan
            rowData={rowData || {}}
            visible={openUpdateCustomerRatePlan}
            onCancel={() => setUpdateCustomerRatePlan(false)}
            onUpdate={updateChanges}
          />
          <AssignCustomerModal
            rowData={rowData || {}}
            visible={openAssignCustomerModal}
            onCancel={() => setOpenAssignCustomer(false)}
            onUpdate={updateChanges}
          />
          <InventoryEditCostCenterModal
            rowData={rowData || {}}
            visible={openInventoryEditCostCenterModal}
            onCancel={() => setOpenInventoryEditCostCenterModal(false)}
            onUpdate={updateChanges}
          />

          <EditCostCenter
            rowData={rowData || {}}
            visible={openEditCostCenterModal}
            onCancel={() => setEditCostCenter(false)}
            onUpdate={updateChanges}
          />
          <UpdateFeaturesModal
            rowData={rowData || {}}
            visible={openUpdateFeaturesModal}
            onCancel={() => setOpenUpdateFeatures(false)}
            onUpdate={updateChanges}
          />
          <UpdatePhoneNumberModal
            rowData={rowData || {}}
            visible={openChangePhoneNumberModal}
            onCancel={() => setOpenChangePhoneNumberModal(false)}
            onUpdate={updateChanges}
          />
        </>
      )}
    </>
  );
};

export default ActionItems;
