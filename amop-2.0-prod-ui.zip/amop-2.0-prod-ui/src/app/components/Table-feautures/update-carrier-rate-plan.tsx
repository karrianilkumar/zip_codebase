import React, { useState, useEffect } from "react";
import { Modal, Divider, Select, Button, DatePicker, Spin } from "antd";
import { ChevronDownIcon } from "@heroicons/react/24/outline";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { CloseOutlined } from "@ant-design/icons";
import dayjs from "dayjs";
import moment from "moment";

const { Option } = Select;

interface UpdateStatusModalProps {
  visible: boolean;
  onCancel: () => void;
  onUpdate: (updatedRow: any, event_type: string) => void;
  rowData?: any;
}

const UpdateCarrierRatePlan: React.FC<UpdateStatusModalProps> = ({
  visible,
  onCancel,
  onUpdate,
  rowData,
}) => {
  const [selectedCarrierRatePlan, setSelectedCarrierRatePlan] = useState<
    string | undefined
  >(rowData?.carrier_rate_plan_name);
  const [selectedCommPlan, setSelectedCommPlan] = useState<string | undefined>(
    rowData?.communication_plan
  );
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [formData, setFormData] = useState<any>(rowData);
  const [loading, setLoading] = useState(true);
  const { username, partner, role, token, selectedDb,metaData, firstLastName, sessionId } = useAuth();
  const [carrierRatePlanOptions, setCarrierRatePlanOptions] = useState<any[]>([]);
  const [ratePlanCodeOptions, setRatePlanCodOptions] = useState<any[]>([]);
  const [commPlans, setCommPlans] = useState<any[]>([]);
  const [parsedData, setParsedData] = useState<any>(null);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  const handleCarrierRatePlanChange = (value: string) => {
    if (value) {
      const formData_ = { ...formData };
      formData_.carrier_rate_plan_name = value;
      setSelectedCarrierRatePlan(value);
      setFormData(formData_);
      const communicationPlans = parsedData.communication_rate_plan_list[value] || [];
      const formattedCommPlans = communicationPlans.map((plan: any, index: any) => ({
        value: plan,
        name: plan,
        key: index,
      }));
      // setCommPlans(formattedCommPlans);
      setSelectedCommPlan(undefined);
    }
    else {
      // When the value is cleared (X is clicked)
      setSelectedCarrierRatePlan(undefined); // Clear carrier rate plan
      // setCommPlans([]); // Clear communication plans
      setSelectedCommPlan(undefined); // Clear selected communication plan
    }
  };


  const handleCommPlanChange = (value: string) => {
    if (value) {
      const formData_ = { ...formData };
      let commPlan_
      if (value === "no change") {
        commPlan_ = formData_.communication_plan ? rowData.communication_plan : null
      }
      else {
        commPlan_ = value
      }
      formData_.communication_plan = commPlan_;
      setSelectedCommPlan(value);
      setFormData(formData_);
    }
    else {
      setSelectedCommPlan(undefined); // Clear selected communication plan
    }
  };

  const handleDateChange = (date: any, dateString: string | string[]) => {
    if (typeof dateString === "string") {
      setSelectedDate(dateString);
    } else {
      setSelectedDate(dateString[0]);
    }
    const formData_ = { ...formData };
    formData_["effective_date"] = dateString;
    setFormData(formData_);
  };

  const handleCancel = () => {
    setSelectedCarrierRatePlan(undefined);
    setSelectedCommPlan(undefined);
    onCancel();
  };

  const handleSubmit = () => {
    const newErrors: { [key: string]: string } = {};
    if (carrierRatePlanOptions.length > 0 && (!selectedCarrierRatePlan || selectedCarrierRatePlan === "")) newErrors.carrierRatePlan = "Carrier Rate Plan is required.";
    // if (commPlans.length>0&&(!selectedCommPlan||selectedCommPlan==="")) newErrors.commPlan = "Communication Plan is required.";
    if (!selectedCommPlan || selectedCommPlan === "") newErrors.commPlan = "Communication Plan is required.";

    // if (isEffectiveDateChecked && !effectiveDate) {
    //   newErrors.effectiveDate = "Effective date is required.";
    // }
    setErrors(newErrors);

    // Proceed only if there are no errors
    if (Object.keys(newErrors).length === 0) {
      handleUpdate();

      // console.log("Form submitted successfully!");

    }
  };

  const handleUpdate = () => {
    setSelectedCarrierRatePlan(undefined);
    setSelectedCommPlan(undefined);


    const ratePlan_ = selectedCarrierRatePlan;

    if (ratePlan_) {
      // Find the index of the selected rate plan in the options array
      const index = carrierRatePlanOptions.indexOf(ratePlan_);


      if (index !== -1 && ratePlanCodeOptions[index]) {
        const newRatePlanCode = ratePlanCodeOptions[index];

        // Create a new formData object with updated carrier_rate_plan_name
        const updatedFormData = {
          ...formData,
          carrier_rate_plan_name: newRatePlanCode,
        };

        console.log("formData after update", updatedFormData);

        onUpdate(updatedFormData, "Update Carrier Rate Plan");
        return;
      }
    }

    // Fallback if ratePlan_ is undefined or index is invalid
    onUpdate(formData, "Update Carrier Rate Plan");
  };


  useEffect(() => {
    setErrors({})
    // setSelectedCarrierRatePlan(rowData?.carrier_rate_plan_name||'')
    setSelectedCommPlan(rowData?.communication_plan || '')
    const fetchData = async () => {
      setLoading(true);
      try {
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/inventory_dropdowns_data",
          role_name: role,
          parent_module: "Sim Management",
          module_name: "SimManagement Inventory",
          feature_module_name: "Inventory",
          list_view_data_id: rowData?.id || 0,
          service_provider_id: rowData?.service_provider_id,
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
        ... metaData,
          sessionID: sessionId,
          dropdown: "Carrier Rate Plan",
        };

        const response = await axios.post(url, { data });
        const fetchedData = JSON.parse(response.data.body);
        setParsedData(fetchedData);

        if (fetchedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content: fetchedData.message || "An error occurred while fetching Inventory data. Please try again.",
            centered: true,
            onOk: handleCancel,
          });
        } else {
          setLoading(false);
          // const carrierOptions_ = Object.entries(fetchedData.communication_rate_plan_list).map(([name]) => ({ name }));
          const carrierOptions_ = fetchedData?.rate_plan_list || []
          setCarrierRatePlanOptions(carrierOptions_);

          const ratePlanCodeOptions_ = fetchedData?.rate_plan_code_list || []
          setRatePlanCodOptions(ratePlanCodeOptions_);

          // const allCommPlans = Object.values(carrierOptions_).flat();
          const allCommPlans = fetchedData?.communication_plan_list || []
          setCommPlans(allCommPlans);

          const ratePlanCode_ = rowData?.carrier_rate_plan_name || '';

          if (ratePlanCode_) {
            // Find the index of the selected rate plan in the options array
            const index = ratePlanCodeOptions_.indexOf(ratePlanCode_);
            console.log("ratePlanCode_", ratePlanCode_)

            console.log("index", index)

            if (index !== -1 && carrierOptions_[index]) {
              const newRatePlan = carrierOptions_[index];
              console.log("newRatePlanCode", newRatePlan)
              setSelectedCarrierRatePlan(newRatePlan)

            }
            else {
              setSelectedCarrierRatePlan(rowData?.carrier_rate_plan_name || '')

            }
          }
        }
      } catch (error) {
        setLoading(false);
        console.error("Error fetching data:", error);
        Modal.error({
          title: "Data Fetch Error",
          content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
          centered: true,
          onOk: handleCancel,
        });
      } finally {
        setLoading(false);
      }
    };

    if (visible) {
      fetchData();
    }
  }, [visible]);
  const disablePastDates = (current: any) => {
    // Disable all dates before today
    return current && current < moment().startOf('day'); // Start of the current day to include today's date
  };
  return (
    <Modal
      title={<span className="text-[19px]">Update Carrier Rate Plan</span>}
      visible={visible}
      centered
      onCancel={handleCancel}
      footer={[
        <div className="flex justify-center space-x-2 mt-12" key="buttons">
          <Button
            key="cancel"
            onClick={handleCancel}
            className="cancel-btn h-[30px] text-base"
            style={{ fontFamily: "Calibri, sans-serif" }}
          >
            Cancel
          </Button>
          <Button
            key="update"
            onClick={handleSubmit}
            className="save-btn text-base border-none"
            style={{ fontFamily: "Calibri, sans-serif" }}
          >
            Update
          </Button>
        </div>,
      ]}
      width={500}
      style={{ height: "500px" }}
    >
      <>
        {loading ? (
          <div className="popup flex justify-center items-center w-full h-full">
            <Spin size="large" />
          </div>
        ) : (
          <div className="flex flex-col space-y-4">
            <div>
              <label
                htmlFor="carrier-rate-plan"
                className="font-normal text-lg"
                style={{ fontFamily: "Calibri, sans-serif" }}
              >
                Carrier Rate Plan<span className="text-red-500 mt-2">*</span>
              </label>
              <Select
                id="carrier-rate-plan"
                placeholder="Select a Carrier Rate Plan"
                onChange={handleCarrierRatePlanChange}
                className="w-full mt-1 mb-2"
                value={selectedCarrierRatePlan}
                suffixIcon={<ChevronDownIcon className="w-5 mt-2 h-5 text-gray-600" />}
                showSearch
                allowClear
                clearIcon={
                  <CloseOutlined className="clear" />
                }
              >
                {carrierRatePlanOptions.map((option, index) => (
                  <Option key={index} value={option}>
                    {option}
                  </Option>
                ))}
              </Select>
              {errors.carrierRatePlan && <div className="text-red-500 mt-1">{errors.carrierRatePlan}</div>}
            </div>
            <div>
              <label
                htmlFor="comm-plan"
                className="font-normal text-lg"
                style={{ fontFamily: "Calibri, sans-serif" }}
              >
                Communication Plan<span className="text-red-500 mt-2">*</span>
              </label>
              <Select
                id="comm-plan"
                placeholder="Select a Communication Plan"
                onChange={handleCommPlanChange}
                className="w-full mt-2"
                value={selectedCommPlan}
                suffixIcon={<ChevronDownIcon className="w-5 mt-2 h-5 text-gray-600" />}
                showSearch
                allowClear
                clearIcon={
                  <CloseOutlined className="clear" />
                }
              >
                <Option value="no change">No Change</Option>
                {commPlans.map((option, index) => (
                  <Option key={index} value={option}>
                    {option}
                  </Option>
                ))}
              </Select>
              {errors.commPlan && <div className="text-red-500 mt-2">{errors.commPlan}</div>}

            </div>
            <div>
              <label
                htmlFor="effective-date"
                className="font-normal text-lg"
                style={{ fontFamily: "Calibri, sans-serif" }}
              >
                Effective Date
              </label>
              <DatePicker
                id="effective-date"
                onChange={handleDateChange}
                className="w-full h-10 mt-2"
              // disabledDate={disablePastDates}
              />
            </div>
          </div>
        )}
      </>
    </Modal>
  );
};

export default UpdateCarrierRatePlan;
