import React, { useState, useEffect } from "react";
import { Modal, Row, Col, Spin } from "antd";
import { useAuth } from "@/app/components/auth_context";
import { ENV_ROUTES } from "../routes/route_constants";
import axios from "axios";
import { getCurrentDateTime } from "../header_constants";
import Select from "react-select";

interface UpdatePhoneNumberModalProps {
    visible: boolean;
    onCancel: () => void;
    onUpdate: (updatedRow: any, event_type: string) => void;
    rowData?: any;
}

const UpdatePhoneNumberModal: React.FC<UpdatePhoneNumberModalProps> = ({
    visible,
    onCancel,
    onUpdate,
    rowData,
}) => {

    const [formData, setFormData] = useState<any>({...rowData});
    const { username, token, partner, selectedDb, role, firstLastName, sessionId } = useAuth();
    const [loading, setLoading] = useState(false);
    const [currentDate, setCurrentDate] = useState('');
    // const [newMSISDN, setNewMSISDN] = useState("");
    const [msisdnError, setMsisdnError] = useState("");

    useEffect(() => {
        if (visible) {
            console.log("formData",formData)
            const date = new Date();
            const formattedDate =
                `${(date.getMonth() + 1).toString().padStart(2, '0')}/${date.getDate().toString().padStart(2, '0')}/${date.getFullYear()}`;
            setCurrentDate(formattedDate);
            setFormData({ ...formData, effective_date: formattedDate})
        }
        // setMsisdnError("")
        // setNewMSISDN("")
    }, [visible,rowData]);

    const handleUpdate = () => {
        onUpdate(formData, "Change Phone Number");
        // let hasError = false;
        // if (!/^[0-9]{10,18}$/.test(newMSISDN)) {
        //     setMsisdnError("Subscriber Number must be between 10 to 18 digits long.");
        //     console.log("Validation failed: Invalid Subscriber Number format.");
        //     hasError = true;
        //   }
        //   else {
        //     setMsisdnError("")
        //   }
        //   if(!hasError){
        //     onUpdate(formData, "Change Phone Number");
        //   }
    };

    const handleCancel = () => {
        // setNewMSISDN("")
        setFormData(rowData);
        onCancel();
    };

    return (
        <Modal
            title={
                <div className="mt-[-10px]">
                    <span className="text-[19px]">Change Phone Number</span>
                </div>
            }
            visible={visible}
            centered
            onCancel={handleCancel}
            footer={[
                <div className="flex justify-center space-x-2 mt-12" key="buttons">
                    <button
                        key="cancel"
                        onClick={onCancel}
                        className="cancel-btn h-[30px] text-base"
                        style={{ fontFamily: "Calibri, sans-serif" }}
                    >
                        Cancel
                    </button>
                    <button
                        key="update"
                        onClick={handleUpdate}
                        className="save-btn  text-base border-none"
                        style={{ fontFamily: "Calibri, sans-serif" }}
                    >
                        Update
                    </button>
                </div>,
            ]}
            width={500}
            style={{ height: "500px" }}
        >
            <>
                {loading ? (
                    <div className="popup flex justify-center items-center w-full h-full mt-4">
                        <Spin size="large" />
                    </div>
                ) : (
                    <>
                        <Row style={{ marginBottom: 16 }}>
                            <Col span={8}>
                                <label className="text-lg" style={{ fontFamily: "Calibri, sans-serif" }}>
                                    Effective Date
                                </label>
                            </Col>
                            <Col span={16}>
                                <input
                                    type="text"
                                    value={currentDate}
                                    className="non-editable-input"
                                    disabled
                                />
                            </Col>
                        </Row>
                        <Row style={{ marginBottom: 16 }}>
                            <Col span={8}>
                                <label className="text-lg" htmlFor="old_msisdn" style={{ fontFamily: "Calibri, sans-serif" }}>
                                    Old Subscriber Number
                                </label>
                            </Col>
                            <Col span={16}>
                                <input
                                    className="non-editable-input"
                                    id="old_msisdn"
                                    value={rowData.msisdn || ""}
                                    disabled
                                />
                            </Col>
                        </Row>
                        {/* <Row>
                            <Col span={8}>
                                <label className="text-lg" htmlFor="new_msisdn" style={{ fontFamily: "Calibri, sans-serif" }}>
                                    New Subscriber Number
                                </label>
                            </Col>
                            <Col span={16}>
                                <input
                                    className="input"
                                    id="new_msisdn"
                                    value={newMSISDN}
                                    onChange={(e) => {
                                        setFormData({ ...formData, msisdn: e.target.value })
                                        setNewMSISDN( e.target.value )}}
                                />
                                {msisdnError && <div className="text-red-500 text-sm">{msisdnError}</div>}
                            </Col>
                        </Row> */}

                    </>
                )
                }
            </>

        </Modal>
    );
};

export default UpdatePhoneNumberModal;
