'use client'
import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { usePathname } from 'next/navigation';
import Link from 'next/link';
import { ChevronDownIcon, ChevronLeftIcon, ChevronRightIcon, Bars3Icon } from '@heroicons/react/24/outline';
import Image from 'next/image';
import { moduleIconMap } from '../constants/moduleiconmap';
import { useAuth } from './auth_context';
import { useLogoStore } from '../stores/logoStore';
import dayjs from 'dayjs';
import { useOptimizationStore } from '../stores/optimizationStore';
import { useSidebarStore } from '../stores/navBarStore';
import { Modal, Tooltip } from 'antd';
import { ENV_ROUTES } from './routes/route_constants';
import { getCurrentDateTime } from './header_constants';
import axios from 'axios';
import ThemeSelector from './ThemeSelector';
import { useCustomerProfileStore } from '../billing/killbill_stores/customer_profile_store';
import { useSearchStore } from '../stores/searchStore';
interface NavItem {
  label: string;
  icon?: React.ReactNode;
  href?: string;
  subNav?: NavItem[];
}
const renderIcon = (iconClass: string | undefined) => {
  if (!iconClass) return null;
  return <i className={`${iconClass} w-4 h-4`}></i>; // Render the Flat Icon using the class
};

type IconKey = keyof typeof moduleIconMap;

const encodePathComponent = (component: string): string => {
  return encodeURIComponent(  component?.toLowerCase().replace(/[\s/:;.&]/g, "_") || "");
};


const generateNavItems = (modules: any[]): NavItem[] => {
  return modules.map((module) => {
    const { parent_module_name, children } = module;
    const iconClass = moduleIconMap[parent_module_name as IconKey];
    const subNav =
      children.length > 0
        ? children.map((child: any) => {
          const childIconClass = moduleIconMap[child.child_module_name as IconKey];
          const childHref = `/${encodePathComponent(
            parent_module_name
          )}/${encodePathComponent(child.child_module_name)}`;

          return {
            icon: renderIcon(childIconClass),
            href: child.child_module_name ? childHref : undefined,
            label: child.child_module_name,
            subNav: child.sub_children?.map((subChild: any) => {
              //const subChildIconClass = moduleIconMap[subChild.sub_child_module_name as IconKey];
                const subChildIconClass = subChild.sub_child_module_name === "Billing"
              ? moduleIconMap["BillingChild"]
              : moduleIconMap[subChild.sub_child_module_name as IconKey];
              const subChildHref = `/${encodePathComponent(
                parent_module_name
              )}/${encodePathComponent(
                child.child_module_name
              )}/${encodePathComponent(subChild.sub_child_module_name)}`;
              return {
                icon: renderIcon(subChildIconClass),
                href: subChildHref,
                label: subChild.sub_child_module_name,
              };
            }),
          };
        })
        : [];

    const href =
      children.length === 0
        ? `/${encodePathComponent(parent_module_name)}`
        : undefined;

    return {
      label: parent_module_name,
      icon: renderIcon(iconClass),
      href: href,
      subNav,
    };
  });
};

const SideNav: React.FC = () => {
  const setAccountNumber = useCustomerProfileStore((state) => state.setAccountNumber);
  const currentPath = usePathname();
  const { modules, selectedDb,metaData, settabledata, setShowPasswordUpdate, sessionId, logoUrl, collapsedLogoUrl, partner, role, username, firstLastName, token, darkModeLogoUrl, darkModeCollapsedLogoUrl } = useAuth();
  // const { logoUrl } = useLogoStore();
  const [openDropdowns, setOpenDropdowns] = useState<{
    [key: string]: boolean;
  }>({});
  const [navItems, setNavItems] = useState<NavItem[]>([]);
  const setTitle = useLogoStore((state) => state.setTitle);
  const { optimizationRow, setOptimizationRow } = useOptimizationStore()

  const storedLogo: any = localStorage.getItem('logo');
  const logoUrl_ = logoUrl || storedLogo || ""
  const { setIsCustomerProfilesNav,setShowNewPage } = useCustomerProfileStore();
  const storedCollapsedLogo: any = localStorage.getItem('collapsed_logo');
  const collapsedLogoUrl_ = collapsedLogoUrl || storedCollapsedLogo || ""

  const storedDarkModeCollapsedLogo: any = localStorage.getItem('dark_mode_collapsed_logo');
  const darkModeCollapsedLogoUrl_ = darkModeCollapsedLogoUrl || storedDarkModeCollapsedLogo || ""

  const storedDarkModeLogo: any = localStorage.getItem('dark_mode_logo');
  const darkModeLogoUrl_ = darkModeLogoUrl || storedDarkModeLogo || ""
  useEffect(() => {
    const generatedItems = generateNavItems(modules);
    setNavItems(generatedItems);
  }, [modules]);

  const [isCollapsedMode, setIsCollapsedMode] = useState(false);
  const [isLargeScreen, setIsLargeScreen] = useState(false);

  const isExpanded = useSidebarStore((state) => state.isExpanded);
  const setIsExpanded = useSidebarStore((state) => state.setIsExpanded);
  const setIsDeploying = useSidebarStore((state: any) => state.setIsDeploying);
  const setDeployMsg = useSidebarStore((state: any) => state.setDeployMsg);
  const [theme, setTheme] = useState('normal');
  const { setIsRedirectedFromDetails } = useSearchStore();
  

  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        const storedTheme = localStorage.getItem('app_theme');
        if (storedTheme) setTheme(storedTheme);
      } catch (e) {
        console.warn("Error reading theme from localStorage:", e);
      }
    }
  }, []);

  const fetchBanner = async () => {
    try {
      const url = ENV_ROUTES.TENANT_ONBOARDING;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_deployment_alert",
        role_name: role,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: "Banner Error",
          content:
            parsedData.message ||
            "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      } else {
        const bannerData = parsedData?.data && parsedData?.data.length > 0 ? parsedData?.data[0] : parsedData?.data || {}
        console.log("bannerData", bannerData)
        const is_deploying = bannerData?.status || false
        setIsDeploying(is_deploying)
        const ideploying_msg = bannerData?.banner || "Deployment is in Progress"
        setDeployMsg(ideploying_msg)

      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: "Banner Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
    }
  };

  useEffect(() => {
    const updateScreenSize = () => {
      const large = window.innerWidth >= 1024;
      setIsLargeScreen(large);
      setIsCollapsedMode(large && !isExpanded);
      console.log("isexpanded", isExpanded)
      console.log("large", large)
    };

    console.log("logoUrl", logoUrl_)
    console.log("collapsedlogo", collapsedLogoUrl_)
    console.log("darkModeCollapsedlogo", darkModeCollapsedLogoUrl_)
    console.log("darkModelogo", darkModeLogoUrl_)


    updateScreenSize(); // Initial check
    window.addEventListener("resize", updateScreenSize);
    //for side submenu
    // if(!isExpanded){
    //   closeDropdown()
    // }
    return () => window.removeEventListener("resize", updateScreenSize);
  }, [isExpanded]);


  const toggleDropdown = useCallback((key: string) => {
    setOpenDropdowns((prev) => ({
      ...Object.keys(prev).reduce((acc, dropdownKey) => {
        // Close all other parent dropdowns

        if (!key.startsWith(dropdownKey)) {
          acc[dropdownKey] = false;
        }
        else {
          acc[dropdownKey] = true;
        }
        return acc;
      }, {} as { [key: string]: boolean }),
      // Toggle the current dropdown
      [key]: !prev[key],
    }));
  }, []);

  const isActive = useCallback(
    (href?: string, subNav?: NavItem[]): boolean => {
      if (!href) return false;
      // Check if the current path starts with the href or any of its subNav links
      if (
        currentPath === href ||
        currentPath.startsWith(href + "/")
      ) {
        return true;
      }
      // Recursively check for nested subNav items
      if (subNav && subNav.length > 0) {
        return subNav.some((subItem) => isActive(subItem.href, subItem.subNav));
      }
      return false;
    },
    [currentPath]
  );

  useEffect(() => {
    const findActiveLabel = (items: NavItem[]): string | undefined => {

      for (const item of items) {
        if (item.subNav) {
          for (const subItem of item.subNav) {
            if (subItem.subNav) {
              for (const subSubItem of subItem.subNav) {
                if (isActive(subSubItem.href, subSubItem.subNav)) {
                  return subSubItem.label;
                }
              }
            }
            if (isActive(subItem.href, subItem.subNav)) {
              return subItem.label;
            }
          }
        }
        if (isActive(item.href, item.subNav)) {
          return item.label;
        }
      }

      return undefined;
    };

    const activeLabel = findActiveLabel(navItems);
    if (activeLabel) {
      setTitle(activeLabel); // Set the title in the store based on active label
      settabledata([]);
    }
    fetchBanner()
  }, [currentPath, navItems, isActive, setTitle]);

  const handleNavigationClick = (
    event: React.MouseEvent<HTMLAnchorElement>,
    label: string,
    href?: string,
    parentLabel?: string
  ) => {
    setIsRedirectedFromDetails(false)
    setOptimizationRow(null)
    setShowPasswordUpdate(false);
    const clickTime = dayjs().format('HH:mm:ss.SSS');
    localStorage.setItem('latestNavClick', JSON.stringify({ label, clickTime }));
    const currentPath = location.pathname;
    // Check for "Net Sapiens" or its children
    if (parentLabel === "Net Sapiens" || label === "Net Sapiens") {
      event.preventDefault(); // Stop navigation in current tab
      const redirectUrl = process.env.NEXT_PUBLIC_AMOP_1_BASE_URL + "/NetSapiens";
      window.open(redirectUrl, "_blank"); // Open in new tab
    } else if (parentLabel === "LNP" || label === "LNP") {
      event.preventDefault(); // Stop navigation in current tab
      const redirectUrl = process.env.NEXT_PUBLIC_AMOP_1_BASE_URL + "/LNP/PhoneNumbers";
      window.open(redirectUrl, "_blank"); // Open in new tab
    } 
    else if ((parentLabel === "Customer Profiles" || label === "Customer Profiles")) {
      // setIsCustomerProfilesNav(true);
      localStorage.setItem("isCustomerProfileNav","true")
      setShowNewPage(false);
    };
    setAccountNumber("")
   localStorage.removeItem("accountNumber");
   localStorage.removeItem("CustomerNumber");
   localStorage.removeItem("is_redirected");

  }

  const closeDropdown = () => {
    setOpenDropdowns({});
  };

  const hasActiveChild = (subNav: NavItem[] = []): boolean => {
    return subNav.some(
      (subItem) =>
        isActive(subItem.href, subItem.subNav) || hasActiveChild(subItem.subNav)
    );
  };


  const renderNavItems = (items: NavItem[], parentKey?: string, parentLabel?: string, isCollapsedSubmenu?: boolean) =>
    items.map((item) => {
      const key = parentKey ? `${parentKey}-${item.label}` : item.label;
      const isItemActive = isActive(item.href, item.subNav) || hasActiveChild(item.subNav);
      const isOpen = openDropdowns[key];

      return (
        <li key={key} className="relative">
          {item.subNav && item.subNav.length > 0 ? (
            <>
              {/* Navigation Item with Dropdown */}
              <Tooltip title={item.label} placement="left">
                <div className={`flex items-center justify-between p-2 nav-link w-full cursor-pointer ${isItemActive ? 'nav-active-link' : ''} ${isCollapsedMode ? 'pl-[12px]' : ''}`} onClick={() => {
                  // setIsExpanded(true)  //for side submenu
                  // setIsCollapsedMode(false) //for sid e submenu
                  // if(!isCollapsedMode){
                  toggleDropdown(key)
                  // }

                }}>
                  <div className="flex items-start space-x-1">
                    {item.icon}
                    {(!isCollapsedMode) && (
                      <span className="whitespace-normal break-words flex-1">{item.label}</span>
                    )}
                  </div>
                  {!isCollapsedMode && (
                    <button
                      onClick={() => toggleDropdown(key)}
                      className="ml-auto"
                    >
                      {isOpen ? (
                        <ChevronDownIcon className="w-4 h-4 flex-shrink-0" />
                      ) : (
                        <ChevronRightIcon className="w-4 h-4 flex-shrink-0" />
                      )}
                    </button>
                  )}

                </div>
              </Tooltip>

              {/* Sub Navigation Items */}
              {isOpen && (
                // isCollapsedMode ? (
                //   <ul
                //     className="absolute left-full top-0 mt-0 ml-1 bg-white shadow-lg border rounded min-w-[160px]"
                //     style={{ zIndex: 9999 }}
                //   >
                //     {renderNavItems(item.subNav, key, item.label,true)}
                //   </ul>

                // ) : (
                <ul className={`${isCollapsedMode ? 'pl-2' : 'pl-6'} space-y-2 mt-2`}>
                  {renderNavItems(item.subNav, key, item.label)}
                </ul>
                // )
              )}
            </>
          ) : (
            <Link href={item.href || ''} passHref legacyBehavior>
                <a
                  onClick={(event) => {
                    handleNavigationClick(event, item.label, item.href, parentLabel);
                    // if (parentKey) {
                    // closeDropdown(); // Close the submenu
                    if (!isLargeScreen) {
                      setIsExpanded(false)
                    }
                    // }
                  }}
                  className={`flex justify-between items-center p-2 nav-link w-full cursor-pointer ${isItemActive ? "nav-active-link" : ""} ${isCollapsedMode ? 'pl-[12px]' : ''}`}

                >
              <Tooltip title={item.label} placement="left">

                  <div className="flex items-start space-x-2 w-full">
                    {item.icon}
                    {(!isCollapsedMode) && (
                    <span
                      className={`whitespace-normal break-words flex-1 ${
                        item.label === "Billing Report w/_City_County_Country" ? "text-sm" : ""
                      }`}
                    >
                      {item.label}
                    </span>
                    )}
                  </div>
              </Tooltip>
                </a>

            </Link>
          )}
        </li>

      );
    });
  const memoizedNavItems = useMemo(
    () => renderNavItems(navItems),
    [navItems, openDropdowns, toggleDropdown, isActive, isExpanded, isCollapsedMode]
  );

  const renderLogo = () => {
    return (
      <>
        <img
          src={logoUrl_}
          alt="Uploaded Logo"
          width={150}
          height={40}
          // className="logo"
           className={`${partner === "4GBiz" ? "partner-4g" : "logo"}`}
        />
      </>
    )
  }
  const renderCollapsedLogo = () => {
    return (
      <>
        <img
          src={collapsedLogoUrl_}
          alt="Uploaded Logo"
          width={150}
          height={40}
          className="collapsed-logo !ml-[0px]"
        />
      </>
    )
  }
  const renderDarkModeCollapsedLogo = () => {
    return (
      <>
        <img
          src={darkModeCollapsedLogoUrl_}
          alt="Uploaded Logo"
          width={150}
          height={40}
          className="collapsed-logo !ml-[0px]"
        />
      </>
    )
  }
  const renderDefaultLogo = () => {
    return (
      <>
        <Image
          src="/amop-core.png"
          alt="AMOP Core Logo"
          width={150}
          height={40}
          layout="intrinsic"
        />
      </>
    )
  }
  const renderDarkModeLogo = () => {
    return (
      <>
        <img
          src={darkModeLogoUrl_}
          alt="Uploaded Logo"
          width={150}
          height={40}
          // className="logo"
           className={`${partner === "4GBiz" ? "partner-4g" : "logo"}`}
        />
      </>
    )
  }

  return (
    <div className={`navbar p-2 shadow-lg ${isExpanded
      ? "w-[250px]"
      : "lg:w-[70px]"
      }`}>
      <div className="flex items-center space-x-2">
        {isExpanded ? (
          <>
            {theme === 'dark'
              ? (
                darkModeLogoUrl_ && darkModeLogoUrl_ !== "" && darkModeLogoUrl_ !== "null"
                  ? (
                    renderDarkModeLogo()
                  ) : (logoUrl_ && logoUrl_ !== "" && logoUrl_ !== "null")
                    ? (
                      renderLogo()
                    ) : (
                      renderDefaultLogo()
                    )
              )
              : ((logoUrl_ && logoUrl_ !== "" && logoUrl_ !== "null")
                ? (
                  renderLogo()
                ) : (
                  renderDefaultLogo()
                )
              )}
          </>
        ) : (
          <>

            {theme === 'dark'
              ? (
                darkModeCollapsedLogoUrl_ && darkModeCollapsedLogoUrl_ !== "" && darkModeCollapsedLogoUrl_ !== "null"
                  ? (
                    renderDarkModeCollapsedLogo()
                  ) : (logoUrl_ && logoUrl_ !== "" && logoUrl_ !== "null")
                    ? (
                      renderCollapsedLogo()
                    ) : (
                      renderDefaultLogo()
                    )
              )
              : ((collapsedLogoUrl_ && collapsedLogoUrl_ !== "" && collapsedLogoUrl_ !== "null")
                ? (
                  renderCollapsedLogo()
                ) : (
                  renderDefaultLogo()
                )
              )}
          </> 
        )}

      </div>
      <div>
        {/* Toggle Button */}
        {/* <button onClick={()=>{setIsExpanded(!isExpanded)}} className="text-gray-700 focus:outline-none mr-4">
    <Bars3Icon className='w-6 h-6' />
  </button> */}
      </div>

      <ul className="space-y-4 mt-4">{memoizedNavItems}</ul>
    </div>
  );
};

export default React.memo(SideNav);
