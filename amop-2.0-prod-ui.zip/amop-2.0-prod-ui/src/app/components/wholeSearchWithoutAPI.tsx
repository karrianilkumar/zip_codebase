import React, { useCallback, useEffect, useRef, useState } from "react";
import { Input, Button, Modal, Spin } from "antd";
import { SearchOutlined, CloseOutlined } from "@ant-design/icons";
import axios from "axios";
import { useAuth } from "./auth_context";
import { useFeatureStore } from "../sim_management/inventory/featureStore";
import { MultiValue } from "react-select";
import { ENV_ROUTES } from "./routes/route_constants";
import { useSearchStore } from "../stores/searchStore";
import { debounce } from "lodash";
import { useOptimizationStore } from "@/app/stores/optimizationStore";
import { useCustomerRatePlanStore } from "../stores/customerRateplanStore";
interface SearchInputProps {
    modulename: string;
    headerMap: Record<string, any>;
    headers: any;
    initialData: any;
    itemsPerPage: number;
}

interface HeaderOption {
    value: string;
    label: string;
}

const WholeSearchWithoutAPI: React.FC<SearchInputProps> = ({
    modulename,
    headers = [],
    headerMap = {},
    initialData,
    itemsPerPage = 10
}) => {
    // const [searchTerm, setSearchTerm] = useState("");
    const [searchTable, setSearchTable] = useState<any[]>([]);
    const { setWithoutAPISearchData, setOptimizationErrorsData,withoutAPISearchData,setSearchTerm,searchTerm,activeFilters } = useSearchStore();
    const [loading, setLoading] = useState(false);

    const inputRef = useRef<HTMLInputElement | null>(null);

    useEffect(() => {
        console.log("initial data", initialData)
        console.log("modulename", modulename)
        console.log("headers", headers)
        console.log("headerMap", headerMap)

    }, [initialData, modulename, headers, headerMap])

    const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
        const value = e.target.value;
        setSearchTerm(value);

    };

const handleSearchSubmit = () => {
  setLoading(true);

  const term = searchTerm.toLowerCase();

  const filtered = initialData.filter((item: any) => {
    // ✅ Safely convert to string for search term check
    const matchesSearchTerm = headers.some((header: any) => {
      const value = item[header];
      return value !== null && value !== undefined 
        ? String(value).toLowerCase().includes(term)
        : false;
    });

    // ✅ Safely convert to string for filter matching
    const matchesFilters = Object.entries(activeFilters).every(([key, values]) => {
      if (!Array.isArray(values) || values.length === 0) return true;
      const itemValue = item[key];
      return values.some((filterVal) =>
        itemValue !== null && itemValue !== undefined
          ? String(itemValue).toLowerCase().includes(filterVal.toLowerCase())
          : false
      );
    });

    return matchesSearchTerm && matchesFilters;
  });
//   console.log("🔍 Filtered data based on searchTerm and activeFilters:", filtered);
  if (filtered.length === 0) {
    Modal.error({
      title: 'No Records Found',
    //   content: 'No matching records were found for your search.',
      centered: true,
      onOk: () => {
        setSearchTable(initialData);
        setWithoutAPISearchData(initialData);
        setSearchTerm('')
      },
    });
  } else {
    setSearchTable(filtered);
    setWithoutAPISearchData(filtered);
  }

  setLoading(false);
};




   const handleClear = () => {
  setSearchTerm(""); // Clear search input

  // Check if filters exist
  const hasFilters = Object.values(activeFilters).some((arr) => Array.isArray(arr) && arr.length > 0);

  if (hasFilters) {
    // Apply filter logic only (no search term)
    const filteredData = initialData.filter((row: any) => {
      return Object.entries(activeFilters).every(([key, values]) => {
        const rowValue = row[key]?.toString().trim().toLowerCase();
        if (Array.isArray(values)) {
          return values.map((v: string) => v.toLowerCase().trim()).includes(rowValue);
        }
        return true; // If values is not an array, skip filter
      });
    });

    setSearchTable(filteredData.slice(0, itemsPerPage));
    setWithoutAPISearchData(filteredData);
    setOptimizationErrorsData([]);
  } else {
    // No filters, just reset to first page
    const filtered = initialData.slice(0, itemsPerPage);
    setSearchTable(filtered);
    setWithoutAPISearchData([]);
    setOptimizationErrorsData([]);
  }
};

    return (
        <div className="">
            {loading && (
                <div className="absolute inset-0 flex justify-center items-center bg-white bg-opacity-75 z-50 pointer-events-none">
                    <Spin size="large" />
                </div>
            )}
            <div className="flex items-center space-x-2">
                <div className="relative flex items-center border border-gray-300 rounded-lg p-1 w-full space-x-4 w-[250px]">
                    <input
                        placeholder={"Search..."}
                        value={searchTerm}
                        onChange={handleSearch}
                        ref={inputRef}
                        onKeyDown={(e) => {
                            if (e.key === "Enter") {
                                handleSearchSubmit();
                            }
                        }}
                        className="h-8 border-none outline-none w-full pl-2 pr-12 rounded-lg search-input"
                    />
                    {searchTerm && (
                        <CloseOutlined
                            className="absolute right-8 text-gray-500 cursor-pointer"
                            onClick={handleClear}
                        />
                    )}
                    <SearchOutlined
                        className="absolute right-2 text-gray-500 cursor-pointer"
                        onClick={handleSearchSubmit}
                    />
                </div>
                {(searchTerm && (typeof window !== "undefined" && window.innerWidth > 700)) && (
                    <button
                        className="save-btn hidden md:inline-flex"
                        onClick={handleSearchSubmit}
                    >
                        Search
                    </button>
                )}
            </div>
        </div>
    );
};

export default WholeSearchWithoutAPI;
