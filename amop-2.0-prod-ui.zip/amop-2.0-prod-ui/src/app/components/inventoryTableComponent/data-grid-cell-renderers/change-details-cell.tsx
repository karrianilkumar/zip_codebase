import { FC, useEffect, useState } from "react";
import { useRouter } from 'next/navigation';
import { Tooltip } from "antd";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { InformationCircleIcon } from "@heroicons/react/24/outline";

export const ChangeDetailCell: FC<{
  row?: any;
}> = ({ row }) => {
  const [isMounted, setIsMounted] = useState(false);
  const router = useRouter();
  const { setRowId,setBulkRow} = useFeatureStore();

  useEffect(() => {
    setIsMounted(true);
  }, []);
  
  const handleClick = () => {
    if (isMounted) {
      setBulkRow(row)
      localStorage.setItem('bulk_row', JSON.stringify(row || "{}"));
      if(row){
        router.push(`/sim_management/bulk_history`);
      }
    }
  };

  return (
    <div className="flex w-full ml-8">
    <Tooltip title="More information about the bulk change">
      <a onClick={handleClick} className="text-center block cursor-pointer">
        <InformationCircleIcon className="h-5 w-5 text-green-500 cursor-pointer"/>
      </a>
    </Tooltip>
    </div>
  );
};

export function ChangeDetailCellRenderer(row: any) {
  return <ChangeDetailCell row={row} />;
}

