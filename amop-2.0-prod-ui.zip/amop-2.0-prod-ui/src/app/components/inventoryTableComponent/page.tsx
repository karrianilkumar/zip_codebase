"use client";
import React, { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
    PencilIcon,
    TrashIcon,
    InformationCircleIcon,
    UserIcon,
} from "@heroicons/react/24/outline";
import { CopyOutlined } from "@ant-design/icons";
import EditModal from "../../components/editPopup";
import Pagination from "@/app/components/pagination";
import EditUsernameCellRenderer from "./data-grid-cell-renderers/edit-username-cell-renderer";
import { StatusCellRenderer } from "./data-grid-cell-renderers/status-cell-renderer";
import { StatusHistoryCellRenderer } from "./data-grid-cell-renderers/status-history-cell-renderer";
import ServiceProviderCellRenderer from "./data-grid-cell-renderers/service-provider-cell-renderer";
import { Modal, Checkbox, notification, Spin, Tooltip, Button, Radio } from "antd";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import ActionItems from "@/app/components/Table-feautures/action-items";
import {
    ArrowUpOutlined,
    ArrowDownOutlined,
    ExclamationCircleOutlined,
} from "@ant-design/icons";
import StatusIndicator from "./data-grid-cell-renderers/status-indicator";
import QuantityCell, {
    STATUS_TYPE,
} from "./data-grid-cell-renderers/quantity-cell-renderer";
import { ChangeDetailCellRenderer } from "./data-grid-cell-renderers/change-details-cell";
import { useAuth } from "../auth_context";
import axios from "axios";
import { getCurrentDateTime } from "../header_constants";
import { usePartnerStore } from "@/app/partner/partner_info/partnerStore";
import { ENV_ROUTES } from "../routes/route_constants";
import { useSearchStore } from "@/app/stores/searchStore";
import { useOptimizationStore } from "@/app/stores/optimizationStore";
import AssignRatePlanModal from "../optimizationTableComponent/assignRatePlanModal";
import { useCustomerRatePlanStore } from "@/app/stores/customerRateplanStore";
import RowDetailsModal from "../rowDetailsModal";

interface InventoryTableComponentProps {
    headers: string[];
    initialData: { [key: string]: any }[];
    searchQuery: string;
    visibleColumns: string[];
    itemsPerPage: number;
    allowedActions?: (
        | "Actions"
    )[];
    popupHeading: string;
    advancedFilters?: any;
    createModalData?: any[];
    generalFields?: any;
    isSelectRowVisible?: boolean;
    headerMap?: any;
    pagination: any;
    height?: any;
}

const colorMap = {
    activated: "#12E620",
    activate: "#12E620",
    reactive: "#12E620",
    online: "#12E620",
    active: "#12E620",
    a: "#12E620",
    deactivated: "#E61224",
    deactivate: "#E61224",
    deactive: "#E61224",
    inactive: "#E61224",
    stopped: "#E61224",
    "activation ready": "#E6CA15",
    "pending activation": "#52A6E6",
    retired: "#7D7D7D",
    "pre-active": "#d1dade",
    waiting: "#ffc107",
    unactivated: "#ffc107",
    // Add more statuses and colors as needed
};

const InventoryTableComponent: React.FC<InventoryTableComponentProps> = ({
    headers,
    initialData,
    searchQuery,
    visibleColumns,
    itemsPerPage,
    allowedActions,
    popupHeading,
    createModalData,
    generalFields,
    advancedFilters,
    isSelectRowVisible = true,
    headerMap,
    pagination,
    height,
}) => {
    const [rowData, setRowData] = useState<{ [key: string]: any }[]>(initialData);
    const [currentPage, setCurrentPage] = useState(1);
    const isFirstRender = useRef(true);
    const isFirstSearchRender = useRef(true);
    const isFirstTableDataRender = useRef(true);
    const isFirstAdvancedSearchRender = useRef(true);
    const [selectAll, setSelectAll] = useState(false);
    const [selectedRows, setSelectedRows] = useState<number[]>([]);
    const [sortConfig, setSortConfig] = useState<{ key: string; direction: "ascending" | "descending"; } | null>(null);
    const { optimizationRow, optimizationType } = useOptimizationStore()
    const {
        username,
        tenantNames,
        role,
        partner,
        selectedPartnerModule,
        Environment,
        tabledata,
        storedpagination,
        advancedStoredpagination,
        combineAdnvaceStoredpagination,
        token,
        selectedDb,
        metaData,
        sessionId,
        serviceProviderList,
        selectedServiceProvider,
        setAdvancedStoredPagination,
        setStoredPagination,
        setCombineAdnvaceStoredpagination,
        firstLastName
    } = useAuth();
    const [totalPages, setTotalPages] = useState(1);
    const { bulkRow, features: moduleFeatures } = useFeatureStore();
    const [loading, setLoading] = useState(false);
    const { searchData,
        advancedSearchData,
        combineAdnvaceSearchData,
        setOptimizationErrorsData,
        setOptimizationErrorsPagination,
        optimizationErrorsData,
        optimizationErrorsPagination,
        isSearchComponentCall,
        setIsSearchComponentCall
    } = useSearchStore();
    const { showAdvanced } = useCustomerRatePlanStore();
    const [assignRatePlanOpen, setAssignRatePlanOpen] = useState(false);
    const [assignRatePlanRowIndex, setAssignRatePlanRowIndex] = useState<number | null>(null);

    const [showRowModal, setShowRowModal] = useState<boolean>(false);
    const [showRowModalData, setShowRowModalData] = useState<any>(null);


    //Viewport height
    const [viewportHeight, setViewportHeight] = useState(window.innerHeight);
     // Add state to track screen width
     const [isSmallScreen, setIsSmallScreen] = useState(false);
    
     // Check for small screen on component mount and window resize
     useEffect(() => {
         const checkScreenSize = () => {
             setIsSmallScreen(window.innerWidth < 700);
         };
         
         // Initial check
         checkScreenSize();
         
         // Add event listener for window resize
         window.addEventListener('resize', checkScreenSize);
         
         // Clean up
         return () => window.removeEventListener('resize', checkScreenSize);
     }, []);

    useEffect(() => {
        setAdvancedStoredPagination(null)
        setStoredPagination(null)
        setCombineAdnvaceStoredpagination(null)
        setIsSearchComponentCall(false)
        const handleResize = () => {
            setViewportHeight(window.innerHeight);
        };

        // Add event listener for window resize
        window.addEventListener("resize", handleResize);

        // Cleanup event listener on component unmount
        return () => {
            window.removeEventListener("resize", handleResize);
        };
    }, []);

    //To display the initial data
    useEffect(() => {
        if (popupHeading === "Optimization errors" || popupHeading === "Audit Logs") {
            const newRowData = optimizationErrorsData.length > 0 ? optimizationErrorsData : initialData;
            setRowData(newRowData);
        }
        else {
            const newRowData = tabledata.length > 0 ? tabledata : initialData;
            setRowData(newRowData);
        }

    }, [initialData, tabledata, optimizationErrorsData]);

    useEffect(() => {
        setCurrentPage(1);
        setIsSearchComponentCall(false)
    }, [tabledata, optimizationErrorsData, sortConfig]);

    useEffect(() => {
        setCurrentPage(1);
    }, [totalPages]);

    useEffect(() => {
        let pagination_;

        if (popupHeading === "Optimization errors" || popupHeading === "Audit Logs") {
            pagination_ = optimizationErrorsPagination ? optimizationErrorsPagination : pagination
        }
        else {
            // let pagination_;
            if (combineAdnvaceStoredpagination) {
                pagination_ = combineAdnvaceStoredpagination
            }
            else if (advancedStoredpagination && !storedpagination) {
                pagination_ = advancedStoredpagination
            }
            else if (storedpagination && !advancedStoredpagination) {
                pagination_ = storedpagination
            }
            else {
                pagination_ = pagination
            }

        }
        console.log("pagination_", pagination_)
        // const pagination_ = pagination;
        const start = pagination_?.start || 1;
        const total = pagination_?.total || 1;
        const end = pagination_?.end || 1;
        const lastPageWithData_ = Math.floor(end / itemsPerPage);
        const totalPages_ = Math.ceil(total / itemsPerPage);
        const currentPage_ = Math.floor(start / itemsPerPage) + 1;
        setTotalPages(totalPages_);
        // setCurrentPage(currentPage_);
        // setLastPageWithData(lastPageWithData_);
    }, [tabledata, initialData, pagination, itemsPerPage, currentPage, storedpagination, advancedStoredpagination, optimizationErrorsPagination, combineAdnvaceStoredpagination, sortConfig]);

    //To manage the pagination routes

    const updatePaginator = async () => {
        let start_ = Math.floor((currentPage - 1) * itemsPerPage);
        let end_ = Math.floor((currentPage - 1) * itemsPerPage + 100);
        try {
            const colSortKey = sortConfig ? sortConfig.key : ""
            const colSortDirection = sortConfig ? sortConfig.direction : ""
            const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";
            // if (currentPage !== 1) {
            setLoading(true);
            // }
            if (popupHeading === "Inventory") {
                const url = ENV_ROUTES.SIM_MANAGEMENT;
                const data = {
                    tenant_name: partner || "default_value",
                    username: username,
                    firstLastName: firstLastName,
                    path: "/get_inventory_data",
                    role_name: role,
                    parent_module: "Sim Management",
                    module_name: "SimManagement Inventory",
                    feature_module_name: "Inventory",
                    mod_pages: {
                        start: start_,
                        end: end_,
                    },
                    request_received_at: getCurrentDateTime(),
                    Partner: partner,
                    access_token: token,
                    db_name: selectedDb,
                    ...metaData,
                    sessionID: sessionId,
                    ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
                        : {}),
                };

                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);
                if (parsedData.flag === false) {
                    Modal.error({
                        title: "Data Fetch Error",
                        content:
                            parsedData.message ||
                            "An error occurred while fetching Inventory data. Please try again.",
                        centered: true,
                    });
                } else {
                    const inventoryData =
                        parsedData?.inventory_data || [];
                    setRowData(inventoryData);
                    pagination = parsedData?.pages || pagination
                }
            }
            if (popupHeading === "Optimization errors") {
                const url = ENV_ROUTES.OPTIMIZATION
                const data = {
                    tenant_name: partner || "default_value",
                    username: username,
                    firstLastName: firstLastName,
                    path: "/get_optimization_row_details",
                    role_name: role,
                    parent_module: "Optimization",
                    module_name: "Optimization",
                    feature_module_name: "Optimization",
                    optimization_type: optimizationType,
                    request_received_at: getCurrentDateTime(),
                    Partner: partner,
                    access_token: token,
                    db_name: selectedDb,
                    ...metaData,
                    sessionID: sessionId,
                    session_id: optimizationRow?.session_id || '',
                    start: start_,
                    end: end_,
                    fetch_type: "error_details",
                    ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
                        : {}),
                };

                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);
                if (parsedData.flag === false) {
                    Modal.error({
                        title: 'Data Fetch Error',
                        content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                        centered: true,
                    });
                } else {
                    const tableData = parsedData?.error_details || []
                    setRowData(tableData);
                    pagination = parsedData?.pages || pagination
                }
            }
            if (popupHeading === "Audit Logs") {
                    try {
                      const url = ENV_ROUTES.TENANT_ONBOARDING;
                      const data = {
                        tenant_name: partner || "default_value",
                        username: username,
                        firstLastName: firstLastName,
                        path: "/get_tenant_banners_list_view_data",
                        role_name: role,
                        parent_module: "Super Admin",
                        module_name: "Deployment Notifier",
                        sub_module: "Tenant Based Banners logs",
                        mod_pages: {
                          start: start_,
                          end: Math.floor((currentPage - 1) * itemsPerPage + 75),
                        },
                        limit: 75,
                        request_received_at: getCurrentDateTime(),
                        Partner: partner,
                        access_token: token,
                        db_name: selectedDb,
                        ...metaData,
                        sessionID: sessionId,
                        ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
                          : {}),
                      };
                      const response = await axios.post(url, { data });
                      const parsedData = JSON.parse(response.data.body);
                      if (parsedData.flag === false) {
                        Modal.error({
                          title: "Data Fetch Error",
                          content:
                            parsedData.message ||
                            "An error occurred while fetching data. Please try again.",
                          centered: true,
                        });
                      } else {
                        const tableData_ = parsedData?.data || [];
                        setRowData(tableData_);
                      }
                    } catch (err) {
                      console.error("Error fetching data:", err);
                      Modal.error({
                        title: "Data Fetch Error",
                        content:
                          err instanceof Error
                            ? err.message
                            : "An unexpected error occurred while fetching data. Please try again.",
                        centered: true,
                      });
                    } finally {
                      // setLoading(false);
                    }
                  }
        } catch (err) {
            console.error("Error fetching data:", err);
        } finally {
            setLoading(false);
        }
        // }
    };
    const updateSearchPaginator = async () => {
        let start_ = Math.floor((currentPage - 1) * itemsPerPage);
        let end_ = Math.floor((currentPage - 1) * itemsPerPage + 100);
        const colSortKey = sortConfig ? sortConfig.key : ""
        const colSortDirection = sortConfig ? sortConfig.direction : ""
        const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";
        try {
            setLoading(true);
            const url = ENV_ROUTES.OPEN_SEARCH;
            let data = { ...searchData, username: username, }
            data.data.pages = {
                start: start_,
                end: end_,
            }
            data.data.col_sort = { [colSortKey]: colSortValue }
            const response = await axios.post(url, data);
            const parsedData = JSON.parse(response.data.body);
            console.log("parsed", parsedData);
            if (parsedData?.flag) {
                const tableData = parsedData?.data?.table || [];
                const pagination_ = parsedData?.pages || {};
                if (popupHeading === "Optimization errors" || popupHeading === "Audit Logs") {
                    setRowData(tableData)
                    setOptimizationErrorsPagination(pagination_)
                }
                else {
                    setRowData(tableData);
                    setStoredPagination(pagination_);
                }

                setAdvancedStoredPagination(null)
                setCombineAdnvaceStoredpagination(null)
                if (tableData.length === 0) {
                    Modal.error({
                        title: "No Records found",
                    });
                }
            } else {
                Modal.error({
                    title: "Search error",
                    content:
                        parsedData.error ||
                        "An error occurred while searching. Please try again.",
                });
            }
            console.log(response);
        } catch (error) {
            console.log(error);
        } finally {
            setLoading(false); // Stop loader
        }
    }
    const updateAdvancedSearchPaginator = async () => {
        let start_ = Math.floor((currentPage - 1) * itemsPerPage);
        let end_ = Math.floor((currentPage - 1) * itemsPerPage + 100);
        const colSortKey = sortConfig ? sortConfig.key : ""
        const colSortDirection = sortConfig ? sortConfig.direction : ""
        const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";
        try {
            setLoading(true);
            const url = ENV_ROUTES.OPEN_SEARCH;
            let data = { ...advancedSearchData, username: username, }
            data.data.pages = {
                start: start_,
                end: end_,
            }
            data.data.col_sort = { [colSortKey]: colSortValue }
            const response = await axios.post(url, data);
            const parsedData = JSON.parse(response.data.body);
            console.log("parsed", parsedData);
            if (parsedData?.flag) {
                const tableData = parsedData?.data?.table;
                setRowData(tableData);
                const pagination_ = parsedData?.pages || {}
                setStoredPagination(null)
                setAdvancedStoredPagination(pagination_)
                setCombineAdnvaceStoredpagination(null)
                if (tableData.length === 0) {
                    Modal.error({
                        title: "No Records found",
                    });
                }
            } else {
                Modal.error({
                    title: "Search error",
                    content:
                        parsedData.error ||
                        "An error occurred while searching. Please try again.",
                });
            }
            console.log(response);
        } catch (error) {
            console.log(error);
        } finally {
            setLoading(false); // Stop loader
        }
    }
    const updateCombinedSearchPaginator = async () => {
        const colSortKey = sortConfig ? sortConfig.key : ""
        const colSortDirection = sortConfig ? sortConfig.direction : ""
        const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";
        let start_ = Math.floor((currentPage - 1) * itemsPerPage);
        let end_ = Math.floor((currentPage - 1) * itemsPerPage + 100);
        try {
            setLoading(true);
            const url = ENV_ROUTES.OPEN_SEARCH;
            let data = { ...combineAdnvaceSearchData, username: username, }
            data.data.pages = {
                start: start_,
                end: end_,
            }
            data.data.col_sort = { [colSortKey]: colSortValue }
            const response = await axios.post(url, data);
            const parsedData = JSON.parse(response.data.body);
            console.log("parsed", parsedData);
            if (parsedData?.flag) {
                const tableData = parsedData?.data?.table;
                setRowData(tableData);
                const pagination_ = parsedData?.pages || {}
                setStoredPagination(null)
                setAdvancedStoredPagination(null)
                setCombineAdnvaceStoredpagination(pagination_)
                if (tableData.length === 0) {
                    Modal.error({
                        title: "No Records found",
                    });
                }
            } else {
                Modal.error({
                    title: "Search error",
                    content:
                        parsedData.error ||
                        "An error occurred while searching. Please try again.",
                });
            }
            console.log(response);
        } catch (error) {
            console.log(error);
        } finally {
            setLoading(false); // Stop loader
        }
    }

    useEffect(() => {
        if (!isFirstRender.current) {
            if (combineAdnvaceStoredpagination) {
                updateCombinedSearchPaginator()
            }
            else if (storedpagination && !advancedStoredpagination) {
                updateSearchPaginator()
            }
            else if (advancedStoredpagination && !storedpagination) {
                updateAdvancedSearchPaginator()
            }
            else {
                updatePaginator();
            }

        } else { isFirstRender.current = false }
    }, [currentPage, sortConfig]);

    useEffect(() => {
        if (!isFirstTableDataRender.current && !isSearchComponentCall) {

            if (tabledata !== rowData && currentPage === 1) {
                if (combineAdnvaceStoredpagination) {
                    updateCombinedSearchPaginator()
                }
                else if (storedpagination && !advancedStoredpagination) {
                    updateSearchPaginator()
                }
                else if (advancedStoredpagination && !storedpagination) {
                    updateAdvancedSearchPaginator()
                }
                else {
                    updatePaginator();
                }
            }

        } else { isFirstTableDataRender.current = false }
    }, [tabledata]);

    useEffect(() => {
        // console.log("searchQuery",searchQuery)
        if (!isFirstSearchRender.current) {
            if (searchQuery === "") {
                console.log("searchQuery", isFirstRender)
                if (storedpagination) {
                    updateSearchPaginator()
                }
                else if (advancedStoredpagination) {
                    updateAdvancedSearchPaginator()
                }
                else {
                    updatePaginator();
                }
            }
        } else { isFirstSearchRender.current = false }
    }, [searchQuery]);

    useEffect(() => {
        // console.log("advancedFilters",advancedFilters)
        if (!isFirstAdvancedSearchRender.current) {
            if (advancedFilters) {
                const allEmpty = Object.values(advancedFilters).every(
                    (value) => Array.isArray(value) && value.length === 0
                );

                if (allEmpty) {
                    console.log("advancedFilters", advancedFilters)
                    if (storedpagination) {
                        updateSearchPaginator()
                    }
                    else if (advancedStoredpagination) {
                        updateAdvancedSearchPaginator()
                    }
                    else {
                        updatePaginator();
                    }
                }
            }
        } else { isFirstAdvancedSearchRender.current = false }

    }, [advancedFilters]);
    //For sorting the table
    const handleSort = (key: string) => {
        let direction: "ascending" | "descending" = "ascending";
        if (
            sortConfig &&
            sortConfig.key === key &&
            sortConfig.direction === "ascending"
        ) {
            direction = "descending";
        }

        // const sortedData = [...rowData].sort((a, b) => {
        //     let aValue = a[key];
        //     let bValue = b[key];

        //     // Special handling for the "Assigned rate plans" or "Assigned rate plan count" columns
        //     if (key === "carrier_rate_plans") {
        //         aValue = Array.isArray(aValue) ? aValue.length : JSON.parse(aValue)?.length || 0;
        //         bValue = Array.isArray(bValue) ? bValue.length : JSON.parse(bValue)?.length || 0;
        //     }

        //     // Convert 'None' to null for easier comparison
        //     const normalizeValue = (value: any) => {
        //         if (value === 'None') return null;
        //         return value;
        //     };

        //     aValue = normalizeValue(aValue);
        //     bValue = normalizeValue(bValue);

        //     // Function to split a string into alphabetical and numeric segments
        //     const splitIntoSegments = (str: string) => {
        //         return str.toLowerCase().match(/([a-z]+|\d+)/g) || [];
        //     };

        //     // Split values into segments
        //     const aSegments = typeof aValue === "string" ? splitIntoSegments(aValue) : [aValue];
        //     const bSegments = typeof bValue === "string" ? splitIntoSegments(bValue) : [bValue];

        //     // Compare each segment one by one
        //     for (let i = 0; i < Math.max(aSegments.length, bSegments.length); i++) {
        //         const aSegment = aSegments[i];
        //         const bSegment = bSegments[i];

        //         // If one segment is undefined, consider it smaller
        //         if (aSegment === undefined) return direction === "ascending" ? -1 : 1;
        //         if (bSegment === undefined) return direction === "ascending" ? 1 : -1;

        //         // Compare numeric segments numerically, and character segments lexicographically
        //         const isANumber = !isNaN(Number(aSegment));
        //         const isBNumber = !isNaN(Number(bSegment));

        //         if (isANumber && isBNumber) {
        //             // Both segments are numbers; compare them numerically
        //             const numA = Number(aSegment);
        //             const numB = Number(bSegment);
        //             if (numA < numB) return direction === "ascending" ? -1 : 1;
        //             if (numA > numB) return direction === "ascending" ? 1 : -1;
        //         } else {
        //             // At least one segment is not a number; compare them as strings
        //             if (aSegment < bSegment) return direction === "ascending" ? -1 : 1;
        //             if (aSegment > bSegment) return direction === "ascending" ? 1 : -1;
        //         }
        //     }

        //     return 0;
        // });
        setCurrentPage(1)
        setSortConfig({ key, direction });
        // setRowData(sortedData);
    };

    const openAssignRatePlan = (rowIndex: number) => {
        setAssignRatePlanOpen(true)
        setAssignRatePlanRowIndex(rowIndex)
    }

    //For closing all the modals

    const closeModal = () => {
        setAssignRatePlanOpen(false)
        setAssignRatePlanRowIndex(null)
    }

    const ERROR_MESSAGES = [
        "There is an error in Processing Customer Rate Plans",
        "No Comm Groups and/or Rate Plans for this Instance",
        "No Rate Plans for this Instance",
        "One or more Rate Plans have invalid Data per Overage Charge or Overage Rate",
        "Optimization Groups and", // Partial check for count message
        "Rate Plans is not enough to run optimization Instance id"
    ];

    const renderAssignRatePlanBtn = (rowIndex: number) => {
        const errorMessage = rowData[rowIndex]?.["error_message"];
        console.log("errorMessage", errorMessage)
        const shouldShowButton = ERROR_MESSAGES.some((msg) =>
            errorMessage?.includes(msg)
        );
        console.log("shouldShowButton", shouldShowButton)

        if (shouldShowButton) {
            return (
                <button
                    className='save-btn'
                    onClick={() => openAssignRatePlan(rowIndex)}
                >
                    <span>Assign rate plan</span>
                </button>
            );
        } else {
            return null; // Do not render anything
        }
    };

    const renderCustomStatus = (cellData: any) => {
        const value=cellData && typeof cellData === 'string' ?cellData.toLowerCase() :cellData || "" 
       if(value === "active"){
        return <span className="text-green-500">{cellData}</span>
       }
       else if (value === "inactive"){
        return <span className="text-red-500">{cellData}</span>
       }
       else{
        return <span>{cellData}</span>
       }
    };

    //For custom cell rendering
    const renderCell = (cellData: any, column: string, rowIndex: number) => {
        if (moduleFeatures.includes("Edit user-Inventory") && (headerMap &&
            headerMap?.[column]?.[0] === "Username" ||
            column === "Username")) {
            return <EditUsernameCellRenderer rowData={rowData[rowIndex]} />
        }
        if (headerMap &&
            headerMap?.[column]?.[0] === "SIM Status") {
            return <StatusCellRenderer
                record={rowData[rowIndex]}
                value={cellData || 'None'}
                index={rowIndex}
                colorMap={colorMap}
            />
        }
        if (popupHeading === "Optimization errors" &&
            column === "action") {
            return renderAssignRatePlanBtn(rowIndex)

        }
        if (moduleFeatures.includes("Action history-Inventory") &&
            (headerMap?.[column]?.[0] === "Action History" || column === "Action History")) {
            return <StatusHistoryCellRenderer row={rowData[rowIndex]} />
        }
        // if (["Provider", "Service Provider"].includes(
        //     headerMap?.[column]?.[0]
        // ) ||
        //     column === "service_provider") {
        //     return <ServiceProviderCellRenderer value={cellData} index={rowData[rowIndex].id} />
        // }
        if (column === "Status" ||
            (headerMap && headerMap?.[column]?.[0] === "Status")) {
                return renderCustomStatus(cellData)
        }
        return (
            <Tooltip
                title={`${cellData}`}
                placement="topLeft"
                overlayStyle={{ whiteSpace: 'normal', maxWidth: '60vw', wordWrap: 'break-word', zIndex: 50 }}
                // getPopupContainer={(triggerNode) => (triggerNode.parentNode as HTMLElement) || document.body} // Fallback to document.body
                getPopupContainer={() => document.body} // Render tooltip directly on the body to avoid stacking issues
            >
                <span>{cellData}</span>
            </Tooltip>
        ); cellData;
    };

    if (loading) {
        return (
            <div className="flex justify-center items-center h-screen">
                <Spin size="large" />
            </div>
        );
    }

     // Pagination component to be used in both places
     const paginationComponent = (
        <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
            moduleName={popupHeading}
        />
    );

    return (
        <div>
            {/* Show pagination at top right for small screens */}
            {isSmallScreen && visibleColumns.length > 0 && (
                <div className="flex justify-end mb-2 mr-2">
                    {paginationComponent}
                </div>
            )}

            <div className="overflow-x-auto">
                <div
                    className="overflow-y-auto"
                    style={{
                        height: popupHeading === "Optimization errors"
                            ? 'auto'
                            : popupHeading === "Audit Logs"
                                ? '500px'
                                : `${viewportHeight - height}px`
                    }}
                >
                    <table className="table-auto w-full">
                        <thead className="sticky top-0 bg-gray-200 z-10 table-header-row">
                            <tr>
                                {/* Removed S.No UAT FIX
                                 {visibleColumns.length > 0 && (
                                    <th className="px-6 border-b border-gray-300 text-left font-semibold">
                                        S.No
                                    </th>
                                )} */}
                                {(typeof window !== "undefined" && window.innerWidth < 700) && (
                                    <th
                                        className={`px-6 py-3 border-b border-gray-300 text-left font-semibold table-header sticky top-0 freeze-header`}
                                        style={{
                                            cursor: "pointer", position: "sticky", left: 0, zIndex: 11, backgroundColor: "#E5E7EB" , minWidth:"40px"
                                        }}>

                                    </th>
                                )}

                                {headers.map((header) => (
                                    headerMap && headerMap[header] && visibleColumns.includes(header) && (
                                        <th
                                            key={header}
                                            className={`px-6 py-3 border-b border-gray-300 text-left font-semibold table-header sticky top-0 ${sortConfig && sortConfig.key === header ? "text-blue-600  active-table-header" : ""
                                                } ${(popupHeading === "Inventory" && header === "iccid")?'freeze-header':''}`}
                                            style={{
                                                cursor: "pointer",
                                                ...(popupHeading === "Inventory" && header === "iccid"
                                                    ? { position: "sticky", left: (typeof window !== "undefined" && window.innerWidth < 700) ? "40px" : 0, zIndex: 11 }
                                                    : {})
                                            }}
                                            onClick={() => {
                                                handleSort(header);
                                            }}
                                        // style={{ cursor: "pointer" }}
                                        >
                                            {headerMap?.[header]?.[0] || header}

                                            {
                                                sortConfig && sortConfig.key === header ? (
                                                    sortConfig.direction === "ascending" ? (
                                                        <ArrowUpOutlined className="sorting-arrow"  style={{ marginLeft: 8, color: "#2563EB" }} />
                                                    ) : (
                                                        <ArrowDownOutlined className="sorting-arrow"  style={{ marginLeft: 8, color: "#2563EB" }} />
                                                    )
                                                ) : (
                                                    <ArrowUpOutlined style={{ marginLeft: 8, opacity: 0.5 }} />
                                                )
                                            }
                                        </th>
                                    )
                                ))}
                                {allowedActions && visibleColumns.length > 0 && (
                                    <th className="px-6 border-b border-gray-300 text-left font-semibold table-header">
                                        Actions
                                    </th>
                                )}

                            </tr>
                        </thead>
                        <tbody>
                            {visibleColumns.length > 0 ? (
                                rowData.length > 0 ? (
                                    rowData.map((row, index) => (
                                        <tr
                                            key={index}
                                            className={index % 2 === 0 ? "bg-gray-50 even-table-row" : ""}
                                        >

                                            {/*  Removed S.No UAT FIX
                                    {visibleColumns.length > 0 && (
                                        <td className="px-6 border-b border-gray-300 table-cell">
                                            {(currentPage - 1) * itemsPerPage + index + 1}
                                        </td>
                                    )} */}
                                            {(typeof window !== "undefined" && window.innerWidth < 700) && (
                                                <td
                                                    className={`border-b border-gray-300 table-cell ${index % 2 === 0 ? "even-freeze-cell" : "freeze-cell"}`}
                                                    style={
                                                        { position: "sticky", left: 0, backgroundColor: "white", zIndex: 5 }
                                                    }>
                                                    <Radio
                                                        checked={true}
                                                        onClick={() => {
                                                            setShowRowModal(true);
                                                            setShowRowModalData(row);
                                                        }}
                                                        className="custom-gray-radio"
                                                    />
                                                </td>
                                            )}

                                            {headers.map((header, columnIndex) =>
                                                visibleColumns.includes(header) && headerMap[header] && (
                                                    <td
                                                        key={columnIndex}
                                                        className={`border-b border-gray-300 table-cell ${(popupHeading === "Inventory" && header === "iccid") ?index % 2 === 0 ? "even-freeze-cell" :"freeze-cell" : ""}`}
                                                        style={
                                                            popupHeading === "Inventory" && header === "iccid"
                                                                ? { position: "sticky", left: (typeof window !== "undefined" && window.innerWidth < 700) ?  "40px" : 0, zIndex: 5 }
                                                                : {}
                                                        }>

                                                        {header && headerMap?.[header]?.[0] && renderCell(row[header], header, index) || ""}
                                                    </td>
                                                )
                                            )}
                                            {allowedActions && visibleColumns.length > 0 && (
                                                <td className="border-b border-gray-300 table-cell">
                                                    <div className="flex items-center space-x-2">
                                                        {allowedActions.includes("Actions") && (
                                                            <ActionItems
                                                                initialData={initialData}
                                                                currentPage={currentPage}
                                                                itemsPerPage={itemsPerPage}
                                                                index={index}
                                                                rowData={row}
                                                            />
                                                        )}
                                                    </div>
                                                </td>
                                            )}
                                        </tr>
                                    ))
                                ) : (
                                    <tr>
                                        <td
                                            colSpan={
                                                headers.filter((header) =>
                                                    visibleColumns.includes(header)
                                                ).length + 1
                                            }
                                            className="px-6 py-3 border-b border-gray-300 text-center text-gray-500"
                                        >
                                            No Records Found
                                        </td>
                                    </tr>
                                )
                            ) : null
                            }
                        </tbody>
                    </table>
                </div>
            </div>
           {/* Show pagination at bottom for larger screens */}
           {(!isSmallScreen && visibleColumns.length > 0) && (
                <div className="flex justify-center mt-5">
                    {paginationComponent}
                </div>
            )}
            {assignRatePlanOpen &&
                <AssignRatePlanModal
                    rowData={assignRatePlanRowIndex !== null
                        ? rowData[assignRatePlanRowIndex]
                        : null}
                    onClose={closeModal}
                    isOpen={assignRatePlanOpen}
                />
            }
            {showRowModal &&
                <RowDetailsModal
                    row={showRowModalData}
                    headerMap={headerMap}
                    onClose={() => {
                        setShowRowModal(false)
                        setShowRowModalData(null)
                    }}
                    isOpen={showRowModal}
                />
            }

        </div>
    );
};

export default InventoryTableComponent;
