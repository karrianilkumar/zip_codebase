import React, { useState } from "react";
import StatusLog from "@/app/sim_management/bulk_history/status_log";

const STATUS = {
  PROCESSED: "PROCESSED",
  ERROR: "ERROR",
  PENDING: "PENDING",
  Pending:"Pending",
  SUCCESSFUL:"Successful",
  PROCESSING: "PROCESSING",
  ACTIVE: "Active",
  INACTIVE: "Inactive",
  OPEN:"OPEN",
  FAILED:"Failed",
  Generated:"Generated",
  CLOSE:"CLOSE",
  Returned:"Returned",
  Voided:"Voided"

};

interface StatusIndicatorProps {
  status: (typeof STATUS)[keyof typeof STATUS];
  row: any;
  heading: string;
}

const StatusIndicator: React.FC<StatusIndicatorProps> = ({
  status,
  row,
  heading,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleClick = () => {
    if (heading === "Bulk Change History") {
      setIsModalOpen(true);
    }
  };

  let colorClass = "";
  switch (status) {
    case STATUS.PROCESSED:
      colorClass = "text-green-500";
      break;
    case STATUS.ACTIVE:
      colorClass = "text-green-500";
      break;
    case STATUS.SUCCESSFUL:
      colorClass = "text-green-500";
    break
    case STATUS.OPEN:
      colorClass = "text-green-500";
      break;
    case STATUS.ERROR:
      colorClass = "text-red-500";
      break;
    case STATUS.FAILED:
      colorClass = "text-red-500";
      break;
    case STATUS.INACTIVE:
      colorClass = "text-red-500";
      break;
    case STATUS.PENDING:
      colorClass = "text-yellow-500";
      break;
    case STATUS.PROCESSING:
      colorClass = "text-blue-500";
      break;
    case STATUS.Pending:
      colorClass = "text-yellow-500";
      break;
    case STATUS.Generated:
      colorClass = "text-green-500";
      break;
    case STATUS.CLOSE:
      colorClass = "text-red-500";
      break;
    case STATUS.Returned:
      colorClass = "text-green-500";
      break;
    case STATUS.Voided:
      colorClass = "text-green-500";
      break;
    default:
      colorClass = "text-gray-500";
  }

  return (
    <>
      <div
       onClick={heading === "Bulk Change History" ? handleClick : undefined}
       className={`rounded-md ${colorClass} ${
         heading === "Bulk Change History" ? "cursor-pointer" : ""
       }`}
      >
        {status}
      </div>
      {isModalOpen&& (
        <StatusLog
          row={row}
          isOpen={isModalOpen}
          onRequestClose={() => setIsModalOpen(false)}
        />
      )}
    </>
  );
};

export default StatusIndicator;
