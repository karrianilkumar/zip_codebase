import React from "react";

export enum STATUS_TYPE {
  UPLOAD = "upload",
  SUCCESSFUL = "successful",
  ERRORS = "errors",
}

interface CountCellProps {
  value: any;
}

const RatePlansCountCell: React.FC<CountCellProps> = ({ value }) => {
  const ratePlanList = () => {
    if (typeof value === "string") {
      let parsedPlans: any[];
      // Handle JSON string
      try {
        parsedPlans = JSON.parse(value);
        if (Array.isArray(parsedPlans)) {
          return parsedPlans;
        }
      } catch (err) {
        // If parsing fails, check for "{...}" pattern
        const match = value.match(/^\{(.+?)\}$/);
        if (match) {
          return [match[1]]; // Extract content inside {} and return as an array
        }
      }

      return [];
    }
    if (Array.isArray(value)) {
      return value;
    }
    return [];
  };
  const parsedList = ratePlanList();
  const displayValue =
    parsedList && parsedList !== null && parsedList.length>0 ? parsedList.length : "";

  return (
    <div>
      <span className="">{displayValue}</span>
    </div>
  );
};

export default RatePlansCountCell;
