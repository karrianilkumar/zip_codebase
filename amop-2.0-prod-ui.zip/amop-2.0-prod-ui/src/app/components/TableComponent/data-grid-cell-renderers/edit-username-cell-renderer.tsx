import { FC, useEffect, useState } from "react";
import { Button, Modal, Input, Spin, notification, Tooltip } from "antd";
import { EditFilled } from "@ant-design/icons";
import { useAuth } from '@/app/components/auth_context';
import axios from 'axios';
import { getCurrentDateTime } from "../../header_constants";
import { ENV_ROUTES } from "../../routes/route_constants";
import React from "react";

interface EditUsernameProps {
  rowData: any;
  onCancel: () => void;
  onUpdate: (updatedRow: any, event_type: string) => void;
  currentUserName: string;
  loader?: boolean;
}

const EditUsernameModal: FC<EditUsernameProps> = ({
  rowData,
  onCancel,
  onUpdate,
  currentUserName,
  loader
}) => {
  const [Firstname, setFirstname] = useState('');
const [Lastname, setLastname] = useState('');

useEffect(() => {
  if (currentUserName && currentUserName!=='None') {
    const nameParts = currentUserName.split(" ");
    setFirstname(nameParts[0]); // First word goes to Firstname
    setLastname(nameParts.slice(1).join(" ")); // Remaining words go to Lastname
  }
}, [currentUserName]);
  const [formData, setFormData] = useState<any>(rowData);
  const [loading, setLoading] = useState(false);

  const handleUpdate = () => {
    const combinedName = `${Firstname} ${Lastname}`.trim();
    const updatedFormData = { ...formData, username:combinedName };
    setFormData(updatedFormData);
    setLoading(true);
    onUpdate(updatedFormData, "Update Username");
    setLoading(false);
    onCancel();
  };

  if (loading) {
    return (
      <Modal
        title={
          <div>
            <span className="font-semibold text-xl">Edit username</span>
            <hr className="border-gray-300 mt-2 mb-8" />
          </div>
        }
        centered
        open={true}
        onCancel={onCancel}
        footer={null}
        style={{ height: '500px' }}
      >
        <div className="popup flex justify-center items-center w-full h-full">
          <Spin size="large" />
        </div>
      </Modal>
    );
  }

  return (
    <Modal
      title={
        <div>
          <span className="font-semibold text-xl">Edit Username</span>
          <hr className="border-gray-300 mt-2 mb-8" />
        </div>
      }
      centered
      open={true}
      onCancel={onCancel}
      footer={[
        <div className="flex justify-center space-x-2 mt-10" key="buttons">
          <button key="cancel" onClick={onCancel} className="cancel-btn h-[30px] text-base">
            Cancel
          </button>
          <button key="update" onClick={handleUpdate} className="save-btn text-base">
            Update
          </button>
        </div>,
      ]}
      style={{ height: '500px' }}
    >
      
      <div className="flex justify-center items-center mb-4">
        <span className="mr-4 w-[100px] font-semibold font-[18px]">First Name:</span>
        <Input
          className="text-base h-10"
          value={Firstname}
          onChange={(e) => setFirstname(e.target.value)}
          placeholder="Enter firstname"
        />
      </div>
      <div className="flex justify-center items-center mb-4">
        <span className="mr-4 w-[100px] font-semibold font-[18px]">Last Name:</span>
        <Input
          className="text-base h-10"
          value={Lastname}
          onChange={(e) => setLastname(e.target.value)}
          placeholder="Enter lastname"
        />
      </div>
    </Modal>
  );
};

const EditUsernameCellRenderer: FC<{ rowData: any }> = ({ rowData }) => {
  const [modalOpen, setModalOpen] = useState(false);
  const currentUserName = rowData?.username;
  const { username: partnerUser, partner, role, settabledata, token, selectedDb,metaData, firstLastName,sessionId} = useAuth();
  const originaldata = JSON.stringify(rowData);
  const [loading, setLoading] = useState(false);
  const messageStyle = {
    fontSize: '14px',
    fontWeight: 'bold',
    padding: '16px',
    // Add padding
  };
  const handleOpenModal = () => {
    setModalOpen(true);
  };

  const handleCloseModal = () => {
    setModalOpen(false);
  };

  const fetchData = async () => {
    try {
      setLoading(true);
      const url =ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: partnerUser,
        firstLastName: firstLastName,
        path: "/get_inventory_data",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "SimManagement Inventory",
        feature_module_name:"Inventory",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        setLoading(false);
        Modal.error({
          title: 'Data Update Error',
          content: parsedData.message || 'An error occurred while updating Inventory data. Please try again.',
          centered: true,
        });
      } else {
        const tableData_ = parsedData?.inventory_data || [];
        settabledata(tableData_);
        setLoading(false);
        if (parsedData.flag === true) {
          notification.success({
            message: 'Success',
            description: 'Updated successfully',
            style: messageStyle,
            placement: 'top',
          });
        }
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while updating data. Please try again.',
        centered: true,
      });
    }
  };

  const sendUpdatedData = async (updatedRow: any, event_type: any) => {
    let oldData = JSON.parse(originaldata)
    let data: any = {
      tenant_name: partner || "default_value",
      username: partnerUser,
      firstLastName: firstLastName,
      path: "/update_inventory_data",
      role_name: role,
      module_name: "SimManagement Inventory",
      feature_module_name:"Inventory",
      Partner: partner,
      access_token: token,
      db_name:selectedDb,
      ... metaData,
      sessionID: sessionId,
      table_name: "sim_management_inventory",
      old_data: oldData,
      change_event_type: event_type,
      template_name:"Inventory Username Update"
    };
    try {
      setLoading(true);
      const url =ENV_ROUTES.SIM_MANAGEMENT;
      data["changed_data"] = {
        id: rowData.id,
        username: updatedRow.username,
        modified_by: firstLastName
      };
      data["history"] = {
        service_provider: oldData.service_provider,
        sim_management_inventory_id: oldData.id,
        iccid: oldData.iccid,
        msisdn: oldData.msisdn,
        previous_value: oldData.username,
        current_value: updatedRow.username,
        date_of_change: getCurrentDateTime(),
        change_event_type: "Update Username",
        changed_by: firstLastName,
        tenant_name: partner || "default_value",
        customer_account_name: oldData?.customer_name || ""
      }
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        setLoading(false);
        Modal.error({
          title: 'Data Update Error',
          content: parsedData.message || 'An error occurred while updating Username. Please try again.',
          centered: true,
        });
      } else {
        fetchData();
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: 'Data Update Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while updating Username. Please try again.',
        centered: true,
      });
    }
  };

  const handleUpdateUsername = (updatedRow: any, event_type: string) => {
    sendUpdatedData(updatedRow, event_type);
    handleCloseModal();
  };

  return (
    <>
      {loading ? (
          <Modal
            title={
              <div>
                <span className="font-semibold  text-xl">Edit Username</span>
                <hr className="border-gray-300 mt-2 mb-8" />
              </div>
            }
            centered
            open={true}
            style={{ height: '500px' }}

            footer={null}
          >
            <div className="popup flex justify-center items-center w-full h-full">
              <Spin size="large" />
            </div>
          </Modal>

      ) : (
        <div className="flex items-center">
          <div className="flex-1 overflow-hidden">
          <a onClick={handleOpenModal} className="text-blue-500 cursor-pointer flex-1 overflow-hidden text-ellipsis whitespace-nowrap">
            {currentUserName!=="None"?currentUserName:""}
          </a>
          </div>
          <Tooltip title="Edit Username">
          <Button
            type="link"
            icon={<EditFilled />}
            onClick={handleOpenModal}
            className="mr-1"
          />
          </Tooltip>
          {modalOpen && (
            <EditUsernameModal
              rowData={rowData}
              currentUserName={currentUserName}
              onCancel={handleCloseModal}
              onUpdate={handleUpdateUsername}
              loader={loading}
            />
          )}
        </div>
      )}
    </>
  );
};

export function renderEditUsernameCell(rowData: any) {
  return <EditUsernameCellRenderer rowData={rowData} />;
}

export default EditUsernameCellRenderer;
