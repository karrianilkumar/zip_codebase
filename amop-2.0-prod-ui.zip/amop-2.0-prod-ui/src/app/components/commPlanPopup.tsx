"use client";
import React, { useEffect, useState } from "react";
import { Input, Button, Modal, Spin, message, notification } from "antd";
import Select from "react-select";
import { useAuth } from "./auth_context";
import { getCurrentDateTime } from "./header_constants";
import axios from "axios";
import { ENV_ROUTES } from "./routes/route_constants";
import { DropdownStyles } from "./css/dropdown";

interface CommPlanModalProps {
  isOpen: boolean;
  onClose: () => void;
  rowData: any;
  tableData?: any;
  generalFields: any;
  mode: "create" | "edit"; 
}

const messageStyle = {
  fontSize: '14px',
  fontWeight: 'bold',
  padding: '16px',
};

const CommPlanModal: React.FC<CommPlanModalProps> = ({
  isOpen,
  onClose,
  rowData,
  generalFields,mode
}) => {
  const [filteredRatePlans, setFilteredRatePlans] = useState<any[]>([]);
  const [communicationPlanName, setCommunicationPlanName] = useState("");
  const [aliasName, setAliasName] = useState("");
  const [serviceProviderName, setServiceProviderName] = useState("");
  const [selectedRatePlans, setSelectedRatePlans] = useState<any[]>([]);
  const [ratePlanCodeOptions, setRatePlanCodOptions] = useState<any[]>([]);
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);
  const [parsedData, setParsedData] = useState<any>(null);
  const [rateplanOptions, setRateplanOptions] = useState<any[]>([]);
  const ratePlansMap = generalFields?.carrier_rate_plan || [];
  const [loading, setLoading] = useState(false);
  const { username, tenantNames, role, partner, settabledata, token, selectedDb,metaData, firstLastName,sessionId} = useAuth();
  const [formData, setFormData] = useState<any>({});
  const [validationErrors, setValidationErrors] = useState<{
    communication_plan_name?: string;
    service_provider?: string;
  }>({});

useEffect(() => {
  if (isOpen) {
    if (mode === "edit" && rowData) {
      setCommunicationPlanName(rowData.communication_plan_name || "");
      setAliasName(rowData.alias_name || "");
      setServiceProviderName(rowData.service_provider_name || "");
      setFormData(rowData || {});
    } else if (mode === "create") {
      setCommunicationPlanName("");
      setAliasName("");
      setServiceProviderName("");
      setSelectedRatePlans([]);
      setFormData({});
    }
  }
}, [isOpen, mode, rowData]);
useEffect(() => {
  if (isOpen && mode === "edit" && rowData && rateplanOptions.length > 0) {
    let existingPlans: string[] = [];

    const rawPlans = rowData.carrier_rate_plans || "";

    try {
      if (rawPlans.startsWith("[")) {
        // JSON string array
        existingPlans = JSON.parse(rawPlans);
      } else if (rawPlans.startsWith("{") && rawPlans.endsWith("}")) {
        // Curly braces format
        existingPlans = rawPlans.replace(/[{}]/g, "").split(",").map((p:string) => p.trim());
      } else {
        // Comma separated string fallback
        existingPlans = rawPlans.split(",").map((p:string) => p.trim());
      }
    } catch (err) {
      console.error("Failed to parse carrier_rate_plans:", err);
    }


    const initialSelectedPlans = rateplanOptions.filter((option) => {
        // Direct match first
        if (existingPlans.includes(option.value)) {
          return true;
        }

        // Otherwise, check the code part after "--"
        const code = option.value.includes("--")
          ? option.value.split("--").pop()?.trim()
          : option.value.trim();

        return existingPlans.includes(code || "");
      });

    setSelectedRatePlans(initialSelectedPlans);
  }
}, [isOpen, mode, rowData, rateplanOptions]);




const carrierRatePlans = (() => {
  if (typeof rowData?.carrier_rate_plans === "string") {
    let parsedPlans: string[] = [];
    try {
      // remove { } and split by comma
      parsedPlans = rowData.carrier_rate_plans
        .replace(/[{}]/g, "") // remove { and }
        .split(",")           // split into array
        .map((plan:any) => plan.trim()) // remove extra spaces
        .filter((plan:any) => plan.length > 0); // clean empty values
    } catch (err) {
      console.log("Parse error:", err);
    }
    return parsedPlans;
  }

  if (Array.isArray(rowData?.carrier_rate_plans)) {
    return rowData.carrier_rate_plans;
  }

  return [];
})();


  const handleChange = (name: string, value: any) => {
    setFormData((prevState: any) => ({
      ...prevState,
      [name]: value,
    }));
  };
  const handleSelectChange = (name: string, value: any) => {
    setFormData((prevState: any) => ({
      ...prevState,
      [name]: JSON.stringify(value),
    }));
  };
  // Filter rate plans based on the selected service provider name
  useEffect(() => {
    if (serviceProviderName) {
      const filteredPlans = ratePlansMap.filter(
        (plan: any) => plan.service_provider === serviceProviderName
      );
      setFilteredRatePlans(
        filteredPlans.map((plan: any) => ({
          value: plan.rate_plan_code,
          label: plan.rate_plan_code,
        }))
      );
    }
  }, [serviceProviderName, ratePlansMap]);

  // Set initial selected rate plans
  useEffect(() => {
    const initialSelectedPlans = carrierRatePlans.map((plan: string) => ({
      value: plan,
      label: plan,
    }));
    // setSelectedRatePlans(initialSelectedPlans);
  }, [rowData]);

  const handleCancel = () => {
    onClose();
    setValidationErrors({});
  };

  useEffect(() => {
    const fetchData = async () => {
        setLoading(true);
      try {
        const url = ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/rate_plan_dropdown_data",
          service_provider: serviceProviderName,
          role_name: role,
          parent_module: "Sim Management",
          module_name: "Communication plans",
          feature_module_name: "Communication Plans",
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
        };
  
        const response = await axios.post(url, { data });
        const fetchedData = JSON.parse(response.data.body);
        console.log(fetchedData, "fetchedOptions");
        setParsedData(fetchedData);
  
        if (fetchedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content: fetchedData.message || "An error occurred while fetching Inventory data. Please try again.",
            centered: true,
            onOk: handleCancel,
          });
        } else {
          // const sortedOptions = Object.entries(fetchedData.carrier_rate_plans).reduce(
          //   (acc:any, [carrier, plans]) => {
          //     acc[carrier] = (plans as string[]).sort(); // Sort the array of plans for each carrier
          //     return acc;
          //   },
          //   {}
          // );
  
          // Carrier Rate Plans (names)
        const sortedOptions = fetchedData?.carrier_rate_plans || {};
        const filteredOptions: string[] = sortedOptions[serviceProviderName] || [];
        console.log("formattedOptions",sortedOptions[serviceProviderName])
        console.log("filteredOptions",filteredOptions)
        // Format plan names for dropdown
        const formattedOptions = Array.from(new Set(filteredOptions)).map((plan) => ({
          value: plan,
          label: plan,
        }));
        console.log("formattedOptions",formattedOptions)

        setRateplanOptions(formattedOptions);

        // Carrier Rate Plan Codes
        const ratePlanCodeOptions = fetchedData?.carrier_rate_plan_codes || {};
        const filteredCodeOptions: string[] = ratePlanCodeOptions[serviceProviderName] || [];
        setRatePlanCodOptions(filteredCodeOptions);

        // Map selected rate plan codes (carrierRatePlans) to their corresponding plan names
        const selectedRatePlanCodes: string[] = carrierRatePlans || [];

        // Match codes to plans based on index
        const selectedRatePlans = selectedRatePlanCodes.map((code, index) => {
          const plan = filteredOptions[index]; // align by index
          return {
            value: plan || code, // fallback to code if no plan found
            label: plan || code,
          };
        });

        setSelectedRatePlans(selectedRatePlans);


    console.log("selectedRatePlanCodes",selectedRatePlanCodes)
    console.log("selectedRatePlans",selectedRatePlans)
    console.log("initialSelectedPlans",selectedRatePlans)
    // console.log("selectedRatePlanCodes",selectedRatePlanCodes)

    setSelectedRatePlans(selectedRatePlans);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        Modal.error({
          title: "Data Fetch Error",
          content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
          centered: true,
          onOk: handleCancel,
        });
      } finally {
        setLoading(false);
      }
    };
  
    if (isOpen) {
      console.log(isOpen, "visible check")
      fetchData();
    }
  }, [isOpen]);

  useEffect(()=>{
    const sortedOptions = parsedData?.carrier_rate_plans || []
          // Filter the options based on the selected service provider
          const filteredOptions = sortedOptions[serviceProviderName] || [];
          const formattedOptions = filteredOptions.map((plan: string) => ({
            value: plan,
            label: plan,
          }));
  
          setRateplanOptions(formattedOptions);

          const rate_plan_code_options = parsedData?.carrier_rate_plan_codes || []
          // Filter the options based on the selected service provider
          const filteredCodeOptions = rate_plan_code_options[serviceProviderName] || [];
          setRatePlanCodOptions(filteredCodeOptions)

  },[serviceProviderName,parsedData])
  const handleSave = () => {
    onClose();
  };

  const showConfirmation = () => {
    if (!validateFields()) return;
    setIsConfirmationOpen(true);
  };
  const handleCancelConfirmation = () => {
    setIsConfirmationOpen(false);
  };
  const validateFields = () => {
  const errors: any = {};

  if (mode !== "edit") {
    if (!communicationPlanName.trim()) {
      errors.communication_plan_name = "Communication Plan Name is required";
    }
    if (!serviceProviderName.trim()) {
      errors.service_provider = "Service Provider Name is required";
    }
  }

  setValidationErrors(errors);
  return Object.keys(errors).length === 0; // return true if no errors
};

  const handleConfirmEdit = async () => {
    setIsConfirmationOpen(false);
    formData["alias_name"] = aliasName;
    if(mode !== "edit"){
      formData["communication_plan_name"] = communicationPlanName;
      formData["service_provider_name"] = serviceProviderName;
    }
    const valuesList = selectedRatePlans.map((plan) => plan.value);
    // Get matching rate plan codes using the same indexes
  const selectedRatePlanCodes = valuesList.map((_, index) => ratePlanCodeOptions[index]);
  formData["carrier_rate_plans"] = valuesList;
    // formData["carrier_rate_plans"] = valuesList;
    formData["modified_by"] = firstLastName;
    formData["is_active"] = "True";
    delete formData["carrier_rate_plans__1"];
    delete formData["modified_date"];

    try {
      setLoading(true);
      const url =ENV_ROUTES.SIM_MANAGEMENT
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/update_sim_management_modules_data",
        role_name: role,
        parent_module: "Sim Management",
        module: "Communication plans",
        table_name: "sim_management_communication_plan",
        action: mode === "edit" ? "update" : "create",
        [mode === "edit" ? "changed_data" : "new_data"]: formData,        
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        setLoading(false);
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      } else {
        try {
          const url =ENV_ROUTES.MODULE_MANAGEMENT;
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/get_module_data",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "Communication plans",
            feature_module_name:"Communication Plans",
            mod_pages: {
              start: 0,
              end: 100,
            },
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };

          const response = await axios.post(url, { data });

          if (parsedData.flag === false) {
            setLoading(false);

            Modal.error({
              title: "Data Fetch Error",
              content:
                parsedData.message ||
                "An error occurred while fetching data. Please try again.",
              centered: true,
            });
          } else {
            const parsedData = JSON.parse(response.data.body);
            const tableData_ =
              parsedData?.data?.sim_management_communication_plan || [];
            settabledata(tableData_);
            setLoading(false);
            const message = mode === "edit" ? "Successfully edited the record!" : "Successfully created the record!";
            notification.success({
              message: "Success",
              description: message,
              style: messageStyle,
              placement: "top",
            });
          }
        } catch (error) {
          setLoading(false);

          console.error("Error fetching data:", error);
          Modal.error({
            title: "Data Fetch Error",
            content:
              error instanceof Error
                ? error.message
                : "An unexpected error occurred while fetching data. Please try again.",
            centered: true,
          });
        } finally {
          setLoading(false);
        }
        setLoading(false);
      }
    } catch (error) {
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    }
    handleSave();
  };
  const modalWidth =
    typeof window !== "undefined" ? (window.innerWidth * 2.5) / 4 : 0;
  const modalHeight =
    typeof window !== "undefined" ? (window.innerHeight * 2) / 4 : 0;
  return (
    <div>
      <Modal
        visible={isOpen}
        onCancel={handleCancel}
        width={700}
        height = {500}
        centered
        style={{ 
          top: 55,
        }}
        title={
          <h3 className="popup-heading text-lg md:text-xl font-semibold">
            {mode === "edit" ? "Update Communication Plan" : "Create Communication Plan"}
          </h3>
        }
        footer={
          <div className="flex justify-center space-x-2 mt-4 md:mt-6">
            <button 
              onClick={handleCancel} 
              className="cancel-btn px-3 py-1 md:px-4 md:py-2 text-sm md:text-base"
            >
              Cancel
            </button>
            <button 
              onClick={showConfirmation} 
              className="save-btn px-3 py-1 md:px-4 md:py-2 text-sm md:text-base"
            >
              {mode === "edit" ? "Update" : "Create"}
            </button>
          </div>
        }
        
      >
        {!loading ? (
          <div className="px-2 py-1 md:px-4">
            <div className="grid grid-cols-2 gap-4">
              
             <div className="flex flex-col mb-2">
            <label className="field-label text-sm sm:text-base">
              Communication Plan Name <span className="text-red-500">*</span>
            </label>
            <Input
              disabled={mode === "edit"}
              className={`${mode === "edit" ? "non-editable-input" : "input"} w-full text-sm md:text-base`}
              placeholder="Enter Communication Plan Name"
              value={communicationPlanName}
              onChange={(e) => setCommunicationPlanName(e.target.value)}
            />
              {validationErrors["communication_plan_name"] && (
                <span className="text-red-500 text-xs sm:text-sm mt-1">
                  {validationErrors["communication_plan_name"]}
                </span>
              )}
          </div>
              <div className="flex flex-col mb-2">
              <label className="field-label text-sm sm:text-base">
                Service Provider Name<span className="text-red-500">*</span>
              </label>

              {mode === "edit" ? (
                <Input
                  className="non-editable-input w-full text-sm md:text-base"
                  disabled
                  placeholder="Enter Service Provider Name"
                  value={serviceProviderName}
                  onChange={(e) => setServiceProviderName(e.target.value)}
                />
              ) : (
                <Select
                  className="w-full"
                  styles={DropdownStyles}
                  placeholder="Select Service Provider"
                 value={serviceProviderName ? { value: serviceProviderName, label: serviceProviderName } : null}
                  onChange={(option) => {setServiceProviderName(option?.value || "");
                    setSelectedRatePlans([]);}
                  }
                     options={generalFields?.serviceprovider?.map(
                      (sp: { id: string; service_provider_name: string }) => ({
                        value: sp.service_provider_name,
                        label: sp.service_provider_name,
                      })
                    )}
                />
              )}
               {validationErrors["service_provider"] && (
                          <span className="text-red-500 text-xs sm:text-sm mt-1">
                            {validationErrors["service_provider"]}
                          </span>
                        )}
            </div>
            <div className="flex flex-col mb-2">
              <label className="field-label text-sm sm:text-base">Alias Name</label>
                <Input
                  className="input w-full text-sm md:text-base"
                  placeholder="Enter Alias Name"
                  value={ (aliasName && aliasName!=="None") ? aliasName : "" }
                  onChange={(e) => setAliasName(e.target.value)}
                />
              </div>


              <div className="flex flex-col mb-2">
                <label className="field-label text-sm sm:text-base">Rate Plans</label>
                <Select
                  isMulti
                  options={rateplanOptions}
                  value={selectedRatePlans}
                  onChange={(selectedOptions: any) =>
                    setSelectedRatePlans(selectedOptions)
                  }
                  styles={DropdownStyles}
                  className="rate-plans-select w-full"
                 
                />
              </div>
            </div>
          </div>
        ) : (
          <div className="flex justify-center items-center w-full py-12">
            <Spin size={window.innerWidth <= 576 ? "default" : "large"} />
          </div>
        )}
      </Modal>
      <Modal
        title="Confirmation"
        open={isConfirmationOpen}
        onOk={handleConfirmEdit}
        onCancel={handleCancelConfirmation}
        centered
      >
        <p>Are you sure you want to {mode === "edit"? "Update" : "Create"} this Communication Plan</p>
      </Modal>
    </div>
  );
};

export default CommPlanModal;
