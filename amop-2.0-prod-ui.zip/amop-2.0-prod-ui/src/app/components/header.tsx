"use client";
import React, { useRef, useState, useEffect, useCallback } from "react";
import {
  EnvelopeIcon,
  QuestionMarkCircleIcon,
  Bars3Icon,
  UserIcon,
  ChevronDownIcon,
} from "@heroicons/react/24/outline";
import Image from "next/image";
import {
  LogoutOutlined,
  SettingOutlined,
  DownOutlined,
  KeyOutlined,
} from "@ant-design/icons";
import { useSidebarStore } from "../stores/navBarStore";
import { useLogoStore } from "../stores/logoStore";
import { useAuth } from "./auth_context";
import { usePathname, useRouter } from "next/navigation";
import { getCurrentDateTime } from "./header_constants";
import axios from "axios";
import { Modal, Spin, Tooltip } from "antd";
import { ENV_ROUTES } from "./routes/route_constants";
import { moduleIconMap } from "../constants/moduleiconmap";
import { useCustomerProfileStore } from "../billing/killbill_stores/customer_profile_store";
import ThemeSelector from "./ThemeSelector";

interface NavItem {
  label: string;
  icon?: React.ReactNode;
  href?: string;
  subNav?: NavItem[];
}
const renderIcon = (iconClass: string | undefined) => {
  if (!iconClass) return null;
  return <i className={`${iconClass} w-4 h-4`}></i>; // Render the Flat Icon using the class
};

type IconKey = keyof typeof moduleIconMap;

const encodePathComponent = (component: string): string => {
  return encodeURIComponent(component?.toLowerCase().replace(/[\s/.]/g, "_") || "");
};
const generateNavItems = (modules: any[]): NavItem[] => {
  return modules.map((module) => {
    const { parent_module_name, children } = module;
    const iconClass = moduleIconMap[parent_module_name as IconKey];
    const subNav =
      children.length > 0
        ? children.map((child: any) => {
          const childIconClass = moduleIconMap[child.child_module_name as IconKey];
          const childHref = `/${encodePathComponent(
            parent_module_name
          )}/${encodePathComponent(child.child_module_name)}`;

          return {
            icon: renderIcon(childIconClass),
            href: child.child_module_name ? childHref : undefined,
            label: child.child_module_name,
            subNav: child.sub_children?.map((subChild: any) => {
              const subChildIconClass = moduleIconMap[subChild.sub_child_module_name as IconKey];
              const subChildHref = `/${encodePathComponent(
                parent_module_name
              )}/${encodePathComponent(
                child.child_module_name
              )}/${encodePathComponent(subChild.sub_child_module_name)}`;
              return {
                icon: renderIcon(subChildIconClass),
                href: subChildHref,
                label: subChild.sub_child_module_name,
              };
            }),
          };
        })
        : [];

    const href =
      children.length === 0
        ? `/${encodePathComponent(parent_module_name)}`
        : undefined;

    return {
      label: parent_module_name,
      icon: renderIcon(iconClass),
      href: href,
      subNav,
    };
  });
};  

const Header: React.FC = () => {
  const { username, partner, role, setShowPasswordUpdate, showPasswordUpdate, firstLastName, setSelectedPartner, dynamicColumns, setDynamicColumns, modules } =
    useAuth();
  // const { setIsExpanded ,isExpanded} = useSidebarStore();
  // const { logoUrl } = useLogoStore();
  const isExpanded = useSidebarStore((state) => state.isExpanded);
  const setIsExpanded = useSidebarStore((state) => state.setIsExpanded);
  const title = useLogoStore((state) => state.title);
  const setTitle = useLogoStore((state) => state.setTitle);
  const [showChooseTenant, setShowChooseTenant] = useState(false);
  const [showDefaultSettings, setShowDefaultSettings] = useState(false);
  const pathname = usePathname();
  const router = useRouter();
  const [showLogout, setShowLogout] = useState(false);
  const { logout, LogoutChooseTenant, selectedDb,metaData, selectedBillingDb,sessionId } = useAuth();
  const [isLoggingOut, setIsLoggingOut] = useState(false);
  const menuRef = useRef<HTMLDivElement | null>(null);
  const [networkAccessFee, setNetworkAccessFee] = useState('');
  const [costRecoveryFee, setCostRecoveryFee] = useState('');
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [errors, setErrors] = useState({ networkAccessFee: '', costRecoveryFee: '' });
  const [loading, setLoading] = useState(false);
  const currentPath = usePathname();
  const isActive = useCallback(
    (href?: string, subNav?: NavItem[]): boolean => {
      if (!href) return false;
      // Check if the current path starts with the href or any of its subNav links
      if (currentPath.startsWith(href)) {
        return true;
      }
      // Recursively check for nested subNav items
      if (subNav && subNav.length > 0) {
        return subNav.some((subItem) => isActive(subItem.href, subItem.subNav));
      }
      return false;
    },
    [currentPath]
  );
const {  userProfileDetails} = useCustomerProfileStore();

  useEffect(() => {
    const navItems = generateNavItems(modules);
    const findActiveLabel = (items: NavItem[]): string | undefined => {
      for (const item of items) {
        if (item.subNav) {
          for (const subItem of item.subNav) {
            if (subItem.subNav) {
              for (const subSubItem of subItem.subNav) {
                if (isActive(subSubItem.href, subSubItem.subNav)) {
                  return subSubItem.label;
                }
              }
            }
            if (isActive(subItem.href, subItem.subNav)) {
              return subItem.label;
            }
          }
        }
        if (isActive(item.href, item.subNav)) {
          return item.label;
        }
      }

      return undefined;
    };

    const activeLabel = findActiveLabel(navItems);
    // console.log("activeLabel", activeLabel)
    // console.log("currentPath", currentPath)
    localStorage.removeItem('accountNumber');
    if (activeLabel) {
      setTitle(activeLabel); // Set the title in the store based on active label
    }
  }, [currentPath, isActive, setTitle, modules]);
  // console.log("isexpanded", isExpanded)
  // console.log("userProfileDetails", userProfileDetails)
  const handleSaveClick = () => {
    // console.log("Save button clicked"); // Debugging line
    // console.log("Network Access Fee:", networkAccessFee); // Debugging line
    // console.log("Cost Recovery Fee:", costRecoveryFee); // Debugging line

    let newErrors = { networkAccessFee: "", costRecoveryFee: "" };

    // Ensure networkAccessFee is a string before calling trim
    if (typeof networkAccessFee === 'string' && !networkAccessFee.trim()) {
      newErrors.networkAccessFee = 'Network Access Fee is required.';
    }

    // Ensure costRecoveryFee is a string before calling trim
    if (typeof costRecoveryFee === 'string' && !costRecoveryFee.trim()) {
      newErrors.costRecoveryFee = 'Cost Recovery Fee is required.';
    }

    if (newErrors.networkAccessFee || newErrors.costRecoveryFee) {
      // console.log("Errrrrrrr");
      // console.log(newErrors, "Show errs.");
      setErrors(newErrors);
      return;
    }

    // If no errors, proceed with showing the confirmation modal
    setShowConfirmation(true);
    // console.log("Proceed to confirmation");
  };
  const handleClick = () => {
    setShowLogout(!showLogout);
  };

  const handleClickOutside = (event: MouseEvent) => {
    if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
      setShowLogout(false);
    }
  };

  const handleLogout = async () => {
    setIsLoggingOut(true);
    const pathname = window.location.pathname;
    // const url = `/auth/logout?redirect=${pathname}&action=logout`;
    // window.location.href = url;
    const data = {
      path: "/logout",
      username: username,
      firstLastName: firstLastName,
      Partner: partner,
      request_received_at: getCurrentDateTime(),
      dynamic_cols: dynamicColumns
    };
    try {
      localStorage.clear(); // Clear session data
      const url = ENV_ROUTES.USER_AUTHENTICATION;
      const response = await axios.post(url, { data: data }, {
        headers: {
          'Content-Type': 'application/json',
        },
      });
      if (response.data.statusCode === 200) {
        localStorage.clear()
      }
      else {
        Modal.error({
          title: 'Login Error',
          content: 'An unexpected error occurred during login. Please try again.',
          centered: true,
        });
      }
    } catch (error) {
      console.error('Error during login:', error);
      if (error instanceof Error) {
        Modal.error({
          title: 'Login Error',
          content: error.message || 'An unexpected error occurred during login. Please try again.',
          centered: true,
        });
      } else {
        Modal.error({
          title: 'Login Error',
          content: 'An unexpected error occurred during login. Please try again.',
          centered: true,
        });
      }
    } finally {
      setIsLoggingOut(false);
    }
    logout();
  };

  const handleChoosePartner = () => {
    setSelectedPartner(false)
    localStorage.removeItem('tenant_name'); // Remove only 'tenant_name' key
    setShowPasswordUpdate(false);
    LogoutChooseTenant();
  };

  const handlechoosePassword = () => {
    setShowPasswordUpdate(true);
  };
  const handleDefaultClick = async () => {
    setShowDefaultSettings(true);
    setLoading(true); // Start loading when opening the modal
    try {
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/fetch_default_settings",
        role_name: role,
        table_name: "default_settings",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        db_name: 'billing_platform',
        billing_db_name:selectedBillingDb,
        ...metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      console.log(response.data.data.default_settings);

      if (response.data.flag === true) {
        const { network_access_fee: networkAccessFee, cost_recovery_fee: costRecoveryFee } = response.data.data.default_settings[0];
        setNetworkAccessFee(networkAccessFee); // Set the fetched value
        setCostRecoveryFee(costRecoveryFee); // Set the fetched value
      } else {
        Modal.error({
          title: 'Error',
          content: 'Failed to fetch default settings. Please try again.',
          centered: true,
        });
      }
    } catch (error) {
      console.error('Error fetching default settings:', error);
      Modal.error({
        title: 'Error',
        content: 'An error occurred while fetching default settings. Please try again.',
        centered: true,
      });
    } finally {
      setLoading(false); // Stop loading after the API call
    }
  };

  const handleConfirmSave = async () => {
    setShowConfirmation(false);
    setLoading(true); // Start loading when saving

    try {
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/update_defualt_settings",
        role_name: role,
        table_name: "default_settings",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        db_name: 'billing_platform',
        ...metaData,
        billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        changed_data: {
          network_access_fee: networkAccessFee,
          cost_recovery_fee: costRecoveryFee
        }
      };

      const response = await axios.post(url, { data });
      console.log(response);
      if (response.data.flag === true) {
        Modal.success({
          title: 'Success',
          content: 'Fees saved successfully!',
          centered: true,
        });
        handleDefaultClickClose();
      } else {
        Modal.error({
          title: 'Error',
          content: 'Failed to save fees.',
          centered: true,
        });
      }
    } catch (error) {
      Modal.error({
        title: 'Error',
        content: 'Failed to save fees. Please try again.',
        centered: true,
      });
    } finally {
      setLoading(false); // Stop loading after the API call
    }
  };
  const handleDefaultClickClose = () => {
    setShowDefaultSettings(false);
    setNetworkAccessFee("");
    setCostRecoveryFee("");

  };

  const handleCyberreefClick = async () => {
    const data = {
      path: "/login_to_cyberreef",
      username: username,
      db_name: selectedDb,
                ...metaData,
      firstLastName: firstLastName,
      Partner: partner,
      request_received_at: getCurrentDateTime(),
    };

    try {
      const response = await axios.post(ENV_ROUTES.USER_AUTHENTICATION, data, {
        headers: {
          'Content-Type': 'application/json',
        },
      });
      const resp = JSON.parse(response.data.body);
      console.log(resp.data);
      if (resp?.flag === true) {
        // Redirect to the URL from the response
        window.open(resp.data.redirect_url, '_blank');
      } else {
        // Show an error modal if the flag is false
        Modal.error({
          title: 'Login Failed',
          content: 'Unable to log in to Cyberreef. Please check your credentials or account not available',
          centered: true,
        });
      }
    } catch (error) {
      console.error('Error during API call:', error);
      // Show an error modal for any other errors
      Modal.error({
        title: 'API Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred. Please try again later.',
        centered: true,
      });
    }
  };

  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <div className="p-2 flex justify-between items-left shadow-md header">
      <div className={`flex flex-col`}>
      <div className={`absolute left-[5px] p-2 top-[-5px] md:top-auto ${title?.startsWith("Customer Profiles -") ? 'md:mt-[-11px]' : ''}`}>
        {/* Toggle Button */}
        <button onClick={() => { setIsExpanded(!isExpanded) }} className="header-toggle text-gray-700 focus:outline-none relative top-[4px]">
          <Bars3Icon className='w-6 h-6' />
        </button>
        {typeof window !== "undefined" && (window.innerWidth > 700 || (!isExpanded && window.innerWidth < 700)) && (<span className=" p-4 font-[500] text-[18px] md:text-[24px]">
          {title !== "Comm Plans" ? title : "Communication Plans"}
        </span>)}
        <span className="mt-2">
          <ThemeSelector />
        </span>
        
        
      </div>
        {title?.startsWith("Customer Profiles -") && (
          <div className="mt-8 ml-12 flex gap-2 hidden lg:flex">
            {Object.entries(userProfileDetails).map(([key, value]) => {
              const normalizedKey = key.trim().toLowerCase();

              const formatCurrency = (amount: any) => {
                const cleaned = String(amount).replace(/,/g, "");
                const num = Number(cleaned);
                if (isNaN(num)) return String(amount);
                return num < 0 ? `-$${Math.abs(num).toFixed(2)}` : `$${num.toFixed(2)}`;
              };

              const displayValue =
                normalizedKey === "balance" || normalizedKey === "overdue"
                  ? formatCurrency(value)
                  : String(value);

              const valueClass =
                normalizedKey === "overdue"
                  ? "text-red-600"
                  : "text-black-600";

              return (
                <div key={key} className="max-w-[180px] truncate">
                  <span className="font-medium">{key}:</span>{" "}
                  <Tooltip title={displayValue}>
                    <span className={`text-sm truncate cursor-pointer ${valueClass}`}>
                      {displayValue}
                    </span>
                  </Tooltip>
                </div>
              );
            })}

          </div>
        )}
      </div>
      {/* {window.innerWidth} */}
      {typeof window !== "undefined" && (window.innerWidth > 700 || (!isExpanded && window.innerWidth < 700)) &&
        <div className="flex items-center md:space-x-2 absolute right-[20px] sm:right-[10px] mt-3 md:mt-0">
          <a
            onClick={handleCyberreefClick}
            rel="noopener noreferrer"
            style={{ cursor: 'pointer' }}
          >
            <img
              src="/images/mobile-shield.svg"
              alt="Go to Cyberreef"
              className="w-6 h-6"
            />
          </a>
          <div className="">
            <div
              className="flex items-center cursor-pointer ml-2 md:ml-5 mt-2"
              onClick={handleClick}
            >
              <div className="flex items-center justify-center w-10 h-10 rounded-full bg-green-500 text-white">
                <UserIcon className="w-5 h-5" />
              </div>
              <div className="ml-2 flex flex-col justify-center hidden lg:flex">
                <p className="text-base font-medium">{username}</p>
                <p className="text-xs text-gray-500">
                  {partner}, {role}
                </p>
              </div>
              <div className="ml-2  hidden md:flex">
                <ChevronDownIcon className="w-4 h-4" />
              </div>
            </div>

            {showLogout && (
              <div
                ref={menuRef}
                className="absolute top-full mt-2 bg-white rounded shadow-md whitespace-normal text-sm w-[200px] flex flex-col right-[0px]  lg:right-auto header-settings-menu"
              >
                <div className="ml-2 flex flex-col justify-center flex lg:hidden">
                  <p className="text-base font-medium">{username}</p>
                  <p className="text-xs text-gray-500">
                    {partner}, {role}
                  </p>
                </div>
                {title?.startsWith("Customer Profiles -") && (
          <div className="ml-2 flex flex-col gap-2 flex lg:hidden">
            {Object.entries(userProfileDetails).map(([key, value]) => {
              const normalizedKey = key.trim().toLowerCase();

              const formatCurrency = (amount: any) => {
                const cleaned = String(amount).replace(/,/g, "");
                const num = Number(cleaned);
                if (isNaN(num)) return String(amount);
                return num < 0 ? `-$${Math.abs(num).toFixed(2)}` : `$${num.toFixed(2)}`;
              };

              const displayValue =
                normalizedKey === "balance" || normalizedKey === "overdue"
                  ? formatCurrency(value)
                  : String(value);

              const valueClass =
                normalizedKey === "overdue"
                  ? "text-red-600"
                  : "text-black-600";

              return (
                <div key={key} className="max-w-[180px] truncate">
                  <span className="font-medium">{key}:</span>{" "}
                  <Tooltip title={displayValue}>
                    <span className={`text-sm truncate cursor-pointer ${valueClass}`}>
                      {displayValue}
                    </span>
                  </Tooltip>
                </div>
              );
            })}

          </div>
        )}

                <button
                  onClick={handleChoosePartner}
                  className="text-black rounded  hover:bg-[#E5E7EB] p-2 whitespace-nowrap flex items-center headers-menu-item"
                >
                  <SettingOutlined className="mr-3" />
                  Change Partner
                </button>
                <button
                  onClick={handlechoosePassword}
                  className="text-black rounded  hover:bg-[#E5E7EB] p-2 whitespace-nowrap flex items-center headers-menu-item"
                >
                  <KeyOutlined className="mr-3" />
                  Change Password
                </button>
                <button
                  onClick={handleLogout}
                  className="text-black rounded hover:bg-[#E5E7EB] whitespace-nowrap p-2  flex items-center headers-menu-item"
                >
                  <LogoutOutlined className="mr-3" />
                  <Tooltip title={username} placement="top">
                    <span className="truncate max-w-[120px]">
                      Logout ({username})
                    </span>
                  </Tooltip>
                </button>
              </div>
            )}
          </div>

          {showDefaultSettings && (
            <Modal
              title="Customer Profile Settings"
              footer={null}
              open={showDefaultSettings}
              onCancel={() => handleDefaultClickClose()}
              centered
            >
              {loading ? ( // Show loading spinner if loading
                <div className="flex justify-center items-center">
                  <Spin size="large" />
                </div>
              ) : (
                <div className="flex flex-col space-y-2">
                  <label className="field-label">
                    Network Access Fee<span className="text-red-500 ml-1">*</span>
                  </label>
                  <input
                    type="text"
                    className="input-field border border-gray-300 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={networkAccessFee}
                    onChange={(e) => setNetworkAccessFee(e.target.value)} // Update state on change
                  />
                  {errors.networkAccessFee && (
                    <p className="text-red-500">{errors.networkAccessFee}</p>
                  )} {/* Error message */}

                  <label className="field-label">
                    Cost Recovery Fee<span className="text-red-500 ml-1">*</span>
                  </label>
                  <input
                    type="text"
                    className="input-field border border-gray-300 rounded-md p-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={costRecoveryFee}
                    onChange={(e) => setCostRecoveryFee(e.target.value)} // Update state on change
                  />
                  {errors.costRecoveryFee && (
                    <p className="text-red-500">{errors.costRecoveryFee}</p>
                  )} {/* Error message */}
                </div>
              )}
              <div className="flex justify-center space-x-2 mt-4">
                <button
                  onClick={() => handleDefaultClickClose()}
                  className="cancel-btn"
                >
                  Cancel
                </button>
                <button
                  onClick={handleSaveClick}
                  className="save-btn"
                  disabled={loading} // Disable the button while loading
                >
                  Save
                </button>
              </div>
            </Modal>
          )}

          {showConfirmation && (
            <Modal
              title="Confirm Submission"
              open={showConfirmation}
              onCancel={() => setShowConfirmation(false)}
              onOk={handleConfirmSave}
              centered
            >
              <p>Are you sure you want to save these changes?</p>
            </Modal>
          )}

          {/* Conditional Rendering for Titanium Bill Center */}
          {partner === "Titanium - AWX" && (
            <a
              href="https://titanium.billcenter.net/"
              target="_blank"
              rel="noopener noreferrer"
              className="p-2 hover:underline text-blue-600 cursor-pointer flex items-center"
              style={{ fontFamily: "Calibri, sans-serif" }}
            >
              Titanium Bill Center
            </a>
          )}

          {/* Envelope Icon */}
          {/* <button className="p-2 rounded-full hover:bg-gray-200 hover:text-gray-800">
          <EnvelopeIcon className="w-6 h-6" />
        </button> */}
          {/* QuestionMarkCircle Icon */}
          <button className="p-2 rounded-full hover:bg-gray-200 hover:text-gray-800">
            <a
              href="https://lms.amop.services/auto2/byzrg5cgv4aa7/ddanx6w1ig702"
              target="_blank"
              rel="noopener noreferrer"
            >
              <QuestionMarkCircleIcon className="w-6 h-6" />
            </a>
          </button>
        </div>

      }
      {/* Display loader when logging out */}
      {isLoggingOut && (
        <div className="absolute inset-0 bg-gray-200 bg-opacity-75 flex justify-center items-center h-screen">
          <Spin size="large" />
        </div>
      )}
    </div>
  );
};

export default Header;
