import React, { useEffect, useState } from "react";
import { Modal, DatePicker, Select, Spin, Checkbox, notification } from "antd";
import { ChevronDownIcon } from "@heroicons/react/24/outline";
import { useAuth } from "../auth_context";
import { getCurrentDateTime } from "../header_constants";
import axios from "axios";
import { ENV_ROUTES } from "../routes/route_constants";
import { useOptimizationStore } from "@/app/stores/optimizationStore";

interface AddCarrierRatePlanProps {
  isOpen: boolean;
  onClose: () => void;
  row: any
}
const { Option } = Select;

const AddCarrierRatePlan: React.FC<AddCarrierRatePlanProps> = ({
  isOpen,
  onClose,
  row
}) => {
  const [customerRatePlan, setCustomerRatePlan] = useState<string>("");
  // const [customerRatePool, setCustomerRatePool]=useState<string>("");
  const [ratePool, setRatePool] = useState<string>("");
  const [effectiveDate, setEffectiveDate] = useState<string | null>(null);
  const [isEffectiveDateChecked, setIsEffectiveDateChecked] = useState<boolean>(false);
  const { username, partner, role, settabledata, token, selectedDb, metaData, firstLastName,sessionId} = useAuth();
  const [CustomerRatePlanCodeOptions, setCustomerRatePlanCodeOptions] = useState<any[]>([])
  const [ratePools, setRatePools] = useState<any[]>([])
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const { optimizationRow, optimizationType ,setIDActionMap,IDActionMap} = useOptimizationStore()

  const messageStyle = {
    fontSize: '14px',
    fontWeight: 'bold',
    padding: '16px',
  };

  const fetchData = async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/inventory_dropdowns_data",
        role_name: role,
        parent_module: "Optimization",
        module_name: "Optimization",
        service_provider_id: row?.service_provider_id || 0,
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
        dropdown: "Customer Rate Plan",
        modified_by: firstLastName
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
          onOk: onClose

        });
      } else {
        const carrierOptions_ = parsedData?.rate_plan_list || []
        setCustomerRatePlanCodeOptions(carrierOptions_)
        const commOptions_ = parsedData?.rate_pool_list || []
        setRatePools(commOptions_)
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
        onOk: onClose

      });
    } finally {
      setLoading(false);
    }
  };
  const SubmitData = async () => {
    setLoading(true);
    const changedData={
      id: row?.iccid||"",
      customer_rate_plan_name:customerRatePlan || null,
      customer_rate_pool_name:ratePool|| null,
      effective_date:effectiveDate|| null
    }
    try {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/update_inventory_data",
        role_name: role,
        module_name: "SimManagement Inventory",
        feature_module_name: "Inventory",
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        table_name: "sim_management_inventory",
        change_event_type: "Update Carrier Rate Plan",
        request_received_at: getCurrentDateTime(),
        template_name: "Inventory Status Update",
        changed_data:{...changedData},
        sessionID: sessionId,
        action: "Add customer rate plan",
        modified_by: firstLastName
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        Modal.error({
          title: 'Submit Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
          onOk: onClose

        });
      } else {
        const uniqueId = row.iccid;
        const updatedValue = IDActionMap?.[uniqueId] || []; // Get the existing value or an empty array
        const updatedMap = {
          ...IDActionMap,
          [uniqueId]: updatedValue.includes("Add carrier rate plan")
              ? updatedValue // Keep the existing value if already present
              : [...updatedValue, "Add carrier rate plan"], // Add the new value otherwise
      };
        
        setIDActionMap(updatedMap);
        notification.success({
          message: 'Success',
          description: 'Successfully updated!',
          style: messageStyle,
          placement: 'top',
        });
        onClose()
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Submit Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting data. Please try again.',
        centered: true,
        onOk: onClose

      });
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    fetchData()
  }, [isOpen]);

  // useEffect(() => {
  //   if (isOpen && CustomerRatePlanCodeOptions.length === 0) {
  //     fetchData();
  //   }
  // }, [isOpen]);


  const handleCarrierRatePlanChange = (value: string) => {
    if (value) {
      setCustomerRatePlan(value);
    }
  };


  const handleComPlanChange = (value: string) => {
    if (value) {
      setRatePool(value);
    }
  };

  const handleDateChange = (date: any, dateString: string | string[]) => {
    if (typeof dateString === 'string') {
      setEffectiveDate(dateString);
    } else {
      setEffectiveDate(dateString[0]);
    }
  };



  // const handleEffectiveDateCheck = (e: any) => {
  //   setIsEffectiveDateChecked(e.target.checked);
  //   if (!e.target.checked) {
  //     setEffectiveDate(null);
  //   }
  // };
  const handleSubmit = () => {
    const newErrors: { [key: string]: string } = {};
    if (!customerRatePlan) newErrors.customerRatePlan = "customer rate plan is required.";
    if (!ratePool) newErrors.ratePool = "Customer rate pool is required.";
    // if (!isEffectiveDateChecked) {
    //   newErrors.effectiveDate = "Effective date is required";
    // } 
   if (!effectiveDate) {
      newErrors.effectiveDate = "Effective date is required.";
    } 
     setErrors(newErrors);

        // Proceed only if there are no errors
        if (Object.keys(newErrors).length === 0) {
          SubmitData();
          
            // console.log("Form submitted successfully!");

        }
  };

  return (
    <>
      <Modal
        title={
          <div className='mt-[-10px]'><span className='text-[19px]'>Add Carrier Rate Plan</span></div>}
        visible={isOpen}
        centered
        onCancel={onClose}
        footer={[
          <div className="flex justify-center space-x-2 mt-12" key="buttons">
            <button key="cancel" onClick={onClose} className="cancel-btn h-[30px] text-base" style={{ fontFamily: 'Calibri, sans-serif' }}>
              Cancel
            </button>
            <button key="update" onClick={handleSubmit} className="save-btn text-base border-none" style={{ fontFamily: 'Calibri, sans-serif' }}>
              Update
            </button>
          </div>,
        ]}
        width={500}
        style={{ height: '500px' }}
      > <>
          {loading ? (
            <div className="popup flex justify-center items-center w-full h-full">
              <Spin size="large" />
            </div>
          ) : (
            <div className="flex flex-col space-y-4">
              <div>
                <label htmlFor='carrier-rate-plan' className="font-normal text-lg" style={{ fontFamily: 'Calibri, sans-serif' }}>Carrier rate plan <span className="text-red-500">*</span></label>
                <Select
                  id='carrier-rate-plan'
                  placeholder="Select a carrier rate plan"
                  onChange={handleCarrierRatePlanChange}
                  className="w-full mt-1 mb-2"
                  value={customerRatePlan}
                  showSearch
                  suffixIcon={<ChevronDownIcon className="w-5 mt-2 h-5 text-gray-600 arrow" />}                 >
                  {CustomerRatePlanCodeOptions.map((option) => (
                    <Option key={option} value={option}>
                      {option}
                    </Option>
                  ))}
                </Select>
                {errors.customerRatePlan && <div className="text-red-500 mt-1">{errors.customerRatePlan}</div>}
              </div>
              <div>
                <label htmlFor='comm-plan' className="font-normal text-lg" style={{ fontFamily: 'Calibri, sans-serif' }}>Communication Plan<span className="text-red-500">*</span></label>
                <Select
                  id='comm-plan'
                  placeholder="Select a communication plan"
                  onChange={handleComPlanChange}
                  className="w-full mt-1 mb-2"
                  value={ratePool}
                  showSearch
                  suffixIcon={<ChevronDownIcon className="w-5 mt-2 h-5 text-gray-600 arrow" />}                 >
                  {ratePools.map((option, index) => (
                    <Option key={index} value={option}>
                      {option}
                    </Option>
                  ))}
                </Select>
                {errors.ratePool && <div className="text-red-500 mt-1">{errors.ratePool}</div>}
              </div>
              <div style={{ marginTop: '1.5rem' }} className='mb-2'>
                
              
                  <div className="mt-2 ">
                    <label htmlFor='date-picker' className="font-normal text-lg" style={{ fontFamily: 'Calibri, sans-serif' }}>Effective Date</label>
                    <DatePicker id='date-picker' onChange={handleDateChange} className="w-full mt-1 h-10" />
                  </div>
               
                {isEffectiveDateChecked && errors.effectiveDate && (
                  <div className="text-red-500 mt-1">{errors.effectiveDate}</div>
                )}
              </div>
            </div>
          )}
        </>
      </Modal>
    </>
  );
};
export default AddCarrierRatePlan;
