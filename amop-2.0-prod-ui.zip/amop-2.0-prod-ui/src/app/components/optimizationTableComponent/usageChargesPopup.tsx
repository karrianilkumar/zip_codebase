import React, { useState } from 'react';
import { Modal, DatePicker, notification, Spin } from 'antd';
import axios from 'axios';
import { ENV_ROUTES } from '../routes/route_constants';
import { useAuth } from '../auth_context';
import { useOptimizationStore } from '@/app/stores/optimizationStore';
import moment from 'moment';

interface UsageChargesProps {
  isOpen: boolean;
  onClose: () => void;
  row: any;
}

const UsageCharges: React.FC<UsageChargesProps> = ({ isOpen, onClose, row }) => {
  const { username, partner, role, token, selectedDb,metaData, firstLastName,sessionId} = useAuth();
  const { setIDActionMap, IDActionMap ,optimizationRow} = useOptimizationStore();
  const [loading, setLoading] = useState(false);

  // State variables for form fields
  const [chargeAmount, setChargeAmount] = useState('');
  const [description, setDescription] = useState('');
  const [productId, setProductId] = useState('');
  const [startDate, setStartDate] = useState<string | null>(null);
  const [endDate, setEndDate] = useState<string | null>(null);

  const messageStyle = {
    fontSize: '14px',
    fontWeight: 'bold',
    padding: '16px',
  };

  const handleSubmit = async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.OPTIMIZATION;
      const changedData = {
        charge_amount: chargeAmount,
        charge_product_description: description,
        product_type_id: productId,
        start_date_of_charge: startDate,
        end_date_of_charge: endDate,
        service_provider_id: optimizationRow?.service_provider_id || 0,
        change_request_type_id: "7",
        status: 'NEW',
        created_by: firstLastName,
        is_active: "True",
        is_deleted: "False",
        service_provider: optimizationRow?.service_provider || "",
        change_request_type: "Create Rev Service",
        modified_by: firstLastName,
        uploaded: 0,
        processed_by: firstLastName,
      }
      const data = {
        tenant_name: partner || 'default_value',
        username: username,
        firstLastName: firstLastName,
        path: '/update_push_charges_data_optimization',
        role_name: role,
        parent_module: 'Optimization',
        module_name: 'Optimization',
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
        dropdown: 'Customer Rate Plan',
        changed_data:changedData,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        Modal.error({
          title: 'Update Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
          onOk: onClose,
        });
      } else {
        const uniqueId = row.iccid;
        const updatedValue = IDActionMap?.[uniqueId] || [];
        const updatedMap = {
          ...IDActionMap,
          [uniqueId]: updatedValue.includes('Usage charges')
            ? updatedValue
            : [...updatedValue, 'Usage charges'],
        };

        setIDActionMap(updatedMap);
        notification.success({
          message: 'Success',
          description: 'Successfully updated!',
          style: messageStyle,
          placement: 'top',
        });
        onClose();
      }
    } catch (error) {
      console.error('Error fetching data:', error);
      Modal.error({
        title: 'Update Error',
        content:
          error instanceof Error
            ? error.message
            : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
        onOk: onClose,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      title={
        <div className="mt-[-10px]">
          <span className="text-[23px]">Usage Charges</span>
        </div>
      }
      open={isOpen}
      onCancel={onClose}
      footer={null}
      centered
      width={600}
    >
      <>
        {loading ? (
          <div className="popup flex justify-center items-center w-full h-[300px]">
            <Spin size="large" />
          </div>
        ) : (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="field-label">Charge Amount</label>
                <input
                  type="text"
                  className="input w-full"
                  placeholder="Enter charge amount"
                  value={chargeAmount}
                  onChange={(e) => setChargeAmount(e.target.value)}
                />
              </div>
              <div>
                <label className="field-label">Charge/Product Description</label>
                <input
                  type="text"
                  className="input w-full"
                  placeholder="Enter description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                />
              </div>
              <div>
                <label className="field-label">Product Id/Product Type Id</label>
                <input
                  type="text"
                  className="input w-full"
                  placeholder="Enter product ID"
                  value={productId}
                  onChange={(e) => setProductId(e.target.value)}
                />
              </div>
              <div>
                <label className="field-label">Start Date of Charge</label>
                <DatePicker
                  value={startDate}
                  onChange={(date) => setStartDate(date)}
                  className="input"
                  format="YYYY-MM-DD"
                  placeholder="YYYY-MM-DD"
                />
              </div>
              <div>
                <label className="field-label">End Date of Charge</label>
                <DatePicker
                  value={endDate}
                  onChange={(date) => setEndDate(date)}
                  className="input"
                  format="YYYY-MM-DD"
                  placeholder="YYYY-MM-DD"
                />
              </div>
            </div>
            <div className="flex justify-center gap-4 mt-6">

              <button onClick={onClose} className="cancel-btn">
                Cancel
              </button>
              <button onClick={handleSubmit} className="save-btn" disabled={loading}>
                Update
              </button>
            </div>
          </div>
        )
        }
      </>
    </Modal>
  );
};

export default UsageCharges;
