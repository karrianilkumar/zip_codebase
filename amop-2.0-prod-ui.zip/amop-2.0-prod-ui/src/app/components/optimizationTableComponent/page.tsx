"use client";

import React, { useState, useEffect, useRef, useCallback } from 'react';
import Pagination from '../pagination';
import { ArrowDownOutlined, ArrowUpOutlined } from '@ant-design/icons';
import { useAuth } from '../auth_context';
import axios from 'axios';
import { getCurrentDateTime } from '../header_constants';
import { Modal, Select, Spin, Tooltip ,Radio} from 'antd';
import { ENV_ROUTES } from '../routes/route_constants';
import ProgressBar from './cell-renderers/progressBar';
import { useRouter } from 'next/navigation';
import OptimizationDetails from './optimizationDetails';
import AssignRatePlanModal from './assignRatePlanModal';
import { CheckCircleIcon, ChevronDownIcon, XCircleIcon } from '@heroicons/react/24/outline';
import AddCustomerRatePlan from './addCustomerRatePlanPopup';
import AddServiceLine from './addServiceLinePopup';
import UsageCharges from './usageChargesPopup';
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { useOptimizationStore } from "@/app/stores/optimizationStore";
import AddCarrierRatePlan from './addCarrierRatePlanPopup';
import { useSearchStore } from '@/app/stores/searchStore';
import { useCustomerRatePlanStore } from '@/app/stores/customerRateplanStore';
import RowDetailsModal from '../rowDetailsModal';

interface OptimizationTableComponentProps {
    headers: string[];
    headerMap: any;
    initialData: any[];
    searchQuery?: string;
    visibleColumns: string[];
    itemsPerPage: number;
    moduleName: string;
    pagination: {
        start: number;
        end: number;
        total: number;
    };
    advancedFilters?: any;
    iccids_list?: any[]
    instance_ids_list?: any[]
    height?: any;
}

const OptimizationTableComponent: React.FC<OptimizationTableComponentProps> = ({
    headers,
    headerMap,
    initialData,
    searchQuery,
    visibleColumns,
    itemsPerPage,
    moduleName,
    pagination,
    advancedFilters,
    iccids_list,
    instance_ids_list,
    height
}) => {
    const [rowData, setRowData] = useState(initialData);
    const [currentPage, setCurrentPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const isFirstRender = useRef(true);
    const isFirstSearchRender = useRef(true);
    const isFirstAdvancedSearchRender = useRef(true);
    const [sortConfig, setSortConfig] = useState<{ key: string; direction: "ascending" | "descending"; } | null>(null);
    const [loading, setLoading] = useState(false);

    const [detailsOpen, setDetailsOpen] = useState(false);
    const [pushChargesOpen, setPushChargesOpen] = useState(false);
    const [detailsRowIndex, setDetailsRowIndex] = useState<number | null>(null);
    const [assignRatePlanOpen, setAssignRatePlanOpen] = useState(false);
    const [assignRatePlanRowIndex, setAssignRatePlanRowIndex] = useState<number | null>(null);
    const [selectedRows, setSelectedRows] = useState<number[]>([]);
    const [selectAllPushCharges, setSelectAllPushCharges] = useState<boolean>(false);

    const [isRatePlanModalOpen, setIsRatePlanModalOpen] = useState(false);
    const [isServiceLineModalOpen, setIsServiceLineModalOpen] = useState(false);
    const [isUsageChargesModalOpen, setIsUsageChargesModalOpen] = useState(false);
    const [actionsRow, setActionsRow] = useState<any>({});

    const { features: moduleFeatures, setFeatures: setModuleFeatures } = useFeatureStore();

    const { optimizationRow, optimizationType, setChargesSummaryRows, chargesSummaryRows, IDActionMap, setIDActionMap, setSelectAll, setOptimizationRow, setDeselectedRowIds, setOptimizationType } = useOptimizationStore()

    const router = useRouter();

    const {
        username,
        tenantNames,
        role,
        partner,
        selectedPartnerModule,
        Environment,
        tabledata,
        storedpagination,
        advancedStoredpagination,
        combineAdnvaceStoredpagination,
        token,
        selectedDb,
        metaData,
        sessionId,
        serviceProviderList,
        selectedServiceProvider,
        setAdvancedStoredPagination,
        setStoredPagination,
        setCombineAdnvaceStoredpagination,
        firstLastName,
        settabledata
    } = useAuth();
    const { searchData, advancedSearchData, combineAdnvaceSearchData } = useSearchStore();
    const { showAdvanced } = useCustomerRatePlanStore();
    const [showRowModal, setShowRowModal] = useState<boolean>(false);
    const [showRowModalData, setShowRowModalData] = useState<any>(null);
    const current_session_details_active_module = localStorage.getItem("current_session_details_active_module");
    //Viewport height
    const [viewportHeight, setViewportHeight] = useState(window.innerHeight);
          // Add state to track screen width
             const [isSmallScreen, setIsSmallScreen] = useState(false);
            
             // Check for small screen on component mount and window resize
             useEffect(() => {
                 const checkScreenSize = () => {
                     setIsSmallScreen(window.innerWidth < 700);
                 };
                 
                 // Initial check
                 checkScreenSize();
                 
                 // Add event listener for window resize
                 window.addEventListener('resize', checkScreenSize);
                 
                 // Clean up
                 return () => window.removeEventListener('resize', checkScreenSize);
             }, []);

    useEffect(() => {
        setAdvancedStoredPagination(null)
        setStoredPagination(null)
        setCombineAdnvaceStoredpagination(null)
        const handleResize = () => {
            setViewportHeight(window.innerHeight);
        };

        // Add event listener for window resize
        window.addEventListener("resize", handleResize);

        // Cleanup event listener on component unmount
        return () => {
            window.removeEventListener("resize", handleResize);
        };
    }, []);


    //To display the initial data
    useEffect(() => {
        const newRowData = tabledata.length > 0 ? tabledata : initialData;
        setRowData(newRowData);
    }, [initialData, tabledata]);

    useEffect(() => {
        setCurrentPage(1);
    }, [tabledata, sortConfig]);

    useEffect(() => {
        setCurrentPage(1);
    }, [totalPages]);

    useEffect(() => {
        let pagination_
        if (combineAdnvaceStoredpagination) {
            pagination_ = combineAdnvaceStoredpagination
        }
        else if (advancedStoredpagination && !storedpagination) {
            pagination_ = advancedStoredpagination
        }
        else if (storedpagination && !advancedStoredpagination) {
            pagination_ = storedpagination
        }
        else {
            pagination_ = pagination
        }
        // const pagination_ = pagination;
        const start = pagination_?.start || 1;
        const total = pagination_?.total || 1;
        const end = pagination_?.end || 1;
        const lastPageWithData_ = Math.floor(end / itemsPerPage);
        const totalPages_ = Math.ceil(total / itemsPerPage);
        const currentPage_ = Math.floor(start / itemsPerPage) + 1;
        setTotalPages(totalPages_);
        // setCurrentPage(currentPage_);
        // setLastPageWithData(lastPageWithData_);
    }, [tabledata, initialData, pagination, itemsPerPage, currentPage, storedpagination, advancedStoredpagination, combineAdnvaceStoredpagination, sortConfig]);

    //To manage the pagination routes
    const refreshFetchData = useCallback(async () => {
        settabledata([])
          setLoading(true);
        try {
          console.log("setLoading", loading)
          const url = ENV_ROUTES.OPTIMIZATION;
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/get_optimization_data",
            role_name: role,
            parent_module: "Optimization",
            module_name: "Optimization",
            feature_module_name: "Optimization",
            optimization_type:optimizationType,
            mod_pages: {
              start: 0,
              end: 100,
            },
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
        ... metaData,
            sessionID: sessionId,
          };
          const response = await axios.post(url, { data });
          const parsedData = JSON.parse(response.data.body);
          if (parsedData.flag === false) {
            Modal.error({
              title: 'Data Fetch Error',
              content: parsedData.message || 'An error occurred while fetching data. Please try again.',
              centered: true,
            });
          } else {
            const headersMap_ = parsedData?.headers_map?.["Customer"]?.header_map || {}
            const tableData_ = parsedData?.data || []
            settabledata(tableData_)
          }
          // addLog('BulkChange Table Data Processing Data Completed');
        } catch (error) {
          console.error("Error fetching data:", error);
          Modal.error({
            title: 'Data Fetch Error',
            content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
            centered: true,
          });
        } finally {
          setLoading(false); // Only stop loading for the first call
        }
      }, [username, partner, role, token]);
    const updatePaginator = async () => {
        let start_ = Math.floor((currentPage - 1) * itemsPerPage);
        let end_ = Math.floor((currentPage - 1) * itemsPerPage + itemsPerPage);
        try {
            const colSortKey = sortConfig ? sortConfig.key : ""
            const colSortDirection = sortConfig ? sortConfig.direction : ""
            const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";
            // if (currentPage !== 1) {
            setLoading(true);
            // }
            if (moduleName === "Central Optimization") {
                const url = ENV_ROUTES.CENTRALIZED_VIEW
                const data = {
                    tenant_name: partner || "default_value",
                    username: username,
                    firstLastName: firstLastName,
                    path: "/get_centralized_list_view_data",
                    role_name: role,
                    parent_module: "Super Admin",
                    module_name: "Centralized Optimization View",
                    feature_module_name: "Centralized Optimization View",
                    sub_module: "Customer",
                    table_name: "vw_all_combined_optimization",
                    mod_pages: {
                        start: start_,
                        end: end_,
                    },
                    request_received_at: getCurrentDateTime(),
                    Partner: partner,
                    access_token: token,
                    db_name: "central_db",
                    sessionID: sessionId,
                    ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
                        : {}),
                };
                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);
                if (parsedData.flag === false) {
                    Modal.error({
                        title: 'Data Fetch Error',
                        content: parsedData.message || 'An error occurred while fetching optimization data. Please try again.',
                        centered: true,
                    });
                } else {
                    const tableData_ = parsedData?.data || []
                    setRowData(tableData_);
                    pagination = parsedData?.pages || pagination
                }
            }
            if (moduleName === "Customer optimization") {
                const url = ENV_ROUTES.OPTIMIZATION
                const data = {
                    tenant_name: partner || "default_value",
                    username: username,
                    firstLastName: firstLastName,
                    path: "/get_optimization_data",
                    role_name: role,
                    parent_module: "Optimization",
                    module_name: "Optimization",
                    feature_module_name: "Optimization",
                    optimization_type: "Customer",
                    mod_pages: {
                        start: start_,
                        end: end_,
                    },
                    request_received_at: getCurrentDateTime(),
                    Partner: partner,
                    access_token: token,
                    db_name: selectedDb,
        ... metaData,
                    sessionID: sessionId,
                    ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
                        : {}),
                };
                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);
                if (parsedData.flag === false) {
                    Modal.error({
                        title: 'Data Fetch Error',
                        content: parsedData.message || 'An error occurred while fetching optimization data. Please try again.',
                        centered: true,
                    });
                } else {
                    const tableData_ = parsedData?.data || []
                    setRowData(tableData_);
                    pagination = parsedData?.pages || pagination
                }
            }
            if (moduleName === "Carrier optimization") {
                const url = ENV_ROUTES.OPTIMIZATION
                const data = {
                    tenant_name: partner || "default_value",
                    username: username,
                    firstLastName: firstLastName,
                    path: "/get_optimization_data",
                    role_name: role,
                    parent_module: "Optimization",
                    module_name: "Optimization",
                    feature_module_name: "Optimization",
                    optimization_type: "Carrier",
                    mod_pages: {
                        start: start_,
                        end: end_,
                    },
                    request_received_at: getCurrentDateTime(),
                    Partner: partner,
                    access_token: token,
                    db_name: selectedDb,
        ... metaData,
                    sessionID: sessionId,
                    ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
                        : {}),
                };
                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);
                if (parsedData.flag === false) {
                    Modal.error({
                        title: 'Data Fetch Error',
                        content: parsedData.message || 'An error occurred while fetching optimization data. Please try again.',
                        centered: true,
                    });
                } else {
                    const tableData_ = parsedData?.data || []
                    setRowData(tableData_);
                    pagination = parsedData?.pages || pagination
                }
            }
            if (moduleName === "Charge history") {
                const url = ENV_ROUTES.CHARGES_HISTORY
                const data = {
                    tenant_name: partner || "default_value",
                    username: username,
                    firstLastName: firstLastName,
                    path: "/get_charge_history_data",
                    role_name: role,
                    module_name: "Charge history",
                    feature_module_name: "Charge History",
                    mod_pages: {
                        start: start_,
                        end: end_,
                    },
                    request_received_at: getCurrentDateTime(),
                    Partner: partner,
                    access_token: token,
                    db_name: selectedDb,
        ... metaData,
                    sessionID: sessionId,
                    ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
                        : {}),
                };

                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);
                if (parsedData.flag === false) {
                    Modal.error({
                        title: 'Data Fetch Error',
                        content: parsedData.message || 'An error occurred while fetching optimization data. Please try again.',
                        centered: true,
                    });
                } else {
                    const tableData = parsedData?.customer_charges_data || []
                    setRowData(tableData);
                    pagination = parsedData?.pages || pagination
                }
            }
            if (moduleName === "High usage customers") {
                const url = ENV_ROUTES.OPTIMIZATION
                const data = {
                    tenant_name: partner || "default_value",
                    username: username,
                    firstLastName: firstLastName,
                    path: "/get_optimization_row_details",
                    role_name: role,
                    parent_module: "Optimization",
                    module_name: "Optimization",
                    feature_module_name: "Optimization",
                    optimization_type: optimizationType,
                    request_received_at: getCurrentDateTime(),
                    Partner: partner,
                    access_token: token,
                    db_name: selectedDb,
        ... metaData,
                    sessionID: sessionId,
                    session_id: optimizationRow?.session_id || '',
                    start: start_,
                    end: end_,
                    fetch_type: "high_usage",
                    ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
                        : {}),
                };

                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);
                if (parsedData.flag === false) {
                    Modal.error({
                        title: 'Data Fetch Error',
                        content: parsedData.message || 'An error occurred while fetching optimization data. Please try again.',
                        centered: true,
                    });
                } else {
                    const tableData = parsedData?.high_usage_customers_data || []
                    setRowData(tableData);
                    pagination = parsedData?.pages || pagination
                }
            }
            if (moduleName === "Push charge errors") {
                const url = ENV_ROUTES.OPTIMIZATION
                const data = {
                    tenant_name: partner || "default_value",
                    username: username,
                    firstLastName: firstLastName,
                    path: "/get_optimization_push_charges_data",
                    role_name: role,
                    parent_module: "Optimization",
                    module_name: "Optimization",
                    feature_module_name: "Optimization",
                    optimization_type: "Customer",
                    request_received_at: getCurrentDateTime(),
                    Partner: partner,
                    access_token: token,
                    db_name: selectedDb,
        ... metaData,
                    sessionID: sessionId,
                    session_id: optimizationRow?.session_id || '',
                    start: start_,
                    end: end_,
                    ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
                        : {}),
                };
                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);
                if (parsedData.flag === false) {
                    Modal.error({
                        title: 'Data Fetch Error',
                        content: parsedData.message || 'An error occurred while fetching optimization data. Please try again.',
                        centered: true,
                    });
                } else {
                    const tableData = parsedData?.push_charges_data || []
                    setRowData(tableData);
                    pagination = parsedData?.pages || pagination
                }
            }

        } catch (err) {
            console.error("Error fetching data:", err);
        } finally {
            setLoading(false);
        }
        // }
    };

    const updateSearchPaginator = async () => {
        let start_ = Math.floor((currentPage - 1) * itemsPerPage);
        let end_ = Math.floor((currentPage - 1) * itemsPerPage + 100);
        const colSortKey = sortConfig ? sortConfig.key : ""
        const colSortDirection = sortConfig ? sortConfig.direction : ""
        const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";
        try {
            setLoading(true);
            const url = ENV_ROUTES.OPEN_SEARCH;
            let data = { ...searchData, username: username, }
            data.data.pages = {
                start: start_,
                end: end_,
            }
            data.data.col_sort = { [colSortKey]: colSortValue }
            const response = await axios.post(url, data);
            const parsedData = JSON.parse(response.data.body);
            if (parsedData?.flag) {
                const tableData = parsedData?.data?.table || [];
                setRowData(tableData);
                const pagination_ = parsedData?.pages || {};
                setStoredPagination(pagination_);
                setAdvancedStoredPagination(null)
                if (tableData.length === 0) {
                    Modal.error({
                        title: "No Records found",
                    });
                }
            } else {
                Modal.error({
                    title: "Search error",
                    content:
                        parsedData.error ||
                        "An error occurred while searching. Please try again.",
                });
            }
            console.log(response);
        } catch (error) {
            console.log(error);
        } finally {
            setLoading(false); // Stop loader
        }
    }
    const updateAdvancedSearchPaginator = async () => {
        let start_ = Math.floor((currentPage - 1) * itemsPerPage);
        let end_ = Math.floor((currentPage - 1) * itemsPerPage + 100);
        const colSortKey = sortConfig ? sortConfig.key : ""
        const colSortDirection = sortConfig ? sortConfig.direction : ""
        const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";
        try {
            setLoading(true);
            const url = ENV_ROUTES.OPEN_SEARCH;
            let data = { ...advancedSearchData, username: username, }
            data.data.pages = {
                start: start_,
                end: end_,
            }
            data.data.col_sort = { [colSortKey]: colSortValue }
            const response = await axios.post(url, data);
            const parsedData = JSON.parse(response.data.body);
            if (parsedData?.flag) {
                const tableData = parsedData?.data?.table;
                setRowData(tableData);
                const pagination_ = parsedData?.pages || {}
                setStoredPagination(null)
                setAdvancedStoredPagination(pagination_)
                if (tableData.length === 0) {
                    Modal.error({
                        title: "No Records found",
                    });
                }
            } else {
                Modal.error({
                    title: "Search error",
                    content:
                        parsedData.error ||
                        "An error occurred while searching. Please try again.",
                });
            }
            console.log(response);
        } catch (error) {
            console.log(error);
        } finally {
            setLoading(false); // Stop loader
        }
    }
    const updateCombinedSearchPaginator = async () => {
        let start_ = Math.floor((currentPage - 1) * itemsPerPage);
        let end_ = Math.floor((currentPage - 1) * itemsPerPage + 100);
        const colSortKey = sortConfig ? sortConfig.key : ""
        const colSortDirection = sortConfig ? sortConfig.direction : ""
        const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";
        try {
            setLoading(true);
            const url = ENV_ROUTES.OPEN_SEARCH;
            let data = { ...combineAdnvaceSearchData, username: username, }
            data.data.pages = {
                start: start_,
                end: end_,
            }
            data.data.col_sort = { [colSortKey]: colSortValue }
            const response = await axios.post(url, data);
            const parsedData = JSON.parse(response.data.body);
            console.log("parsed", parsedData);
            if (parsedData?.flag) {
                const tableData = parsedData?.data?.table;
                setRowData(tableData);
                const pagination_ = parsedData?.pages || {}
                setStoredPagination(null)
                setAdvancedStoredPagination(null)
                setCombineAdnvaceStoredpagination(pagination_)
                if (tableData.length === 0) {
                    Modal.error({
                        title: "No Records found",
                    });
                }
            } else {
                Modal.error({
                    title: "Search error",
                    content:
                        parsedData.error ||
                        "An error occurred while searching. Please try again.",
                });
            }
            console.log(response);
        } catch (error) {
            console.log(error);
        } finally {
            setLoading(false); // Stop loader
        }
    }

    useEffect(() => {
        if (!isFirstRender.current) {
            if (combineAdnvaceStoredpagination) {
                updateCombinedSearchPaginator()
            }
            else if (storedpagination && !advancedStoredpagination) {
                updateSearchPaginator()
            }
            else if (advancedStoredpagination && !storedpagination) {
                updateAdvancedSearchPaginator()
            }
            else {
                updatePaginator();
            }

        } else { isFirstRender.current = false }
    }, [currentPage, sortConfig]);

    useEffect(() => {
        // console.log("searchQuery",searchQuery)
        if (!isFirstSearchRender.current) {
            if (searchQuery === "") {
                console.log("searchQuery", isFirstRender)
                if (storedpagination) {
                    updateSearchPaginator()
                }
                else if (advancedStoredpagination) {
                    updateAdvancedSearchPaginator()
                }
                else {
                    updatePaginator();
                }
            }
        } else { isFirstSearchRender.current = false }
    }, [searchQuery]);

    useEffect(() => {
        // console.log("advancedFilters",advancedFilters)
        if (!isFirstAdvancedSearchRender.current) {
            if (advancedFilters) {
                const allEmpty = Object.values(advancedFilters).every(
                    (value) => Array.isArray(value) && value.length === 0
                );

                if (allEmpty) {
                    console.log("advancedFilters", advancedFilters)
                    if (storedpagination) {
                        updateSearchPaginator()
                    }
                    else if (advancedStoredpagination) {
                        updateAdvancedSearchPaginator()
                    }
                    else {
                        updatePaginator();
                    }
                }
            }
        } else { isFirstAdvancedSearchRender.current = false }

    }, [advancedFilters]);
    //For sorting the table
    const handleSort = (key: string) => {
        let direction: "ascending" | "descending" = "ascending";
        if (
            sortConfig &&
            sortConfig.key === key &&
            sortConfig.direction === "ascending"
        ) {
            direction = "descending";
        }

        // const sortedData = [...rowData].sort((a, b) => {
        //     let aValue = a[key];
        //     let bValue = b[key];

        //     // Special handling for the "Assigned rate plans" or "Assigned rate plan count" columns
        //     if (key === "carrier_rate_plans") {
        //         aValue = Array.isArray(aValue) ? aValue.length : JSON.parse(aValue)?.length || 0;
        //         bValue = Array.isArray(bValue) ? bValue.length : JSON.parse(bValue)?.length || 0;
        //     }

        //     // Convert 'None' to null for easier comparison
        //     const normalizeValue = (value: any) => {
        //         if (value === 'None') return null;
        //         return value;
        //     };

        //     aValue = normalizeValue(aValue);
        //     bValue = normalizeValue(bValue);

        //     // Function to split a string into alphabetical and numeric segments
        //     const splitIntoSegments = (str: string) => {
        //         return str.toLowerCase().match(/([a-z]+|\d+)/g) || [];
        //     };

        //     // Split values into segments
        //     const aSegments = typeof aValue === "string" ? splitIntoSegments(aValue) : [aValue];
        //     const bSegments = typeof bValue === "string" ? splitIntoSegments(bValue) : [bValue];

        //     // Compare each segment one by one
        //     for (let i = 0; i < Math.max(aSegments.length, bSegments.length); i++) {
        //         const aSegment = aSegments[i];
        //         const bSegment = bSegments[i];

        //         // If one segment is undefined, consider it smaller
        //         if (aSegment === undefined) return direction === "ascending" ? -1 : 1;
        //         if (bSegment === undefined) return direction === "ascending" ? 1 : -1;

        //         // Compare numeric segments numerically, and character segments lexicographically
        //         const isANumber = !isNaN(Number(aSegment));
        //         const isBNumber = !isNaN(Number(bSegment));

        //         if (isANumber && isBNumber) {
        //             // Both segments are numbers; compare them numerically
        //             const numA = Number(aSegment);
        //             const numB = Number(bSegment);
        //             if (numA < numB) return direction === "ascending" ? -1 : 1;
        //             if (numA > numB) return direction === "ascending" ? 1 : -1;
        //         } else {
        //             // At least one segment is not a number; compare them as strings
        //             if (aSegment < bSegment) return direction === "ascending" ? -1 : 1;
        //             if (aSegment > bSegment) return direction === "ascending" ? 1 : -1;
        //         }
        //     }

        //     return 0;
        // });
        setCurrentPage(1)
        setSortConfig({ key, direction });
        // setRowData(sortedData);
    };

    const handleActionSelect = (value: string, row: any) => {
        setActionsRow(row)
        switch (value) {
            case "add-rate":
                setIsRatePlanModalOpen(true);
                break;
            case "add-service":
                setIsServiceLineModalOpen(true);
                break;
            case "push-charges":
                setIsUsageChargesModalOpen(true);
                break;
        }
    };

    const navigateToDetails = (rowIndex: number) => {
        if (current_session_details_active_module !== "Optimization") {
            const optimization_type_=rowData[rowIndex]?.optimization_type || "Customer"
            setOptimizationType(optimization_type_)
            localStorage.setItem("optimization_details_row", JSON.stringify(rowData[rowIndex] || {}));
            // Open new tab
            window.open("/super_admin/centralized_view/optimization/optimization_details", "_blank");
        }
        setOptimizationRow(rowData[rowIndex] || {})
        if(current_session_details_active_module === "Optimization"){
            setDetailsOpen(true)
        }
        setDetailsRowIndex(rowIndex)
    }
    const navigateToPushCharges = (rowIndex: number) => {
        setPushChargesOpen(true)
        setOptimizationRow(rowData[rowIndex] || {})
        setDetailsOpen(true)
        setDetailsRowIndex(rowIndex)
    }
    const openAssignRatePlan = (rowIndex: number) => {
        setAssignRatePlanOpen(true)
        setAssignRatePlanRowIndex(rowIndex)
    }

    //For closing all the modals

    const closeModal = () => {
        setDetailsOpen(false)
        setPushChargesOpen(false)
        setDetailsRowIndex(null)
        setAssignRatePlanOpen(false)
        setAssignRatePlanRowIndex(null)
    }

    const renderPushedChargesCol = (cellData: any) => {
        if (cellData === "true" || cellData === true || cellData === "True") {
            return (
                <div className='w-full flex items-center justify-center'>
                    <CheckCircleIcon className="text-green-500 h-5 w-5" />
                </div>
            );
        } else {
            return (
                <div className='w-full flex items-center justify-center'>
                    <XCircleIcon className="text-red-500 h-5 w-5" />
                </div>
            )
        }
    };

    const renderStatusCell = (cellData: any) => {
        let textColorClass = "";
        if (cellData === "Complete with Success") {
            textColorClass = "text-green-500";
        } else if (cellData === "Inprogress"
            || cellData === 'Comm Group Setup'
            || cellData === 'Enqueue Permutations'
            || cellData === 'Running Permutations'
            || cellData === 'Cleaning Up') {
            textColorClass = "text-yellow-500";
        } else if (cellData === "Complete with Errors") {
            textColorClass = "text-red-500";
        }
        return <span className={`${textColorClass}`}>{cellData}</span>;
    }

    const ERROR_MESSAGES = [
        "There is an error in Processing Customer Rate Plans",
        "No Comm Groups and/or Rate Plans for this Instance",
        "No Rate Plans for this Instance",
        "One or more Rate Plans have invalid Data per Overage Charge or Overage Rate",
        "Optimization Groups and", // Partial check for count message
        "Rate Plans is not enough to run optimization Instance id"
    ];

    const renderAssignRatePlanBtn = (rowIndex: number) => {
        const errorMessage = rowData[rowIndex]?.["error_message"];
        const shouldShowButton = ERROR_MESSAGES.some((msg) =>
            errorMessage?.includes(msg)
        );

        if (shouldShowButton) {
            return (
                <button
                    className='save-btn'
                    onClick={() => openAssignRatePlan(rowIndex)}
                >
                    <span>Assign rate plan</span>
                </button>
            );
        } else {
            return null; // Do not render anything
        }
    };

    const actionOptions = [
        optimizationType === "Customer"
            ? { value: "add-rate", label: "Add customer rate plan" }
            : { value: "add-rate", label: "Add carrier rate plan" },
        { value: "add-service", label: "Add a service line" },
        { value: "push-charges", label: "Push MRC and usage charges" },
    ];

    const renderActionDropdown = (row: any) => {
        const uniqueId = row.iccid;
        const displayValue = IDActionMap?.[uniqueId] || []; // Get the existing value
        const tooltipContent = displayValue.join(", ");
        return (
            <Select
                placeholder="Select Action"
                suffixIcon={
                    <ChevronDownIcon className="w-4 h-4 mt-5 text-gray-600" />
                }
                options={actionOptions}
                style={{ width: "200px" }}
                onChange={(value) => handleActionSelect(value, row)}
                value={tooltipContent}
            ></Select>
        )
    }

    const renderSelectedActions = (row: any) => {
        const uniqueId = row.iccid;
        const displayValue = IDActionMap?.[uniqueId] || []; // Get the existing value
        const tooltipContent = displayValue.join(", ");
        return (
            <Tooltip title={tooltipContent}>
                <span>{tooltipContent}</span>
            </Tooltip>
        );
    }
    const handleSelectAllPushCharges = (checked: boolean) => {
        setSelectAllPushCharges(checked);
        setSelectAll(checked)
        if (checked) {
            const allRowIds = instance_ids_list && instance_ids_list.map((id: any) => id) || []; // Use `id` instead of index
            setSelectedRows(allRowIds);
            setDeselectedRowIds([]);
            setChargesSummaryRows(rowData);
        } else {
            setSelectedRows([]);
            setChargesSummaryRows([]);
            setDeselectedRowIds([]);
        }
       
    };

    const handleRowCheckboxChange = (checked: boolean, rowId: any) => {
        setSelectedRows((prev) => {
            if (checked) {
                return [...prev, rowId];
            } else {
                // If unchecked, add to deselected row IDs
            // Get the current deselected IDs from the store
            const currentDeselectedIds = useOptimizationStore.getState().deselectedRowIds;
            // Update the store with the new deselected ID
            setDeselectedRowIds([...currentDeselectedIds, rowId]);
                return prev.filter((id) => id !== rowId);
            }
        });
    
        let updatedSummaryRows = [...chargesSummaryRows];
        if (checked) {
            // Add the new row data
            updatedSummaryRows = [...updatedSummaryRows, rowData.find((row) => row.instance_id === rowId)];
        } else {
            // Remove the deselected row data
            updatedSummaryRows = updatedSummaryRows.filter((row: any) => row.instance_id !== rowId);
        }
        console.log("updatedSummaryRows",updatedSummaryRows)
        setChargesSummaryRows(updatedSummaryRows);
    
        const allRowsSelected = selectedRows.length === rowData.length;
        setSelectAllPushCharges(allRowsSelected);
    };

    const renderCheckBox = (rowId: any) => {
        return (
            <input
                type="checkbox"
                checked={selectedRows.includes(rowId)}
                onChange={(e) => handleRowCheckboxChange(e.target.checked, rowId)}
                className="transform scale-125 cursor-pointer"
            />
        );
    };


    //For custom cell rendering
    const renderCell = (cellData: any, column: string, rowIndex: number) => {
        if (column === 'progress') {
            return <ProgressBar value={cellData} />;
        }
        if (moduleName === "Push charge errors" &&
            column === "action"
        ) {
            return renderActionDropdown(rowData[rowIndex]);
        }
        if (moduleName === "Review charges" &&
            column === "action"
        ) {
            return renderSelectedActions(rowData[rowIndex]);
        }
        if ((moduleName === "Push charge errors" &&
            column === "push_charges") ||
            (moduleName === "High usage customers" &&
                column === "details_push_charges")
        ) {
            return renderCheckBox(rowData[rowIndex]?.instance_id || 0);
        }
        if (headerMap &&
            (headerMap?.[column]?.[0] === "Session Details" || headerMap?.[column]?.[0] === "Push Charges Details" || headerMap?.[column]?.[0] === "Details") && ((moduleName!=="Central Optimization" && (moduleFeatures.includes("Details-Customer optimization") || moduleFeatures.includes("Details-Carrier optimization"))) || (moduleName==="Central Optimization"))) {
            const progress = rowData[rowIndex]?.progress;
            let isDisabled = false
            let numericData = progress && typeof progress === 'number' ? progress : Number(progress);
            let normalizedValue = 0;

            if (!isNaN(numericData)) {
                normalizedValue = Math.max(0, Math.min(100, numericData));
            }
            if (normalizedValue === 0 || normalizedValue === 100) {
                // isDisabled=false
            } else {
                // isDisabled=true

            }
            // Enable the button unless progress is a valid number and 100
            // Enable the button only if progress is a valid number and equals 100
            isDisabled = !(
                progress !== null && progress !== "None" &&
                progress !== "" &&
                !isNaN(Number(progress)) &&
                Number(progress) === 100);

            return (
                <>
                    {(headerMap?.[column]?.[0] === "Session Details" || headerMap?.[column]?.[0] === "Details") && (
                        <span
                            className={`cursor-pointer text-blue-500 ${(isDisabled ) ? "pointer-events-none text-gray-400" : ""}`}
                            onClick={(!isDisabled) ? () => navigateToDetails(rowIndex) : undefined}
                        >
                            details
                        </span>
                    )}
                    {headerMap?.[column]?.[0] === "Push Charges Details" && (
                        <span
                            className={`cursor-pointer text-blue-500 ${isDisabled || (!rowData[rowIndex]?.push_charge_page) ? "pointer-events-none text-gray-400" : ""}`}
                            onClick={!isDisabled || (!rowData[rowIndex]?.push_charge_page) ? () => navigateToPushCharges(rowIndex) : undefined}
                        >
                            details
                        </span>
                    )}

                </>
            );
        }
        if (moduleName === "Optimization errors" &&
            column === "action") {
            return renderAssignRatePlanBtn(rowIndex)

        }
        if (column === 'run_status') {
            return renderStatusCell(cellData);
        }
        if (column === 'pushed_charges') {
            return renderPushedChargesCol(cellData)
        }
        return (
            <Tooltip
                title={cellData}
                placement="topLeft"
                overlayStyle={{ whiteSpace: 'normal', maxWidth: '60vw', wordWrap: 'break-word', zIndex: 50 }}
                // getPopupContainer={(triggerNode) => (triggerNode.parentNode as HTMLElement) || document.body} // Fallback to document.body
                getPopupContainer={() => document.body} // Render tooltip directly on the body to avoid stacking issues
            >
                <span>{cellData}</span>
            </Tooltip>
        )
        // return cellData;
    };
    if (loading) {
        return (
            <div className="flex justify-center items-center h-screen">
                <Spin size="large" />
            </div>
        );
    }
   

    return (
        <div>
             {/* Show pagination at top right for small screens */}
             {isSmallScreen && visibleColumns.length > 0 && (
                <div className="flex justify-end mb-2 mr-2">
                    <Pagination
                        currentPage={currentPage}
                        totalPages={totalPages}
                        onPageChange={setCurrentPage}
                        moduleName={moduleName} />
                </div>
            )}
            <div className="overflow-x-auto mb-4">
                <div
                    className="overflow-y-auto"
                    style={{
                        height: (moduleName !== "High usage customers" && moduleName !== "Review charges")
                            ? `${viewportHeight - height}px`
                            : "auto" // Apply auto height when moduleName matches
                    }}>
                    <table className="table-auto w-full">
                        <thead className="sticky top-0 bg-gray-200 z-10 table-header-row">
                            <tr>
                                {/* {visibleColumns.length > 0 && (
                                    <th className="px-6 border-b border-gray-300 text-left font-semibold">
                                        S.No
                                    </th>
                                )} */}
                                {(typeof window !== "undefined" && window.innerWidth < 700) && (
                                    <th
                                        className={`px-6 py-3 border-b border-gray-300 text-left font-semibold table-header sticky top-0 freeze-header`}
                                        style={{
                                            cursor: "pointer", position: "sticky", left: 0, zIndex: 11, backgroundColor: "#E5E7EB", minWidth: "40px"
                                        }}>

                                    </th>
                                )}
                                {headers.map((header) => (
                                    headerMap && headerMap[header] && visibleColumns.includes(header) && (
                                        <th
                                            key={header}
                                            className={`px-6 py-3 border-b border-gray-300 text-left font-semibold table-header sticky top-0 ${sortConfig && sortConfig.key === header ? "text-blue-600 active-table-header" : ""
                                                } ${((moduleName === "Carrier optimization" || moduleName === "Customer optimization" || moduleName === "Central Optimization") && header === "session_id")?'freeze-header':''}`}
                                            style={{
                                                cursor: "pointer",
                                                ...((moduleName === "Carrier optimization" || moduleName === "Customer optimization" || moduleName === "Central Optimization") && header === "session_id"
                                                    ? { position: "sticky",  left: (typeof window !== "undefined" && window.innerWidth < 700) ? "40px" : 0, zIndex: 11 }
                                                    : {})
                                            }}
                                            onClick={() => {
                                                headerMap && headerMap[header][0] !== 'Session Details' && headerMap && headerMap[header][0] !== 'Push Charges Details' && headerMap[header][0] !== 'Details' && handleSort(header);
                                            }}
                                        >

                                            {(moduleName === "Push charge errors" && header === "push_charges") || (optimizationType === "Customer" && moduleName === "High usage customers" && header === "details_push_charges") ? (
                                                <input
                                                    type="checkbox"
                                                    className="transform scale-125 cursor-pointer"
                                                    checked={selectAllPushCharges}
                                                    onChange={(e) => handleSelectAllPushCharges(e.target.checked)}
                                                    onClick={(e) => e.stopPropagation()}
                                                />
                                            ) : (
                                                <>
                                                    {/* Display header name */}
                                                    {headerMap?.[header]?.[0] || header}

                                                    {/* Sort icons for headers other than "Details" */}
                                                    {headerMap && headerMap[header][0] !== 'Session Details'&& headerMap[header][0] !== 'Push Charges Details'&& headerMap[header][0] !== 'Details'?
                                                        (sortConfig && sortConfig.key === header ? (
                                                            sortConfig.direction === "ascending" ? (
                                                                <ArrowUpOutlined className="sorting-arrow" style={{ marginLeft: 8, color: "#2563EB" }} />
                                                            ) : (
                                                                <ArrowDownOutlined className="sorting-arrow" style={{ marginLeft: 8, color: "#2563EB" }} />
                                                            )
                                                        ) : (
                                                            <ArrowUpOutlined style={{ marginLeft: 8, opacity: 0.5 }} />
                                                        )
                                                        ) : null}
                                                </>
                                            )}
                                        </th>
                                    )
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {visibleColumns.length > 0 ? (
                                rowData.length > 0 ? (
                                    rowData.map((row, index) => (
                                        <tr
                                            key={index}
                                            className={`
                                                moduleName === "Charge history" &&
                                                    optimizationRow &&
                                                    row.session_id === optimizationRow.session_id
                                                    ? "bg-green-100"
                                                    : ""
                                            ${index % 2 === 0 ? "bg-gray-50 even-table-row" : ""}`}>
                                            {/* {visibleColumns.length > 0 && (
                                                <td className="px-6 border-b border-gray-300 table-cell">
                                                    {(currentPage - 1) * itemsPerPage + index + 1}
                                                </td>
                                            )} */}
                                            {(typeof window !== "undefined" && window.innerWidth < 700) && (
                                                <td
                                                    className={`border-b border-gray-300 table-cell ${index % 2 === 0 ? "even-freeze-cell" : "freeze-cell"}`}
                                                    style={
                                                        { position: "sticky", left: 0, backgroundColor: "white", zIndex: 5 }
                                                    }>
                                                    <Radio
                                                        checked={true}
                                                        onClick={() => {
                                                            setShowRowModal(true);
                                                            setShowRowModalData(row);
                                                        }}
                                                        className="custom-gray-radio"
                                                    />
                                                </td>
                                            )}
                                            {headers.map(
                                                (header, columnIndex) =>
                                                    visibleColumns.includes(header) &&
                                                    headerMap[header] && (
                                                        <td
                                                            key={columnIndex}
                                                            className={`px-6 py-1 border-b border-gray-300 table-cell ${((moduleName === "Carrier optimization" || moduleName === "Customer optimization" || moduleName === "Central Optimization") && header === "session_id")?index % 2 === 0 ? "even-freeze-cell" :"freeze-cell" : ""}`}
                                                            style={{
                                                                ...((moduleName === "Carrier optimization" || moduleName === "Customer optimization" || moduleName === "Central Optimization") && header === "session_id"
                                                                    ? { position: "sticky",  left: (typeof window !== "undefined" && window.innerWidth < 700) ? "40px" : 0, zIndex: 5 }
                                                                    : {})
                                                            }}
                                                        >
                                                            {(header &&
                                                                headerMap?.[header]?.[0] &&
                                                                renderCell(
                                                                    row[header],
                                                                    header,
                                                                    index
                                                                )) ||
                                                                ""}
                                                        </td>
                                                    )
                                            )}
                                        </tr>
                                    ))
                                ) : (
                                    <tr>
                                        <td
                                            colSpan={
                                                headers.filter((header) =>
                                                    visibleColumns.includes(header)
                                                ).length + 1
                                            }
                                            className="px-6 py-3 border-b border-gray-300 text-center text-gray-500"
                                        >
                                            No Records Found
                                        </td>
                                    </tr>
                                )
                            ) : null}
                        </tbody>
                    </table>
                </div>
            </div>
             {/* Show pagination at bottom for larger screens */}
           {(!isSmallScreen && visibleColumns.length > 0) && (
                <div className="flex justify-center mt-5">
                   <Pagination
                        currentPage={currentPage}
                        totalPages={totalPages}
                        onPageChange={setCurrentPage}
                        moduleName={moduleName} />
                </div>
            )}
            

            {detailsOpen &&
                <OptimizationDetails
                    // rowData={detailsRowIndex !== null
                    //     ? rowData[detailsRowIndex]
                    //     : null}
                    rowData={optimizationRow}
                    onClose={()=>{
                        if (current_session_details_active_module === "Optimization") {
                                refreshFetchData();
                            }
                        // refreshFetchData();
                        closeModal()
                    }}
                    isPushchargesOpen={pushChargesOpen} />
            }
            {assignRatePlanOpen &&
                <AssignRatePlanModal
                    rowData={assignRatePlanRowIndex !== null
                        ? rowData[assignRatePlanRowIndex]
                        : null}
                    onClose={closeModal}
                    isOpen={assignRatePlanOpen}
                />
            }
            {isRatePlanModalOpen && (
                optimizationType && optimizationType === "Customer" ?
                    <AddCustomerRatePlan
                        row={actionsRow}
                        isOpen={isRatePlanModalOpen}
                        onClose={() => setIsRatePlanModalOpen(false)}
                    />
                    :
                    <AddCarrierRatePlan
                        row={actionsRow}
                        isOpen={isRatePlanModalOpen}
                        onClose={() => setIsRatePlanModalOpen(false)}
                    />
            )}

            {isServiceLineModalOpen && (
                <AddServiceLine
                    row={actionsRow}
                    visible={isServiceLineModalOpen}
                    onCancel={() => setIsServiceLineModalOpen(false)}
                />
            )}

            {isUsageChargesModalOpen && (
                <UsageCharges
                    row={actionsRow}
                    isOpen={isUsageChargesModalOpen}
                    onClose={() => setIsUsageChargesModalOpen(false)}
                />
            )}
            {showRowModal &&
                <RowDetailsModal
                    row={showRowModalData}
                    headerMap={headerMap}
                    onClose={() => {
                        setShowRowModal(false)
                        setShowRowModalData(null)
                    }}
                    isOpen={showRowModal}
                />
            }
        </div>
    );
};

export default OptimizationTableComponent;
