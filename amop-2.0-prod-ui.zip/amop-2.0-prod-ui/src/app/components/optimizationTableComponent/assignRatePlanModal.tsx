import { Modal, Input, Spin, notification } from 'antd';
import React, { useEffect, useState } from 'react';
import Select from 'react-select';
import { DropdownStyles } from '../css/dropdown';
import axios from 'axios';
import { ENV_ROUTES } from '../routes/route_constants';
import { useAuth } from '../auth_context';
import { useOptimizationStore } from '@/app/stores/optimizationStore';

// Utility function to map strings to select options
const mapToSelectOptions = (options: string[]) =>
    options.map((option) => ({ value: option, label: option }));

interface AssignRatePlanProps {
    rowData: any;
    onClose: () => void; // To close the modal
    isOpen: boolean;
}

const AssignRatePlanModal: React.FC<AssignRatePlanProps> = ({ rowData, onClose, isOpen }) => {
    const [ratePlanOptions, setRatePlanOptions] = useState<string[]>([]);
    const [selectedRatePlan, setSelectedRatePlan] = useState<{ value: string, label: string } | null>(null);
    const [loading, setLoading] = useState(false);
    const { username, partner, role, settabledata, token, selectedDb,metaData, firstLastName,sessionId} = useAuth();
    const { optimizationRow,optimizationType } = useOptimizationStore()
    const [errors, setErrors] = useState<{ [key: string]: string }>({});
    // const [customerRatePlanCode, setSelectedCustomerRatePlanCode] = useState<string>("");
    const messageStyle = {
        fontSize: '14px',
        fontWeight: 'bold',
        padding: '16px',
    };


    const fetchData = async () => {
        setLoading(true);
        try {
            const url = ENV_ROUTES.OPTIMIZATION;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_assign_rate_plan_optimization_dropdown_data",
                role_name: role,
                parent_module: "Optimization",
                module_name: "Optimization",
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                dropdown: "Customer Rate Plan",
                modified_by: firstLastName,
                service_provider: optimizationRow?.service_provider || "",
                optimization_type: optimizationType || ""
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === false) {
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                    onOk: onClose

                });
            } else {
                const ratePlanOptions_ = parsedData?.rate_plan_list_data || []
                setRatePlanOptions(ratePlanOptions_)
            }
        } catch (error) {
            console.error("Error fetching data:", error);
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
                onOk: onClose

            });
        } finally {
            setLoading(false);
        }
    };

    const submitData = async () => {
        setLoading(true);
        const key=optimizationType === "Customer" ? "customer_rate_plan_name": "carrier_rate_plan_name"
        const changedData = {
            [key]: selectedRatePlan?.value ||""
        }
        try {
            const url = ENV_ROUTES.OPTIMIZATION;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/update_optimization_actions_data",
                role_name: role,
                parent_module: "Optimization",
                module_name: "Optimization",
                iccid: rowData?.iccid || "0",
                action: "Assign Rate Plan",
                changed_data: changedData,
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                modified_by: firstLastName,
                service_provider: optimizationRow?.service_provider || "",
                optimization_type: optimizationType || "",
                service_provider_ids: optimizationRow?.service_provider_ids || [],
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === false) {
                Modal.error({
                    title: 'Update Error',
                    content: parsedData.message || 'An error occurred while updating. Please try again.',
                    centered: true,
                    onOk: onClose

                });
            } else {
                // console.log("customerData", parsedData)
                // const carrierOptions_ = parsedData?.rate_plan_list || []
                notification.success({
                    message: 'Success',
                    description: 'Successfully updated!',
                    style: messageStyle,
                    placement: 'top',

                });
                onClose();
            }
        } catch (error) {
            console.error("Error fetching data:", error);
            Modal.error({
                title: 'Update Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while updating. Please try again.',
                centered: true,
                onOk: onClose

            });
        } finally {
            setLoading(false);
        }
    };
    useEffect(() => {
        fetchData()
    }, [isOpen]);

    // Handlers for when an option is selected
    const handleRatePlanChange = (selectedOption: { value: string, label: string } | null) => {
        if (selectedOption) {
            const value = selectedOption
            setSelectedRatePlan(value);
        }

    };
    const handleContinue = () => {
        const newErrors: { [key: string]: string } = {};
        if (!selectedRatePlan) {
            newErrors.selectedRatePlan = "Rate plan is required.";
        }

        setErrors(newErrors);

        // Proceed only if there are no errors
        if (Object.keys(newErrors).length === 0) {
            submitData()
            // console.log("Form submitted successfully!");

        }

    }

    return (
        <Modal
            title="Assign Rate Plan"
            visible={isOpen}
            onCancel={onClose}
            centered
            footer={
                <div className='flex justify-center space-x-4'>
                    <button key="cancel" onClick={onClose} className="cancel-btn">Cancel</button>
                    <button key="update" className="save-btn" onClick={handleContinue}>Update</button>
                </div>
            }
        >
            {loading ? (
                <div className="flex justify-center items-center w-full h-[250px]">
                    <Spin size="large" />
                </div>
            ) : (
                <div className='space-y-3'>
                    <div className="form-group">
                        <label className='field-label'>Customer Name</label>
                        <Input
                            value={rowData?.customer_name || " "}
                            className='non-editable-input'
                        />
                    </div>
                    <div className="form-group">
                        <label className='field-label'>Service Provider</label>
                        <Input
                            value={optimizationRow?.service_provider || ""}
                            className='non-editable-input'
                        />
                    </div>
                    <div className="form-group">
                        <label className="field-label">
                            {optimizationType === "Customer" ? "Customer rate plan" : "Carrier rate plan"}
                            <span className="text-red-500">*</span>
                        </label>
                        <Select
                            options={mapToSelectOptions(ratePlanOptions)}
                            value={selectedRatePlan}
                            onChange={handleRatePlanChange}
                            styles={DropdownStyles}
                        // placeholder="Select Rate Plan"
                        />
                        {errors.selectedRatePlan && <div className="text-red-500 mt-1">{errors.selectedRatePlan}</div>}

                    </div>


                </div>
            )}

        </Modal>
    );
};

export default AssignRatePlanModal;
