import React, { useState, useEffect, useCallback } from 'react';
import { Input, Modal, notification, Spin } from 'antd';
import { useAuth } from '../auth_context';
import OptimizationTableComponent from './page';
import PushChargeDetails from './pushCharges';
import ExportDetailsModal from './detailsExportModal';
import { ArrowDownTrayIcon, ArrowLeftIcon, ArrowPathIcon } from '@heroicons/react/24/outline';
import { ENV_ROUTES } from '../routes/route_constants';
import { getCurrentDateTime } from '../header_constants';
import axios from 'axios';
import TableSearch from '../entire_table_search';
import { useOptimizationStore } from "@/app/stores/optimizationStore";
import InventoryTableComponent from '../inventoryTableComponent/page';
import { useSearchStore } from '@/app/stores/searchStore';
import { LeftOutlined } from '@ant-design/icons';
import ReviewChargesModal from './ReviewChargesModal';

import { useRouter } from 'next/navigation';
import RatePlanUploadModal from './optimizationRatePlanUpload';
import { useSidebarStore } from '@/app/stores/navBarStore';

interface OptimizationDetailsProps {
    rowData: any,
    onClose: () => void; // To close the modal
    isPushchargesOpen: boolean;
}

const customer_headerMap: any = {
    "details_push_charges": [
        "Select",
        "1"
    ],
    "customer_name": [
        "Customer",
        "2"
    ],
    "rev_customer_id": [
        "Account Number",
        "3"
    ],
    "device_count": [
        "Device Count",
        "4"
    ],
    "total_charges": [
        "Total Charge",
        "5"
    ],
    "total_charge_amount": [
        "Charges Pushing from AMOP",
        "6"
    ],
    "sms_charge_total": [
        "SMS charges",
        "7"
    ],
}
const customer_table: any = [
    {
        "id": 1,
        "customer": "Brezeline",
        "device_count": 100,
        "total_charge": "$100",
        "total_charge_amount": "$100"
    }
]
const error_headerMap: any = {
    "rev_customer_id": [
        "Account Number",
        "1"
    ],
    "customer_name": [
        "Customer",
        "2"
    ],
    "msisdn": [
        "MSISDN/TN",
        "3"
    ],
    "iccid": [
        "ICCID/SIM",
        "4"
    ],
    "error_message": [
        "Error",
        "5"
    ],
    "action": [
        "Action",
        "6"
    ]
}
const error_table: any = [
    {
        "id": 1,
        "customer": "Brezeline",
        "account_number": "1001919131",
        "msisdn_tn": "3998989799",
        "iccid": "12423568690",
        "error": "No rate plan",
        "action": "12423568690"
    },
    {
        "id": 1,
        "customer": "Brezeline",
        "account_number": "1001919131",
        "msisdn_tn": "3998989799",
        "iccid": "12423568690",
        "error": "None",
        "action": "12423568690"
    }
]

const messageStyle = {
    fontSize: "14px",
    fontWeight: "bold",
    padding: "16px",
};
const OptimizationDetails: React.FC<OptimizationDetailsProps> = ({ rowData, onClose, isPushchargesOpen }) => {
    // State for form fields
    const [sessionId, setSessionId] = useState<string>(rowData?.session_id || '');
    const [runDate, setRunDate] = useState<string>(rowData?.run_start_time || '');
    const [runEndDate, setRunEndDate] = useState<string>(rowData?.optimization_run_end_time || '');
    const [totalCharges, setTotalCharges] = useState<string>(rowData?.total_charges || '');
    const [serviceProvider, setServiceProvider] = useState<string>(rowData?.service_provider || "");
    const [chargesFromAMOP, setChargesFromAMOP] = useState<string>(rowData?.total_charge_amount || "");
    const [deviceCount, setDeviceCount] = useState<string>(rowData?.device_count || "");
    const [cycleDateRange, setCycleDateRange] = useState<string>(rowData?.billing_period_duration || "");
    const { username, partner, role, token, selectedDb,metaData, firstLastName, sessionId: sessionID, settabledata } = useAuth();
    const { setOptimizationErrorsData, setOptimizationErrorsPagination } = useSearchStore();
    const [customersVisibleColumns, setCustomersVisibleColumns] = useState<string[]>([]);
    const [customersPagination, setCustomersPagination] = useState<any>(null);
    const [customersTableData, setCustomersTableData] = useState<any>([]);
    const [customersHeaders, setCustomersHeaders] = useState<any[]>([]);
    const [customersHeaderMap, setCustomersHeaderMap] = useState<any>({});

    const [errorsVisibleColumns, setErrorsVisibleColumns] = useState<string[]>([]);
    const [errorsPagination, setErrorsPagination] = useState<any>(null);
    const [errorsTableData, setErrorsTableData] = useState<any>([]);
    const [errorsHeaders, setErrorsHeaders] = useState<any[]>([]);
    const [errorsHeaderMap, setErrorsHeaderMap] = useState<any>({});
    const [loading, setLoading] = useState(false);
    const [exportModalOpen, setExportModalOpen] = useState(false);

    const [pushChargesOpen, setPushChargesOpen] = useState(false);
    const [customerSearchTerm, setCustomerSearchTerm] = useState("");
    const [errorsSearchTerm, setErrorsSearchTerm] = useState("");
    const [exportLoading, setExportLoading] = useState(false);
    const { setOptimizationRow, optimizationType, chargesSummaryRows, setChargesSummaryRows, setSelectAll } = useOptimizationStore()
    const [isPushChargesEnabled, setIsPushChargesEnabled] = useState(false);
    const [pushChargesSummaryOpen, setPushChargesSummaryOpen] = useState(false);
    const [isRatePlanUploadOpen, setIsRatePlanUploadOpen] = useState(false);

    //assignments count variables
    const [assignmentsQueued, setAssignmentsQueued] = useState(0);
    const [assignmentsPushed, setAssignmentsPushed] = useState(0);
    const [refreshLoading, setRefreshLoading] = useState(false);
    const [instanceIDsList, setInstanceIdsList] = useState<any[]>([]);
    const [assignmentsError, setAssignMentsError] = useState(false);
    const [buttonStatus, setButtonStatus] = useState(false);

    const isExpanded = useSidebarStore((state: any) => state.isExpanded);
    const current_session_details_active_module = localStorage.getItem("current_session_details_active_module");

    console.log("rowdata",rowData)
    let partner_name=partner
      let db_name_=selectedDb
    if (current_session_details_active_module !== "Optimization") {
      partner_name=rowData?.tenant || partner
      db_name_=rowData?.db_name || selectedDb
    }

    const router = useRouter();

    type HeaderMap = Record<string, [string, number]>;

    const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
        const entries = Object.entries(headerMap) as [string, [string, number]][];
        entries.sort((a, b) => a[1][1] - b[1][1]);
        return Object.fromEntries(entries) as HeaderMap;
    }, []);


    const fetchData = useCallback(async () => {
        settabledata([])
        setChargesSummaryRows([])
        setSelectAll(false)
        setOptimizationErrorsData([])
        setOptimizationErrorsPagination(null)
        setLoading(true);
        setInstanceIdsList([])
        try {
            const url = ENV_ROUTES.OPTIMIZATION;
            const data = {
                tenant_name: partner_name || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_optimization_row_details",
                role_name: role,
                parent_module: "Optimization",
                module_name: "Optimization",
                feature_module_name: "Optimization",
                optimization_type: optimizationType,
                request_received_at: getCurrentDateTime(),
                Partner: partner_name,
                access_token: token,
                db_name: db_name_,
                sessionID: sessionID,

                session_id: rowData?.session_id || '',
                start: 0,
                end: 10,
                fetch_type: "both"
            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                const pagination = parsedData?.pages || { start: 1, end: 1, high_usage_total: 1, error_details_total: 1 }
                const customer_pagination = {
                    start: pagination?.start || 1,
                    end: pagination?.end || 1,
                    total: pagination?.high_usage_total || 1
                }
                const error_pagination = {
                    start: pagination?.start || 1,
                    end: pagination?.end || 1,
                    total: pagination?.error_details_total || 1
                }
                setCustomersPagination(customer_pagination)
                setErrorsPagination(error_pagination)
                const customer_table = parsedData?.high_usage_customers_data || []
                const error_table = parsedData?.error_details || []
                setCustomersTableData(customer_table)

                const instance_ids = parsedData?.instance_ids || []
                setInstanceIdsList(instance_ids)
                // if (error_table.length>0 &&error_table[0]) {
                //     error_table[0].error_message = "No rate plan";
                // }
                setErrorsTableData(error_table)
            }
            // addLog('BulkChange Table Data Processing Data Completed');
        } catch (error) {
            console.error("Error fetching data:", error);
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        } finally {
            setLoading(false);
        }
    }, [username, partner, role, token]);

    const fetchAssignmentsCount = useCallback(async () => {
        try {
            setRefreshLoading(true)
            const url = ENV_ROUTES.OPTIMIZATION;
            const data = {
                tenant_name: partner_name || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/rate_plan_progress",
                role_name: role,
                parent_module: "Optimization",
                module_name: "Optimization",
                optimization_type: optimizationType,
                request_received_at: getCurrentDateTime(),
                Partner: partner_name,
                access_token: token,
                db_name: db_name_,
                sessionID: sessionID,
                instance_id: rowData?.instance_id || '',
                service_provider_id: rowData?.service_provider_id || '',
                optimization_list_view_id: rowData?.id || '',
            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                // Modal.error({
                //     title: 'Data Fetch Error',
                //     content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                //     centered: true,
                // });
            } else {
                const assignments_queued = parsedData?.assignments_queued || '0'
                setAssignmentsQueued(assignments_queued)
                const assignments_pushed_to_carrier = parsedData?.assignments_pushed_to_carrier 
                ? Number(parsedData.assignments_pushed_to_carrier) 
                : 0;
                setAssignmentsPushed(assignments_pushed_to_carrier)
                const is_disable = parsedData.flag
                setButtonStatus(is_disable)
                if ((assignments_queued !== assignments_pushed_to_carrier) && assignments_pushed_to_carrier > 0 && assignments_queued > 0) {
                    setAssignMentsError(true)
                }
                else {
                    setAssignMentsError(false)
                }
            }
            // addLog('BulkChange Table Data Processing Data Completed');
        } catch (error) {
            console.error("Error fetching data:", error);
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        } finally {
            setRefreshLoading(false)
        }
    }, [username, partner, role, token]);

    // const fetchDataFlag = useCallback(async () => {
    //     // settabledata([])
    //     // setOptimizationErrorsData([])
    //     // setOptimizationErrorsPagination(null)
    //     setLoading(true);
    //     try {
    //         const url = ENV_ROUTES.OPTIMIZATION;
    //         const data = {
    //             tenant_name: partner || "default_value",
    //             username: username,
    //             firstLastName: firstLastName,
    //             path: "/get_push_charges_status",
    //             role_name: role,
    //             parent_module: "Optimization",
    //             module_name: "Optimization",
    //             feature_module_name: "Optimization",
    //             optimization_type: optimizationType,
    //             request_received_at: getCurrentDateTime(),
    //             Partner: partner,
    //             access_token: token,
    //             db_name: selectedDb,
        // ... metaData,
    //             session_id: rowData?.session_id || '',
    //             start: 0,
    //             end: 10,
    //             fetch_type: "both"
    //         };
    //         const response = await axios.post(url, { data });
    //         const parsedData = JSON.parse(response.data.body);
    //         if (parsedData.flag === false) {
    //             Modal.error({
    //                 title: 'Data Fetch Error',
    //                 content: parsedData.message || 'An error occurred while fetching data. Please try again.',
    //                 centered: true,
    //             });
    //         } else {

    //             if (parsedData?.push_charges_button_status !== undefined) {
    //                 setIsPushChargesEnabled(parsedData.push_charges_button_status);
    //             }
    //         }
    //         // addLog('BulkChange Table Data Processing Data Completed');
    //     } catch (error) {
    //         console.error("Error fetching data:", error);
    //         Modal.error({
    //             title: 'Data Fetch Error',
    //             content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
    //             centered: true,
    //         });
    //     } finally {
    //         setLoading(false);
    //     }
    // }, []);

    // Effect to handle rowData changes (if required)
    useEffect(() => {
        // setOptimizationRow(rowData || {})
        const customers_sortedheaderMap = sortHeaderMap(customer_headerMap)
        setCustomersHeaderMap(customers_sortedheaderMap)
        const customers_headers_ = Object.keys(customers_sortedheaderMap).length > 0 ? Object.keys(customers_sortedheaderMap) : []
        setCustomersHeaders(customers_headers_)
        setCustomersVisibleColumns(customers_headers_)

        let errors_sortedheaderMap: any
        if (optimizationType === "Carrier") {
            const filteredHeaderMap = Object.keys(error_headerMap)
                .filter(key => key !== "rev_customer_id" && key !== "customer_name")
                .reduce((acc, key) => {
                    acc[key] = error_headerMap[key];
                    return acc;
                }, {} as any);

            errors_sortedheaderMap = sortHeaderMap(filteredHeaderMap);
            setErrorsHeaderMap(errors_sortedheaderMap);
        } else {
            errors_sortedheaderMap = sortHeaderMap(error_headerMap);
            setErrorsHeaderMap(errors_sortedheaderMap);
        }
        const errors_headers_ = Object.keys(errors_sortedheaderMap).length > 0 ? Object.keys(errors_sortedheaderMap) : []
        setErrorsHeaders(errors_headers_)
        setErrorsVisibleColumns(errors_headers_)
        // fetchData()

    }, [rowData]);

    useEffect(() => {
        fetchData()
        // fetchDataFlag()
        fetchAssignmentsCount()
    }, [fetchData]);

    // Prevent body scrolling when the modal is open
    useEffect(() => {
        document.body.style.overflow = 'hidden'; // Disable scrolling

        return () => {
            document.body.style.overflow = ''; // Cleanup: Enable scrolling when modal closes
        };
    }, []);


    useEffect(() => {
        console.log()
        if (isPushchargesOpen) {
            setPushChargesOpen(true)
        }
    }, [isPushchargesOpen]);

    const navigateToPushCharges = () => {
        setPushChargesOpen(true)
    }
    const closeModal = () => {
        setPushChargesOpen(false)
        fetchData()
    }


    //Export functionality for carrier

    const openExportModal = () => {
        setExportModalOpen(true)
    }
    const closeExportModal = () => {
        setExportModalOpen(false)
    }

    const handleOptTypeBasedExport = () => {
        if (optimizationType === "Carrier") {
            handleExport()
        }
        else {
            openExportModal()
        }
    }

    const pollExportStatus = async () => {
        try {

            const export_url = ENV_ROUTES.OPTIMIZATION;
            const export_data = {
                tenant_name: partner_name || "default_value",
                username,
                path: "/get_export_status",
                role_name: role,
                parent_module: "Optimization",
                module_name: optimizationType,
                request_received_at: getCurrentDateTime(),
                Partner: partner_name,
                access_token: token,
                db_name: db_name_,
                sessionID: sessionId,
            };

            const export_response = await axios.post(export_url, { data: export_data });
            const export_parsedData = JSON.parse(export_response.data.body);

            if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
                const s3Url = export_parsedData?.export_status_data?.url || null;
                if (s3Url) {
                    window.location.href = s3Url;
                    notification.success({
                        message: "Success",
                        description: "Successfully exported!",
                        style: messageStyle,
                        placement: "top",
                    });
                } else {
                    Modal.error({
                        title: "Export Error",
                        content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
                        centered: true,
                    });
                }
                return true; // Stop polling
            }

            if (export_parsedData?.export_status_data?.status_flag === "Failure") {
                Modal.error({
                    title: "Export Error",
                    content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
                    centered: true,
                });
                return true; // Stop polling
            }

            return false; // Continue polling
        } catch (error) {
            // Modal.error({
            //     title: "Export Error",
            //     content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
            //     centered: true,
            // });
            return true; // Stop polling
        }
    };
    const startPolling = async () => {
        let isPollingComplete = false;

        while (!isPollingComplete) {
            isPollingComplete = await pollExportStatus();
            if (!isPollingComplete) {
                await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
            }
        }
    };

    const handleExport = async () => {
        setExportLoading(true);
        try {
            const url = ENV_ROUTES.OPTIMIZATION;
            const data = {
                tenant_name: partner_name || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_optimization_details_reports_data",
                role_name: role,
                parent_module: "Optimization",
                module_name: "Optimization",
                optimization_type: optimizationType,
                request_received_at: getCurrentDateTime(),
                Partner: partner_name,
                access_token: token,
                db_name: db_name_,
                sessionID: sessionId,
                session_id: rowData?.session_id || '',
                report_type: "All Reports",
                errors: errorsTableData.length === 0 ? "false" : "true"
            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === true) {
                await startPolling();

            } else {
                await startPolling();
            }

        } catch (error) {
            await startPolling();
        } finally {
            setExportLoading(false);
        }
    };
    const closePushChargesSummary = () => {
        // setChargesSummaryRows([])
        setPushChargesSummaryOpen(false)
        setPushChargesOpen(false)
        // setSelectAll(false)
    }

    const navigateToChargeHistory = () => {
        router.push(`/optimization/charge_history`);
    }

    const openPushChargesSummary = () => {
        if (chargesSummaryRows.length === 0) {
            notification.error({
                message: "Validation Error",
                description: "Select rows to continue",
                placement: "top",
            });

            // Modal.error({
            //   title: "Validation Error",
            //   content:"Select rows which have actions performed.",
            //   centered: true,
            // });
            return;
        }
        setPushChargesSummaryOpen(true);
    }

    const openRatePlanUpload = () => {
        setIsRatePlanUploadOpen(true)
    }
    const closeRatePlanUpload = () => {
        setIsRatePlanUploadOpen(false)
        fetchAssignmentsCount()
    }

    const refreshFetchData = useCallback(async () => {
        settabledata([])
          setLoading(true);
        try {
          console.log("setLoading", loading)
          const url = ENV_ROUTES.OPTIMIZATION;
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/get_optimization_data",
            role_name: role,
            parent_module: "Optimization",
            module_name: "Optimization",
            feature_module_name: "Optimization",
            optimization_type: "Customer",
            mod_pages: {
              start: 0,
              end: 100,
            },
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
        ... metaData,
            sessionID: sessionId,
          };
          const response = await axios.post(url, { data });
          const parsedData = JSON.parse(response.data.body);
          if (parsedData.flag === false) {
            Modal.error({
              title: 'Data Fetch Error',
              content: parsedData.message || 'An error occurred while fetching data. Please try again.',
              centered: true,
            });
          } else {
            const headersMap_ = parsedData?.headers_map?.["Customer"]?.header_map || {}
            const tableData_ = parsedData?.data || []
            settabledata(tableData_)
          }
          // addLog('BulkChange Table Data Processing Data Completed');
        } catch (error) {
          console.error("Error fetching data:", error);
          Modal.error({
            title: 'Data Fetch Error',
            content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
            centered: true,
          });
        } finally {
          setLoading(false); // Only stop loading for the first call
        }
      }, [username, partner, role, token]);

    return (
        <div className="optimization-modal-overlay">
            <div className="optimization-modal-content">
                {loading ? (
                    <div className="flex justify-center items-center h-screen">
                        <Spin size="large" />
                    </div>
                ) : (
                    <>
                        <div className=' flex flex-col items-end md:flex-row md:items-center md:justify-between'>
                            <div className='flex space-x-2 mb-4'>
                                <button className="border-none flex mr-2" onClick={onClose}>
                                    <ArrowLeftIcon className="h-5 w-5 text-black-500 mr-2" />
                                    <span>Back</span>
                                </button>
                                <span className='text-[16px] font-600'>
                                    <strong>Session ID: </strong>{sessionId}
                                </span>
                                {/* <button
                                    className='border-none text-blue-500 bg-transparent'
                                    onClick={onClose}>
                                    Session {sessionId}
                                </button>
                                <span className='mt-2.5'>&gt;</span>
                                <button
                                    className='border-none text-blue-500 bg-transparent'>
                                    Optimization Details
                                </button> */}
                            </div>
                            <div>
                                <div className="flex gap-4">
                                    {/* {optimizationType !== "Carrier" && (
                                        <div className="flex flex-col items-start">
                                            <button
                                                className="save-btn"
                                                onClick={navigateToPushCharges}
                                                // disabled={!isPushChargesEnabled}
                                            >
                                                Push Charges
                                            </button>

                                        </div>
                                    )} */}
                                    {optimizationType === "Carrier" && (
                                        <div className="flex flex-col items-start">  {/* Added flex-col to stack children vertically */}
                                            <button
                                                className={(assignmentsPushed > 0 || assignmentsQueued>0)?"cancel-btn cursor-not-allowed":"save-btn"}
                                                onClick={openRatePlanUpload}
                                                disabled={assignmentsPushed>0 || assignmentsQueued>0}
                                            >
                                                Rate Plan Upload
                                            </button>

                                        </div>
                                    )}
                                    <button className="save-btn" onClick={handleOptTypeBasedExport}>
                                        <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                                        <span>Export</span>
                                    </button>
                                </div>
                                {/* {!isPushChargesEnabled && (
                                    <div className="export-processing-div mt-2">
                                        Sync is in progress...
                                    </div>
                                )} */}

                            </div>
                        </div>
                        <div>

                            <span className='font-semibold  mb-4 mt-2 text-[16px] block'>Session Details</span>
                            <div className="mb-6 flex grid grid-cols-1 gap-4 md:grid-cols-2 md:gap-4 lg:grid-cols-3 lg:gap-6">
                                <div>
                                    <label className='field-label'>Session ID</label>
                                    <Input
                                        className='non-editable-input'
                                        value={sessionId}
                                    // onChange={(e) => setSessionId(e.target.value)} 
                                    />
                                </div>
                                <div>
                                    <label className='field-label'>Run Start Date</label>
                                    <Input
                                        className='non-editable-input'
                                        value={runDate}
                                    // onChange={(e) => setRunDate(e.target.value)}
                                    />
                                </div>
                                <div>
                                    <label className='field-label'>Run End Date</label>
                                    <Input
                                        className='non-editable-input'
                                        value={runEndDate}
                                    // onChange={(e) => setRunDate(e.target.value)}
                                    />
                                </div>
                                <div>
                                    <label className='field-label'>Service Provider</label>
                                    <Input
                                        className='non-editable-input'
                                        value={serviceProvider}
                                    // onChange={(e) => setServiceProvider(e.target.value)}
                                    />
                                </div>

                                <div>
                                    <label className='field-label'>Total Charges</label>
                                    <Input
                                        className='non-editable-input'
                                        value={totalCharges}
                                    // onChange={(e) => setTotalCharges(e.target.value)} 
                                    />
                                </div>


                                {optimizationType !== "Carrier" && (
                                    <div>
                                        <label className='field-label'>Charges Pushing from AMOP</label>
                                        <Input
                                            className='non-editable-input'
                                            value={chargesFromAMOP}
                                        // onChange={(e) => setChargesFromAMOP(e.target.value)}
                                        />
                                    </div>
                                )}
                                {optimizationType !== "Carrier" ? (
                                    <>
                                        <div>
                                            <label className='field-label'>Cycle Date Range</label>
                                            <Input
                                                className='non-editable-input'
                                                value={cycleDateRange}
                                            // onChange={(e) => setDeviceCount(e.target.value)}
                                            />
                                        </div>

                                        <div>
                                            <label className='field-label'>Device Count</label>
                                            <Input
                                                className='non-editable-input'
                                                value={deviceCount}
                                            // onChange={(e) => setDeviceCount(e.target.value)}
                                            />
                                        </div></>
                                ) : (
                                    <>
                                        <div>
                                            <label className='field-label'>Device Count</label>
                                            <Input
                                                className='non-editable-input'
                                                value={deviceCount}
                                            // onChange={(e) => setDeviceCount(e.target.value)}
                                            />
                                        </div>
                                        <div>
                                            <label className='field-label'>Cycle Date Range</label>
                                            <Input
                                                className='non-editable-input'
                                                value={cycleDateRange}
                                            // onChange={(e) => setDeviceCount(e.target.value)}
                                            />
                                        </div>

                                    </>
                                )}



                                {optimizationType === "Carrier" && (
                                    <div>
                                        <label className="field-label">Assignments Queued</label>
                                        <div className="relative flex justify-center space-x-2">
                                            <Input
                                                type="text"
                                                className="non-editable-input pr-10" // Add padding to make space for the icon inside the input
                                                value={assignmentsQueued || ""}
                                                readOnly
                                            />
                                        </div>
                                        {assignmentsError &&
                                            <div className='sync-progress-div'>
                                                <span>Sync is in Progress</span>
                                            </div>}
                                    </div>
                                )}
                                {optimizationType === "Carrier" && (
                                    <div>
                                        <label className="field-label">Assignments Pushed to Carrier</label>
                                        <div className="relative flex justify-center space-x-2">
                                            <Input
                                                type="text"
                                                className="non-editable-input pr-10" // Add padding to make space for the icon inside the input
                                                value={assignmentsPushed || 0}
                                                readOnly
                                            />

                                            <span
                                                onClick={fetchAssignmentsCount}
                                                className="absolute inset-y-0 right-0 pr-3 flex items-center cursor-pointer"
                                            >
                                                {refreshLoading ? (
                                                    <div className="h-5 w-5 border-2 border-gray-500 border-t-transparent rounded-full animate-spin"></div>
                                                ) : (
                                                    <ArrowPathIcon className="h-5 w-5 text-gray-500" />
                                                )}
                                            </span>
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>

                        {optimizationType !== "Carrier" && (
                            <div>
                                {optimizationType === "Customer" && (
                                    <div className="flex justify-end items-center mb-2">
                                        {/* <span className="font-semibold  mb-4 mt-2 text-[18px] block">
                                            Push Charge Errors
                                        </span> */}
                                        <button
                                            className="save-btn"
                                            onClick={openPushChargesSummary}
                                        // disabled={!isPushChargesEnabled}
                                        >Push Charges</button>
                                    </div>
                                )
                                }

                                <div className="flex justify-between">
                                    <span className='font-semibold  mb-4 mt-2 text-[18px] block'>Customer Charges</span>
                                    <div className="flex justify-end mb-2">
                                        <TableSearch
                                            searchTerm={customerSearchTerm}
                                            setSearchTerm={setCustomerSearchTerm}
                                            tableName={"optimization_instance_summary"}
                                            headerMap={customersHeaderMap}
                                        />
                                    </div>

                                </div>
                                <OptimizationTableComponent
                                    headers={customersHeaders}
                                    headerMap={customersHeaderMap}
                                    initialData={customersTableData}
                                    visibleColumns={customersVisibleColumns}
                                    itemsPerPage={10}
                                    moduleName="High usage customers"
                                    pagination={customersPagination}
                                    searchQuery={customerSearchTerm}
                                    instance_ids_list={instanceIDsList}
                                />
                            </div>
                        )}
                        <div>
                            <div className="flex justify-between">
                                <span className='font-semibold  mb-4 mt-4 text-[18px] block'>Optimization Errors</span>
                                <TableSearch
                                    searchTerm={errorsSearchTerm}
                                    setSearchTerm={setErrorsSearchTerm}
                                    tableName={"optimization_error_details"}
                                    headerMap={errorsHeaderMap}
                                />
                            </div>

                            <InventoryTableComponent
                                headers={errorsHeaders}
                                headerMap={errorsHeaderMap}
                                initialData={errorsTableData}
                                visibleColumns={errorsVisibleColumns}
                                itemsPerPage={10}
                                popupHeading="Optimization errors"
                                pagination={errorsPagination}
                                searchQuery={errorsSearchTerm}
                            />

                        </div>
                    </>
                )}

            </div>
            {pushChargesOpen &&
                <div className={`fullscreen-modal left-0 ${isExpanded
                    ? " left-[250px] "
                    : "lg:left-[70px] left-[0px]"
                }}`}>
                    <PushChargeDetails
                        isOpen={pushChargesOpen}
                        rowData={rowData}
                        navigateToDetails={() => {
                            if (current_session_details_active_module === "Optimization") {
                                refreshFetchData();
                            }
                            (isPushchargesOpen ? onClose : closeModal)();
                          }}
                        navigateToListView={onClose}
                        errorLength={errorsTableData && errorsTableData.length || 0} />
                </div>
            }

            {exportModalOpen &&
                <ExportDetailsModal
                    isOpen={exportModalOpen}
                    rowData={rowData}
                    onClose={closeExportModal}
                    setLoading={setExportLoading}
                    errorsLength={errorsTableData && errorsTableData.length || 0} />
            }
            {pushChargesSummaryOpen &&
                <ReviewChargesModal
                    isOpen={pushChargesSummaryOpen}
                    rowData={rowData}
                    onClose={closePushChargesSummary}
                    moduleName="High usage customers"
                    instance_ids_list={instanceIDsList}
                    onSuccess={navigateToPushCharges}
                />
            }
            {isRatePlanUploadOpen &&
                <RatePlanUploadModal
                    isOpen={isRatePlanUploadOpen}
                    onClose={closeRatePlanUpload}
                />
            }
            {exportLoading && (
                <div className="opt-details-export-processing-div">
                    Export Processing...
                </div>
            )}
        </div>
    );
};

export default OptimizationDetails;
