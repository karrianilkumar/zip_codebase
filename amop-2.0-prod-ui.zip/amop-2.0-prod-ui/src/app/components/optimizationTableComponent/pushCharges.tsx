import { ArrowDownTrayIcon, ArrowLeftIcon, ArrowPathIcon, ChevronDownIcon } from "@heroicons/react/24/outline";
import { Input, Modal, notification, Select, Spin } from "antd";
import React, { useCallback, useEffect, useState } from "react";
import OptimizationTableComponent from "./page";
import { ENV_ROUTES } from "../routes/route_constants";
import { getCurrentDateTime } from "../header_constants";
import { useAuth } from "../auth_context";
import axios from "axios";
import ExportDetailsModal from "./detailsExportModal";
import TableSearch from "../entire_table_search";
import ReviewChargesModal from "./ReviewChargesModal";
import { useOptimizationStore } from "@/app/stores/optimizationStore";

import { useRouter } from 'next/navigation';

interface PushChargeErrorRow {
  customerAccountNumber: string;
  customer: string;
  msisdnTn: string;
  iccidSimId: string;
  status: string;
  error: string;
  amount: string;
  isChecked: boolean;
}

interface PushChargesProps {
  rowData: any;
  isOpen: boolean;
  navigateToDetails: () => void;
  navigateToListView: () => void;
  errorLength: any
}

const push_charge_headerMap: any = {
  rev_customer_id: ["Customer account number", "1"],
  customer_name: ["Customer", "2"],
  msisdn: ["MSISDN/TN", "3"],
  iccid: ["ICCID/SIM#", "4"],
  // run_status: ["Status", "5"],
  error_message: ["Error", "6"],
  action: ["Action", "7"],
  total_charge_amount: ["Amount", "8"],
  push_charges: ["Push charges", "9"],
};

const push_charge_table: any = [
  {
    id: 1,
    rev_customer_id: 325234656,
    customer_name: "Autogrid",
    msisdn: 399899897,
    iccid: 124239587348,
    run_status: "Active",
    error_message: "No service",
    action: "",
    total_charge_amount: "$0.83",
    push_charges: false,
  },
  {
    id: 2,
    rev_customer_id: 467234656,
    customer_name: "Autogrid",
    msisdn: 399899898,
    iccid: 124239587349,
    run_status: "In active",
    error_message: "No service",
    action: "",
    total_charge_amount: "$0.60",
    push_charges: false,
  },
];

const PushChargeDetails: React.FC<PushChargesProps> = ({
  rowData,
  navigateToDetails,
  navigateToListView,
  isOpen,
  errorLength
}) => {
  const [pushErrorsVisibleColumns, setPushErrorsVisibleColumns] = useState<
    string[]
  >([]);
  const [pushErrorsPagination, setPushErrorsPagination] = useState<any>({});
  const [pushErrorsTableData, setPushErrorsTableData] = useState<any>([]);
  const [pushErrorsHeaders, setPushErrorsHeaders] = useState<any[]>([]);
  const [pushErrorsHeaderMap, setPushErrorsHeaderMap] = useState<any>({});
  const [exportModalOpen, setExportModalOpen] = useState(false);
  const [pushChargesSummaryOpen, setPushChargesSummaryOpen] = useState(false);
  const [errorsSearchTerm, setErrorsSearchTerm] = useState("");
  const [exportLoading, setExportLoading] = useState(false);
  const { username, partner, role, token, selectedDb,metaData, firstLastName, sessionId } = useAuth();
  const { setChargesSummaryRows, setIDActionMap, chargesSummaryRows, IDActionMap, setSelectAll } = useOptimizationStore()
  const [loading, setLoading] = useState(false);

  //push charges count variables
  const router = useRouter();

  const [remainingChargeCount, setRemainingChargeCount] = useState('0');
  const [pushChargeCount, setPushChargeCount] = useState('0');
  const [totalUsageCharges, setTotalUsageCharges] = useState('0');
  const [totalSMSCharges, setTotalSMSCharges] = useState('0');
  const [chargeHistoryDisable, setChargeHistoryDisable] = useState(true);
  const [refreshLoading, setRefreshLoading] = useState(false);
  const [instanceIDsList, setInstanceIdsList] = useState<any[]>([]);
  const [ICCIDsList, setICCIdsList] = useState<any[]>([]);
  const [cycleDateRange, setCycleDateRange] = useState<string>(rowData?.billing_period_duration || "");
  const [serviceProvider, setServiceProvider] = useState<string>(rowData?.service_provider || "");

  type HeaderMap = Record<string, [string, number]>;
  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);

  const checkChargesCount = (value: any) => {
    let numericData = value && typeof value === 'number' ? value : Number(value);
    let normalizedValue = 0;

    if (!isNaN(numericData)) {
      normalizedValue = Math.max(0, Math.min(100, numericData));
    }
    if (normalizedValue === 0) {
      setChargeHistoryDisable(false)
    } else {
      setChargeHistoryDisable(true)
    }

  }

  const fetchRemainingChargesCount = useCallback(async () => {
    try {
      setRefreshLoading(true)
      const url = ENV_ROUTES.OPTIMIZATION;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_push_charges_count",
        role_name: role,
        parent_module: "Optimization",
        module_name: "Optimization",
        feature_module_name: "Optimization",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        optimization_session_id: rowData?.id || '',
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        // Modal.error({
        //     title: 'Data Fetch Error',
        //     content: parsedData.message || 'An error occurred while fetching data. Please try again.',
        //     centered: true,
        // });
      } else {
        const remaining_count = parsedData?.remaining_push_charges_count || '0'
        setRemainingChargeCount(remaining_count)
        const charges_count = parsedData?.no_of_charges_to_push || '0'
        setTotalUsageCharges(parsedData?.total_usage_charges_20)
        setTotalSMSCharges(parsedData?.total_sms_charges)
        setPushChargeCount(charges_count)
        checkChargesCount(remaining_count)
      }
      // addLog('BulkChange Table Data Processing Data Completed');
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      setRefreshLoading(false)
    }
  }, [username, partner, role, token]);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.OPTIMIZATION;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_optimization_push_charges_data",
        role_name: role,
        parent_module: "Optimization",
        module_name: "Optimization",
        feature_module_name: "Optimization",
        optimization_type: "Customer",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        session_id: rowData?.session_id || '',
        start: 0,
        end: 10,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        const pagination = parsedData?.pages || { start: 1, end: 1, total_count: 1 }
        const errors_pagination = {
          start: pagination?.start || 1,
          end: pagination?.end || 1,
          total: pagination?.total_count || 1
        }
        setPushErrorsPagination(errors_pagination)
        const customer_table = parsedData?.push_charges_data || []
        setPushErrorsTableData(customer_table)

        const instance_ids = parsedData?.instance_ids || []
        setInstanceIdsList(instance_ids)
        const iccids = parsedData?.iccids || []
        setICCIdsList(iccids)
      }
      // addLog('BulkChange Table Data Processing Data Completed');
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  }, [username, partner, role, token]);

  // Effect to handle rowData changes (if required)
  useEffect(() => {
    const errors_sortedheaderMap = sortHeaderMap(push_charge_headerMap);
    setPushErrorsHeaderMap(errors_sortedheaderMap);
    const errors_headers_ =
      Object.keys(errors_sortedheaderMap).length > 0
        ? Object.keys(errors_sortedheaderMap)
        : [];
    setPushErrorsHeaders(errors_headers_);
    setPushErrorsVisibleColumns(errors_headers_);
    fetchData()
    fetchRemainingChargesCount()
    setChargesSummaryRows([])
    setSelectAll(false)
    setIDActionMap({})
  }, [isOpen]);




  const openExportModal = () => {
    setExportModalOpen(true)
  }
  const closeExportModal = () => {
    setExportModalOpen(false)
  }

  const openPushChargesSummary = () => {
    const invalidRow = chargesSummaryRows.find((row: any) => !(row.iccid in IDActionMap));

    if (chargesSummaryRows.length === 0) {
      notification.error({
        message: "Validation Error",
        description: "Select rows to continue",
        placement: "top",
      });

      // Modal.error({
      //   title: "Validation Error",
      //   content:"Select rows which have actions performed.",
      //   centered: true,
      // });
      return;
    }
    if (invalidRow) {

      Modal.confirm({
        title: "Validation Error",
        content: "No actions are performed do you want to continue?",
        okText: "Yes",
        cancelText: "No",
        centered: true,
        onOk: () => {
          setPushChargesSummaryOpen(true);
        },
        onCancel: () => {
          // Optional: Add any action on cancel if needed
        },
      });
      return;
    }

    setPushChargesSummaryOpen(true);
  }
  const closeParentModalOnSuccess = () => {
    navigateToDetails()
    //  console.log('closeParentModalOnSuccess',navigateToDetails)

  }
  const closePushChargesSummary = () => {
    // setChargesSummaryRows([])
    setPushChargesSummaryOpen(false)
  }

  const navigateToChargeHistory = () => {
    router.push(`/optimization/charge_history`);
  }
  return (
    <div className="push-charges-modal-overlay">
      <div className="push-charges-modal-content">
        {loading ? (
          <div className="flex justify-center items-center h-screen">
            <Spin size="large" />
          </div>
        ) : (
          <>
            <div className="flex space-x-2 ">
              <button className="border-none flex mr-2" onClick={navigateToDetails}>
                <ArrowLeftIcon className="h-5 w-5 text-black-500 mr-2" />
                <span>Back</span>
              </button>
              <span className='text-[16px] font-600'>
                <strong>Session ID: </strong>{rowData?.session_id || ''}
              </span>
            </div>
            <div className="">
              <div className="flex justify-between items-center">
                <h2 className="font-semibold  mb-2 mt-2 text-[16px] block">Push Charge Details</h2>
                <button className="save-btn" onClick={openExportModal}>
                  <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                  <span>Export</span>
                </button>
              </div>

              <div className="mb-8">
                <h3 className="text-lg font-medium mb-4">Charge Details</h3>

                <div className="grid grid-cols-1 gap-4 md:grid-cols-2 md:gap-4 lg:grid-cols-3 lg:gap-6 mb-4">
                  <div>
                    <label className="field-label">Customer Name</label>
                    <Input
                      type="text"
                      className="input non-editable-input w-full"
                      value={rowData?.customer_name || ""} />
                  </div>
                  <div>
                    <label className="field-label">Total Usage Charges</label>
                    <Input
                      type="text"
                      className="input non-editable-input w-full"
                      value={totalUsageCharges|| ""} />
                  </div>
                  <div>
                    <label className="field-label">Total SMS Charges</label>
                    <Input
                      type="text"
                      className="input non-editable-input w-full"
                      value={`$${totalSMSCharges || ""}`} />
                  </div>

                {/* </div> */}

                {/* <div className="grid grid-cols-3 gap-4 mb-4"> */}

                  {/* <div>
                    <label className="field-label">Billing Period Start</label>
                    <Input
                      type="text"
                      className="input non-editable-input w-full"
                      value={rowData?.billing_period_start_date || ""} />
                  </div>
                  <div>
                    <label className="field-label">Billing Period End</label>
                    <Input
                      type="text"
                      className="input non-editable-input w-full"
                      value={rowData?.billing_period_end_date || ""} />
                  </div> */}
                  <div>
                    <label className='field-label'>Provider</label>
                    <Input
                      className='non-editable-input'
                      value={serviceProvider}
                    // onChange={(e) => setServiceProvider(e.target.value)}
                    />
                  </div>
                  <div>
                    <label className='field-label'>Cycle Date Range</label>
                    <Input
                      className='non-editable-input'
                      value={cycleDateRange}
                    // onChange={(e) => setDeviceCount(e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="field-label">Device Count</label>
                    <Input
                      type="text"
                      className="input non-editable-input w-full"
                      value={rowData?.device_count || ""} />
                  </div>
                  <div>
                    <label className="field-label">Number of Charges To Push</label>
                    <div className="relative flex justify-center space-x-2">
                      <Input
                        type="text"
                        className="non-editable-input pr-10" // Add padding to make space for the icon inside the input
                        value={pushChargeCount || ""}
                        readOnly
                      />

                      {/* Refresh icon positioned inside the input */}
                      <span
                        onClick={fetchRemainingChargesCount}
                        className="absolute inset-y-0 right-0 pr-3 flex items-center cursor-pointer"
                      >
                        {refreshLoading ? (
                          <div className="h-5 w-5 border-2 border-gray-500 border-t-transparent rounded-full animate-spin"></div>
                        ) : (
                          <ArrowPathIcon className="h-5 w-5 text-gray-500" />
                        )}
                      </span>
                    </div>
                  </div>
                  <div>
                    <label className="field-label">Charges Remaining To Push</label>
                    <div className="relative flex justify-center space-x-2">
                      <Input
                        type="text"
                        className="non-editable-input pr-10" // Add padding to make space for the icon inside the input
                        value={remainingChargeCount || ""}
                        readOnly
                      />

                      {/* Refresh icon positioned inside the input */}
                      <span
                        onClick={fetchRemainingChargesCount}
                        className="absolute inset-y-0 right-0 pr-3 flex items-center cursor-pointer"
                      >
                        {refreshLoading ? (
                          <div className="h-5 w-5 border-2 border-gray-500 border-t-transparent rounded-full animate-spin"></div>
                        ) : (
                          <ArrowPathIcon className="h-5 w-5 text-gray-500" />
                        )}
                      </span>
                    </div>
                  </div>

                  <div>
                    {/* <label className='field-label'></label> */}
                    <button
                      className={`${chargeHistoryDisable
                        ? 'text-gray-500 cursor-not-allowed text-[18px]'
                        : 'text-blue-500 underline hover:text-blue-700 cursor-pointer text-[18px]'
                        } mt-6 bg-transparent border-none p-0`}
                      onClick={navigateToChargeHistory}
                      disabled={chargeHistoryDisable}>
                      Navigate to Charge History
                    </button>
                  </div>
                </div>

                {/* <div className="mb-4">
                  <label className="field-label">Validation Comments</label>
                  <textarea className="input w-full h-24" />
                </div> */}
              </div>

              <div>
                <div className="flex justify-between items-center mb-2">
                  <span className="font-semibold  mb-4 mt-2 text-[18px] block">
                    Push Charge Errors
                  </span>
                  <button className="save-btn" onClick={openPushChargesSummary}>Push Charges</button>
                </div>
                <div className="flex justify-end mb-2">
                  <TableSearch
                    searchTerm={errorsSearchTerm}
                    setSearchTerm={setErrorsSearchTerm}
                    tableName={"optimization_push_charges_data"}
                    headerMap={pushErrorsHeaderMap}
                  />
                </div>
                <OptimizationTableComponent
                  headers={pushErrorsHeaders}
                  headerMap={pushErrorsHeaderMap}
                  initialData={pushErrorsTableData}
                  visibleColumns={pushErrorsVisibleColumns}
                  itemsPerPage={10}
                  moduleName="Push charge errors"
                  pagination={pushErrorsPagination}
                  instance_ids_list={instanceIDsList}
                  iccids_list={instanceIDsList}
                />
              </div>
            </div>
          </>
        )
        }
        {exportModalOpen &&
          <ExportDetailsModal
            isOpen={exportModalOpen}
            rowData={rowData}
            onClose={closeExportModal}
            setLoading={setExportLoading}
            errorsLength={errorLength} />
        }

        {pushChargesSummaryOpen &&
          <ReviewChargesModal
            isOpen={pushChargesSummaryOpen}
            rowData={rowData}
            onClose={closePushChargesSummary}
            onSuccess={closeParentModalOnSuccess}
            moduleName="Push charge errors"
            instance_ids_list={instanceIDsList}
            iccids_list={ICCIDsList}
          />
        }
        {exportLoading && (
          <div className="export-processing-div">
            Export Processing...
          </div>
        )}
      </div>
    </div>
  );
};

export default PushChargeDetails;
