'use client'
import React, { lazy, Suspense, useState, useEffect, act } from 'react';
import { Modal, Input, Button, Checkbox, DatePicker, Form, message, Row, Col, notification, Spin } from 'antd';
import Select from 'react-select';
import { useRevStore } from '@/app/stores/revStore';
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from '@/app/components/header_constants';
import axios from 'axios';
import moment from 'moment';
import { isNumber } from 'lodash';
import { ENV_ROUTES } from '@/app/components/routes/route_constants';
import { useOptimizationStore } from '@/app/stores/optimizationStore';

const RevTableComponent = lazy(() => import('@/app/components/revTableComponent/page'));

interface OptionType {
  value: string;
  label: string;
}

interface MyModalProps {
  row: any
  visible: boolean;
  onCancel: () => void;
}

const messageStyle = {
  fontSize: '14px',
  fontWeight: 'bold',
  padding: '16px',
};

const AddServiceLine: React.FC<MyModalProps> = ({ visible, onCancel, row }) => {
  const [selectedCustomer, setSelectedCustomer] = useState(row?.customer_name || "");
  const [selectedProvider, setSelectedProvider] = useState(null);
  const [selectedServiceType, setSelectedServiceType] = useState(null);
  const [selectedProduct, setSelectedProduct] = useState<any>([]);
  const [usagePlanGroup, setUsagePlanGroup] = useState(null);
  const [selectedPackage, setSelectedPackage] = useState(null);
  const [selectedQuantity, setSelectedQuantity] = useState<string>("1");
  const [description, setDescription] = useState<any>(null);
  const [prorate, setProrate] = useState(false);
  const [addRatePlan, setAddRatePlan] = useState(false);
  const [useCarrierActivation, setUseCarrierActivation] = useState(false);

  const [selectedCustomerRatePlan, setSelectedCustomerRatePlan] = useState(null);
  const [showConfirmation, setShowConfirmation] = useState<boolean>(false);
  const [activationDate, setActivationDate] = useState(null);
  const [customerRatePlanOptions, setCustomerRatePlanOptions] = useState<any[]>([]);
  const [providerOptions, setProviderOptions] = useState<any[]>([]);
  const [serviceTypeOptions, setServiceTypeOptions] = useState<any[]>([]);
  const [usagePlanGroupOptions, setUsagePlanGroupOptions] = useState<any[]>([]);
  const [productOptions, setProductOptions] = useState<any[]>([]);
  const [packageOptions, setPackageOptions] = useState<any[]>([]);
  const [providerMap, setProviderMap] = useState<{ [key: string]: string }>({});
  const [providerPackageMap, setProviderPackageMap] = useState<{ [key: string]: string }>({});

  const [providerError, setProviderError] = useState('');
  const [serviceTypeError, setServiceTypeError] = useState('');
  const [activationDateError, setActivationDateError] = useState('');
  const [productError, setProductError] = useState('');
  const [quantityError, setQuantityError] = useState('');
  const [loading, setLoading] = useState(false);

  //Rate state variables
  const [rateProductMap, setRateProductMap] = useState<any>({});
  const [ratePackageMap, setRatePackageMap] = useState<any>([]);
  const [selectedRates, setSelectedRates] = useState<any>({});

  const { username, role, partner, token, selectedDb, firstLastName, sessionId,metaData } = useAuth();
  const { optimizationRow, optimizationType, setIDActionMap, IDActionMap } = useOptimizationStore()

  //To get the initial data
  const fetchData = async () => {
    try {
      const url =
        ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/add_service_line_dropdown_data",
        customer_name: row?.customer_name || "",
        service_provider: row?.service_provider || "",
        service_provider_id: row?.service_provider_id || "",
        iccid: row?.iccid || "",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        const revProviderOptions_ = parsedData?.response_data?.rev_provider || []
        setProviderOptions(revProviderOptions_)
        const serviceTypeOptions_ = parsedData?.response_data?.service_type || []
        setServiceTypeOptions(serviceTypeOptions_)
        const revIOProductOptions = parsedData?.response_data?.rev_product || []
        setProductOptions(revIOProductOptions)
        const customerRatePlanOptions = parsedData?.response_data?.customer_rate_plan_dropdown || []
        setCustomerRatePlanOptions(customerRatePlanOptions)
        const rev_usage_plan_group = parsedData?.response_data?.rev_usage_plan_group || []
        setUsagePlanGroupOptions(rev_usage_plan_group)
        const providerPackageMap_ = parsedData?.response_data?.rev_provider_id_map || {}
        setProviderMap(providerPackageMap_)
        const rev_package = parsedData?.response_data?.rev_package || {}
        setProviderPackageMap(rev_package)
        const rateProductMap_ = parsedData?.response_data?.rev_product_rate || {}
        setRateProductMap(rateProductMap_)
        const productOptions_ = rateProductMap_.map((product: any) => (product?.description || ""))
        setProductOptions(productOptions_)
        const ratePackageMap_ = parsedData?.response_data?.rev_package_rate || []
        setRatePackageMap(ratePackageMap_)
        // Extract descriptions for packageOptions
        const packageOptions_ = ratePackageMap_.map((item: any) => {
          const packageInfo = item[0]; // First item in the inner array
          return packageInfo?.description || ''; // Get the description or fallback to an empty string
        }).filter(Boolean); // Remove any undefined or empty strings 
        console.log("packageOptions_", packageOptions_)
        setPackageOptions(packageOptions_)
      }
    } catch (error) {
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });

    }
  };
  useEffect(() => {
    // fetchData()
    setSelectedCustomerRatePlan(null)
    setSelectedPackage(null)
    setSelectedProduct([])
    setSelectedProvider(null)
    setSelectedQuantity("")
    setSelectedServiceType(null)
    setActivationDate(null)
    setDescription(null)
    setUsagePlanGroup(null)
    setSelectedRates({})
    setPackageOptions([])
    setProviderOptions([])
    setServiceTypeOptions([])
    setProductOptions([])
    setUsagePlanGroupOptions([])

    setProviderError('')
    setServiceTypeError('')
    setActivationDateError('')
    setProductError('')
    setQuantityError('')
    fetchData()
  }, [visible]);

  //To submit the requested payload
  const submitData = async () => {
    let selectedRates_: any = [];
    if (selectedRates && Object.keys(selectedRates).length > 0) {
      selectedRates_ = Object.values(selectedRates);
    }

    try {
      setLoading(true)
      const submitData = {
        customer_name: selectedCustomer,
        provider_name: selectedProvider && selectedProvider !== 'No options' ? selectedProvider : "",
        service_type: selectedServiceType && selectedServiceType !== 'No options' ? selectedServiceType : "",
        revio_product: selectedProduct && !selectedProduct.includes('No options') ? selectedProduct : "",
        revio_package: selectedPackage && selectedPackage !== 'No options' ? selectedPackage : "",
        rate: selectedRates_ || [],
        rate_plan: selectedCustomerRatePlan && selectedCustomerRatePlan !== 'No options' ? selectedCustomerRatePlan : "",
        activation_date: activationDate || "",
        quantity: Number(selectedQuantity) ? selectedQuantity : "",
        add_rate_plan: addRatePlan || "",
        prorate: prorate || "",
        use_carrier_activation: useCarrierActivation || "",
        description: description || "",
        usage_plan_group: usagePlanGroup && usagePlanGroup !== 'No options' ? usagePlanGroup : ""

      }
      const url =
        ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/submit_service_line_dropdown_data",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
        submit_data: submitData,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Update Error',
          content: parsedData.message || 'An error occurred while updating data. Please try again.',
          centered: true,
        });
      } else {
        const uniqueId = row.iccid;
        const updatedValue = IDActionMap?.[uniqueId] || []; // Get the existing value or an empty array
        const updatedMap = {
          ...IDActionMap,
          [uniqueId]: updatedValue.includes("Add service line")
            ? updatedValue // Keep the existing value if already present
            : [...updatedValue, "Add service line"], // Add the new value otherwise
        };
        setIDActionMap(updatedMap);
        notification.success({
          message: 'Success',
          description: 'Successfully updated!',
          style: messageStyle,
          placement: 'top',
        });
        onCancel()
        setLoading(false)
        try {
          const url = ENV_ROUTES.SIM_MANAGEMENT;
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/run_db_script",
            role_name: role,
            module_name: "Bulk Change",
            mod_pages: {
              start: 0,
              end: 100,
            },
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            bulkchange_id: parsedData?.bulkchange_id?.id,
            data: parsedData?.data,
            bulk_chnage_id_20: parsedData?.bulk_chnage_id_20

          };

          const response = await axios.post(url, { data });
          const responseData = JSON.parse(response.data.body);

          if (responseData.flag === false) {
            console.log("failed")
          } else {
            console.log("success")
          }
        } catch (error) {
          console.error("Error fetching data:", error);
        } finally {
        }
      }
    } catch (error) {
      Modal.error({
        title: 'Update Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while updating data. Please try again.',
        centered: true,
      });
    }
    finally {
      onCancel()
      setLoading(false)
    }

  };

  //Function for handling provider change
  const handleProviderChange = (selectedOption: any) => {
    if (selectedOption) {
      setSelectedProvider(selectedOption.value);
      setPackageOptions([]);
      setSelectedPackage(null)
      const providerID = providerMap?.[selectedOption.value]

      if (providerID) {
        // Extract package options and rate options using the provider ID
        const packageOptions: any = providerPackageMap?.[providerID] || [];

        // Update the state with the extracted options
        setPackageOptions(packageOptions);
      } else {
        setPackageOptions([]);
      }
    }
    else if (selectedOption === null) {
      setSelectedProvider(null)
    }

  };

  //Function for handling service type change
  const handleServiceTypeChange = (selectedOption: any) => {
    if (selectedOption) {
      setSelectedServiceType(selectedOption.value);
    }
    else if (selectedOption === null) {
      setSelectedServiceType(null)
    }
  };

  //Function for handling rev.io product change
  const handleProductChange = (selectedOptions: any) => {
    if (selectedOptions) {
      setSelectedPackage(null);
      if (Array.isArray(selectedOptions)) {
        const values = selectedOptions.map((option: any) => option.value);

        // Create an object mapping descriptions to rates
        const matchedRates = values.reduce((acc: any, description: string) => {
          const match = rateProductMap.find(
            (product: any) => product.description === description
          );
          if (match) {
            acc[description] = match?.rate || "0";
          }
          return acc;
        }, {});

        setSelectedRates(matchedRates)
        setSelectedProduct(values);
        setSelectedPackage(null);
        console.log("matchedRates", matchedRates)


      } else {
        setSelectedProduct([]);
        setSelectedRates({})
      }
    }
    else if (selectedOptions === null) {
      setSelectedProduct([])
      setSelectedRates({})
    }
  };

  //Function for handling rev.io package change
  const handlePackageChange = (selectedOption: any) => {
    if (selectedOption) {
      const selectedValue = selectedOption.value;

      // Find the matched list in ratePackageMap
      const matchedItem = ratePackageMap.find(
        (item: any) => item[0]?.description === selectedValue
      );

      // Assign the second item of the matched list to matchedList
      const matchedList = matchedItem ? matchedItem[1] : null;

      // Transform the matched item into a key-value pair object
      const selectedRates = matchedItem
        ? matchedItem[1].reduce((acc: Record<string, number>, curr: any) => {
          acc[curr.subdescription] = curr.rate;
          return acc;
        }, {})
        : {};

      // Update the selected package and optionally log or use matchedList
      setSelectedPackage(selectedValue);
      setSelectedRates(selectedRates)
      console.log("matchedItem:", matchedItem);
      console.log("Matched List:", matchedList);

      // Perform further actions with matchedList if needed
    } else if (selectedOption === null) {
      setSelectedPackage(null);
      setSelectedRates({})
    }
  };


  //Function for handling usage plan change
  const handleUsagePlanGroup = (selectedOption: any) => {
    if (selectedOption) {
      setUsagePlanGroup(selectedOption.value);
    }
    else if (selectedOption === null) {
      setUsagePlanGroup(null)
    }
  };

  //Function for handling customer rate plan change
  const handleCustomerRatePlanChange = (selectedOption: any) => {
    if (selectedOption) {
      setSelectedCustomerRatePlan(selectedOption.value);
    }
    else if (selectedOption === null) {
      setSelectedCustomerRatePlan(null)
    }
  };

  const handleSubmit = () => {
    let isValid = true;
    // Validate provider
    if (!selectedProvider) {
      setProviderError("Please select a provider!");
      isValid = false;
    } else {
      setProviderError('');
    }

    // Validate service type
    if (!selectedServiceType) {
      setServiceTypeError("Please select a service type!");
      isValid = false;
    } else {
      setServiceTypeError('');
    }

    // Validate activation date
    if (!activationDate && !useCarrierActivation) {
      setActivationDateError("Please select an activation date!");
      isValid = false;
    } else {
      setActivationDateError('');
    }

    // Validate product and package
    if (selectedProduct.length < 1 && !selectedPackage) {
      setProductError("Please select a either  product or package");
      isValid = false;
    } else {
      setProductError('');
    }

    // Validate rate

    // Validate quantity
    if (!selectedQuantity || isNumber(selectedQuantity) || Number(selectedQuantity) <= 0) {
      setQuantityError("Please input a valid quantity!");
      isValid = false;
    } else {
      setQuantityError('');
    }

    // If the form is valid, proceed to the next step
    if (isValid) {
      setShowConfirmation(true)

    } else {
      message.error("Please fill all required fields.");
    }
  };

  //Function for handling confirm submit change
  const confirmSubmit = () => {
    submitData()
    // message.success('Data submitted successfully!');
    setShowConfirmation(false);
  };

  //Function to display custom label
  const renderLabel = (label: string, required: boolean) => (
    <span className="field-label">
      {label}{" "}
      {required && (
        <span className="required-indicator" style={{ color: "red" }}>
          *
        </span>
      )}
    </span>
  );

  const handleNext = () => {
    let isValid = true;
    // Validate provider
    if (!selectedProvider) {
      setProviderError("Please select a provider!");
      isValid = false;
    } else {
      setProviderError('');
    }

    // Validate service type
    if (!selectedServiceType) {
      setServiceTypeError("Please select a service type!");
      isValid = false;
    } else {
      setServiceTypeError('');
    }

    // Validate activation date
    if (!activationDate && !useCarrierActivation) {
      setActivationDateError("Please select an activation date!");
      isValid = false;
    } else {
      setActivationDateError('');
    }

    // Validate product
    if (selectedProduct.length < 1 && !selectedPackage) {
      setProductError("Please select a either  product or package");
      isValid = false;
    } else {
      setProductError('');
    }

    // Validate package
    // if (!selectedPackage) {
    //   setPackageError("Please select a package!");
    //   isValid = false;
    // } else {
    //   setPackageError('');
    // }

    // Validate rate

    // Validate quantity
    if (!selectedQuantity || isNumber(selectedQuantity) || Number(selectedQuantity) <= 0) {
      setQuantityError("Please input a valid quantity!");
      isValid = false;
    } else {
      setQuantityError('');
    }

    // If the form is valid, proceed to the next step
    if (isValid) {
      const headerMap_ = {
        "service_number": [
          "Service id",
          null
        ],
        "customer_rate_plan_name": [
          "Customer rate plan",
          null
        ],
        "carrier_rate_plan_name": [
          "Carrier rate plan",
          null
        ]
      }

    } else {
      message.error("Please fill all required fields.");
    }
  };
  const cancelConfirmation = () => {
    setShowConfirmation(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    // Prevent default behavior for specific keys
    const invalidKeys = ['+', '-', 'e']; // List of invalid keys
    if (invalidKeys.includes(e.key)) {
      e.preventDefault(); // Prevent the default action for these keys
      console.log(`${e.key} key pressed - blocked`);
    }
  };

  const disablePastDates = (current: any) => {
    // Disable all dates before today
    return current && current < moment().startOf('day'); // Start of the current day to include today's date
  };
  const modalHeight =
    typeof window !== "undefined" ? (window.innerHeight * 2.5) / 4 : 0;
  return (
    <>
      <Modal
        title="Add a Service Line"
        visible={visible}
        onCancel={onCancel}
        width={800}
        maskClosable={false}

        style={{ top: 40 }}
        footer={
          <div className='justify-center flex space-x-2'>
            <>
              <button key="cancel" className='cancel-btn' onClick={onCancel}>
                Cancel
              </button>
              <button key="submit" className="save-btn" onClick={handleSubmit}>
                Submit
              </button>
            </>
          </div>
        }
        centered
      // width={800}
      >
        {loading ? (
          <div
            className="flex justify-center items-center"
            style={{ height: modalHeight }}
          >
            <Spin size="large" />
          </div>
        ) : (
          <div
            style={{
              height: modalHeight,
              overflowY: "auto",
              overflowX: "hidden",
              padding: "4px",
            }}
          >
            <div className="form-container">
              <div className='grid grid-cols-2 gap-4'>
                <div>
                  <label>{renderLabel("Billing Customer", true)}</label>
                  <Input
                    type="text"
                    className="input non-editable-input w-full"
                    value={selectedCustomer} />
                </div>

                <div>
                  <label>{renderLabel("Billing Provider", true)}</label>
                  <Select
                    options={providerOptions.length > 0 ? providerOptions.map((option) => ({
                      label: option,
                      value: option,
                    })) : [{ value: 'No options', label: 'No options' }]}
                    value={selectedProvider === 'No options' ? null : { label: selectedProvider, value: selectedProvider }}
                    onChange={handleProviderChange}
                    isClearable
                  />
                  {providerError && <p className="error text-red-500">Please Select a Provider</p>}
                </div>

                <div>
                  <label>{renderLabel("Service type", true)}</label>
                  <Select
                    options={serviceTypeOptions.length > 0 ? serviceTypeOptions.map((option) => ({
                      label: option,
                      value: option,
                    })) : [{ value: 'No options', label: 'No options' }]}
                    value={selectedServiceType === 'No options' ? null : { label: selectedServiceType, value: selectedServiceType }}
                    onChange={handleServiceTypeChange}
                    isClearable
                  />
                  {serviceTypeError && <p className="error text-red-500">Please Select a Service Type</p>}
                </div>

                <div>
                  <label>{renderLabel("Activation date", true)}</label>
                  <DatePicker
                    style={{ width: '100%' }}
                    value={activationDate}
                    onChange={(date) => setActivationDate(date)}
                    className='input p-[7px]'
                    // disabledDate={disablePastDates}
                    disabled={useCarrierActivation}
                  />
                  {activationDateError && <p className="error text-red-500">Please Select an Activation Date</p>}
                </div>


                <div>
                  <label>{renderLabel("Billing product", true)}</label>
                  <Select
                    options={productOptions.length > 0 ? productOptions.map((option) => ({
                      label: option,
                      value: option,
                    })) : [{ value: 'No options', label: 'No options' }]}
                    value={selectedProduct.length > 0 ? selectedProduct.map((option: any) => ({ label: option, value: option })) : null}
                    onChange={handleProductChange}
                    isDisabled={!!selectedPackage}
                    isMulti
                  />
                  {productError && <p className="error text-red-500">Please Select Either Product or Package</p>}
                </div>

                <div>
                  <label>{renderLabel("Billing package", true)}</label>
                  <Select
                    options={packageOptions.length > 0 ? packageOptions.map((option) => ({
                      label: option,
                      value: option,
                    })) : [{ value: 'No options', label: 'No options' }]}
                    placeholder="Please select a Billing Package"
                    value={selectedPackage === 'No options' ? null : { label: selectedPackage, value: selectedPackage }}
                    onChange={handlePackageChange}
                    isDisabled={selectedProduct.length > 0 || !selectedProvider}
                    isClearable
                  />
                  {productError && <p className="error text-red-500">Please Select Either Product or Package</p>}
                </div>
                <div>
                  <label>{renderLabel("Usage plan group", false)}</label>
                  <Select
                    options={usagePlanGroupOptions.length > 0 ? usagePlanGroupOptions.map((option) => ({
                      label: option,
                      value: option,
                    })) : [{ value: 'No options', label: 'No options' }]}
                    value={usagePlanGroup === 'No options' ? null : { label: usagePlanGroup, value: usagePlanGroup }}
                    onChange={handleUsagePlanGroup}
                    isClearable
                  />
                </div>
                <div>
                  <label className='font-600'>{renderLabel("Rates", false)}</label>
                  {selectedRates && Object.keys(selectedRates).length > 0 && (
                    <div className="grid grid-cols-2 gap-4">
                      {Object.entries(selectedRates).map(([product, rate], index) => (
                        <React.Fragment key={index}>
                          {/* Left Column: Label */}
                          <div className="text-left pr-4">{product}:</div>

                          {/* Right Column: Input Field */}
                          <div>
                            <input
                              type="number"
                              value={Number(rate)}
                              min="0"
                              step="0.01"
                              className="w-[100px] border border-gray-400 rounded pl-2"
                              onChange={(e) => {
                                const newRate = e.target.value;
                                setSelectedRates((prevRates: any) => ({
                                  ...prevRates,
                                  [product]: newRate,
                                }));
                              }}
                            />
                          </div>
                        </React.Fragment>
                      ))}
                    </div>
                  )}
                </div>

                <div>
                  <label>{renderLabel("Quantity", true)}</label>
                  <input
                    type="number"
                    value={selectedQuantity}
                    className="input"
                    min={1}
                    onChange={(e) => {
                      const value = Math.max(1, parseInt(e.target.value, 10)); // Ensure quantity is not less than 1
                      setSelectedQuantity(value.toString());
                    }}
                    onKeyDown={handleKeyDown} // Add the keydown event listener

                  />
                  {quantityError && <p className="error text-red-500">Please Input the Quantity</p>}
                </div>
                <div>
                  <label>{renderLabel("Service line description", false)}</label>
                  <input
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className='input'
                  />
                </div>
                <div>
                  <Checkbox
                    checked={useCarrierActivation}
                    onChange={(e) => setUseCarrierActivation(e.target.checked)}
                    className='mt-4'
                  >
                    Use Carrier Activation
                  </Checkbox>
                  {/* <label>Use Carrier Activation?</label> */}
                </div>
                <div>
                  <Checkbox
                    checked={prorate}
                    onChange={(e) => setProrate(e.target.checked)}
                    className='mt-4'
                  >
                    Prorate
                  </Checkbox>
                  {/* <label>Prorate?</label> */}
                </div>
                <div>
                  <Checkbox
                    checked={addRatePlan}
                    onChange={(e) => setAddRatePlan(e.target.checked)}
                    className='mt-2'
                  >
                    Add Rate Plan
                  </Checkbox>
                  {/* <label>Add Customer Rate Plan?</label> */}
                </div>
                {addRatePlan && (
                  <div>
                    <label>{renderLabel("Customer rate plan", false)}</label>
                    <Select
                      options={customerRatePlanOptions.length > 0 ? customerRatePlanOptions.map((option) => ({
                        label: option,
                        value: option,
                      })) : [{ value: 'No options', label: 'No options' }]}
                      value={{ label: selectedCustomerRatePlan, value: selectedCustomerRatePlan }}
                      onChange={handleCustomerRatePlanChange}
                      isClearable
                    />
                  </div>
                )}

              </div>
            </div>

          </div>
        )}

      </Modal>
      <Modal
        title="Submit Data"
        visible={showConfirmation}
        onCancel={cancelConfirmation}
        centered
        footer={
          <div className="justify-center flex space-x-2">
            <button key="cancel" className='cancel-btn' onClick={cancelConfirmation}>
              Cancel
            </button>
            <button key="confirm" className='save-btn' onClick={confirmSubmit}>
              OK
            </button>
          </div>
        }
      >
        <p>Are you sure you want to Submit this data</p>
      </Modal>
    </>
  );
};

export default AddServiceLine;
