import { Modal, Input, notification, Spin, Checkbox } from 'antd';
import React, { useCallback, useEffect, useState } from 'react';
import Select from 'react-select';
import { DropdownStyles } from '../css/dropdown';
import { ENV_ROUTES } from '../routes/route_constants';
import { useAuth } from '../auth_context';
import axios from 'axios';
import { getCurrentDateTime } from '../header_constants';
import { useOptimizationStore } from '@/app/stores/optimizationStore';
import OptimizationTableComponent from './page';

interface pushChargesSummaryProps {
    rowData: any;
    onClose: () => void; // To close the modal
    isOpen: boolean;
    onSuccess?: () => void;
    moduleName: string;
    instance_ids_list?: any[];
    iccids_list?: any[];

}

const push_charge_headerMap: any = {
    rev_customer_id: ["Customer account number", "1"],
    customer_name: ["Customer", "2"],
    msisdn: ["MSISDN/TN", "3"],
    iccid: ["ICCID/SIM#", "4"],
    run_status: ["Status", "5"],
    error_message: ["Error", "6"],
    action: ["Action", "7"],
    total_charge_amount: ["Amount", "8"],
    // push_charges: ["Push charges", "9"],



};

const messageStyle = {
    fontSize: "14px",
    fontWeight: "bold",
    padding: "16px",
};

const ReviewChargesModal: React.FC<pushChargesSummaryProps> = ({ rowData, onClose, isOpen, onSuccess, moduleName, instance_ids_list, iccids_list }) => {

    const [loading, setLoading] = useState(false);
    // State variables for selected values
    const { username, partner, role, token, selectedDb,metaData, firstLastName, sessionId } = useAuth();
    const [pushErrorsPagination, setPushErrorsPagination] = useState<any>({});
    const [pushErrorsHeaders, setPushErrorsHeaders] = useState<any[]>([]);
    const [pushErrorsHeaderMap, setPushErrorsHeaderMap] = useState<any>(push_charge_headerMap);
    const [pushErrorsVisibleColumns, setPushErrorsVisibleColumns] = useState<
        string[]
    >([]);
    const { chargesSummaryRows, optimizationType, optimizationRow, selectAll, deselectedRowIds } = useOptimizationStore()
     console.log(deselectedRowIds,"Show deseelcted rowIds")

    const [isPushChargesChecked, setPushChargesChecked] = useState(false);
    const [isPushUsageChecked, setPushUsageChecked] = useState(false);

    const [checkboxError, setCheckboxError] = useState<string | null>(null);
    // console.log(rowData?.serviceproviderids,"Show rowData........")

    useEffect(() => {
        setPushErrorsHeaderMap(push_charge_headerMap);
        const errors_headers_ =
            Object.keys(push_charge_headerMap).length > 0
                ? Object.keys(push_charge_headerMap)
                : [];
        setPushErrorsHeaders(errors_headers_);
        setPushErrorsVisibleColumns(errors_headers_);
    }, [isOpen]);


    const handleUpdate = () => {
        if (!isPushChargesChecked && !isPushUsageChecked) {
            // notification.error({
            //     message: 'Validation Error',
            //     description: 'Please select either "Push Charges" or "Push Usage" before updating.',
            //     style: messageStyle,
            //     placement: 'top',
            // });

            setCheckboxError('Please select either "Push Charges" or "Push Usage" before updating.');
        }
        else {
            setCheckboxError(null);
            submitData()
        }
    }


    const submitData = async () => {
        setLoading(true);
        try {
            const newInstanceIds = chargesSummaryRows.map((row: any) => {
                return row.instance_id || null;
            });

            const newSessionIds = chargesSummaryRows.map((row: any) => {
                return row.session_id || null;
            });

            const newICCIDs = chargesSummaryRows.map((row: any) => {
                return row.iccid || null;
            });

            let push_type
            if (isPushChargesChecked) {
                push_type = "Charges"
            }
            if (isPushUsageChecked) {
                push_type = "Usage"
            }
            if (isPushChargesChecked && isPushUsageChecked) {
                push_type = "Both"
            }
            let data;
            const url = ENV_ROUTES.OPTIMIZATION;
            if (moduleName === "High usage customers") {
                data = {
                    tenant_name: partner || "default_value",
                    username: username,
                    firstLastName: firstLastName,
                    path: "/push_charges_submit",
                    role_name: role,
                    Partner: partner,
                    request_received_at: getCurrentDateTime(),
                    access_token: token,
                    db_name: selectedDb,
        ... metaData,
                    sessionID: sessionId,
                    SessionId: optimizationRow?.session_id || null,
                    selectedInstances:selectAll?instance_ids_list?.filter(id => !deselectedRowIds.includes(id)): newInstanceIds,
                    selectedUsageInstances: "",
                    pushType: push_type,
                    service_provider_id:rowData?.service_provider_id || "",
                    optimization_list_view_id:rowData?.id || "",
                    // service_provider_ids: optimizationRow?.service_provider_ids || [],
                    service_provider_ids:rowData?.serviceproviderids||null,
                    

                };
            }
            else {
                data = {
                    tenant_name: partner || "default_value",
                    username: username,
                    firstLastName: firstLastName,
                    path: "/push_charges_submit",
                    role_name: role,
                    Partner: partner,
                    request_received_at: getCurrentDateTime(),
                    access_token: token,
                    db_name: selectedDb,
        ... metaData,
                    sessionID: sessionId,
                    SessionId: optimizationRow?.session_id || null,
                    selectedInstances: isPushChargesChecked ?selectAll?instance_ids_list?.filter(id => !deselectedRowIds.includes(id)): newInstanceIds : null,
                    selectedUsageInstances: !isPushChargesChecked ?selectAll?iccids_list: newICCIDs : null,
                    pushType: push_type,
                    service_provider_id:rowData?.service_provider_id || "",
                    optimization_list_view_id:rowData?.id || "",
                    // service_provider_ids: optimizationRow?.service_provider_ids || [],
                    service_provider_ids:rowData?.serviceproviderids||null,
                };
            }
          
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                setLoading(false);
                onSuccess?.();

                setLoading(false);
                notification.success({
                    message: 'Success',
                    description: 'Successfully saved.',
                    style: messageStyle,
                    placement: 'top',
                });

            } else {
                onSuccess?.();

                setLoading(false);
                notification.success({
                    message: 'Success',
                    description: 'Successfully saved.',
                    style: messageStyle,
                    placement: 'top',
                });


            }
        } catch (error) {
            // Modal.error({
            //     title: "Data Fetch Error",
            //     content:
            //         error instanceof Error
            //             ? error.message
            //             : "An unexpected error occurred while submitting data. Please try again.",
            //     centered: true,
            // });
            notification.success({
                message: 'Success',
                description: 'Successfully Pushed Charges',
                style: messageStyle,
                placement: 'top',
              });
        } finally {
            setLoading(false);
            onClose()
            onSuccess?.();
        }
    };


    return (
        <Modal
            title="Review Charges"
            visible={isOpen}
            onCancel={onClose}
            centered
            width={350}
            footer={
                <div className='flex justify-center space-x-4'>
                    <button key="cancel" onClick={onClose} className="cancel-btn">Cancel</button>
                    <button key="update" className="save-btn" onClick={handleUpdate}>Push</button>
                </div>
            }
        >
            <>
                {loading ?
                    (
                        <div className="flex justify-center items-center">
                            <Spin size="large" />
                        </div>
                    ) :
                    (
                        <>
                            {/* <div className='w-full mb-4'>
                                <OptimizationTableComponent
                                    headers={pushErrorsHeaders}
                                    headerMap={pushErrorsHeaderMap}
                                    initialData={chargesSummaryRows}
                                    visibleColumns={pushErrorsVisibleColumns}
                                    itemsPerPage={10}
                                    moduleName="Review charges"
                                    pagination={pushErrorsPagination}
                                />
                            </div> */}

                            <div className="my-4 flex justify-center">
                                <Checkbox
                                    checked={isPushChargesChecked}
                                    onChange={(e) => {
                                        setPushChargesChecked(e.target.checked)
                                        setCheckboxError(null);
                                    }
                                    }
                                >
                                    Push Charges
                                </Checkbox>
                                <Checkbox
                                    checked={isPushUsageChecked}
                                    onChange={(e) => {
                                        setPushUsageChecked(e.target.checked);
                                        setCheckboxError(null);
                                    }}
                                    style={{ marginLeft: "16px" }}
                                >
                                    Push Usage
                                </Checkbox>
                            </div>
                            {checkboxError && (
                                <div className="flex justify-center mt-2 text-red-500 text-sm">
                                    {checkboxError}
                                </div>
                            )}
                        </>
                    )
                }

            </>
        </Modal>
    );
};

export default ReviewChargesModal;
