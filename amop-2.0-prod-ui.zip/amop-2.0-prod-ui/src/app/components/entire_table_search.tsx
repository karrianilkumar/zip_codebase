import React, { useCallback, useEffect, useRef, useState } from "react";
import { Input, Button, Modal, Spin } from "antd";
import { SearchOutlined, CloseOutlined } from "@ant-design/icons";
import axios from "axios";
import { useAuth } from "./auth_context";
import { useFeatureStore } from "../sim_management/inventory/featureStore";
import { MultiValue } from "react-select";
import { ENV_ROUTES } from "./routes/route_constants";
import { useSearchStore } from "../stores/searchStore";
import { debounce } from "lodash";
import { useOptimizationStore } from "@/app/stores/optimizationStore";
import { useCustomerRatePlanStore } from "../stores/customerRateplanStore";
interface SearchInputProps {
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  placeholder?: string;
  width?: string;
  tableName: string;
  headerMap: Record<string, any>;
  loader?: boolean;
  selectedSubPartner?: any;
  selectedPartner?: any;
}

interface HeaderOption {
  value: string;
  label: string;
}

const TableSearch: React.FC<SearchInputProps> = ({
  searchTerm,
  setSearchTerm,
  placeholder = "Search...",
  headerMap = {},
  tableName,selectedSubPartner,selectedPartner
}) => {
  const headers = Object.keys(headerMap); // Get the keys of the headerMap
  const [selectedHeaders, setSelectedHeaders] = useState<HeaderOption[]>([]);
  const [colsList, setColsList] = useState<string[]>([]);
  const [searchTable, setSearchTable] = useState<any[]>([]);
  const { setCombineAdnvaceStoredpagination,advancedStoredpagination,storedpagination,combineAdnvaceStoredpagination,username, partner, role, settabledata, tabledata, setStoredPagination, setAdvancedStoredPagination, tenantId, selectedDb,selectedBillingDb,metaData, tenantName, sessionId, setWholeSearchWord,firstLastName } =
    useAuth();
  const { setSearchData, setOptimizationErrorsData, setOptimizationErrorsPagination,advancedSearchData,combineAdnvaceSearchData,setCombineAdnvaceSearchData, setIsSearchComponentCall } = useSearchStore();
  const [loading, setLoading] = useState(false);
  const [inputValue, setInputValue] = useState(searchTerm);
  const { optimizationRow } = useOptimizationStore();
  const { customerShowActive } = useCustomerRatePlanStore();
  const bulkRow :any= JSON.parse(localStorage.getItem('bulk_row') || '{}');
  const iccid :any= localStorage.getItem('iccid') || '0';



  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    setWholeSearchWord(searchTerm);
    console.log(searchTerm,"searchTerm");
  }, [searchTerm]);

  useEffect(() => {
    setInputValue(inputValue);
  }, [inputValue]);
  
  // useEffect(() => {
  //   if(searchTable.length>0 && tabledata.length>0 && searchTable!==tabledata){
  //     if(!combineAdnvaceStoredpagination){
  //       handleClear()
  //     }
  //   }
  // }, [tabledata,searchTable]);

  useEffect(() => {
      if(!advancedStoredpagination && !combineAdnvaceStoredpagination && searchTerm!==""){
        // handleNormalButtonClick();
        handleClear()
      }
    }, [advancedStoredpagination, combineAdnvaceStoredpagination]);
  
  const debouncedSearch = useCallback(
    debounce((value: string) => {
      // setStoredPagination(null);
      // setAdvancedStoredPagination(null);
      console.log("debouncedSearch called with value:", value);
      if(tableName !== "Carrier Status Mapping"){
        setOptimizationErrorsPagination(null)
      }
      setSearchTerm(value);
    }, 300),
    [setStoredPagination, setAdvancedStoredPagination, setSearchTerm]
  );

  // useEffect(() => {
  //   return () => {
  //     debouncedSearch.cancel();
  //   };
  // }, [debouncedSearch]);

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;

    // Immediately update input value
    setInputValue(value);

    // Trigger debounced search for the actual search functionality (API call)
    debouncedSearch(value);
  };

  const handleClear = () => {
    setInputValue("");
    setStoredPagination(null);
    setCombineAdnvaceStoredpagination(null)
    setCombineAdnvaceSearchData(null)
    setOptimizationErrorsPagination(null)
    // setAdvancedStoredPagination(null)
    setSearchTerm("");
  };


  const handleHeaderChange = (selectedOptions: MultiValue<HeaderOption>) => {
    const selectedValues = selectedOptions.map((option) => option.value);
    setSelectedHeaders(selectedOptions as HeaderOption[]);
    setColsList(selectedValues);
  };

  const handleNormalButtonClick = async () => {
    setIsSearchComponentCall(true)
    console.log(advancedStoredpagination,"AdvancedStoredPagination");
    console.log(storedpagination,"storedpagination");
    // setAdvancedStoredPagination(null)
    console.log(advancedSearchData,"AdnvacedsearchData");
    // setStoredPagination(null);  removed the pagination setting to null
    if((advancedStoredpagination && advancedSearchData) || combineAdnvaceStoredpagination){
      const data=combineAdnvaceStoredpagination?combineAdnvaceSearchData:advancedSearchData
      handleCombineButtonClick(data);
    }else{
      try {
        setLoading(true);
        const url = ENV_ROUTES.OPEN_SEARCH;
        const data = {
          data: {
            path: "/perform_search",
            search_word: inputValue,
            search_all_columns:
              colsList.length === headers.length || colsList.length === 0
                ? "True"
                : "False",
            index_name: tableName,
            tenant_id: tenantId,
            partner: partner,
            username: username,
            db_name: tableName === "Billing Service Providers"? selectedBillingDb: selectedDb,
            sessionID: sessionId,
            ...metaData,
            search: "whole",
            pages: {
              start: 0,
              end: 100,
            },
            ...(tableName === "status_history" && iccid && iccid !== "None" && iccid !== ""
              ? { iccid: [iccid] }
              : {}),
            ...(tableName === "status_history" && iccid && iccid !== "None" && iccid !== ""
              ? { flag: "status_history" }
              : {}),
            ...(tableName === "sim_management_bulk_change_request" && bulkRow && bulkRow !== null ? { flag: "bulk_history" } : {}),
            ...(tableName === "sim_management_bulk_change_request" && bulkRow && bulkRow !== null
              ? { bulk_change_id:bulkRow?.row?.bulk_change_id || bulkRow?.row?.id || "0"}
              : {}),
            ...(tableName === "optimization_instance_summary" || tableName === "optimization_error_details"
              ? { session_id: optimizationRow.session_id }
              : {}),
            ...(tableName === "Customer_Rate_Plan"
              ? { toggle: customerShowActive }
              : {}),
            ...(tableName === "rev_assurance"
              ? { toggle: customerShowActive }
              : {}),
               ...(tableName === "Billing Service Providers" && selectedPartner && { Selected_Partner: selectedPartner }),
          ...(tableName === "Billing Service Providers" && selectedSubPartner && { sub_partner: selectedSubPartner }),
          ...(tableName ==="customer_groups" && {
            firstLastName:firstLastName
          })
          },
        };
        setSearchData(data)
        const response = await axios.post(url, data);
        const parsedData = JSON.parse(response.data.body);
        if (parsedData?.flag) {
          const tableData = parsedData?.data?.table || [];
          const pagination_ = parsedData?.pages || {};
          if (tableName === "optimization_error_details" || tableName === "tenant_based_banners_logs") {
            setOptimizationErrorsData(tableData)
            setOptimizationErrorsPagination(pagination_)
          }
          else {
            settabledata(tableData);
            setSearchTable(tableData)
            setStoredPagination(pagination_);
          }
          if (tableData.length === 0) {
            Modal.error({
              title: "No Records found",
            });
          handleClear()
          }
        } else {
          Modal.error({
            title: "Search error",
            content:
              parsedData.error ||
              "An error occurred while searching. Please try again.",
          });
          handleClear()
        }
        console.log(response);
      } catch (error) {
        console.log(error);
      } finally {
        setLoading(false); // Stop loader
      }
    }
   
  };
  const handleCombineButtonClick = async (advancedSearchData_: any) => {
    setLoading(true);
    const filters_ =advancedSearchData_?.data?.filters
    try {
      const url = ENV_ROUTES.OPEN_SEARCH;
      const data = {
        data: {
          path: "/perform_search",
          search: "combined",
          filters: filters_,
          search_word: inputValue,
          search_all_columns: "True",
          index_name: tableName,
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
             ...(tableName === "Billing Service Providers" && selectedPartner && { Selected_Partner: selectedPartner }),
          ...(tableName === "Billing Service Providers" && selectedSubPartner && { sub_partner: selectedSubPartner }),
          db_name: tableName === "Billing Service Providers" ? selectedBillingDb: selectedDb,
          sessionID: sessionId,
          ...metaData,
        },
        ...(tableName === "rev_assurance" || tableName === "Customer_Rate_Plan"
          ? { toggle: customerShowActive }
          : {}),
        ...(tableName === "status_history" && iccid && iccid !== "None" && iccid !== ""
          ? { flag: "status_history" }
          : {}),
        ...(tableName === "sim_management_bulk_change_request" && bulkRow && bulkRow !== null
          ? { flag: "bulk_history" }
          : {}),
        ...(tableName === "high_usage_customers" || tableName === "optimization_errors"
          ? { session_id: optimizationRow.session_id }
          : {}),
          ...(tableName ==="customer_groups" && {
            firstLastName:firstLastName
          })
      };
      
      setCombineAdnvaceSearchData(data);
      const response = await axios.post(url, data);
      const parsedData = JSON.parse(response.data.body);
      
      if (parsedData?.flag) {
        const tableData = parsedData?.data?.table;
        settabledata(tableData);
        setSearchTable(tableData)
        const pagination_ = parsedData?.pages || {};
        setCombineAdnvaceStoredpagination(pagination_);
        
        if (tableData.length === 0) {
          Modal.error({
            title: "No Records found",
          });
        handleClear()
        }
      } else {
        Modal.error({
          title: "Search error",
          content: parsedData.error || "An error occurred while searching. Please try again.",
        });
        handleClear()
      }
    } catch (error) {
      console.error(error);
    }
    finally{
    setLoading(false);
    }
  };

  return (
    <div className="">
      {loading && (
        <div className="absolute inset-0 flex justify-center items-center adv-search-loader bg-white bg-opacity-75 z-50 pointer-events-none">
          <Spin size="large" />
        </div>
      )}
      <div className="flex items-center space-x-2">
        <div className="relative flex items-center border border-gray-300 rounded-lg p-1 w-full space-x-4 w-[250px]">
          <input
            placeholder={placeholder}
            value={inputValue}
            onChange={handleSearch}
            ref={inputRef}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                handleNormalButtonClick();
              }
            }}
            className="h-8 border-none outline-none w-full pl-2 pr-12 rounded-lg search-input"
          />
          {searchTerm && (
            <CloseOutlined
              className="absolute right-8 text-gray-500 cursor-pointer"
              onClick={handleClear}
            />
          )}
          <SearchOutlined
            className="absolute right-2 text-gray-500 cursor-pointer"
            onClick={handleNormalButtonClick}
          />
        </div>
        {(searchTerm && (typeof window !== "undefined" && window.innerWidth > 700))&& (
          <button
            className="save-btn hidden md:inline-flex"
            onClick={handleNormalButtonClick}
          >
            Search
          </button>
        )}
      </div>
    </div>
  );
};

export default TableSearch;
