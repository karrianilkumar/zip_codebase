"use client";
import React, { useEffect, useState, lazy, Suspense, useRef } from "react";
import {
  PlusIcon,
  ArrowDownTrayIcon,
  ArrowLeftIcon,
} from "@heroicons/react/24/outline";
import { Button, Modal, Spin, DatePicker, notification } from "antd";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { useLogoStore } from "@/app/stores/logoStore";
import { getCurrentDateTime } from "@/app/components/header_constants";
import dayjs, { Dayjs } from "dayjs";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { useRouter } from "next/navigation";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useOptimizationStore } from "@/app/stores/optimizationStore";
const { RangePicker } = DatePicker;
//Lazy loading components
const TableComponent = lazy(
  () => import("@/app/components/TableComponent/page")
);
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));
const TableSearch = lazy(() => import("@/app/components/entire_table_search"));
const AdvancedMultiFilter = lazy(
  () => import("@/app/components/advanced_search")
);

const StatusHistory: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, settabledata, token, selectedDb} = useAuth();
  const [loading, setLoading] = useState(false);
  const title = useLogoStore((state) => state.title);
  const [pagination, setpagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [totalOptimizations, setTotalOptimizations] = useState<any>("");
  const [uploadedOptimizations, setUploadedOptimizations] = useState<any>("");
  const [createModalData, setCreateModalData] = useState<any[]>([]);
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([
    null,
    null,
  ]);
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const { optimizationRow } = useOptimizationStore();

  // const {features:moduleFeatures,setFeatures:setModuleFeatures} = useFeatureStore();

  const router = useRouter();

  const handleFilter = (advancedFilters: any) => {
    console.log(advancedFilters);
  };

  const handleReset = (EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  };

  const handleBackNavigation = (EmptyFilters: any) => {
    router.push(`/optimization`);
  };

  type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = (headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];

    entries.sort((a, b) => a[1][1] - b[1][1]);

    return Object.fromEntries(entries) as HeaderMap;
  };

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        console.log("opt",optimizationRow)
        const url =  ENV_ROUTES.OPTIMIZATION;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          path: "/optimization_row_info_data",
          role_name: role,
          module_name: "Optimization",
          mod_pages: {
            start: 0,
            end: 100,
          },
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          session_id:optimizationRow?.session_id ||"None"
        };
        console.log(getCurrentDateTime(),"Show the log time request sent from ui to lambda");
        
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        console.log(getCurrentDateTime(),"Show the log time response sent from lambda to ui");
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching History. Please try again.",
            centered: true,
          });
        } else {
          const headersMap_ =
            parsedData?.headers_map?.["Optimization Info"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);
          const headers_ =
            Object.keys(sortedheaderMap).length > 0
              ? Object.keys(sortedheaderMap)
              : [];
          setHeaders(headers_);
          setVisibleColumns(headers_);
          const tableData_ = parsedData?.info_dict || [];
          setTableData(tableData_);
          const pagination_ = parsedData?.pages || {};
          setpagination(pagination_);
          const totalOptimizations_ = parsedData?.["Total Optimizations in sessions"] || {};
          setTotalOptimizations(totalOptimizations_);
          const uploadedOptimizations_ = parsedData?.["Uploaded Optimizations"] || {};
          setTotalOptimizations(uploadedOptimizations_);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        Modal.error({
          title: "Data Fetch Error",
          content:
            error instanceof Error
              ? error.message
              : "An unexpected error occurred while History. Please try again.",
          centered: true,
        });
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [username, partner, role]);

  //From here
  const messageStyle = {
    fontSize: "14px",
    fontWeight: "bold",
    padding: "16px",
    // Add padding
  };


  //Here
  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }
  //Added
  const disableFutureDates = (current: any) => {
    console.log("future dates:", current && current > dayjs().endOf("day"));
    return current && current > dayjs().endOf("day"); // Disable future dates
  };

  return (
    <Suspense
      fallback={
        <div className="flex justify-center items-center h-screen">
          <Spin size="large" />
        </div>
      }
    >
      <div className="relative justify-center items-center">
        <div className="flex justify-start p-4">
          <button
            className="border-none flex mr-8"
            onClick={handleBackNavigation}
          >
            <ArrowLeftIcon className="h-5 w-5 text-black-500 mr-2" />
            <span>Back</span>
          </button>
          <span className="font-semibold text-gray-800">
            Optimization info
          </span>
        </div>
        <div className="pl-4 flex items-center justify-between mt-1">
          <div className="flex justify-start">
            <div className="flex flex-col justify-start">
              <div className="grid grid-cols-2 gap-8">
                <span className="text-gray-600">Service provider:</span>
                <span className="font-semibold text-gray-800">
                  {optimizationRow?.service_provider || "N/A"}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-8">
                <span className="text-gray-600">Total optimizations in session:</span>
                <span className="font-semibold text-gray-800">
                {totalOptimizations || "N/A"}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-8">
                <span className="text-gray-600">Total charges in session:</span>
                <span className="font-semibold text-gray-800">
                {optimizationRow?.total_charge_amount || "N/A"}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-8">
                <span className="text-gray-600">Total devices in session:</span>
                <span className="font-semibold text-gray-800">
                {optimizationRow?.device_count || "N/A"}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-8">
                <span className="text-gray-600">Uploaded optimizations:</span>
                <span className="font-semibold text-gray-800">
                {uploadedOptimizations || "N/A"}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-8">
                <span className="text-gray-600">Uploaded usage charges:</span>
                <span className="font-semibold text-gray-800">
                {optimizationRow?.total_charge_amount || "N/A"}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-8">
                <span className="text-gray-600">Uploaded SMS charges:</span>
                <span className="font-semibold text-gray-800">
                {optimizationRow?.sms_charge_total|| "N/A"}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-8">
                <span className="text-gray-600">Uploaded and no charge devices:</span>
                <span className="font-semibold text-gray-800">
                {optimizationRow?.device_count|| "N/A"}
                </span>
              </div>
            </div>
          </div>
        </div>
        <div className="flex justify-between p-4">
          <div className="flex space-x-2 h-full justify-start ">
            <TableSearch
              searchTerm={searchTerm}
              setSearchTerm={setSearchTerm}
              tableName={"sim_management_bulk_change_request"}
              headerMap={headerMap}
            />
            <AdvancedMultiFilter
              showAdvanced={showAdvanced}
              setShowAdvanced={setShowAdvanced}
              onFilter={handleFilter}
              onReset={handleReset}
              headers={headers}
              headerMap={headerMap}
              tableName={"sim_management_bulk_change_request"}
            />
          </div>
          <div className="flex space-x-2 justify-end ">
            <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
            />
          </div>
        </div>
        <div className=" mb-4 space-x-2"></div>
        <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
          <TableComponent
            headers={headers}
            headerMap={headerMap}
            initialData={tableData}
            searchQuery={searchTerm}
            visibleColumns={visibleColumns}
            itemsPerPage={100}
            popupHeading="Optimization Info"
            createModalData={createModalData}
            pagination={pagination}
            advancedFilters={filteredData}
          />
        </div>
      </div>
    </Suspense>
  );
};

export default StatusHistory;
