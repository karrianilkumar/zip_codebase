"use client";

import React, { useEffect, useState, lazy, Suspense } from "react";
import { useSidebarStore } from "@/app/stores/navBarStore";
import { useLogoStore } from "@/app/stores/logoStore";
import { Spin } from "antd";

const CarrierOptimization = lazy(() => import("./carrier_optimization"));
const CustomerOptimization = lazy(() => import("./customer_optimization"));

const Optimization: React.FC = () => {
  const [activeTab, setActiveTab] = useState("customer");
  const isExpanded = useSidebarStore((state: any) => state.isExpanded);
  const [loading, setLoading] = useState(false);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }
  return (
    <Suspense
      fallback={
        <div className="flex justify-center items-center h-screen">
          <Spin size="large" />
        </div>
      }
    >
      <div className="">
        <div
          className={`bg-white shadow-md mb-4 gap-4  tabs ${
            isExpanded ? "left-[17%]" : "left-[112px]"
          }`}
        >
          <button
            className={`tab-headings ${
              activeTab === "customer" ? "active-tab-heading" : ""
            }`}
            onClick={() => setActiveTab("customer")}
          >
            Customer optimization
          </button>
          <button
            className={`tab-headings ${
              activeTab === "carrier" ? "active-tab-heading" : ""
            }`}
            onClick={() => setActiveTab("carrier")}
          >
            Carrier optimization
          </button>
        </div>
        <div className="h-[calc(100vh-150px)] pt-[70px]">
          {activeTab === "carrier" && <CarrierOptimization />}
          {activeTab === "customer" && <CustomerOptimization />}
        </div>
      </div>
    </Suspense>
  );
};

export default Optimization;
