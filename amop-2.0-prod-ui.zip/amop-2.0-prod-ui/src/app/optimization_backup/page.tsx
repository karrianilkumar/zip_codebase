"use client";
import React, {
    useEffect,
    useState,
    lazy,
    Suspense,
    useRef,
    useCallback,
} from "react";
import { ArrowDownTrayIcon, ArrowUpTrayIcon } from "@heroicons/react/24/outline";
import { Modal, Spin, DatePicker, notification } from "antd";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import dayjs, { Dayjs } from "dayjs";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { MinusCircleOutlined, MinusOutlined, PlusOutlined, SettingOutlined } from "@ant-design/icons";
import { useRevStore } from "@/app/stores/revStore";
import moment from "moment";
import Select from 'react-select';
import { ENV_ROUTES } from "../components/routes/route_constants";
import Optimize from "../sim_management/optimize";
import DownloadModal from "../components/revTableComponent/downloadModal";
import RowUploadModal from "./optimization_row_upload";
type ExportData = {
    path: string;
    username: string | null;
    module_name: string;
    request_received_at: string;
    billing_period_start_date: string;
    billing_period_end_date: string;
    Partner: string | null;
    access_token: string | null;
    db_name: string | null;
    optimization_type: string | null,
    service_provider: string | null
    sessionID:String|null;
};

const { RangePicker } = DatePicker;
const RevTableComponent = lazy(
    () => import("@/app/components/revTableComponent/page")
);
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));
const TableSearch = lazy(() => import("@/app/components/entire_table_search"));
const AdvancedMultiFilter = lazy(
    () => import("@/app/components/advanced_search")
);

const Optimization: React.FC = () => {
    const [isExportModalOpen, setExportModalOpen] = useState(false);
    const [searchTerm, setSearchTerm] = useState("");
    const [optimizationTyperror, setOptimizationTypeError] = useState(false);
    const [providerError, setProviderError] = useState(false);
    const [dateError, setDateError] = useState(false);
    const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
    const { username, partner, role, token, selectedDb, firstLastName,sessionId} = useAuth();
    const [pagination, setPagination] = useState<any>({});
    const [tableData, setTableData] = useState<any>([]);
    const [features, setFeatures] = useState<string[]>([]);
    const [headers, setHeaders] = useState<any[]>([]);
    const [headerMap, setHeaderMap] = useState<any>({});
    const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([
        null,
        null,
    ]);
    const [selectedDate, setSelectedDate] = useState<string | null>(moment().format('YYYY-MM-DD')); // Default to current date

    const [filteredData, setFilteredData] = useState([]);
    const [showAdvanced, setShowAdvanced] = useState(false);
    const { revRows, setRevRows, setRevHeaders, setRevHeaderMap } = useRevStore();
    const [loading, setLoading] = useState(true);

    const [optimizationTypeOptions, setOptimizationTypeOptions] = useState<any[]>([])
    const [serviceProviderOptions, setServiceProviderOptions] = useState<any[]>([])
    const [selectedProvider, setSelectedProvider] = useState(null);
    const [selectedOptimizationType, setSelectedOptimizationType] = useState(null);

    const [isDownloadModalOpen, setIsDownloadModalOpen] = useState(false);
    const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);

    const [isOptimizeModalVisible, setIsOptimizeModalVisible] = useState(false);
    const [uploadOptimizationType, setUploadOptimizationType] = useState<string|null>(null);
    const [allowedActions, setAllowedActions] = useState<any[]>([]);
    
    type HeaderMap = Record<string, [string, number]>;

    const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
        const entries = Object.entries(headerMap) as [string, [string, number]][];
        entries.sort((a, b) => a[1][1] - b[1][1]);
        return Object.fromEntries(entries) as HeaderMap;
    }, []);


    //React query
    // // Function to fetch optimization data (formerly in fetchData)
    // const fetchData = async () => {
    //     try {
    //         console.log("data overwritten")
    //         setLoading(true)
    //         const url = ENV_ROUTES.SIM_MANAGEMENT;
    //         const data = {
    //             tenant_name: partner || "default_value",
    //             username: username,
    //             path: "/get_optimization_data",
    //             role_name: role,
    //             module_name: "Optimization",
    //             mod_pages: {
    //                 start: 0,
    //                 end: 100,
    //             },
    //             request_received_at: getCurrentDateTime(),
    //             Partner: partner,
    //             access_token: token,
    //             db_name: selectedDb,
    //         };

    //         const response = await axios.post(url, { data });
    //         const parsedData = JSON.parse(response.data.body);
    //         if (parsedData.flag === false) {
    //             setLoading(false)
    //             Modal.error({
    //                 title: 'Data Fetch Error',
    //                 content: parsedData.message || 'An error occurred while fetching rev assurance data. Please try again.',
    //                 centered: true,
    //             });
    //         }
    //         else {
    //             return parsedData;
    //         }
    //     }
    //     catch (error) {
    //         setLoading(false);
    //         Modal.error({
    //             title: 'Data Fetch Error',
    //             content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
    //             centered: true,
    //         });
    //     } finally {
    //         setLoading(false);
    //     }
    // };

    // // Use React Query's useQuery hook to fetch the data
    // const {
    //     data,
    //     status,
    // } = useQuery({
    //     queryKey: ["optimizationData", partner], // Query key with "partner"
    //     queryFn: fetchData, // The function that fetches the data
    //     refetchOnMount: true, // Option to refetch data on mount
    // });


    // // Handling data updates on successful fetch
    // useEffect(() => {
    //     if (data) {
    //         setLoading(false)
    //         const headersMap_ = data?.header_map?.["Optimization"]?.header_map || {};
    //         const sortedheaderMap = sortHeaderMap(headersMap_);
    //         setHeaderMap(sortedheaderMap);
    //         setRevHeaderMap(sortedheaderMap);
    //         const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
    //         setHeaders(headers_);
    //         setRevHeaders(headers_);
    //         setVisibleColumns(headers_);
    //         const tableData_ = data?.optimization_data || [];
    //         setTableData(tableData_);
    //         setRevRows([]);
    //         const features_ = data?.header_map?.["Optimization"]?.module_features || [];
    //         setFeatures(features_);
    //         const pagination_ = data?.pages || {};
    //         setPagination(pagination_);
    //         const service_provider = data?.service_provider || [];
    //         setServiceProviderOptions(service_provider);
    //     }
    // }, [data]);

    //React query

    //To load the initial data
    const fetchData = async () => {
        try {
            setLoading(true);
            const url = ENV_ROUTES.SIM_MANAGEMENT
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_optimization_data",
                role_name: role,
                parent_module: "Sim Management",
                module_name: "Optimization",
                feature_module_name:"Optimization",
                mod_pages: {
                    start: 0,
                    end: 100,
                },
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                sessionID: sessionId,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching optimization data. Please try again.',
                    centered: true,
                });
            } else {
                const headersMap_ = parsedData?.header_map?.["Optimization"]?.header_map || {}
                const sortedheaderMap = sortHeaderMap(headersMap_)
                setHeaderMap(sortedheaderMap)
                setRevHeaderMap(sortedheaderMap)
                const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : []
                setHeaders(headers_)
                setRevHeaders(headers_)
                setVisibleColumns(headers_)
                const tableData_ = parsedData?.optimization_data || []
                setTableData(tableData_)
                setRevRows([])
                const features_ = parsedData?.header_map?.["Optimization"]?.module_features || []
                setFeatures(features_)
                const allowedActions_:any=[]
                if(features_.includes("Info-Optimization")){
                  allowedActions_.push("info-status")
                }
                if(features_.includes("Row upload-Optimization")){
                  allowedActions_.push("upload")
                }
                if(features_.includes("Row download-Optimization")){
                  allowedActions_.push("download")
                }
                setAllowedActions(allowedActions_)
                const pagination_ = parsedData?.pages || {}
                setPagination(pagination_)
                const service_provider = parsedData?.service_provider || []
                setServiceProviderOptions(service_provider)
            }
        } catch (error) {
            console.error("Error fetching data:", error);
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        } finally {
            setLoading(false);
        }
    }
    // Setting optimization type options on component mount
    useEffect(() => {
        fetchData()
        setOptimizationTypeOptions(["Carrier", "Customer"]);
    }, [partner]);

    const handleOptimizationTypeChange = (selectedOption: any) => {
        if (selectedOption) {
            setSelectedOptimizationType(selectedOption.value);
            setOptimizationTypeError(false)
        }
        else if (selectedOption === null) {
            setSelectedOptimizationType(null)
        }
    };
    const handleServiceProviderChange = (selectedOption: any) => {
        if (selectedOption) {
            setSelectedProvider(selectedOption.value);
            setProviderError(false)
        }
        else if (selectedOption === null) {
            setSelectedProvider(null)
        }
    };

    //Functions to handle the enabling and disabling of buttons

    const isRatePlanUploadDisable = () => {
        const providerNames = revRows.map(row => row.service_provider);
        const isAllProviderNamesSame = providerNames.every(name => name === providerNames[0]);
        return (
          revRows.length < 1 || 
          revRows.some((row) => row.upload === false) || 
          revRows.some((row) => row.optimization_type === 'Customer'||
          !isAllProviderNamesSame
        )
        );
      };
      
      const isCustomerChargeUploadDisable = () => {
        const providerNames = revRows.map(row => row.service_provider);
        const isAllProviderNamesSame = providerNames.every(name => name === providerNames[0]);
        return (
            revRows.length < 1 || 
            revRows.some((row) => row.upload === false) || 
            revRows.some((row) => row.optimization_type === 'Carrier' ||
            !isAllProviderNamesSame
        )
          );
      };
      
      const isDownloadDisable = () => {
        const providerNames = revRows.map(row => row.service_provider);
        const isAllProviderNamesSame = providerNames.every(name => name === providerNames[0]);
        return revRows.length < 1 || revRows.some((row) => row.download === false || !isAllProviderNamesSame);
      };
    // Functions to handle opening and closing of modal
    const openDownloadModal = () => {
        setIsDownloadModalOpen(true);
    };

    const closeDownloadModal = () => {
        setIsDownloadModalOpen(false);
    };

    const openRatePlanUploadModal = () => {
        setUploadOptimizationType("Carrier")
        setIsUploadModalOpen(true);
    };
    const openCustomerChargeUploadModal = () => {
        setUploadOptimizationType("Customer")
        setIsUploadModalOpen(true);
    };
    const closeUploadModal = () => {
        setIsUploadModalOpen(false);
        setUploadOptimizationType(null)
    };
    const handleOpenOptimizeModal = () => {
        setIsOptimizeModalVisible(true);
    };

    const handleOptimizeCancel = () => {
        setIsOptimizeModalVisible(false);
    };
    const handleFilter = useCallback((advancedFilters: any) => {
    }, []);

    const handleReset = useCallback((EmptyFilters: any) => {
        setFilteredData(EmptyFilters);
    }, []);

    const messageStyle = {
        fontSize: "14px",
        fontWeight: "bold",
        padding: "16px",
    };

    const exportMutation = useMutation<any, Error, ExportData>({
        mutationFn: async (exportData) => {
            const url = ENV_ROUTES.SIM_MANAGEMENT
            const response = await axios.post(
                url,
                { data: exportData },
                {
                    headers: {
                        "Content-Type": "application/json",
                    },
                }
            );
            return JSON.parse(response.data.body);
        },
        onSuccess: (data) => {
            if (data.flag === true) {
                notification.success({
                    message: "Success",
                    description: "Successfully exported the record!",
                    style: messageStyle,
                    placement: "top",
                });
                downloadBlob(data.blob);
            } else {
                Modal.error({
                    title: "Export Error",
                    content: data.message,
                    centered: true,
                });
            }
            handleExportModalClose();
        },
        onError: (error) => {
            console.error("Error downloading the file:", error);
            Modal.error({
                title: "Export Error",
                content:
                    "An error occurred while exporting the file. Please try again.",
            });
        },
    });

    const handleExportModalOpen = () => {
        setExportModalOpen(true);
    };

    const handleExportModalClose = () => {
        setDateRange([null, null]);
        setSelectedProvider(null);
        setSelectedOptimizationType(null)
        setOptimizationTypeError(false)
        setProviderError(false)
        setDateError(false)
        setExportModalOpen(false);
    };
    const handleExport = () => {
        const isValid = selectedOptimizationType && selectedProvider && dateRange
        if (isValid) {
            handleExportSave()
        }
        else {
            if(!selectedOptimizationType){
                setOptimizationTypeError(true)
            }
            if(!selectedProvider){
                setProviderError(true)
            }
            if (!dateRange || dateRange[0] === null || dateRange[1] === null){
                setDateError(true)
            }
        }
    }
    const handleExportSave = () => {

        if (!dateRange || dateRange[0] === null || dateRange[1] === null) {
            setDateError(true)
            return;
        }

        let [startDate, endDate] = dateRange;

        const exportData: ExportData = {
            path: "/export_optimization_data_zip",
            username: username,
            module_name: "Optimization",
            optimization_type: selectedOptimizationType,
            service_provider: selectedProvider,
            request_received_at: getCurrentDateTime(),
            billing_period_start_date: startDate.format("YYYY-MM-DD 00:00:00"),
            billing_period_end_date: endDate.format("YYYY-MM-DD 23:59:59"),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
            sessionID: sessionId,
        };

        exportMutation.mutate(exportData);
    };

    const downloadZipBlob = (base64Blob: string) => {
        // Convert base64 string to binary data
        const byteCharacters = atob(base64Blob);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);

        // Create a Blob from the byteArray with a type of zip
        const blobObject = new Blob([byteArray], {
            type: "application/zip",
        });

        // Create a download link and trigger it to download the .zip file
        const link = document.createElement("a");
        link.href = URL.createObjectURL(blobObject);
        link.download = "Optimization.zip"; // Ensure to download as .zip
        document.body.appendChild(link);
        link.click(); 
        document.body.removeChild(link);
    };

    const downloadBlob = (base64Blob: string) => {
        const byteCharacters = atob(base64Blob);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
    
        const blobObject = new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blobObject);
        link.download = 'Optimization.xlsx';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      };


    if (loading) {
        return (
            <div className="flex justify-center items-center h-screen">
                <Spin size="large" />
            </div>
        );
    }

    const disableFutureDates = (current: any) => {
        return current && current > dayjs().endOf("day");
    };

    return (
        <>
            <Suspense
                fallback={
                    <div className="flex justify-center items-center h-screen">
                        <Spin size="large" />
                    </div>
                }
            >
                <div className="relative">
                    <div className="flex justify-between  p-4">
                        <div className="flex justify-start space-x-2">
                        {features.includes("Optimize-Optimization") && (
                            <button className="save-btn" onClick={handleOpenOptimizeModal}>
                                <span>Optimize</span>
                            </button>
                        )}
                            {features.includes("Export-Optimization") && (
                            <button className="save-btn" onClick={handleExportModalOpen}>
                                <span>Export</span>
                            </button>
                            )}
                            {features.includes("Downlaod-Optimization") && (
                            <button className={`${isDownloadDisable() ? 'inactive-btn' : 'save-btn'} disabled:cursor-not-allowed`}
                                onClick={openDownloadModal}
                                disabled={isDownloadDisable()}
                                >
                                <span>Download</span>
                            </button>
                            )}
                            {features.includes("Rate plan upload-Optimization") && (
                            <button
                                className={`${isRatePlanUploadDisable() ? 'inactive-btn' : 'save-btn'} disabled:cursor-not-allowed`}
                                onClick={openRatePlanUploadModal}
                                disabled={isRatePlanUploadDisable()}
                                >
                                <span>Rate Plan Upload</span>
                            </button>
                            )}
                            {features.includes("Customer charges upload-Optimization") && (
                            <button
                                className={`${isCustomerChargeUploadDisable() ? 'inactive-btn' : 'save-btn'} disabled:cursor-not-allowed`}
                                onClick={openCustomerChargeUploadModal}
                                disabled={isCustomerChargeUploadDisable()}
                                >
                                <span>Customer Charges Upload</span>
                            </button>
                            )}
                        </div>
                    </div>
                    <div className="p-2 flex items-center justify-between mt-1 mb-2">
                        <div className="flex space-x-2">
                        {features.includes("Search-Optimization") && (
                            <TableSearch
                                searchTerm={searchTerm}
                                setSearchTerm={setSearchTerm}
                                tableName={"optimization_instance_summary"}
                                headerMap={headerMap}
                            // loader={loading}
                            />
                        )}
                            {features.includes("Advanced filter-Optimization") && (
                            <AdvancedMultiFilter
                                showAdvanced={showAdvanced}
                                setShowAdvanced={setShowAdvanced}
                                onFilter={handleFilter}
                                onReset={handleReset}
                                headers={headers}
                                headerMap={headerMap}
                                tableName={"optimization_instance_summary"}
                            />
                            )}
                        </div>
                        <div className="flex space-x-2">
                            <ColumnFilter
                                headers={headers}
                                visibleColumns={visibleColumns}
                                setVisibleColumns={setVisibleColumns}
                                headerMap={headerMap}
                            />

                        </div>
                    </div>

                    <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
                        <RevTableComponent
                            headers={headers}
                            headerMap={headerMap}
                            initialData={tableData}
                            searchQuery={searchTerm}
                            visibleColumns={visibleColumns}
                            itemsPerPage={100}
                            // selectedDate={selectedDate} 
                            // handleDateChange={handleDateChange} 
                            moduleName="Optimization"
                            pagination={pagination}
                            advancedFilters={filteredData}
                            onDateChange={() => { }}
                            allowedActions={allowedActions}
                        />
                    </div>
                    <Modal
                        title={
                            <span className="font-semibold text-xl space-y-3">
                                Export Output
                            </span>
                        }
                        visible={isExportModalOpen}
                        onCancel={() => {
                            handleExportModalClose();

                        }}
                        footer={null}
                        centered
                        afterClose={() => { handleExportModalClose() }}
                        style={{ top: "-4%" }}
                    >
                        <div className="flex flex-col space-y-4 mb-4">
                            <div className="">
                                <label>
                                    Optimization Type<span className="text-red-500">*</span>
                                </label>
                                <Select
                                    options={optimizationTypeOptions.map((option) => ({
                                        label: option,
                                        value: option,
                                    }))}
                                    value={{ label: selectedOptimizationType, value: selectedOptimizationType }}
                                    onChange={handleOptimizationTypeChange}
                                />
                                {optimizationTyperror && (<span className="text-red-500">Please Select Optimization Type</span>)}
                            </div>
                            <div className="">
                                <label>
                                    Service Provider<span className="text-red-500">*</span>
                                </label>
                                <Select
                                    options={serviceProviderOptions.map((option) => ({
                                        label: option,
                                        value: option,
                                    }))}
                                    value={{ label: selectedProvider, value: selectedProvider }}
                                    onChange={handleServiceProviderChange}

                                />
                                {providerError && (<span className="text-red-500">Please Select Service Provider</span>)}
                            </div>
                            <div className="">
                                <label className="field-label">
                                    Bill Period<span className="text-red-500">*</span>
                                </label>
                                <RangePicker
                                    className="w-full input"
                                    value={
                                        dateRange[0] && dateRange[1]
                                            ? [dateRange[0], dateRange[1]]
                                            : null
                                    }
                                    onChange={(dates) => {
                                        if (dates && dates.length === 2) {
                                            setDateRange([dates[0], dates[1]] as [Dayjs, Dayjs]);
                                            setDateError(false)
                                        } else {
                                            setDateRange([null, null]);
                                        }
                                    }}
                                    format="YYYY-MM-DD"
                                    disabledDate={disableFutureDates}
                                    popupClassName="custom-range-popup"
                                />
                                {dateError && (<span className="text-red-500">Please Select Bill Period</span>)}
                            </div>
                            <div className="flex space-x-4 justify-center">
                                <button className="cancel-btn" onClick={() => {
                                    handleExportModalClose();
                                }}>
                                    Cancel
                                </button>
                                <button className="save-btn" onClick={handleExport}>
                                    Export
                                </button>
                            </div>
                        </div>
                    </Modal>
                </div>
            </Suspense>
            <div>
            </div>
            {/* <Modal
                title="Download record"
                visible={isDownloadModalOpen}
                onCancel={closeDownloadModal}
                centered
                footer={
                    <div className="justify-center flex space-x-2">
                        <button key="cancel" className='cancel-btn' onClick={closeDownloadModal}>
                            Cancel
                        </button>
                        <button key="confirm" className='save-btn' onClick={handleDownload}>
                            OK
                        </button>
                    </div>
                }
            >
                <p>Are you sure you want to submit this data?</p>
            </Modal> */}
            {isDownloadModalOpen && (
                <DownloadModal
                    visible={isDownloadModalOpen}
                    rows={revRows}
                    onCancel={closeDownloadModal}
                    moduleName={"Optimization"}
                />
            )}
            {isUploadModalOpen && (
                <RowUploadModal
                    visible={isUploadModalOpen}
                    rows={revRows}
                    onCancel={closeUploadModal}
                    optimization_type={uploadOptimizationType}
                />
            )}
            {isOptimizeModalVisible && (
                <Optimize
                    isOpen={isOptimizeModalVisible}
                    onCancel={handleOptimizeCancel}
                    module_name={'Optimization'}
                    onSubmit={handleOptimizeCancel}
                />
            )}
        </>

    );

};

export default Optimization;
