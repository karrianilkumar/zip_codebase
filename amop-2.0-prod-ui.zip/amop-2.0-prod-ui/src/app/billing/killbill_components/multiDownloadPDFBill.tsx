// "use client";
// import { useCallback, useEffect, useRef, useState, lazy } from "react";
// import axios from "axios";
// import { Modal } from "antd";
// import { ENV_ROUTES } from "@/app/components/routes/route_constants";
// import { useCustomerProfileStore } from "../killbill_stores/customer_profile_store";
// import { useTemplateStore } from "../killbill_stores/templateStore";
// import { useAuth } from "@/app/components/auth_context";
// const MultiTemplate = lazy(() => import("@/app/billing/multiGenerateBill/createMultiTemplate"));

// const InvoiceTemplate = lazy(() => import("@/app/billing/generate_bill/invoiceTemplate"));

// interface MultiDownloadPDFBillProps {
//   isOpen: boolean;
//   onClose: () => void;
//   rowData: any;
// }

// const MultiDownloadPDFBill: React.FC<MultiDownloadPDFBillProps> = ({ isOpen, onClose, rowData }) => {
//   const [loading, setLoading] = useState(false);
//   const [invoiceData, setInvoiceData] = useState<any>(null);
//   const { accountNumber } = useCustomerProfileStore();
//   const { setTemplateData } = useTemplateStore();
//   const { partner, token, selectedDb, sessionId } = useAuth();
//   const hasFetchedData = useRef(false);

//   // Parse pdf_template from rowData
//   const parsedTemplate = rowData?.pdf_template ? JSON.parse(rowData.pdf_template) : null;
//   const templateData = {
//     template_name: rowData?.template_name || "Default Template",
//     pdf_template: Array.isArray(parsedTemplate) ? parsedTemplate : [],
//   };

//   // Fetch invoice data
//   const fetchInvoiceData = useCallback(async () => {
//     setLoading(true);
//     const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
//     const data = {
//       account_number: accountNumber || rowData?.account_number,
//       id: rowData?.id,
//       path: "/generate_bill_pdf",
//       tenant_name: partner || "default_value",
//       access_token: token,
//       db_name: selectedDb,
//       sessionID: sessionId,
//     };

//     try {
//       const response = await axios.post(url, { data });
//       const fetchedData = JSON.parse(response.data.data);
//       setInvoiceData(fetchedData);
//     } catch (error) {
//       console.error("Error fetching invoice data:", error);
//       Modal.error({
//         title: "Error",
//         content: "Failed to fetch invoice data. Please try again.",
//       });
//     } finally {
//       setLoading(false);
//     }
//   }, [accountNumber, rowData?.id, partner, token, selectedDb, sessionId]);

//   // Fetch data and set template when modal opens
//   useEffect(() => {
//     if (isOpen && !hasFetchedData.current) {
//       hasFetchedData.current = true;
//       setInvoiceData(null);
//       setTemplateData([templateData]); // Set parsed template from rowData
//       fetchInvoiceData();
//     }
//   }, [isOpen, fetchInvoiceData, setTemplateData, templateData]);

//   // Reset state when modal closes
//   useEffect(() => {
//     if (!isOpen) {
//       setInvoiceData(null);
//       setTemplateData([]);
//       hasFetchedData.current = false;
//     }
//   }, [isOpen, setTemplateData]);

//   if (!isOpen) return null;

//   return (
//     <Modal
//       title="Preview and Download PDF Bill"
//       open={isOpen}
//       onCancel={onClose}
//       footer={null}
//       width={1000}
//       centered
//     >
//       {loading && <div className="opt-details-export-processing-div">Loading...</div>}
//       {invoiceData && (
//             <MultiTemplate invoiceData={invoiceData}  templateData={templateData} downloadPDF={false}/>
//       )}
//     </Modal>
//   );
// };

// export default MultiDownloadPDFBill;

"use client";
import { useEffect, useRef, useState, lazy } from "react";
import { Modal, Spin } from "antd";
import { useCustomerProfileStore } from "../killbill_stores/customer_profile_store";
import { useTemplateStore } from "../killbill_stores/templateStore";
// const MultiTemplate = lazy(() => import("@/app/billing/multiGenerateBill/createMultiTemplate"));

interface MultiDownloadPDFBillProps {
  isOpen: boolean;
  onClose: () => void;
  rowData: any;
}

const invoice_data = {
  "tenant": "Altaworx Test",
  "contact_number": "",
  "constact_email": "testing@gmail.com",
  "billTo": "455 Magnolia Ave, Suite B, Alabama, Florida, 36532, United States",
  "remitTo": "6445 Powers Ferry Rd, #350\nAtlanta\nGA\n30339\n",
  "billDate": "2025-03-20 07:24:56",
  "dueDate": "2025-03-31",
  "totalAmount": 2048.6,
  "bill_id": "450",
  "customer_id": "300000118",
  "summary": {
    "paymentsReceived": 10.0,
    "Reccurring Charges": 48.0,
    "Non-Reccurring Charges": 2000.6,
    "Total Amount Due": 2038.6
  },
  "items": [
    {
      "heading": "Recurring Charges",
      "sub_total": 48.0,
      "msisdn_phone": null,
      "address": "Altaworx, LLC\nP.O. Box 15577\nHattiesburg, MS 39404",
      "table_headers": {
        "description": "Description",
        "start": "Start",
        "end": "End",
        "amt": "Amount"
      },
      "table_rowData": [
        {
          "description": "Lens",
          "amt": 24.0,
          "start": "2025-03-20",
          "end": ""
        },
        {
          "description": "COFE",
          "amt": 12.0,
          "start": "2025-03-20",
          "end": ""
        },
        {
          "description": "Lens",
          "amt": 12.0,
          "start": "2025-03-20",
          "end": ""
        }
      ]
    },
    {
      "heading": "Non Recurring Charges",
      "sub_total": 2000.6,
      "msisdn_phone": null,
      "address": "Altaworx, LLC\nP.O. Box 15577\nHattiesburg, MS 39404",
      "table_headers": {
        "description": "Description",
        "start": "Start",
        "end": "End",
        "amt": "Amount"
      },
      "table_rowData": [
        {
          "description": "Network Access Fee",
          "start": "",
          "end": "",
          "amt": 0.36
        },
        {
          "description": "Cost Recovery Fee",
          "start": "",
          "end": "",
          "amt": 0.24
        },
        {
          "description": "TEST",
          "start": "2025-04-29",
          "end": "2025-04-29",
          "amt": 2000.0
        }
      ]
    },
    {
      "heading": "Credits",
      "sub_total": 0,
      "table_headers": {
        "description": "Description",
        "start": "Start",
        "end": "End",
        "amt": "Amount"
      },
      "table_rowData": []
    },
    {
      "heading": "Payments",
      "sub_total": 10.0,
      "table_headers": {
        "description": "Description",
        "date": "Date",
        "amt": "Amount"
      },
      "table_rowData": [
        {
          "description": "Thanks for the Payment",
          "date": "2025-03-20 12:56:17.464000",
          "amt": 10.0
        }
      ]
    },
    {
      "heading": "Taxes",
      "sub_total": 1.08,
      "table_headers": {
        "tax": "Tax"
      },
      "table_rowData": [
        {
          "tax": 1.08
        }
      ]
    },
    {
      "heading": "Management Reports",
      "sub_heading": "Master Account Summary",
      "total_mrc": 48.0,
      "total_nrc": 2000.6,
      "total_usage": 0,
      "total_cred": 0.0,
      "total_tax": 1.08,
      "table_headers": {
        "acct": "Acct",
        "mrc": "MRC",
        "nrc": "NRC",
        "usage": "Usage",
        "cred": "Cred",
        "tax": "Tax"
      },
      "table_rowData": [
        {
          "acct": "300000118",
          "mrc": 48.0,
          "nrc": 2000.6,
          "usage": 0,
          "cred": 0.0,
          "tax": 1.08
        }
      ]
    }
  ]
};

const MultiDownloadPDFBill: React.FC<MultiDownloadPDFBillProps> = ({ isOpen, onClose, rowData }) => {
  const [loading, setLoading] = useState(false);
  const [invoiceData, setInvoiceData] = useState<any>(null);
  const { accountNumber } = useCustomerProfileStore();
  const { setTemplateData } = useTemplateStore();
  const hasFetchedData = useRef(false);
  console.log(rowData,"Show rowData.....");
  // Parse pdf_template from rowData
  const parsedTemplate = rowData?.pdf_template ? JSON.parse(rowData.pdf_template) : null;
  const templateData = {
    template_name: rowData?.template_name || "Default Template",
    pdf_template: Array.isArray(parsedTemplate) ? parsedTemplate : [],
  };

  // Set dummy invoice data when modal opens
useEffect(() => {
  if (isOpen && !hasFetchedData.current) {
    hasFetchedData.current = true;
    setLoading(true);

    // Simulate async data fetch
    const fetchData = async () => {
      // Mimic an API or processing delay
      await new Promise((res) => setTimeout(res, 300));
      setInvoiceData(invoice_data);
      setTemplateData([templateData]);
      setLoading(false);
    };

    fetchData();
  }
}, [isOpen, setTemplateData, templateData]);


  // Reset state when modal closes
  useEffect(() => {
    if (!isOpen) {
      setInvoiceData(null);
      setTemplateData([]);
      hasFetchedData.current = false;
    }
  }, [isOpen, setTemplateData]);

  if (!isOpen) return null;

  return (
    <Modal
      title="Preview and Download PDF Bill"
      open={isOpen}
      onCancel={onClose}
      footer={null}
      width={1000}
      centered
    >
      <>
      {
  // loading ? (
  //   <div className="flex justify-center items-center min-h-[500px]">
  //     <Spin size="large" />
  //   </div>
  // ) : (
  //   invoiceData && (
  //     <MultiTemplate
  //       invoiceData={invoiceData}
  //       templateData={templateData}
  //       downloadPDF={false} // Preview only, no auto-download
  //       preview={true} // Enable preview mode
  //     />
  //   )
  // )
}
      </>
    </Modal>
  );
};

export default MultiDownloadPDFBill;

