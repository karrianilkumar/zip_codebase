import React from 'react';
import { Modal, Button, List } from 'antd';

interface PackageListModalProps {
  isOpen?: boolean;
  onClose?: () => void;
  rowData?: any; // Allow any type for rowData (string, array, etc.)
}

const PackageListModal: React.FC<PackageListModalProps> = ({ isOpen, onClose, rowData }) => {

  // Function to process rowData if it's a stringified array-like string
  const processRowData = (data: any) => {
    if (typeof data === 'string') {
      // If the string looks like an array (contains '[' and ']'), treat it as an array-like string
      if (data === '[]' || data === 'null' || data === '') {
        return []; // If it's '[]' or empty, return an empty array
      }

      if (data.startsWith('[') && data.endsWith(']')) {
        // Remove the surrounding brackets and split by comma
        return data.slice(1, -1).split(',').map(item => item.trim().replace(/^'|'$/g, '').trim());
      }

      return [data]; // If it's just a string, treat it as a single item in the list
    }

    return data || []; // Return data as-is if it's already an array, or empty if it's null or undefined
  };

  // Function to render content based on the type of rowData
  const renderContent = () => {
    const processedData = processRowData(rowData); // Process the rowData into an array if needed

    // Case 1: If processedData is an empty array or rowData is `[]`, show "No products available."
    if (Array.isArray(processedData) && processedData.length === 0) {
      return (
        <div className="text-center">
          <h3>No packages available</h3>
        </div>
      );
    }

    // Case 2: If processedData is an array, display its contents correctly
    if (Array.isArray(processedData)) {
      return (
        <div style={{ maxHeight: '300px', overflowY: 'auto' }}>
          <List
            size="large"
            bordered
            dataSource={processedData}
            renderItem={(item) => (
              <List.Item>
                <strong>{item}</strong>
              </List.Item>
            )}
          />
        </div>
      );
    }

    // If processedData is of an unexpected type, show a default message or error
    return (
      <div className="text-center">
        <h3>Invalid data format.</h3>
      </div>
    );
  };

  return (
    <Modal
      title="Package List"
      visible={isOpen}
      onCancel={onClose}
      footer={[
        <Button key="close" onClick={onClose}>
          Close
        </Button>
      ]}
      style={{ maxWidth: '80%' }} // Adjust modal width
      bodyStyle={{ padding: '0 20px' }} // Add some padding for better content display
    >
      {renderContent()}
    </Modal>
  );
};

export default PackageListModal;
