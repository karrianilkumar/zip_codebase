import React, { lazy, Suspense, useCallback, useEffect, useRef, useState } from "react";
import { Modal, Input, Spin, notification, Tooltip, Checkbox } from 'antd';
import { Select } from "antd";
import { DropdownStyles } from '@/app/components/css/dropdown';
import { DatePicker } from 'antd';
import KillbillTableComponent from "./table__component"; // Ensure this path is correct
import { useAuth } from "@/app/components/auth_context";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { CloseOutlined } from "@ant-design/icons";
import VirtualList from "rc-virtual-list";
import { useKillBillStore } from "../killbill_stores/activeStore";
const { RangePicker } = DatePicker;

interface CreatePackageModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: any;
  modalData: {
    id: number;
    display_name: string;
    type: string;
    mandatory: boolean;
    db_column_name: string;
  }[];
  title: string;
  generalFields?: any;
  isEditable?: boolean;
  action?: string;
  rowData?: any;


}
const TableComponent = lazy(
  () => import("@/app/components/TableComponent/page")
);
// const CreateModal = lazy(() => import("@/app/components/createPopup"));
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));
const TableSearch = lazy(() => import("@/app/components/entire_table_search"));
const AdvancedMultiFilter = lazy(
  () => import("@/app/components/advanced_search")
);
const EditableTableComponent = lazy(
  () => import("./editable_table_component"));

const CreatePackageModal: React.FC<CreatePackageModalProps> = ({
  isOpen,
  onClose,
  onSave,
  modalData,
  title,
  generalFields,
  isEditable,
  action,
  rowData
}) => {
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("General");
  const [productsFields, setProductsFields] = useState<any[]>([]);
  const [fieldsData, setFieldsData] = useState<any[]>([]);
  const [isExpanded, setIsExpanded] = useState(false);
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const [UpdatedTableData, setUpdatedTableData] = useState<string[]>([]);

  const { username, partner, role, token, selectedDb,metaData,selectedBillingDb, sessionId, settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId, firstLastName, setStoredPagination, setAdvancedStoredPagination } = useAuth();
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  const [filteredData, setFilteredData] = useState([]);
  const [isLoading, setIsLoading] = useState(false); // Loading state
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
  const [PopupData, setPopupData] = useState([]);
  const [generalFormData, setGeneralFormData] = useState<Record<string, any>>({});
  const [productsFormData, setProductsFormData] = useState<Record<string, any>>({});
  const [productTypeOptions, setProductTypeOptions] = useState<{ label: string; value: string }[]>([]);
  const [dependentOptions, setDependentOptions] = useState<{ label: string; value: string }[]>([]);
  const [generalFields2, setgeneralFields2] = useState<Record<string, any>>({});
  const [productsearchValue, setProductSearchValue] = useState("");
  const [productTypeSearchValue, setproductTypeSearchValue] = useState("");
  const [validationErrors, setValidationErrors] = useState<{
    [key: string]: string;
  }>({});
  const [maxHeight, setMaxHeight] = useState('auto'); // State to hold the maximum height
  const { serviceShowActive, productTypeShowActive, packageActive ,productShowActive , servicesActive , customerProfilesActive} = useKillBillStore();
  
      // Function to calculate the height of the content
      const calculateHeight = () => {
        const generalContentHeight = document.getElementById('general-content')?.offsetHeight || 0;
        const productsContentHeight = document.getElementById('products-content')?.offsetHeight || 0; 
        const newHeight = Math.max(generalContentHeight, productsContentHeight);
        setMaxHeight(`${newHeight}px`); // Convert newHeight to a string with 'px' suffix
      };
  
  useEffect(() => {
    // Calculate height on mount and when active tab changes
    calculateHeight();
    window.addEventListener('resize', calculateHeight); // Recalculate on window resize

    return () => {
      window.removeEventListener('resize', calculateHeight); // Cleanup
    };
  }, [activeTab]);

  const hasFetchedData = useRef(false);

  const {
    iccid,
    bulkRow,
    features: moduleFeatures,
    setFeatures: setModuleFeatures,
    setICCID,
    setBulkRow
  } = useFeatureStore();
  useEffect(() => {
    console.log("Updated productsFormData:", productsFormData);  // Verify changes
  }, [productsFormData]);
  type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);

  const SubmitData = async (data: any) => {
    setIsLoading(true);
    try {
      const url = ENV_ROUTES.BP_SERVICES_PRODUCTS;
      let Action = action === "create" ? "update" : "copy"
      let Path = action === "create" ? "/add_package" :action === "edit"? "/update_package":"/copy_package"
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";

      const requestData = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: Path,
        role_name: role,
        module_name: "Billing Packages",
        feature_module_name: "Billing Platform",
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        // table_name: "sim_management_inventory",
        request_received_at: getCurrentDateTime(),
        sessionID: sessionId,
        action: Action,
        tenant_id:tenant_id_,
        modified_by: firstLastName,
        main_module_name: "Products",
        changed_data: { ...data } // Spread the collected data here
      };

      const response = await axios.post(url, { data: requestData });
      const parsedData_ = JSON.parse(response.data.body);

      if (parsedData_.flag === false) {
        if(parsedData_.status === false){
          Modal.error({
            title: 'Submit Error',
            content: parsedData_.message || 'An error occurred while fetching data. Please try again.',
            centered: true,
            
          })
        }
        else{
          Modal.error({
            title: 'Submit Error',
            content: parsedData_.message || 'An error occurred while fetching data. Please try again.',
            centered: true,
            onOk: handlecancle
          });
        }
      } else {
        if (parsedData_?.validation) {
          Modal.error({
            title: "Validation Error",
            content: parsedData_.message || "An error occurred while submitting data. Please try again.",
            centered: true,
          });
          return;
        }
        let parsedData: any;
        try {
          setIsLoading(true);
          const url = ENV_ROUTES.BP_SERVICES_PRODUCTS;
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/services_product_package_list_view",
            role_name: role,
            parent_module: "Billing Platform",
            module_name: "Billing Packages",
            mod_pages: {
              start: 0,
              end: 100,
            },
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
            ...metaData,
billing_db_name: selectedBillingDb,
            tenant_id:tenant_id_,
            sessionID: sessionId,
            status: packageActive?"true":"false",
            feature_module_name: "Billing Packages",
        main_module_name: "Products",
          };

          const response = await axios.post(url, { data });
          parsedData = JSON.parse(response.data.body);
           if (response.data.statusCode === 200 && parsedData.flag === true) {
            if(parsedData?.validation){
                                Modal.error({
                                  title: "Validation Error",
                                  content: parsedData.message,
                                  centered: true,
                                });
                                return;
                              }
          if (parsedData.flag === true) {
            settabledata(parsedData?.data?.billing_packages || []);
          };
          
          notification.success({
            message: 'Success',
            description: 'Successfully updated!',
            placement: 'top',
          });
          handlecancle();
        }
        }
        catch { }
        finally { setIsLoading(false) }
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Submit Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting data. Please try again.',
        centered: true,
        onOk: handlecancle
      });
    } finally {
      setIsLoading(false);
    }
  };
  const handleSubmit = () => {
    const newErrors: { [key: string]: string } = {};
    const formElement = document.querySelector('form') as HTMLFormElement | null; // Safeguard against null

    if (!formElement) {
      console.error("Form element not found");
      return; // Exit the function if no form element is found
    }

    setErrors(newErrors);

    const formData = new FormData(formElement);
    const data = Array.from(formData.entries()).reduce(
      (acc, [key, value]) => ({ ...acc, [key]: value }),
      {}
    );

    const combinedData = {

      generalData: generalFormData,  // Data from the "General" tab
      productsData: {
        ...productsFormData,
        UpdatedTableData: UpdatedTableData && UpdatedTableData.length ? UpdatedTableData : tableData
      }
    };

    console.log("UpdatedTableData", UpdatedTableData)
    SubmitData(combinedData);

  };
  const handlecancle = () => {
    setGeneralFormData({});
    setProductsFormData({ description: "" });
    setDependentOptions([]);
    onClose()
    setTableData([])
    setActiveTab("General");
    setValidationErrors({});

  }

  const handleCancelConfirmation = () => {
    setIsConfirmationOpen(false);
  };

  const fetchPackagePopupData = async () => {
    let parsedData: any;
    try {
      setIsLoading(true);
      const url = ENV_ROUTES.BP_SERVICES_PRODUCTS;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/product_package_pop_up_list_view",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing Packages",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        feature_module_name: "Billing Packages",
        main_module_name: "Products",
      };

      const response = await axios.post(url, { data });
      console.log("API Response:", response.data);
      parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === true) {
        // Log data and set loading to false immediately to stop the loader
        // setIsLoading(false);
        console.log("table response:", getCurrentDateTime());
        //  setLoading(false); // Ensure this happens right away

        // Defer other state updates using a timeout to decouple them from the main thread
        setTimeout(() => {
          const headersMap_ = parsedData?.header_map?.["Product Packages"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);
          console.log("parsedData", parsedData)
          setgeneralFields2(parsedData || {})
          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
          console.log("headers", headers_)
          setHeaders(headers_);
          setVisibleColumns(headers_);
          setFeatures(parsedData?.header_map?.["Product Packages"]?.module_features || []);
          setModuleFeatures(parsedData?.header_map?.["Product Packages"]?.module_features || []);
          const featres_ = parsedData?.header_map?.["Product Packages"]?.module_features || []
          const createModalData_ = parsedData?.header_map?.["Product Packages"]?.pop_up || []
          console.log("createModalData_", createModalData_)
          setProductsFields(createModalData_)
        }, 0);
        // requestIdleCallback(() => {
        //   setTableData(parsedData?.inventory_data || []);
        //   console.log("table response:", getCurrentDateTime());
        // });
      } else {
        //  setIsLoading(false);
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      //  setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setIsLoading(false);
    }

  };


  useEffect(() => {
    console.log("Current active tab:", activeTab);
    console.log("Current table data:", fieldsData);
    // setFieldsData([]);
    if (activeTab === "General") {
      // setIsLoading(true);
      setFieldsData(modalData.filter((field) => field.type !== "products"));
    } else if (activeTab === "Products") {
      // setIsLoading(true);
      setFieldsData([]);

      if (!hasFetchedData.current) {
        fetchPackagePopupData();
        hasFetchedData.current = true;
      }

    }

  }, [activeTab]);
  useEffect(() => {
  if (activeTab === "Products") {
    if (!hasFetchedData.current) {
      fetchPackagePopupData();
      hasFetchedData.current = true;
    }
  } else {
    // When user leaves "Products" tab, reset the flag
    hasFetchedData.current = false;
  }
}, [activeTab]);


 const handleFilterLoad = (event:any) => {
  event.preventDefault()
  const errors: { [key: string]: string } = {};

    productsFields.forEach((column) => {

      if (column.mandatory) {
        const value = productsFormData[column.db_column_name];

        if (
          (Array.isArray(value) && value.length === 0) ||
          (!Array.isArray(value) && !value)
        ) {
          errors[column.db_column_name] = `${column.display_name} is required.`;
        }
        // errors[column.db_column_name] = `${column.display_name} is required.`;
      }
    });




    if (Object.keys(errors).length > 0) {
      setValidationErrors(errors);
    } else {
      setValidationErrors({});
      fetchPackageTableData();
    }
};



  useEffect(() => {
    // if (generalFields2.dropdown?.product_type) {
    //   const options = Object.keys(generalFields2.dropdown.product_type).map((key) => ({
    //     label: key,
    //     value: key,
    //   }));
    //   setProductTypeOptions(options);
    // }
  if (generalFields2?.dropdown?.description) {
  console.log(
    "generalFields2?.dropdown?.description",
      generalFields2.dropdown.description
    );

    const options = Array.isArray(generalFields2.dropdown.description)
      ? generalFields2.dropdown.description
      : [];

    setDependentOptions(
      options.map((key: string) => ({
        label: key,
        value: key,
      }))
    );
  }

  }, [generalFields2]);

  const modalWidth =
    typeof window !== 'undefined' ? (window.innerWidth * 3) / 4 : 0;
  const modalHeight =
    typeof window !== 'undefined' ? (window.innerHeight * 2.5) / 4 : 0;

  if (!isOpen) return null;
  const handleTabChange = (tab: React.SetStateAction<string>) => {

    const errors: { [key: string]: string } = {};
    console.log(tab,"Show the tab")
    modalData.forEach((column) => {

      if (column.mandatory) {
        const value = generalFormData[column.db_column_name];

        if (
          (Array.isArray(value) && value.length === 0) ||
          (!Array.isArray(value) && !value)
        ) {
          errors[column.db_column_name] = `${column.display_name} is required.`;
        }
        // errors[column.db_column_name] = `${column.display_name} is required.`;
      }
    });




    if (Object.keys(errors).length > 0) {
      setValidationErrors(errors);
      setIsConfirmationOpen(false); // Don't show confirmation popup if there are errors
    } else {
      console.log("Changing tab to:", tab)
      // setIsLoading(true);
      setActiveTab(tab);
      calculateHeight(); // Recalculate height on tab change
      setValidationErrors({});
      // setIsConfirmationOpen(true); // Only open the confirmation popup if there are no errors
    } 

  }
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>, tab: string) => {
    const { name, value } = e.target;

    if (tab === "General") {
      setGeneralFormData((prev) => ({ ...prev, [name]: value }));
    } else if (tab === "Products") {
      setProductsFormData((prev) => ({ ...prev, [name]: value }));
    }
    let errors = { ...validationErrors };
    setValidationErrors(errors);
  };
  const showConfirmation = () => {
    const errors: { [key: string]: string } = {};

    productsFields.forEach((column) => {

      if (column.mandatory) {
        const value = productsFormData[column.db_column_name];

        if (
          (Array.isArray(value) && value.length === 0) ||
          (!Array.isArray(value) && !value)
        ) {
          errors[column.db_column_name] = `${column.display_name} is required.`;
        }
        // errors[column.db_column_name] = `${column.display_name} is required.`;
      }
    });




    if (Object.keys(errors).length > 0) {
      setValidationErrors(errors);
      setIsConfirmationOpen(false); // Don't show confirmation popup if there are errors
    } else {
      setValidationErrors({});
      setIsConfirmationOpen(true); // Only open the confirmation popup if there are no errors
    }

  };

  const handleConfirm = () => {
    setIsConfirmationOpen(false);
    handleSubmit()
  }




  // const handleProductTypeChange = (selectedValues: string[]) => {
  //   console.log('Selected Values:', selectedValues); // Ensure this logs the correct selected values

  //   // Collect dependent options for the selected keys
  //   const aggregatedDependentOptions = selectedValues.flatMap((key: string) => {
  //     return generalFields2?.dropdown?.product_type?.[key] || [];
  //   });

  //   // Ensure options are unique
  //   const uniqueDependentOptions = Array.from(new Set(aggregatedDependentOptions)).map((option: any) => ({
  //     label: option,
  //     value: option,
  //   }));

  //   // Set the dependent options
  //   setDependentOptions(uniqueDependentOptions);

  //   // Update the form data
  //   setProductsFormData((prev) => ({
  //     ...prev,
  //     product_type: selectedValues, // Ensure selected values are an array of strings
  //     description: "", // Reset description when product type changes
  //   }));

  //   // Clear validation errors
  //   let errors = { ...validationErrors };
  //   delete errors.product_type;
  //   setValidationErrors(errors);
  // };




  const fetchPackageTableData = async () => {
    let parsedData: any;
    const payload = {
      description: productsFormData.description || null, // Use state value
      // product_type: productsFormData.product_type || null,
    };
    try {
      setIsLoading(true);
      const url = ENV_ROUTES.BP_SERVICES_PRODUCTS;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";

      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/product_package_pop_up_list_view_data",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing Packages",
        mod_pages: {
          start: 0,
          end: 100,
        },
        changed_data: payload,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        tenant_id:tenant_id_,
        sessionID: sessionId,
        feature_module_name: "Billing Packages",
        main_module_name: "Products",
      };

      const response = await axios.post(url, { data });
      console.log("API Response:", response.data);
      parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === true) {
        // Log data and set loading to false immediately to stop the loader
        setIsLoading(false);
        console.log("table response:", getCurrentDateTime());
        //  setLoading(false); // Ensure this happens right away

        // Defer other state updates using a timeout to decouple them from the main thread
        setTimeout(() => {
          setTableData((prevTableData:any) => {
            if (!prevTableData.length) {
              console.log("🔹 First fetch, setting new data");
              return parsedData?.data?.product_packages || [];
            }
          
            const oldTableData = [...prevTableData];
            const newTableData = parsedData?.data?.product_packages || [];
          
            console.log("🟢 Old Table Data:", oldTableData);
            console.log("🟡 New Table Data:", newTableData);
          
            // 1️⃣ Find IDs in old data
            const oldDataIds = new Set(oldTableData.map((row) => row.id));
          
            // 2️⃣ Find IDs in new data
            const newDataIds = new Set(newTableData.map((row: { id: any; }) => row.id));
          
            // 3️⃣ Add new rows (IDs that are in newData but not in oldData)
            const addedRows = newTableData.filter((row: { id: any; }) => !oldDataIds.has(row.id));
          
            // 4️⃣ Keep existing rows (IDs that are in both old and new data)
            const unchangedRows = oldTableData.filter((row) => newDataIds.has(row.id));
          
            // 5️⃣ Remove rows (IDs that exist in oldData but not in newData)
            const removedRows = oldTableData.filter((row) => !newDataIds.has(row.id));
          
            console.log("✅ Added Rows:", addedRows);
            console.log("✅ Unchanged Rows:", unchangedRows);
            console.log("✅ Removed Rows:", removedRows);
          
            // Merge old and new data, keeping only valid rows
            return [...unchangedRows, ...addedRows];
          });
          
          const headersMap_ = parsedData?.header_map?.["Product Packages"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);
          console.log("parsedData", parsedData)
          // setgeneralFields2(parsedData || {})
          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
          console.log("headers", headers_)
          setHeaders(headers_);
          setVisibleColumns(headers_);
          setFeatures(parsedData?.header_map?.["Product Packages"]?.module_features || []);
          setModuleFeatures(parsedData?.header_map?.["Product Packages"]?.module_features || []);
          const featres_ = parsedData?.header_map?.["Product Packages"]?.module_features || []
          const createModalData_ = parsedData?.header_map?.["Product Packages"]?.pop_up || []
          console.log("createModalData_", createModalData_)
          setProductsFields(createModalData_)
          setPagination(parsedData?.pages || {});
         

          // Defer heavy state updates to allow the UI to remain responsive
          // setTimeout(() => {
          //   setTableData(parsedData?.inventory_data || []);
          // }, 0);
        }, 0);
        // requestIdleCallback(() => {
        //   setTableData(parsedData?.inventory_data || []);
        //   console.log("table response:", getCurrentDateTime());
        // });
      } else {
        //  setIsLoading(false);
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      //  setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setIsLoading(false);
    }

  };
  // const handleCheckboxChange = (selectedOption: string, isChecked: boolean) => {
  //   // Ensure product_type is always an array
  //   const currentProductType = Array.isArray(productsFormData.product_type)
  //     ? productsFormData.product_type
  //     : []; // Fallback to an empty array if not an array
  
  //   // Add or remove selectedOption from the product_type list
  //   const updatedSelectedValues = isChecked
  //     ? [...currentProductType, selectedOption] // Add if checked
  //     : currentProductType.filter((item: string) => item !== selectedOption); // Remove if unchecked
  
  //   // Collect dependent options based on the selected product types
  //   const aggregatedDependentOptions = updatedSelectedValues.flatMap((key: string) => {
  //     return generalFields2?.dropdown?.product_type?.[key] || [];
  //   });
  
  //   // Ensure dependent options are unique
  //   const uniqueDependentOptions = Array.from(new Set(aggregatedDependentOptions)).map((option: any) => ({
  //     label: option,
  //     value: option,
  //   }));
  
  //   // **Ensure description is an array before filtering**
  //   const updatedDescription = Array.isArray(productsFormData.description)
  //     ? productsFormData.description.filter((desc: string) =>
  //         uniqueDependentOptions.some((opt) => opt.value === desc)
  //       )
  //     : []; // Default to empty array if not valid
  
  //   // Update state for dependent options and the selected product types
  //   setDependentOptions(uniqueDependentOptions);
  
  //   // Update the form data with the newly selected product types and filtered description values
  //   setProductsFormData((prev) => ({
  //     ...prev,
  //     product_type: updatedSelectedValues, // Update product types
  //     description: updatedDescription, // Remove descriptions that are no longer valid
  //   }));
  
  //   // Clear validation errors for product_type if they exist
  //   let errors = { ...validationErrors };
  //   delete errors.product_type;
  //   setValidationErrors(errors);
  // };

 // Function to validate required fields and set error messages
 const validateRequiredFields = () => {
  const errors: { [key: string]: string } = {};
  modalData.forEach((field) => {
    if (field.mandatory) {
      const value = generalFormData[field.db_column_name];
      if ((Array.isArray(value) && value.length === 0) || (!Array.isArray(value) && !value)) {
        errors[field.db_column_name] = `${field.display_name} is required.`;
      }
    }
  });
  return errors;
};

// Handle Next button click
const handleNextClick = () => {
  const errors = validateRequiredFields();
  if (Object.keys(errors).length > 0) {
    setValidationErrors(errors); // Set validation errors
  } else {
    setValidationErrors({}); // Clear any existing errors
    setActiveTab("Products"); // Change to Products tab
  }
};



  return (
    <div>
      <Modal
        open={isOpen}
        onCancel={handlecancle}
        title={
          <h3 className="popup-heading">
            {action === "copy"
              ? `Copy ${title}`
              : `Add ${title}`}
          </h3>
        }
        centered
        // footer={
        //   <div className="!mt-2">
        //     {activeTab === "Products" ? (
        //       <div className="justify-center mt-[4px] flex space-x-2">
        //         <button onClick={handlecancle} className="cancel-btn">
        //           Cancel
        //         </button>
        //         <button onClick={showConfirmation} className="save-btn">
        //           Create
        //         </button>
        //       </div>
        //     ) : (
        //       <div style={{ height: "46px" }} /> // Placeholder footer for General tab
        //     )}
        //   </div>
        // }
        footer={
          <div className="!mt-2">
            {activeTab === "General" ? (
              <div className="justify-center mt-[4px] flex space-x-2">
                <button onClick={handlecancle} className="cancel-btn">
                  Cancel
                </button>
                <button
                  onClick={handleNextClick} // Use the new handler
                  className="save-btn"
                >
                  Next
                </button>
              </div>
            ) : (
              <div className="justify-center mt-[4px] flex space-x-2">
                <button onClick={handlecancle} className="cancel-btn">
                  Cancel
                </button>
                <button onClick={showConfirmation} className="save-btn">
                  Create
                </button>
              </div>
            )}
          </div>
        }
        width={modalData.length > 5 ? modalWidth : '800px'}
        bodyStyle={{ padding: '4px', minHeight: "430px", height: maxHeight, overflow: 'auto' }} // Set fixed height and hide overflow
      >
        <div className={`rounded flex centered w-1/4 h-12 gap-2 mb-4`}>
        <button
            className={`tab-headings ${activeTab === "General" ? "active-tab-heading" : ""}`}
            onClick={() =>  handleTabChange("General") }
          >
            General
          </button>

          <button
            className={`tab-headings ${activeTab === "Products" ? "active-tab-heading" : ""}`}
            onClick={() =>   handleTabChange("Products")}
          >
            Products
          </button>
        </div>

        <div style={{ flex: '1', overflowY: 'auto' }}> {/* Prevent overall scroll */} 
          <form>
            {activeTab === "General" ? (
              <>
                {isLoading ? (
                  <div className="flex justify-center items-center h-[500px]">
                    <Spin size="large" />
                  </div>
                ) : (
                  <div className={`grid gap-4 grid-cols-1 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3 2xl:grid-cols-3`}>
                    {modalData.map((field) => (
                      <div key={field.id} className="mb-4">
                        <div className="flex flex-col">
                          <label className="field-label">
                            {field.display_name}
                            {field.mandatory && field.mandatory !== null && <span className="text-red-500">*</span>}
                          </label>
                        </div>

                        {field.type === "text" && (
                          <>
                            <Input
                              type="text"
                              name={field.db_column_name}
                              value={
                                generalFormData[field.db_column_name] || ""
                              }
                              onChange={(e) => handleInputChange(e, "General")}
                              className="input"
                            />
                            {validationErrors[field.db_column_name] && (
                              <span className="text-red-500">{validationErrors[field.db_column_name]}</span>
                            )}
                          </>
                        )}
                        {field.type === "dollar" && (
                          <div className="relative">
                            {/* Non-editable span for the dollar symbol */}
                            <span className="absolute left-2 top-1/2 transform -translate-y-1/2 pointer-events-none z-10">
                              $
                            </span>
                            <Input
                              type="number"
                              name={field.db_column_name}
                              className="input !pl-4" // Add padding-left to make room for the "$" symbol
                              value={generalFormData[field.db_column_name]} // Always append "$"
                              onChange={(e) =>
                                handleInputChange(e, "General")
                              }

                            />
                            {validationErrors[field.db_column_name] && (
                              <span className="text-red-500">
                                {validationErrors[field.db_column_name]}
                              </span>
                            )}
                          </div>
                        )}

                        
                        {field.type === "dropdown" && (
                          <>
                            <Select
                              allowClear
                              showArrow
                              showSearch
                              style={{ width: "100%", display: "flex",
                                alignItems: "center", marginTop:'5px'}}// Vertically center content
                              value={generalFormData[field.db_column_name] || undefined} // Ensuring value is correctly set
                              options={
                                Array.isArray(generalFields?.dropdown?.[field.db_column_name])
                                  ? generalFields.dropdown[field.db_column_name].map((option: string) => ({
                                    label: option,
                                    value: option,
                                  }))
                                  : []
                              }
                              onChange={(value) =>
                                setGeneralFormData((prev) => ({
                                  ...prev,
                                  [field.db_column_name]: value ?? "", // Ensure an empty string when cleared
                                }))
                              }
                              placeholder="Select an option"
                            />

                            {/* Validation Error Message */}
                            {validationErrors[field.db_column_name] && (
                              <span className="text-red-500 mt-2 block">{validationErrors[field.db_column_name]}</span>
                            )}
                          </>
                        )}

                      </div>
                    ))}
                  </div>
                )}
              </>
            ) : (
              <>
                {isLoading ? (
                  <div className="flex justify-center items-center h-[500px]">
                    <Spin size="large" />
                  </div>
                ) : (
                  <div className={`${isExpanded ? "mt-[50px]" : ""}`}>
                     <div className="grid grid-cols-1 sm:grid-cols-2 sm:gap-2 lg:grid-cols-3 gap-4">

                      {productsFields.map((field) => (
                        <div key={field.id} className="mb-2">
                          <label className="field-label">
                            {field.display_name}
                            {field.mandatory && <span className="text-red-500">*</span>}
                          </label>

                          {/* Description Dropdown */}
                          {field.type === "dropdown" && field.db_column_name === "description" && (
                            <>
                              <Select
                                mode="multiple"
                                allowClear
                                showArrow
                                showSearch
                                style={{ width: "100%" }}
                                value={Array.isArray(productsFormData.description) ? productsFormData.description : []}
                                options={dependentOptions.map((item) => ({
                                  label: String(item.label ?? ""),  // Convert to string safely
                                  value: String(item.value ?? ""),  // Convert to string safely
                                }))}
                                onChange={(selectedValues) =>
                                  setProductsFormData((prev) => ({
                                    ...prev,
                                    description: selectedValues.map((val) => String(val)),  // Ensure only strings
                                  }))
                                }
                                optionLabelProp="label"
                                maxTagCount={1}  // Show only 1 tag
                                maxTagPlaceholder={(omittedValues) => `+${omittedValues.length}`}  // Show count for omitted tags
                                tagRender={(props) => {
                                  const { label, closable, onClose } = props;
                                  const labelString = String(label);  // Ensure the label is a string
                                  const truncatedLabel = labelString.length > 190 ? `${labelString.slice(0, 187)}...` : labelString;  // Truncate long labels

                                  // Combine all selected labels for the tooltip
                                  const allSelectedLabels = Array.isArray(productsFormData.description)
                                    ? productsFormData.description.map((value: any) => {
                                      const option = dependentOptions.find((opt) => opt.value === value);
                                      return option?.label;
                                    }).join(", ")
                                    : ''; // Fallback to empty string if it's not an array

                                  return (
                                    <span
                                      className="inline-flex items-center text-ellipsis px-1 py-1 overflow-hidden whitespace-nowrap relative shadow-lg rounded-lg max-w-[185px]"
                                      title={allSelectedLabels}  
                                      style={{ 
                                        maxWidth: '165px',  // Fixed width for the tags
                                        wordWrap: 'break-word',  // Allow text to wrap
                                        overflow: 'hidden',  // Hide overflow
                                      }}// Tooltip for all selected labels
                                    >
                                      {truncatedLabel}  {/* Display truncated label */}
                                      {closable && (
                                        <CloseOutlined
                                          onClick={onClose}
                                          style={{ marginLeft: 4, cursor: 'pointer' }}
                                        />
                                      )}
                                    </span>
                                  );
                                }}
                                dropdownRender={(menu) => {
                                  const filteredOptions = dependentOptions.filter((item) =>
                                    item.label.toLowerCase().includes(productsearchValue.toLowerCase())
                                  );

                                  return (
                                    <div className="relative shadow-lg rounded-lg max-w-full">
                                      <div style={{ padding: "4px 8px" }}>
                                        <Input
                                          placeholder="Search..."
                                          size="middle"
                                          value={productsearchValue}
                                          onChange={(e) => setProductSearchValue(e.target.value)}
                                        />
                                      </div>
                                      <VirtualList
                                        data={filteredOptions}
                                        height={250}
                                        itemHeight={0}
                                        itemKey="value"
                                      >
                                        {(item) => (
                                          <div key={item.value} className="ml-2 mb-2 flex items-center">
                                            <Checkbox
                                              checked={(productsFormData.description ?? []).includes(item.value)}
                                              onChange={(e) =>
                                                setProductsFormData((prev) => ({
                                                  ...prev,
                                                  description: e.target.checked
                                                    ? [...(prev.description ?? []), item.value]
                                                    : (prev.description ?? []).filter((val: any) => val !== item.value),
                                                }))
                                              }
                                            >
                                              {item.label}
                                            </Checkbox>

                                          </div>
                                        )}
                                      </VirtualList>
                                    </div>
                                  );
                                }}
                                onDropdownVisibleChange={(open) => {
                                  if (!open) setProductSearchValue(""); // Clear search when dropdown closes
                                }}
                              />
                              {validationErrors[field.db_column_name] && (
                                <span className="text-red-500">{validationErrors[field.db_column_name]}</span>
                              )}
                            </>
                          )}


                          {/* Product Type Dropdown */}
                          {/* {field.type === "dropdown" && field.db_column_name === "product_type" && (
                            <>
                              <Select
                                mode="multiple"
                                allowClear
                                showArrow
                                showSearch
                                style={{ width: "100%" }}
                                value={Array.isArray(productsFormData.product_type) ? productsFormData.product_type : []}
                                options={productTypeOptions.map((item) => ({
                                  label: item.label,
                                  value: item.value,
                                }))}
                                onChange={handleProductTypeChange}
                                optionLabelProp="label"
                                maxTagCount={1}  
                                maxTagPlaceholder={(omittedValues) => `+${omittedValues.length}`}  
                                tagRender={(props) => {
                                  const { label, closable, onClose } = props;
                                  const labelString = String(label);  
                                  const truncatedLabel = labelString.length > 190 ? `${labelString.slice(0, 187)}...` : labelString;

                                  const allSelectedLabels = Array.isArray(productsFormData.product_type)
                                    ? productsFormData.product_type.map((value: any) => {
                                      const option = productTypeOptions.find((opt) => opt.value === value);
                                      return option?.label;
                                    }).join(", ")
                                    : ''; 

                                  return (
                                    <span
                                      className="inline-flex items-center text-ellipsis px-1 py-1 overflow-hidden whitespace-nowrap relative shadow-lg rounded-lg max-w-[185px]"
                                      title={allSelectedLabels} 
                                      style={{ 
                                        maxWidth: '165px',  
                                        wordWrap: 'break-word', 
                                        overflow: 'hidden',  
                                      }} 
                                    >
                                      {truncatedLabel} 
                                      {closable && (
                                        <CloseOutlined
                                          onClick={onClose}
                                          style={{ marginLeft: 4, cursor: 'pointer' }}
                                        />
                                      )}
                                    </span>
                                  );
                                }}
                                dropdownRender={(menu) => {
                                  const filteredOptions = productTypeOptions.filter((item) =>
                                    item.label.toLowerCase().includes(productTypeSearchValue.toLowerCase())
                                  );

                                  return (
                                    <div
                                      className="relative shadow-lg rounded-lg max-w-full">
                                      <div style={{ padding: "4px 8px" }}>
                                        <Input
                                          placeholder="Search..."
                                          size="middle"
                                          value={productTypeSearchValue}
                                          onChange={(e) => setproductTypeSearchValue(e.target.value)}
                                        />
                                      </div>
                                      <VirtualList
                                        data={filteredOptions}
                                        height={250}
                                        itemHeight={0}
                                        itemKey="value"
                                      >
                                        {(item) => (
                                          <div key={item.value} className="ml-2 mb-2 flex items-center">
                                            <Checkbox
                                              checked={productsFormData.product_type?.includes(item.value)}
                                              onChange={(e) => handleCheckboxChange(item.value, e.target.checked)}
                                              className="mr-2"
                                            >
                                              {item.label}
                                            </Checkbox>
                                          </div>
                                        )}
                                      </VirtualList>
                                    </div>
                                  );
                                }}
                                onDropdownVisibleChange={(open) => {
                                  if (!open) setproductTypeSearchValue("");
                                }}
                              />
                              {validationErrors[field.db_column_name] && (
                                <span className="text-red-500">{validationErrors[field.db_column_name]}</span>
                              )}
                            </>
                          )} */}


                        </div>
                      ))}
                          <div className="mb-2 mt-2 md:mt-4 sm:col-span-1 flex items-end">
                            <button
                              className="save-btn w-full sm:w-auto"
                              onClick={handleFilterLoad} type="button"
                            >
                              Filter
                            </button>
                          </div>
                    </div>
                    <div style={{ overflowX: 'auto', width: '100%' }}>
                    <EditableTableComponent
                      headers={headers}
                      headerMap={headerMap}
                      initialData={tableData}
                      searchQuery={searchTerm}
                      visibleColumns={visibleColumns}
                      itemsPerPage={100}
                      popupHeading="Products"
                      pagination={pagination}
                      advancedFilters={filteredData}
                      height={700}
                      setUpdatedTableData={setUpdatedTableData}
                    />
                    </div>

                  </div>
                )}
              </>
            )}
          </form>

        </div>
      </Modal>

      <Modal
        title="Confirmation"
        open={isConfirmationOpen}
        // onOk={handleConfirm}
        // onCancel={handleCancelConfirmation}
        footer={
          <div style={{ display: 'flex', justifyContent: 'center', width: '100%', gap: "6px" }}>
            <button
              className="cancel-btn"
              onClick={handleCancelConfirmation}
            >
              Cancel
            </button>
            <button
              className="save-btn"
              onClick={handleConfirm}
            >
              OK
            </button>
          </div>
        }

        centered
      >
        <p>Are you sure you want to create this {title
          .split(" ")
          .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
          .join(" ")}?</p>
      </Modal>
    </div>
  );

};

export default CreatePackageModal;




