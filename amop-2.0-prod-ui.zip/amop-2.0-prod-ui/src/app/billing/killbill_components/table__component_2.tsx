"use client";
import React, { lazy, useEffect, useRef, useState } from "react";
import Select from "react-select";
import {
  PencilIcon,
  TrashIcon,
  InformationCircleIcon,NoSymbolIcon, CheckIcon 
} from "@heroicons/react/24/outline";
import { CopyOutlined, CreditCardOutlined, DownloadOutlined, EyeOutlined, TagOutlined, WalletOutlined } from "@ant-design/icons";
import EditPopup from "./editpopup"
import { StatusCellRenderer } from "@/components/data-grid-cell-renderers/status-cell-renderer";
import { StatusHistoryCellRenderer } from "@/app/components/inventoryTableComponent/data-grid-cell-renderers/status-history-cell-renderer";

import { Modal, Checkbox, notification, Spin, Tooltip, Button, Input, DatePicker, message, Radio } from "antd";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import {
  ArrowUpOutlined,
  ArrowDownOutlined
} from "@ant-design/icons";
import StatusIndicator from "@/app/components/TableComponent/data-grid-cell-renderers/status-indicator";

import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import BillingPagination from "./pagination__";
import AdvancedTab from "../customer_profiles/advancedTabsPage"
import CopyPackageModal from "./copypackage";
import { exportLoadingStore } from "../../stores/ExportLoadingStore";
import ChargesPopup from "./chargespopup";
import { useSearchStore } from "@/app/stores/searchStore";
import { useKillBillStore } from "../killbill_stores/activeStore";
import { useRouter } from "next/navigation";
import { useCustomerProfileStore } from "../killbill_stores/customer_profile_store";
import PackageModal from "./customerProfilesProductsList";
import EditServiceLocationModal from "../customer_profiles/billings_collections/billing_collections_sub_tabs/services-action-items/edit-service-location";
import PackageListModal from "./product_list";
// import { useLogoStore } from "../killbill_stores/logo_store";
import { useLogoStore } from "@/app/stores/logoStore";
import CustomerProfilesEditModal from "./customerProfilesEditProducts";
import { error } from "console";
import EditCollectionModal from "./edit_collectionsPopup";
import StepModal from "../collections/editStepModal";
import { useDateRangeStore } from "../killbill_stores/dateStoreReports";
import CustomerProfilesEditNewServiceModal from "./customerProfilesEditNewServiceModal";
import { DropdownStyles } from "@/app/components/css/dropdown";
import dayjs from "dayjs";
import { initial } from "lodash";
import RepostMRC from "../customer_profiles/billings_collections/billing_collections_sub_tabs/bills_repost_MRC";
import RowDetailsModal from "@/app/components/rowDetailsModal"
import TaxesModal from "./taxesModal";
import CollectionsStepModal from "./collectionsStepModal";
import { PerformanceLogStore } from "@/app/stores/performance_matrix_store";

const DownloadPDFBill = lazy(() => import("./downloadPDFBill"));
const MultiDownloadPDFBill = lazy(() => import('./multiDownloadPDFBill'))
interface BillingPlatformTableComponent2Props {
  headers: string[];
  initialData: { [key: string]: any }[];
  searchQuery?: string;
  visibleColumns: string[];
  itemsPerPage: number;
  allowedActions?: (
    | "edit"
    | "delete"
    | "info"
    | "copy"
    | "deactivate"
    | "copyPackage"
    | "editPackage"
    | "adjust"
    | "paynow"
    | "downloadbill"
    | "editCollection"
    | "editStep"
    | 'preview'
    | 'editServiceLocation' 
    | 'editNewService'
  )[];
  popupHeading: string;
  advancedFilters?: any;
  modalData?: any[];
  createModalData?: any;
  generalFields?: any;
  isSelectRowVisible?: boolean;
  headerMap?: any;
  pagination: any;
  height?: any;
  setReverseRowData?: any;
  onRowClick?: any;
  onTabsClose?: any;
  setCallFetchdata?: any;
  setHeaders?: (headers: string[]) => void;
  setHeaderMap?: (map: Record<string, string[]>) => void;
  setTableData?: (data: any[]) => void;
  tableData?: any[];
  onTableDataUpdate?:any;
  ReportsData?:any;
  reportType?:any;
  setUpdatedAccountNumber?:any;
  repostedFields?:any;
  setAdvancedPage?: (value: boolean) => void;
  registerCloseAdvancedTabs?: (fn: () => void) => void;
 selectedSubPartner?: any;
  selectedPartner?: any;
  BPDashboardStartDate?: any;
  BPDashboardEndDate?: any;
  highlightedRowId?:any;
}
type FormData = {
  item_amount: any | null;
  reason: any | null;
  comment: any | null;
  fee: any | null;
  reference_no: any | null;
  payment_method: any | null;
  agent: any | null;
  received_date: any | null;
};
const formatColumnName = (name: string) => {
  return name
    .replace(/_/g, " ") // Replace underscores with spaces
    .split(" ") // Split the string into words
    .map(
      (
        word // Capitalize each word
      ) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
    )
    .join(" "); // Join the words back into a single string
};


const colorMap = {
  active:'#12E620',
  activated: "#12E620",
  activate: "#12E620",
  deactivated: "#E61224",
  // suspended: "#E61224",
  pending: "#A9A9A9",
  // Add more statuses and colors as needed
};
const messageStyle = {
  fontSize: "14px",
  fontWeight: "normal",
  padding: "16px",
};
const BillingPlatformTableComponent2: React.FC<BillingPlatformTableComponent2Props> = ({
  headers,
  initialData = [],
  searchQuery,
  visibleColumns,
  itemsPerPage,
  allowedActions,
  popupHeading,
  createModalData,
  modalData,
  generalFields,
  advancedFilters,
  isSelectRowVisible = true,
  headerMap,
  pagination,
  height,
  setReverseRowData,
  onRowClick,
  onTabsClose, setCallFetchdata, setHeaders,
  setHeaderMap,
  setTableData, tableData, onTableDataUpdate, ReportsData,
  reportType,setUpdatedAccountNumber,repostedFields,setAdvancedPage , registerCloseAdvancedTabs,
   selectedSubPartner,
  selectedPartner,
  BPDashboardStartDate,
  BPDashboardEndDate,
  highlightedRowId
}) => {
  const router = useRouter();
  const [rowData, setRowData] = useState<{ [key: string]: any }[]>(initialData || []);
  const [currentPage, setCurrentPage] = useState(1);
  const isFirstRender = useRef(true);
  const isFirstSearchRender = useRef(true);
  const isFirstAdvancedSearchRender = useRef(true);
  const [sortConfig, setSortConfig] = useState<{ key: string; direction: "ascending" | "descending"; } | null>(null);
  const [editRowIndex, setEditRowIndex] = useState<number | null>(null);
  const [repostModalIndex, setRepostModalIndex] = useState<number | null>(null)
  const [isEditable, setIsEditable] = useState(false);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [repostModalOpen, setRepostModalOpen] = useState(false);
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [ProcessPaymentOpen, setProcessPaymentOpen] = useState(false);
  const [deleteRowIndex, setDeleteRowIndex] = useState<number | null>(null);
  const [isCopyRowIndex, setCopyRowIndex] = useState<number | null>(null);
  const [isCopyModal, setCopyModal] = useState(false);
  const [isCopyPackageModal, setCopyPackageModal] = useState(false);
  const [isEditPackageModal, setEditPackageModal] = useState(false);
  const [isCollectionModal, setCollectionModal] = useState(false);
  const [isStepModal, setEditStepModal] = useState(false);
  const [isStepModalRowIndex, setEditStepModalRowIndex] = useState<number | null>(null);
  const [actionType, setActionType] = useState<string>("");
  const [PreviewModal, setPreviewModal] = useState(false);
  const [showRowModal, setShowRowModal] = useState<boolean>(false);
  const [showRowModalData, setShowRowModalData] = useState<any>(null);
  const [statusType, setStatusType] = useState<string>("");
  const [selectedRow, setSelectedRow] = useState(null);
  const [viewportHeight, setViewportHeight] = useState(window.innerHeight);
  const [showNewPage, setShowNewPage] = useState(false);
  const [showChargesPage, setChargesPage] = useState(false);
  const { searchData, advancedSearchData, combineAdnvaceSearchData , serviceProviderData} = useSearchStore();
  const [isOpen, setIsOpen] = useState<Record<number, boolean>>({});
  const [openIndex, setOpenIndex] = useState<number | null>(null);
  const { addExport, removeExport } = exportLoadingStore();
  const { productShowActive} = useKillBillStore();
  const { setUserProfileDetails } = useCustomerProfileStore();
    const accountNumber = useCustomerProfileStore((state) => state.accountNumber);
    const setAccountNumber = useCustomerProfileStore((state) => state.setAccountNumber);
  // console.log("tableData...", tableData);
  const {
    username,
    tenantNames,
    role,
    partner,
    selectedPartnerModule,
    Environment,
    tabledata,
    storedpagination,
    advancedStoredpagination,
    combineAdnvaceStoredpagination,
    token,
    // selectedDb,
    sessionId,
    serviceProviderList,
    selectedServiceProvider,
    setAdvancedStoredPagination,
    setStoredPagination,
    setCombineAdnvaceStoredpagination,
    firstLastName,
    metaData,
    selectedDb, selectedBillingDb
  } = useAuth();
  const [totalPages, setTotalPages] = useState(1);
  const [lastPageWithData, setLastPageWithData] = useState(1);
  const [loading, setLoading] = useState(false);
  const [formErrors, setFormErrors] = useState({ item_amount: "" });
   const [formData, setFormData] = useState<FormData>({
        item_amount: '',
        fee: '',
        reason: '',
        comment: '',
        reference_no: '',
        payment_method: '',
        agent: '',
        received_date: '',
      });
  // Assuming you have a state to manage selected rows
  const [selectedRows, setSelectedRows] = useState<number[]>([]); 
  const [editServiceModalOpen, setEditServiceModalOpen] = useState(false);
  const [downloadPDFBill, setDownloadPDFBill] = useState(false);
  const [editServiceProductModalOpen, setEditServiceProductModalOpen] = useState(false);
  const [isEditServiceProductRowIndex, setEditServiceProductRowIndex] = useState<number | null>(null);
  const [editNewServiceModalOpen, setEditNewServiceModalOpen] = useState(false);
  const [isEditNewServiceRowIndex, setEditNewServiceRowIndex] = useState<number | null>(null);
  const [serviceSelectedRow, setServiceSelectedRow] = useState<{ [key: string]: any; } | null>(null);
  const title = useLogoStore((state) => state.title);
  const setTitle = useLogoStore((state) => state.setTitle);
  const popupRef = useRef<HTMLDivElement | null>(null); // Type the ref as HTMLDivElement
  const [selectedPaymentMode, setSelectedPaymentMode] = useState<string>("");
  const [selectedPaymentAccountNumber, setSelectedPaymentMethodAccountNumber] = useState<string>("");
  const [isConfirmModalOpen, setIsConfirmModalOpen] = useState(false);
  const [isMoveDownConfirmModalOpen, setMoveDownConfirmModalOpen] = useState(false);
  const [isMoveDownRowIndex, setMoveDownModalRowIndex] = useState<number | null>(null);
  const [isMoveUpConfirmModalOpen, setMoveUpConfirmModalOpen] = useState(false);
  const [isMoveUpRowIndex, setMoveUpModalRowIndex] = useState<number | null>(null);
  const [isAmountModalOpen, setIsAmountModalOpen] = useState(false);
  const [amount, setAmount] = useState("");
  const [agentOptions, setAgentOptions] = useState<any[]>(
    generalFields?.dropdown?.sales_person || []
  );
  
  const [isProcessing, setIsProcessing] = useState(false);
  const [isAllSelected, setIsAllSelected] = useState(false); // State to track if all rows are selected
  const [quillValue, setQuillValue] = useState("");
  const [showStepsHeader, setShowStepsHeader] = useState(false);
  const [renderKey, setRenderKey] = useState(0);
  const {startDateDailyReport,endDateDailyReport,setCustomRange} = useDateRangeStore();
  const [isSmallScreen, setIsSmallScreen] = useState(false);
    useEffect(() => {
        const checkScreenSize = () => {
            setIsSmallScreen(window.innerWidth < 700);
        };
        
        // Initial check
        checkScreenSize();
        
        // Add event listener for window resize
        window.addEventListener('resize', checkScreenSize);
        
        // Clean up
        return () => window.removeEventListener('resize', checkScreenSize);
    }, []);
    useEffect(() => {
    if (registerCloseAdvancedTabs) {
      registerCloseAdvancedTabs(closeAdvancedTabs);
    }
  }, [headerMap]);
  
  const getFirstProductDescription = (productsJson: string) => {
    let products;

    // Attempt to parse the JSON string
    try {
      products = productsJson;
    } catch (error) {
      // If parsing fails, return an error message
      return "No products";
    }
    // console.log("description products", products);
    // Check if products is an array and has at least one product
    if (Array.isArray(products) && products.length > 0) {
      return products[0].description || "No description available";
    }

    return products;
  };

  useEffect(() => {
    setAdvancedStoredPagination(null)
    setStoredPagination(null)
    setCombineAdnvaceStoredpagination(null)
    const handleResize = () => {
      setViewportHeight(window.innerHeight);
    };

    // Add event listener for window resize
    window.addEventListener("resize", handleResize);

    // Cleanup event listener on component unmount
    return () => {
      window.removeEventListener("resize", handleResize);
    };

  }, []);

  useEffect(() => {
    if (!router) {
      // console.error("NextRouter is not available.");
    }
  }, [router]);

  // useEffect(() => {
  //   const newRowData = tabledata?.length > 0 ? tabledata : initialData||[];
  //   setRowData(newRowData);
  // }, [tabledata, initialData]);
  const checkIfAnyStepsExist = () => {
    const hasSteps = rowData.some(row => row.closure_step || row.promise_step);

    // Only update the state if it actually changes
    // console.log("hasSteps,showStepsHeader",hasSteps,showStepsHeader)
    if (hasSteps !== showStepsHeader) {
        setShowStepsHeader(hasSteps);

    }
};

useEffect(() => {
    if (popupHeading === "Collections Steps" || popupHeading === "Create Collections") {
        // console.log("rowData updating...");
        checkIfAnyStepsExist();
    }
}, [rowData]);
// useEffect(() => {
//   console.log("Updating header key...");
//   setRenderKey((prev) => prev + 1);
// }, [showStepsHeader]);
useEffect(() => {

  // ✅ Case 1: Service Provider — Highest Priority
  if (popupHeading === "Service Provider") {
    const newRowData = serviceProviderData.length > 0 
      ? serviceProviderData 
      : initialData || [];

    setRowData(newRowData);
    return; // 🔥 stop here, do NOT run below logic
  }

  // ✅ Case 2: Collections Steps / Create Collections
  if (popupHeading === "Collections Steps" || popupHeading === "Create Collections") {
    const activeRows = Array.isArray(initialData)
      ? initialData.filter(row => !row.is_deleted)
      : [];

    let cumulativeDay = 0;

    const updatedRowData = activeRows.map((row, index) => {
      const gracePeriod = parseInt(row.grace_period, 10) || 0;

      if (index === 0) {
        row.day = gracePeriod.toString();
        cumulativeDay = gracePeriod;
      } else {
        cumulativeDay += gracePeriod;
        row.day = cumulativeDay.toString();
      }

      return row;
    });

    setRowData(updatedRowData);
    return; // ✅ stop here too
  }

  // ✅ Case 3: Default Case (All Other Popups)
  const newRowData =
    tabledata.length > 0
      ? tabledata
      : initialData || [];

  setRowData(newRowData);

}, [popupHeading, initialData, tabledata, serviceProviderData]);


  useEffect(() => {
    setCurrentPage(1);
    }, [tabledata,sortConfig]);

  useEffect(() => {
    setCurrentPage(1);
  }, [totalPages]);

  //To manage the pagination routes
  useEffect(() => {
    let pagination_;
    if(combineAdnvaceStoredpagination){
      pagination_=combineAdnvaceStoredpagination

    }
    else if (advancedStoredpagination && !storedpagination) {
      pagination_=advancedStoredpagination

    }
    else if (storedpagination && !advancedStoredpagination) {
      pagination_=storedpagination

    }
  else{
      pagination_=pagination
    }
    // const pagination_ =combineAdnvaceStoredpagination? storedpagination ? storedpagination : advancedStoredpagination ? advancedStoredpagination : pagination
    // const pagination_ = pagination;
    const start = pagination_?.start || 1;
    const total = pagination_?.total || 1;
    const end = pagination_?.end || 1;
    const lastPageWithData_ = Math.floor(end / itemsPerPage);
    const totalPages_ = Math.ceil(total / itemsPerPage);
    const currentPage_ = Math.floor(start / itemsPerPage) + 1;
    setTotalPages(totalPages_);
    // setCurrentPage(currentPage_);
    setLastPageWithData(lastPageWithData_);
  }, [tabledata, initialData, pagination, itemsPerPage, currentPage, storedpagination, advancedStoredpagination, combineAdnvaceStoredpagination , sortConfig]);
  useEffect(() => {
    if(popupHeading === "Bills"){
      // Select all rows by default when popupHeading is "Service Product"
      const allRowIds = initialData.map(row => row.id);
      // console.log(initialData,"Show initial Data")
      setSelectedRows(allRowIds);
      setIsAllSelected(true); // Set all selected to true
      if (typeof setReverseRowData === 'function') {
        setReverseRowData(initialData);
      }
    }
    if (popupHeading === "Service Product") {
      // Select all rows by default when popupHeading is "Service Product"
      const allRowIds = initialData?.map(row => row.id);
      setSelectedRows(allRowIds);
      setIsAllSelected(true); // Set all selected to true
      if (typeof setReverseRowData === 'function') {
        setReverseRowData(allRowIds);
      }
    }
    else {
      // Clear selected rows if the popupHeading changes
      setSelectedRows([]);
      setIsAllSelected(false); // Reset all selected state
      if (typeof setReverseRowData === 'function') {
        setReverseRowData([]);
      }
    }
  }, [popupHeading, initialData]);
  // Effect to update rowData based on tabledata and initialData


  const updatePaginator = async () => {
    // console.log(serviceShowActive,"Show Service Active")
    let start_ = Math.floor((currentPage - 1) * itemsPerPage);
    let end_ = Math.floor((currentPage - 1) * itemsPerPage + 100);
    try {
      const colSortKey=sortConfig?sortConfig.key:""
      const colSortDirection=sortConfig?sortConfig.direction:""
      const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";

      setLoading(true);
        if (popupHeading === "Service Provider") {
        const url = ENV_ROUTES.MODULE_MANAGEMENT;

        const data = {
         tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/bp_service_providers_list_view",
              role_name: role,
              parent_module: "Partner Info",
              module_name: "Billing Service Providers",
              Selected_Partner: selectedPartner,
              sub_partner: selectedSubPartner,
              request_received_at: getCurrentDateTime(),
              access_token: token,
              db_name: selectedDb,
              ...metaData,
billing_db_name: selectedBillingDb,
              sessionID: sessionId,
               ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
            : {}),
              mod_pages: {
                start: start_,
                end: end_,
              },
            };
            const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        console.log("parsed...", parsedData);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const ReportsData =
            parsedData?.data?.billing_service_providers || [];
          setRowData(ReportsData);
          pagination = parsedData?.pages || pagination
        }
            
        }

      
    } catch (err) {
      console.error("Error fetching data:", err);
    } finally {
      setLoading(false);
    }
    // }
  };
  const updateSearchPaginator = async () => {
    let start_ = Math.floor((currentPage - 1) * itemsPerPage);
    let end_ = Math.floor((currentPage - 1) * itemsPerPage + 100);
    const colSortKey=sortConfig?sortConfig.key:""
    const colSortDirection=sortConfig?sortConfig.direction:""
    const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";
    try {
      setLoading(true);
      const url = ENV_ROUTES.OPEN_SEARCH;
      let data = { ...searchData, username: username, }
      data.data.pages = {
        start: start_,
        end: end_,
      }
      data.data.col_sort={ [colSortKey]: colSortValue }
      const response = await axios.post(url, data);
      const parsedData = JSON.parse(response.data.body);
      // console.log("parsed", parsedData);
      if (parsedData?.flag) {
        const tableData = parsedData?.data?.table || [];
        setRowData(tableData);
        const pagination_ = parsedData?.pages || {};
        setStoredPagination(pagination_);
        setAdvancedStoredPagination(null);
        setCombineAdnvaceStoredpagination(null)
        if (tableData.length === 0) {
          Modal.error({
            title: "No Records found",
          });
        }
      } else {
        Modal.error({
          title: "Search error",
          content:
            parsedData.error ||
            "An error occurred while searching. Please try again.",
        });
      }
      // console.log(response);
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false); // Stop loader
    }
  }
  const updateAdvancedSearchPaginator = async () => {
    let start_ = Math.floor((currentPage - 1) * itemsPerPage);
    let end_ = Math.floor((currentPage - 1) * itemsPerPage + 100);
    const colSortKey=sortConfig?sortConfig.key:""
    const colSortDirection=sortConfig?sortConfig.direction:""
    const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";
    try {
      setLoading(true);
      const url = ENV_ROUTES.OPEN_SEARCH;
      let data = { ...advancedSearchData, username: username,}
      data.data.pages = {
        start: start_,
        end: end_,
      }
      data.data.col_sort={ [colSortKey]: colSortValue }
      const response = await axios.post(url, data);
      const parsedData = JSON.parse(response.data.body);
      // console.log("parsed", parsedData);
      if (parsedData?.flag) {
        const tableData = parsedData?.data?.table;
        setRowData(tableData);
        const pagination_ = parsedData?.pages || {}
        setStoredPagination(null)
        setAdvancedStoredPagination(pagination_)
        setCombineAdnvaceStoredpagination(null)
        if (tableData.length === 0) {
          Modal.error({
            title: "No Records found",
          });
        }
      } else {
        Modal.error({
          title: "Search error",
          content:
            parsedData.error ||
            "An error occurred while searching. Please try again.",
        });
      }
      console.log(response);
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false); // Stop loader
    }
  }
  const updateCombinedSearchPaginator = async () => {
    let start_ = Math.floor((currentPage - 1) * itemsPerPage);
    let end_ = Math.floor((currentPage - 1) * itemsPerPage + 100);
    const colSortKey=sortConfig?sortConfig.key:""
    const colSortDirection=sortConfig?sortConfig.direction:""
    const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";
    try {
      setLoading(true);
      const url = ENV_ROUTES.OPEN_SEARCH;
      let data = { ...combineAdnvaceSearchData, username: username,}
      data.data.pages = {
        start: start_,
        end: end_,
      }
      data.data.col_sort={ [colSortKey]: colSortValue }
      const response = await axios.post(url, data);
      const parsedData = JSON.parse(response.data.body);
      console.log("parsed", parsedData);
      if (parsedData?.flag) {
        const tableData = parsedData?.data?.table;
        setRowData(tableData);
        const pagination_ = parsedData?.pages || {}
        setStoredPagination(null)
        setAdvancedStoredPagination(null)
        setCombineAdnvaceStoredpagination(pagination_)
        if (tableData.length === 0) {
          Modal.error({
            title: "No Records found",
          });
        }
      } else {
        Modal.error({
          title: "Search error",
          content:
            parsedData.error ||
            "An error occurred while searching. Please try again.",
        });
      }
      console.log(response);
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false); // Stop loader
    }
  }
  useEffect(() => {
    if (!isFirstRender.current) {

      if (combineAdnvaceStoredpagination) {
        updateCombinedSearchPaginator()
      }
      else if (storedpagination && !advancedStoredpagination) {
        updateSearchPaginator()
      }
      else if (advancedStoredpagination && !storedpagination) {
        updateAdvancedSearchPaginator()
      }
      else {
        updatePaginator();
      }

     }  else { isFirstRender.current = false }
  }, [currentPage, sortConfig]);

  useEffect(() => {
    // console.log("searchQuery",searchQuery)
    if (!isFirstSearchRender.current) {
        if (searchQuery==="") {
        // console.log("searchQuery",isFirstRender)
        if (storedpagination) {
          updateSearchPaginator()
        }
        else if (advancedStoredpagination) {
          updateAdvancedSearchPaginator()
        }
        else {
          // console.log("advancedStoredpagination",advancedStoredpagination)
          updatePaginator();
        }
      }
    } else { isFirstSearchRender.current = false }
  }, [searchQuery]);

  useEffect(() => {
    // console.log("advancedFilters",advancedFilters)
    if (!isFirstAdvancedSearchRender.current) {
      if (advancedFilters) {
        const allEmpty = Object.values(advancedFilters).every(
          (value) => Array.isArray(value) && value.length === 0
        );

        if (allEmpty) {
          // console.log("advancedFilters",advancedFilters)
          if (storedpagination) {
            updateSearchPaginator()
          }
          else if (advancedStoredpagination) {
            updateAdvancedSearchPaginator()
          }
          else {
            updatePaginator();
          }
        }
      }
    } else { isFirstAdvancedSearchRender.current = false }

  }, [advancedFilters]);
  const handleDelete = async (rowIndex: number, actionType: string, statusType: string) => {
    if (rowIndex >= 0 && rowIndex < rowData.length) {
      const updatedData: any = [...rowData];
      const row = updatedData[rowIndex];
      console.log(row);
      if (actionType === "delete") {
        row["deleted_by"] = firstLastName;
        row["is_deleted"] = true;
        row["is_active"] = false;
      } else if (actionType === "deactivate") {
        row["is_active"] = false;
      }
      else {
        row["is_active"] = true;
      }
      updatedData[rowIndex] = row;
      

        try {
          let url = ENV_ROUTES.BP_SERVICES_PRODUCTS;
          let url2 = ENV_ROUTES.BP_COLLECTIONS;
          let url3 = ENV_ROUTES.BP_CUSTOMER_PROFILES;
          let url4 = ENV_ROUTES.MODULE_MANAGEMENT;
          const tenant_id_ = localStorage.getItem("tenant_id") || "0";

          let data;
          
           if (popupHeading === "Service Provider") {
            if (row) {
              row["modified_by"] = firstLastName;
              row["modified_date"] = getCurrentDateTime();
            }

            data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/deactivate_bp_service_provider",
              role_name: role,
               parent_module: "Partner Info",
              module_name: "Billing Service Providers",
              Selected_Partner: selectedPartner,
              sub_partner: selectedSubPartner,
              action: actionType,
              changed_data: row,
              Partner: partner,
              request_received_at: getCurrentDateTime(),
              status: productShowActive?"true":"false",
              access_token: token,
              tenant_id:tenant_id_,
              db_name: "billing_platform",
              ...metaData,
              billing_db_name:selectedBillingDb,
              sessionID: sessionId,              
            };

          }

        let postUrl;
         
            postUrl = url4;

        const response = await axios.post(postUrl, { data });
          const parsedData = JSON.parse(response.data.body);
          if (response && response.status === 200) {
            notification.success({
              message: "Success",
              description: parsedData.message || "Data Modified Successfully!",
              // style: messageStyle,
              placement: "top",
            });
            
             if (popupHeading === "Service Provider") {
              const url = ENV_ROUTES.MODULE_MANAGEMENT;
               const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/bp_service_providers_list_view",
              role_name: role,
              parent_module: "Partner Info",
              module_name: "Billing Service Providers",
              Selected_Partner: selectedPartner,
              sub_partner: selectedSubPartner,
              request_received_at: getCurrentDateTime(),
              access_token: token,
              db_name: selectedDb,
              ...metaData,
billing_db_name: selectedBillingDb,
              sessionID: sessionId,
              mod_pages: {
                start: 0,
                end: 100,
              },
            };
              const response = await axios.post(url, { data });
              const parsedData = JSON.parse(response.data.body);
              if (parsedData.flag === false) {
                Modal.error({
                  title: "Data Fetch Error",
                  content:
                    parsedData.message ||
                    "An error occurred while fetching Customer groups data. Please try again.",
                  centered: true,
                });
              } else {

                setRowData(parsedData?.data?.billing_service_providers || []);
              }
            }
          } else {
            const errorMsg = JSON.parse(response.data.body).message;
            Modal.error({
              title: "Saving Error",
              content: errorMsg,
              centered: true,
            });
          }
        } catch (err) {
          // console.error("Error fetching data:", err);
          notification.error({
            message: "Error",
            description: "Failed to Deleted the record. Please try again.",
            style: messageStyle,
            placement: "top", // Apply custom styles here
          }); //// place it after you make the call to load the table data
        }
      }

      // setRowData(updatedData);
  };
  const confirmDelete = (actionType: any, statusType?: any) => {
    if (deleteRowIndex !== null) {
      handleDelete(deleteRowIndex, actionType, statusType);
    }
    setDeleteModalOpen(false);
    setDeleteRowIndex(null);
  };

  const handleSort = (key: string) => {
    let direction: "ascending" | "descending" = "ascending";
    if (
      sortConfig &&
      sortConfig.key === key &&
      sortConfig.direction === "ascending"
    ) {
      direction = "descending";
    }
    setCurrentPage(1)
    setSortConfig({ key, direction });
  };



  //For custom cell rendering
  const renderCell = (cellData: any, column: string, rowIndex: number) => {

    if (headerMap &&
      headerMap?.[column]?.[0] === "SIM Status") {
      return <StatusCellRenderer
        record={rowData[rowIndex]}
        value={cellData || "None"}
        index={rowIndex}
        colorMap={colorMap}
      />
    }

    if (column.toLowerCase() === "status" ||
      (headerMap && headerMap?.[column]?.[0] === "Status")) {
      return <StatusIndicator
        row={rowData[rowIndex]}
        status={cellData}
        heading={popupHeading}
      />

    }
    return (
      <Tooltip
        title={cellData}
        placement="topLeft"
        overlayStyle={{ whiteSpace: 'normal', maxWidth: '60vw', wordWrap: 'break-word' , zIndex: 50}}
        // getPopupContainer={(triggerNode) => (triggerNode.parentNode as HTMLElement) || document.body} // Fallback to document.body
        getPopupContainer={() => document.body}
      >
        <span>{cellData && (cellData).toString()}</span>
      </Tooltip>
    ); cellData;
  };

  const handleActionClick = (action: string, rowIndex: number, title?: any,isActive?: boolean  ) => {

    switch (action) {
      case "edit":
        setEditRowIndex(rowIndex);
        setIsEditable(true);
        setEditModalOpen(true);
        // console.log(editModalOpen);
        break;
      case "delete":
        setActionType("delete")
        setDeleteRowIndex(rowIndex);
        setDeleteModalOpen(true);
        break;
      case "activate":
        setActionType(title === "Active" ? "deactivate" : "activate")
        setStatusType(title === "Active" ? "Deactivate" : "Activate")
        setDeleteRowIndex(rowIndex);
        setDeleteModalOpen(true);
        break;
      case "deactivate":
      const shouldDeactivate = isActive === true || title === "Active";
      setActionType(shouldDeactivate ? "deactivate" : "activate");
      setStatusType(shouldDeactivate ? "Deactivate" : "Activate");
      setDeleteRowIndex(rowIndex);
      setDeleteModalOpen(true);
      break;

      case "info":
        setEditRowIndex(rowIndex);
        setIsEditable(false);
        setEditModalOpen(true);
        break;
      case "copy":
        setIsEditable(true);
        setCopyModal(true);
        setCopyRowIndex(rowIndex);
        break;
     
      default:
        break;
    }
  };
  const handleCloseModal = () => {
    setEditModalOpen(false);
    setDeleteModalOpen(false);
    setCopyModal(false);
    setCopyPackageModal(false)
    setEditPackageModal(false)
    setCollectionModal(false)
    setEditStepModal(false)
    setPreviewModal(false)
    setRepostModalOpen(false)
  }
  const handleSaveModal = (
    updatedRow?: { [key: string]: any },
    tableData?: any
  ) => {
    if (editRowIndex !== null) {
      // const updatedData = [...rowData];
      // updatedData[editRowIndex] = updatedRow;
      // setRowData(updatedData);
      handleCloseModal();
      setReverseRowData?.()
      // setRowData(tableData)
    }
  };

  const closeAdvancedTabs = () => {
    // console.log("closing all the tabs")
    setShowNewPage(false);
    setAdvancedPage?.(false)
    setSelectedRow(null);
    setUserProfileDetails({});
    // Retrieve and restore the previous title

    const storedPrevTitle = localStorage.getItem("prevTitle") || "";
  if(storedPrevTitle){
      setTitle(storedPrevTitle);
    }
    localStorage.setItem("title", storedPrevTitle);
    onTabsClose()// Close the AdvancedTab and show the Actions button
  };
  const handleClickOutside = (event: MouseEvent) => {
    if (popupRef.current && !popupRef.current.contains(event.target as Node)) {
      setOpenIndex(null); // Close dropdown if clicked outside
    }
  };

  useEffect(() => {
    document.addEventListener('mousedown', handleClickOutside);

    // Cleanup event listener on component unmount
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }
  const ExportWithoutSearch = async (key: string, heading: string, id: any) => {
      try {
      // Add the export to the store
      addExport(key, heading);

      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Request timed out"));
          }, timeout);

          promise
            .then((res) => {
              clearTimeout(timer);
              resolve(res);
            })
            .catch((err) => {
              clearTimeout(timer);
              reject(err);
            });
        });
      };

      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/generate_bill_excel",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Generate Bill",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        account_number:accountNumber? accountNumber:id?.account_number,
        id:id.id,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        feature_module_name: "Generate Bill",
        start_date: getFirstDayOfCurrentMonth(),
        end_date: getLastDayOfCurrentMonth(),
        killbill_flag: "True",
          main_module_name: "Customer Profiles",
      };

      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000);
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }

      // Wait for 20 seconds before polling
      await new Promise((resolve) => setTimeout(resolve, 20000));

      const export_url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const export_data = {
        ...data,
        path: "/get_export_status",
      };

      const pollExportStatus = async () => {
        try {
          const export_response = await axios.post(export_url, { data: export_data });
          const export_parsedData = JSON.parse(export_response.data.body);

          if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
            const s3Url = export_parsedData?.export_status_data?.url || null;
            if (s3Url) {
              window.location.href = s3Url;
              notification.success({
                message: "Success",
                description: "Successfully exported the  record!",
                style: messageStyle,
                placement: "top",
              });
            } else {
              Modal.error({
                title: "Export Error",
                content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            }
            return true; // Stop polling
          }

          if (export_parsedData?.export_status_data?.status_flag === "Failure") {
            Modal.error({
              title: "Export Error",
              content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
              centered: true,
            });
            return true; // Stop polling
          }
          if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
                      Modal.error({
                        title: "Export Error",
                        content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
                        centered: true,
                      });
                      return true; // Stop polling
                    }

          return false; // Continue polling
        } catch (error) {
          Modal.error({
            title: "Export Error",
            content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
            centered: true,
          });
          return true; // Stop polling
        }
      };

      const startPolling = async () => {
        let isPollingComplete = false;

        while (!isPollingComplete) {
          isPollingComplete = await pollExportStatus();
          if (!isPollingComplete) {
            await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
          }
        }
      };

      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      removeExport(key); // Remove the export from the store
    }
  };

  const ReportsModule =["Transaction Analysis","A/R Aging","Altaworx Billing Report","Charge By Service","Billing Charge By Service"]
  const freezeColumn = (header:string) =>{
    if(
      (popupHeading === "Bills" && header === "id") || ( !ReportsModule.includes(popupHeading) && header === "account_number") ||
      (popupHeading === "Automation rule" && header === "automation_rule_name")
    ){
      return true
    }
    else{
      return false
    }
  }
  const currencyHeaders = ["Rate", "Charges", "Credits", "Payments", "Taxes", "Total", "Amount Due", "Remaining", "Charge", "Credit", "Balance", "Amount","Account Balance","Grouped","Ungrouped","One Time Charge","MRC","SMS","Balance Limit"];

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }
const paginationComponent = (
    <BillingPagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
            moduleName={popupHeading} />
);
  const tablesInModals = ["Charge By Service","Billing Charge By Service"]
  return (

    <div>

      {isSmallScreen && visibleColumns.length > 0 && (
        <div className="flex justify-end mb-2 mr-2">
          {paginationComponent}
        </div>
      )}
      <div className="overflow-x-auto">
      <div className="overflow-x-auto overflow-y-auto"
        style={{
          height: popupHeading === "Service Product"
            ? undefined  // Let height be auto
            : `${viewportHeight - height}px`,
          minHeight: popupHeading === "Service Product"
            ? "300px"    // Set a fixed minimum height
            : undefined, // No minHeight otherwise
        }}
      >
          <table className="table-auto w-full">
            <thead className={`sticky top-0 bg-gray-200 z-10 ${tablesInModals.includes(popupHeading)?"disconnect-table-header":"table-header-row"}`}>
              <tr>
                {(typeof window !== "undefined" && window.innerWidth < 700) && (
                  <th
                    className={`px-6 py-3 border-b border-gray-300 text-left font-semibold table-header sticky top-0 freeze-header`}
                    style={{
                      cursor: "pointer", position: "sticky", left: 0, zIndex: 11, backgroundColor: "#E5E7EB", minWidth: "40px"
                    }}>

                  </th>
                )}
                
                {headers.map((header) => (
                  headerMap && headerMap[header] && visibleColumns.includes(header) && (
                    <th
                      key={header}
                      className={`px-6 py-3 border-b border-gray-300 text-left font-semibold table-header sticky top-0 
                        ${sortConfig && sortConfig.key === header ? "text-blue-600 active-table-header" : ""
                        } ${freezeColumn(header) ? 'freeze-header' : ''}`}
                      // className="px-6 py-3 border-b border-gray-300 text-left font-semibold table-header sticky top-0"
                      onClick={() => { headerMap && headerMap[header][0] !== 'Total' && handleSort(header) }}
                      style={{
                        cursor: "pointer",
                        ...(freezeColumn(header)
                          ? { position: "sticky", left: (typeof window !== "undefined" && window.innerWidth < 700) ? "40px" : 0, zIndex: 11, cursor: "pointer" }
                          : {})
                      }}
                    >
                      {headerMap && headerMap[header]
                        ? headerMap[header][0]
                        : formatColumnName(header)}
                      {headerMap && headerMap[header][0] !== 'Total' ?
                        (sortConfig && sortConfig.key === header ? (
                          sortConfig.direction === "ascending" ? (
                            <ArrowUpOutlined className="sorting-arrow" style={{ marginLeft: 8, color: "#2563EB" }} />
                          ) : (
                            <ArrowDownOutlined className="sorting-arrow" style={{ marginLeft: 8, color: "#2563EB" }} />
                          )
                        ) : (
                          <ArrowUpOutlined style={{ marginLeft: 8, opacity: 0.5 }} />
                        )
                        ) : null}
                    </th>
                  )
                ))}
                {(allowedActions && allowedActions.length > 0) && visibleColumns.length > 0 && (
                  <th className="px-6 border-b border-gray-300 text-left font-semibold table-header">
                    {"Actions"}
                  </th>)}
              </tr>
            </thead>
            <tbody>

              {visibleColumns.length > 0 ? (
              rowData.length > 0 ? (
                (rowData)
                .map((row, index) => (                 
                  <tr
                    key={index}
                    className={index % 2 === 0 ? "bg-gray-50 even-table-row" : ""}
                  >
                    {(typeof window !== "undefined" && window.innerWidth < 700) && (
                      <td
                        className={`border-b border-gray-300 table-cell ${index % 2 === 0 ? "even-freeze-cell" : "freeze-cell"}`}
                        style={
                          { position: "sticky", left: 0, backgroundColor: "white", zIndex: 5 }
                        }>
                        <Radio
                          checked={true}
                          onClick={() => {
                            setShowRowModal(true);
                            setShowRowModalData(row);
                          }}
                          className="custom-gray-radio"
                        />
                      </td>
                    )}
                    
                    {headers.map(
                      (header, columnIndex) =>
                        visibleColumns.includes(header) &&
                        headerMap[header] && (
                          <td
                            key={columnIndex}
                            className={` px-6 py-3 border-b border-gray-300 table-cell 
                              ${headerMap?.[header]?.[0] === "Payment Mode"
                                ? "table-cell !px-[24px] !py-[3px]"
                                : "table-cell"}
                              ${freezeColumn(header) ?index % 2 === 0 ? "even-freeze-cell" :"freeze-cell" : ""}`}
                            // onClick={() => {
                            //   if (headerMap[header][0] !== "Bills") {
                            //     onRowClick && onRowClick(row);
                            //   }
                            // }}
                             style={{
                            ...(freezeColumn(header)
                              ? { position: "sticky", left: (typeof window !== "undefined" && window.innerWidth < 700) ? "40px" : 0, zIndex: 5, cursor: "pointer" }
                              : {})
                          }}
                          >
                            
                            {popupHeading === "A/R Aging" && headerMap[header][0] === "Collection Step" ? (
                            <>
                              <a
                                onClick={(e) => {
                                  e.stopPropagation();
                                }}
                                className="text-blue-500 cursor-pointer underline"
                              >
                                <Tooltip title={row[header]}>
                                  <span>{row[header]}</span>
                                </Tooltip>
                              </a>
                            </>
                            ):
                            (
                              renderCell(
                                header === "is_active"
                                  ? row[header]
                                    ? <span className="text-green-500">Active</span>
                                    : <span className="text-red-500">Inactive</span>
                                  : (currencyHeaders.includes(headerMap[header][0]) && row[header]
                                    ? `$${row[header]}`
                                    : row[header]),
                                header,
                                index
                              ) || ""


                            )}
                          </td>
                        )
                    )}


                    {Array.isArray(allowedActions) && allowedActions.length > 0 && visibleColumns.length > 0 && !["Services", "Collections Steps","Bills"].includes(popupHeading) ? (
                      <td className="px-6 border-b border-gray-300 table-cell relative" style={{ overflow: "visible" }}>
                        <div className="flex items-center space-x-2">
                          {allowedActions.includes("preview") && (
                            <Tooltip title="Preview">
                              <EyeOutlined
                                className="h-6 w-6 text-blue-500 cursor-pointer"
                                onClick={() => handleActionClick("preview", index)}
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("edit") && (
                            <Tooltip title="Edit">
                              <PencilIcon
                                className="h-5 w-5 text-blue-500 cursor-pointer"
                                onClick={() => handleActionClick("edit", index)}
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("deactivate") && (
                            <Tooltip
                            title={
                              row.is_active === true || row.status === "Active"
                                ? "Deactivate"
                                : row.is_active === false || row.status === "Inactive"
                                  ? "Activate"
                                  : "Unknown Status"
                            }
                          >
                            {row.is_active === true || row.status === "Active" ? (
                              <NoSymbolIcon
                                className="h-5 w-5 text-red-500 cursor-pointer"
                                onClick={() => handleActionClick("deactivate", index, row.status, row.is_active)}
                              />
                            ) : row.is_active === false || row.status === "Inactive" ? (
                              <CheckIcon
                                className="h-5 w-5 text-green-500 cursor-pointer"
                                onClick={() => handleActionClick("activate", index, row.status, row.is_active)}
                              />
                            ) : (
                              <NoSymbolIcon
                                className="h-5 w-5 text-gray-400 cursor-pointer"
                                onClick={() => handleActionClick("unknown", index, row.status, row.is_active)}
                              />
                            )}
                          </Tooltip>
                          )}
                          {allowedActions.includes("delete") && (
                            <Tooltip title="Delete">
                              <TrashIcon
                                className="h-5 w-5 text-red-500 cursor-pointer"
                                onClick={() => handleActionClick("delete", index)}
                              />
                            </Tooltip>
                          )}

                          {allowedActions.includes("info") && (
                            <Tooltip title="Info">
                              <InformationCircleIcon
                                className="h-5 w-5 text-green-500 cursor-pointer"
                                onClick={() => handleActionClick("info", index)}
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("copy") && (
                            <Tooltip title="Copy">
                              <CopyOutlined
                                className="h-5 w-5 text-blue-500 cursor-pointer"
                                onClick={() => handleActionClick("copy", index)}
                              />
                            </Tooltip>
                          )}


                        </div>
                      </td>
                    ) : (
                      null
                    )}
                  </tr>
                ))
              ):(
              <tr>
                  <td
                    colSpan={
                      headers.filter((header) =>
                        visibleColumns.includes(header)
                      ).length + 1
                    }
                    className="px-6 py-3 border-b border-gray-300 text-center text-gray-500"
                  >
                    No Records Found
                  </td>
                </tr>
                )
               ) : null}
            </tbody>
          </table>
        </div>
      </div>
      {/* {visibleColumns.length > 0 &&
        <div className="flex justify-center mt-5">
          <BillingPagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
            moduleName={popupHeading} />
        </div>
      } */}
          {(!isSmallScreen && visibleColumns.length > 0) && (
              <div className="flex justify-center mt-5">
                  {paginationComponent}
              </div>
          )}
          {editModalOpen &&
              (<EditPopup
                  createModalData={createModalData || []}
                  isOpen={editModalOpen}
                  isEditable={isEditable}
                  rowData={editRowIndex !== null ? rowData[editRowIndex] : null}
                  onSave={handleSaveModal}
                  onClose={handleCloseModal}
                  heading={popupHeading}
                  generalFields={generalFields}
                  tableData={rowData}
                  action="edit"
                  selectedSubPartner={selectedSubPartner}
                  selectedPartner={selectedPartner}
              />)

          }

      <Modal
        title={actionType === "delete"
          ? "Confirm Deletion"
          : actionType === "deactivate"
            ? ("Confirm Deactivation")
            : "Confirm Activation"}
        open={deleteModalOpen}
        onOk={() => confirmDelete(actionType, statusType)}
        onCancel={() => setDeleteModalOpen(false)}
        centered
        footer={
          <div style={{ display: 'flex', justifyContent: 'center', width: '100%', gap: "6px" }}>
            <button
              className="cancel-btn"
              onClick={() => setDeleteModalOpen(false)}
            >
              Cancel
            </button>
            <button
              className="save-btn"
              onClick={() => confirmDelete(actionType, statusType)}
            >
              OK
            </button>
          </div>
        }
      >
        {actionType === "delete" ? (
          <p>Do you want to delete this row?</p>
        ) : (
          <p>Do you want to {statusType} this row?</p>
        )}
      </Modal>
    </div>
  );
};

export default BillingPlatformTableComponent2;

