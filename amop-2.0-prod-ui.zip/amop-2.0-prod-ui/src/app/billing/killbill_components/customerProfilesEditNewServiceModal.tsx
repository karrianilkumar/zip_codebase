"use client";
import React, { useCallback, useEffect, useState, useRef } from "react";
import { Checkbox, Input, Modal, notification, Spin, DatePicker, Select } from 'antd';
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useAuth } from "@/app/components/auth_context";
import { CloseOutlined } from "@ant-design/icons";
import dayjs, { Dayjs } from 'dayjs';
import Dropdown from "./dropdownComponent";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import VirtualList from 'rc-virtual-list';
import { useKillBillStore } from "../killbill_stores/activeStore";
import { FunnelIcon } from "@heroicons/react/24/outline";

interface EditeProductModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: any;
  modalData: {
    id: number;
    display_name: string;
    type: string;
    mandatory: boolean;
    db_column_name: string;
  }[];
  title: string;
  action: string;
  rowData?: any;
  generalFields?: any;
  dropdownValues?: any;
  accountNumber?: any;
}

type FormData = {
  create: any | null;
  service_type: any | null;
  provider: any | null;
  contract_term: [Dayjs | null, Dayjs | null];
  effective_date: Dayjs | null;
  accounts: string;
  dest_customer: any | null;
   products: {
    value: string | number;
    label: string;
    rate?: number;
    cost?: number;
    quantity?: number;
  }[];
  packages: any;
  address_line_1: string | null;
  city: string | null;
  state: string | null;
  postal_code: string | null;
  country: string | null;
  built_in_fields: { [key: string]: string | Dayjs | null };
  [key: string]: any;
};

const messageStyle = {
  fontSize: '14px',
  fontWeight: 'bold',
  padding: '16px',
};

const CustomerProfilesEditNewServiceModal: React.FC<EditeProductModalProps> = ({
  isOpen,
  onClose,
  onSave,
  modalData,
  title,
  rowData,
  generalFields,
  dropdownValues,
  accountNumber,
}) => {
  const [customerRatePlanOptions, setCustomerRatePlanOptions] = useState<{ label: string; value: string }[]>([]);
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);
  const { username, partner, role, settabledata, token, selectedDb,metaData,selectedBillingDb, firstLastName, sessionId } = useAuth();
  const [loading, setLoading] = useState(false);
  const [loading2, setLoading2] = useState(false);
  const [newServiceFields, setNewServiceFields] = useState(true);
  const [showProductRow, setShowProductRow] = useState(false);
  const options = [
    { value: "newService", label: "New Service" },
  ];
  const [productOptions, setProductOptions] = useState<{label: string; value: string}[]>([]);
  const [packageOptions, setPackageOptions] = useState<{label: string; value: string}[]>([]);
  const [productPackageData, setProductPackageData] = useState<any>({});
  const [selectedOption, setSelectedOption] = useState(options[0]);
  const [PrimaryField,setPrimaryField] = useState('')
  const [isPrimaryFieldEditable, setisPrimaryFieldEditable] = useState(false);
  const [builtInFields, setBuiltInFields] = useState<any[]>([]);
  const [customFields, setCustomFields] = useState<any[]>([]);
  const [formData, setFormData] = useState<FormData>({
    create: options[0],
    service_type: null,
    provider: null,
    contract_term: [null, null],
    effective_date: null,
    accounts: "",
    dest_customer: null,
    products: [],
    packages: '',
    address_line_1: null,
    city: null,
    state: null,
    postal_code: null,
    country: null,
    built_in_fields: {},
  });
  const [errors, setErrors] = useState<{
    service_type: string;
    provider: string;
    effective_date: string;
    accounts: string;
    products: string;
    packages: string;
    address_line_1: string;
    city: string;
    state: string;
    postal_code: string;
    country: string;
    dest_customer: string;
    // contract_term: string;
    iccid: string;
    msisdn: string;
    imei: string;
    eid: string;
    customer_rate_plan: string;
    primary_field: string;
  }>({
    service_type: '',
    provider: '',
    effective_date: '',
    accounts: '',
    products: '',
    packages: '',
    address_line_1: '',
    city: '',
    state: '',
    postal_code: '',
    country: '',
    dest_customer: '',
    // contract_term: '',
    iccid: '',
    msisdn: '',
    imei: '',
    eid: '',
    customer_rate_plan: '',
    primary_field: ''
  });
  const [tableData, setTableData] = useState<any>([]);
  type HeaderMap = Record<string, [string, number]>;
  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [headers, setHeaders] = useState<any[]>([]);
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const [UpdatedTableData, setUpdatedTableData] = useState<string[]>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const { features: moduleFeatures, setFeatures: setModuleFeatures } = useFeatureStore();
  const [pagination, setPagination] = useState<any>({});
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredData, setFilteredData] = useState([]);
  const [selectedProducts, setSelectedProducts] = useState<any>([]);
  const [selectedPackages, setSelectedPackages] = useState<any>([]);
  const [productRates, setProductRates] = useState<Record<string, number | null>>({});
  const [packageRates, setPackageRates] = useState<Record<string, number | null>>({});
  const [productQuantities, setProductQuantities] = useState<Record<string, number | null>>({});
  const [packageQuantities, setPackageQuantities] = useState<Record<string, number | null>>({});
  const hasFetchedData = useRef(false);
    const { servicesActive, setservicesShowActive } = useKillBillStore();
const selectedPackagesArray = Array.isArray(selectedPackages)
  ? Array.from(new Set(selectedPackages)) // remove duplicates here
  : selectedPackages
  ? [selectedPackages]
  : [];

  const { RangePicker } = DatePicker;
const initialProductsRef = useRef<string[]>([]);
const tenant_id_= localStorage.getItem("tenant_id") || "0";
useEffect(() => {
  if (dropdownValues?.customer_rate_plan) {
    setCustomerRatePlanOptions(
      dropdownValues.customer_rate_plan.map((item: string) => ({
        label: item,
        value: item,
      }))
    );
  } else {
    setCustomerRatePlanOptions([]);
  }
}, [dropdownValues?.customer_rate_plan]);

  useEffect(() => {
    if (isOpen && rowData && !hasFetchedData.current) {
      try {
        // Determine date fields from dropdownValues
        const dateFields = new Set<string>();
        if (rowData.service_type && dropdownValues?.for_new_service?.[rowData.service_type]) {
          dropdownValues.for_new_service[rowData.service_type].forEach((field: { field: string; type: string }) => {
            if (field.type === 'date') {
              dateFields.add(field.field);
            }
          });
        }
        // FetchProductPackageOptions(rowData.service_type || '');
         const customerRatePlan =
          rowData?.customer_rate_plan_id && rowData?.customer_rate_plan_name
            ? `${rowData.customer_rate_plan_id} - ${rowData.customer_rate_plan_name}`
            : null;

        // console.log("Customer Rate Plan:", customerRatePlan);
        if(customerRatePlan){
          FetchProductPackageOptions(customerRatePlan ?? "")
        }
        FetchProductPackageOptionsfromServiceType(rowData?.service_type)
        // Convert built_in_fields, only converting date fields to Dayjs
        const builtInFields = rowData.built_in_fields || {};
        console.log("rowdata.builtin fields",rowData.built_in_fields)
        const convertedBuiltInFields = Object.keys(builtInFields).reduce((acc, key) => {
          const value = builtInFields[key];
          if (dateFields.has(key) && value && dayjs(value).isValid()) {
            acc[key] = dayjs(value);
          } else {
            acc[key] = value;
          }
          return acc;
        }, {} as { [key: string]: string | Dayjs | null });

        // Parse contract_term
        let contractTerm: [Dayjs | null, Dayjs | null] = [null, null];
        if (rowData.contract_term) {
          try {
            const parsedTerm = typeof rowData.contract_term === 'string'
              ? JSON.parse(rowData.contract_term)
              : rowData.contract_term;
            if (Array.isArray(parsedTerm) && parsedTerm.length === 2) {
              const startDate = parsedTerm[0] && dayjs(parsedTerm[0]).isValid() ? dayjs(parsedTerm[0]) : null;
              const endDate = parsedTerm[1] && dayjs(parsedTerm[1]).isValid() ? dayjs(parsedTerm[1]) : null;
              contractTerm = [startDate, endDate];
            }
          } catch (e) {
            console.error("Error parsing contract_term:", e);
          }
        }

        // Initialize products and packages from product_data and package_data
        let products: string[] = [];
        let selectedPackage : any = null;
        let packages: any;
        let productRates: Record<string, number | null> = {};
        let packageRates: Record<string, number | null> = {};
        let productQuantities: Record<string, number | null> = {};
        let packageQuantities: Record<string, number | null> = {};
        let parsedProducts: any[] = [];

        if (rowData.product_data && Array.isArray(rowData.product_data) && rowData.product_data.length > 0) {
          products = rowData.product_data.map((item: any) => item.product_key).filter((key: string) => key);
          productRates = Object.fromEntries(
            rowData.product_data.map((item: any) => [item.product_key, item.rate ?? null])
          );
          productQuantities = Object.fromEntries(
            rowData.product_data.map((item: any) => [item.product_key, item.quantity ?? null])
          );
        }
        else if (rowData.products && !rowData.packages) {
          let parsedProducts;

          try {
            parsedProducts = JSON.parse(rowData.products); // 👈 convert string to array
          } catch (e) {
            console.error("Invalid products JSON:", e);
            parsedProducts = [];
          }

          if (Array.isArray(parsedProducts) && parsedProducts.length > 0) {
            products = parsedProducts

            productRates = Object.fromEntries(
              parsedProducts.map((item: any) => [item.id, item.rate ?? null])
            );

            productQuantities = Object.fromEntries(
              parsedProducts.map((item: any) => [item.id, item.quantity ?? null])
            );
          }
        }
         else if (rowData.products && rowData.packages) {
          let parsedProducts;

          try {
            parsedProducts = rowData.package_data; // 👈 convert string to array
          } catch (e) {
            console.error("Invalid products JSON:", e);
            parsedProducts = [];
          }

          if (Array.isArray(parsedProducts) && parsedProducts.length > 0) {
            products = parsedProducts

            productRates = Object.fromEntries(
              parsedProducts.map((item: any) => [item.product_id, item.rate ?? null])
            );

            productQuantities = Object.fromEntries(
              parsedProducts.map((item: any) => [item.product_id, item.quantity ?? null])
            );
          }
        }
        initialProductsRef.current = [...products];
        if (rowData.package_data && Array.isArray(rowData.package_data) && rowData.package_data.length > 0) {
          packages = rowData.package_data.map((item: any) => item.package_key).filter((key: string) => key);
          // selectedPackage = rowData.packages
          // let selectedPackage = '';

          if (typeof rowData.packages === 'string') {
            const parsedArray = rowData.packages
              .replace(/[\[\]']/g, '') // remove brackets and quotes
              .split(',')
              .map((item: any) => item.trim())
              .filter((item: any) => item); // remove empty strings

            selectedPackage = parsedArray[0] || ''; // Take only the first item
            console.log("Selected Package:", selectedPackage);
          }

         if (rowData?.package_data && rowData.package_data.length > 0) {
          packageRates = Object.fromEntries(
            rowData.package_data.map((item: any) => [`${item.package_key}-${item.id}`, item.rate ?? null])
          );

          packageQuantities = Object.fromEntries(
            rowData.package_data.map((item: any) => [`${item.package_key}-${item.id}`, item.quantity ?? 1])
          );

          console.log("Package Quantities:", packageQuantities);

          setPackageRates(packageRates);
          setPackageQuantities(packageQuantities);
        }


        } else if (rowData.packages && Array.isArray(rowData.packages) && rowData.packages.length > 0) {
          packages = rowData.packages.filter((key: string) => key);
          packageRates = Object.fromEntries(
            packages.map((key: string) => [
              key,
              rowData.package_data?.find((item: any) => item.package_key === key)?.rate ?? null,
            ])
          );
          packageQuantities = Object.fromEntries(
            packages.map((key: string) => [
              key,
              rowData.package_data?.find((item: any) => item.package_key === key)?.quantity ?? null,
            ])
          );
        }
        
       let parsedRowdataCustomFields = {};

        if (typeof rowData?.custom_fields === "string") {
          try {
            parsedRowdataCustomFields = JSON.parse(rowData.custom_fields.replace(/'/g, '"'));
          } catch (error) {
            console.error("Failed to parse custom_fields:", error);
            parsedRowdataCustomFields = {};
          }
        } else if (typeof rowData?.custom_fields === "object") {
          parsedRowdataCustomFields = rowData.custom_fields;
        }
        // Set formData
        setFormData({
          create: options[0],
          service_type: rowData.service_type ? { label: rowData.service_type, value: rowData.service_type } : null,
          provider: rowData.service_provider_name ? { label: rowData.service_provider_name, value: rowData.service_provider_name } : null,
          contract_term: contractTerm,
          effective_date: rowData.effective_date && dayjs(rowData.effective_date).isValid() ? dayjs(rowData.effective_date) : null,
          accounts: accountNumber || '',
          dest_customer: null,
          products:
            rowData.packages && rowData.package_data
              ? [] // don't set products if both exist
              : products.map((item: any) => ({
                value: item.description,
                label: item.description || '',
                rate: item.rate,
                cost: item.cost,
                quantity: item.quantity,
              })),
          packages:selectedPackage,
          address_line_1: rowData.address_line_1 || null,
          city: rowData.city || null,
          state: rowData.state || null,
          postal_code: rowData.postal_code || null,
          country: rowData.country || null,
          built_in_fields: convertedBuiltInFields,
          custom_fields:parsedRowdataCustomFields,
          iccid:rowData?.iccid,
          imei:rowData?.imei,
          eid:rowData?.eid,
          msisdn:rowData?.msisdn,
          custom_primary_field: rowData?.custom_primary_field_value || null,
          customer_rate_plan: rowData?.customer_rate_plan_id && rowData?.customer_rate_plan_name
          ? {
              value: `${rowData.customer_rate_plan_id} - ${rowData.customer_rate_plan_name}`,
              label: `${rowData.customer_rate_plan_id} - ${rowData.customer_rate_plan_name}`,
            }
          : null,
        });

        // Set selected products and packages
        setSelectedProducts(products);
        setSelectedPackages(packages);
        setProductRates(productRates);
        setPackageRates(packageRates);
        setProductQuantities(productQuantities);
        setPackageQuantities(packageQuantities);
        setBuiltInFields(rowData?.built_in_fields || {})
        setCustomFields(rowData?.custom_fields)
      let parsedCustomFields: any = {};

      if (typeof rowData?.custom_fields === "string") {
        try {
          parsedCustomFields = JSON.parse(rowData.custom_fields.replace(/'/g, '"'));
        } catch (error) {
          console.error("Failed to parse custom_fields:", error);
          parsedCustomFields = {};
        }
      } else if (typeof rowData?.custom_fields === "object") {
        parsedCustomFields = rowData.custom_fields;
      }
      console.log("parsedCustomFields",parsedCustomFields)

      // If parsedCustomFields is an object, convert to array; if already array, use as is
      const parsedCustomFieldsArray = Array.isArray(parsedCustomFields)
        ? parsedCustomFields
        : Object.entries(parsedCustomFields).map(([key, value]) => ({ key, value }));
      console.log("parsedCustomFieldsArray",parsedCustomFieldsArray)
      setCustomFields(parsedCustomFields);





        // Show product row if either product_data or package_data has data
        setShowProductRow(
          (products?.length > 0) || (packages?.length > 0)
        );
        console.log("formdata", formData);
        hasFetchedData.current = true;
      } catch (error) {
        console.error("Error parsing rowData:", error);
      }
      console.log("formdata",formData)
    }
  }, [isOpen, rowData, dropdownValues, accountNumber]);
// useEffect(() => {
//   setProductQuantities((prev) => {
//     const newQuantities = { ...prev };
//     selectedProducts.forEach((key) => {
//       if (!(key in newQuantities) || newQuantities[key] === null) {
//         newQuantities[key] = 1;
//       }
//     });
//     // Remove quantities for unselected products
//     Object.keys(newQuantities).forEach((key) => {
//       if (!selectedProducts.includes(key)) {
//         delete newQuantities[key];
//       }
//     });
//     return newQuantities;
//   });
// }, [selectedProducts]);

// useEffect(() => {
//   setPackageQuantities((prev) => {
//     const newQuantities = { ...prev };
//     (Array.isArray(selectedPackages) ? selectedPackages : selectedPackages ? [selectedPackages] : []).forEach((key: any) => {
//       if (!(key in newQuantities) || newQuantities[key] === null) {
//         newQuantities[key] = 1;
//       }
//     });
//     // Remove quantities for unselected packages
//     Object.keys(newQuantities).forEach((key) => {
//       if (!(Array.isArray(selectedPackages) ? selectedPackages : selectedPackages ? [selectedPackages] : []).includes(key)) {
//         delete newQuantities[key];
//       }
//     });
//     return newQuantities;
//   });
// }, [selectedPackages]);

 const FetchProductPackageOptionsfromServiceType = async (serviceType: string) => {
     let parsedData: any;
        try {
          setLoading(true);
          const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";

          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/get_products_packages_by_service_type",
            role_name: role,
            account_number:accountNumber,
            parent_module: "Billing Platform",
            module_name: "Customer Services",
            table_name: "customer_services",
            service_type_id : rowData?.service_type_id,
            service_type: serviceType,
            customer_service_id : rowData?.customer_service_id,
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
            ...metaData,
            billing_db_name: selectedBillingDb,
            tenant_id:tenant_id_,
            sessionID: sessionId,
            feature_module_name: "Customer Services",
          main_module_name: "Customer Profiles",
          };
    
          const response = await axios.post(url, { data });
          console.log(response)
          parsedData = JSON.parse(response.data.body);
          console.log(parsedData)
    
          if (parsedData.flag === true) {
            setLoading(false);
            console.log("parsedData:", parsedData);
            setProductPackageData(parsedData);
            const productOptionsFromApi = parsedData.products
              ? Object.keys(parsedData.products).map((key: string) => ({
                label: key,
                value: key,
              }))
              : [];

            // Set package options
            const packageOptionsFromApi = parsedData.packages && typeof parsedData.packages === 'object'
              ? Object.keys(parsedData.packages).map((key: string) => ({
                label: key,
                value: key,
              }))
              : [];
              setPrimaryField(parsedData.primary_field)
            // Save them to state variables (you should declare them using useState)
            setProductOptions(productOptionsFromApi);
            setPackageOptions(packageOptionsFromApi);
            setCustomerRatePlanOptions(
              parsedData?.customer_rate_plan?.map((item: string) => ({
                label: item,
                value: item,
              })) || []
            );
          }
          else {
            setLoading(false);
            console.log("flag set to false")
            Modal.error({
              title: "Data Fetch Error",
              content: parsedData.message || "An error occurred while fetching data. Please try again.",
              centered: true,
            });
          }
        } catch (error) {
          setLoading(false);
          Modal.error({
            title: "Data Fetch Error",
            content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
            centered: true,
          });
        } finally {
          setLoading(false);
        }
  }
const FetchProductPackageOptions = async (ratePlanType: string) => {
     let parsedData: any;
        try {
          setLoading(true);
          const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/fetch_customer_rate_plan_details",
            role_name: role,
            account_number:accountNumber,
            row_id: rowData?.id || null,
            parent_module: "Billing Platform",
            module_name: "Customer Services",
            table_name: "customer_services",
            customer_rate_plan: ratePlanType,
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            tenant_id:tenant_id_,
            db_name: selectedDb,
            ...metaData,
            billing_db_name: selectedBillingDb,
            sessionID: sessionId,
            main_module_name: "Customer Profiles",
            feature_module_name: "Customer Services",
          };
    
          const response = await axios.post(url, { data });
          console.log(response)
          parsedData = JSON.parse(response.data.body);
          console.log(parsedData)
    
          if (parsedData.flag === true) {
            setLoading(false);
            console.log("parsedData:", parsedData);
            setProductPackageData(parsedData);
            setBuiltInFields(parsedData?.built_in_fields || {})
            setCustomFields(parsedData?.custom_fields || {})
            // setServiceTypeID(parsedData?.service_type_id)

            // Set service_type dropdown value from parsedData.service_type
            setFormData(prev => ({
              ...prev,
              products: parsedData?.product
              ? parsedData.product.map((item: string) => ({ label: item, value: item }))
              : [],
              packages:parsedData?.packges,
              service_type: parsedData.service_type
                ? { label: parsedData.service_type, value: parsedData.service_type }
                : null,
            }));
            setFormData(prev => ({
              ...prev,
              // provider: parsedData?.service_provider_name || "hello",
              custom_fields: parsedData?.custom_fields || {},
              built_in_fields: parsedData?.built_in_fields || {},
            }));

            // Determine if products exist and are non-empty
            const hasProducts = !parsedData.packages && parsedData.products && Array.isArray(parsedData.products) && parsedData.products.length > 0;
            const hasPackages = parsedData.packages && parsedData.packages !== null && parsedData.packages !== "";
            if (hasProducts) {
              // Map products keys for options and selectedProducts
              const productOptionsFromApi = parsedData.products.map((prod: any) => ({
                label: `${prod.product_id} - ${prod.description}`,
                value: String(prod.product_id),
              }));
              const productKeys = productOptionsFromApi.map((opt: { value: any; }) => opt.value); // Use full "id - desc"
              setProductOptions(productOptionsFromApi);
              console.log("productKeys",productKeys)
              setSelectedProducts(parsedData.products);
              // setFormData(prev => ({
              //   ...prev,
              //   products: productKeys,
              //   packages: '',
              // }));
              // setProductsFields(true);
              setPackageOptions([]);
              setSelectedPackages([]);
            } else if(hasPackages) {
              
              const packageOptionsFromApi = parsedData.packages
              ? [
                  {
                    label: parsedData.packages,
                    value: parsedData.packages,
                  },
                ]
                : [];
                const packageKeys = packageOptionsFromApi.map((opt: { value: any; }) => opt.value); 
              setPackageOptions(packageOptionsFromApi);
              setSelectedPackages(parsedData?.products);
              // setFormData(prev => ({
              //   ...prev,
              //   packages: packageKeys[0],
              //   products: [],
              // }));
              // setProductsFields(false);
              setSelectedProducts([]);
              setProductOptions([]);
            }
            else{
              Modal.error({
                title: "Error",
                content: "No products or packages available",
                centered : true
              })
               setFormData(prev => ({
              ...prev,
              customer_rate_plan:null
            }));

            }

            // setPrimaryField(parsedData?.primary_field);
          }
          else {
            setLoading(false);
            console.log("flag set to false")
            Modal.error({
              title: "Data Fetch Error",
              content: parsedData.message || "An error occurred while fetching data. Please try again.",
              centered: true,
            });
          }
        } catch (error) {
          setLoading(false);
          Modal.error({
            title: "Data Fetch Error",
            content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
            centered: true,
          });
        } finally {
          setLoading(false);
        }
  }
  const SubmitData = async (formData: FormData) => {
    setLoading2(true);
    try {
      const cleanedData = Object.keys(formData).reduce((acc: any, key) => {
        const value = formData[key];
        acc["service_type_id"] = rowData.service_type_id
        if (key === 'create' && value === "newService") {
          acc[key] = value;
        } 
        else if (key === 'products') {
          acc[key] = Array.isArray(value) ? value : [];
          acc['product_data'] = selectedProducts.map((key:any) => ({
            ...key
            // product_key: key,
            // description: rowData.product_data?.find((item: any) => item.product_key === key)?.description ||
            //              productPackageData?.products?.[key]?.description || key,
            // rate: productRates[key] ?? null,
            // quantity: productQuantities[key] ?? null,
            // total_rate: productRates[key] !== null && productQuantities[key] !== null ? productRates[key]! * productQuantities[key]! : null,
            // id: rowData.product_data?.find((item: any) => item.product_key === key)?.id ||
            //     productPackageData?.products?.[key]?.id || null,
          }));
            
          if (!selectedPackages) {
            acc['package_data'] = [];
          } 
          else {
            acc['package_data'] = selectedPackages.map((key:any) => {
            // const [pkgKey, idxStr] = key.split("__");
            // const pkgArray = productPackageData?.packages?.[pkgKey];
            // const pkgIndex = parseInt(idxStr, 10);
            // const pkg = Array.isArray(pkgArray) ? pkgArray[pkgIndex] : null;

            return {
              ...key
              // package_key: pkgKey,
              // product_description: pkg?.description || '',
              // rate: packageRates[key] ?? null,
              // quantity: packageQuantities[key] ?? null,
              // total_rate: packageRates[key] !== null && packageQuantities[key] !== null
              //   ? packageRates[key]! * packageQuantities[key]!
              //   : null,
              // id: pkg?.id || null,
            };
          });
            // // Normalize selectedPackages to always be an array
            // const packagesArray = Array.isArray(selectedPackages) ? selectedPackages : [selectedPackages];

            // // Collect and flatten all package entries
            // const allPackages = packagesArray.flatMap(pkgKey => {
            //   // Get all items matching package_key from rowData.package_data
            //   const matchingRows = rowData.package_data?.filter((item: any) => item.package_key === pkgKey) || [];

            //   // Fallback dropdown data if no matching row data
            //   const dropdownProducts = productPackageData?.packages?.[pkgKey] || [];

            //   // Debugging logs
            //   console.log("Iterating package:", pkgKey);
            //   console.log("Matching Rows:", matchingRows);
            //   console.log("Dropdown products fallback:", dropdownProducts);

            //   if (matchingRows.length > 0) {
            //     console.log("Found matching rows for package:", matchingRows);
            //     // Map over each matching row to produce individual package data entries
            //     return dropdownProducts.map((product: { id: any; description: any; }) => {
            //       const matchedRow = matchingRows.find((row: { id: any; }) => row.id === product.id);
            //       console.log("Matched Row:", matchedRow);
            //       console.log("packageRates:", packageRates);
            //       console.log("packageQuantities:", packageQuantities);
            //       console.log("pkgKey:", pkgKey);
            //       return {
            //         package_key: pkgKey,
            //         product_description: product.description,
            //         rate: packageRates[`${pkgKey}-${product.id}`] ?? matchedRow?.rate ?? null,
            //         quantity: packageQuantities[`${pkgKey}-${product.id}`] ?? matchedRow?.quantity ?? null,
            //         total_rate:
            //           (packageRates[`${pkgKey}-${product.id}`] ?? matchedRow?.rate) != null &&
            //           (packageQuantities[`${pkgKey}-${product.id}`] ?? matchedRow?.quantity) != null
            //             ? (packageRates[`${pkgKey}-${product.id}`] ?? matchedRow?.rate)! *
            //               (packageQuantities[`${pkgKey}-${product.id}`] ?? matchedRow?.quantity)!
            //             : null,
            //         id: product.id,
            //       };
            //     });
            //   } else {
            //     console.log("No matching rows for package:", pkgKey);
            //     // No matching rows, fallback to dropdown product array for this package
            //     return dropdownProducts.map((product: { description: any; id: any; rate: any; }) => ({
            //       package_key: pkgKey,
            //       product_description: product.description,
            //       rate: packageRates[`${pkgKey}-${product.id}`] ?? product.rate ?? null,
            //       quantity: packageQuantities[`${pkgKey}-${product.id}`] ?? 1,
            //       total_rate:
            //         packageRates[`${pkgKey}-${product.id}`] != null && packageQuantities[`${pkgKey}-${product.id}`] != null
            //           ? packageRates[`${pkgKey}-${product.id}`]! * packageQuantities[`${pkgKey}-${product.id}`]!
            //           : null,
            //       id: product.id,
            //     }));
            //   }
            // });

            // // Deduplicate by `id` only (keep first occurrence)
            // const seenIds = new Set();
            // const uniquePackages = allPackages.filter(pkg => {
            //   if (seenIds.has(pkg.id)) return false;
            //   seenIds.add(pkg.id);
            //   return true;
            // });

            // acc['package_data'] = uniquePackages;
          }
    } else if (key === 'built_in_fields') {
          if (Object.keys(value).length > 0) {
            acc[key] = Object.keys(value).reduce((fieldsAcc: any, fieldKey) => {
              const fieldValue = value[fieldKey];
              fieldsAcc[fieldKey] = fieldValue && dayjs.isDayjs(fieldValue) && fieldValue.isValid()
                ? fieldValue.format('YYYY-MM-DD')
                : fieldValue;
              return fieldsAcc;
            }, {});
          }
        } else if (
          value !== null &&
          value !== undefined &&
          value !== "" &&
          !(Array.isArray(value) && value.every((item) => item === null || item === ""))
        ) {
          if (typeof value === "object" && value?.label) {
            acc[key] = value.value;
          } else if (key === 'contract_term' && Array.isArray(value)) {
            acc[key] = value.map((date: Dayjs | null) => (date && dayjs.isDayjs(date) && date.isValid() ? date.format('YYYY-MM-DD') : null));
          } else if (key === 'effective_date' && dayjs.isDayjs(value) && value.isValid()) {
            acc[key] = value.format('YYYY-MM-DD');
          } else {
            acc[key] = value;
          }
        }
        return acc;
      }, {});
      cleanedData.row_id = rowData.id;
      cleanedData.primary_field = PrimaryField

      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const selectedPlanName = formData.customer_rate_plan?.label?.split(" - ")[1] || "";
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/update_customer_service",
        role_name: role,
        module_name: "Customer Profile Services",
        feature_module_name: "Billing Platform",
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        billing_db_name: selectedBillingDb,
        request_received_at: getCurrentDateTime(),
        sessionID: sessionId,
        tenant_id:tenant_id_,
        action: "update",
        modified_by: firstLastName,
        changed_data: cleanedData,
        account_number: accountNumber,
        modified_date: getCurrentDateTime(),
        main_module_name: "Customer Profiles",
        is_new_cp : rowData.customer_rate_plan_name !== selectedPlanName
      };

      const response = await axios.post(url, { data });
      const resp = JSON.parse(response.data.body);
      if (response.data.statusCode === 200 && resp.flag === true) {
        try {
          setLoading(true);
          const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";

          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/customer_services_list_view",
            role_name: role,
            account_number: accountNumber,
            parent_module: "Billing Platform",
            module_name: "Customer Services",
            table_name: "customer_services",
            mod_pages: {
              start: 0,
              end: 100,
            },
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            tenant_id:tenant_id_,
            db_name: selectedDb, 
            ...metaData,
            billing_db_name: selectedBillingDb,           
            sessionID: sessionId,
            status: servicesActive ? "true" : "false",
            feature_module_name: "Customer Services",
          main_module_name: "Customer Profiles",
          };

          const response = await axios.post(url, { data });
          const parsedData = JSON.parse(response.data.body);

          if (parsedData.flag === true) {
            settabledata(parsedData?.data?.customer_services || []);
          }
          notification.success({
            message: 'Success',
            description: 'Successfully updated the record!',
            style: messageStyle,
            placement: 'top',
          });
          handleCancel();
          onClose();
        } catch {
          // Handle error
        } finally {
          setLoading(false);
        }
      } else {
        const errorMsg = JSON.parse(response.data.body).message;
        Modal.error({
          title: "Saving Error",
          content: errorMsg,
          centered: true,
        });
        setIsConfirmationOpen(false);
      }
    } catch (error) {
      Modal.error({
        title: 'Submit Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting data. Please try again.',
        centered: true,
        onOk: onClose,
      });
    } finally {
      setLoading2(false);
    }
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    const isValid = validateForm();
    if (isValid) {
      setIsConfirmationOpen(true);
    }
  };

  const handleCancel = () => {
    setIsConfirmationOpen(false);
    setShowProductRow(false);
    setFormData({
      create: options[0],
      service_type: null,
      provider: null,
      contract_term: [null, null],
      effective_date: null,
      accounts: '',
      dest_customer: null,
      products: [],
      packages: null,
      address_line_1: null,
      city: null,
      state: null,
      postal_code: null,
      country: null,
      built_in_fields: {},
    });
    setErrors({
      service_type: '',
      provider: '',
      effective_date: '',
      accounts: '',
      products: '',
      packages: '',
      address_line_1: '',
      city: '',
      state: '',
      postal_code: '',
      country: '',
      dest_customer: '',
    //   contract_term: '',
      iccid: '',
      msisdn: '',
      imei: '',
      eid: '',
    customer_rate_plan: '',
    primary_field: ''
    });
    setHeaderMap({});
    setTableData([]);
    setHeaders([]);
    setNewServiceFields(true);
    setSelectedProducts([]);
    setSelectedPackages(null);
    setProductRates({});
    setPackageRates({});
    hasFetchedData.current = false;
    onClose();
  };

  const handleCancelConfirmation = () => {
    setIsConfirmationOpen(false);
  };

  const handleConfirmCreate = () => {
    SubmitData(formData);
  };

const validateForm = () => {
  let isValid = true;

  const requiredFields: Record<string, string> = {
    service_type: 'Service Type is required.',
    provider: 'Provider is required.',
    effective_date: 'Effective Date is required.',
    address_line_1: 'Address is required.',
    city: 'City is required.',
    state: 'State is required.',
    postal_code: 'Postal Code is required.',
    country: 'Country is required.',
  };

  const newValidationErrors: typeof errors & { [key: string]: string } = {
  service_type: '',
  provider: '',
  effective_date: '',
  accounts: '',
  products: '',
  packages: '',
  address_line_1: '',
  city: '',
  state: '',
  postal_code: '',
  country: '',
  dest_customer: '',
  iccid: '',
  msisdn: '',
  imei: '',
  eid: '',
  customer_rate_plan: '',
  primary_field:''
};

  // Check required fields
  for (const field in requiredFields) {
    if (!formData[field]) {
      newValidationErrors[field] = requiredFields[field];
      isValid = false;
    }
  }

  // Postal Code validation
  const postalCode = formData.postal_code as string;
  if (postalCode) {
    if (!/^\d+$/.test(postalCode)) {
      newValidationErrors.postal_code = 'Postal Code must only contain numbers.';
      isValid = false;
    } else if (postalCode.length !== 5) {
      newValidationErrors.postal_code = 'Postal Code must be exactly 5 digits.';
      isValid = false;
    }
  }

  // Primary field validations
  const validateNumberField = (field: string, label: string, lengthRange?: [number, number]) => {
    const value = formData[field] as string;
    if (!value) {
      newValidationErrors[field] = `${label} is required.`;
      isValid = false;
    } else if (!/^\d+$/.test(value)) {
      newValidationErrors[field] = `${label} must only contain numbers.`;
      isValid = false;
    } else if (lengthRange) {
      const [min, max] = lengthRange;
      if (value.length < min || value.length > max) {
        newValidationErrors[field] = `${label} must be between ${min} and ${max} digits.`;
        isValid = false;
      }
    }
  };

  switch (PrimaryField) {
    case 'ICCID':
      validateNumberField('iccid', 'ICCID', [14, 22]);
      break;
    case 'MSISDN':
      validateNumberField('msisdn', 'MSISDN', [10, 10]);
      break;
    case 'IMEI':
      if (!formData.imei) {
        newValidationErrors.imei = 'IMEI is required.';
        isValid = false;
      }
      break;
    case 'EID':
      if (!formData.eid) {
        newValidationErrors.eid = 'EID is required.';
        isValid = false;
      }
      break;
  }

  setErrors(newValidationErrors);
  return isValid;
};

  const handleSelectChange = (key: keyof FormData) => (selectedValues: any) => {
      if (selectedValues === null) {
        setFormData(prev => ({
          ...prev,
          [key]: null,
        }));
      }
    if (key === "service_type") {
      setFormData(prev => ({
        ...prev,
        service_type: selectedValues,
        products: [],
        packages: null,
        built_in_fields: {},
      }));
      setSelectedProducts([]);
      setSelectedPackages(null);
      setErrors(prev => ({
        ...prev,
        service_type: '',
        products: '',
        packages: '',
      }));
      setSelectedProducts([]);
      setSelectedPackages(null);
      setProductRates({});
      setPackageRates({});
    } else if (key === "products") {
      const newProductValues = selectedValues.map((val: any) => String(val));

      setFormData(prev => ({
        ...prev,
        products: selectedValues.map((val: any) => String(val)),
        packages: null,
      }));
      if (selectedValues.length > 0) {
        setErrors(prev => ({
          ...prev,
          products: '',
          packages: '',
        }));
      }
      // setSelectedProducts(prev => {
      //   const newKeys = newProductValues.filter((key: string) => !prev.includes(key));
      //   const retained = prev.filter(key => newProductValues.includes(key));
      //   return [...newKeys, ...retained]; // new ones at the top
      // });

      // Preserve existing rates for products that remain selected
      setProductRates(prevRates => {
        const newRates = { ...prevRates };
        // Remove rates for products no longer selected
        Object.keys(newRates).forEach(key => {
          if (!newProductValues.includes(key)) {
            delete newRates[key];
          }
        });
        // Add default rates for newly selected products
        newProductValues.forEach((key: string) => {
          if (!(key in newRates)) {
            newRates[key] = productPackageData?.products?.[key]?.rate ?? null;
          }
        });
        return newRates;
      });
      setProductQuantities(prevQuantities => {
        const newQuantities: Record<string, number> = {};
        newProductValues.forEach((key: string) => {
          newQuantities[key] = prevQuantities[key] ?? 1;
        });
        return newQuantities;
      });


      setPackageRates({});
    } 
   else if (key === "packages") {
  const newPackageValues = Array.isArray(selectedValues)
    ? selectedValues
    : selectedValues
      ? [String(selectedValues)]
      : [];

  setFormData(prev => ({
    ...prev,
    packages: newPackageValues.length > 0 ? newPackageValues[0] : null,
    products: [],
  }));

  if (newPackageValues.length > 0) {
    setErrors(prev => ({
      ...prev,
      packages: '',
      products: '',
    }));
  }

  setSelectedPackages(newPackageValues); // ✅ Set full array

  const updatedRates: Record<string, number> = {};
  const updatedQuantities: Record<string, number> = {};

  newPackageValues.forEach((pkgKey: string) => {
    const productsInPackage = productPackageData.packages?.[pkgKey];

    if (Array.isArray(productsInPackage)) {
      productsInPackage.forEach((product: any) => {
        const fullKey = `${pkgKey}-${product.id}`;

        const matchingRow = rowData.package_data?.find(
          (p: any) => p.package_key === pkgKey && p.id === product.id
        );

        updatedRates[fullKey] = matchingRow?.rate ?? product.rate ?? 0;
        updatedQuantities[fullKey] = matchingRow?.quantity ?? 1;
      });
    }
  });

  setPackageRates(updatedRates);
  setPackageQuantities(updatedQuantities);

  setProductRates({});
    }
    else if(key === "customer_rate_plan"){
    setFormData(prev => ({
      ...prev,
      // iccid:'',
      customer_rate_plan :selectedValues,
      provider:null
    }));
    setisPrimaryFieldEditable(true)
    if(selectedValues!== null){
      FetchProductPackageOptions(selectedValues?.value || '');
    }
    else{
      setProductPackageData(null);
      setSelectedPackages([]);
      setFormData(prev => ({
      ...prev,
      service_type :null,
      packages:null,
      products:[],
    }));
    }
  }

else {
      setFormData(prev => ({
        ...prev,
        [key]: selectedValues,
      }));
      if (selectedValues) {
        setErrors(prev => ({
          ...prev,
          [key]: '',
        }));
      }
    }
  };

  const handleInputChange = (key: keyof FormData) => (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setFormData(prev => ({
      ...prev,
      [key]: value,
    }));
    if (key === 'postal_code') {
      if (!value) {
        setErrors(prev => ({
          ...prev,
          postal_code: 'Postal Code is required.',
        }));
      } else if (!/^\d+$/.test(value)) {
        setErrors(prev => ({
          ...prev,
          postal_code: 'Postal Code must only contain numbers.',
        }));
      } else if (value.length !== 5) {
        setErrors(prev => ({
          ...prev,
          postal_code: 'Postal Code must be exactly 5 digits.',
        }));
      } else {
        setErrors(prev => ({
          ...prev,
          postal_code: '',
        }));
      }
    } 
    if(key === 'address_line_1'){
      if (!value) {
        setErrors(prev => ({
          ...prev,
          address_line_1: 'Address is required.',
        }));
      } else {
        setErrors(prev => ({
          ...prev,
          address_line_1: '',
        }));
      }
    } 
    if(key ==='country'){
      if (!value) {
        setErrors(prev => ({
          ...prev,
          country: 'Country is required.',
        }));
      } else {
        setErrors(prev => ({
          ...prev,
          country: '',
        }));
      }
    }else {
      if (value) {
        setErrors(prev => ({
          ...prev,
          [key]: '',
        }));
      }
    }
  };
   const FetchPrimaryFieldDetails = async (primaryKey: any) => {
      console.log("formdata",formData)
      let parsedData: any;
      const primaryValue = formData?.[primaryKey] || ""
      try {
        setLoading(true);
        const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/fetch_customer_rate_plan_details_by_service_type",
          role_name: role,
          account_number: accountNumber,
          parent_module: "Billing Platform",
          module_name: "Customer Services",
          table_name: "customer_services",
          service_type: formData?.service_type?.value || "",
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          tenant_id: tenant_id_,
          db_name: selectedDb,
          ...metaData,
          billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          main_module_name: "Customer Profiles",
          feature_module_name: "Customer Services",
          primary_key: primaryKey || "",
          primary_value: primaryValue || "",
          customer_rate_plan:formData.customer_rate_plan?.label ?? null
        };
  
        const response = await axios.post(url, { data });
        console.log(response)
        parsedData = JSON.parse(response.data.body);
        console.log(parsedData)
  
        if (parsedData.flag === true) {
          setLoading(false);
          console.log("parsedData:", parsedData);
          const customer_plan_options = parsedData?.customer_rate_plan || []
          const customerRatePlanOptions_ = customer_plan_options
            ? customer_plan_options.map((item: string) => ({
              label: item,
              value: item,
            }))
            : [];
          // setCustomerRatePlanOptions(customerRatePlanOptions_)
          setFormData(prev => ({
            ...prev,
            provider: parsedData.service_provider_name ? { label: parsedData.service_provider_name, value: parsedData.service_provider_name } : null,
              service_type_id: parsedData.service_type_id
              ? parsedData.service_type_id
              : null,
          }));
          // Clear validation errors when values are set programmatically
          setErrors(prev => ({
            ...prev,
            provider: parsedData.service_provider_name ? '' : prev.provider,
            // You can also clear other related errors if needed
          }));
  
        }
        else {
          setLoading(false);
          console.log("flag set to false")
          if(parsedData.validation){
          Modal.error({
            title: "Validation Error",
            content: parsedData.message || "An error occurred while fetching data. Please try again.",
            centered: true,
          });
          }
          else{
            Modal.error({
              title: "Data Fetch Error",
              content: parsedData.message || "An error occurred while fetching data. Please try again.",
              centered: true,
            });
          }
        }
      } catch (error) {
        setLoading(false);
        Modal.error({
          title: "Data Fetch Error",
          content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
          centered: true,
        });
      } finally {
        setLoading(false);
      }
    }

  const handleContractTermChange = (dates: [Dayjs | null, Dayjs | null] | null, dateStrings: [string, string]) => {
    if (dates && dates.length === 2) {
      setFormData((prevState) => ({
        ...prevState,
        contract_term: dates,
      }));
      setErrors(prev => ({
        ...prev,
        contract_term: '',
      }));
    } else {
      setFormData((prevState) => ({
        ...prevState,
        contract_term: [null, null],
      }));
    }
  };

  const newServiceTypeOptions = dropdownValues?.for_new_service
    ? Object.keys(dropdownValues.for_new_service).map((key) => ({
        label: key,
        value: key,
      }))
    : [];

  const providerOptions = dropdownValues?.provider?.map((item: string) => ({
    label: item,
    value: item,
  }));
  // const productOptions = dropdownValues?.products_
  //   ? Object.keys(dropdownValues.products_.products || {}).map((key: string) => ({
  //       label: key,
  //       value: key,
  //     }))
  //   : [];
  // const packageOptions = dropdownValues?.products_
  //   ? Object.keys(dropdownValues.products_.packages || {}).map((key: string) => ({
  //       label: key,
  //       value: key,
  //     }))
  //   : [];
  const stateOptions = dropdownValues?.state?.map((item: string) => ({
    label: item,
    value: item,
  })) || [];

  const ProductsMultiSelect = ({ label = "Products" }: { label?: string }) => (
        <div className="custom-disabled-antd-select">
      <label className="field-label">{label}</label>
      <Select
        mode="multiple"
        showArrow
        showSearch
        style={{ width: "100%" }}
        value={formData.products.map((v: any) => v.value)}  
        disabled
        placeholder="Select products"
        options={productOptions.map((item: any) => ({
          label: String(item.label ?? ""),
          value: String(item.value ?? ""),
        }))}
        getPopupContainer={(triggerNode) => triggerNode.parentNode as HTMLElement}
        maxTagCount={1}
        maxTagPlaceholder={(omittedValues) => `+${omittedValues.length}`}
        tagRender={(props) => {
          const { label, closable, onClose } = props;
          const labelString = String(label);
          const truncatedLabel = labelString.length > 190 ? `${labelString.slice(0, 187)}...` : labelString;
          const allSelectedLabels = formData.products
            .map((value: any) => {
              const option = productOptions.find((opt: any) => opt.value === (typeof value === 'object' ? value.value : value));
              return option?.label || value;
            })
            .join(', ');
          return (
            <span
              className="inline-flex items-center text-ellipsis px-1 py-1 overflow-hidden whitespace-nowrap relative bg-white shadow-lg rounded-lg max-w-[185px] archive-summary-warning"
              title={allSelectedLabels}
              style={{
                maxWidth: '165px',
                wordWrap: 'break-word',
                overflow: 'hidden',
              }}
            >
              {truncatedLabel}
              {closable && (
                <CloseOutlined
                  onClick={onClose}
                  style={{ marginLeft: 4, cursor: 'pointer', color: 'black' }}
                />
              )}
            </span>
          );
        }}
        dropdownRender={(menu) => (
          <div
            className="relative bg-white shadow-lg rounded-lg max-w-full"
            style={{ maxHeight: "250px", overflowY: "auto" }}
          >
            <VirtualList
              data={productOptions}
              height={250}
              itemHeight={0}
              itemKey="value"
            >
              {(item) => {
                const isChecked = formData.products.some((v: any) => (typeof v === 'object' ? v.value === item.value : v === item.value));
                return (
                  <div key={item.value} className="ml-2 mb-2 flex items-center">
                    <Checkbox
                      checked={isChecked}
                      onChange={(e) => {
                        const currentValues = formData.products.map((v: any) => (typeof v === 'object' && v?.value ? v.value : v));
                        const newValues = e.target.checked
                          ? [...currentValues, item.value]
                          : currentValues.filter((v) => v !== item.value);
                        handleSelectChange('products')(newValues);
                      }}
                      disabled={ initialProductsRef.current.includes(item.value) ||formData.packages !== null && formData.packages !== "" }
                    >
                      {item.label}
                    </Checkbox>
                  </div>
                );
              }}
            </VirtualList>
          </div>
        )}
        onChange={(value) => {
          if (value === undefined || value === null) {
            handleSelectChange('products')([]);
          } else {
            handleSelectChange('products')(value);
          }
        }}
      />
      {errors.products && <span className="text-red-500">{errors.products}</span>}
    </div>
  );

  const PackagesMultiSelect = ({ label = "Packages" }: { label?: string }) => (
        <div className="custom-disabled-antd-select">
      <label className="field-label">{label}</label>
      <Select
        allowClear
        showArrow
        showSearch
        style={{ width: "100%" }}
        value={typeof formData.packages === 'string' ? formData.packages : undefined}
        disabled
        placeholder="Select package"
        options={packageOptions.map((item: any) => ({
          label: String(item.label ?? ""),
          value: String(item.value ?? ""),
        }))}
        getPopupContainer={(triggerNode) => triggerNode.parentNode as HTMLElement}
        onChange={(value) => {
          if (value === undefined || value === null) {
            handleSelectChange('packages')(null);
          } else {
            handleSelectChange('packages')(value);
          }
        }}
      />
      {errors.packages && <span className="text-red-500">{errors.packages}</span>}
    </div>
  );

  const modalWidth = typeof window !== "undefined"
  ? window.innerWidth <= 768  // 768px is Tailwind's `md` breakpoint
    ? (window.innerWidth * 3.5) / 4
    : (window.innerWidth * 2.5) / 4
  : 0;  
  const modalHeight = typeof window !== "undefined" ? (window.innerHeight * 2.5) / 4 : 0;

  if (loading2) {
    return (
      <div className="absolute inset-0 flex justify-center items-center bg-white bg-opacity-75 z-50 border pointer-events-none">
        <div className='flex justify-center'>
          <Spin size="large" />
        </div>
      </div>
    );
  }
// Ensure customFields is always a proper object
let normalizedCustomFields: Record<string, any> = {};

if (typeof customFields === "string") {
  try {
    normalizedCustomFields = JSON.parse(
      (customFields as string).replace(/'/g, '"') // convert to valid JSON
    );
  } catch (e) {
    console.error("Invalid customFields string:", e);
  }
} else if (Array.isArray(customFields)) {
  normalizedCustomFields = customFields.reduce<Record<string, any>>((acc, item) => {
    if (item.key) acc[item.key] = item.value;
    return acc;
  }, {});
} else if (customFields && typeof customFields === "object") {
  normalizedCustomFields = customFields;
}

// Suppose your editable state is an array like:
// [{ key: "Test", value: "Srikanth11" }, { key: "Customer Id", value: "34763446" }]

const handleCustomFieldsChange = (dbColumnName: string, value: any) => {
  console.log("custom_fields",customFields)
  console.log("custom_fields",value)
  setFormData((prev) => ({
    ...prev,
    custom_fields: {
      ...(prev.custom_fields ?? {}), // ensure object, avoid spreading undefined
      [dbColumnName]: value,
    },
  }));
};



  return (
    <div>
      <Modal
        open={isOpen}
        onCancel={handleCancel}
        title={<h3 className='popup-heading'>Edit Service</h3>}
        centered
        footer={
          <div className="justify-center flex space-x-2 mt-2">
            <button onClick={handleCancel} className="cancel-btn">Cancel</button>
            <button onClick={handleSave} className="save-btn">Save</button>
          </div>
        }
        width={modalData.length > 5 ? modalWidth : '780px'}
        styles={{ body: { height: modalHeight, padding: "4px" } }}
        bodyStyle={{ padding: '4px', minHeight: "400px", overflowY: "auto" }}
      >
        <div className={`${modalData.length > 5 ? 'popup' : ''}`}>
          <form onSubmit={handleSave}>
            {loading ? (
              <div className="flex justify-center items-center w-full h-full absolute top-0 left-0">
                <Spin size="large" />
              </div>
            ) : (
              <div className="grid grid-cols-1 w-full h-full">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 p-2">
                  <div className="flex flex-col">
                    <Dropdown
                      options={options}
                      value={formData.create}
                      onChange={(selected: any) => setSelectedOption(selected)}
                      placeholder="Create"
                    />
                  </div>
                  {newServiceFields && (
                    <>
                    <div className="flex flex-col">
                        <Dropdown
                          options={newServiceTypeOptions}
                          value={formData.service_type}
                          onChange={handleSelectChange('service_type')}
                          placeholder="Service Type"
                          mandatory={true}
                          disabled={true}
                        />
                        {errors.service_type && <span className="text-red-500">{errors.service_type}</span>}
                      </div>
                        <div className="flex flex-col">
                          <Dropdown
                            options={customerRatePlanOptions}
                            value={formData.customer_rate_plan}
                            onChange={handleSelectChange("customer_rate_plan")}
                            placeholder="Customer Rate Plan"
                            mandatory={false}
                            className={rowData.customer_rate_plan_name ? "input" : "non-editable-input"}
                            disabled={rowData.customer_rate_plan_name ? false : true}
                          />
                          {errors.customer_rate_plan && <span className="text-red-500">{errors.customer_rate_plan}</span>}
                        </div>
                           {PrimaryField === "ICCID" && (
                          <div className="flex flex-col">
                            <label className="field-label">ICCID <span className="text-red-500">*</span></label>
                            <div className="flex w-full">
                            <Input
                              value={(formData.iccid as string) || ''}
                              onChange={(e) =>
                                setFormData((prev) => ({
                                  ...prev,
                                  iccid: e.target.value,
                                  built_in_fields: { ...prev.built_in_fields, iccid: e.target.value },
                                }))
                              }
                              placeholder="Enter ICCID"
                              className="non-editable-input !w-[85%]"
                              // disabled={!isPrimaryFieldEditable}
                            />
                            <button
                              className="!w-[15%] border border-gray rounded-md p-[5px]"
                              onClick={() => FetchPrimaryFieldDetails("iccid")}>
                              <FunnelIcon className="w-5 h-5" />
                            </button>
                            </div>
                            {errors.iccid && <span className="text-red-500">{errors.iccid}</span>}
                          </div>)}
                        {PrimaryField === "MSISDN" && (<div className="flex flex-col">
                          <label className="field-label">MSISDN <span className="text-red-500">*</span></label>
                            <div className="flex w-full">
                          <Input
                            value={(formData.msisdn as string) || ''}
                            onChange={(e) => {
                              const value = e.target.value;
                              setFormData((prev) => ({
                                ...prev,
                                msisdn: value,
                                built_in_fields: { ...prev.built_in_fields, msisdn: value },
                              }));
                              if (/^\d+$/.test(value) && value.length === 10) {
                                setErrors((prev) => ({ ...prev, msisdn: '' }));
                              } else if (!/^\d+$/.test(value)) {
                                setErrors((prev) => ({
                                  ...prev,
                                  msisdn: 'MSISDN must only contain numbers.',
                                }));
                              } else if (value.length < 10 || value.length > 15) {
                                setErrors((prev) => ({
                                  ...prev,
                                  msisdn: 'MSISDN must be between 10 to 15 digits.',
                                }));
                              }
                            }}
                            placeholder="Enter MSISDN"
                            className="non-editable-input !w-[85%]"
                          />
                          <button
                            className="!w-[15%] border border-gray rounded-md p-[5px]"
                            onClick={() => FetchPrimaryFieldDetails("msisdn")}>
                            <FunnelIcon className="w-5 h-5" />
                          </button>
                          </div>
                          {errors.msisdn && <span className="text-red-500">{errors.msisdn}</span>}
                        </div>)}
                        {PrimaryField === "IMEI" && (<div className="flex flex-col">
                          <label className="field-label">IMEI <span className="text-red-500">*</span></label>
                            <div className="flex w-full">
                          <Input
                            value={(formData.imei as string) || ''}
                            onChange={(e) => {
                              const value = e.target.value;
                              setFormData((prev) => ({
                                ...prev,
                                imei: value,
                                built_in_fields: { ...prev.built_in_fields, imei: value },
                              }));
                              if (/^\d+$/.test(value) && value.length === 10) {
                                setErrors((prev) => ({ ...prev, imei: '' }));
                              } else if (!/^\d+$/.test(value)) {
                                setErrors((prev) => ({
                                  ...prev,
                                  imei: 'IMEI must only contain numbers.',
                                }));
                              } else if (value.length !== 15) {
                                setErrors((prev) => ({
                                  ...prev,
                                  imei: 'IMEI must be exactly 15 digits.',
                                }));
                              }
                            }}
                            placeholder="Enter IMEI"
                            className="non-editable-input !w-[85%]"
                          />
                          <button
                            className="!w-[15%] border border-gray rounded-md p-[5px]"
                            onClick={() => FetchPrimaryFieldDetails("imei")}>
                            <FunnelIcon className="w-5 h-5" />
                          </button>
                          </div>
                          {errors.imei && <span className="text-red-500">{errors.imei}</span>}
                        </div>)}
                        {PrimaryField === "EID" && (<div className="flex flex-col">
                          <label className="field-label">EID <span className="text-red-500">*</span> </label>
                            <div className="flex w-full">
                          <Input
                            value={(formData.eid as string) || ''}
                            onChange={(e) => {
                              const value = e.target.value;
                              setFormData((prev) => ({
                                ...prev,
                                eid: value,
                                built_in_fields: { ...prev.built_in_fields, eid: value },
                              }));
                              if (/^\d+$/.test(value) && value.length === 10) {
                                setErrors((prev) => ({ ...prev, eid: '' }));
                              } else if (!/^\d+$/.test(value)) {
                                setErrors((prev) => ({
                                  ...prev,
                                  imei: 'EID must only contain numbers.',
                                }));
                              } else if (value.length !== 10) {
                                setErrors((prev) => ({
                                  ...prev,
                                  imei: 'EID must be exactly 10 digits.',
                                }));
                              }
                            }}
                            placeholder="Enter EID"
                            className="non-editable-input !w-[85%]"
                          />
                          <button
                            className="!w-[15%] border border-gray rounded-md p-[5px]"
                            onClick={() => FetchPrimaryFieldDetails("eid")}>
                            <FunnelIcon className="w-5 h-5" />
                          </button>
                          </div>
                          {errors.eid && <span className="text-red-500">{errors.eid}</span>}
                        </div>)}
                        {PrimaryField && !["ICCID", "MSISDN", "IMEI", "EID"].includes(PrimaryField) && (
                          <div className="flex flex-col">
                            <label className="field-label">{PrimaryField}<span className="text-red-500">*</span> </label>
                            <div className="flex w-full">
                              <Input
                                value={(formData.custom_primary_field as string) || ''}
                                onChange={(e) => {
                                  const value = e.target.value;
                                  setFormData((prev) => ({
                                    ...prev,
                                    custom_primary_field: value || '',
                                  }));
                                }}
                                placeholder="Enter Primary Field"
                                className="non-editable-input" 
                                disabled/>

                            </div>
                            {errors.primary_field && <span className="text-red-500">{errors.primary_field}</span>}
                          </div>)}
                      <div className="flex flex-col">
                        <Dropdown
                          options={providerOptions}
                          value={
                              formData?.provider
                                || null
                          } 
                          onChange={handleSelectChange('provider')}
                          placeholder="Provider"
                          mandatory={true}
                          disabled={true}
                        />
                        {errors.provider && <span className="text-red-500">{errors.provider}</span>}
                      </div>
                      <div className="flex flex-col">
                        <label className="field-label">Contract Term</label>
                        <RangePicker
                          value={formData.contract_term as [Dayjs | null, Dayjs | null]}
                          onChange={handleContractTermChange}
                          format="MM-DD-YY"
                          className="input" 
                          placeholder={['Start Date', 'End Date']}
                           popupClassName="custom-range-popup"
                           disabled
                        />
                        {/* {errors.contract_term && <span className="text-red-500">{errors.contract_term}</span>} */}
                      </div>
                      <div className="flex flex-col">
                        <label className="field-label">Effective Date <span className="text-red-500">*</span></label>
                        <DatePicker
                          value={formData.effective_date}
                          onChange={handleSelectChange('effective_date')}
                          placeholder="Select a date"
                          disabled={!rowData.customer_rate_plan_name}
                          className={rowData.customer_rate_plan_name ? "input" : "non-editable-input"}
                          format="MM-DD-YY"
                          
                        />
                        {errors.effective_date && <span className="text-red-500">{errors.effective_date}</span>}
                      </div>
                   
                      <div className="flex flex-col">
                        <label className="field-label">Address <span className="text-red-500">*</span></label>
                        <Input
                          value={formData.address_line_1 || ''}
                          onChange={handleInputChange('address_line_1')}
                          placeholder="Enter Address"
                          className="non-editable-input"
                          readOnly
                        />
                        {errors.address_line_1 && <span className="text-red-500">{errors.address_line_1}</span>}
                      </div>
                      <div className="flex flex-col">
                        <label className="field-label">City <span className="text-red-500">*</span></label>
                        <Input
                          value={formData.city || ''}
                          onChange={handleInputChange('city')}
                          placeholder="Enter City"
                          className="non-editable-input"
                          readOnly
                        />
                        {errors.city && <span className="text-red-500">{errors.city}</span>}
                      </div>
                      <div className="flex flex-col">
                        <Dropdown
                          options={stateOptions}
                          value={formData.state ? { label: formData.state, value: formData.state } : null}
                          onChange={(selected: { value: any; }) => handleSelectChange('state')(selected ? selected.value : null)}
                          placeholder="State"
                          mandatory={true}
                          disabled={true}
                        />
                        {errors.state && <span className="text-red-500">{errors.state}</span>}
                      </div>
                      <div className="flex flex-col">
                        <label className="field-label">Postal Code <span className="text-red-500">*</span></label>
                        <Input
                          value={formData.postal_code || ''}
                          onChange={handleInputChange('postal_code')}
                          placeholder="Enter Postal Code"
                          className="non-editable-input"
                          readOnly
                        />
                        {errors.postal_code && <span className="text-red-500">{errors.postal_code}</span>}
                      </div>
                        <div className="flex flex-col">
                          <label className="field-label">Country <span className="text-red-500">*</span></label>
                          <Input
                            value={formData.country || ''}
                            onChange={handleInputChange('country')}
                            placeholder="Enter Country"
                            className="non-editable-input"
                            readOnly
                          />
                          {errors.country && <span className="text-red-500">{errors.country}</span>}
                        </div>
                        {(builtInFields || customFields) && (
                          <>
                            {/* Built-in fields */}
                            {builtInFields && Object.entries(builtInFields).map(([dbColumnName, value], index) => (
                              <div key={`built-${dbColumnName}-${index}`} className="flex flex-col">
                                <label className="field-label">{dbColumnName}</label>

                                {/* Assuming all are text for now; adjust type detection if needed */}
                                <Input
                                  value={typeof value === "string" ? value : ""}
                                  onChange={(e) =>
                                    setFormData((prev) => ({
                                      ...prev,
                                      built_in_fields: {
                                        ...prev.built_in_fields,
                                        [dbColumnName]: e.target.value,
                                      },
                                    }))
                                  }
                                  placeholder={`Enter ${dbColumnName}`}
                                  className="non-editable-input"
                                  readOnly
                                />
                              </div>
                            ))}


                            {/* Custom fields */}
                          {Object.entries(normalizedCustomFields).map(([dbColumnName, value], index) => (
                              <div key={`custom-${dbColumnName}-${index}`} className="flex flex-col">
                                <label className="field-label">{dbColumnName}</label>

                                {typeof value === "string" ? (
                                  <Input
                                    value={formData.custom_fields?.[dbColumnName] ?? value}
                                      onChange={(e) => handleCustomFieldsChange(dbColumnName, e.target.value)}
                                    placeholder={`Enter ${dbColumnName}`}
                                    className="input"
                                  />
                                ) : 
                                value &&
                                typeof value !== "string" &&
                                typeof (value as any).isValid === "function" &&
                                (value as any).isValid() ? (
                                  <DatePicker
                                    value={value}
                                    onChange={(date) =>
                                      setFormData((prev) => ({
                                        ...prev,
                                        custom_fields: {
                                          ...prev.custom_fields,
                                          [dbColumnName]: date,
                                        },
                                      }))
                                    }
                                    format="MM-DD-YY"
                                    placeholder={`Select ${dbColumnName}`}
                                    className="input"
                                  />
                                ) : null}
                              </div>
                            ))  }                          



                          </>
                        )}
                    </>
                  )}
                </div>
                {newServiceFields && (
                    <div className="mt-4 px-2 flex flex-col md:flex-row md:space-x-4 space-y-4 md:space-y-0">
                      <div className="flex flex-col space-y-2 md:w-1/2 lg:w-1/3">
                      <ProductsMultiSelect label="Products" />
                      <div className="text-black-500 font-semibold text-center">OR</div>
                      <PackagesMultiSelect label="Packages" />
                    </div>
                    <div className="flex-1 space-y-3">
                      {(selectedProducts.length > 0 || selectedPackages) && (
                        <div className="flex font-semibold text-gray-700 mb-2 space-x-4 bulk-history-div">
                          <div className="w-[150px]">Description</div>
                          <div className="w-[70px]">Rate</div>
                            <div className="w-[70px] !ml-10">Quantity</div>
                            <div className="w-[70px] !ml-4">Total Rate</div>
                        </div>
                      )}
                     {selectedProducts.map((product:any) => {
                            const key = product.product_id;

                            return (
                              <div key={key} className="flex items-center space-x-4">
                                <span className="w-[150px] text-gray-800 bulk-history-div">
                                  {product.description}
                                </span>

                                {/* Rate Input */}
                                <input
                                  type="number"
                                  className="non-editable-input !w-[70px]"
                                  value={product.rate ?? ''}
                                  onChange={(e) =>
                                    setProductRates((prev) => ({
                                      ...prev,
                                      [key]: e.target.value === '' ? null : parseFloat(e.target.value),
                                    }))
                                  }
                                  readOnly
                                />

                                <span>X</span>

                                {/* Quantity Input */}
                                <input
                                  type="number"
                                  className="non-editable-input !w-[70px]"
                                  value={'1'}
                                  onChange={(e) =>
                                    setProductQuantities((prev) => ({
                                      ...prev,
                                      [key]: e.target.value === '' ? null : parseInt(e.target.value, 10),
                                    }))
                                  }
                                  min={1}
                                  readOnly
                                />

                                {/* Total = rate × quantity */}
                                <input
                                  type="number"
                                  className="non-editable-input !w-[70px]"
                                  value={product?.rate || ''}
                                  readOnly
                                />
                              </div>
                            );
                          })}



                        {/* Package Rates */}
                        {selectedPackages?.map((product:any) => {
                          const key = product.product_id;
                          return (
                            <div key={key} className="flex items-center space-x-4">
                              <span className="w-[150px]">{product?.description}</span>
                              <input
                                type="number"
                                className="non-editable-input !w-[70px]"
                                value={product?.rate ?? ''}
                                onChange={(e) =>
                                  setPackageRates((prev) => ({
                                    ...prev,
                                    [key]: e.target.value === '' ? null : parseFloat(e.target.value),
                                  }))
                                }
                                readOnly
                              />
                              <span>X</span>
                              <input
                                type="number"
                                className="non-editable-input !w-[70px]"
                                value={'1'}
                                onChange={(e) =>
                                  setPackageQuantities((prev) => ({
                                    ...prev,
                                    [key]: e.target.value === '' ? null : parseInt(e.target.value, 10),
                                  }))
                                }
                                min={1}
                              />
                              <input
                                type="number"
                                className="non-editable-input !w-[70px]"
                                value={product?.rate ?? ''}
                                readOnly
                              />
                            </div>
                          );
                        })}
                      </div>



                   
                  </div>
                )}
              </div>
            )}
          </form>
        </div>
      </Modal>
      <Modal
        title="Confirmation"
        open={isConfirmationOpen}
        onCancel={handleCancelConfirmation}
        centered
        footer={
          <div style={{ display: 'flex', justifyContent: 'center', width: '100%', gap: "6px" }}>
            <button
              className="cancel-btn"
              onClick={handleCancelConfirmation}
            >
              Cancel
            </button>
            <button
              className="save-btn"
              onClick={handleConfirmCreate}
            >
              OK
            </button>
          </div>
        }
      >
        <p>Are you sure you want to update this {title
          .split(" ")
          .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
          .join(" ")}?</p>
      </Modal>
    </div>
  );
};

export default CustomerProfilesEditNewServiceModal;