import React, { useCallback, useEffect, useState } from "react";
import { Checkbox, Input, Modal, notification, Popover, Spin, Switch, DatePicker } from 'antd'; // Import DatePicker
import Select from 'react-select';
import { NonEditableDropdownStyles, DropdownStyles } from '@/app/components/css/dropdown';
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useAuth } from "@/app/components/auth_context";
import RichTextEditor from "./RichTextEditor";
import KillbillTableComponent from "./table__component";
import StepModal from "../collections/addStepModal";
const { RangePicker } = DatePicker; // Extract RangePicker

interface EditModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSave: (updatedRow: any, tableData?: any) => void;
    modalData: {
        id: number;
        display_name: string;
        type: string;
        mandatory: boolean;
        db_column_name: string;
    }[];
    title: string;
    visible?: boolean;
    action: string;
    rowData?: any;
    generalFields?: any;


}
const messageStyle = {
    fontSize: '14px',
    fontWeight: 'normal',
    padding: '16px',
};
const EditCollectionModal: React.FC<EditModalProps> = ({
    isOpen,
    onClose,
    onSave,
    modalData,
    title,
    visible,
    action,
    rowData,
    generalFields,
}) => {
    const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);
    const { username, partner, role, token, selectedDb, sessionId, metaData,selectedBillingDb,settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId, firstLastName, setStoredPagination, setAdvancedStoredPagination, setCombineAdnvaceStoredpagination } = useAuth();
    const [loading, setLoading] = useState(false);
    const [loading2, setLoading2] = useState(false);
    const [formValues, setFormValues] = useState<Record<string, any>>({});
    const [validationErrors, setValidationErrors] = useState<{
        [key: string]: string;
    }>({});
    const [createModalData, setcreateModalData] = useState<any[]>([]);
    const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
    const [pagination, setPagination] = useState<any>({});
    const [tableData, setTableData] = useState<any>([]);
    const [features, setFeatures] = useState<string[]>([]);
    const [headers, setHeaders] = useState<any[]>([]);
    const [headerMap, setHeaderMap] = useState<any>({});
    const [filteredData, setFilteredData] = useState([]);
    const [showAdvanced, setShowAdvanced] = useState(false);
    const [allowedActions, setAllowedActions] = useState<any[]>([]);
    const [generalFields2, setGeneralFields2] = useState<any>({});
    const [generalFields3, setGeneralFields3] = useState<any>({});
    const [quillValue, setQuillValue] = useState("");
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [selectedStep, setSelectedStep] = useState("");
    const tenant_id_ = localStorage.getItem("tenant_id") || "0";
    
      type HeaderMap = Record<string, [string, number]>;
    
      const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
        const entries = Object.entries(headerMap) as [string, [string, number]][];
        entries.sort((a, b) => a[1][1] - b[1][1]);
        return Object.fromEntries(entries) as HeaderMap;
      }, []);
    
    const FetchStepData = async () => {
        // settabledata([]);
        // setStoredPagination(null);
        // setAdvancedStoredPagination(null);
        // // setSearchTerm("");
        // setShowAdvanced(false)
        // setCombineAdnvaceStoredpagination(null)        
        let parsedData: any;
        try {
            setLoading(true);
            const url = ENV_ROUTES.BP_COLLECTIONS;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/collections_template_edit_view",
                role_name: role,
                parent_module: "Billing Platform",
                module_name: "Collection Steps List View",
                mod_pages: {
                    start: 0,
                    end: 100,
                },
                template_id: rowData.id,
                table_name: "collection_steps",
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: 'billing_platform',
                ...metaData,
                billing_db_name: selectedBillingDb,
                sessionID: sessionId,
                feature_module_name: "Collection Steps List View",
                action:"update",
        main_module_name: 'Collections',
            };

            const response = await axios.post(url, { data });
            console.log(response)
            parsedData = JSON.parse(response.data.body);
            console.log(parsedData)

            if (parsedData.flag === true) {
                setLoading(false);
                // Defer other state updates using a timeout to decouple them from the main thread
                setTimeout(() => {
                    const headersMap_ = parsedData?.header_map?.["Collection Steps List View"]?.header_map || {};
                    const sortedheaderMap = sortHeaderMap(headersMap_);
                    setHeaderMap(sortedheaderMap);
          
          
                    const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
                    console.log("headers", headers_)
                    setHeaders(headers_);
                    setVisibleColumns(headers_);
                    const generalFields_ = parsedData || {}
                    setGeneralFields3(generalFields_)
                    console.log("generalFields_", generalFields_)
                    setFeatures(parsedData?.header_map?.["Collection Steps List View"]?.module_features || []);
                    const featres_ = parsedData?.header_map?.["Collection Steps List View"]?.module_features || []
                    const allowedActions_: any = []
                    if (featres_.includes("Edit-Collection Steps List View")) {
                      allowedActions_.push("editStep")
                    }
                    // if (featres_.includes("Delete-Collection Steps List View")) {
                    //   allowedActions_.push("delete")
                    // }
          
                    setAllowedActions(allowedActions_)
                    const createModalData_ = parsedData?.header_map?.["Collection Steps List View"]?.pop_up || []
                    console.log("createModalData_", createModalData_)
                    setcreateModalData(createModalData_)
                    setPagination(parsedData?.pages || {});
                    setTableData(parsedData?.data?.collection_steps || []);
          
          
                  }, 0);

            } else {
                setLoading(false);
                console.log("flag set to false")
                Modal.error({
                    title: "Data Fetch Error",
                    content: parsedData.message || "An error occurred while fetching data. Please try again.",
                    centered: true,
                });
            }
        } catch (error) {
            setLoading(false);
            Modal.error({
                title: "Data Fetch Error",
                content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
                centered: true,
            });
        } finally {
            setLoading(false);
        }
    };
    useEffect(() => {
        if (isOpen) {
            setFormValues(rowData || {});
            setValidationErrors({});
            FetchStepData()
            console.log("Rowdata", rowData)
        }
    }, [isOpen, rowData]);

    const handleAddStep = async () => {


        let parsedData: any;
        try {
            setLoading(true);
            const url = ENV_ROUTES.BP_COLLECTIONS;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/add_step_data",
                role_name: role,
                parent_module: "Billing Platform",
                module_name: "Collection Steps",
                mod_pages: {
                    start: 0,
                    end: 100,
                },
                options: formValues["step_type"],
                // table_name:"collection_templates_temp",
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: 'billing_platform',
                ...metaData,
                billing_db_name: selectedBillingDb,
                sessionID: sessionId,
                feature_module_name: "Collection Steps",
        main_module_name: 'Collections',
            };

            const response = await axios.post(url, { data });
            console.log(response)
            parsedData = JSON.parse(response.data.body);
            console.log(parsedData)

            if (parsedData.flag === true) {
                setLoading(false);
                // Defer other state updates using a timeout to decouple them from the main thread
                setTimeout(() => {
                    const createModalData_ = parsedData?.header_map?.["Collection Steps"]?.pop_up || []
                    console.log("createModalData_", createModalData_)
                    setcreateModalData(createModalData_)
                    const generalFields_ = parsedData || {}
                    setGeneralFields2(generalFields_)
                    setIsModalOpen(true); 
                    setSelectedStep(formValues["step_type"])



                }, 0);

            } else {
                setLoading(false);
                console.log("flag set to false")
                Modal.error({
                    title: "Data Fetch Error",
                    content: parsedData.message || "An error occurred while fetching data. Please try again.",
                    centered: true,
                });
            }
        } catch (error) {
            setLoading(false);
            Modal.error({
                title: "Data Fetch Error",
                content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
                centered: true,
            });
        } finally {
            setLoading(false);
        }
    };
    // Call the function to test
    const SubmitData = async () => {
        setLoading2(true);
        try {
            let data;
            const url = ENV_ROUTES.BP_COLLECTIONS;


            data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/update_collection_data",
                role_name: role,
                module_name: "Collection Steps",
                feature_module_name: "Billing Platform",
                Partner: partner,
                access_token: token,
                db_name: 'billing_platform',
                ...metaData,
                billing_db_name: selectedBillingDb,
                template_table_name: "collection_templates",
                step_table_name: "collection_steps",
                request_received_at: getCurrentDateTime(),
                sessionID: sessionId,
                action: "create",
                modified_by: firstLastName,
                template_id: rowData.id,
                tenant_id: tenant_id_,
        main_module_name: 'Collections',
                changed_data: { ...formValues,stepsData:tableData  } // Spread the collected data here
            };

            const response = await axios.post(url, { data });
            const resp = JSON.parse(response.data.body);
            console.log(resp, "show the response");
            if (response.data.statusCode === 200 && resp.flag === true) {
                if (response && response.data.statusCode === 200) {
                    // Show success message
                    notification.success({
                        message: "Success",
                        description: "Successfully saved the record!",
                        style: messageStyle,
                        placement: "top", // Apply custom styles here
                    });
                    settabledata([]);
                        try {
                          setLoading2(true);
                          const url = ENV_ROUTES.BP_COLLECTIONS;
                         const data = {
                                 tenant_name: partner || "default_value",
                                 username: username,
                                 firstLastName: firstLastName,
                                 path: "/collections_list_view",
                                 role_name: role,
                                 parent_module: "Billing Platform",
                                 module_name: "Collection Templates",
                                 mod_pages: {
                                   start: 0,
                                   end: 100,
                                 },
                                 table_name: "collection_templates",
                                 // account_number: '3000005505',
                                 request_received_at: getCurrentDateTime(),
                                 Partner: partner,
                                 access_token: token,
                                 db_name: 'billing_platform',
                                 ...metaData,
                                 billing_db_name: selectedBillingDb,
                                 tenant_id: tenant_id_,
                                 sessionID: sessionId,
                                 feature_module_name: "Collection Templates",
                                main_module_name: 'Collections',
                               };
                          const response = await axios.post(url, { data });
                          const parsedData = JSON.parse(response.data.body);
                          if (parsedData.flag === false) {
                            Modal.error({
                              title: "Data Fetch Error",
                              content:
                                parsedData.message ||
                                "An error occurred while fetching Customer groups data. Please try again.",
                              centered: true,
                            });
                          } else {
                            settabledata(parsedData?.data?.collection_templates || []);
                          }
                        }
                        catch {
          
                        }
                        finally {
                          setLoading2(false);
                        }
                      
                } else {
                    const errorMsg = JSON.parse(response.data.body).message;
                    Modal.error({
                        title: "Saving Error",
                        content: errorMsg,
                        centered: true,
                    });
                    handleCancel()
                }
            } else {
                Modal.error({
                    title: "Saving Error",
                    content: resp.message,
                    centered: true,
                });
                // handleCancel()
            }
        } catch (error) {
            console.error("Error fetching data:", error);
            Modal.error({
                title: 'Submit Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting data. Please try again.',
                centered: true,
                onOk: onClose
            });
        } finally {
            setLoading2(false);
            handleCancel()

        }
    };
    const handleInputChange = (name: any, value: any) => {
        setFormValues((prevState: any) => {
            const updatedFormData = {
                ...prevState,
                [name]: value,
            };
            console.log("formdata ", updatedFormData)
            return updatedFormData;
        });

        let errors = { ...validationErrors };

        // Email validation
        if (name === "email") {
            const validateEmail = (email: string) => {
                const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
                return emailRegex.test(email);
            };
            if (!validateEmail(value)) {
                errors[name] = "Invalid email address";
            } else {
                delete errors[name]; // Remove email error if valid
            }
        }
        // Account Number validation (between 6 to 20 characters and only numbers)
        if (name === "account_number") {
            // Check if the value is provided and its length is valid
            if (value && (value.length < 6 || value.length > 20)) {
                errors[name] = "Account number must be between 6 to 20 characters.";
            }
            // Check if the value contains only numbers
            else if (value && !/^[0-9]+$/.test(value)) {
                errors[name] = "Account number must contain only numbers (0-9).";
            }
            // If valid, remove any existing error
            else {
                delete errors[name];
            }
        }
        if (name === "balance_limit") {
            if (value && !/^\d+(\.\d{0,2})?$/.test(value)) {
                errors[name] = "Balance limit must contain only numbers (0-9) with up to 2 decimal places.";
            } else {
                delete errors[name];  // Remove error if valid
            }
        }
        if (name === "step_type") {

            setcreateModalData([])
            // setFormValues({})
        }

        // Update validation errors
        setValidationErrors(errors);
    };


    const showConfirmation = () => {
        const errors: { [key: string]: string } = {};

        modalData.forEach((column) => {
            const value = formValues[column.db_column_name];

            // Mandatory field validation
            if (column.mandatory) {
                if ((Array.isArray(value) && value.length === 0) || (!Array.isArray(value) && !value)) {
                    errors[column.db_column_name] = `${column.display_name} is required.`;
                }
            }

            // Email validation
            if (column.db_column_name === "email") {
                const validateEmail = (email: string) => {
                    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
                    return emailRegex.test(email);
                };

                if (!validateEmail(value)) {
                    errors[column.db_column_name] = "Invalid email address";
                    return;
                }
            }

            // Account number validation (6-20 characters)
            if (column.db_column_name === "account_number") {
                if (value && (value.length < 6 || value.length > 20)) {
                    errors[column.db_column_name] = "Account number must be between 6 to 20 characters.";
                }
            }
        });

        // Set errors or open confirmation modal
        if (Object.keys(errors).length > 0) {
            setValidationErrors(errors);
            setIsConfirmationOpen(false); // Don't show confirmation popup if there are errors
        } else {
            setValidationErrors({});
            setIsConfirmationOpen(true); // Open confirmation popup if no errors
        }
    };
    function handleConfirmCreate(): void {

        setIsConfirmationOpen(false);
        SubmitData();
    }
    const handleCancelConfirmation = () => {
        setIsConfirmationOpen(false);
    };
    const handleCancel = () => {
        setFormValues({});
        onClose();
        setValidationErrors({});

    };


    const handleKeyPress = (event: any) => {
        const charCode = event.charCode;
        // Allow only numbers (0-9)
        if (charCode < 48 || charCode > 57) {
            event.preventDefault();
        }
    };
    const handleCloseModal = () =>{
        setIsModalOpen(false)
    }
    const handleUpdateTableData = (updatedData: any) => {
        console.log("Updated Data from Child:", updatedData);
        setTableData(updatedData);  // Update parent-level table data
      };
    if (loading2) {
        return (
            <div className="absolute inset-0 flex justify-center items-center bg-white bg-opacity-75 z-50 border pointer-events-none">
                <div className='flex justify-center'>
                    <Spin size="large" />
                </div>

            </div>

        );
    }
    const lowerCaseFirstLetter = (text: string) => {
        // if (!text) return '';
        // return text.charAt(0).toLowerCase() + text.slice(1);
        if (!text) return '';
        return text
          .split(' ') // Split the sentence into an array of words
          .map((word: string) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()) // Capitalize each word
          .join(' ');
      };
    return (
        <>
        <div className="advanced-tabs-overlay">

        <div className="p-2 push-charges-modal-content">

            {/* Header */}
            <div className="flex justify-between items-center pb-2 pt-2">
                <h3 className="popup-heading">Edit Collection Template</h3>
                <button onClick={onClose} className="text-black-700">
                    ✕
                </button>
            </div>

            {/* Form Section */}
            <div className="p-2">
                <form>
                    {loading ? (
                        <div className="flex justify-center items-center w-full h-[500px]">
                            <Spin size="large" />
                        </div>
                    ) : (
                        <>
                        <div className="flex flex-col">
                        <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 w-full">                
                        {/* Render modalData fields first */}
                                {modalData?.map((field) => (
                                    <div key={field.id} className="mb-2">
                                        {field.db_column_name === "step_type" && (
                                            <label className="text-md font-bold text-black-700">Collection Steps</label>
                                        )}

                                        {field.type !== "checkbox" && (
                                            <label className="field-label">
                                                {field.display_name}{" "}
                                                {field.mandatory && <span className="text-red-500">*</span>}
                                            </label>
                                        )}

                                        {field.type === "text" && (
                                            <div>
                                                <Input
                                                    type="text"
                                                    name={field.db_column_name}
                                                    className="input"
                                                    value={formValues[field.db_column_name] || ""}
                                                    onChange={(e) => handleInputChange(field.db_column_name, e.target.value)}
                                                    placeholder={`Enter ${field.display_name}`} />
                                                {validationErrors[field.db_column_name] && (
                                                    <span className="text-red-500">
                                                        {validationErrors[field.db_column_name]}
                                                    </span>
                                                )}
                                            </div>
                                        )}
                                        {field.type === "dollar" && (
                                            <div className="flex flex-col">
                                                <div className="relative flex items-center">  
                                                    {/* Dollar symbol */}
                                                    <span className="absolute left-2 pointer-events-none z-10">
                                                        $
                                                    </span>
                                        
                                                    <Input
                                                        type="text"
                                                        name={field.db_column_name}
                                                        className="input !pl-4"  // ✅ Add padding to make space for the "$"
                                                        value={formValues[field.db_column_name]}
                                                        onChange={(e) =>
                                                            handleInputChange(field.db_column_name, e.target.value)
                                                        }
                                                        placeholder={`Enter ${lowerCaseFirstLetter(field.display_name)}`}
                                                    />
                                                </div>
                                        
                                                {/* Validation message below */}
                                                {validationErrors[field.db_column_name] && (
                                                    <span className="text-red-500">
                                                        {validationErrors[field.db_column_name]}
                                                    </span>
                                                )}
                                            </div>
                                        )}
                                        {field.type === "dropdown" && (
                                            <div className="w-full">
                                                    <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                                                    <Select
                                                        styles={DropdownStyles}
                                                        className="w-full  z-30"
                                                        options={generalFields.dropdown?.[field.db_column_name]?.map((option: any) => ({
                                                            label: option,
                                                            value: option,
                                                        })) || []}
                                                        value={formValues[field.db_column_name]
                                                            ? { label: formValues[field.db_column_name], value: formValues[field.db_column_name] }
                                                            : null}
                                                        onChange={(value) => handleInputChange(field.db_column_name, value?.value || null)}
                                                        isClearable />
                                                    {validationErrors[field.db_column_name] && (
                                                        <span className="text-red-500">
                                                            {validationErrors[field.db_column_name]}
                                                        </span>
                                                    )}

                                                    {field.db_column_name === "step_type" && (
                                                        <button className={!formValues["step_type"]?"cancel-btn cursor-not-allowed":"save-btn"} onClick={handleAddStep} 
                                                        disabled={!formValues["step_type"]}>
                                                         Add
                                                       </button>
                                                    )}
                                                </div>

                                            </div>
                                        )}
                                    </div>
                                ))}
                            </div>
                           
                            
                            <div className="mt-4">
                                <KillbillTableComponent
                                     headers={headers}
                                     setHeaders={setHeaders}      
                                     headerMap={headerMap}
                                     setHeaderMap={setHeaderMap}   
                                     initialData={tableData}
                                     setTableData={setTableData}  
                                    visibleColumns={visibleColumns}
                                    itemsPerPage={100}
                                    allowedActions={allowedActions}
                                    popupHeading="Collections Steps"
                                    pagination={pagination}
                                    advancedFilters={filteredData}
                                    createModalData={createModalData}
                                    generalFields={generalFields3}
                                    height={showAdvanced ? 300 : 300}
                                    onTableDataUpdate={handleUpdateTableData} 
                                    
                                />
                            </div>
                        </div>
                        <StepModal
                        isModalOpen={isModalOpen}
                        setIsModalOpen={setIsModalOpen}
                        createModalData={createModalData}
                        generalFields2={generalFields2}
                        quillValue={quillValue}
                        setQuillValue={setQuillValue}
                        onClose={handleCloseModal}
                        selectedStep={selectedStep}
                        setHeaders={setHeaders}
                        setHeaderMap={setHeaderMap}
                        setTableData={setTableData}
                        tableData={tableData} 

                        />
                        </>
                    )}

                </form>
            </div>

            {/* Footer with Buttons */}
            <div className="flex justify-center space-x-2 mt-7 pt-4">
                <button onClick={handleCancel} className="cancel-btn">
                    Cancel
                </button>
                <button onClick={showConfirmation} className="save-btn">
                    Save
                </button>
            </div>
        </div>
        </div>
        <Modal
            title="Confirmation"
            open={isConfirmationOpen}
            onCancel={handleCancelConfirmation}
            centered
            footer={<div style={{ display: 'flex', justifyContent: 'center', width: '100%', gap: "6px" }}>
                <button
                    className="cancel-btn"
                    onClick={handleCancelConfirmation}
                >
                    Cancel
                </button>
                <button
                    className="save-btn"
                    onClick={handleConfirmCreate}
                >
                    OK
                </button>
            </div>}
        >
                <p>Are you sure you want to save this Template</p>
            </Modal></>

    );
};

export default EditCollectionModal;

