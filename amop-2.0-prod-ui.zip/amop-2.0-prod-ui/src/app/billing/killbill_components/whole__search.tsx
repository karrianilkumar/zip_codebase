import React, { useCallback, useEffect, useRef, useState } from "react";
import { Input, Button, Modal, Spin } from "antd";
import { SearchOutlined, CloseOutlined } from "@ant-design/icons";
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import { MultiValue } from "react-select";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useSearchStore } from "@/app/stores/searchStore";
import { debounce } from "lodash";
import { useOptimizationStore } from "@/app/stores/optimizationStore";
import { useCustomerRatePlanStore } from "@/app/stores/customerRateplanStore";
import { useKillBillStore } from "../killbill_stores/activeStore";
import { useCustomerProfileStore } from "../killbill_stores/customer_profile_store";
import { table } from "console";
import { Dayjs } from "dayjs";
interface SearchInputProps {
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  placeholder?: string;
  width?: string;
  tableName: string;
  headerMap: Record<string, any>;
  loader?: boolean;
  billId?:string;
  current_cycle?: [Dayjs | null, Dayjs | null];
  selectedSubPartner?: any;
  selectedPartner?: any;
}

interface HeaderOption {
  value: string;
  label: string;
}

const WholeTableSearch: React.FC<SearchInputProps> = ({
  searchTerm,
  setSearchTerm,
  placeholder = "Search...",
  headerMap = {},
  tableName,billId,current_cycle, selectedSubPartner,
  selectedPartner,
}) => {
  const headers = Object.keys(headerMap); // Get the keys of the headerMap
  const [selectedHeaders, setSelectedHeaders] = useState<HeaderOption[]>([]);
  const [colsList, setColsList] = useState<string[]>([]);  
  const { setSearchData, setOptimizationErrorsData, setOptimizationErrorsPagination,advancedSearchData,combineAdnvaceSearchData,setCombineAdnvaceSearchData } = useSearchStore();
  const [loading, setLoading] = useState(false);
  const [inputValue, setInputValue] = useState(searchTerm);
  const { optimizationRow } = useOptimizationStore();
  const { customerShowActive } = useCustomerRatePlanStore();
  const { serviceShowActive, productTypeShowActive,packageActive,productShowActive , servicesActive , customerProfilesActive} = useKillBillStore();
  const [searchTable, setSearchTable] = useState<any[]>([]);
  const { setCombineAdnvaceStoredpagination,advancedStoredpagination,storedpagination,combineAdnvaceStoredpagination,username, partner, role, settabledata,selectedBillingDb, tabledata, setStoredPagination, setAdvancedStoredPagination, tenantId, selectedDb, tenantName, sessionId,setWholeSearchWord } = useAuth();
  const { setAccountNumber, accountNumber, setBillId, BillId ,setSummaryExportData} = useCustomerProfileStore();



  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    setWholeSearchWord(searchTerm);
    console.log(searchTerm,"searchTerm");
  }, [searchTerm]);
  
  useEffect(() => {
    setInputValue(inputValue);
  }, [inputValue]);

   useEffect(() => {
        if(!advancedStoredpagination && !combineAdnvaceStoredpagination && searchTerm!==""){
          // handleNormalButtonClick();
        handleClear()
        }
      }, [advancedStoredpagination, combineAdnvaceStoredpagination]);

  const debouncedSearch = useCallback(
    debounce((value: string) => {
      // setStoredPagination(null);
      // setAdvancedStoredPagination(null);
      setOptimizationErrorsPagination(null)
      setSearchTerm(value);
    }, 300),
    [setStoredPagination, setAdvancedStoredPagination, setSearchTerm]
  );

  // useEffect(() => {
  //   return () => {
  //     debouncedSearch.cancel();
  //   };
  // }, [debouncedSearch]);

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;

    // Immediately update input value
    setInputValue(value);

    // Trigger debounced search for the actual search functionality (API call)
    debouncedSearch(value);
  };

  const handleClear = () => {
    setInputValue("");
    setStoredPagination(null);
    setCombineAdnvaceStoredpagination(null)
    setCombineAdnvaceSearchData(null)
    setOptimizationErrorsPagination(null)
    setAdvancedStoredPagination(null)
    setSearchTerm("");
  };


  const handleHeaderChange = (selectedOptions: MultiValue<HeaderOption>) => {
    const selectedValues = selectedOptions.map((option) => option.value);
    setSelectedHeaders(selectedOptions as HeaderOption[]);
    setColsList(selectedValues);
  };

  const Billing_Collections_modules = ["Billing and Collections Bill","Unposted","Customer Payment History","Customer Services","Ledger","Customer Service","Reversals"]
  const tenant_id_ = localStorage.getItem("tenant_id") || "0";

  const handleNormalButtonClick = async () => {
    console.log(advancedStoredpagination,"AdvancedStoredPagination");
    console.log(storedpagination,"storedpagination");
    // setAdvancedStoredPagination(null)
    console.log(advancedSearchData,"AdnvacedsearchData");
    // setStoredPagination(null);  removed the pagination setting to null
    if((advancedStoredpagination && advancedSearchData) || combineAdnvaceStoredpagination){
      const data=combineAdnvaceStoredpagination?combineAdnvaceSearchData:advancedSearchData
      handleCombineButtonClick(data);
    }else{
      try {
        setLoading(true);
        const url = ENV_ROUTES.OPEN_SEARCH;

        const data = {
            data: {
              path: "/perform_search",
              search_word: inputValue,
              search_all_columns:
                colsList.length === headers.length || colsList.length === 0
                  ? "True"
                  : "False",
              index_name: tableName,
              tenant_id: tenant_id_,
              partner: partner,
              username: username,
              db_name: selectedBillingDb,
              // Only include Selected_Partner and sub_partner if tableName is "GL Code Settings"
              ...(tableName === "GL Code Settings" && selectedPartner && { Selected_Partner: selectedPartner }),
              ...(tableName === "GL Code Settings" && selectedSubPartner && { sub_partner: selectedSubPartner }),
              sessionID: sessionId,
              search: "whole",
              pages: {
                start: 0,
                end: 100,
              },
              ...(Billing_Collections_modules.includes(tableName)
                ? {account_number:accountNumber}
                : {}),
              ...(tableName === "Billing Service"
                ? { toggle: serviceShowActive, col_sort:{description: "ASC"} }
                : {}),          
              ...(tableName === "Billing Product Type"
                ? { toggle: productTypeShowActive ,
                    col_sort:{description: "ASC"}
                  }
                : {}),
                ...(tableName === "Billing Product"
                  ? { toggle: productShowActive ,
                      col_sort:{description: "ASC"}
                    }
                  : {}),
                 ...(tableName === "Customer Services"
                  ? { toggle: servicesActive, 
                    col_sort:{description: "ASC"}
                  }
                  : {}),
              ...(tableName === "Billing Package"
                ? { toggle: packageActive,
                    col_sort:{category: "ASC"}
                  }
                : {}),  
            ...(tableName === "Customer Profile"
              ? { toggle:  customerProfilesActive,col_sort: { account_number: "ASC" } }
              : {}),
            ...(tableName === "RepostedMRC" ? {current_cycle : current_cycle , account_number:accountNumber} : {}),
             ...(tableName === "Billing Service" ? {tenant_database : selectedDb } : {})
              
          },
        };
        setSearchData(data)
        const response = await axios.post(url, data);
        const parsedData = JSON.parse(response.data.body);
        if (parsedData?.flag) {
          const tableData = parsedData?.data?.table || [];
          const pagination_ = parsedData?.pages || {};
           const summary_ = parsedData?.summary || {};
          const mappedSummary: Record<string, number> = {};

          // Loop through summary keys and map to headerMap display name
          Object.entries(summary_).forEach(([key, value]) => {
            const displayName = headerMap[key]?.[0] || key; // fallback to key if not found
            mappedSummary[displayName] = value as number;
          });

          console.log("Mapped Summary:", mappedSummary);
          setSummaryExportData(mappedSummary || {});
          if (tableName === "optimization_error_details") {
            setOptimizationErrorsData(tableData)
            setOptimizationErrorsPagination(pagination_)
          }
          else {
            settabledata(tableData);
            setSearchTable(tableData)
            setStoredPagination(pagination_);
          }
          if (tableData.length === 0) {
            Modal.error({
              title: "No Records found",
            });
          handleClear()
          }
        } else {
          Modal.error({
            title: "Search error",
            content:
              parsedData.error ||
              "An error occurred while searching. Please try again.",
          });
          handleClear()
        }
        console.log(response);
      } catch (error) {
        console.log(error);
      } finally {
        setLoading(false); // Stop loader
      }
    }
   
  };
  const handleCombineButtonClick = async (advancedSearchData_: any) => {
    setLoading(true);
    const filters_ =advancedSearchData_?.data?.filters
    try {
      const url = ENV_ROUTES.OPEN_SEARCH;
      const data = {
        data: {
          path: "/perform_search",
          search: "combined",
          filters: filters_,
          search_word: inputValue,
          search_all_columns: "True",
          index_name: tableName,
          tenant_id: tenant_id_,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedBillingDb,
          // Only include Selected_Partner and sub_partner if tableName is "GL Code Settings"
          ...(tableName === "GL Code Settings" && selectedPartner && { Selected_Partner: selectedPartner }),
          ...(tableName === "GL Code Settings" && selectedSubPartner && { sub_partner: selectedSubPartner }),
          sessionID: sessionId,
          ...(Billing_Collections_modules.includes(tableName)
            ? {account_number:accountNumber}
            : {}),
          ...(tableName === "Billing Service"
            ? { toggle: serviceShowActive, col_sort:{description: "ASC"} }
            : {}),          
          ...(tableName === "Billing Product Type"
            ? { toggle: productTypeShowActive ,
                col_sort:{description: "ASC"}
              }
            : {}),
          ...(tableName === "Billing Package"
            ? { toggle: packageActive,
                col_sort:{category: "ASC"}
              }
            : {}),  
                ...(tableName === "Billing Product"
                  ? { toggle: productShowActive ,
                      col_sort:{description: "ASC"}
                    }
                  : {}),
                  ...(tableName === "Customer Services"
                  ? { toggle: servicesActive, 
                    col_sort:{description: "ASC"}
                  }
                  : {}),
          ...(tableName === "Customer Profile"
            ? { col_sort: { account_number: "ASC" } }
            : {}),
          ...(tableName === "Customer Services" ? {bill_id : {billId}} : {}),
          ...(tableName === "Billing Service" ? {tenant_database : selectedDb } : {})
              
         
        },
       
       
      };
      
      setCombineAdnvaceSearchData(data);
      const response = await axios.post(url, data);
      const parsedData = JSON.parse(response.data.body);
      
      if (parsedData?.flag) {
        const tableData = parsedData?.data?.table;
        settabledata(tableData);
        setSearchTable(tableData)
        const pagination_ = parsedData?.pages || {};
        setCombineAdnvaceStoredpagination(pagination_);
           const summary_ = parsedData?.summary || {};
          const mappedSummary: Record<string, number> = {};

          // Loop through summary keys and map to headerMap display name
          Object.entries(summary_).forEach(([key, value]) => {
            const displayName = headerMap[key]?.[0] || key; // fallback to key if not found
            mappedSummary[displayName] = value as number;
          });

          console.log("Mapped Summary:", mappedSummary);
          setSummaryExportData(mappedSummary || {});
        if (tableData.length === 0) {
          Modal.error({
            title: "No Records found",
          });
        handleClear()
        }
      } else {
        Modal.error({
          title: "Search error",
          content: parsedData.error || "An error occurred while searching. Please try again.",
        });
        handleClear()
      }
    } catch (error) {
      console.error(error);
    }
    finally{
    setLoading(false);
    }
  };

  return (
    <div className="">
      {loading && (
        <div className="absolute inset-0 flex justify-center items-center adv-search-loader bg-white bg-opacity-75 z-50 pointer-events-none">
          <Spin size="large" />
        </div>
      )}
      <div className="flex items-center space-x-2">
        <div className="relative flex items-center border border-gray-300 rounded-lg p-1 w-full space-x-4 w-[250px]">
          <input
            placeholder={placeholder}
            value={inputValue}
            onChange={handleSearch}
            ref={inputRef}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                handleNormalButtonClick();
              }
            }}
            className="h-8 border-none outline-none w-full pl-2 pr-12 rounded-lg  search-input"
          />
          {searchTerm && (
            <CloseOutlined
              className="absolute right-8 text-gray-500 cursor-pointer"
              onClick={handleClear}
            />
          )}
          <SearchOutlined
            className="absolute right-2 text-gray-500 cursor-pointer"
            onClick={handleNormalButtonClick}
          />
        </div>
        {searchTerm && (
          <button
            className="save-btn"
            onClick={handleNormalButtonClick}
          >
            Search
          </button>
        )}
      </div>
    </div>
  );
};

export default WholeTableSearch;
