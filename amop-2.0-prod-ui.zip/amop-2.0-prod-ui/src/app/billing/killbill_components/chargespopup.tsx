
import { Modal, notification, Spin } from "antd";
import React, { Suspense, useCallback, useEffect, useRef, useState } from "react";
import KillbillTableComponent from "./table__component";
import { ArrowDownTrayIcon } from "@heroicons/react/24/outline";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { useAuth } from "@/app/components/auth_context";
import { Tabs } from "antd";
import { useCustomerProfileStore } from "../killbill_stores/customer_profile_store";

const { TabPane } = Tabs;
interface ChargesPopupProps {
  row: any;
  isOpen: boolean;
  onClose: () => void;
  popupheading: string;
}
interface ChargeOverview {
  bill_details: Record<string, number>;
  usage_details: Record<string, number>;
}


const ChargesPopup: React.FC<ChargesPopupProps> = ({
  row,
  onClose,
  isOpen, popupheading
}) => {
  const [loading, setLoading] = useState(false);
  // const [exportLoading, setExportLoading] = useState(false);
  const { addExport, removeExport } = exportLoadingStore();
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const [createModalData, setcreateModalData] = useState<any[]>([]);
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
  const [generalFields, setgeneralFields] = useState<any[]>([])
  const { username, partner, role, token, selectedDb,metaData,selectedBillingDb, sessionId, settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId, firstLastName, setStoredPagination, setAdvancedStoredPagination } = useAuth();
  const hasFetchedChargeOverview = useRef(false);
  const hasFetchedChargeByService = useRef(false);
  const [activeTab, setActiveTab] = useState("1"); // Track active tab
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [overViewData, setOverViewData] = useState<ChargeOverview>({
    bill_details: {},
    usage_details: {},
  });
  const [features, setFeatures] = useState<string[]>([]);
  const [features2, setFeatures2] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const modalHeight = typeof window !== "undefined" ? window.innerHeight * 0.5 : 0; // 50% of viewport height
  type HeaderMap = Record<string, [string, number]>;
  const { setAccountNumber, accountNumber, setBillId, BillId } = useCustomerProfileStore();

  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});

  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  const fetchData = async () => {

    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/charge_overview_list_view",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Charge Overview",
        // sub_module: "Charge Overview",
        mod_pages: {
          start: 0,
          end: 100,
        },
        bill_id: BillId,
        accoun_number: accountNumber,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: 'billing_platform',
        ...metaData,
        billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        main_module_name:  "Customer Profiles",
        feature_module_name: "Charge Overview",
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)

      if (parsedData.flag === true) {
        setLoading(false);
        // Defer other state updates using a timeout to decouple them from the main thread
        setTimeout(() => {
          if (popupheading === "Billing") {

            setOverViewData(parsedData?.data?.charge_overview || []);
            setFeatures(parsedData?.header_map?.["Charge Overview"]?.module_features || []);

          }
          else {
            setOverViewData(parsedData?.data?.charge_overview || []);
            setFeatures(parsedData?.header_map?.["Charge Overview"]?.module_features || []);


          }


        }, 0);

      } else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
  const fetchChargeByService = async () => {

    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    let parsedData: any;
    try {
      setLoading(true);
      // const LAMBDA = popupheading === "Billing"?"BP_BILLING_PAYMENTS":"BP_CUSTOMER_PROFILES"
      const url =  ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/charge_by_service_list_view",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Charge By Service",
        mod_pages: {
          start: 0,
          end: 100,
        },
        bill_id: BillId,
        account_number: accountNumber,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: 'billing_platform',
        ...metaData,
        billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        main_module_name:"Customer Profiles",
        feature_module_name: "Charge By Service",
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)

      if (parsedData.flag === true) {
        // Log data and set loading to false immediately to stop the loader
        console.log("table response:", parsedData);
        setLoading(false); // Ensure this happens right away

        // Defer other state updates using a timeout to decouple them from the main thread
        setTimeout(() => {
          if (popupheading === "Billing") {
            const headersMap_ = parsedData?.header_map?.["Charge By Service"]?.header_map || {};
            const sortedheaderMap = sortHeaderMap(headersMap_);
            setHeaderMap(sortedheaderMap);
            const generalFields_ = parsedData || {}
            setgeneralFields(generalFields_)

            const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
            console.log("headers", headers_)
            setHeaders(headers_);
            setVisibleColumns(headers_);
            setFeatures2(parsedData?.header_map?.["Charge By Service"]?.module_features || []);
            const createModalData_ = parsedData?.header_map?.["Charge By Service"]?.pop_up || []

            setcreateModalData(createModalData_)
            setPagination(parsedData?.pages || {});
            setTableData(parsedData?.data?.charge_by_service || []);

          }
          else {

            const headersMap_ = parsedData?.header_map?.["Charge By Service"]?.header_map || {};
            const sortedheaderMap = sortHeaderMap(headersMap_);
            setHeaderMap(sortedheaderMap);
            const generalFields_ = parsedData || {}
            setgeneralFields(generalFields_)

            const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
            console.log("headers", headers_)
            setHeaders(headers_);
            setVisibleColumns(headers_);
            setFeatures2(parsedData?.header_map?.["Charge By Service"]?.module_features || []);
            const createModalData_ = parsedData?.header_map?.["Charge By Service"]?.pop_up || []

            setcreateModalData(createModalData_)
            setPagination(parsedData?.pages || {});
            setTableData(parsedData?.data?.charge_by_service || []);

          }


          // Defer heavy state updates to allow the UI to remain responsive
          // setTimeout(() => {
          //   setTableData(parsedData?.inventory_data || []);
          // }, 0);
        }, 0);
        // requestIdleCallback(() => {
        //   setTableData(parsedData?.inventory_data || []);
        //   console.log("table response:", getCurrentDateTime());
        // });
      } else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    if (isOpen) {
      if (activeTab === "1" && !hasFetchedChargeOverview.current) {
        fetchData();
        hasFetchedChargeOverview.current = true;
      }
      else if (activeTab === "2" && !hasFetchedChargeByService.current) {
        fetchChargeByService();
        hasFetchedChargeByService.current = true;
      }
    }
  }, [isOpen, activeTab]);
  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }
  const ExportWithoutSearch = async (key: string) => {

    try {

      const path =
        key === "Charge By Service"
          ? "/charge_by_service_export"
          : "/charge_overview_export";

      const moduleName = key === "Charge By Service"
            ? "Charge By Service"
            : "Charge Overview";
      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Request timed out"));
          }, timeout);

          promise
            .then((res) => {
              clearTimeout(timer);
              resolve(res);
            })
            .catch((err) => {
              clearTimeout(timer);
              reject(err);
            });
        });
      };

      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username,
        path,
        role_name: role,
        bill_id: BillId,
        account_number: popupheading === "Billing" ? "" : accountNumber,
        parent_module: "Billing Platform",
        module_name: moduleName,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        feature_module_name: moduleName,
        main_module_name:"Customer Profiles",
        start_date: getFirstDayOfCurrentMonth(),
        end_date: getLastDayOfCurrentMonth(),
        killbill_flag: "True"
      };

      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000);
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }

      // Wait for 20 seconds before polling
      await new Promise((resolve) => setTimeout(resolve, 20000));

      const export_url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const export_data = {
        ...data,
        path: "/get_export_status",
      };

      const pollExportStatus = async () => {
        try {
          const export_response = await axios.post(export_url, { data: export_data });
          const export_parsedData = JSON.parse(export_response.data.body);

          if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
            const s3Url = export_parsedData?.export_status_data?.url || null;
            if (s3Url) {
              window.location.href = s3Url;
              notification.success({
                message: "Success",
                description: "Successfully exported the  record!",
                style: messageStyle,
                placement: "top",
              });
            } else {
              Modal.error({
                title: "Export Error",
                content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            }
            return true; // Stop polling
          }

          if (export_parsedData?.export_status_data?.status_flag === "Failure") {
            Modal.error({
              title: "Export Error",
              content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
              centered: true,
            });
            return true; // Stop polling
          }
          if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
                      Modal.error({
                        title: "Export Error",
                        content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
                        centered: true,
                      });
                      return true; // Stop polling
                    }

          return false; // Continue polling
        } catch (error) {
          Modal.error({
            title: "Export Error",
            content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
            centered: true,
          });
          return true; // Stop polling
        }
      };

      const startPolling = async () => {
        let isPollingComplete = false;

        while (!isPollingComplete) {
          isPollingComplete = await pollExportStatus();
          if (!isPollingComplete) {
            await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
          }
        }
      };

      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      removeExport(key); // Remove the export from the store
    }
  };

  const handleExport = async (key: string, heading: string) => {

    try {
      addExport(key, heading);

      let parsedData;
      let url;
      let data: any;
      let response;

      if (advancedStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/export_inventory",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name: "inventory_export",
          module_name: "SimManagement Inventory",
          pages: { start: 0, end: 100 },
          partner,
          db_name: selectedDb,
          ...metaData,
          billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
      else if (storedpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/export_inventory",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "inventory_export",
          module_name: "SimManagement Inventory",
          search: "whole",
          pages: { start: 0, end: 100 },
          partner,
          db_name: selectedDb,
          ...metaData,
          billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } else {
        await ExportWithoutSearch(key);
        return;
      }

      if (parsedData.flag) {
        const s3Url = parsedData?.download_url || null;
        if (s3Url) {
          window.location.href = s3Url;
          notification.success({
            message: "Success",
            description: "Successfully exported the  record!",
            style: messageStyle,
            placement: "top",
          });
        } else {
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      } else {
        Modal.error({
          title: "Export Error",
          content: parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      removeExport(key);
    }
  };
  if (!isOpen) return null;
  const messageStyle = {
    fontSize: "14px",
    fontWeight: "normal",
    padding: "16px",
  };

  const handleCancel = () => {
    setHeaders([]) // Clear new field input
    setTableData([])
    onClose();
  };
  const handleTabChange = async (key: any) => {
    // setLoading(true); // Show loader

    // Simulate data fetching delay (replace with actual API call if needed)
    await new Promise((resolve) => setTimeout(resolve, 500));

    setActiveTab(key);
    setLoading(false); // Hide loader
  };
 const totalTaxSum = tableData.reduce((sum: number, row: { tax_amount: any }) => {
  const taxStr = String(row.tax_amount || "").replace(/[$,]/g, ""); // remove $ and commas
  const tax = parseFloat(taxStr);
  return sum + (isNaN(tax) ? 0 : tax);
}, 0);

const totalTaxRounded = Number(totalTaxSum.toFixed(2));

const totalSum = tableData.reduce((sum: number, row: { total: any }) => {
  const total = parseFloat(row.total);
  return sum + (isNaN(total) ? 0 : total);
}, 0);

const totalSumRounded = Number(totalSum.toFixed(2));  
  return (
  <Modal
    open={isOpen}
    onCancel={handleCancel}
    centered
    footer={null}
    width="900px"
    bodyStyle={{
      height: window.innerHeight - 100,
      // display: "flex",
      flexDirection: "column",
    }}
  >
    <Tabs defaultActiveKey="1" activeKey={activeTab} onChange={handleTabChange} className="flex-1 overflow-hidden">
      {/* Charge Overview */}
      <TabPane tab="Charge Overview" key="1">
        {loading ? (
          <div className="flex justify-center items-center" style={{ height: "400px" }}>
            <Spin size="large" />
          </div>
        ) : (
          <div className="flex flex-col h-full">
            <div className="pb-2 flex justify-end">
              {(features.includes("Export-Billing Charge Overview") || features.includes("Export-Charge Overview")) && (
                <button className="save-btn" onClick={() => handleExport("Charge Overview", "Charge Overview")}>
                  <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                  <span>Export</span>
                </button>
              )}
            </div>
  
            {/* Scrollable Content Wrapper */}
            <div className="flex-1 overflow-auto max-h-[calc(80vh-50px)]">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {/* Bill Details */}
                    <div className="border p-4 rounded-lg shadow-md overflow-auto max-h-[calc(80vh-100px)]">
                      <h4 className="font-semibold mb-2">Bill Details</h4>
                      <ul>
                        {(overViewData?.bill_details || overViewData?.usage_details) &&
                          Object.keys({ ...overViewData?.bill_details, ...overViewData?.usage_details }).length > 0 ? (
                          <ul>
                            {(() => {
                                const billDetails = overViewData?.bill_details ?? {};
                                const usageDetails = overViewData?.usage_details ?? {};
                                const allDetails = { ...billDetails, ...usageDetails };

                                const chargeDetails = Array.isArray(allDetails.charge_details) ? allDetails.charge_details : [];
                                const creditDetails = Array.isArray(allDetails.credit_details) ? allDetails.credit_details : [];
                                const recurringDetails = Array.isArray(allDetails.recurring_charge_details) ? allDetails.recurring_charge_details : [];
                                const totalCharges = Number(allDetails["Total Charges"] ?? 0);
                                const totalCredits = Number(allDetails["Total Credits"] ?? 0);
                                const totalRecurringCharges = Number(allDetails["Total Recurring Charges"] ?? 0);
                                const totalTaxes = Number(allDetails["Total Taxes"] ?? 0);

                              return (
                                <>
                                  {/* Charge Details Section */}
                                  {chargeDetails?.map((charge, index) => (
                                    charge ? (
                                      <li key={index} className="flex justify-between border-b py-2">
                                        <span className="font-medium">{charge.charge_type}</span>
                                        <span className="font-medium">${Number(charge.charge_amount).toFixed(2)}</span>
                                      </li>
                                    ) : null
                                  ))}


                                  {/* Total Charges */}
                                  <li className="flex justify-between border-t py-2 font-bold">
                                    <span>Total Charges</span>
                                    <span>${Number(totalCharges).toFixed(2)}</span>
                                  </li>

                                  {/* Credit Details Section */}
                                  {creditDetails.map((credit, index) => (
                                    <li key={index} className="flex justify-between border-b py-2">
                                      <span>{credit?.charge_type ?? 'N/A'}</span>
                                      <span className="font-medium">
                                        (${Number(credit?.charge_amount ?? 0).toFixed(2)})
                                      </span>
                                    </li>
                                  ))}


                                  {/* Total Credits */}
                                  <li className="flex justify-between border-t py-2 font-bold">
                                    <span>Total Credits</span>
                                    <span>(${Number(totalCredits).toFixed(2)})</span>
                                  </li>
                                  {/* Recurring charges */}
                                  {recurringDetails.map((credit, index) => (
                                    <li key={index} className="flex justify-between border-b py-2">
                                      <span>{credit?.charge_type ?? 'N/A'}</span>
                                      <span className="font-medium">
                                        ${Number(credit?.charge_amount ?? 0).toFixed(2)}
                                      </span>
                                    </li>
                                  ))}


                                  {/* Total Credits */}
                                  <li className="flex justify-between border-t py-2 font-bold">
                                    <span>Total Recurring Charges</span>
                                    <span>${Number(totalRecurringCharges).toFixed(2)}</span>
                                  </li>
                                  {/* Total Taxes */}
                                  <li className="flex justify-between border-t py-2 font-bold">
                                    <span>Total Taxes</span>
                                    <span>${Number(totalTaxes).toFixed(2)}</span>
                                  </li>
                                </>
                              );
                            })()}
                          </ul>
                        ) : (
                          <p >There is no usage on this bill</p>
                        )}
                      </ul>
                    </div>

                    {/* Usage Details */}
                    <div className="border p-4 rounded-lg shadow-md overflow-auto max-h-[calc(80vh-100px)]">
                      <h4 className="font-semibold mb-2">Usage Details</h4>
                      <ul>
                        {Array.isArray(overViewData?.usage_details?.usage_info) && overViewData.usage_details.usage_info.length > 0 ? (
                          <div className="overflow-x-auto">
                            <div style={{ minWidth: 500 }}>
                              {/* Header Row */}
                              <div className="grid grid-cols-5 border-b py-2 font-semibold text-gray-800 text-left">
                                <span>Service ID</span>
                                <span>Bill Range</span>
                                <span>Type</span>
                                <span>Cost</span>
                                <span>Tax</span>
                              </div>
                              {/* Data Rows */}
                              <ul>
                                {overViewData.usage_details.usage_info.map((item, index) => (
                                  <li
                                    key={index}
                                    className="grid grid-cols-5 border-b py-2 text-sm text-left"
                                  >
                                    <span>{item.service_id}</span>
                                    <span className="whitespace-pre-line pr-4">{item.bill_range.split(' - ').join('\n')}</span>
                                    <span>{item.type}</span>
                                    <span>${Number(item.cost)}</span>
                                    <span>${Number(item.tax)}</span>
                                  </li>
                                ))}
                              </ul>
                              {/* Total Charges & Taxes Row */}
                              <div className="grid grid-cols-5 py-2 border-t border-black text-sm font-bold text-left text-gray-900">
                                <span>Total</span>
                                <span></span>
                                <span></span>
                                <span>${overViewData.usage_details.total_usage}</span>
                                <span>${overViewData.usage_details.total_tax}</span>
                              </div>
                            </div>
                          </div>
                        ) : (
                          <p >There is no usage on this bill</p>
                        )}


                      </ul>
                    </div>
                  </div>

            </div>
          </div>
        )}
      </TabPane>
  
      {/* Charge By Service */}
      <TabPane tab="Charges By Service" key="2">
  <div className="flex flex-col h-full mb-4">
    <div className="pb-2 flex justify-end">
      {(features2.includes("Export-Billing Charge By Service") || features2.includes("Export-Charge By Service")) && (
        <button className="save-btn" onClick={() => handleExport("Charge By Service", "Charge By Service")}>
          <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
          <span>Export</span>
        </button>
      )}
    </div>

    <div className="flex-1 overflow-auto">
      {loading ? (
        <div className="flex justify-center items-center" style={{ height: "350px" }}>
          <Spin size="large" />
        </div>
      ) : (
        <>
          <KillbillTableComponent
            headers={headers}
            headerMap={headerMap}
            initialData={tableData}
            searchQuery={searchTerm}
            visibleColumns={visibleColumns}
            itemsPerPage={100}
            allowedActions={allowedActions}
            popupHeading={"Charge By Service"}
            pagination={pagination}
            advancedFilters={filteredData}
            createModalData={createModalData}
            generalFields={generalFields}
            height={300}
          />
                    <div className="flex flex-col items-end">
                      <div className="flex justify-between w-[100px]">
                        <p><strong>Total:</strong></p>
                        <p>{totalSumRounded !== 0 ? `$${totalSumRounded}` : totalSumRounded}</p>
                      </div>
                      <div className="flex justify-between w-[120px]">
                        <p><strong>Total Taxes:</strong></p>
                        <p>{totalTaxRounded !== 0 ? `$${totalTaxRounded}` : totalTaxRounded}</p>
                      </div>
                    </div>

        </>
      )}
    </div>
  </div>
</TabPane>
    </Tabs>
  </Modal>
  

  );

};


export default ChargesPopup;

