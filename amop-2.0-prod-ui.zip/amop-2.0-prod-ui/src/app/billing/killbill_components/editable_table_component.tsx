"use client";
import React, { useEffect, useRef, useState } from "react";
import { StatusCellRenderer } from "@/components/data-grid-cell-renderers/status-cell-renderer";
import { StatusHistoryCellRenderer } from "@/app/components/inventoryTableComponent/data-grid-cell-renderers/status-history-cell-renderer";
import { X } from "lucide-react";
import { Modal, Checkbox, notification, Spin, Tooltip, Button,DatePicker , Input} from "antd";
import dayjs from 'dayjs';
const { RangePicker } = DatePicker;
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import {
  ArrowUpOutlined,
  ArrowDownOutlined
} from "@ant-design/icons";
import StatusIndicator from "@/app/components/TableComponent/data-grid-cell-renderers/status-indicator";
import Select from 'react-select';
import { useAuth } from "@/app/components/auth_context";
import BillingPagination from "./pagination__";
import { DropdownStyles } from "@/app/components/css/dropdown";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { useCustomerProfileStore } from "../killbill_stores/customer_profile_store";

interface EditableTableComponentProps {
  headers: string[];
  initialData: { [key: string]: any }[];
  searchQuery?: string;
  visibleColumns: string[];
  itemsPerPage: number;
  
  popupHeading: string;
  advancedFilters?: any;
  modalData?: any[];
  createModalData?: any;
  generalFields?: any;
  isSelectRowVisible?: boolean;
  headerMap?: any;
  pagination: any;
  height?: any;
  setUpdatedTableData?: any;
  setSelectedRowData?: any;
  setEffectiveDateDisable?:any;
  row?: any;
  highlightedRowId?:any;
}

const colorMap = {
  Activated: "#12E620",
  Active: "#12E620",
  Deactivated: "#E61224",
  "Activation ready": "#E6CA15",
  "Pending activation": "#52A6E6",
  Retired: "#7D7D7D",
  // Add more statuses and colors as needed
};
const messageStyle = {
  fontSize: "14px",
  fontWeight: "bold",
  padding: "16px",
};
const EditableTableComponent: React.FC<EditableTableComponentProps> = ({
  headers,
  initialData,
  searchQuery,
  visibleColumns,
  itemsPerPage,
  popupHeading,
  createModalData,
  modalData,
  generalFields,
  advancedFilters,
  isSelectRowVisible = true,
  headerMap,
  pagination,
  height,
  setUpdatedTableData,
  setSelectedRowData,
  setEffectiveDateDisable,row,
  highlightedRowId
}) => {
  // console.log("InitialData",initialData)
  // console.log("effectiveDateDisable....",setEffectiveDateDisable);
  const [rowData, setRowData] = useState<{ [key: string]: any }[]>(initialData);
  const [currentPage, setCurrentPage] = useState(1);
  const isFirstRender = useRef(true);
  const [sortConfig, setSortConfig] = useState<{ key: string; direction: "ascending" | "descending"; } | null>(null);
  const [editRowIndex, setEditRowIndex] = useState<number | null>(null);
  const [isEditable, setIsEditable] = useState(false);
  const [editModalOpen, setEditModalOpen] = useState(false);

  const [viewportHeight, setViewportHeight] = useState(window.innerHeight);

  const [totalPages, setTotalPages] = useState(1);
  const [lastPageWithData, setLastPageWithData] = useState(1);
  
  const { bulkRow, features: moduleFeatures } = useFeatureStore();
  const [loading, setLoading] = useState(false);
  // const [searchData, advancedSearchData] = useState<any>();
  const [isAllSelected, setIsAllSelected] = useState(false); // State to track if all rows are selected
  const [selectedRows, setSelectedRows] = useState<number[]>([]); 
  const [isSmallScreen, setIsSmallScreen] = useState(false);
  const {
    username,
    tenantNames,
    role,
    partner,
    selectedPartnerModule,
    Environment,
    tabledata,
    storedpagination,
    advancedStoredpagination,
    combineAdnvaceStoredpagination,
    token,
    selectedDb,
    metaData,
    selectedBillingDb,
    sessionId,
    serviceProviderList,
    selectedServiceProvider,
    setAdvancedStoredPagination,
    setStoredPagination,
    setCombineAdnvaceStoredpagination,
    firstLastName
  } = useAuth();
    const accountNumber = useCustomerProfileStore((state) => state.accountNumber);

  // To display the initial data
  const [selectedDates, setSelectedDates] = useState<Record<
  number,
  { completed_date: string | null; canceled_date: string | null }
>>({});

 useEffect(() => {
         const checkScreenSize = () => {
             setIsSmallScreen(window.innerWidth < 700);
         };
         
         // Initial check
         checkScreenSize();
         
         // Add event listener for window resize
         window.addEventListener('resize', checkScreenSize);
         
         // Clean up
         return () => window.removeEventListener('resize', checkScreenSize);
     }, []);
  // console.log(popupHeading,tabledata,"Show popup heading")
  useEffect(() => {
    if(popupHeading==="Customer Edit Service Packages" || popupHeading === "Collections Steps"){
      setRowData(initialData);
    }
    else if(popupHeading ==="Products"){
      setRowData(initialData);
    }
    else if(popupHeading ==="Customer Products"){
      setRowData(initialData);
    }
    else if (popupHeading==="Deposits"){
      setRowData(initialData);

    }
    else if (popupHeading === "Services") {
      // Select all rows by default when popupHeading is "Service Product"
      const allRowIds = initialData.map(row => row.id);
      setSelectedRows(allRowIds);
      setIsAllSelected(true); // Set all selected to true
      if (typeof setSelectedRowData === 'function') {
        setSelectedRowData(allRowIds);
      }
    }
    
    else{
      const newRowData = tabledata.length > 0 ? tabledata : initialData;
      console.log("rowdata loading...............")
      console.log("generalFields loading...............",generalFields)

      setRowData(newRowData);
    }
    
  }, [initialData, tabledata]);
  
    useEffect(() => {
      setCurrentPage(1);
      }, [tabledata,sortConfig]);
  
    useEffect(() => {
      setCurrentPage(1);
    }, [totalPages]);
  
    //To manage the pagination routes
    useEffect(() => {
      let pagination_;
      if(combineAdnvaceStoredpagination){
        pagination_=combineAdnvaceStoredpagination
  
      }
      else if (advancedStoredpagination && !storedpagination) {
        pagination_=advancedStoredpagination
  
      }
      else if (storedpagination && !advancedStoredpagination) {
        pagination_=storedpagination
  
      }
    else{
        pagination_=pagination
      }
      // const pagination_ =combineAdnvaceStoredpagination? storedpagination ? storedpagination : advancedStoredpagination ? advancedStoredpagination : pagination
      // const pagination_ = pagination;
      const start = pagination_?.start || 1;
      const total = pagination_?.total || 1;
      const end = pagination_?.end || 1;
      const lastPageWithData_ = Math.floor(end / itemsPerPage);
      const totalPages_ = Math.ceil(total / itemsPerPage);
      const currentPage_ = Math.floor(start / itemsPerPage) + 1;
      setTotalPages(totalPages_);
      // setCurrentPage(currentPage_);
      setLastPageWithData(lastPageWithData_);
    }, [tabledata, initialData, pagination, itemsPerPage, currentPage, storedpagination, advancedStoredpagination, combineAdnvaceStoredpagination , sortConfig]);
    useEffect(() => {
        if (!isFirstRender.current) {
          
            updatePaginator();  
         }  else { isFirstRender.current = false }
      }, [currentPage, sortConfig]);
  useEffect(() => {
    const handleResize = () => {
      setViewportHeight(window.innerHeight);
    };

    // Add event listener for window resize
    window.addEventListener("resize", handleResize);

    // Cleanup event listener on component unmount
    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);
   const updatePaginator = async () => {
      // console.log(serviceShowActive,"Show Service Active")
      let start_ = Math.floor((currentPage - 1) * itemsPerPage);
      let end_ = Math.floor((currentPage - 1) * itemsPerPage + 100);
      let taxes_end_ = Math.floor((currentPage - 1) * itemsPerPage + 15);

      try {
        const colSortKey=sortConfig?sortConfig.key:""
        const colSortDirection=sortConfig?sortConfig.direction:""
        const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";
        const tenant_id_ = localStorage.getItem("tenant_id") || "0";
  
        // if (currentPage !== 1) {
        setLoading(true);
        // }
        if (popupHeading === "Deposits") {
          try{
            const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
  
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/customer_deposit_pop_up",
              role_name: role,
              parent_module: "Billing Platform",
              module_name: "Basic Details Deposits",
              table_name:"customer_profiles",
              mod_pages: {
                start: start_,
                end: end_,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              access_token: token,
              db_name: 'billing_platform',
              ...metaData,
              billing_db_name: selectedBillingDb,
              tenant_id:tenant_id_,
              main_module_name: "Customer Profiles",
              sessionID: sessionId,
            ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
                : {}),
            };
  
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            const DepositsData = parsedData?.data?.basic_details_deposits || [];
            setRowData(DepositsData);
          }
          catch (err) {
            // console.error("Error fetching data:", err);
            Modal.error({
              title: "Data Fetch Error",
              content:
                err instanceof Error
                  ? err.message
                  : "An unexpected error occurred while fetching data. Please try again.",
              centered: true,
            });
          } finally {
            // setLoading(false);
          }
        }
        if (popupHeading === "Taxes") {
          try{
            const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
            const type = row?.type || ""
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/get_taxes_unposted",
              account_number: accountNumber,
              role_name: role,
              row_id: row?.row_id || row?.id || "",
              parent_module: "Billing Platform",
              module_name: "Billing and Collections Taxes",
              // table_name: type&& type==="Bill"?"customer_bills":"customer_charges",
              table_name: type && (type==="Bill" || type==="Reverse Bill")?"customer_bills":"customer_charges",
              mod_pages: {
                start: start_,
                end: taxes_end_,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
billing_db_name: selectedBillingDb,
              tenant_id:tenant_id_,
              main_module_name: "Billing and Collections Taxes",
              sessionID: sessionId,
            ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
                : {}),
            };
  
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            const DepositsData = parsedData?.data?.billing_collections_taxes || [];
            setRowData(DepositsData);
          }
          catch (err) {
            // console.error("Error fetching data:", err);
            Modal.error({
              title: "Data Fetch Error",
              content:
                err instanceof Error
                  ? err.message
                  : "An unexpected error occurred while fetching data. Please try again.",
              centered: true,
            });
          } finally {
            // setLoading(false);
          }
        }
        if (popupHeading === "Collections Steps") {
          try{
            const url = ENV_ROUTES.BP_REPORTS;
            const type = row?.type 
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
               path: "/collections_steps_list_view",
              account_number: accountNumber,
              role_name: role,
              row_id: row?.row_id || "",
              changed_data: row || "",
              parent_module: "Billing Platform",
              module_name: "Collections Step Reports",
              feature_module_name: "Collections Steps",
              main_module_name: "Collections",
              table_name: "collection_steps",
              mod_pages: {
                start: start_,
                end: taxes_end_,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
billing_db_name: selectedBillingDb,
              tenant_id:tenant_id_,
              sessionID: sessionId,
            ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
                : {}),
            };
  
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            const CollectionsData = parsedData?.data?.collection_steps || [];
            setRowData(CollectionsData);
          }
          catch (err) {
            // console.error("Error fetching data:", err);
            Modal.error({
              title: "Data Fetch Error",
              content:
                err instanceof Error
                  ? err.message
                  : "An unexpected error occurred while fetching data. Please try again.",
              centered: true,
            });
          } finally {
            // setLoading(false);
          }
        }
        
      } catch (err) {
        console.error("Error fetching data:", err);
      } finally {
        setLoading(false);
      }
      // }
    };
  const handleSort = (key: string) => {
    let direction: "ascending" | "descending" = "ascending";
    if (
      sortConfig &&
      sortConfig.key === key &&
      sortConfig.direction === "ascending"
    ) {
      direction = "descending";
    }
    setCurrentPage(1)
    setSortConfig({ key, direction });
  };


  const handleCloseModal = () => {
    setEditModalOpen(false);



  }
  const handleSaveModal = (
    updatedRow: { [key: string]: any },
    tableData: any
  ) => {
    if (editRowIndex !== null) {
      // const updatedData = [...rowData];
      // updatedData[editRowIndex] = updatedRow;
      // setRowData(updatedData);
      handleCloseModal();
      // setRowData(tableData)
    }
  };

 const handleCellChange = (rowIndex: any, header: any, value: any) => {
  const updatedData = [...rowData];
  
  let newValue = value || "";
  if (header === "amount" || header === "refund_amount") {
    const decimalRegex = /^\d*\.?\d{0,2}$/;
    if (!decimalRegex.test(value)) return;
  }
  if (header === "amount" && !/^\d*\.?\d*$/.test(value)) {
    Modal.error({
      title: "Invalid Input",
      content: "Amount must contain only numbers.",
      centered: true,
    });
    return;
  }
  
  if (header === "itemize" || header === "tax_incl" || header === "group" || header === "prorate"){
    newValue = value || false;
  }

  if ((header === "refund_amount" || header === "balance_left") && !/^\d*\.?\d*$/.test(newValue)) {
    Modal.error({
      title: "Invalid Input",
      content: "Balance and Refund Amount must contain only numbers.",
      centered: true,
    });
    return;
  }

  updatedData[rowIndex] = { ...updatedData[rowIndex], [header]: newValue };

  if (header === "refund_amount") {
    const amount = parseFloat(updatedData[rowIndex].balance_left || "0");
    const refundAmount = parseFloat(newValue || "0");

    if (refundAmount > amount) {
      if (amount === 0){
        Modal.error({
          title: "Validation Error",
          content: "Please Deposit amount Before making a Refund",
          centered: true,
        });
      }else{
        Modal.error({
          title: "Validation Error",
          content: "Refund Amount cannot be greater than the Balance Left.",
          centered: true,
        });
      }
      updatedData[rowIndex][header] = "";
    }
  }
  
  if (header === "rate" || header === "quantity") {
    const rate = parseFloat(updatedData[rowIndex].rate || "0");
    const quantity = parseFloat(updatedData[rowIndex].quantity || "0");
    const totalRate = rate * quantity;
    updatedData[rowIndex].total_rate = totalRate;
  }

  const filteredUpdatedData = updatedData.filter((row) => row.isNew !== false);

  setRowData(updatedData);
  if (popupHeading === "Deposits"){
    setUpdatedTableData(updatedData);
  }else{
    setUpdatedTableData(updatedData);
  }
  
if (popupHeading === "Disconnect Service") {
  console.log("setSelectedRowData called for Disconnect Service", updatedData);
  console.log("Currently selected rows:", selectedRows);

  const mappedData = updatedData.reduce((acc: Record<string, string>, row: any) => {
    if (!selectedRows.map(String).includes(String(row.id))) {
      return acc;
    }

    const rawDate = row.manual_disconnect_date;
    let formattedDate = "";

    if (rawDate) {
      // ✅ Case 1: Dayjs instance
      if (dayjs.isDayjs(rawDate)) {
        formattedDate = rawDate.isValid() ? rawDate.format("YYYY-MM-DD") : "";
      }

      // ✅ Case 2: Native Date
      else if (rawDate instanceof Date) {
        const parsed = dayjs(rawDate);
        formattedDate = parsed.isValid() ? parsed.format("YYYY-MM-DD") : "";
      }

      // ✅ Case 3: String (ISO or known formats)
      else if (typeof rawDate === "string") {
        const parsed = dayjs(rawDate, [
          "MM-DD-YYYY HH:mm:ss",
          "MM-DD-YYYY",
          "MM-DD-YY",
          "YYYY-MM-DD",
        ]);
        formattedDate = parsed.isValid() ? parsed.format("YYYY-MM-DD") : "";
      }

      // ✅ Case 4: Object with $d (Dayjs-like)
      else if (rawDate && typeof rawDate === "object" && "$d" in rawDate) {
        const parsed = dayjs((rawDate as any).$d);
        formattedDate = parsed.isValid() ? parsed.format("YYYY-MM-DD") : "";
      }
    }
    acc[row.id] = formattedDate || "";
    if (!formattedDate) {
      console.warn(`⚠️ manual_disconnect_date cleared or invalid for row ${row.id}:`, rawDate);
    }

    return acc;
  }, {});

  console.log("Mapped Data (only selected rows):", mappedData);
  setSelectedRowData(mappedData);
}




  console.log("Updated Data", updatedData);
};
  const paginationComponent = (
    <BillingPagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
            moduleName={popupHeading} />
);

 
  const getStateOptions = () => {
    const states = [
      "AK", "AL", "AR", "AZ", "CA", "CO", "CT", "DC", "DE", "FL",
      "GA", "HI", "IA", "ID", "IL", "IN", "KS", "KY", "LA", "MA",
      "MD", "ME", "MI", "MN", "MO", "MS", "MT", "NC", "ND", "NE",
      "NH", "NJ", "NM", "NV", "NY", "OH", "OK", "OR", "PA", "RI",
      "SC", "SD", "TN", "TX", "UT", "VA", "VT", "WA", "WI", "WV", "WY"
    ];

    return [
      { label: "All", value: "" },
      ...states.map((state) => ({ label: state, value: state })),
    ];
  };
  const currencyHeaders = ["Cost","Buy Rate","Rate","Credit","Amount","Balance Left","Refund Amount","Total Rate"];
  const TaxesCurrencyHeaders = ["Amount" , "Basis"]
  const TaxesPercentageHeaders = ["Basis Rate","Rate"]
  const NoneditableHeaders = ["display_name","rate_type","id","created_date","balance_left","hold_months","start_date","months_left","modified_by","reason","package_name","total_rate","service_type","service_provider_name","primary_field"]
  if(popupHeading==="Services"){
    NoneditableHeaders.push("description")
  }
  const deleteDeposit = (index: number) => {
    const updatedData = rowData.filter((_, i) => i !== index);
    // console.log("updatedData",updatedData)
    setRowData(updatedData);
    setUpdatedTableData(updatedData); 
  };
  
  useEffect(() => {
  // Clear selected row data when no rows are selected
  if (selectedRows.length === 0 && popupHeading === "Disconnect Service") {
    if (typeof setSelectedRowData === "function") {
      setSelectedRowData({});
    }
  }
}, [selectedRows, popupHeading, setSelectedRowData]);
const handleSelectCheckboxChange = (
  event: React.ChangeEvent<HTMLInputElement>,
  row: any
) => {
  const isChecked = event.target.checked;

  setSelectedRows((prevSelected) => {
    let updatedSelectedRows;

    updatedSelectedRows = isChecked
      ? [...prevSelected, row.id] // Add row ID if checked
      : prevSelected.filter((id) => id !== row.id); // Remove row ID if unchecked

    // Update the "Select All" state
    setIsAllSelected(updatedSelectedRows.length === initialData.length);

    if (typeof setSelectedRowData === "function") {
      if (popupHeading === "Disconnect Service") {
        // Create { service_id: date } mapping
        const selectedData: Record<string, string> = {};
        updatedSelectedRows.forEach((id) => {
          const matchedRow = rowData.find((item) => item.id === id);
          if (matchedRow) {
            selectedData[matchedRow.id] = matchedRow.manual_disconnect_date || "";
          }
        });
        setSelectedRowData(selectedData);
      } else {
        setSelectedRowData(updatedSelectedRows);
      }
    } else {
      console.error("setSelectedRowData is not a function");
    }

    return updatedSelectedRows;
  });
};

const handleSelectAllCheckboxChange = (event: React.ChangeEvent<HTMLInputElement>) => {
  const isChecked = event.target.checked;

  const updatedSelectedRows = isChecked ? rowData.map((row) => row.id) : [];

  setSelectedRows(updatedSelectedRows);
  setIsAllSelected(isChecked);

  if (typeof setSelectedRowData === "function") {
    if (popupHeading === "Disconnect Service") {
  const selectedData: Record<string, string> = {};

  if (isChecked) {
    rowData.forEach((row) => {
      console.log("row",row)
      const date = row.manual_disconnect_date;
      let formattedDate = "";

      if (date) {
        // ✅ Case 1: Proper Dayjs object
        if (dayjs.isDayjs(date)) {
          formattedDate = date.isValid() ? date.format("YYYY-MM-DD") : "";
        }

        // ✅ Case 2: Native JS Date
        else if (date instanceof Date) {
          const parsed = dayjs(date);
          formattedDate = parsed.isValid() ? parsed.format("YYYY-MM-DD") : "";
        }

        // ✅ Case 3: Plain string (ISO or known formats)
        else if (typeof date === "string") {
          const parsed = dayjs(date, [
            "MM-DD-YYYY HH:mm:ss",
            "MM-DD-YYYY",
            "MM-DD-YY",
            "YYYY-MM-DD",
          ]);
          formattedDate = parsed.isValid() ? parsed.format("YYYY-MM-DD") : "";
        }

        // ✅ Case 4: Object with `$d` (Dayjs-like)
        else if (typeof date === "object" && "$d" in date) {
          const parsed = dayjs((date as any).$d);
          formattedDate = parsed.isValid() ? parsed.format("YYYY-MM-DD") : "";
        }
      }

      selectedData[row.id] = formattedDate || ""; // Always include
    });

    console.log("✅ Select All mapped data:", selectedData);
    setSelectedRowData(selectedData);
  } else {
    setSelectedRowData({});
  }
}


  } else {
    console.error("setSelectedRowData is not a function");
  }
};

  
  const handleDateChange = (rowIndex: number, header: string, dateString: string | string[]) => {
    setSelectedDates((prev) => ({
      ...prev,
      [rowIndex]: {
        ...(prev[rowIndex] || {}),
        [header]: dateString || null,
      },
    }));
  
    handleCellChange(rowIndex, header, dateString);
  };
  
  
  const isDisabled = (header: string, rowIndex: number) => {
    const rowDates = selectedDates[rowIndex] || {};
  
    if (header === "completed_date" && rowDates.canceled_date) {
      return true;
    }
    if (header === "canceled_date" && rowDates.completed_date) {
      return true;
    }
    return false;
  };
  
   if (loading) {
    return (
      <div className="flex justify-center items-center h-[500px]">
        <Spin size="large" />
      </div>
    );
  }
  return (
    <div>
       {isSmallScreen && visibleColumns.length > 0 && (
        <div className="flex justify-end mb-2 mr-2">
          {paginationComponent}
        </div>
      )}
      <div className="overflow-x-auto">
        <div className="overflow-x-auto overflow-y-auto" style={{
          height:
           ( popupHeading === "Disconnect Service" || popupHeading === "Transfer Service")
              ? "auto" // ✅ auto height for Disconnect Service popup
              : `${viewportHeight - height}px`,
          minHeight: "270px",
        }}>
          <table className="table-auto w-full">
            <thead className="sticky top-0 bg-gray-200 z-10 disconnect-table-header">
              <tr>
                {(popupHeading === "Services" || popupHeading === "Disconnect Service" ) && (
                  <th className="px-4 py-2 border-b border-gray-300 table-cell">
                    {/* Checkbox for selecting all rows */}
                    <input
                      type="checkbox"
                      className="cursor-pointer"
                      checked={isAllSelected} // Bind header checkbox to isAllSelected state
                      onChange={handleSelectAllCheckboxChange}
                    />
                  </th>
                )}
                {headers.map((header) => (
                  headerMap && headerMap[header] && visibleColumns.includes(header) && (
                    <th
                      key={header}
                      className={`px-6 py-3 border-b border-gray-300 text-left font-semibold table-header sticky top-0 
                        ${sortConfig && sortConfig.key === header ? "text-blue-600 active-table-header" : ""
                        }`}                      
                      onClick={() => handleSort(header)}
                      style={{ cursor: "pointer" }}
                    >
                      {headerMap?.[header]?.[0] || header}

                      {sortConfig && sortConfig.key === header ? (
                        sortConfig.direction === "ascending" ? (
                          <ArrowUpOutlined className="sorting-arrow"  style={{ marginLeft: 8, color: "#2563EB" }} />
                        ) : (
                          <ArrowDownOutlined className="sorting-arrow"  style={{ marginLeft: 8, color: "#2563EB" }} />
                        )
                      ) : (
                        <ArrowUpOutlined style={{ marginLeft: 8, opacity: 0.5 }}/>
                      )
                      }
                    </th>
                  )
                ))}

              </tr>
            </thead>
            <tbody>
              {rowData.map((row, rowIndex) => (
                <tr
                  key={row.id || rowIndex}
                  className={`
                  ${rowIndex % 2 === 0 ? "bg-gray-50 even-table-row" : ""}
                  ${highlightedRowId && (row.id?.toString() === highlightedRowId || row.step_id?.toString() === highlightedRowId)
                                ? "bg-yellow-200 border-yellow-400 border-2" : ""}
                `}
                  style={{
                    backgroundColor: highlightedRowId && (row.id === highlightedRowId || row.step_id?.toString() === highlightedRowId)
                      ? "#fef3c7" : undefined,
                    fontWeight: highlightedRowId && (row.id === highlightedRowId || row.step_id?.toString() === highlightedRowId)
                      ? "bold" : "normal"
                  }}
                >
                {/* <tr key={rowIndex} className={rowIndex % 2 === 0 ? "bg-gray-50 even-table-row" : ""}  > */}
                  
                  {(popupHeading === "Services" || popupHeading === "Disconnect Service" ) && (
                      <td className="px-4 py-2 border-b border-gray-300 table-cell">
                        <input
                          type="checkbox"
                          className="cursor-pointer"
                          checked={selectedRows.includes(row.id)} // Check if the row is selected
                          onChange={(e) => handleSelectCheckboxChange(e, row)}
                        />
                      </td>
                    )}
                  {headers.map(
                    (header, columnIndex) =>
                      visibleColumns.includes(header) &&
                      headerMap[header] && (
                        <><td
                          key={columnIndex}
                          className="px-1 py-2 border-b border-gray-300 table-cell"
                        >
                          {header === "state" || header === "type" ? (
                            // Render dropdown for "State" and "Type"
                            <Select
                              value={{
                                label: row[header] || "All",
                                value: row[header] || "",
                              }}
                              onChange={(selectedOption: any) => handleCellChange(rowIndex, header, selectedOption?.value || "")}
                              options={header === "state"
                                ? getStateOptions()
                                : [
                                  { label: "All", value: "" },
                                  { label: "New", value: "New" },
                                  { label: "Conversion", value: "Conversion" },
                                ]}
                              className="min-w-[100px]"
                              styles={{
                                ...DropdownStyles,
                                menuPortal: (base) => ({ ...base, zIndex: 9999 }), // ensure on top
                              }}
                              menuPortalTarget={document.body} // keep if needed
                              menuPlacement="auto"             // allows top/bottom flip
                              menuPosition="absolute" />

                          ) : header === "itemize" || header === "tax_incl" || header === "group" || header === "prorate" ? (
                            // Render checkbox for "Itemize", "Tax Incl", and "Group"
                              <Checkbox
                                checked={!!row[header]}
                                onChange={(e) => handleCellChange(rowIndex, header, e.target.checked)}
                                className="checkbox ml-4"
                                disabled={
                                  (popupHeading === "Services" && header === "prorate") ||
                                  (popupHeading === "Products" && header === "prorate" &&
                                    row["product_type_code"]?.toLowerCase().includes("onetime"))
                                }
                              />

                          ) : ((popupHeading === "Deposits"|| popupHeading === "Collection") && (NoneditableHeaders.includes(header) || !row.isNew) && header !== "refund_amount") ? (
                            <Tooltip title={`${row[header] ?? ""}`}
                              placement="topLeft"
                              overlayStyle={{ whiteSpace: 'normal', maxWidth: '60vw', wordWrap: 'break-word' }}
                              getPopupContainer={(triggerNode) => (triggerNode.parentNode as HTMLElement) || document.body}>
                              <span>{row[header]}</span>
                            </Tooltip>
                          ) : NoneditableHeaders.includes(header) ? (
                            <Tooltip title={`${row[header] ?? ""}`}
                              placement="topLeft"
                              overlayStyle={{ whiteSpace: 'normal', maxWidth: '60vw', wordWrap: 'break-word' }}
                              getPopupContainer={(triggerNode) => (triggerNode.parentNode as HTMLElement) || document.body}>
                              <span>{row[header]}</span>
                            </Tooltip>
                                ) : ((popupHeading === "Collection" && (header === "completed_date" || header === "canceled_date")) || (popupHeading === "Services" && (header === "activation_date" || header === "deactivation_date")) || (popupHeading === "Disconnect Service") && header === "manual_disconnect_date") ? (
                                  // <Tooltip
                                  //   title={`${row[header] ?? ""}`}
                                  //   placement="topLeft"
                                  //   overlayStyle={{ whiteSpace: 'normal', maxWidth: '60vw', wordWrap: 'break-word' }}
                                  //   getPopupContainer={(triggerNode) => (triggerNode.parentNode as HTMLElement) || document.body}
                                  // >
                                    <DatePicker
                                      value={row[header] ? dayjs(row[header]) : null}
                                      onChange={(date, dateString) => handleDateChange(rowIndex, header, dateString)}
                                      className="input !max-h-[33px] min-w-[110px]"
                                      disabled={isDisabled(header, rowIndex) || (popupHeading === "Disconnect Service" && !selectedRows.includes(row.id))}
                                      format="MM-DD-YY"
                                      disabledDate={(current) => {
                                        const today = dayjs().startOf('day');
                                        // Disable dates before setEffectiveDateDisable when popupHeading is "Services" and header is "activation_date"
                                        if (popupHeading === "Services" && header === "activation_date" && setEffectiveDateDisable) {
                                          const effectiveDate = dayjs(setEffectiveDateDisable, 'MM-DD-YYYY HH:mm:ss');
                                          return current && current < effectiveDate.startOf('day');
                                        }
                                        if (popupHeading === "Services" && header === "deactivation_date") {
                                          const activationDateStr = row["activation_date"];
                                          if (activationDateStr) {
                                            const activationDate = dayjs(activationDateStr).startOf('day');
                                            return current && current < activationDate;
                                          }
                                          return current && current < today; // fallback if activation date not selected yet
                                        }
                                        if (popupHeading === "Disconnect Service") {
                                          return current && current < today;
                                        }
                                        return false; // Allow all dates if conditions are not met
                                      }}
                                    />
                                  // </Tooltip>

                          ) :(popupHeading === "Collection" && (header === "step_description" )) ? (
                            <Tooltip
                              title={`${row[header] ?? ""}`}
                              placement="topLeft"
                              overlayStyle={{ whiteSpace: 'normal', maxWidth: '60vw', wordWrap: 'break-word' }}
                              getPopupContainer={(triggerNode) => (triggerNode.parentNode as HTMLElement) || document.body}
                            >
                              <Select
                            value={row[header] ? { label: row[header], value: row[header] } : null}
                            onChange={(selectedOption) => handleCellChange(rowIndex, header, selectedOption?.value || '')}
                            placeholder="Select Description"
                            options={generalFields?.dropdown?.["step_description"]
                              ? generalFields.dropdown["step_description"].map((item:any) => ({
                                  label: item,    // Use item as label
                                  value: item     // Use item as value
                              }))
                              : []}
                            isClearable
                              className="min-w-[175px]"
                              styles={DropdownStyles}
                              menuPortalTarget={document.body}
                              menuPlacement="auto"
                              menuPosition="fixed"
                          />
                            </Tooltip>

                          ) : (popupHeading === "Taxes" || popupHeading === "Collections Steps") ?(
                            <Tooltip title={`${row[header] ?? ""}`}
                              placement="topLeft"
                              overlayStyle={{ whiteSpace: 'normal', maxWidth: '60vw', wordWrap: 'break-word' }}
                              getPopupContainer={(triggerNode) => (triggerNode.parentNode as HTMLElement) || document.body}
                            >
                              <span>
                                {(TaxesCurrencyHeaders.includes(header) && row[header]) ? `$${row[header]}` : (TaxesPercentageHeaders.includes(header) && row[header] )? `${row[header]}%`:row[header]}</span>
                              </Tooltip>

                          ):(
                            // Render input field for other headers
                            <Tooltip title={`${row[header] ?? ""}`}
                              placement="topLeft"
                              overlayStyle={{ whiteSpace: 'normal', maxWidth: '60vw', wordWrap: 'break-word' }}
                              getPopupContainer={(triggerNode) => (triggerNode.parentNode as HTMLElement) || document.body}>
                              <div className="flex items-center">
                                <Input
                                  value={row[header] || ""}
                                  onChange={(e) => handleCellChange(rowIndex, header, e.target.value)}
                                  prefix={currencyHeaders.includes(headerMap[header][0]) ? "$" : undefined}
                                  className="w-full px-2 py-1 bg-transparent overflow-hidden whitespace-nowrap text-ellipsis min-w-[100px] border border-gray-300 rounded-md"
                                />
                              </div>


                            </Tooltip>
                          )}
                        </td>
                        {header === "refund_amount" && row.isNew &&(<td>    
                          <X className="w-5 h-5 text-red-500 cursor-pointer hover:text-red-700" onClick={()=>deleteDeposit(rowIndex)}/>
                          </td>)}</>
                      
                      )
                  )}

                </tr>
                
              ))}
            </tbody>
          </table>
        </div>
      </div>
      {/* {visibleColumns.length > 0 &&
        <div className="flex justify-center mt-5">
          <BillingPagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
            moduleName={popupHeading} />
        </div>
      } */}
      {(!isSmallScreen && visibleColumns.length > 0) && (
                <div className="flex justify-center mt-5">
                    {paginationComponent}
                </div>
            )}
    
    </div>
  );
};

export default EditableTableComponent;


