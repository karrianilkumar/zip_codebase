// import React, { useCallback, useEffect, useState } from "react";
// import { Modal, Spin } from "antd";
// import EditableTableComponent from "../killbill_components/editable_table_component";
// import { ENV_ROUTES } from "@/app/components/routes/route_constants";
// import { useCustomerProfileStore } from "../killbill_stores/customer_profile_store";
// import axios from "axios";
// import { getCurrentDateTime } from "@/app/components/header_constants";
// import { useAuth } from "@/app/components/auth_context";

// interface CollectionsStepModalProps {
//   isOpen: boolean;
//   onClose: () => void;
//   onSave?: () => void;
//   rowData: any; // The row data passed from the table component
// }

// const CollectionsStepModal: React.FC<CollectionsStepModalProps> = ({
//   isOpen,
//   onClose,
//   onSave,
//   rowData,
// }) => {
//   const [loading, setLoading] = useState(true);
//   const [headers, setHeaders] = useState<any[]>([]);
//   const [headerMap, setHeaderMap] = useState<any>({});
//   const [pagination, setPagination] = useState<any>({});
//   const [tableData, setTableData] = useState<any>([]);
//   const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
//   const [highlightedRowId, setHighlightedRowId] = useState<string | null>(null);
  
//   const { 
//     username, 
//     partner, 
//     role, 
//     token, 
//     selectedDb, 
//     sessionId, 
//     settabledata, 
//     advancedStoredpagination, 
//     storedpagination, 
//     tenantName, 
//     tenantId, 
//     firstLastName, 
//     setStoredPagination, 
//     setAdvancedStoredPagination 
//   } = useAuth();

//   const accountNumber = useCustomerProfileStore((state) => state.accountNumber);

//   type HeaderMap = Record<string, [string, number]>;
//   const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
//     const entries = Object.entries(headerMap) as [string, [string, number]][];
//     entries.sort((a, b) => a[1][1] - b[1][1]);
//     return Object.fromEntries(entries) as HeaderMap;
//   }, []);

//   const fetchCollectionsStepData = async () => {
//     setLoading(true);
//     // settabledata([]);
//     setStoredPagination(null);
//     setAdvancedStoredPagination(null);

//     let parsedData: any;
//     try {
//       const url = ENV_ROUTES.BP_REPORTS; // Use Collections route
//       const data = {
//         tenant_name: partner || "default_value",
//         username: username,
//         firstLastName: firstLastName,
//         path: "/collections_steps_list_view", // Collections steps path
//         role_name: role,
//         parent_module: "Billing Platform",
//         module_name: "Collections Steps",
//         feature_module_name: "Collections Steps",
//         main_module_name: "Collections",
//         table_name: "collection_steps",
//         request_received_at: getCurrentDateTime(),
//         Partner: partner,
//         access_token: token,
//         db_name: selectedDb,
//         sessionID: sessionId,
//         changed_data: rowData, // Pass the row data from the component
//         mod_pages: {
//           start: 0,
//           end: 50,
//         },
//       };

//       const response = await axios.post(url, { data });
//       console.log("Collections Step Response:", response);
//       parsedData = JSON.parse(response.data.body);
//       console.log("Parsed Data:", parsedData);

//       if (parsedData.flag === true) {
//         setLoading(false);

//         setTimeout(() => {
//           const headersMap_ = parsedData?.header_map?.["Collections Steps"]?.header_map || {};
//           const sortedHeaderMap = sortHeaderMap(headersMap_);
//           setHeaderMap(sortedHeaderMap);

//           const headers_ = Object.keys(sortedHeaderMap).length > 0 ? Object.keys(sortedHeaderMap) : [];
//           setHeaders(headers_);
//           setVisibleColumns(headers_);
//           setTableData(parsedData?.collections_steps || []);
//           console.log("Table Data:", parsedData?.data?.collections_steps || []);
//           setPagination(parsedData?.pages || {});
            
//           // Set the highlighted row ID from the response
//           if (parsedData?.highlighted_row_id) {
//             setHighlightedRowId(parsedData.highlighted_row_id.id);
//           }
//         }, 0);
//       } else {
//         setLoading(false);
//         console.log("Flag set to false");
//         Modal.error({
//           title: "Data Fetch Error",
//           content: parsedData.message || "An error occurred while fetching data. Please try again.",
//           centered: true,
//         });
//       }
//     } catch (error) {
//       setLoading(false);
//       Modal.error({
//         title: "Data Fetch Error",
//         content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
//         centered: true,
//       });
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     if (isOpen && rowData) {
//       fetchCollectionsStepData();
//     }
//   }, [isOpen, rowData]);

//   console.log("Table Data:", tableData);
//   return (
//     <Modal
//       open={isOpen}
//       onCancel={onClose}
//       title="Collections Steps"
//       centered
//       width={1200}
//       bodyStyle={{
//         height: "auto",
//         overflowY: "auto",
//       }}
    
//     >
//       <div>
//         {loading ? (
//           <div
//             className="flex justify-center items-center overflow-y-auto"
//             style={{ height: "400px" }}
//           >
//             <Spin size="large" />
//           </div>
//         ) : (
//           <EditableTableComponent
//             headers={headers}
//             headerMap={headerMap}
//             initialData={tableData}
//             visibleColumns={visibleColumns}
//             itemsPerPage={50}
//             popupHeading="Collections Steps"
//             pagination={pagination}
//             height={400}
//             highlightedRowId={highlightedRowId} // Pass the highlighted row ID
//             row={rowData || null}
//           />
//         )}
//       </div>
//     </Modal>
//   );
// };

// export default CollectionsStepModal;
import React, { useCallback, useEffect, useState } from "react";
import { Modal, Spin } from "antd";
import EditableTableComponent from "../killbill_components/editable_table_component";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useCustomerProfileStore } from "../killbill_stores/customer_profile_store";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { useAuth } from "@/app/components/auth_context";
import KillbillTableComponent from "./table__component";

interface CollectionsStepModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave?: () => void;
  rowData: any; // The row data passed from the table component
}

const CollectionsStepModal: React.FC<CollectionsStepModalProps> = ({
  isOpen,
  onClose,
  onSave,
  rowData,
}) => {
  const [loading, setLoading] = useState(true);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const [highlightedRowId, setHighlightedRowId] = useState<string | number | null>(null);
  
   const { username, partner, role, token, selectedDb,metaData,selectedBillingDb, sessionId, settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId, firstLastName , setStoredPagination , setAdvancedStoredPagination, setCombineAdnvaceStoredpagination,combineAdnvaceStoredpagination} = useAuth();
 

  const accountNumber = useCustomerProfileStore((state) => state.accountNumber);

  type HeaderMap = Record<string, [string, number]>;
  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);

  // Create default headers from the data structure
 
  const fetchCollectionsStepData = async () => {
    setLoading(true);
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    // setSearchTerm("");
    // setShowAdvanced(false)
    setCombineAdnvaceStoredpagination(null)
    // settabledata([]);

    let parsedData: any;
    try {
      const url = ENV_ROUTES.BP_REPORTS; // Use Collections route
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";
      
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/collections_steps_list_view", // Collections steps path
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Collections Step Reports",
        feature_module_name: "Collections Step Reports",
        main_module_name: "Collections",
        table_name: "collection_steps",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        tenant_id: tenant_id_,
        changed_data: rowData, // Pass the row data from the component
        mod_pages: {
          start: 0,
          end: 50,
        },
      };

      const response = await axios.post(url, { data });
      console.log("Collections Step Response:", response);
      parsedData = JSON.parse(response.data.body);
      console.log("Parsed Data:", parsedData);

      if (parsedData.flag === true) {
        setTimeout(() => {
          // FIXED: Access the correct data path
          const collectionsData = parsedData?.data?.collection_steps || [];
          console.log("Collections Data:", collectionsData);
          // Check if header_map exists and has data
          const headersMap_ = parsedData?.header_map?.["Collections Step Reports"]?.header_map || {};
          
          if (Object.keys(headersMap_).length > 0) {
            // Use provided header map
            const sortedHeaderMap = sortHeaderMap(headersMap_);
            setHeaderMap(sortedHeaderMap);
            const headers_ = Object.keys(sortedHeaderMap);
            setHeaders(headers_);
            setVisibleColumns(headers_);
          } 
          
          // FIXED: Set the correct table data
          setTableData(collectionsData);
          console.log("Table Data:", collectionsData);
          setPagination(parsedData?.pages || {});
          
          // Set the highlighted row ID from the response
          if (parsedData?.highlighted_row_id) {
            // Handle both object and primitive types
            const highlightId = typeof parsedData.highlighted_row_id === 'object' 
              ? parsedData.highlighted_row_id.id 
              : parsedData.highlighted_row_id;
            
            setHighlightedRowId(highlightId);
            console.log("Highlighted Row ID:", highlightId);
          }
        }, 0);
      } else {
        console.log("Flag set to false");
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      console.error("Error fetching collections data:", error);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen && rowData) {
      fetchCollectionsStepData();
    }
  }, [isOpen, rowData]);

  console.log("Table Data:", tableData);
  console.log("Headers:", headers);
  console.log("Header Map:", headerMap);
  console.log("Highlighted Row ID:", highlightedRowId);

  return (
    <Modal
      open={isOpen}
      onCancel={onClose}
      title="Collections Steps"
      centered
      width={1200}
      bodyStyle={{
        height: "auto",
        overflowY: "auto",
      }}
      footer={null}
    >
      <div>
        {loading ? (
          <div
            className="flex justify-center items-center overflow-y-auto"
            style={{ height: "400px" }}
          >
            <Spin size="large" />
          </div>
        ) : (
          <EditableTableComponent
            headers={headers}
            headerMap={headerMap}
            initialData={tableData}
            visibleColumns={visibleColumns}
            itemsPerPage={50}
            popupHeading="Collections Steps"
            pagination={pagination}
            height={400}
            highlightedRowId={highlightedRowId} // Pass the highlighted row ID
            row={rowData || null}
          />
        //   <KillbillTableComponent
        //     headers={headers}
        //     headerMap={headerMap}
        //     initialData={tableData}
        //     visibleColumns={visibleColumns}
        //     itemsPerPage={100}
        //     popupHeading={"Collections Steps"}
        //     pagination={pagination}
        //     height={300}
        //     highlightedRowId={highlightedRowId} // Pass the highlighted row ID
        //   />
        )}
      </div>
    </Modal>
  );
};

export default CollectionsStepModal;

