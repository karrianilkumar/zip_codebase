import dynamic from "next/dynamic";
import { useEffect, useState } from "react";
import "react-quill/dist/quill.snow.css";

// Dynamically import ReactQuill to prevent SSR issues
const ReactQuill = dynamic(() => import("react-quill"), { ssr: false });

interface RichTextEditorProps {
  htmlContent?: string;                   //  Prop for initial content
  onHtmlChange: (html: string) => void;  // Callback prop
}

const RichTextEditor: React.FC<RichTextEditorProps> = ({ htmlContent,onHtmlChange }) => {
  const [editorHtml, setEditorHtml] = useState("");
  useEffect(() => {
    if (htmlContent) {
      setEditorHtml(htmlContent);
    }
  }, [htmlContent]);
  const handleChange = (content: string) => {
    setEditorHtml(content);
    onHtmlChange(content);  //  Trigger callback with HTML content
  };

  return (
    <div className="mt-4">
      <label className="field-label">Content</label>
      <ReactQuill value={editorHtml} onChange={handleChange} />
    </div>
  );
};

export default RichTextEditor;
