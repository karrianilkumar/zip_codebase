import React, { useCallback, useEffect, useState, useMemo } from "react";
import { Select as AntdSelect, Checkbox, Input, Modal, notification, Popover, Spin, Switch, DatePicker } from 'antd';
import { NonEditableDropdownStyles, DropdownStyles } from '@/app/components/css/dropdown';
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useAuth } from "@/app/components/auth_context";
import { CloseOutlined, DeleteOutlined, MinusOutlined, PlusOutlined, EditOutlined } from "@ant-design/icons";
import dayjs from "dayjs";
import { useKillBillStore } from "../killbill_stores/activeStore";
import { MinusCircleIcon, PlusCircleIcon } from "@heroicons/react/24/outline";
import CreatableSelect from "react-select/creatable";
import Select from "react-select"; 
import { X } from "lucide-react";
import VirtualList from "rc-virtual-list";

const { RangePicker } = DatePicker;

interface CreateModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: () => void;
  modalData: {
    id: number;
    display_name: string;
    type: string;
    mandatory: boolean;
    db_column_name: string;
     table_header_order?: string; // Add this
  }[];
  title: string;
  visible: boolean;
  action: string;
  rowData?: any;
  generalFields?: any;
  selectedSubPartner?: any;
  selectedPartner?: any;
}

const messageStyle = {
  fontSize: '14px',
  fontWeight: 'normal',
  padding: '16px',
};

const CreateModal: React.FC<CreateModalProps> = ({
  isOpen,
  onClose,
  onSave,
  modalData,
  title,
  visible,
  action,
  rowData,
  generalFields,
  selectedSubPartner,
  selectedPartner,
}) => {
  // console.log("modalData:", modalData);
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);
  const [customFields, setCustomFields] = useState<string[]>([]);
  const [error, setError] = useState("");
  const [identifierError, setIdentifierError] = useState("");
  const [newFieldDisplayName, setNewFieldDisplayName] = useState('');
  const [newIdentifierName, setNewIdentifierName] = useState('');
  const [showCustomFields, setShowCustomFields] = useState(false);
  const [showCustomIdentifier, setShowCustomIdentifier] = useState(false);
  const { username, partner, role, settabledata, token, selectedDb,metaData,selectedBillingDb, isSubTenant,firstLastName, sessionId } = useAuth();
  const [loading, setLoading] = useState(false);
  const [loading2, setLoading2] = useState(false);
  const [builtinFields, setBuiltinFields] = useState<any[]>([]);
  const [showBuiltinFields, setShowBuiltinFields] = useState(false);
  const [selectedFields, setSelectedFields] = useState<{ display_name: string, type: string, db_column_name: string }[]>([]);
  const [tempSelectedFields, setTempSelectedFields] = useState<string[]>([]);
  const [dropdownOpen, setDropdownOpen] = useState(false);
  const [editIndex, setEditIndex] = useState<number | null>(null);
  const [editValue, setEditValue] = useState('');
  const [formValues, setFormValues] = useState<Record<string, any>>({});
  const [validationErrors, setValidationErrors] = useState<{ [key: string]: string }>({});
  const [isTaxClassOverrideEnabled, setIsTaxClassOverrideEnabled] = useState(false);
  const [isTaxTypeOverrideEnabled, setIsTaxTypeOverrideEnabled] = useState(false);
  const [isPSCodeOverrideEnabled, setIsPSCodeOverrideEnabled] = useState(false);
  const [selectedPrimaryField, setSelectedPrimaryField] = useState<string | null>(null);

  const { serviceShowActive, productTypeShowActive, packageActive, productShowActive } = useKillBillStore();
  const [searchTerm, setSearchTerm] = useState('');
  const [searchValue, setSearchValue] = React.useState("");


  // Sort modalData by table_header_order
// Sort modalData by table_header_order
const sortedModalData = useMemo(() => {
  return [...modalData].sort((a, b) => {
    const orderA = parseInt(a.table_header_order || "0") || 0;
    const orderB = parseInt(b.table_header_order || "0") || 0;
    return orderA - orderB;
  });
}, [modalData]);


  const SubmitData = async (formData: any) => {
    if(formData){
    setLoading(true);
    try {
      let data;
      let url = title === "Customer Profiles" ? ENV_ROUTES.BP_CUSTOMER_PROFILES : ENV_ROUTES.BP_SERVICES_PRODUCTS;
      let url2 = ENV_ROUTES.MODULE_MANAGEMENT;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";

      if (title === "service type") {
        data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/add_service_type",
          role_name: role,
          module_name: "Billing Services",
          feature_module_name: "Billing Platform",
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
billing_db_name: selectedBillingDb,
          request_received_at: getCurrentDateTime(),
          sessionID: sessionId,
          tenant_id:tenant_id_,
          action: "create",
          modified_by: firstLastName,
          changed_data: { ...formData },
          main_module_name: "Service Types",
        };
      } else if (title === "Product") {
        data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/add_product",
          role_name: role,
          module_name: "Billing Products",
          feature_module_name: "Billing Platform",
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
billing_db_name: selectedBillingDb,
          request_received_at: getCurrentDateTime(),
          sessionID: sessionId,
          tenant_id:tenant_id_,
          action: "create",
          modified_by: firstLastName,
          changed_data: { ...formData },
          main_module_name: "Products",
        };
      } else if (title === "Product Type") {
        data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/add_product_type",
          role_name: role,
          module_name: "Billing Products",
          feature_module_name: "Billing Platform",
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
billing_db_name: selectedBillingDb,
          request_received_at: getCurrentDateTime(),
          sessionID: sessionId,
          tenant_id:tenant_id_,
          action: "create",
          modified_by: firstLastName,
          changed_data: { ...formData },
          main_module_name: "Products",
        };
      } else if (title === "Customer Profiles") {
        data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/add_customer_profile",
          role_name: role,
          module_name: "Billing Customer Profiles",
          feature_module_name: "Billing Platform",
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
billing_db_name: selectedBillingDb,
          is_subtenant:isSubTenant,
          table_name: "customer_profiles",
          request_received_at: getCurrentDateTime(),
          sessionID: sessionId,
          tenant_id:tenant_id_,
          main_module_name: "Customer Profiles",
          action: "create",
          modified_by: firstLastName,
          changed_data: { ...formData }
        };
      }else if (title === "GL Code") {
        data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/add_glcode",
          role_name: role,
          parent_module: "Partner Info",
          module_name: "Billing GL Code",
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
billing_db_name: selectedBillingDb,
          request_received_at: getCurrentDateTime(),
          sessionID: sessionId,
          tenant_id:tenant_id_,
          Selected_Partner: selectedPartner,
          sub_partner: selectedSubPartner,
          action: "create",
          modified_by: firstLastName,
          changed_data: { ...formData }
        };
      }
      else if (title === "Service Provider") {
         data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/add_bp_service_provider",
          role_name: role,
          parent_module: "Partner Info",
          module_name: "Billing Service Providers",
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
billing_db_name: selectedBillingDb,
          request_received_at: getCurrentDateTime(),
          sessionID: sessionId,
          tenant_id:tenant_id_,
          Selected_Partner: selectedPartner,
          sub_partner: selectedSubPartner,
          action: "create",
          modified_by: firstLastName,
          changed_data: { ...formData }
        };
      }

      let postUrl;
      if (title === "GL Code" || title === "Service Provider") {
        postUrl = url2;
      } else {
        postUrl = url;    
      }
      const response = await axios.post(postUrl, { data });
      const resp = JSON.parse(response.data.body);
      if (response.data.statusCode === 200 && resp.flag === true) {
        if(resp?.validation){
          Modal.error({
            title: "Validation Error",
            content: resp.message,
            centered: true,
          });
          return;
        }
        notification.success({
          message: "Success",
          description: "Successfully saved the record!",
          style: messageStyle,
          placement: "top",
        });
        handleCancel();
        if (title === "service type") {
          try {
            setLoading(true);
            const url = ENV_ROUTES.BP_SERVICES_PRODUCTS;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/services_list_view",
              role_name: role,
              parent_module: "Billing Platform",
              module_name: "Billing Services",
              sub_module: "Services",
              mod_pages: { start: 0, end: 100 },
              status: serviceShowActive ? "true" : "false",
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              access_token: token,
              tenant_id:tenant_id_,
              db_name: selectedDb,
              ...metaData,
billing_db_name: selectedBillingDb,
              sessionID: sessionId,
              feature_module_name: "Billing Services",
        main_module_name: "Service Types",
            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content: parsedData.message || "An error occurred while fetching Customer groups data. Please try again.",
                centered: true,
              });
            } else {
              settabledata(parsedData?.data?.billing_services || []);
            }
          } catch {
          } finally {
            setLoading(false);
          }
        }
        if (title === "Product") {
          const url = ENV_ROUTES.BP_SERVICES_PRODUCTS;
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/products_list_view",
            role_name: role,
            parent_module: "Billing Platform",
            module_name: "Billing Products",
            sub_module: "Products",
            mod_pages: { start: 0, end: 100 },
            request_received_at: getCurrentDateTime(),
            status: productShowActive ? "true" : "false",
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
            ...metaData,
billing_db_name: selectedBillingDb,
            sessionID: sessionId,
            tenant_id:tenant_id_,
            feature_module_name: "Billing Products",
        main_module_name: "Service Types",
          };
          const response = await axios.post(url, { data });
          const parsedData = JSON.parse(response.data.body);
          if (parsedData.flag === false) {
            Modal.error({
              title: "Data Fetch Error",
              content: parsedData.message || "An error occurred while fetching Customer groups data. Please try again.",
              centered: true,
            });
          } else {
            settabledata(parsedData?.data?.billing_products || []);
          }
        }
        if (title === "Product Type") {
          try {
            setLoading(true);
            const url = ENV_ROUTES.BP_SERVICES_PRODUCTS;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/product_type_list_view",
              role_name: role,
              parent_module: "Billing Platform",
              module_name: "Billing Product Types",
              sub_module: "Products",
              mod_pages: { start: 0, end: 100 },
              request_received_at: getCurrentDateTime(),
              status: productTypeShowActive ? "true" : "false",
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
billing_db_name: selectedBillingDb,
              sessionID: sessionId,
              tenant_id:tenant_id_,
              feature_module_name: "Billing Product Types",
        main_module_name: "Service Types",
            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content: parsedData.message || "An error occurred while fetching Customer groups data. Please try again.",
                centered: true,
              });
            } else {
              settabledata(parsedData?.data?.billing_product_types || []);
            }
          } catch (err) {
            console.error('Error fetching data:', err);
            notification.error({
              message: 'Error',
              description: 'Failed to create the record. Please try again.',
              style: messageStyle,
              placement: 'top',
            });
            setLoading(false);
          } finally {
            setLoading(false);
          }
        }
        if (title === "packages") {
          try {
            setLoading(true);
            const url = ENV_ROUTES.BP_SERVICES_PRODUCTS;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/services_product_package_list_view",
              role_name: role,
              parent_module: "Billing Platform",
              module_name: "Billing Packages",
              sub_module: "Products",
              mod_pages: { start: 0, end: 100 },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
billing_db_name: selectedBillingDb,
              sessionID: sessionId,
              tenant_id:tenant_id_,
              feature_module_name: "Billing Packages",
        main_module_name: "Service Types",
              status: packageActive ? "true" : "false",
            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content: parsedData.message || "An error occurred while fetching Customer groups data. Please try again.",
                centered: true,
              });
            } else {
              settabledata(parsedData?.data?.billing_packages || []);
            }
          } catch (err) {
            console.error('Error fetching data:', err);
            notification.error({
              message: 'Error',
              description: 'Failed to create the record. Please try again.',
              style: messageStyle,
              placement: 'top',
            });
            setLoading(false);
          } finally {
            setLoading(false);
          }
        }
        if (title === "Customer Profiles") {
          onSave();
        }
        if (title === "GL Code") {
          try {
            setLoading(true);
          const url = ENV_ROUTES.MODULE_MANAGEMENT;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/glcode_list_view",
              role_name: role,
              parent_module: "Partner Info",
              module_name: "Billing GL Code",
              Selected_Partner: selectedPartner,
              sub_partner: selectedSubPartner,
              request_received_at: getCurrentDateTime(),
              access_token: token,
              db_name: selectedDb,
              ...metaData,
billing_db_name: selectedBillingDb,
              sessionID: sessionId,
              mod_pages: {
              start: 0,
              end: 100,
            },      
            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content: parsedData.message || "An error occurred while fetching Customer groups data. Please try again.",
                centered: true,
              });
            } else {
              settabledata(parsedData?.data?.billing_gl_code || []);
            }
          } catch (err) {
            console.error('Error fetching data:', err);
            notification.error({
              message: 'Error',
              description: 'Failed to create the record. Please try again.',
              style: messageStyle,
              placement: 'top',
            });
            setLoading(false);
          } finally {
            setLoading(false);
          }
        }
        if (title === "Service Provider") {
          try {
            setLoading(true);
          const url = ENV_ROUTES.MODULE_MANAGEMENT;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/bp_service_providers_list_view",
              role_name: role,
              parent_module: "Partner Info",
              module_name: "Billing Service Providers",
              Selected_Partner: selectedPartner,
              sub_partner: selectedSubPartner,
              request_received_at: getCurrentDateTime(),
              access_token: token,
              db_name: selectedDb,
              ...metaData,
billing_db_name: selectedBillingDb,
              sessionID: sessionId,
              mod_pages: {
              start: 0,
              end: 100,
            },      
            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content: parsedData.message || "An error occurred while fetching Customer groups data. Please try again.",
                centered: true,
              });
            } else {
              settabledata(parsedData?.data?.billing_service_providers || []);
            }
          } catch (err) {
            console.error('Error fetching data:', err);
            notification.error({
              message: 'Error',
              description: 'Failed to create the record. Please try again.',
              style: messageStyle,
              placement: 'top',
            });
            setLoading(false);
          } finally {
            setLoading(false);
          }
        }
      } else {
        Modal.error({
          title: "Saving Error",
          content: resp.message,
          centered: true,
        });
        if(title !== "Customer Profiles") {
          handleCancel();
        }
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Submit Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting data. Please try again.',
        centered: true,
        onOk: onClose
      });
      // handleCancel();
    }
    finally {
      setLoading(false);
    }
  } 
  setIsConfirmationOpen(false);
    
  };

  useEffect(() => {
      if (title === "Product" &&
        formValues["product_type_code"] &&
      formValues["product_type_code"]?.toLowerCase().startsWith("onetime")
    ) {
      setFormValues((prevState: any) => {
      const updatedFormData = {
        ...prevState,
        prorate:false
      };
      return updatedFormData;
    });
    }
    }, [title, formValues]);

  const handleInputChange = (name: any, value: any) => {
    // console.log("name", name, "value", value);
   setFormValues((prevState: any) => {
    let updatedFormData = {
      ...prevState,
      [name]: value,
    };

    // If lead_days is cleared → clear late_fee and late_fee_type too
    if (name === "lead_days" && (!value || value === "")) {
       delete errors["late_fee"];
       delete errors["late_fee_type"];
      updatedFormData = {
        ...updatedFormData,
        late_fee: "",
        late_fee_type: "",
      };
    }

    return updatedFormData;
  });

    let errors = { ...validationErrors };
    if((name === "late_fee_type" || name === "late_fee")&& value ){
      delete errors["late_fee"];
      delete errors["late_fee_type"];
    }
    if (name === "bill_period_end_day") {
      if (value && (!/^\d+$/.test(value.toString()) || Number(value) < 1 || Number(value) > 28)) {
        errors[name] = "Bill Period Start Day must be a number between 1 and 28";
      } else {
        delete errors[name];
      }
    }

    if (name === "bill_period_end_hour") {
      if (value && (!/^\d+$/.test(value.toString()) || Number(value) < 0 || Number(value) > 23)) {
        errors[name] = "Bill Period Start Hour must be a number between 0 and 23";
      } else {
        delete errors[name];
      }
    }

    if (name === "email") {
      const validateEmail = (email: string) => {
        const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        return emailRegex.test(email);
      };
      if (!validateEmail(value)) {
        errors[name] = "Invalid email address";
      } else {
        delete errors[name];
      }
    }

    if (name === "account_number") {
      if (value && (value.length < 6 || value.length > 20)) {
        errors[name] = "Account number must be between 6 to 20 characters.";
      } else if (value && !/^[0-9]+$/.test(value)) {
        errors[name] = "Account number must contain only numbers (0-9).";
      } else {
        delete errors[name];
      }
    }
    if (name === "customer_name") {
        const regex = /^[a-zA-Z\s]+$/; // Only allow letters and spaces
        if (!regex.test(value)) {
          errors[name] = "Numbers are not allowed in customer name";
        } else {
          delete errors[name]; // Remove error if validation passes
        }
      }
    if (name === "telephone_number") {
      const mobileRegex = /^\d{10}$/;
      if (value && !mobileRegex.test(value)) {
        errors[name] = "Mobile number must be 10 digits.";
      } else {
        delete errors[name];
      }
    }

    if (name === "postal_code") {
      const postalCodeRegex = /^\d{5}$/;
      if (value && !postalCodeRegex.test(value)) {
        errors[name] = "Postal code must be exactly 5 digits";
      } else {
        delete errors[name];
      }
    }
    // New Lead Days validation
  if (name === "lead_days") {
    if (value && !/^\d+$/.test(value.toString())) {
      errors[name] = "Lead Days must be a number";
    } else {
      delete errors[name];
    }
    
    // Clear Late Fee and Late Fee Value when Lead Days is cleared
    if (!value || value.trim() === "") {
      setFormValues(prev => ({
        ...prev,
        late_fee_type: "",
        late_fee: ""
      }));
      delete errors["late_fee_type"];
      delete errors["late_fee"];
    }
  }

  // New Late Fee Value validation
  if (name === "late_fee") {
    if (value && !/^\d*\.?\d+$/.test(value.toString())) {
      errors[name] = "Late Fee Value must be a number";
    } else {
      delete errors[name];
    }
  }
    setValidationErrors(errors);
  };

  const showConfirmation = () => {
    const errors: { [key: string]: string } = {};

    modalData.forEach((column) => {
      const value = formValues[column.db_column_name];

      if (column.db_column_name === "parent_accounts" && title === "Customer Profiles" && formValues.account_type !== "Child") {
        return;
      }
      // if ((column.db_column_name === "btn_provider" && formValues["billing_cycle_range"]) || (column.db_column_name === "billing_cycle_range" && formValues["btn_provider"])) {
      //   return;
      // }

      if (
      column.mandatory ||
      ((column.db_column_name === "late_fee_type" ||
        column.db_column_name === "late_fee") &&
        formValues["lead_days"])
    ) {
        if ((Array.isArray(value) && value.length === 0) || (!Array.isArray(value) && !value)) {
          errors[column.db_column_name] = `${column.display_name} is required.`;
        }
      }
      if(formValues["primary_field"] && formValues["primary_field"] === "Custom" && !newIdentifierName){
        errors["custom_identifier"] = "Please Enter Custom Identifier Name"
        setIdentifierError("Please Enter Custom Identifier Name");
        return;
      }
      if (column.db_column_name === "email") {
        const validateEmail = (email: string) => {
          const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
          return emailRegex.test(email);
        };
        if (!validateEmail(value)) {
          errors[column.db_column_name] = "Invalid email address";
          return;
        }
      }
      

      if (column.db_column_name === "account_number") {
        if (value && (value.length < 6 || value.length > 20)) {
          errors[column.db_column_name] = "Account number must be between 6 to 20 characters.";
        }
      }

      if (column.db_column_name === "telephone_number") {
        const mobileRegex = /^\d{10}$/;
        if (value && !mobileRegex.test(value)) {
          errors[column.db_column_name] = "Mobile number must be 10 digits.";
        }
      }

      if (column.db_column_name === "postal_code") {
        const postalCodeRegex = /^\d{5}$/;
        if (value && !postalCodeRegex.test(value)) {
          errors[column.db_column_name] = "Postal code must be exactly 5 digits";
        }
      }
    });

    if (Object.keys(errors).length > 0) {
      setValidationErrors(errors);
      setIsConfirmationOpen(false);
    } else {
      setValidationErrors({});
      setIsConfirmationOpen(true);
    }
  };

  const handleSave = () => {
    const formElement = document.querySelector('form') as HTMLFormElement;
    const formData = new FormData(formElement);

    const data: Record<string, string> = Array.from(formData.entries()).reduce(
      (acc, [key, value]) => ({ ...acc, [key]: value as string }),
      {}
    );

    const formattedBuiltInFields = selectedFields.map(field => ({
        field: field.display_name,
        type: field.type,
        db_column_name: field.db_column_name
    }));

    const formattedCustomFields = customFields.map(field => ({
        field,
        type: "text",
        db_column_name: field
    }));

    const combinedData = {
      ...formValues,
      ...(formattedBuiltInFields.length > 0 && { built_in_fields: formattedBuiltInFields }),
      ...(formattedCustomFields.length > 0 && { custom_fields: formattedCustomFields }),
      ...(newIdentifierName && { custom_primary_field: newIdentifierName})
    };

    console.log("Saving data:", combinedData); // Debugging log

    setSelectedFields([]);
    setCustomFields([]);
    SubmitData(combinedData);
  };

  const handleCancel = () => {
    setFormValues({});
    setSelectedFields([]);
    setTempSelectedFields([]);
    setBuiltinFields([]);
    setCustomFields([]);
    setNewFieldDisplayName('');
    setNewIdentifierName('');
    setShowBuiltinFields(false);
    setShowCustomFields(false);
    setDropdownOpen(false);
    onClose();
    setValidationErrors({});
    setIsPSCodeOverrideEnabled(false);
    setIsTaxClassOverrideEnabled(false);
    setIsTaxTypeOverrideEnabled(false);
  };

  const handleCancelConfirmation = () => {
    setIsConfirmationOpen(false);
  };

  const modalWidth = typeof window !== "undefined"
  ? window.innerWidth <= 768  // 768px is Tailwind's `md` breakpoint
    ? (window.innerWidth * 3.5) / 4
    : (window.innerWidth * 2.5) / 4
  : 0;
  const modalHeight = typeof window !== 'undefined' ? (window.innerHeight * 2.5) / 4 : 0;

  if (!isOpen) return null;

  const handleConfirmCreate = () => {
    setIsConfirmationOpen(false);
    handleSave();
  };

  const handleAddCustomField = () => {
    if (newFieldDisplayName.trim()) {
      setCustomFields([...customFields, newFieldDisplayName]);
      setNewFieldDisplayName("");
      setError("");
    } else {
      setError("Please enter field name");
    }
  };

  const handleDeleteCustomField = (index: number) => {
    const updatedCustomFields = customFields.filter((_, i) => i !== index);
    setCustomFields(updatedCustomFields);
  };

  const handleBuiltinFields = async () => {
    if (showBuiltinFields) {
      setShowBuiltinFields(false);
      setTempSelectedFields([]);
      setDropdownOpen(false);
      return;
    }
    setLoading(true);

    try {
      const url = ENV_ROUTES.BP_SERVICES_PRODUCTS;
      const data = {
        tenant_name: partner || "default_value",
        username,
        firstLastName,
        path: "/services_built_in_fields",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing Services Builtin Fields",
        request_received_at: getCurrentDateTime(),
        main_module_name: "Service Types",
        Partner: partner,
        access_token: token,
        db_name: 'billing_platform',
        billing_db_name: selectedBillingDb,
        ...metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      if (!response.data.body) {
        throw new Error("Response data body is missing or invalid.");
      }

      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === true) {
        const fields = parsedData.header_map["Service Types Builtin Fields"].pop_up;
        setBuiltinFields(fields || []);
        setShowBuiltinFields(true);
        setTempSelectedFields(selectedFields.map(field => field.db_column_name));
        setDropdownOpen(true); // Open dropdown when fields are fetched
      } else {
        Modal.error({
          title: 'Fetch Error',
          content: parsedData.message || 'An error occurred while fetching built-in fields. Please try again.',
          centered: true,
          onOk: onClose,
        });
      }
    } catch (error) {
      console.error("Error fetching built-in fields:", error);
      if (axios.isAxiosError(error)) {
        console.error("Axios error response:", error.response?.data);
      }
      Modal.error({
        title: 'Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching built-in fields. Please try again.',
        centered: true,
        onOk: onClose,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleOkFields = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const newSelectedFields = tempSelectedFields.map(val => {
      const field = builtinFields.find(f => f.db_column_name === val);
      return {
        display_name: field.display_name,
        type: field.type,
        db_column_name: field.db_column_name
      };
    });
    setSelectedFields(newSelectedFields);
    setDropdownOpen(false);
    setSearchTerm('')
  };

  const handleCancelFields = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setTempSelectedFields(selectedFields.map(field => field.db_column_name));
    setDropdownOpen(false);
  };

  const handleDeleteField = (index: number) => {
    setSelectedFields(prev => prev.filter((_, i) => i !== index));
    setTempSelectedFields(prev => prev.filter(val => val !== selectedFields[index].db_column_name));
  };

  const handleEditField = (index: number) => {
    setEditIndex(index);
    setEditValue(selectedFields[index].display_name);
  };

  const handleEditChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setEditValue(e.target.value);
  };

  const handleEditSave = (index: number) => {
    if (editValue.trim()) {
      setSelectedFields(prev => {
        const updatedFields = [...prev];
        updatedFields[index].display_name = editValue;
        return updatedFields;
      });
      setEditIndex(null);
      setEditValue('');
    }
  };

  const handleToggleCustomFields = () => {
    setShowCustomFields((prev) => !prev);
  };

  const lowerCaseFirstLetter = (text: string) => {
    if (!text) return '';
    return text
      .split(' ')
      .map((word: string) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase())
      .join(' ');
  };

  const handleKeyPress = (event: any) => {
    const charCode = event.charCode;
    if (charCode < 48 || charCode > 57) {
      event.preventDefault();
    }
  };

  if (loading2) {
    return (
      <div className="absolute inset-0 flex justify-center items-center bg-white bg-opacity-75 z-50 border pointer-events-none">
        <div className='flex justify-center'>
          <Spin size="large" />
        </div>
      </div>
    );
  }

  const getFieldValue = (field: any) => {
    const fieldName = field.db_column_name;

    if (fieldName === "parent_accounts" && formValues.account_type !== "Child") {
      return null;
    }

    const fieldValue = formValues[fieldName];

    if (!fieldValue) {
      return [];
    }

    if (fieldName === "tax_class" && title === "Product") {
      if (isTaxClassOverrideEnabled) {
        return fieldValue ? { label: fieldValue, value: fieldValue } : null;
      } else {
        const selectedProductType = formValues["product_type"];
        if (selectedProductType && generalFields.dropdown["product_type"]?.[selectedProductType]) {
          return {
            label: generalFields.dropdown["product_type"][selectedProductType],
            value: generalFields.dropdown["product_type"][selectedProductType],
          };
        }
        return null;
      }
    }

    if (fieldName === "tax_type" && title === "Product") {
      if (isTaxTypeOverrideEnabled) {
        return fieldValue ? { label: fieldValue, value: fieldValue } : null;
      } else {
        const selectedProductType = formValues["product_type"];
        if (selectedProductType && generalFields.dropdown["product_type_1"]?.[selectedProductType]) {
          return {
            label: generalFields.dropdown["product_type_1"][selectedProductType],
            value: generalFields.dropdown["product_type_1"][selectedProductType],
          };
        }
        return null;
      }
    }

    // if (fieldName === "ps_code" && title === "Product") {
    //   if (isPSCodeOverrideEnabled) {
    //     return fieldValue ? { label: fieldValue, value: fieldValue } : null;
    //   } else {
    //     const selectedProductType = formValues["product_type"];
    //     if (selectedProductType && generalFields.dropdown["product_type_2"]?.[selectedProductType]) {
    //       return {
    //         label: generalFields.dropdown["product_type_2"][selectedProductType],
    //         value: generalFields.dropdown["product_type_2"][selectedProductType],
    //       };
    //     }
    //     return null;
    //   }
    // }

    if (Array.isArray(fieldValue)) {
      return fieldValue.map((item: string) => ({
        label: item,
        value: item,
      }));
    }

    return { label: fieldValue, value: fieldValue };
  };

  const isFieldDisabled = (fieldName: string) => {
    if (title === "Product") {
      if (fieldName === "tax_class" && !isTaxClassOverrideEnabled) {
        return true;
      }
      if (fieldName === "tax_type" && !isTaxTypeOverrideEnabled) {
        return true;
      }
      // if (fieldName === "ps_code" && !isPSCodeOverrideEnabled) {
      //   return true;
      // }
    }
    // if (fieldName === "btn_provider" && formValues["billing_cycle_range"]) {
    //   return true;
    // }
    if (title === "Customer Profiles" && fieldName === "parent_accounts" && formValues.account_type !== "Child") {
      return true;
    }
    // Lead Days dependency for both Late Fee dropdown and Late Fee Value
    if (title === "Customer Profiles") {
      const leadDaysValue = formValues["lead_days"];
      const hasLeadDays = leadDaysValue && leadDaysValue.toString().trim() !== "";
      
      if ((fieldName === "late_fee_type" || fieldName === "late_fee") && !hasLeadDays) {
        return true;
      }
    }

    return false;
  };

  // const handleOverrideChange = (fieldName: string, isChecked: boolean) => {
  //   if (fieldName === "tax_class") {
  //     setIsTaxClassOverrideEnabled(isChecked);
  //   } else if (fieldName === "tax_type") {
  //     setIsTaxTypeOverrideEnabled(isChecked);
  //   } 
  //   else if (fieldName === "ps_code") {
  //     setIsPSCodeOverrideEnabled(isChecked);
  //   }

  //   handleInputChange(`override_${fieldName}`, isChecked);
  // };

  const getDropdownStyles = (fieldName: string) => {
    const isNonEditable =
           (title === "Product" &&
        ((fieldName === "tax_class" && !isTaxClassOverrideEnabled) ||
          (fieldName === "tax_type" && !isTaxTypeOverrideEnabled)))|| 
          

      (title === "Customer Profiles" &&
        fieldName === "parent_accounts" &&
        formValues.account_type !== "Child") 
        // ||(fieldName === "btn_provider" && formValues["billing_cycle_range"]);
        ||
      // Add Late Fee to the disabled styling
      (title === "Customer Profiles" &&
        fieldName === "late_fee_type" &&
        (!formValues["lead_days"] || formValues["lead_days"].toString().trim() === ""));
          
    return {
      ...(isNonEditable ? NonEditableDropdownStyles : DropdownStyles),
      menuPortal: (base: any) => ({ ...base, zIndex: 9999 }),
    };
  };

  const handleCloseBuiltinFields = () => {
    setShowBuiltinFields(false);
    setBuiltinFields([])
    setSelectedFields([]);
    setTempSelectedFields([]);
    setDropdownOpen(false);
  };

  const handleCloseCustomFields = () => {
    setShowCustomFields(false);
    setCustomFields([])
  };

  const handleCustomFieldChange = (e: any) => {
    setNewFieldDisplayName(e.target.value);
    setIdentifierError("");
  };
   const handleCustomIdentifierChange = (e: any) => {
    setNewIdentifierName(e.target.value);
    setError("");
  };

  return (
    <div>
      <Modal
        open={isOpen}
        onCancel={handleCancel}
        title={
          <h3 className='popup-heading'>
            {title === "Report"
              ? `Generate ${title.toLowerCase().split(" ").map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(" ")}`
              : `Add ${title.toLowerCase().split(" ").map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(" ")}`}
          </h3>
        }
        centered
        footer={
      <div className="mt-7 flex flex-wrap justify-center gap-2">            
        
            {title === "service type" && (
              <>
                <button
                  className={(showBuiltinFields) ? "cancel-btn cursor-not-allowed" : "save-btn"}
                  disabled={showBuiltinFields}
                  onClick={handleBuiltinFields}
                >
                  {"Add Built-in Fields"}
                </button>
                <button
                  className={(showCustomFields) ? "cancel-btn cursor-not-allowed" : "save-btn"}
                  disabled={showCustomFields}
                  onClick={handleToggleCustomFields}
                >
                  {"Add Custom Fields"}
                </button>
              </>
            )}
            <button onClick={handleCancel} className="cancel-btn">
              Cancel
            </button>
            <button onClick={showConfirmation} className="save-btn">
              Save
            </button>
          </div>
        }
        width={(modalData.length > 5 || title === "service type") ? modalWidth : '500px'}
        styles={{ body: { height: (modalData.length >= 5 || title === "service type") ? modalHeight : 'auto', padding: '4px' } }}
      >
         {!loading ? (
          <div className={`${(modalData.length >= 5 || title === "service type") ? 'popup' : ''}`}>
            <form>
              
                <div
                  className={`grid gap-4 ${
                    modalData.length > 5 && title === "Product"
                      ? "grid-cols-1 sm:grid-cols-2"
                      : modalData.length > 4 && title === "Product Type"
                      ? "grid-cols-1 sm:grid-cols-1"
                      : modalData.length >= 5 && title !== "Product"
                      ? "grid-cols-1 sm:grid-cols-2 md:grid-cols-3"
                      : modalData.length >= 4 && title === "service type"
                      ? "sm:grid-cols-1 md:grid-cols-2"
                      : modalData.length === 6
                      ? "grid-cols-1 sm:grid-cols-2"
                      : "grid-cols-1"
                  }`}
                >

                 {sortedModalData?.map((field) => (
                    <div key={field.id} className={`${title === "Product Type" ? "mb-2":"mb-4"}`}>
                      {field.type !== "checkbox" && (
                        <label className="field-label" title={field.display_name === 'PS Code' ? 'Product Specific Code' : ''}>
                          {field.display_name}{" "}
                          {field.mandatory && field.mandatory !== null && (
                            <span className="text-red-500">*</span>
                          )}
                        </label>
                      )}
                      {field.type === "text" && (
                        <div>
                          <Input
                            type="text"
                            name={field.db_column_name}
                            className="input pl-8"
                            value={formValues[field.db_column_name] || ""}
                            onChange={(e) => {
                              const value = e.target.value;
                              // For Lead Days, only allow numbers
                              if (field.db_column_name === "lead_days") {
                                if (value === "" || /^\d+$/.test(value)) {
                                  handleInputChange(field.db_column_name, value);
                                }
                              } 
                              // For Late Fee Value, allow numbers and decimals
                              else if (field.db_column_name === "late_fee") {
                                if (value === "" || /^\d*\.?\d*$/.test(value)) {
                                  handleInputChange(field.db_column_name, value);
                                }
                              } 
                              else {
                                handleInputChange(field.db_column_name, value);
                              }
                            }}
                            placeholder={`Enter ${lowerCaseFirstLetter(field.display_name)}`}
                            disabled={isFieldDisabled(field.db_column_name)}
                          />
                          {validationErrors[field.db_column_name] && (
                            <span className="text-red-500">
                              {validationErrors[field.db_column_name]}
                            </span>
                          )}
                          
                        </div>
                      )}
                      {field.type === "number" && (
                        <div>
                          <Input
                            type="text"
                            pattern="[0-9]*"
                            name={field.db_column_name}
                            onKeyPress={handleKeyPress}
                            className="input pl-8"
                            value={formValues[field.db_column_name] || ""}
                            onChange={(e) =>
                              handleInputChange(field.db_column_name, e.target.value)
                            }
                            placeholder={`Enter ${lowerCaseFirstLetter(field.display_name)}`}
                          />
                          {validationErrors[field.db_column_name] && (
                            <span className="text-red-500">
                              {validationErrors[field.db_column_name]}
                            </span>
                          )}
                        </div>
                      )}
                     {field.type === "dollar" && (
                        <div className="relative">
                          <span className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-500 pointer-events-none z-10">
                            $
                          </span>
                          <Input
                            type="number"
                            name={field.db_column_name}
                            className="input !pl-4"
                            value={formValues[field.db_column_name]}
                            min={1} // ✅ restricts to >= 1
                            step={1} // ✅ no decimals
                            onKeyDown={(e) => {
                              if (["e", "E", "+", "-", "."].includes(e.key)) {
                                e.preventDefault(); // ✅ block alphabets, exponent, minus, decimals
                              }
                            }}
                           onWheel={(e) => {
                             (e.target as HTMLInputElement).blur();
                           }} 
                            onChange={(e) => {
                              const value = e.target.value;
                              // ✅ allow only positive integers
                              const numericValue = value.replace(/[^0-9]/g, ""); // remove non-digits
                              handleInputChange(field.db_column_name, numericValue);
                            }}
                            placeholder={`Enter ${lowerCaseFirstLetter(field.display_name)}`}
                          />
                          {validationErrors[field.db_column_name] && (
                            <span className="text-red-500">
                              {validationErrors[field.db_column_name]}
                            </span>
                          )}
                        </div>
                      )}
                      {field.type === "month" && (
                        <>
                          <Input
                            type="text"
                            name={field.db_column_name}
                            className="input"
                            value={formValues[field.db_column_name] || ""}
                            onChange={(e) =>
                              handleInputChange(field.db_column_name, e.target.value)
                            }
                            placeholder="Enter months"
                          />
                          {validationErrors[field.db_column_name] && (
                            <span className="text-red-500">
                              {validationErrors[field.db_column_name]}
                            </span>
                          )}
                        </>
                      )}
                      {field.type === 'checkbox' && (
                        <>
                          <Checkbox
                            checked={formValues[field.db_column_name] ?? (field.db_column_name === "is_active" ? true : false)}
                            onChange={(e) =>
                              handleInputChange(field.db_column_name, e.target.checked)
                            }
                            className={`checkbox ${
                              ((title === "Product") && field.db_column_name === "is_active") ||
                              (title === "Product" && field.db_column_name === "prorate")||((title === "Product") && field.db_column_name === "is_surcharge")
                                ? "mt-6"
                                : ""
                            }`}
                            disabled={
                            title === "Product" &&
                            field.db_column_name === "prorate" &&
                            formValues["product_type_code"]?.toLowerCase().startsWith("onetime")
                            }
                            >
                            {field.display_name}
                          </Checkbox>
                          {validationErrors[field.db_column_name] && (
                            <span className="text-red-500">
                              {validationErrors[field.db_column_name]}
                            </span>
                          )}
                        </>
                      )}
                      {field.type === "dropdown" && (
                        <>
                          <Select
                            isMulti={field.db_column_name === "multi_service_id" || field.db_column_name === "multi_provider_accounts" || field.db_column_name === "multi_options"}
                            styles={getDropdownStyles(field.db_column_name)}
                            name={field.db_column_name}
                            className="w-full"
                            options={
                              generalFields.db_column_name !== null &&
                                generalFields &&
                                generalFields.dropdown[field.db_column_name]
                                ? field.db_column_name === "product_type" &&
                                  typeof generalFields.dropdown[field.db_column_name] === "object"
                                  ? Object.keys(generalFields.dropdown[field.db_column_name]).map((key) => ({
                                    label: key,
                                    value: key,
                                  }))
                                  : Array.isArray(generalFields.dropdown[field.db_column_name])
                                    ? generalFields.dropdown[field.db_column_name].map((option: string) => ({
                                      label: option,
                                      value: option,
                                    }))
                                    : []
                                : []
                            }
                            menuPortalTarget={document.body}
                            menuPlacement="auto"
                            menuPosition="fixed"
                            value={getFieldValue(field)}
                            onChange={(value: any) => {
                              if (value === null) {
                                handleInputChange(field.db_column_name, null);
                                if (field.db_column_name === "product_type") {
                                  handleInputChange("tax_class", null);
                                }
                              }
                              else if (Array.isArray(value)) {
                                handleInputChange(field.db_column_name, value.map(v => v.value));
                                if (field.db_column_name === "product_type" && !isTaxClassOverrideEnabled) {
                                  const selectedProductType = value.map(v => v.value)[0];
                                  if (selectedProductType && generalFields.dropdown["product_type"]?.[selectedProductType] && !formValues["tax_class"]) {
                                    handleInputChange("tax_class", generalFields.dropdown["product_type"][selectedProductType]);
                                  }
                                }
                                if (field.db_column_name === "product_type" && !isTaxTypeOverrideEnabled) {
                                  const selectedProductType = value.map(v => v.value)[0];
                                  if (selectedProductType && generalFields.dropdown["product_type_1"]?.[selectedProductType] && !formValues["tax_type"]) {
                                    handleInputChange("tax_type", generalFields.dropdown["product_type_1"][selectedProductType]);
                                  }
                                }
                                if (field.db_column_name === "product_type" && !isPSCodeOverrideEnabled) {
                                  const selectedProductType = value.map(v => v.value)[0];
                                  if (selectedProductType && generalFields.dropdown["product_type_2"]?.[selectedProductType] && !formValues["ps_code"]) {
                                    handleInputChange("ps_code", generalFields.dropdown["product_type_2"][selectedProductType]);
                                  }
                                } 
                              } else {
                                handleInputChange(field.db_column_name, value.value);
                                if (field.db_column_name === "product_type" && !isTaxClassOverrideEnabled) {
                                  const selectedProductType = value.value;
                                  if (selectedProductType && generalFields.dropdown["product_type"]?.[selectedProductType] && !formValues["tax_class"]) {
                                    handleInputChange("tax_class", generalFields.dropdown["product_type"][selectedProductType]);
                                  }
                                }
                                if (field.db_column_name === "product_type" && !isTaxTypeOverrideEnabled) {
                                  const selectedProductType = value.value;
                                  if (selectedProductType && generalFields.dropdown["product_type_1"]?.[selectedProductType] && !formValues["tax_type"]) {
                                    handleInputChange("tax_type", generalFields.dropdown["product_type_1"][selectedProductType]);
                                  }
                                }
                                if (field.db_column_name === "product_type" && !isPSCodeOverrideEnabled) {
                                  const selectedProductType = value.value;
                                  if (selectedProductType && generalFields.dropdown["product_type_2"]?.[selectedProductType] && !formValues["ps_code"]) {
                                    handleInputChange("ps_code", generalFields.dropdown["product_type_2"][selectedProductType]);
                                  }
                                }

                                  if (field.db_column_name === "primary_field") {
                                    handleInputChange("primary_field", value.value);
                                    console.log("Selected primary_field:", value.value);
                                    setSelectedPrimaryField(value.value); // Track selected primary_field
                                  }

                                  // if (field.db_column_name === "product_type" ) {
                                  //   const selectedProductType = value.value;
                                  //   if (selectedProductType && generalFields.dropdown["product_type_2"]?.[selectedProductType] && !formValues["ps_code"]) {
                                  //     handleInputChange("ps_code", generalFields.dropdown["product_type_2"][selectedProductType]);
                                  //   }
                                  // }
                                }
                              }}
                            isClearable
                            isDisabled={
                              isFieldDisabled(field.db_column_name) || (title === "Product" &&
                              [, "tax_type", "tax_class"].includes(field.db_column_name))
                            }
                          />
                          {validationErrors[field.db_column_name] && (
                            <span className="text-red-500">
                              {validationErrors[field.db_column_name]}
                            </span>
                          )}

                          {/* {["tax_class", "tax_type", "ps_code"].includes(field.db_column_name) && title === "Product" && (
                            <>
                              <div className="flex items-center mt-2">
                                <input
                                  type="checkbox"
                                  id={`override_${field.db_column_name}`}
                                  name={`override_${field.db_column_name}`}
                                  className="mr-2"
                                  checked={
                                    field.db_column_name === "tax_class"
                                      ? isTaxClassOverrideEnabled
                                      : field.db_column_name === "tax_type"
                                      ? isTaxTypeOverrideEnabled
                                      : isPSCodeOverrideEnabled
                                  }
                                  onChange={(e) => handleOverrideChange(field.db_column_name, e.target.checked)}
                                />
                                <label htmlFor={`override_${field.db_column_name}`} className="text-sm font-medium">
                                  Override
                                </label>
                              </div>
                              <span className="text-[#B5B5B5]">
                                This {field.display_name} is inherited from the selected Product Type
                              </span>
                            </>
                          )} */}
                        </>
                      )}
                    {field.type === "multi_dropdown" && (
                      <>
                        <AntdSelect
                          mode="multiple"
                          style={{ ...DropdownStyles, width: "100%" }}
                          allowClear
                          showArrow
                          disabled={isFieldDisabled(field.db_column_name)}
                          value={(() => {
                            const fieldValue = getFieldValue(field);
                            if (fieldValue === null || fieldValue === undefined) return [];
                            if (Array.isArray(fieldValue)) {
                              return fieldValue.map(v => typeof v === 'object' ? v.value : v);
                            }
                            return fieldValue?.value ? [fieldValue.value] : (fieldValue ? [fieldValue] : []);
                          })()}
                          options={[]}
                          getPopupContainer={(triggerNode) => triggerNode.parentNode as HTMLElement}
                          maxTagCount={1}
                          maxTagPlaceholder={(omittedValues) => `+${omittedValues.length}`}
                          tagRender={(props) => {
                            const { label, closable, onClose } = props;
                            const labelString = String(label);
                            const truncatedLabel = labelString.length > 190 ? `${labelString.slice(0, 187)}...` : labelString;

                            let allSelectedLabels = '';
                            const fieldValue = getFieldValue(field);
                            if (Array.isArray(fieldValue)) {
                              const fieldOptions =
                                field.db_column_name === "product_type" &&
                                  typeof generalFields.dropdown[field.db_column_name] === "object"
                                  ? Object.keys(generalFields.dropdown[field.db_column_name]).map((key) => ({
                                    label: key,
                                    value: key,
                                  }))
                                  : Array.isArray(generalFields.dropdown[field.db_column_name])
                                    ? generalFields.dropdown[field.db_column_name].map((option: string) => ({
                                      label: option,
                                      value: option,
                                    }))
                                    : [];
                              allSelectedLabels = fieldValue
                                .map((value: any) => {
                                  const valueStr = typeof value === 'object' ? value.value : value;
                                  const option = fieldOptions.find((opt: any) => opt.value === valueStr);
                                  return option?.label || valueStr;
                                })
                                .join(", ");
                            } else if (fieldValue && typeof fieldValue === 'object') {
                              allSelectedLabels = fieldValue.label || '';
                            }

                            return (
                              <span
                                className="inline-flex items-center px-1 py-1 overflow-hidden whitespace-nowrap bg-white shadow-lg rounded-lg max-w-[185px]"
                                title={allSelectedLabels}
                              >
                                {truncatedLabel}
                                {closable && (
                                  <CloseOutlined
                                    onClick={onClose}
                                    style={{ marginLeft: 4, cursor: 'pointer', color: 'black' }}
                                  />
                                )}
                              </span>
                            );
                          }}
                          dropdownRender={(menu) => {
                            const rawOptions =
                              generalFields.db_column_name !== null &&
                                generalFields &&
                                generalFields.dropdown[field.db_column_name]
                                ? field.db_column_name === "product_type" &&
                                  typeof generalFields.dropdown[field.db_column_name] === "object"
                                  ? Object.keys(generalFields.dropdown[field.db_column_name]).map((key) => ({
                                    label: key,
                                    value: key,
                                  }))
                                  : Array.isArray(generalFields.dropdown[field.db_column_name])
                                    ? generalFields.dropdown[field.db_column_name].map((option: string) => ({
                                      label: option,
                                      value: option,
                                    }))
                                    : []
                                : [];

                            const filteredOptions = rawOptions.filter((opt: { label: string; }) =>
                              opt.label.toLowerCase().includes(searchValue.toLowerCase())
                            );

                            return (
                              <div className="bg-white shadow-lg rounded-lg dark-theme-select" style={{ maxHeight: "300px" }}>
                                <div style={{ padding: "4px 8px" }}>
                                  <Input
                                    placeholder="Search..."
                                    value={searchValue}
                                    onChange={(e) => {
                                      e.stopPropagation(); // Prevent event bubbling
                                      setSearchValue(e.target.value);
                                    }}
                                    onKeyDown={(e) => {
                                      e.stopPropagation(); // Prevent key events from affecting the select
                                    }}
                                    size="middle"
                                  />
                                </div>
                                <div style={{ maxHeight: "250px", overflowY: "auto" }}>
                                  <VirtualList
                                    data={filteredOptions}
                                    height={250}
                                    itemHeight={0}
                                    itemKey="value"
                                  >
                                    {(item) => {
                                      const fieldValue = getFieldValue(field);
                                      const isChecked = Array.isArray(fieldValue)
                                        ? fieldValue.some(v => (typeof v === 'object' ? v.value === item.value : v === item.value))
                                        : fieldValue?.value === item.value || fieldValue === item.value;

                                      // Helper function to determine option type (BP or AMOP)
                                      const getOptionType = (optionValue: string) => {
                                        // Check only after the last "--" separator
                                        const parts = optionValue.split('--');
                                        if (parts.length > 1) {
                                          const lastPart = parts[parts.length - 1].trim().toUpperCase();
                                          if (lastPart === 'BP') {
                                            return 'BP';
                                          } else if (lastPart === 'AMOP') {
                                            return 'AMOP';
                                          }
                                        }
                                        return 'OTHER';
                                      };

                                      // Check if this option should be disabled for Service Type
                                      const isServiceType = title === "service type" || field.display_name?.toLowerCase().includes('service');
                                      const shouldDisableOption = isServiceType && (() => {
                                        const currentValues = Array.isArray(fieldValue)
                                          ? fieldValue.map(v => typeof v === 'object' ? v.value : v)
                                          : fieldValue
                                            ? [typeof fieldValue === 'object' ? fieldValue.value : fieldValue]
                                            : [];
                                        
                                        if (currentValues.length === 0) return false;
                                        
                                        const currentType = getOptionType(currentValues[0]);
                                        const itemType = getOptionType(item.value);
                                        
                                        return currentType !== 'OTHER' && itemType !== 'OTHER' && currentType !== itemType;
                                      })();

                                      return (
                                        <div key={item.value} className="ml-2 mb-2 flex items-center">
                                          <Checkbox
                                            checked={isChecked}
                                            disabled={shouldDisableOption}
                                            onChange={(e) => {
                                              e.stopPropagation(); // Prevent event bubbling
                                              const currentValues = Array.isArray(fieldValue)
                                                ? fieldValue.map(v => typeof v === 'object' ? v.value : v)
                                                : fieldValue
                                                  ? [typeof fieldValue === 'object' ? fieldValue.value : fieldValue]
                                                  : [];

                                              if (e.target.checked) {
                                                // For Service Type, if selecting different type, clear existing and add new
                                                if (isServiceType && currentValues.length > 0) {
                                                  const currentType = getOptionType(currentValues[0]);
                                                  const newType = getOptionType(item.value);
                                                  
                                                  if (currentType !== 'OTHER' && newType !== 'OTHER' && currentType !== newType) {
                                                    handleInputChange(field.db_column_name, [item.value]);
                                                  } else {
                                                    handleInputChange(field.db_column_name, [...currentValues, item.value]);
                                                  }
                                                } else {
                                                  handleInputChange(field.db_column_name, [...currentValues, item.value]);
                                                }
                                              } else {
                                                handleInputChange(
                                                  field.db_column_name,
                                                  currentValues.filter(v => v !== item.value)
                                                );
                                              }
                                            }}
                                            className="mr-2"
                                          />
                                          <span className={shouldDisableOption ? 'text-gray-400' : ''}>
                                            {item.label}
                                          </span>
                                        </div>
                                      );
                                    }}
                                  </VirtualList>
                                </div>
                              </div>
                            );
                          }}
                          onDropdownVisibleChange={(open) => {
                            if (!open) {
                              // Clear search term when dropdown closes
                              setSearchValue("");
                            }
                          }}
                          onChange={(value) => {
                            // Only handle changes that come from actual selection changes, not search clearing
                            if (Array.isArray(value)) {
                              handleInputChange(field.db_column_name, value.length === 0 ? null : value);
                              if (field.db_column_name === "product_type" && value.length === 0) {
                                handleInputChange("tax_class", null);
                              }
                            } else if (value === undefined || value === null) {
                              // Only clear if this is an intentional clear action (like clicking the clear button)
                              handleInputChange(field.db_column_name, null);
                              if (field.db_column_name === "product_type") {
                                handleInputChange("tax_class", null);
                              }
                            }
                          }}
                        />

                        {validationErrors[field.db_column_name] && (
                          <span className="text-red-500">
                            {validationErrors[field.db_column_name]}
                          </span>
                        )}
                      </>
                    )}
                      {field.type === "editable_dropdown" && (
                        <>
                          <Select
                            isMulti={field.db_column_name === "multi_service_id" || field.db_column_name === "multi_provider_accounts" || field.db_column_name === "multi_options"}
                            styles={{
                              ...DropdownStyles,
                              menuPortal: (base) => ({ ...base, zIndex: 9999 }),
                            }}
                            name={field.db_column_name}
                            className="w-full"
                            options={
                              Array.isArray(generalFields.dropdown[field.db_column_name])
                                ? generalFields.dropdown[field.db_column_name].map((option: string) => ({
                                  label: option,
                                  value: option,
                                }))
                                : []
                            }
                            menuPortalTarget={document.body}
                            menuPlacement="auto"
                            menuPosition="fixed"
                            value={formValues[field.db_column_name]
                              ? Array.isArray(formValues[field.db_column_name])
                                ? formValues[field.db_column_name].map((item: string) => ({
                                  label: item,
                                  value: item,
                                }))
                                : { label: formValues[field.db_column_name], value: formValues[field.db_column_name] }
                              : []}
                            onChange={(value: any) => {
                              if (value === null) {
                                handleInputChange(field.db_column_name, null);
                              } else if (Array.isArray(value)) {
                                handleInputChange(field.db_column_name, value.map(v => v.value));
                              } else {
                                handleInputChange(field.db_column_name, value.value);
                              }
                            }}
                            isClearable
                          />
                          {validationErrors[field.db_column_name] && (
                            <span className="text-red-500">
                              {validationErrors[field.db_column_name]}
                            </span>
                          )}
                        </>
                      )}
                      {field.type === "date_range" && (
                        <>
                          <RangePicker
                            style={{ marginLeft: "2px", marginRight: "5px", height: "43px" }}
                            name={field.db_column_name}
                            className="w-full"
                            getPopupContainer={(trigger) => trigger.parentElement!}
                            value={formValues[field.db_column_name] || null}
                            onChange={(dates) =>
                              handleInputChange(field.db_column_name, dates)
                            }
                            format="MM-DD-YY"
                          />
                          {validationErrors[field.db_column_name] && (
                            <span className="text-red-500">
                              {validationErrors[field.db_column_name]}
                            </span>
                          )}
                        </>
                      )}
                      {field.type === 'date' && (
                        <>
                          <DatePicker
                            value={
                              formValues[field.db_column_name]
                                ? dayjs(formValues[field.db_column_name])
                                : null
                            }
                            onChange={(date, dateString) =>
                              handleInputChange(field.db_column_name, dateString)
                            }
                            format="MM-DD-YY"
                            className="input"
                            disabledDate={(current) => {
                              if (field.db_column_name === 'billing_cycle_range') {
                                return current.date() >= 29;
                              } else if (field.db_column_name === 'inactivity_start') {
                                return current && current < dayjs().startOf('day');
                              }
                              return false;
                            }}
                            // disabled={field.db_column_name === "billing_cycle_range" ? formValues["btn_provider"] : ""}
                          />
                          {validationErrors[field.db_column_name] && (
                            <span className="text-red-500">{validationErrors[field.db_column_name]}</span>
                          )}
                        </>
                      )}
                    </div>
                  ))}
                </div>
              {showBuiltinFields && builtinFields.length > 0 && (
                <div className="mt-6">
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="popup-heading !pl-0">Built-in Fields</h3>
                    <button
                      onClick={handleCloseBuiltinFields}
                      className="text-red-500 hover:text-red-700 p-1"
                      title="Close Built-in Fields"
                    >
                      <X size={20} />
                    </button>
                  </div>
                  <div className="mb-4">
                    <AntdSelect
                      mode="multiple"
                      className="w-full sm:w-1/2 md:w-1/3"
                      allowClear
                      showArrow
                      showSearch
                      placeholder="Select fields"
                      value={tempSelectedFields}
                      open={dropdownOpen}
                      onDropdownVisibleChange={(open) => setDropdownOpen(open)}
                      options={builtinFields
                        .filter(field => !selectedFields.some(selected => selected.db_column_name === field.db_column_name))
                        .map(field => ({
                          label: field.display_name,
                          value: field.db_column_name,
                          type: field.type,
                          disabled: field.db_column_name.toLowerCase() === selectedPrimaryField?.toLowerCase(), // Case-insensitive comparison
                        }))}
                      getPopupContainer={(triggerNode) => triggerNode.parentNode as HTMLElement}
                      maxTagCount={0}
                      dropdownRender={(menu) => (
                        <div
                          className="relative bg-white shadow-lg rounded-lg max-w-full dark-theme-select"
                          style={{ overflowY: "auto", zIndex: 10000 }}
                        >
                          {/* Add Search Input */}
                          <div className="p-2 border-b">
                            <Input
                              placeholder="Search..."
                              value={searchTerm}
                              onChange={(e) => setSearchTerm(e.target.value)}
                              className="w-full"
                            />
                          </div>
                          <VirtualList
                            data={builtinFields
                              .filter(field =>
                                !selectedFields.some(selected => selected.db_column_name === field.db_column_name) &&
                                field.display_name.toLowerCase().includes(searchTerm.toLowerCase())
                              )}
                            height={250}
                            itemHeight={0}
                            itemKey="db_column_name"
                          >
                            {(item) => {
                              const isChecked = tempSelectedFields.includes(item.db_column_name);
                              const isDisabled = item.db_column_name.toLowerCase() === selectedPrimaryField?.toLowerCase();
                              //  console.log(isDisabled,selectedPrimaryField, item.db_column_name,"is disabled....");
                              return (
                                <div key={item.db_column_name} className="ml-2 mb-2 flex items-center">
                                  <Checkbox
                                    checked={isChecked}
                                    disabled={isDisabled} // Disable if it matches primary_field
                                    onChange={(e) => {
                                      if (e.target.checked) {
                                        setTempSelectedFields(prev => [...prev, item.db_column_name]);
                                      } else {
                                        setTempSelectedFields(prev => prev.filter(val => val !== item.db_column_name));
                                      }
                                    }}
                                    className="mr-2"
                                  />
                                  {item.display_name}
                                </div>
                              );
                            }}
                          </VirtualList>
                          <div className="flex justify-between p-2 border-t">
                            <button
                              className="save-btn mr-2 !min-w-[70px]"
                              onClick={handleOkFields}
                            >
                              OK
                            </button>
                            <button
                              className="cancel-btn !min-w-[70px]"
                              onClick={handleCancelFields}
                            >
                              Cancel
                            </button>
                          </div>
                        </div>
                      )}
                      onChange={(value) => setTempSelectedFields(value)}
                    />
                  </div>
                  {selectedFields.length > 0 && (
                    <div className="mt-4">
                      <h4 className="text-sm font-medium mb-2">Selected Fields</h4>
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                        {selectedFields.map((field, index) => (
                          <div key={index} className="flex items-center justify-between p-2 rounded builtin-field">
                            {editIndex === index ? (
                              <div className="flex items-center space-x-2">
                                <Input
                                  value={editValue}
                                  onChange={handleEditChange}
                                  className="input"
                                  placeholder="Edit field name"
                                />
                                <button
                                  className="text-green-500 hover:text-green-700"
                                  onClick={() => handleEditSave(index)}
                                >
                                  Save
                                </button>
                                <button
                                  className="text-red-500 hover:text-red-700"
                                  onClick={() => setEditIndex(null)}
                                >
                                  Cancel
                                </button>
                              </div>
                            ) : (
                              <>
                                <span>{field.display_name}</span>
                                <div className="flex space-x-2">
                                  <EditOutlined
                                    className="text-blue-500 cursor-pointer"
                                    onClick={() => handleEditField(index)}
                                  />
                                  <DeleteOutlined
                                    className="text-red-500 cursor-pointer"
                                    onClick={() => handleDeleteField(index)}
                                  />
                                </div>
                              </>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}
              {(showCustomIdentifier || formValues["primary_field"] === "Custom") && (
                <div className="mt-6">
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="popup-heading !pl-0">Add Custom Identifier <span className="text-red-500">*</span></h3>
                    
                  </div>
                  <div className="mb-4 flex items-center space-x-2">
                    <Input
                      type="text"
                      value={newIdentifierName}
                      onChange={handleCustomIdentifierChange}
                      placeholder="Enter Custom Identifier"
                      className="input !w-[300px]"
                    />
                   
                  </div>
                  {identifierError && (
                    <div className="text-red-500 text-sm mb-2">{identifierError}</div>
                  )}
                 
                </div>
              )}
              {showCustomFields && (
                <div className="mt-6">
                  <div className="flex justify-between items-center mb-2">
                    <h3 className="popup-heading !pl-0">Custom Fields</h3>
                    <button
                      onClick={handleCloseCustomFields}
                      className="text-red-500 hover:text-red-700 p-1"
                      title="Close Custom Fields"
                    >
                      <X size={20} />
                    </button>
                  </div>
                  <div className="mb-4 flex items-center space-x-2">
                    <Input
                      type="text"
                      value={newFieldDisplayName}
                      onChange={handleCustomFieldChange}
                      placeholder="Enter field name"
                      className="input !w-[300px]"
                    />
                    <PlusCircleIcon
                      onClick={handleAddCustomField}
                      className="w-6 h-6 text-green-500 cursor-pointer"
                    />
                  </div>
                  {error && (
                    <div className="text-red-500 text-sm mb-2">{error}</div>
                  )}
                  {customFields.length > 0 && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
                      {customFields.map((field, index) => (
                        <div key={index} className="flex items-center justify-between p-2 rounded builtin-field">
                          <span>{field}</span>
                          <MinusCircleIcon
                            className="w-6 h-6 text-red-500 cursor-pointer"
                            onClick={() => handleDeleteCustomField(index)}
                          />
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </form>
          </div>
          ) : (
                 <div className="flex justify-center items-center w-full h-full absolute top-0 left-0">
                  <Spin size="large" />
                </div>
                )}
      </Modal>
      <Modal
        title="Confirmation"
        open={isConfirmationOpen}
        onCancel={handleCancelConfirmation}
        centered
        style={{ zIndex: 10000 }}
        width={400}
        footer={
          <div className="justify-center flex space-x-2 mt-5">
            <button onClick={handleCancelConfirmation} className="cancel-btn">
              Cancel
            </button>
            <button   onClick={handleConfirmCreate} className="save-btn">
              Ok    
            </button>
          </div>
        }
        >
        <p>Are you sure you want to create this {title
          .split(" ")
          .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
          .join(" ")}</p>
      </Modal>
    </div>
  );
};

export default CreateModal;

// want add a function to the drop down to select all options in the multi select