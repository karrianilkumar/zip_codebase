import React, { useCallback, useEffect, useState } from "react";
import { Modal, Spin } from "antd";
import EditableTableComponent from "../killbill_components/editable_table_component";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useCustomerProfileStore } from "../killbill_stores/customer_profile_store";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { useAuth } from "@/app/components/auth_context";

interface TaxesModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave?: () => void;
  row: any; 
}

const TaxesModal: React.FC<TaxesModalProps> = ({
  isOpen,
  onClose,
  onSave,
  row,
}) => {
    const [loading, setLoading] = useState(true);
    const [headers, setHeaders] = useState<any[]>([]);
    const [headerMap, setHeaderMap] = useState<any>({});
    const [pagination, setPagination] = useState<any>({});
    const [tableData, setTableData] = useState<any>([]);
    const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
    const { username, partner, role, token, selectedDb,metaData,selectedBillingDb, sessionId, settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId, firstLastName, setStoredPagination, setAdvancedStoredPagination } = useAuth();
    const accountNumber = useCustomerProfileStore((state) => state.accountNumber);
    const [totalAmount, setTotalAmount] = useState<any>(0);
    
   
      type HeaderMap = Record<string, [string, number]>;
      const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
        const entries = Object.entries(headerMap) as [string, [string, number]][];
        entries.sort((a, b) => a[1][1] - b[1][1]);
        return Object.fromEntries(entries) as HeaderMap;
      }, []);
      
    const fetchTaxesData = async () => {
        setLoading(true);
         settabledata([])
    setStoredPagination(null);
    setAdvancedStoredPagination(null);

    let parsedData: any;
    try {
      console.log("row...",row)
      const type = row?.type || null
      setLoading(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_taxes_unposted",
        account_number: accountNumber,
        role_name: role,
        row_id: row?.row_id || row?.id || "",
        parent_module: "Billing Platform",
        module_name:  "Billing and Collections Taxes",
        table_name: type && (type==="Bill" || type==="Reverse Bill")?"customer_bills":"customer_charges",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
...metaData,
billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        feature_module_name: "Billing and Collections Taxes",
        main_module_name: 'Customer Profiles',
        mod_pages: {
          start: 0,
          end: 15,
        },
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)
      // setModalData(parsedData)
      if (parsedData.flag === true) {
        // console.log("table response:", parsedData?.data?.basic_details_deposits);
        setLoading(false);

        setTimeout(() => {
          const headersMap_ = parsedData?.header_map?.["Billing and Collections Taxes"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);
        //   console.log("parsedData", parsedData)
          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
        //   console.log("headers", headers_)
          setHeaders(headers_);
          setVisibleColumns(headers_);
          setTableData(parsedData?.data?.billing_collections_taxes || []);
          calculateTotalAndQuantity(parsedData?.data?.billing_collections_taxes || []);
          setPagination(parsedData?.pages || {});
          setTotalAmount(parsedData?.total_amount || 0)
        }, 0);
      } else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
    }
    const calculateTotalAndQuantity = (data: any[]) => {
      return {
        quantity: data.length,
        total_rate: data.reduce((sum, item) => sum + Number(item.Amount || 0), 0),
      };
    };
    const totals = calculateTotalAndQuantity(tableData);

     useEffect(() => {
        fetchTaxesData();
    } , [isOpen, row]);
    
  return (
    <Modal
      open={isOpen}
      onCancel={onClose}
      title="Taxes"
      centered
      width={1000}
      bodyStyle={{
        height: "auto",
        overflowY: "auto",
      }}
      footer={
        
        <div className="flex flex-col justify-start items-start gap-2">
          <p><strong>Quantity: {pagination?.total || "0"} </strong></p>
          <p><strong>Total: {`$${totalAmount}`}</strong></p>

        </div>
      }
    >
      <div>
        {/* <div className="flex items-center justify-end mb-2">
          <button className="save-btn !p-2" onClick={onAddTax}>
            Add Tax
          </button>
        </div> */}

        {loading ? (
          <div
            className="flex justify-center items-center overflow-y-auto"
            style={{ height: "270px" }}
          >
            <Spin size="large" />
          </div>
        ) : (
          <EditableTableComponent
            headers={headers}
            headerMap={headerMap}
            initialData={tableData}
            visibleColumns={visibleColumns}
            itemsPerPage={15}
            popupHeading="Taxes"
            pagination={pagination}
            height={340}
            row={row|| null}
            // setUpdatedTableData={setUpdatedTableData}
          />
        )}
      </div>
    </Modal>
  );
};

export default TaxesModal;
