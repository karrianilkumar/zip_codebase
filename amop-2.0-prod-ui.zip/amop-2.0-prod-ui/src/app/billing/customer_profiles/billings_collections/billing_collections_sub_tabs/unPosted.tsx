/* eslint-disable react-hooks/exhaustive-deps */
"use client";

import React, {
  useEffect,
  useState,
  lazy,
  Suspense,
  useRef,
  useCallback,
} from "react";
import { ArrowDownTrayIcon, ArrowPathIcon, ArrowUturnLeftIcon, PlusIcon } from "@heroicons/react/24/outline";
import { Modal, Spin, DatePicker, notification, Input } from "antd";
import Dropdown from "../../../killbill_components/dropdownComponent";

import { useAuth } from "../../../../components/auth_context";
import axios from "axios";
// import { getCurrentDateTime } from "@/app/components/header_constants";
import { getCurrentDateTime } from "../../../../components/header_constants";
import dayjs, { Dayjs } from "dayjs";
import { useFeatureStore } from "../../../../sim_management/inventory/featureStore";
import * as XLSX from "xlsx";
// import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { ENV_ROUTES } from "../../../../components/routes/route_constants";
import { exportLoadingStore } from "../../../../stores/ExportLoadingStore";
import CreateModal from "../../../killbill_components/createpopup";
import { PlusCircleOutlined, SyncOutlined, UnderlineOutlined, UndoOutlined } from "@ant-design/icons";
import { useCustomerProfileStore } from "@/app/billing/killbill_stores/customer_profile_store";
import { debounce } from "lodash";
import { useLogoStore } from "@/app/billing/killbill_stores/logo_store";
import { PlusCircle, PlusCircleIcon } from "lucide-react";
type ExportData = {
  path: string;
  username: string | null;
  module_name: string;
  request_received_at: string;
  start_date: string;
  end_date: string;
  Partner: string | null;
  access_token: string | null;
  db_name: string | null;
};
const KillbillTableComponent = lazy(
  () => import("../../../killbill_components/table__component")
);
// const CreateModal = lazy(() => import("@/app/components/createPopup"));
const ColumnFilter = lazy(() => import("../../../../components/columnfilter"));
const WholeTableSearch = lazy(() => import("../../../killbill_components/whole__search"));
const AdvancedMultiFilter2 = lazy(
  () => import("../../../killbill_components/advanced__search")
);
interface UnpostedProps {
  row?: any;
 
}
interface CreateBillModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentCycle: string;
  onCreate: (dueDate: Dayjs | null) => void; 
  dueDate: Dayjs | null;
}
const UnPosted: React.FC <UnpostedProps>= ({row}) => {
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, token, selectedDb,metaData,selectedBillingDb, sessionId, settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId, firstLastName , setStoredPagination , setAdvancedStoredPagination,combineAdnvaceStoredpagination,setCombineAdnvaceStoredpagination} = useAuth();
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([
    null,
    null,
  ]);
  const [loading, setLoading] = useState(false);
  // const [exportLoading, setExportLoading] = useState(false);
  const { addExport, removeExport } = exportLoadingStore();
  const exportKey = "Inventory";
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [isCreateModalOpen, setCreateModalOpen] = useState(false);
  const [createModalData, setcreateModalData] = useState<any[]>([]);
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
  const [generalFields, setgeneralFields] = useState<any[]>([])
  const [ReverseRowData, setReverseRowData] = useState<any[]>([]);
  const { accountNumber, BillId, setBillId , setUserProfileDetails } = useCustomerProfileStore();
  const [isCreateBillModalOpen, setCreateBillModalOpen] = useState(false);
  const [isApplyToBillModalOpen, setApplyToBillModalOpen] = useState(false);
  const [currentCycle, setCurrentCycle] = useState("");
  const [dueDate, setDueDate] = useState<Dayjs | null>(null);
  const [unpostedTotalCharge, setUnpostedTotalCharge] = useState(0);
  const [accountStatus , setAccountStatus] = useState(false);


  const hasFetchedData = useRef(false);
  const {
    iccid,
    bulkRow,
    features: moduleFeatures,
    setFeatures: setModuleFeatures,
    setICCID,
    setBulkRow
  } = useFeatureStore();
  // const queryClient = useQueryClient();

  type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);


  const fetchData = async () => {
    settabledata([]);
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    setSearchTerm("");
    setShowAdvanced(false)
    setCombineAdnvaceStoredpagination(null)
    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/unposted_bills_list_view",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing and Collections Unposted",
        // sub_module:"Services",
        mod_pages: {
          start: 0,
          end: 100,
        },
        table_name:"customer_charges",
        account_number:accountNumber,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        tenant_id: tenant_id_,
        sessionID: sessionId,
        feature_module_name: "Billing and Collections Unposted",
        main_module_name: "Customer Profiles",
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)

      if (parsedData.flag === true) {
        setLoading(false);
        // Defer other state updates using a timeout to decouple them from the main thread
        setUserProfileDetails(parsedData?.user_profile_details || {});

        setTimeout(() => {
          const unposted_total_charge_ = parsedData?.unposted_total_charge || 0;
          setUnpostedTotalCharge(unposted_total_charge_);
          const headersMap_ = parsedData?.header_map?.["Billing and Collections Unposted"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);
          const current_cycle_ = parsedData?.current_cycle || '';
        console.log("current_cycle_", current_cycle_);
        setCurrentCycle(current_cycle_);
        setDueDate(parsedData?.due_date_of_this_bill ? dayjs(parsedData.due_date_of_this_bill) : null);
          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
          console.log("headers", headers_)
          setHeaders(headers_);
          setVisibleColumns(headers_);
          const generalFields_ = parsedData || {}
          setgeneralFields(generalFields_)
          console.log("generalFields_",generalFields_)
          setFeatures(parsedData?.header_map?.["Billing and Collections Unposted"]?.module_features || []);
          setModuleFeatures(parsedData?.header_map?.["Billing and Collections Unposted"]?.module_features || []);
          const featres_ = parsedData?.header_map?.["Billing and Collections Unposted"]?.module_features || []
          if(parsedData?.account_status){
             const allowedActions_:any=[]
          if(featres_.includes("Edit-Billing Services")){
            allowedActions_.push("edit")
          }
          // if(featres_.includes("Delete-Billing Services")){
          //   allowedActions_.push("delete")
          // }
          if(featres_.includes("Copy-Billing Services")){
            allowedActions_.push("copy")
          }
          if(featres_.includes("Discontinue-Billing Services")){
            allowedActions_.push("deactivate")

          }
          
          setAllowedActions(allowedActions_)
          }
          else{
            setAllowedActions([])
          }
           setAccountStatus(parsedData?.account_status || "");
          const createModalData_=parsedData?.header_map?.["Billing and Collections Unposted"]?.pop_up||[]
          console.log("createModalData_",createModalData_)
          setcreateModalData(createModalData_)
          setPagination(parsedData?.pages || {});
          setTableData(parsedData?.data?.billing_and_collections_unposted || []);

         
        }, 0);
        
      } else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
  const handleCreateModalOpen = () => {
    setCreateModalOpen(true);
  };

  const handleCreateModalClose = () => {
    setCreateModalOpen(false);
  };

  const handleCreateRow = () => {
    handleCreateModalClose();
  };
  useEffect(() => {
    if (!hasFetchedData.current) {
      fetchData();
      hasFetchedData.current = true;
    }
  }, [partner]);
  const handleReverseTransaction = async () => {
    
    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
    const tenant_id_ = localStorage.getItem("tenant_id") || "0";

      setReverseRowData((prevReverseRowData) => { 
        if (!Array.isArray(prevReverseRowData)) return []; 
  
        console.log("Previous row data:", prevReverseRowData);
  
        const updatedData = prevReverseRowData.map((row, index) => ({
          ...row, 
          is_active: false, 
          is_deleted: true
        }));
  
        console.log("Updated ReverseRowData:", updatedData);
        return updatedData;
      });
  
      // ✅ Use a separate variable to store the modified data
      const updatedReverseRowData = ReverseRowData.map(row => ({
        ...row, 
        is_active: false, 
        is_deleted: true
      }));
      
      
      
      
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/unposted_reverse_transaction",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing and Collections Unposted",
        // sub_module:"Services",
        mod_pages: {
          start: 0,
          end: 100,
        },
        changed_data:updatedReverseRowData,
        account_number:accountNumber,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: 'billing_platform',
        billing_db_name: selectedBillingDb,
        ...metaData,
        table_name:'customer_charges',
        sessionID: sessionId,
        tenant_id: tenant_id_,
        feature_module_name: "Billing and Collections Unposted",
        main_module_name: "Customer Profiles",
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)

      if (parsedData.flag === true) {
         notification.success({
                    message: 'Success',
                    description: parsedData.message,
                    placement: 'top',
                  });
        await fetchData();
        setLoading(false);


        
      } else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
  const exportToExcel = (headers: any, rowData: any, fileName = 'exported_data.xlsx') => {
    // Map the rowData to an array of objects with headers as keys
    const formattedData = rowData.map((row: any) => {
      const formattedRow: any = {};
      headers.forEach((header: any) => {
        formattedRow[header] = row[header] !== undefined ? row[header] : null;
      });
      return formattedRow;
    });

    // Create a new worksheet from the formatted data
    const worksheet = XLSX.utils.json_to_sheet(formattedData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');

    // Write the workbook and trigger download
    XLSX.writeFile(workbook, fileName);
  };

  const handleFilter = useCallback((advancedFilters: any) => {
    console.log(advancedFilters);
    setAdvancedFilters(advancedFilters)
  }, []);

  const handleReset = useCallback((EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  }, []);

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "normal",
    padding: "16px",
  };

  const handleExportModalOpen = () => {
    setExportModalOpen(true);
  };

  const handleExportModalClose = () => {
    setExportModalOpen(false);
    console.log("Modal closed, resetting date range.");
  };

  
  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }

  const ExportWithoutSearch = async () => {
  
    try {
      // Add the export to the store
      // addExport(exportKey, "Inventory");
  
      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Request timed out"));
          }, timeout);
  
          promise
            .then((res) => {
              clearTimeout(timer);
              resolve(res);
            })
            .catch((err) => {
              clearTimeout(timer);
              reject(err);
            });
        });
      };
  
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/unposted_export",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing and Collections Unposted",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        account_number:accountNumber,
        table_name:"customer_charges",
        db_name: selectedDb,
        sessionID: sessionId,
        billing_db_name: selectedBillingDb,
        ...metaData,
        feature_module_name: "Billing and Collections Unposted",
        start_date: getFirstDayOfCurrentMonth(),
        end_date: getLastDayOfCurrentMonth(),
        killbill_flag:"True",
        main_module_name: "Customer Profiles",
      };
  
      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000);
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }
  
      // Wait for 20 seconds before polling
      await new Promise((resolve) => setTimeout(resolve, 20000));
  
      const export_url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const export_data = {
        ...data,
        path: "/get_export_status",
      };
  
      const pollExportStatus = async () => {
        try {
          const export_response = await axios.post(export_url, { data: export_data });
          const export_parsedData = JSON.parse(export_response.data.body);
  
          if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
            const s3Url = export_parsedData?.export_status_data?.url || null;
            if (s3Url) {
              // window.location.href = s3Url;
              // notification.success({
              //   message: "Success",
              //   description: "Successfully exported the  record!",
              //   style: messageStyle,
              //   placement: "top",
              // });
              fetch(s3Url)
              .then(response => response.blob())
              .then(blob => {
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'Billing and Collections Unposted.xlsx';
                a.click();
                a.remove();
                window.URL.revokeObjectURL(url);
                notification.success({
                  message: "Success",
                  description: "Successfully exported the record!",
                  style: messageStyle,
                  placement: "top",
                });
              })
              .catch((err) => {
                console.log("error", err)
                Modal.error({
                  title: "Export Error",
                  content: "An error occurred while exporting data. Please try again.",
                  centered: true,
                });
              });
            } else {
              Modal.error({
                title: "Export Error",
                content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            }
            return true; // Stop polling
          }
  
          if (export_parsedData?.export_status_data?.status_flag === "Failure") {
            Modal.error({
              title: "Export Error",
              content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
              centered: true,
            });
            return true; // Stop polling
          }
          if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
                      Modal.error({
                        title: "Export Error",
                        content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
                        centered: true,
                      });
                      return true; // Stop polling
                    }
          return false; // Continue polling
        } catch (error) {
          Modal.error({
            title: "Export Error",
            content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
            centered: true,
          });
          return true; // Stop polling
        }
      };
  
      const startPolling = async () => {
        let isPollingComplete = false;
  
        while (!isPollingComplete) {
          isPollingComplete = await pollExportStatus();
          if (!isPollingComplete) {
            await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
          }
        }
      };
  
      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      // removeExport(exportKey); // Remove the export from the store
    }
  };
  


  const handleExport = async (key: string, heading: string) => {
  
    try {
      addExport(key, heading);
  
      let parsedData;
      let url;
      let data: any;
      let response;
  
      if(combineAdnvaceStoredpagination){
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          account_number:accountNumber,
          path: "/search_export",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedBillingDb,
          sessionID: sessionId,
          index_name: "Unposted",
          module_name: "Billing and Collections Unposted",
          // col_sort:{charge_description: "ASC"}
        };
        console.log("combineAdnvaceStoredpagination",data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
      else if  (advancedStoredpagination && !storedpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name: "Unposted",
          module_name: "Billing and Collections Unposted",
          pages: { start: 0, end: 100 },
          partner,
          account_number:accountNumber,
          db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
          // col_sort:{charge_description: "ASC"},
          username: username,

        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } 
      else if (storedpagination && !advancedStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "Unposted",
          module_name: "Billing and Collections Unposted",
          search: "whole",
          pages: { start: 0, end: 100 },
          partner,
          account_number:accountNumber,
          db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
          // col_sort:{charge_description: "ASC"},
          username: username,
          
        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } else {
        await ExportWithoutSearch();
        return;
      }
  
      if (parsedData.flag) {
        const s3Url = parsedData?.download_url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the  record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
            .then(response => response.blob())
            .then(blob => {
              const url = window.URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'Billing and Collections Unposted.xlsx';
              a.click();
              a.remove();
              window.URL.revokeObjectURL(url);
              notification.success({
                message: "Success",
                description: "Successfully exported the record!",
                style: messageStyle,
                placement: "top",
              });
            })
            .catch((err) => {
              console.log("error", err)
              Modal.error({
                title: "Export Error",
                content: "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            });
        } else {
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      } else {
        Modal.error({
          title: "Export Error",
          content: parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      removeExport(key);
    }
  };
  

  const downloadBlob = (base64Blob: string) => {
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    const blobObject = new Blob([byteArray], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blobObject);
    link.download = "Inventory.xlsx";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleCreateBillModalOpen = () => {
  setCreateBillModalOpen(true);
};
const handleApplytoBillModalOpen = () => {
    const hasNonCredit = ReverseRowData.some((row: any) => row.category !== "Credit");

  if (hasNonCredit) {
    Modal.error({
      title: "Invalid Operation",
      content: "Apply to Bill is only applicable for Credit entries.",
      centered: true,
    });
    return;
  }


  setApplyToBillModalOpen(true);
  };

  const handleCreateBillModalClose = () => {
  setCreateBillModalOpen(false);
};

const handleCreateBill = async (dueDate: Dayjs | null) => { 
   setLoading(true)

    // Extract only the IDs from ReverseRowData
    const updatedReverseRowData = ReverseRowData.map(row => row.id);
    console.log("Selected charge IDs:", updatedReverseRowData);

  const payload = {
    current_cycle: currentCycle,
    due_date: dueDate && dayjs(dueDate).isValid() ? dayjs(dueDate).format('MM-DD-YYYY') : null,
    selected_charge_ids : updatedReverseRowData,
    // Add any other necessary fields here
  };

  try {
    const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
    const tenant_id_ = localStorage.getItem("tenant_id") || "0";
    const response = await axios.post(url, {
      data: {
        ...payload,
        path: "/bill_creation_from_unposted_charges",
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing and Collections Unposted",       
        table_name:"customer_charges",
        account_number:accountNumber,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        tenant_id:tenant_id_,
        feature_module_name: "Billing and Collections Unposted",
        main_module_name: "Customer Profiles",

      },
    });

    const parsedData = JSON.parse(response.data.body);
    if (parsedData.flag) {
      notification.success({
        message: "Success",
        description: "Bill created successfully!",
         style: messageStyle,
        placement: "top",
      });
      setLoading(false)

       fetchData(); // Refresh data after creating the bill
       handleCreateBillModalClose();
       const resp = JSON.parse(response?.data?.body || "{}");
      //  const invoiceData = resp.pdf_data?.data ? JSON.parse(resp.pdf_data.data) : {};
      //   console.log("PDF Data:", invoiceData);
      //   const { logoUrl } = useLogoStore.getState();
      
        // Handle pdf_template: use directly if array, parse if string, default to empty array
        let templateData = [];
        // if (resp.pdf_data?.pdf_template) {
        //   if (Array.isArray(resp.pdf_data.pdf_template)) {
        //     templateData = resp.pdf_data.pdf_template;
        //   } else if (typeof resp.pdf_data.pdf_template === "string") {
        //     try {
        //       templateData = JSON.parse(resp.pdf_data.pdf_template);
        //       if (!Array.isArray(templateData)) {
        //         console.warn("Parsed pdf_template is not an array, defaulting to []");
        //         templateData = [];
        //       }
        //     } catch (e) {
        //       console.error("Failed to parse pdf_template:", e);
        //       templateData = [];
        //     }
        //   } else {
        //     console.warn("pdf_template is neither an array nor a string, defaulting to []");
        //     templateData = [];
        //   }
        // }
        // const { generatePDFBlob } = await import("@/app/billing/customer_profiles/billings_collections/billing_collections_sub_tabs/GeneratePDF");
        // const pdfBlob = await generatePDFBlob(invoiceData, templateData, logoUrl);
      
        // const base64Data = await new Promise<string>((resolve, reject) => {
        //   const reader = new FileReader();
        //   reader.onloadend = () => resolve(reader.result as string);
        //   reader.onerror = reject;
        //   reader.readAsDataURL(pdfBlob);
        // });
      
        // const base64String = base64Data.split(",")[1];
      
        const emailPayload = {
          tenant_name: partner || "default_value",
          username,
          path: "/upload_pdf_to_s3",
          role_name: role,
          access_token: token,
          db_name: "billing_platform",
          billing_db_name:selectedBillingDb,
          ...metaData,
          sessionID: sessionId,
          tenant_id:tenant_id_,
          account_number: accountNumber,
          email_trigger_details: resp.email_trigger_details,
          // pdf_base64: base64String,
        };
        await axios.post(url, { data: emailPayload });

     
    } else {
      Modal.error({
        title: "Creation Error",
        content: parsedData.message || "An error occurred while creating the bill. Please try again.",
        centered: true,
      });
    }
  } catch (error) {
    Modal.error({
      title: "Creation Error",
      content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
      centered: true,
    });
  }
};

// New modal component for Apply to Bill
const ApplyToBillModal: React.FC<{
  isOpen: boolean;
  onClose: () => void;
  billIds: string[];
}> = ({ isOpen, onClose, billIds }) => {
  const [applyToBill, setApplyToBill] = useState<any>(null);
  const [billOptions, setBillOptions] = useState<any[]>([]);

  const [selectedBillId, setSelectedBillId] = useState<string>("");

 useEffect(() => {
  if (isOpen) {
    setSelectedBillId("");
    console.log("Bill IDs:", (generalFields as Record<string, any>)['apply_to_bill']);

    const dynamicOptions = Array.isArray(generalFields)
      ? []
      : generalFields['apply_to_bill'] || [];

    // Prepend the static option
    const updatedOptions = [
      "Apply to old invoice", // static option
      ...dynamicOptions        // dynamic options
    ];

    setBillOptions(updatedOptions); // Update billOptions with combined list
  }
}, [isOpen]);


  const handleSelectChange = (event: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedBillId(event.target.value);
  };

  const handleApply = async () => {
   setLoading(true)
    // Extract only the IDs from ReverseRowData
    const updatedReverseRowData = ReverseRowData.map(row => row.id);
    console.log("Selected charge IDs:", updatedReverseRowData);

  const payload = {
   apply_to_bill: applyToBill.value,
    selected_charge_ids : updatedReverseRowData,

  };

  try {
    const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
    const response = await axios.post(url, {
      data: {
        ...payload,
        path: "/apply_credits_to_bill",
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing and Collections Unposted",       
        // table_name:"customer_charges",
        account_number:accountNumber,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: 'billing_platform',
        ...metaData,
        billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        feature_module_name: "Billing and Collections Unposted",
        main_module_name: "Customer Profiles",
      },
    });

    const parsedData = JSON.parse(response.data.body);
    if (parsedData.flag) {
      notification.success({
        message: "Success",
        description: parsedData.message || "Bill applied successfully!",
         style: messageStyle,
        placement: "top",
      });
      setLoading(false)
      setApplyToBillModalOpen(false);

       fetchData(); // Refresh data after creating the bill
     
    } else {
      Modal.error({
        title: "Creation Error",
        content: parsedData.message || "An error occurred while creating the bill. Please try again.",
        centered: true,
      });
      setLoading(false)
      setApplyToBillModalOpen(false);


    }
  } catch (error) {
    Modal.error({
      title: "Creation Error",
      content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
      centered: true,
    });
      setLoading(false)

  }
  };

  return (
    <Modal
      title="Apply to Bill"
      open={isOpen}
      onCancel={onClose}
      centered
      width={400}
      footer={
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            gap: 16,
            padding: "12px 24px",
          }}
        >
          <button onClick={onClose} className="cancel-btn">
            Cancel
          </button>
          <button
            className={!applyToBill ? "cancel-btn cursor-not-allowed" : "save-btn"}
            onClick={handleApply}
            disabled={!applyToBill}
          >
            Save
          </button>
        </div>
      }
    >
      <div className="flex flex-col">
        <Dropdown
          options={
            (billOptions || []).map((item) => ({
              label: item.includes('-') ? item.split('-')[0].trim() : item,
              value: item,
            }))
          }
          value={applyToBill}
          onChange={(selected: any) => setApplyToBill(selected)}
          placeholder="Create"
          mandatory={true}
        />

      </div>
    </Modal>
  );
};


const CreateBillModal: React.FC<CreateBillModalProps> = ({
  isOpen,
  onClose,
  currentCycle,
  onCreate,
  dueDate
}) => {
  // // Local state for dueDate
  const [dueDateChange, setDueDateChange] = useState<Dayjs | null>(null);
  useEffect(() => {
    setDueDateChange(dueDate ?? null);
  }, [dueDate, isOpen]);


  const handleCreate = () => {
    onCreate(dueDateChange);
    setDueDateChange(null) // Pass dueDate to parent
  };

  return (
    <Modal
      title="Create Bill"
      open={isOpen}
      onCancel={onClose}
      centered
      width={400}
      footer={
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            gap: 16,
            padding: "12px 24px",
          }}
        >
          <button onClick={onClose} className="cancel-btn ">
            Cancel
          </button>
          <button
            className={!dueDateChange || !accountStatus? "cancel-btn cursor-not-allowed" : "save-btn"}
            onClick={handleCreate}
            disabled={!dueDateChange || !accountStatus}
          >
            Create Bill
          </button>
        </div>
      }
    >
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          gap: 24,
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 16,
          }}
        >
          <label
            htmlFor="current-cycle"
            style={{
              minWidth: 120,
              fontWeight: 600,
              userSelect: "none",
            }}
          >
            Current Cycle
          </label>
          <Input
            id="current-cycle"
            value={currentCycle}
            readOnly
            style={{ flex: 1, minWidth: 0 }}
          />
        </div>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 16,
          }}
        >
          <label
            htmlFor="due-date"
            style={{
              minWidth: 120,
              fontWeight: 600,
              userSelect: "none",
            }}
          >
            Due Date
          </label>
          <DatePicker
            id="due-date"
            style={{ flex: 1, minWidth: 0 }}
            value={dueDateChange}
            onChange={val => setDueDateChange(val ?? null)}
            disabledDate={(current) =>
              current ? current < dayjs().startOf('day') : false
            }
            allowClear={false}
            format="MM-DD-YY"
          />
        </div>
      </div>
    </Modal>
  );
};



  if (loading) {
    return (
      <div className="flex justify-center items-center h-[400px]">
        <Spin size="large" />
      </div>
    );
  }
  const isDisabled =
  ReverseRowData.length === 0 ||
  ReverseRowData.some(row => row.category === "Usage" || row.category === "SMS") ||
  !accountStatus;
  return (
    <>
      <Suspense
        fallback={
          <div className="flex justify-center items-center h-[400px]">
            <Spin size="large" />
          </div>
        }
      >
        <div className="relative">
          {/* <div className="p-2 flex items-center justify-between mt-1 mb-2">
            <div className="flex space-x-2"> */}
          <div className="p-4 flex md:flex-row md:items-center md:justify-between space-y-6 md:space-y-0">
            {/* Search and Advanced Filter Container */}
            <div className="flex  space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last">
              { features.includes("Search-Billing and Collections Unposted") &&(
                <WholeTableSearch
                  searchTerm={searchTerm}
                  setSearchTerm={setSearchTerm}
                  tableName={"Unposted"}
                  headerMap={headerMap}
                />
              )}
              {features.includes("Advanced-Billing and Collections Unposted") && (
                <AdvancedMultiFilter2
                  showAdvanced={showAdvanced}
                  setShowAdvanced={setShowAdvanced}
                  onFilter={handleFilter}
                  onReset={handleReset}
                  headers={headers}
                  headerMap={headerMap}
                  tableName={"Unposted"}
                />
              )}
            </div>
            {/* <div className="flex space-x-2"> */}
              {/* Export and ColumnFilter Container */}
            <div className="hidden md:flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2 md:order-none order-first ml-1">
                <span className="save-btn no-hover">
                  Total: {unpostedTotalCharge}
                </span>
                {features.includes("Apply to Bill-Billing and Collections Unposted") && (<button className={ReverseRowData.length === 0 || !accountStatus ? "cancel-btn cursor-not-allowed" : "save-btn"} 
                   disabled={ReverseRowData.length === 0 || !accountStatus}  onClick={handleApplytoBillModalOpen}>
                  Apply to Bill
                </button>)}    
                 {features.includes("Create Bill-Billing and Collections Unposted") && (<button className={ReverseRowData.length === 0 || !accountStatus ? "cancel-btn cursor-not-allowed" : "save-btn"} 
                   disabled={ReverseRowData.length === 0 || !accountStatus}  onClick={handleCreateBillModalOpen}>
                  Create Bill
                </button>  )}     
                {features.includes("Export-Billing and Collections Unposted") && (
                <button className="save-btn" onClick={() => handleExport("Unposted", "Unposted")}>
                <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2"  />
                  <span>Export</span>
                </button>
              )}
              {features.includes("Reverse Transaction-Billing and Collections Unposted") && (
                <button
                  className={isDisabled ? "cancel-btn cursor-not-allowed" : "save-btn"}
                  disabled={isDisabled}
                  onClick={handleReverseTransaction}
                >
                  <ArrowPathIcon className="h-5 w-5 text-black-500 mr-1" />
                  Reversal
                </button>

              )}

             
             <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
                popupHeading="Unposted"
              />
            </div>
          </div>
          <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
          <KillbillTableComponent
              headers={headers}
              headerMap={headerMap}
              initialData={tableData}
              searchQuery={searchTerm}
              visibleColumns={visibleColumns}
              itemsPerPage={100}
              allowedActions={allowedActions}
              popupHeading="Unposted"
              pagination={pagination}
              advancedFilters={filteredData}
              createModalData={createModalData}
              generalFields = {generalFields}
              // height={350}  
              height = {showAdvanced?395:325}                
              setReverseRowData={setReverseRowData}
            />
          </div>
            <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
                <span className="save-btn no-hover">
                  Total: {unpostedTotalCharge}
                </span>
                {features.includes("Apply to Bill-Billing and Collections Unposted") &&(<button className={ReverseRowData.length === 0 || !accountStatus ? "cancel-btn cursor-not-allowed" : "save-btn"} 
                   disabled={ReverseRowData.length === 0 || !accountStatus}  onClick={handleApplytoBillModalOpen}>
                  Apply to Bill
                </button> )}   
                {features.includes("Create Bill-Billing and Collections Unposted") &&( <button className={ReverseRowData.length === 0 || !accountStatus ? "cancel-btn cursor-not-allowed" : "save-btn"} 
                  style={{minWidth: "3rem", width: "3rem", padding: 0}}
                   disabled={ReverseRowData.length === 0 || !accountStatus}  onClick={handleCreateBillModalOpen}>
                  <PlusCircleOutlined className="text-xl text-black-500"  />
                </button> )}      
                {features.includes("Export-Billing and Collections Unposted") && (
                <button className="save-btn" onClick={() => handleExport("Unposted", "Unposted")}
                  style={{minWidth: "3rem", width: "3rem", padding: 0}}>  
                <ArrowDownTrayIcon className="h-5 w-5 text-black-500"  />
                </button>
              )}
              {features.includes("Reverse Transaction-Billing and Collections Unposted") && (
                <button
                  className={
                    ReverseRowData.length > 0 &&
                      !ReverseRowData.some(row => row.category === "Usage" || row.category === "SMS")
                      ? "save-btn "
                      : "cancel-btn"
                  }
                  style={{minWidth: "3rem", width: "3rem", padding: 0}}
                  disabled={
                    ReverseRowData.length === 0 ||
                    ReverseRowData.some(row => row.category === "Usage" || row.category === "SMS")
                  }
                  onClick={handleReverseTransaction}
                >
                  <UndoOutlined className="text-xl text-black-500" />
                 
                </button>
              )}

             
             <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
                popupHeading="Unposted"
              />
            </div>
          <CreateModal
              isOpen={isCreateModalOpen}
              onClose={handleCreateModalClose}
              onSave={handleCreateRow}
              modalData={createModalData}
              title="Unposted"
              visible={isCreateModalOpen}
              action="create"
              generalFields = {generalFields}
              
            />
          <CreateBillModal
            isOpen={isCreateBillModalOpen}
            onClose={handleCreateBillModalClose}
            currentCycle={currentCycle}
            onCreate={handleCreateBill}
            dueDate={dueDate}
          />
          <ApplyToBillModal
            isOpen={isApplyToBillModalOpen}
            onClose={() => setApplyToBillModalOpen(false)}
            billIds={tableData.map((item: any) => item.bill_id).filter(Boolean)}
          />

          {/* {exportLoading && (
            <div className="export-processing-div">
              Export processing...
            </div>
          )} */}
        </div>
      </Suspense>
    </>
  );
};

export default UnPosted;
