"use client";

import React, { useCallback, useEffect, useState } from "react";
import { Modal, DatePicker, Spin, notification } from "antd";
const { RangePicker } = DatePicker;
import dayjs, { Dayjs } from "dayjs";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useCustomerProfileStore } from "@/app/billing/killbill_stores/customer_profile_store";
import { getCurrentDateTime } from "../../../../components/header_constants";
import axios from "axios";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { useAuth } from "@/app/components/auth_context";
import WholeTableSearch from "@/app/billing/killbill_components/whole__search";
import AdvancedMultiFilter2 from "@/app/billing/killbill_components/advanced__search";
import KillbillTableComponent from "@/app/billing/killbill_components/table__component";
import { useItemStore } from "@/app/billing/killbill_stores/useItemStore";
import { useLogoStore } from "@/app/billing/killbill_stores/logo_store";

interface FormData {
  include_proration: boolean;
  current_cycle: [Dayjs | null, Dayjs | null];
}

interface RepostMRCProps {
  isOpen?: boolean;
  onClose?: () => void;
  onSave ?: () => void;
  rowData?: any;
  reversalsReverseData?:any;
  //   onCreate: (formData: FormData) => void;
}
const RepostMRC: React.FC<RepostMRCProps> = ({
  isOpen,
  onClose,
  onSave,
  rowData,
  reversalsReverseData,
  //   onCreate,
}) => {
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, token, selectedDb,metaData,selectedBillingDb, sessionId, settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId, firstLastName,
    setStoredPagination, setAdvancedStoredPagination, combineAdnvaceStoredpagination,
    setCombineAdnvaceStoredpagination } = useAuth();
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [createModalData, setcreateModalData] = useState<any[]>([]);
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
  const [generalFields, setgeneralFields] = useState<any[]>([])
  const [ReverseRowData, setReverseRowData] = useState<any[]>([]);
  const { accountNumber, BillId, setBillId, setUserProfileDetails } = useCustomerProfileStore();
  const [validationErrors, setValidationErrors] = useState<{ [key: string]: string }>({});

  const {
    iccid,
    bulkRow,
    // features: moduleFeatures,
    // setFeatures: setModuleFeatures,
    setICCID,
    setBulkRow
  } = useFeatureStore();
  const [formData, setFormData] = useState<FormData>({
    include_proration: false,
    current_cycle: [null, null],
  });
 const [formDataChanged, setFormDataChanged] = useState(false);
  const tenant_id_ = localStorage.getItem("tenant_id") || "0";

  useEffect(() => {
  // console.log("RowData", rowData);
  // console.log("reverserowdata", reversalsReverseData);
  console.log("Raw current_cycle string:", rowData.dropdown.current_cycle);

  if (isOpen) {
    setFormData({
      include_proration: false,
      current_cycle:
        typeof rowData.dropdown.current_cycle === "string" && rowData.dropdown.current_cycle.includes(" - ")
          ? rowData.dropdown.current_cycle.split(" - ").map((dateStr: any) => {
              const date = dayjs(dateStr.trim(), "YYYY-MM-DD"); // <-- correct format
              return date.isValid() ? date : null;
            })
          : [null, null],
    });
  }
}, [isOpen, rowData.dropdown.current_cycle]);

  // 1. When modal opens OR current_cycle changes, mark formDataChanged true
useEffect(() => {
  if (isOpen) {
    setFormDataChanged(true);
  }
}, [isOpen]);

// 2. When formData.current_cycle changes (due to user or programmatic change), mark formDataChanged true
useEffect(() => {
  if (formData.current_cycle && formData.current_cycle[0] && formData.current_cycle[1]) {
    setFormDataChanged(true);
  }
}, [formData.current_cycle]);

// 3. Single effect to run fetch when formDataChanged is true
useEffect(() => {
  if (formDataChanged) {
    fetchRepostedMRCS();
    setFormDataChanged(false);
  }
}, [formDataChanged]);

  type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);
  const handleFilter = useCallback((advancedFilters: any) => {
    console.log(advancedFilters);
    setAdvancedFilters(advancedFilters)
  }, []);

  const handleReset = useCallback((EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  }, []);

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "normal",
    padding: "16px",
  };

  const fetchRepostedMRCS = async () => {
    settabledata([]);
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    setSearchTerm("");
    setShowAdvanced(false)
    setCombineAdnvaceStoredpagination(null)
    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      // const table_name_base = "vw_customer_services_usage";
      // const lower_tenant = (partner ?? "").toLowerCase();
      // const final_table_name = lower_tenant.includes("altaworx") ? `${table_name_base}_altaworx`
      //                           : `${table_name_base}_${lower_tenant}`;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_reposted_mrcs",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing and Collections Reposted",
        mod_pages: {
          start: 0,
          end: 100,
        },
        prorated_flag:formData.include_proration,
        table_name: "customer_services",
        bill_id : reversalsReverseData.id,
        account_number: accountNumber,
        current_cycle:formData.current_cycle.map(date => date ? date.format("MM-DD-YY") : null),
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        tenant_id: tenant_id_,
        sessionID: sessionId,
        feature_module_name: "Billing and Collections Reposted",
        main_module_name: "Customer Profiles",
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)

      if (parsedData.flag === true) {
        if(parsedData?.validation){
          setTableData([]);
          Modal.error({
            title: "Validation Error",
            content: parsedData.message,
            centered: true,
          });
        }
        setLoading(false);
        // Defer other state updates using a timeout to decouple them from the main thread
        // setUserProfileDetails(parsedData?.user_profile_details || {});

        setTimeout(() => {
          //  const unposted_total_charge_ = parsedData?.unposted_total_charge || 0;
          //  setUnpostedTotalCharge(unposted_total_charge_);
          const headersMap_ = parsedData?.header_map?.["Billing and Collections Reposted"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);
          // const current_cycle_ = parsedData?.current_cycle
          //   ? dayjs(parsedData.current_cycle).format('YYYY-MM-DD')
          //   : '';

          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
          console.log("headers", headers_)
          setHeaders(headers_);
          setVisibleColumns(headers_);
          const generalFields_ = parsedData || {}
          setgeneralFields(generalFields_)
          console.log("generalFields_", generalFields_)
          setFeatures(parsedData?.header_map?.["Billing and Collections Reposted"]?.module_features || []);
          // setFeatures(parsedData?.header_map?.["Billing and Collections Reposted"]?.module_features || []);
          const featres_ = parsedData?.header_map?.["Billing and Collections Reposted"]?.module_features || []
          const allowedActions_: any = []
          if (featres_.includes("Edit-Billing Services")) {
            allowedActions_.push("edit")
          }
          // if(featres_.includes("Delete-Billing Services")){
          //   allowedActions_.push("delete")
          // }
          if (featres_.includes("Copy-Billing Services")) {
            allowedActions_.push("copy")
          }
          if (featres_.includes("Discontinue-Billing Services")) {
            allowedActions_.push("deactivate")

          }

          setAllowedActions(allowedActions_)
          const createModalData_ = parsedData?.header_map?.["Billing and Collections Reposted"]?.pop_up || []
          console.log("createModalData_", createModalData_)
          setcreateModalData(createModalData_)
          setPagination(parsedData?.pages || {});
          setTableData(parsedData?.data?.billing_collections_reposted || []);


        }, 0);

      } else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };


const handleChange = (field: keyof FormData, value: any) => {
  setFormData((prev) => ({
    ...prev,
    [field]: value,
  }));
  setFormDataChanged(true);
};



  const handleCreate = () => {
  const errors: { [key: string]: string } = {};

  if (!formData.current_cycle[0] || !formData.current_cycle[1]) {
    errors.current_cycle = "Current cycle is required.";
  }

  // If there are errors, set them in state or display them
  if (Object.keys(errors).length > 0) {
  setValidationErrors(errors);
 // Make sure you have a useState for this
    return;
  }
  ConfirmCreate()
  // If valid, proceed with bill creation
  console.log("Creating bill with:", formData);
};

  const ConfirmCreate = async () => {
    setLoading(true);
    try {
      let data;
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES
      data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/save_reposted_mrcs",
        role_name: role,
        account_number: accountNumber,
        module_name: "Billing and Collections Reposted",
        table_name: "customer_charges",
        feature_module_name: "Billing and Collections Reposted",
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        request_received_at: getCurrentDateTime(),
        sessionID: sessionId,
        tenant_id: tenant_id_,
        modified_by: firstLastName,
        bill_id : reversalsReverseData.id,
        current_cycle:formData.current_cycle,
        prorated_flag:formData.include_proration,
        changed_data: [...ReverseRowData],
        main_module_name: "Customer Profiles",
        
      };
      const response = await axios.post(url, { data });
      const resp = JSON.parse(response.data.body);
      if (resp.flag === true) {
        notification.success({
          message: "Success",
          description: resp.message || "Successfully saved the record!",
          style: messageStyle,
          placement: "top",
        });
        onClose && onClose();
        onSave && onSave();
        // Safely parse invoice data
        // const invoiceData = resp.pdf_data?.data ? JSON.parse(resp.pdf_data.data) : {};
        // // console.log("PDF Data:", invoiceData);

        // // Handle pdf_template: use directly if array, parse if string, default to empty array
        // let templateData = [];
        // if (resp.pdf_data?.pdf_template) {
        //   if (Array.isArray(resp.pdf_data.pdf_template)) {
        //     templateData = resp.pdf_data.pdf_template;
        //   } else if (typeof resp.pdf_data.pdf_template === "string") {
        //     try {
        //       templateData = JSON.parse(resp.pdf_data.pdf_template);
        //       if (!Array.isArray(templateData)) {
        //         console.warn("Parsed pdf_template is not an array, defaulting to []");
        //         templateData = [];
        //       }
        //     } catch (e) {
        //       console.error("Failed to parse pdf_template:", e);
        //       templateData = [];
        //     }
        //   } else {
        //     console.warn("pdf_template is neither an array nor a string, defaulting to []");
        //     templateData = [];
        //   }
        // }
        // // console.log("temp..... Data:", templateData);

        // let { items, setItems } = useItemStore.getState();
        // const { logoUrl } = useLogoStore.getState();

        // if (!items || items.length === 0) {
        //   // console.log("Fetching template data...");

        //   const templateResponse = await axios.post(url, {
        //     data: {
        //       tenant_name: partner || "default_value",
        //       username,
        //       firstLastName: "",
        //       path: "/billing_collections_bills_list_view",
        //       role_name: role,
        //       parent_module: "Billing Platform",
        //       module_name: "Billing and Collections Bills",
        //       mod_pages: { start: 0, end: 100 },
        //       table_name: "customer_bills",
        //       account_number: accountNumber,
        //       request_received_at: getCurrentDateTime(),
        //       Partner: partner,
        //       access_token: token,
        //       db_name: "billing_platform",
        //       sessionID: sessionId,
        //       feature_module_name: "Billing and Collections Bills",
        //     },
        //   });

        //   const templateResp = JSON.parse(templateResponse.data.body);

        //   if (templateResp.flag && Array.isArray(templateResp.pdf_template)) {
        //     // console.log("Hi....");
        //     items = templateResp.pdf_template;
        //     // console.log(items, "IIIIIIIIIIIII");
        //     setItems(items);
        //   } else {
        //     // console.log("Hellooo...");
        //     const { generateDefaultTemplate } = await import("@/app/billing/multiGenerateBill/createMultiTemplate");
        //     items = generateDefaultTemplate(invoiceData, logoUrl);
        //     // console.log(items, "TTT");
        //     setItems(items);
        //   }
        // }

        // const { generatePDFBlob } = await import("@/app/billing/customer_profiles/billings_collections/billing_collections_sub_tabs/GeneratePDF");
        // const pdfBlob = await generatePDFBlob(invoiceData, templateData, logoUrl);

        // const base64Data = await new Promise<string>((resolve, reject) => {
        //   const reader = new FileReader();
        //   reader.onloadend = () => resolve(reader.result as string);
        //   reader.onerror = reject;
        //   reader.readAsDataURL(pdfBlob);
        // });

        // const base64String = base64Data.split(",")[1];

        // const emailPayload = {
        //   tenant_name: partner || "default_value",
        //   username,
        //   path: "/upload_pdf_to_s3",
        //   role_name: role,
        //   access_token: token,
        //   db_name: "billing_platform",
        //   sessionID: sessionId,
        //   account_number: accountNumber,
        //   email_trigger_details: resp.email_trigger_details,
        //   pdf_base64: base64String,
        // };

        // await axios.post(url, { data: emailPayload });

        // onClose()
        // onSave()
        // handleCancel();
      }
      else {
        Modal.error({
          title: "Saving Error",
          content: resp.message,
          centered: true,
        });
        // onClose()
        
        // handleCancel();
      }

    }
    catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Submit Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting data. Please try again.',
        centered: true,
        onOk: onClose
      });
      // handleCancel();
    }
    finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      title="Repost MRC's"
      open={isOpen}
      onCancel={onClose}
      centered
      width={815}
      footer={
        <div
          style={{
            display: "flex",
            justifyContent: "center",
            gap: 16,
            padding: "6px 6px",
          }}
        >
          <button onClick={onClose} className="cancel-btn">
            Cancel
          </button>
          <button
            className={"save-btn"}
            onClick={handleCreate}
          >
            Submit
          </button>
        </div>
      }
    >
        {loading ? (
      <div className="flex justify-center items-center h-[400px]">
        <Spin size="large" />
      </div>
    ) : (
      <>
       <div className="flex flex-col md:flex-row md:items-center md:space-x-4">
        <label className="field-label md:w-[150px] mb-1 md:mb-0">
          Current Cycle <span className="text-red-500">*</span>
        </label>
        
              <div className="flex-1">

                <RangePicker
                  className="input w-full md:max-w-[250px]"
                  value={
                    formData.current_cycle && formData.current_cycle[0] && formData.current_cycle[1]
                      ? [
                        dayjs(formData.current_cycle[0], "MM-DD-YY"),  // if your format is MM-DD-YY
                        dayjs(formData.current_cycle[1], "MM-DD-YY")
                      ]
                      : [null, null]
                  }
                  onChange={(dates) =>
                    handleChange(
                      "current_cycle",
                      dates ? [dates[0], dates[1]] : [null, null]
                    )
                  }
                  allowClear={false}
                  format="MM-DD-YY"
                />

                {validationErrors["current_cycle"] && (
                  <span className="text-red-500 text-sm">
                    {validationErrors["current_cycle"]}
                  </span>
                )}
              </div>
      </div>

      <div style={{ marginTop: 16, display: "flex", alignItems: "center", gap: 8 }}>
        <input
          type="checkbox"
          id="include_proration"
          checked={formData.include_proration}
          onChange={(e) => handleChange("include_proration", e.target.checked)}
        />
        <label htmlFor="include_proration" className="field-label">
          Include Proration
        </label>
      </div>
      { (

        <div className="relative">
          {/* <div className="p-2 flex items-center justify-between mt-1 mb-2">
                  <div className="flex space-x-2"> */}
          <h3 className="font-bold">Service Lines</h3>
          <div className="pr-4 pl-4  pt-1 flex flex-col md:flex-row md:items-center md:justify-between mb-2 space-y-2">
            {/* Search and Advanced Filter Container */}
            <div className="flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last min-h-[40px]">
              {features.includes("Search-Billing and Collections Reversals") && (
                <WholeTableSearch
                  searchTerm={searchTerm}
                  setSearchTerm={setSearchTerm}
                  tableName={"RepostedMRC"}
                  headerMap={headerMap}
                  billId = {reversalsReverseData.id}
                  current_cycle = {formData.current_cycle}
                />
              )}
              {features.includes("Advanced-Billing and Collections Reversals") && (
                <AdvancedMultiFilter2
                  showAdvanced={showAdvanced}
                  setShowAdvanced={setShowAdvanced}
                  onFilter={handleFilter}
                  onReset={handleReset}
                  headers={headers}
                  headerMap={headerMap}
                  tableName={"RepostedMRC"}
                  billId = {reversalsReverseData.id}
                  current_cycle = {formData.current_cycle}
                />
              )}
            </div>

          </div>
          {(
            <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
              {loading ? (
                <div className="flex justify-center items-center h-[400px]">
                  <Spin size="large" />
                </div>
              ) : (
                <KillbillTableComponent
                  headers={headers}
                  headerMap={headerMap}
                  initialData={tableData}
                  searchQuery={searchTerm}
                  visibleColumns={visibleColumns}
                  itemsPerPage={100}
                  allowedActions={allowedActions}
                  popupHeading="RepostMRCs"
                  pagination={pagination}
                  advancedFilters={filteredData}
                  createModalData={createModalData}
                  generalFields={generalFields}
                  height={showAdvanced ? 395 : 335}
                  setReverseRowData={setReverseRowData}
                  repostedFields = {formData}
                />
              )}
            </div>
          )}

        </div>)}
      </>
    )}
    </Modal>
  );
};

export default RepostMRC;
