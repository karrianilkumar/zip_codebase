import React, { useState } from 'react';
import { Modal, Select, Button, notification, Spin } from 'antd';
import axios from 'axios';
import { ENV_ROUTES } from '@/app/components/routes/route_constants';
import { useAuth } from '@/app/components/auth_context';
import { useCustomerProfileStore } from '@/app/billing/killbill_stores/customer_profile_store';
import { getCurrentDateTime } from '@/app/components/header_constants';

interface RowData {
  id: number;
  customer_profile_id: number;
  service_type: string;
  service_type_id: number;
  service_location: any;
}


interface EditServiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  rowData: any;
}

const EditServiceLocationModal: React.FC<EditServiceModalProps> = ({ isOpen, onClose, rowData }) => {
  const [editLocation, setEditLocation] = useState(rowData?.service_location || '');
  const [loading, setLoading] = useState(false);
  const { username, partner, role, token, selectedDb,metaData,selectedBillingDb, firstLastName, sessionId,settabledata } = useAuth();
  const { accountNumber, setAccountNumber, setBillId } = useCustomerProfileStore();
  // Get serviceDropdownValues from the store
  const serviceDropdownValues = useCustomerProfileStore((state) => state.serviceDropdownValues);
  
  // Check if serviceDropdownValues is not null and is an object
  const serviceLocations = serviceDropdownValues && typeof serviceDropdownValues === 'object' 
    ? serviceDropdownValues.service_locations || [] 
    : [];
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);

  console.log(serviceDropdownValues,"Show the dropdown values.......")

  const handleSubmit = async () => {
    setLoading(true);
    try {
      const updatedData = {
        id: rowData.id,
        service_provider_id: rowData.service_provider_id,
        service_type: rowData.service_type,
        service_location: editLocation,
      };

      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || 'default_value',
        username: username,
        firstLastName: firstLastName,
        path: '/edit_service_location',
        role_name: role,
        module_name: 'Customer Profile Services',
        feature_module_name: 'Billing Platform',
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        request_received_at: new Date().toISOString(),
        sessionID: sessionId,
        action: 'update',
        modified_by: firstLastName,
        changed_data: updatedData,
        modified_date:getCurrentDateTime(),
        main_module_name: "Customer Profiles",
      };

      const response = await axios.post(url, { data });
      const resp = JSON.parse(response.data.body);
      console.log(resp, 'show the response');
      if (response.data.statusCode === 200 && resp.flag === true) {
      
          let parsedData: any;
          try {
            setLoading(true);
            const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
            const tenant_id_ = localStorage.getItem("tenant_id") || "0";

             const data = {
                    tenant_name: partner || "default_value",
                    username: username,
                    firstLastName: firstLastName,
                    path: "/customer_services_list_view",
                    role_name: role,
                    account_number: accountNumber,
                    parent_module: "Billing Platform",
                    module_name: "Customer Services",
                    table_name: "customer_services",
                    // sub_module:"Services",
                    mod_pages: {
                      start: 0,
                      end: 100,
                    },
                    request_received_at: getCurrentDateTime(),
                    Partner: partner,
                    access_token: token,
                    tenant_id:tenant_id_,
                    db_name: selectedDb,
                    ...metaData,
billing_db_name: selectedBillingDb,
                    sessionID: sessionId,
                    feature_module_name: "Customer Services",
                    main_module_name: "Customer Profiles",
                  };
  
            const response = await axios.post(url, { data });
            parsedData = JSON.parse(response.data.body);
  
            if (parsedData.flag === true) {
              settabledata(parsedData?.data?.customer_services || []);
            };
            notification.success({
              message: 'Success',
              description: 'Successfully updated the record!',
              style: {
                fontSize: '14px',
                fontWeight: 'bold',
                padding: '16px',
              },
              placement: 'top',
            });
            onClose();
          }
          catch { }
          finally { setLoading(false) }
        
        
      } else {
        const errorMsg = JSON.parse(response.data.body).message;
        notification.error({
          message: 'Error',
          description: errorMsg,
          style: {
            fontSize: '14px',
            fontWeight: 'bold',
            padding: '16px',
          },
          placement: 'top',
        });
      }
    } catch (error) {
      console.error('Error fetching data:', error);
      notification.error({
        message: 'Error',
        description: error instanceof Error ? error.message : 'An unexpected error occurred while submitting data. Please try again.',
        style: {
          fontSize: '14px',
          fontWeight: 'bold',
          padding: '16px',
        },
        placement: 'top',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCancelConfirmation = () => {
    setIsConfirmationOpen(false);
  };
  const handleSave = (e: React.FormEvent) => {
      e.preventDefault();
        setIsConfirmationOpen(true);
    };
  const handleConfirmCreate = async () => {
    // Call SubmitData when the user confirms in the modal
    handleSubmit();
  };
  const modalWidth =
  typeof window !== 'undefined' ? (window.innerWidth * 2.5) / 4 : 0;
const modalHeight =
  typeof window !== 'undefined' ? (window.innerHeight * 1.5) / 4 : 0;
if (!isOpen) return null;
if (loading) {
  return (
    <div className="absolute inset-0 flex justify-center items-center bg-white bg-opacity-75 z-50 border pointer-events-none">
      <div className='flex justify-center'>
        <Spin size="large" />
      </div>

    </div>

  );
}
  return (
    <>
    <Modal
      title="Edit Service Location"
      visible={isOpen}
      onCancel={onClose}
      footer={
  <div className="flex flex-col sm:flex-row justify-center items-center space-y-2 sm:space-y-0 sm:space-x-3 mt-6">
    <button className="cancel-btn w-full sm:w-auto" onClick={onClose}>
      Cancel
    </button>
    <button className="save-btn w-full sm:w-auto" onClick={handleConfirmCreate}>
      Save
    </button>
  </div>
}

      width={500}
      styles={{ body: { height: '150px'} }}
    >
        <div className="w-full  space-y-4">
          <div className="flex flex-col">
            <label className="text-sm font-medium text-gray-700 field-label">Service Type</label>
            <Select
              value={rowData.service_type}
              disabled
              className="w-full mb-4"
            />
          </div>

          <div className="flex flex-col">
            <label className=" text-sm font-medium text-gray-700 field-label">Edit Service Location</label>
            <Select
              value={editLocation}
              onChange={setEditLocation}
              className="w-full"
            >
              {serviceLocations.map((location, index) => (
                <Select.Option key={index} value={location}>
                  {location}
                </Select.Option>
              ))}
            </Select>
          </div>
        </div>

    </Modal>
     <Modal
            title="Confirmation"
            open={isConfirmationOpen}
    
            centered
            footer={
              <div style={{ display: 'flex', justifyContent: 'center', width: '100%', gap: "6px" }}>
                <button
                  className="cancel-btn"
                  onClick={handleCancelConfirmation}
                >
                  Cancel
                </button>
                <button
                  className="save-btn"
                  onClick={handleConfirmCreate}
                >
                  OK
                </button>
              </div>
            }
          >
            <p>Are you sure you want to submit</p>
          </Modal>
          </>
  );
};

export default EditServiceLocationModal;
