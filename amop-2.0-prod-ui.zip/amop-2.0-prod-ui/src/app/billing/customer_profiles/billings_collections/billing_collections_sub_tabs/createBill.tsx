"use client";

import React, { useCallback, useEffect, useState } from "react";
import { Checkbox, Input, Modal, notification, Popover, Spin, Switch, DatePicker, Upload, message, Select } from 'antd'; // Import DatePicker and Select
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useAuth } from "@/app/components/auth_context";
import dayjs, { Dayjs } from 'dayjs'; // Import dayjs
import Dropdown from "../../../killbill_components/dropdownComponent";
import { useCustomerProfileStore } from "@/app/billing/killbill_stores/customer_profile_store";
// import { generateDefaultTemplate, InvoicePDFTemplate } from "@/app/billing/generate_bill/createTemplate";
import { useItemStore } from "@/app/billing/killbill_stores/useItemStore";
// import {pdf} from "@react-pdf/renderer";
import dynamic from "next/dynamic";
import { useLogoStore } from "@/app/billing/killbill_stores/logo_store";
import { DownloadOutlined, UploadOutlined } from "@ant-design/icons";
const { RangePicker } = DatePicker; // Extract RangePicker
// Dynamically import InvoicePDFTemplate (React component) with SSR disabled

interface CreateBillModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (type?:any) => void;
  modalData: {
    id: number;
    display_name: string;
    type: string;
    mandatory: boolean;
    db_column_name: string;
  }[];
  title: string;
  visible: boolean;
  action: string;
  rowData?: any;
  generalFields?: any;
  row:any;

}
interface ValidationFormData {
  charge_type: string;
  charge_amount: string;
  charge_description: string;
  transfer_to_account: string;
  due_date_of_this_bill: string;
}
type FormData = {
  //selected type
  create: any | null;
  bill_type: any | null;
  specify_amount_to_bill: any | null;
  // usage_range: [Dayjs | null, Dayjs | null];
  due_date_of_this_bill: Dayjs | null;
  current_bill_cycle: [Dayjs | null, Dayjs | null];
  // enforce_no_paper_bill_fee: any | null;
  // final_bill_flag: any | null;
  // itemized_local_cost: any | null;
  //selected Charge & Credit type
  charge_type: any | null;
  product: any | null;
  select_type: any | null;
  quantity: number;
  total_rate: any | null;  
  service_providers: any | null;    // Changed to number
  charge_amount: any | null;  // Changed to number
  buy_rate: any | null;       // Changed to number
  cost: any | null;           // Changed to number
  service: any | null;
  charge_description: string;
  date_range: [Dayjs | null, Dayjs | null];
  options: any | null;
  //selected balance transfer type
  amount_to_transfer: any | null;             // Changed to number
  transfer_from_name: string;
  transfer_from_account: any | null;
  transfer_from_current_balance: any | null;  // Changed to number
  transfer_from_balance_after: any | null;    // Changed to number
  transfer_to_name: string;
  transfer_to_account: any | null;
  transfer_to_current_balance: any | null;    // Changed to number
  transfer_to_balance_after: any | null; 
  bill_ids:any | null;
};


const messageStyle = {
  fontSize: '14px',
  fontWeight: 'normal',
  padding: '16px',
};
const CreateBillModal: React.FC<CreateBillModalProps> = ({
  isOpen,
  onClose,
  onSave,
  modalData,
  title,
  visible,
  action,
  rowData,
  generalFields,
  row
}) => {
  const { accountNumber , BillId} = useCustomerProfileStore();
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);
  const { username, partner, role, settabledata, token, selectedDb,metaData,selectedBillingDb, firstLastName, sessionId } = useAuth();
  const [loading, setLoading] = useState(false);
  const [loading2, setLoading2] = useState(false);
  const [billFields, setBillFields] = useState(false);
  const [chargeFields, setChargeFields] = useState(false);
  const [creditFields, setCreditFields] = useState(false);
  const [balanceTransferFields, setBalanceTransferFields] = useState(false);

  //uploadStates
  const [isUploadModalVisible, setIsUploadModalVisible] = useState(false);
  const [selectedUploadType, setSelectedUploadType] = useState<string | null>(null);
  const [uploadKey, setUploadKey] = useState(Date.now());
  
   const SelectOptions = [
    { label: 'Product', value: 'Product' },
    { label: 'Product Type', value: 'Product Type' }
  ];

 const [ServiceProviderOptions, setServiceProviderOptions] = useState<any[]>([]);
 const [ProductTypeOptions, setProductTypeOptions] = useState<any[]>([]);
 const [ServiceTypeOptions, setServiceTypeOptions] = useState<any[]>([]);
 const [billIdsList, setbillIdsList] = useState<any[]>([]);
 const [billTypeOptions, setBillTypeOptions] = useState<any[]>([]);
 const [ProductOptions, setProductOptions] = useState<any[]>([]);

  const dependentProductsMap = generalFields?.dropdown?.dependent_products || {};
  const dependentProductsAmount = generalFields?.dropdown?.product_amount || {};

  const [selectedParentAccount, setSelectedParentAccount] = useState<any>(null);
  const [selectedChildAccount, setSelectedChildAccount] = useState<any>(null);


  const [inputErrors, setInputErrors] = useState({
    // specify_amount_to_bill: '',
    charge_amount: '',
    buy_rate:'',
    cost:'',
    amount_to_transfer:'',
    // other fields...
  });
  const [ParentAccountOptions, setParentAccountOptions] = useState<any[]>([]); 
  const [ChildAccountOptions, setChildAccountOptions] = useState<any[]>([]);
  const [Options, setOptions] = useState<any>(
    generalFields?.dropdown?.options?.map((item: string) => ({
      label: item,
      value: item,
    })) || []
  );
  const options = [
    // { value: "Select", label: "Select" },
    { value: "Bill", label: "Bill" },
    { value: "Charge", label: "Charge" },
    { value: "Credit", label: "Credit" },
    { value: "Balance Transfer", label: "Balance Transfer" },
  ];


  const [selectedOption, setSelectedOption] = useState<{ label: string; value: string } | null>(null);
  const [formData, setFormData] = useState<FormData>({
    // selected type
    create: '',
    bill_type: null,
    specify_amount_to_bill: null,
    // usage_range: [null, null],
    current_bill_cycle: [null, null],
    due_date_of_this_bill: null,
    // enforce_no_paper_bill_fee: null,
    // final_bill_flag: null,
    // itemized_local_cost: null,
    // selected Charge & Credit type
    charge_type: null,
    product: null,
    select_type: null,
    quantity: 1,
    total_rate: null,
    service_providers: null, // Changed to null
    charge_amount: null,  // Changed to null
    buy_rate: null,       // Changed to null
    cost: null,           // Changed to null
    service: null,
    charge_description: '',
    options: null,
    date_range: [null, null],
    // selected balance transfer type
    amount_to_transfer: null,              // Changed to null
    transfer_from_name: '',
    transfer_from_account: null,
    transfer_from_current_balance: null,   // Changed to null
    transfer_from_balance_after: null,     // Changed to null
    transfer_to_name: '',
    transfer_to_account: null,
    transfer_to_current_balance: null,     // Changed to null
    transfer_to_balance_after: null,  
    bill_ids:null     
  });
  
  
  const [amountError, setAmountError] = useState<string>("");
  const { RangePicker } = DatePicker; // Extract RangePicker
  const tenant_id_ = localStorage.getItem("tenant_id") || "0";
 useEffect(() => {
  if (isOpen && generalFields) {
    setSelectedUploadType(null);

    const dropdowns = generalFields.dropdown || {};

    // Parse and set default for current bill cycle (range)
    const currentCycle = dropdowns.current_cycle;
    const defaultCycleDates: [Dayjs, Dayjs] | [null, null] = currentCycle
      ? currentCycle.split(" - ").map((date: string) => dayjs(date.trim())) as [Dayjs, Dayjs]
      : [null, null];

    const hasUserInputCycle = Array.isArray(formData.current_bill_cycle) && formData.current_bill_cycle.length === 2;

    if (!hasUserInputCycle && currentCycle) {
      setFormData((prev) => ({
        ...prev,
        current_bill_cycle: defaultCycleDates,
      }));
    }
    
    // Parse and set default for due date (single date)
    const dueDateString = dropdowns.due_date_of_this_bill;
    const defaultDueDate: Dayjs | null = dueDateString ? dayjs(dueDateString.trim()) : null;

    if (!formData.due_date_of_this_bill && dueDateString) {
      setFormData((prev) => ({
        ...prev,
        due_date_of_this_bill: defaultDueDate,
      }));
    }

    // Dropdown options
    setServiceProviderOptions(
      dropdowns.service_providers?.map((item: string) => ({ label: item, value: item })) || []
    );

    setBillTypeOptions(
      dropdowns.bill_type?.map((item: string) => ({ label: item, value: item })) || []
    );

    setProductOptions(
      dropdowns.all_products?.map((item: string) => ({
        label: item.includes('-') ? item.split('-').slice(1).join('-').trim() : item,
        value: item,
      })) || []
    );

    setProductTypeOptions(
      dropdowns.charge_type?.map((item: string) => ({
        label: item.includes('-') ? item.split('-').slice(1).join('-').trim() : item,
        value: item,
      })) || []
    );

    setServiceTypeOptions(
      dropdowns.service?.map((item: string) => ({
        label: item,
        value: item,
      })) || []
    );
    setbillIdsList(
      dropdowns.bill_ids?.map((item: string) => ({ 
        label: item, value:
        item })) || []
    )

    setParentAccountOptions(
      dropdowns.transfer_from_account
        ? Object.keys(dropdowns.transfer_from_account).map((key) => ({
          label: key,
          value: key,
        }))
        : []
    );
    setChildAccountOptions(
      dropdowns.transfer_to_account
      ? Object.keys(dropdowns.transfer_to_account).map((key) => ({
        label: key,
        value: key,
      })):[]
    )
  }
}, [isOpen, generalFields]);

 


  useEffect(() => {
    // console.log("General fields", generalFields);
  
    if (formData.transfer_from_account) {
      setFormData((prevFormData) => ({
        ...prevFormData,
        transfer_from_name: generalFields?.dropdown?.transfer_from_name?.[formData.transfer_from_account.value] || "",
      }));
    }
  
    if (formData.transfer_to_account) {
      setFormData((prevFormData) => ({
        ...prevFormData,
        transfer_to_name: generalFields?.dropdown?.transfer_to_name?.[formData.transfer_to_account.value] || "",
      }));
    }
  }, [formData.transfer_from_account, formData.transfer_to_account, generalFields]);
  
  
  useEffect(() => {
    // console.log("Formdata",formData);
    // console.log("Amount to Transfer:", formData.amount_to_transfer);
    // console.log("Transfer From Current Balance:", formData.transfer_from_current_balance);
    // console.log("Transfer To Current Balance:", formData.transfer_to_current_balance);

    const transferAmount = Number(formData.amount_to_transfer);
    const fromCurrentBalance = Number(formData.transfer_from_current_balance);
    const toCurrentBalance = formData.transfer_to_current_balance ? Number(formData.transfer_to_current_balance) : 0; // Fix: Ensure it’s treated as 0 if empty

    if (
        formData.amount_to_transfer !== null && formData.amount_to_transfer !== "" &&
        formData.transfer_from_current_balance !== null && formData.transfer_from_current_balance !== ""
    ) {
        if (transferAmount > fromCurrentBalance) {
            console.log("Error: Insufficient balance");
            setAmountError("Insufficient balance: Transfer amount cannot exceed available balance.");
        } else {
            setAmountError(""); // Clear error if valid
        }

        const newTransferFromBalance = Number((fromCurrentBalance - transferAmount).toFixed(2));
        const newTransferToBalance = toCurrentBalance + Number(transferAmount.toFixed(2)); // Fix: Now it correctly adds to 0

        console.log("New Transfer From Balance After:", newTransferFromBalance);
        console.log("New Transfer To Balance After:", newTransferToBalance);

        setFormData((prevFormData) => ({
            ...prevFormData,
            transfer_from_balance_after: isNaN(newTransferFromBalance) ? null : newTransferFromBalance,
            transfer_to_balance_after: isNaN(newTransferToBalance) ? null : newTransferToBalance, // Fix: Now updates correctly
        }));
    } else {
        console.log("Amount to Transfer or Transfer From Balance is null, resetting balances...");
        setAmountError(""); // Reset error when input is cleared
        setFormData((prevFormData) => ({
            ...prevFormData,
            transfer_from_balance_after: null,
            transfer_to_balance_after: null,
        }));
    }
}, [formData.amount_to_transfer, formData.transfer_from_current_balance, formData.transfer_to_current_balance]);

const SubmitData = async (formData: any) => {
  setLoading2(true);

  try {
    const extractId = (value: string | null | undefined) => {
      if (typeof value === "string" && value.includes("-")) {
        return value.split("-")[0];
      }
      return null;
    };

    // Extract IDs
    const chargeTypeId = extractId(formData.charge_type?.value);
    const productId = extractId(formData.product?.value);
    const serviceId = extractId(formData.service?.value);

    // Prepare cleaned form data
    const enhancedData = {
      ...formData,
      product_id: productId,
      product_type_id: chargeTypeId,
      service_id: serviceId,
    };

    const cleanedData = Object.keys(enhancedData).reduce((acc: any, key) => {
      const value = enhancedData[key];
      if (
        value !== null &&
        value !== undefined &&
        value !== "" &&
        !(Array.isArray(value) && value.every((item) => item === null || item === ""))
      ) {
        if (key === "bill_ids" && Array.isArray(value)) {
          acc[key] = value.map((item: any) => item.value?.toString?.() ?? item.toString?.());
        } else if (key === "due_date_of_this_bill") {
          acc[key] = dayjs(value).format("MM-DD-YY");
        } else if (
          Array.isArray(value) &&
          value.length === 2 &&
          dayjs.isDayjs(value[0]) &&
          dayjs.isDayjs(value[1])
        ) {
          acc[key] = value.map((date: Dayjs) => date.format("MM-DD-YY"));
        } else if (typeof value === "object" && value?.label && value?.value) {
          acc[key] = value.value;
        } else {
          acc[key] = value;
        }
      }
      return acc;
    }, {});

    console.log("Cleaned Data at Submit:", cleanedData);

    const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
    const tenant_id_ = localStorage.getItem("tenant_id") || "0";

    // ======================
    // 1. Create Bill
    // ======================
    const billPayload = {
      tenant_name: partner || "default_value",
      username,
      firstLastName,
      path: "/add_bill",
      role_name: role,
      parent_module: "Billing Platform",
      module_name: "Billing and Collections Bills",
      feature_module_name: "Billing and Collections Bills",
      Partner: partner,
      access_token: token,
      account_number: accountNumber,
      request_received_at: getCurrentDateTime(),
      sessionID: sessionId,
      tenant_id: tenant_id_,
      db_name: selectedDb,
      ...metaData,
billing_db_name: selectedBillingDb,
      action: "create",
      modified_by: firstLastName,
      changed_data: cleanedData,
      main_module_name: "Customer Profiles",
    };

    const billResponse = await axios.post(url, { data: billPayload });
    const billResp = JSON.parse(billResponse?.data?.body || "{}");

    if (!(billResponse.data.statusCode === 200 && billResp.flag === true)) {
      Modal.error({
        title: "Saving Error",
        content: billResp.message || "Something went wrong while saving.",
        centered: true,
      });
      setIsConfirmationOpen(false);
      return;
    }

    notification.success({
      message: "Success",
      description: billResp.message || "",
      style: messageStyle,
      placement: "top",
    });

    if (cleanedData.create === "Bill") {
      // Safely parse invoice data
      // const invoiceData = billResp.pdf_data?.data
      //   ? JSON.parse(billResp.pdf_data.data)
      //   : {};

      // let templateData: any[] = [];
      // if (billResp.pdf_data?.pdf_template) {
      //   if (Array.isArray(billResp.pdf_data.pdf_template)) {
      //     templateData = billResp.pdf_data.pdf_template;
      //   } else if (typeof billResp.pdf_data.pdf_template === "string") {
      //     try {
      //       templateData = JSON.parse(billResp.pdf_data.pdf_template);
      //       if (!Array.isArray(templateData)) templateData = [];
      //     } catch {
      //       templateData = [];
      //     }
      //   }
      // }

      // ======================
      // 2. Fetch Template Data
      // ======================
      let { items, setItems } = useItemStore.getState();
      const { logoUrl } = useLogoStore.getState();

      if (!items || items.length === 0) {
        const templatePayload = {
          tenant_name: partner || "default_value",
          username,
          firstLastName: "",
          path: "/billing_collections_bills_list_view",
          role_name: role,
          parent_module: "Billing Platform",
          module_name: "Billing and Collections Bills",
          mod_pages: { start: 0, end: 100 },
          table_name: "customer_bills",
          account_number: accountNumber,
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
          billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          feature_module_name: "Billing and Collections Bills",
        };

        const templateResponse = await axios.post(url, { data: templatePayload });
        const templateResp = JSON.parse(templateResponse.data.body);

        if (templateResp.flag && Array.isArray(templateResp.pdf_template)) {
          items = templateResp.pdf_template;
          setItems(items);
        } else {
          // const { generateDefaultTemplate } = await import(
          //   "@/app/billing/multiGenerateBill/createMultiTemplate"
          // );
          // items = generateDefaultTemplate(invoiceData, logoUrl);
          // setItems(items);
        }
      }

      // ======================
      // 3. Upload to S3 (Async, No Loader)
      // ======================
      (async () => {
        // const { generatePDFBlob } = await import(
        //   "@/app/billing/customer_profiles/billings_collections/billing_collections_sub_tabs/GeneratePDF"
        // );
        // const pdfBlob = await generatePDFBlob(invoiceData, templateData, logoUrl);

        // const base64Data = await new Promise<string>((resolve, reject) => {
        //   const reader = new FileReader();
        //   reader.onloadend = () => resolve(reader.result as string);
        //   reader.onerror = reject;
        //   reader.readAsDataURL(pdfBlob);
        // });

        // const base64String = base64Data.split(",")[1];

        const emailPayload = {
          tenant_name: partner || "default_value",
          tenant_id:tenant_id_,
          username,
          path: "/upload_pdf_to_s3",
          role_name: role,
          access_token: token,
          db_name: "billing_platform",
          billing_db_name:selectedBillingDb,
          ...metaData,
          sessionID: sessionId,
          account_number: accountNumber,
          email_trigger_details: billResp.email_trigger_details,
          // pdf_base64: base64String,
        };

        try {
          await axios.post(url, { data: emailPayload });
        } catch (err) {
          console.error("Failed to upload PDF to S3:", err);
        }
      })();
    }

    // Final cleanup
    handleCancel();
    onSave?.(
      cleanedData.create === "Charge"
        ? "Charge"
        : cleanedData.create === "Credit" &&
          (cleanedData.bill_ids === "" || cleanedData.bill_ids == null)
        ? "Credit"
        : ""
    );
  } catch (error: any) {
    console.error("Error processing data:", error);
    Modal.error({
      title: "Submit Error",
      content: error?.message || "An unexpected error occurred.",
      centered: true,
      onOk: onClose,
    });
  } finally {
    setLoading2(false);
  }
};


  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    // const hasInputErrors = Object.values(inputErrors).some(error => error !== "" && error !== null);
    // console.log("Current inputErrors:", inputErrors); // Log the inputErrors object
    // console.log(hasInputErrors,"Show has input errors");
    const isValid = validateForm(); // Validate the form
    if (isValid) {
      setIsConfirmationOpen(true);
    }
  };
  const handleCancel = () => {
    setIsConfirmationOpen(false);
    setFormData({
      //select type
      create: null,
      bill_type: null,
      specify_amount_to_bill: null,
      // usage_range: [null, null],
      due_date_of_this_bill: null,
      current_bill_cycle: [null, null],
      // enforce_no_paper_bill_fee: null,
      // final_bill_flag: null,
      // itemized_local_cost: null,
      //select charge & credit type
      charge_type: null,
      product: null,
      select_type: null,
      quantity: 1,
      total_rate: null,
      service_providers: null,
      charge_amount: null,
      buy_rate: null,
      cost: null,
      service: null,
      charge_description: '',
      options: null,
      date_range: [null, null],
      //Balance Transfer
      // transfer_to_acc: '',
      amount_to_transfer: null,
      transfer_from_name: '',
      transfer_from_account: null,
      transfer_from_current_balance: null,
      transfer_from_balance_after: null,
      transfer_to_name: '',
      transfer_to_account: null,
      transfer_to_current_balance: null,
      transfer_to_balance_after: null,
      bill_ids: null,
    });
    setBillFields(false)
    setBalanceTransferFields(false)
    setChargeFields(false)
    setCreditFields(false)
    onClose();
    setAmountError('')
    setSelectedUploadType("")
  };


  const handleCancelConfirmation = () => {
    setIsConfirmationOpen(false);
  };

  const modalWidth =
    typeof window !== 'undefined' ? (window.innerWidth * 2.5) / 4 : 0;
  const modalHeight =
    typeof window !== 'undefined' ? (window.innerHeight * 2.5) / 4 : 0;
  if (!isOpen) return null;

  const handleConfirmCreate = async () => {
    // Call SubmitData when the user confirms in the modal
    await SubmitData(formData);
  };


  const validateForm = (): boolean => {
    let isValid = true;  
    const isEmpty = (value: any) => value === null || value === undefined || value === '';
  
    switch (formData.create?.label) {
      case "Bill":
        if (
          // isEmpty(formData.specify_amount_to_bill) ||
          // isEmpty(formData.usage_range[0]) || isEmpty(formData.usage_range[1]) ||
          isEmpty(formData.current_bill_cycle[0]) || isEmpty(formData.current_bill_cycle[1]) ||
          isEmpty(formData.bill_type) ||
          isEmpty(formData.due_date_of_this_bill) 
          // formData.enforce_no_paper_bill_fee === null
          // formData.final_bill_flag === null ||
          // formData.itemized_local_cost === null
        ) {
          isValid = false;
        }
        break;
  
      case "Charge":
        if (
          // (formData.select_type?.value === "Product Type" && isEmpty(formData.charge_type)) ||
          isEmpty(formData.charge_amount) ||
          // isEmpty(formData.buy_rate) ||
          // isEmpty(formData.cost) ||  
          // isEmpty(formData.service) ||
          isEmpty(formData.charge_description) ||
          isEmpty(formData.date_range[0]) || isEmpty(formData.date_range[1])
        ) {
          isValid = false;
        }
        break;
  
      case "Credit":
        if (
          // (formData.select_type?.value === "Product Type" && isEmpty(formData.charge_type)) ||
          isEmpty(formData.charge_amount) ||
          // isEmpty(formData.buy_rate) ||
          // isEmpty(formData.cost) ||
          // isEmpty(formData.service) ||
          isEmpty(formData.charge_description) ||
          isEmpty(formData.date_range[0]) || isEmpty(formData.date_range[1])
        ) {
          isValid = false;
        }
        break;
  
      case "Balance Transfer":
        console.log("Balance Transfer Validation Running...");
        console.log("amountError:", amountError);
        console.log("formData:", formData);
        if (
          isEmpty(formData.amount_to_transfer) ||
          isEmpty(formData.transfer_from_account) ||
          isEmpty(formData.transfer_from_current_balance) ||
          isEmpty(formData.transfer_from_balance_after) ||
          isEmpty(formData.transfer_to_account) ||
          isEmpty(formData.transfer_to_current_balance) ||
          isEmpty(formData.transfer_to_balance_after) ||
          (amountError !== undefined && amountError) // Fix: Only fail if amountError is explicitly `true`
        ) {
          console.log("Validation Failed for Balance Transfer");
          isValid = false;
        }
        
        
        console.log("formdata",formData)
        break;
  
      default:
        isValid = false;
        break;
    }
  
    if (!isValid) {
      console.log("Validation Failed:", formData); // Debugging
      showErrorModal();
    }
  
    return isValid;
  };
  
  
  const showErrorModal = () => {
    Modal.error({
      title: "Form Incomplete",
      content: "Please fill all the mandatory fields.",
      centered:true
    });
  };
  



  const handleChange = (key: any, selected: any) => {
    const selectedLabel = selected?.label || '';
    setFormData((prevFormData) => ({      //select type
      create: selected,
      bill_type: null,
      specify_amount_to_bill: generalFields?.dropdown?.specify_amount_to_bill || null,
      usage_range: [null, null],
      due_date_of_this_bill: generalFields?.dropdown?.due_date_of_this_bill
        ? dayjs(generalFields.dropdown.due_date_of_this_bill)
        : null,
      current_bill_cycle: generalFields?.dropdown?.current_cycle
        ? generalFields.dropdown.current_cycle.split(" - ").map((d: string) => dayjs(d.trim()))
        : [null, null],
      enforce_no_paper_bill_fee: null,
      final_bill_flag: null,
      // itemized_local_cost: null,
      //select charge & credit type
      charge_type: null,
      charge_amount: '',
      product: null,
      select_type: null,
      quantity: 1,
      total_rate: '',
      service_providers: null,
      buy_rate: '',
      cost: '',
      service: null,
      charge_description: '',
      options: null,
      date_range: [null, null],
      //Balance Transfer
      // transfer_to_acc: '',
      amount_to_transfer: '',
      transfer_from_account: null,
      transfer_from_current_balance: '',
      transfer_from_balance_after: '',
      transfer_to_account: null,
      transfer_to_current_balance: '',
      transfer_to_balance_after: '',

      transfer_from_name:  '',
      transfer_to_name:   '',
      bill_ids: null
    }));
    setSelectedOption(selected);
    console.log(selected, "Show selected")
   setSelectedUploadType(selectedLabel)
    switch (selectedLabel) {
      case 'Bill':
        setBillFields(true);
        setChargeFields(false);
        setBalanceTransferFields(false);
        setCreditFields(false);
        break;
      case 'Charge':
        setChargeFields(true);
        setBillFields(false);
        setCreditFields(false);
        setBalanceTransferFields(false);
        break;
      case 'Credit':
        setCreditFields(true)
        setChargeFields(false);
        setBillFields(false);
        setBalanceTransferFields(false);
        break;
      case 'Balance Transfer':
        setBalanceTransferFields(true);
        setBillFields(false);
        setChargeFields(false);
        setCreditFields(false);

        break;
      default:
        setBillFields(false);
        setChargeFields(false);
        setCreditFields(false);
        setBalanceTransferFields(false);
        break;
    }
  };
 
  const handleInputChange = (key: string) => (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value;

    // Additional logic for amount_to_transfer
    if (key === 'amount_to_transfer') {
       const regex = /^\d+(\.\d{0,2})?$/;
        if (value === "" || regex.test(value)) {
          const transferAmount = Number(value);
          const currentBalance = Number(formData.transfer_from_current_balance);
  
          if (transferAmount && currentBalance && transferAmount > currentBalance) {
              setAmountError("Insufficient balance: Transfer amount cannot exceed available balance.");
          } else {
              setAmountError(""); // Clear error when valid
          }
           setFormData((prevFormData) => ({
        ...prevFormData,
        [key]: value,
    }));
        }
        else{
          return
        }
    }
    else{
       setFormData((prevFormData) => ({
        ...prevFormData,
        [key]: value,
    }));
    }

   
};
const handleNumericInputChange = (key: string) => (e: React.ChangeEvent<HTMLInputElement>) => {
  const value = e.target.value;

const regex =/^\d*\.?\d{0,2}$/;

  if (!regex.test(value)) {
    // setInputErrors((prevErrors) => ({
    //   ...prevErrors,
    //   [key]: key === 'quantity'
    //     ? "Only digits (no decimals) are allowed for quantity."
    //     : "Only numbers with up to 2 decimal digits are allowed.",
    // }));
    return;
  } else {
    setInputErrors((prevErrors) => ({
      ...prevErrors,
      [key]: "",
    }));
  }

  // Your existing logic to update formData...
  if (key === 'quantity' || key === 'charge_amount') {
    const quantityStr = key === 'quantity' ? value : String(formData.quantity);
    const chargeStr = key === 'charge_amount' ? value : String(formData.charge_amount);

    const quantityNum = parseInt(quantityStr, 10);
    const chargeNum = parseFloat(chargeStr);

    const safeQuantity = isNaN(quantityNum) ? 1 : quantityNum;
    const safeCharge = isNaN(chargeNum) ? 0 : chargeNum;

    setFormData((prevFormData) => ({
      ...prevFormData,
      [key]: value, // keep string value during input
      total_rate: value === '' ? '' : String((safeCharge * safeQuantity).toFixed(2)),
    }));
  } else {
    setFormData((prevFormData) => ({
      ...prevFormData,
      [key]: value,
    }));
  }
};




const handleTextInputChange = (key: string) => (e: React.ChangeEvent<HTMLInputElement>) => {
  const value = e.target.value;

  // Clear any existing error for this field
  setInputErrors((prevErrors) => ({
    ...prevErrors,
    [key]: "", // Assuming text fields don't have specific validation for now
  }));

  setFormData((prevFormData) => ({
    ...prevFormData,
    [key]: value,
  }));
};
// Handle change for ParentAccount selection
const handleSelectChange = (key: any) => (selected: any) => {
  if (selected === null) {
    // Handle null cases - only clear what's absolutely necessary
    if (key === 'transfer_from_account') {
      setFormData((prevFormData) => ({
        ...prevFormData,
        [key]: null,
        transfer_from_current_balance: null,
        transfer_from_balance_after: null,
        transfer_to_current_balance: null,
        transfer_to_balance_after: null,
        transfer_to_account: null,
        transfer_from_name: '',
        transfer_to_name: '',
      }));
      setSelectedParentAccount(null);
      setSelectedChildAccount(null);
    } 
    else if (key === 'transfer_to_account') {
      setFormData((prevFormData) => ({
        ...prevFormData,
        [key]: null,
        transfer_to_current_balance: null,
        transfer_to_balance_after: null,
      }));
      setSelectedChildAccount(null);
    }
    else if (key === 'charge_type') {
      // Only update product options and reset product - don't touch description
      setProductOptions(
        generalFields?.dropdown?.all_products?.map((item: string) => ({
          label: item.includes('-') ? item.split('-').slice(1).join('-').trim() : item,
          value: item,
        })) || []
      );
      setFormData((prevFormData) => ({
        ...prevFormData,
        [key]: null,
        product: null, // Only reset product
      }));
      setInputErrors(() => ({
      charge_amount: '',
      amount_to_transfer:'',
      buy_rate:'',
      cost:''
    }));
    }
    else if (key === 'product') {
      // Only clear product-related fields
      setFormData((prevFormData) => ({
        ...prevFormData,
        [key]: null,
        charge_description: '',
        charge_amount: '',
        total_rate: '',
      }));
    }
  } 
  else {
    let newTransferFromBalance = formData.transfer_from_current_balance;
    let newTransferToBalance = formData.transfer_to_current_balance;

    // Get new balance for the selected account
    if (key === 'transfer_from_account') {
      newTransferFromBalance = generalFields?.dropdown?.transfer_from_account?.[selected.value] ?? null;
    } else if (key === 'transfer_to_account') {
      newTransferToBalance = generalFields?.dropdown?.transfer_to_account?.[selected.value] ?? null;
    }
    else if (key === 'select_type') {
      setFormData((prevFormData) => ({
        ...prevFormData,
        [key]: null,
      }));
      
    
            setInputErrors(() => ({
      charge_amount: '',
      amount_to_transfer:'',
      buy_rate:'',
      cost:''
    }));
    }

    setFormData((prevFormData) => {
      const updatedFormData = {
        ...prevFormData,
        [key]: selected,
         ...(key === 'transfer_from_account' && {
          transfer_from_current_balance: newTransferFromBalance,
          transfer_from_balance_after: newTransferFromBalance
            ? Number(newTransferFromBalance) - Number(prevFormData.amount_to_transfer)
            : null,
        }),
        ...(key === 'transfer_to_account' && {
          transfer_to_current_balance: newTransferToBalance,
          transfer_to_balance_after: newTransferToBalance
            ? Number(newTransferToBalance) + Number(prevFormData.amount_to_transfer)
            : null,
        }),
      };

     
      
      // Handle charge_type - only update product options
       if (key === 'charge_type') {
        const selectedKey = selected?.value?.includes('-') 
          ? selected.value.split('-').slice(1).join('-').trim() 
          : selected.value;
        const dependentProduct = dependentProductsMap[selectedKey];
        
        if (dependentProduct) {
          const products = Array.isArray(dependentProduct) ? dependentProduct : [dependentProduct];
          setTimeout(() => {
            setProductOptions(
              products.map((item: string) => ({
                label: item.includes('-') ? item.split('-').slice(1).join('-').trim() : item,
                value: item,
              }))
            );
          }, 0);
        } else {
          setTimeout(() => {
            setProductOptions(
              generalFields?.dropdown?.all_products?.map((item: string) => ({
                label: item.includes('-') ? item.split('-').slice(1).join('-').trim() : item,
                value: item,
              })) || []
            );
          }, 0);
        }
        updatedFormData.product = null;
      }
      
      // Handle product selection
      else if (key === 'product') {
        const selectedLabel = selected?.label || selected?.value || '';
        const selectedAmount = dependentProductsAmount[selectedLabel];

        updatedFormData.charge_description = selectedLabel;
        updatedFormData.charge_amount = selectedAmount !== undefined && selectedAmount !== null
          ? String(selectedAmount)
          : '';

        // Set default quantity if not already set
        const quantity = formData.quantity && Number(formData.quantity);
        updatedFormData.quantity = quantity;

        // Update total_rate = amount × quantity
        if (selectedAmount !== undefined && selectedAmount !== null) {
          updatedFormData.total_rate = String(Number(selectedAmount) * quantity);
        } else {
          updatedFormData.total_rate = '';
        }
      }

      // Revalidate amount error after account change
      if (updatedFormData.amount_to_transfer && updatedFormData.transfer_from_current_balance) {
        const transferAmount = Number(updatedFormData.amount_to_transfer);
        const currentBalance = Number(updatedFormData.transfer_from_current_balance);

        if (transferAmount > currentBalance) {
          setAmountError("Insufficient balance: Transfer amount cannot exceed available balance.");
        } else {
          setAmountError(""); // Clear error when valid
        }
      }

      return updatedFormData;
    });

    // Update selected accounts
    setSelectedParentAccount(key === 'transfer_from_account' ? selected.value : selectedParentAccount);
    setSelectedChildAccount(key === 'transfer_to_account' ? selected.value : selectedChildAccount);
  }
};




// Filter out the selected parent account from the child options
const filteredChildOptions = ChildAccountOptions.filter(
  (option: any) => option.value !== selectedParentAccount
);
  
 const fetchSpecifyAmountToBill = async () => {
          let parsedData: any;
          try {
            // setLoading(true);
            const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/fetch_specify_amount_to_bill",     
              account_number: accountNumber,
              role_name: role,
              parent_module: "Billing Platform",
              module_name: "Billing and Collections Bills",
              feature_module_name: "Billing and Collections Bills",
              main_module_name: "Customer Profiles",
              // table_name:"customer_profiles",
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
              ...metaData,
billing_db_name: selectedBillingDb,
              sessionID: sessionId,
              current_bill_cycle: formData.current_bill_cycle,
            };
      
            const response = await axios.post(url, { data });
            console.log(response)
            parsedData = JSON.parse(response.data.body);
            console.log(parsedData)
            if (parsedData.flag === true) {
              console.log("table response:", parsedData);
              setLoading(false);
      
              setTimeout(() => {
                setFormData((prevFormData) => ({
                  ...prevFormData,
                  specify_amount_to_bill: parsedData.specify_amount_to_bill || null,
                }));
              }, 0);
            } else {
              // setLoading(false);
              console.log("flag set to false")
              // Modal.error({
              //   title: "Data Fetch Error",
              //   content: parsedData.message || "An error occurred while fetching data. Please try again.",
              //   centered: true,
              // });
            }
          } catch (error) {
            // setLoading(false);
            // Modal.error({
            //   title: "Data Fetch Error",
            //   content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
            //   centered: true,
            // });
            console.error("Error fetching specify amount to bill:", error);
          } finally {
            // setLoading(false);
          }
 }
  const handleDateChange = (field: keyof FormData) =>
    
    async (dates: [Dayjs | null, Dayjs | null] | null, dateStrings: [string, string]) => {
      if (field === "current_bill_cycle") {
      await fetchSpecifyAmountToBill();
    }
    
      setFormData((prevState) => ({
        ...prevState,
        [field]: dates || [null, null],
      }));
      console.log("formdata",formData)
    };
  const handleSingleDateChange = (field: keyof FormData) =>
    (date: Dayjs | null) => {
      setFormData((prev) => ({
        ...prev,
        [field]: date, // Store single date value
      }));
    };

//To conver the blob to xlsx
  const downloadBlob = (base64Blob: string,fileName:string) => {
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    const blobObject = new Blob([byteArray], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blobObject);
    link.download = `${fileName}.xlsx`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleUploadClick = () => {
      setIsUploadModalVisible(true);
  
    }
    const handleDownloadTemplate = async (templateFlag:string) => {
      handleUploadModalClose()
      setLoading(true);
      const fileName=`${selectedUploadType} ${templateFlag==="product_type"?"Product Type":"Product"}`
      const url =
        ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/download_credit_charge_template",
        parent_module:"Billing Platform",
        module_name: "Charge Overview",
        feature_module_name:"Charge Overview",
        main_module_name: "Customer Profiles",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        bill_flag:selectedUploadType,
        template_flag:templateFlag,
        table_name:`${templateFlag}s`
      };
  
      const response = await axios.post(url, { data });
      const resp = JSON.parse(response.data.body);
      const blob = resp.blob;
      console.log(resp);
      if (response.data.statusCode === 200) {
        if (resp.flag === true) {
          notification.success({
            message: 'Success',
            description: 'Successfully downloaded the template!',
            style: messageStyle,
            placement: 'top',
          });
          downloadBlob(blob,fileName);
          setLoading(false);
          setIsUploadModalVisible(false);
        } else {
          console.log('Error message:', resp.message);
          Modal.error({
            title: 'Export Error',
            content: resp.message,
            centered: true,
          });
        }
      } else {
        console.log('Unexpected status code:', response.data.statusCode);
        Modal.error({
          title: 'Export Error',
          content: resp.message,
          centered: true,
        });
      }
    };
    const handleUploadModalClose = () => {
      setIsUploadModalVisible(false);
    };
    const handleUpload = async (blob: string) => {
      handleUploadModalClose()
      setLoading(true)
      try {
        const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;  
 
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/import_credit_charge_bulk_upload",
          parent_module:"Billing Platform",
          module_name: "Charge Overview",
          feature_module_name:"Charge Overview",
        main_module_name: "Customer Profiles",
          role_name: role,
          Partner: partner,
          request_received_at: getCurrentDateTime(),
          access_token: token,
          db_name: selectedDb,
          ...metaData,
billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenant_id_,
          blob: blob, // Include the Blob in the data
          table_name:"customer_charges",
          account_number:accountNumber
        };
  
        const response = await axios.post(url, { data });
  
        const resp = JSON.parse(response.data.body);
        if (response.data.statusCode === 200) {
          if (resp.flag === true) {
            notification.success({
              message: 'Success',
              description: 'Successfully uploaded the record!',
              placement: 'top',
            });
          } else {
            Modal.error({
              title: 'Import Error',
              content: resp.message,
              centered: true,
              onOk: handleErrorModalClose,
              onCancel: handleErrorModalClose
            });
          }
        } else {
          Modal.error({
            title: 'Import Error',
            content: resp.message,
            centered: true,
            onOk: handleErrorModalClose,
            onCancel: handleErrorModalClose
          });
        }
      } catch (error) {
        console.error('Error during file upload:', error);
        Modal.error({
          title: 'Import Error',
          content: 'There was an error uploading the file.',
          centered: true,
          onOk: handleErrorModalClose,
          onCancel: handleErrorModalClose
        });
  
      }
      finally {
        setLoading(false)
        setIsUploadModalVisible(false)
      }
    }
    const handleErrorModalClose = () => {
      setIsUploadModalVisible(false)
    }
const handleUploadChange = (info: any) => {
    if (info.file.status === 'done') {
      let blob;
      const file = info.file.originFileObj; // Get the file object
      const reader = new FileReader();
      reader.onload = (e: any) => {
        // Get the file data URL (Base64 string)
        blob = e.target.result;
        console.log('File Base64 String:', blob);
        handleUpload(blob)
        setUploadKey(Date.now());
      };

      if (blob) {
      }

      reader.readAsDataURL(file); // Read the file as data URL
    } else if (info.file.status === 'error') {
      // Handle upload error
      message.error('Upload failed.');
    }
    else if (info.file.status === 'removed') {
      
    }
  };
  const uploadProps = {
    key: uploadKey,
    accept: '.xlsx, .xls',
    beforeUpload: (file: any) => {
      // Check if file is an Excel file
      const isExcel = file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || file.type === 'application/vnd.ms-excel';
      if (!isExcel) {
        message.error('You can only upload Excel files!');
      }
      return isExcel;
    },
    onChange: handleUploadChange,
  };
  if (loading2) {
    return (
      <div className="absolute inset-0 flex justify-center items-center bg-white bg-opacity-75 z-50 border pointer-events-none">
        <div className='flex justify-center'>
          <Spin size="large" />
        </div>

      </div>

    );
  }

  return (
    <div
    >
      <Modal
        open={isOpen}
        onCancel={handleCancel}
        title={
          <h3 className='popup-heading'>
            Create
          </h3>
        }
        centered
        footer={
          <div className="justify-center flex space-x-2 mt-7">
            <button onClick={handleCancel} className="cancel-btn">
              Cancel
            </button>
            <button onClick={handleSave} className="save-btn">
              Save
            </button>
          </div>
        }
        width={'780px'}
        styles={{ body: { height: modalHeight, overflowY: 'hidden' } }}

      >
        <>

          <div className={`${modalData.length > 5 ? 'popup' : ''}`}>
            <form onSubmit={handleSave}>
              {loading ? (
                <div className="flex justify-center items-center w-full h-full absolute top-0 left-0">
                  <Spin size="large" />
                </div>
              ) : (
                <>
                <div className={`${selectedUploadType && (selectedUploadType==="Charge" || selectedUploadType==="Credit") ? '' : 'hidden'} flex justify-end`}>
                  <button
                  // type="default"
                  // icon={<PlusOutlined />}
                  // className={`${revRows.length > 0 && !isDuplicates ? "save-btn" : "deactive"} p-[4px] min-h-[40px] w-[215px] pr-[8px]`}
                  type="button"
                  className="save-btn"
                  onClick={handleUploadClick}
                >
                  <UploadOutlined style={{ marginRight: '4px' }} />
                  Upload
                </button>
                </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="flex flex-col">
                    <Dropdown
                      options={options}
                      value={formData.create}
                      onChange={(selected: any) => handleChange('create', selected)} // Use an anonymous function to call handleChange
                      placeholder="Create"
                      mandatory={true}

                    />
                  </div>

                    {billFields && (
                      <>
                        <div className="flex flex-col">
                          <label className="field-label">Current Cycle<span className="text-red-500 ml-1">*</span></label>
                          <RangePicker
                            value={formData.current_bill_cycle || [null,null]}
                            onChange={handleDateChange('current_bill_cycle')}
                            className="input"
                            placeholder={['Start Date', 'End Date']}
                            disabledDate={(current) => {
                              // Disable all dates before today
                              return current && current < dayjs().startOf('day');
                            }}
                            format="MM-DD-YY"
                          />
                          
                        </div>
                        <div className="flex flex-col">
                        
                        <Dropdown
                          options={billTypeOptions}
                          value={formData.bill_type}
                          onChange={handleSelectChange('bill_type')}
                          placeholder="Bill Type"
                          className="input"
                          mandatory={true}
                        />
                      
                        </div>
                        {/* <div className="flex flex-col">
                        
                        <Dropdown
                          options={booleanOptions}
                          value={formData.itemized_local_cost}
                          onChange={handleSelectChange('itemized_local_cost')}
                          placeholder="Itemize Local Calls"
                          className="input"
                          mandatory={true}
                        />
                      
                        </div> */}
                        {/* <div className="flex flex-col">

                        <Dropdown
                          options={booleanOptions}
                          value={formData.final_bill_flag}
                          onChange={handleSelectChange('final_bill_flag')}
                          placeholder="Is this a final bill?"
                          className="input"
                          mandatory={true}
                        />
                      
                        </div> */}
                        {/* <div className="flex flex-col">
                        <Dropdown
                          options={booleanOptions}
                          value={formData.enforce_no_paper_bill_fee}
                          onChange={handleSelectChange('enforce_no_paper_bill_fee')}
                          placeholder="Enforce no paper bill fee?"
                          className="input"
                          mandatory={true}
                        />
                        
                        </div> */}

                        <div className="flex flex-col">
                          <label className="field-label">
                            Due Date of this Bill<span className="text-red-500 ml-1">*</span>
                          </label>
                          <DatePicker
                            value={formData.due_date_of_this_bill || null }
                            onChange={handleSingleDateChange('due_date_of_this_bill')}
                            className="input"
                            placeholder="Select Due Date"
                            format="MM-DD-YY"
                             disabledDate={(current) => {
                            // Disable only past dates (today and future are enabled)
                            return current && current < dayjs().startOf('day');
                          }}
                          />
                          
                        </div>

                        {/* <div className="flex flex-col">
                          <label className="field-label">Usage Range<span className="text-red-500 ml-1">*</span></label>
                          <RangePicker
                            value={formData.usage_range as [Dayjs, Dayjs]}
                            onChange={handleDateChange('usage_range')}
                            className="input"
                            placeholder={['Start Date', 'End Date']}
                            disabledDate={(current) => {
                              return current && current <= dayjs().endOf('day');
                            }}
                          />
                          
                        </div> */}
                        
                        <div className="flex flex-col">
                          <label className="field-label">Specify Amount To Bill</label>
                          <div className="relative">
                          <span className="absolute left-2 top-1/2 transform -translate-y-1/2 pointer-events-none z-10">
                              $
                            </span>
                          <Input
                            type="text"
                            // pattern="[0-9]*"
                            // onKeyPress={handleKeyPress}
                            className="input !pl-4"
                            value={formData.specify_amount_to_bill}
                            onChange={handleNumericInputChange('specify_amount_to_bill')}
                            placeholder="Enter Amount"
                          />
                          </div>
                          {/* {inputErrors['specify_amount_to_bill'] && (
                            <span className="text-red-500">{inputErrors['specify_amount_to_bill']}</span>
                          )} */}
                        </div>
                      </>
                    )}

                  {chargeFields && (
                          <>
                            {/* Row 1: Product Type (full width) */}
                            {/* <div className="flex flex-col">
                              <Dropdown
                                options={ProductTypeOptions}
                                value={formData.charge_type}
                                onChange={handleSelectChange('charge_type')}
                                placeholder="Product Type"
                                className="input"
                                mandatory={true}
                              />
                            </div> */}

                            {/* Row 2: Product | Description (50% each) */}
                              <div className="flex flex-col ">
                                <Dropdown
                                  options={ProductOptions}
                                  value={formData.product}
                                  onChange={handleSelectChange('product')}
                                  placeholder="Product"
                                  className="input"
                                  mandatory={true}
                                />
                              </div>
                              
                              <div className="flex flex-col ">
                                <label className="field-label">Description<span className="text-red-500 ml-1">*</span></label>
                                <Input
                                  type="text"
                                  className="input"
                                  value={formData.charge_description}
                                  onChange={handleTextInputChange('charge_description')}
                                  placeholder="Enter Description"
                                  readOnly={!formData.product}
                                />
                              </div>
                            {/* Row 4: Date Range | Service (50% each) */}
                               <div className="flex flex-col ">
                                <label className="field-label">
                                  Date Range<span className="text-red-500 ml-1">*</span>
                                </label>
                                <RangePicker
                                  value={formData.date_range as [Dayjs, Dayjs]}
                                  onChange={handleDateChange('date_range')}
                                  className="input"
                                  format="MM-DD-YY"
                                  placeholder={['Start Date', 'End Date']}
                                />
                              </div>
                            {/* Row 3: Amount | Quantity | Total Rate (33.33% each) */}
                              <div className="flex flex-col">
                                <label className="field-label">Amount<span className="text-red-500 ml-1">*</span></label>
                                <div className="flex items-center">
                                  <div className="relative  w-[95%]">
                                    <span className="absolute left-2 top-1/2 transform -translate-y-1/2 pointer-events-none z-10">
                                      $
                                    </span>
                                    <Input
                                      type="text"
                                      className="input !pl-4"
                                      value={formData.charge_amount}
                                      onChange={handleNumericInputChange('charge_amount')}
                                      placeholder="Enter Amount"
                                    />
                                  </div>
                                  <div className="w-[10%] flex items-center justify-center pl-[5%]">
                                    <span className="text-xl">X</span>
                                  </div>
                                </div>
                                {inputErrors['charge_amount'] && (
                                  <span className="text-red-500 text-sm mt-1">{inputErrors['charge_amount']}</span>
                                )}
                              </div>
                              
                            <div className="flex flex-col">
                              <div className="flex space-x-4">

                                <div className="flex flex-col w-1/2">
                                  <label className="field-label">Quantity</label>
                                  <Input
                                    type="number"
                                    className="input"
                                    min={0}
                                    value={formData.quantity}
                                    onChange={handleNumericInputChange('quantity')}
                                    onKeyDown={(e) => {
                                        if (!/[\d]/.test(e.key) && e.key !== 'Backspace' && e.key !== 'Delete' && e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') {
                                          e.preventDefault();
                                        }
                                      }}
                                    onWheel={(e) => {
                                      (e.target as HTMLInputElement).blur();
                                    }} 
                                    placeholder="Enter Quantity"
                                  />

                                  {/* {inputErrors['quantity'] && (
                                  <span className="text-red-500 text-sm mt-1">{inputErrors['quantity']}</span>
                                )} */}
                                </div>
                                {/* Total Rate (Amount x Quantity) */}
                                <div className="flex flex-col w-1/2">
                                  <label className="field-label">Total Rate</label>
                                  <div className="relative">
                                    <span className="absolute left-2 top-1/2 transform -translate-y-1/2 pointer-events-none z-10">
                                      $
                                    </span>
                                    <Input
                                      type="text"
                                      className="input !pl-4"
                                      value={formData.total_rate}
                                      readOnly
                                      placeholder="Total Rate"
                                    />
                                  </div>
                                </div>
                              </div>
                            </div>
                             

                              <div className="flex flex-col ">
                                <Dropdown
                                  options={ServiceTypeOptions}
                                  value={formData.service}
                                  onChange={handleSelectChange('service')}
                                  placeholder="Service"
                                  className="input"
                                  mandatory={false}
                                />
                              </div>
                            {/* Row 6: Buy Rate | Cost (50% each) */}
                              <div className="flex flex-col ">
                                <label className="field-label">Buy Rate</label>
                                <div className="relative">
                                  <span className="absolute left-2 top-1/2 transform -translate-y-1/2 pointer-events-none z-10">
                                    $
                                  </span>
                                  <Input
                                    type="text"
                                    className="input !pl-4"
                                    value={formData.buy_rate}
                                    onChange={handleNumericInputChange('buy_rate')}
                                    placeholder="Enter Buy Rate"
                                  />
                                </div>
                                {inputErrors['buy_rate'] && (
                                  <span className="text-red-500 text-sm mt-1">{inputErrors['buy_rate']}</span>
                                )}
                              </div>

                              <div className="flex flex-col ">
                                <label className="field-label">Cost</label>
                                <div className="relative">
                                  <span className="absolute left-2 top-1/2 transform -translate-y-1/2 pointer-events-none z-10">
                                    $
                                  </span>
                                  <Input
                                    type="text"
                                    className="input !pl-4"
                                    value={formData.cost}
                                    onChange={handleNumericInputChange('cost')}
                                    placeholder="Enter Cost"
                                  />
                                </div>
                                {inputErrors['cost'] && (
                                  <span className="text-red-500 text-sm mt-1">{inputErrors['cost']}</span>
                                )}
                              </div>

                            {/* Row 7: Service Provider (50%) */}
                              <div className="flex flex-col ">
                                <Dropdown
                                  options={ServiceProviderOptions}
                                  value={formData.service_providers}
                                  onChange={handleSelectChange('service_providers')}
                                  placeholder="Service Provider"
                                  className="input"
                                  mandatory={false}
                                />
                              </div>
                          </>
                        )}
                      {creditFields && (
                        <>
                          {/* Row 1: Product Type (full width) */}
                          {/* <div className="flex flex-col">
      <Dropdown
        options={ProductTypeOptions}
        value={formData.charge_type}
        onChange={handleSelectChange('charge_type')}
        placeholder="Product Type"
        className="input"
        mandatory={true}
      />
    </div> */}

                          {/* Row 2: Product | Description (50% each) */}
                          <div className="flex flex-col ">
                            <Dropdown
                              options={ProductOptions}
                              value={formData.product}
                              onChange={handleSelectChange('product')}
                              placeholder="Product"
                              className="input"
                              mandatory={true}
                            />
                          </div>
                          <div className="flex flex-col">
                            <label className="field-label">
                              Description<span className="text-red-500 ml-1">*</span>
                            </label>
                            <Input
                              type="text"
                              className="input"
                              value={formData.charge_description}
                              onChange={handleTextInputChange('charge_description')}
                              placeholder="Enter Description"
                            />
                          </div>
                             {/* Row 4: Date Range | Service */}
                          <div className="flex flex-col">
                            <label className="field-label">
                              Date Range<span className="text-red-500 ml-1">*</span>
                            </label>
                            <RangePicker
                              value={formData.date_range as [Dayjs, Dayjs]}
                              onChange={handleDateChange('date_range')}
                              className="input"
                              format="MM-DD-YY"
                              placeholder={['Start Date', 'End Date']}
                            />
                          </div>
                          {/* Row 3: Amount | Quantity | Total Rate */}
                          <div className="flex flex-col">
                            <label className="field-label">Amount<span className="text-red-500 ml-1">*</span></label>
                            <div className="flex items-center">
                              <div className="relative  w-[95%]">
                                <span className="absolute left-2 top-1/2 transform -translate-y-1/2 pointer-events-none z-10">
                                  $
                                </span>
                                <Input
                                  type="text"
                                  className="input !pl-4"
                                  value={formData.charge_amount}
                                  onChange={handleNumericInputChange('charge_amount')}
                                  placeholder="Enter Amount"
                                />
                              </div>
                              <div className="w-[10%] flex items-center justify-center pl-[5%]">
                                <span className="text-xl">X</span>
                              </div>
                            </div>
                            {inputErrors['charge_amount'] && (
                              <span className="text-red-500 text-sm mt-1">{inputErrors['charge_amount']}</span>
                            )}
                          </div>
                          <div className="flex flex-col">
                            <div className="flex space-x-4">
                              <div className="flex flex-col w-1/2">
                                <label className="field-label">Quantity</label>
                                <Input
                                  type="number"
                                  className="input"
                                  min={0}
                                  value={formData.quantity}
                                  onChange={handleNumericInputChange('quantity')}
                                  onKeyDown={(e) => {
                                    if (!/[\d]/.test(e.key) && e.key !== 'Backspace' && e.key !== 'Delete' && e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') {
                                      e.preventDefault();
                                    }
                                  }}
                                  onWheel={(e) => {
                                    (e.target as HTMLInputElement).blur();
                                  }}
                                  
                                  placeholder="Enter Quantity"
                                />
                              </div>
                              {/* Total Rate (Amount x Quantity) */}
                              <div className="flex flex-col w-1/2">
                                <label className="field-label">Total Rate</label>
                                <div className="relative">
                                  <span className="absolute left-2 top-1/2 transform -translate-y-1/2  pointer-events-none z-10">
                                    $
                                  </span>
                                  <Input
                                    type="text"
                                    className="input !pl-4"
                                    value={formData.total_rate}
                                    readOnly
                                    placeholder="Total Rate"
                                  />
                                </div>
                              </div>
                            </div>
                          </div>

                         

                          <div className="flex flex-col">
                            <Dropdown
                              options={ServiceTypeOptions}
                              value={formData.service}
                              onChange={handleSelectChange('service')}
                              placeholder="Service"
                              className="input"
                              mandatory={false}
                            />
                          </div>

                          {/* Row 5: Invoices (full width) */}
                          <div className="flex flex-col">
                            <label className="field-label">Invoices</label>
                            <Select
                              mode="multiple"
                              allowClear
                              options={billIdsList}
                              placeholder="Select"
                              value={formData.bill_ids ? (Array.isArray(formData.bill_ids) ? formData.bill_ids.map((item: any) => item.value ?? item) : [formData.bill_ids.value ?? formData.bill_ids]) : []}
                              onChange={(values) => {
                                const selectedOptions = values.map((val: any) => {
                                  const found = billIdsList.find(item => item.value === val);
                                  return found || { label: val, value: val };
                                });
                                setFormData((prev) => ({
                                  ...prev,
                                  bill_ids: selectedOptions,
                                }));
                              }}
                              maxTagCount={3}
                              maxTagPlaceholder={(omittedValues) => `+${omittedValues.length} more`}
                            />
                          </div>

                          {/* Row 6: Buy Rate | Cost */}
                          <div className="flex flex-col">
                            <label className="field-label">Buy Rate</label>
                            <div className="relative">
                              <span className="absolute left-2 top-1/2 transform -translate-y-1/2 pointer-events-none z-10">
                                $
                              </span>
                              <Input
                                type="text"
                                className="input !pl-4"
                                value={formData.buy_rate}
                                onChange={handleNumericInputChange('buy_rate')}
                                placeholder="Enter Buy Rate"
                              />
                            </div>
                            {inputErrors['buy_rate'] && (
                              <span className="text-red-500 text-sm mt-1">{inputErrors['buy_rate']}</span>
                            )}
                          </div>

                          <div className="flex flex-col">
                            <label className="field-label">Cost</label>
                            <div className="relative">
                              <span className="absolute left-2 top-1/2 transform -translate-y-1/2 pointer-events-none z-10">
                                $
                              </span>
                              <Input
                                type="text"
                                className="input !pl-4"
                                value={formData.cost}
                                onChange={handleNumericInputChange('cost')}
                                placeholder="Enter Cost"
                              />
                            </div>
                            {inputErrors['cost'] && (
                              <span className="text-red-500 text-sm mt-1">{inputErrors['cost']}</span>
                            )}
                          </div>

                          {/* Row 7: Service Provider */}
                          <div className="flex flex-col ">
                            <Dropdown
                              options={ServiceProviderOptions}
                              value={formData.service_providers}
                              onChange={handleSelectChange('service_providers')}
                              placeholder="Service Provider"
                              className="input"
                              mandatory={false}
                            />
                          </div>
                        </>
                      )}


                    {balanceTransferFields && (
                      <><div className="flex flex-col">
                        <label className="field-label">Amount to Transfer<span className="text-red-500 ml-1">*</span></label>
                        <div className="relative">
                          <span className="absolute left-2 top-1/2 transform -translate-y-1/2 pointer-events-none z-10">
                            $
                          </span>
                          <Input
                            type="text"
                            className="input !pl-4"
                            value={formData.amount_to_transfer}
                            onChange={handleInputChange('amount_to_transfer')}
                            placeholder="Enter" />
                        </div>
                        {inputErrors['amount_to_transfer'] && (
                          <span className="text-red-500">{inputErrors['amount_to_transfer']}</span>
                        )}
                        {amountError && <span className="text-red-500">{amountError}</span>}
                      </div><div className="col-span-1 sm:col-span-2">
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-2">
                            {/* Transfer From Title */}
                            <div className="col-span-1 sm:col-span-2">
                              <h2 className="text-lg font-semibold">Transfer From</h2>
                            </div>

                            <div className="flex flex-col">
                              <label className="field-label">Name</label>
                              <Input
                                type="text"
                                className="input !text-black cursor-not-allowed"
                                value={formData.transfer_from_name}
                                onChange={handleInputChange('transfer_from_name')}
                                disabled />
                            </div>

                            <div className="flex flex-col">
                              <Dropdown
                                options={ParentAccountOptions}
                                value={formData.transfer_from_account}
                                onChange={handleSelectChange('transfer_from_account')}
                                placeholder="Account#"
                                className="input"
                                mandatory={true} />
                            </div>

                            <div className="flex flex-col">
                              <label className="field-label">Current Balance</label>
                              <div className="relative">
                                <span className="absolute left-2 top-1/2 transform -translate-y-1/2 pointer-events-none z-10">
                                  $
                                </span>
                                <Input
                                  type="text"
                                  className="input !pl-4 !text-black"
                                  value={formData.transfer_from_current_balance}
                                  onChange={handleInputChange('transfer_from_current_balance')}
                                  disabled />
                              </div>
                            </div>

                            <div className="flex flex-col">
                              <label className="field-label">Balance After</label>
                              <div className="relative">
                                <span className="absolute left-2 top-1/2 transform -translate-y-1/2 pointer-events-none z-10">
                                  $
                                </span>
                                <Input
                                  type="number"
                                  className="input !pl-4 !text-black"
                                  value={formData.transfer_from_balance_after}
                                  onChange={handleInputChange('transfer_from_balance_after')}
                                  disabled />
                              </div>
                            </div>

                            {/* Transfer To Title */}
                            <div className="col-span-1 sm:col-span-2 mt-2">
                              <h2 className="text-lg font-semibold">Transfer To</h2>
                            </div>

                            <div className="flex flex-col">
                              <label className="field-label">Name</label>
                              <Input
                                type="text"
                                className="input !text-black"
                                value={formData.transfer_to_name}
                                onChange={handleInputChange('transfer_to_name')}
                                disabled />
                            </div>

                            <div className="flex flex-col">
                              <Dropdown
                                options={filteredChildOptions}
                                value={formData.transfer_to_account}
                                onChange={handleSelectChange('transfer_to_account')}
                                placeholder="Account#"
                                className="input"
                                mandatory={true} />
                            </div>

                            <div className="flex flex-col">
                              <label className="field-label">Current Balance</label>
                              <div className="relative">
                                <span className="absolute left-2 top-1/2 transform -translate-y-1/2 pointer-events-none z-10">
                                  $
                                </span>
                                <Input
                                  type="number"
                                  className="input !pl-4 !text-black"
                                  value={formData.transfer_to_current_balance}
                                  onChange={handleInputChange('transfer_to_current_balance')}
                                  disabled />
                              </div>
                            </div>

                            <div className="flex flex-col">
                              <label className="field-label">Balance After</label>
                              <div className="relative">
                                <span className="absolute left-2 top-1/2 transform -translate-y-1/2 pointer-events-none z-10">
                                  $
                                </span>
                                <Input
                                  type="number"
                                  className="input !pl-4 !text-black"
                                  value={formData.transfer_to_balance_after}
                                  onChange={handleInputChange('transfer_to_balance_after')}
                                  disabled />
                              </div>
                            </div>
                          </div>
                        </div></>
                    )}
                </div>
                </>
              )}
            </form>
          </div>
        </>
      </Modal>

       {/* Upload Modal*/}
                <Modal
                  title="Upload Files"
                  visible={isUploadModalVisible}
                  onCancel={handleUploadModalClose}
                  footer={null}
                  centered
                  width={400}
                >
                  <div className="flex flex-col gap-4">
                    <div className="flex flex-col  gap-4 justify-center p-4">
                        <Upload {...uploadProps} className="cursor-pointer upload-btn">
                        <button className="">
                          <span  className="mr-2"><UploadOutlined/></span>
                          Upload
                        </button>
                      </Upload>
                      <span></span>
                      <button
                        onClick={()=>handleDownloadTemplate("product_type")}
                        className="upload-btn disabled:cursor-not-allowed"
                      >
                        <span className="mr-2"><DownloadOutlined /></span>
                        Product Types Template
                      </button>
                      <button
                        onClick={()=>handleDownloadTemplate("product")}
                        className="upload-btn disabled:cursor-not-allowed"
                      >
                        <span className="mr-2"><DownloadOutlined /></span>
                        Products Template
                      </button>
                    </div>
                  </div>
                </Modal>
      
      <Modal
        title="Confirmation"
        open={isConfirmationOpen}
        onCancel={handleCancelConfirmation}
        centered
        footer={
          <div style={{ display: 'flex', justifyContent: 'center', width: '100%', gap: "6px" }}>
            <button
              className="cancel-btn"
              onClick={handleCancelConfirmation}
            >
              Cancel
            </button>
            <button
              className="save-btn"
              onClick={handleConfirmCreate}
            >
              OK
            </button>
          </div>
        }
      >
        <p>Are you sure you want to Create this {formData.create?.label}</p>
      </Modal>
    </div>

  );
};

export default CreateBillModal;

