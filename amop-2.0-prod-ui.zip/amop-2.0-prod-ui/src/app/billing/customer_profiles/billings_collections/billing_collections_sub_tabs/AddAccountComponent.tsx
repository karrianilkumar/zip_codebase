import React, { useState, useRef, useCallback, lazy, useEffect, Suspense} from 'react';
import { ArrowLeftOutlined, CloseOutlined } from '@ant-design/icons'; // Import an icon from Ant Design or any other icon library
import { useFeatureStore } from "../../../../sim_management/inventory/featureStore";
import { ENV_ROUTES } from '@/app/components/routes/route_constants';
import { getCurrentDateTime } from '@/app/components/header_constants';
import axios from 'axios';
import { Modal } from 'antd/lib';
import { useAuth } from '@/app/components/auth_context';
import { Spin } from 'antd';
import { ArrowLeftIcon } from '@heroicons/react/24/outline';
const KillbillTableComponent = lazy(
  () => import("../../../killbill_components/table__component")
);

const AddAccountComponent = ({ onClose, row}:{ onClose :() => void, row: any }) => {  //({ onClose, invoiceData, tableData, summaryData })
  const [viewportHeight, setViewportHeight] = useState(window.innerHeight);

   const [searchTerm, setSearchTerm] = useState("");
    const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
    const { username, partner, role, token, selectedDb,selectedBillingDb,sessionId, settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId, firstLastName , setStoredPagination , setAdvancedStoredPagination} = useAuth();
    const [pagination, setPagination] = useState<any>({});
    const [tableData, setTableData] = useState<any>([]);
    const [features, setFeatures] = useState<string[]>([]);
    const [headers, setHeaders] = useState<any[]>([]);
    const [headerMap, setHeaderMap] = useState<any>({});
    
    const [loading, setLoading] = useState(false);
    const [filteredData, setFilteredData] = useState([]);
    const [createModalData, setcreateModalData] = useState<any[]>([]);
    const [allowedActions, setAllowedActions] = useState<any[]>([]);
    const [generalFields, setgeneralFields] = useState<any[]>([]);
  
    const hasFetchedData = useRef(false);
    const {
    
      features: moduleFeatures,
      setFeatures: setModuleFeatures,
      
    } = useFeatureStore();
    // const queryClient = useQueryClient();
  
    type HeaderMap = Record<string, [string, number]>;
  
    const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
      const entries = Object.entries(headerMap) as [string, [string, number]][];
      entries.sort((a, b) => a[1][1] - b[1][1]);
      return Object.fromEntries(entries) as HeaderMap;
    }, []);

    // eslint-disable-next-line react-hooks/exhaustive-deps
    const fetchData = async () => {
        setStoredPagination(null);
        setAdvancedStoredPagination(null);
        let parsedData: any;
        try {
          setLoading(true);
          const url = ENV_ROUTES.BP_SERVICES_PRODUCTS;
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/services_list_view",
            role_name: role,
            parent_module: "Billing Platform",
            module_name: "Billing Services",
            sub_module:"Services",
            mod_pages: {
              start: 0,
              end: 100,
            },
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
            ...metaData,
billing_db_name: selectedBillingDb,
            sessionID: sessionId,
            feature_module_name: "Billing Services",
          };
    
          const response = await axios.post(url, { data });
          console.log(response)
          parsedData = JSON.parse(response.data.body);
          console.log(parsedData)
    
          if (parsedData.flag === true) {
            setLoading(false);
            // Defer other state updates using a timeout to decouple them from the main thread
            setTimeout(() => {
              const headersMap_ = parsedData?.header_map?.["Billing Services"]?.header_map || {};
              const sortedheaderMap = sortHeaderMap(headersMap_);
              setHeaderMap(sortedheaderMap);
              
    
              const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
              console.log("headers", headers_)
              setHeaders(headers_);
              setVisibleColumns(headers_);
              const generalFields_ = parsedData || {}
              setgeneralFields(generalFields_)
              console.log("generalFields_",generalFields_)
              setFeatures(parsedData?.header_map?.["Billing Services"]?.module_features || []);
              setModuleFeatures(parsedData?.header_map?.["Billing Services"]?.module_features || []);
              const featres_ = parsedData?.header_map?.["Billing Services"]?.module_features || []
              const allowedActions_:any=[]
              if(featres_.includes("Edit-Billing Services")){
                allowedActions_.push("adjust")
              }
              // if(featres_.includes("Delete-Billing Services")){
              //   allowedActions_.push("delete")
              // }
              if(featres_.includes("Copy-Billing Services")){
                allowedActions_.push("paynow")
              }
              if(featres_.includes("Discontinue-Billing Services")){
                allowedActions_.push("delete")
    
              }
              
              setAllowedActions(allowedActions_)
              const createModalData_=parsedData?.header_map?.["Billing Services"]?.pop_up||[]
              console.log("createModalData_",createModalData_)
              setcreateModalData(createModalData_)
              setPagination(parsedData?.pages || {});
              setTableData(parsedData?.data?.billing_services || []);
    
             
            }, 0);
            
          } else {
            setLoading(false);
            console.log("flag set to false")
            Modal.error({
              title: "Data Fetch Error",
              content: parsedData.message || "An error occurred while fetching data. Please try again.",
              centered: true,
            });
          }
        } catch (error) {
          setLoading(false);
          Modal.error({
            title: "Data Fetch Error",
            content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
            centered: true,
          });
        } finally {
          setLoading(false);
        }
      };
     useEffect(() => {
        if (!hasFetchedData.current) {
          fetchData();
          hasFetchedData.current = true;
        }
      }, [fetchData]);

      if (loading) {
        return (
          <div className="flex justify-center items-center h-screen">
            <Spin size="large" />
          </div>
        );
      }
    
    
   
      return (
        <>
        <Suspense
                fallback={
                  <div className="flex justify-center items-center h-screen">
                    <Spin size="large" />
                  </div>
                }
              >
            <div className="overflow-x-auto">
            <div className="overflow-x-auto overflow-y-auto" style={{
                height: `${viewportHeight - 150}px`,
            }}>
                <div className="relative pb-8">
                <button onClick={onClose} className="absolute top-2 left-2 flex items-center gap-2">
                <ArrowLeftIcon  className="h-5 w-5 text-black-500 mr-2"  />
                <span className="text-500">Back</span>
              </button>
                </div>
                <div className="ml-2"> 
                <div className="flex mb-2 ml-4"> 
                <span>Invoice:</span>
                <span className="ml-2">152</span>
                </div>
                <div className="flex mb-2 ml-4">
                <span>Invoice Date:</span>
                <span className="ml-2">21-09-2025</span>
                </div>
                <div className="flex mb-2 ml-4">
                <span>Target Date:</span>
                <span className="ml-2">21-09-2026</span>
                </div>
            </div>
                <div className="mb-2">
                <KillbillTableComponent
                    headers={headers}
                    headerMap={headerMap}
                    initialData={tableData}
                    searchQuery={searchTerm}
                    visibleColumns={visibleColumns}
                    itemsPerPage={100}
                    allowedActions={allowedActions}
                    popupHeading="Service Type"
                    pagination={pagination}
                    advancedFilters={filteredData}
                    createModalData={createModalData}
                    generalFields={generalFields}
                    height={340}
                />
                </div>
        
                <div className="flex justify-end mb-4 mr-8"> {/* Flex container to align to the right */}
                <div className="shadow-md p-4 w-2/4"> {/* Set width to 1/3 of the container */}
                    <div className="grid grid-cols-2 gap-4">
                    <div className="flex mb-2">
                        <span>Invoice Total:</span>
                        <span className="ml-2">$1,0234 USD</span>
                    </div>
                    <div className="flex mb-2">
                        <span>Discount:</span>
                        <span className="ml-2">$0.00</span>
                    </div>
                    <div className="flex mb-2">
                        <span>Resulting Available Credits:</span>
                        <span className="ml-2">$0 USD</span>
                    </div>
                    <div className="flex mb-2">
                        <span>Unposted Amount:</span>
                        <span className="ml-2">$0.00</span>
                    </div>
                    <div className="flex mb-2">
                        <span>Refunded:</span>
                        <span className="ml-2">$0 USD</span>
                    </div>
                    <div className="flex mb-2">
                        <span>Final Amount:</span>
                        <span className="ml-2">$1,600.00</span>
                    </div>
                    </div>
                </div>
                </div>
            </div>
            </div>
        </Suspense>
        </>
      );
};

export default AddAccountComponent;