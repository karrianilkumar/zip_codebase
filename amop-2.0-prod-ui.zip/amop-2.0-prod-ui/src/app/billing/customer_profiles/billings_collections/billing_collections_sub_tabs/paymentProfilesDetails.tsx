/* eslint-disable react-hooks/exhaustive-deps */
"use client";

import React, {
  useEffect,
  useState,
  lazy,
  Suspense,
  useRef,
  useCallback,
} from "react";
import { Modal, Spin, notification } from "antd";
import { useAuth } from "../../../../components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "../../../../components/header_constants";
import { ENV_ROUTES } from "../../../../components/routes/route_constants";
import { useCustomerProfileStore } from "@/app/billing/killbill_stores/customer_profile_store";
import { Star, Trash2 } from "lucide-react";

interface PaymentProfilesProps {
  row?: any;
}
interface PaymentMethod {
  number: string;
  type: string;
  expiry: string;
  id : number;
}
interface ProfileData {
  payment_methods?: PaymentMethod[];
  default_method?: PaymentMethod | null;
}
const PaymentProfiles: React.FC<PaymentProfilesProps> = ({row}) => {
  const { username, partner, role, token, selectedDb, selectedBillingDb,metaData,sessionId, firstLastName , setStoredPagination , setAdvancedStoredPagination} = useAuth();
  
  const { accountNumber} = useCustomerProfileStore();
  const [loading, setLoading] = useState(false);
 
const [profileData, setProfileData] = useState<ProfileData | null>(null);
  const [StatusMessage, setStatusMessage] = useState('');
  const [isConfirmDeleteModalOpen, setIsConfirmDeleteModalOpen] = useState(false);
  const [isConfirmDefaultModalOpen, setIsConfirmDefaultModalOpen] = useState(false);
  const [isConfirmRemoveDefaultModalOpen, setIsConfirmRemoveDefaultModalOpen] = useState(false);
  const [selectedCard, setSelectedCard] = useState<PaymentMethod | null>(null);

  const hasFetchedData = useRef(false);


  const fetchData = async () => {
   
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_PAYMENT_INTEGRATION;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/fetch_payment_methods",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Payment Profiles",
        // sub_module:"Services",
        mod_pages: {
          start: 0,
          end: 100,
        },
        account_number:accountNumber,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: 'billing_platform',
        billing_db_name: selectedBillingDb,
        ...metaData,
        sessionID: sessionId,
        // feature_module_name: "Payment History",
        table_name: "customer_payment_profiles",
        main_module_name: "Customer Profiles",
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)

      if (parsedData.flag === true) {
        setLoading(false);
        setStatusMessage(parsedData?.message)
        // notification.success({
        //   message: "Success",
        //   description: parsedData.message || "An error occurred while fetching data. Please try again.",
        //   style: messageStyle,
        //   placement: "top",
        // });

        // Defer other state updates using a timeout to decouple them from the main thread
        setTimeout(() => {
         const profile_data=parsedData?.payment_methods
         setProfileData(parsedData)
         

         
        }, 0);
        
      } else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
 

  useEffect(() => {
    if (!hasFetchedData.current) {
      fetchData();
      hasFetchedData.current = true;
    }
  }, [fetchData]);



  const messageStyle = {
    fontSize: "14px",
    fontWeight: "normal",
    padding: "16px",
  };
  const formatKey = (key: string) => {
    const formattedKey = key
      .toLowerCase()
      .replace(/_/g, ' ')
      .replace(/\b\w/g, (char) => char.toUpperCase());
  
    // Handle specific cases where "ID" should be fully capitalized
    if (formattedKey === "Id") return "ID";
    if (formattedKey === "Payment Profile Id") return "Payment Profile ID";
  
    return formattedKey;
  };
  
  if (loading) {
    return (
      <div className="flex justify-center items-center h-[400px]">
        <Spin size="large" />
      </div>
    );
  }
  const handleDeleteCard = (method: PaymentMethod) => {
  setSelectedCard(method);
  setIsConfirmDeleteModalOpen(true);
};

const handleMakeDefault = (method: PaymentMethod) => {
  setSelectedCard(method);
  setIsConfirmDefaultModalOpen(true);
};

const confirmDeleteCard = async () => {
  console.log("Deleting card:", selectedCard);
  let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_PAYMENT_INTEGRATION;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/delete_payment_method",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Payment Profiles",
        // sub_module:"Services",
        mod_pages: {
          start: 0,
          end: 100,
        },
        account_number:accountNumber,
        changed_data: {
        payment_method: {
          number: selectedCard?.number,
          type: selectedCard?.type,
          expiry: selectedCard?.expiry,
        },
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: 'billing_platform',
        billing_db_name: selectedBillingDb,
        ...metaData,
        sessionID: sessionId,
        // feature_module_name: "Payment History",
        table_name: "customer_payment_profiles",
        main_module_name: "Customer Profiles",
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)

      if (parsedData.flag === true) {
        setLoading(false);
        
        notification.success({
          message: "Success",
          description: parsedData.message || "An error occurred while fetching data. Please try again.",
          style: messageStyle,
          placement: "top",
        });
        fetchData();

        // Defer other state updates using a timeout to decouple them from the main thread
      } else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
        setIsConfirmRemoveDefaultModalOpen(false);
        setIsConfirmDeleteModalOpen(false);
        setIsConfirmDefaultModalOpen(false);
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  setIsConfirmDeleteModalOpen(false);
  setSelectedCard(null);
};

const confirmMakeDefault = async () => {
  console.log("Making default card:", selectedCard);
  // setIsConfirmRemoveDefaultModalOpen(true);
 let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_PAYMENT_INTEGRATION;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/update_default_payment_method",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Payment Profiles",
        // sub_module:"Services",
        mod_pages: {
          start: 0,
          end: 100,
        },
        account_number:accountNumber,
        changed_data: {
        payment_method: {
          number: selectedCard?.number,
          type: selectedCard?.type,
          expiry: selectedCard?.expiry,
        },
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: 'billing_platform',
        billing_db_name: selectedBillingDb,
        ...metaData,
        sessionID: sessionId,
        // feature_module_name: "Payment History",
        table_name: "customer_payment_profiles",
        main_module_name: "Customer Profiles",
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)

      if (parsedData.flag === true) {
        setLoading(false);
        
        notification.success({
          message: "Success",
          description: parsedData.message || "An error occurred while fetching data. Please try again.",
          style: messageStyle,
          placement: "top",
        });
        fetchData();

        // Defer other state updates using a timeout to decouple them from the main thread
      } else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }  setIsConfirmDefaultModalOpen(false);
  setSelectedCard(null);
};

const confirmRemoveDefault = async () => {
  console.log("Removing default status");
  let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_PAYMENT_INTEGRATION;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/update_default_payment_method",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Payment Profiles",
        mod_pages: {
          start: 0,
          end: 100,
        },
        account_number:accountNumber,
        changed_data: {
          payment_method: null // Send null to remove default status
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: 'billing_platform',
        billing_db_name: selectedBillingDb,
        ...metaData,
        sessionID: sessionId,
        table_name: "customer_payment_profiles",
        main_module_name: "Customer Profiles",
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)

      if (parsedData.flag === true) {
        setLoading(false);
        
        notification.success({
          message: "Success",
          description: parsedData.message || "Default payment method removed successfully.",
          style: messageStyle,
          placement: "top",
        });
        fetchData();
      } else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while removing default payment method. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while removing default payment method. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  setIsConfirmRemoveDefaultModalOpen(false);
  setSelectedCard(null);
};
const cardTypeColors: Record<string, string> = {
  Visa: "#d0e7ff",        // Light blue
  MasterCard: "#ffe0b2",  // Light orange
  Amex: "#c8e6c9",        // Light green
  Rupay: "#e1bee7",       // Light purple
  Discover: "#f5c6cb",    // Light pink
  Default: "#f3f4f6",     // Gray fallback
};
const achCards = profileData?.payment_methods?.filter(
  (method: any) => method.type === "Ach"
) || [];

const otherCards = profileData?.payment_methods?.filter(
  (method: any) => method.type !== "Ach"
) || [];
 return (
  <>
    <Suspense fallback={
      <div className="flex justify-center items-center h-[400px]">
        <Spin size="large" />
      </div>
    }>
      <div className="relative p-2">
         {/* If no payment methods */}
         {otherCards.length === 0 && achCards.length === 0 && (
           <div className="text-center text-gray-600 py-10 text-lg font-medium">
             This account has no saved payment methods.
           </div>
         )}
        {/* Saved Card Payments */}
        {otherCards.length > 0 && (<h2 className="font-bold ml-4">Saved Card Payments</h2>)}
        <div className="flex flex-wrap gap-4 p-4">
          {otherCards.length > 0 &&(
            otherCards.map((method: any, index: number) => {
              const isDefault =profileData && profileData.default_method?.id === method.id;

              return (
                <div
                  key={index}
                  className="relative w-60 rounded-xl p-6 shadow-md text-black"
                  style={{ backgroundColor: cardTypeColors[method.type] || cardTypeColors.Default }}
                >
                  {/* Icons */}
                  <div className="absolute top-2 right-2 flex space-x-2">
                    <Star
                      className={`w-5 h-5 ${isDefault ? "text-yellow-500 fill-yellow-500 " : "text-gray-500 cursor-pointer"}`}
                      onClick={() => {
                        if (isDefault) {
                          setIsConfirmRemoveDefaultModalOpen(true);
                          setSelectedCard(null);
                        } else {
                          handleMakeDefault(method);
                        }
                      }} />
                    <Trash2
                      className={`w-5 h-5 ${isDefault ? "text-gray-300" : "text-red-500 cursor-pointer"}`}
                      onClick={() => !isDefault && handleDeleteCard(method)}
                    />
                  </div>

                  {/* Card Number */}
                  <div className="text-lg font-mono tracking-widest mb-4">{method.number}</div>

                  {/* Card Info */}
                  <div className="flex justify-between items-center">
                    <span className="font-semibold">{method.type}</span>
                    <span className="text-sm font-bold text-right">
                      VALID THRU <br /> {method.expiry}
                    </span>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Saved ACH/Electronic Check */}
        {achCards.length > 0 && (<h2 className="font-bold ml-4">Saved ACH/Electronic Check</h2>)}
        <div className="flex flex-wrap gap-4 p-4">
          {achCards.length > 0 && (
            achCards.map((method: any, index: number) => {
              const isDefault = profileData && profileData.default_method?.number === method.number;

              return (
                <div
                  key={index}
                  className="relative w-60 rounded-xl p-6 shadow-md text-black"
                  style={{ backgroundColor: cardTypeColors[method.type] || cardTypeColors.Default }}
                >
                  {/* Icons */}
                  <div className="absolute top-2 right-2 flex space-x-2">
                    <Star
                      className={`w-5 h-5 cursor-pointer ${isDefault ? "text-yellow-500 fill-yellow-500" : "text-gray-500"}`}
                      onClick={() => {
                        if (isDefault) {
                          setIsConfirmRemoveDefaultModalOpen(true);
                          setSelectedCard(null);
                        } else {
                          handleMakeDefault(method);
                        }
                      }} />
                    <Trash2
                      className={`w-5 h-5 cursor-pointer ${isDefault ? "text-gray-300 cursor-not-allowed" : "text-red-500"}`}
                      onClick={() => !isDefault && handleDeleteCard(method)}
                    />
                  </div>

                  {/* Card Number */}
                  <div className="text-lg font-mono tracking-widest mb-4">{method.number}</div>

                  {/* Card Info */}
                  <div className="flex justify-between items-center">
                    <span className="font-semibold">{method.type}</span>
                    <span className="text-sm font-bold text-right">
                      VALID THRU <br /> {method.expiry}
                    </span>
                  </div>
                </div>
              );
            })
          ) }
        </div>

        {/* Your Modals code here */}
         <Modal
           title="Confirm Deletion"
           open={isConfirmDeleteModalOpen}
           onCancel={() => setIsConfirmDeleteModalOpen(false)}
           centered
           footer={
             <div style={{ display: "flex", justifyContent: "center", gap: "6px" }}>
               <button
                 className="cancel-btn"
                 onClick={() => setIsConfirmDeleteModalOpen(false)}
               >
                 Cancel
               </button>
               <button className="save-btn" onClick={confirmDeleteCard}>
                 OK
               </button>
             </div>
           }
         >
           <p>Do you want to delete this payment method?</p>
         </Modal>

         {/* Default Modal */}
         <Modal
           title="Confirm Default"
           open={isConfirmDefaultModalOpen}
           onCancel={() => setIsConfirmDefaultModalOpen(false)}
           centered
           footer={
             <div style={{ display: "flex", justifyContent: "center", gap: "6px" }}>
               <button
                 className="cancel-btn"
                 onClick={() => setIsConfirmDefaultModalOpen(false)}
               >
                 Cancel
               </button>
               <button className="save-btn" onClick={confirmMakeDefault}>
                 OK
               </button>
             </div>
           }
         >
           <p>Do you want to make this card your default payment method?</p>
         </Modal>
         <Modal
           title="Confirm Change Default"
           open={isConfirmRemoveDefaultModalOpen}
           onCancel={() => setIsConfirmRemoveDefaultModalOpen(false)}
           centered
           footer={
             <div style={{ display: "flex", justifyContent: "center", gap: "6px" }}>
               <button
                 className="cancel-btn"
                 onClick={() => setIsConfirmRemoveDefaultModalOpen(false)}
               >
                 Cancel
               </button>
               <button className="save-btn" onClick={confirmRemoveDefault}>
                 OK
               </button>
             </div>
           }
         >
           <p>This card is no longer the default. Auto payments will not use it. Are you sure you want to proceed?</p>
         </Modal>
      </div>
    </Suspense>
  </>
);
  
};

export default PaymentProfiles;
