/* eslint-disable react-hooks/exhaustive-deps */
"use client";

import React, {
  useEffect,
  useState,
  lazy,
  Suspense,
  useRef,
  useCallback,
} from "react";
import { ArrowDownTrayIcon, PlusIcon } from "@heroicons/react/24/outline";
import { Modal, Spin, DatePicker, notification } from "antd";
import { useAuth } from "../../../../components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "../../../../components/header_constants";
import { useFeatureStore } from "../../../../sim_management/inventory/featureStore";
import * as XLSX from "xlsx";
import { ENV_ROUTES } from "../../../../components/routes/route_constants";
import { exportLoadingStore } from "../../../../stores/ExportLoadingStore";
import CreateModal from "../../../killbill_components/createpopup";
import { useCustomerProfileStore } from "@/app/billing/killbill_stores/customer_profile_store";

const KillbillTableComponent = lazy(
  () => import("../../../killbill_components/table__component")
);
// const CreateModal = lazy(() => import("@/app/components/createPopup"));
const ColumnFilter = lazy(() => import("../../../../components/columnfilter"));
const WholeTableSearch = lazy(() => import("../../../killbill_components/whole__search"));
const AdvancedMultiFilter2 = lazy(
  () => import("../../../killbill_components/advanced__search")
);
interface LedgerProps {
  row?: any;
 
}
const Ledger: React.FC<LedgerProps> = ({row}) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const selectedDb = "billing_platform"
  const { username, partner, role, token,sessionId, settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId,selectedBillingDb,metaData, firstLastName , setStoredPagination , setAdvancedStoredPagination,setCombineAdnvaceStoredpagination,combineAdnvaceStoredpagination} = useAuth();
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  const [loading, setLoading] = useState(false);
  const { addExport, removeExport } = exportLoadingStore();
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [isCreateModalOpen, setCreateModalOpen] = useState(false);
  const [createModalData, setcreateModalData] = useState<any[]>([]);
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
  const [generalFields, setgeneralFields] = useState<any[]>([])
  const { accountNumber, BillId, setBillId } = useCustomerProfileStore();

  const hasFetchedData = useRef(false);
  const {
    features: moduleFeatures,
    setFeatures: setModuleFeatures,
  } = useFeatureStore();
  // const queryClient = useQueryClient();

  type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);


  const fetchData = async () => {
    settabledata([]);
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    setSearchTerm("");
    setShowAdvanced(false)
    setCombineAdnvaceStoredpagination(null)
    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/billing_collections_ledger_list_view",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing and Collections Ledger",
        mod_pages: {
          start: 0,
          end: 100,
        },
        table_name:"ledger",
        account_number:accountNumber,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: 'billing_platform',
        ...metaData,
        billing_db_name: selectedBillingDb,
        tenant_id: tenant_id_,
        sessionID: sessionId,
        main_module_name: "Customer Profiles",
        feature_module_name: "Billing and Collections Ledger",
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)

      if (parsedData.flag === true) {
        setLoading(false);
        // Defer other state updates using a timeout to decouple them from the main thread
        setTimeout(() => {
          const headersMap_ = parsedData?.header_map?.["Billing and Collections Ledger"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);
          

          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
          console.log("headers", headers_)
          setHeaders(headers_);
          setVisibleColumns(headers_);
          const generalFields_ = parsedData || {}
          setgeneralFields(generalFields_)
          console.log("generalFields_",generalFields_)
          setFeatures(parsedData?.header_map?.["Billing and Collections Ledger"]?.module_features || []);
          setModuleFeatures(parsedData?.header_map?.["Billing and Collections Ledger"]?.module_features || []);
          const featres_ = parsedData?.header_map?.["Billing and Collections Ledger"]?.module_features || []
         
          const createModalData_=parsedData?.header_map?.["Billing and Collections Ledger"]?.pop_up||[]
          console.log("createModalData_",createModalData_)
          setcreateModalData(createModalData_)
          setPagination(parsedData?.pages || {});
          setTableData(parsedData?.data?.billing_and_collections_ledger || []);

         
        }, 0);
        
      } else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
  const handleCreateModalOpen = () => {
    setCreateModalOpen(true);
  };

  const handleCreateModalClose = () => {
    setCreateModalOpen(false);
  };

  const handleCreateRow = () => {
    handleCreateModalClose();
  };
  useEffect(() => {
    if (!hasFetchedData.current) {
      fetchData();
      hasFetchedData.current = true;
    }
  }, [fetchData]);

  const exportToExcel = (headers: any, rowData: any, fileName = 'exported_data.xlsx') => {
    // Map the rowData to an array of objects with headers as keys
    const formattedData = rowData.map((row: any) => {
      const formattedRow: any = {};
      headers.forEach((header: any) => {
        formattedRow[header] = row[header] !== undefined ? row[header] : null;
      });
      return formattedRow;
    });

    // Create a new worksheet from the formatted data
    const worksheet = XLSX.utils.json_to_sheet(formattedData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');

    // Write the workbook and trigger download
    XLSX.writeFile(workbook, fileName);
  };

  const handleFilter = useCallback((advancedFilters: any) => {
    console.log(advancedFilters);
    setAdvancedFilters(advancedFilters)
  }, []);

  const handleReset = useCallback((EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  }, []);

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "normal",
    padding: "16px",
  };
  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }

  const ExportWithoutSearch = async () => {
  
    try {
      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Request timed out"));
          }, timeout);
  
          promise
            .then((res) => {
              clearTimeout(timer);
              resolve(res);
            })
            .catch((err) => {
              clearTimeout(timer);
              reject(err);
            });
        });
      };
  
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/ledger_export",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing and Collections Ledger",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        account_number:accountNumber,
        main_module_name: "Customer Profiles",
        feature_module_name: "Billing and Collections Ledger",
        start_date: getFirstDayOfCurrentMonth(),
        end_date: getLastDayOfCurrentMonth(),
        killbill_flag:"True"
      };
  
      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000);
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }
  
      // Wait for 20 seconds before polling
      await new Promise((resolve) => setTimeout(resolve, 20000));
  
      const export_url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const export_data = {
        ...data,
        path: "/get_export_status",
      };
  
      const pollExportStatus = async () => {
        try {
          const export_response = await axios.post(export_url, { data: export_data });
          const export_parsedData = JSON.parse(export_response.data.body);
  
          if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
            const s3Url = export_parsedData?.export_status_data?.url || null;
            if (s3Url) {
              // window.location.href = s3Url;
              // notification.success({
              //   message: "Success",
              //   description: "Successfully exported the  record!",
              //   style: messageStyle,
              //   placement: "top",
              // });
              fetch(s3Url)
            .then(response => response.blob())
            .then(blob => {
              const url = window.URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'Billing and Collections Ledger.xlsx'; 
              a.click();
              a.remove();
              window.URL.revokeObjectURL(url);
              notification.success({
                message: "Success",
                description: "Successfully exported the record!",
                style: messageStyle,
                placement: "top",
              });
            })
            .catch((err) => {
              console.log("error", err)
              Modal.error({
                title: "Export Error",
                content: "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            });
            } else {
              Modal.error({
                title: "Export Error",
                content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            }
            return true; // Stop polling
          }
  
          if (export_parsedData?.export_status_data?.status_flag === "Failure") {
            Modal.error({
              title: "Export Error",
              content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
              centered: true,
            });
            return true; // Stop polling
          }
          if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
                      Modal.error({
                        title: "Export Error",
                        content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
                        centered: true,
                      });
                      return true; // Stop polling
                    }
          return false; // Continue polling
        } catch (error) {
          Modal.error({
            title: "Export Error",
            content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
            centered: true,
          });
          return true; // Stop polling
        }
      };
  
      const startPolling = async () => {
        let isPollingComplete = false;
  
        while (!isPollingComplete) {
          isPollingComplete = await pollExportStatus();
          if (!isPollingComplete) {
            await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
          }
        }
      };
  
      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      // removeExport(exportKey); // Remove the export from the store
    }
  };
  


  const handleExport = async (key: string, heading: string) => {
  
    try {
      addExport(key, heading);
  
      let parsedData;
      let url;
      let data: any;
      let response;
  
      if(combineAdnvaceStoredpagination){
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          account_number:accountNumber,
          path: "/search_export",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedBillingDb,
          sessionID: sessionId,
          index_name: "Ledger",
          module_name: "Billing and Collections Ledger",
          // col_sort:{account_number: "ASC"}
        };
        console.log("combineAdnvaceStoredpagination",data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
      else if  (advancedStoredpagination && !storedpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name: "Ledger",
          module_name: "Billing and Collections Ledger",
          pages: { start: 0, end: 100 },
          partner,
          account_number:accountNumber,
          db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
          username: username
          // col_sort:{account_number: "ASC"}
        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } 
      else if (storedpagination && !advancedStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "Ledger",
          module_name: "Billing and Collections Ledger",
          search: "whole",
          pages: { start: 0, end: 100 },
          partner,
          account_number:accountNumber,
          db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
          username: username
          // col_sort:{account_number: "ASC"}
          
        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } else {
        await ExportWithoutSearch();
        return;
      }
  
      if (parsedData.flag) {
        const s3Url = parsedData?.download_url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the  record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
            .then(response => response.blob())
            .then(blob => {
              const url = window.URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'Billing and Collections Ledger.xlsx'; 
              a.click();
              a.remove();
              window.URL.revokeObjectURL(url);
              notification.success({
                message: "Success",
                description: "Successfully exported the record!",
                style: messageStyle,
                placement: "top",
              });
            })
            .catch((err) => {
              console.log("error", err)
              Modal.error({
                title: "Export Error",
                content: "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            });
        } else {
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      } else {
        Modal.error({
          title: "Export Error",
          content: parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      removeExport(key);
    }
  };
  
  

  const downloadBlob = (base64Blob: string) => {
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    const blobObject = new Blob([byteArray], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blobObject);
    link.download = "Inventory.xlsx";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-[400px]">
        <Spin size="large" />
      </div>
    );
  }
  return (
    <>
      <Suspense
        fallback={
          <div className="flex justify-center items-center h-[400px]">
            <Spin size="large" />
          </div>
        }
      >
        <div className="relative">
          {/* <div className="p-2 flex items-center justify-between mt-1 mb-2">
            <div className="flex space-x-2"> */}
          <div className="p-4 flex md:flex-row md:items-center md:justify-between space-y-6 md:space-y-0">
            {/* Search and Advanced Filter Container */}
            <div className="flex  space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last">
              {features.includes("Search-Billing and Collections Ledger") && (
                <WholeTableSearch
                  searchTerm={searchTerm}
                  setSearchTerm={setSearchTerm}
                  tableName={"Ledger"}
                  headerMap={headerMap}
                />
              )}
              { features.includes("Advanced-Billing and Collections Ledger") &&(
                <AdvancedMultiFilter2
                  showAdvanced={showAdvanced}
                  setShowAdvanced={setShowAdvanced}
                  onFilter={handleFilter}
                  onReset={handleReset}
                  headers={headers}
                  headerMap={headerMap}
                  tableName={"Ledger"}
                />
              )}
            </div>
            {/* <div className="flex space-x-2"> */}
             {/* Export and ColumnFilter Container */}
            <div className="hidden md:flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2 md:order-none order-first">
              {/* {features.includes("Update Bill-Billing and Collections Ledger") &&(
                     <button className="save-btn" onClick={handleCreateModalOpen}>
                     <SyncOutlined className="h-5 w-5 text-black-500 mr-1" />
                     Update Bill
                 </button>  )} */}
              { features.includes("Export-Billing and Collections Ledger") &&(
                <button className="save-btn" onClick={() => handleExport("Ledger", "Ledger")}>
                <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                  <span>Export</span>
                </button>
              )}
             <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
              />
            </div>
          </div>
           
          <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
          <KillbillTableComponent
              headers={headers}
              headerMap={headerMap}
              initialData={tableData}
              searchQuery={searchTerm}
              visibleColumns={visibleColumns}
              itemsPerPage={100}
              allowedActions={allowedActions}
              popupHeading="Ledger"
              pagination={pagination}
              advancedFilters={filteredData}
              createModalData={createModalData}
              generalFields = {generalFields}
              // height = {showAdvanced?410:350}
              height = {showAdvanced?395:325}
            />
          </div>
            <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
              {/* {features.includes("Update Bill-Billing and Collections Ledger") &&(
                     <button className="save-btn" onClick={handleCreateModalOpen}>
                     <SyncOutlined className="h-5 w-5 text-black-500 mr-1" />
                     Update Bill
                 </button>  )} */}
              { features.includes("Export-Billing and Collections Ledger") &&(
                <button className="save-btn" onClick={() => handleExport("Ledger", "Ledger")}>
                <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                </button>
              )}
             <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
              />
            </div>
          <CreateModal
              isOpen={isCreateModalOpen}
              onClose={handleCreateModalClose}
              onSave={handleCreateRow}
              modalData={createModalData}
              title="Ledger"
              visible={isCreateModalOpen}
              action="create"
              generalFields = {generalFields}


              
            />
          {/* {exportLoading && (
            <div className="export-processing-div">
              Export processing...
            </div>
          )} */}
        </div>
      </Suspense>
    </>
  );
};

export default Ledger;
