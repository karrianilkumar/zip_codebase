/* eslint-disable react-hooks/exhaustive-deps */
"use client";

import React, {
  useEffect,
  useState,
  lazy,
  Suspense,
  useRef,
  useCallback,
} from "react";
import Select from "react-select";
import { PlusIcon } from "@heroicons/react/24/outline";
import { DatePicker, Input, Modal, notification, Spin } from "antd";
import { useAuth } from "../../../../components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "../../../../components/header_constants";
import { useFeatureStore } from "../../../../sim_management/inventory/featureStore";
import { ENV_ROUTES } from "../../../../components/routes/route_constants";
import { CreditCardOutlined, SyncOutlined } from "@ant-design/icons";
import CreateBillModal from "./createBill";
import { useCustomerProfileStore } from "@/app/billing/killbill_stores/customer_profile_store";
import { useTemplateStore } from "@/app/billing/killbill_stores/templateStore";
import { DropdownStyles } from '../../../../components/css/dropdown';
import dayjs from "dayjs";

const KillbillTableComponent = lazy(
  () => import("../../../killbill_components/table__component")
);
const ColumnFilter = lazy(() => import("../../../../components/columnfilter"));
const WholeTableSearch = lazy(() => import("../../../killbill_components/whole__search"));
const AdvancedMultiFilter2 = lazy(
  () => import("../../../killbill_components/advanced__search")
);
interface BillsProps {
  row?: any;
  onRowClick: (row: any) => void;
  onRedirectToUnpostedChange?: (value: boolean) => void;
}
type FormData = {
  item_amount: any | null;
  reason: any | null;
  comment: any | null;
  credit_card_fee?: boolean | null;
  reference_no: any | null;
  payment_method: any | null;
  agent: any | null;
  received_date: any | null;
};
const Bills: React.FC<BillsProps> = ({ row,onRowClick,onRedirectToUnpostedChange }) => {
  const tenant_id_ = localStorage.getItem("tenant_id") || "0";
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, token, selectedDb,metaData,selectedBillingDb, sessionId, settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId, firstLastName, setStoredPagination, setAdvancedStoredPagination, setCombineAdnvaceStoredpagination } = useAuth();
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  const [loading, setLoading] = useState(false);
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [isCreateModalOpen, setCreateModalOpen] = useState(false);
  const [createModalData, setcreateModalData] = useState<any[]>([]);
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
  const [generalFields, setgeneralFields] = useState<any[]>([])
  const { accountNumber, BillId, setBillId , setUserProfileDetails , setMultiPaymentModalOpen,isMultiPaymentModalOpen } = useCustomerProfileStore();
  const [templateData,setTemplateData_] = useState<any[]>([])
  const {setTemplateData}=useTemplateStore();
  const [creditCardFee , setCreditCardFee] = useState<number>(0)
  const [agentOptions, setAgentOptions] = useState<any[]>([]);
  const hasFetchedData = useRef(false);
  const [iframeUrl , setIframeUrl] = useState("")
  // const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [paymentFormloading, setPaymentFormLoading] = useState(true);
  const {
    features: moduleFeatures,
    setFeatures: setModuleFeatures,
  } = useFeatureStore();
  const [showPayNow, setPayNow] = useState(false);
  const [editableRowData,setEditableRowData] = useState<any[]>([]);
  const [totalAmount, setTotalAmount] = useState<number>(0);
  // console.log("editableRowData",editableRowData,tableData)
  const [formData, setFormData] = useState<FormData>({
      item_amount: '',
      credit_card_fee: true,
      reason: '',
      comment: '',
      reference_no: '',
      payment_method: '',
      agent: '',
      received_date: dayjs().format("MM-DD-YYYY"),
    });
  const [isProcessing, setIsProcessing] = useState(false);
  const [formErrors, setFormErrors] = useState({ item_amount: "" });
  const [ProcessPaymentOpen, setProcessPaymentOpen] = useState(false);
  const [isAmountModalOpen, setIsAmountModalOpen] = useState(false);
  const [amount, setAmount] = useState("");
  const [accountStatus , setAccountStatus] = useState(false);
  
  // Add this useEffect after the existing state declarations
  useEffect(() => {
    console.log("useEffect triggered with:", {
    item_amount: formData.item_amount,
    credit_card_fee: formData.credit_card_fee,
    creditCardFee: creditCardFee
  });
    if (!formData.item_amount) {
      setTotalAmount(0)
      return;
    }

    console.log("recalculating total after form formData change");
    const itemAmount = parseFloat(formData.item_amount) || 0;
    let calculatedTotal = itemAmount;
    
    // Apply credit card fee if checkbox is checked
    if (formData.credit_card_fee && creditCardFee > 0) {
      const feeAmount = (itemAmount * creditCardFee) / 100;
      calculatedTotal = itemAmount + feeAmount;
    }
    
    setTotalAmount(Number(calculatedTotal.toFixed(2)));
  }, [formData.item_amount, formData.credit_card_fee, creditCardFee]);
  
  type HeaderMap = Record<string, [string, number]>;
  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);
//  useEffect(() => {
//    function handlePaymentMessage(event: { origin: string; data: { action: any; url: any; }; }) {
//      if (event.origin !== "https://pay.trxservices.net") return;
 
//      const { action, url } = event.data;
//      console.clear()
//      console.error("TRX Data",event.data)
 
//      if (action === "navigate" && url) {
//        // Check if the URL contains approval or rejection indicators
//        const approvalURL = "https://qa.amop.services/billing/customer_profiles/payment_history";
//        const rejectedURL = "https://qa.amop.services/billing/customer_profiles/bills";
 
//        if (url.startsWith(approvalURL)) {
//          setPaymentFormLoading(false);
//          setIsPaymentModalOpen(false);
//          Modal.success({
//            title:"Payment Success",
//            content:"",
//            centered:true
//          })
//        } else if (url.startsWith(rejectedURL)) {
//          setPaymentFormLoading(false);
//          Modal.error({
//            title:"Payment Failed",
//            content:"",
//            centered:true
//          })
//        }
//      }
//    }
 
//    window.addEventListener("message", handlePaymentMessage);
//    return () => window.removeEventListener("message", handlePaymentMessage);
//  }, []);
 
   useEffect(() => {
   if (iframeUrl) {
     setPaymentFormLoading(true);
   }
 }, [iframeUrl]);
  const GetToken = async (row:any) => {
    // setLoading(true);
    if (accountNumber) {
      localStorage.setItem("account_number", accountNumber);
    }
    try {
      // console.log("row",row)    
       // Ensure row is always an array
      const billIds = Array.isArray(row) ? row : [row]; // Wrap in an array if it's not already 
      let data;
      const url = ENV_ROUTES.BP_PAYMENT_INTEGRATION;
      data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_payment_token",
        role_name: role,
        parent_module: "Billing Platform",
        // module_name: "Billing and Collections Bills",
        // feature_module_name: "Billing and Collections Bills",
        Partner: partner,
        access_token: token,
        db_name: 'billing_platform',
        billing_db_name: selectedBillingDb,
        ...metaData,
        main_module_name: "Customer Profiles",
        // table_name: "sim_management_inventory",
        request_received_at: getCurrentDateTime(),
        sessionID: sessionId,
        tenant_id:tenant_id_,
        action: "create",
        modified_by: firstLastName,
        credit_card_flag:formData.credit_card_fee ?? "False",
        account_number:accountNumber,
        bill_id: billIds,
        ...formData
      };

      const response = await axios.post(url, { data });
      const resp = JSON.parse(response.data.body);
      console.log(resp, "show the response");

      if (response.data.statusCode === 200 && resp.flag === true) {
        if(resp.batch_id){
          const batchId_ = resp.batch_id;
          // console.log("Batch ID:", batchId_); 
          localStorage.setItem("batch_id", batchId_ ); 
        }
        if (resp.token) {
          // const trxIframeUrl = `https://trx-iframe-host/paynow?token=${resp.token}`;
          console.log("tokennn",resp.token)
          setIframeUrl(resp.token);
          setMultiPaymentModalOpen(true)
          setIsProcessing(false);
          setProcessPaymentOpen(false)
        } else {
          throw new Error("Payment token missing in response.");
        }
      } else {
        Modal.error({
          title: "Data Error",
          content: resp.message,
          centered: true,
        });
        // setLoading(false);
        handleCancel()
        setIsProcessing(false);

      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Error',
        content: 'Missing Payment Token',
        centered: true,
      });
      setIsProcessing(false);
      handleCancel()
      // setLoading(false);

    } finally {
      // setLoading(false);
    }
  };
   const handleConfirmChange = async (row:any) => {
      // setIsConfirmModalOpen(false);
      // if (!selectedRow) return;
  
      // console.log("Payment Mode changed for row:", selectedRow, "New Value:", selectedPaymentMode,"Account number", accountNumber);
      const billIds = Array.isArray(row) ? row : [row]; // Wrap in an array if it's not already 
      setLoading(true);
      try {
        const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/change_payment_mode",
          role_name: role,
          parent_module: "Billing Platform",
          module_name: "Billing and Collections Bills",
          feature_module_name: "Billing and Collections Bills",
          Partner: partner,
          access_token: token,
          db_name: "billing_platform",
          account_number: accountNumber,
          main_module_name: "Customer Profiles",
          payment_mode: formData.payment_method,
          // amount:amount,
          // bill_id: selectedRow,
          // id: [selectedRow],
          bill_id: billIds,
          request_received_at: getCurrentDateTime(),
          sessionID: sessionId,
          modified_by: firstLastName,
          ...formData
        };
  
        const response = await axios.post(url, { data });
        const resp = JSON.parse(response.data.body);
  
        console.log(resp, "show the response");
  
        if (response.data.statusCode === 200 && resp.flag === true) {
          notification.success({
            message: "Success",
            description: resp.message || "Successfully updated payment mode!",
            style: messageStyle,
            placement: "top",
          });
  
          // setRowData((prevData) =>
          //   prevData.map((item) =>
          //     item.id === selectedRow ? { ...item, payment_mode: selectedPaymentMode } : item
          //   )
          // );
          handleCancel()
  
        } else {
          Modal.error({
            title: "Saving Error",
            content: resp.message,
            centered: true,
          });
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        Modal.error({
          title: 'Submit Error',
          content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting data. Please try again.',
          centered: true,
          //  onOk: onclose
        });
      } finally {
        setLoading(false);
      }
    };
    const handleCancel = () => {
      setProcessPaymentOpen(false);
      setFormData({
        item_amount: null,
        reason: null,
        comment: null,
        credit_card_fee: null,
        reference_no: null,
        payment_method: null,
        agent: null,
        received_date: null,
      });
      setFormErrors({ item_amount: "" });
      setAmount("")
      setIsAmountModalOpen(false)
      setCallFetchdata()
      setIsProcessing(false);
  
    };
    const handleClosePaynowModal = () => {
      setProcessPaymentOpen(false);
      setFormData({
        item_amount: null,
        reason: null,
        comment: null,
        credit_card_fee: null,
        reference_no: null,
        payment_method: null,
        agent: null,
        received_date: null,
      });
      setFormErrors({ item_amount: "" });
      setAmount("")
      setIsAmountModalOpen(false)
      setIsProcessing(false);
    }
  const fetchData = async () => {
    settabledata([]);
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    setSearchTerm("");
    setShowAdvanced(false)
    setCombineAdnvaceStoredpagination(null)
    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/billing_collections_bills_list_view",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing and Collections Bills",
        mod_pages: {
          start: 0,
          end: 100,
        },
        table_name:"customer_bills",
        account_number: accountNumber,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        tenant_id: tenant_id_,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        main_module_name: "Customer Profiles",
        feature_module_name: "Billing and Collections Bills",
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      // console.log(parsedDaata)

      if (parsedData.flag === true) {
        setLoading(false);
        // Defer other state updates using a timeout to decouple them from the main thread
        setUserProfileDetails(parsedData?.dropdown?.user_profile_details || {});
        setTimeout(() => {
          const headersMap_ = parsedData?.header_map?.["Billing and Collections Bills"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);
          const template_data = JSON.parse(parsedData.pdf_template);
          setTemplateData_(template_data);
          setTemplateData(template_data);
          

          // console.log(template_data,"show template")

          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
          console.log("headers", headers_)
          setHeaders(headers_);
          setVisibleColumns(headers_);
          const generalFields_ = parsedData || {}
          setgeneralFields(generalFields_)
          // console.log("generalFields_", generalFields_)
          setFeatures(parsedData?.header_map?.["Billing and Collections Bills"]?.module_features || []);
          setModuleFeatures(parsedData?.header_map?.["Billing and Collections Bills"]?.module_features || []);
          const featres_ = parsedData?.header_map?.["Billing and Collections Bills"]?.module_features || []
          // if(parsedData?.account_status){
              const allowedActions_: any = []
          if (featres_.includes("Payment-Billing and Collections Bills")) {
            allowedActions_.push("paynow")
          }
          // if (featres_.includes("delete-Billing and Collections Bills")) {
          //   allowedActions_.push("delete")
          // }
          if (featres_.includes("adjust-Billing and Collections Bills")) {
            allowedActions_.push("adjust")
          }
          if (featres_.includes("download bill-Billing and Collections Bills")) {
            allowedActions_.push("downloadbill")

          }
          
           setAllowedActions(allowedActions_)
          // }
          setAccountStatus(parsedData?.account_status)
          setCreditCardFee(parsedData?.dropdown?.credit_card_fee || "");
          const createModalData_ = parsedData?.header_map?.["Billing and Collections Bills"]?.pop_up || []
          // console.log("createModalData_", createModalData_)
          setcreateModalData(createModalData_)
          setPagination(parsedData?.pages || {});
          setTableData(parsedData?.data?.billing_and_collections_bills || []);
          setAgentOptions(parsedData?.dropdown?.sales_person || []);
        }, 0);

      } else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
  const handleCreateModalOpen = () => {
    setCreateModalOpen(true);
  };

  const handlePayNow = () => {
    console.log("paynow  clicked");
  //   const totalAmount_ = tableData
  //   .filter((row: { id: any; }) => editableRowData.includes(row.id))
  //   .reduce((sum: any, row: { amount_due: any; }) => sum + (row.amount_due || 0), 0);
  //    const roundedAmountWithFee = Number(totalAmount_.toFixed(2)) + creditCardFee;
  //    const roundedAmount = Number(totalAmount_.toFixed(2));
  // setTotalAmount(roundedAmountWithFee)
    const totalAmount_ = tableData
      .filter((row: { id: any }) => {
        // If editableRowData contains numbers, treat as IDs
        if (typeof editableRowData[0] === "number") {
          return editableRowData.includes(row.id);
        }
        // If editableRowData contains objects, match by row.id
        if (typeof editableRowData[0] === "object") {
          return editableRowData.some((edit: any) => edit.id === row.id);
        }
        return false;
      })
      .reduce((sum: number, row: { amount_due: number }) => sum + (row.amount_due || 0), 0);

    const roundedAmount = Number(totalAmount_.toFixed(2));

  // ✅ Calculate fee as a percentage of total
  const creditCardFeePercent = creditCardFee|| 0;
  const creditCardFeeAmount = (roundedAmount * creditCardFeePercent) / 100;

  // ✅ Add fee amount to total
  const roundedAmountWithFee = roundedAmount + creditCardFeeAmount;

  setTotalAmount(roundedAmountWithFee);

  setFormData({
    item_amount: roundedAmount,
    reason: "",
    comment: "",
    credit_card_fee: true,
    reference_no: "",
    payment_method: "card payment", 
    agent: "",
  received_date: dayjs().format("MM-DD-YYYY")
  });
    setPayNow(true);
    setProcessPaymentOpen(true);
  };
     const handleReverseBill = async () => {

    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      // const tenant_id_ = localStorage.getItem("tenant_id") || "0";
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/bill_reversal_update",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing and Collections Bills",
        mod_pages: {
          start: 0,
          end: 100,
        },
        table_name:"customer_reversal_bills",
        account_number: accountNumber,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        tenant_id: tenant_id_,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        changed_data: tableData.filter((row: { id: any }) =>
          editableRowData.some((edit: any) =>
            typeof edit === "object" ? edit.id === row.id : edit === row.id
          )
        ),
        // changed_data: tableData.filter((row: { id: any }) =>
        //   editableRowData.some((edit: any) => edit.id === row.id)
        // ),
//         changed_data = tableData.filter(row =>
//   editableRowData.includes(row.id)
// ),
        main_module_name: "Customer Profiles",
        feature_module_name: "Billing and Collections Bills",
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      // console.log(parsedDaata)

      if (parsedData.flag === true) {
        notification.success({
              message: "Success",
              description: parsedData.message || "Successfully Updated",
              style: messageStyle,
              placement: "top",
            });
        fetchData()
      } else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const handlePayNowClose =()=>{
    setPayNow(false);
  }

  const handleCreateModalClose = () => {
    setCreateModalOpen(false);
  };

  const handleSave = (type:any) => {
    if (type === "Charge" || type === "Credit") {
    onRedirectToUnpostedChange?.(true)
  }
    fetchData();
  };

  useEffect(() => {
    if (!hasFetchedData.current) {
      fetchData();
      hasFetchedData.current = true;
    }
  }, [fetchData]);


  const handleFilter = useCallback((advancedFilters: any) => {
    console.log(advancedFilters);
    setAdvancedFilters(advancedFilters)
  }, []);

  const handleReset = useCallback((EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  }, []);


const setCallFetchdata = () =>{
  fetchData()
}
const messageStyle = {
  fontSize: "14px",
  fontWeight: "normal",
  padding: "16px",
};
const handlePayNowClick = () => {
  console.log(formData,"Show form data")
  if (!formData.item_amount) {
    setFormErrors({ item_amount: "Item Amount is required" });
    return; // Stop execution if validation fails
  }
  formData["item_amount"]=(formData.item_amount).toString()
  setFormErrors({ item_amount: "" });
  if(formData.payment_method === 'paper check' || formData.payment_method === 'money order'){
    handleConfirmChange(editableRowData.length > 0 ? editableRowData : [])
  }
  else{
    setIsProcessing(true);
    GetToken(editableRowData.length > 0 ? editableRowData : []);
  }
  };

  const handleInputChange =(field: string) =>
    (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
      const value = e.target.value.toString();
      console.log("value", value)

      

      // Validation for item_amount
      if (field === "item_amount") {
        const regex = /^\d+(\.\d{0,2})?$/;
        if (value === "" || regex.test(value)) {
              setFormData((prev) => ({
                ...prev,
                item_amount: value,
              }));
        
          const itemAmount = parseFloat(value);
          let totalRemaining = 0;
          console.log("editableRowData",editableRowData)
          console.log("tableData",tableData)

          // Calculate the total remaining amount for all editable rows
          editableRowData.forEach((edit: any) => {
            const id = typeof edit === "object" ? edit.id : edit;
            const matchingRow = tableData.find((row: any) => row.id === id);
            console.log("matchingRow", matchingRow);
            if (matchingRow) {
              totalRemaining += matchingRow.remaining || 0;
            }
          });

          // Check if the item amount exceeds the total remaining amount
          if (itemAmount > totalRemaining) {
            setFormErrors((prevErrors) => ({
              ...prevErrors,
              item_amount: `Item amount cannot exceed the total remaining amount of ${totalRemaining}.`,
            }));
          } else {
            // Clear error if valid
            setFormErrors((prevErrors) => ({
              ...prevErrors,
              item_amount: "",
            }));
          }
        }
      }
      else{
      // Update form data
      setFormData((prev) => ({
        ...prev,
        [field]: value,
      }));  
      }
    };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-[400px]">
        <Spin size="large" />
      </div>
    );
  }
const hasEditableRows = tableData.some((row: any) => 
  editableRowData.some((edit: any) => {
    const editId = typeof edit === "object" ? edit.id : edit;
    return row.id === editId && row.remaining > 0;
  })
);

  return (
    <>
        <div className="relative">
          {/* <div className="p-2 flex items-center justify-between mt-1 mb-2">
            <div className="flex space-x-2"> */}
          <div className="p-4 flex md:flex-row md:items-center md:justify-between space-y-6 md:space-y-0">
            <div className="flex  space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last">
              {features.includes("Search-Billing and Collections Bills") && (
                <WholeTableSearch
                  searchTerm={searchTerm}
                  setSearchTerm={setSearchTerm}
                  tableName={"Billing and Collections Bill"}
                  headerMap={headerMap}
                />
              )}
              {features.includes("Advanced-Billing and Collections Bills") && (
                <AdvancedMultiFilter2
                  showAdvanced={showAdvanced}
                  setShowAdvanced={setShowAdvanced}
                  onFilter={handleFilter}
                  onReset={handleReset}
                  headers={headers}
                  headerMap={headerMap}
                  tableName={"Billing and Collections Bill"}
                />
              )}
            </div>
            {/* Export and ColumnFilter Container */}
            <div className="hidden md:flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2 md:order-none order-first">
              {features.includes("Payment-Billing and Collections Bills") && (
              <button
                className={editableRowData.length === 0 || !accountStatus ? 'cancel-btn cursor-not-allowed' : 'save-btn'}
                onClick={handlePayNow}
                disabled={editableRowData.length === 0 || !accountStatus}
              >
                <CreditCardOutlined className="h-5 w-5 text-black-500 mr-1" />
                Pay Now
              </button>
            )}
             {features.includes("Reverse-Billing and Collections Bills") && (
              <button
                className={!hasEditableRows || !accountStatus ? 'cancel-btn cursor-not-allowed' : 'save-btn'}
                onClick={handleReverseBill}
                disabled={!hasEditableRows || !accountStatus}
              >
                <SyncOutlined className="h-5 w-5 text-black-500 mr-1" />
                Reverse Bill
              </button>
            )}
              {features.includes("Create-Billing and Collections Bills") && (
                <button className={!accountStatus? "cancel-btn" :"save-btn"} onClick={handleCreateModalOpen} disabled={!accountStatus}>
                  <PlusIcon className="h-5 w-5 text-black-500 mr-1" />
                  Create
                </button>)}
                {/* {features.includes("Update Bill-Billing and Collections Bills") && (
                <button className="save-btn" onClick={handleGenerateBill }>
                  <SyncOutlined className="h-5 w-5 text-black-500 mr-1" />
                  Update Bill
                </button>
              )} */}
              <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
                popupHeading="Bills"
              />
            </div>
          </div>
          <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
          {/* {showGenerateBill ? (
          <GenerateBill />
        ) : ( */}
          <KillbillTableComponent
            headers={headers}
            headerMap={headerMap}
            initialData={tableData}
            searchQuery={searchTerm}
            visibleColumns={visibleColumns}
            itemsPerPage={100}
            allowedActions={allowedActions}
            popupHeading="Bills"
            pagination={pagination}
            advancedFilters={filteredData}
            createModalData={createModalData}
            generalFields={generalFields}
            // height={showAdvanced ? 410 : 350}
            height = {showAdvanced?395:325}
            onRowClick={onRowClick}
            setCallFetchdata={setCallFetchdata}
            setReverseRowData={setEditableRowData}
          />
        {/* )} */}
          </div>
            <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
              {features.includes("Payment-Billing and Collections Bills") && (
              <button
                className={editableRowData.length === 0 ? 'cancel-btn cursor-not-allowed' : 'save-btn'}
                onClick={handlePayNow}
                disabled={editableRowData.length === 0}
              >
                <CreditCardOutlined className="h-5 w-5 text-black-500" />
              </button>
            )}
             {features.includes("Reverse-Billing and Collections Bills") && (
              <button
                className={editableRowData.length === 0 ? 'cancel-btn cursor-not-allowed' : 'save-btn'}
                onClick={handleReverseBill}
                disabled={editableRowData.length === 0}
              >
                <SyncOutlined className="h-5 w-5 text-black-500" />
              </button>
            )}
              {features.includes("Create-Billing and Collections Bills") && (
                <button className="save-btn" onClick={handleCreateModalOpen}>
                  <PlusIcon className="h-5 w-5 text-black-500" />
                </button>)}
                {/* {features.includes("Update Bill-Billing and Collections Bills") && (
                <button className="save-btn" onClick={handleGenerateBill }>
                  <SyncOutlined className="h-5 w-5 text-black-500 mr-1" />
                  Update Bill
                </button>
              )} */}
              <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
              />
            </div>
          
          {/* {showGenerateBill && <GenerateBill/>} */}
          <CreateBillModal
            isOpen={isCreateModalOpen}
            onClose={handleCreateModalClose}
            onSave={handleSave}
            modalData={createModalData}
            title="Bills"
            visible={isCreateModalOpen}
            action="create"
            generalFields={generalFields}
            row={row}
            
          />
        {showPayNow&&(
             <Modal
             title={"Process Payment"}
             open={ProcessPaymentOpen}
             onCancel={handleClosePaynowModal}
             centered
             footer={
               <div style={{ display: "flex", justifyContent: "center", width: "100%", gap: "6px" }}>
                 <button className="cancel-btn" onClick={handleClosePaynowModal} disabled={isProcessing}>
                   Cancel
                 </button>
                 
                 <button className="save-btn" onClick={handlePayNowClick} disabled={!!formErrors.item_amount}>
                     Pay Now
                 </button>
                
               </div>
               
             }
            width={450}
           >
             {/* Show Loader When Processing */}
             {isProcessing ? (
               <div className="flex justify-center items-center flex-col h-[200px]">
                 <Spin size="large" />
                 <p className="mt-2 text-gray-600">Processing...</p>
               </div>
             ) : (
                    <div className="flex flex-col gap-2">

                      <div className="flex gap-2 mb-2">
                        <label className="field-label" style={{ minWidth: '150px' }}>Payment Method</label>
                        <Select
                          options={[
                            { value: "card payment", label: "Card Payment" },
                            { value: "paper check", label: "Paper Check" },
                            { value: "money order", label: "Money Order" },
                            { value: "inbound ach", label: "Inbound ACH" },
                          ]}
                          styles={DropdownStyles}
                          className="min-w-[220px]"
                          value={
                            formData.payment_method
                              ? { value: formData.payment_method, label: formData.payment_method.charAt(0).toUpperCase() + formData.payment_method.slice(1) }
                              : null
                          }
                          onChange={(selectedOption) =>
                            setFormData((prev) => ({
                              ...prev,
                              payment_method: selectedOption ? selectedOption.value : "",
                            }))
                          }
                        />
                      </div>
                      <div className="flex gap-2 mb-2">
                        <label className="field-label" style={{ minWidth: '150px' }}>Amount<span className="text-red-500">*</span></label>
                        <div className="flex flex-col gap-1">
                        <Input
                          type="text"
                          className="input !w-[220px]"
                          value={formData.item_amount}
                          onChange={handleInputChange("item_amount")}
                          placeholder="Enter Amount"
                          prefix="$"
                        />
                        {formErrors.item_amount && <p className="text-red-500 text-sm">{formErrors.item_amount}</p>}
                        </div>
                      </div>
                        {/* <div className="flex flex-col">
                        <label className="field-label">Reason</label>
                        <Input
                          type="text"
                          className="input"
                          value={formData.reason}
                          onChange={handleInputChange("reason")}
                          placeholder="Enter Buy Rate"
                        />
                          </div> */}
                      <div className="flex flex-col mb-2">
                      <div className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          checked={formData.credit_card_fee ?? true}
                          onChange={(e) => {
                            console.log("Checkbox changed to:", e.target.checked); // Add this debug log
                            setFormData((prev) => ({
                              ...prev,
                              credit_card_fee: e.target.checked,
                            }));
                          }}
                        />
                        <label className="field-label text-sm" style={{ minWidth: "150px" }}>
                          Apply Credit Card Fee ({creditCardFee}%)
                        </label>
                      </div>
                      {/* <span className="text-xs text-gray-600 italic ml-6">
                        (Uncheck to process without credit card fee)
                      </span> */}
                    </div>
                    
                      <div className="flex gap-2 mb-2">
                        <label className="field-label" style={{ minWidth: '150px' }}>Total</label>
                        {/* <span className="text-sm text-gray-800 ml-2">${totalAmount || 0}</span> */}
                        <span className="text-sm text-gray-800 ml-2">${totalAmount.toFixed(2)}</span>
                      </div>
                      <div className="flex gap-2 mb-2">
                        <label className="field-label" style={{ minWidth: '150px' }}>Reference</label>
                        <Input
                          type="text"
                          className="input !w-[220px]"
                          value={formData.reference_no}
                          onChange={handleInputChange("reference_no")}
                        //  placeholder="Enter Amount"
                        //  prefix="$"
                        />
                      </div>
                      <div className="flex gap-2 mb-2">
                        <label className="field-label" style={{ minWidth: '150px' }}>Received</label>
                        <DatePicker
                          value={formData.received_date ? dayjs(formData.received_date) : dayjs()}
                          onChange={(date) => {
                            setFormData(prev => ({
                              ...prev,
                              received_date: date ? date.format('MM-DD-YYYY') : '',
                            }));
                          }}
                          format="MM-DD-YYYY"
                          className="non-editable-input !w-[220px]"
                          disabled
                          disabledDate={(current) => current && current > dayjs().startOf('day')
                          }
                        />
                      </div>
                      <div className="flex gap-2 mb-2">
                        <label className="field-label" style={{ minWidth: '150px' }}>Agent</label>
                        <Select
                          options={agentOptions.map((option) => ({
                            value: option,
                            label: option,
                          }))}
                          styles={DropdownStyles}
                          className="min-w-[220px]"
                          value={
                              formData.agent
                                ? { value: formData.agent, label: formData.agent }
                                : null
                            }                          
                            onChange={(selectedOption) =>
                            setFormData((prev) => ({
                              ...prev,
                              agent: selectedOption ? selectedOption.value : "",
                            }))
                          }
                           menuPlacement="top"
                           isClearable
                        />
                      </div>
                      {/* <div className="flex flex-col mt-4">
                   <label className="field-label">Comment</label>
                        <textarea
                      className="textarea"
                    value={formData.comment}
                     onChange={handleInputChange("comment")}
                     placeholder="Enter your comment"
                     rows={4}
                   />
                 </div> */}
                    </div>
             )}
           </Modal>
              
        )}
        <Modal
              open={isMultiPaymentModalOpen}
              onCancel={() => setMultiPaymentModalOpen(false)}
              footer={null}
              width={800}
              destroyOnClose
              centered
              bodyStyle={{ height: "500px", padding: 0, position: "relative" }}
            >
              {iframeUrl && (
                <>
                  {paymentFormloading && (
                    <div
                      className="flex items-center justify-center"
                      style={{
                        position: 'absolute',
                        top: 0,
                        left: 0,
                        width: '100%',
                        height: '100%',
                        backgroundColor: 'rgba(255, 255, 255, 0.8)',
                        zIndex: 1000, // ensure it appears above iframe
                      }}
                    >
                      <Spin size="large" tip="Loading Payment Form..." />
                    </div>
                  )}
                  <iframe
                    src={iframeUrl}
                    width="100%"
                    height="100%"
                    frameBorder="0"
                    allowFullScreen
                    title="Payment"
                    onLoad={() => setPaymentFormLoading(false)} // hide loader once iframe is ready
                  />
                </>
              )}
            </Modal>
        
        </div>
    
    </>
  );
};

export default Bills;
