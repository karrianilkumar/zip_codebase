// app/page.tsx
"use client"
import React from 'react';
import BillingAndCollectionsSubTabs from './billing_collections_sub_tabs/page';
// import ChartsPage from './charts/page';
import { useRouter } from 'next/navigation';
interface BillingAndCollectionsProps {
  row?: any;
  }

const BillingAndCollections: React.FC<BillingAndCollectionsProps> = ({row}) => {
  const router = useRouter();
 
  return (
    // <div className="">
      <div className="flex-1 flex flex-col">
        {/* <div className="flex"> */}
          {/* <ChartsPage /> */}
        
        
          <BillingAndCollectionsSubTabs row={row}/>
        {/* </div> */}
      </div>
    // </div>
  );
};

export default BillingAndCollections;
