"use client";

import React, {
  useEffect,
  useState,
  lazy,
  Suspense,
  useRef,
  useCallback,
} from "react";
import { ArrowDownTrayIcon, ArrowUpTrayIcon, PlusIcon } from "@heroicons/react/24/outline";
import { Modal, Spin, DatePicker, notification, Upload, message, Switch } from "antd";
import { useAuth } from "../../components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "../../components/header_constants";
import  dayjs, { Dayjs } from "dayjs";
import moment from 'moment';
import { useFeatureStore } from "../../sim_management/inventory/featureStore";
import * as XLSX from "xlsx";
import { ENV_ROUTES } from "../../components/routes/route_constants";
import { exportLoadingStore } from "../../stores/ExportLoadingStore";
import KillbillTableComponent from "../killbill_components/table__component";
import CustomCreateModal from "../killbill_components/customerProfilesAddService";
import AdvancedMultiFilter2 from "../killbill_components/advanced__search";
import WholeTableSearch from "../killbill_components/whole__search";
import { useCustomerProfileStore } from "../killbill_stores/customer_profile_store";
import ColumnFilter from "@/app/components/columnfilter";
import { DownloadOutlined, UploadOutlined } from "@ant-design/icons";
import { useKillBillStore } from "../killbill_stores/activeStore";

interface ServicesProps {
  
  row:any;
}
const ServicesPage: React.FC <ServicesProps>= ({row}) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, token, selectedDb,metaData,selectedBillingDb,sessionId, settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId, firstLastName , setStoredPagination , setAdvancedStoredPagination, setCombineAdnvaceStoredpagination,combineAdnvaceStoredpagination} = useAuth();
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  const [loading, setLoading] = useState(false);
  const { addExport, removeExport } = exportLoadingStore();
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [isCreateModalOpen, setCreateModalOpen] = useState(false);
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
  const [generalFields, setgeneralFields] = useState<any[]>([])
  const [createModalData, setcreateModalData] = useState<any[]>([]);
  const [dropDownData, setDropDownData] = useState<any[]>([]);
  const [showActive, setShowActive] = useState(true);
  const hasFetchedData = useRef(false);
  const {
    features: moduleFeatures,
    setFeatures: setModuleFeatures,
    setICCID,
    setBulkRow
  } = useFeatureStore();
  const { accountNumber , setServiceDropdownValues, setUserProfileDetails} = useCustomerProfileStore();
  const [isUploadModalVisible, setIsUploadModalVisible] = useState(false);
  const [isReUploadModalVisible, setIsReUploadModalVisible] = useState(false);
  const [uploadKey, setUploadKey] = useState(Date.now());
  const [isFileSelected, setIsFileSelected] = useState(false);
  const [crossProviderFlag,setCrossProviderFlag] = useState(false);
  const [accountStatus , setAccountStatus] = useState(false);
  const [moduleName_,setModuleName_] = useState('');
  const [isSmallScreen, setIsSmallScreen] = useState(false);
  const { servicesActive, setservicesShowActive } = useKillBillStore();

  // for disconnect modal
  const [isDisconnectModalOpen, setIsDisconnectModalOpen] = useState(false);
  const [disconnectDate, setDisconnectDate] = useState<Dayjs | null>(null);
  const [selectedRowForDisconnect, setSelectedRowForDisconnect] = useState<any>(null);
  const [showDisconnectError, setShowDisconnectError] = useState(false);


  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);

const handleOpenConfirmation = () => {
  setIsConfirmationOpen(true);
};

const handleCancelConfirmation = () => {
  setIsConfirmationOpen(false);
  console.log("Disconnect cancelled by user");
};

const handleConfirmDisconnect = async () => {
  await processDisconnectService(); // your existing logic
  setIsConfirmationOpen(false);
};

   useEffect(() => {
  if (selectedRowForDisconnect?.manual_disconnect_date) {
    const parsed = dayjs(
      selectedRowForDisconnect.manual_disconnect_date,
      ["MM-DD-YYYY HH:mm:ss", "MM-DD-YY", "YYYY-MM-DD"]
    );
    setDisconnectDate(parsed.isValid() ? parsed : null);
  } else {
    setDisconnectDate(null);
  }
}, [selectedRowForDisconnect]);

  type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);


  // eslint-disable-next-line react-hooks/exhaustive-deps
  const fetchData = async () => {
    setBulkRow(null)
    setICCID("");
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    setSearchTerm("");
    setShowAdvanced(false)
    setCombineAdnvaceStoredpagination(null)
    settabledata([]);
    // setTableData([]);
    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/customer_services_list_view",
        role_name: role,
        account_number:accountNumber,
        parent_module: "Billing Platform",
        module_name: "Customer Services",
        main_module_name: "Customer Profiles",
        table_name: "customer_services",
        // sub_module:"Services",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        tenant_id:tenant_id_,
        sessionID: sessionId,
        status: showActive ? "true" : "false",
        feature_module_name: "Customer Services",
        col_sort:{ "modified_date": "DESC" }
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)

      if (parsedData.flag === true) {
        // Defer other state updates using a timeout to decouple them from the main thread
        setUserProfileDetails(parsedData?.dropdown_vals?.user_profile_details || {});

        // setTimeout(() => {
          const headersMap_ = parsedData?.header_map?.["Customer Services"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);
          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
          console.log("headers", headers_)
          setHeaders(headers_);
          setVisibleColumns(headers_);
          const generalFields_ = parsedData || {}
          setgeneralFields(generalFields_)
          console.log("generalFields_",generalFields_)
          setFeatures(parsedData?.header_map?.["Customer Services"]?.module_features || []);
          setModuleFeatures(parsedData?.header_map?.["Customer Services"]?.module_features || []);
          const featres_ = parsedData?.header_map?.["Customer Services"]?.module_features || []
          if(parsedData?.account_status){
            const allowedActions_:any=[]
            if(featres_.includes("Edit Service Location-Customer Services")){
              allowedActions_.push("editServiceLocation")
            }
            if(featres_.includes("Edit Product-Customer Services")){
              allowedActions_.push("editProduct")
            }
            if(featres_.includes("Edit Customer-Services")){
              allowedActions_.push("editNewService")
            }
            if(featres_.includes("Disconnect Service-Customer Services")){
              allowedActions_.push("disconnectService")
            }
            setAllowedActions(allowedActions_)
          }
          else{
            setAllowedActions([])
          }
          setAccountStatus(parsedData?.account_status || "");
          const createModalData_=parsedData?.header_map?.["Customer Services"]?.pop_up||[]
          console.log("createModalData_",createModalData_)
          setcreateModalData(createModalData_)
          setDropDownData(parsedData?.dropdown_vals);
          setServiceDropdownValues(parsedData?.dropdown_vals);
          setPagination(parsedData?.pages || {});
          console.log("parsedData?.data?.customer_services || [])",parsedData?.data?.customer_services || []);
          setTableData(parsedData?.data?.customer_services || []);
          setCrossProviderFlag(parsedData?.cross_provider || false);
          // setModuleName_(parsedData?.cross_provider  ? "Customer Services Customer" : "Customer Services Carrier");
        // }, 0);
        // setLoading(false);
        
      } else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
  const handleCreateModalOpen = () => {
    setCreateModalOpen(true);
  };

  const handleCreateModalClose = () => {
    setCreateModalOpen(false);
  };

  const handleCreateRow = (newRow: any) => {
    console.log("New Row Data:", newRow);
    handleCreateModalClose();
  };

  const handleDisconnectModalOpen = (row: any) => {
  setSelectedRowForDisconnect(row);
  setIsDisconnectModalOpen(true);
    };

    const handleDisconnectModalClose = () => {
      setIsDisconnectModalOpen(false);
      setSelectedRowForDisconnect(null);
      setDisconnectDate(null);
      setShowDisconnectError(false);
    };
   const handleDisconnectService = async () => {
  if (!disconnectDate) {
    setShowDisconnectError(true);
    return;
  }

  // ✅ Open your custom confirmation modal
  handleOpenConfirmation();
};


    // Show confirmation dialog with compact width like reference
  //   Modal.confirm({
  //     title: 'Confirmation',
  //     content: 'Deactivating this service may affect unbilled unposted charges.',
      
  //     centered: true,
  //     okText: 'OK',
  //     cancelText: 'Cancel',
  //     okType: 'primary',
  //     icon: null, // This removes any default icon/emoji
  //     closable: true, // Add X symbol like disconnect popup
  //     onOk: async () => {
  //       // This function will run when user clicks "OK"
  //       await processDisconnectService();
  //     },
  //     onCancel: () => {
  //       // User clicked Cancel - do nothing
  //       console.log('Disconnect cancelled by user');
  //     },
  //     // Reduced width to match reference image
  //     width: 500, // Changed from 400 to 320
  //     bodyStyle: {
  //       // padding: '8px 20px', // Reduced padding from 16px to 8px (above/below)
  //       fontSize: '14px'
  //     },
  //     // Button styling to match compact layout
  //     okButtonProps: { 
  //       style: {
  //         minWidth: '60px'
  //       }
  //     },
  //     cancelButtonProps: {
  //       style: {
  //         minWidth: '60px',
  //         backgroundColor: ' #6b7280', // Grey background like disconnect modal
  //         borderColor: '#d9d9d9',     // Grey border
  //         color: '#595959'            // Grey text color
  //       }
  //     }
      
      
  //   });
  // };


// Create a separate function for the actual API call
const processDisconnectService = async () => {
  setIsConfirmationOpen(false);
  try {
    setLoading(true);
    const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
    const tenant_id_ = localStorage.getItem("tenant_id") || "0";
    const fullId = selectedRowForDisconnect.id; // e.g. "3703-127-2"
    const mainId = String(fullId).split("-")[0]; // e.g. "3703"
    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/disconnect_service_lines",
      role_name: role,
      parent_module: "Billing Platform",
      module_name: "Customer Services",
      main_module_name: "Customer Profiles",
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
      tenant_id: tenant_id_,
      sessionID: sessionId,
      account_number: accountNumber,
      disconnect_data:{
        [mainId] : disconnectDate?.format('YYYY-MM-DD')
      }
      // disconnect_date: disconnectDate?.format('YYYY-MM-DD'),
      // row_id: selectedRowForDisconnect.id,
    };

    const response = await axios.post(url, { data });
    const resp = JSON.parse(response.data.body);

    if (response.data.statusCode === 200 && resp.flag === true) {
      notification.success({
        message: 'Success',
        description: resp.message || 'Service disconnected successfully!',
        placement: 'top',
      });
      handleDisconnectModalClose();
      await fetchData();
    } else {
      Modal.error({
        title: 'Disconnect Error',
        content: resp.message || 'An error occurred while disconnecting the service.',
        centered: true,
      });
    }
  } catch (error) {
    Modal.error({
      title: 'Disconnect Error',
      content: error instanceof Error ? error.message : 'An unexpected error occurred.',
      centered: true,
    });
  } finally {
    setLoading(false);
  }
};

  useEffect(() => {
    if (!hasFetchedData.current) {
      fetchData();
      hasFetchedData.current = true;
    }
  }, [fetchData]);
   useEffect(() => {
          const checkScreenSize = () => {
              setIsSmallScreen(window.innerWidth < 700);
          };
          
          // Initial check
          checkScreenSize();
          
          // Add event listener for window resize
          window.addEventListener('resize', checkScreenSize);
          
          // Clean up
          return () => window.removeEventListener('resize', checkScreenSize);
      }, []);
   useEffect(() => {
     fetchData();
     console.log("If show active is false", showActive)
     setservicesShowActive(showActive);
   }, [partner, showActive]);
   const handleSwitchChange = (checked: any) => {
     setShowActive(checked)
   };
  const handleFilter = useCallback((advancedFilters: any) => {
    console.log(advancedFilters);
    setAdvancedFilters(advancedFilters)
  }, []);

  const handleReset = useCallback((EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  }, []);
  
  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }

  const ExportWithoutSearch = async (key:string) => {
  
    try {
     // Set module_name based on crossProviderFlag
      // const module_name = crossProviderFlag
      //   ? "Customer Services Customer"
      //   : "Customer Services Carrier";
      const module_name = servicesActive ?  "Active Customer Services" : "Customer Services"
      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Request timed out"));
          }, timeout);
  
          promise
            .then((res) => {
              clearTimeout(timer);
              resolve(res);
            })
            .catch((err) => {
              clearTimeout(timer);
              reject(err);
            });
        });
      };
  
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";
      
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/customer_services_export",
        role_name: role,
        parent_module: "Billing Platform",
        module_name,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        tenant_id:tenant_id_,
        feature_module_name: "Customer Services",
        start_date: getFirstDayOfCurrentMonth(),
        end_date: getLastDayOfCurrentMonth(),
        killbill_flag:"True",
        account_number:accountNumber,
        main_module_name: "Customer Profiles",

      };
  
      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000);
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }
  
      // Wait for 20 seconds before polling
      await new Promise((resolve) => setTimeout(resolve, 20000));
  
      const export_url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const export_data = {
        ...data,
        path: "/get_export_status",
        module_name,
      };
  
      const pollExportStatus = async () => {
        try {
          const export_response = await axios.post(export_url, { data: export_data });
          const export_parsedData = JSON.parse(export_response.data.body);
  
          if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
            const s3Url = export_parsedData?.export_status_data?.url || null;
            if (s3Url) {
              // window.location.href = s3Url;
              // notification.success({
              //   message: "Success",
              //   description: "Successfully exported the  record!",
              //   style: messageStyle,
              //   placement: "top",
              // });
              fetch(s3Url)
              .then(response => response.blob())
              .then(blob => {
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = showActive ? 'Active Customer Services.xlsx' : "Customer Services.xlsx";
                a.click();
                a.remove();
                window.URL.revokeObjectURL(url);
                notification.success({
                  message: "Success",
                  description: "Successfully exported the record!",
                  style: messageStyle,
                  placement: "top",
                });
              })
              .catch((err) => {
                console.log("error", err)
                Modal.error({
                  title: "Export Error",
                  content: "An error occurred while exporting data. Please try again.",
                  centered: true,
                });
              });
            } else {
              Modal.error({
                title: "Export Error",
                content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            }
            return true; // Stop polling
          }
  
          if (export_parsedData?.export_status_data?.status_flag === "Failure") {
            Modal.error({
              title: "Export Error",
              content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
              centered: true,
            });
            return true; // Stop polling
          }
          if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
                      Modal.error({
                        title: "Export Error",
                        content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
                        centered: true,
                      });
                      return true; // Stop polling
                    }
          return false; // Continue polling
        } catch (error) {
          Modal.error({
            title: "Export Error",
            content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
            centered: true,
          });
          return true; // Stop polling
        }
      };
  
      const startPolling = async () => {
        let isPollingComplete = false;
  
        while (!isPollingComplete) {
          isPollingComplete = await pollExportStatus();
          if (!isPollingComplete) {
            await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
          }
        }
      };
  
      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      removeExport(key); // Remove the export from the store
    }
  };
  
  const handleUploadClick = () => {
    setIsUploadModalVisible(true);

  }
   const handleReUploadClick = () => {
    setIsReUploadModalVisible(true);

  }

  const handleDownloadTemplate = async (flag:string,type?:any) => {
    settabledata([]);
    const serviceTypeIds = tableData.map((row: { id: any; }) => row.id);
    const rowData: Record<string, any[]> = {};
    tableData.forEach((row: { customer_service_id: string | number; products: string; is_active: boolean }) => {
      try {
        const fixedProductsString = row.products
          .replace(/'/g, '"')                // Replace single quotes with double quotes
          .replace(/\bNone\b/g, 'null')      // Replace None with null
          .replace(/\bTrue\b/g, 'true')      // Replace True with true
          .replace(/\bFalse\b/g, 'false');   // Replace False with false

        const parsedProducts = JSON.parse(fixedProductsString);

        // Only push to rowData if the row itself is active
        if (row.is_active && parsedProducts.length > 0) {
          rowData[row.customer_service_id] = parsedProducts;
        }

      } catch (error) {
        console.error(`Failed to parse products for ${row.customer_service_id}`, error);
      }
    });

    // console.log(rowData);

    setLoading(true);
    const url =
      ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";
    
    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName:firstLastName,
      path: type === 'upload' && flag === 'download_template'? "/download_bulk_upload_services_template":type === 'upload' && flag === 'download_template_2'? "/download_bulk_upload_service_types_template":type === 'reupload'? "/download_to_reupload_services_template":"",
      table_name: "customer_services",
      module_name: "Customer Services",
      services_list: serviceTypeIds? serviceTypeIds : [],
      flag:flag,
      Partner: partner,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
      ...metaData,
billing_db_name: selectedBillingDb,
      sessionID: sessionId,
      tenant_id:tenant_id_,
      account_number:accountNumber,
      row_data: rowData,
      main_module_name: "Customer Profiles",
    };
     if (type === 'reupload') {
    data.services_list = serviceTypeIds? serviceTypeIds : [];
  }

    const response = await axios.post(url, { data });
    const resp = JSON.parse(response.data.body);
    const blob = resp.blob;
    console.log(resp);
    if (response.data.statusCode === 200) {
      if (resp.flag === true) {
        notification.success({
          message: 'Success',
          description: 'Successfully downloaded the template!',
          style: messageStyle,
          placement: 'top',
        });
        downloadBlob(blob,resp.file_name);
        // fetchData();
        setLoading(false);
        setIsUploadModalVisible(false);
        setIsReUploadModalVisible(false);

      } else {
        console.log('Error message:', resp.message);
        Modal.error({
          title: 'Export Error',
          content: resp.message,
          centered: true,
        });
    setLoading(false)

      }
    } else {
      console.log('Unexpected status code:', response.data.statusCode);
      Modal.error({
        title: 'Export Error',
        content: resp.message,
        centered: true,
      });
    setLoading(false)

    }
  };
  const handleUpload = async (blob: string) => {
    setLoading(true)
    try {
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";

      const data = {
        accountNumber:accountNumber,
        tenant_name: partner || "default_value",
        username: username,
        firstLastName:firstLastName,
        path: "/import_bulk_data",
        table_name: "customer_services",
        insert_flag: "append",
        module_name: "Customer Services",
        role_name: role,
        Partner: partner,
        account_number:accountNumber,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        tenant_id:tenant_id_,
        main_module_name: "Customer Profiles",
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        blob: blob, // Include the Blob in the data
      };

      const response = await axios.post(url, { data });

      const resp = JSON.parse(response.data.body);
      if (response.data.statusCode === 200) {
        if (resp.flag === true) {
          setIsUploadModalVisible(false)
          await fetchData()
          notification.success({
            message: 'Success',
            description: resp.message || 'Successfully uploaded the record!',
            placement: 'top',
            duration: 0,
          });
        } else {
          Modal.error({
            title: 'Import Error',
            content: resp.message,
            centered: true,
            onOk: handleErrorModalClose,
            onCancel: handleErrorModalClose
          });
        }
      } else {
        Modal.error({
          title: 'Import Error',
          content: resp.message,
          centered: true,
          onOk: handleErrorModalClose,
          onCancel: handleErrorModalClose
        });
      }
    } catch (error) {
      console.error('Error during file upload:', error);
      Modal.error({
        title: 'Import Error',
        content: 'There was an error uploading the file.',
        centered: true,
        onOk: handleErrorModalClose,
        onCancel: handleErrorModalClose
      });

    }
    finally{
    setLoading(false)
    setIsUploadModalVisible(false)
    }
  }
  const handleReUpload = async (blob: string) => {
    setIsReUploadModalVisible(false);
    setLoading(true)
    try {
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;

      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName:firstLastName,
        path: "/reupload_customer_services",
        table_name: "customer_services",
        insert_flag: "append",
        module_name: "Customer Services",
        role_name: role,
        Partner: partner,
        account_number:accountNumber,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ...metaData,
billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        blob: blob, 
        main_module_name: "Customer Profiles",
      };

      const response = await axios.post(url, { data });

      const resp = JSON.parse(response.data.body);
      if (response.data.statusCode === 200) {
        if (resp.flag === true) {
          await fetchData()
          notification.success({
            message: 'Success',
            description: resp.message || 'Successfully uploaded the record!',
            placement: 'top',
            duration: 0,
          });
          // setIsReUploadModalVisible(false);
        } else {
          Modal.error({
            title: 'Import Error',
            content: resp.message,
            centered: true,
            onOk: handleErrorModalClose,
            onCancel: handleErrorModalClose
          });
        }
      } else {
        Modal.error({
          title: 'Import Error',
          content: resp.message,
          centered: true,
          onOk: handleErrorModalClose,
          onCancel: handleErrorModalClose
        });
      }
    } catch (error) {
      console.error('Error during file upload:', error);
      Modal.error({
        title: 'Import Error',
        content: 'There was an error uploading the file.',
        centered: true,
        onOk: handleErrorModalClose,
        onCancel: handleErrorModalClose
      });

    }
    finally{
    setLoading(false)
    setIsUploadModalVisible(false)
    setIsReUploadModalVisible(false);
    }
  }
  const downloadBlob = (base64Blob: string ,file_name :any) => {
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    const blobObject = new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blobObject);
    link.download =   `${file_name}.xlsx` || "Customer Service.xlsx";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
   const handleChange = (info: any) => {
      if (info.file.status === "done") {
    const file = info.file.originFileObj;
    const reader = new FileReader();

    reader.onload = (e: any) => {
      const data = new Uint8Array(e.target.result);
      const workbook = XLSX.read(data, { type: "array", cellDates: false });

      const allSheetsData = workbook.SheetNames.map((sheetName) => {
        const sheet = workbook.Sheets[sheetName];
        
        // Convert to JSON with raw: false to preserve formatted text
        const json = XLSX.utils.sheet_to_json(sheet, { 
          raw: false,  // This will read formatted values as strings
          defval: ''   // Default empty values
        }) as Record<string, any>[];

        // Data is already in the correct format, just pass it through
        const parsed = json.map((row) => {
          const newRow: Record<string, any> = {};
          
          for (const key in row) {
            // All values including dates are now strings, no conversion needed
            newRow[key] = row[key];
          }
          
          return newRow;
        });

        return { sheetName, data: parsed };
      });

      console.log("All Sheets Data:", allSheetsData);
      handleUpload(JSON.stringify(allSheetsData));
    };

    reader.readAsArrayBuffer(file);
  }else if (info.file.status === 'error') {
        // Handle upload error
        message.error('Upload failed.');
      }
      else if (info.file.status === 'removed') {
        setIsFileSelected(false);
       
      }
    };

const handleReUploadChange = (info: any) => {
  if (info.file.status === "done") {
    const file = info.file.originFileObj;
    const reader = new FileReader();

    reader.onload = (e: any) => {
      const data = new Uint8Array(e.target.result);
      const workbook = XLSX.read(data, { type: "array", cellDates: false });

      const allSheetsData = workbook.SheetNames.map((sheetName) => {
        const sheet = workbook.Sheets[sheetName];
        
        // Convert to JSON with raw: false to preserve formatted text
        const json = XLSX.utils.sheet_to_json(sheet, { 
          raw: false,  // This will read formatted values as strings
          defval: ''   // Default empty values
        }) as Record<string, any>[];

        // Data is already in the correct format, just pass it through
        const parsed = json.map((row) => {
          const newRow: Record<string, any> = {};
          
          for (const key in row) {
            // All values including dates are now strings, no conversion needed
            newRow[key] = row[key];
          }
          
          return newRow;
        });

        return { sheetName, data: parsed };
      });

      console.log("All Sheets Data:", allSheetsData);
      handleReUpload(JSON.stringify(allSheetsData));
    };

    reader.readAsArrayBuffer(file);
  }
  else if (info.file.status === 'error') {
        // Handle upload error
        message.error('Upload failed.');
      }
      else if (info.file.status === 'removed') {
        setIsFileSelected(false);
       
      }
};


  const uploadProps = {
    key: uploadKey,
    accept: '.xlsx, .xls',
    beforeUpload: (file: any) => {
      // Check if file is an Excel file
      const isExcel = file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || file.type === 'application/vnd.ms-excel';
      if (!isExcel) {
        message.error('You can only upload Excel files!');
      }
      return isExcel;
    },
    onChange: handleChange,
  };
  const reUploadProps = {
    key: uploadKey,
    accept: '.xlsx, .xls',
    beforeUpload: (file: any) => {
      // Check if file is an Excel file
      const isExcel = file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || file.type === 'application/vnd.ms-excel';
      if (!isExcel) {
        message.error('You can only upload Excel files!');
      }
      return isExcel;
    },
    onChange: handleReUploadChange,
  };
 

  const handleExport = async (key: string, heading: string) => {
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";
  
    try {
      addExport(key, heading);
  
      let parsedData;
      let url;
      let data: any;
      let response;
      console.log("crossProviderFlag",crossProviderFlag)
      // Set module_name based on crossProviderFlag
      const moduleName = "Customer Services";
      // setModuleName_(moduleName);

      console.log("module_name",moduleName)
  
      if(combineAdnvaceStoredpagination){
        console.log("combineAdnvaceStoredpagination",combineAdnvaceStoredpagination)
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          // tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedBillingDb,
          ...metaData,
// billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id : tenant_id_,
          index_name:moduleName,
          module_name:moduleName,
          account_number:accountNumber,
          toggle: servicesActive ? true : false,
        };
        console.log("combineAdnvaceStoredpagination",data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
        else if (advancedStoredpagination && !storedpagination) {
        console.log("advancedStoredpagination",advancedStoredpagination)
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "advanced",
          filters: advancedMultiFilters,
          username:username,
          index_name: moduleName,
          module_name: moduleName,
          pages: { start: 0, end: 100 },
          partner,
          db_name: selectedBillingDb,
          ...metaData,
// billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenant_id_,
          account_number:accountNumber,
          toggle: servicesActive ? true : false,
        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } 
      else if (storedpagination && !advancedStoredpagination) {
        console.log("storedpagination",storedpagination)
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search_word: searchTerm,
          username: username,
          search_all_columns: "True",
          index_name: moduleName,
          module_name: moduleName,
          search: "whole",
          pages: { start: 0, end: 100 },
          partner,
          db_name: selectedBillingDb,
          ...metaData,
// billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenant_id_,
          account_number:accountNumber,
          toggle: servicesActive ? true : false,
        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } else {
        await ExportWithoutSearch(key);
        return;
      }
  
      if (parsedData.flag) {
        const s3Url = parsedData?.download_url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the  record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
          .then(response => response.blob())
          .then(blob => {
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'Customer Services.xlsx';
            a.click();
            a.remove();
            window.URL.revokeObjectURL(url);
            notification.success({
              message: "Success",
              description: "Successfully exported the record!",
              style: messageStyle,
              placement: "top",
            });
          })
          .catch((err) => {
            console.log("error", err)
            Modal.error({
              title: "Export Error",
              content: "An error occurred while exporting data. Please try again.",
              centered: true,
            });
          });
        } else {
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      } else {
        Modal.error({
          title: "Export Error",
          content: parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      removeExport(key);
    }
  };
  const handleErrorModalClose = () => {
    setIsUploadModalVisible(false)
  }
  const handleUploadModalClose = () => {
    setIsUploadModalVisible(false);
  };
const handleReUploadModalClose = () => {
    setIsReUploadModalVisible(false);
  }
  const messageStyle = {
    fontSize: "14px",
    fontWeight: "normal",
    padding: "16px",
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }
  console.log(row,"Show account number")
  return (
    <>
      <div className="relative">
        <div className="flex justify-end p-2">
          <div className="flex items-center space-x-2 justify-end mt-2">
            <Switch onChange={handleSwitchChange} checked={showActive} className="custom-switch" />
            <span className="font-bold text-lg">Show Active only</span>
          </div>
        </div>
          <div className="p-2 flex md:flex-row md:items-center md:justify-between mt-1 space-y-6 md:space-y-0">
            <div className="flex  space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last">
            {features.includes("Search-Customer Services") && (
              <WholeTableSearch
                searchTerm={searchTerm}
                setSearchTerm={setSearchTerm}
                tableName={"Customer Services"}
                headerMap={headerMap}
              />
            )}
            {features.includes("Advanced filter-Customer Services") && (
              <AdvancedMultiFilter2
                showAdvanced={showAdvanced}
                setShowAdvanced={setShowAdvanced}
                onFilter={handleFilter}
                onReset={handleReset}
                headers={headers}
                headerMap={headerMap}
                tableName={"Customer Services"}
              />
            )}
          </div>
            <div className="hidden md:flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2 pl-2 md:order-none order-first">
            {features.includes("Add New-Customer Services") && (

              <button className={!accountStatus? "cancel-btn" :"save-btn"} onClick={handleCreateModalOpen} disabled={!accountStatus}>
                {/* <PlusIcon className="h-5 w-5 text-black-500 mr-1" /> */}
                Actions
              </button>)}
            {features.includes("Reupload-Customer Services") && (
              <button className={!accountStatus? "cancel-btn" :"save-btn"} onClick={handleReUploadClick} disabled={!accountStatus}>
                <ArrowUpTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                <span>Edit Services</span>
              </button>
            )}
            {features.includes("Upload-Customer Services") && (
              <button className={!accountStatus? "cancel-btn" :"save-btn"} onClick={handleUploadClick} disabled={!accountStatus}>
                <ArrowUpTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                <span>Upload Service</span>
              </button>
            )}
            {/* <Modal
              title="Upload Files"
              visible={isUploadModalVisible}
              onCancel={handleUploadModalClose}
              footer={null}
              centered
              bodyStyle={{ padding: '1rem' }}
              width={400}
            >
              <div className="flex flex-col gap-4 px-2 sm:px-4">
                <div className="flex flex-col gap-4 items-center m-auto p-4">
                  <Upload {...uploadProps}>
                    <button
                      className="w-[200px] upload-btn disabled:cursor-not-allowed h-10 flex items-center justify-center"
                    >
                      <span className="mr-2"><UploadOutlined /></span>
                      Upload
                    </button>
                  </Upload>

                  <button
                    onClick={() => handleDownloadTemplate('download_template')}
                    className="w-[200px] upload-btn disabled:cursor-not-allowed h-10 flex items-center justify-center"
                  >
                    <span className="mr-2"><DownloadOutlined /></span>
                    Download Template
                  </button>

                  <button
                    onClick={() => handleDownloadTemplate('download_prefilled_template')}
                    className="w-[200px] upload-btn disabled:cursor-not-allowed h-10 flex items-center justify-center"
                  >
                    <span className="mr-2"><DownloadOutlined /></span>
                    Download Prefilled Template
                  </button>
                </div>
              </div>
            </Modal> */}


            <Modal
              title="Upload Files"
              visible={isUploadModalVisible}
              onCancel={handleUploadModalClose}
              footer={null}
              centered
              bodyStyle={{ padding: "1rem", height: "200px", overflow: "hidden" }}
              width={400}
            >
              <div className="flex flex-col items-center justify-center gap-4 h-full">
                {/* First Row: Upload and Download Template */}
                <div className="flex flex-col gap-4">
                  <Upload {...uploadProps}>
                    <button
                      className="upload-btn w-64 disabled:cursor-not-allowed h-10 flex items-center justify-center whitespace-normal break-words"
                    >
                      <span className="mr-2"><UploadOutlined /></span>
                      Upload
                    </button>
                  </Upload>
                  <button
                    onClick={() => handleDownloadTemplate("download_template", 'upload')}
                    className="upload-btn w-64 disabled:cursor-not-allowed h-10 flex items-center justify-center whitespace-normal break-words"
                  >
                    <span className="mr-2"><DownloadOutlined /></span>
                    Download Customer Rate plan Template
                  </button>
                  <button
                    onClick={() => handleDownloadTemplate("download_template_2", 'upload')}
                    className="upload-btn w-64 disabled:cursor-not-allowed h-10 flex items-center justify-center whitespace-normal break-words"
                  >
                    <span className="mr-2"><DownloadOutlined /></span>
                    Download Service Type Template
                  </button>
                </div>
                {/* Second Row: Download Prefilled Template */}
                {/* <div className="flex flex-row gap-4">
                  <button
                    onClick={() => handleDownloadTemplate("download_prefilled_template",'upload')}
                    className="upload-btn match-width disabled:cursor-not-allowed h-10 flex items-center justify-center whitespace-nowrap pr-6 pl-6"
                  >
                    <span className="mr-2"><DownloadOutlined /></span>
                    Download Prefilled Template
                  </button>
                </div> */}
              </div>
            </Modal>
            <Modal
              title="Edit Services"
              visible={isReUploadModalVisible}
              onCancel={handleReUploadModalClose}
              footer={null}
              centered
              bodyStyle={{ padding: "1rem", height: "100px", overflow: "hidden" }}
              width={400}
            >
              <div className="flex flex-col justify-evenly gap-4 h-full">
                {/* First Row: Upload and Download Template */}
                <div className="flex flex-row gap-4">
                  <Upload {...reUploadProps}>
                    <button
                      className="upload-btn match-width disabled:cursor-not-allowed h-10 flex items-center justify-center whitespace-nowrap"
                    >
                      <span className="mr-2"><UploadOutlined /></span>
                      Upload
                    </button>
                  </Upload>
                  <button
                    onClick={() => handleDownloadTemplate("download_template", 'reupload')}
                    className="upload-btn match-width disabled:cursor-not-allowed h-10 flex items-center justify-center whitespace-nowrap"
                  >
                    <span className="mr-2"><DownloadOutlined /></span>
                    Download Template
                  </button>
                </div>
              </div>
            </Modal>
            {features.includes("Export-Customer Services") && (
              <button className="save-btn" onClick={() => handleExport("Services", "Services")}
                {...(showAdvanced && {
                  style: { minWidth: "2rem", width: "2rem", padding: 0 }
                })}>                
                <ArrowDownTrayIcon className={`h-5 w-5 text-black-500 ${!showAdvanced ? "mr-2" : ""}`} />
                {!showAdvanced && (<span>Export</span>)}
              </button>
            )}
            <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
              popupHeading="Services"
            />
          </div>
        </div>
        <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
          <KillbillTableComponent
          headers={headers}
          headerMap={headerMap}
          initialData={tableData}
          searchQuery={searchTerm}
          visibleColumns={visibleColumns}
          itemsPerPage={100}
          allowedActions={allowedActions}
          popupHeading="Services"
          pagination={pagination}
          advancedFilters={filteredData}
          height={showAdvanced ? 360 : 300}
          onDisconnectService={handleDisconnectModalOpen}
        />

        </div>
            <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
            {features.includes("Add New-Customer Services") && (

              <button className={!accountStatus? "cancel-btn" :"save-btn"} onClick={handleCreateModalOpen} disabled={!accountStatus}>
                <PlusIcon className="h-5 w-5 text-black-500" />
              </button>)}
            {features.includes("Reupload-Customer Services") && (
              <button className={!accountStatus? "cancel-btn" :"save-btn"} onClick={handleReUploadClick} disabled={!accountStatus}>
                <ArrowUpTrayIcon className="h-5 w-5 text-black-500" />
              </button>
            )}
            {features.includes("Upload-Customer Services") && (
              <button className={!accountStatus? "cancel-btn" :"save-btn"} onClick={handleUploadClick} disabled={!accountStatus}>
                <ArrowUpTrayIcon className="h-5 w-5 text-black-500" />
              </button>
            )}
            {/* <Modal
              title="Upload Files"
              visible={isUploadModalVisible}
              onCancel={handleUploadModalClose}
              footer={null}
              centered
              bodyStyle={{ padding: '1rem' }}
              width={400}
            >
              <div className="flex flex-col gap-4 px-2 sm:px-4">
                <div className="flex flex-col gap-4 items-center m-auto p-4">
                  <Upload {...uploadProps}>
                    <button
                      className="w-[200px] upload-btn disabled:cursor-not-allowed h-10 flex items-center justify-center"
                    >
                      <span className="mr-2"><UploadOutlined /></span>
                      Upload
                    </button>
                  </Upload>

                  <button
                    onClick={() => handleDownloadTemplate('download_template')}
                    className="w-[200px] upload-btn disabled:cursor-not-allowed h-10 flex items-center justify-center"
                  >
                    <span className="mr-2"><DownloadOutlined /></span>
                    Download Template
                  </button>

                  <button
                    onClick={() => handleDownloadTemplate('download_prefilled_template')}
                    className="w-[200px] upload-btn disabled:cursor-not-allowed h-10 flex items-center justify-center"
                  >
                    <span className="mr-2"><DownloadOutlined /></span>
                    Download Prefilled Template
                  </button>
                </div>
              </div>
            </Modal> */}

            {isSmallScreen && isUploadModalVisible &&(
            <Modal
              title="Upload Files"
              visible={isUploadModalVisible}
              onCancel={handleUploadModalClose}
              footer={null}
              centered
              bodyStyle={{ padding: "1rem", height: "100px", overflow: "hidden" }}
              width={400}
            >
              <div className="flex flex-col justify-evenly gap-4 h-full">
                {/* First Row: Upload and Download Template */}
                <div className="flex flex-row gap-4">
                  <Upload {...uploadProps}>
                    <button
                      className="upload-btn match-width disabled:cursor-not-allowed h-10 flex items-center justify-center whitespace-nowrap"
                    >
                      <span className="mr-2"><UploadOutlined /></span>
                      Upload
                    </button>
                  </Upload>
                  <button
                    onClick={() => handleDownloadTemplate("download_template", 'upload')}
                    className="upload-btn match-width disabled:cursor-not-allowed h-10 flex items-center justify-center whitespace-nowrap"
                  >
                    <span className="mr-2"><DownloadOutlined /></span>
                    Download Template
                  </button>
                </div>
                {/* Second Row: Download Prefilled Template */}
                {/* <div className="flex flex-row gap-4">
      <button
        onClick={() => handleDownloadTemplate("download_prefilled_template",'upload')}
        className="upload-btn match-width disabled:cursor-not-allowed h-10 flex items-center justify-center whitespace-nowrap pr-6 pl-6"
      >
        <span className="mr-2"><DownloadOutlined /></span>
        Download Prefilled Template
      </button>
    </div> */}
              </div>
            </Modal>
            )}
           {(isSmallScreen && isReUploadModalVisible) &&(
            <Modal
              title="Edit Services"
              visible={isReUploadModalVisible}
              onCancel={handleReUploadModalClose}
              footer={null}
              centered
              bodyStyle={{ padding: "1rem", height: "100px", overflow: "hidden" }}
              width={400}
            >
              <div className="flex flex-col justify-evenly gap-4 h-full">
                {/* First Row: Upload and Download Template */}
                <div className="flex flex-row gap-4">
                  <Upload {...reUploadProps}>
                    <button
                      className="upload-btn match-width disabled:cursor-not-allowed h-10 flex items-center justify-center whitespace-nowrap"
                    >
                      <span className="mr-2"><UploadOutlined /></span>
                      Upload
                    </button>
                  </Upload>
                  <button
                    onClick={() => handleDownloadTemplate("download_template", 'reupload')}
                    className="upload-btn match-width disabled:cursor-not-allowed h-10 flex items-center justify-center whitespace-nowrap"
                  >
                    <span className="mr-2"><DownloadOutlined /></span>
                    Download Template
                  </button>
                </div>
              </div>
            </Modal>
           )}
            {features.includes("Export-Customer Services") && (
              <button className="save-btn" onClick={() => handleExport("Services", "Services")}>
                <ArrowDownTrayIcon className="h-5 w-5 text-black-500" />
              </button>
            )}
            <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
            />
          </div>
          
          <Modal
          title="Disconnect Service"
          visible={isDisconnectModalOpen}
          onCancel={handleDisconnectModalClose}
          footer={null}
          centered
          width={400}
          height={100}
          // bodyStyle={{ padding: '16px' }}
        >
          
          <div className="flex flex-col gap-2">
            <label className="text-sm font-medium text-gray-700">
              Disconnect Date <span className="text-red-500">*</span>
            </label>
            <DatePicker
              value={disconnectDate}
              className="input"
               onChange={(date) => {
                  setDisconnectDate(date);
                  setShowDisconnectError(false);
                }}
              format="MM-DD-YYYY"
              disabledDate={(current) => current && current < moment().startOf('day')}
              placeholder="Disconnect Date"
              style={{ width: '100%', height: '40px' }}
            />
            {showDisconnectError && !disconnectDate && (
              <span className="text-red-500 text-xs mt-1">
                Disconnect Date is required
              </span>
            )}
          </div>
            
            <div className="flex justify-center gap-4 mt-6">
              <button
                className="cancel-btn"
                onClick={handleDisconnectModalClose}
                style={{ minWidth: '120px' }}
              >
                Cancel
              </button>
              <button
                className="save-btn"
                onClick={handleDisconnectService}
                style={{ minWidth: '120px' }}
              >
                Save
              </button>
            </div>
          
        </Modal>

      

        <Modal
  title="Confirmation"
  open={isConfirmationOpen}
  onCancel={handleCancelConfirmation}
  centered
  width={480}
  closable
  bodyStyle={{
    // padding: "12px 20px",
    fontSize: "14px",
  }}
  footer={
    <div
      style={{
        display: "flex",
        justifyContent: "center",
        width: "100%",
        gap: "10px",
      }}
    >
      <button
        className="cancel-btn"
        onClick={handleCancelConfirmation}
        style={{ minWidth: "100px", padding: "6px 0" }}
      >
        Cancel
      </button>
      <button
        className="save-btn"
        onClick={handleConfirmDisconnect}
        style={{ minWidth: "100px", padding: "6px 0" }}
      >
        OK
      </button>
    </div>
  }
>
  <p>
    Deactivating this service may affect unposted charges.
  </p>
</Modal>


        <CustomCreateModal
          isOpen={isCreateModalOpen}
          onClose={handleCreateModalClose}
          onSave={handleCreateRow}
          modalData={createModalData}
          title="Services"
          visible={isCreateModalOpen}
          action="create"
          generalFields={generalFields}
          dropdownValues={dropDownData}
          accountNumber={accountNumber}
          fetchdata={fetchData}
        />
      </div>
    </>
  );
};

export default ServicesPage;
