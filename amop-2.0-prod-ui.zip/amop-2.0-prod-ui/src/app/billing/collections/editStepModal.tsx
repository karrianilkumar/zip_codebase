import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import RichTextEditor from "../killbill_components/RichTextEditor";
import { Checkbox, Input, Modal, notification, Popover, Spin, Switch, DatePicker, Tooltip } from 'antd'; // Import DatePicker
import { useEffect, useState } from "react";
import Select from 'react-select';
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { DropdownStyles } from "@/app/components/css/dropdown";
import { InformationCircleIcon } from "@heroicons/react/24/outline";

interface EditStepModalProps {
  isModalOpen: boolean;
  setIsModalOpen?: (open: boolean) => void;
  quillValue: string;
  setQuillValue: (value: string) => void;
  onClose: () => void;
  selectedStep?:any;
  rowData?:any;
  setHeaders: any;           
  setHeaderMap: any;  
  setTableData: any; 
  tableData: any;  
}
const messageStyle = {
    fontSize: '14px',
    fontWeight: 'normal',
    padding: '16px',
};

const EditStepModal: React.FC<EditStepModalProps> = ({
  isModalOpen,
  setIsModalOpen,
  quillValue,
  setQuillValue,onClose,selectedStep,rowData,setHeaders,
  setHeaderMap,
  setTableData,tableData
}) => {
    const [loading, setLoading] = useState(false);
      const [formValues, setFormValues] = useState<Record<string, any>>({});
    
    const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);
    const { username, partner, role, token, selectedDb,metaData, selectedBillingDb,sessionId, settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId, firstLastName, setStoredPagination, setAdvancedStoredPagination, setCombineAdnvaceStoredpagination } = useAuth();
    const [validationErrors, setValidationErrors] = useState<{
        [key: string]: string;
    }>({});
    const [createModalData, setcreateModalData] = useState<any[]>([]);
    const [generalFields2, setGeneralFields2] = useState<any>({});
    const [htmlContent, setHtmlContent] = useState("");
     useEffect(() => {
            if (isModalOpen) {
                setFormValues(rowData || {});
                setValidationErrors({});
                FetchStepData()
                console.log("Rowdata", rowData)
            }
        }, [isModalOpen]);
    const FetchStepData = async () => {


        let parsedData: any;
        try {
            setLoading(true);
            const url = ENV_ROUTES.BP_COLLECTIONS;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/collection_step_edit",
                role_name: role,
                parent_module: "Billing Platform",
                module_name: "Collection Steps",
                mod_pages: {
                    start: 0,
                    end: 100,
                },
                changed_data:{...rowData},
                // table_name:"collection_templates_temp",
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: 'billing_platform',
                ...metaData,
                billing_db_name: selectedBillingDb,
                sessionID: sessionId,
                main_module_name: 'Collections',
                feature_module_name: "Collection Steps",
            };

            const response = await axios.post(url, { data });
            console.log(response)
            parsedData = JSON.parse(response.data.body);
            console.log(parsedData)

            if (parsedData.flag === true) {
                setLoading(false);
                // Defer other state updates using a timeout to decouple them from the main thread
                setTimeout(() => {
                    const createModalData_ = parsedData?.header_map?.["Collection Steps"]?.pop_up || []
                    console.log("createModalData_", createModalData_)
                    setcreateModalData(createModalData_)
                    const generalFields_ = parsedData || {}
                    setGeneralFields2(generalFields_)
                    setHtmlContent(parsedData.changed_data.content_data)


                }, 0);

            } else {
                setLoading(false);
                console.log("flag set to false")
                Modal.error({
                    title: "Data Fetch Error",
                    content: parsedData.message || "An error occurred while fetching data. Please try again.",
                    centered: true,
                });
            }
        } catch (error) {
            setLoading(false);
            Modal.error({
                title: "Data Fetch Error",
                content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
                centered: true,
            });
        } finally {
            setLoading(false);
        }
    };
    const modalWidth = typeof window !== "undefined"
    ? window.innerWidth <= 768  // 768px is Tailwind's `md` breakpoint
      ? (window.innerWidth * 3.5) / 4
      : (window.innerWidth * 2.5) / 4
    : 0;
  const modalHeight =
    typeof window !== 'undefined' ? (window.innerHeight * 2.5) / 4 : 0;
    const showConfirmation = () => {
        const errors: { [key: string]: string } = {};

        createModalData.forEach((column) => {
            const value = formValues[column.db_column_name];

            // Mandatory field validation
            if (column.mandatory && column.db_column_name !== "day" && column.db_column_name !=="step_type" && column.db_column_name !== "email_alert") {
                if ((Array.isArray(value) && value.length === 0) || (!Array.isArray(value) && (value === undefined || value === null || value === ""))) {
                    errors[column.db_column_name] = `${column.display_name} is required.`;
                }
                
            }


            // Email validation
            if (column.db_column_name === "email") {
                const validateEmail = (email: string) => {
                    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
                    return emailRegex.test(email);
                };

                if (!validateEmail(value)) {
                    errors[column.db_column_name] = "Invalid email address";
                    return;
                }
            }

            // Account number validation (6-20 characters)
            if (column.db_column_name === "account_number") {
                if (value && (value.length < 6 || value.length > 20)) {
                    errors[column.db_column_name] = "Account number must be between 6 to 20 characters.";
                }
            }
        });

        // Set errors or open confirmation modal
        if (Object.keys(errors).length > 0) {
            setValidationErrors(errors);
            setIsConfirmationOpen(false);
        } else {
            setValidationErrors({});
            // setIsConfirmationOpen(true);
            handleConfirmCreate()
        }
    };
    function handleConfirmCreate(): void {

        setIsConfirmationOpen(false);
        SubmitData();
    }
    const SubmitData = async () => {
        setLoading(true);
        console.log("Submitting data...");
    
        // Combine form values and HTML content
        const combinedData = {
            ...formValues,                   // Include form values
            content_data: htmlContent || ""       // Include HTML content as "content" field
        };
    
        console.log("Combined Data:", combinedData);  // ✅ Log combined data
    
        // Check if the row being edited already exists
        let updatedTableData;
    
        if (formValues.id) {
            // If editing, find and update the existing row
            updatedTableData = tableData.map((row: any) =>
                row.id === formValues.id ? { ...row, ...combinedData } : row
            );
        } else {
            // If new, append it as a new row
            updatedTableData = [...tableData, combinedData];
        }
    
        console.log("Updated Table Data:", updatedTableData);
    
        // Filter mandatory fields dynamically
        const mandatoryFields = createModalData.filter((field) => field.mandatory === true);
    
        // Build the header map with db_column_name as key and display_name inside
        const newHeaderMap: Record<string, string[]> = {};
    
        mandatoryFields.forEach((field) => {
            const value = formValues[field.db_column_name] || "";
            newHeaderMap[field.db_column_name] = [field.display_name, value];
        });
    
        // Add HTML content to header map as "content"
        newHeaderMap["content"] = ["Content", htmlContent || ""];
    
        // Set the filtered headers, header map, and updated table data
        const headers = mandatoryFields
        .filter((field) => field.db_column_name.toLowerCase() !== "subject") // Exclude "subject"
        .map((field) => field.db_column_name);     
        setHeaders(headers);
        setHeaderMap(newHeaderMap);
        setTableData(updatedTableData);
    
        // Convert the final table data to JSON
        const jsonData = JSON.stringify(updatedTableData, null, 2);  // ✅ Save as JSON object
        console.log("Final JSON Data:", jsonData);
    
        setLoading(false);
        onClose();
    };
    
    const handleCancelConfirmation = () => {
        setIsConfirmationOpen(false);
    };
    const handleCancel = () => {
        setFormValues({});
        setIsModalOpen?.(false);
        onClose()

    };
    const handleInputChange = (name: any, value: any) => {
        setFormValues((prevState: any) => {
          const updatedFormData = {
            ...prevState,
            [name]: value,
          };
        //   console.log("formdata ", updatedFormData)
          return updatedFormData;
        });
    
        let errors = { ...validationErrors };
    
        // Email validation
        if (name === "email") {
          const validateEmail = (email: string) => {
            const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
            return emailRegex.test(email);
          };
          if (!validateEmail(value)) {
            errors[name] = "Invalid email address";
          } else {
            delete errors[name]; // Remove email error if valid
          }
        }
        // Account Number validation (between 6 to 20 characters and only numbers)
        if (name === "account_number") {
          // Check if the value is provided and its length is valid
          if (value && (value.length < 6 || value.length > 20)) {
            errors[name] = "Account number must be between 6 to 20 characters.";
          }
          // Check if the value contains only numbers
          else if (value && !/^[0-9]+$/.test(value)) {
            errors[name] = "Account number must contain only numbers (0-9).";
          }
          // If valid, remove any existing error
          else {
            delete errors[name];
          }
        }
        
    
        // Update validation errors
        setValidationErrors(errors);
      };
      const handleHtmlChange = (html: string) => {
        console.log("HTML Content from Child:", html);  // ✅ Console log the HTML
        setHtmlContent(html);  // Store it in state if needed
      };
  return (
    <>
    <Modal
          title="Edit Step Data"
          open={isModalOpen}
          onCancel={handleCancel}
          footer={<div className="flex justify-center space-x-2 pt-4">
              <button onClick={handleCancel} className="cancel-btn">
                  Cancel
              </button>
              <button onClick={showConfirmation} className="save-btn">
                  Save
              </button>
          </div>}
        centered
        width={createModalData.length > 6 ? modalWidth : '500px'}
        styles={{ body: { height: createModalData.length > 6 ? modalHeight : 'auto', padding: '4px' } }}
      >
        <div className='popup'>
          {loading ? (
              <div className="flex justify-center items-center w-full h-[300px]">
                  <Spin size="large" />
              </div>
          ) : (
              <div className="flex flex-col">
                          {createModalData
                              .filter((field) => field.db_column_name !== "step_type" && field.db_column_name !== "day")
                              .length > 0 && (
                                  <>
                                      <label className="text-md font-bold text-black-700 mb-2">
                                          Option for: {rowData.step_type}
                                      </label>

                                      <div className={`grid gap-4 w-full ${createModalData.length > 6
                                          ? "grid-cols-1 sm:grid-cols-2"
                                          : "grid-cols-1"
                                          }`}>                                          
                                          {createModalData
                                              .filter((field) => field.db_column_name !== "step_type" && field.db_column_name !== "day")
                                              .map((field) => (
                                                  <div key={field.id} className="mb-2">
                                                      {field.type !== "checkbox" && field.type !== "toggle" &&(
                                                            <div className="flex">
                                                                <label className="field-label">
                                                                    {field.display_name}{" "}
                                                                    {field.mandatory && <span className="text-red-500">*</span>}
                                                                </label>
                                                                {field.db_column_name === "grace_period" && (
                                                                    <Tooltip title="The time given after the due date for the customer to pay the amount" className="text-[11px]">
                                                                        <InformationCircleIcon
                                                                            className="h-5 w-5 text-blue-500 cursor-pointer ml-2"
                                                                        />
                                                                    </Tooltip>
                                                                )}
                                                            </div>
                                                        )}
                                                      {field.type === "text" && (
                                                        <>
                                                          <Input
                                                              type="text"
                                                              name={field.db_column_name}
                                                              className="input"
                                                              value={formValues[field.db_column_name] || ""}
                                                              onChange={(e) => handleInputChange(field.db_column_name, e.target.value)}
                                                              placeholder={`Enter ${field.display_name}`}
                                                          />
                                                          {validationErrors[field.db_column_name] && (
                                                            <span className="text-red-500">
                                                              {validationErrors[field.db_column_name]}
                                                                  </span>
                                                              )}</>
                                                      )}
                                                      {field.type === "toggle" && (
                                                           <div className="flex items-center">
                                                              <Switch
                                                                  checked={!!formValues[field.db_column_name]}
                                                                  onChange={(checked) =>
                                                                      handleInputChange(field.db_column_name, checked)
                                                                  }
                                                              />
                                                              <label className="field-label !ml-2">
                                                                  {field.display_name}{" "}

                                                              </label>
                                                              {/* {validationErrors[field.db_column_name] && (
                                                                  <span className="text-red-500">
                                                                      {validationErrors[field.db_column_name]}
                                                                  </span>
                                                              )} */}
                                                          </div>
                                                      )}

                                                      {field.type === "number" && (
                                                        <>
                                                          <Input
                                                              type="number"
                                                              name={field.db_column_name}
                                                              className="input"
                                                              value={formValues[field.db_column_name] ?? ""}
                                                              onChange={(e) => handleInputChange(field.db_column_name, e.target.value)}
                                                              placeholder={`Enter ${field.display_name}`}
                                                          />
                                                          {validationErrors[field.db_column_name] && (
                                                            <span className="text-red-500">
                                                              {validationErrors[field.db_column_name]}
                                                            </span>
                                                          )}</>
                                                      )}

                                                      {field.type === "dropdown" && (
                                                        <>
                                                          <Select
                                                              className="w-full"
                                                              styles={{
                                                                ...DropdownStyles,
                                                                menuPortal: (base) => ({ ...base, zIndex: 9999 }) // ✅ Ensures it appears above modals, etc.
                                                              }}                                                              
                                                              options={generalFields2?.dropdown?.[field.db_column_name]?.map((option: any) => ({
                                                                  label: option,
                                                                  value: option,
                                                              })) || []}
                                                              value={formValues[field.db_column_name]
                                                                  ? { label: formValues[field.db_column_name], value: formValues[field.db_column_name] }
                                                                  : null}
                                                              onChange={(value) => handleInputChange(field.db_column_name, value?.value || null)}
                                                              isClearable
                                                            //   menuPortalTarget={document.body}
                                                              menuPlacement="auto"
                                                              menuPosition="fixed"
                                                          />
                                                          {validationErrors[field.db_column_name] && (
                                                            <span className="text-red-500">
                                                              {validationErrors[field.db_column_name]}
                                                            </span>
                                                          )}</>
                                                      )}
                                                  </div>
                                              ))}
                                      </div>

                                      {rowData.step_type === "Email" && (
                                          <div className="mt-4 w-full">
                                              <RichTextEditor htmlContent={htmlContent} onHtmlChange={handleHtmlChange} />
                                          </div>
                                      )}
                                  </>
                              )}

                      </div>
                  )}
          </div>
      </Modal>
      <Modal
          title="Confirmation"
          open={isConfirmationOpen}
          onCancel={handleCancelConfirmation}
          centered
          footer={<div style={{ display: 'flex', justifyContent: 'center', width: '100%', gap: "6px" }}>
              <button
                  className="cancel-btn"
                  onClick={handleCancelConfirmation}
              >
                  Cancel
              </button>
              <button
                  className="save-btn"
                  onClick={handleConfirmCreate}
              >
                  OK
              </button>
          </div>}
      >
              <p>Are you sure you want to create this Collection Step</p>
          </Modal></>
  );
};

export default EditStepModal;
