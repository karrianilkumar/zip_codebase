"use client";

import React, {
  useEffect,
  useState,
  lazy,
  Suspense,
  useRef,
  useCallback,
} from "react";
import { ArrowDownTrayIcon, PlusIcon } from "@heroicons/react/24/outline";
import { Modal, Spin, DatePicker, notification, Button } from "antd";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import dayjs, { Dayjs } from "dayjs";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import * as XLSX from "xlsx";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import OptimizationTableComponent from "@/app/components/optimizationTableComponent/page";
import InventoryTableComponent from "@/app/components/inventoryTableComponent/page";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import KillbillTableComponent from "../killbill_components/table__component";
import CreateModal from "../killbill_components/createpopup";
import CreateCollectionsPopup from "../killbill_components/create_collectionsPopup";
import Select from "react-select";
import { DropdownStyles } from "@/app/components/css/dropdown";
import { metadata } from "@/app/metaData";
type ExportData = {
  path: string;
  username: string | null;
  module_name: string;
  request_received_at: string;
  start_date: string;
  end_date: string;
  Partner: string | null;
  access_token: string | null;
  db_name: string | null;
};

interface Section {
  title: string;
  fields: {
    id: number;
    display_name: string;
    type: string;
    mandatory: boolean;
    inline?: boolean;
    sideHeading?: string;
  }[];
}

const { RangePicker } = DatePicker;
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));
const WholeTableSearch = lazy(() => import("../killbill_components/whole__search"));
const AdvancedMultiFilter2 = lazy(
  () => import("../killbill_components/advanced__search")
);

const Collections: React.FC = () => {
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, token, selectedDb,metaData,selectedBillingDb, sessionId, settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId, firstLastName, setStoredPagination, setAdvancedStoredPagination, setCombineAdnvaceStoredpagination, combineAdnvaceStoredpagination } = useAuth();
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([
    null,
    null,
  ]);
  const [loading, setLoading] = useState(false);
  const { addExport, removeExport } = exportLoadingStore();
  const exportKey = "Inventory";
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [isCreateModalOpen, setCreateModalOpen] = useState(false);
  const [defaultTemplateModal, setDefaultTemplateModal] = useState(false);
  type TemplateOption = { value: string; label: string };
 const [selectedTemplate, setSelectedTemplate] = useState<{ label: string; value: string } | null>(null);
  const [generalFields, setgeneralFields] = useState<any[]>([]);
  const [createModalData, setcreateModalData] = useState<any[]>([]);
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
  const [templateOptions, setTemplateOptions] = useState<{ label: string; value: string }[]>([]);

  const hasFetchedData = useRef(false);
  const {
    iccid,
    bulkRow,
    features: moduleFeatures,
    setFeatures: setModuleFeatures,
    setICCID,
    setBulkRow
  } = useFeatureStore();

  type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);

  const fetchData = async () => {
    settabledata([]);
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    setSearchTerm("");
    setShowAdvanced(false)
    setCombineAdnvaceStoredpagination(null)

    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_COLLECTIONS;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";

      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/collections_list_view",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Collection Templates",
        mod_pages: {
          start: 0,
          end: 100,
        },
        table_name: "collection_templates",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        tenant_id: tenant_id_,
        db_name: 'billing_platform',
        ...metaData,
        billing_db_name: selectedBillingDb,
        main_module_name: 'Collections',
        sessionID: sessionId,
        feature_module_name: "Collection Templates",
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)

      if (parsedData.flag === true) {
        setLoading(false);
        setTimeout(() => {
          const headersMap_ = parsedData?.header_map?.["Collection Templates"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);

          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
          console.log("headers", headers_)
          setHeaders(headers_);
          setVisibleColumns(headers_);
          const generalFields_ = parsedData || {}
          setgeneralFields(generalFields_)
          console.log("generalFields_", generalFields_)
          setFeatures(parsedData?.header_map?.["Collection Templates"]?.module_features || []);
          setModuleFeatures(parsedData?.header_map?.["Collection Templates"]?.module_features || []);
          const featres_ = parsedData?.header_map?.["Collection Templates"]?.module_features || []
          const allowedActions_: any = []
          if (featres_.includes("Edit-Collection Templates")) {
            allowedActions_.push("editCollection")
          }
          if (featres_.includes("Delete-Collection Templates")) {
            allowedActions_.push("delete")
          }

          setAllowedActions(allowedActions_)
          const createModalData_ = parsedData?.header_map?.["Collection Templates"]?.pop_up || []
          console.log("createModalData_", createModalData_)
          setcreateModalData(createModalData_)
          setPagination(parsedData?.pages || {});
          setTableData(parsedData?.data?.collection_templates || []);
        }, 0);

      } else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleCreateModalOpen = () => {
    setCreateModalOpen(true);
  };

  const handleCreateModalClose = () => {
    setCreateModalOpen(false);
    fetchData()
  };

  const handleCreateRow = (newRow: any) => {
    console.log("New Row Data:", newRow);
    handleCreateModalClose();
  };
  
  useEffect(() => {
    if (!hasFetchedData.current) {
      fetchData();
      hasFetchedData.current = true;
    }
  }, [fetchData]);

  const exportToExcel = (headers: any, rowData: any, fileName = 'exported_data.xlsx') => {
    const formattedData = rowData.map((row: any) => {
      const formattedRow: any = {};
      headers.forEach((header: any) => {
        formattedRow[header] = row[header] !== undefined ? row[header] : null;
      });
      return formattedRow;
    });

    const worksheet = XLSX.utils.json_to_sheet(formattedData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');
    XLSX.writeFile(workbook, fileName);
  };

  const handleFilter = useCallback((advancedFilters: any) => {
    console.log(advancedFilters);
    setAdvancedFilters(advancedFilters)
  }, []);

  const handleReset = useCallback((EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  }, []);

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "normal",
    padding: "16px",
  };

  const handleExportModalOpen = () => {
    setExportModalOpen(true);
  };

  const handleExportModalClose = () => {
    setExportModalOpen(false);
    console.log("Modal closed, resetting date range.");
  };

  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }

  const ExportWithoutSearch = async () => {
    try {
      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Request timed out"));
          }, timeout);

          promise
            .then((res) => {
              clearTimeout(timer);
              resolve(res);
            })
            .catch((err) => {
              clearTimeout(timer);
              reject(err);
            });
        });
      };

      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/export_to_s3_bucket",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Collection Templates",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        billing_db_name: selectedBillingDb,
        killbill_flag: "True",
        sessionID: sessionId,
        main_module_name: 'Collections',
        feature_module_name: "Collection Templates",
        start_date: getFirstDayOfCurrentMonth(),
        end_date: getLastDayOfCurrentMonth(),
      };

      try {
        await callWithTimeout(axios.post(url, { data }), 10000);
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }

      await new Promise((resolve) => setTimeout(resolve, 20000));

      const export_url = ENV_ROUTES.MODULE_MANAGEMENT;
      const export_data = {
        ...data,
        path: "/get_export_status",
      };

      const pollExportStatus = async () => {
        try {
          const export_response = await axios.post(export_url, { data: export_data });
          const export_parsedData = JSON.parse(export_response.data.body);

          if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
            const s3Url = export_parsedData?.export_status_data?.url || null;
            if (s3Url) {
              fetch(s3Url)
                .then(response => response.blob())
                .then(blob => {
                  const url = window.URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = 'Collection Templates.xlsx';
                  a.click();
                  a.remove();
                  window.URL.revokeObjectURL(url);
                  notification.success({
                    message: "Success",
                    description: "Successfully exported the record!",
                    style: messageStyle,
                    placement: "top",
                  });
                })
                .catch((err) => {
                  console.log("error", err)
                  Modal.error({
                    title: "Export Error",
                    content: "An error occurred while exporting data. Please try again.",
                    centered: true,
                  });
                });
            } else {
              Modal.error({
                title: "Export Error",
                content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            }
            return true;
          }

          if (export_parsedData?.export_status_data?.status_flag === "Failure") {
            Modal.error({
              title: "Export Error",
              content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
              centered: true,
            });
            return true;
          }
          if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
            Modal.error({
              title: "Export Error",
              content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
              centered: true,
            });
            return true;
          }
          return false;
        } catch (error) {
          Modal.error({
            title: "Export Error",
            content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
            centered: true,
          });
          return true;
        }
      };

      const startPolling = async () => {
        let isPollingComplete = false;

        while (!isPollingComplete) {
          isPollingComplete = await pollExportStatus();
          if (!isPollingComplete) {
            await new Promise((resolve) => setTimeout(resolve, 5000));
          }
        }
      };

      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    }
  };

  const handleExport = async (key: string, heading: string) => {
    try {
      addExport(key, heading);

      let parsedData;
      let url;
      let data: any;
      let response;

      if (combineAdnvaceStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedBillingDb,
          sessionID: sessionId,
          index_name: "Collection Templates",
          module_name: "Collection Templates",
          col_sort: { id: "ASC" }
        };
        console.log("combineAdnvaceStoredpagination", data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
      else if (advancedStoredpagination && !storedpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name: "Collection Templates",
          module_name: "Collection Templates",
          pages: { start: 0, end: 100 },
          partner,
          username: username,
          db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
          col_sort: { id: "ASC" },
        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
      else if (storedpagination && !advancedStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "Collection Templates",
          module_name: "Collection Templates",
          search: "whole",
          pages: { start: 0, end: 100 },
          partner,
          username: username,
          db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
          col_sort: { id: "ASC" }
        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } else {
        await ExportWithoutSearch();
        return;
      }

      if (parsedData.flag) {
        const s3Url = parsedData?.download_url || null;
        if (s3Url) {
          fetch(s3Url)
            .then(response => response.blob())
            .then(blob => {
              const url = window.URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'Collection Templates.xlsx';
              a.click();
              a.remove();
              window.URL.revokeObjectURL(url);
              notification.success({
                message: "Success",
                description: "Successfully exported the record!",
                style: messageStyle,
                placement: "top",
              });
            })
            .catch((err) => {
              console.log("error", err)
              Modal.error({
                title: "Export Error",
                content: "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            });
        } else {
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      } else {
        Modal.error({
          title: "Export Error",
          content: parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      removeExport(key);
    }
  };
  const handleDefaultTemplate = () => {
    setDefaultTemplateModal(true);
    fetchTemplatesData("fetch");
  }
const fetchTemplatesData = async (action:string) => {
  // setDefaultTemplateModal(false)
   let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_COLLECTIONS;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";

      const data:any = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/fetch_default_templates",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Collection Templates",
        mod_pages: {
          start: 0,
          end: 100,
        },
        flag:action,
        table_name: "collection_templates",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        tenant_id: tenant_id_,
        db_name: 'billing_platform',
        ...metadata,
        billing_db_name: selectedBillingDb,
        main_module_name: 'Collections',
        sessionID: sessionId,
        feature_module_name: "Collection Templates",
      };
      if (action === "save") {
        data.selected_template = selectedTemplate?.value || "";
      }

      const response = await axios.post(url, { data });
      // console.log(response)
      parsedData = JSON.parse(response.data.body);
      // console.log(parsedData)

      if (parsedData.flag === true && action === "fetch") {
        setLoading(false);

        const mappedOptions = (parsedData?.templates || []).map((item: any) => ({
          label: item,
          value: item
        }));

        setTemplateOptions(mappedOptions);

        const selectedOption =
          mappedOptions.find(
            (opt:any) => opt.value === parsedData?.selected_template
          ) || null;

        setSelectedTemplate(selectedOption); // keep it as object, not string
      }
      else if( parsedData.flag === true && action === "save") {
        setLoading(false);
        setDefaultTemplateModal(false);
        notification.success({
          message: "Success",
          description: "Default template saved successfully!",
          style: messageStyle,
          placement: "top",
        });
      }
      else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
}

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }
  
  return (
    <>
      {/* <Suspense
        fallback={
          <div className="flex justify-center items-center h-screen">
            <Spin size="large" />
          </div>
        }
      > */}
        <div className="relative">
          <div className="p-4 flex md:flex-row md:items-center md:justify-between space-y-6 md:space-y-0">
          <div className="flex space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last">
              {features.includes("Search-Collection Templates") && (
                <WholeTableSearch
                  searchTerm={searchTerm}
                  setSearchTerm={setSearchTerm}
                  tableName={"Collection Templates"}
                  headerMap={headerMap}
                />
              )}
              {features.includes("Advanced-Collection Templates") && (
                <AdvancedMultiFilter2
                  showAdvanced={showAdvanced}
                  setShowAdvanced={setShowAdvanced}
                  onFilter={handleFilter}
                  onReset={handleReset}
                  headers={headers}
                  headerMap={headerMap}
                  tableName={"Collection Templates"}
                />
              )}
            </div>

            {/* Export and ColumnFilter Container - Hidden on small screens */}
            <div className="hidden md:flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2 md:order-none order-first ml-1">
              {features.includes("Default Template-Collection Templates") && (
                <button className="save-btn" onClick={handleDefaultTemplate}>
                  Default Template
                </button>
              )}
              <Modal
                title="Select Default Template"
                open={defaultTemplateModal}
                onCancel={() => setDefaultTemplateModal(false)}
                centered
                footer={[
                  <div key="footer-buttons" className="flex justify-center space-x-2">
                    <button
                      onClick={() => setDefaultTemplateModal(false)}
                      className="cancel-btn"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={() => fetchTemplatesData("save")}
                      className="save-btn"
                    // disabled={!selectedTemplate}
                    >
                      Save
                    </button>
                  </div>,
                ]}
              >
                <div className="relative w-full min-h-[70px]">
                  {loading ? (
                    <div className="flex justify-center items-center absolute inset-0 bg-white bg-opacity-80 z-10">
                      <Spin size="large" />
                    </div>
                  ) : (
                    <Select
                      className="w-full"
                      styles={DropdownStyles}
                      value={selectedTemplate} 
                      options={templateOptions}
                      onChange={(option) =>
                        setSelectedTemplate(option as TemplateOption | null)
                      }
                      placeholder="Choose a template"
                    />
                  )}
                </div>
              </Modal>

              {features.includes("Export-Collection Templates") && (
                <button className="save-btn" onClick={handleCreateModalOpen}>
                  <PlusIcon className="h-5 w-5 text-black-500 mr-1" />
                  {showAdvanced ?"Add" : "Add Collection"}
                </button>
              )}

              {features.includes("Export-Collection Templates") && (
                <button className="save-btn" style={{ minWidth: showAdvanced ? "40px" : "auto" }}
                onClick={() => handleExport("Collections", "Collections")}>
                  <ArrowDownTrayIcon className="h-5 w-5 text-black-500" />
                {!showAdvanced && <span className="ml-2">Export</span>}               
                </button>
              )}
              <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
                popupHeading="Collection Template"
              />
            </div>
          </div>

          {/* Sticky Footer for Small Screens */}
          <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
            {features.includes("Export-Collection Templates") && (
              <button className="save-btn" onClick={handleCreateModalOpen}>
                <PlusIcon className="h-5 w-5 text-black-500 mr-1" />
              </button>
            )}
            {features.includes("Export-Collection Templates") && (
              <button className="save-btn" onClick={() => handleExport("Collections", "Collections")}>
                <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
              </button>
            )}
            <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
              popupHeading="Collection Template"
            />
          </div>

          {isCreateModalOpen && (
            <div className="absolute inset-0 flex justify-center items-center z-50">
              <div className="bg-white p-2 w-full h-full">
                <CreateCollectionsPopup
                  isOpen={isCreateModalOpen}
                  onClose={handleCreateModalClose}
                  onSave={handleCreateRow}
                  modalData={createModalData}
                  title="Collection Template"
                  action="Create"
                  generalFields={generalFields}
                />
              </div>
            </div>
          )}

          {/* Table Component */}
          <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
            <KillbillTableComponent
              headers={headers}
              headerMap={headerMap}
              initialData={tableData}
              searchQuery={searchTerm}
              visibleColumns={visibleColumns}
              itemsPerPage={100}
              allowedActions={allowedActions}
              popupHeading="Collections"
              pagination={pagination}
              advancedFilters={filteredData}
              createModalData={createModalData}
              generalFields={generalFields}
              height={showAdvanced ? 278 : 210}
            />
          </div>
        </div>
      {/* </Suspense> */}
    </>
  );
};

export default Collections;
