"use client";

import React, { useEffect, useState, lazy, Suspense } from "react";
import { useSidebarStore } from "@/app/stores/navBarStore";
import { useLogoStore } from "@/app/stores/logoStore";
import { Spin } from "antd";

// const BillCreation = lazy(() => import("./billing/bill_creation/page"));
// const BillProfiles = lazy(() => import("./billing/bill_profiles/page"));




const BillingAndPayments: React.FC = () => {
  const title = useLogoStore((state) => state.title);
  const setTitle = useLogoStore((state) => state.setTitle);
  const [activeTab, setActiveTab] = useState("billcreation");
  const isExpanded = useSidebarStore((state: any) => state.isExpanded);
  const [loading, setLoading] = useState(false);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }
  return (
    <Suspense
      fallback={
        <div className="flex justify-center items-center h-screen">
          <Spin size="large" />
        </div>
      }
    >
      {/* <div className="">
        <div
          className={`bg-white shadow-md mb-4 gap-4  tabs ${
            isExpanded ? "left-[17%]" : "left-[112px]"
          }`}
        >
         
          <button
            className={`tab-headings ${
              activeTab === "billcreation" ? "active-tab-heading" : ""
            }`}
            onClick={() => setActiveTab("billcreation")}
          >
            Bill creation
          </button>
          <button
            className={`tab-headings ${
              activeTab === "billprofiles" ? "active-tab-heading" : ""
            }`}
            onClick={() => setActiveTab("billprofiles")}
          >
            Bill creation
          </button>
        </div>
        <div className="h-[calc(100vh-150px)] pt-[70px]">
          {activeTab === "billcreation" && <BillCreation />}
          {activeTab === "billprofiles" && <BillProfiles />}
           

        </div>
      </div> */}
    </Suspense>
  );
};

export default BillingAndPayments;
