import { create } from "zustand";
interface ServiceDropdownValues {
  service_type: string[];
  provider: string[];
  product: string[];
  customer_names: string[];
  service_locations: string[];
  terms: string[];
}
interface AccountState {
  batchId: string | null;
  setBatchId: (batchId: string) => void;
  accountNumber: string | null;
  setAccountNumber: (accountNumber: string) => void;
  BillId: string | null;
  setBillId: (BillId: string) => void;
  serviceDropdownValues: ServiceDropdownValues | null; 
  setServiceDropdownValues: (dropdownValues: ServiceDropdownValues) => void;
  userProfileDetails: Record<string, number>;
  setUserProfileDetails: (userProfileDetails: Record<string, number>) => void;
  summaryExportData: Record<string, number>;
  setSummaryExportData: (summaryExportData: Record<string, number>) => void;
  showNewPage: boolean;
  setShowNewPage: (value: boolean) => void;
  isCustomerProfilesNav: boolean;
  setIsCustomerProfilesNav: (value: boolean) => void;
  isSinglePaymentModalOpen: boolean;
  setSinglePaymentModalOpen: (value: boolean) => void;
  isMultiPaymentModalOpen: boolean;
  setMultiPaymentModalOpen: (value: boolean) => void;
  BillingAndCollectionsActiveTab: string;
  setBillingAndCollectionsActiveTab: (BillingAndCollectionsActiveTab: string) => void;
}

export const useCustomerProfileStore = create<AccountState>((set) => ({
  batchId: null,
  setBatchId: (batchId) => set({ batchId }),
  accountNumber: null,
  setAccountNumber: (accountNumber) => set({ accountNumber }),
  BillId: null,
  setBillId: (BillId) => set({ BillId }),
  serviceDropdownValues: null,
  setServiceDropdownValues: (serviceDropdownValues) => set({ serviceDropdownValues }),
  userProfileDetails: {}, 
  setUserProfileDetails: (userProfileDetails) => set({ userProfileDetails }),
  summaryExportData: {}, 
  setSummaryExportData: (summaryExportData) => set({ summaryExportData }),
  isCustomerProfilesNav: false,
  setIsCustomerProfilesNav: (value) => set({ isCustomerProfilesNav: value }),
  showNewPage: false,
  setShowNewPage: (value) => set({ showNewPage: value }),
  isSinglePaymentModalOpen: false,
  setSinglePaymentModalOpen: (value) => set({isSinglePaymentModalOpen: value}),
  isMultiPaymentModalOpen: false,
  setMultiPaymentModalOpen: (value) => set({isMultiPaymentModalOpen: value}),
  BillingAndCollectionsActiveTab: "bills",
  setBillingAndCollectionsActiveTab : (value) => set({BillingAndCollectionsActiveTab: value})
}));