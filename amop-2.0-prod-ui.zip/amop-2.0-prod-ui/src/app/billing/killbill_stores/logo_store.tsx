// killbill_stores/logo_store.tsx
import { create } from 'zustand';

interface KillbillLogoState {
  logoUrl: string | null;
  title: string;
  setLogoUrl: (url: string) => void;
  setTitle: (title: string) => void;
}

export const useLogoStore = create<KillbillLogoState>((set) => ({
  logoUrl: null,
  title: '',
  setLogoUrl: (url: string) => set({ logoUrl: url }),
  setTitle: (title: string) => set({ title }),
}));
