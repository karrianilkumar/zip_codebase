// store/sidebarStore.ts
import { create } from 'zustand';

interface KillbillSidebarState {
  isExpanded: boolean;
  toggleSidebar: () => void;
}

export const useSidebarStore = create<KillbillSidebarState>((set) => ({
  isExpanded: true,
  toggleSidebar: () =>
    set((state) => ({
      isExpanded: !state.isExpanded,
    })),
}));
