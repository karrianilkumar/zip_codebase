// templateStore.ts
import create from 'zustand';

interface TemplateStore {
  templateData: any[];
  setTemplateData: (data: any[]) => void;
}

export const useTemplateStore = create<TemplateStore>((set) => ({
  templateData: [],
  setTemplateData: (data) => set({ templateData: data }),
}));