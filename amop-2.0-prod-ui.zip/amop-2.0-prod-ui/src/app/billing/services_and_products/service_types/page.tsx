/* eslint-disable react-hooks/exhaustive-deps */
"use client";

import React, {
  useEffect,
  useState,
  lazy,
  Suspense,
  useRef,
  useCallback,
} from "react";
import { ArrowDownTrayIcon, ArrowUpTrayIcon, PlusIcon } from "@heroicons/react/24/outline";
import { Modal, Spin, DatePicker, notification, Switch, Upload, message } from "antd";
import { useAuth } from "../../../components/auth_context";
import axios from "axios";
// import { getCurrentDateTime } from "@/app/components/header_constants";
import { getCurrentDateTime } from "../../../components/header_constants";
import dayjs, { Dayjs } from "dayjs";
import { useFeatureStore } from "../../../sim_management/inventory/featureStore";
import * as XLSX from "xlsx";
// import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { ENV_ROUTES } from "../../../components/routes/route_constants";
import { exportLoadingStore } from "../../../stores/ExportLoadingStore";
import CreateModal from "../../killbill_components/createpopup";
import { useKillBillStore } from "../../killbill_stores/activeStore";
import { Line } from "recharts";
import { DownloadOutlined, UploadOutlined } from "@ant-design/icons";
type ExportData = {
  path: string;
  username: string | null;
  module_name: string;
  request_received_at: string;
  start_date: string;
  end_date: string;
  Partner: string | null;
  access_token: string | null;
  db_name: string | null;
};
const KillbillTableComponent = lazy(
  () => import("../../killbill_components/table__component")
);
// const CreateModal = lazy(() => import("@/app/components/createPopup"));
const ColumnFilter = lazy(() => import("../../../components/columnfilter"));
const WholeTableSearch = lazy(() => import("../../killbill_components/whole__search"));
const AdvancedMultiFilter2 = lazy(
  () => import("../../killbill_components/advanced__search")
);

const ServicesPage: React.FC = () => {
  const tenant_id_ = localStorage.getItem("tenant_id") || "0";
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  // const selectedDb = "billing_platform"
  const { username, partner, role, token, sessionId, selectedDb,metaData,selectedBillingDb, settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId, firstLastName, setStoredPagination, setAdvancedStoredPagination, setCombineAdnvaceStoredpagination, combineAdnvaceStoredpagination } = useAuth();
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([
    null,
    null,
  ]);
  const [loading, setLoading] = useState(false);
  // const [exportLoading, setExportLoading] = useState(false);
  const { addExport, removeExport } = exportLoadingStore();
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [isCreateModalOpen, setCreateModalOpen] = useState(false);
  const [createModalData, setcreateModalData] = useState<any[]>([]);
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
  const [generalFields, setgeneralFields] = useState<any[]>([])
  const [showActive, setShowActive] = useState(true);
  const { serviceShowActive, setServiceShowActive } = useKillBillStore();

  const [isReUploadModalVisible, setIsReUploadModalVisible] = useState(false);
  const [isUploadModalVisible, setIsUploadModalVisible] = useState(false);
  const [uploadKey, setUploadKey] = useState(Date.now());
  const [isFileSelected, setIsFileSelected] = useState(false);
  const [isSmallScreen, setIsSmallScreen] = useState(false);
  const hasFetchedData = useRef(false);
  const {
    iccid,
    bulkRow,
    features: moduleFeatures,
    setFeatures: setModuleFeatures,
    setICCID,
    setBulkRow
  } = useFeatureStore();
  // const queryClient = useQueryClient();

  type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);

  useEffect(() => {
    const checkScreenSize = () => {
      setIsSmallScreen(window.innerWidth < 700);
    };

    // Initial check
    checkScreenSize();

    // Add event listener for window resize
    window.addEventListener('resize', checkScreenSize);

    // Clean up
    return () => window.removeEventListener('resize', checkScreenSize);
  }, []);

  const fetchData = async () => {
    setBulkRow(null)
    setICCID("");
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    setSearchTerm("");
    setShowAdvanced(false)
    setCombineAdnvaceStoredpagination(null)
    settabledata([]);
    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_SERVICES_PRODUCTS;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";

      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/services_list_view",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Billing Services",
        sub_module: "Services",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
                  ...metaData,
          billing_db_name: selectedBillingDb,
        tenant_id: tenant_id_,
        sessionID: sessionId,
        feature_module_name: "Billing Services",
        main_module_name: "Service Types",
        status: showActive ? "true" : "false"
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)

      if (parsedData.flag === true) {
        setLoading(false);
        // Defer other state updates using a timeout to decouple them from the main thread
        setTimeout(() => {
          const headersMap_ = parsedData?.header_map?.["Billing Services"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);


          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
          console.log("headers", headers_)
          setHeaders(headers_);
          setVisibleColumns(headers_);
          const generalFields_ = parsedData || {}
          setgeneralFields(generalFields_)
          console.log("generalFields_", generalFields_)
          setFeatures(parsedData?.header_map?.["Billing Services"]?.module_features || []);
          setModuleFeatures(parsedData?.header_map?.["Billing Services"]?.module_features || []);
          const featres_ = parsedData?.header_map?.["Billing Services"]?.module_features || []
          const allowedActions_: any = []
          if (featres_.includes("Edit-Billing Services")) {
            allowedActions_.push("edit")
          }
          // if(featres_.includes("Delete-Billing Services")){
          //   allowedActions_.push("delete")
          // }
          if (featres_.includes("Copy-Billing Services")) {
            allowedActions_.push("copy")
          }
          if (featres_.includes("Discontinue-Billing Services")) {
            allowedActions_.push("deactivate")

          }

          setAllowedActions(allowedActions_)
          const createModalData_ = parsedData?.header_map?.["Billing Services"]?.pop_up || []
          console.log("createModalData_", createModalData_)
          setcreateModalData(createModalData_)
          setPagination(parsedData?.pages || {});
          setTableData(parsedData?.data?.billing_services || []);


        }, 0);

      } else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
  const handleCreateModalOpen = () => {
    setCreateModalOpen(true);
  };

  const handleCreateModalClose = () => {
    setCreateModalOpen(false);
  };

  const handleCreateRow = () => {
    handleCreateModalClose();
  };
  // useEffect(() => {
  //   if (!hasFetchedData.current) {
  //     fetchData();
  //     hasFetchedData.current = true;
  //   }
  // }, [fetchData]);

  const exportToExcel = (headers: any, rowData: any, fileName = 'exported_data.xlsx') => {
    // Map the rowData to an array of objects with headers as keys
    const formattedData = rowData.map((row: any) => {
      const formattedRow: any = {};
      headers.forEach((header: any) => {
        formattedRow[header] = row[header] !== undefined ? row[header] : null;
      });
      return formattedRow;
    });

    // Create a new worksheet from the formatted data
    const worksheet = XLSX.utils.json_to_sheet(formattedData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');

    // Write the workbook and trigger download
    XLSX.writeFile(workbook, fileName);
  };

  const handleFilter = useCallback((advancedFilters: any) => {
    console.log(advancedFilters);
    setAdvancedFilters(advancedFilters)
  }, []);

  const handleReset = useCallback((EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  }, []);

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "normal",
    padding: "16px",
  };

  const handleExportModalOpen = () => {
    setExportModalOpen(true);
  };

  const handleExportModalClose = () => {
    setExportModalOpen(false);
    console.log("Modal closed, resetting date range.");
  };

  useEffect(() => {
    fetchData();
    console.log("If show active is false", showActive)
    setServiceShowActive(showActive)
  }, [partner, showActive]);

  const handleSwitchChange = (checked: any) => {
    setShowActive(checked)
  };

  // const handleExport = async () => {
  //   if (!dateRange || dateRange[0] === null || dateRange[1] === null) {
  //     Modal.error({ title: "Error", content: "Please select a date range." });
  //     return;
  //   }

  //   const [startDate, endDate] = dateRange;
  //   const exportData: ExportData = {
  //     path: "/export",
  //     username: username,
  //     module_name: "SimManagement Inventory",
  //     request_received_at: getCurrentDateTime(),
  //     start_date: startDate.format("YYYY-MM-DD 00:00:00"),
  //     end_date: endDate.format("YYYY-MM-DD 23:59:59"),
  //     Partner: partner,
  //     access_token: token,
  //     db_name: selectedDb,
  //   };

  //   try {
  //     const url = ENV_ROUTES.MODULE_MANAGEMENT;
  //     const response = await axios.post(url, { data: exportData }, {
  //       headers: {
  //         "Content-Type": "application/json",
  //       },
  //     });
  //     const data = JSON.parse(response.data.body);

  //     if (data.flag === true) {
  //       notification.success({
  //         message: "Success",
  //         description: "Successfully exported the record!",
  //         placement: "top",
  //       });
  //       downloadBlob(data.blob);
  //     } else {
  //       Modal.error({
  //         title: "Export Error",
  //         content: data.message,
  //         centered: true,
  //       });
  //     }
  //     handleExportModalClose();
  //   } catch (error) {
  //     console.error("Error downloading the file:", error);
  //     Modal.error({
  //       title: "Export Error",
  //       content: "An error occurred while exporting the file. Please try again.",
  //     });
  //   }
  // };

  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }

  const ExportWithoutSearch = async () => {

    try {
      // Add the export to the store
      // addExport(exportKey, "Inventory");

      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Request timed out"));
          }, timeout);

          promise
            .then((res) => {
              clearTimeout(timer);
              resolve(res);
            })
            .catch((err) => {
              clearTimeout(timer);
              reject(err);
            });
        });
      };

      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/export_to_s3_bucket",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: showActive ? "Active Billing Services" : "Billing Services",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
          ...metaData,
          billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        feature_module_name: "Billing Services",
        start_date: getFirstDayOfCurrentMonth(),
        end_date: getLastDayOfCurrentMonth(),
        killbill_flag: "True"
      };

      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000);
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }

      // Wait for 20 seconds before polling
      await new Promise((resolve) => setTimeout(resolve, 20000));

      const export_url = ENV_ROUTES.MODULE_MANAGEMENT;
      const export_data = {
        ...data,
        path: "/get_export_status",
        module_name: showActive ? "Active Billing Services" : "Billing Services",
      };

      const pollExportStatus = async () => {
        try {
          const export_response = await axios.post(export_url, { data: export_data });
          const export_parsedData = JSON.parse(export_response.data.body);

          if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
            const s3Url = export_parsedData?.export_status_data?.url || null;
            if (s3Url) {
              // window.location.href = s3Url;
              // notification.success({
              //   message: "Success",
              //   description: "Successfully exported the  record!",
              //   style: messageStyle,
              //   placement: "top",
              // });
              fetch(s3Url)
                .then(response => response.blob())
                .then(blob => {
                  const url = window.URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = showActive ? "Active Billing Services.xlsx" : "Billing Services.xlsx";
                  a.click();
                  a.remove();
                  window.URL.revokeObjectURL(url);
                  notification.success({
                    message: "Success",
                    description: "Successfully exported the record!",
                    style: messageStyle,
                    placement: "top",
                  });
                })
                .catch((err) => {
                  console.log("error", err)
                  Modal.error({
                    title: "Export Error",
                    content: "An error occurred while exporting data. Please try again.",
                    centered: true,
                  });
                });
            } else {
              Modal.error({
                title: "Export Error",
                content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            }
            return true; // Stop polling
          }

          if (export_parsedData?.export_status_data?.status_flag === "Failure") {
            Modal.error({
              title: "Export Error",
              content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
              centered: true,
            });
            return true; // Stop polling
          }
          if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
            Modal.error({
              title: "Export Error",
              content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
              centered: true,
            });
            return true; // Stop polling
          }

          return false; // Continue polling
        } catch (error) {
          Modal.error({
            title: "Export Error",
            content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
            centered: true,
          });
          return true; // Stop polling
        }
      };
      const startPolling = async () => {
        console.log
        let isPollingComplete = false;

        while (!isPollingComplete) {
          isPollingComplete = await pollExportStatus();
          if (!isPollingComplete) {
            await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
          }
        }
      };

      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      // removeExport(exportKey); // Remove the export from the store
    }
  };



  const handleExport = async (key: string, heading: string) => {

    try {
      addExport(key, heading);

      let parsedData;
      let url;
      let data: any;
      let response;

      if (combineAdnvaceStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedBillingDb,
          ...metaData,
          // billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          index_name: "Billing Service",
          module_name: "Billing Services",
          toggle: showActive ? true : false,
          col_sort: { description: "ASC" },
          tenant_database: selectedDb

        };
        console.log("combineAdnvaceStoredpagination", data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
      else if (advancedStoredpagination && !storedpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name: "Billing Service",
          module_name: "Billing Services",
          pages: { start: 0, end: 100 },
          partner,
          db_name: selectedBillingDb,
          ...metaData,
          // billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
          toggle: showActive ? true : false,
          col_sort: { description: "ASC" },
          username: username,
          tenant_database: selectedDb

        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
      else if (storedpagination && !advancedStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "Billing Service",
          module_name: "Billing Services",
          search: "whole",
          pages: { start: 0, end: 100 },
          partner,
          db_name: selectedBillingDb,
          ...metaData,
          // billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
          toggle: showActive ? true : false,
          col_sort: { description: "ASC" },
          username: username,
          tenant_database: selectedDb
        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } else {
        await ExportWithoutSearch();
        return;
      }

      if (parsedData.flag) {
        const s3Url = parsedData?.download_url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the  record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
            .then(response => response.blob())
            .then(blob => {
              const url = window.URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = showActive ? "Active Billing Services.xlsx" : "Billing Services.xlsx";
              a.click();
              a.remove();
              window.URL.revokeObjectURL(url);
              notification.success({
                message: "Success",
                description: "Successfully exported the record!",
                style: messageStyle,
                placement: "top",
              });
            })
            .catch((err) => {
              console.log("error", err)
              Modal.error({
                title: "Export Error",
                content: "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            });
        } else {
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      } else {
        Modal.error({
          title: "Export Error",
          content: parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      removeExport(key);
    }
  };
  const handleReUploadClick = () => {
    setIsReUploadModalVisible(true);

  }
  const handleUploadClick = () => {
    setIsUploadModalVisible(true)
  }
   const handleUploadChange = (info: any) => {
    if (info.file.status === 'done') {
      setIsFileSelected(true);
      let blob;
      const file = info.file.originFileObj; // Get the file object
      const reader = new FileReader();
      reader.onload = (e: any) => {
        // Get the file data URL (Base64 string)
        blob = e.target.result;
        console.log('File Base64 String:', blob);
        handleUpload(blob)
        setUploadKey(Date.now());
      };

      if (blob) {
      }

      reader.readAsDataURL(file); // Read the file as data URL
    } else if (info.file.status === 'error') {
      // Handle upload error
      message.error('Upload failed.');
    }
    else if (info.file.status === 'removed') {
      setIsFileSelected(false);

    }
  };
  const handleReUploadChange = (info: any) => {
    if (info.file.status === 'done') {
      setIsFileSelected(true);
      let blob;
      const file = info.file.originFileObj; // Get the file object
      const reader = new FileReader();
      reader.onload = (e: any) => {
        // Get the file data URL (Base64 string)
        blob = e.target.result;
        console.log('File Base64 String:', blob);
        handleReUpload(blob)
        setUploadKey(Date.now());
      };

      if (blob) {
      }

      reader.readAsDataURL(file); // Read the file as data URL
    } else if (info.file.status === 'error') {
      // Handle upload error
      message.error('Upload failed.');
    }
    else if (info.file.status === 'removed') {
      setIsFileSelected(false);

    }
  };
  const reUploadProps = {
    key: uploadKey,
    accept: '.xlsx, .xls',
    beforeUpload: (file: any) => {
      // Check if file is an Excel file
      const isExcel = file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || file.type === 'application/vnd.ms-excel';
      if (!isExcel) {
        message.error('You can only upload Excel files!');
      }
      return isExcel;
    },
    onChange: handleReUploadChange,
  };
   const UploadProps = {
    key: uploadKey,
    accept: '.xlsx, .xls',
    beforeUpload: (file: any) => {
      // Check if file is an Excel file
      const isExcel = file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || file.type === 'application/vnd.ms-excel';
      if (!isExcel) {
        message.error('You can only upload Excel files!');
      }
      return isExcel;
    },
    onChange: handleUploadChange,
  };

  const handleReUpload = async (blob: string) => {
    setIsReUploadModalVisible(false);
    setLoading(true)
    try {
      const url = ENV_ROUTES.BP_SERVICES_PRODUCTS;

      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/reupload_service_types",
        table_name: "services",
        insert_flag: "append",
        module_name: "Billing Services",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
                  ...metaData,
          billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        blob: blob,
        main_module_name: "Billing Services",
      };

      const response = await axios.post(url, { data });

      const resp = JSON.parse(response.data.body);
      if (response.data.statusCode === 200) {
        if (resp.flag === true) {
          await fetchData()
          notification.success({
            message: 'Success',
            description: 'Successfully uploaded the record!',
            placement: 'top',
          });
          // setIsReUploadModalVisible(false);
        } else {
          Modal.error({
            title: 'Import Error',
            content: resp.message,
            centered: true,
            onOk: handleErrorModalClose,
            onCancel: handleErrorModalClose
          });
        }
      } else {
        Modal.error({
          title: 'Import Error',
          content: resp.message,
          centered: true,
          onOk: handleErrorModalClose,
          onCancel: handleErrorModalClose
        });
      }
    } catch (error) {
      console.error('Error during file upload:', error);
      Modal.error({
        title: 'Import Error',
        content: 'There was an error uploading the file.',
        centered: true,
        onOk: handleErrorModalClose,
        onCancel: handleErrorModalClose
      });

    }
    finally {
      setLoading(false)
      setIsReUploadModalVisible(false);
    }
  }
   const handleUpload = async (blob: string) => {
    setIsUploadModalVisible(false);
    setLoading(true)
    try {
      const url = ENV_ROUTES.BP_SERVICES_PRODUCTS;

      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/bulk_upload_service_types",
        table_name: "services",
        insert_flag: "append",
        module_name: "Billing Services",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
                  ...metaData,
          billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        tenant_id:tenant_id_,
        blob: blob,
        main_module_name: "Billing Services",
      };

      const response = await axios.post(url, { data });

      const resp = JSON.parse(response.data.body);
      if (response.data.statusCode === 200) {
        if (resp.flag === true) {
          await fetchData()
          notification.success({
            message: 'Success',
            description: resp.message || 'Successfully uploaded the record!',
            placement: 'top',
          });
        } else {
          Modal.error({
            title: 'Import Error',
            content: resp.message,
            centered: true,
            onOk: handleErrorModalClose,
            onCancel: handleErrorModalClose
          });
        }
      } else {
        Modal.error({
          title: 'Import Error',
          content: resp.message,
          centered: true,
          onOk: handleErrorModalClose,
          onCancel: handleErrorModalClose
        });
      }
    } catch (error) {
      console.error('Error during file upload:', error);
      Modal.error({
        title: 'Import Error',
        content: 'There was an error uploading the file.',
        centered: true,
        onOk: handleErrorModalClose,
        onCancel: handleErrorModalClose
      });

    }
    finally {
      setLoading(false)
      setIsUploadModalVisible(false);
    }
  }
  const handleErrorModalClose = () => {
    setIsReUploadModalVisible(false)
    setIsUploadModalVisible(false);
  }
  const downloadBlob = (base64Blob: string , file_name:string) => {
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    const blobObject = new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blobObject);
    link.download = `${file_name}.xlsx` || "Service Types.xlsx";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  const handleDownloadTemplate = async (flag: string, type?: any) => {
    // settabledata([]);
    // const serviceTypeIds = tableData.map((row: { id: any; }) => row.id);
    // const rowData: Record<string, any[]> = {};
    // tableData.forEach((row: { customer_service_id: string | number; products: string; is_active: boolean }) => {
    //   try {
    //     const fixedProductsString = row.products
    //       .replace(/'/g, '"')                // Replace single quotes with double quotes
    //       .replace(/\bNone\b/g, 'null')      // Replace None with null
    //       .replace(/\bTrue\b/g, 'true')      // Replace True with true
    //       .replace(/\bFalse\b/g, 'false');   // Replace False with false

    //     const parsedProducts = JSON.parse(fixedProductsString);

    //     // Only push to rowData if the row itself is active
    //     if (row.is_active && parsedProducts.length > 0) {
    //       rowData[row.customer_service_id] = parsedProducts;
    //     }

    //   } catch (error) {
    //     console.error(`Failed to parse products for ${row.customer_service_id}`, error);
    //   }
    // });

    // console.log(rowData);

    setLoading(true);
    const url =
      ENV_ROUTES.BP_SERVICES_PRODUCTS;
    const tenant_id_ = localStorage.getItem("tenant_id") || "0";

    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: type === "upload"? "/download_template_for_service_types" : "/download_template_reupload",
      table_name: "services",
      module_name: "Billing Services",
      // services_list: serviceTypeIds? serviceTypeIds : [],
      flag: "Billing Services",
      Partner: partner,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
                ...metaData,
          billing_db_name: selectedBillingDb,
      sessionID: sessionId,
      tenant_id: tenant_id_,
      main_module_name: "Billing Services",
    };
    //    if (type === 'reupload') {
    //   data.services_list = serviceTypeIds? serviceTypeIds : [];
    // }

    try{
      const response = await axios.post(url, { data });
    const resp = JSON.parse(response.data.body);
    const blob = resp.blob;
    console.log(resp);
    if (response.data.statusCode === 200) {
      if (resp.flag === true) {
        setIsReUploadModalVisible(false);
        setIsUploadModalVisible(false);
        await fetchData();
        notification.success({
          message: 'Success',
          description: 'Successfully downloaded the template!',
          style: messageStyle,
          placement: 'top',
        });
        downloadBlob(blob,resp.file_name);
        setLoading(false);

      } else {
        console.log('Error message:', resp.message);
        Modal.error({
          title: 'Export Error',
          content: resp.message,
          centered: true,
        });
        setLoading(false)

      }
    } else {
      console.log('Unexpected status code:', response.data.statusCode);
      Modal.error({
        title: 'Export Error',
        content: resp.message,
        centered: true,
      });
      setLoading(false)

    }
    }
    catch(err){
      Modal.error({
        title: "Export Error",
        content: err instanceof Error ? err.message : "An unexpected error occurred while downloading data. Please try again.",
        centered: true,
      });
    }
    
  };
  const handleReUploadModalClose = () => {
    setIsReUploadModalVisible(false);
    setIsUploadModalVisible(false);
  }

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }
  return (
    <>
      <Suspense
        fallback={
          <div className="flex justify-center items-center h-screen">
            <Spin size="large" />
          </div>
        }
      >
        <div className="relative">
          <div className="flex justify-end p-2">
            <div className="flex items-center space-x-2 justify-end">
              <Switch onChange={handleSwitchChange} checked={showActive} className="custom-switch" />
              <span className="font-bold text-lg">Show Active only</span>
            </div>
          </div>
          {/* <div className="p-2 flex items-center justify-between mt-1 mb-2">
            <div className="flex space-x-2"> */}
          <div className="p-4 flex md:flex-row md:items-center md:justify-between space-y-6 md:space-y-0">
            {/* Search and Advanced Filter Container */}
            <div className="flex  space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last">
              {features.includes("Search-Billing Services") && (
                <WholeTableSearch
                  searchTerm={searchTerm}
                  setSearchTerm={setSearchTerm}
                  tableName={"Billing Service"}
                  headerMap={headerMap}
                />
              )}
              {features.includes("Advanced filter-Billing Services") && (
                <AdvancedMultiFilter2
                  showAdvanced={showAdvanced}
                  setShowAdvanced={setShowAdvanced}
                  onFilter={handleFilter}
                  onReset={handleReset}
                  headers={headers}
                  headerMap={headerMap}
                  tableName={"Billing Service"}
                />
              )}
            </div>
            {/* <div className="flex space-x-2"> */}
            {/* Export and ColumnFilter Container */}
            <div className="hidden md:flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2 md:order-none order-first ml-1">
              {features.includes("Add Service Type-Billing Services") && (
                <button className="save-btn" onClick={handleCreateModalOpen}>
                  <PlusIcon className="h-5 w-5 text-black-500 mr-1" />
                  {showAdvanced ? "Add" : "Add Service Type" }
                </button>)}
             
                {features.includes("Bulk Upload-Billing Services") && (
                <button className="save-btn" onClick={handleUploadClick}>
                  <ArrowUpTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                  <span>Upload</span>
                </button>)}
               {features.includes("Bulk Edit-Billing Services") && (
                <button className="save-btn" onClick={handleReUploadClick}>
                  <ArrowUpTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                  {/* <span>Edit Service Types</span> */}
                  {showAdvanced ? "Edit" : "Edit Service Types" }

                </button>)}
                {features.includes("Export-Billing Services") && (
                <button className="save-btn flex items-center" 
                style={{ minWidth: showAdvanced ? "40px" : "auto" }} onClick={() => handleExport("services", "Services")}>
                  <ArrowDownTrayIcon className="h-5 w-5 text-black-500" />
                    {!showAdvanced && <span className="ml-2">Export</span>}               
                    </button>)}
              <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
                popupHeading="Service Type"
              />
            </div>
          </div>
          <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
            <KillbillTableComponent
              headers={headers}
              headerMap={headerMap}
              initialData={tableData}
              searchQuery={searchTerm}
              visibleColumns={visibleColumns}
              itemsPerPage={100}
              allowedActions={allowedActions}
              popupHeading="Service Type"
              pagination={pagination}
              advancedFilters={filteredData}
              createModalData={createModalData}
              generalFields={generalFields}
              height={showAdvanced ? 305 : 250}

            />
          </div>
          <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
            {features.includes("Add Service Type-Billing Services") && (
              <button className="save-btn" onClick={handleCreateModalOpen}>
                <PlusIcon className="h-5 w-5 text-black-500" />
              </button>)}
           
             {features.includes("Bulk Upload-Billing Services") && (
                <button className="save-btn" onClick={handleUploadClick}>
                  <ArrowUpTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                </button>)}
            {features.includes("Bulk Edit-Billing Services") && (
              <button className="save-btn" onClick={handleReUploadClick}>
                <ArrowUpTrayIcon className="h-5 w-5 text-black-500 mr-2" />
              </button>)}
              {features.includes("Export-Billing Services") && (
              <button className="save-btn" onClick={() => handleExport("services", "Services")}>
                <ArrowDownTrayIcon className="h-5 w-5 text-black-500" />
              </button>
            )}
            <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
            />
          </div>
          <CreateModal
            isOpen={isCreateModalOpen}
            onClose={handleCreateModalClose}
            onSave={handleCreateRow}
            modalData={createModalData}
            title="service type"
            visible={isCreateModalOpen}
            action="create"
            generalFields={generalFields}



          />
          <Modal
            title="Edit Service Types"
            visible={isReUploadModalVisible}
            onCancel={handleReUploadModalClose}
            footer={null}
            centered
            width={400}
          >
            <div className="flex flex-col gap-4">
              <div className="flex flex-col md:flex-row gap-4 justify-center m-auto p-4">
                <Upload {...reUploadProps}>
                  <button
                    className="w-[200px] md:w-full upload-btn disabled:cursor-not-allowed"
                  >
                    <span className="mr-2"><UploadOutlined /></span>
                    Upload
                  </button>
                </Upload>
                <button
                  onClick={() => handleDownloadTemplate("download_template", 'reupload')}
                  className="w-[200px] md:w-full upload-btn disabled:cursor-not-allowed">
                  <span className="mr-2"><DownloadOutlined /></span>
                  Download Template
                </button>
              </div>
            </div>
          </Modal>
          <Modal
            title="Upload Service Types"
            visible={isUploadModalVisible}
            onCancel={handleReUploadModalClose}
            footer={null}
            centered
            width={400}
          >
            <div className="flex flex-col gap-4">
              <div className="flex flex-col md:flex-row gap-4 justify-center m-auto p-4">
                <Upload {...UploadProps}>
                  <button
                    className="w-[200px] md:w-full upload-btn disabled:cursor-not-allowed"                  >
                    <span className="mr-2"><UploadOutlined /></span>
                    Upload
                  </button>
                </Upload>
                <button
                  onClick={() => handleDownloadTemplate("download_template", 'upload')}
                  className="w-[200px] md:w-full upload-btn disabled:cursor-not-allowed"                >
                  <span className="mr-2"><DownloadOutlined /></span>
                  Download Template
                </button>
              </div>
            </div>
          </Modal>
          {/* {exportLoading && (
            <div className="export-processing-div">
              Export processing...
            </div>
          )} */}
        </div>
      </Suspense>
    </>
  );
};

export default ServicesPage;
