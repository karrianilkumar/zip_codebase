"use client"
import React, { useCallback, useState } from "react";
import { DatePicker, Input, Radio, Checkbox, RadioChangeEvent, notification, Modal, Spin } from "antd";
import Dropdown from "../killbill_components/dropdownComponent";
import { Dayjs } from "dayjs";
import { useAuth } from "@/app/components/auth_context";
import axios, { AxiosResponse } from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { X } from "lucide-react";
import KillbillTableComponent from "../killbill_components/table__component";
import { DownloadOutlined } from "@ant-design/icons";
import { ArrowDownTrayIcon } from "@heroicons/react/24/outline";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import dayjs from "dayjs"; // Ensure Dayjs is imported

interface DropdownOption {
    [key: string]: string[];
}

interface ReportPageProps {
    onBack: () => void;
    // onRun: (formData: ReportFormData) => void;
    dropdown: DropdownOption;
}
const messageStyle = {
    fontSize: '14px',
    fontWeight: 'normal',
    padding: '16px',
  };
type ReportFormData = {
    report_type: { label: string; value: string } | null;
    date_range: [Dayjs | null, Dayjs | null];
    [key: string]: any;
};

const ReportPage: React.FC<ReportPageProps> = ({ onBack,  dropdown }) => {
    // console.log(dropdown, "Show the dropdown values");
    const { RangePicker } = DatePicker;
    const [formData, setFormData] = useState<Record<string, any>>({});
      const [loading, setLoading] = useState(false);
      const selectedDb = 'billing_platform'
  const { username, partner, role, token, sessionId, settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId,metaData, selectedBillingDb,firstLastName, setStoredPagination, setAdvancedStoredPagination, setCombineAdnvaceStoredpagination } = useAuth();
    
      const [pagination, setPagination] = useState<any>({});
      const [tableData, setTableData] = useState<any>([]);
      const [features, setFeatures] = useState<string[]>([]);
      const [headers, setHeaders] = useState<any[]>([]);
      const [headerMap, setHeaderMap] = useState<any>({});
      const [generalFields, setgeneralFields] = useState<any[]>([]);
      const [allowedActions, setAllowedActions] = useState<any[]>([]);
      const [createModalData, setcreateModalData] = useState<any[]>([]);
      const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
      const { addExport, removeExport } = exportLoadingStore();
      
        type HeaderMap = Record<string, [string, number]>;
      
        const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
          const entries = Object.entries(headerMap) as [string, [string, number]][];
          entries.sort((a, b) => a[1][1] - b[1][1]);
          return Object.fromEntries(entries) as HeaderMap;
        }, []);
        
      const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
    const reportOptions = [
        { value: "A/R Aging", label: "A/R Aging" },
        { value: "Unposted Items By Customer", label: "Unposted Items By Customer" },
        { value: "Altaworx Billing Report", label: "Altaworx Billing Report" },
        { value: "Payment Details By Date Range", label: "Payment Details By Date Range" },
        { value: "Transaction Analysis", label: "Transaction Analysis" },
    ];

    // Convert string arrays to option format expected by Dropdown
    const formatOptions = (options: string[]) => 
        options.map(option => ({ label: option, value: option }));

    const handleInputChange = (key: string) => (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData({ ...formData, [key]: e.target.value });
    };

    const handleRadioChange = (key: string) => (e: RadioChangeEvent) => {
        setFormData({ ...formData, [key]: e.target.value });
    };

    const handleSelectChange = (field: string) => (value: any) => {
      if (field === "report_type") {
          setFormData({
              report_type: value?value.value:null
          } as ReportFormData);
          setHeaderMap([])
          setHeaders([])
          settabledata([])
          setStoredPagination(null);
          setAdvancedStoredPagination(null);
          setPagination([])
          setVisibleColumns([])
      } 
      else if (field === "date") {
        setFormData((prevData) => ({
            ...prevData,
            [field]: value ? value.toDate().toISOString() : null  // Store as ISO string
        }));
    } else {
          setFormData((prevData) => ({
              ...prevData,
              [field]: value?value.value:null
          }));
      }
  };
  const handleDateChange = (field: string) => (date: dayjs.Dayjs | null) => {
    setFormData((prevData) => {
        const newDateRange = [...(prevData.date_range || [])];

        if (field === "date_start") {
            newDateRange[0] = date ? date.toDate().toISOString() : null; 
        } else if (field === "date_end") {
            newDateRange[1] = date ? date.toDate().toISOString() : null; 
        }

        return {
            ...prevData,
            date_range: newDateRange.filter(d => d !== null) // Remove null values if any
        };
    });
};


  

    const handleDateRangeChange = (dates: [Dayjs | null, Dayjs | null] | null, dateStrings: [string, string]) => {
        setFormData({ ...formData, date_range: dates || [null, null] });
    };

    const handleCheckboxChange = (key: string) => (checkedValues: string[]) => {
        setFormData({ ...formData, [key]: checkedValues });
    };
  
  
  
    const onRun = async (formData: any) => {
        setLoading(true);
        try {
          let data;
          const url = ENV_ROUTES.BP_REPORTS;
   
   
            data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/generate_report",
              role_name: role,
              // module_name: "Billing Services",
              mod_pages: { start: 0, end: 100 },
              feature_module_name: "Billing Platform",
              Partner: partner,
              access_token: token,
              db_name: 'billing_platform',
              ...metaData,
billing_db_name: selectedBillingDb,
              report_name:formData.report_type,
              table_name: formData.report_type ==="Payment Details By Date Range"?"vw_payment_history"
                         :formData.report_type === "Altaworx Billing Report"?"billing_report_view":
                          formData.report_type === "Unposted Items By Customer"?"customer_charges":
                          formData.report_type === "Transaction Analysis"?"customer_charges":
                          formData.report_type === "A/R Aging"?"ar_aging_view":"",
              main_module_name: formData.reportType === "Payment Details By Date Range" ? "Payment Details By Date Range"
            : formData.reportType === "Altaworx Billing Report" ? "Altaworx Billing" :
              formData.reportType === "Unposted Items By Customer" ? "Unposted Items by Customer" :
                formData.reportType === "Transaction Analysis" ? "Transaction Analysis" : 
                formData.reportType === "A/R Aging"?"A/R Aging":"",
              request_received_at: getCurrentDateTime(),
              sessionID: sessionId,
              report_flag: "view",
              modified_by: firstLastName,
              changed_data: { ...formData }
            };
   
   
         
          const response = await axios.post(url, { data });
          // const resp = JSON.parse(response.data.body);
          const parsedData = JSON.parse(response.data.body);

          console.log(parsedData, "show the response");
          if (parsedData.flag === true) {
                 setLoading(false);
                 setTimeout(() => {
                  const report_type = formData.report_type
                  console.log("formData.report_type",formData.report_type)
                  const type = report_type === "Altaworx Billing Report"? "Altaworx Billing Report"
                            : report_type === "Payment Details By Date Range"? "Payment History Report"
                            : report_type === "Unposted Items By Customer"?"Unposted Items"
                            :report_type === "Transaction Analysis"?"Transaction Report"
                            :report_type === "A/R Aging"?"ar_aging_view":"";
                  const headersMap_ = parsedData?.header_map?.[type]?.header_map || {};
                  console.log("Parseddata.headermap",parsedData?.header_map)
                  console.log("Type",type)
                  console.log("headersMap_",headersMap_)
                   const sortedheaderMap = sortHeaderMap(headersMap_);
                   setHeaderMap(sortedheaderMap);
                   const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
                   setHeaders(headers_);
                   setVisibleColumns(headers_);
                   const generalFields_ = parsedData || {};
                   setgeneralFields(generalFields_);                   
                   const createModalData_ = parsedData?.header_map?.[type]?.pop_up || [];
                   setcreateModalData(createModalData_);
                   setPagination(parsedData?.pages || {});
                   setTableData(parsedData?.data?.reports_data || []);
                  //  setDropDownValues(parsedData?.dropdown||{});
                 }, 0);
               } else {
                 setLoading(false);
                 Modal.error({
                   title: "Data Fetch Error",
                   content: parsedData.message || "An error occurred while fetching data. Please try again.",
                   centered: true,
                 });
               }
        } catch (error) {
          console.error("Error fetching data:", error);
          Modal.error({
            title: 'Submit Error',
            content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting data. Please try again.',
            centered: true,
            onOk: onClose
          });
          // handleCancel()
        } finally {
          setLoading(false);
        }
      };
      const onClose = () => {
        console.log("Modal closed");
      };
    const handleRun = () => {
        if (formData.report_type) {
            onRun(formData);
        }
    };
    function getFirstDayOfCurrentMonth() {
      const now = new Date();
      const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
      return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, "0")}-${String(firstDay.getDate()).padStart(2, "0")} 00:00:00`;
    }
  
    function getLastDayOfCurrentMonth() {
      const now = new Date();
      const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
      return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, "0")}-${String(lastDay.getDate()).padStart(2, "0")} 23:59:59`;
    }
  
    const ExportWithoutSearch = async (key:any,heading:any) => {
      try {
      addExport(key, heading);

        const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
          return new Promise((resolve, reject) => {
            const timer = setTimeout(() => reject(new Error("Request timed out")), timeout);
            promise.then((res) => { clearTimeout(timer); resolve(res); }).catch((err) => { clearTimeout(timer); reject(err); });
          });
        };
  
        let data;
        const url = ENV_ROUTES.BP_REPORTS;
 
 
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/generate_report",
            role_name: role,
            // module_name: "Billing Services",
            // mod_pages: { start: 0, end: 100 },
            feature_module_name: "Billing Platform",
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
            ...metaData,
billing_db_name: selectedBillingDb,
            report_name:formData.report_type,
            table_name: formData.report_type ==="Payment Details By Date Range"?"vw_payment_history"
                         :formData.report_type === "Altaworx Billing Report"?"billing_report_view":
                          formData.report_type === "Unposted Items By Customer"?"customer_charges":
                          formData.report_type === "Transaction Analysis"?"customer_charges":
                          formData.report_type === "A/R Aging"?"ar_aging_view":"",
            main_module_name: formData.reportType === "Payment Details By Date Range" ? "Payment Details By Date Range"
            : formData.reportType === "Altaworx Billing Report" ? "Altaworx Billing" :
              formData.reportType === "Unposted Items By Customer" ? "Unposted Items by Customer" :
                formData.reportType === "Transaction Analysis" ? "Transaction Analysis" : 
                formData.reportType === "A/R Aging"?"A/R Aging":"",
            request_received_at: getCurrentDateTime(),
            sessionID: sessionId,
            report_flag: "download",
            modified_by: firstLastName,
            changed_data: { ...formData }
          };
        let generateReportResponse 
  
        try {
          // await callWithTimeout(axios.post(url, { data }), 10000);
          const export_response = await callWithTimeout(axios.post(url, { data }), 10000) as AxiosResponse<any>;  // ✅ Explicit type assertion
          generateReportResponse = JSON.parse(export_response.data.body);
          console.log("generateReportResponse",generateReportResponse)
        } catch (err) {
          console.warn("First API request failed or timed out:", err);
        }
  
        await new Promise((resolve) => setTimeout(resolve, 20000));
  
        const export_url = ENV_ROUTES.BP_REPORTS;
        const export_data = { ...data, path: "/get_export_status" ,report_id:generateReportResponse?.report_id,request_received_at: getCurrentDateTime()};
  
        const pollExportStatus = async () => {
          try {
            const export_response = await axios.post(export_url, { data: export_data });
            const export_parsedData = JSON.parse(export_response.data.body);
  
            if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
              const s3Url = export_parsedData?.export_status_data?.url || null;
              if (s3Url) {
                window.location.href = s3Url;
                notification.success({
                  message: "Success",
                  description: "Successfully exported the record!",
                  style: messageStyle,
                  placement: "top",
                });
              } else {
                Modal.error({ title: "Export Error", content: export_parsedData.message || "An error occurred while exporting data.", centered: true });
              }
              return true;
            }
  
            if (export_parsedData?.export_status_data?.status_flag === "Failure") {
              Modal.error({ title: "Export Error", content: export_parsedData.message || "An error occurred while exporting data.", centered: true });
              return true;
            }
            if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
                        Modal.error({
                          title: "Export Error",
                          content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
                          centered: true,
                        });
                        return true; // Stop polling
                      }
            return false;
          } catch (error) {
            Modal.error({ title: "Export Error", content: error instanceof Error ? error.message : "An unexpected error occurred.", centered: true });
            return true;
          }
        };
  
        const startPolling = async () => {
          let isPollingComplete = false;
          while (!isPollingComplete) {
            isPollingComplete = await pollExportStatus();
            if (!isPollingComplete) await new Promise((resolve) => setTimeout(resolve, 5000));
          }
        };
  
        await startPolling();
      } catch (error) {
        Modal.error({ title: "Export Error", content: error instanceof Error ? error.message : "An unexpected error occurred.", centered: true });
      }
      finally{
      removeExport(key);

      }
    };

    const renderReportFields = () => {
        if (!formData.report_type) return null;

        const reportType = formData.report_type;
        switch (reportType) {
            case "A/R Aging":
                return (
                    <div className="p-2">
                        <h3 className="text-xl font-bold mb-4">A/R Aging</h3>
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-4 mb-4">
                            <div className="flex flex-col">
                                <label className="field-label">Date</label>
                                <DatePicker onChange={handleSelectChange("date")}   value={formData.date ? dayjs(formData.date) : null}   
                                format="MM-DD-YY"
                                className="input w-full mt-1 h-10" />
                            </div>
                            <div className="flex flex-col">
                                <label className="field-label">Charge Date</label>
                                <Dropdown 
                                    options={formatOptions(dropdown.charge_date)} 
                                    onChange={handleSelectChange("charge_date")} 
                                    className="w-full" 
                                    value={formData.charge_date
                                      ? formatOptions(dropdown.charge_date).find((option) => option.value === formData.charge_date) || null 
                                      : null
                                  }
                                    
                                />
                            </div>
                            <div className="flex flex-col">
                                <label className="field-label">Credit Date</label>
                                <Dropdown 
                                    options={formatOptions(dropdown.credit_date)} 
                                    onChange={handleSelectChange("credit_date")} 
                                    className="w-full" 
                                    value={formData.credit_date
                                      ? formatOptions(dropdown.credit_date).find((option) => option.value === formData.credit_date) || null 
                                      : null
                                  }
                                />
                            </div>
                            <div className="flex flex-col">
                                <label className="field-label">Payment Date</label>
                                <Dropdown 
                                    options={formatOptions(dropdown.payment_date)} 
                                    onChange={handleSelectChange("payment_date")} 
                                    className="w-full" 
                                    value={formData.payment_date
                                      ? formatOptions(dropdown.payment_date).find((option) => option.value === formData.payment_date) || null 
                                      : null
                                  }
                                />
                            </div>
                            <div className="flex flex-col">
                                <label className="field-label">Format</label>
                                <Dropdown 
                                    options={formatOptions(dropdown.format)} 
                                    onChange={handleSelectChange("format")} 
                                    className="w-full" 
                                    value={formData.format
                                      ? formatOptions(dropdown.format).find((option) => option.value === formData.format) || null 
                                      : null
                                  }
                                />
                            </div>
                            <div className="flex flex-col">
                                <label className="field-label">Customer Status</label>
                                <Dropdown 
                                    options={formatOptions(dropdown.customer_status)} 
                                    onChange={handleSelectChange("customer_status")} 
                                    className="w-full" 
                                    value={formData.customer_status
                                      ? formatOptions(dropdown.customer_status).find((option) => option.value === formData.customer_status) || null 
                                      : null
                                  }
                                />
                            </div>
                            <div className="flex flex-col">
                                <label className="field-label">Minimum Balance</label>
                                <Input
                                    onChange={handleInputChange("minimum_balance")}
                                    placeholder="Enter amount"
                                    className="input w-full mt-1 h-10"
                                    value={formData.minimum_balance}
                                />
                            </div>
                            <div className="flex flex-col">
                                <label className="field-label">Agent</label>
                                <Dropdown 
                                    options={formatOptions(dropdown.sales_persons)} 
                                    onChange={handleSelectChange("agent")} 
                                    className="w-full" 
                                    value={formData.agent
                                      ? formatOptions(dropdown.sales_persons).find((option) => option.value === formData.agent) || null 
                                      : null
                                  }
                                />
                            </div>
                        </div>
                        {/* <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                           
                            
                           
                        </div> */}
                    </div>
                );
            case "Unposted Items By Customer":
                return (
                    <div className="p-4">
                        <h3 className="text-xl font-bold mb-4">Unposted Items By Customer</h3>
                        <div className="grid grid-cols-3 gap-4">
                            <div className="flex flex-col">
                                <label className="field-label">Column</label>
                                <Input onChange={handleInputChange("column")} defaultValue={"Customer ID"} disabled value={formData.column} placeholder="Enter column" className="input" />
                            </div>
                            <div className="flex flex-col">
                                <label className="field-label">Value</label>
                                <Input onChange={handleInputChange("value")} value={formData.value} placeholder="Enter value" className="input" />
                            </div>
                        </div>
                    </div>
                );
            case "Altaworx Billing Report":
                return (
                    <div className="p-4">
                        <h3 className="text-xl font-bold mb-4">Altaworx Billing Report</h3>
                        <div className="grid grid-cols-3 gap-4">
                      <div className="flex flex-col">
                        <label className="field-label">@Date Range</label>
                        <RangePicker
                          onChange={(dates) => {
                            setFormData((prevData) => ({
                              ...prevData,
                              date_range: dates
                                ? [dates[0]?.toISOString(), dates[1]?.toISOString()]
                                : []
                            }));
                          }}
                          value={formData.date_range?.length === 2
                            ? [dayjs(formData.date_range[0]), dayjs(formData.date_range[1])]
                            : undefined
                          }
                          className="input w-full mt-1 h-10"
                          format="MM-DD-YY"
                        />
                      </div>
                            {/* <div className="flex flex-col">
                                <label className="field-label">@Agent_Id</label>
                                <Dropdown 
                                    options={formatOptions(dropdown.sales_persons)} 
                                    onChange={handleSelectChange("agent_id")} 
                                    className="w-full"
                                />
                            </div> */}
                        </div>
                    </div>
                );
            case "Payment Details By Date Range":
                return (
                    <div className="p-4">
                        <h3 className="text-xl font-bold mb-4">Payment Details By Date Range</h3>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="flex flex-col">
                                <label className="field-label">Date Range</label>
                            
                                <RangePicker onChange={handleDateRangeChange} className="input" value={formData.date_range} format="MM-DD-YY" />
                            </div>
                            <div className="flex flex-col">
                                <label className="field-label">Evaluate Using</label>
                                <Radio.Group onChange={handleRadioChange("evaluate_using")} value={formData.evaluate_using}>
                                    <Radio value="Created Date">Created Date</Radio>
                                    <Radio value="Received Date">Received Date</Radio>
                                </Radio.Group>
                            </div>
                            <div className="flex flex-col">
                                <label className="field-label">Last 4</label>
                                <Input onChange={handleInputChange("last_4")} value={formData.last_4}placeholder="Enter last 4" className="input  w-full mt-1 h-10" />
                            </div>
                            <div className="flex flex-col">
                                <label className="field-label">Method</label>
                                <Dropdown 
                                    options={formatOptions(dropdown.method)} 
                                    onChange={handleSelectChange("method")} 
                                    className="w-full"
                                    value={formData.method
                                      ? formatOptions(dropdown.method).find((option) => option.value === formData.method) || null 
                                      : null
                                  }
                                />
                            </div>
                            <div className="flex flex-col">
                                <label className="field-label">Min. Amount</label>
                                <Input onChange={handleInputChange("min_amount")} value={formData.min_amount} placeholder="Enter amount" className="input  w-full mt-1 h-10" />
                            </div>
                            <div className="flex flex-col">
                                <label className="field-label">Created By</label>
                                <Dropdown 
                                    options={formatOptions(dropdown.sales_persons)} 
                                    onChange={handleSelectChange("created_by")} 
                                    className="w-full"
                                    value={formData.created_by
                                      ? formatOptions(dropdown.sales_persons).find((option) => option.value === formData.created_by) || null 
                                      : null
                                  }
                                />
                            </div>
                        </div>
                    </div>
                );
            case "Transaction Analysis":
                return (
                    <div className="p-4">
                        <h3 className="text-xl font-bold mb-4">Transaction Analysis</h3>
                        <div className="grid grid-cols-2 gap-4">
                            <div className="flex flex-col">
                                <label className="field-label">Date Start & Date End</label>
                                <RangePicker onChange={handleDateRangeChange} className="input  w-full mt-1 h-10" value={formData.date_range} format="MM-DD-YY"/>
                            </div>
                            <div className="flex flex-col">
                                <label className="field-label">Cycle (optional)</label>
                                <Input onChange={handleInputChange("cycle")} placeholder="Enter cycle" value={formData.cycle} className="input  w-full mt-1 h-10"/>
                            </div>
                            <div className="flex flex-col">
                                <label className="field-label">Product Type</label>
                                <Dropdown
                                    options={formatOptions(dropdown.product_types)}
                                    onChange={handleSelectChange("product_type")}
                                    className="w-full"
                                    value={formData.product_type
                                      ? formatOptions(dropdown.product_types).find((option) => option.value === formData.product_type) || null 
                                      : null
                                  }
                                />
                            </div>
                            <div className="flex flex-col">
                                <label className="field-label">G/L Code</label>
                                <Dropdown
                                    options={formatOptions(dropdown.g_l_codes)}
                                    onChange={handleSelectChange("gl_code")}
                                    className="w-full"
                                    value={formData.gl_code
                                      ? formatOptions(dropdown.g_l_codes).find((option) => option.value === formData.gl_code) || null 
                                      : null
                                  }
                                />
                            </div>
                            <div className="flex flex-col">
                                <label className="field-label">Service Type</label>
                                <Dropdown
                                    options={formatOptions(dropdown.service_types)}
                                    onChange={handleSelectChange("service_type")}
                                    className="w-full"
                                    value={formData.service_type
                                      ? formatOptions(dropdown.service_types).find((option) => option.value === formData.service_type) || null 
                                      : null
                                  }
                                />
                            </div>
                            <div className="flex flex-col">
                                <label className="field-label">State</label>
                                <Dropdown
                                    options={formatOptions(dropdown.service_locations)}
                                    onChange={handleSelectChange("state")}
                                    className="w-full"
                                    value={formData.state
                                      ? formatOptions(dropdown.service_locations).find((option) => option.value === formData.state) || null 
                                      : null
                                  }
                                />
                            </div>
                            <div className="flex flex-col col-span-2">
                                <label className="field-label">Item Description</label>
                                <Input onChange={handleInputChange("item_description")} value={formData.item_description}placeholder="Enter description" className="input" />
                            </div>
                            <div className="flex flex-col col-span-2">
                                <label className="field-label">Level of Detail</label>
                                <Checkbox.Group
                                    options={[
                                        "Cycle",
                                        "Month",
                                        "Detailed Item",
                                        "CustomerID",
                                        "Product Type",
                                        "State",
                                        "ServiceType",
                                        "G/L Code",
                                    ]}
                                    value={formData.level_of_detail}
                                    onChange={handleCheckboxChange("level_of_detail")}
                                />
                            </div>
                            <div className="flex flex-col col-span-2">
                                <label className="field-label">Types</label>
                                <Radio.Group onChange={handleRadioChange("types")} value={formData.types}>
                                    <Radio value="All">All</Radio>
                                    <Radio value="Non-Recurring">Non-Recurring</Radio>
                                    <Radio value="Subscriber Line">Subscriber Line</Radio>
                                    <Radio value="Network Access">Network Access</Radio>
                                    <Radio value="PICC">PICC</Radio>
                                    <Radio value="OCC's">OCCs</Radio>
                                    <Radio value="Adjustments">Adjustments</Radio>
                                    <Radio value="Monthly Recurring">Monthly Recurring</Radio>
                                    <Radio value="Usage">Usage</Radio>
                                </Radio.Group>
                            </div>
                        </div>
                    </div>
                );
            default:
                return null;
        }
    };
     if (loading) {
        return (
          <div className="flex justify-center items-center h-screen">
            <Spin size="large" />
          </div>
        );
      }

    return (
      <div>
        <div className="p-2 ">
          <div className="flex justify-between items-center">
            {" "}
            {/* Label + X aligned */}
            <label className="field-label">Select Report Type</label>
            <X
              className="w-6 h-6 text-gray-500 cursor-pointer "
              onClick={onBack}
            />
          </div>

          {/* Dropdown below */}
          <div className="flex space-x-6">
          <div className="w-[300px]">
            <Dropdown
              options={reportOptions}
              value={reportOptions.find(option => option.value === formData.report_type) || null}
              onChange={handleSelectChange("report_type")}
              // className="w-full"
            />
          </div>
          {formData.report_type && (
          <div className="flex justify-center space-x-2 ">
            {/* <button onClick={onBack} className="save-btn">
              Back
            </button> */}
            <button onClick={handleRun} className="save-btn">
              Run
            </button>
          </div>
          
        )}
        </div>
        </div>
        {renderReportFields()}

        
        <div className="mt-[10px]">
          <div className="p-4">
    {headers.length > 0 &&(<button className="save-btn" onClick={() => ExportWithoutSearch(formData.report_type, formData.report_type)}>
                  <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                  <span>Export</span>
                </button>)}
                </div>

    {/* Table Component */}
    <KillbillTableComponent
        headers={headers}
        headerMap={headerMap}
        initialData={tableData}
        visibleColumns={visibleColumns}
        itemsPerPage={100}
        allowedActions={allowedActions}
        popupHeading="Reports"
        pagination={pagination}
        createModalData={createModalData}
        generalFields={generalFields}
        height={235}
        ReportsData={formData}
        reportType={formData.report_type}
    />
</div>

      </div>
    );
};

export default ReportPage;