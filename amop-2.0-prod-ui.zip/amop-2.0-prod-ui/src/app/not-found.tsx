"use client"; // Required for useEffect in Next.js 13+

import { useEffect } from "react";
import { useRouter } from "next/navigation";

export default function NotFound() {

    return (
        <div className="flex flex-col items-center justify-center h-screen  bg-gray-100 pb-20">
          <p className="text-lg font-semibold text-gray-700 text-center pb-8">
            Redirecting to the Page...
          </p>
      
          {/* Loader animation */}
          <div className=" h-12 w-12 animate-spin rounded-full border-t-4 border-blue-600 border-solid"></div>
        </div>
      );
    }      
