import React, { useEffect, useState } from 'react';
import { Row, Col, Input, Button, Modal, Spin } from 'antd';
import { ENV_ROUTES } from '@/app/components/routes/route_constants';
import { useAuth } from '@/app/components/auth_context';
import { getCurrentDateTime } from '@/app/components/header_constants';
import axios from 'axios';

interface RuleDetailsProps {
  isOpen: boolean;
  onClose: () => void;
  row: any;
}

interface Step {
  id: number;
  Condition: string;
  dataConditionValue: any
  Action: any;
  ActionValue: any;
}

const RuleDetails: React.FC<RuleDetailsProps> = ({ row, isOpen }) => {
  console.log("row", row)
  const [loading, setLoading] = useState(true);
  const { username, partner, role, settabledata, token, selectedDb,firstLastName,sessionId,metaData} = useAuth();
  const [actionType, setActionType] = useState<string>("");
  const [condition, setCondition] = useState<string>("");
  const [conditionValue, setConditionValue] = useState<string>("");
  const [action, setAction] = useState<string>("");
  const [feature, setFeature] = useState<string>("");

  const [steps, setSteps] = useState<Step[]>([]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.AUTOMATION_RULE;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_automation_rule_details_data",
        role_name: role,
        module_name: "Automation rule log",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        automation_rule_name: row?.automation_rule_name || '',
        service_provider_name: row?.service_provider_display_name || '',
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {

        //read the description from selected row for the ActionType
        const parsedDescription = JSON.parse(row?.description);
        console.log("parsedDescription", parsedDescription)

        const actionType_ = parsedDescription?.ActionType || "Main action"
        setActionType(actionType_)

        //Mappings of options
        const ruleConditionMap = parsedData?.automation_rule_condition_dict || []
        const ruleStatusMap = parsedData?.Has_Current_status_values || []
        const ruleFeatureMap = parsedData?.features_data || []
        const actionMap = parsedData?.automation_rule_action_dict || []
        const automation_rule_detail_data_ = parsedData?.automation_rule_detail_data || []

        //set condition
        const conditionObject: any = ruleConditionMap.find((item: any) => parsedDescription.RuleConditionType === (item.id).toString());
        const selectedCondition = conditionObject?.automation_rule_condition_name || '';
        setCondition(selectedCondition)

        //set condition value
        let selectedConditionValue
        if (selectedCondition === "Has Current Status") {
          const statusObject: any = ruleStatusMap.find((item: any) => (
            parsedDescription.RuleConditionValue === (item.id).toString()
          ));
          selectedConditionValue = statusObject?.display_name
        }
        else {
          selectedConditionValue = parsedDescription.RuleConditionValue
        }
        setConditionValue(selectedConditionValue)

        //set action
        const action_ = parsedDescription?.RuleActionType || ""
        setAction(action_)

        //set action value
        const featureObject: any = ruleFeatureMap.find((item: any) => (
          parsedDescription?.RuleActionValue === item.soc_code
        ));

        const selectedFeature = featureObject?.friendly_name || ''

        setFeature(selectedFeature)

        // Convert automation_rule_detail_data_ to steps
        const automationRuleSteps = convertToSteps(
          automation_rule_detail_data_,
          ruleConditionMap,
          ruleStatusMap,
          ruleFeatureMap,
          actionMap
        );
        setSteps(automationRuleSteps)

        console.log("automationRuleSteps", automationRuleSteps)
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      setLoading(false);

    }
  };

  // Convert automation_rule_detail_data_ to steps
  const convertToSteps = (ruleDetailData: any[], ruleConditionMap: any[], ruleStatusMap: any[], ruleFeatureMap: any[], actionMap: any[]): Step[] => {
    return ruleDetailData.map((detail) => {
      // Find the matching condition in the ruleConditionMap
      const conditionObject = ruleConditionMap.find(
        (item: any) => detail.rule_condition_id === item.id
      );
      const conditionName = conditionObject ? conditionObject.automation_rule_condition_name : '';

      // Determine the condition value
      let conditionValue;
      if (conditionName === "Has Current Status") {
        const statusObject = ruleStatusMap.find(
          (item: any) => detail.rule_condition_value === item.id.toString()
        );
        conditionValue = statusObject ? statusObject.display_name : detail.rule_condition_value;
      }
      else if (conditionName === "Has feature") {
        const featureObject: any = ruleFeatureMap.find((item: any) => (
          detail.rule_condition_value === item.soc_code
        ));
        conditionValue = featureObject ? `${featureObject?.friendly_name} ${featureObject?.soc_code}` : detail.rule_condition_value;
      } else {
        conditionValue = detail.rule_condition_value;
      }

      // Find the matching action in the ruleConditionMap
      const actionObject = actionMap.find(
        (item: any) => detail.rule_action_id === item.id
      );
      const actionName = actionObject ? actionObject.automation_rule_action_name : '';

      // Find the matching actionValue
      let actionValue;
      if (actionName === "Change Status") {
        const statusObject = ruleStatusMap.find(
          (item: any) => detail.rule_action_value === item.id.toString()
        );
        actionValue = statusObject ? statusObject.display_name : detail.rule_action_value;
      }
      else {
        const featureObject: any = ruleFeatureMap.find((item: any) => (
          detail.rule_action_value === item.soc_code
        ));
        actionValue = featureObject ? `${featureObject?.friendly_name} ${featureObject?.soc_code}` : detail.rule_condition_value;
      }



      // Return the constructed step
      return {
        id: detail.condition_step,
        Condition: conditionName,
        dataConditionValue: conditionValue,
        Action: actionName,
        ActionValue: actionValue,
      };
    });
  };


  useEffect(() => {
    if (isOpen) {
      fetchData();
    }
  }, [isOpen]);

  return (
    <>
      {loading ? (
        <div className="flex justify-center items-center h-[300px]">
          <Spin size="large" />
        </div>
      ) : (
          steps.map((step, index) => (
            <div className='mb-8' key={index}>
              <span className='font-semibold  mb-8 mt-2 text-[16px]'>Step{step?.id}</span>
              <Row gutter={[16, 16]}>
                <Col xs={24} sm={24} md={4} > <label>Automation Rule</label></Col>
                <Col xs={24} sm={24} md={20}>
                  <Input
                    className='non-editable-input'
                    value={row?.automation_rule_name || ''}
                  />
                </Col>
                <Col xs={24} sm={24} md={4}> <label>Action Type</label></Col>
                <Col xs={24} sm={24} md={20}>
                  <Input
                    className='non-editable-input'
                    value={actionType || ''}
                  />
                </Col>
                <Col xs={24} sm={24} md={4}> <label>If any SIMs</label></Col>
                <Col xs={12} sm={12} md={10}>
                  <Input
                    className='non-editable-input'
                    value={step?.Condition || ''}
                  />
                </Col>

                <Col xs={12} sm={12} md={10}>
                  {/* <label>Status:</label> */}
                  <Input
                    className='non-editable-input'
                    value={step?.dataConditionValue || ''}
                  />
                </Col>
                <Col xs={24} sm={24} md={4}> <label>Do this</label></Col>
                <Col xs={12} sm={12} md={10}>
                  <Input
                    className='non-editable-input'
                    value={step?.Action || ''}
                  />
                </Col>

                <Col xs={12} sm={12} md={10}>
                  {/* <label>Feature:</label> */}
                  <Input
                    className='non-editable-input'
                    value={step?.ActionValue|| ''}
                  />
                </Col>

              </Row>
            </div>
          ))

      )}</>

  );
};

export default RuleDetails;
