"use client";
import React, { useEffect, useState, lazy, Suspense } from 'react';
// import dynamic from 'next/dynamic';
import { useSidebarStore } from '@/app/stores/navBarStore';
import { useLogoStore } from "@/app/stores/logoStore";
import { Spin } from 'antd';


const AutomationRule = lazy(() => import('./automation_rule'));
const AutomationRuleLog = lazy(() => import('./automation_rule_log'));



const Automation: React.FC = () => {
  const title = useLogoStore((state) => state.title);
  const setTitle = useLogoStore((state) => state.setTitle);
  const active_tab = localStorage.getItem("activeTab") || "automationRule"
  const active_tabs_list = ["automationRule", "automationRuleLog"]
  const [activeTab, setActiveTab] = useState(() => {
    // Check if active_tab is in active_tabs_list; default to 'customer' if not
    return active_tabs_list.includes(active_tab) ? active_tab : "automationRule";
  });
  const isExpanded = useSidebarStore((state: any) => state.isExpanded);

  const [loading, setLoading] = useState(false); // State to manage loading


  useEffect(() => {
    // Save activeTab state to localStorage on change
    localStorage.setItem("activeTab", activeTab);
  }, [activeTab]);


  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }
  return (
    <Suspense fallback={<div className="flex justify-center items-center h-screen"><Spin size="large" /></div>}>

      <div className="">
        <div className={`bg-white shadow-md mb-4 gap-4  tabs ${
        isExpanded
            ? "left-[250px]"
            : "lg:left-[70px] left-0"
        }`}>


          <button
            className={`tab-headings ${activeTab === 'automationRule' ? 'active-tab-heading' : ''}`}
            onClick={() => setActiveTab('automationRule')}
          >
            Automation Rule
          </button>
          <button
            className={`tab-headings ${activeTab === 'automationRuleLog' ? 'active-tab-heading' : ''}`}
            onClick={() => setActiveTab('automationRuleLog')}
          >
            Automation Rule Log
          </button>


        </div>
        <div className="h-[calc(100vh-150px)] pt-[70px]">
          {activeTab === 'automationRule' && <AutomationRule />}
          {activeTab === 'automationRuleLog' && <AutomationRuleLog />}


        </div>
      </div>
    </Suspense>
  );
};

export default Automation;

