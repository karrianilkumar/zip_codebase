"use client";
import React, { lazy, Suspense, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/app/components/auth_context";
import { useLogoStore } from "@/app/stores/logoStore";

import {
    XAxis,
    YAxis,
    CartesianGrid,
    Tooltip,
    Legend,
    BarChart,
    Bar,
    ResponsiveContainer,
    Cell,
    PieChart,
    Pie,
    LineChart,
    Line,
    ScatterChart,
    Scatter,
} from "recharts";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { DatePicker, Modal, notification, Select, Spin } from "antd";
import { ChevronDownIcon } from "@heroicons/react/24/outline";
import moment, { months } from "moment";
import dayjs, { Dayjs } from "dayjs";
import { ArrowsAltOutlined, BarChartOutlined, DotChartOutlined, DownloadOutlined, LineChartOutlined, ShrinkOutlined } from "@ant-design/icons";

const OverviewCards = lazy(() => import("@/app/super_admin/centralized_view/bulk_change_details/overview_cards"));
const DashboardTables = lazy(() => import("@/app/dashboard/dasboard_table"));

const { RangePicker } = DatePicker;
interface FilterOptions {
    options: any[];
}
interface Message {
    [key: string]: number;
}

interface ChartDataItem {
    provider: string;
    messages: Message;
}


const Overview: React.FC = () => {
    const router = useRouter();
    const { username, partner, role, selectedDb,metaData, token, firstLastName, sessionId, setSelectedPartner } = useAuth();
    const [loading, setLoading] = useState(false);
    const [chartsData, setChartsData] = useState<any>([]);
    const setTitle = useLogoStore((state) => state.setTitle);
    const [filterOptions, setFilterOptions] = useState<FilterOptions>({
        options: [],
    });
    const [compareChartTitle, setCompareChartTitle] = useState("");
    const [selectedFilter, setSelectedFilter] = useState("All Tenants");
    const [selectedButton, setSelectedButton] = useState<string | null>("Today");
    const [startDate, setStartDate] = useState<string>(
        moment().format("YYYY-MM-DD")
    );


    const [endDate, setEndDate] = useState<string>(moment().format("YYYY-MM-DD"));
    const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([
        null,
        null,
    ]);

    const [currentYear, setCurrentYear] = useState(new Date().getFullYear());
    const presentYear = new Date().getFullYear();
    const presentMonth = dayjs().month();
    const { RangePicker } = DatePicker;


    const [downloadLoading, setDownloadLoading] = useState<{ [key: string]: boolean }>({});

    // const COLORS = ["#6a8bcc","#4ade80","#0984E3"];
    const COLORS = ["#34d399", "#e15151", "#5fafee"];
    const COLORSForBarTwo = [
        // "#8884d8",
        // "#82ca9d",
        // "#ffc658",
        "#6a8bcc",
        "#4ade80",
        "#0984E3",
        "#ff7300",
        "#0088fe",
        "#00C49F",
        "#FFBB28",
        "#FF8042",
        "#a4de6c",
        "#d0ed57",
        "#FFB6C1",
    ];
    const stackeDBarColors = [
        "#4ade80", // light green
        "#5fafee", // sky blue
        "#6a8bcc", // medium blue
        "#facc15", // yellow
        "#f97316", // orange
        "#a78bfa", // lavender
        "#f472b6", // pink
        "#34d399", // teal
        "#c084fc", // purple
        "#ff8c00", // dark orange
        "#b4b4f9", // light purple
    ];

    // Inside your component
    const [isSmallMediumScreen, setIsSmallMediumScreen] = useState(false);

    useEffect(() => {
        const handleResize = () => {
            setIsSmallMediumScreen(window.innerWidth <= 1000); // Customize breakpoint if needed
        };

        handleResize(); // Set on mount
        window.addEventListener("resize", handleResize);

        return () => window.removeEventListener("resize", handleResize);
    }, []);


    const fetchData = async (
        startDate: any,
        endDate: any,
        selectedFilter: any
    ) => {
        setLoading(true);
        try {
            const url = ENV_ROUTES.CENTRALIZED_VIEW;
            const requestPaths = [
                { path: "/bargraph_bulk_change_process_status" },
                { path: "/pie_chart_bulk_change_sync_status" },
                { path: "/stackbar_bulk_change_change_request" },
            ];

            const tenantFilter =
                selectedFilter === "All Tenants" ? "All" : selectedFilter;

            const promises = requestPaths.map(({ path }) => {
                const requestData = {
                    partner: partner,
                    role_name: role,
                    start_date: startDate,
                    end_date: endDate,
                    selected_tenant: tenantFilter,
                    path,
                    access_token: token,
                    db_name: "central_db",
                    ... metaData,
                    sessionID: sessionId,
                    username: username,
                    filter: selectedButton || null,
                };

                return axios.post(url, { data: requestData }).then((response) => {
                    const parsedBody = JSON.parse(response.data.body);
                    const { data } = parsedBody;
                    return {
                        title: data.title,
                        chart_type: data.chart_type,
                        data: data.data,
                        angleField: data.angleField,
                        colorField: data.colorField,
                        radius: data.radius,
                        innerRadius: data.innerRadius,
                        height: data.height,
                        width: data.width,
                        xField: data.xField,
                        yField: data.yField,
                        smooth: data.smooth,
                        isStacked: data.isStacked,
                    };
                });
            });
            const results = await Promise.allSettled(promises);
            const successfulResults = results
                .filter((result) => result.status === "fulfilled")
                .map((result) => result.value);

            setChartsData(successfulResults);
        } catch (error) {
            console.error("Error fetching data in dashboard:", error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        const initializeDashboard = async () => {
            setSelectedPartner(true);
            console.log("App mounted, fetching SSM parameters");
            setLoading(true);

            try {
                await fetchFilterOptions();
                await fetchData(startDate, endDate, selectedFilter);
            } catch (error) {
                console.error("Error during initialization:", error);
            } finally {
                setLoading(false);
            }
        };

        // Call the initialization function
        initializeDashboard();
    }, [role, partner]);

    const renderCustomizedLabel = ({
        cx,
        cy,
        midAngle,
        innerRadius,
        outerRadius,
        percent,
    }: any) => {
        const RADIAN = Math.PI / 180;
        const radius = innerRadius + (outerRadius - innerRadius) * 0.35;
        const x = cx + radius * Math.cos(-midAngle * RADIAN);
        const y = cy + radius * Math.sin(-midAngle * RADIAN);

        return (
            <text
                x={x}
                y={y}
                fill="white"
                textAnchor="middle"
                dominantBaseline="central"
                fontSize="16"
            >
                {`${(percent * 100).toFixed(0)}%`}
            </text>
        );
    };

    const handleButtonClick = (
        range: "Today" | "Current Week" | "Current Month"
    ) => {
        setSelectedButton(range);

        if (range === "Today") {
            setDateRange([null, null]);
            const today = moment().format("YYYY-MM-DD");
            setStartDate(today);
            setEndDate(today);
        } else if (range === "Current Week") {
            setDateRange([null, null]);
            setStartDate(moment().startOf("week").format("YYYY-MM-DD"));
            setEndDate(moment().endOf("week").format("YYYY-MM-DD"));
        } else if (range === "Current Month") {
            setDateRange([null, null]);
            setStartDate(moment().startOf("month").format("YYYY-MM-DD"));
            setEndDate(moment().endOf("month").format("YYYY-MM-DD"));
        }
    };

    const handleDateRangeChange = (
        dates: [Dayjs | null, Dayjs | null] | null,
        dateStrings: [string, string]
    ) => {
        setSelectedButton(null);
        if (dates && dates[0] && dates[1]) {
            setDateRange([dates[0], dates[1]]);
            setStartDate(dates[0].format("YYYY-MM-DD"));
            setEndDate(dates[1].format("YYYY-MM-DD"));
            setSelectedButton("");
        } else {
            setDateRange([null, null]);
            setSelectedButton("Today");
        }
    };

    useEffect(() => {
        let startDate = "";
        let endDate = "";

        if (selectedButton === "Today") {
            startDate = moment().format("YYYY-MM-DD");
            endDate = moment().format("YYYY-MM-DD");
        } else if (selectedButton === "Current Week") {
            startDate = moment().startOf("week").format("YYYY-MM-DD");
            endDate = moment().endOf("week").format("YYYY-MM-DD");
        } else if (selectedButton === "Current Month") {
            startDate = moment().startOf("month").format("YYYY-MM-DD");
            endDate = moment().endOf("month").format("YYYY-MM-DD");
        } else if (dateRange[0] && dateRange[1]) {
            startDate = dateRange[0].format("YYYY-MM-DD");
            endDate = dateRange[1].format("YYYY-MM-DD");
        }

        fetchData(startDate, endDate, selectedFilter);
        console.log("292")
    }, [selectedButton, dateRange, selectedFilter]);

    const fetchFilterOptions = async () => {
        try {
            const url = ENV_ROUTES.CENTRALIZED_VIEW;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_tenants_list",
                role_name: role,
                parent_module: "Super Admin",
                module_name: "Centralized View",
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
        ... metaData,
                sessionID: sessionId,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            const tenantsList = parsedData?.tenant_list || []
            const tenantOptions = tenantsList
                .map((tenant: any) => ({
                    value: tenant,
                    label: tenant,
                }));
            setFilterOptions({ options: tenantOptions });
        } catch (error) {
            console.error(error);
        }
    };

    const handleFilterChange = async (value: any) => {
        setSelectedFilter(value);
        await fetchData(startDate, endDate, value);
        console.log("330")
    };

    const formatStackedBarData = (data: any[]) => {
        const result = [];
        const categories = new Set();

        // Create a map to aggregate counts for each service provider and change request type
        const dataMap: any = {};

        data.forEach((item) => {
            const { tenant, change_request_type, count } = item;
            categories.add(change_request_type);

            // Initialize entry if service_provider doesn't exist in map
            if (!dataMap[tenant]) {
                dataMap[tenant] = { tenant };
            }
            // Set or add the count to the respective change request type
            dataMap[tenant][change_request_type] = count;
        });

        // Convert map to array format
        for (const key in dataMap) {
            result.push(dataMap[key]);
        }

        return {
            data: result,
            categories: Array.from(categories),
        };
    };


    const renderControls = () => {
        const allTenantsOption = { label: "All Tenants", value: "All Tenants" };

        const availableOptions = [
            allTenantsOption,
            ...filterOptions.options.filter(
                (option: any) => option.value !== selectedFilter && option.value !== "All Tenants"
            ),
        ];
        const isSmallScreen = typeof window !== "undefined" && window.innerWidth < 700;

        if (isSmallScreen) {
            return (
                <div className="flex flex-col gap-4 mx-3 my-2">
                    {/* First Row: Select and RangePicker */}
                    <div className="flex justify-between items-center gap-2">
                        <Select
                            style={{
                                width: "100%",
                                maxWidth: 200,
                                fontWeight: "450",
                                height: "47px",
                                fontFamily: "Calibri, sans-serif",
                                borderRadius: "8px",
                            }}
                            value={selectedFilter}
                            onChange={handleFilterChange}
                            options={availableOptions}
                            notFoundContent="No options available"
                            showSearch
                            suffixIcon={<ChevronDownIcon className="w-4 h-4 text-gray-600" />}
                            className="flex-1"
                        />
                        <RangePicker
                            value={dateRange}
                            onChange={handleDateRangeChange}
                            style={{
                                width: "100%",
                                maxWidth: 250,
                                height: "47px",
                                borderRadius: "8px",
                            }}
                            disabledDate={(current) => current && current > dayjs().endOf("day")}
                            className="flex-1 small-screen-range-picker"
                            popupClassName="custom-range-popup"
                        />
                    </div>
                    {/* Second Row: Select label and Buttons */}
                    <div className="flex flex-wrap items-center gap-2">
                        <span
                            style={{
                                fontFamily: "Calibri, sans-serif",
                                fontSize: "16px",
                            }}
                            className="mr-2"
                        >
                            Select:
                        </span>
                        <button
                            className={
                                selectedButton === "Today"
                                    ? "save-btn"
                                    : "email-dashboard-btns"
                            }
                            onClick={() => handleButtonClick("Today")}
                            style={{
                                fontFamily: "Calibri, sans-serif",
                                fontSize: "14px",
                                padding: "8px 12px",
                            }}
                        >
                            Today
                        </button>
                        <button
                            className={
                                selectedButton === "Current Week"
                                    ? "save-btn"
                                    : "email-dashboard-btns"
                            }
                            onClick={() => handleButtonClick("Current Week")}
                            style={{
                                fontFamily: "Calibri, sans-serif",
                                fontSize: "14px",
                                padding: "8px 12px",
                            }}
                        >
                            Current Week
                        </button>
                        <button
                            className={
                                selectedButton === "Current Month"
                                    ? "save-btn"
                                    : "email-dashboard-btns"
                            }
                            onClick={() => handleButtonClick("Current Month")}
                            style={{
                                fontFamily: "Calibri, sans-serif",
                                fontSize: "14px",
                                padding: "8px 12px",
                            }}
                        >
                            Current Month
                        </button>
                    </div>
                </div>

            );
        }


        return (
            <div
                style={{
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "flex-end",
                    marginBottom: "10px",
                    marginTop: "10px",
                    marginRight: "12px",
                }}
                className="flex flex-wrap gap-2"
            >
                <Select
                    style={{
                        width: 200,
                        fontWeight: "450",
                        height: "47px",
                        fontFamily: "Calibri, sans-serif",
                        borderRadius: "8px",
                    }}
                    value={selectedFilter}
                    onChange={handleFilterChange}
                    options={availableOptions}
                    notFoundContent="No options available"
                    showSearch
                    suffixIcon={<ChevronDownIcon className="w-4 h-4 text-gray-600" />}
                />
                <span
                    style={{
                        marginLeft: 10,
                        marginRight: 20,
                        fontFamily: "Calibri, sans-serif",
                        fontSize: "16px",
                        marginTop: "-2px",
                    }}
                >
                    Select:
                </span>
                <button
                    className={
                        selectedButton === "Today" ? "save-btn" : "email-dashboard-btns"
                    }
                    onClick={() => handleButtonClick("Today")}
                    style={{
                        marginRight: 10,
                        fontFamily: "Calibri, sans-serif",
                        fontSize: "16px",
                        padding: "10px",
                        marginTop: "-2px",
                    }}
                >
                    Today
                </button>
                <button
                    className={
                        selectedButton === "Current Week"
                            ? "save-btn"
                            : "email-dashboard-btns"
                    }
                    onClick={() => handleButtonClick("Current Week")}
                    style={{
                        marginRight: 10,
                        fontFamily: "Calibri, sans-serif",
                        fontSize: "16px",
                        padding: "10px",
                        marginTop: "-2px",
                    }}
                >
                    Current Week
                </button>
                <button
                    className={
                        selectedButton === "Current Month"
                            ? "save-btn"
                            : "email-dashboard-btns"
                    }
                    onClick={() => handleButtonClick("Current Month")}
                    style={{
                        marginRight: 10,
                        fontFamily: "Calibri, sans-serif",
                        fontSize: "16px",
                        padding: "10px",
                        marginTop: "-2px",
                    }}
                >
                    Current Month
                </button>
                <RangePicker
                    value={dateRange}
                    onChange={handleDateRangeChange}
                    style={{
                        marginLeft: "2px",
                        marginRight: "5px",
                        height: "47px",
                        borderRadius: "8px",
                    }}
                    popupClassName="custom-range-popup"
                    disabledDate={(current) => current && current > dayjs().endOf("day")}
                />
            </div>
        );

    };

    const renderChart = (chart: any) => {
        switch (chart.chart_type) {
            case "bar": {
                return (
                    <ResponsiveContainer width="100%" height={300}>
                        <BarChart
                            layout="vertical"
                            data={chart.data}
                            margin={{ top: 20, right: 30, left: isSmallMediumScreen ? 30 : 100, bottom: 20 }}
                        >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis type="number" />
                            <YAxis
                                type="category"
                                dataKey="name"
                                tick={({ x, y, payload }) => (
                                    <text
                                        x={x - 10} // position left a bit
                                        y={y}
                                        transform={isSmallMediumScreen ? `rotate(-45, ${x - 10}, ${y})` : ''}
                                        textAnchor="end"
                                        fontSize={isSmallMediumScreen ? 12 : 14}
                                    >
                                        {payload.value}
                                    </text>
                                )}
                            />
                            <Tooltip isAnimationActive={false} />
                            <Legend verticalAlign="bottom" height={36} />
                            <Bar
                                dataKey="UI"
                                fill="#0B60B0"
                                barSize={20}
                                activeBar={false}
                            />
                            <Bar
                                dataKey="API"
                                fill="#5fafee"
                                barSize={20}
                                activeBar={false}
                            />
                        </BarChart>
                    </ResponsiveContainer>
                );
            }
            case "pie": {
                const hasNonZeroData =
                    chart.data &&
                    chart.data.some((item: { count: number }) => item.count > 0);

                const transformedData =
                    chart.data?.map((item: { status: string; count: number }) => ({
                        name: item.status,
                        value: item.count,
                    })) || [];

                return (
                    <div
                        style={{
                            height: "280px",
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                        }}
                    >
                        {hasNonZeroData ? (
                            <ResponsiveContainer width="100%" height="100%">
                                <PieChart>
                                    <Pie
                                        data={transformedData}
                                        cx="50%"
                                        cy="50%"
                                        innerRadius={80}
                                        outerRadius={130}
                                        fill="#8884d8"
                                        paddingAngle={0}
                                        minAngle={6}
                                        dataKey="value"
                                        nameKey="name"
                                        label={renderCustomizedLabel}
                                        labelLine={false}
                                    >
                                        {transformedData.map((entry: any, index: number) => (
                                            <Cell
                                                key={`cell-${index}`}
                                                fill={COLORS[index % COLORS.length]}
                                            />
                                        ))}
                                    </Pie>
                                    <Tooltip />
                                    <Legend
                                        layout="horizontal"
                                        align="center"
                                        verticalAlign="bottom"
                                        iconType="square"
                                    />
                                </PieChart>
                            </ResponsiveContainer>
                        ) : (
                            <ResponsiveContainer width="100%" height="100%">
                                <PieChart>
                                    <Pie
                                        data={[{ name: "No data", value: 1 }]}
                                        cx="50%"
                                        cy="50%"
                                        innerRadius={80}
                                        outerRadius={120}
                                        fill="#f0f0f0"
                                        dataKey="value"
                                        labelLine={false}
                                        isAnimationActive={false}
                                    />
                                    <text
                                        x="50%"
                                        y="50%"
                                        textAnchor="middle"
                                        fill="#8884d8"
                                        style={{
                                            fontSize: "16px",
                                            fontFamily: "Calibri, sans-serif",
                                        }}
                                    >
                                        No Data
                                    </text>
                                </PieChart>
                            </ResponsiveContainer>
                        )}
                    </div>
                );
            }
            case "stackedBar": {
                const formattedData = formatStackedBarData(chart.data);
                const hasData = Array.isArray(chart.data) && chart.data.length > 0;
                return (
                    <div style={{ width: "90vw", maxWidth: "100%" }}>
                        <ResponsiveContainer width="100%" height={400}>
                            <BarChart
                                data={formattedData.data}
                                margin={{ top: 20, right: 30, left: 20, bottom: isSmallMediumScreen ? 10 : 60 }}
                            >
                                <CartesianGrid strokeDasharray="3 3" vertical={false} />
                                <XAxis
                                    dataKey="tenant"
                                    axisLine={false}
                                    tickLine={false}
                                    height={isSmallMediumScreen ? 150 : 40} // give enough room for vertical labels
                                    angle={isSmallMediumScreen ? -60 : 0}   // vertical on small screens
                                    textAnchor={isSmallMediumScreen ? "end" : "middle"}
                                    tickFormatter={
                                        isSmallMediumScreen
                                            ? (value) => value.replace(/ /g, "\u00A0") // Prevent word-break at spaces
                                            : undefined
                                    }
                                    label={{
                                        value: "Tenants",
                                        position: "center",
                                        // offset: 15,
                                        offset: isSmallMediumScreen ? -90 : 5, dy: 40
                                    }}
                                    interval={0}
                                    // tick={{ fontSize: 14, width:40, }}
                                    tick={{
                                        fontSize: isSmallMediumScreen ? 12 : 16,
                                        width: 40,
                                    }}
                                />
                                <YAxis
                                    axisLine={false}
                                    tickLine={false}
                                    domain={[0, "dataMax + 10"]}
                                    label={{
                                        value: "No. of Change Requests",
                                        angle: -90,
                                        position: "insideLeft",
                                        offset: -8,
                                        style: { textAnchor: "middle" },
                                    }}
                                    interval={0}
                                />
                                <Tooltip cursor={{ fill: 'transparent' }} />
                                <Legend
                                    className="stacked-bar-legend"
                                    align="center"
                                    verticalAlign="bottom"
                                    iconType="square"
                                    wrapperStyle={{
                                        width: "fit-content",
                                        textAlign: "center",
                                        paddingTop: isSmallMediumScreen ? 0 : 10,
                                        // paddingBottom: 6,
                                        marginTop: isSmallMediumScreen ? 2 : 30,
                                        maxHeight: isSmallMediumScreen ? "auto" : 50,
                                        fontSize: isSmallMediumScreen ? 14 : 15,
                                        flexWrap: "wrap",
                                        justifyContent: "center",
                                    }}
                                    payload={formattedData.categories.map((category, index) => ({
                                        value: category,
                                        type: "square",
                                        color: stackeDBarColors[index % stackeDBarColors.length],
                                    }))}
                                />
                                {formattedData.categories.map((category, index) => (
                                    <Bar
                                        key={index}
                                        dataKey={category as string}
                                        stackId="a"
                                        fill={stackeDBarColors[index % stackeDBarColors.length]}
                                    />
                                ))}
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                );
            }
            default:
                return null;
        }
    };

    return (
        <>
            {loading ? (
                <div className="flex justify-center items-center h-screen">
                    <Spin size="large" />
                </div>
            ) : (
                <>
                    <Suspense>
                        {renderControls()}
                        <OverviewCards
                            startDate={startDate}
                            endDate={endDate}
                            selectedTenant={selectedFilter === "All Tenants" ? "All" : selectedFilter}
                        />
                        {/* Charts Section */}
                        <div className="grid grid-cols-1 md:grid-cols-2 justify-center gap-[10px] m-[10px]">
                            {chartsData.map((chart: any, index: any) => {
                                const isStackedBar =
                                    chart.chart_type === "stackedBar" ||
                                    chart.chart_type === "bar_two";

                                return (
                                    <div
                                        key={index}
                                        className={`${isStackedBar? "md:col-span-2 mb-[20px] h-[600px] md:h-[500px]" : "h-[350px]"} graph`}
                                        style={{
                                            borderRadius: "10px",
                                            boxShadow: "0 4px 8px rgba(0, 0, 0, 0.1)",
                                            // backgroundColor: "#fff",
                                            paddingBottom: "8px",
                                            cursor: "pointer",
                                            // height: isStackedBar ? "500px" : "350px",
                                        }}
                                    // onClick={() => handleChartClick(chart.chart_type)}
                                    >
                                        <h3
                                            className="text-[19px] mb-[5px] pb-[2px]"
                                            style={{
                                                fontFamily: "Calibri, sans-serif",
                                                marginLeft: "22px",
                                                marginTop: "10px",
                                                position: "relative",
                                            }}
                                        >
                                            {chart.title}
                                        </h3>
                                        <div
                                            style={{
                                                height: `${chart.height}px`,
                                                width: "100%",
                                            }}
                                        >
                                            {renderChart(chart)}
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    </Suspense>

                </>
            )}
        </>
    );
};

export default Overview;