"use client";
import React, { useEffect, useState, lazy, Suspense, useRef } from "react";
import { ArrowDownTrayIcon, } from "@heroicons/react/24/outline";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { useLogoStore } from "@/app/stores/logoStore";
import dayjs, { Dayjs } from "dayjs";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { Button, Modal, Popover, Spin, DatePicker, notification } from "antd";
import { CalendarOutlined, DownloadOutlined } from '@ant-design/icons'; // Import CalendarOutlined and optionally DownloadOutlined
import { useDateRangeStore } from "@/app/stores/dateStoreDailyUsageReport";
const { RangePicker } = DatePicker;
//Lazy Loading Components
const TableComponent = lazy(
  () => import("@/app/components/TableComponent/page")
);
const TableSearch = lazy(() => import("@/app/components/entire_table_search"));
const AdvancedMultiFilter = lazy(
  () => import("@/app/components/advanced_search")
);
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));

const ActionsHistoryReport: React.FC = () => {
  const [features, setFeatures] = useState<string[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [loading, setLoading] = useState(true);
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, settabledata, token, tenantId, tenantName, selectedDb, metaData, advancedStoredpagination, storedpagination, firstLastName, sessionId, combineAdnvaceStoredpagination, setCombineAdnvaceStoredpagination,dynamicColumns,setDynamicColumns } =
    useAuth();
  const [tableData, setTableData] = useState<any[]>([]);
  const title = useLogoStore((state) => state.title);
  const [pagination, setpagination] = useState<any>({});
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [createModalData, setcreateModalData] = useState<any[]>([]);
  const [generalFields, setgeneralFields] = useState<any[]>([]);
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [selectedButton, setSelectedButton] = useState("currentMonth");
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  // Ensure state includes isDateModalOpen
const [isDateModalOpen, setIsDateModalOpen] = useState(false);
  const {
    startDateDailyReport,
    endDateDailyReport,
    setActionHistoryCurrentMonth,
    setCustomRange
  } = useDateRangeStore();
  const { addExport, removeExport } = exportLoadingStore();
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});

  useEffect(() => {
    if (role?.toLowerCase() !== "super admin" && role?.toLowerCase() !== "partner admin" && role?.toLowerCase() !== "agent partner admin") {
      const removeHeaderList = Object.keys(headerMap).filter(
        (key) =>
          ["communication plan"].includes(
            headerMap[key][0]?.toLowerCase()
          )
      );

      setHeaders((prevHeaders) =>
        prevHeaders.filter((header) => !removeHeaderList.includes(header))
      );
    }
  }, [role, headerMap]);

  useEffect(() => {
        setDynamicColumns((prev:any)=>({...prev,"Actions History Report":visibleColumns}))
      }, [visibleColumns]);

  const fetchData = async (startDate: string, endDate: string) => {
    settabledata([])
    setCombineAdnvaceStoredpagination(null)
    setLoading(true);
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username,
        role_name: role,
        start_date: startDate,
        end_date: endDate,
        path: "/reports_data_with_date_filter",
        parent_module: "Reports",
        module_name: "Actions History Report",
        feature_module_name: "Actions History Report",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        table_name: "sim_management_inventory_action_history",
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
      };
      console.log(getCurrentDateTime(), "Show the log time request sent from ui to lambda");
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      console.log(getCurrentDateTime(), "Show the log time response sent from lambda to ui");
      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      } else {
        const tableData = parsedData?.data || [];
        const headerMap =
          parsedData.headers_map?.["Actions History Report"]?.["header_map"] || {};
        const sortedheaderMap = sortHeaderMap(headerMap);
        // const generalFields = parsedData.data
        const pagination_ = parsedData?.pages || {};
        setpagination(pagination_);
        // setgeneralFields(generalFields)
        const features_ = parsedData?.headers_map?.["Actions History Report"]?.module_features || [];
        setFeatures(features_);
        setHeaderMap(headerMap);
        // setcreateModalData(sortPopup(createModalData))
        setTableData(tableData);
        const headers_ =
            Object.keys(sortedheaderMap).length > 0
              ? Object.keys(sortedheaderMap)
              : [];
          setHeaders(headers_);
          const dynamic_cols=dynamicColumns?.["Actions History Report"] && dynamicColumns["Actions History Report"].length>0 ?dynamicColumns["Actions History Report"] :headers_ || headers_
          setVisibleColumns(dynamic_cols)
        setLoading(false);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false); // Ensure loading is set to false in the finally block
    }
  };

  const handleCurrentMonthClick = () => {
    setStartDate(null);
    setEndDate(null);
    const startOfMonth = dayjs().subtract(1, "month").date(dayjs().date()).format("YYYY-MM-DD");
    const endOfMonth = dayjs().format("YYYY-MM-DD");
    setActionHistoryCurrentMonth()
    fetchData(startOfMonth, endOfMonth);
  };
  const handleClickRangePicker = (range: any) => {
    if (!range) {
      // If range is null, clear both local state and store
      setStartDate(null);
      setEndDate(null);
      setCustomRange(null, null);
      return;
    }

    const [rangeStart, rangeEnd] = range;

    if (rangeStart && rangeEnd) {
      const formattedStart = rangeStart.format('YYYY-MM-DD');
      const formattedEnd = rangeEnd.format('YYYY-MM-DD');

      // Update local state with dayjs objects
      setStartDate(rangeStart);
      setEndDate(rangeEnd);

      // Update store with formatted strings
      setCustomRange(formattedStart, formattedEnd);

      // Fetch data with formatted dates
      fetchData(formattedStart, formattedEnd);
    }
  };
  useEffect(() => {
    handleCurrentMonthClick();
  }, []);
  const handleFilter = (advancedFilters: any) => {
    console.log(advancedFilters);
    setAdvancedFilters(advancedFilters)
  };

  const handleReset = (EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  };

  type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = (headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];

    entries.sort((a, b) => a[1][1] - b[1][1]);

    return Object.fromEntries(entries) as HeaderMap;
  };
  useEffect(() => {
    if (!loading) {
      console.log("Data Displayed in UI", getCurrentDateTime());
    }
  }, [loading]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "bold",
    padding: "16px",
  };

  function getStartDay() {
    const now = new Date();
    const startDay = new Date(now.getFullYear(), now.getMonth() - 1, now.getDate());
    return `${startDay.getFullYear()}-${String(startDay.getMonth() + 1).padStart(2, '0')}-${String(startDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getEndDay() {
    const now = new Date();
    return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} 23:59:59`;
  }

  const ExportWithoutSearch = async () => {

    try {
      // setExportLoading(true)
      // addExport(key, heading);

      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Request timed out"));
          }, timeout);

          promise
            .then((res) => {
              clearTimeout(timer);
              resolve(res);
            })
            .catch((err) => {
              clearTimeout(timer);
              reject(err);
            });
        });
      };
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const formattedStartDate = `${dayjs(startDateDailyReport).format("YYYY-MM-DD")} 00:00:00`;
      const formattedEndDate = `${dayjs(endDateDailyReport).format("YYYY-MM-DD")} 23:59:59`;
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/export_to_s3_bucket",
        role_name: role,
        parent_module: "Reports",
        module_name: "Actions History Report Export",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        feature_module_name: "Actions History Report",
        start_date: formattedStartDate,
        end_date: formattedEndDate,
        service_provider: "",
        billing_cycle_period: ""
      };
      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000); // Timeout of 10 seconds
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }

      // Wait for 20 seconds before polling
      await new Promise((resolve) => setTimeout(resolve, 20000));

      // Polling for the second API

      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      // setExportLoading(false);
    }
  }
  const pollExportStatus = async () => {
    const export_url = ENV_ROUTES.MODULE_MANAGEMENT;
    const export_data = {
      tenant_name: partner || "default_value",
      username,
      path: "/get_export_status",
      role_name: role,
      parent_module: "Reports",
      module_name: "Actions History Report Export",
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
      ... metaData,
      sessionID: sessionId,
    };
    try {
      const export_response = await axios.post(export_url, { data: export_data });
      const export_parsedData = JSON.parse(export_response.data.body);

      if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
        const s3Url = export_parsedData?.export_status_data?.url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
                          .then(response => response.blob())
                          .then(blob => {
                            const url = window.URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = 'Actions History Report.xlsx';
                            a.click();
                            a.remove();
                            window.URL.revokeObjectURL(url);
                            notification.success({
                              message: "Success",
                              description: "Successfully exported the record!",
                              style: messageStyle,
                              placement: "top",
                            });
                          })
                        .catch((err) => {
                          console.log("error",err)
                          Modal.error({
                            title: "Export Error",
                            content: "An error occurred while exporting data. Please try again.",
                            centered: true,
                          });
                        });
        } else {
          Modal.error({
            title: "Export Error",
            content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
        return true; // Stop polling
      }

      if (export_parsedData?.export_status_data?.status_flag === "Failure") {
        Modal.error({
          title: "Export Error",
          content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
        return true; // Stop polling
      }
      // Check for "No Data Found for export"
      if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
        Modal.info({
          title: "Export Information",
          content: "No Data Found for export",
          centered: true,
        });
        return true; // Stop polling
      }

      return false; // Continue polling
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
      return true; // Stop polling
    }
  };

  const startPolling = async () => {
    let isPollingComplete = false;

    while (!isPollingComplete) {
      isPollingComplete = await pollExportStatus();
      if (!isPollingComplete) {
        await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
      }
    }
  };


  const handleExport = async (key: string, heading: string) => {
    try {
      addExport(key, heading);
      let parsedData
      let url
      let data: any
      let response
      if (combineAdnvaceStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
          ... metaData,
          sessionID: sessionId,
          index_name: "action_history_report",
          module_name: "Actions History Report Export",
        };
        console.log("combineAdnvaceStoredpagination", data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
      else if (advancedStoredpagination && !storedpagination) {
        // setExportLoading(true)
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          module_name: "Actions History Report Export",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name: "action_history_report",
          pages: {
            start: 0,
            end: 100
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
          ... metaData,
          sessionID: sessionId,
          tenant_id: tenantId,
          // }
        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

      }
      else if (storedpagination && !advancedStoredpagination) {
        // setExportLoading(true)
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          module_name: "Actions History Report Export",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "action_history_report",
          search: "whole",
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
          ... metaData,
          sessionID: sessionId,
          tenant_id: tenantId,
        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

      }
      else {
        await ExportWithoutSearch();
      }

      if (advancedStoredpagination || storedpagination || combineAdnvaceStoredpagination) {
        if (parsedData.flag === true) {
          const s3Url = parsedData?.download_url || null;
          if (s3Url) {
            // window.location.href = s3Url;
            // // setExportLoading(false)
            // notification.success({
            //   message: 'Success',
            //   description: 'Successfully exported the record!',
            //   style: messageStyle,
            //   placement: 'top',
            // });
            fetch(s3Url)
                            .then(response => response.blob())
                            .then(blob => {
                              const url = window.URL.createObjectURL(blob);
                              const a = document.createElement('a');
                              a.href = url;
                              a.download = 'Actions History Report.xlsx';
                              a.click();
                              a.remove();
                              window.URL.revokeObjectURL(url);
                              notification.success({
                                message: "Success",
                                description: "Successfully exported the record!",
                                style: messageStyle,
                                placement: "top",
                              });
                            })
                          .catch((err) => {
                            console.log("error",err)
                            Modal.error({
                              title: "Export Error",
                              content: "An error occurred while exporting data. Please try again.",
                              centered: true,
                            });
                          });
          }
          else {
            // setExportLoading(false)
            Modal.error({
              title: "Export Error",
              content: parsedData.message || "An error occurred while exporting data. Please try again.",
              centered: true,
            });
          }
        }
        else {
          // setExportLoading(false)
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      }
    } catch (error) {
      await startPolling();
      // setExportLoading(false)
      // setLoading(false);
      // Modal.error({
      //   title: "Export Error",
      //   content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
      //   centered: true,
      // });
    } finally {
      // setExportLoading(false)
      removeExport(key);
    }
  };

  const disablePastOneYearDates = (current: any) => {
    const oneYearAgo = dayjs().subtract(1, "year").startOf("day"); // One year before today
    const today = dayjs().endOf("day"); // End of today

    return current && (current > today || current < oneYearAgo); // Disable dates outside the range
  };

  return (
    <Suspense
      fallback={
        <div className="flex justify-center items-center h-screen">
          <Spin size="large" />
        </div>
      }
    >
      <div className="relative">
        {/* Date Selection Buttons - Hidden on small screens */}
        <div className="hidden md:flex flex-col p-4 md:flex-row space-y-2 md:space-y-0 md:space-x-2 md:justify-end md:order-none order-first">
          <Button
            className={`${selectedButton === 'currentMonth' ? 'save-btn' : ''} min-h-[40px]`}
            onClick={() => {
              setSelectedButton("currentMonth");
              handleCurrentMonthClick();
              setIsDateModalOpen(false); // Close modal if open
            }}
          >
            Current Month
          </Button>
          <RangePicker
            format="YYYY-MM-DD"
            placeholder={["Start Date", "End Date"]}
            value={startDate && endDate ? [startDate, endDate] : [null, null]}
            style={{ width: "20%", marginLeft: "10px" }}
            onChange={(dates) => {
              setSelectedButton("customDate");
              handleClickRangePicker(dates);
              setIsDateModalOpen(false); // Close modal after selection
            }}
            disabledDate={disablePastOneYearDates}
            className={`${selectedButton === 'customDate' ? 'save-btn' : ''} min-h-[40px]`}
            popupClassName="custom-range-popup"
          />
        </div>
  
        {/* Search and Filter Section */}
        <div className="pr-4 pl-4 pt-2 flex md:flex-row md:items-center md:justify-between mt-1 mb-4 space-y-4">
          {/* Search and Advanced Filter Container */}
          <div className="flex space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last">
            {features.includes("Search-Actions History Report") && (
              <TableSearch
                searchTerm={searchTerm}
                setSearchTerm={setSearchTerm}
                tableName={"action_history_report"}
                headerMap={headerMap}
              />
            )}
            {features.includes("Advanced filter-Actions History Report") && (
              <AdvancedMultiFilter
                showAdvanced={showAdvanced}
                setShowAdvanced={setShowAdvanced}
                onFilter={handleFilter}
                onReset={handleReset}
                headers={headers}
                headerMap={headerMap}
                tableName={"action_history_report"}
              />
            )}
          </div>
          {/* Export and ColumnFilter Container */}
          <div className="hidden md:flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-first pb-2 md:pb-4">
            {features.includes("Export-Actions History Report") && (
              <button className="save-btn" onClick={() => handleExport("ActionsHistoryReport", "Actions History Report")}>
                <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-1" />
                <span>Export</span>
              </button>
            )}
            <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
            />
          </div>
        </div>
  
        {/* Table and Other Components */}
        <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
          <TableComponent
            headers={headers}
            headerMap={headerMap}
            initialData={tableData}
            searchQuery={searchTerm}
            visibleColumns={visibleColumns}
            itemsPerPage={100}
            popupHeading="Actions History Report"
            createModalData={createModalData}
            pagination={pagination}
            generalFields={generalFields}
            advancedFilters={filteredData}
            height={showAdvanced ? 360 : 300}
          />
        </div>
  
        {/* Sticky Footer for Small Screens */}
        <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
          {features.includes("Export-Actions History Report") && (
            <button className="save-btn" onClick={() => handleExport("ActionsHistoryReport", "Actions History Report")}>
              <ArrowDownTrayIcon className="h-5 w-5 text-black-500" />
            </button>
          )}
          <button className="save-btn" onClick={() => setIsDateModalOpen(true)} aria-label="Open date selection">
            <CalendarOutlined className="h-5 w-5 text-black-500" />
          </button>
          <ColumnFilter
            headers={headers}
            visibleColumns={visibleColumns}
            setVisibleColumns={setVisibleColumns}
            headerMap={headerMap}
          />
        </div>
  
        {/* Date Selection Modal for Small Screens */}
        <Modal
          title="Select Date Range"
          visible={isDateModalOpen}
          onCancel={() => setIsDateModalOpen(false)}
          footer={null}
          centered
        >
          <div className="flex flex-col space-y-2">
            <Button
              className={`${selectedButton === 'currentMonth' ? 'save-btn' : ''} min-h-[40px]`}
              onClick={() => {
                setSelectedButton("currentMonth");
                handleCurrentMonthClick();
                setIsDateModalOpen(false);
              }}
            >
              Current Month
            </Button>
            <RangePicker
              format="YYYY-MM-DD"
              placeholder={["Start Date", "End Date"]}
              value={startDate && endDate ? [startDate, endDate] : [null, null]}
              onChange={(dates) => {
                setSelectedButton("customDate");
                handleClickRangePicker(dates);
                setIsDateModalOpen(false);
              }}
              disabledDate={disablePastOneYearDates}
              popupClassName="custom-range-popup"
              className={`${selectedButton === 'customDate' ? 'save-btn' : ''} min-h-[40px] w-full`}
            />
          </div>
        </Modal>
      </div>
    </Suspense>
  );
 

};
export default ActionsHistoryReport;
