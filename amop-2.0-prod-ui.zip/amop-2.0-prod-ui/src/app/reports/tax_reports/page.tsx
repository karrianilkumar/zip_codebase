"use client";

import { TRANSACTION_CATEGORY } from "@/common/constants/report-constant";
import { FileSyncOutlined } from "@ant-design/icons";
import {
  Button,
  Card,
  Flex,
  Space,
  Statistic,
  Tabs,
  TabsProps,
  Typography,
} from "antd";
import { RequestExportReportModal } from "./components/request-export-report-modal";
import { useExportTaxReportStore } from "./components/request-export-report-modal.store";
import { TaxReportTable } from "./components/tax-report-table";
import { useTaxReportStore } from "./components/tax-reports.store";
import { useCommonFeatureStore } from "@/stores/common-feature-store";
import { ReportFeaturesTaxReportsFeatures } from "@/common/enums/module-feature-enum";

export default function TaxReportsIndex() {
  const { hasFeature } = useCommonFeatureStore();
  const openExportModal = useExportTaxReportStore((state) => state.openModal);
  const {
    selectedTab,
    setSelectedTab,
    totalTransaction,
    totalAmount,
    isFetching,
  } = useTaxReportStore();

  const tabs: TabsProps["items"] = [
    {
      key: TRANSACTION_CATEGORY.ACTUAL_TRANSACTION,
      label: "Tax Transaction",
      children: <TaxReportTable />,
    },
    {
      key: TRANSACTION_CATEGORY.TAX_CALCULATION,
      label: "Calculate Tax",
      children: <TaxReportTable />,
    },
  ].filter((tab) => {
    switch (tab.key) {
      case TRANSACTION_CATEGORY.ACTUAL_TRANSACTION:
        return hasFeature(ReportFeaturesTaxReportsFeatures.ActualTransaction);
      case TRANSACTION_CATEGORY.TAX_CALCULATION:
        return hasFeature(ReportFeaturesTaxReportsFeatures.Calculation);
      default:
        return true;
    }
  });

  return (
    <Flex vertical gap={8}>
      <Flex align="center" justify="space-between" wrap gap={8}>
        {hasFeature(ReportFeaturesTaxReportsFeatures.ReportRequest) && (
          <Button
            type={"primary"}
            size="large"
            icon={<FileSyncOutlined />}
            onClick={openExportModal}
          >
            Report Request
          </Button>
        )}

        <Space>
          <Card>
            <Statistic
              title={`${selectedTab === TRANSACTION_CATEGORY.ACTUAL_TRANSACTION ? "Transaction" : "Tax Calculation"} (Last 30 days)`}
              value={totalTransaction}
              loading={isFetching}
            />
          </Card>

          <Card>
            <Statistic
              title={"Total Amount (Last 30 days)"}
              value={totalAmount}
              loading={isFetching && !totalAmount}
              prefix={"$"}
              precision={2}
            />
          </Card>
        </Space>
      </Flex>

      <div className="flex-auto overflow-auto">
        <Typography.Title level={4}>
          Monthly Transaction History
        </Typography.Title>

        <Tabs
          items={tabs}
          onChange={(key) => setSelectedTab(key as TRANSACTION_CATEGORY)}
        />
      </div>

      {hasFeature(ReportFeaturesTaxReportsFeatures.ReportRequest) && (
        <RequestExportReportModal />
      )}
    </Flex>
  );
}
