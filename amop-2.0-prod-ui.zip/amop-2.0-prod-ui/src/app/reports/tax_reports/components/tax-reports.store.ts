import { TRANSACTION_CATEGORY } from "@/common/constants/report-constant";
import { create } from "zustand";

export type TaxReportStore = {
  selectedTab: TRANSACTION_CATEGORY;
  totalTransaction: number;
  isFetching: boolean;
  totalAmount: number;
};
export type TaxReportAction = {
  setSelectedTab: (tab: TRANSACTION_CATEGORY) => void;
  setTotalTransaction: (totalTransaction: number) => void;
  setIsFetching: (isFetching: boolean) => void;
  setTotalAmount: (totalAmount: number) => void;
};

const initialState: TaxReportStore = {
  selectedTab: TRANSACTION_CATEGORY.ACTUAL_TRANSACTION,
  totalTransaction: 0,
  isFetching: true,
  totalAmount: 0,
};

export const useTaxReportStore = create<TaxReportStore & TaxReportAction>(
  (set) => ({
    ...initialState,
    setSelectedTab: (tab) => set({ selectedTab: tab }),
    setTotalTransaction: (totalTransaction) => set({ totalTransaction }),
    setIsFetching: (isFetching) => set({ isFetching }),
    setTotalAmount: (totalAmount) => set({ totalAmount }),
  }),
);
