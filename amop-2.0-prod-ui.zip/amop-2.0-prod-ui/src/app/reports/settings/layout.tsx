import { PropsWithChildren } from "react";
import { FeatureFlagProvider } from "@/components/feature-flag/feature-flag-provider";
import {
  ModuleFeatures,
  ReportFeatures,
} from "@/common/enums/module-feature-enum";

export default function SettingReportsLayout(props: PropsWithChildren) {
  return (
    <div className="p-4 adm-wrapper">
      <FeatureFlagProvider
        parentModule={ModuleFeatures.Reports}
        module={ReportFeatures.ReportSettings}
      >
        {props.children}
      </FeatureFlagProvider>
    </div>
  );
}
