"use client";

import React, {
  useEffect,
  useState,
  lazy,
  Suspense,
  useRef,
  useCallback,
} from "react";
import { ArrowDownTrayIcon } from "@heroicons/react/24/outline";
import { Modal, Spin, DatePicker, notification } from "antd";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import dayjs, { Dayjs } from "dayjs";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import * as XLSX from "xlsx";
// import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import OptimizationTableComponent from "@/app/components/optimizationTableComponent/page";
import InventoryTableComponent from "@/app/components/inventoryTableComponent/page";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { useCustomerRatePlanStore } from "@/app/stores/customerRateplanStore";
type ExportData = {
  path: string;
  username: string | null;
  module_name: string;
  request_received_at: string;
  start_date: string;
  end_date: string;
  Partner: string | null;
  access_token: string | null;
  db_name: string | null;
};

const { RangePicker } = DatePicker;
const TableComponent = lazy(
  () => import("@/app/components/TableComponent/page")
);
// const CreateModal = lazy(() => import("@/app/components/createPopup"));
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));
const TableSearch = lazy(() => import("@/app/components/entire_table_search"));
const AdvancedMultiFilter = lazy(
  () => import("@/app/components/advanced_search")
);

const SimManagementInventory: React.FC = () => {
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, token, selectedDb,metaData,sessionId, settabledata, advancedStoredpagination, storedpagination, combineAdnvaceStoredpagination, tenantName, tenantId, firstLastName , setStoredPagination , setAdvancedStoredPagination, setCombineAdnvaceStoredpagination,dynamicColumns,setDynamicColumns} = useAuth();
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([
    null,
    null,
  ]);
  const [loading, setLoading] = useState(false);
  // const [exportLoading, setExportLoading] = useState(false);
  const { addExport, removeExport, exports } = exportLoadingStore();
  const exportKey = "Inventory";
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [dynamicColumnsKey,setDynamicColumnsKey]=useState<any>("SimManagement Inventory")
  // const { showAdvanced, setShowAdvanced} = useCustomerRatePlanStore();
  const hasFetchedData = useRef(false);
  const {
    iccid,
    bulkRow,
    features: moduleFeatures,
    setFeatures: setModuleFeatures,
    setICCID,
    setBulkRow
  } = useFeatureStore();
  // const queryClient = useQueryClient();

  type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);

  //Remove columns based on role
    useEffect(() => {
      if (
        role?.toLowerCase() !== "super admin" &&
        role?.toLowerCase() !== "partner admin"
      ) {
        let headersToRemove: string[] = [];
      
        if (role?.toLowerCase() === "agent partner admin") {
          headersToRemove = [
            "communication plan",
            "carrier data allocation mb",
            "carrier rate plan display rate",
            "billing account no",
            "foundation account number",
          ];
        } else {
          headersToRemove = [
            "rate plan",
            "communication plan",
            "carrier data allocation mb",
            "carrier rate plan display rate",
            "billing account no",
            "foundation account number",
            "carrier cycle usage",
          ];
        }
      
        const removeHeaderList = Object.keys(headerMap).filter((key) =>
          headersToRemove.includes(headerMap[key][0]?.toLowerCase())
        );
      
        setHeaders((prevHeaders) =>
          prevHeaders.filter((header) => !removeHeaderList.includes(header))
        );
      }
      // if (role?.toLowerCase() === "agent") {
      //   const removeHeaderList = Object.keys(headerMap).filter(
      //     (key) =>
      //       ["billing account no","foundation account number"].includes(
      //         headerMap[key][0]?.toLowerCase()
      //       )
      //   );
    
      //   setHeaders((prevHeaders) =>
      //     prevHeaders.filter((header) => !removeHeaderList.includes(header))
      //   );
      // }
    }, [role,headerMap]);

    useEffect(() => {
      console.log("dynamicColumnsKey",dynamicColumnsKey)
          setDynamicColumns((prev:any)=>({...prev,[dynamicColumnsKey]:visibleColumns}))
        }, [visibleColumns]);

  const fetchData = async () => {
    localStorage.removeItem('bulk_row');
    setBulkRow(null)
    setICCID("");
    localStorage.removeItem('iccid');
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    setCombineAdnvaceStoredpagination(null)
    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_inventory_data",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "SimManagement Inventory",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        feature_module_name: "Inventory",
      };

      const response = await axios.post(url, { data });
      parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === true) {
        // Log data and set loading to false immediately to stop the loader
        console.log("table response:", getCurrentDateTime());
        setLoading(false); // Ensure this happens right away

        // Defer other state updates using a timeout to decouple them from the main thread
        setTimeout(() => {
          const inventoryType: "SimManagement Inventory" | "Cross Carrier Inventory" | null = parsedData?.header_map?.["SimManagement Inventory"] 
          ? "SimManagement Inventory"
          : parsedData?.header_map?.["Cross Carrier Inventory"]
          ? "Cross Carrier Inventory"
          : null;
          setDynamicColumnsKey(inventoryType)
          if(inventoryType){

          const headersMap_ = parsedData?.header_map?.[inventoryType]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);

          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
          console.log("headers", headers_)
          setHeaders(headers_);
          const dynamic_cols=dynamicColumns?.[inventoryType]&& dynamicColumns[inventoryType].length>0 ?dynamicColumns[inventoryType] :headers_ || headers_
          setVisibleColumns(dynamic_cols)
          setFeatures(parsedData?.header_map?.[inventoryType]?.module_features || []);
          setModuleFeatures(parsedData?.header_map?.[inventoryType]?.module_features || []);
          setPagination(parsedData?.pages || {});
          setTableData(parsedData?.inventory_data || []);
          }else{
            console.log("inventory type is not defined")
          }

          // Defer heavy state updates to allow the UI to remain responsive
          // setTimeout(() => {
          //   setTableData(parsedData?.inventory_data || []);
          // }, 0);
        }, 0);
        // requestIdleCallback(() => {
        //   setTableData(parsedData?.inventory_data || []);
        //   console.log("table response:", getCurrentDateTime());
        // });
      } else {
        setLoading(false);
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (!hasFetchedData.current) {
      fetchData();
      hasFetchedData.current = true;
    }
  }, [fetchData]);

  const exportToExcel = (headers: any, rowData: any, fileName = 'exported_data.xlsx') => {
    // Map the rowData to an array of objects with headers as keys
    const formattedData = rowData.map((row: any) => {
      const formattedRow: any = {};
      headers.forEach((header: any) => {
        formattedRow[header] = row[header] !== undefined ? row[header] : null;
      });
      return formattedRow;
    });

    // Create a new worksheet from the formatted data
    const worksheet = XLSX.utils.json_to_sheet(formattedData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Sheet1');

    // Write the workbook and trigger download
    XLSX.writeFile(workbook, fileName);
  };

  const handleFilter = useCallback((advancedFilters: any) => {
    console.log(advancedFilters);
    setAdvancedFilters(advancedFilters)
  }, []);

  const handleReset = useCallback((EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  }, []);

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "bold",
    padding: "16px",
  };

  const handleExportModalOpen = () => {
    setExportModalOpen(true);
  };

  const handleExportModalClose = () => {
    setExportModalOpen(false);
    console.log("Modal closed, resetting date range.");
  };

  // const handleExport = async () => {
  //   if (!dateRange || dateRange[0] === null || dateRange[1] === null) {
  //     Modal.error({ title: "Error", content: "Please select a date range." });
  //     return;
  //   }

  //   const [startDate, endDate] = dateRange;
  //   const exportData: ExportData = {
  //     path: "/export",
  //     username: username,
  //     module_name: "SimManagement Inventory",
  //     request_received_at: getCurrentDateTime(),
  //     start_date: startDate.format("YYYY-MM-DD 00:00:00"),
  //     end_date: endDate.format("YYYY-MM-DD 23:59:59"),
  //     Partner: partner,
  //     access_token: token,
  //     db_name: selectedDb,
        // ... metaData,
  //   };

  //   try {
  //     const url = ENV_ROUTES.MODULE_MANAGEMENT;
  //     const response = await axios.post(url, { data: exportData }, {
  //       headers: {
  //         "Content-Type": "application/json",
  //       },
  //     });
  //     const data = JSON.parse(response.data.body);

  //     if (data.flag === true) {
  //       notification.success({
  //         message: "Success",
  //         description: "Successfully exported the record!",
  //         placement: "top",
  //       });
  //       downloadBlob(data.blob);
  //     } else {
  //       Modal.error({
  //         title: "Export Error",
  //         content: data.message,
  //         centered: true,
  //       });
  //     }
  //     handleExportModalClose();
  //   } catch (error) {
  //     console.error("Error downloading the file:", error);
  //     Modal.error({
  //       title: "Export Error",
  //       content: "An error occurred while exporting the file. Please try again.",
  //     });
  //   }
  // };

  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }

  const ExportWithoutSearch = async () => {
  
    try {
      // Add the export to the store
      // addExport(exportKey, "Inventory");
  
      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Request timed out"));
          }, timeout);
  
          promise
            .then((res) => {
              clearTimeout(timer);
              resolve(res);
            })
            .catch((err) => {
              clearTimeout(timer);
              reject(err);
            });
        });
      };
  
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/export_to_s3_bucket",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "SimManagement Inventory",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        feature_module_name: "Inventory",
        start_date: getFirstDayOfCurrentMonth(),
        end_date: getLastDayOfCurrentMonth(),
      };
  
      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000);
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }
  
      // Wait for 20 seconds before polling
      await new Promise((resolve) => setTimeout(resolve, 20000));
  
      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      // removeExport(exportKey); // Remove the export from the store
    }
  };
  
  const pollExportStatus = async () => {
    const export_url = ENV_ROUTES.MODULE_MANAGEMENT;
    const export_data = {
      tenant_name: partner || "default_value",
      username,
      role_name: role,
      parent_module: "Sim Management",
      module_name: "SimManagement Inventory",
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
        ... metaData,
      sessionID: sessionId,
      feature_module_name: "Inventory",
      start_date: getFirstDayOfCurrentMonth(),
      end_date: getLastDayOfCurrentMonth(),
      path: "/get_export_status",
    };
      try {
        const export_response = await axios.post(export_url, { data: export_data });
        const export_parsedData = JSON.parse(export_response.data.body);

        if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
          const s3Url = export_parsedData?.export_status_data?.url || null;
          if (s3Url) {
            // window.location.href = s3Url;
            // notification.success({
            //   message: "Success",
            //   description: "Successfully exported the  record!",
            //   style: messageStyle,
            //   placement: "top",
            // });
            fetch(s3Url)
                            .then(response => response.blob())
                            .then(blob => {
                              const url = window.URL.createObjectURL(blob);
                              const a = document.createElement('a');
                              a.href = url;
                              a.download = 'Inventory.xlsx';
                              a.click();
                              a.remove();
                              window.URL.revokeObjectURL(url);
                              notification.success({
                                message: "Success",
                                description: "Successfully exported the record!",
                                style: messageStyle,
                                placement: "top",
                              });
                            })
                          .catch((err) => {
                            console.log("error",err)
                            Modal.error({
                              title: "Export Error",
                              content: "An error occurred while exporting data. Please try again.",
                              centered: true,
                            });
                          });
          } else {
            Modal.error({
              title: "Export Error",
              content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
              centered: true,
            });
          }
          return true; // Stop polling
        }

        if (export_parsedData?.export_status_data?.status_flag === "Failure") {
          Modal.error({
            title: "Export Error",
            content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
          return true; // Stop polling
        }
        if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
                  Modal.info({
                    title: "Export Error",
                    content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
                    centered: true,
                  });
                  return true; // Stop polling
                }

        return false; // Continue polling
      } catch (error) {
        Modal.error({
          title: "Export Error",
          content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
          centered: true,
        });
        return true; // Stop polling
      }
    };

    const startPolling = async () => {
      let isPollingComplete = false;

      while (!isPollingComplete) {
        isPollingComplete = await pollExportStatus();
        if (!isPollingComplete) {
          await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
        }
      }
    };

  const handleExport = async (key: string, heading: string) => {
    console.log("test", combineAdnvaceStoredpagination,advancedStoredpagination,storedpagination)
    try {
      addExport(key, heading);
  
      let parsedData;
      let url;
      let data: any;
      let response;

      if(combineAdnvaceStoredpagination){
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/export_inventory",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "inventory_export",
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
        ... metaData,
          sessionID: sessionId,
          module_name: "SimManagement Inventory",
        };
        console.log("combineAdnvaceStoredpagination",data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
  
      else if (advancedStoredpagination && !storedpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/export_inventory",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name: "inventory_export",
          module_name: "SimManagement Inventory",
          pages: { start: 0, end: 100 },
          partner,
          username: username,
          db_name: selectedDb,
        ... metaData,
          sessionID: sessionId,
          tenant_id: tenantId,
        };
        console.log("advancedStoredpagination",data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } 
      else if (storedpagination && !advancedStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/export_inventory",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "inventory_export",
          module_name: "SimManagement Inventory",
          search: "whole",
          pages: { start: 0, end: 100 },
          partner,
          username: username,
          db_name: selectedDb,
        ... metaData,
          sessionID: sessionId,
          tenant_id: tenantId,
        };
        console.log("storedpagination",data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } else {
        await ExportWithoutSearch();
        return;
      }
  
      if (parsedData.flag) {
        console.log("flag")
        const s3Url = parsedData?.download_url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the  record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
                          .then(response => response.blob())
                          .then(blob => {
                            const url = window.URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = 'Inventory.xlsx';
                            a.click();
                            a.remove();
                            window.URL.revokeObjectURL(url);
                            notification.success({
                              message: "Success",
                              description: "Successfully exported the record!",
                              style: messageStyle,
                              placement: "top",
                            });
                          })
                        .catch((err) => {
                          console.log("error",err)
                          Modal.error({
                            title: "Export Error",
                            content: "An error occurred while exporting data. Please try again.",
                            centered: true,
                          });
                        });
        } else {
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      } else {
        console.log("!flag")

        Modal.error({
          title: "Export Error",
          content: parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      console.log("catch")

      await startPolling()
      // Modal.error({
      //   title: "Export Error",
      //   content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
      //   centered: true,
      // });
    } finally {
      removeExport(key);
    }
  };
  

  const downloadBlob = (base64Blob: string) => {
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    const blobObject = new Blob([byteArray], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blobObject);
    link.download = "Inventory.xlsx";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }
  return (
    <>
      <Suspense
        fallback={
          <div className="flex justify-center items-center h-screen">
            <Spin size="large" />
          </div>
        }
      >
        <div className="relative">
        <div className="pr-4 pl-4  pt-2 flex  md:flex-row md:items-center md:justify-between mt-1 mb-4 space-y-4">
  {/* Search and Advanced Filter Container */}
  <div className="flex space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last ">
  {features.includes("Search-Inventory") && (
      <TableSearch
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        tableName={"Inventory"}
        headerMap={headerMap}
      />
    )}
    {features.includes("Advanced filter-Inventory") && (
      <AdvancedMultiFilter
        showAdvanced={showAdvanced}
        setShowAdvanced={setShowAdvanced}
        onFilter={handleFilter}
        onReset={handleReset}
        headers={headers}
        headerMap={headerMap}
        tableName={"Inventory"}
      />
    )}
    
  </div>

  {/* Export and ColumnFilter Container */}
  <div className="hidden md:flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2  md:order-none order-first pb-2 md:pb-4">
    {features.includes("Export inventory-Inventory") && (
      <button
        className="save-btn"
        onClick={() => {
          if (!exports.some((exportItem) => exportItem.popupHeading === "Inventory")) {
            handleExport("inventory", "Inventory");
          }
        }}
      >
        <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
        <span>Export</span>
      </button>
    )}
    <ColumnFilter
      headers={headers}
      visibleColumns={visibleColumns}
      setVisibleColumns={setVisibleColumns}
      headerMap={headerMap}
    />
  </div>
</div>
          <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
            <InventoryTableComponent
              headers={headers}
              headerMap={headerMap}
              initialData={tableData}
              searchQuery={searchTerm}
              visibleColumns={visibleColumns}
              itemsPerPage={100}
              allowedActions={["Actions"]}
              popupHeading="Inventory"
              pagination={pagination}
              advancedFilters={filteredData}
              height = {showAdvanced?280:230}
            />
          </div>
           {/* Sticky Footer for Small Screens */}
           <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
            
           {features.includes("Export inventory-Inventory") && (
              <button
                className="save-btn"
                onClick={() => {
                  if (!exports.some((exportItem) => exportItem.popupHeading === "Inventory")) {
                    handleExport("inventory", "Inventory");
                  }
                }}
              >
                <ArrowDownTrayIcon className="h-5 w-5 text-black-500" />
              </button>
            )}
            <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
            />
          </div>

          {/* {exportLoading && (
            <div className="export-processing-div">
              Export processing...
            </div>
          )} */}
        </div>
      </Suspense>
    </>
  );
};

export default SimManagementInventory;
