import create from "zustand";

interface UserState {
  features: any[];
  setFeatures: (features: any[]) => void;
  rowId: any;
  setRowId: (rowId: any) => void;
  bulkRow: any;
  setBulkRow: (bulkRow: any) => void;
  iccid: any;
  setICCID: (iccid: any) => void;
  activationPayload: any;
  setsetActivationPayload: (iccid: any) => void;
  bulkChangeLimit: number;
  setBulkChangeLimit: (bulkChangeLimit: number) => void;
  simIdentifierMap: any;
  setSimIdentifierMap: (simIdentifierMap: any) => void;
}

export const useFeatureStore = create<UserState>((set) => ({
  features: [],
  setFeatures: (features) => set({ features }),
  rowId: "",
  setRowId: (rowId) => set({ rowId }),
  bulkRow: null,
  setBulkRow: (bulkRow) => set({ bulkRow }),
  iccid: "",
  setICCID: (iccid) => set({ iccid }),
  activationPayload: { iccid: [], imei: [], Devices: [], },
  setsetActivationPayload: (activationPayload) => set({ activationPayload }),
  bulkChangeLimit: 5000,
  setBulkChangeLimit: (bulkChangeLimit) => set({ bulkChangeLimit }),
  simIdentifierMap: [],
  setSimIdentifierMap: (simIdentifierMap) => set({ simIdentifierMap }),
}));
