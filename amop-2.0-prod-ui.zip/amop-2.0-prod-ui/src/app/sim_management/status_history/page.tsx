"use client";

import React, { useEffect, useState, lazy, Suspense, useRef } from "react";
import {
  PlusIcon,
  ArrowDownTrayIcon,
  ArrowLeftIcon,
} from "@heroicons/react/24/outline";
import { Button, Modal, Spin, DatePicker, notification } from "antd";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { useLogoStore } from "@/app/stores/logoStore";
import { getCurrentDateTime } from "@/app/components/header_constants";
import dayjs, { Dayjs } from "dayjs";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { useRouter } from "next/navigation";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useCustomerRatePlanStore } from "@/app/stores/customerRateplanStore";

const { RangePicker } = DatePicker;
//Lazy loading components
const TableComponent = lazy(
  () => import("@/app/components/TableComponent/page")
);
const CreateModal = lazy(() => import("@/app/components/createPopup"));
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));
const TableSearch = lazy(() => import("@/app/components/entire_table_search"));
const AdvancedMultiFilter = lazy(
  () => import("@/app/components/advanced_search")
);

const StatusHistory: React.FC = () => {
  const [isCreateModalOpen, setCreateModalOpen] = useState(false);
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [newRowData, setNewRowData] = useState<any>({});
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, settabledata, token, selectedDb, metaData,firstLastName, sessionId, setAdvancedStoredPagination, setCombineAdnvaceStoredpagination, setStoredPagination ,dynamicColumns,setDynamicColumns} = useAuth();
  const [loading, setLoading] = useState(false);
  const title = useLogoStore((state) => state.title);
  const [pagination, setpagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [createModalData, setCreateModalData] = useState<any[]>([]);
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([
    null,
    null,
  ]);
  const [filteredData, setFilteredData] = useState([]);
  const rowId :any= localStorage.getItem('row_id') || '0';
  const [showAdvanced, setShowAdvanced] = useState(false);
    // const {showAdvanced, setShowAdvanced} = useCustomerRatePlanStore();

  const router = useRouter();
  const iccid :any= localStorage.getItem('iccid') || '0';


  const handleFilter = (advancedFilters: any) => {
    console.log(advancedFilters);
  };
  const handleReset = (EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  };
  const handleBackNavigation = (EmptyFilters: any) => {
    router.push(`/sim_management/inventory`);
  };

  type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = (headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];

    entries.sort((a, b) => a[1][1] - b[1][1]);

    return Object.fromEntries(entries) as HeaderMap;
  };

  useEffect(() => {
        setDynamicColumns((prev:any)=>({...prev,"inventory status history":visibleColumns}))
      }, [visibleColumns]);

  useEffect(() => {
    console.log("rowid", rowId);
    setAdvancedStoredPagination(null)
    setStoredPagination(null)
    setCombineAdnvaceStoredpagination(null)
    settabledata([])
    const fetchData = async () => {
      setLoading(true);
      try {
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/get_status_history",
          role_name: role,
          module_name: "inventory status history",
          mod_pages: {
            start: 0,
            end: 100,
          },
          access_token: token,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          list_view_data_id: rowId,
          iccid:iccid,
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        console.log(getCurrentDateTime(),"Show the log time response sent from lambda to ui");
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching History. Please try again.",
            centered: true,
          });
        } else {
          console.log("parsed", parsedData);
          const headersMap_ =
            parsedData?.header_map?.["inventory status history"]?.header_map ||
            {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);
          const headers_ =
            Object.keys(sortedheaderMap).length > 0
              ? Object.keys(sortedheaderMap)
              : [];
          setHeaders(headers_);
     const dynamic_cols=dynamicColumns?.["inventory status history"]&& dynamicColumns["inventory status history"].length>0 ?dynamicColumns["inventory status history"] :headers_ || headers_
      setVisibleColumns(dynamic_cols)
          setVisibleColumns(dynamic_cols)
          const tableData_ = parsedData?.status_history_data || [];
          setTableData(tableData_);
          const pagination_ = parsedData?.pages || {};
          setpagination(pagination_);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        Modal.error({
          title: "Data Fetch Error",
          content:
            error instanceof Error
              ? error.message
              : "An unexpected error occurred while History. Please try again.",
          centered: true,
        });
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [username, partner, role]);

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "bold",
    padding: "16px",
  };

  const handleExportModalOpen = () => {
    setExportModalOpen(true);
  };

  const handleExportModalClose = () => {
    setExportModalOpen(false);
    console.log("Modal closed, resetting date range."); // Debug log
  };

  const handleExport = async () => {
    const [startDate, endDate] = dateRange;

    const data = {
      path: "/export",
      username: username,
      firstLastName: firstLastName,
      // table: "",
      module_name: "inventory status history",
      request_received_at: getCurrentDateTime(),
      ids: rowId,
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
    };

    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const response = await axios.post(
        url,
        { data: data },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );

      const resp = JSON.parse(response.data.body);
      const blob = resp.blob;
      console.log(resp);
      // Close the modal after exporting
      if (response.data.statusCode === 200) {
        if (resp.flag === true) {
          notification.success({
            message: "Success",
            description: "Successfully exported the record!",
            style: messageStyle,
            placement: "top",
          });

          // Trigger the download after a successful export
          downloadBlob(blob);
        } else {
          // Log and show error message
          console.log("Error message:", resp.message);
          Modal.error({
            title: "Export Error",
            content: resp.message,
            centered: true,
          });
        }
      } else {
        // Handle unexpected status codes
        console.log("Unexpected status code:", response.data.statusCode);
        Modal.error({
          title: "Export Error",
          content: resp.message,
          centered: true,
        });
      }

      handleExportModalClose();
    } catch (error) {
      // console.error("Error downloading the file:", error);
      // Modal.error({ title: 'Export Error', content: 'An error occurred while exporting the file. Please try again.' });
    }
  };

  const downloadBlob = (base64Blob: string) => {
    // Decode the Base64 string
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    const blobObject = new Blob([byteArray], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blobObject);
    link.download = "Status History.xlsx"; // Set the file name to .xlsx
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  useEffect(() => {
    if (!loading) {
      console.log("Data Displayed in UI", getCurrentDateTime());
    }
  }, [loading]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  const disableFutureDates = (current: any) => {
    console.log("future dates:", current && current > dayjs().endOf("day"));
    return current && current > dayjs().endOf("day"); // Disable future dates
  };



  return (
    <Suspense
      fallback={
        <div className="flex justify-center items-center h-screen">
          <Spin size="large" />
        </div>
      }
    >
      <div className="relative">
        <div className="justify-start flex p-4">
          <button
            className="border-none flex mr-2"
            onClick={handleBackNavigation}
          >
            <ArrowLeftIcon className="h-5 w-5 text-black-500 mr-2" />
            <span>Back</span>
          </button>
          <span className="font-semibold text-gray-800 font-[18px]">
            Inventory Change History
          </span>
        </div>
        <div className="flex space-x-2"></div>
        <div className="p-4 flex md:flex-row md:items-center md:justify-between mt-1 mb-4 space-y-6 md:space-y-0">
  {/* Search and Advanced Filter Container */}
  <div className="flex  space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last">
            <TableSearch
              searchTerm={searchTerm}
              setSearchTerm={setSearchTerm}
              tableName={"status_history"}
              headerMap={headerMap}
            />
            <AdvancedMultiFilter
              showAdvanced={showAdvanced}
              setShowAdvanced={setShowAdvanced}
              onFilter={handleFilter}
              onReset={handleReset}
              headers={headers}
              headerMap={headerMap}
              tableName={"status_history"}
            />
          </div>
               {/* Export and ColumnFilter Container */}
               <div className="hidden md:flex flex-col pb-4 md:flex-row space-y-2 md:space-y-0 md:space-x-2 md:order-none order-first">
            <button className="save-btn" onClick={handleExport}>
              <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
              <span>Export</span>
            </button>
            <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
            />
          </div>
        </div>
        <div className=" mb-4 space-x-2"></div>
        <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
          <TableComponent
            headers={headers}
            headerMap={headerMap}
            initialData={tableData}
            searchQuery={searchTerm}
            visibleColumns={visibleColumns}
            itemsPerPage={100}
            popupHeading="status change history"
            createModalData={createModalData}
            pagination={pagination}
            advancedFilters={filteredData}
            height = {showAdvanced?330:280}
          />
        </div>
          {/* Sticky Footer for Small Screens */}
          <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
          <button className="save-btn" onClick={handleExport}>
              <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
            </button>
            <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
            />
          </div>
        {/* Export Modal*/}
        {/* <Modal
          title="Export Output"
          visible={isExportModalOpen}
          onCancel={() => {
            handleExportModalClose();
            setDateRange([null, null]);
          }}
          footer={null}
          centered
          afterClose={() => setDateRange([null, null])}
        >
          <div className="flex flex-col space-y-4">
            <span>Select Date Range:</span>
            <RangePicker
              value={dateRange[0] && dateRange[1] ? [dateRange[0], dateRange[1]] : null} 
              onChange={(dates) => {
                console.log("Selected dates:", dates); 
                if (dates && dates.length === 2) {
                  setDateRange([dates[0], dates[1]] as [Dayjs, Dayjs]);
                } else {
                  setDateRange([null, null]); 
                }
              }}
              format="YYYY-MM-DD"
              disabledDate={disableFutureDates}
            />
            <div className="flex justify-end space-x-2">
              <Button onClick={handleExportModalClose}>Cancel</Button>
              <Button type="primary" onClick={handleExport}>Export</Button>
            </div>
          </div>
        </Modal> */}
      </div>
    </Suspense>
  );
};

export default StatusHistory;
