import {
  exportTaxReportTransactions,
  getTaxReportTransactions,
} from "@/api/tax-api";
import { AmopDataGrid, useAmopDataGridStates } from "@/components/data-grid";
import { DownloadOutlined } from "@ant-design/icons";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Button, notification } from "antd";
import { AxiosResponse } from "axios";
import { taxReportColumns } from "../tax-report.columns";
import { useTaxReportStore } from "./tax-reports.store";
import { FC, useEffect } from "react";
import { useCommonFeatureStore } from "@/stores/common-feature-store";
import { ReportFeaturesTaxReportsFeatures } from "@/common/enums/module-feature-enum";

interface TaxReportTableProps {}

export const TaxReportTable: FC<TaxReportTableProps> = () => {
  const { hasFeature } = useCommonFeatureStore();
  const { selectedTab, setTotalTransaction, setTotalAmount, setIsFetching } =
    useTaxReportStore();
  const [tableStates, { onChange, onSearch }] = useAmopDataGridStates<any>({
    page: 1,
    pageSize: 10,
    filters: {},
    sorter: [],
  });

  const { data, isFetching, isError } = useQuery({
    queryKey: [
      "tax-reports",
      "transactions",
      tableStates,
      selectedTab,
    ] as const,
    queryFn: async ({ queryKey }) => {
      const [, , query, selectedTab] = queryKey;
      const result = await getTaxReportTransactions({
        page: query.page,
        limit: query.pageSize,
        category: selectedTab,
      });

      if (result) {
        setTotalTransaction(result.totalResults);
        setTotalAmount(result.totalAmount);
      }

      return result;
    },
    initialData: () => ({
      results: [],
      totalResults: 0,
    }),
  });

  const { mutateAsync: exportTransaction, isPending: isExporting } =
    useMutation({
      mutationFn: async () => {
        const res = await exportTaxReportTransactions();
        downloadFile(res);
      },
      onSuccess: () => {
        notification.success({
          message: "Export Success",
          description: "The report has been exported",
        });
      },
      onError: (error) => {
        notification.error({
          message: "Export Failed",
          description: `Error: ${error}`,
        });
      },
    });

  useEffect(() => {
    if (isError) {
      notification.error({
        message: "Error",
        description: "Error fetching tax report transactions",
      });
    }
  }, [isError]);

  useEffect(() => {
    setIsFetching(isFetching);
  }, [isFetching, setIsFetching]);

  const actionButtons = hasFeature(ReportFeaturesTaxReportsFeatures.Export) ? (
    <Button
      data-testid="export-button"
      size="large"
      onClick={() => exportTransaction()}
      icon={<DownloadOutlined />}
      loading={isExporting}
      className="save-btn"
      type="primary"
    >
      Export
    </Button>
  ) : undefined;

  return (
    <AmopDataGrid
      tableLayout="fixed"
      rowSelection={undefined} // disable row selection
      columns={taxReportColumns}
      data={data.results}
      total={data.totalResults}
      pageSize={tableStates.pageSize}
      currentPage={tableStates.page}
      onChange={onChange}
      onSearch={onSearch}
      loading={isFetching}
      tableName={"Tax Reports"}
      actions={actionButtons}
      showSearchBox={false}
      sticky={{
        offsetHeader: 64,
      }}
      scroll={{ x: 1200 }}
    />
  );
};

function downloadFile(response: AxiosResponse) {
  const url = window.URL.createObjectURL(new Blob([response.data]));
  const link = document.createElement("a");
  const contentDisposition = response.headers["Content-Disposition"];
  const fileName = contentDisposition
    ? contentDisposition.split("filename=")[1]
    : "tax-report.xlsx";

  link.setAttribute("download", fileName);
  link.href = url;
  link.click();

  link.remove();
}
