"use client";
import React, { useEffect, useState } from "react";
import { Modal, Input, Checkbox, Spin, Switch, DatePicker } from "antd";
import Select from "react-select";
import { InformationCircleIcon } from "@heroicons/react/24/outline";
import { useAuth } from "@/app/components/auth_context";
import { NonEditableDropdownStyles } from "@/app/components/css/dropdown";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";

interface FormData {
  optimization_type?: string;
  plan_mb?: string;
  rate_plan_name?: string;
  base_rate?: string;
  rate_charge_amt?: string;
  is_billing_advance_eligible?: boolean;
  overage_rate_cost?: string;
  data_per_overage_charge?: string;
  min_plan_data_mb?: string;
  max_plan_data_mb?: string;
  service_provider_name?: string;
  rate_plan_code?: string;
  allows_sim_pooling?: boolean;
  sms_rate?: string;
  automation_rule?: string;
  is_active?: boolean;
  soc_code?: string | null;
  product?: string[] | null;
  package?: string | null;
  service_type?: string | null;

}

interface InfoCustomerRatePlanModalProps {
  isOpen: boolean;
  onClose: () => void;
  generalFields: any; // This will contain service_provider_name and soc_list
  rowData: any; // Add rowData prop to receive data for displaying
}

const InfoCustomerRatePlan: React.FC<InfoCustomerRatePlanModalProps> = ({
  isOpen,
  onClose,
  generalFields,
  rowData,
}) => {
  const modalHeight =
    typeof window !== "undefined" ? (window.innerHeight * 2.8) / 4 : 0;

  // Convert service provider names into the format expected by Select
  const providerOptions =
    generalFields.service_provider_name?.map((provider: string) => ({
      label: provider,
      value: provider,
    })) || [];

  // Convert combined_soc_code names into the format expected by Select
  const socCodeOptions =
    generalFields.soc_code?.map((code: string) => ({
      label: code,
      value: code,
    })) || [];

  // Convert automation rules into the format expected by Select
  const automationRuleOptions =
    generalFields.automation_rule?.map((rule: string) => ({
      label: rule,
      value: rule,
    })) || [];
  console.log(rowData, "Show the rowdata");
  console.log("is_active value:", rowData.is_active, "Type:", typeof rowData.is_active);
  //BP Integration state variables
  const [isBPEnabled, setIsBPEnabled] = useState(false);
  const [productsMap, setProductsMap] = useState<any[]>([]);
  const [packageMap, setPackageMap] = useState<any[]>([]);
  const [serviceTypeMap, setServiceTypeMap] = useState<any[]>([]);
  const [productsRateMap, setProductsRateMap] = useState<any[]>([]);
  const [productsOptions, setProductsOptions] = useState<any[]>([]);
  const [packageOptions, setPackageOptions] = useState<any[]>([]);
  const [serviceTypeOptions, setServiceTypeOptions] = useState<any[]>([]);
  const [selectedRates, setSelectedRates] = useState<any[]>([]);
  const [selectedPackage, setSelectedPackage] = useState(null);
  const [selectedserviceType, setSelectedServiceType] = useState(null);
  const [selectedProduct, setSelectedProduct] = useState<any>([]);
  const [useCarrierActivation, setUseCarrierActivation] = useState(true);
  const [activationDate, setActivationDate] = useState(null);
  const providerName = (rowData?.service_provider_name === "string" && rowData?.service_provider_name).toLowerCase() || "";
  const { username, token, partner, selectedDb,metaData,selectedBillingDb, role, settabledata, firstLastName, sessionId } = useAuth();


  const fetchProductsPackageData = async () => {
    const tenant_id_ = localStorage.getItem("tenant_id") || "0";
    try {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/fetch_product_package_data",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Active Customer Rate Plan",
        feature_module_name: "Customer Rate Plans",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
       db_name: selectedDb,
        ...metaData,
        billing_db_name: selectedBillingDb,
        sessionID: sessionId,
         tenant_id:tenant_id_
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        const product_rate = parsedData?.data?.product_rate || []
        setProductsRateMap(product_rate)
        const product = parsedData?.data?.product || []
        setProductsMap(product)
        const products_options = product.map((product: any) => ({ label: `${product?.description} -- ${product?.product_id}` || "", value: `${product?.description} -- ${product?.product_id}` || "" }))
        setProductsOptions(products_options)
        const package_ = parsedData?.data?.package || []
        setPackageMap(package_)
        const package_options = package_.map((opt: any) => ({ label: `${opt?.category} -- ${opt?.package_id}` || "", value: `${opt?.category} -- ${opt?.package_id}` || "" }))
        setPackageOptions(package_options)
        const service_type_map = parsedData?.data?.service_types || []
        setServiceTypeMap(package_)
        const service_type_options = service_type_map.map((opt: any) => ({ label: `${opt?.description} -- ${opt?.service_type_id}` || "", value: `${opt?.description} -- ${opt?.service_type_id}` || "" }))
        setServiceTypeOptions(service_type_options)
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
    }
  };

  const fetchData = async () => {
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_cross_provider_optimization_status",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Active Customer Rate Plan",
        feature_module_name: "Customer Rate Plans",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
       db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        const billing_plaform_flag = parsedData?.billing_platform_flag || false
        setIsBPEnabled(billing_plaform_flag)
        if (billing_plaform_flag) {
          fetchProductsPackageData()
        }
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchData()
    }
  }, [isOpen])

  useEffect(() => {
    const selectedPackage: any = rowData["package"] || "";
    const selectedProducts: any = rowData["product"] || [];

    if (selectedPackage) {
      const matchedItem = packageMap.find(
        (item: any) => `${item?.category} -- ${item?.package_id}` === selectedPackage
      );
      console.log("matchedItem", matchedItem)
      const matchedProductList = matchedItem ? matchedItem?.products_list : [];
      console.log("matchedProductList", matchedProductList)

      const matchedRates = productsRateMap.filter((product: any) =>
        matchedProductList.some(
          (option: any) => option?.description === product?.description
        )
      );
      console.log("matchedRates", matchedRates)

      setSelectedPackage(selectedPackage);
      setSelectedRates(matchedRates)
      setSelectedProduct([]);
    }
    else if (selectedProducts.length > 0) {
      const matchedRates = productsRateMap.filter((product: any) =>
        selectedProducts.some(
          (option: any) => option === `${product?.description} -- ${product?.product_id}`
        )
      );

      setSelectedRates(matchedRates);
      setSelectedProduct(selectedProducts);
      setSelectedPackage(null);
    }
    else {
      console.log("else condition")
      setSelectedPackage(null);
      setSelectedProduct([]);
      setSelectedRates([])
    }

  }, [rowData["package"], rowData["product"], packageMap, productsRateMap])

  return (
    <Modal
      title="Customer Rate Plan Details"
      open={isOpen}
      onCancel={onClose}
      centered
      width={800}
      footer={null} // No footer buttons
    >
      <div
        style={{
          height: modalHeight,
          overflowY: "auto",
          overflowX: "hidden",
          padding: "4px",
        }}
      >
        <div className="flex flex-col space-y-4">
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
            <div>
              <label className="field-label">
                Optimization Type
              </label>
              <Select
                className="w-full"
                styles={NonEditableDropdownStyles}
                isDisabled={true}
                value={
                  rowData?.optimization_type
                    ? {
                      label: rowData?.optimization_type,
                      value: rowData?.optimization_type,
                    }
                    : null
                }
                options={[
                  {
                    label: "Auto Change Rate Plan",
                    value: "Auto Change Rate Plan",
                  },
                  {
                    label: "Cross Customer Pooling",
                    value: "Cross Customer Pooling",
                  },
                ]}
              />
            </div>
            {rowData.optimization_type && (
              <>
                <div>
                  <label className="field-label">
                    MB Included
                  </label>
                  <Input
                    value={rowData?.plan_mb || ""}
                    className="non-editable-input"
                    readOnly
                  />
                </div>
                <div>
                  <label className="field-label">
                    Rate Plan Name
                  </label>
                  <Input
                    value={rowData?.rate_plan_name || ""}
                    className="non-editable-input"
                    readOnly
                  />
                </div>
                <div>
                  <label className="field-label">
                    Base Rate
                  </label>
                  <Input
                    value={rowData?.base_rate || ""}
                    className="non-editable-input"
                    readOnly
                  />
                </div>
                <div>
                  <label className="field-label">
                    Rate Charge
                  </label>
                  <Input
                    value={rowData?.rate_charge_amt || ""}
                    className="non-editable-input"
                    readOnly
                  />
                </div>
                <div>
                  <Checkbox
                    checked={rowData?.is_billing_advance_eligible === "True"}
                    className="checkbox"
                    disabled
                  >
                    Bill in Advance (Bills Rate Charge Separately from Overage)
                  </Checkbox>
                </div>
                <div>
                  <label className="field-label">
                    Overage Rate Cost
                  </label>
                  <Input
                    value={rowData?.overage_rate_cost || ""}
                    className="non-editable-input"
                    readOnly
                  />
                </div>
                <div>
                  <label className="field-label">
                    Data per Overage Charge
                  </label>
                  <Input
                    value={rowData?.data_per_overage_charge || ""}
                    className="non-editable-input"
                    readOnly
                  />
                </div>
                <div>
                  <label className="field-label">Min. Plan MB</label>
                  <Input
                    value={rowData?.min_plan_data_mb || ""}
                    className="non-editable-input"
                    readOnly
                  />
                </div>
                <div>
                  <label className="field-label">Max. plan MB</label>
                  <Input
                    value={rowData?.max_plan_data_mb || ""}
                    className="non-editable-input"
                    readOnly
                  />
                </div>
                <div>
                  <label className="field-label">
                    Provider
                  </label>
                  <Select
                    className="w-full"
                    styles={NonEditableDropdownStyles}
                    isDisabled
                    value={
                      rowData?.service_provider_name
                        ? {
                          label: rowData.service_provider_name,
                          value: rowData.service_provider_name,
                        }
                        : null
                    }
                    options={providerOptions}
                  />
                </div>
                <div>
                  <label className="field-label">
                    Rate Plan Code
                  </label>
                  <Select
                    className="w-full"
                    styles={NonEditableDropdownStyles}
                    isDisabled
                    value={
                      rowData?.rate_plan_code
                        ? {
                          label: rowData.rate_plan_code,
                          value: rowData.rate_plan_code,
                        }
                        : null
                    }
                    options={generalFields?.soc_list?.map((soc: string[]) => ({
                      label: soc[0],
                      value: soc[0],
                    }))}
                  />
                </div>
                <div>
                  <Checkbox
                    checked={rowData?.allows_sim_pooling === "True"}
                    className="checkbox"
                    disabled
                  >
                    Pool Sims (Applies to all Plans sharing this Rate Plan Code)
                  </Checkbox>
                </div>
                <div>
                  <label className="field-label">
                    SMS per Message Rate
                  </label>
                  <Input
                    value={rowData.sms_rate}
                    className="non-editable-input"
                    readOnly
                  />
                </div>
                <div>
                  <label className="field-label">Automation Rule</label>
                  <Select
                    className="w-full"
                    styles={NonEditableDropdownStyles}
                    isDisabled
                    value={
                      Array.isArray(rowData?.automation_rule)
                        ? rowData.automation_rule.map((rule: any) => ({
                          label: rule,
                          value: rule,
                        }))
                        : rowData?.automation_rule
                          ? (() => {
                            try {
                              const parsedRules = JSON.parse(rowData.automation_rule);
                              return Array.isArray(parsedRules)
                                ? parsedRules.map((rule) => ({
                                  label: rule,
                                  value: rule,
                                }))
                                : [];
                            } catch (error) {
                              console.error("Invalid automation_rule JSON:", error);
                              return [];
                            }
                          })()
                          : null
                    }
                    options={automationRuleOptions}
                    isMulti
                  />
                </div>
                <div>
                  <label className="field -label">Status</label>
                  <div className="flex items-center">
                    <Switch
                      checked={(rowData?.is_active === "True")}
                      disabled
                    />
                    <span className="ml-2">
                      {rowData?.is_active === "True" ? "Active" : "Inactive"}
                    </span>
                  </div>
                </div>

                {(typeof providerName === "string" && providerName.includes("telegence")) && (
                  <div>
                    <label className="field-label">
                      SOC Code
                    </label>
                    <Select
                      className="w-full"
                      styles={NonEditableDropdownStyles}
                      value={
                        rowData?.soc_code
                          ? {
                            label: rowData.soc_code,
                            value: rowData.soc_code,
                          }
                          : null
                      }
                      options={socCodeOptions}
                    />
                  </div>
                )}

                {isBPEnabled && (
                  <>
                    <div>
                      <label className="field-label">
                        Service Type <span className="text-red-500">*</span>
                      </label>
                      <Select
                        className="w-full"
                        isClearable
                        styles={NonEditableDropdownStyles}
                        placeholder="Select a Service Type"
                        value={rowData["service_type"] ?
                          {
                            label: rowData["service_type"],
                            value: rowData["service_type"]
                          }
                          : null

                        }
                        options={serviceTypeOptions}
                      />
                      <span className="font-semibold mt-4 block">OR</span>

                    </div>
                    <div>
                      <label className="field-label">
                        Package <span className="text-red-500">*</span>
                      </label>
                      <Select
                        className="w-full"
                        isClearable
                        // styles={formData["product"] && formData["product"].length > 0 ? NonEditableDropdownStyles : DropdownStyles}
                        styles={NonEditableDropdownStyles}
                        placeholder="Select a Package"
                        value={rowData["package"] ?
                          {
                            label: rowData["package"],
                            value: rowData["package"]
                          }
                          : null

                        }
                        // isDisabled={formData["product"] && formData["product"].length > 0 ? true : false}
                        isDisabled
                        options={packageOptions}
                      />
                      {/* {validationErrors["package"] && (
                                            <span className="text-red-500">
                                              {validationErrors["package"]}
                                            </span>
                                          )} */}
                      <span className="font-semibold mt-4 block">OR</span>

                    </div>

                    <div>
                      <label className="field-label">
                        Rates  <span className="text-red-500">*</span>
                      </label>
                      <div className="grid grid-cols-3 gap-4 items-center">
                        {/* Headings */}
                        <div className="font-semibold">Product</div>
                        <div className="font-semibold">Cost</div>
                        <div className="font-semibold">Rate</div>

                        {/* Data rows */}
                        {selectedRates.map((product, index) => (
                          <React.Fragment key={index}>
                            {/* Product description */}
                            <span>{`${product?.description} -- ${product?.product_id}` || '-'}</span>

                            {/* Editable Cost */}
                            <input
                              type="number"
                              value={product?.cost ?? ''}
                              onChange={(e) => {
                                const updatedCost = e.target.value;
                                setSelectedRates((prev) =>
                                  prev.map((p, i) =>
                                    i === index ? { ...p, cost: updatedCost } : p
                                  )
                                );
                              }}
                              disabled
                              className="border border-gray-300 bg-gray-100 rounded px-2 py-1"

                            />

                            {/* Disabled Rate */}
                            <input
                              type="number"
                              value={product?.rate ?? ''}
                              disabled
                              className="border border-gray-300 bg-gray-100 rounded px-2 py-1"
                            />
                          </React.Fragment>
                        ))}
                      </div>

                    </div>
                    <div>
                      <label className="field-label">
                        Product <span className="text-red-500">*</span>
                      </label>
                      <Select
                        className="w-full"
                        // styles={formData["package"] ? NonEditableDropdownStyles : DropdownStyles}
                        styles={NonEditableDropdownStyles}
                        placeholder="Select Products"
                        isMulti
                        value={
                          Array.isArray(rowData["product"])
                            ? rowData["product"].map((product) => ({
                              label: product,
                              value: product,
                            }))
                            : []
                        }
                        // isDisabled={formData["package"] ? true : false}
                        isDisabled
                        options={productsOptions}
                      />
                      {/* {validationErrors["product"] && (
                                            <span className="text-red-500">
                                              {validationErrors["product"]}
                                            </span>
                                          )} */}
                    </div>

                    <div>
                      <Checkbox
                        checked={useCarrierActivation}
                        onChange={(e) => setUseCarrierActivation(e.target.checked)}
                        className='mt-4 text-[#000]'
                        disabled
                      >
                        <span className="text-gray-800">Use Carrier Activation</span>
                      </Checkbox>
                      {/* <label>Use Carrier Activation?</label> */}
                    </div>
                    {/* <div>
                      <label>Activation Date</label>
                      <DatePicker
                        style={{ width: '100%' }}
                        value={activationDate}
                        onChange={(date) => setActivationDate(date)}
                        className='input p-[7px]'
                        disabled
                      />
                    </div> */}

                  </>
                )}

              </>
            )}
          </div>
        </div>
      </div>
    </Modal>
  );
};

export default InfoCustomerRatePlan;