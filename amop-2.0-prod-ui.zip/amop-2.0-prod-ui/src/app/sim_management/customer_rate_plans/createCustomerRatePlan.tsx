"use client";
import React, { useState, useEffect } from "react";
import CreatableSelect from "react-select/creatable";
import { Select as AntSelect, DatePicker } from "antd";
import {
  Modal,
  Input,
  Checkbox,
  Button,
  Popover,
  notification,
  Switch,
  Spin,
} from "antd";
import Select from "react-select";
import { InformationCircleIcon } from "@heroicons/react/24/outline";
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import {
  DropdownStyles,
  NonEditableDropdownStyles,
} from "@/app/components/css/dropdown";

interface FormData {
  optimization_type?: string;
  plan_mb?: string;
  rate_plan_name?: string;
  base_rate?: string;
  rate_charge_amt?: string;
  is_billing_advance_eligible?: boolean;
  overage_rate_cost?: string;
  data_per_overage_charge?: string;
  min_plan_data_mb?: any;
  max_plan_data_mb?: any;
  service_provider_name?: string[]; // Changed to array
  rate_plan_code?: string[]; // Changed to array
  allows_sim_pooling?: boolean;
  sms_rate?: string;
  automation_rule?: string[];
  is_active?: boolean;
  soc_code?: string | null;
  product?: string[] | null;
  package?: string | null;
  service_type?: string | null;

}

interface CreateCustomerRatePlanModalProps {
  isOpen: boolean;
  onClose: () => void;
  generalFields: any; // This will contain service_provider_name and soc_list
  onSubmit: () => void;
}

const CreateCustomerRatePlan: React.FC<CreateCustomerRatePlanModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  generalFields,
}) => {
  const initialFormData: FormData = {
    optimization_type: undefined,
    plan_mb: undefined,
    rate_plan_name: undefined,
    base_rate: undefined,
    rate_charge_amt: undefined,
    is_billing_advance_eligible: false,
    overage_rate_cost: undefined,
    data_per_overage_charge: undefined,
    min_plan_data_mb: null,
    max_plan_data_mb: null,
    service_provider_name: [], // Changed to array
    rate_plan_code: [], // Changed to array
    allows_sim_pooling: false,
    sms_rate: undefined,
    automation_rule: [],
    is_active: true,
    soc_code: "",
  };
  const [formData, setFormData] = useState<FormData>(initialFormData);
  const [loading, setLoading] = useState(false);
  const [isCrossOptimization, setIsCrossOptimization] = useState(false);
  const [validationErrors, setValidationErrors] = useState<
    Record<string, string>
  >({});
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);
  const { username, token, partner, selectedDb,metaData,selectedBillingDb, role, firstLastName, sessionId } = useAuth();
  const [filteredSocOptions, setFilteredSocOptions] = useState<any[]>([]);
  // const [socCodeOptions, setSocCodeOptions] = useState<any[]>([]);
  const [isAutomationRuleEnabled, setIsAutomationRuleEnabled] = useState(false);
  const tenantId = localStorage.getItem("tenant_id");
  const isAdmin = role?.toLowerCase() === "super admin" || role?.toLowerCase() === "partner admin"
  //BP Integration state variables

  const [isBPEnabled, setIsBPEnabled] = useState(false);
  const [productsMap, setProductsMap] = useState<any[]>([]);
  const [packageMap, setPackageMap] = useState<any[]>([]);
  const [serviceTypeMap, setServiceTypeMap] = useState<any[]>([]);
  const [productsRateMap, setProductsRateMap] = useState<any[]>([]);
  const [productsOptions, setProductsOptions] = useState<any[]>([]);
  const [packageOptions, setPackageOptions] = useState<any[]>([]);
  const [serviceTypeOptions, setServiceTypeOptions] = useState<any[]>([]);
  const [selectedRates, setSelectedRates] = useState<any[]>([]);
  const [selectedPackage, setSelectedPackage] = useState(null);
  const [selectedserviceType, setSelectedServiceType] = useState(null);
  const [selectedProduct, setSelectedProduct] = useState<any>([]);
  const [productDependentMap, setProductDependentMap] = useState<Record<string, string[]>>({});
  const [packageDependentMap, setPackageDependentMap] = useState<Record<string, string[]>>({});
  const [useCarrierActivation, setUseCarrierActivation] = useState(true);
  const [activationDate, setActivationDate] = useState(null);

  // Convert service provider names into the format expected by Select
  const providerOptions =
    generalFields.service_provider_name?.map((provider: string) => ({
      label: provider,
      value: provider,
    })) || [];

  // Convert combined_soc_code names into the format expected by Select
  const socCodeOptions = generalFields?.soc_code
    ?.filter((code: string) => {
      // Exclude if the part after ' - ' is 'None'
      const parts = code.split(" - ");
      return !(parts.length > 1 && parts[0] === "None");
    })
    .map((code: string) => ({
      label: !isAdmin ? code.split(" - ")[1] : code,
      value: code,
    })) || [];

  // Convert automation rules into the format expected by Select
  const automationRuleOptions =
    generalFields.automation_rule?.map((rule: string) => ({
      label: rule,
      value: rule,
    })) || [];


  const fetchProductsPackageData = async () => {
    const tenant_id_ = localStorage.getItem("tenant_id") || "0";
    setLoading(true);
    try {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/fetch_product_package_data",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Active Customer Rate Plan",
        feature_module_name: "Customer Rate Plans",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        billing_db_name: selectedBillingDb,
        sessionID: sessionId,
         tenant_id:tenant_id_
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        const product_rate = parsedData?.data?.product_rate || []
        setProductsRateMap(product_rate)
        const product = parsedData?.data?.product || []
        setProductsMap(product)
        const products_options = product.map((product: any) => ({ label: `${product?.description} -- ${product?.product_id}` || "", value: `${product?.description} -- ${product?.product_id}` || "" }))
        // setProductsOptions(products_options)
        const package_ = parsedData?.data?.package || []
        setPackageMap(package_)
        const package_options = package_.map((opt: any) => ({ label: `${opt?.category} -- ${opt?.package_id}` || "", value: `${opt?.category} -- ${opt?.package_id}` || "" }))
        // setPackageOptions(package_options)
        const service_type_map = parsedData?.data?.service_types || []
        setServiceTypeMap(service_type_map)
        const service_type_options = service_type_map.map((opt: any) => ({ label: `${opt?.description} -- ${opt?.service_type_id}` || "", value: `${opt?.description} -- ${opt?.service_type_id}` || "" }))
        setServiceTypeOptions(service_type_options)

        // New: Set product_dependent and package_dependent data
        const productDependent = parsedData?.data?.product_dependent || {};
        const packageDependent = parsedData?.data?.package_dependent || {};
        setProductDependentMap(productDependent);
        setPackageDependentMap(packageDependent);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      setLoading(false);

    }
  };

  const fetchData = async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_cross_provider_optimization_status",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Active Customer Rate Plan",
        feature_module_name: "Customer Rate Plans",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        const cross_carrier_optimization = parsedData?.cross_carrier_optimization || false
        setIsCrossOptimization(cross_carrier_optimization)
        const billing_plaform_flag = parsedData?.billing_platform_flag || false
        setIsBPEnabled(billing_plaform_flag)
        if (billing_plaform_flag) {
          fetchProductsPackageData()
        }
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      setLoading(false);

    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchData()
      // fetchProductsPackageData()

    }
  }, [isOpen])

  useEffect(() => {
    if (selectedRates.length>0) {
      let sum_of_rates=0
      selectedRates.forEach((item: any) => {
      const rate = Number(item?.rate) || 0
      sum_of_rates += rate;
    });
    const basRate=sum_of_rates
    setFormData((prev) => ({
        ...prev,
        base_rate: basRate !==0 ? basRate.toString() : '',
      }));
    }
    else{
      setFormData((prev) => ({
        ...prev,
        base_rate: '',
      }));
    }
  }, [selectedRates])

  // Update the useEffect to filter and map SOC options based on the selected provider
  useEffect(() => {
    if (
      formData.service_provider_name &&
      formData.service_provider_name.length > 0
    ) {
      const socList = generalFields.soc_list || [];
      const filteredSocs = socList
        .filter((soc_list: string[]) =>
          formData.service_provider_name?.includes(soc_list[1])
        ) // Match the provider name
        .map((soc_list: string[]) => ({
          label: soc_list[0], // SOC code (first element)
          value: soc_list[0], // SOC code (first element)
        }));
      setFilteredSocOptions(filteredSocs);
    } else {
      setFilteredSocOptions([]);
    }
  }, [formData.service_provider_name, generalFields.soc_list]);

  // const handleChange = (field: keyof FormData, value: any) => {
  //   setFormData((prev) => ({ ...prev, [field]: value }));
  // };
  const handleChange = (field: keyof FormData, value: any) => {
    // If the optimization type is changed, reset the service provider and rate plan code
    if (field === "optimization_type") {
      setIsAutomationRuleEnabled(false);
      setFormData((prev) => ({
        ...prev,
        [field]: value,
        // service_provider_name: [], 
        // rate_plan_code: [],
        // automation_rule: [],
        // soc_code: null,
        // min_plan_data_mb: null,
        // max_plan_data_mb: null,
      }));
    } else if (field === "service_provider_name") {
      console.log("value", value)
      // Ensure `value` is an array
      const valueArray = Array.isArray(value) ? value : [value];
      console.log("valueArray", valueArray)

      setFormData((prev) => ({
        ...prev,
        [field]: value,
        rate_plan_code: [],
      }));
      // Check if the selected provider is "AT&T - Telegence"
      if (valueArray.some((item) => item.includes("AT&T - Telegence"))) {
      console.log("true",valueArray)
        setIsAutomationRuleEnabled(true);
      } else {
        setIsAutomationRuleEnabled(false);
        setFormData((prev) => ({
          ...prev,
          automation_rule: [], // Clear the field
        }));
      }
    }
    // else if (field === "automation_rule") {
    //   console.log("value",value)
    //   const aggregatedCodes = value.flatMap(
    //     (rule:any) => socCodeOptionsMap[rule] || []
    //   );
    //   console.log("aggregatedCodes",aggregatedCodes)
    //   const socCodeOptions_=aggregatedCodes?.map((code: string) => ({
    //     label: code,
    //     value: code,
    //   })) || [];

    //   // setSocCodeOptions(socCodeOptions_)
    //   setFormData((prev) => ({
    //     ...prev,
    //     [field]: value,
    //   }));

    // }  
    else {
      setFormData((prev) => ({ ...prev, [field]: value }));
    }
  };

  const validateForm = () => {
    const errors: Record<string, string> = {};

    // Check if optimization_type is provided
    if (!formData.optimization_type) {
      errors.optimization_type = "Optimization type is required";
    }

    // Define mandatory fields
    const mandatoryFields: Array<keyof FormData> = [
      "plan_mb",
      "rate_plan_name",
      "base_rate",
      "rate_charge_amt",
      "overage_rate_cost",
      "data_per_overage_charge",
      "sms_rate",
      "service_provider_name",
      "rate_plan_code",
    ];

    // Create a mapping for display names
    const fieldDisplayNames: Record<string, string> = {
      plan_mb: "Plan MB",
      rate_plan_name: "Rate plan name",
      base_rate: "Base rate",
      rate_charge_amt: "Rate charge",
      overage_rate_cost: "Overage rate cost",
      data_per_overage_charge: "Data per overage charge",
      sms_rate: "SMS rate",
      service_provider_name: "Provider name",
      rate_plan_code: "Rate plan code",
    };

    // Validate mandatory fields
    mandatoryFields.forEach((field) => {
      if (
        formData[field] === null ||
        formData[field] === undefined ||
        formData[field] === "" ||
        formData[field] === "None" || formData[field] === "None" ||
        (Array.isArray(formData[field]) && formData[field].length === 0 && field !== 'rate_plan_code')
      ) {
        errors[field] = `${fieldDisplayNames[field]} is required`;
      }
      if ((!formData[field] || formData[field].length === 0) && field === 'rate_plan_code') {
        errors[field] = `${fieldDisplayNames[field]} is required`;
      }


    });
    Object.keys(formData).forEach((field) => {
      if (field === "plan_mb" ||
        field === "base_rate" ||
        field === "rate_charge_amt" ||
        field === "overage_rate_cost" ||
        field === "data_per_overage_charge" ||
        field === "min_plan_data_mb" ||
        field === "max_plan_data_mb") {
        console.log("field", field)
        const regex = /^[^a-zA-Z\s]*$/; // Regex to avoid alphabets and spaces
        const value = formData[field] ? formData[field].toString().replace('$', '') : '0'; // Ensure value is a string
        console.log("value", value)
        if ((formData[field] !== null &&
          formData[field] !== undefined &&
          formData[field] !== "" &&
          formData[field] !== "None") && formData[field] !== "None" && !regex.test(value)) {
          errors[field] = "Alphabets are not allowed";
        }
      }

    });

    if (isBPEnabled) {
      if (((formData['product'] && formData['product'].length === 0)|| !formData['product']) && !formData['package']) {
        errors["product"] = "Either Product or Package is required"
        errors["package"] = "Either Product or Package is required"
      }
      else {
        delete errors["product"]
        delete errors["package"]
      }
      if(!formData['service_type']){
        errors['service_type'] = 'Service Type is required'
      }
      else{
        delete errors['service_type']
      }
    }
    console.log("errors", errors)
    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleCreate = () => {
    if (validateForm()) {
          if (isBPEnabled) {
            if (selectedRates.length === 0) {
              Modal.error({
                title: "Validation Error",
                content: "Selected package has no associated products",
                centered: true,
              })
            }
            else {
    
              setIsConfirmationOpen(true);
            }
          }
          else {
    
            setIsConfirmationOpen(true);
          }
    
        }
  };

  const handleConfirmCreate = async () => {
    const cleanedFormData: any = { ...formData }
    cleanedFormData["soc_code"] = cleanedFormData["soc_code"] && cleanedFormData["soc_code"].split(" - ")[0] || cleanedFormData["soc_code"]
    if (!isBPEnabled) {
      delete cleanedFormData["product"]
      delete cleanedFormData["package"]
    }
    else {
      cleanedFormData["use_carrier_activation"] = useCarrierActivation
      // cleanedFormData["effective_date"] = activationDate
      cleanedFormData["product_cost"] = selectedRates

    }
    // cleanedFormData["service_provider_name"] =cleanedFormData?.optimization_type==='Cross Customer Pooling'?cleanedFormData?.service_provider_name:cleanedFormData?.service_provider_name[0] ||"" ;
    const syncData = {
      customerrateplan: [
        {
          ...(formData.rate_plan_code && { rate_plan_code: formData.rate_plan_code }),
          ...(formData.plan_mb && { plan_mb: formData.plan_mb }),
          ...(formData.base_rate && { base_rate: formData.base_rate }),
          created_by: firstLastName,
          is_deleted: false,
          ...(formData.is_active && { is_active: formData.is_active }),
          ...(formData.rate_charge_amt && { rate_charge_amt: formData.rate_charge_amt }),
          ...(formData.data_per_overage_charge && { data_per_overage_charge: formData.data_per_overage_charge }),
          ...(formData.overage_rate_cost && { overage_rate_cost: formData.overage_rate_cost }),
          allows_sim_pooling: formData.allows_sim_pooling,
          is_billing_advance_eligible: formData.is_billing_advance_eligible,
          ...(formData.sms_rate && { sms_rate: formData.sms_rate }),
        },
      ],
    };
    console.log("syncData", syncData)
    const payload = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/update_sim_management_modules_data",
      role_name: role,
      parent_module: "Sim Management",
      module: "Customer Rate Plan",
      action: "create",
      table_name: "customerrateplan",
      new_data: {
        ...cleanedFormData,
        created_by: firstLastName,
        modified_by: firstLastName,
        is_deleted: false,
        is_active: true,
        created_date: getCurrentDateTime(),
        auto_change_rate_plan: "",
        surcharge_3g: "",
        automation_rule_flag: cleanedFormData.automation_rule.length === 0 ? false : true,
        tenant_id: partner?.toLowerCase() === "altaworx" || partner?.toLowerCase() === "altaworx test" ? 1 : Number(tenantId) || 0,
      },
      sync_data: syncData,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
    };

    try {
      setLoading(true);
      setIsConfirmationOpen(false);
      const response = await axios.post(ENV_ROUTES.SIM_MANAGEMENT, {
        data: payload,
      });

      const parsedResponse = JSON.parse(response.data.body);
      if (parsedResponse.flag === false) {
        Modal.error({
          title: "Saving Error",
          content:
            parsedResponse.message ||
            "An error occurred while saving data. Please try again.",
          centered: true,
        });
      } else {
        notification.success({
          message: "Success",
          description: "Customer Rate Plan created successfully!",
          placement: "top",
        });
        // Extract the necessary data from the response
        const customerRatePlanId = parsedResponse.data; // Assuming this is the ID you need

        delete customerRatePlanId[0]["product"]
        delete customerRatePlanId[0]["package"]
        delete customerRatePlanId[0]["effective_date"]
        delete customerRatePlanId[0]["product_cost"]
        delete customerRatePlanId[0]["use_carrier_activation"]

        console.log("customerRatePlanId", customerRatePlanId)

        // Prepare the second API payload
        const secondApiPayload = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/run_db_script",
          role_name: role,
          module_name: "Customer Rate Plan",
          mod_pages: {
            start: 0,
            end: 100,
          },
          access_token: token,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          request_received_at: getCurrentDateTime(),
          Partner: partner || "default_value",
          data: {
            customer_rate_plan: customerRatePlanId, // Use the ID from the first response
          },
        };

        // Call the second API
        await axios.post(ENV_ROUTES.SIM_MANAGEMENT, {
          data: secondApiPayload,
        });

        // Call the onSubmit and onClose functions
        onSubmit();
        handleModalClose()
      }
    } catch (err) {
      console.error("Error saving data:", err);
      notification.error({
        message: "Error",
        description: "Failed to create the customer. Please try again.",
        placement: "top",
      });
    } finally {
      setLoading(false);
      setIsConfirmationOpen(false);
    }
  };

  const handleCancelConfirmation = () => {
    setIsConfirmationOpen(false);
  };

  const handleModalClose = () => {
    setFormData(initialFormData); // Reset form data
    setValidationErrors({}); // Clear validation errors
    onClose();
    setSelectedServiceType(null)
    setSelectedProduct([]);
    setSelectedPackage(null);
    setSelectedRates([])
    setProductDependentMap({});
    setPackageDependentMap({});
    setProductsOptions([]);
    setPackageOptions([])
  };

  const handlePackageChange = (selectedOption: any) => {
    if (selectedOption) {
      const selectedValue = selectedOption?.value || "";
      const matchedItem = packageMap.find(
        (item: any) => `${item?.category} -- ${item?.package_id}` === selectedValue
      );
      setFormData((prev) => ({ ...prev, package: selectedValue }));

      console.log("matchedItem", matchedItem)
      const matchedProductList = matchedItem ? matchedItem?.products_list : [];
      console.log("matchedProductList", matchedProductList)

      // const matchedRates = productsRateMap.filter((product: any) =>
      //   matchedProductList.some(
      //     (option: any) => option?.description === product?.description && option?.product_id === product?.product_id
      //   )
      // );

      setSelectedPackage(selectedValue);
      setSelectedRates(matchedProductList)
      setSelectedProduct([]);

    } else if (selectedOption === null) {
      setFormData((prev) => ({ ...prev, package: null }));
      setSelectedPackage(null);
      setSelectedRates([])
    }
  };
  const handleServiceTypeChange = (selectedOption: any) => {
    if (selectedOption) {
      const selectedValue = selectedOption?.value || "";
      setFormData((prev) => ({ ...prev, service_type: selectedValue }));
      setSelectedServiceType(selectedValue);

      // Extract key from selectedValue by splitting on " -- " and taking first part trimmed
      const key = selectedValue.split(" -- ")[0].trim();

      // Update product options based on selected service type key
        let productOptionsForServiceType = productDependentMap[key] || [];
        if (typeof productOptionsForServiceType === 'string') {
          productOptionsForServiceType = [productOptionsForServiceType];
        }
        if (productOptionsForServiceType && productOptionsForServiceType.length > 0) {
          const productOptionsMapped = productOptionsForServiceType.map((opt: string) => ({ label: opt, value: opt }));
          setProductsOptions(productOptionsMapped);
        } else {
          setProductsOptions([]);
        }

        let packageOptionsForServiceType = packageDependentMap[key] || [];
        if (typeof packageOptionsForServiceType === 'string') {
          packageOptionsForServiceType = [packageOptionsForServiceType];
        }
        if (packageOptionsForServiceType && packageOptionsForServiceType.length > 0) {
          const packageOptionsMapped = packageOptionsForServiceType.map((opt: string) => ({ label: opt, value: opt }));
          setPackageOptions(packageOptionsMapped);
        } else {
          setPackageOptions([]);
        }

      // Reset selected product and package in formData
      setFormData((prev) => ({ ...prev, product: [], package: null }));
      setSelectedProduct([]);
      setSelectedPackage(null);
      setSelectedRates([])


    } else if (selectedOption === null) {
      setFormData((prev) => ({ ...prev, service_type: null }));
      setSelectedServiceType(null);
      setProductsOptions([]);
      setPackageOptions([]);
      setFormData((prev) => ({ ...prev, product: [], package: null }));
      setSelectedProduct([]);
      setSelectedPackage(null);
      setSelectedRates([])
    }
  };

  const handleProductChange = (selectedOptions: any) => {
    if (selectedOptions) {
      setSelectedPackage(null);

      if (Array.isArray(selectedOptions)) {
        const values = selectedOptions.map((option: any) => option.value);
        setFormData((prev) => ({ ...prev, product: values }));

        const matchedRates = productsRateMap.filter((product: any) =>
          selectedOptions.some(
            (option: any) => option.value === `${product?.description} -- ${product?.product_id}`
          )
        );

        setSelectedRates(matchedRates);
        // console.log("matchedRates", matchedRates)
        setSelectedProduct(values);
        setSelectedPackage(null);
      } else {
        setFormData((prev) => ({ ...prev, product: [] }));
        setSelectedProduct([]);
        setSelectedRates([]);
      }
    } else if (selectedOptions === null) {
      setFormData((prev) => ({ ...prev, product: [] }));
      setSelectedProduct([]);
      setSelectedRates([]);
    }
  };


  const getSOCCOdeLabel = (socCode: any) => {

    const matchedCode = socCodeOptions.find((opt: any) =>
      (opt?.value || "").startsWith(socCode)
    );

    return matchedCode?.label || matchedCode || ""
  }

  const modalHeight =
    typeof window !== "undefined" ? (window.innerHeight * 2.5) / 4 : 0;

  return (
    <>
      <Modal
        title="Create Customer Rate Plan"
        open={isOpen}
        onCancel={handleModalClose}
        footer={
          <div className="flex justify-center space-x-2">
            <Button onClick={handleModalClose} className="cancel-btn">
              Cancel
            </Button>
            <Button onClick={handleCreate} className="save-btn">
              Create
            </Button>
          </div>
        }
        centered
        width={800}
      >
        {loading ? (
          <div
            className="flex justify-center items-center"
            style={{ height: modalHeight }}
          >
            <Spin size="large" />
          </div>
        ) : (
          <div
            style={{
              height: modalHeight,
              overflowY: "auto",
              overflowX: "hidden",
              padding: "4px",
            }}
          >
            <div className="flex flex-col space-y -4 p-2">
              <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
                <div>
                  <label className="field-label">
                    Optimization Type <span className="text-red-500">*</span>
                  </label>
                  <div className="flex items-center gap-3">
                    <Select
                      className="w-full"
                      styles={DropdownStyles}
                      placeholder="Select Optimization Type"
                      value={
                        formData["optimization_type"]
                          ? {
                            label: formData["optimization_type"],
                            value: formData["optimization_type"],
                          }
                          : null
                      }
                      onChange={(option: any) =>
                        handleChange("optimization_type", option.value)
                      }
                      options={[
                        {
                          label: "Standard",
                          value: "Standard",
                        },
                        {
                          label: "Auto Change Rate Plan",
                          value: "Auto Change Rate Plan",
                        },
                        {
                          label: "Cross Customer Pooling",
                          value: "Cross Customer Pooling",
                        },
                      ]}
                    />
                    <Popover
                      content={
                        <img
                          src="/images/rate-plan-info.png"
                          alt="Rate Plan Info"
                          style={{ width: "400px" }}
                        />
                      }
                      trigger="hover"
                      placement="right"
                    >
                      <InformationCircleIcon className="w-5 h-5 text-blue-600 cursor-pointer" />
                    </Popover>
                  </div>
                  {validationErrors["optimization_type"] && (
                    <span className="text-red-500">
                      {validationErrors["optimization_type"]}
                    </span>
                  )}
                </div>
                {formData["optimization_type"] && (
                  <>
                    <div>
                      <label className="field-label">
                        MB Included <span className="text-red-500">*</span>
                      </label>
                      <Input
                        value={formData["plan_mb"]}
                        className="input"
                        onChange={(e) =>
                          handleChange("plan_mb", e.target.value)
                        }
                        placeholder="Enter MB Included"
                      />
                      {validationErrors["plan_mb"] && (
                        <span className="text-red-500">
                          {validationErrors["plan_mb"]}
                        </span>
                      )}
                    </div>
                    <div>
                      <label className="field-label">
                        Rate Plan Name <span className="text-red-500">*</span>
                      </label>
                      <Input
                        value={formData["rate_plan_name"]}
                        className="input"
                        onChange={(e) =>
                          handleChange("rate_plan_name", e.target.value)
                        }
                        placeholder="Enter Rate Plan Name"
                      />
                      {validationErrors["rate_plan_name"] && (
                        <span className="text-red-500">
                          {validationErrors["rate_plan_name"]}
                        </span>
                      )}
                    </div>
                    <div>
                      <label className="field-label">
                        Base Rate <span className="text-red-500">*</span>
                      </label>
                      <Input
                        value={formData["base_rate"]}
                        className={`${isBPEnabled ? 'non-editable-input' : 'input'}`}
                        onChange={(e) =>
                          handleChange("base_rate", e.target.value)
                        }
                        disabled={isBPEnabled}
                        placeholder="Enter Base Rate"
                      />
                      {validationErrors["base_rate"] && (
                        <span className="text-red-500">
                          {validationErrors["base_rate"]}
                        </span>
                      )}
                    </div>
                    <div>
                      <label className="field-label">
                        Rate Charge <span className="text-red-500">*</span>
                      </label>
                      <Input
                        value={formData["rate_charge_amt"]}
                        className="input"
                        onChange={(e) =>
                          handleChange("rate_charge_amt", e.target.value)
                        }
                        placeholder="Enter Rate Charge"
                      />
                      {validationErrors["rate_charge_amt"] && (
                        <span className="text-red-500">
                          {validationErrors["rate_charge_amt"]}
                        </span>
                      )}
                    </div>
                    <div>
                      <Checkbox
                        checked={formData["is_billing_advance_eligible"]}
                        onChange={(e) =>
                          handleChange(
                            "is_billing_advance_eligible",
                            e.target.checked
                          )
                        }
                        className="checkbox"
                      >
                        Bill in Advance (Bills Rate Charge Separately from
                        Overage)
                      </Checkbox>
                    </div>
                    <div>
                      <label className="field-label">
                        Overage Rate Cost{" "}
                        <span className="text-red-500">*</span>
                      </label>
                      <Input
                        value={formData["overage_rate_cost"]}
                        className="input"
                        onChange={(e) =>
                          handleChange("overage_rate_cost", e.target.value)
                        }
                        placeholder="Enter overage rate cost"
                      />
                      {validationErrors["overage_rate_cost"] && (
                        <span className="text-red-500">
                          {validationErrors["overage_rate_cost"]}
                        </span>
                      )}
                    </div>
                    <div>
                      <label className="field-label">
                        Data Per Overage Charge{" "}
                        <span className="text-red-500">*</span>
                      </label>
                      <Input
                        value={formData["data_per_overage_charge"]}
                        className="input"
                        onChange={(e) =>
                          handleChange(
                            "data_per_overage_charge",
                            e.target.value
                          )
                        }
                        placeholder="Enter Data per Overage Charge"
                      />
                      {validationErrors["data_per_overage_charge"] && (
                        <span className="text-red-500">
                          {validationErrors["data_per_overage_charge"]}
                        </span>
                      )}
                    </div>
                    <div>
                      <label className="field-label">Min. Plan MB</label>
                      <Input
                        value={formData["min_plan_data_mb"] !== "None" ? formData["min_plan_data_mb"] : ''}
                        className="input"
                        onChange={(e) =>
                          handleChange("min_plan_data_mb", e.target.value)
                        }
                        placeholder="Enter min. plan MB"
                      />
                      {validationErrors["min_plan_data_mb"] && (
                        <span className="text-red-500">
                          {validationErrors["min_plan_data_mb"]}
                        </span>
                      )}
                    </div>
                    <div>
                      <label className="field-label">Max. Plan MB</label>
                      <Input
                        value={formData["max_plan_data_mb"] !== "None" ? formData["max_plan_data_mb"] : ''}
                        className="input"
                        onChange={(e) =>
                          handleChange("max_plan_data_mb", e.target.value)
                        }
                        placeholder="Enter max plan MB"
                      />
                      {validationErrors["max_plan_data_mb"] && (
                        <span className="text-red-500">
                          {validationErrors["max_plan_data_mb"]}
                        </span>
                      )}
                    </div>
                    <div>
                      <label className="field-label">
                        Provider <span className="text-red-500">*</span>
                      </label>
                      <Select
                        className="w-full"
                        styles={DropdownStyles}
                        placeholder="Select Provider"
                        isMulti={isCrossOptimization} // Conditional multi-select
                        value={
                          !isCrossOptimization
                            ? formData["service_provider_name"]
                              ? {
                                label: formData["service_provider_name"],
                                value: formData["service_provider_name"],
                              }
                              : null
                            : formData["service_provider_name"]?.map(
                              (provider) => ({
                                label: provider,
                                value: provider,
                              })
                            )
                        } // Handle single select vs multi-select
                        onChange={(options: any) => {
                          const selectedValues =
                            isCrossOptimization
                              ? Array.isArray(options)
                                ? options.map((option: any) => option.value)
                                : []
                              : options
                                ? options.value
                                : null; // For single select
                          handleChange("service_provider_name", selectedValues);
                        }}
                        options={providerOptions}
                      />
                      {validationErrors["service_provider_name"] && (
                        <span className="text-red-500">
                          {validationErrors["service_provider_name"]}
                        </span>
                      )}
                    </div>
                    <div>
                      <label className="field-label">
                        Rate Plan Code <span className="text-red-500">*</span>
                      </label>
                      <CreatableSelect
                        isClearable
                        className="w-full"
                        styles={DropdownStyles}
                        placeholder="Select or Type Rate Plan Code"
                        isMulti={isCrossOptimization}
                        value={
                          !isCrossOptimization
                            ? formData["rate_plan_code"]
                              ? {
                                label: formData["rate_plan_code"],
                                value: formData["rate_plan_code"],
                              }
                              : null
                            : formData["rate_plan_code"]?.map((code) => ({
                              label: code,
                              value: code,
                            }))
                        }
                        onChange={(options: any) => {
                          const selectedValues =
                            isCrossOptimization
                              ? Array.isArray(options)
                                ? options.map((option: any) => option.value)
                                : []
                              : options
                                ? options.value
                                : null;
                          handleChange("rate_plan_code", selectedValues);
                        }}

                        onCreateOption={(inputValue: string) => {
                          // Handle the creation of a new option
                          const newOption = {
                            value: inputValue,
                            label: inputValue,
                          };

                          if (isCrossOptimization) {
                            // For multi-select, append to existing values
                            const currentValues =
                              formData["rate_plan_code"] || [];
                            handleChange("rate_plan_code", [
                              ...currentValues,
                              inputValue,
                            ]);
                          } else {
                            // For single select
                            handleChange("rate_plan_code", inputValue);
                          }
                        }}
                        options={filteredSocOptions}
                        formatCreateLabel={(inputValue: string) =>
                          `Add "${inputValue}"`
                        }
                      />
                      {validationErrors["rate_plan_code"] && (
                        <span className="text-red-500">
                          {validationErrors["rate_plan_code"]}
                        </span>
                      )}
                    </div>
                    <div>
                      <Checkbox
                        checked={formData["allows_sim_pooling"]}
                        onChange={(e) =>
                          handleChange("allows_sim_pooling", e.target.checked)
                        }
                        className="checkbox"
                      >
                        Pool Sims (Applies to all Plans Sharing this Rate Plan
                        Code)
                      </Checkbox>
                    </div>
                    <div>
                      <label className="field-label">
                        SMS Per Message Rate{" "}
                        <span className="text-red-500">*</span>
                      </label>
                      <Input
                        value={formData["sms_rate"]}
                        className="input"
                        onChange={(e) =>
                          handleChange("sms_rate", e.target.value)
                        }
                        placeholder="Enter SMS per message rate"
                      />
                      {validationErrors["sms_rate"] && (
                        <span className="text-red-500">
                          {validationErrors["sms_rate"]}
                        </span>
                      )}
                    </div>
                    <div>
                      <label className="field-label">Automation Rule</label>
                      <Select
                        isMulti
                        className="w-full"
                        styles={
                          isAutomationRuleEnabled
                            ? DropdownStyles
                            : NonEditableDropdownStyles
                        } // Use conditional styles
                        placeholder="Select Automation Rule"
                        value={formData["automation_rule"]?.map((rule) => ({
                          label: rule,
                          value: rule,
                        })) || []} // Map selected values for multi-select
                        onChange={(options: any) => {
                          const selectedValues = options ? options.map((option: any) => option.value) : [];
                          handleChange("automation_rule", selectedValues); // Update formData with selected values
                        }}
                        // Map selected values for multi-select
                        options={automationRuleOptions}
                        isDisabled={!isAutomationRuleEnabled} // Disable if not enabled
                        menuPlacement="auto"
                      />
                    </div>
                    <div>
                      <label className="field-label">Status</label>
                      <div className="flex items-center">
                        <span className="mr-2 w-12">
                          {formData["is_active"] ? "Active" : "Inactive"}
                        </span>
                        <Switch
                          checked={formData["is_active"]}
                          onChange={() =>
                            handleChange("is_active", !formData["is_active"])
                          }
                        />
                      </div>
                    </div>
                    {isAutomationRuleEnabled && (
                      <div>
                        <label className="field-label">
                          {isAdmin ? "SOC Code" : "Carrier Rate Plan"}
                        </label>
                        <Select
                          isClearable
                          className="w-full"
                          // styles={!formData.automation_rule || formData.automation_rule.length===0?NonEditableDropdownStyles:DropdownStyles}
                          styles={DropdownStyles}
                          placeholder={`Select ${isAdmin ? "SOC Code" : "Carrier Rate Plan"}`}
                          value={
                            formData["soc_code"]
                              ? {
                                label: !isAdmin ? getSOCCOdeLabel(formData["soc_code"]) : formData["soc_code"],
                                value: !isAdmin ? getSOCCOdeLabel(formData["soc_code"]) : formData["soc_code"],
                              }
                              : null
                          }
                          onChange={(options: any) => {
                            const selectedValues =
                              options
                                ? options.value
                                : null; // For single select
                            handleChange("soc_code", selectedValues);
                          }}
                          options={socCodeOptions}
                          menuPlacement="top"
                        // isDisabled={!formData.automation_rule || formData.automation_rule.length===0}
                        />
                      </div>
                    )}

                    {isBPEnabled && (
                      <>
                        <div>
                          <label className="field-label">
                            Service Type <span className="text-red-500">*</span>
                          </label>
                          <Select
                            className="w-full"
                            isClearable
                            styles={DropdownStyles}
                            placeholder="Select a Service Type"
                            value={formData["service_type"] ?
                              {
                                label: formData["service_type"],
                                value: formData["service_type"]
                              }
                              : null

                            }
                            onChange={handleServiceTypeChange}
                            options={serviceTypeOptions}
                          />
                          {validationErrors["service_type"] && (
                            <span className="text-red-500">
                              {validationErrors["service_type"]}
                            </span>
                          )}

                        </div>
                        <div>
                          <label className="field-label">
                            Package <span className="text-red-500">*</span>
                          </label>
                          <Select
                            className="w-full"
                            isClearable
                            styles={formData["product"] && formData["product"].length > 0 ? NonEditableDropdownStyles : DropdownStyles}
                            placeholder="Select a Package"
                            value={formData["package"] ?
                              {
                                label: formData["package"],
                                value: formData["package"]
                              }
                              : null

                            }
                            isDisabled={formData["product"] && formData["product"].length > 0 ? true : false}
                            onChange={handlePackageChange}
                            options={packageOptions}
                          />
                          {validationErrors["package"] && (
                            <span className="text-red-500">
                              {validationErrors["package"]}
                            </span>
                          )}
                          <span className="font-semibold mt-4 block">OR</span>

                        </div>

                        <div>
                          <label className="field-label">
                            Rates  <span className="text-red-500">*</span>
                          </label>
                          <div className="grid grid-cols-3 gap-4 items-center">
                            {/* Headings */}
                            <div className="font-semibold">Product</div>
                            <div className="font-semibold">Cost</div>
                            <div className="font-semibold">Rate</div>

                            {/* Data rows */}
                            {selectedRates.map((product, index) => (
                              <React.Fragment key={index}>
                                {/* Product description */}
                                <span>{`${product?.description} -- ${product?.product_id}` || '-'}</span>

                                {/* Editable Cost */}
                                <input
                                  type="number"
                                  disabled
                                  value={product?.cost ?? ''}
                                  className="non-editable-input"
                                />

                                {/* Disabled Rate */}
                                <input
                                  type="number"
                                  value={product?.rate ?? ''}
                                  disabled={formData['package']?true:false}
                                  onChange={(e) => {
                                    const updatedCost = e.target.value;
                                    setSelectedRates((prev) =>
                                      prev.map((p, i) =>
                                        i === index ? { ...p, rate: updatedCost } : p
                                      )
                                    );
                                  }}
                                  className={`${formData['package']? 'non-editable-input':'input'}`}
                                />
                              </React.Fragment>
                            ))}
                          </div>

                        </div>
                        <div>
                          <label className="field-label">
                            Product <span className="text-red-500">*</span>
                          </label>
                          <Select
                            className="w-full"
                            styles={formData["package"] ? NonEditableDropdownStyles : DropdownStyles}
                            placeholder="Select Products"
                            isMulti
                            value={formData["product"]?.map(
                              (product) => ({
                                label: product,
                                value: product,
                              })
                            )
                            }
                            isDisabled={formData["package"] ? true : false}
                            onChange={handleProductChange}
                            options={productsOptions}
                          />
                          {validationErrors["product"] && (
                            <span className="text-red-500">
                              {validationErrors["product"]}
                            </span>
                          )}
                        </div>

                        <div>
                          <Checkbox
                            checked={useCarrierActivation}
                            onChange={(e) => setUseCarrierActivation(e.target.checked)}
                            className='mt-4'
                            disabled
                          >
                            Use Carrier Activation
                          </Checkbox>
                          {/* <label>Use Carrier Activation?</label> */}
                        </div>
                        {/* <div>
                          <label>Activation Date</label>
                          <DatePicker
                            style={{ width: '100%' }}
                            value={activationDate}
                            onChange={(date) => setActivationDate(date)}
                            className='input p-[7px]'
                            // disabledDate={disablePastDates}
                            disabled={useCarrierActivation}
                          />
                        </div> */}

                      </>
                    )}


                  </>
                )}
              </div>
            </div>
          </div>
        )}
      </Modal>
      <Modal
        title="Confirmation"
        open={isConfirmationOpen}
        onOk={handleConfirmCreate}
        onCancel={handleCancelConfirmation}
        centered
      >
        <p>Are you sure you Want to Create this Customer Rate Plan</p>
      </Modal>
    </>
  );
};

export default CreateCustomerRatePlan;
