"use client";
import React, { useState, useEffect, useRef } from "react";
import {
  Modal,
  Input,
  Checkbox,
  Button,
  Popover,
  notification,
  Switch,
  Spin,
  DatePicker,
} from "antd";
import Select from "react-select";
import { InformationCircleIcon } from "@heroicons/react/24/outline";
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { DropdownStyles, NonEditableDropdownStyles } from "@/app/components/css/dropdown";
import CreatableSelect from "react-select/creatable";
import { useCustomerRatePlanStore } from "@/app/stores/customerRateplanStore";
import dayjs from 'dayjs';

interface FormData {
  optimization_type?: string;
  plan_mb?: string;
  rate_plan_name?: string;
  base_rate?: string;
  rate_charge_amt?: string;
  is_billing_advance_eligible?: boolean;
  overage_rate_cost?: string;
  data_per_overage_charge?: string;
  min_plan_data_mb?: any;
  max_plan_data_mb?: any;
  service_provider_name?: string[];
  rate_plan_code?: string[];
  allows_sim_pooling?: boolean;
  sms_rate?: string;
  automation_rule?: string[];
  is_active?: boolean;
  soc_code?: string | null;
  product?: string[] | null;
  package?: string | null;
  product_cost?:any[]
  service_type?: string | null;
  use_carrier_activation?: boolean;
  // effective_date: string | null;
}

interface CopyCustomerRatePlanModalProps {
  isOpen: boolean;
  onClose: () => void;
  generalFields: any; // This will contain service_provider_name and soc_list
  rowData: any; // Add rowData prop to receive data for editing
  isEditable: boolean;
}

const CopyCustomerRatePlan: React.FC<CopyCustomerRatePlanModalProps> = ({
  isOpen,
  onClose,
  generalFields,
  rowData,
  isEditable,
}) => {
  const { username, token, partner, selectedDb,metaData,selectedBillingDb, role, settabledata, firstLastName, sessionId, } = useAuth();

  const isAdmin = role?.toLowerCase() === "super admin" || role?.toLowerCase() === "partner admin"

  const socCodeOptions = generalFields?.soc_code
    ?.filter((code: string) => {
      // Exclude if the part after ' - ' is 'None'
      const parts = code.split(" - ");
      return !(parts.length > 1 && parts[0] === "None");
    })
    .map((code: string) => ({
      label: !isAdmin ? code.split(" - ")[1] : code,
      value: code,
    })) || [];

  const [formData, setFormData] = useState<FormData>({
    ...rowData,
    // is_active: rowData?.is_active === "True", // Ensure is_active is a boolean
    // is_billing_advance_eligible: rowData?.is_billing_advance_eligible === "True", // Convert to boolean
    // allows_sim_pooling: rowData?.allows_sim_pooling === "True",
    soc_code: (() => {
      const soc_code_ = rowData?.soc_code || "";
      let matchedCode
      if (soc_code_) {
        matchedCode = socCodeOptions.find((opt: any) =>
          (opt?.value || "").startsWith(soc_code_)
        );
        console.log("matchedCode", matchedCode)
      }
      return matchedCode?.value || matchedCode || ""
    })(), // set matched string or empty
    // effective_date: (() => {
    //   const activation_date = rowData?.effective_date || null;
    //   return activation_date
    // })(),
    product: (() => {
      const product_ = rowData?.product || null;
      return product_
    })(),
     package: (() => {
      const package_ = rowData?.package || null;
      return package_
    })(),
    product_cost: (() => {
      const product_cost_ = rowData?.product_cost || [];
      return product_cost_
    })(),
    use_carrier_activation: (() => {
      const use_carrier_activation_ = rowData?.use_carrier_activation || false;
      return use_carrier_activation_
    })(),
    automation_rule: (() => {
      if (Array.isArray(rowData.automation_rule)) {
        return rowData.automation_rule; // Assign directly if already an array
      }
      if (rowData.automation_rule) {
        try {
          return JSON.parse(rowData.automation_rule); // Parse if it's a string
        } catch (error) {
          console.error("Invalid automation_rule JSON:", error);
          return []; // Fallback to an empty array on parse failure
        }
      }
      return []; // Fallback to an empty array if undefined or null
    })(),
    service_provider_name: (() => {
      if (rowData.optimization_type === "Cross Customer Pooling") {
        // Split service_provider_name string into an array if optimization_type matches
        return typeof rowData.service_provider_name === "string"
          ? rowData.service_provider_name.split(',').map((name: any) => name.trim()) // Split by comma and trim spaces
          : [];
      }
      return rowData.service_provider_name; // Otherwise, return as-is
    })(),
    rate_plan_code: (() => {
      if (rowData.optimization_type === "Cross Customer Pooling") {
        // Split service_provider_name string into an array if optimization_type matches
        return typeof rowData.rate_plan_code === "string"
          ? rowData.rate_plan_code.split(',').map((name: any) => name.trim()) // Split by comma and trim spaces
          : [];
      }
      return rowData.rate_plan_code; // Otherwise, return as-is
    })(),
  });
  const { customerShowActive, setCustomerShowActive } = useCustomerRatePlanStore();
  const [loading, setLoading] = useState(false);
  const [validationErrors, setValidationErrors] = useState<
    Record<string, string>
  >({});
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);
  const [filteredSocOptions, setFilteredSocOptions] = useState<any[]>([]);
  // const [socCodeOptions, setSocCodeOptions] = useState<any[]>([]);
  const providerIDMapping = generalFields.service_provider_mapping || {};
  const [isCrossOptimization, setIsCrossOptimization] = useState(false);
  // Convert service provider names into the format expected by Select
  const providerOptions =
    generalFields.service_provider_name?.map((provider: string) => ({
      label: provider,
      value: provider,
    })) || [];

  // Convert automation rules into the format expected by Select
  const automationRuleOptions =
    generalFields.automation_rule?.map((rule: string) => ({
      label: rule,
      value: rule,
    })) || [];
  //BP Integration state variables

  const [isBPEnabled, setIsBPEnabled] = useState(false);
  const [productsMap, setProductsMap] = useState<any[]>([]);
  const [packageMap, setPackageMap] = useState<any[]>([]);
  const [serviceTypeMap, setServiceTypeMap] = useState<any[]>([]);
  const [productsRateMap, setProductsRateMap] = useState<any[]>([]);
  const [productsOptions, setProductsOptions] = useState<any[]>([]);
  const [packageOptions, setPackageOptions] = useState<any[]>([]);
  const [serviceTypeOptions, setServiceTypeOptions] = useState<any[]>([]);
  const [selectedRates, setSelectedRates] = useState<any[]>([]);
  const [selectedPackage, setSelectedPackage] = useState(null);
  const [selectedserviceType, setSelectedServiceType] = useState(null);
  const [selectedProduct, setSelectedProduct] = useState<any>([]);
  const [useCarrierActivation, setUseCarrierActivation] = useState(true);
   //const providerName = getTargetTenantProvider(rowData?.service_provider_display_name  || "").toLowerCase();
  // const [activationDate, setActivationDate] = useState<dayjs.Dayjs | null>(
  //   formData?.effective_date ? dayjs(formData.effective_date) : null
  // );
const hasInitialized = useRef(false);

  const fetchProductsPackageData = async () => {
    const tenant_id_ = localStorage.getItem("tenant_id") || "0";
    setLoading(true);
    try {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/fetch_product_package_data",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Active Customer Rate Plan",
        feature_module_name: "Customer Rate Plans",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        tenant_id:tenant_id_
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        const product_rate = parsedData?.data?.product_rate || []
        setProductsRateMap(product_rate)
        const product = parsedData?.data?.product || []
        setProductsMap(product)
        const products_options = product.map((product: any) => ({ label: `${product?.description} -- ${product?.product_id}` || "", value: `${product?.description} -- ${product?.product_id}` || "" }))
        setProductsOptions(products_options)
        const package_ = parsedData?.data?.package || []
        setPackageMap(package_)
        const package_options = package_.map((opt: any) => ({ label: `${opt?.category} -- ${opt?.package_id}` || "", value: `${opt?.category} -- ${opt?.package_id}` || "" }))
        setPackageOptions(package_options)
        const service_type_map = parsedData?.data?.service_types || []
        setServiceTypeMap(package_)
        const service_type_options = service_type_map.map((opt: any) => ({ label: `${opt?.description} -- ${opt?.service_type_id}` || "", value: `${opt?.description} -- ${opt?.service_type_id}` || "" }))
        setServiceTypeOptions(service_type_options)
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      setLoading(false);

    }
  };
  const fetchData = async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_cross_provider_optimization_status",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Active Customer Rate Plan",
        feature_module_name: "Customer Rate Plans",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        const cross_carrier_optimization = parsedData?.cross_carrier_optimization || false
        setIsCrossOptimization(cross_carrier_optimization)
        const billing_plaform_flag = parsedData?.billing_platform_flag || false
        setIsBPEnabled(billing_plaform_flag)
        if (billing_plaform_flag) {
          fetchProductsPackageData()
        }
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      setLoading(false);

    }
  };

  useEffect(() => {
    if (isOpen) {
      fetchData()
    }
  }, [isOpen])


  useEffect(() => {
    setFormData({
      ...formData,
      service_provider_name: (() => {
        if (isCrossOptimization) {
          // Split service_provider_name string into an array if optimization_type matches
          return typeof rowData.service_provider_name === "string"
            ? rowData.service_provider_name.split(',').map((name: any) => name.trim()) // Split by comma and trim spaces
            : [];
        }
        return rowData.service_provider_name; // Otherwise, return as-is
      })(),
      rate_plan_code: (() => {
        if (isCrossOptimization) {
          // Split service_provider_name string into an array if optimization_type matches
          return typeof rowData.rate_plan_code === "string"
            ? rowData.rate_plan_code.split(',').map((name: any) => name.trim()) // Split by comma and trim spaces
            : [];
        }
        return rowData.rate_plan_code; // Otherwise, return as-is
      })(),
    })
  }, [isCrossOptimization])
useEffect(() => {
  if (rowData?.product_cost) {
    setSelectedRates(rowData.product_cost); // Contains rate & cost
  }
}, [rowData]);


  const isAtAndTTelegence = (serviceProviderName: string[] | string | undefined): boolean => {
    if (Array.isArray(serviceProviderName)) {
      return serviceProviderName.some(name => name.includes("AT&T - Telegence"));
    }
    return typeof serviceProviderName === "string" && serviceProviderName.includes("AT&T - Telegence");
  };

  // Update the useEffect to filter and map SOC options based on the selected provider
  useEffect(() => {
    if (formData.service_provider_name && formData.service_provider_name.length > 0) {
      const socList = generalFields.soc_list || [];
      const filteredSocs = socList
        .filter((soc_list: string[]) => formData.service_provider_name?.includes(soc_list[1])) // Match the provider name
        .map((soc_list: string[]) => ({
          label: soc_list[0], // SOC code (first element)
          value: soc_list[0], // SOC code (first element)
        }));
      setFilteredSocOptions(filteredSocs);
    } else {
      setFilteredSocOptions([]);
    }
  }, [formData.service_provider_name, generalFields.soc_list]);
  const handleChange = (field: keyof FormData, value: any) => {
    if (field === "optimization_type") {
      setFormData((prev) => ({
        ...prev,
        [field]: value,
        // service_provider_name: [],
        // rate_plan_code: [],
        // automation_rule: [], // Clear the field
        // soc_code: null, // Clear the field
      }));
    } else if (field === "service_provider_name" || field === "rate_plan_code") {
      // Ensure the value is an array, even if it's a single value
      setFormData((prev) => ({
        ...prev,
        [field]: Array.isArray(value) ? value : [value],
      }));
      if (field === "service_provider_name") {
        setFormData((prev) => ({
          ...prev,
          automation_rule: [], // Clear the field
          soc_code: "", // Clear the field

        }));
      }
    } else if (field === "automation_rule") {
      // Handle multiple selected values for automation rules
      setFormData((prev) => ({
        ...prev,
        [field]: value.map((option: any) => option.value), // Store only the values
      }));
    } else {
      setFormData((prev) => ({ ...prev, [field]: value }));
    }
  };

  useEffect(() => {
      if (selectedRates.length>0) {
        let sum_of_rates=0
        selectedRates.forEach((item: any) => {
        const rate = Number(item?.rate) || 0
        sum_of_rates += rate;
      });
      const basRate=sum_of_rates
      setFormData((prev) => ({
          ...prev,
          base_rate: basRate !==0 ? basRate.toString() : '',
        }));
      }
      else{
        setFormData((prev) => ({
          ...prev,
          base_rate: '',
        }));
      }
    }, [selectedRates])
  const validateForm = () => {
    const errors: Record<string, string> = {};

    // Check if optimization_type is provided
    if (!formData.optimization_type) {
      errors.optimization_type = "Optimization type is required";
    }

    // Define mandatory fields
    const mandatoryFields: Array<keyof FormData> = [
      "plan_mb",
      "rate_plan_name",
      "base_rate",
      "rate_charge_amt",
      "overage_rate_cost",
      "data_per_overage_charge",
      "sms_rate",
      "service_provider_name",
      "rate_plan_code",
    ];

    // Create a mapping for display names
    const fieldDisplayNames: Record<string, string> = {
      plan_mb: "Plan MB",
      rate_plan_name: "Rate plan name",
      base_rate: "Base rate",
      rate_charge_amt: "Rate charge", // Change here
      overage_rate_cost: "Overage rate cost",
      data_per_overage_charge: "Data per overage charge",
      sms_rate: "SMS rate",
      service_provider_name: "Provider name",
      rate_plan_code: "Rate plan code",
    };

    // Validate mandatory fields
    mandatoryFields.forEach((field) => {
      if (
        formData[field] === null ||
        formData[field] === undefined ||
        formData[field] === "" ||
        formData[field] === "None" || formData[field] === "None" ||
        (Array.isArray(formData[field]) && formData[field].length === 0 && field !== 'rate_plan_code')
      ) {
        errors[field] = `${fieldDisplayNames[field]} is required`;
      }
      if (!formData[field] && filteredSocOptions.length > 0 && field === 'rate_plan_code') {
        errors[field] = `${fieldDisplayNames[field]} is required`;
      }
    });
    Object.keys(formData).forEach((field) => {
      if (
        field === "base_rate" ||
        field === "rate_charge_amt" ||
        field === "overage_rate_cost" ||
        field === "data_per_overage_charge" ||
        field === "min_plan_data_mb" ||
        field === "max_plan_data_mb" ||
        field === "plan_mb") {
        console.log("field", field);
        const regex = /^[^a-zA-Z\s]*$/; // Regex to avoid alphabets and spaces
        const value = formData[field]
          ? formData[field].toString().replace('$', '').trim()  // Remove '$' and trim whitespace
          : '0';
        console.log("value", value);
        if ((formData[field] !== null &&
          formData[field] !== undefined &&
          formData[field] !== "" &&
          formData[field] !== "None") && formData[field] !== "None" && !regex.test(value)) {
          errors[field] = "Alphabets are not allowed";
        }
      }


    });

    if (isBPEnabled) {
      if(!formData['service_type']){
        errors['service_type'] = 'Service Type is required'
      }
      else{
        delete errors['service_type']
      }
    //   if ((formData['product'] && formData['product'].length === 0) && !formData['package']) {
    //     console.log("")
    //     errors["product"] = "Either Product or Package is required"
    //     errors["package"] = "Either Product or Package is required"
    //   }
    //   else {
    //     delete errors["product"]
    //     delete errors["package"]
    //   }
    }

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleEdit = () => {
    if (validateForm()) {
      if (isBPEnabled) {
        if (selectedRates.length === 0) {
          Modal.error({
            title: "Validation Error",
            content: "Selected package has no associated products",
            centered: true,
          })
        }
        else {

          setIsConfirmationOpen(true);
        }
      }
      else {

        setIsConfirmationOpen(true);
      }

    }
  };

  const handleSwitchChange = (checked: boolean) => {
    setCustomerShowActive(checked);
  };

  const removeDollarSignFromFormData = (data: any) => {
    const cleanedData = { ...data }; // Create a shallow copy to avoid mutating the original formData

    // List of fields to clean from the formData (add more fields as necessary)
    const fieldsToClean = [
      "base_rate",
      "rate_charge_amt",
      "overage_rate_cost",
      "sms_rate",
      "min_plan_data_mb",
      "max_plan_data_mb",
      "data_per_overage_charge",
    ];

    fieldsToClean.forEach((field) => {
      if (cleanedData[field]) {
        cleanedData[field] = cleanedData[field].replace(/^\$/, ""); // Remove leading $
      }

      if (field === "min_plan_data_mb" || field === "max_plan_data_mb") {
        if (!cleanedData[field] || cleanedData[field] === "")
          cleanedData[field] = null;
      }
    });



    return cleanedData;
  };
  const handleConfirmEdit = async () => {
    if (formData) {
      // Preprocess formData to remove any dollar signs from numeric fields
      const cleanedFormData = removeDollarSignFromFormData(formData);
      // convert rate_plan_code is a string
      if (Array.isArray(cleanedFormData.rate_plan_code)) {
        cleanedFormData.rate_plan_code = cleanedFormData.rate_plan_code.join(','); // Or use `.toString()` if comma-separated values are acceptable
      }
      cleanedFormData["modified_by"] = firstLastName;
      cleanedFormData["service_provider_name"] = isCrossOptimization
        ? cleanedFormData?.service_provider_name
        : Array.isArray(cleanedFormData?.service_provider_name)
          ? cleanedFormData?.service_provider_name.join(',')
          : cleanedFormData?.service_provider_name || ""; // Fallback to empty string if undefined
      console.log(cleanedFormData['service_provider_name'], "Show the service provider name");
      if (Array.isArray(cleanedFormData?.service_provider_name)) {
        // Handle array of service provider names
        cleanedFormData["service_provider_id"] = cleanedFormData.service_provider_name.map(
          (name: any) => providerIDMapping?.[name] || null // Use null or an appropriate fallback if mapping not found
        ).filter((id: any) => id !== null); // Optionally filter out null values if needed
      } else {
        // Handle single string service provider name
        cleanedFormData["service_provider_id"] = providerIDMapping?.[cleanedFormData.service_provider_name] || cleanedFormData?.["service_provider_id"];
      }
      cleanedFormData["modified_date"] = getCurrentDateTime();
      delete cleanedFormData['service_provider'];
      delete cleanedFormData['deleted_date'];
      cleanedFormData['is_deleted'] = false;
      delete cleanedFormData['id'];
      cleanedFormData['created_by'] = firstLastName;
      cleanedFormData['created_date'] = getCurrentDateTime();
      cleanedFormData['automation_rule_flag'] = cleanedFormData.automation_rule.length === 0 ? false : true,
        cleanedFormData["soc_code"] = cleanedFormData["soc_code"] && cleanedFormData["soc_code"].split(" - ")[0] || cleanedFormData["soc_code"]

      if (!isBPEnabled) {
        delete cleanedFormData["product"]
        delete cleanedFormData["package"]
      }
      else {
        cleanedFormData["use_carrier_activation"] = useCarrierActivation
        // cleanedFormData["effective_date"] = activationDate
        cleanedFormData["product_cost"] = selectedRates

      }
      console.log(cleanedFormData, "Show the cleaned form data");
      const syncData = {
        customerrateplan: [{

          ...(cleanedFormData.rate_plan_code && { rate_plan_code: cleanedFormData.rate_plan_code }),
          ...(cleanedFormData.plan_mb && { plan_mb: cleanedFormData.plan_mb }),
          ...(cleanedFormData.base_rate && { base_rate: cleanedFormData.base_rate }),
          modified_by: firstLastName,
          modified_date: getCurrentDateTime(),
          ...(cleanedFormData.id && { id: cleanedFormData.id }),
          is_deleted: false,
          ...(cleanedFormData.is_active && { is_active: cleanedFormData.is_active }),
          ...(cleanedFormData.rate_charge_amt && { rate_charge_amt: cleanedFormData.rate_charge_amt }),
          ...(cleanedFormData.data_per_overage_charge && { data_per_overage_charge: cleanedFormData.data_per_overage_charge }),
          ...(cleanedFormData.overage_rate_cost && { overage_rate_cost: cleanedFormData.overage_rate_cost }),
          allows_sim_pooling: cleanedFormData.allows_sim_pooling,
          is_billing_advance_eligible: cleanedFormData.is_billing_advance_eligible,
          ...(cleanedFormData.sms_rate && { sms_rate: cleanedFormData.sms_rate }),
          ...(cleanedFormData.rate_plan_name && { rate_plan_name: cleanedFormData.rate_plan_name }),
          ...(cleanedFormData.min_plan_data_mb && { min_plan_data_mb: cleanedFormData.min_plan_data_mb }),
          ...(cleanedFormData.max_plan_data_mb && { max_plan_data_mb: cleanedFormData.max_plan_data_mb }),
          ...(cleanedFormData.optimization_type && { optimization_type: cleanedFormData.optimization_type }),
          ...(cleanedFormData.service_provider_name && { service_provider_name: cleanedFormData.service_provider_name }),
          ...(cleanedFormData.service_provider_id && { service_provider_id: cleanedFormData.service_provider_id }),
          ...(cleanedFormData.automation_rule && { automation_rule: cleanedFormData.automation_rule }),
          ...(cleanedFormData.automation_rule.length === 0 ? { automation_rule_flag: false } : { automation_rule_flag: true }),
          ...(cleanedFormData.soc_code && { soc_code: cleanedFormData.soc_code }),
        }],
      };
      console.log(syncData, "show syncData");
      console.log(cleanedFormData, "show cleanedFormData");
      // Prepare the payload with cleaned data
      const payload = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/update_sim_management_modules_data",
        role_name: role,
        parent_module: "Sim Management",
        module: "Customer Rate Plan",
        action: "create",
        table_name: "customerrateplan",
        new_data: cleanedFormData,  // Use cleanedFormData here
        // sync_data: syncData,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };

      try {
        setLoading(true);
        setIsConfirmationOpen(false);

        // Make API call to save data
        const response = await axios.post(ENV_ROUTES.SIM_MANAGEMENT, { data: payload });
        const parsedResponse = JSON.parse(response.data.body);

        if (parsedResponse.flag === false) {
          Modal.error({
            title: "Saving Error",
            content:
              parsedResponse.message ||
              "An error occurred while saving data. Please try again.",
            centered: true,
          });
        } else {
          // Fetch updated data
          const url = ENV_ROUTES.SIM_MANAGEMENT;
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/get_customer_rate_plan_list_view_data",
            role_name: role,
            parent_module: "Sim Management",
            module_name: customerShowActive ? "Active Customer Rate Plan" : "Customer Rate Plan",
            feature_module_name: "Customer Rate Plans",
            mod_pages: {
              start: 0,
              end: 100,
            },
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            sync_data: syncData,
            access_token: token,
            db_name: selectedDb,
            ...metaData,
            sessionID: sessionId,
          };

          const fetchResponse = await axios.post(url, { data });
          const parsedData = JSON.parse(fetchResponse.data.body);
          const tableData_ = parsedResponse?.data?.customerrateplan || []
          settabledata(tableData_)

          if (parsedData.flag === false) {
            Modal.error({
              title: 'Data Fetch Error',
              content: parsedData.message || 'An error occurred while fetching data. Please try again.',
              centered: true,
            });
          } else {
            const tableData = parsedData?.data?.customerrateplan || [];
            settabledata(tableData);
          }

          notification.success({
            message: "Success",
            description: "Customer rate plan updated successfully!",
            placement: "top",
          });
          const customerRatePlanId = parsedResponse.data; // Assuming this is the ID you need

          // Prepare the second API payload
          const secondApiPayload = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/run_db_script",
            role_name: role,
            module_name: "Customer Rate Plan",
            mod_pages: {
              start: 0,
              end: 100,
            },
            access_token: token,
            db_name: selectedDb,
            ...metaData,
            sessionID: sessionId,
            // update_flag: true,
            request_received_at: getCurrentDateTime(),
            Partner: partner || "default_value",
            data: {
              customer_rate_plan: customerRatePlanId,
              // ...syncData // Use the ID from the first response
            },
          };

          // Call the second API
          await axios.post(ENV_ROUTES.SIM_MANAGEMENT, { data: secondApiPayload });
          onClose();
        }
      } catch (err) {
        console.error("Error saving data:", err);
        notification.error({
          message: "Error",
          description:
            "Failed to update the customer rate plan. Please try again.",
          placement: "top",
        });
      } finally {
        setLoading(false);
        setIsConfirmationOpen(false);
      }
    }
  };


  const handleCancelConfirmation = () => {
    setIsConfirmationOpen(false);
  };

  const handleModalClose = () => {
    setFormData(rowData); // Reset form data to rowData
    setValidationErrors({}); // Clear validation errors
    onClose(); // Close the modal
  };


const handlePackageChange = (selectedOption: any) => {
  if (selectedOption) {
    const selectedValue = selectedOption?.value || "";
    setFormData((prev) => ({ ...prev, package: selectedValue, product: [] }));
    setSelectedProduct([]);

    const matchedItem = packageMap.find(
      (item: any) => `${item?.category} -- ${item?.package_id}` === selectedValue
    );
    const matchedProductList = matchedItem?.products_list || [];

    const matchedRates = productsRateMap.filter((product: any) =>
      matchedProductList.some(
        (option: any) => option?.description === product?.description
      )
    );

    setSelectedRates(matchedProductList);
    setSelectedPackage(selectedValue);
  } else {
    setFormData((prev) => ({ ...prev, package: null }));
    setSelectedPackage(null);
    setSelectedRates([]);
  }
};


  const handleServiceTypeChange = (selectedOption: any) => {
    if (selectedOption) {
      const selectedValue = selectedOption?.value || "";
      setFormData((prev) => ({ ...prev, service_type: selectedValue ,product:null,package:null}));
      setSelectedServiceType(selectedValue);
      setSelectedRates([])

    } else if (selectedOption === null) {
      setFormData((prev) => ({ ...prev, service_type: null ,product:null,package:null}));
      setSelectedServiceType(null);
      setSelectedRates([])
    }
  };

const handleProductChange = (selectedOptions: any) => {
  if (Array.isArray(selectedOptions)) {
    const values = selectedOptions.map((option: any) => option.value);
    setFormData((prev) => ({ ...prev, product: values, package: null }));
    setSelectedPackage(null);

    // Get already selectedRates from state
    const currentRates = [...selectedRates];

    // Build new list
    const updatedRates = values.map((value: string) => {
      // Check if it already exists in current selectedRates
      const existing = currentRates.find(
        (item) => `${item.description} -- ${item.product_id}` === value
      );

      if (existing) return existing;

      // Else, find it from master productRateMap
      const fresh = productsRateMap.find(
        (product) => `${product.description} -- ${product.product_id}` === value
      );

      return fresh ? { ...fresh } : { description: "", product_id: "", cost: 0, rate: 0 };
    });

    setSelectedRates(updatedRates);
    setSelectedProduct(values);
  } else {
    setFormData((prev) => ({ ...prev, product: [] }));
    setSelectedProduct([]);
    setSelectedRates([]);
  }
};



  const getSOCCOdeLabel = (socCode: any) => {

    const matchedCode = socCodeOptions.find((opt: any) =>
      (opt?.value || "").startsWith(socCode)
    );

    return matchedCode?.label || matchedCode || ""
  }

  const modalHeight =
    typeof window !== "undefined" ? (window.innerHeight * 2.5) / 4 : 0;
  console.log(formData, "show formData");
  console.log(formData["is_billing_advance_eligible"], "Show formdata")
  return (
    <>
      <Modal
        title="Copy Customer Rate Plan"
        open={isOpen}
        onCancel={handleModalClose}
        footer={
          <div className="flex justify-center space-x-2">
            <Button onClick={handleModalClose} className="cancel-btn">
              Cancel
            </Button>
            <Button onClick={handleEdit} className="save-btn">
              Save
            </Button>
          </div>
        }
        centered
        width={800}
      >
        {loading ? (
          <div
            className="flex justify-center items-center"
            style={{ height: modalHeight }}
          >
            <Spin size="large" />
          </div>
        ) : (
          <div
            style={{
              height: modalHeight,
              overflowY: "auto",
              overflowX: "hidden",
              padding: "4px",
            }}
          >
            <div className="flex flex-col space-y-4">
              <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
                <div>
                  <label className="field-label">
                    Optimization Type <span className="text-red-500">*</span>
                  </label>
                  <div className="flex items-center gap-3">
                    <Select
                      className="w-full"
                      styles={DropdownStyles}
                      placeholder="Select Optimization Type"
                      value={
                        formData["optimization_type"]
                          ? {
                            label: formData["optimization_type"],
                            value: formData["optimization_type"],
                          }
                          : null
                      }
                      onChange={(option: any) =>
                        handleChange("optimization_type", option.value)
                      }
                      options={[
                        {
                          label: "Standard",
                          value: "Standard",
                        },
                        {
                          label: "Auto Change Rate Plan",
                          value: "Auto Change Rate Plan",
                        },
                        {
                          label: "Cross Customer Pooling",
                          value: "Cross Customer Pooling",
                        },
                      ]}
                    />
                    <Popover
                      content={
                        <img
                          src="/images/rate-plan-info.png"
                          alt="Rate Plan Info"
                          style={{ width: "400px" }}
                        />
                      }
                      trigger="hover"
                      placement="right"
                    >
                      <InformationCircleIcon className="w-5 h-5 text-blue-600 cursor-pointer" />
                    </Popover>
                  </div>
                  {validationErrors["optimization_type"] && (
                    <span className="text-red-500">
                      {validationErrors["optimization_type"]}
                    </span>
                  )}
                </div>
                {formData["optimization_type"] && (
                  <>
                    <div>
                      <label className="field-label">
                        MB Included <span className="text-red-500">*</span>
                      </label>
                      <Input
                        value={formData["plan_mb"]}
                        className="input"
                        onChange={(e) =>
                          handleChange("plan_mb", e.target.value)
                        }
                        placeholder="Enter MB Included"
                      />
                      {validationErrors["plan_mb"] && (
                        <span className="text-red-500">
                          {validationErrors["plan_mb"]}
                        </span>
                      )}
                    </div>
                    <div>
                      <label className="field-label">
                        Rate Plan Name <span className="text-red-500">*</span>
                      </label>
                      <Input
                        value={formData["rate_plan_name"]}
                        className="input"
                        onChange={(e) =>
                          handleChange("rate_plan_name", e.target.value)
                        }
                        placeholder="Enter rate plan name"
                      />
                      {validationErrors["rate_plan_name"] && (
                        <span className="text-red-500">
                          {validationErrors["rate_plan_name"]}
                        </span>
                      )}
                    </div>
                    <div>
                      <label className="field-label">
                        Base Rate <span className="text-red-500">*</span>
                      </label>
                      <Input
                        value={formData["base_rate"]}
                        className={`${isBPEnabled ? 'non-editable-input' : 'input'}`}
                        onChange={(e) =>
                          handleChange("base_rate", e.target.value)
                        }
                        placeholder="Enter base rate"
                        disabled={isBPEnabled}
                      />
                      {validationErrors["base_rate"] && (
                        <span className="text-red-500">
                          {validationErrors["base_rate"]}
                        </span>
                      )}
                    </div>
                    <div>
                      <label className="field-label">
                        Rate Charge <span className="text-red-500">*</span>
                      </label>
                      <Input
                        value={formData["rate_charge_amt"]}
                        className="input"
                        onChange={(e) =>
                          handleChange("rate_charge_amt", e.target.value)
                        }
                        placeholder="Enter rate charge"
                      />
                      {validationErrors["rate_charge_amt"] && (
                        <span className="text-red-500">
                          {validationErrors["rate_charge_amt"]}
                        </span>
                      )}
                    </div>
                    <div>
                      <Checkbox
                        checked={formData["is_billing_advance_eligible"]}
                        onChange={(e) =>
                          handleChange(
                            "is_billing_advance_eligible",
                            e.target.checked
                          )
                        }
                        className="checkbox"
                      >
                        Bill in Advance (bills Rate Charge Separately from
                        Overage)
                      </Checkbox>
                    </div>
                    <div>
                      <label className="field-label">
                        Overage Rate Cost{" "}
                        <span className="text-red-500">*</span>
                      </label>
                      <Input
                        value={formData["overage_rate_cost"]}
                        className="input"
                        onChange={(e) =>
                          handleChange("overage_rate_cost", e.target.value)
                        }
                        placeholder="Enter Overage Rate Cost"
                      />
                      {validationErrors["overage_rate_cost"] && (
                        <span className="text-red-500">
                          {validationErrors["overage_rate_cost"]}
                        </span>
                      )}
                    </div>
                    <div>
                      <label className="field-label">
                        Data Per Overage Charge{" "}
                        <span className="text-red-500">*</span>
                      </label>
                      <Input
                        value={formData["data_per_overage_charge"]}
                        className="input"
                        onChange={(e) =>
                          handleChange(
                            "data_per_overage_charge",
                            e.target.value
                          )
                        }
                        placeholder="Enter Data Per Overage Charge"
                      />
                      {validationErrors["data_per_overage_charge"] && (
                        <span className="text-red-500">
                          {validationErrors["data_per_overage_charge"]}
                        </span>
                      )}
                    </div>
                    <div>
                      <label className="field-label">Min. plan MB</label>
                      <Input
                        value={formData["min_plan_data_mb"] !== "None" ? formData["min_plan_data_mb"] : ''}
                        className="input"
                        onChange={(e) =>
                          handleChange("min_plan_data_mb", e.target.value)
                        }
                        placeholder="Enter min. Plan MB"
                      />
                      {validationErrors["min_plan_data_mb"] && (
                        <span className="text-red-500">
                          {validationErrors["min_plan_data_mb"]}
                        </span>
                      )}
                    </div>
                    <div>
                      <label className="field-label">Max. plan MB</label>
                      <Input
                        value={formData["max_plan_data_mb"] !== "None" ? formData["max_plan_data_mb"] : ''}
                        className="input"
                        onChange={(e) =>
                          handleChange("max_plan_data_mb", e.target.value)
                        }
                        placeholder="Enter max Plan MB"
                      />
                      {validationErrors["max_plan_data_mb"] && (
                        <span className="text-red-500">
                          {validationErrors["max_plan_data_mb"]}
                        </span>
                      )}
                    </div>
                    <div>
                      <label className="field-label">
                        Provider <span className="text-red-500">*</span>
                      </label>
                      <Select
                        className="w-full"
                        styles={DropdownStyles}
                        placeholder="Select Provider"
                        isMulti={isCrossOptimization} // Conditional multi-select
                        value={
                          Array.isArray(formData.service_provider_name)
                            ? isCrossOptimization
                              ? formData.service_provider_name.map((name) => ({
                                label: name,
                                value: name,
                              })) // Multi-select: Map array to objects
                              : formData.service_provider_name[0] // Single-select: Use the first element
                                ? {
                                  label: formData.service_provider_name[0],
                                  value: formData.service_provider_name[0],
                                }
                                : null // Fallback if the array is empty
                            : formData.service_provider_name // Handle single value directly
                              ? {
                                label: formData.service_provider_name,
                                value: formData.service_provider_name,
                              }
                              : null // Fallback if service_provider_name is null or undefined
                        }
                        onChange={(options: any) => {
                          const selectedValues =
                            isCrossOptimization
                              ? (Array.isArray(options) ? options.map((option: any) => option.value) : [])
                              : options
                                ? options.value
                                : null; // For single select
                          handleChange("service_provider_name", selectedValues);
                          console.log(selectedValues, "Show the selected values")
                        }}
                        options={providerOptions}
                        menuPlacement="auto"
                      />
                      {validationErrors["service_provider_name"] && (
                        <span className="text-red-500">{validationErrors["service_provider_name"]}</span>
                      )}
                    </div>
                    <div>
                      <label className="field-label">
                        Rate Plan Code <span className="text-red-500">*</span>
                      </label>
                      <CreatableSelect
                        isClearable
                        className="w-full"
                        styles={DropdownStyles}
                        placeholder="Select or type rate plan code"
                        isMulti={isCrossOptimization}
                        value={
                          Array.isArray(formData["rate_plan_code"]) // Check if it's an array
                            ? formData["rate_plan_code"].map((code) => ({
                              label: code,
                              value: code,
                            }))
                            : formData["rate_plan_code"] // If not an array, handle it as a single value
                              ? {
                                label: formData["rate_plan_code"],
                                value: formData["rate_plan_code"],
                              }
                              : null // Fallback if rate_plan_code is null or undefined
                        }

                        onChange={(options: any) => {
                          const selectedValues = isCrossOptimization
                            ? Array.isArray(options)
                              ? options.map((option: any) => option.value)
                              : []
                            : options
                              ? options.value
                              : null;
                          handleChange("rate_plan_code", selectedValues);
                        }}

                        onCreateOption={(inputValue: string) => {
                          // Handle the creation of a new option
                          const newOption = {
                            value: inputValue,
                            label: inputValue,
                          };

                          if (isCrossOptimization) {
                            // For multi-select, append to existing values
                            const currentValues =
                              formData["rate_plan_code"] || [];
                            handleChange("rate_plan_code", [
                              ...currentValues,
                              inputValue,
                            ]);
                          } else {
                            // For single select
                            handleChange("rate_plan_code", inputValue);
                          }
                        }}
                        options={filteredSocOptions}
                        formatCreateLabel={(inputValue: string) =>
                          `Add "${inputValue}"`
                        }
                      />
                      {validationErrors["rate_plan_code"] && (
                        <span className="text-red-500">{validationErrors["rate_plan_code"]}</span>
                      )}
                    </div>
                    <div>
                      <Checkbox
                        checked={formData["allows_sim_pooling"]}
                        onChange={(e) =>
                          handleChange("allows_sim_pooling", e.target.checked)
                        }
                        className="checkbox"
                      >
                        Pool Sims (Applies to all Plans Sharing this Rate Plan
                        Code)
                      </Checkbox>
                    </div>
                    <div>
                      <label className="field-label">
                        SMS per Message Rate{" "}
                        <span className="text-red-500">*</span>
                      </label>
                      <Input
                        value={formData["sms_rate"]}
                        className="input"
                        onChange={(e) =>
                          handleChange("sms_rate", e.target.value)
                        }
                        placeholder="Enter SMS per message rate"
                      />
                      {validationErrors["sms_rate"] && (
                        <span className="text-red-500">
                          {validationErrors["sms_rate"]}
                        </span>
                      )}
                    </div>
                    <div>
                      <label className="field-label">Automation Rule</label>
                      <Select
                        className="w-full"
                        styles={
                          isAtAndTTelegence(formData?.['service_provider_name'])
                            ? DropdownStyles
                            : NonEditableDropdownStyles
                        }
                        placeholder="Select Automation Rule"
                        value={Array.isArray(formData.automation_rule)
                          ? formData.automation_rule.map((rule) => ({
                            label: rule,
                            value: rule,
                          }))
                          : []}
                        onChange={(options: any) => {
                          handleChange("automation_rule", options);
                        }}
                        options={automationRuleOptions}
                        isDisabled={
                          !isAtAndTTelegence(formData?.['service_provider_name'])
                        } // Enable only for "AT&T - Telegence"
                        isMulti // Enable multi-select
                        menuPlacement="auto"
                      />
                    </div>
                    <div>
                      <label className="field-label">Status</label>
                      <div className="flex items-center">
                        <span className="mr-2 w-12">
                          {formData["is_active"] ? "Active" : "Inactive"}
                        </span>
                        <Switch
                          checked={formData["is_active"]}
                          onChange={() =>
                            handleChange("is_active", !formData["is_active"])
                          }
                        />
                      </div>
                    </div>

                    {isAtAndTTelegence(formData?.['service_provider_name']) && (
                      <div>
                        <label className="field-label">
                          {isAdmin ? "SOC Code" : "Carrier Rate Plan"}
                        </label>
                        <Select
                          isClearable
                          className="w-full"
                          styles={DropdownStyles}
                          // styles={!formData.automation_rule || formData.automation_rule.length===0?NonEditableDropdownStyles:DropdownStyles}
                          placeholder={`Select ${isAdmin ? "SOC Code" : "Carrier Rate Plan"}`}
                          value={formData["soc_code"]
                            ? {
                              label: !isAdmin ? getSOCCOdeLabel(formData["soc_code"]) : formData["soc_code"],
                              value: !isAdmin ? getSOCCOdeLabel(formData["soc_code"]) : formData["soc_code"],
                            }
                            : null
                          }
                          onChange={(options: any) => {
                            const selectedValues =
                              options
                                ? options.value
                                : null; // For single select
                            handleChange("soc_code", selectedValues);
                          }}
                          options={socCodeOptions}
                          menuPlacement="top"
                        // isDisabled={!formData.automation_rule || formData.automation_rule.length===0}
                        />
                      </div>
                    )}
                    {isBPEnabled && (
                      <>
                        <div>
                          <label className="field-label">
                            Service Type <span className="text-red-500">*</span>
                          </label>
                          <Select
                            className="w-full"
                            isClearable
                            styles={DropdownStyles}
                            placeholder="Select a Service Type"
                            value={formData["service_type"] ?
                              {
                                label: formData["service_type"],
                                value: formData["service_type"]
                              }
                              : null

                            }
                            onChange={handleServiceTypeChange}
                            options={serviceTypeOptions}
                          />
                          {validationErrors["service_type"] && (
                            <span className="text-red-500">
                              {validationErrors["service_type"]}
                            </span>
                          )}
                        </div>
                        <div>
                          <label className="field-label">
                            Package <span className="text-red-500">*</span>
                          </label>
                          <Select
                            className="w-full"
                            isClearable
                            styles={formData["product"] && formData["product"].length > 0 ? NonEditableDropdownStyles : DropdownStyles}
                            // styles={NonEditableDropdownStyles}
                            placeholder="Select a Package"
                            value={formData["package"] ?
                              {
                                label: formData["package"],
                                value: formData["package"]
                              }
                              : null

                            }
                            isDisabled={formData["product"] && formData["product"].length > 0 ? true : false}
                            onChange={handlePackageChange}
                            options={packageOptions}
                          />
                          {/* {validationErrors["package"] && (
                            <span className="text-red-500">
                              {validationErrors["package"]}
                            </span>
                          )} */}
                          <span className="font-semibold mt-4 block">OR</span>

                        </div>

                        <div>
                          <label className="field-label">
                            Rates  <span className="text-red-500">*</span>
                          </label>
                          <div className="grid grid-cols-3 gap-4 items-center">
                            {/* Headings */}
                            <div className="font-semibold">Product</div>
                            <div className="font-semibold">Cost</div>
                            <div className="font-semibold">Rate</div>

                            {/* Data rows */}
                            {selectedRates.map((product, index) => (
                              <React.Fragment key={index}>
                                {/* Product description */}
                                <span>{`${product?.description} -- ${product?.product_id}` || '-'}</span>

                                {/* Editable Cost */}
                                <input
                                  type="number"
                                  disabled
                                  value={product?.cost ?? ''}
                                  className="non-editable-input"
                                />

                                {/* Disabled Rate */}
                                <input
                                  type="number"
                                  value={product?.rate ?? ''}
                                  disabled={formData['package']?true:false}
                                  onChange={(e) => {
                                    const updatedCost = e.target.value;
                                    setSelectedRates((prev) =>
                                      prev.map((p, i) =>
                                        i === index ? { ...p, rate: updatedCost } : p
                                      )
                                    );
                                  }}
                                  className={`${formData['package']? 'non-editable-input':'input'}`}
                                />
                              </React.Fragment>
                            ))}
                          </div>

                        </div>
                        <div>
                          <label className="field-label">
                            Product <span className="text-red-500">*</span>
                          </label>
                          <Select
                            className="w-full"
                            styles={formData["package"] ? NonEditableDropdownStyles : DropdownStyles}
                            // styles={NonEditableDropdownStyles}
                            placeholder="Select Products"
                            isMulti
                              value={
                                Array.isArray(formData["product"])
                                  ? formData["product"].map((product) => ({
                                    label: product,
                                    value: product,
                                  }))
                                  : []
}

                            isDisabled={formData["package"] ? true : false}
                            onChange={handleProductChange}
                            options={productsOptions}
                          />
                          {/* {validationErrors["product"] && (
                            <span className="text-red-500">
                              {validationErrors["product"]}
                            </span>
                          )} */}
                        </div>

                        <div>
                          <Checkbox
                            checked={formData["use_carrier_activation"] || useCarrierActivation}
                            onChange={(e) => {
                              setUseCarrierActivation(e.target.checked)
                              setFormData((prev) => ({ ...prev, use_carrier_activation: e.target.checked }));
                            }}
                            className='mt-4'
                            disabled
                          >
                            Use Carrier Activation
                          </Checkbox>
                          {/* <label>Use Carrier Activation?</label> */}
                        </div>
                        {/* <div>
                          <label>Activation Date</label>
                          <DatePicker
                            style={{ width: '100%' }}
                            value={activationDate}
                            onChange={(date) => {
                              if (date) {
                                const safeDate = date.hour(12).minute(0).second(0).millisecond(0);
                                setActivationDate(safeDate);
                                setFormData((prev) => ({
                                  ...prev,
                                  effective_date: safeDate.format("YYYY-MM-DD"), // only the date part
                                }));
                              } else {
                                setActivationDate(null);
                                setFormData((prev) => ({
                                  ...prev,
                                  effective_date: null,
                                }));
                              }
                            }}
                            className="input p-[7px]"
                            disabled={useCarrierActivation}
                          />
                        </div> */}

                      </>
                    )}
                  </>
                )}
              </div>
            </div>
          </div>
        )}
      </Modal>
      <Modal
        title="Confirmation"
        open={isConfirmationOpen}
        onOk={handleConfirmEdit}
        onCancel={handleCancelConfirmation}
        centered
      >
        <p>Are you sure you want to update this customer rate plan</p>
      </Modal>
    </>
  );
};

export default CopyCustomerRatePlan;
