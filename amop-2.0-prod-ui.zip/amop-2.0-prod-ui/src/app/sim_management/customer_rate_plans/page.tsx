"use client";
import React, { useEffect, useState, lazy, Suspense, useRef, useCallback } from "react";
import {
  PlusIcon,
  ArrowDownTrayIcon,
  ArrowUpTrayIcon,
} from "@heroicons/react/24/outline";
import { Button, Modal, Spin, DatePicker, notification, Upload, message, Switch } from "antd";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import dayjs, { Dayjs } from "dayjs";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { DownloadOutlined, SettingOutlined, UploadOutlined, DoubleLeftOutlined } from "@ant-design/icons";
import Optimize from "../optimize";
import { RenderPerformanceMatrixModal } from "@/app/performance_modal";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import CreateCustomerRatePlan from "./createCustomerRatePlan";
import { useCustomerRatePlanStore } from "@/app/stores/customerRateplanStore";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";

const { RangePicker } = DatePicker;
const TableComponent = lazy(() => import("@/app/components/TableComponent/page"));
const CreateModal = lazy(() => import("@/app/components/createPopup"));
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));
const TableSearch = lazy(() => import("@/app/components/entire_table_search"));
const AdvancedMultiFilter = lazy(() => import("@/app/components/advanced_search"));

const SimManagementCustomerRatePlan: React.FC = () => {
  const { customerShowActive, setCustomerShowActive} = useCustomerRatePlanStore();
  const [isCreateModalOpen, setCreateModalOpen] = useState(false);
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, settabledata, token, tenantId, tenantName, selectedDb, metaData, advancedStoredpagination, setStoredPagination,setAdvancedStoredPagination,storedpagination,firstLastName,sessionId, combineAdnvaceStoredpagination,setCombineAdnvaceStoredpagination, dynamicColumns, setDynamicColumns} = useAuth();
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([null, null]);
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [createModalData, setcreateModalData] = useState<any[]>([]);
  const [generalFields, setgeneralFields] = useState<any[]>([])
  const [isOptimizeModalVisible, setIsOptimizeModalVisible] = useState(false);
  // const { features: moduleFeatures, setFeatures: setModuleFeatures } = useFeatureStore();
  const [isUploadModalVisible, setIsUploadModalVisible] = useState(false);
  const [appendChecked, setAppendChecked] = useState(false);
  const [overwriteChecked, setOverwriteChecked] = useState(false);
  const [isFileSelected, setIsFileSelected] = useState(false);
  const [uploadKey, setUploadKey] = useState(Date.now());
  const [isLogModalOpen, setIsLogModalOpen] = useState(false); // State to manage log modal visibility
  const [logs, setLogs] = useState<{ step: string; time: string }[]>([]); // State for logs
  const [performanceMatrix, setPerformanceMatrix] = useState<any>({});
  const [latestNavClick, setLatestNavClick] = useState<{ label: string; clickTime: string } | null>(null);
  const [showLogsButton, setShowLogsButton] = useState(false);
  const [isActive, setIsActive] = useState(true);
  const [showActive, setshowActive] = useState(true);
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
  //export functionality
  const [exportLoading, setExportLoading] = useState(false);
  const { addExport, removeExport,exports } = exportLoadingStore();
  const exportKey = "Customer Rate Plans";
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  const {
    features: moduleFeatures,
    setFeatures: setModuleFeatures,
  } = useFeatureStore();

  //BP states
  const [isBPEnabled, setIsBPEnabled] = useState(false);

  //Remove columns based on role
  useEffect(() => {
    let removeHeaderList: any = []
    if (role?.toLowerCase() !== "super admin" && role?.toLowerCase() !== "partner admin") {
      removeHeaderList = Object.keys(headerMap).filter(
        (key) =>
          ["soc code"].includes(
            headerMap[key][0]?.toLowerCase()
          )
      );

    }
    if (!isBPEnabled) {
      console.log("isBPEnabled",isBPEnabled)
      removeHeaderList.push("product")
      removeHeaderList.push("package")
    }
      console.log("removeHeaderList",removeHeaderList)


    setHeaders((prevHeaders) =>
      prevHeaders.filter((header) => !removeHeaderList.includes(header))
    );
  }, [role, headerMap, isBPEnabled]);

  useEffect(() => {
    setDynamicColumns((prev:any)=>({...prev,"Customer Rate Plan":visibleColumns}))
  }, [visibleColumns]);

  const fetchBPFlag = async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_cross_provider_optimization_status",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Active Customer Rate Plan",
        feature_module_name: "Customer Rate Plans",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
       db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        const billing_plaform_flag = parsedData?.billing_platform_flag || false
        setIsBPEnabled(billing_plaform_flag)
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      setLoading(false);

    }
  };

  const hasFetchedData = useRef(false);
  type HeaderMap = Record<string, [string, number]>;
  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);

  const sortPopup = (fields: any[]): any[] => {
    return fields.sort((a: any, b: any) => a?.id - b?.id);
  };
  const handleFilter = useCallback((advancedFilters: any) => {
    console.log(advancedFilters);
    setAdvancedFilters(advancedFilters)
  }, []);

  const handleReset = useCallback((EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  }, []);


  const fetchData = async () => {
    console.log("dynamic columns",dynamicColumns)
    setStoredPagination(null);
    setAdvancedStoredPagination(null)
    setShowAdvanced(false)
    setSearchTerm("")
    setCombineAdnvaceStoredpagination(null)
    settabledata([])
    setLoading(true);
    try {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_customer_rate_plan_list_view_data",
        role_name: role,
        parent_module: "Sim Management",
        module_name: showActive ? "Active Customer Rate Plan" : "Customer Rate Plan",
        feature_module_name: "Customer Rate Plans",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
       db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching Inventory data. Please try again.',
          centered: true,
        });
      } else {
        const headersMap_ = parsedData?.headers_map?.[showActive ? "Active Customer Rate Plan" : "Customer Rate Plan"]?.header_map || {}
        const sortedheaderMap = sortHeaderMap(headersMap_)
        setHeaderMap(sortedheaderMap)
        const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : []
        setHeaders(headers_)
        const dynamic_cols=dynamicColumns?.["Customer Rate Plan"] && dynamicColumns["Customer Rate Plan"] .length>0 ?dynamicColumns["Customer Rate Plan"]  :headers_ || headers_
        setVisibleColumns(dynamic_cols)
        const tableData_ = parsedData?.data?.customerrateplan || []
        setTableData(tableData_)
        settabledata(tableData_)
        const features_ = parsedData?.headers_map?.[showActive ? "Active Customer Rate Plan" : "Customer Rate Plan"]?.module_features || []
        setFeatures(features_)
        const allowedActions_: any = []
        if (features_.includes("Edit-Customer rate plans")) {
          allowedActions_.push("editCustomerRatePlan")
        }
        if (features_.includes("Delete-Customer rate plans")) {
          allowedActions_.push("delete")
        }
        if (features_.includes("Info-Customer rate plans")) {
          allowedActions_.push("infoCustomerRatePlan")
        }
        if (features_.includes("Copy-Customer rate plans")) {
          allowedActions_.push("copyCustomerRatePlan")
        }
        setAllowedActions(allowedActions_)
        const createModalData_ = parsedData?.headers_map?.[showActive ? "Active Customer Rate Plan" : "Customer Rate Plan"]?.pop_up || []
        const sortedCreatemodeldata_ = sortPopup(createModalData_)
        setcreateModalData(sortedCreatemodeldata_)
        const generalFields_ = parsedData?.data || {}
        setgeneralFields(generalFields_)
        setModuleFeatures(features_)
        const pagination_ = parsedData?.pages || {}
        setPagination(pagination_)
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      setLoading(false);

    }
  };

  useEffect(() => {
    // if (!hasFetchedData.current) {
    fetchData();
    fetchBPFlag()
    console.log("If show active is false", showActive)
    // hasFetchedData.current = true;
    // }

  }, [partner, showActive]);
  const handleSwitchChange = (checked: any) => {
    setshowActive(checked)
    setCustomerShowActive(checked);
  };


  const messageStyle = {
    fontSize: '14px',
    fontWeight: 'bold',
    padding: '16px',
  };
  const closeLogModal = () => {
    setIsLogModalOpen(false);
  };
  const handleUploadClick = () => {
    setIsUploadModalVisible(true);

  }
  const handleDownloadTemplate = async () => {
    setLoading(true);
    const url =
      ENV_ROUTES.SIM_MANAGEMENT;
    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName:firstLastName,
      path: "/download_bulk_upload_template",
      table_name: "customerrateplan",
      module_name: "customer rate plan",
      role_name: role,
      Partner: partner,
      request_received_at: getCurrentDateTime(),
      access_token: token,
     db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
    };

    const response = await axios.post(url, { data });
    const resp = JSON.parse(response.data.body);
    const blob = resp.blob;
    console.log(resp);
    if (response.data.statusCode === 200) {
      if (resp.flag === true) {
        notification.success({
          message: 'Success',
          description: 'Successfully downloaded the template!',
          style: messageStyle,
          placement: 'top',
        });
        downloadBlob(blob);
        fetchData();
        setLoading(false);
        setIsUploadModalVisible(false);
      } else {
        console.log('Error message:', resp.message);
        Modal.error({
          title: 'Export Error',
          content: resp.message,
          centered: true,
        });
      }
    } else {
      console.log('Unexpected status code:', response.data.statusCode);
      Modal.error({
        title: 'Export Error',
        content: resp.message,
        centered: true,
      });
    }
  };
  const handleUploadModalClose = () => {
    setIsUploadModalVisible(false);
  };
  const handleExportModalOpen = () => {
    setExportModalOpen(true);
  };

  const handleExportModalClose = () => {
    setExportModalOpen(false);
    console.log("Modal closed, resetting date range.");
  };

  // const handleExport = async () => {
  //   const data = {
  //     path: "/export",
  //     username: username,
  //     module_name: "Customer Rate Plan",
  //     request_received_at: getCurrentDateTime(),
  //     Partner: partner,
  //     access_token: token,
  //    db_name: selectedDb,
  //   };

  //   try {
  //     const url = ENV_ROUTES.MODULE_MANAGEMENT;
  //     const response = await axios.post(url, { data: data }, {
  //       headers: {
  //         'Content-Type': 'application/json',
  //       },
  //     });

  //     const resp = JSON.parse(response.data.body);
  //     const blob = resp.blob;
  //     console.log(resp);

  //     if (response.data.statusCode === 200) {
  //       if (resp.flag === true) {
  //         notification.success({
  //           message: 'Success',
  //           description: 'Successfully exported the record!',
  //           style: messageStyle,
  //           placement: 'top',
  //         });
  //         downloadBlob(blob);
  //       } else {
  //         console.log('Error message:', resp.message);
  //         Modal.error({
  //           title: 'Export Error',
  //           content: resp.message,
  //           centered: true,
  //         });
  //       }
  //     } else {
  //       console.log('Unexpected status code:', response.data.statusCode);
  //       Modal.error({
  //         title: 'Export Error',
  //         content: resp.message,
  //         centered: true,
  //       });
  //     }

  //     handleExportModalClose();
  //   } catch (error) {
  //     console.error("Error downloading the file:", error);
  //     Modal.error({ title: 'Export Error', content: 'An error occurred while exporting the file. Please try again.' });
  //   }
  // };
  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }

  const ExportWithoutSearch = async () => {
    // setExportLoading(true)
    // const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
    //   return new Promise((resolve, reject) => {
    //     const timer = setTimeout(() => {
    //       reject(new Error("Request timed out"));
    //     }, timeout);

    //     promise
    //       .then((res) => {
    //         clearTimeout(timer);
    //         resolve(res);
    //       })
    //       .catch((err) => {
    //         clearTimeout(timer);
    //         reject(err);
    //       });
    //   });
    // };
   
    try {
      // setExportLoading(true)
      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Request timed out"));
          }, timeout);
  
          promise
            .then((res) => {
              clearTimeout(timer);
              resolve(res);
            })
            .catch((err) => {
              clearTimeout(timer);
              reject(err);
            });
        });
      };
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/export_to_s3_bucket",
        role_name: role,
        parent_module: "Sim Management",
        module_name: showActive ? "Active Customer Rate Plan" : "Customer Rate Plan",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
       db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        feature_module_name: "Customer Rate Plans",
        start_date: getFirstDayOfCurrentMonth(),
        end_date: getLastDayOfCurrentMonth(),
      };
      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000); // Timeout of 10 seconds
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }

      // Wait for 20 seconds before polling
      await new Promise((resolve) => setTimeout(resolve, 20000));
      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      // setExportLoading(false);
      // removeExport(exportKey); // Remove the export from the store
    }
  }

  const pollExportStatus = async () => {
    // Polling for the second API
  const export_url = ENV_ROUTES.MODULE_MANAGEMENT;
  const export_data = {
    tenant_name: partner || "default_value",
    username,
    path: "/get_export_status",
    role_name: role,
    parent_module: "Sim Management",
    module_name: showActive ? "Active Customer Rate Plan" : "Customer Rate Plan",
    request_received_at: getCurrentDateTime(),
    Partner: partner,
    access_token: token,
   db_name: selectedDb,
    ...metaData,
    sessionID: sessionId,
  };
    try {
      const export_response = await axios.post(export_url, { data: export_data });
      const export_parsedData = JSON.parse(export_response.data.body);

      if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
        const s3Url = export_parsedData?.export_status_data?.url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the Customer Rate Plans record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
            .then(response => response.blob())
            .then(blob => {
              const url = window.URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'Customer Rate Plans.xlsx';
              a.click();
              a.remove();
              window.URL.revokeObjectURL(url);
              notification.success({
                message: "Success",
                description: "Successfully exported the record!",
                style: messageStyle,
                placement: "top",                              
              });
            })
            .catch((err) => {
              console.log("error",err)
              Modal.error({
                title: "Export Error",
                content: "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            });
        } else {
          Modal.error({
            title: "Export Error",
            content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
        return true; // Stop polling
      }

      if (export_parsedData?.export_status_data?.status_flag === "Failure") {
        Modal.error({
          title: "Export Error",
          content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
        return true; // Stop polling
      }
      if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
                Modal.info({
                  title: "Export Error",
                  content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
                  centered: true,
                });
                return true; // Stop polling
              }

      return false; // Continue polling
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
      return true; // Stop polling
    }
  };

  const startPolling = async () => {
    let isPollingComplete = false;

    while (!isPollingComplete) {
      isPollingComplete = await pollExportStatus();
      if (!isPollingComplete) {
        await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
      }
    }
  };
  const handleExport = async (key: string, heading: string) => {
    try {
      addExport(key, heading);

      let parsedData;
      let url;
      let data: any;
      let response;
      if(combineAdnvaceStoredpagination){
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          index_name: "Customer_Rate_Plan_Report",
          module_name: showActive ? "Active Customer Rate Plan" : "Customer Rate Plan",
          role_name: role,
        };
        console.log("combineAdnvaceStoredpagination",data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
      else if (advancedStoredpagination && !storedpagination){
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name: "Customer_Rate_Plan_Report",
          module_name: showActive ? "Active Customer Rate Plan" : "Customer Rate Plan",
          pages: {
            start: 0,
            end: 100
          },
          partner:partner,
          username: username,
         db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          tenant_id: tenantId,
          role_name: role,
          // }
        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

      }
      else if (storedpagination && !advancedStoredpagination){
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "Customer_Rate_Plan_Report",
          module_name: showActive ? "Active Customer Rate Plan" : "Customer Rate Plan",
          search: "whole",
          pages: {
            start: 0,
            end: 100,
          },
          partner:partner,
          username: username,
         db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          tenant_id: tenantId,
          role_name: role,
        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

      }
      else {
         await ExportWithoutSearch();
        return;
      }

      if (parsedData.flag) {
        console.log("flag")
        const s3Url = parsedData?.download_url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the  record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
            .then(response => response.blob())
            .then(blob => {
              const url = window.URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'Customer Rate Plans.xlsx';
              a.click();
              a.remove();
              window.URL.revokeObjectURL(url);
              notification.success({
                message: "Success",
                description: "Successfully exported the record!",
                style: messageStyle,
                placement: "top",                              
              });
            })
            .catch((err) => {
              console.log("error",err)
              Modal.error({
                title: "Export Error",
                content: "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            });
        }

         else {
          setExportLoading(false)
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      } else {
        console.log("!flag")
        Modal.error({
          title: "Export Error",
          content: parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      console.log("catch")
      await startPolling()
      // Modal.error({
      //   title: "Export Error",
      //   content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
      //   centered: true,
      // });
      
    } finally {
      // setExportLoading(false)
      removeExport(key);
    }
  };

  const handleCreateModalOpen = () => {
    setCreateModalOpen(true);
  };

  const handleCreateModalClose = () => {
    setCreateModalOpen(false);
  };
  const handleAppendChange = (e: any) => {
    setAppendChecked(e.target.checked);
    if (e.target.checked) setOverwriteChecked(false);
  };
  const handleToggle = (checked: any) => {
    setIsActive(checked);
  };
  const handleOverwriteChange = (e: any) => {
    setOverwriteChecked(e.target.checked);
    if (e.target.checked) setAppendChecked(false);
  };
  const handleUpload = async (blob: string) => {
    setLoading(true)
    try {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      let flag: string = appendChecked ? "append" : "overwrite";

      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName:firstLastName,
        path: "/import_bulk_data",
        table_name: "customerrateplan",
        insert_flag: "append",
        module_name: "customer rate plan",
        role_name: role,
        Partner: partner,

        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        blob: blob, // Include the Blob in the data
      };

      const response = await axios.post(url, { data });

      const resp = JSON.parse(response.data.body);
      if (response.data.statusCode === 200) {
        if (resp.flag === true) {
          setTimeout(() => {
            fetchData();
          }, 3000);
          notification.success({
            message: 'Success',
            description: 'Successfully uploaded the record!',
            placement: 'top',
          });
        } else {
          Modal.error({
            title: 'Import Error',
            content: resp.message,
            centered: true,
            onOk: handleErrorModalClose,
            onCancel: handleErrorModalClose
          });
        }
      } else {
        Modal.error({
          title: 'Import Error',
          content: resp.message,
          centered: true,
          onOk: handleErrorModalClose,
          onCancel: handleErrorModalClose
        });
      }
    } catch (error) {
      console.error('Error during file upload:', error);
      Modal.error({
        title: 'Import Error',
        content: 'There was an error uploading the file.',
        centered: true,
        onOk: handleErrorModalClose,
        onCancel: handleErrorModalClose
      });

    }
    finally{
    setLoading(false)
    setIsUploadModalVisible(false)
    }
  }
  const handleErrorModalClose = () => {
    setIsUploadModalVisible(false)
  }
  const handleChange = (info: any) => {
    if (info.file.status === 'done') {
      setIsFileSelected(true);
      let blob;
      const file = info.file.originFileObj; // Get the file object
      const reader = new FileReader();
      reader.onload = (e: any) => {
        // Get the file data URL (Base64 string)
        blob = e.target.result;
        console.log('File Base64 String:', blob);
        handleUpload(blob)
        setUploadKey(Date.now());
      };

      if (blob) {
      }

      reader.readAsDataURL(file); // Read the file as data URL
    } else if (info.file.status === 'error') {
      // Handle upload error
      message.error('Upload failed.');
    }
    else if (info.file.status === 'removed') {
      setIsFileSelected(false);
      setAppendChecked(false);
      setOverwriteChecked(false);
    }
  };
  const uploadProps = {
    key: uploadKey,
    accept: '.xlsx, .xls',
    beforeUpload: (file: any) => {
      // Check if file is an Excel file
      const isExcel = file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || file.type === 'application/vnd.ms-excel';
      if (!isExcel) {
        message.error('You can only upload Excel files!');
      }
      return isExcel;
    },
    onChange: handleChange,
  };
  const handleCreateRow = (newRow: any, tableData: any) => {
    const updatedData = [...tableData, newRow];
    // setTable(tableData);
    // setTableData(tableData);
    handleCreateModalClose();
  };
  const handleFormSubmitSuccess = () => {
    handleCreateModalClose()
    fetchData();// Re-fetch data to get the latest row
  };
  const downloadBlob = (base64Blob: string) => {
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    const blobObject = new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blobObject);
    link.download = 'Customer Rate Plan.xlsx';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleOpenModal = () => {
    setIsOptimizeModalVisible(true);
  };

  const handleCancel = () => {
    setIsOptimizeModalVisible(false);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  const disableFutureDates = (current: any) => {
    console.log("future dates:", current && current > dayjs().endOf('day'));
    return current && current > dayjs().endOf('day');
  };


  return (
    <>
      <Suspense fallback={<div className="flex justify-center items-center h-screen container"><Spin size="large" /></div>}>
        <div className="relative">
          <div className="flex justify-end p-2">
            <div className="flex items-center space-x-2 justify-end">
              <Switch onChange={handleSwitchChange} checked={showActive} className="custom-switch" />
              <span className="font-bold text-lg">Show Active only</span>
            </div>
          </div>
          <div className="pr-4 pl-4  pt-2 flex md:flex-row md:items-center md:justify-between mt-1 mb-4 space-y-4">
          {/* Search and Advanced Filter Container */}
          <div className="flex space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last ">
              {features.includes("Search-Customer rate plans") && (
                <TableSearch
                  searchTerm={searchTerm}
                  setSearchTerm={setSearchTerm}
                  tableName={"Customer_Rate_Plan"}
                  headerMap={headerMap}
                />
              )}
              {features.includes("Advanced filter-Customer rate plans") && (
                <AdvancedMultiFilter
                  showAdvanced={showAdvanced}
                  setShowAdvanced={setShowAdvanced}
                  onFilter={handleFilter}
                  onReset={handleReset}
                  headers={headers}
                  headerMap={headerMap}
                  tableName={"Customer_Rate_Plan"}
                />
              )}
            </div>


            {/* Commented because of UAT Fix
              {features.includes("Optimize-Customer rate plans") && (
              <button className="save-btn" onClick={handleOpenModal}>
                <SettingOutlined className="h-5 w-5 text-black-500 mr-1" />
                Optimize
              </button>
              )} */}
                 {/* Export and ColumnFilter Container */}
           <div className="hidden md:flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2  md:order-none order-first pb-2 md:pb-4">
              {features.includes("Create-Customer rate plans") && (
                <button className="save-btn" onClick={handleCreateModalOpen}>
                  <PlusIcon className="h-5 w-5 text-black-500 mr-1" />
                  Create
                </button>
              )}

              {features.includes("Upload-Customer rate plans") && (
                <button className="save-btn" onClick={handleUploadClick}>
                  <ArrowUpTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                  <span>Upload</span>
                </button>
              )}
              <Modal
                title="Upload Files"
                visible={isUploadModalVisible}
                onCancel={handleUploadModalClose}
                footer={null} // No default footer buttons
                centered
                width={370}
              >
                <div className="flex flex-col gap-4">
                  <div className="flex gap-4 justify-center p-4">
                    <Upload {...uploadProps} className="upload-wrapper">
                      <button
                        className="upload-btn disabled:cursor-not-allowed"
                        style={{ height: '40px', display: 'inline-flex', alignItems: 'center' }}>
                        <span className="mr-2"><UploadOutlined /></span>
                        Upload
                      </button>
                    </Upload>
                    <button
                      onClick={handleDownloadTemplate}
                      className="upload-btn disabled:cursor-not-allowed"
                    // disabled={!appendChecked && !overwriteChecked}
                    >
                      <span className="mr-2"><DownloadOutlined /></span>
                      Download Template
                    </button>
                  </div>
                </div>
              </Modal>
              {features.includes("Export-Customer rate plans") && (
                <button className="save-btn"
                onClick={() => {
                  if (!exports.some((exportItem) => exportItem.popupHeading === "Customer Rate Plans")) {
                    handleExport("customerRatePlans", "Customer Rate Plans");
                  }
                }}>
                  <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                  <span>Export</span>
                </button>
              )}
              <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
              />
            </div>
          </div>
          <div className={`${showAdvanced ? 'mt-[70px]' : ''}`}>
            <TableComponent
              headers={headers}
              headerMap={headerMap}
              initialData={tableData}
              searchQuery={searchTerm}
              visibleColumns={visibleColumns}
              itemsPerPage={100}
              // allowedActions={
              //   partner === "Titanium - AWX"
              //     ? ["edit", "info", "delete", "copyFeature"]
              //     : ["edit", "info", "delete"]
              // }
              allowedActions={allowedActions}
              popupHeading="Customer Rate Plan"
              pagination={pagination}
              advancedFilters={filteredData}
              createModalData={createModalData}
              generalFields={generalFields}
              height = {showAdvanced?300:260}
            />
          </div>
          <CreateCustomerRatePlan
            isOpen={isCreateModalOpen}
            onClose={handleCreateModalClose}
            onSubmit={handleFormSubmitSuccess}
            // onSave={handleCreateRow}
            // columnNames={createModalData}
            // heading="Customer Rate Plan"
            // header={tableData && tableData.length > 0 ? Object.keys(tableData[0]) : []}
            generalFields={generalFields}
          // tableData={tableData}
          />
          {/* <Modal
            title="Export output"
            visible={isExportModalOpen}
            onCancel={() => {
              handleExportModalClose();
              setDateRange([null, null]);
            }}
            footer={null}
            centered
            style={{ top: '-4%' }}

            afterClose={() => setDateRange([null, null])}
          >
            <div className="flex flex-col space-y-4">
              <span>Select date range</span>
              <RangePicker
                value={dateRange[0] && dateRange[1] ? [dateRange[0], dateRange[1]] : null}
                onChange={(dates) => {
                  console.log("Selected dates:", dates);
                  if (dates && dates.length === 2) {
                    setDateRange([dates[0], dates[1]] as [Dayjs, Dayjs]);
                  } else {
                    setDateRange([null, null]);
                  }
                }}
                format="YYYY-MM-DD"
                disabledDate={disableFutureDates}
              />
              <div className="flex justify-center space-x-2">
                <button className="cancel-btn" onClick={handleExportModalClose}>Cancel</button>
                <button className="save-btn" onClick={handleExport}>Export</button>
              </div>
            </div>
          </Modal> */}

          {isOptimizeModalVisible && (
            <Optimize
              isOpen={isOptimizeModalVisible}
              onCancel={handleCancel}
              module_name={'Customer Rate Plan'}
              onSubmit={handleCancel}
            />
          )}
            {/* {exportLoading && (
            <div className="export-processing-div">
              Export Processing...
            </div>
          )} */}
        </div>
        
                  {/* Sticky Footer for Small Screens */}
                             <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
                             {features.includes("Create-Customer rate plans") && (
                                <button className="save-btn" onClick={handleCreateModalOpen}>
                                  <PlusIcon className="h-5 w-5 text-black-500" />
                                </button>
                              )}

                              {features.includes("Upload-Customer rate plans") && (
                                <button className="save-btn" onClick={handleUploadClick}>
                                  <ArrowUpTrayIcon className="h-5 w-5 text-black-500 " />
                                </button>
                              )}
                                              {features.includes("Export-Customer rate plans") && (
                                <button className="save-btn"
                                onClick={() => {
                                  if (!exports.some((exportItem) => exportItem.popupHeading === "Customer Rate Plans")) {
                                    handleExport("customerRatePlans", "Customer Rate Plans");
                                  }
                                }}>
                                  <ArrowDownTrayIcon className="h-5 w-5 text-black-500 " />
                                </button>
                              )}
                              <ColumnFilter
                                headers={headers}
                                visibleColumns={visibleColumns}
                                setVisibleColumns={setVisibleColumns}
                                headerMap={headerMap}
                              />
                            </div>
      </Suspense>


    </>

  );
};

export default SimManagementCustomerRatePlan;
