"use client";

import React, { useEffect, useState, lazy, Suspense, useRef } from "react";
import { PlusIcon, ArrowDownTrayIcon } from "@heroicons/react/24/outline";
import { Button, Modal, Spin, DatePicker, notification } from "antd";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import dayjs, { Dayjs } from "dayjs";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import CreateSimOrderForm from "./create_sim_order_form";
import { DoubleLeftOutlined } from "@ant-design/icons";
import { PerformanceLogStore } from "@/app/stores/performance_matrix_store";
import { RenderPerformanceMatrixModal } from "@/app/performance_modal";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useCustomerRatePlanStore } from "@/app/stores/customerRateplanStore";
import form from "antd/es/form";

const { RangePicker } = DatePicker;
const TableComponent = lazy(
  () => import("@/app/components/TableComponent/page")
);
const CreateModal = lazy(() => import("@/app/components/createPopup"));
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));
const TableSearch = lazy(() => import("@/app/components/entire_table_search"));
const AdvancedMultiFilter = lazy(
  () => import("@/app/components/advanced_search")
);

const SimOrderForm: React.FC = () => {
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, settabledata, token, selectedDb,metaData, firstLastName, sessionId ,dynamicColumns,setDynamicColumns} = useAuth();
  const [loading, setLoading] = useState(true);
  const [pagination, setpagination] = useState<any>({});
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([
    null,
    null,
  ]);
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  // const { showAdvanced, setShowAdvanced} = useCustomerRatePlanStore();
  const [carrierOptions, setCarrierOptions] = useState<any[]>([]);
  // const [isLogModalOpen, setIsLogModalOpen] = useState(false);
  const [logs, setLogs] = useState<{ step: string; time: string }[]>([]);
  const [performanceMatrix, setPerformanceMatrix] = useState<any>({});
  const [showLogsButton, setShowLogsButton] = useState(false);
  const [latestNavClick, setLatestNavClick] = useState<{
    label: string;
    clickTime: string;
  } | null>(null);
  const { logStatement, setLogStatement } = PerformanceLogStore();

  const [allowedActions, setAllowedActions] = useState<any[]>([]);

  useEffect(() => {
    // Retrieve the latest navigation click time from localStorage
    const storedNavClick = localStorage.getItem("latestNavClick");
    if (storedNavClick) {
      setLatestNavClick(JSON.parse(storedNavClick));
    }
  }, []);

  // Function to add a log


  const { features: moduleFeatures, setFeatures: setModuleFeatures } =
    useFeatureStore();

  type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = (headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];

    entries.sort((a, b) => a[1][1] - b[1][1]);

    return Object.fromEntries(entries) as HeaderMap;
  };

  const hasFetchedData = useRef(false);

  useEffect(() => {
        setDynamicColumns((prev:any)=>({...prev,"Sim Order Form":visibleColumns}))
      }, [visibleColumns]);

  // Move fetchData outside of useEffect
  const fetchData = async () => {
    setLoading(true);
    try {
      settabledata([])
      setLogStatement("UI API Call");
      console.log("API called");
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_sim_order_form_list_view_data",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Sim Order Form",
        feature_module_name:"Sim Order Form",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
          ...metaData,
        sessionID: sessionId,
      };
      console.log(getCurrentDateTime(),"Show the log time request sent from ui to lambda");
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      console.log(response.data, "matrixxxx");
      setPerformanceMatrix(JSON.parse(response.data.performance_matrix));
      setShowLogsButton(response.data.performance_matrix_feature === true);
      console.log(
        JSON.parse(response.data.performance_matrix),
        "Show the parsed data"
      ); // Set performance_matrix here
      setLogStatement("Lambda Response to UI");
      console.log(getCurrentDateTime(),"Show the log time response sent from lambda to ui");
      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      } else {
        const headersMap_ =
          parsedData?.headers_map?.["Sim Order Form"]?.header_map || {};
        const sortedheaderMap = sortHeaderMap(headersMap_);
        setHeaderMap(sortedheaderMap);
        const headers_ =
          Object.keys(sortedheaderMap).length > 0
            ? Object.keys(sortedheaderMap)
            : [];
        setHeaders(headers_);
          const dynamic_cols=dynamicColumns?.["Sim Order Form"]&& dynamicColumns["Sim Order Form"].length>0 ?dynamicColumns["Sim Order Form"] :headers_ || headers_
        setVisibleColumns(dynamic_cols)
        const tableData_ = parsedData?.data?.sim_order_form || [];
        setTableData(tableData_);
        const features_ =
          parsedData?.headers_map?.["Sim Order Form"]?.module_features || [];
        setFeatures(features_);
        setModuleFeatures(features_);
        const allowedActions_:any=[]
        if(features_.includes("Info-Sim order form")){
          allowedActions_.push("form")
        }
        setAllowedActions(allowedActions_)
        const pagination_ = parsedData?.pages || {};
        setpagination(pagination_);
        const carrierOptions_ = parsedData?.data?.service_provider_name || [];
        setCarrierOptions(carrierOptions_);
      }
    } catch (error) {
      setLoading(false);
      console.error("Error fetching data:", error);
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    if (!hasFetchedData.current) {
      fetchData();
      hasFetchedData.current = true;
    }
  }, [username, partner, role]);

  useEffect(() => {
    setLogStatement("Component rendered");
  }, []);

  // useEffect(() => {
  //   if (!loading) {
  //     setLogStatement("Data Displayed in UI");
  //   }
  // }, [loading]);
  useEffect(() => {
    if (!loading) {
      console.log("Data Displayed in UI", getCurrentDateTime());
    }
  }, [loading]);

  // Callback to refresh the table data after form submission
  const handleFormSubmitSuccess = () => {
    fetchData(); // Re-fetch data to get the latest row
  };

  const handleFilter = (advancedFilters: any) => {
    console.log(advancedFilters);
  };

  const handleReset = (EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  };

  // const closeLogModal = () => {
  //   setIsLogModalOpen(false);
  // };

  const handleCreate = () => {
    setIsCreateModalOpen(true);
  };

  const closeCreateModal = () => {

    setIsCreateModalOpen(false);
  };
  
  const modalWidth =
    typeof window !== "undefined" ? (window.innerWidth * 2.5) / 4 : 0;
  const modalHeight =
    typeof window !== "undefined" ? (window.innerHeight * 2.5) / 4 : 0;
  // Add log after Suspense

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  return (
    <>
      <Suspense
        fallback={
          <div className="flex justify-center items-center h-screen">
            <Spin size="large" />
          </div>
        }
      >
        <div className="relative">
        <div className="p-4 flex md:flex-row md:items-center md:justify-between mt-1 mb-4 space-y-6 md:space-y-0">
  {/* Search and Advanced Filter Container */}
  <div className="flex  space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last">
            {features.includes("Search-Sim order form") && (
              <TableSearch
                searchTerm={searchTerm}
                setSearchTerm={setSearchTerm}
                tableName={"sim_order_form"} //Need to change
                headerMap={headerMap}
              />
            )}
              {features.includes("Advanced filter-Sim order form") && (
              <AdvancedMultiFilter
                showAdvanced={showAdvanced}
                setShowAdvanced={setShowAdvanced}
                onFilter={handleFilter}
                onReset={handleReset}
                headers={headers}
                headerMap={headerMap}
                tableName={"sim_order_form"} // Need to change
              />
              )}         
            </div>
            <div className="hidden md:flex flex-col pb-4 md:flex-row space-y-2 md:space-y-0 md:space-x-2 md:order-none order-first">
            {features.includes("Create-Sim order form") && (
              <button
                onClick={handleCreate}
                className="save-btn text-base"
              ><span><PlusIcon className="h-5 w-5 text-black-500" /></span>
                Create
              </button>
            )}
              <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
              />
              {/* {
                <RenderPerformanceMatrixModal
                  performanceMatrix={performanceMatrix}
                  latestNavClick={latestNavClick}
                />
              } */}
            </div>
          </div>
          <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
            <TableComponent
              headers={headers}
              headerMap={headerMap}
              initialData={tableData}
              searchQuery={searchTerm}
              visibleColumns={visibleColumns}
              itemsPerPage={100}
              allowedActions={allowedActions}
              popupHeading="Sim Order Form"
              pagination={pagination}
              advancedFilters={filteredData}
              height = {showAdvanced?280:230}
            />
          </div>
        </div>

        {/* <Modal
          visible={isCreateModalOpen}
          onCancel={closeCreateModal}
          footer={null}
          centered
          title={
            <div className="mt-[-10px] ml-1">
              <span className="text-[18px]">Create SIM Order Form</span>
            </div>
          }
          width={800}
          style={{
            top: '10vh', // 10% from the top of the screen
            height: '80vh', // 80% of the screen height
            padding: "5px",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
          
        >
         
        </Modal> */}

         <CreateSimOrderForm
            visible={isCreateModalOpen}
            onClose={closeCreateModal}
            onSuccess={handleFormSubmitSuccess}
            carrierOptions={carrierOptions}
            addLog={setLogStatement}
          />

          {/* Sticky Footer for Small Screens */}
                     <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
                      
                     {features.includes("Create-Sim order form") && (
                        <button
                          onClick={handleCreate}
                          className="save-btn text-base"
                        >
                          <PlusIcon className="h-5 w-5 text-black-500" />
                        </button>
                      )}
                      <ColumnFilter
                        headers={headers}
                        visibleColumns={visibleColumns}
                        setVisibleColumns={setVisibleColumns}
                        headerMap={headerMap}
                      />
                    </div>
      </Suspense>

    </>
  );
};

export default SimOrderForm;
