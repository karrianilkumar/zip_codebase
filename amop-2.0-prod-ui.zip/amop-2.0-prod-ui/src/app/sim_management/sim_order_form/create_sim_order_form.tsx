"use client";

import React, { useEffect, useState } from "react";
import {
  Form,
  Input,
  Checkbox,
  Button,
  Select,
  Col,
  Row,
  Spin,
  notification,
  Modal,
  Tooltip,
  Popover,
} from "antd";
import axios from "axios";
import { CloseOutlined } from "@ant-design/icons";
import { ChevronDownIcon, PlusIcon } from "@heroicons/react/16/solid";
import { useLogoStore } from "@/app/stores/logoStore";
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { RenderPerformanceMatrixModal } from "@/app/performance_modal";
import { PerformanceLogStore } from "@/app/stores/performance_matrix_store";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { InformationCircleIcon } from "@heroicons/react/24/outline";
import { values } from "lodash";

const { Option } = Select;

const CreateSimOrderForm: React.FC<{
  visible: boolean;
  onClose: () => void;
  onSuccess: () => void;
  carrierOptions: any[];
  addLog: (step: string) => void;
}> = ({ onClose, onSuccess, carrierOptions, addLog,visible }) => {
  const [form] = Form.useForm();
  const [count, setCount] = useState(1);
  const [blocks, setBlocks] = useState<number[]>([0]);
  const [loading, setLoading] = useState(false);
  const title = useLogoStore((state) => state.title);
  const { username, tenantNames, token, partner, email, selectedDb, metaData,firstLastName, sessionId } =
    useAuth();
  const { logStatement, setLogStatement } = PerformanceLogStore();
  const [carrierOptionsList, setCarrierOptionsList] =
    useState<any[]>(carrierOptions);
  const [simSizeDropdownOptions, setSimSizeDropdownOptions] = useState<
    string[]
  >([]);
  const [isImageVisible, setIsImageVisible] = useState(false);
  const [formKey, setFormKey] = useState(0); // Force re-render of the form


  const handleAddMore = () => {
    setBlocks([...blocks, blocks.length]);
    setCount(count + 1);
  };

  const handleRemove = (index: number) => {
    setBlocks(blocks.filter((_, i) => i !== index));
    setCount(count - 1);
  };

  const handleCancel= () => {
    console.log("close the modal ")
    form.resetFields();
    setFormKey((prevKey) => prevKey + 1); // Change key to force re-render
    onClose();
  }

  const handleToggleImage = () => {
    setIsImageVisible(!isImageVisible);
  };

  const [carrier, setCarrier] = useState<string>("");

  const simSizeOptions = ["Standard", "Micro", "Nano"];
  const carrierOption = [
    "AT & T - POD19",
    "AT & T Cisco Jasper",
    "AT & T Telegence",
    "Pond IOT",
    "Teal",
    "Verizon - HDP",
    "Verizon - Thingspace IoT",
    "Verizon - Thingspace PN",
  ];

  const filteredCarrierOptions = [
    "AT&T - Cisco Jasper",
    "AT&T - POD19",
    "Verizon",
  ];

  const handleCarrierChange = (value: string) => {
    // Set the `SIM size` options based on selected `Carrier`
    if (value === "AT&T - POD19") {
      setSimSizeDropdownOptions(simSizeOptions);
    } else if (
      [
        "AT&T - Cisco Jasper",
        "Verizon - ThingSpace IoT",
        "Verizon Thingspace IoT",
        "Verizon"
      ].includes(value)
    ) {
      setSimSizeDropdownOptions(["Tricut"]);
    } else {
      setSimSizeDropdownOptions([]); // No options available
    }
  };

  const renderLabel = (label: string, required: boolean) => (
    <span className="field-label">
      {label}{" "}
      {required && (
        <span className="required-indicator" style={{ color: "red" }}>
          *
        </span>
      )}
    </span>
  );

  const onFinish = async (values: { [key: string]: any }) => {
    const formData = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/sim_order_form_mail_trigger",
      module_name: "Sim Order Form",
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      sim_order_data: {
        company: values.company,
        contact_name: values.contactName,
        email: values.email,
        country: values.country,
        shipping_address: values.shippingAddress,
        special_instructions: values.SpecialInstructions || "",
        expedite: values.expedite || false,
        created_date: getCurrentDateTime(),
        created_by: values.contactName,
        sim_info: blocks.map((_, index) => ({
          carrier: values[`carrier${index}`],
          "SIM Size": values[`simSize${index}`],
          Quantity: values[`quantity${index}`],
        })),
      },
      access_token: token,
      db_name: selectedDb,
        ... metaData,
      sessionID: sessionId,
    };
    console.log(formData, "Form Data");

    try {
      setLoading(true);
      const response = await axios.post(ENV_ROUTES.SIM_MANAGEMENT, {
        data: formData,
      });
      const parsedData = JSON.parse(response.data.body);
      console.log("parsedData",parsedData)
      if (parsedData.flag === false) {
        setLoading(false);
        notification.error({
          message: "Error",
          description: "There was an error submitting the data.",
        });
      } else {
        setLoading(false);
        setLogStatement("Form data submitted successfully");
        onClose(); // Close the form after successful submission
        notification.success({
          message: "Success",
          description: "Data submitted successfully!",
        });
        onSuccess();
      }
    } catch (error) {
      setLoading(false);
      setLogStatement("Error in form submission");
      console.error("Failed to submit form data", error);
      notification.error({
        message: "Error",
        description: "There was an error submitting the data.",
      });
    }
  };
  useEffect(() => {
    setLogStatement("CreateSimOrderForm component mounted");
    form.resetFields();
  }, [form]);
  const modalHeight =
    typeof window !== "undefined" ? (window.innerHeight * 3) / 4 : 0;

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64 w-[500px]">
        <Spin size="large" />
      </div>
    );
  }

  return (
    // <div
    //   // style={{
    //   //   textAlign: "left",
    //   //   height: modalHeight,
    //   //   overflowY: "auto",
    //   //   overflowX: "hidden",
    //   // }}
    // >
       <Modal
      visible={visible} // Control modal visibility with the prop
      onCancel={handleCancel}
      footer={null}
      title="Create SIM Order Form"
      width={800}
      style={{ top: '10vh',
        textAlign: "left",
        // height: modalHeight,
        // overflowY: "auto",
       
       }}
       bodyStyle={{
        maxHeight: modalHeight,
        overflowY: 'auto', // Enable vertical scrolling
        overflowX: "hidden",
      }}
    >
      <Form
        key={formKey}
        form={form}
        className="ant-form"
        layout="vertical"
        initialValues={{
          company: partner,
          contactName: firstLastName,
          email: email,
        }}
        onFinish={onFinish}
        requiredMark={false} // Disable default asterisk for all fields
      >
        {/* First Block */}
        <Row gutter={16}>
          <Col span={12}>
            <Form.Item label={renderLabel("Company", false)} name="company">
              <Input
                className="non-editable-input"
                placeholder="Company"
                readOnly
              />
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              label={renderLabel("Contact Name", false)}
              name="contactName"
            >
              <Input
                className="non-editable-input"
                placeholder="Contact name"
                readOnly
              />
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              label={renderLabel("Email", true)}
              name="email"
              rules={[
                { required: true, message: "Please enter your email!" },
                { type: "email", message: "Invalid email address" },
              ]}
            >
              <Input
                className="input"
                defaultValue="email"
                placeholder="Enter your Email"
              />
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              label={renderLabel("Country", true)}
              name="country"
              rules={[
                { required: true, message: "Please input your country!" },
              ]}
            >
              <Input className="input" placeholder="Country" />
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              label={renderLabel("Shipping Address", true)}
              name="shippingAddress"
              rules={[
                {
                  required: true,
                  message: "Please input your shipping address!",
                },
              ]}
            >
              <Input.TextArea
                className="text-area"
                placeholder="Shipping Address"
                rows={3}
              />
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item
              label={renderLabel("Special Instructions", false)}
              name="SpecialInstructions"
            >
              <Input.TextArea
                className="text-area"
                placeholder="Special Instructions"
                rows={3}
              />
            </Form.Item>
          </Col>
          <Col span={24}>
            <Form.Item name="expedite" valuePropName="checked">
              <Checkbox
                style={{
                  width: "50px",
                  height: "50px",
                  fontSize: "20px",
                  lineHeight: "50px",
                }}
              >
                Expedite
              </Checkbox>
            </Form.Item>
          </Col>
        </Row>

        {/* Second Block */}
        <div className={`grid grid-cols-1 xl:grid-cols-2 gap-4`}>
          {blocks.map((_, index) => (
            <div className="form-block w-full sm:w-6/7 mx-auto" key={index}>
              {index > 0 && (
                <Button
                  icon={<CloseOutlined />}
                  onClick={() => handleRemove(index)}
                  className="custom-close-button"
                />
              )}
              <div className="grid grid-cols-1">
                <Form.Item
                  label={renderLabel("Static IP Needed", true)}
                  // name="staticIPNeeded"
                  name={`staticIPNeeded${index}`}
                  rules={[
                    { required: true, message: "Please Select an Option!" },
                  ]}
                >
                  <Select
                    defaultValue="Select option"
                    className="editableDrp"
                    suffixIcon={
                      <ChevronDownIcon className="w-5 h-5 mt-2 text-gray-500" />
                    }
                    style={{ marginBottom: "9px" }}
                    onChange={(value) => {
                      form.setFieldsValue({ [`carrier${index}`]: null });
                      if (value === "Yes") {
                        // Filter and set only options present in carrierOptions for "Yes"
                        const filteredOptions = ["Verizon - Thingspace IoT","Verizon - ThingSpace IoT"].filter((option) =>
                          carrierOptions.includes(option)
                        );
                        setCarrierOptionsList(filteredOptions);
                      } else if (value === "No") {
                        // Filter and set only options present in carrierOptions for "No"
                        // const filteredOptions = filteredCarrierOptions.filter((option) =>
                        //   carrierOptions.includes(option)
                        // );
                        setCarrierOptionsList(carrierOptions);
                      } else {
                        setCarrierOptionsList(carrierOptions);
                      }
                    }}
                  >
                    <Option value="Yes">Yes</Option>
                    <Option value="No">No</Option>
                  </Select>
                </Form.Item>
                <Form.Item
                  label={renderLabel("Carrier", true)}
                  name={`carrier${index}`}
                  rules={[
                    { required: true, message: "Please select your carrier!" },
                  ]}
                >
                  <Select
                    defaultValue="Select carrier"
                    className="editableDrp"
                    suffixIcon={
                      <ChevronDownIcon className="w-5 h-5 mt-2 text-gray-500" />
                    }
                    style={{ marginBottom: "9px" }}
                    onChange={(value) => {
                      form.setFieldsValue({ [`simSize${index}`]: undefined });
                      handleCarrierChange(value); 
                    }}
                    disabled={!form.getFieldValue(`staticIPNeeded${index}`)}
                  >
                    {carrierOptionsList.map((carrier) => (
                      <Option key={carrier} value={carrier}>
                        {carrier}
                      </Option>
                    ))}
                  </Select>
                </Form.Item>
                <Form.Item
                  label={
                    <span className="flex items-center">
                      {renderLabel("SIM Size", true)}
                      <Popover
                        content={
                          <div style={{ border: "1px solid #d9d9d9", borderRadius: "4px", padding: "8px" }}>
                          <img
                            src="/images/sim-info-modal.png" // Ensure this path is correct
                            alt="SIM sizes"
                            style={{ width: "200px" }} // Adjust width as needed
                          />
                          </div>
                        }
                        trigger="hover"
                        placement="right" 
                      >
                        <InformationCircleIcon className="w-5 h-5 text-gray-500 ml-2 cursor-pointer" />
                      </Popover>
                    </span>
                  }
                  name={`simSize${index}`}
                  rules={[
                    { required: simSizeDropdownOptions.length > 0, message: "Please select your SIM size!" },
                  ]}
                >
                  <Select
                    placeholder="SIM Size"
                    className="editableDrp"
                    suffixIcon={
                      <ChevronDownIcon className="w-5 h-5 mt-2 text-gray-500" />
                    }
                    style={{ marginBottom: "9px" }}
                  >
                    {simSizeDropdownOptions.length > 0 ? (
                      simSizeDropdownOptions.map((size) => (
                        <Option key={size} value={size}>
                          {size}
                        </Option>
                      ))
                    ) : (
                      <Option value="" disabled>
                        No Options Available
                      </Option>
                    )}
                  </Select>
                </Form.Item>
                <Form.Item
                  label={renderLabel("Quantity", true)}
                  name={`quantity${index}`}
                  rules={[
                    { required: true, message: "Please input the quantity!" },
                    {
                      validator: (_, value) =>
                        value >= 0
                          ? Promise.resolve()
                          : Promise.reject(
                              new Error("Quantity cannot be negative")
                            ),
                    },
                  ]}
                >
                  <Input
                    className="input"
                    placeholder="Quantity"
                    type="number"
                    min={0}
                  />
                </Form.Item>
              </div>
            </div>
          ))}

          <button
            onClick={handleAddMore}
            className="save-btn mt-1 h-8" // Add margin at the top
          >
            <PlusIcon className="h-5 w-5 text-black-500" />
            Add Additional SIMs
          </button>
        </div>

        <Form.Item>
          <div className="button-container mt-3">
            <button type="button" onClick={handleCancel} className="cancel-btn">
              Cancel
            </button>
            <button type="submit" className="save-btn">
              Save
            </button>
          </div>
        </Form.Item>
      </Form>
      </Modal>
    // </div>
  );
};

export default CreateSimOrderForm;
