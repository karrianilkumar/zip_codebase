'use client'
import React, { useEffect, useState } from 'react';
import { Modal, Button, message } from 'antd';
import { useRevStore } from '@/app/stores/revStore';
import RevTableComponent from '@/app/components/revTableComponent/page';
import dayjs from 'dayjs';
import axios from 'axios';
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from '@/app/components/header_constants';
import { ENV_ROUTES } from '@/app/components/routes/route_constants';

const DisconnectServiceProductPage: React.FC<{ onClose: () => void; visible: boolean }> = ({ onClose, visible }) => {
    const { settabledata,username, role, partner, token, selectedDb } = useAuth();
    const { revHeaders, revRows, revHeaderMap, setRevHeaderMap, setRevHeaders, setRevRows, setIsClosed } = useRevStore();
    const [showConfirmModal, setShowConfirmModal] = useState<boolean>(false);
    const [confirmData, setConfirmData] = useState<{ customerIds: number[]; totalProducts: number } | null>(null);
    const [isContinueClicked, setIsContinueClicked] = useState<boolean>(false);
    const [initialRows, setInitialRows] = useState<any[]>([]);

    useEffect(() => {
        if (visible) {
            settabledata([])
            setInitialRows(revRows);
            setRevRows([]);
            const additionalHeaders = ['package_id', 'rate', 'description', 'product_id'];
            const hasNewHeaders = additionalHeaders.some(header => !revHeaders.includes(header));
            if (hasNewHeaders) {
                const updatedHeaders = [...new Set([...revHeaders, ...additionalHeaders])];
                setRevHeaders(updatedHeaders);

                const updatedHeaderMap = {
                    ...revHeaderMap,
                    package_id: ['Package ID', null],
                    rate: ['Rate', null],
                    description: ['Description', null],
                    product_id: ['Product ID', null]
                };
                setRevHeaderMap(updatedHeaderMap);
            }
        }
    }, [visible]);

    const handleDateChange = (rowIndex: number, date: string | null) => {
        const updatedRows = [...initialRows];
        updatedRows[rowIndex]['Effective Date'] = date;
        setInitialRows(updatedRows);
    };

    const handleContinue = () => {
        const todayDate = dayjs().format('YYYY-MM-DD');
        const updatedRows = initialRows.map(row => ({
            ...row,
            'Effective Date': row['Effective Date'] || todayDate,
        }));
        setInitialRows(updatedRows);

        // Add 'Effective Date' to headers and headerMap
        const updatedHeaders = [...revHeaders, 'Effective Date'];
        setRevHeaders(updatedHeaders);

        const updatedHeaderMap = {
            ...revHeaderMap,
            'Effective Date': ['Effective Date', null]
        };
        setRevHeaderMap(updatedHeaderMap);

        setIsContinueClicked(true);
    };

    const handleSubmit = () => {
        const customerIds: any[] = initialRows.map(row => ({
            customer_id: row.rev_account_number,
        }))
        const totalProducts = revRows.length;
        setConfirmData({ customerIds, totalProducts });
        setShowConfirmModal(true);

    };

    const handleConfirmSubmit = async () => {
        try {
            const payload = {
                data: {
                    tenant_name: partner,
                    username: username,
                    path: "/deactivate_service_product",
                    role_name: role,
                    parent_module: "Sim Management",
                    module_name: "Rev assurance",
                    customer_id: confirmData?.customerIds.map((item: any) => item.customer_id),
                    deactivate_data: initialRows.map(row => ({
                        service_product_id: row.service_product_id,
                        effective_date: row['Effective Date'],
                        generate_proration: true,
                    })),
                    request_received_at: getCurrentDateTime(),
                    Partner: partner,
                    access_token: token,
                    db_name: selectedDb,
                }
            };

            const response = await axios.post( ENV_ROUTES.SIM_MANAGEMENT, payload);
            handleOnClose();
            const parsedData = JSON.parse(response.data.body);

            if (response.data.statusCode === 200) {
                const rev_customer_ids = confirmData?.customerIds.map((item: any) => item.customer_id).join(', ');
                Modal.success({
                    title: 'Service product disconnected',
                    centered: true,
                    content: (
                        <div>
                            <p>This will Disconnect Service Product</p>
                            <h2>RevCustomerId: {rev_customer_ids}</h2>
                            <h2>Total Selected Product: {confirmData?.totalProducts}</h2>
                        </div>
                    ),
                    onOk: handleOnClose
                });
            } else {
                const err_customer_ids = parsedData.data.map((item: { error_message: any; customer_id: any }) => item.customer_id).join(',');
                Modal.error({
                    title: 'Submission failed',
                    centered: true,
                    content: (
                        <div>
                            <p>Customer id: {err_customer_ids}</p>
                            <p>Service Product id is Missing or Null</p>
                        </div>
                    ),
                    onOk: handleOnClose,
                });
            }
        } catch (error) {
            console.error('Unexpected error:', error);
            message.error('Failed to submit data');
        }
        setShowConfirmModal(false);
    };

    const clearData = () => {
        setRevRows([]);
        setIsClosed(true);
        setIsContinueClicked(false);
        setInitialRows([]);
        // Remove 'Effective Date' from headers and headerMap
        const updatedHeaders = revHeaders.filter(header => header !== 'Effective Date');
        setRevHeaders(updatedHeaders);
        const { 'Effective Date': _, ...updatedHeaderMap } = revHeaderMap;
        setRevHeaderMap(updatedHeaderMap);
    };

    const handleOnClose = () => {
        onClose();
        clearData();
    };

    const handleCancelConfirm = () => {
        setShowConfirmModal(false);
    };

    return (
        <>
            <Modal
                visible={visible}
                title="Disconnect Service Product"
                maskClosable={false}

                footer={
                    <div className="justify-center flex space-x-2">
                        <Button key="cancel" className="cancel-btn" onClick={handleOnClose}>
                            Cancel
                        </Button>
                        {isContinueClicked ? (
                            <Button key="submit" className="save-btn" onClick={handleSubmit} disabled={revRows.length < 1}>
                                Submit
                            </Button>
                        ) : (
                            <Button key="continue" className='save-btn' onClick={handleContinue} disabled={revRows.length < 1}>
                                Continue
                            </Button>
                        )}
                    </div>
                }
                centered
                width={'1400px'}
                bodyStyle={{
                    height: 'auto',
                    overflowY: 'auto',
                }}
                onCancel={handleOnClose}
            >
                <RevTableComponent
                    headers={revHeaders}
                    headerMap={revHeaderMap}
                    initialData={initialRows}
                    searchQuery=""
                    visibleColumns={revHeaders}
                    itemsPerPage={10}
                    moduleName="Disconnect Service Product"
                    pagination={{ start: 1, end: 10, total: initialRows.length }}
                    onDateChange={handleDateChange}
                />
            </Modal>
            <Modal
                open={showConfirmModal}
                title="Confirm Submission"
                onCancel={handleCancelConfirm}
                footer={
                    <div className="justify-center flex space-x-2">
                        <Button key="cancel" className="cancel-btn" onClick={handleCancelConfirm}>
                            Cancel
                        </Button>
                        <Button key="confirm" className="save-btn" onClick={handleConfirmSubmit}>
                            Confirm
                        </Button>
                    </div>
                }
                centered
                width={'auto'}
                bodyStyle={{
                    height: 'auto',
                    overflowY: 'auto',
                }}
            >
                {confirmData && (
                    <>
                        <p>Are you sure want to Submit</p>
                    </>
                )}
            </Modal>
        </>
    );
};

export default DisconnectServiceProductPage;