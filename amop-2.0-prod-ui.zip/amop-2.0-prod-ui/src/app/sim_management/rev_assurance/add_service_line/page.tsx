'use client'
import React, { lazy, Suspense, useState, useEffect, act } from 'react';
import { Modal, Input, Button, Checkbox, DatePicker, Form, message, Row, Col, notification } from 'antd';
import Select from 'react-select';
import { useRevStore } from '@/app/stores/revStore';
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from '@/app/components/header_constants';
import axios from 'axios';
import moment from 'moment';
import { isNumber } from 'lodash';
import { ENV_ROUTES } from '@/app/components/routes/route_constants';

const RevTableComponent = lazy(() => import('@/app/components/revTableComponent/page'));

interface OptionType {
  value: string;
  label: string;
}

interface MyModalProps {
  visible: boolean;
  onCancel: () => void;
}

const AddServiceLine: React.FC<MyModalProps> = ({ visible, onCancel }) => {
  const [form] = Form.useForm();
  const { revRows, revHeaders, revHeaderMap, setIsClosed, setRevRows, setRevHeaderMap } = useRevStore();
  const [isNextClicked, setIsNextClicked] = useState(false);
  const [initialRows, setInitialRows] = useState(revRows)
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [selectedProvider, setSelectedProvider] = useState(null);
  const [selectedServiceType, setSelectedServiceType] = useState(null);
  const [selectedProduct, setSelectedProduct] = useState<any>([]);
  const [usagePlanGroup, setUsagePlanGroup] = useState(null);
  const [selectedPackage, setSelectedPackage] = useState(null);
  const [selectedRate, setSelectedRate] = useState(null);
  const [selectedQuantity, setSelectedQuantity] = useState<string>("1");
  const [description, setDescription] = useState<any>(null);
  const [prorate, setProrate] = useState(false);
  const [addRatePlan, setAddRatePlan] = useState(false);
  const [useCarrierActivation, setUseCarrierActivation] = useState(false);

  const [selectedCustomerRatePlan, setSelectedCustomerRatePlan] = useState(null);
  const [showConfirmation, setShowConfirmation] = useState<boolean>(false);
  const [activationDate, setActivationDate] = useState(null);
  const [customerRatePlanOptions, setCustomerRatePlanOptions] = useState<any[]>([]);
  const [customerOptions, setCustomerOptions] = useState<any[]>([]);
  const [providerOptions, setProviderOptions] = useState<any[]>([]);
  const [serviceTypeOptions, setServiceTypeOptions] = useState<any[]>([]);
  const [usagePlanGroupOptions, setUsagePlanGroupOptions] = useState<any[]>([]);
  const [productOptions, setProductOptions] = useState<any[]>([]);
  const [packageOptions, setPackageOptions] = useState<any[]>([]);
  const [rateOptions, setRateOptions] = useState<any[]>([]);
  const [providerMap, setProviderMap] = useState<{ [key: string]: string }>({});
  const [providerPackageMap, setProviderPackageMap] = useState<{ [key: string]: string }>({});
  const [providerRateMap, setProviderRateMap] = useState<{ [key: string]: string }>({});

  const [customerError, setCustomerError] = useState('');
  const [providerError, setProviderError] = useState('');
  const [serviceTypeError, setServiceTypeError] = useState('');
  const [activationDateError, setActivationDateError] = useState('');
  const [productError, setProductError] = useState('');
  const [packageError, setPackageError] = useState('');
  const [rateError, setRateError] = useState('');
  const [quantityError, setQuantityError] = useState('');
  const [originalHeaderMap, setOriginalHeaderMap] = useState<any>(revHeaderMap);

  const { username, role, partner, token, selectedDb } = useAuth();

  useEffect(() => {
    console.log("opened popup")
    setInitialRows(revRows)
    const customerOptions_ = Array.from(new Set(revRows.map((row) => row?.['customer_name'])));
    setCustomerOptions(customerOptions_);
    setIsNextClicked(false)
    setSelectedCustomer(null)
    setSelectedCustomerRatePlan(null)
    setSelectedPackage(null)
    setSelectedProduct([])
    setSelectedProvider(null)
    setSelectedQuantity("")
    setSelectedRate(null)
    setSelectedServiceType(null)
    setActivationDate(null)
    setDescription(null)
    setUsagePlanGroup(null)

    setPackageOptions([])
    setProviderOptions([])
    setServiceTypeOptions([])
    setProductOptions([])
    setRateOptions([])
    setUsagePlanGroupOptions([])

    setCustomerError('')
    setProviderError('')
    setServiceTypeError('')
    setActivationDateError('')
    setProductError('')
    setQuantityError('')
    setRateError('')
  }, [visible]);


  //To get the initial data
  const fetchData = async (value: any) => {
    try {
      const url =
      ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        path: "/add_service_line_dropdown_data",
        customer_name: value,
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        const revProviderOptions_ = parsedData?.response_data?.rev_provider || []
        setProviderOptions(revProviderOptions_)
        const serviceTypeOptions_ = parsedData?.response_data?.service_type || []
        setServiceTypeOptions(serviceTypeOptions_)
        const revIOProductOptions = parsedData?.response_data?.rev_product || []
        setProductOptions(revIOProductOptions)
        const customerRatePlanOptions = parsedData?.response_data?.customer_rate_plan_dropdown || []
        setCustomerRatePlanOptions(customerRatePlanOptions)
        const rev_usage_plan_group = parsedData?.response_data?.rev_usage_plan_group || []
        setUsagePlanGroupOptions(rev_usage_plan_group)
        const providerPackageMap_ = parsedData?.response_data?.rev_provider_id_map || {}
        setProviderMap(providerPackageMap_)
        const rev_package = parsedData?.response_data?.rev_package || {}
        setProviderPackageMap(rev_package)
        const rate = parsedData?.response_data?.rate || {}
        setProviderRateMap(rate)
      }
    } catch (error) {
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });

    }
  };

  //To submit the requested payload
  const submitData = async () => {
    const selectedICCIDs = revRows.map((row) => row?.['iccid'])
    const selectedProviderss = revRows.map((row) => row?.['service_provider'])
    try {
      const submitData = {
        customer_name: selectedCustomer && selectedCustomer!=='No options'? selectedCustomer:null,
        provider_name: selectedProvider&& selectedProvider!=='No options'? selectedProvider:null,
        service_type: selectedServiceType&& selectedServiceType!=='No options'? selectedServiceType:null,
        revio_product: selectedProduct && !selectedProduct.includes('No options')? selectedProduct:null,
        revio_package: selectedPackage && selectedPackage!=='No options'? selectedPackage:null,
        rate: selectedRate && selectedRate!=='No options'? selectedRate:null,
        rate_plan: selectedCustomerRatePlan && selectedCustomerRatePlan!=='No options'? selectedCustomerRatePlan:null,
        activation_date: activationDate || null,
        quantity: Number(selectedQuantity) ? selectedQuantity : null,
        add_rate_plan: addRatePlan || null,
        prorate: prorate || null,
        use_carrier_activation: useCarrierActivation || null,
        description: description || null,
        iccid: selectedICCIDs || null,
        usage_plan_group: usagePlanGroup && usagePlanGroup!=='No options'? usagePlanGroup:null

      }
      const url =
      ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        path: "/submit_service_line_dropdown_data",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        submit_data: submitData,
        service_provider: selectedProviderss[0] || null

      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        try {
          const url =  ENV_ROUTES.SIM_MANAGEMENT;
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            path: "/run_db_script",
            role_name: role,
            module_name: "Bulk Change",
            mod_pages: {
              start: 0,
              end: 100,
            },
            access_token: token,
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            bulkchange_id: parsedData?.bulkchange_id?.id,
            data: parsedData?.data,
            bulk_chnage_id_20: parsedData?.bulk_chnage_id_20

          };

          const response = await axios.post(url, { data });
          const responseData = JSON.parse(response.data.body);

          if (responseData.flag === false) {
            console.log("failed")
          } else {
            console.log("success")
          }
        } catch (error) {
          console.error("Error fetching data:", error);
        } finally {
        }
      }
    } catch (error) {
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    }

  };

  //Function for handling customer change
  const handleCustomerChange = (selectedOption: any) => {
    // Reset dependent fields
    setPackageOptions([])
    setProviderOptions([])
    setServiceTypeOptions([])
    setProductOptions([])
    setRateOptions([])
    setUsagePlanGroupOptions([])
    setSelectedProvider(null);
    setSelectedServiceType(null);
    setSelectedProduct([]);
    setSelectedPackage(null);
    setSelectedRate(null);
    setUsagePlanGroup(null)
    setSelectedCustomerRatePlan(null);
    if (selectedOption) {
      setSelectedCustomer(selectedOption.value);
      fetchData(selectedOption.value)
    }
    else if (selectedOption === null) {
      setSelectedCustomer(null)
    }
  };

  //Function for handling provider change
  const handleProviderChange = (selectedOption: any) => {
    if (selectedOption) {
      setSelectedProvider(selectedOption.value);
      setPackageOptions([]);
      setRateOptions([]);
      setSelectedPackage(null)
      setSelectedRate(null)
      const providerID = providerMap?.[selectedOption.value]

      if (providerID) {
        // Extract package options and rate options using the provider ID
        const packageOptions: any = providerPackageMap?.[providerID] || [];
        const rateOptions: any = providerRateMap?.[providerID] || [];

        // Update the state with the extracted options
        setPackageOptions(packageOptions);
        setRateOptions(rateOptions);
      } else {
        setPackageOptions([]);
        setRateOptions([]);
      }
    }
    else if (selectedOption === null) {
      setSelectedProvider(null)
    }

  };

  //Function for handling service type change
  const handleServiceTypeChange = (selectedOption: any) => {
    if (selectedOption) {
      setSelectedServiceType(selectedOption.value);
    }
    else if (selectedOption === null) {
      setSelectedServiceType(null)
    }
  };

  //Function for handling rev.io product change
  const handleProductChange = (selectedOptions: any) => {
    if (selectedOptions) {
      setSelectedPackage(null);
      if (Array.isArray(selectedOptions)) {
        const values = selectedOptions.map((option: any) => option.value);
        setSelectedProduct(values);
        setSelectedPackage(null);

      } else {
        setSelectedProduct([]);
      }
    }
    else if (selectedOptions === null) {
      setSelectedProduct([])
    }
  };

  //Function for handling rev.io package change
  const handlePackageChange = (selectedOption: any) => {
    if (selectedOption) {
      setSelectedPackage(selectedOption.value);
    }
    else if (selectedOption === null) {
      setSelectedPackage(null)
    }
  };
  //Function for handling rate change
  const handleRateChange = (selectedOption: any) => {
    if (selectedOption) {
      setSelectedRate(selectedOption.value);
    }
    else if (selectedOption === null) {
      setSelectedRate(null)
    }
  };

  //Function for handling usage plan change
  const handleUsagePlanGroup = (selectedOption: any) => {
    if (selectedOption) {
      setUsagePlanGroup(selectedOption.value);
    }
    else if (selectedOption === null) {
      setUsagePlanGroup(null)
    }
  };

  //Function for handling customer rate plan change
  const handleCustomerRatePlanChange = (selectedOption: any) => {
    if (selectedOption) {
      setSelectedCustomerRatePlan(selectedOption.value);
    }
    else if (selectedOption === null) {
      setSelectedCustomerRatePlan(null)
    }
  };

  const handleSubmit = () => {
    setShowConfirmation(true)
  };

  //Function for handling confirm submit change
  const confirmSubmit = () => {
    setRevHeaderMap(originalHeaderMap)
    setRevRows([]);
    setInitialRows([]);
    setIsClosed(true)
    submitData()
    message.success('Data submitted successfully!');
    setShowConfirmation(false);
    onCancel()
  };

  //Function to display custom label
  const renderLabel = (label: string, required: boolean) => (
    <span className="field-label">
      {label}{" "}
      {required && (
        <span className="required-indicator" style={{ color: "red" }}>
          *
        </span>
      )}
    </span>
  );

  const handleNext = () => {
    let isValid = true;
    // Validate customer
    if (!selectedCustomer) {
      setCustomerError("Please select a customer!");
      isValid = false;
    } else {
      setCustomerError('');
    }

    // Validate provider
    if (!selectedProvider) {
      setProviderError("Please select a provider!");
      isValid = false;
    } else {
      setProviderError('');
    }

    // Validate service type
    if (!selectedServiceType) {
      setServiceTypeError("Please select a service type!");
      isValid = false;
    } else {
      setServiceTypeError('');
    }

    // Validate activation date
    if (!activationDate&&!useCarrierActivation) {
      setActivationDateError("Please select an activation date!");
      isValid = false;
    } else {
      setActivationDateError('');
    }

    // Validate product
    if (selectedProduct.length < 1 && !selectedPackage) {
      setProductError("Please select a either  product or package");
      isValid = false;
    } else {
      setProductError('');
    }

    // Validate package
    // if (!selectedPackage) {
    //   setPackageError("Please select a package!");
    //   isValid = false;
    // } else {
    //   setPackageError('');
    // }

    // Validate rate
    if (!selectedRate) {
      setRateError("Please select a rate!");
      isValid = false;
    } else {
      setRateError('');
    }

    // Validate quantity
    if (!selectedQuantity || isNumber(selectedQuantity) || Number(selectedQuantity) <= 0) {
      setQuantityError("Please input a valid quantity!");
      isValid = false;
    } else {
      setQuantityError('');
    }

    // If the form is valid, proceed to the next step
    if (isValid) {
      setIsNextClicked(true);
      const headerMap_ = {
        "service_number": [
          "Service id",
          null
        ],
        "customer_rate_plan_name": [
          "Customer rate plan",
          null
        ],
        "carrier_rate_plan_name": [
          "Carrier rate plan",
          null
        ]
      }
      setRevHeaderMap(headerMap_)

    } else {
      message.error("Please fill all required fields.");
    }
  };
  const cancelConfirmation = () => {
    setShowConfirmation(false);
    setIsNextClicked(false)
  };
  const handleBack = () => {
    setIsNextClicked(false)
  }
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    // Prevent default behavior for specific keys
    const invalidKeys = ['+', '-', 'e']; // List of invalid keys
    if (invalidKeys.includes(e.key)) {
      e.preventDefault(); // Prevent the default action for these keys
      console.log(`${e.key} key pressed - blocked`);
    }
  };

  const disablePastDates = (current: any) => {
    // Disable all dates before today
    return current && current < moment().startOf('day'); // Start of the current day to include today's date
  };
  return (
    <>
      <Modal
        title="Create new rev.io service line"
        visible={visible}
        onCancel={onCancel}
        width={800}
        maskClosable={false}

        style={{ top: 40 }}
        footer={
          <div className='justify-center flex space-x-2'>

            {isNextClicked ? (
              <>
                <button key="cancel" className='cancel-btn' onClick={handleBack}>
                  Back
                </button>
                <button key="submit" className="save-btn" onClick={handleSubmit}>
                  Submit
                </button>
              </>
            ) : (
              <>
                <button key="cancel" className='cancel-btn' onClick={onCancel}>
                  Cancel
                </button>
                <button key="next" className='save-btn' onClick={handleNext}>
                  Next
                </button>
              </>
            )}

          </div>
        }
      >
        {!isNextClicked ? (
          <div className="form-container">
            <div className='grid grid-cols-2 gap-4'>
              <div>
                <label>{renderLabel("Rev.io customer", true)}</label>
                <Select
                  options={customerOptions.length>0?customerOptions.map((option) => ({
                    label: option,
                    value: option,
                  })):[{value:null,label:'No options'}]}
                  // placeholder="Select a Rev.io customer"
                  value={selectedCustomer === 'No options' ? null : { label: selectedCustomer, value: selectedCustomer }}
                  onChange={handleCustomerChange}
                  isClearable
                />
                {customerError && <p className="error text-red-500">Please select a customer</p>}
              </div>

              <div>
                <label>{renderLabel("Rev.io provider", true)}</label>
                <Select
                  options={providerOptions.length>0?providerOptions.map((option) => ({
                    label: option,
                    value: option,
                  })):[{value:'No options',label:'No options'}]}
                  // placeholder="Please select a Rev.io provider"
                  value={selectedProvider === 'No options' ? null : { label: selectedProvider, value: selectedProvider }}
                  onChange={handleProviderChange}
                  isDisabled={!selectedCustomer||selectedCustomer==='No options'}
                  isClearable
                />
                {providerError && <p className="error text-red-500">Please select a provider</p>}
              </div>

              <div>
                <label>{renderLabel("Service type", true)}</label>
                <Select
                  options={serviceTypeOptions.length>0?serviceTypeOptions.map((option) => ({
                    label: option,
                    value: option,
                  })):[{value:'No options',label:'No options'}]}
                  // placeholder="Please select a service type"
                  value={selectedServiceType === 'No options' ? null : { label: selectedServiceType, value: selectedServiceType }}
                  onChange={handleServiceTypeChange}
                  isDisabled={!selectedCustomer}
                  isClearable
                />
                {serviceTypeError && <p className="error text-red-500">Please select a service type</p>}
              </div>

              <div>
                <label>{renderLabel("Activation date", true)}</label>
                <DatePicker
                  style={{ width: '100%' }}
                  value={activationDate}
                  onChange={(date) => setActivationDate(date)}
                  className='input p-[7px]'
                  disabledDate={disablePastDates}
                  disabled={useCarrierActivation}
                />
                {activationDateError && <p className="error text-red-500">Please select an activation date</p>}
              </div>


              <div>
                <label>{renderLabel("Rev.io product", true)}</label>
                <Select
                  options={productOptions.length>0?productOptions.map((option) => ({
                    label: option,
                    value: option,
                  })):[{value:'No options',label:'No options'}]}
                  // placeholder="Select a product"
                  value={selectedProduct.length > 0 ? selectedProduct.map((option: any) => ({ label: option, value: option })) : null}
                  onChange={handleProductChange}
                  isDisabled={!selectedCustomer || selectedPackage}
                  isMulti
                />
                {productError && <p className="error text-red-500">Please select either product or package</p>}
              </div>

              <div>
                <label>{renderLabel("Rev.io package", true)}</label>
                <Select
                  options={packageOptions.length>0?packageOptions.map((option) => ({
                    label: option,
                    value: option,
                  })):[{value:'No options',label:'No options'}]}
                  placeholder="Please select a rev.io package"
                  value={selectedPackage === 'No options' ? null :{ label: selectedPackage, value: selectedPackage }}
                  onChange={handlePackageChange}
                  isDisabled={selectedProduct.length > 0 || !selectedProvider}
                  isClearable
                />
                {productError && <p className="error text-red-500">Please select either product or package</p>}
              </div>
              <div>
                <label>{renderLabel("Usage plan group", false)}</label>
                <Select
                  options={usagePlanGroupOptions.length>0?usagePlanGroupOptions.map((option) => ({
                    label: option,
                    value: option,
                  })):[{value:'No options',label:'No options'}]}
                  value={usagePlanGroup === 'No options' ? null :{ label: usagePlanGroup, value: usagePlanGroup }}
                  onChange={handleUsagePlanGroup}
                  isDisabled={!selectedCustomer}
                  isClearable
                />
              </div>
              <div>
                <label>{renderLabel("Rate", true)}</label>
                <Select
                  options={rateOptions.length>0?rateOptions.map((option) => ({
                    label: option,
                    value: option,
                  })):[{value:'No options',label:'No options'}]}
                  // placeholder="Please select a rate"
                  value={selectedRate === 'No options' ? null :{ label: selectedRate, value: selectedRate }}
                  onChange={handleRateChange}
                  isDisabled={!selectedProduct}
                  isClearable
                />
                {rateError && <p className="error text-red-500">Please input the rate</p>}
              </div>

              <div>
                <label>{renderLabel("Quantity", true)}</label>
                <input
                  type="number"
                  value={selectedQuantity}
                  // onChange={(e) => {
                  //   const value = Math.max(1, Number(e.target.value)); // Ensure the value is at least 1
                  //   setSelectedQuantity(value); // Update the state with the new value
                  // }}
                  className="input"
                  min={1}
                  onChange={(e) => {
                    const value = Math.max(1, parseInt(e.target.value, 10)); // Ensure quantity is not less than 1
                    setSelectedQuantity(value.toString());
                  }}
                onKeyDown={handleKeyDown} // Add the keydown event listener

                />
                {quantityError && <p className="error text-red-500">Please input the quantity</p>}
              </div>
              <div>
                <label>{renderLabel("Service line description", false)}</label>
                <input
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className='input'
                />
              </div>
              <div>
                <Checkbox
                  checked={useCarrierActivation}
                  onChange={(e) => setUseCarrierActivation(e.target.checked)}
                  className='mt-4'
                >
                  Use carrier activation
                </Checkbox>
                {/* <label>Use Carrier Activation?</label> */}
              </div>
              <div>
                <Checkbox
                  checked={prorate}
                  onChange={(e) => setProrate(e.target.checked)}
                  className='mt-4'
                >
                  Prorate
                </Checkbox>
                {/* <label>Prorate?</label> */}
              </div>
              <div>
                <Checkbox
                  checked={addRatePlan}
                  onChange={(e) => setAddRatePlan(e.target.checked)}
                  className='mt-2'
                >
                  Add rate plan
                </Checkbox>
                {/* <label>Add Customer Rate Plan?</label> */}
              </div>
              {addRatePlan && (
                <div>
                  <label>{renderLabel("Customer rate plan", false)}</label>
                  <Select
                    options={customerRatePlanOptions.length>0?customerRatePlanOptions.map((option) => ({
                      label: option,
                      value: option,
                    })):[{value:'No options',label:'No options'}]}
                    value={{ label: selectedCustomerRatePlan, value: selectedCustomerRatePlan }}
                    onChange={handleCustomerRatePlanChange}
                    isClearable
                  />
                </div>
              )}

            </div>
          </div>

        ) : (
          <>
            <Suspense fallback={<div>Loading...</div>}>
              <RevTableComponent
                headerMap={revHeaderMap}
                headers={revHeaders}
                initialData={initialRows}
                searchQuery=""
                visibleColumns={revHeaders}
                itemsPerPage={10}
                moduleName="Rev.IO Data"
                pagination={{
                  start: 1,
                  end: 10,
                  total: revRows.length
                }}
                advancedFilters={{}}
                onDateChange={() => { }}
              />
            </Suspense>
          </>
        )}
      </Modal>
      <Modal
        title="Submit data"
        visible={showConfirmation}
        onCancel={cancelConfirmation}
        centered
        footer={
          <div className="justify-center flex space-x-2">
            <Button key="cancel" className='cancel-btn' onClick={cancelConfirmation}>
              Cancel
            </Button>
            <Button key="confirm" className='save-btn' onClick={confirmSubmit}>
              OK
            </Button>
          </div>
        }
      >
        <p>Are you sure you want to submit this data</p>
      </Modal>
    </>
  );
};

export default AddServiceLine;
