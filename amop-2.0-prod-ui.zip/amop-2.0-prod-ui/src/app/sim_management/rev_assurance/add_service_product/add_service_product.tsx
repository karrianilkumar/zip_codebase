"use client";
import React, { useState, useEffect } from "react";
import {
  Modal,
  Input,
  Button,
  Checkbox,
  Form,
  message,
  Row,
  Col,
  DatePicker,
} from "antd";
import Select from "react-select";
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { useRevStore } from "@/app/stores/revStore";
import { format } from "date-fns";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";

interface OptionType {
  value: string;
  label: string;
}

interface MyModalProps {
  visible: boolean;
  onCancel: () => void;
  onOk: (data: any) => void;
}

const AddServiceProduct: React.FC<MyModalProps> = ({
  visible,
  onCancel,
  onOk,
}) => {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [submitDisabled, setSubmitDisabled] = useState(true); // State to control Submit button
  const { username, role, partner, token ,selectedDb } = useAuth();
  const { revRows } = useRevStore();

  const [serviceOptions, setServiceOptions] = useState<OptionType[]>([]);
  const [productOptions, setProductOptions] = useState<OptionType[]>([]);
  const [rateOptions, setRateOptions] = useState<OptionType[]>([]);
  const [productIdMap, setProductIdMap] = useState<Record<string, string>>({});
  const [productRateMap, setProductRateMap] = useState<Record<string, string[]>>({});
  const [selectedService, setSelectedService] = useState<OptionType | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<OptionType | null>(null);
  const [selectedRate, setSelectedRate] = useState<OptionType | null>(null);
  const [quantity, setQuantity] = useState<string>("1"); // Start with 1 as minimum
  const [prorate, setProrate] = useState<boolean>(false);
  const [effectiveDate, setEffectiveDate] = useState<Date | null>(null);
  const [description, setDescription] = useState<string>("");

  useEffect(() => {
    if (visible && revRows.length > 0) {
      const customerName = revRows[0].customer_name;
      fetchDropdownData(customerName);
    } else if (!visible) {
      // Reset form fields when modal is closed
      form.resetFields();
      setSelectedService(null);
      setSelectedProduct(null);
      setSelectedRate(null);
      setQuantity("1");
      setProrate(false);
      setEffectiveDate(null);
      setDescription("");
      setSubmitDisabled(true); // Disable Submit button when modal is closed
    }
  }, [visible, revRows, form]);

  const isValidCustomerName = (name: string): boolean => {
    // Define the expected format for `customer_name`
    const expectedFormatRegex = /^\d+ - Service id: \d+ - Service Type: \w+$/;
    return expectedFormatRegex.test(name);
  };

  const fetchDropdownData = async (customerName: string) => {
    try {
      setLoading(true);
      const url =
      ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        path: "/add_service_product_dropdown_data",
        customer_name: customerName,
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching data. Please try again.",
          centered: true,
        });
        setSubmitDisabled(true); // Disable Submit button on fetch error
      } else {
        const customerName = parsedData.response_data.customer_name;

        if (!isValidCustomerName(customerName)) {
          // Handle invalid customer_name format
          setSubmitDisabled(true);
          setServiceOptions([{ value: customerName, label: customerName }]);
          return;
        }

        // Handle valid customer_name format
        const serviceOptions = [{ value: customerName, label: customerName }];

        // Map product options with IDs
        const productIdMap: Record<string, string> =
          parsedData.response_data.rev_product_id_map;
        const productOptions = Object.entries(productIdMap).map(
          ([productName, id]) => ({
            value: id,
            label: productName,
          })
        );

        // Map rates by product ID
        const productRateMap: Record<string, string[]> = {};
        Object.entries(parsedData.response_data.rate).forEach(([id, rates]) => {
          productRateMap[id] = rates as string[];
        });

        setServiceOptions(serviceOptions);
        setProductOptions(productOptions);
        setProductIdMap(productIdMap);
        setProductRateMap(productRateMap);
        setRateOptions([]);
        setSubmitDisabled(false); // Enable Submit button if format is valid
      }
    } catch (error) {
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
      setSubmitDisabled(true); // Disable Submit button on fetch error
    } finally {
      setLoading(false);
    }
  };

  //To handle necessary changes of rev.io product
  const handleProductChange = (selectedOption: OptionType | null) => {
    setSelectedProduct(selectedOption);
    setSelectedRate(null);

    if (selectedOption && selectedOption.value) {
      const productId = selectedOption.value;
      const rates = productRateMap[productId] || [];
      setRateOptions(rates.map((rate) => ({ value: rate, label: rate })));
    } else {
      setRateOptions([]);
    }
  };

  //To submit the requested payload
  const handleSubmit = async () => {
    try {
      const values = await form.validateFields();
      setLoading(true);
      const submitData = {
        customer_name: selectedService?.value==='No options'? selectedService?.value: null,
        product_name: selectedProduct?.label==='No options'?selectedProduct?.label: null,
        rate: selectedRate?.value==='No options' ? [selectedRate.value] : [], // Ensure this is an array
        quantity: quantity || null,
        prorate: prorate || null,
        effective_date: effectiveDate ? effectiveDate.toISOString() : null, // Convert Date to ISO string
        description: description || null,
      };

      const url =
      ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        path: "/submit_add_service_product_dropdown_data",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        submit_data: submitData,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: "Submission Error",
          content:
            parsedData.message ||
            "An error occurred while submitting the data. Please try again.",
          centered: true,
        });
      } else {
        message.success("Data submitted successfully!");
        onOk(submitData);
        onCancel();
      }
    } catch (error) {
      if (error instanceof Error) {
        message.error("Validation failed: " + error.message);
      } else {
        Modal.error({
          title: "Submission Error",
          content:
            "An unexpected error occurred while submitting the data. Please try again.",
          centered: true,
        });
      }
    } finally {
      setLoading(false);
    }
  };
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    // Prevent default behavior for specific keys
    const invalidKeys = ['+', '-', 'e']; // List of invalid keys
    if (invalidKeys.includes(e.key)) {
      e.preventDefault(); // Prevent the default action for these keys
      console.log(`${e.key} key pressed - blocked`);
    }
  };

  const handleDateChange = (date: any) => {
    // Convert date from DatePicker to native Date object
    setEffectiveDate(date ? date.toDate() : null);
  };

  //To display the custom label of fields
  const renderLabel = (label: string, required: boolean) => (
    <span className="field-label">
      {label}{" "}
      {required && (
        <span className="required-indicator" style={{ color: "red" }}>
          *
        </span>
      )}
    </span>
  );

  return (
    <Modal
      title="Create new rev.io service product"
      visible={visible}
      onCancel={onCancel}
      width={800}
      maskClosable={false}
 
      style={{ top: 40 }}
      footer={
        <div className="justify-center flex space-x-2">
          <button key="cancel" className="cancel-btn" onClick={onCancel}>
            Cancel
          </button>
          <button
            key="submit"
            className="save-btn disabled:cursor-not-allowed"
            onClick={handleSubmit}
            // loading={loading}
            // disabled={submitDisabled} // Disable based on state
          >
            Submit
          </button>
        </div>
      }
    >
      <Form layout="vertical" form={form} requiredMark={false}>
        <Row gutter={16}>
          <Col span={12}>
            <Form.Item
              label={renderLabel("Rev.io service", true)}
              name="service"
              rules={[{ required: true, message: "Please select a service!" }]}
            >
              <Select
                options={serviceOptions.length>0?serviceOptions:[{value:'No options',label:'No options'}]}
                placeholder="Select a rev.io service"
                value={selectedService?.value === 'No options' ? null :selectedService}
                onChange={setSelectedService}
              />
            </Form.Item>
          </Col>

          <Col span={12}>
            <Form.Item
              label={renderLabel("Rev.io product", true)}
              name="product"
              rules={[{ required: true, message: "Please select a product!" }]}
            >
              <Select
                options={productOptions.length>0?productOptions:[{value:'No options',label:'No options'}]}
                placeholder="Select a rev.io product"
                value={selectedProduct?.value === 'No options' ? null :selectedProduct}
                onChange={handleProductChange}
                isDisabled={!selectedService} // Disable if no service selected
              />
            </Form.Item>
          </Col>
        </Row>

        <Row gutter={16}>
          <Col span={12}>
            <Form.Item
              label={renderLabel("Rate", true)}
              name="rate"
              rules={[{ required: true, message: "Please select a rate!" }]}
            >
              <Select
                options={rateOptions.length>0?rateOptions:[{value:'No options',label:'No options'}]}
                placeholder="Select a rate"
                value={selectedRate?.value === 'No options' ? null :selectedRate}
                onChange={setSelectedRate}
                isDisabled={!selectedProduct} // Disable if no product selected
              />
            </Form.Item>
          </Col>

          <Col span={12}>
            <Form.Item
              label={renderLabel("Quantity", true)}
              name="quantity"
              rules={[{ required: true, message: "Please enter a quantity!" }]}
            >
              <Input
                className="forminput"
                type="number"
                value={quantity}
                min={1}
                onChange={(e) => {
                  const value = Math.max(1, parseInt(e.target.value, 10)); // Ensure quantity is not less than 1
                  setQuantity(value.toString());
                }}
                onKeyDown={handleKeyDown} // Add the keydown event listener
              />
            </Form.Item>
          </Col>
        </Row>

        <Row gutter={16}>


          <Col span={12}>
            <Form.Item
              label={renderLabel("Effective date", true)}
              name="effectiveDate"
              rules={[{ required: prorate, message: "Please select a date!" }]}
            >
              <DatePicker
                value={
                  effectiveDate ? format(effectiveDate, "yyyy-MM-dd") : null
                }
                onChange={handleDateChange}
                format="YYYY-MM-DD"
                style={{ width: "100%" }}
                disabled={!prorate} // Disable if prorate is not checked
              />
            </Form.Item>
          </Col>
          <Col span={12}>
            <Form.Item name="prorate" valuePropName="checked">
              <Checkbox
                checked={prorate}
                onChange={(e) => setProrate(e.target.checked)}
              >
                Prorate
              </Checkbox>
            </Form.Item>
          </Col>
        </Row>

        <Row gutter={16}>
          <Col span={24}>
            <Form.Item
              label={renderLabel("Product description", false)}
              name="description"
            >
              <Input.TextArea
                rows={4}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </Form.Item>
          </Col>
        </Row>
      </Form>
    </Modal>
  );
};

export default AddServiceProduct;
