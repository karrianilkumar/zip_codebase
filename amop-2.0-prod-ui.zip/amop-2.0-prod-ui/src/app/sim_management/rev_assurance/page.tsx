"use client";
import React, {
  useEffect,
  useState,
  lazy,
  Suspense,
  useRef,
  useCallback,
} from "react";
import { ArrowDownTrayIcon } from "@heroicons/react/24/outline";
import { Button, Modal, Spin, DatePicker, notification, Switch } from "antd";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import dayjs, { Dayjs } from "dayjs";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { MinusCircleOutlined, MinusOutlined, PlusOutlined } from "@ant-design/icons";
import AssignService from "./assign_service/assign_revio_modal";
import { useRevStore } from "@/app/stores/revStore";
import DisconnectServiceProductPage from "./disconnect-service-product/page";
import AddServiceLine from "./add_service_line/page";
import AddServiceProduct from "./add_service_product/add_service_product";
import moment from "moment";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
type ExportData = {
  path: string;
  username: string | null;
  module_name: string;
  request_received_at: string;
  start_date: string;
  end_date: string;
  Partner: string | null;
  access_token: string | null;
  db_name: string | null;
};

const { RangePicker } = DatePicker;
const RevTableComponent = lazy(
  () => import("@/app/components/revTableComponent/page")
);
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));
const TableSearch = lazy(() => import("@/app/components/entire_table_search"));
const AdvancedMultiFilter = lazy(
  () => import("@/app/components/advanced_search")
);

const RevAssurance: React.FC = () => {
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, storedpagination, token, selectedDb } = useAuth();
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([
    null,
    null,
  ]);
  const [selectedDate, setSelectedDate] = useState<string | null>(moment().format('YYYY-MM-DD')); // Default to current date

  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const { revRows, setRevRows, setRevHeaders, setRevHeaderMap ,setShowVarianceStatus} = useRevStore();
  const [duplicateWarning, setDuplicateWarning] = useState(false);
  const [isDuplicates, setIsDuplicates] = useState(false); // Tracks whether duplicates are present

  const [isAssignServiceModalOpen, setIsAssignServiceModalOpen] = useState(false);
  const [showVariance, setShowVariance] = useState(true);
  const [isServiceModalOpen, setisServiceModalOpen] = useState(false);
  const [isDisconnectServiceProductModalOpen, setDisconnectServiceProductModalOpen] = useState(false);
  const [isAddServiceLineModalOpen, setIsAddServiceLineModalOpen] = useState(false);
  const [performanceMatrix, setPerformanceMatrix] = useState<any>({});
  const [isLogModalOpen, setIsLogModalOpen] = useState(false); // State to manage log modal visibility
  const [logs, setLogs] = useState<{ step: string; time: string }[]>([]); // State for logs
  const [loading, setLoading] = useState(true);
  const [latestNavClick, setLatestNavClick] = useState<{
    label: string;
    clickTime: string;
  } | null>(null);

  useEffect(() => {
    // Retrieve the latest navigation click time from localStorage
    const storedNavClick = localStorage.getItem("latestNavClick");
    if (storedNavClick) {
      setLatestNavClick(JSON.parse(storedNavClick));
    }
  }, []);

  const checkForDuplicates = () => {
    const customerNames = revRows.map(row => row.customer_name);
    const carrierNames = revRows.map(row => row.carrier);

    // Check if all names in customerNames are the same
    const allNamesSame = customerNames.every(name => name === customerNames[0]);
    const allCarrierNamesSame = carrierNames.every(name => name === carrierNames[0]);
    // If names are not the same, show the warning and set isDuplicates to true
    if (!allNamesSame || !allCarrierNamesSame) {
      setDuplicateWarning(true); // Show warning if names are different
      setIsDuplicates(true); // Treat different names as 'duplicates' for disabling the button
    } else {
      setIsDuplicates(false); // If all names are the same, no issues
    }
  };

  // Check for duplicates when revRows changes
  useEffect(() => {
    checkForDuplicates();
  }, [revRows]);
  const handleClose = () => {
    setDuplicateWarning(false);
    setIsDuplicates(true)
  };

  // Function to add a log
  const addLog = (step: string) => {
    const now = dayjs().format("HH:mm:ss.SSS"); // 24-hour format with milliseconds
    setLogs((prevLogs) => [...prevLogs, { step, time: now }]);
  };

  type HeaderMap = Record<string, [string, number]>;


  //function to display the headers in order
  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);

  // Function to handle opening the modal
  const openAssignServiceModal = () => {
    setIsAssignServiceModalOpen(true);
  };
  const openServiceProductModal = () => {
    setisServiceModalOpen(true);
  }
  const openDisconnectServiceProductModal = () => {
    setDisconnectServiceProductModalOpen(true);
  };
  const closeAddServiceLineModal = () => {
    setIsAddServiceLineModalOpen(false);
  }


  // Function to handle closing the modal
  const closeAssignServiceModal = () => {
    setIsAssignServiceModalOpen(false);
  };
  const closeServiceProduct = () => {
    setisServiceModalOpen(false);
  }
  const closeDisconnectServiceProductModal = () => {
    setDisconnectServiceProductModalOpen(false);
  };

  const openAddServiceLineModal = () => {
    setIsAddServiceLineModalOpen(true);
  }


  //To initially load the data
  const fetchData = async () => {
    setShowVarianceStatus(true)
    try {
      setLoading(true);
      addLog("UI API call");
      const url =  ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        path: "/get_rev_assurance_data",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Rev assurance",
        feature_module_name:"Rev assurance",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        variance: showVariance
      };
      console.log(getCurrentDateTime(),"Show the log time request sent from ui to lambda");
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      // setPerformanceMatrix(JSON.parse(response.data.performance_matrix));
      addLog("Lambda response to UI");
      console.log(getCurrentDateTime(),"Show the log time response sent from lambda to ui");
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching rev assurance data. Please try again.',
          centered: true,
        });
      } else {
        const headersMap_ = parsedData?.header_map?.["rev assurance"]?.header_map || {}
        const sortedheaderMap = sortHeaderMap(headersMap_)
        setHeaderMap(sortedheaderMap)
        setRevHeaderMap(sortedheaderMap)
        const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : []
        setHeaders(headers_)
        setRevHeaders(headers_)
        setVisibleColumns(headers_)
        const tableData_ = parsedData?.rev_assurance_data || []
        setTableData(tableData_)
        setRevRows([])
        const features_ = parsedData?.header_map?.["rev assurance"]?.module_features || []
        setFeatures(features_)
        const pagination_ = parsedData?.pages || {}
        setPagination(pagination_)
      }
      // addLog('BulkChange Table Data Processing Data Completed');
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [partner, showVariance]);

  const closeLogModal = () => {
    setIsLogModalOpen(false);
  };

  //To handle the Variance feature
  const handleSwitchChange = (checked: any) => {
    setShowVariance(checked)
    setShowVarianceStatus(checked)
  };

  //To handle the export feature
  const exportMutation = useMutation<any, Error, ExportData>({
    mutationFn: async (exportData) => {
      addLog("Rev assurance Export API Call Started");
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const response = await axios.post(
        url,
        { data: exportData },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      addLog("Rev assurance Export API Call Completed");
      return JSON.parse(response.data.body);
    },
    onSuccess: (data) => {
      if (data.flag === true) {
        notification.success({
          message: "Success",
          description: "Successfully exported the record!",
          style: messageStyle,
          placement: "top",
        });
        downloadBlob(data.blob);
      } else {
        Modal.error({
          title: "Export Error",
          content: data.message,
          centered: true,
        });
      }
      handleExportModalClose();
    },
    onError: (error) => {
      console.error("Error downloading the file:", error);
      Modal.error({
        title: "Export Error",
        content:
          "An error occurred while exporting the file. Please try again.",
      });
    },
  });

  const handleFilter = useCallback((advancedFilters: any) => {
  }, []);

  const handleReset = useCallback((EmptyFilters: any) => {
    setFilteredData(EmptyFilters);
  }, []);

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "bold",
    padding: "16px",
  };


  //To handle the opening and closing of the export modals
  const handleExportModalOpen = () => {
    setExportModalOpen(true);
  };

  const handleExportModalClose = () => {
    setExportModalOpen(false);
  };


  //Main function of export (calling route)
  const handleExport = () => {
    if (!dateRange || dateRange[0] === null || dateRange[1] === null) {
      Modal.error({ title: "Error", content: "Please select a date range." });
      return;
    }

    const [startDate, endDate] = dateRange;

    const exportData: ExportData = {
      path: "/export",
      username: username,
      module_name: showVariance ? "rev assurance variance" : "rev assurance",
      request_received_at: getCurrentDateTime(),
      start_date: startDate.format("YYYY-MM-DD 00:00:00"),
      end_date: endDate.format("YYYY-MM-DD 23:59:59"),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
    };

    exportMutation.mutate(exportData);
  };


  //To conver the blob to xlsx
  const downloadBlob = (base64Blob: string) => {
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    const blobObject = new Blob([byteArray], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blobObject);
    link.download = "Rev assurance.xlsx";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  useEffect(() => {
    addLog("Component rendered");
  }, []);

  // useEffect(() => {
  //   if (!loading) {
  //     addLog("Data Displayed in UI");
  //   }
  // }, [loading]);
  useEffect(() => {
    if (!loading) {
      console.log("Data Displayed in UI", getCurrentDateTime());
    }
  }, [loading]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }


  //To disable the future dates in datepicker
  const disableFutureDates = (current: any) => {
    return current && current > dayjs().endOf("day");
  };

  return (
    <>
      <Suspense
        fallback={
          <div className="flex justify-center items-center h-screen">
            <Spin size="large" />
          </div>
        }
      >
        <div className="relative">
          <div className="flex justify-between  p-4">
            <div className="flex justify-start space-x-2">
            {features.includes("Add service line-Rev assurance") && (
              <button
                // type="default"
                // icon={<PlusOutlined />}
                // className={`${revRows.length > 0 ? "active" : "deactive"}`}
                className={`${revRows.length > 0 && !isDuplicates ? "save-btn" : "deactive"} p-[4px] min-h-[40px] w-[200px] pr-[8px]`}
                onClick={openAddServiceLineModal}
                disabled={revRows.length < 1 || isDuplicates}
              >
                <PlusOutlined style={{ marginRight: '8px' }} />
                Add service line
              </button>
            )}
            {features.includes("Add service product-Rev assurance") && (
              <button
                // type="default"
                // icon={<PlusOutlined />}
                onClick={openServiceProductModal}
                className={`${revRows.length > 0 && !isDuplicates ? "save-btn" : "deactive"} p-[4px] min-h-[40px] w-[213px] pr-[8px]`}
                disabled={!(revRows.length > 0) || isDuplicates}
              >
                <PlusOutlined style={{ marginRight: '8px' }} />
                Add service product
              </button>
            )}
            {features.includes("Dissconnect service product-Rev assurance") && (
              <button
                // type="default"
                // icon={<PlusOutlined />}
                className={`${revRows.length > 0 && !isDuplicates ? "save-btn" : "deactive"} p-[4px] min-h-[40px] w-[215px] pr-[8px]`}
                onClick={openDisconnectServiceProductModal}
                disabled={!(revRows.length > 0) || isDuplicates}
              >
                <MinusOutlined style={{ marginRight: '4px' }} />
                Disconnect service product
              </button>
            )}
            {features.includes("Assign service-Rev assurance") && (
              <button
                // type="default"
                // icon={<PlusOutlined />}
                // className="flex items-center border-[#00C1F1] text-[#00C1F1] border-3 rounded-3xl py-4 px-4 font-semibold hover:bg-[#00C1F1] font-normal"
                className={`${revRows.length > 0 && !isDuplicates ? "save-btn" : "deactive"} p-[4px] min-h-[40px] w-[213px] pr-[8px]`}
                onClick={openAssignServiceModal} // Open modal on click
                disabled={!(revRows.length > 0) || isDuplicates}
              >
                <PlusOutlined style={{ marginRight: '8px' }} />
                Assign service
              </button>
            )}
            </div>
            <div className="flex items-center space-x-2 justify-end">
              <Switch onChange={handleSwitchChange} checked={showVariance} className="custom-switch" />
              <span className="font-bold text-lg">Show variance only</span>
            </div>
          </div>
          <div className="p-2 flex items-center justify-between mt-1 mb-2">
            <div className="flex space-x-2">
            {features.includes("Search-Rev assurance") && (
              <TableSearch
                searchTerm={searchTerm}
                setSearchTerm={setSearchTerm}
                tableName={"rev_assurance"}
                headerMap={headerMap}
              // loader={loading}
              />
            )}
            {features.includes("Advanced filter-Rev assurance") && (
              <AdvancedMultiFilter
                showAdvanced={showAdvanced}
                setShowAdvanced={setShowAdvanced}
                onFilter={handleFilter}
                onReset={handleReset}
                headers={headers}
                headerMap={headerMap}
                tableName={"rev_assurance"}
              />
            )}
            </div>
            <div className="flex space-x-2">
            {features.includes("Export-Rev assurance") && (
              <button className="save-btn" onClick={handleExportModalOpen}>
                <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                <span>Export</span>
              </button>
            )}
              <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
              />

            </div>
          </div>

          <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
            <RevTableComponent
              headers={headers}
              headerMap={headerMap}
              initialData={tableData}
              searchQuery={searchTerm}
              visibleColumns={visibleColumns}
              itemsPerPage={100}
              // selectedDate={selectedDate} 
              // handleDateChange={handleDateChange} 
              moduleName="Rev assurance"
              pagination={pagination}
              advancedFilters={filteredData}
              onDateChange={() => { }}
            />
          </div>
          <Modal
            title={
              <span className="font-semibold text-xl space-y-3">
                Export output
              </span>
            }
            visible={isExportModalOpen}
            onCancel={() => {
              handleExportModalClose();
              setDateRange([null, null]);
            }}
            footer={null}
            centered
            afterClose={() => setDateRange([null, null])}
            style={{ top: "-4%" }}
          >
            <div className="flex flex-col space-y-4">
              <span>Select date range</span>
              <RangePicker
                value={
                  dateRange[0] && dateRange[1]
                    ? [dateRange[0], dateRange[1]]
                    : null
                }
                onChange={(dates) => {
                  if (dates && dates.length === 2) {
                    setDateRange([dates[0], dates[1]] as [Dayjs, Dayjs]);
                  } else {
                    setDateRange([null, null]);
                  }
                }}
                format="YYYY-MM-DD"
                disabledDate={disableFutureDates}
              />
              <div
                style={{ marginTop: "2rem" }}
                className="flex  justify-center gap-2 space-x-2"
              >
                <button
                  className="cancel-btn text-[16px] font-medium "
                  onClick={handleExportModalClose}
                  style={{ fontFamily: "Calibri" }}
                >
                  <span>Cancel</span>
                </button>
                <button
                  className="save-btn text-[16px] font-medium"
                  onClick={handleExport}
                  style={{ fontFamily: "Calibri" }}
                >
                  Export
                </button>
              </div>
            </div>
          </Modal>
        </div>
      </Suspense>
      <Modal
        visible={isLogModalOpen}
        onCancel={closeLogModal}
        footer={null}
        title="Performance Details"
        style={{
          position: "fixed",
          bottom: 0,
          right: 0,
          margin: 0,
        }}
        width={800} // Adjusted width for better alignment
      >
        <div style={{ maxHeight: "500px", overflowY: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr>
                <th
                  style={{
                    borderBottom: "2px solid #ddd",
                    padding: "8px",
                    textAlign: "left",
                  }}
                >
                  Step
                </th>
                <th
                  style={{
                    borderBottom: "2px solid #ddd",
                    padding: "8px",
                    textAlign: "left",
                  }}
                >
                  Time
                </th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  Nav Item Clicked
                </td>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  {latestNavClick?.clickTime || "-"}
                </td>
              </tr>
              <tr>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  UI API Call
                </td>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  {logs.find((log) => log.step === "UI API call")?.time || "-"}
                </td>
              </tr>
              <tr>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  Backend API Start Time
                </td>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  {performanceMatrix.start_time || "-"}
                </td>
              </tr>
              <tr>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  Component Rendered
                </td>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  {logs.find((log) => log.step === "Component rendered")
                    ?.time || "-"}
                </td>
              </tr>
              <tr>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  Backend Function Started At
                </td>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  {performanceMatrix.funtion_started_at || "-"}
                </td>
              </tr>
              <tr>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  Backend Database One Connection Complete At
                </td>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  {performanceMatrix.database_one_connection_complete_at || "-"}
                </td>
              </tr>
              <tr>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  Backend Database Two Connection Complete At
                </td>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  {performanceMatrix.database_two_connection_complete_at || "-"}
                </td>
              </tr>
              <tr>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  Backend Permission Manager Verification Completed At
                </td>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  {performanceMatrix.permission_manager_verfication_completed_at ||
                    "-"}
                </td>
              </tr>
              <tr>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  Backend Fetching Module Data Completed At
                </td>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  {performanceMatrix.fetching_module_data_completed_at || "-"}
                </td>
              </tr>
              <tr>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  Backend Auditing Data Completed At
                </td>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  {performanceMatrix.auditing_data_completed_at || "-"}
                </td>
              </tr>
              <tr>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  Backend End Time
                </td>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  {performanceMatrix.end_time || "-"}
                </td>
              </tr>
              <tr>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  Lambda Response to UI
                </td>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  {logs.find((log) => log.step === "Lambda response to UI")
                    ?.time || "-"}
                </td>
              </tr>
              <tr>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  Data Displayed in UI
                </td>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  {logs.find((log) => log.step === "Data Displayed in UI")
                    ?.time || "-"}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </Modal>
      <AssignService
        visible={isAssignServiceModalOpen} // Control visibility
        onCancel={closeAssignServiceModal} // Pass the close handler for cancelling
      />
      <AddServiceProduct visible={isServiceModalOpen} // Control visibility
        onCancel={closeServiceProduct} // Pass the close handler for cancelling
        onOk={(data) => {
          // Handle what happens when the OK button is clicked
          closeServiceProduct(); // Close the modal after submission
        }} />
      <DisconnectServiceProductPage
        visible={isDisconnectServiceProductModalOpen}
        onClose={closeDisconnectServiceProductModal}
      />
      <AddServiceLine
        visible={isAddServiceLineModalOpen}
        onCancel={closeAddServiceLineModal}
      />
      <div>
        {/* Your component JSX goes here */}

        {/* Warning Modal */}
        {duplicateWarning && (
          <Modal
            title="Warning"
            visible={duplicateWarning}
            onOk={handleClose}
            onCancel={handleClose}
            centered
          >
            <p>Multiple customer and carrier names are not allowed.</p>
          </Modal>
        )}
      </div>
    </>

  );

};

export default RevAssurance;
