import React, { lazy, Suspense, useEffect, useState } from 'react';
import { Modal, Button, message, DatePicker } from 'antd';
import Select from 'react-select';
import { useRevStore } from '@/app/stores/revStore';
import { useAuth } from '@/app/components/auth_context';
import { getCurrentDateTime } from '@/app/components/header_constants';
import axios from 'axios';
import VirtualizedSelect from '@/app/components/virtualized_dropdown';
import { ENV_ROUTES } from '@/app/components/routes/route_constants';

// Define the props interface for MyModal
interface MyModalProps {
  visible: boolean;
  onCancel: () => void;
}
// Lazy load the RevTableComponent
const RevTableComponent = lazy(() => import('@/app/components/revTableComponent/page'));

const AssignService: React.FC<MyModalProps> = ({ visible, onCancel }) => {
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [selectedProduct, setSelectedProduct] = useState<any>([]);
  const [selectedPackage, setSelectedPackage] = useState(null);
  const [selectedService, setSelectedService] = useState(null);
  const [isNextClicked, setIsNextClicked] = useState<boolean>(false); // To track if "Next" is clicked
  const { revRows, revHeaders, revHeaderMap, setIsClosed, setRevRows, setRevHeaders, setRevHeaderMap } = useRevStore();
  const [initialRows, setInitialRows] = useState(revRows)
  const [serviceOptions, setServiceOptions] = useState<any[]>([]);
  const [packageOptions, setPackageOptions] = useState<any[]>([]);
  const [productOptions, setProductOptions] = useState<any[]>([]);
  const [customerOptions, setCustomerOptions] = useState<any[]>([]);
  const { username, role, partner, token, selectedDb } = useAuth();
  const [serviceMap, setServiceMap] = useState<{ [key: string]: string }>({});
  const [servicePackageMap, setServicePackageMap] = useState<{ [key: string]: string }>({});
  const [serviceProductMap, setServiceProductMap] = useState<{ [key: string]: string }>({});
  const [isListViewNextClicked, setIsListViewNextClicked] = useState<boolean>(false);
  const [showConfirmation, setShowConfirmation] = useState<boolean>(false);
  const [effectiveDate, setEffectiveDate] = useState(null);
  const [originalHeaderMap, setOriginalHeaderMap] = useState<any>(revHeaderMap);

  const [errors, setErrors] = useState({
    customer: false,
    service: false,
    productOrPackage: false,
  });

  useEffect(() => {
    setInitialRows(revRows)
    const customerOptions_ = revRows.map((row) => row?.['customer_name'])
    setCustomerOptions(customerOptions_)
    setIsNextClicked(false)
    setIsListViewNextClicked(false)

  }, [visible]);

  //to load the initial data
  const fetchData = async (value: any) => {
    try {
      const url =
      ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        path: "/assign_service_dropdown_data",
        customer_name: value,
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        const rev_service = parsedData?.response_data?.rev_service || []
        setServiceOptions(rev_service)
        const rev_product = parsedData?.response_data?.rev_product || []
        setServiceProductMap(rev_product)
        const serviceMap_ = parsedData?.response_data?.rev_service_id_map || {}
        setServiceMap(serviceMap_)
        const rev_package = parsedData?.response_data?.rev_package || {}
        setServicePackageMap(rev_package)

      }
    } catch (error) {
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    }
  };

  //To submit the data (requested payload)
  const submitData = async () => {
    const selectedICCIDs = revRows.map((row) => row?.['iccid'])
    const selectedServiceNos = revRows.map((row) => row?.['service_number'])
    const selectedProviderss = revRows.map((row) => row?.['service_provider'])
    try {
      const submitData = {
        customer_name: selectedCustomer==='No options'? selectedCustomer: null,
        service_type: selectedService==='No options'? selectedService: null,
        revio_product: selectedProduct==='No options'? selectedProduct: null,
        revio_package: selectedPackage==='No options'? selectedPackage: null,
        iccid: selectedICCIDs || null,
        service_number: selectedServiceNos || null,
        effective_date: effectiveDate,
        quantity: revRows.length

      }
      const url =
      ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        path: "/submit_assign_service_data",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        submit_data: submitData,
        // service_provider: selectedProviderss[0] || null

      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        message.success('Data submitted successfully!');
      }
    } catch (error) {
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    }

  };

  //function to handle the customer change
  const handleCustomerChange = (selectedOption: any) => {
    setSelectedPackage(null)
    setSelectedProduct([])
    setSelectedService(null)
    setPackageOptions([])
    setProductOptions([])
    setServiceOptions([])
    if (selectedOption) {
      setSelectedCustomer(selectedOption.value);
      fetchData(selectedOption.value)
    }
    else if (selectedOption === null) {
      setSelectedCustomer(null)
    }
  };
  //function to handle the rev.io product change
  const handleProductChange = (selectedOptions: any) => {
    if (selectedOptions) {
      setSelectedPackage(null);
      console.log("values", selectedOptions)
      if (Array.isArray(selectedOptions)) {
        const values = selectedOptions.map((option: any) => option.value);
        console.log("values", values)
        setSelectedProduct(values);
      } else {
        setSelectedProduct([]);
      }
    }
    else if (selectedOptions === null) {
      setSelectedProduct([])
    }
  };
  //function to handle the rev.io package change
  const handlePackageChange = (selectedOption: any) => {
    if (selectedOption) {
      setSelectedPackage(selectedOption.value);
      setSelectedProduct([]);
    }
    else if (selectedOption === null) {
      setSelectedPackage(null)
    }
  };

  //function to handle the service change
  const handleServiceChange = (selectedOption: any) => {
    setPackageOptions([]);
    setProductOptions([]);
    setSelectedPackage(null)
    setSelectedProduct([])
    if (selectedOption) {
      setSelectedService(selectedOption.value);
      const providerID = serviceMap?.[selectedOption.value]
      if (providerID) {
        // Extract package options and rate options using the provider ID
        const packageOptions: any = servicePackageMap?.[providerID] || [];
        const productOptions: any = serviceProductMap?.[providerID] || [];

        // Update the state with the extracted options
        setPackageOptions(packageOptions);
        setProductOptions(productOptions);
      } else {
        setPackageOptions([]);
        setProductOptions([]);
      }
    }
    else if (selectedOption === null) {
      setSelectedService(null)
    }
  };
  const handleNext = () => {
    const hasErrors = {
      customer: !selectedCustomer,
      service: !selectedService,
      productOrPackage:selectedProduct.length===0&& !selectedPackage,
    };

    setErrors(hasErrors);

    if (!Object.values(hasErrors).some((e) => e)) {
      setIsNextClicked(true);
      const headerMap_ = {
        "service_number": [
          "Service id",
          null
        ],
        "customer_rate_plan_name": [
          "Customer rate plan",
          null
        ],
        "carrier_rate_plan_name": [
          "Carrier rate plan",
          null
        ]
      }
      setRevHeaderMap(headerMap_)
    }
  };
  const handleSubmit = () => {
    setShowConfirmation(true)
  };

  //To reset the values
  const cancelConfirmation = () => {
    setShowConfirmation(false);
    setIsNextClicked(false)
    setIsListViewNextClicked(false);
  };

  //To reset the values
  const confirmSubmit = () => {
    setRevRows([]);
    setInitialRows([]);
    setIsClosed(true)
    submitData()
    setShowConfirmation(false);
    setRevHeaderMap(originalHeaderMap)
    onCancel()
  };

  //to handle navigation
  const handleBack = () => {
    setIsNextClicked(false)
  }

  //to handle navigation
  const handleListViewBack = () => {
    setIsListViewNextClicked(false)
    setIsNextClicked(true)
  }

  //to handle navigation
  const handleListViewNext = () => {
    setIsListViewNextClicked(true)
    setIsNextClicked(false)
  }

  return (
    <>
      <Modal
        title="Assign rev.io service"
        visible={visible}
        onCancel={onCancel}
        maskClosable={false}
        centered
        footer={
          <div className="justify-center flex space-x-2">

            {isListViewNextClicked ? (
              <>
                <button key="cancel" className="cancel-btn" onClick={handleListViewBack}>
                  Back
                </button>
                <button key="submit" className="save-btn" onClick={handleSubmit}>
                  Submit
                </button>
              </>
            ) : isNextClicked ? (
              <>
                <button key="cancel" className="cancel-btn" onClick={handleBack}>
                  Back
                </button>
                <button key="submit" className="save-btn" onClick={handleListViewNext}>
                  Next
                </button>
              </>
            ) : (
              <>
                <button key="cancel" className="cancel-btn" onClick={onCancel}>
                  Cancel
                </button>
                <button key="next" className="save-btn" onClick={handleNext}>
                  Next
                </button>
              </>
            )}

          </div>
        }
      >
        {
          isListViewNextClicked ? (
            <div>
              <div>
                <label style={{ marginRight: 8 }}>Quantity:</label>
                <input
                  type="text"
                  value={revRows.length || 0}
                  readOnly
                  className='non-editable-input' />
              </div>
              <div style={{ marginBottom: 16 }}>
                <label style={{ marginRight: 8 }}>Effective date:</label>
                <DatePicker
                  value={effectiveDate}
                  onChange={(date) => setEffectiveDate(date)}
                  className='input' />
              </div>
            </div>
          ) : isNextClicked ? (
            <>
              <Suspense fallback={<div>Loading...</div>}>
                <RevTableComponent
                  headerMap={revHeaderMap}
                  headers={revHeaders}
                  initialData={initialRows}
                  searchQuery=""
                  visibleColumns={revHeaders}
                  itemsPerPage={10}
                  moduleName="Rev.io data"
                  pagination={{
                    start: 1,
                    end: 10,
                    total: revRows.length,
                  }}
                  advancedFilters={{}}
                  onDateChange={() => { }}
                />
              </Suspense>
            </>
          ) :
            (
              <>
                <div className="form-group">
                  <label>
                    Rev.io customer <span style={{ color: 'red' }}>*</span>
                  </label>
                  <Select
                    options={customerOptions.length>0?customerOptions.map((option) => ({
                      label: option,
                      value: option,
                    })):[{value:'No options',label:'No options'}]}
                    placeholder="Select Customer"
                    value={selectedCustomer === 'No options' ? null :{ label: selectedCustomer, value: selectedCustomer }}
                    onChange={handleCustomerChange}
                    isClearable
                  />
                  {errors.customer && <p style={{ color: 'red' }}>Customer is required</p>}
                </div>

                <div className="form-group" style={{ marginTop: '16px' }}>
                  <label>
                    Rev.io service <span style={{ color: 'red' }}>*</span>
                  </label>
                  <VirtualizedSelect
                    isDisabled={!selectedCustomer}
                    value={selectedService === 'No options' ? null :{ label: selectedService, value: selectedService }}
                    onChange={handleServiceChange}
                    options={serviceOptions.length>0?serviceOptions.map((option: string) => ({
                      label: option,
                      value: option,
                    })):[{value:'No options',label:'No options'}]}
                    isMulti={false}
                    placeholder="Please Select customer"
                    maxHeight={300} // Define the max height for the dropdown
                  />
                  {errors.service && <p style={{ color: 'red' }}>Service is required</p>}
                </div>

                <div className="form-group" style={{ marginTop: '16px' }}>
                  <label>
                    Rev.io product <span style={{ color: 'red' }}>*</span>
                  </label>
                  <Select
                    options={productOptions.length>0?productOptions.map((option) => ({
                      label: option,
                      value: option,
                    })):[{value:'No options',label:'No options'}]}
                    placeholder="Select Product"
                    value={selectedProduct.length > 0 ? selectedProduct.map((option: any) => ({ label: option, value: option })):null}
                    onChange={handleProductChange}
                    isDisabled={!!selectedPackage || !selectedCustomer || !selectedService}
                    isClearable
                    isMulti
                  />
                </div>

                <label style={{ display: 'block', marginTop: '8px' }}>Or</label>

                <div className="form-group" style={{ marginTop: '16px' }}>
                  <label>
                    Rev.io package <span style={{ color: 'red' }}>*</span>
                  </label>
                  <Select
                    options={packageOptions.length>0?packageOptions.map((option) => ({
                      label: option,
                      value: option,
                    })):[{value:'No options',label:'No options'}]}
                    placeholder="Select Package"
                    value={selectedPackage === 'No options' ? null :{ label: selectedPackage, value: selectedPackage }}
                    onChange={handlePackageChange}
                    isDisabled={selectedProduct.length > 0 || !selectedCustomer|| !selectedService}
                    isClearable
                  />
                </div>

                {errors.productOrPackage && (
                  <p style={{ color: 'red' }}>
                    Either rev.io product or rev.io package is required
                  </p>
                )}
              </>
            )
        }
      </Modal>
      <Modal
        title="Submit Data"
        visible={showConfirmation}
        onCancel={cancelConfirmation}
        centered
        footer={
          <div className="justify-center flex space-x-2">
            <Button key="cancel" className='cancel-btn' onClick={cancelConfirmation}>
              Cancel
            </Button>
            <Button key="confirm" className='save-btn' onClick={confirmSubmit}>
              OK
            </Button>
          </div>
        }
      >
        <p>Are you sure you want to submit this data</p>
      </Modal>
    </>
  );
};

export default AssignService;
