import React from 'react';
import { DatePicker } from 'antd';
import dayjs from 'dayjs';
import type { Dayjs } from 'dayjs';

interface EffectiveDateProps {
  selectedDate: string | null;
  handleDateChange: (date: string | null) => void;
}

const EffectiveDate: React.FC<EffectiveDateProps> = ({ selectedDate, handleDateChange }) => {
  const disablePastDates = (current: Dayjs) => {
    return current && current < dayjs().startOf('day');
  };

  return (
    <DatePicker
      format="YYYY-MM-DD"
      style={{ width: '100%' }}
      disabledDate={disablePastDates}
      value={selectedDate ? dayjs(selectedDate) : null}
      onChange={(date: Dayjs | null) => {
        const formattedDate = date ? date.format('YYYY-MM-DD') : null;
        handleDateChange(formattedDate);
      }}
    />
  );
};

export default EffectiveDate;