import { Modal, notification, Spin } from "antd";
import axios from "axios";
import React, { useEffect, useState } from "react";
import Select from "react-select";
import { getCurrentDateTime } from "../components/header_constants";
import { useAuth } from "../components/auth_context";
import { ENV_ROUTES } from "../components/routes/route_constants";
import VirtualizedSelect from "../components/virtualized_dropdown";
import { useOptimizationStore } from "../stores/optimizationStore";
import moment from "moment";
import { DropdownStyles } from "../components/css/dropdown";

interface OptimizeProps {
  onCancel: () => void;
  isOpen: boolean;
  module_name: string;
  onSubmit: () => void;
}
const messageStyle = {
  fontSize: '14px',
  fontWeight: 'bold',
  padding: '16px',
};
const Optimize: React.FC<OptimizeProps> = ({ onCancel, isOpen, module_name ,onSubmit}) => {
  const { optimizationType: storeOptimizationType } = useOptimizationStore();
  const [optimizationType, setOptimizationType] = useState<string>(storeOptimizationType==="Customer"?"Customer":"Carrier");
  const [serviceProvider, setServiceProvider] = useState<string[] | null>(null);
  const [selectedServiceProviderId, setSelectedServiceProviderId] = useState<any[]>([]);
  // const [serviceProvider, setServiceProvider] = useState<string | null>(null);
  // const [selectedServiceProviderId, setSelectedServiceProviderId] = useState<any | null>(null);
  const [serviceProviderOptions, setServiceProviderOptions] = useState<any>([]);
  const [customerOptions, setCustomerOptions] = useState<any>([]);
  const [billPeriodOptions, setBillPeriodOptions] = useState<any>([]);

  const [selectedCustomer, setSelectedCustomer] = useState<string | null>(null);
  const [startModalOpen, setStartModalOpen] = useState<boolean>(false);
  const [selectedCustomerId, setSelectedCustomerId] = useState<any | null>(null);
  const [selectedBillPeriodEnd, setSelectedBillPeriodEnd] = useState<string | null>(
    null
  );
  const [selectedBillPeriodStart, setSelectedBillPeriodStart] = useState<string | null>(
    null
  );
  const [selectedBillPeriodId, setSelectedBillPeriodId] = useState<any | null>(
    null
  );
  const [formattedDate, setFormattedDate] = useState<string | null>(null);
  const [crossProvider, setCrossProvider] = useState<boolean>(false);
  const [providersCustomersMap, setProvidersCustomersMap] = useState<any>({});
  const [CustomersMap,setCustomersMap] = useState<any>({});
  const [providersBillingPeriodMap, setProvidersBillingPeriodMap] =
    useState<any>({});
  const [providersIDMap, setProvidersIDMap] = useState<any>({});
    
  const { username, role, partner, token, selectedDb,metaData, firstLastName, sessionId, } = useAuth();
  const [loading, setLoading] = useState(false);
  const [comments, setComments] = useState<string>("");
  const optimizationTypeOptions = 
  optimizationType === "Carrier"
    ? [{ label: "Carrier", value: "Carrier" }]
    : [{ label: "Customer", value: "Customer" }];

  const [totalSIMCards, setTotalSIMCards] = useState<any | null>(null);
  const [SIMCardsToOptimize, setSIMCardsToOptimize] = useState<any | null>(null);
  const [ratePlanCount, setRatePlanCount] = useState<any | null>(null);


  // State to manage error messages
  const [optimizationTypeError, setOptimizationTypeError] = useState<boolean>(false);
  const [serviceProviderError, setServiceProviderError] = useState<boolean>(false);
  const [billPeriodError, setBillPeriodError] = useState<boolean>(false);
  const [billPeriodStartError, setBillPeriodStartError] = useState<boolean>( SIMCardsToOptimize === 0);

  const [customerError, setCustomerError] = useState<boolean>(false);
  useEffect(() => {
    setBillPeriodStartError(SIMCardsToOptimize === 0);
  }, [SIMCardsToOptimize]);

  useEffect(() => {

    if(optimizationType==="Customer" && selectedBillPeriodId && serviceProvider && serviceProvider.length>0 && selectedServiceProviderId.length>0 ){
      fetchCustomerOptions()
    }
  }, [selectedBillPeriodId,selectedServiceProviderId]);


  const fetchData = async () => {
    try {
      setLoading(true);
      const url = ENV_ROUTES.OPTIMIZATION
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/optimization_dropdown_data",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        setLoading(false);
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      } else {
        setLoading(false);
        const service_provider_Customer_mapping =
          parsedData?.service_provider_customers || {};
        setProvidersCustomersMap(service_provider_Customer_mapping);
        const service_provider_dict =
          parsedData?.service_provider_dict || {};
        setProvidersIDMap(service_provider_dict);
        const service_provider_options = Object.keys(
          service_provider_Customer_mapping
        );
        const serviceProviderOptions_ = 
        optimizationType === "Carrier"
          ? ["AT&T - Cisco Jasper", "AT&T - POD19", "Rogers Sandbox", "T-Mobile Jasper"]
          : service_provider_options;
      
      setServiceProviderOptions(serviceProviderOptions_);
      
        const service_provider_billing_mapping =
          parsedData?.service_provider_billing_periods || {};
        setProvidersBillingPeriodMap(service_provider_billing_mapping);
        const cross_carrier_optimization =
          parsedData?.cross_carrier_optimization || false;
        setCrossProvider(cross_carrier_optimization);
      }
    } catch (error) {
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    }
  };
  const fetchNextData = async () => {
    try {
      setLoading(true);
      const url = ENV_ROUTES.OPTIMIZATION
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_optimization_pop_up_data",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        optimization_type: optimizationType,
        ...(!crossProvider
          ? { ServiceProviderId: selectedServiceProviderId[0] }
          : { serviceProviderIds: selectedServiceProviderId }),
        BillingPeriodId: selectedBillPeriodId,
        customer_name: selectedCustomer,
        customer_id: selectedCustomer === "All Customers" ? 0 : selectedCustomerId || 0,
        BillingPeriodStart: selectedBillPeriodStart,
        BillingPeriodEnd: selectedBillPeriodEnd
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        // setLoading(false);
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching data. Please try again.",
          centered: true,
        });
        // await startPolling();
      } else {
        setLoading(false);

        const rate_plan_count = parsedData?.rate_plan_count
        setRatePlanCount(rate_plan_count)
        const sim_cards_to_optimize = parsedData?.sim_cards_to_optimize
        setSIMCardsToOptimize(sim_cards_to_optimize)
        const total_sim_cards_count = parsedData?.total_sim_cards_count
        setTotalSIMCards(total_sim_cards_count)
        setStartModalOpen(true)
      }
    } catch (error) {
      await startPolling();
    }
    finally{
      setLoading(false);
    }
  };

  const pollNextData = async () => {
    try {

        const url = ENV_ROUTES.OPTIMIZATION;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/get_optimization_pop_up_values",
          role_name: role,
          Partner: partner,
          request_received_at: getCurrentDateTime(),
          access_token: token,
          db_name: selectedDb,
        ... metaData,
          sessionID: sessionId,
          optimization_type: optimizationType,
          ...(!crossProvider
            ? { ServiceProviderId: selectedServiceProviderId[0] }
            : { serviceProviderIds: selectedServiceProviderId }),
          BillingPeriodId: selectedBillPeriodId,
          customer_name: selectedCustomer,
          customer_id: selectedCustomer === "All Customers" ? 0 : selectedCustomerId || 0,
          BillingPeriodStart: selectedBillPeriodStart,
          BillingPeriodEnd: selectedBillPeriodEnd
        };
  
        const response = await axios.post(url, { data: data });
        const parsedData = JSON.parse(response.data.body);

        if (parsedData.flag && parsedData?.status === "Success") {
          const rate_plan_count = parsedData?.rate_plan_count
        setRatePlanCount(rate_plan_count)
        const sim_cards_to_optimize = parsedData?.sim_cards_to_optimize
        setSIMCardsToOptimize(sim_cards_to_optimize)
        const total_sim_cards_count = parsedData?.total_sim_cards_count
        setTotalSIMCards(total_sim_cards_count)
        setStartModalOpen(true)
          
            return true; // Stop polling
        }

        if (parsedData?.status === "Failure") {
            Modal.error({
                title: "Data Fetch Error",
                content: parsedData.message || "An error occurred while fetching data. Please try again.",
                centered: true,
            });
            return true; // Stop polling
        }

        return false; // Continue polling
    } catch (error) {
        Modal.error({
            title: "Data Fetch Error",
            content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
            centered: true,
        });
        return true; // Stop polling
    }
};
const startPolling = async () => {
    let isPollingComplete = false;

    while (!isPollingComplete) {
        isPollingComplete = await pollNextData();
        if (!isPollingComplete) {
            await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
        }
    }
};

  useEffect(() => {
    clearFields()
    fetchData();
  }, [isOpen]);

  const fetchCustomerOptions = async () => {
    try {
      setLoading(true);
      const url = ENV_ROUTES.OPTIMIZATION
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_customer_optimization_customers_data",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        service_provider_id:selectedServiceProviderId[0] || 0,
        billing_period_id:selectedBillPeriodId || 0,
        mobility_flag: serviceProvider && serviceProvider.length>0 && serviceProvider[0]?.includes("AT&T - Telegence") ? true:false || false,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        setLoading(false);
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      } else {
        setLoading(false);
        const customers =parsedData?.customers || {};
        setCustomersMap(customers);
        const formattedCustomerOptions = [
          ...(customers.length > 1
            ? [{ label: "All Customers", value: "All Customers" }]
            : []),
          ...customers.map((customer: any) => ({
            label: customer.customer_name,
            value: customer.customer_name,
          })),
        ];
        setCustomerOptions(formattedCustomerOptions);
        
      }
    } catch (error) {
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    }
  };

  const clearFields = () => {
    setServiceProvider(null);
    setSelectedServiceProviderId([]);

    setSelectedBillPeriodEnd(null);
    setFormattedDate(null)
    setSelectedBillPeriodStart(null)
    setSelectedBillPeriodId(null);

    setSelectedCustomer(null);
    setSelectedCustomerId(null)

    setRatePlanCount(null)
    setTotalSIMCards(null)
    setSIMCardsToOptimize(null)

    setBillPeriodStartError(false)
    setBillPeriodError(false)
    setCustomerError(false)
    setServiceProviderError(false)
    setOptimizationTypeError(false)

    setComments("")
  };

  const handleValidation = (): boolean => {
    let isValid = false
    if (!serviceProvider) {
      setServiceProviderError(true);
      isValid = false
    } else {
      isValid = true
      setServiceProviderError(false);
    }

    if (!selectedBillPeriodEnd) {
      setBillPeriodError(true);
      isValid = false
    } else {
      setBillPeriodError(false);
      isValid = true
    }

    if (!optimizationType) {
      setOptimizationTypeError(true);
      isValid = false
    } else {
      setOptimizationTypeError(false);
      isValid = true
    }

    if (optimizationType && optimizationType === "Customer") {
      if (!selectedCustomer) {
        setCustomerError(true)
        isValid = false
      }
      else {
        setCustomerError(false);
        isValid = true
      }
    }
    // Continue with further actions if no errors
    if (isValid) {
      fetchNextData()
      return false
    }
    else {
      return true
    }
  }
  const handleNext = () => {
    handleValidation()
  };

  const formattedStartDate = moment(selectedBillPeriodStart).format('YYYY-MM-DD HH:mm:ss');
  const formattedEndDate = moment(selectedBillPeriodEnd).format('YYYY-MM-DD HH:mm:ss');
  console.log("Show total count", totalSIMCards)
  console.log("Show end date",selectedBillPeriodStart, formattedStartDate)
  console.log("Show end date",selectedBillPeriodEnd, formattedEndDate)
  const submitData = async () => {
    setLoading(true);
    onCancel()
     // Set a timeout for 5 seconds before proceeding
     setTimeout(() => {
      setLoading(false); // Stop the loader
      onSubmit(); // Call the cancel function
      notification.success({
        message: "Success",
        description: "Successfully started Optimization.",
        style: messageStyle,
        placement: "top",
      });
    }, 10000); //  10 seconds
    try {
      const url = ENV_ROUTES.OPTIMIZATION
      const body = {
        billPeriodId: selectedBillPeriodId,
        siteId: selectedCustomer === "All Customers" ? 0 : selectedCustomerId || null,
        serviceProviderId: selectedServiceProviderId,
        serviceProviderIds: "",
        optimizationType: optimizationType === "Customer" ? 1 : 0,
        optimizationFrom: module_name === "Optimization" ? "group" : "",
        billingEndDayList: "",
      }
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/start_optimization",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        body: { ...body },
        device_count:SIMCardsToOptimize,
        billing_period_start_date:formattedStartDate,
        billing_period_end_date:formattedEndDate ,
        template :`
        Hi ${username},

        This will start a ${optimizationType} optimization for the ${formattedDate} billing period.

        The billing period for ${serviceProvider} is from ${selectedBillPeriodStart} to ${selectedBillPeriodEnd}.

        Total SIM Cards: ${totalSIMCards}

        SIM Cards to Optimize: ${SIMCardsToOptimize}

        Rate Plan Count: ${ratePlanCount}

        Thank you
      `
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      // if (parsedData.flag === false) {
      //   setLoading(false);
      //   Modal.error({
      //     title: "Data Fetch Error",
      //     content:
      //       parsedData.message ||
      //       "An error occurred while submitting data. Please try again.",
      //     centered: true,
      //   });
      // } else {
      //   setLoading(false);
      //   notification.success({
      //     message: 'Success',
      //     description: 'Successfully saved.',
      //     style: messageStyle,
      //     placement: 'top',
      //   });
      // }
    } catch (error) {
      // Modal.error({
      //   title: "Data Fetch Error",
      //   content:
      //     error instanceof Error
      //       ? error.message
      //       : "An unexpected error occurred while submitting data. Please try again.",
      //   centered: true,
      // });
    }
    finally {
      setLoading(false)
    }
  };

  const handleStart = () => {
    submitData()
  };

  const handleCancel = () => {
    clearFields()
    onCancel();
    setStartModalOpen(false)
  };

  const handleOptimizationTypeChange = (selectedOption: any) => {
    if (selectedOption) {
      const value = selectedOption.value
      const service_provider_options = Object.keys(
        providersIDMap
      );
      const serviceProviderOptions_ = value === "Carrier" ? ["AT&T - Cisco Jasper", "AT&T - POD19", "Rogers Sandbox", "T-Mobile Jasper"] : service_provider_options
      setServiceProviderOptions(serviceProviderOptions_)
      setOptimizationType(selectedOption.value);
    }
    else {
      setOptimizationType(selectedOption.value);
    }
  };
  const handleCommentsChange = (value: string) => {
    setComments(value);
  };

  const handleServiceProviderChange = (selectedOption: any) => {
    if (selectedOption) {
      setSelectedBillPeriodEnd(null);
      setFormattedDate(null)
      setCustomerOptions([]);
      setBillPeriodOptions([]);
    console.log("selectedOption",selectedOption)
      const selectedValues = Array.isArray(selectedOption)
        ? selectedOption.map((option: any) => option.value)
        : [selectedOption.value];
        console.log("selectedValues",selectedValues)

      setServiceProvider(selectedValues);

      const selectedProviderIds = selectedValues.map(
        (value) => providersIDMap[value] || null
      );
      setSelectedServiceProviderId(selectedProviderIds);

      if(optimizationType==="Customer"){
        setCustomerOptions([])
      }
      else{
        // Aggregate customer options from selected service providers
      const aggregatedCustomers = selectedValues.flatMap((provider) =>
        providersCustomersMap[provider]?.customers || []
      );
      const formattedCustomerOptions = [
        ...(aggregatedCustomers.length > 1
          ? [{ label: "All Customers", value: "All Customers" }]
          : []),
        ...aggregatedCustomers.map((customer: any) => ({
          label: customer.customer_name,
          value: customer.customer_name,
        })),
      ];
      setCustomerOptions(formattedCustomerOptions);
      }
      
      // Aggregate bill period options
      const aggregatedBillPeriods = selectedValues.flatMap(
        (provider) => providersBillingPeriodMap[provider] || []
      );
      const formattedBillPeriodOptions = aggregatedBillPeriods.map((period: any) => ({
        label: period.billing_period_end_date,
        value: period.billing_period_end_date,
      }));
      setBillPeriodOptions(formattedBillPeriodOptions);
      if (formattedBillPeriodOptions.length > 0) {
      const billPeriodValue=formattedBillPeriodOptions[0].value
        setSelectedBillPeriodEnd(billPeriodValue);
         // Parse and format the date
      const date = new Date(billPeriodValue);
      const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'long' }; // Correct options
      const formatted = new Intl.DateTimeFormat('en-US', options).format(date);
      setFormattedDate(formatted);
      handleFutureDateSelection(billPeriodValue)
      // Find the selected billing period object
      const selectedBillPeriodObject = aggregatedBillPeriods.find(
        (period: any) => period.billing_period_end_date === billPeriodValue
      );

      const selectedId = selectedBillPeriodObject?.id || null;
      setSelectedBillPeriodId(selectedId);

      const selectedStart = selectedBillPeriodObject?.billing_period_start_date || null;
      setSelectedBillPeriodStart(selectedStart);

      }
      // setSelectedCustomer(null); // Reset selected customer
      // setSelectedBillPeriodEnd(null); // Reset selected customer
    } else {
      setServiceProvider(null);
      setSelectedCustomer(null);
      setSelectedBillPeriodEnd(null);
      setFormattedDate(null)
      setSelectedServiceProviderId([]);
      setCustomerOptions([]);
      setBillPeriodOptions([]);
    }
  };

  const handleCustomerChange = (selectedOption: { label: string; value: string } | null) => {
    if (selectedOption) {
      const value = selectedOption.value;

      if (value === "All") {
        // Handle "All" selection
        setSelectedCustomer("All");
        setSelectedCustomerId(null); // No specific ID for "All"
      } else {
        // Handle individual customer selection
        setSelectedCustomer(value);

        // Safely retrieve customer options

        let customerOptions_:any

        if(optimizationType==="Customer"){
          customerOptions_=[...CustomersMap]
        }
        else{
          customerOptions_ = Array.isArray(serviceProvider)
          ? serviceProvider.flatMap(
            (provider: string) => providersCustomersMap?.[provider]?.customers || []
          )
          : serviceProvider
            ? providersCustomersMap?.[serviceProvider]?.customers || []
            : [];
        }

         // Find the selected customer object
         const selectedCustomerObject = customerOptions_.find(
          (customer: any) => customer.customer_name === value
        );

        const selectedId = selectedCustomerObject?.customer_id || null;
        setSelectedCustomerId(selectedId);
        
      }
    } else {
      // Reset state when no customer is selected
      setSelectedCustomer(null);
      setSelectedCustomerId(null);
    }
  };

  const handleFutureDateSelection=(date:any)=>{
    //Checking the date is in future
    if (date) {
      // Parse the selectedStart date
      const selectedStartDate = new Date(date);
      console.log("selectedStartDate",selectedStartDate)
      // Compare with today's date
      const today = new Date(); // Current date and time
      console.log("today",today)
  } 
  }
  const handleBillPeriodChange = (selectedOption: any) => {
    if (selectedOption) {
      const value = selectedOption.value; // Get the selected value
      setSelectedBillPeriodEnd(value);
      handleFutureDateSelection(value)

      // Parse and format the date
      const date = new Date(value);
      const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'long' }; // Correct options
      const formatted = new Intl.DateTimeFormat('en-US', options).format(date);
      setFormattedDate(formatted);

      // Safely retrieve billing period data
      const billPeriodOptions_ = Array.isArray(serviceProvider)
        ? serviceProvider.flatMap((provider: string) => providersBillingPeriodMap?.[provider] || [])
        : serviceProvider
          ? providersBillingPeriodMap?.[serviceProvider] || []
          : [];

      // Find the selected billing period object
      const selectedBillPeriodObject = billPeriodOptions_.find(
        (period: any) => period.billing_period_end_date === value
      );

      const selectedId = selectedBillPeriodObject?.id || null;
      setSelectedBillPeriodId(selectedId);

      const selectedStart = selectedBillPeriodObject?.billing_period_start_date || null;
      setSelectedBillPeriodStart(selectedStart);

    } else {
      // Clear state when the selection is cleared
      setSelectedBillPeriodEnd(null);
      setFormattedDate(null)
      setFormattedDate(null);
      setSelectedBillPeriodId(null);
      setSelectedBillPeriodStart(null);
    }
  };


  return (
    <Modal
      visible={isOpen}
      onCancel={handleCancel}
      footer={null}
      width="600px"
      centered
    >
      {loading ? (
        <div className="flex justify-center items-center h-[400px]">
          <Spin size="large" />
        </div>
      )
        : (
          <>
            <div className="container">
              <div className="mb-4">
                <h2 className="font-[600] text-[18px]">Start Optimization</h2>
              </div>
              <div className="flex flex-col space-y-4 mb-4">
                <div className="">
                  <label className="field-label">
                    Optimization Type<span className="text-red-500">*</span>
                  </label>
                  <Select
                    options={optimizationTypeOptions}
                    // defaultValue={optimizationTypeOptions[1]}
                    value={{label:optimizationType,value:optimizationType}}
                    onChange={handleOptimizationTypeChange}
                    styles={DropdownStyles}
                    
                  />
                  {optimizationTypeError && (
                    <span className="text-red-500 text-sm">Please Select an Optimization Type.</span>
                  )}
                </div>
                <div className="">
                  <label className="field-label">
                    Service Provider<span className="text-red-500">*</span>
                  </label>
                  <Select
                    options={serviceProviderOptions.map((option: string) => ({
                      label: option,
                      value: option,
                    }))}
                    onChange={handleServiceProviderChange}
                    isClearable
                    styles={DropdownStyles}
                    // isMulti={crossProvider}
                    value={serviceProvider && serviceProvider.length>0 ? {label:serviceProvider[0], value:serviceProvider[0]}:null}

                  />

                  {serviceProviderError && (
                    <span className="text-red-500 text-sm">Service Provider is Required.</span>
                  )}
                </div>
                <div className="">
                  <label className="field-label">
                    Bill Period End Date<span className="text-red-500">*</span>
                  </label>
                  <Select
                    options={billPeriodOptions.map((option: string | { label: string; value: string }) =>
                      typeof option === "string"
                        ? { label: option, value: option }
                        : option
                    )}
                    value={
                      selectedBillPeriodEnd
                        ? { label: selectedBillPeriodEnd, value: selectedBillPeriodEnd }
                        : null
                    }
                    onChange={handleBillPeriodChange}
                    isDisabled={!serviceProvider}
                    isClearable
                    styles={DropdownStyles}
                  />

                  {billPeriodError && (
                    <span className="text-red-500 text-sm">Bill Period End Date is Required.</span>
                  )}
                 
                </div>
                <div className="">
                  <div className="flex items-center">
                    <label className="field-label">Customer</label>
                    {optimizationType === "Customer" && <span className="text-red-500">*</span>}
                  </div>
                  <VirtualizedSelect
                    value={
                      selectedCustomer
                        ? { label: selectedCustomer, value: selectedCustomer }
                        : null
                    }
                    onChange={handleCustomerChange}
                    options={customerOptions}
                    isMulti={false}
                    placeholder=""
                    isDisabled={optimizationType === "Carrier" || !serviceProvider}
                    isClearable
                    maxHeight={300} // Define the max height for the dropdown
                  />

                  {customerError && (
                    <span className="text-red-500 text-sm">Customer is Required.</span>
                  )}
                  {/* <Select
            options={customerOptions.map((option: string) => ({
              label: option,
              value: option,
            }))}
            value={
              selectedCustomer
                ? { label: selectedCustomer, value: selectedCustomer }
                : null
            }
            onChange={handleCustomerChange}
            isDisabled={optimizationType === "Carrier" || !serviceProvider}
            isClearable
          /> */}
                </div>
                {/* <div className="">
                  <label htmlFor="comments" className="field-label">Comments</label>
                  <textarea
                    id="comments"
                    value={comments} // Use the comments state
                    onChange={(e) => handleCommentsChange(e.target.value)} // Update comments state
                    rows={2} // Adjust the number of rows as needed
                    className="w-full border border-gray-300 rounded-md p-2 focus:outline-none focus:border-[#0ea5e9] focus:shadow-[0_0_0_1px_#1640ff]"
                  />
                </div> */}
              </div>
              <div className="flex space-x-4 justify-center">
                <button className="cancel-btn" onClick={handleCancel}>
                  Cancel
                </button>
                <button className="save-btn" onClick={handleNext}>
                  Next
                </button>
              </div>
            </div>
            <Modal
              title="Optimization start"
              visible={startModalOpen}
              onCancel={handleCancel}
              footer={<div className="flex space-x-4 justify-center">
                <button className="cancel-btn" onClick={handleCancel}>
                  Cancel
                </button>
                <button
                  className={`${ratePlanCount === 0 && SIMCardsToOptimize === 0 ? "cancel-btn" : "save-btn "} disabled:cursor-not-allowed`}
                  onClick={handleStart}
                  disabled={ratePlanCount === 0 && SIMCardsToOptimize === 0}>
                  Start
                </button>
              </div>}
              centered
            >
              <div className="">
                <div className="justify-content">
                  <p className="mb-4">{`This will start a ${optimizationType} optimization for the ${formattedDate} billing period.`}</p>
                  <p className="mb-4">{`The billing period for ${serviceProvider} is from ${selectedBillPeriodStart} to ${selectedBillPeriodEnd}.`}</p>
                </div>
                <div className="text-left">
                  <p className="font-semibold">Total SIM Cards: <span className="font-normal">{`${totalSIMCards}`}</span></p>
                  <p className="font-semibold">SIM Cards to Optimize: <span className="font-normal">{`${SIMCardsToOptimize}`}</span></p>
                  {billPeriodStartError && (
                    <span className="text-red-500 text-sm">Error Starting Optimization: No eligible SIM Cards found for these options.</span>
                  )}
                  <p className="font-semibold">Rate Plan Count: <span className="font-normal">{`${ratePlanCount}`}</span></p>
                </div>
              </div>

            </Modal>
          </>
        )}

    </Modal>

  );
};

export default Optimize;
