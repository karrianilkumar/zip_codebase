// ProgressTracker.tsx
import { useState, useRef, useEffect } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";

export default function ProgressTracker({ totalAuditData, completedAuditData, fetchData }: { totalAuditData: any[], completedAuditData: any[] , fetchData: ()=>void }) {
    const [showTracker, setShowTracker] = useState(false);

    const sortedData = [...totalAuditData].sort((a, b) => a.id - b.id);
    const containerRef = useRef<HTMLDivElement>(null);

    const scroll = (direction: "left" | "right") => {
        if (containerRef.current) {
            const scrollAmount = direction === "left" ? -300 : 300;
            containerRef.current.scrollBy({ left: scrollAmount, behavior: "smooth" });
        }
    };
    useEffect(()=>{
        fetchData()
    },[showTracker])

    const getBgColor = (item: any) => {
        const id_ = item?.id;
        const action_ = item?.action;

        if (!id_ || !action_) return "bg-gray-500";

        // Find if this item exists in completedData
        const isCompleted = completedAuditData.some(
            (completedItem) =>
                completedItem.id === id_ 
        );

        if (isCompleted) return "bg-green-500";

        // Find the highest ID in completedData
        const maxCompletedId = Math.max(...completedAuditData.map((item) => item.id));

        if (id_ === maxCompletedId + 1) return "bg-yellow-500";

        return "bg-gray-500";
    };


    return (
        <div className="">
            {showTracker && (
                <>
                    <div className="audit-actions-main-container">
                        <div
                            ref={containerRef}
                            className="audit-actions-container"
                        >
                            {sortedData.map((item, index) => (
                                <div key={item.id} className="audit-action-box">
                                    <div className="audit-action">
                                        {item.action}
                                    </div>
                                    <div className="audit-vertical-bar-section">
                                        <div className="audit-vertical-bar"></div>
                                        <div className={`status-circle ${getBgColor(item)}`}></div>
                                    </div>
                                    {index !== sortedData.length - 1 && (
                                        <div className="audit-horizontal-bar"></div>
                                    )}
                                    {(index !== sortedData.length - 1 && index !== 0) && (
                                        <div className="audit-horizontal-dotted-line"></div>
                                    )}
                                    {index === sortedData.length - 1 && (
                                        <div className="last-audit-horizontal-dotted-line"></div>
                                    )}
                                    {index === 0 && (
                                        <div className="start-audit-horizontal-dotted-line"></div>
                                    )}

                                </div>
                            ))}

                        </div>
                        <div className="flex justify-between items-center">
                            <button onClick={() => scroll("left")} className="audit-navigation">
                                <ChevronLeft />
                            </button>
                            <button onClick={() => scroll("right")} className="audit-navigation">
                                <ChevronRight />
                            </button>
                        </div>
                    </div>
                </>
            )}
            <button
                onClick={() => setShowTracker(!showTracker)}
                className="save-btn relative left-[45%]"
            >
                Progress Tracking
            </button>


        </div>
    );
}
