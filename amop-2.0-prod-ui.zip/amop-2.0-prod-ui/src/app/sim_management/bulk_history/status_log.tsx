"use client";

import React, { lazy, useEffect, useState } from "react";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { Modal, Spin } from "antd";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";

interface StatusLogProps {
  row: any;
  isOpen: boolean;
  onRequestClose: () => void;
}

const TableComponent = lazy(
  () => import("@/app/components/TableComponent/page")
);

const StatusLog: React.FC<StatusLogProps> = ({
  row,
  isOpen,
  onRequestClose,
}) => {
  
  const { username, partner, role, settabledata, token,selectedDb,firstLastName,sessionId,setAdvancedStoredPagination,setCombineAdnvaceStoredpagination,setStoredPagination,metaData} = useAuth();
  const [loading, setLoading] = useState(false);
  const [pagination, setpagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const bulkRow :any= JSON.parse(localStorage.getItem('bulk_row') || '{}');

  console.log("row",row)
  console.log("bulkRow",bulkRow)
  type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = (headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];

    entries.sort((a, b) => a[1][1] - b[1][1]);

    return Object.fromEntries(entries) as HeaderMap;
  };
  useEffect(() => {
    setAdvancedStoredPagination(null)
    setStoredPagination(null)
    setCombineAdnvaceStoredpagination(null)
    // settabledata([])
    const fetchData = async () => {
      setLoading(true);
      try {
        const url =  ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName:firstLastName,
          path: "/get_bulk_change_logs",
          role_name: role,
          module_name: "Bulk Change History",
          mod_pages: {
            start: 0,
            end: 100,
          },
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
          access_token: token,
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          change_type:bulkRow?.row?.change_request_type,
          service_provider:bulkRow?.row?.service_provider,
          list_view_data_id:row?.id || "0",
          requested_id:bulkRow?.row?.bulk_change_id || bulkRow?.row?.id || "0",

        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);

        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching History. Please try again.",
            centered: true,
          });
        } else {
          const headersMap_ =
            parsedData?.header_map?.["bulkchange_logs"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          // console.log(sortedheaderMap,"sortedheaderMap")
          setHeaderMap(sortedheaderMap);
          const headers_ =
            Object.keys(sortedheaderMap).length > 0
              ? Object.keys(sortedheaderMap)
              : [];
          setHeaders(headers_);
          const tableData_ = parsedData?.get_bulk_change_logs     || [];
          console.log(tableData_,"Show table data")
          setTableData(tableData_);
        // console.log(tableData_,"tableData_")

          const pagination_ = parsedData?.pages || {};
          setpagination(pagination_);
          // console.log(pagination_,"pagination_")

        }
      } catch (error) {
        console.error("Error fetching data:", error);
        Modal.error({
          title: "Data Fetch Error",
          content:
            error instanceof Error
              ? error.message
              : "An unexpected error occurred while History. Please try again.",
          centered: true,
        });
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, [isOpen]);
 console.log(tableData[0]?.change_request)
  return (
    <Modal
      title="Status Log"
      visible={isOpen}
      onCancel={onRequestClose}
      footer={null}
      width={900}
      centered
    >
      <div className="p-4">
        <div className="flex justify-between mb-4">
          <div className="w-1/2 mr-2">
            <label className="block text-gray-700 text-sm font-bold mb-2 field-label">
              ICCID
            </label>
            <input
              type="text"
              value={row.iccid}
              readOnly
              className="w-full bg-gray-200 text-gray-700 border border-gray-400 rounded py-2 px-3"
            />
          </div>
          <div className="w-1/2 ml-2">
            <label className="block text-gray-700 text-sm font-bold mb-2 field-label">
              Status
            </label>
            <input
              type="text"
              value={row.status}
              readOnly
              className="w-full bg-gray-200 text-gray-700 border border-gray-400 rounded py-2 px-3"
            />
          </div>
        </div>

        <div className="flex justify-between mb-4">
          <div className="w-1/2 mr-2">
            <label className="block text-gray-700 text-sm font-bold mb-2 field-label">
              Request
            </label>
            <textarea
              value={tableData[0]?.change_request}
              readOnly
              className="w-full bg-gray-200 text-gray-700 border border-gray-400 rounded py-2 px-3 h-24 non-editable-input"
            />
          </div>
          <div className="w-1/2 ml-2">
            <label className="block text-gray-700 text-sm font-bold mb-2 field-label">
              Response
            </label>
            <textarea
              value={row.status_details}
              readOnly
              className="w-full bg-gray-200 text-gray-700 border border-gray-400 rounded py-2 px-3 h-24 non-editable-input"
            />
          </div>
        </div>

        <h3 className="text-xl font-bold text-gray-700 mb-4 header-toggle">
          Detailed Log Entries
        </h3>
        <div>
          <TableComponent
            headers={headers}
            headerMap={headerMap}
            initialData={tableData}
            searchQuery={""}
            visibleColumns={headers}
            itemsPerPage={100}
            popupHeading="Bulk Change History status log"
            // createModalData={createModalData}
            pagination={pagination}
            // advancedFilters={filteredData}
          />
        </div>
      </div>
    </Modal>
  );
};

export default StatusLog;
