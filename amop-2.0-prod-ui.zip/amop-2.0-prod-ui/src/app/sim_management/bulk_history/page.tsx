"use client";
import React, { useEffect, useState, lazy, Suspense, useRef } from "react";
import {
  PlusIcon,
  ArrowDownTrayIcon,
  ArrowLeftIcon,
} from "@heroicons/react/24/outline";
import { Button, Modal, Spin, DatePicker, notification } from "antd";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { useLogoStore } from "@/app/stores/logoStore";
import { getCurrentDateTime } from "@/app/components/header_constants";
import dayjs, { Dayjs } from "dayjs";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { useRouter } from "next/navigation";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { useCustomerRatePlanStore } from "@/app/stores/customerRateplanStore";
import ProgressTracker from "./progressTracker";

const { RangePicker } = DatePicker;
//Lazy loading components
const TableComponent = lazy(
  () => import("@/app/components/TableComponent/page")
);
const CreateModal = lazy(() => import("@/app/components/createPopup"));
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));
const TableSearch = lazy(() => import("@/app/components/entire_table_search"));
const AdvancedMultiFilter = lazy(
  () => import("@/app/components/advanced_search")
);

const StatusHistory: React.FC = () => {
  const [isCreateModalOpen, setCreateModalOpen] = useState(false);
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [newRowData, setNewRowData] = useState<any>({});
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, settabledata, token, tenantId, tenantName, selectedDb,metaData, advancedStoredpagination, storedpagination, firstLastName, sessionId, setAdvancedStoredPagination, setStoredPagination, setCombineAdnvaceStoredpagination, combineAdnvaceStoredpagination, dynamicColumns, setDynamicColumns } = useAuth();
  const [loading, setLoading] = useState(false);
  const title = useLogoStore((state) => state.title);
  const [pagination, setpagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [createModalData, setCreateModalData] = useState<any[]>([]);
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([
    null,
    null,
  ]);
  const [filteredData, setFilteredData] = useState([]);
  // const { bulkRow } = useFeatureStore();
  const [showAdvanced, setShowAdvanced] = useState(false);
  // const {showAdvanced, setShowAdvanced} = useCustomerRatePlanStore();
  //export functionality
  // const [exportLoading, setExportLoading] = useState(false);
  const { addExport, removeExport, exports } = exportLoadingStore();
  const exportKey = "Bulk Chnage Records";
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  const bulk_row: any = JSON.parse(localStorage.getItem('bulk_row') || '{}');
  const [bulkChangeRow, setBulkChangeRow] = useState<any>(bulk_row || {});
  const setTitle = useLogoStore((state) => state.setTitle);
  const [bulkChangeCounts, setBulkChangeCounts] = useState<any>({});
  const current_bulk_history_active_module = localStorage.getItem("current_bulk_history_active_module");

  //Audit States
  const [totalAuditData, setTotalAuditData] = useState<any[]>([]);
  const [completedAuditData, setCompletedAuditData] = useState<any[]>([]);


  useEffect(() => {
    console.log("bulk_row", bulk_row)
    console.log("bulkChangeRow", bulkChangeRow)

    if (current_bulk_history_active_module === "Bulk Change") {
      setTitle("Bulk Change")
    }
    if (current_bulk_history_active_module === "Central Bulk Change") {
      setTitle("Centralized View")
    }

  }, []);
  // const {features:moduleFeatures,setFeatures:setModuleFeatures} = useFeatureStore();

  const router = useRouter();

  const handleFilter = (advancedFilters: any) => {
    console.log(advancedFilters);
    setAdvancedFilters(advancedFilters)
  };

  const handleReset = (EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  };

  const handleBackNavigation = (EmptyFilters: any) => {
    if (current_bulk_history_active_module === "Bulk Change") {
      router.push(`/sim_management/bulk_change`);
    }
    if (current_bulk_history_active_module === "Central Bulk Change") {
      localStorage.setItem("activeTab", "detailedLogs");
      router.push(`/super_admin/centralized_view`);

    }
  };

  type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = (headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];

    entries.sort((a, b) => a[1][1] - b[1][1]);

    return Object.fromEntries(entries) as HeaderMap;
  };

  const getAuditTrailResponse = async (offset: number) => {
    // setLoading(true);
    let partner_name = partner
    let db_name_ = selectedDb
    if (current_bulk_history_active_module === "Central Bulk Change") {
      partner_name = bulkChangeRow?.row?.tenant || partner
      db_name_ = bulkChangeRow?.row?.db_name || selectedDb

    }
    const url = ENV_ROUTES.BULKCHANGE_PROCESSOR;

    const data = {
      tenant_name: partner_name || "default_value",
      username,
      firstLastName,
      path: "/get_bulk_change_audit_trial_logs",
      role_name: role,
      module_name: "Bulk Change History",
      access_token: token,
      offset: offset,
      db_name: db_name_,
      ... metaData,
      sessionID: sessionId,
      request_received_at: getCurrentDateTime(),
      Partner: partner_name,
      list_view_data_id: bulkChangeRow?.row?.bulk_change_id || bulkChangeRow?.row?.id || "0",
    };

    const response = await axios.post(url, { data });
    const parsedData = JSON.parse(response.data.body);

    if (!parsedData.flag) {
      throw new Error(parsedData.message || "Error fetching Audit Trails");
    }

    return {
      auditData: parsedData?.complete_audit_data_dict || [],
      recallFlag: parsedData?.recall_flag === true,
      completedData: parsedData?.bulk_change_audit_data || [],
    };
  };
  const pollAuditTrailsData = async () => {
    let allAuditData: any[] = [];
    let completed_audit_data: any[] = [];
    let recall = true;
    let offset = 0;

    while (recall) {
      try {
        const { auditData, recallFlag, completedData } = await getAuditTrailResponse(offset);
        allAuditData = [...allAuditData, ...auditData];
        completed_audit_data = [...completed_audit_data, ...completedData];


        recall = recallFlag;
        if (recall) {
          offset += 1; // Increment offset for next call
        }
      } catch (error) {
        // Modal.error({
        //   title: "Data Fetch Error",
        //   content:
        //     error instanceof Error
        //       ? error.message
        //       : "Unexpected error occurred during audit trail polling.",
        //   centered: true,
        // });
        break;
      }
    }

    return { total: allAuditData, completed: completed_audit_data };
  };

  const fetchAuditTrailsData = async () => {
    // setLoading(true);
    try {
      const data = await pollAuditTrailsData();
      const total_data = data?.total || []
      const completed_data = data?.completed || []

      setTotalAuditData(total_data);
      setCompletedAuditData(completed_data)
    } catch (e) {
      console.error("Audit trail fetch failed:", e);
    } finally {
      // setLoading(false);
    }
  };


  useEffect(() => {
    setDynamicColumns((prev: any) => ({ ...prev, "Bulk Change History": visibleColumns }))
  }, [visibleColumns]);

  const autoRefresh = async () => {
    let partner_name = partner
    let db_name_ = selectedDb
    if (current_bulk_history_active_module === "Central Bulk Change") {
      partner_name = bulkChangeRow?.row?.tenant || partner
      db_name_ = bulkChangeRow?.row?.db_name || selectedDb

    }
    try {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner_name || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_bulk_change_history",
        role_name: role,
        module_name: "Bulk Change History",
        mod_pages: {
          start: 0,
          end: 100,
        },
        access_token: token,
        db_name: db_name_,
        ... metaData,
        sessionID: sessionId,
        request_received_at: getCurrentDateTime(),
        Partner: partner_name,
        list_view_data_id: bulkChangeRow?.row?.bulk_change_id || bulkChangeRow?.row?.id || "0",
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        console.error("Error fetching auto refresh data:", parsedData.message ||
          "An error occurred while fetching History. Please try again.");
          return false
      } else {
        const tableData_ = parsedData?.status_history_data || [];
        const bulk_change_count = parsedData?.bulk_change_count || [];
        const firstRow = tableData_ && tableData_.length > 0 ? tableData_[0] : null
        console.log("firstRow", firstRow)
        const status_flag = firstRow && firstRow?.status ? (firstRow?.status).toLowerCase() : ""

        if(status_flag && status_flag!=="new" && status_flag!==""){
          setTableData(tableData_)
          setBulkChangeCounts(bulk_change_count)
          return true
        }
        else{
          return false
        }
      }
    } catch (error) {
      console.error("Error fetching auto refresh data:", error);
      return false
    } finally {
    }
  };

  useEffect(() => {
  const checkAutoRefresh = async () => {
    const result = await autoRefresh();
    if (!result) {
      setTimeout(checkAutoRefresh, 5000); // Try again after 5 seconds
    } else {
      console.log("Auto-refresh complete.");
    }
  };

  checkAutoRefresh(); // Start the loop

}, [bulkChangeRow]);

  useEffect(() => {
    settabledata([])
    setAdvancedStoredPagination(null);
    setStoredPagination(null);
    setCombineAdnvaceStoredpagination(null)
    const fetchData = async () => {
      setCombineAdnvaceStoredpagination(null)
      setLoading(true);
      let partner_name = partner
      let db_name_ = selectedDb
      if (current_bulk_history_active_module === "Central Bulk Change") {
        partner_name = bulkChangeRow?.row?.tenant || partner
        db_name_ = bulkChangeRow?.row?.db_name || selectedDb

      }
      try {
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
          tenant_name: partner_name || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/get_bulk_change_history",
          role_name: role,
          module_name: "Bulk Change History",
          mod_pages: {
            start: 0,
            end: 100,
          },
          access_token: token,
          db_name: db_name_,
          ... metaData,
          sessionID: sessionId,
          request_received_at: getCurrentDateTime(),
          Partner: partner_name,
          list_view_data_id: bulkChangeRow?.row?.bulk_change_id || bulkChangeRow?.row?.id || "0",
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);

        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching History. Please try again.",
            centered: true,
          });
        } else {
          const headersMap_ =
            parsedData?.header_map?.["Bulk Change History"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setHeaderMap(sortedheaderMap);
          const headers_ =
            Object.keys(sortedheaderMap).length > 0
              ? Object.keys(sortedheaderMap)
              : [];
          setHeaders(headers_);
          const dynamic_cols = dynamicColumns?.["Bulk Change History"] && dynamicColumns["Bulk Change History"].length > 0 ? dynamicColumns["Bulk Change History"] : headers_ || headers_
          setVisibleColumns(dynamic_cols)
          const tableData_ = parsedData?.status_history_data || [];
          setTableData(tableData_);
          const pagination_ = parsedData?.pages || {};
          setpagination(pagination_);
          const bulk_change_count = parsedData?.bulk_change_count || {};
          setBulkChangeCounts(bulk_change_count);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        Modal.error({
          title: "Data Fetch Error",
          content:
            error instanceof Error
              ? error.message
              : "An unexpected error occurred while History. Please try again.",
          centered: true,
        });
      } finally {
        setLoading(false);
      }
    };
    fetchData();
    fetchAuditTrailsData()
  }, [username, partner, role]);

  //From here
  const messageStyle = {
    fontSize: "14px",
    fontWeight: "bold",
    padding: "16px",
    // Add padding
  };

  const handleExportModalOpen = () => {
    setExportModalOpen(true);
  };

  const handleExportModalClose = () => {
    setExportModalOpen(false);
    console.log("Modal closed, resetting date range."); // Debug log
  };

  // const handleExport = async () => {
  //   const [startDate, endDate] = dateRange;

  //   const data = {
  //     path: "/export",
  //     username: username,
  //     // table: "",
  //     module_name: "bulkchange status history",
  //     request_received_at: getCurrentDateTime(),
  //     ids: bulkRow?.row?.id,
  //     Partner: partner,
  //     access_token: token,
  //     db_name:selectedDb,
  //   };

  //   try {
  //     const url =ENV_ROUTES.MODULE_MANAGEMENT;
  //     const response = await axios.post(
  //       url,
  //       { data: data },
  //       {
  //         headers: {
  //           "Content-Type": "application/json",
  //         },
  //       }
  //     );

  //     const resp = JSON.parse(response.data.body);
  //     const blob = resp.blob;
  //     console.log(resp);
  //     // Close the modal after exporting
  //     if (response.data.statusCode === 200) {
  //       if (resp.flag === true) {
  //         notification.success({
  //           message: "Success",
  //           description: "Successfully exported the record!",
  //           style: messageStyle,
  //           placement: "top",
  //         });

  //         // Trigger the download after a successful export
  //         downloadBlob(blob);
  //       } else {
  //         // Log and show error message
  //         console.log("Error message:", resp.message);
  //         Modal.error({
  //           title: "Export Error",
  //           content: resp.message,
  //           centered: true,
  //         });
  //       }
  //     } else {
  //       // Handle unexpected status codes
  //       console.log("Unexpected status code:", response.data.statusCode);
  //       Modal.error({
  //         title: "Export Error",
  //         content: resp.message,
  //         centered: true,
  //       });
  //     }

  //     handleExportModalClose();
  //   } catch (error) {
  //     // console.error("Error downloading the file:", error);
  //     // Modal.error({ title: 'Export Error', content: 'An error occurred while exporting the file. Please try again.' });
  //   }
  // };

  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }

  const ExportWithoutSearch = async () => {
    // setExportLoading(true)
    const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
      return new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          reject(new Error("Request timed out"));
        }, timeout);

        promise
          .then((res) => {
            clearTimeout(timer);
            resolve(res);
          })
          .catch((err) => {
            clearTimeout(timer);
            reject(err);
          });
      });
    };
    try {
      // setExportLoading(true)
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/export_to_s3_bucket",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Bulk Change History",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        start_date: getFirstDayOfCurrentMonth(),
        end_date: getLastDayOfCurrentMonth(),
        list_view_data_id: bulkChangeRow?.row?.bulk_change_id || bulkChangeRow?.row?.id,
      };
      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000); // Timeout of 10 seconds
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }

      // Wait for 20 seconds before polling
      await new Promise((resolve) => setTimeout(resolve, 20000));
      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      // setExportLoading(false);
    }
  }
  const pollExportStatus = async () => {
    // Polling for the second API
    const export_url = ENV_ROUTES.MODULE_MANAGEMENT;
    const export_data = {
      tenant_name: partner || "default_value",
      username,
      path: "/get_export_status",
      role_name: role,
      parent_module: "Sim Management",
      module_name: "Bulk Change History",
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
        ... metaData,
      sessionID: sessionId,
    };

    try {
      const export_response = await axios.post(export_url, { data: export_data });
      const export_parsedData = JSON.parse(export_response.data.body);

      if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
        const s3Url = export_parsedData?.export_status_data?.url || null;
        if (s3Url) {
          //  window.location.href = s3Url;
          //  notification.success({
          //    message: "Success",
          //    description: "Successfully exported the record!",
          //    style: messageStyle,
          //    placement: "top",
          //  });
          fetch(s3Url)
            .then(response => response.blob())
            .then(blob => {
              const url = window.URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'Status History.xlsx';
              a.click();
              a.remove();
              window.URL.revokeObjectURL(url);
              notification.success({
                message: "Success",
                description: "Successfully exported the record!",
                style: messageStyle,
                placement: "top",
              });
            })
            .catch((err) => {
              console.log("error", err)
              Modal.error({
                title: "Export Error",
                content: "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            });
        } else {
          Modal.error({
            title: "Export Error",
            content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
        return true; // Stop polling
      }

      if (export_parsedData?.export_status_data?.status_flag === "Failure") {
        Modal.error({
          title: "Export Error",
          content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
        return true; // Stop polling
      }
      if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
        Modal.info({
          title: "Export Error",
          content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
        return true; // Stop polling
      }

      return false; // Continue polling
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
      return true; // Stop polling
    }
  };

  const startPolling = async () => {
    let isPollingComplete = false;

    while (!isPollingComplete) {
      isPollingComplete = await pollExportStatus();
      if (!isPollingComplete) {
        await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
      }
    }
  };

  const handleExport = async (key: string, heading: string) => {
    try {
      addExport(key, heading);
      // setExportLoading(true)
      let parsedData
      let url
      let data: any
      let response
      const filters_ = { ...advancedMultiFilters }
      // filters_["flag"]="bulk_history"
      filters_["bulk_change_id"] = [bulkChangeRow?.row?.bulk_change_id || bulkChangeRow?.row?.id]
      if (combineAdnvaceStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
        ... metaData,
          sessionID: sessionId,
          index_name: "sim_management_bulk_change_request",
          module_name: "Bulk Change History",
          flag: "bulk_history"
        };
        console.log("combineAdnvaceStoredpagination", data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
      else if (advancedStoredpagination && !storedpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          module_name: "Bulk Change History",
          search: "advanced",
          filters: { ...filters_ },
          index_name: "sim_management_bulk_change_request",
          pages: {
            start: 0,
            end: 100
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
        ... metaData,
          sessionID: sessionId,
          tenant_id: tenantId,
          flag: "bulk_history"
          // }
        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

      }
      else if (storedpagination && !advancedStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          module_name: "Bulk Change History",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "sim_management_bulk_change_request",
          search: "whole",
          pages: {
            start: 0,
            end: 100,
          },
          flag: "bulk_history",
          bulk_change_id: bulkChangeRow?.row?.bulk_change_id || bulkChangeRow?.row?.id,
          partner: partner,
          username: username,
          db_name: selectedDb,
        ... metaData,
          sessionID: sessionId,
          tenant_id: tenantId,
        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
        console.log("serarch data", data)

      }
      else {
        // ExportWithoutSearch()
        await ExportWithoutSearch();
        return;
      }

      if (advancedStoredpagination || storedpagination || combineAdnvaceStoredpagination) {
        //   if (parsedData.flag === true) {
        //     const s3Url = parsedData?.download_url || null;
        //     if (s3Url) {
        //       window.location.href = s3Url;
        //       // setExportLoading(false)
        //       notification.success({
        //         message: 'Success',
        //         description: 'Successfully exported the record!',
        //         style: messageStyle,
        //         placement: 'top',
        //       });
        //     }
        //     else {
        //       // setExportLoading(false)
        //       Modal.error({
        //         title: "Export Error",
        //         content: parsedData.message || "An error occurred while exporting data. Please try again.",
        //         centered: true,
        //       });
        //     }

        if (parsedData.flag) {
          const s3Url = parsedData?.download_url || null;
          if (s3Url) {
            // window.location.href = s3Url;
            // notification.success({
            //   message: "Success",
            //   description: "Successfully Exported the Record!",
            //   style: messageStyle,
            //   placement: "top",
            // });
            fetch(s3Url)
              .then(response => response.blob())
              .then(blob => {
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'Status History.xlsx';
                a.click();
                a.remove();
                window.URL.revokeObjectURL(url);
                notification.success({
                  message: "Success",
                  description: "Successfully exported the record!",
                  style: messageStyle,
                  placement: "top",
                });
              })
              .catch((err) => {
                console.log("error", err)
                Modal.error({
                  title: "Export Error",
                  content: "An error occurred while exporting data. Please try again.",
                  centered: true,
                });
              });
          }

        } else {
          // setExportLoading(false)
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }

      } else {
        Modal.error({
          title: "Export Error",
          content: parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
      }

    } catch (error) {
      console.log("catch")
      await startPolling()
      // Modal.error({
      //   title: "Export Error",
      //   content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
      //   centered: true,
      // });
    } finally {
      // setExportLoading(false)
      removeExport(key);
    }
  };
  const downloadBlob = (base64Blob: string) => {
    // Decode the Base64 string
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    const blobObject = new Blob([byteArray], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blobObject);
    link.download = "Bulk Change Status History.xlsx"; // Set the file name to .xlsx
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  //Here
  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }
  //Added
  const disableFutureDates = (current: any) => {
    console.log("future dates:", current && current > dayjs().endOf("day"));
    return current && current > dayjs().endOf("day"); // Disable future dates
  };

  return (
    <Suspense
      fallback={
        <div className="flex justify-center items-center h-screen">
          <Spin size="large" />
        </div>
      }
    >
      <div className="relative justify-center items-center">


        {<ProgressTracker totalAuditData={totalAuditData} completedAuditData={completedAuditData} fetchData={fetchAuditTrailsData}/>}
        <div className="flex justify-start p-4">
          <button
            className="border-none flex mr-8"
            onClick={handleBackNavigation}
          >
            <ArrowLeftIcon className="h-5 w-5 text-black-500 mr-2" />
            <span>Back</span>
          </button>
          <span className="font-semibold text-gray-800  bulk-history-div">
            Bulk Change History
          </span>
        </div>
        <div className="pl-4 flex items-center justify-between mt-1">
          <div className="flex justify-start">
            <div className="flex flex-col justify-start">
              <div className="grid grid-cols-2 gap-8">
                <span className="text-gray-600 bulk-history-div">Status</span>
                <span className="font-semibold text-gray-800 bulk-history-div">
                  {bulkChangeCounts?.status ? bulkChangeCounts?.status : bulkChangeRow?.row?.status ?? "N/A"}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-8">
                <span className="text-gray-600 bulk-history-div">Processed Date</span>
                <span className="font-semibold text-gray-800 bulk-history-div">
                  {/* {bulkChangeRow?.row?.processed_date || "N/A"} */}
                  {bulkChangeCounts?.processed_date ? bulkChangeCounts?.processed_date : bulkChangeRow?.row?.processed_date ?? "N/A"}

                </span>
              </div>

              <div className="grid grid-cols-2 gap-8">
                <span className="text-gray-600 bulk-history-div">Uploaded</span>
                <span className="font-semibold text-gray-800 bulk-history-div">
                  {/* {bulkChangeRow?.row?.uploaded !== "None"
                    ? bulkChangeRow?.row?.uploaded
                    : 0 || 0} */}

                  {bulkChangeCounts?.uploaded ??
                    (bulkChangeRow?.row?.uploaded !== "None" ? bulkChangeRow?.row?.uploaded : "0")}

                </span>
              </div>

              <div className="grid grid-cols-2 gap-8">
                <span className="text-gray-600 bulk-history-div">Processed</span>
                <span className="font-semibold text-gray-800 bulk-history-div">
                  {/* {bulkChangeRow?.row?.success && bulkChangeRow?.row?.success !== "None" ? bulkChangeRow?.row?.success : "0"} */}
                   {bulkChangeCounts?.success ??
                    (bulkChangeRow?.row?.success !== "None" ? bulkChangeRow?.row?.success : "0")}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-8">
                <span className="text-gray-600 bulk-history-div">Errors</span>
                <span className="font-semibold text-gray-800 bulk-history-div">
                  {/* {bulkChangeRow?.row?.errors && bulkChangeRow?.row?.errors !== "None" ? bulkChangeRow?.row?.errors : 0} */}
                   {bulkChangeCounts?.errors ??
                    (bulkChangeRow?.row?.errors !== "None" ? bulkChangeRow?.row?.errors : "0")}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-8">
                <span className="text-gray-600 bulk-history-div">Bulk Change ID</span>
                <span className="font-semibold text-gray-800 bulk-history-div">
                  {bulkChangeRow?.row?.bulk_change_id ? bulkChangeRow.row.bulk_change_id !== "None" ? bulkChangeRow?.row?.bulk_change_id : 0 : bulkChangeRow?.row?.id || '0'}
                </span>
              </div>

            </div>
          </div>
        </div>
        <div className="p-4 flex  md:flex-row md:items-center md:justify-between mt-1 mb-4 space-y-6 md:space-y-0">
          {/* Search and Advanced Filter Container */}
          <div className="flex space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last">
            <TableSearch
              searchTerm={searchTerm}
              setSearchTerm={setSearchTerm}
              tableName={"sim_management_bulk_change_request"}
              headerMap={headerMap}
            />
            <AdvancedMultiFilter
              showAdvanced={showAdvanced}
              setShowAdvanced={setShowAdvanced}
              onFilter={handleFilter}
              onReset={handleReset}
              headers={headers}
              headerMap={headerMap}
              tableName={"sim_management_bulk_change_request"}
            />
          </div>
          {/* Export and ColumnFilter Container */}
          <div className="hidden md:flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2 md:order-none order-first">
            <button className="save-btn"
              onClick={() => {
                if (!exports.some((exportItem) => exportItem.popupHeading === "Bulk Change Records")) {
                  handleExport("BulkChangeRecords", "Bulk Change Records");
                }
              }} >
              <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
              <span>Export</span>
            </button>
            <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
            />
          </div>
        </div>
        {/* Sticky Footer for Small Screens */}
        <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
          <button className="save-btn"
            onClick={() => {
              if (!exports.some((exportItem) => exportItem.popupHeading === "Bulk Change Records")) {
                handleExport("BulkChangeRecords", "Bulk Change Records");
              }
            }} >
            <ArrowDownTrayIcon className="h-5 w-5 text-black-500" />
          </button>
          <ColumnFilter
            headers={headers}
            visibleColumns={visibleColumns}
            setVisibleColumns={setVisibleColumns}
            headerMap={headerMap}
          />
        </div>

        <div className=" mb-4 space-x-2"></div>
        <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
          <TableComponent
            headers={headers}
            headerMap={headerMap}
            initialData={tableData}
            searchQuery={searchTerm}
            visibleColumns={visibleColumns}
            itemsPerPage={100}
            popupHeading="Bulk Change History"
            createModalData={createModalData}
            pagination={pagination}
            advancedFilters={filteredData}
            height={showAdvanced ? 360 : 300}
          />
        </div>
        {/* {exportLoading && (
            <div className="export-processing-div">
              Export Processing...
            </div>
          )} */}
      </div>
    </Suspense>
  );
};

export default StatusHistory;
