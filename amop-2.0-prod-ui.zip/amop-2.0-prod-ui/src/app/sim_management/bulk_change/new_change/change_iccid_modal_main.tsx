"use client";

import { FC, forwardRef, useEffect, useImperativeHandle, useState } from "react";
import Select from "react-select";
import { Checkbox, Modal, Spin } from "antd";
import 'tailwindcss/tailwind.css';
import { useRouter } from "next/navigation";
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { useFeatureStore } from "../../inventory/featureStore";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { DropdownStyles } from "@/app/components/css/dropdown";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { useAllChangeTypesStore } from "@/app/stores/allChangeTypesStore";

interface ChangeICCIDContentProps {
  onContinue: (customerName: string) => void;
  onBack: () => void;
  dropdown: any;
  service_provider: any;
  change_type: any;
  onClose: () => void;
}

type SelectOption = { value: string; label: string };

export interface ChangeICCIDContentRef {
  runValidation: () => Promise<void> | void;
  runSubmit: () => Promise<void> | void;
  returnUpdate: () => React.ReactNode | Promise<React.ReactNode>;
}

const ChangeICCIDContent = forwardRef<ChangeICCIDContentRef, ChangeICCIDContentProps>(
  ({ onContinue, onBack, dropdown, service_provider, change_type, onClose }, ref) => {
  const [addCustomerRatePlan, setAddCustomerRatePlan] = useState(false);
  const [customerRatePlan, setCustomerRatePlan] = useState<string>('');
  const [customerPool, setCustomerPool] = useState<string>('');
  const [newICCID, setNewICCID] = useState("");
  const [newIMEI, setNewIMEI] = useState("");
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [ratePlanOptions, setRatePlanOptions] = useState<any>([]);
  const [customerPoolOptions, setCustomerPoolOptions] = useState<any>([]);
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const { setRowId, setBulkRow, bulkChangeLimit } = useFeatureStore();
  const { username, role, partner, token, selectedDb,metaData, firstLastName, sessionId, modulesVersionMap } = useAuth();
  const [currentDate, setCurrentDate] = useState('');
  const [ratePlanError, setRatePlanError] = useState<boolean>(false)
  const initial_version_flag = modulesVersionMap?.["Sim Management-Bulk Change"] || false
  const isVersionEnabled = localStorage.getItem("switch_user_2_0_bulk_change") === "True";
  const switch_user_2_0 = isVersionEnabled && initial_version_flag ? "True" : "False"
  const { addExport, removeExport, exports } = exportLoadingStore();
  const { isAllChangeType,setIsValidated,setValidationTrigger, setsuccessFullChangeTypes, activeChange, successFullChangeTypes, allChangeTypesDevices  } = useAllChangeTypesStore();
  const [devicesMap,setDevicesMap] = useState<any>({old:[],new:[]})
  const [saveChanges, setSaveChanges] = useState<boolean>(true);

  useEffect(() => {
    const customer_rate_plan_dropdown = dropdown?.customer_rate_plan_dropdown || [];
    setRatePlanOptions(customer_rate_plan_dropdown);
    const customer_rate_pool_dropdown = dropdown?.customer_rate_pool_dropdown || [];
    setCustomerPoolOptions(customer_rate_pool_dropdown);
  }, [dropdown]);
  useEffect(() => {
    // Get the current date in MM/DD/YYYY format
    const date = new Date();
    const formattedDate =
      `${(date.getMonth() + 1).toString().padStart(2, '0')}/${date.getDate().toString().padStart(2, '0')}/${date.getFullYear()}`;
    setCurrentDate(formattedDate);
  }, []);

  // const onsubmit = async (oldValues: string[], newValues: string[]) => {
  //   try {
  //     setLoading(true);
  //     const url = ENV_ROUTES.SIM_MANAGEMENT
  //     const data = {
  //       tenant_name: partner || "default_value",
  //       path: "/update_bulk_change_data",
  //       request_received_at: getCurrentDateTime(),
  //       access_token: token,
  //       db_name:selectedDb,
  //       sessionID: sessionId,
  //       service_provider: service_provider,
  //       change_type: change_type,
  //       created_by: firstLastName,
  //       changed_data: {
  //         UpdateStatus: null,
  //         IsIgnoreCurrentStatus: false,
  //         PostUpdateStatusId: 0,
  //         Request: {
  //           OldICCID: newICCID ? oldValues : null,
  //           NewICCID: newICCID ? newValues : null,
  //           OldIMEI: newIMEI ? oldValues : null,
  //           NewIMEI: newIMEI ? newValues : null,
  //           MSISDN: null,
  //           EID: null,
  //           IdentifierType: null,
  //           AddCustomerRatePlan: addCustomerRatePlan,
  //           CustomerRatePlan: customerRatePlan && customerRatePlan!=='No options'?customerRatePlan:null,
  //           CustomerRatePool: customerPool && customerRatePlan!=='No options'?customerRatePlan:null,
  //         },
  //         RevService: null,
  //         RevServiceProductCreateModel: null,
  //         IntegrationAuthenticationId: null,
  //       }
  //     };

  //     const response = await axios.post(url, { data });
  //     const parsedData = JSON.parse(response.data.body);
  //     if (parsedData.flag === false) {
  //       setLoading(false);
  //       Modal.error({
  //         title: 'Data Fetch Error',
  //         content: parsedData.message || 'An error occurred while fetching data. Please try again.',
  //         centered: true,
  //       });
  //     } else {
  //       const bulkrow_ = parsedData?.bulkchange_id || {};
  //       const bulkRow:any = { row: bulkrow_ };
  //       setBulkRow(bulkRow);
  //       localStorage.setItem('bulk_row',JSON.stringify(bulkRow || "{}"));
  //       if(bulkRow){
  //         router.push(`/sim_management/bulk_history`);
  //       }
  //       try {
  //         const url = ENV_ROUTES.SIM_MANAGEMENT
  //         const data = {
  //           tenant_name: partner || "default_value",
  //           username: username,
  //           firstLastName:firstLastName,
  //           path: "/run_db_script",
  //           role_name: role,
  //           module_name: "Bulk Change",
  //           mod_pages: {
  //             start: 0,
  //             end: 100,
  //           },
  //           access_token: token,
  //           db_name: selectedDb,
  //           sessionID: sessionId,
  //           request_received_at: getCurrentDateTime(),
  //           Partner: partner,
  //           bulkchange_id: parsedData?.bulkchange_id?.id,
  //           data: parsedData?.data,
  //           bulk_chnage_id_20: parsedData?.bulk_chnage_id_20

  //         };

  //         const response = await axios.post(url, { data });
  //         const responseData = JSON.parse(response.data.body);

  //         if (responseData.flag === false) {
  //           // Modal.error({
  //           //   title: "Data Fetch Error",
  //           //   content:
  //           //     responseData.message ||
  //           //     "An error occurred while fetching updating. Please try again.",
  //           //   centered: true,
  //           // });
  //         } else {
  //           console.log("success")
  //         }
  //       } catch (error) {
  //         console.error("Error fetching data:", error);
  //         // Modal.error({
  //         //   title: "Data Fetch Error",
  //         //   content:
  //         //     error instanceof Error
  //         //       ? error.message
  //         //       : "An unexpected error occurred while updating. Please try again.",
  //         //   centered: true,
  //         // });
  //       } finally {
  //       }

  //     }
  //   } catch (error) {
  //     Modal.error({
  //       title: 'Data Fetch Error',
  //       content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
  //       centered: true,
  //     });
  //   }
  //   finally{
  //     setLoading(false);
  //   }
  // };
  const callMismatchICCID = async (parsedData: any) => {
    const url = ENV_ROUTES.SIM_MANAGEMENT;
    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/bulk_change_validation_update",
      role_name: role,
      module_name: "Bulk Change",
      access_token: token,
      db_name: selectedDb,
                ...metaData,
      sessionID: sessionId,
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      bulkchange_id: parsedData?.bulkchange_id?.id,
      bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
    };

    const response = await axios.post(url, { data });
    const parsedResponse = JSON.parse(response.data.body);

    if (parsedResponse.flag === false) {
      console.error("Data Fetch Error mismatch ICCID: " + parsedResponse.message);
    } else {
      console.log("Success: Bulk update successful.");
    }
  }
  const call_2_0_submit = async (parsedData: any, payload: any, oldValues: string[]) => {
    try {
      const url = ENV_ROUTES.BULKCHANGE_PROCESSOR;
      const prevChangedData = payload?.changed_data || {}
      payload["msisdns"] = oldValues || []
      delete payload["changed_data"]

      const payloadData = {
        ...payload,
        path: "/bulk_change_processor",
        request_received_at: getCurrentDateTime(),
        bulk_change_id: parsedData?.bulk_chnage_id_20,
      }
      const data = { ...payloadData };
      const response = await axios.post(url, { data });
      const responseData = JSON.parse(response.data.body);
      if (responseData.flag === false) {
        console.log("Failure: 2.0 Bulk change update failed.");
      } else {
        console.log("Success: 2.0 Bulk change update successful.");
      }
    }
    catch (error) {
      console.error("Error running DB script:", error);
    } finally {
      setLoading(false);
    }
  }
  const call_2_0_sync = async (parsedData: any) => {
    try {
      const runDbScriptUrl = ENV_ROUTES.SIM_MANAGEMENT;
      const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
      const runDbScriptData = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/update_bulk_change_tables_10",
        role_name: role,
        module_name: "Bulk Change",
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        // service_provider_id: service_provider_id_,
        // bulkchange_id: parsedData?.bulkchange_id?.id,
        // data: parsedData?.data,
        data: {
          bulk_change_id: parsedData?.bulk_chnage_id_20,
        },
        is_update: false,
        // bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
      };

      const runDbScriptResponse = await axios.post(runDbScriptUrl, { data: runDbScriptData });
      const runDbScriptResponseData = JSON.parse(runDbScriptResponse.data.body);

      if (runDbScriptResponseData.flag === false) {
        console.error("Data Fetch Error: " + runDbScriptResponseData.message);
      } else {
        console.log("Success: Bulk update successful.");
      }
    }
    catch (error) {
      console.error("Error running DB script:", error);
    } finally {
      setLoading(false);
    }
  }

  const callRunDbScript = async (parsedData: any, oldValues: string[], newValues: string[]) => {
    try {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
      const runDbScriptData = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/run_db_script",
        role_name: role,
        module_name: "Bulk Change",
        mod_pages: { start: 0, end: 100 },
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        service_provider_id: service_provider_id_,
        bulkchange_id: parsedData?.bulkchange_id?.id,
        data: parsedData?.data,
        bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
        OldICCID: newICCID ? oldValues : null,
        NewICCID: newICCID ? newValues : null,
        OldIMEI: newIMEI ? oldValues : null,
        NewIMEI: newIMEI ? newValues : null,
      };

      const runDbScriptResponse = await axios.post(url, { data: runDbScriptData });
      const runDbScriptResponseData = JSON.parse(runDbScriptResponse.data.body);

      if (runDbScriptResponseData.flag === false) {
        console.error("Data Fetch Error: " + runDbScriptResponseData.message);
      } else {
        console.log("Success: Bulk update successful.");
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  }

  const bulkChangeInsert = async (payload: any, oldValues: string[]) => {
    let partner_name = partner
    let db_name_ = selectedDb
    try {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner_name || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_bulk_change_insertion",
        role_name: role,
        module_name: "Bulk Change History",
        service_provider_name: service_provider,
        change_type: change_type,
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
        request_received_at: getCurrentDateTime(),
        Partner: partner_name,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        console.error("Error fetching bulk change data:", parsedData.message ||
          "An error occurred while fetching bulk change data. Please try again.");
        return false
      } else {
        const statusFlag = parsedData?.bulk_change_data?.status || "";
        const response_data = parsedData?.bulk_change_data?.bulk_change_data || "{}";
        const parsedResp = JSON.parse(response_data)
        console.log("status_flag", statusFlag)
        const status_flag = statusFlag ? (statusFlag).toLowerCase() : ""

        if (status_flag && status_flag === "pending") {
          return false
        }
        else if (status_flag && status_flag === "success") {
          call_2_0_submit(parsedResp, payload, oldValues)
          call_2_0_sync(parsedResp)
          return true
        }
        else if (status_flag && status_flag === "error") {
          Modal.error({
            title: 'Submit Error',
            content: parsedData.message || 'An error occurred while submitting. Please try again.',
            centered: true,
          });
          return true
        }
        else {
          return false
        }
      }
    } catch (error) {
      console.error("Error fetching auto refresh data:", error);
      return false
    } finally {
    }
  };
  const bulkChangePolling = async (data: any, oldValues: string[]) => {
    const result = await bulkChangeInsert(data, oldValues);
    if (!result) {
      setTimeout(() => bulkChangePolling(data, oldValues), 5000); // Try again after 5 seconds
    } else {
      removeExport("bulkChangeInsert");
      console.log("Auto-refresh complete.");
    }
    // if (window.location.pathname.includes("/sim_management/bulk_change")) {
    //     window.location.reload();
    // }
  };

  const onsubmit = async (oldValues: string[], newValues: string[]) => {
    let data: any
    try {
      setLoading(true);
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const sp = service_provider.toLowerCase() || ""
      const serviceCharacteristic_ = [
        {
          "name": "reasonCode",
          "value": "CUST_OWN_EQU"
        },
        {
          "name": "serviceZipCode",
          "value": ""
        },
        {
          "name": "technologyType",
          "value": ""
        },
        {
          "name": "IMEI",
          "value": ""
        },
        {
          "name": "sim",
          "value": ""
        }
      ]
      const selectedRatePool = customerPool && customerPool !== 'No options' ? customerPool : null
      const ratePoolNameParts = (selectedRatePool || "").split(" -- ")
      const ratePlan_ = customerRatePlan && customerRatePlan !== 'No options' ? customerRatePlan : null
      const ratePlanNameParts = (ratePlan_ || "").split(" -- ")
      const RevService_details = {
        "Number": null,
        "ICCID": null,
        "CreateRevService": false,
        "IntegrationAuthenticationId": 0,
        "AddCarrierRatePlan": false,
        "CarrierRatePlan": null,
        "CommPlan": null,
        "UseAgentAccount": false,
        "JasperDeviceID": null,
        "SiteId": 0,
        "AddCustomerRatePlan": true,
        "CustomerRatePlan": ratePlanNameParts[0] || null,
        "CustomerRatePool": ratePoolNameParts[0] || selectedRatePool,
        "DeviceId": 0,
        "RevCustomerId": null,
        "ProviderId": null,
        "ServiceTypeId": 0,
        "Prorate": false,
        "Description": null,
        "ActivatedDate": null,
        "UsagePlanGroupId": null
      }
      data = {
        tenant_name: partner || "default_value",
        path: "/update_bulk_change_data",
        role_name: role,
        username: username,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
        service_provider: service_provider,
        change_type: change_type,
        created_by: firstLastName,
        changed_data: {
          UpdateStatus: null,
          IsIgnoreCurrentStatus: false,
          PostUpdateStatusId: 0,
          Request: {
            OldICCID: (newICCID || newIMEI) ? oldValues : null,
            NewICCID: newICCID ? newValues : null,
            // OldIMEI: newIMEI ? oldValues : null,
            OldIMEI: null,
            NewIMEI: newIMEI ? newValues : null,
            ...(!sp.includes("telegence") ? {
              MSISDN: null,
              EID: null,
              IdentifierType: 0,
              AddCustomerRatePlan: addCustomerRatePlan,
              CustomerRatePlan: customerRatePlan && customerRatePlan !== 'No options' ? customerRatePlan : null,
              CustomerRatePool: customerPool && customerRatePlan !== 'No options' ? customerRatePlan : null,
            } : {}),
            ...(sp.includes("telegence") ? { serviceCharacteristic: serviceCharacteristic_ } : {}),
          },
          ...((sp.includes("telegence") && addCustomerRatePlan) ? {
            RevService: RevService_details
          } : {
            RevService: null,
          }),
          RevServiceProductCreateModel: null,
          IntegrationAuthenticationId: null,
        }
      };

      // Send request to the first API
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        if (parsedData.error_type && parsedData.error_type == "Warning") {
          console.log("parsedData.error_type", parsedData.error_type)
          Modal.warning({
            title: 'Warning',
            content: parsedData.message || 'An error occurred while submitting data. Please try again.',
            centered: true,
          });
        }
        else {
          Modal.error({
            title: 'Data Fetch Error',
            content: parsedData.message || 'An error occurred while fetching data. Please try again.',
            centered: true,
          });
        }
        setLoading(false);
        return;

      }

      const bulkrow_ = parsedData?.bulkchange_id || {};
      const bulkRow: any = { row: bulkrow_ };
      setBulkRow(bulkRow);
      localStorage.setItem('bulk_row', JSON.stringify(bulkRow || "{}"));
      if (bulkRow) {
        if (!isAllChangeType) {
          router.push(`/sim_management/bulk_history`);
        }
      }

      // Prepare payload for the new API call
      // const newApiData = {
      //     tenant_name: partner || "default_value",
      //     username: username,
      //     firstLastName: firstLastName,
      //     path: "/inventory_iccidds_imeids", // New API path
      //     service_provider:service_provider,
      //     role_name: role,
      //     module_name: "Bulk Change",
      //     mod_pages: { start: 0, end: 100 },
      //     access_token: token,
      //     db_name: selectedDb,
      //     sessionID: sessionId,
      //     request_received_at: getCurrentDateTime(),
      //     Partner: partner
      // };

      // // Call the new API to get ICCIDs and IMEIs
      // const newApiResponse = await axios.post(ENV_ROUTES.SIM_MANAGEMENT, { data: newApiData });
      // const newApiParsedData = JSON.parse(newApiResponse.data.body); // Parse the new API response

      // const AlliccidList = newApiParsedData.iccid; // Adjust based on the actual structure of the response
      // const AllimeiList = newApiParsedData.imei; // Adjust based on the actual structure of the response

      // // Compare ICCID and IMEI values against the lists
      // const iccidMatch = oldValues.every((oldIccid: any) => AlliccidList.includes(oldIccid));
      // const imeiMatch = oldValues.every((oldImei: any) => AllimeiList.includes(oldImei));

      // const telegenceProvider=service_provider.toLowerCase().includes("telegence") || ""
      // if(telegenceProvider){
      //   if (!imeiMatch) {
      //     console.log("telegence")
      //     console.log("All ICCID and IMEI values do not match.");
      //     callMismatchICCID(parsedData)
      //     return; // Exit if ICCIDs or IMEIs do not match
      // }
      // }
      // else{
      //   if (!iccidMatch && !imeiMatch) {
      //     console.log("not telegence")
      //     console.log("All ICCID and IMEI values do not match.");
      //     callMismatchICCID(parsedData)
      //     return; // Exit if ICCIDs or IMEIs do not match
      // }
      // }

      // Proceed to call the run_db_script API
      const isVerizon = (service_provider.toLowerCase().includes("verizon") || service_provider.toLowerCase().includes("vzn") || service_provider.toLowerCase().includes("vzwcr") || service_provider.toLowerCase().includes("2215-so01"));
      const isTelegence = service_provider.toLowerCase().includes("telegence");
      if ((isTelegence || isVerizon) && switch_user_2_0 === "True") {
        call_2_0_submit(parsedData, data, oldValues)
        call_2_0_sync(parsedData)
      }
      else {
        await callRunDbScript(parsedData, oldValues, newValues);
      }

    } catch (error) {
      const isVerizon = (service_provider.toLowerCase().includes("verizon") || service_provider.toLowerCase().includes("vzn") || service_provider.toLowerCase().includes("vzwcr") || service_provider.toLowerCase().includes("2215-so01"));
      const isTelegence = service_provider.toLowerCase().includes("telegence");
      if ((isTelegence || isVerizon) && switch_user_2_0 === "True") {
        onClose()
        setLoading(false)
        addExport("bulkChangeInsert", "Bulk Change Submission");
        bulkChangePolling(data, oldValues)
      }
      else {
        Modal.error({
          title: 'Submit Error',
          content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting. Please try again.',
          centered: true,
        });
      }

    } finally {
      setLoading(false);
    }
  };
    const handleSubmit = async () => {
      let valid = false
      if (addCustomerRatePlan && !customerRatePlan) {
        setRatePlanError(true)
        valid = false
      }
      else {
        setRatePlanError(false)
        valid = true
      }
      if (!newICCID && !newIMEI) {
        valid = false
        setErrorMessage("Please fill new ICCID field or new IMEI field.");
      } else {
        valid = true
        setErrorMessage(null);
        // onContinue(newICCID);
      }

      if (valid) {
        const oldValues: string[] = [];
        const newValues: string[] = [];
        const devices = newICCID || newIMEI;

        let hasExtraValues = false;

        const devicesList = devices
          .split("\n")
          .map(line => {
            const values = line
              .split(",")
              .map(val => val.trim())
              .filter(Boolean);

            if (values.length > 2) {
              hasExtraValues = true;
            }

            return values.slice(0, 2);
          })
          .flat();

        console.log("devicesList:", devicesList);
        console.log("Contains extra values in any line:", hasExtraValues);
        devices.split("\n").forEach((line) => {
          const [oldValue, newValue] = line.split(",").map((val) => val.trim());
          if (oldValue && newValue) {
            oldValues.push(oldValue);
            newValues.push(newValue);
          }
        });

        console.log("oldValues", oldValues)
        console.log("newValues", newValues)
        console.log("devices", devices)
        setDevicesMap({old:oldValues,new:newValues})

        if ((devicesList.length > 0 && (devicesList.length) % 2 !== 0 || hasExtraValues)) {
          setErrorMessage("Please fill in one Subscriber Number per line with New ICCID/IMEI separated by a comma.")
          return
        }

        let errorMessages: Set<string> = new Set();
        let hasError = false;

        // Validate Subscriber Numbers
        for (const subscriber of oldValues) {
          const value = subscriber.trim();

          if (value.length === 0) {
            errorMessages.add("Subscriber Number must not be empty.");
            hasError = true;
          } else if (!/^\d+$/.test(value)) {
            errorMessages.add("Please enter numbers only for Subscriber Number. Letters or special characters are not allowed");
            hasError = true;
          } else if (value.length < 10 || value.length > 18) {
            errorMessages.add("Subscriber Number must be between 10 and 18 digits long.");
            hasError = true;
          }
        }

        // Validate ICCID/IMEI values
        for (const iccidOrImei of newValues) {
          const value = iccidOrImei.trim();

          if (value.length === 0) {
            errorMessages.add("ICCID/IMEI must not be empty.");
            hasError = true;
          } else if (!/^\d+$/.test(value)) {
            errorMessages.add("Please enter numbers only for ICCID/IMEI. Letters or special characters are not allowed.");
            hasError = true;
          } else if (value.length < 14 || value.length > 22) {
            errorMessages.add("ICCID/IMEI must be between 14 and 22 digits long.");
            hasError = true;
          }
        }
        if (oldValues.length > bulkChangeLimit || newValues.length > bulkChangeLimit) {
          errorMessages.add(`This request exceeds the allowed record limit  of ${bulkChangeLimit} and cannot be processed`);
          console.log("Limit Exceeded");
          hasError = true;
        }

        // Final check
        if (hasError) {
          setErrorMessage(Array.from(errorMessages).join(" "));
          if (isAllChangeType) {
            setsuccessFullChangeTypes(
              successFullChangeTypes.filter((c: any) => c !== activeChange)
            );
            setIsValidated(false)
            setValidationTrigger();
          }

        } else {
          setErrorMessage(null);
          if (!isAllChangeType) {
          onsubmit(oldValues, newValues);
      }
          else {
            if(saveChanges){
              setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
            }
            setIsValidated(true)
            setValidationTrigger();
          }
        }
      }
      else {
        if(!addCustomerRatePlan && !newICCID && !newIMEI){
          setErrorMessage("")
          setsuccessFullChangeTypes(
            successFullChangeTypes.filter((c: any) => c !== activeChange)
          );
          setIsValidated(true)
          setValidationTrigger();
        }
        else{
          setsuccessFullChangeTypes(
            successFullChangeTypes.filter((c: any) => c !== activeChange)
          );
          setIsValidated(false)
          setValidationTrigger();
        }
        
      }
    }

  const handleSelectRatePlan = (selectedOption: any) => {
    if (selectedOption) {
      const value = selectedOption?.value;
      setCustomerRatePlan(value);
    }
  };

  const handleSelectCustomerPool = (selectedOption: any) => {
    if (selectedOption) {
      const value = selectedOption?.value;
      setCustomerPool(value);
    }
  };

    const returnUpdatedValue = () => {
      const oldValues: string[] = devicesMap?.old || [];
      const newValues: string[] = devicesMap?.new || [];
      return (
        <div className="flex flex-col gap-2">
          <div className="flex grid grid-cols-2 ">
            <span className="font-semibold">{newICCID ? "New ICCIDs:" : "New IMEIs"}</span>
            <span>{newValues.join(",")}</span>
          </div>
        </div>
      )
    }

  useImperativeHandle(ref, () => ({
    runValidation: handleSubmit,
    runSubmit: () => { onsubmit(devicesMap?.old || [], devicesMap?.new || []) },
    returnUpdate: returnUpdatedValue
  }));

  if (loading) {
    return (
      <div className="flex justify-center items-center h-[400px]">
        <Spin size="large" />
      </div>
    );
  }

  return (
    <div className="space-y-3 h-auto">
      {/* Warning Message */}
      <div className="bg-yellow-200 text-yellow-800 p-3 rounded-md text-center">
        IMEI and ICCID changes should be submitted separately. Only one type of swap can be performed per bulk action.
      </div>

      {isAllChangeType && (
        <div className="flex justify-end px-4">
          <span className="mr-2 font-semibold">Save Changes</span>
          <Checkbox
            checked={saveChanges}
            onChange={(e) => {
              if (!e.target.checked) {
                setsuccessFullChangeTypes(
                  successFullChangeTypes.filter((c: any) => c !== activeChange)
                );
              }
              setSaveChanges(e.target.checked)
            }}
            className="custom-checkbox"
          >

          </Checkbox>
        </div>
      )}

      {/* Effective Date (Non-editable) */}
      <div className="flex items-center space-x-4">
        <label className="w-1/4 font-medium">Effective Date<span className='text-red-500'>*</span></label>
        <input
          type="text"
          value={currentDate}
          className="w-3/4 non-editable-input cursor-not-allowed"
          readOnly
        />
      </div>

      {/* Add Customer Rate Plan? Checkbox */}
      <div className="flex items-center space-x-4">
        <label className="w-1/4 font-medium">Add Customer Rate Plan</label>
        <Checkbox
          checked={addCustomerRatePlan}
          onChange={(e) => { setAddCustomerRatePlan(e.target.checked), setCustomerRatePlan("") }}
          className="w-6 h-6 accent-blue-500"
        />
      </div>

      {/* Customer Rate Plan Dropdown */}
      {addCustomerRatePlan && (
        <div className="space-y-4">
          <div className="flex items-center space-x-4">
            <label className="w-1/4 font-medium">Customer Rate Plan<span className='text-red-500'>*</span></label>
            <Select
              placeholder="Select Customer Rate Plan"
              options={ratePlanOptions.length > 0 ? ratePlanOptions.map((option: string) => ({
                label: option,
                value: option,
              })) : [{ value: 'No options', label: 'No options' }]}
              value={customerRatePlan === 'No options' ? null : { label: customerRatePlan, value: customerRatePlan }}
              onChange={handleSelectRatePlan}
              className="w-3/4"
              styles={DropdownStyles}
            />
          </div>

          <div className="flex items-center space-x-4">
            <label className="w-1/4 font-medium">Customer Pool</label>
            <Select
              id="customerRatePool"
              placeholder="Select Customer Rate Pool"
              options={customerPoolOptions.length > 0 ? customerPoolOptions.map((option: string) => ({
                label: option,
                value: option,
              })) : [{ value: 'No options', label: 'No options' }]}
              value={customerPool === 'No options' ? null : { label: customerPool, value: customerPool }}
              onChange={handleSelectCustomerPool}
              className="w-3/4"
              styles={DropdownStyles}
            />
          </div>
        </div>
      )}

      {/* New ICCID Textarea */}
      <div className="flex items-center space-x-4">
        <label className="w-1/4 font-medium">New ICCID<span className='text-red-500'>*</span></label>
        <textarea
          value={newICCID}
          onChange={(e) => {
            setNewICCID(e.target.value);
            if (e.target.value) setNewIMEI(""); // Clear IMEI if ICCID is being entered
          }}
          className="w-3/4 border border-gray-300 rounded-md p-2 h-24"
          placeholder={`Enter one Subscriber Number per line with New ICCID separated by a comma"`}
          disabled={!!newIMEI} // Disable if New IMEI has a value
        />
      </div>

      {/* New IMEI Textarea */}
      <div className="flex items-center space-x-4">
        <label className="w-1/4 font-medium">New IMEI<span className='text-red-500'>*</span></label>
        <textarea
          value={newIMEI}
          onChange={(e) => {
            setNewIMEI(e.target.value);
            if (e.target.value) setNewICCID(""); // Clear ICCID if IMEI is being entered
          }}
          className="w-3/4 border border-gray-300 rounded-md p-2 h-24"
          placeholder={`Enter one Subscriber Number per line with New IMEI separated by a comma`}
          disabled={!!newICCID} // Disable if New ICCID has a value
        />
      </div>

      {/* Error Message */}
      {errorMessage && (
        <div className="text-red-500">{errorMessage}</div>
      )}
      {ratePlanError &&
        <span className="text-red-500">Customer Rate Plan is required</span>}

      {/* Submit Button */}
      {!isAllChangeType && (
        <div className="flex justify-center space-x-4">

        <button
          onClick={onBack}
          className="cancel-btn"
        >
          Back
        </button>
        <button
          onClick={handleSubmit}
          className="save-btn"
        >
          Submit
        </button>
      </div>
      )}
      
    </div>
  );
}
)

export default ChangeICCIDContent;
