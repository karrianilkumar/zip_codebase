"use client";

import { FC, forwardRef, useEffect, useImperativeHandle, useState } from "react";
import { Input, Button, Modal, Spin, Checkbox } from "antd";
import { ArrowLeftIcon } from "@heroicons/react/24/outline";
import { useAuth } from "@/app/components/auth_context";
import { useRouter } from 'next/navigation';
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { TargetStatus } from "@/components/activate-iccid/target-status";
import { json } from "stream/consumers";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import UploadComponent from "./upload_component";
import { useAllChangeTypesStore } from "@/app/stores/allChangeTypesStore";

interface SelectDevicesProps {
  onContinue: () => void;
  onBack: () => void;
  service_provider: any;
  change_type: any;
  changed_data?: any;
  isNextScreen?: boolean;
  onClose?: () => void;
  setSelectedCustomers?: (value: any[]) => void;
  onCancel: () => void;
}

export interface SelectContentRef {
  runSubmit: () => Promise<void> | void;
}

const SelectDevices = forwardRef<SelectContentRef, SelectDevicesProps>(
  ({ onContinue, onBack, service_provider, change_type, changed_data, isNextScreen, onClose, setSelectedCustomers, onCancel }, ref) => {
  const [iccid, setIccid] = useState("");
  const [newIMEI, setNewIMEI] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [processImmediately, setProcessImmediately] = useState(false); // State for checkbox
  const { username, role, partner, token, selectedDb, metaData, firstLastName, sessionId, modulesVersionMap } = useAuth();
  const router = useRouter();
  const { setRowId, setBulkRow, setsetActivationPayload, bulkChangeLimit, simIdentifierMap } = useFeatureStore();
  const [iccidError, setIccidError] = useState("");
  const [imeiError, setImeiError] = useState("");
  const [isIMEI, setIsIMEI] = useState<boolean>(false)
  const [subscriberNumber, setSubscriberNumber] = useState<string>("");
  const initial_version_flag = modulesVersionMap?.["Sim Management-Bulk Change"] || false
  const isVersionEnabled = localStorage.getItem("switch_user_2_0_bulk_change") === "True";
  const switch_user_2_0 = isVersionEnabled && initial_version_flag ? "True" : "False"
  const { addExport, removeExport, exports } = exportLoadingStore();
  const { isAllChangeType, allChangeTypesDevices  } = useAllChangeTypesStore();

  const is_parent_provider_exists = false
  const providerName = (service_provider).toLowerCase()
  // const onsubmit = async (payload: any) => {
  //   try {
  //     const changedData = changed_data ? changed_data : {};
  //     setLoading(true);


  //     // Prepare payload
  //     const url = ENV_ROUTES.SIM_MANAGEMENT;
  //     const data = {
  //       tenant_name: partner || "default_value",
  //       path: "/update_bulk_change_data",
  //       request_received_at: getCurrentDateTime(),
  //       access_token: token,
  //       db_name: selectedDb,
  //       sessionID: sessionId,
  //       service_provider: service_provider,
  //       change_type: change_type,
  //       created_by: firstLastName,
  //       iccids: payload.iccids,
  //       imeids: payload.imeis,
  //       changed_data: {
  //         OverrideValidation: false,
  //         Devices: payload.iccids,
  //         ...changedData
  //       }
  //     };

  //     // Send request to backend
  //     const response = await axios.post(url, { data });
  //     const parsedData = JSON.parse(response.data.body);

  //     if (parsedData.flag === false) {
  //       setLoading(false);
  //       Modal.error({
  //         title: 'Submit Error',
  //         content: parsedData.message || 'An error occurred while submitting. Please try again.',
  //         centered: true,
  //       });
  //     } else {
  //       const bulkrow_ = parsedData?.bulkchange_id || {};
  //       const bulkRow: any = { row: bulkrow_ };
  //       setBulkRow(bulkRow);
  //       localStorage.setItem('bulk_row', JSON.stringify(bulkRow || "{}"));
  //       if (bulkRow) {
  //         router.push(`/sim_management/bulk_history`);
  //       }

  //       const AlliccidList = parsedData.iccid;
  //       const AllimeiList = parsedData.imei;

  //       // Compare ICCID and IMEI values against the lists
  //       const iccidMatch = payload.iccids.every((iccid: any) => AlliccidList.includes(iccid));
  //       const imeiMatch = payload.imeis.every((imei: any) => AllimeiList.includes(imei));

  //       if (
  //         (service_provider === "Verizon - ThingSpace IoT" && (changed_data.UpdateStatus === "Active" || changed_data.UpdateStatus === "Pending activation")) ||
  //         (service_provider === "Verizon - ThingSpace PN" && (changed_data.UpdateStatus === "Active" || changed_data.UpdateStatus === "Pending activation")) ||
  //         service_provider.includes("AT&T - Telegence")
  //       ) {
  //         if (!iccidMatch || !imeiMatch) {
  //           console.log("All ICCID and IMEI values do not match.");
  //         } else {
  //           try {
  //             const url = ENV_ROUTES.SIM_MANAGEMENT;
  //             const data = {
  //               tenant_name: partner || "default_value",
  //               username: username,
  //               firstLastName: firstLastName,
  //               path: "/run_db_script",
  //               role_name: role,
  //               module_name: "Bulk Change",
  //               mod_pages: { start: 0, end: 100 },
  //               access_token: token,
  //               db_name: selectedDb,
  //               sessionID: sessionId,
  //               request_received_at: getCurrentDateTime(),
  //               Partner: partner,
  //               bulkchange_id: parsedData?.bulkchange_id?.id,
  //               data: parsedData?.data,
  //               bulk_chnage_id_20: parsedData?.bulk_chnage_id_20
  //             };

  //             const response = await axios.post(url, { data });
  //             const responseData = JSON.parse(response.data.body);

  //             if (responseData.flag === false) {
  //               console.error("Data Fetch Error: " + responseData.message);
  //             } else {
  //               console.log("Success: Bulk update successful.");
  //             }
  //           } catch (error) {
  //             console.error("Error fetching data:", error);
  //           }
  //         }
  //       } else {
  //         if (!iccidMatch) {
  //           console.log("All ICCID values do not match.");
  //         } else {
  //           console.log("All ICCID values match.");
  //           try {
  //             const url = ENV_ROUTES.SIM_MANAGEMENT;
  //             const data = {
  //               tenant_name: partner || "default_value",
  //               username: username,
  //               firstLastName: firstLastName,
  //               path: "/run_db_script",
  //               role_name: role,
  //               module_name: "Bulk Change",
  //               mod_pages: { start: 0, end: 100 },
  //               access_token: token,
  //               db_name: selectedDb,
  //               sessionID: sessionId,
  //               request_received_at: getCurrentDateTime(),
  //               Partner: partner,
  //               bulkchange_id: parsedData?.bulkchange_id?.id,
  //               data: parsedData?.data,
  //               bulk_chnage_id_20: parsedData?.bulk_chnage_id_20
  //             };

  //             const response = await axios.post(url, { data });
  //             const responseData = JSON.parse(response.data.body);

  //             if (responseData.flag === false) {
  //               console.error("Data Fetch Error: " + responseData.message);
  //             } else {
  //               console.log("Success: Bulk update successful.");
  //             }
  //           } catch (error) {
  //             console.error("Error fetching data:", error);
  //           }
  //         }
  //       }
  //     }
  //   } catch (error) {
  //     Modal.error({
  //       title: 'Submit Error',
  //       content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting. Please try again.',
  //       centered: true,
  //     });
  //   } finally {
  //     setLoading(false);
  //   }
  // };

  const callKoreSync = async (data: any) => {
    const koreUrl = ENV_ROUTES.SM_BULK_CHANGE;
    let koreData = { ...data }
    koreData["path"] = "/start_sync"

    try {
      const koreResponse = await axios.post(koreUrl, { data: koreData });
      const koreResponseData = JSON.parse(koreResponse.data.body);

      if (koreResponseData.flag === false) {
        console.log("Data Fetch Error: " + koreResponseData.message);
      } else {
        console.log("Success: Bulk update successful.");
      }

    }
    catch {
      console.log("error in Start Sync");
    }
  }

  const callRestoreCancelledSync = async (payload: any, parsedData: any) => {
    const url = ENV_ROUTES.SM_BULK_CHANGE;
    const data_ = {
      tenant_name: partner || "default_value",
      path: "/telegence_bc_update_device_status_restore_cancelled",
      role_name: role,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
                ...metaData,
      sessionID: sessionId,
      service_provider: service_provider,
      change_type: change_type,
      created_by: firstLastName,
      msisdns: payload.iccids,
      bulk_change_id: parsedData?.bulk_chnage_id_20,
      tenant_id: parsedData?.tenant_id,
    };


    try {
      const koreResponse = await axios.post(url, { data: data_ });
      const koreResponseData = JSON.parse(koreResponse.data.body);

      if (koreResponseData.flag === false) {
        console.log("Data Fetch Error: " + koreResponseData.message);
      } else {
        console.log("Success: Bulk update successful.");
      }

    }
    catch {
      console.log("error in Start Sync");
    }
  }

  const callMismatchICCID = async (parsedData: any) => {
    const url = ENV_ROUTES.SIM_MANAGEMENT;
    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/bulk_change_validation_update",
      role_name: role,
      module_name: "Bulk Change",
      access_token: token,
      db_name: selectedDb,
                ...metaData,
      sessionID: sessionId,
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      bulkchange_id: parsedData?.bulkchange_id?.id,
      bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
    };

    const response = await axios.post(url, { data });
    const parsedResponse = JSON.parse(response.data.body);

    if (parsedResponse.flag === false) {
      console.error("Data Fetch Error mismatch ICCID: " + parsedResponse.message);
    } else {
      console.log("Success: Bulk update successful.");
    }
  }

  const bulkChangeInsert = async (payload: any) => {
    let partner_name = partner
    let db_name_ = selectedDb
    try {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner_name || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_bulk_change_insertion",
        role_name: role,
        module_name: "Bulk Change History",
        service_provider_name: service_provider,
        change_type: change_type,
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
        request_received_at: getCurrentDateTime(),
        Partner: partner_name,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        console.error("Error fetching bulk change data:", parsedData.message ||
          "An error occurred while fetching bulk change data. Please try again.");
        return false
      } else {
        const statusFlag = parsedData?.bulk_change_data?.status || "";
        const response_data = parsedData?.bulk_change_data?.bulk_change_data || "{}";
        const parsedResp = JSON.parse(response_data)
        console.log("status_flag", statusFlag)
        const status_flag = statusFlag ? (statusFlag).toLowerCase() : ""

        if (status_flag && status_flag === "pending") {
          return false
        }
        else if (status_flag && status_flag === "success") {
          call_2_0_submit(parsedResp, payload)
          call_2_0_sync(parsedResp)
          return true
        }
        else if (status_flag && status_flag === "error") {
          Modal.error({
            title: 'Submit Error',
            content: parsedData.message || 'An error occurred while submitting. Please try again.',
            centered: true,
          });
          return true
        }
        else {
          return false
        }
      }
    } catch (error) {
      console.error("Error fetching auto refresh data:", error);
      return false
    } finally {
    }
  };
  const bulkChangePolling = async (data: any) => {
    const result = await bulkChangeInsert(data);
    if (!result) {
      setTimeout(() => bulkChangePolling(data), 5000); // Try again after 5 seconds
    } else {
      removeExport("bulkChangeInsert");
      console.log("Auto-refresh complete.");
    }
    // if (window.location.pathname.includes("/sim_management/bulk_change")) {
    //     window.location.reload();
    // }
  };

  const onsubmit = async (payload: any) => {
    let data: any
    try {
      const changedData = changed_data ? { ...changed_data } : {};
      const overwrite_flag = changed_data?.overwrite || false
      if (change_type.toLowerCase() === "update device status") {
        delete changedData["effectiveDate"]
        delete changedData["sim_status"]
        delete changedData["device_status_id"]
      }
      if (change_type.toLowerCase() === "update features") {
        delete changedData["overwrite"]
      }
      setLoading(true);

      // Prepare payload for the first API
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      data = {
        tenant_name: partner || "default_value",
        path: "/update_bulk_change_data",
        role_name: role,
        username: username,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
        service_provider: service_provider,
        change_type: change_type,
        created_by: firstLastName,
        ... ((change_type === "Update Features")
          ? { overwrite: overwrite_flag }
          : {}),
        ... ((change_type === "Update PPU address" || change_type === "Update Features" || change_type === "Refresh A Line")
          ? { iccids: payload.iccids }
          : {
            iccids: payload.iccids,
            imeids: payload.imeis
          }),

        ... ((change_type === "Update PPU address" || change_type === "Update Features" || change_type === "Refresh A Line")
          ? { changed_data: { ...changedData } }
          : {
            changed_data: {
              OverrideValidation: false,
              Devices: payload.iccids,
              ...changedData
            }
          }),
      };

      // Send request to the first API
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        setLoading(false);
        Modal.error({
          title: 'Submit Error',
          content: parsedData.message || 'An error occurred while submitting. Please try again.',
          centered: true,
        });
        return;
      }

      const bulkrow_ = parsedData?.bulkchange_id || {};
      const bulkRow: any = { row: bulkrow_ };
      setBulkRow(bulkRow);
      localStorage.setItem('bulk_row', JSON.stringify(bulkRow || "{}"));
      if (bulkRow) {
        if (!isAllChangeType) {
          router.push(`/sim_management/bulk_history`);
        }
      }

      let type = change_type.toLowerCase()

      if ((service_provider.toLowerCase() === "kore" || (service_provider.toLowerCase() === "webbing" && type !== "change customer rate plan" ))  && switch_user_2_0 !== "True") {
        let path
        if (service_provider.toLowerCase() === "kore") {
          path = type && type === "update device status" ? "/update_device_status" : "/update_customer_rate_plan";
        }
        else {
          path = type && type === "update device status" ? "/webbing_update_device_status" : "/update_customer_rate_plan";
        }

        // Prepare payload for the first API
        const url = ENV_ROUTES.SM_BULK_CHANGE;
        let data: any;
        if (type && type === "update device status") {
          data = {
            tenant_name: partner || "default_value",
            path: path,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            service_provider: service_provider,
            change_type: change_type,
            bulk_change_id: parsedData?.bulkchange_id?.id,
            data: parsedData?.data,
            created_by: firstLastName,
            iccids: payload.iccids,
            imeids: payload.imeis,
            updated_status: changedData?.UpdateStatus || null,
            changed_data: {
              OverrideValidation: false,
              Devices: payload.iccids,
              ...changedData
            }
          };
        }
        else {
          let changed_customer_rate_plan_data = { ...changedData }
          // changed_customer_rate_plan_data["CustomerRatePlanUpdate"]["CustomerRatePlanId"] = changed_customer_rate_plan_data["CustomerRatePlanUpdate"]["CustomerRatePlanId"] && changed_customer_rate_plan_data["CustomerRatePlanUpdate"]["CustomerRatePlanId"] !== -1 ? changed_customer_rate_plan_data["CustomerRatePlanUpdate"]["CustomerRatePlanId"] : ""
          // changed_customer_rate_plan_data["CustomerRatePlanUpdate"]["CustomerRatePoolId"] = changed_customer_rate_plan_data["CustomerRatePlanUpdate"]["CustomerRatePoolId"] && changed_customer_rate_plan_data["CustomerRatePlanUpdate"]["CustomerRatePoolId"] !== -1 ? changed_customer_rate_plan_data["CustomerRatePlanUpdate"]["CustomerRatePoolId"] : ""

          data = {
            tenant_name: partner || "default_value",
            path: path,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            service_provider: service_provider,
            change_type: change_type,
            bulk_change_id: parsedData?.bulkchange_id?.id,
            data: parsedData?.data,
            created_by: firstLastName,
            iccids: payload.iccids,
            imeids: payload.imeis,
            changed_data: {
              OverrideValidation: false,
              Devices: payload.iccids,
              ...changed_customer_rate_plan_data,
            },
            updated_data: {
              CustomerRatePlanUpdate: {
                effective_date: changed_customer_rate_plan_data?.CustomerRatePlanUpdate?.EffectiveDate || "",
                customer_rate_plan_name: changed_customer_rate_plan_data?.CustomerRatePlanUpdate?.CustomerRatePlanId || "",
                customer_rate_pool_name: changed_customer_rate_plan_data?.CustomerRatePlanUpdate?.CustomerRatePoolId || "",

              }
            }
          };

        }
        const kore_response = await axios.post(url, { data });
        const kore_parsedData = JSON.parse(kore_response.data.body);

        if (kore_parsedData.flag === false) {
          console.error("Data Fetch Error: " + kore_parsedData.message);
        } else {
          console.log("Success: Bulk update successful.");
        }
        const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
        data["service_provider_id"] = service_provider_id_
        callKoreSync(data)
      }
      else if (service_provider.toLowerCase().includes("telegence") && change_type === "Update Device Status" && changed_data?.UpdateStatus === "M") {
        if (switch_user_2_0 === "True") {
          call_2_0_submit(parsedData, data)
          call_2_0_sync(parsedData)
        }
        else {
          callRestoreCancelledSync(payload, parsedData)
        }
      }
      else if (change_type === "Update PPU address" || change_type === "Update Features" || change_type === "Refresh A Line") {
        call_2_0_submit_ppu_address(parsedData, data)
        call_2_0_sync(parsedData)
      }
      else if ((service_provider.toLowerCase() === "webbing" && type === "change customer rate plan")) {
        call_2_0_submit(parsedData, data)
        call_2_0_sync(parsedData)
      }
      else {
        // Prepare payload for the new API call
        // const newApiData = {
        //   tenant_name: partner || "default_value",
        //   username: username,
        //   firstLastName: firstLastName,
        //   path: "/inventory_iccidds_imeids", // New API path
        //   service_provider:service_provider,
        //   role_name: role,
        //   module_name: "Bulk Change",
        //   mod_pages: { start: 0, end: 100 },
        //   access_token: token,
        //   db_name: selectedDb,
        //   sessionID: sessionId,
        //   request_received_at: getCurrentDateTime(),
        //   Partner: partner
        // };
        //   // Call the new API to get ICCIDs and IMEIs
        // const newApiResponse = await axios.post(ENV_ROUTES.SIM_MANAGEMENT, { data: newApiData });
        // const newApiParsedData = JSON.parse(newApiResponse.data.body); // Parse the new API response

        // const AlliccidList = newApiParsedData.iccid; // Adjust based on the actual structure of the response
        // const AllimeiList = newApiParsedData.imei; // Adjust based on the actual structure of the response
        // const AllmssidnList = newApiParsedData.imei; // Adjust based on the actual structure of the response

        // console.log("AllmssidnList",AllmssidnList)

        // Compare ICCID and IMEI values against the lists
        // const iccidMatch = (payload.iccids.every((iccid: any) => AlliccidList.includes(iccid)) || (service_provider.includes("Verizon") && (changed_data?.UpdateStatus?.toLowerCase() === "inventory")));
        // const imeiMatch = (payload.imeis.every((imei: any) => AllimeiList.includes(imei)) || (service_provider.includes("Verizon") && (changed_data?.UpdateStatus?.toLowerCase() === "inventory")));
        // const mssidnMatch = (payload.iccids.every((iccid: any) => AllmssidnList.includes(iccid)) && (service_provider.includes("AT&T - Telegence") && (change_type === "Change Customer Rate Plan" || change_type === "Update Device Status")));

        // if (
        //   (service_provider === "Verizon - ThingSpace IoT" && (changed_data?.UpdateStatus === "Active" || changed_data?.UpdateStatus === "Pending activation" || (changed_data?.UpdateStatus?.toLowerCase() === "inventory"))) ||
        //   (service_provider === "Verizon - ThingSpace PN" && (changed_data?.UpdateStatus === "Active" || changed_data?.UpdateStatus === "Pending activation" || (changed_data?.UpdateStatus?.toLowerCase() === "inventory"))) || (
        //     service_provider.includes("AT&T - Telegence") && change_type !== "Change Customer Rate Plan"&& change_type !== "Update Device Status")
        // ) {
        //   if (!iccidMatch || !imeiMatch) {
        //     console.log("All ICCID and IMEI values do not match.");
        //     callMismatchICCID(parsedData)
        //   } else {
        // Call run_db_script API
        const isTelegence = service_provider.toLowerCase().includes("telegence");
        const isWebbing = service_provider.toLowerCase().includes("webbing");
        const isVerizon = (service_provider.toLowerCase().includes("verizon") || service_provider.toLowerCase().includes("vzn") || service_provider.toLowerCase().includes("vzwcr") || service_provider.toLowerCase().includes("2215-so01"));
        const isPod19 = service_provider.toLowerCase().includes("pod19");
        const isPondIOT = service_provider.toLowerCase().includes("pond");
        const isJasper = service_provider.toLowerCase().includes("jasper");
        const isTeal = service_provider.toLowerCase().includes("teal");
        const isKore = service_provider.toLowerCase().includes("kore");
        const isRogers = service_provider.toLowerCase().includes("rogers");
        if (switch_user_2_0 === "True" && (isTelegence || isVerizon|| isWebbing || isPod19 || isPondIOT || isJasper || isRogers || isTeal || isKore)) {
          call_2_0_submit(parsedData, data)
          call_2_0_sync(parsedData)
        }
        else {
          await callRunDbScript(parsedData);
        }

        if (change_type === "Change Customer Rate Plan") {
          await callSyncLambda()
        }
        // }
        // }
        // else if (service_provider.includes("AT&T - Telegence") && (change_type === "Change Customer Rate Plan" || change_type === "Update Device Status")) {
        //   if (!mssidnMatch) {
        //     console.log("All MSSIDN values do not match.");
        //     callMismatchICCID(parsedData)
        //   } else {
        //     console.log("All MSSIDN values match.");
        //     // Call run_db_script API
        //     await callRunDbScript(parsedData);
        //     await callSyncLambda()
        //   }
        // }
        // else {
        //   if (!iccidMatch) {
        //     console.log("All ICCID values do not match.");
        //     callMismatchICCID(parsedData)
        //   } else {
        //     console.log("All ICCID values match.");
        //     // Call run_db_script API
        //     await callRunDbScript(parsedData);
        //     if(change_type === "Change Customer Rate Plan"){
        //       await callSyncLambda()
        //     }
        //   }
        // }
      }
    } catch (error) {
      const isTelegence = service_provider.toLowerCase().includes("telegence");
      const isWebbing = service_provider.toLowerCase().includes("webbing");
      const isVerizon = (service_provider.toLowerCase().includes("verizon") || service_provider.toLowerCase().includes("vzn") || service_provider.toLowerCase().includes("vzwcr") || service_provider.toLowerCase().includes("2215-so01"));
      const isPod19 = service_provider.toLowerCase().includes("pod19");
      const isPondIOT = service_provider.toLowerCase().includes("pond");
      const isJasper = service_provider.toLowerCase().includes("jasper");
      const isKore = service_provider.toLowerCase().includes("kore");
      const isTeal = service_provider.toLowerCase().includes("teal");
      const isRogers = service_provider.toLowerCase().includes("rogers");
      if (switch_user_2_0 === "True" && (isTelegence || isVerizon || isPondIOT || isJasper || isPod19 || isRogers || isWebbing || isKore || isTeal)) {
        onCancel()
        setLoading(false)
        addExport("bulkChangeInsert", "Bulk Change Submission");
        bulkChangePolling(data)
      }
      else {
        Modal.error({
          title: 'Submit Error',
          content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting. Please try again.',
          centered: true,
        });
      }
    } finally {
      setLoading(false);
    }
  };

  const callSyncLambda = async () => {
    try {
      const url = ENV_ROUTES.OPTIMIZATION_SYNC_LAMBDA;
      const data = {
        key_name: "bulk_chnage_history",
        path: "/lambda_sync_jobs_",
        tenant_name: partner
      };

      const response = await axios.post(url, { data });
      const responseData = JSON.parse(response.data.body);

      if (responseData.flag === false) {
        console.error("Data Fetch Error: " + responseData.message);
      } else {
        console.log("Success: Bulk update successful.");
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };
  const call_2_0_submit_ppu_address = async (parsedData: any, payload: any) => {
    try {
      const payload_data = { ...payload }
      const url = ENV_ROUTES.BULKCHANGE_PROCESSOR;
      const prevChangedData = payload_data?.changed_data || {}
      payload_data["msisdns"] = payload_data?.iccids
      delete payload_data["imeids"]
      delete payload_data["iccids"]
      if (change_type === "Update Features") {
        delete payload_data["changed_data"]
      }
      const payloadData = {
        ...payload_data,
        path: "/bulk_change_processor",
        request_received_at: getCurrentDateTime(),
        bulk_change_id: parsedData?.bulk_chnage_id_20,
      }
      const data = { ...payloadData };
      const response = await axios.post(url, { data });
      const responseData = JSON.parse(response.data.body);
      if (responseData.flag === false) {
        console.log("Failure: 2.0 Bulk change update failed.");
      } else {
        console.log("Success: 2.0 Bulk change update successful.");
      }
    }
    catch (error) {
      console.error("Error running DB script:", error);
    } finally {
      setLoading(false);
    }
  }
  const call_2_0_sync = async (parsedData: any) => {
    try {
      const runDbScriptUrl = ENV_ROUTES.SIM_MANAGEMENT;
      const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
      const runDbScriptData = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/update_bulk_change_tables_10",
        role_name: role,
        module_name: "Bulk Change",
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        // service_provider_id: service_provider_id_,
        // bulkchange_id: parsedData?.bulkchange_id?.id,
        // data: parsedData?.data,
        data: {
          bulk_change_id: parsedData?.bulk_chnage_id_20,
        },
        is_update: false,
        // bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
      };

      const runDbScriptResponse = await axios.post(runDbScriptUrl, { data: runDbScriptData });
      const runDbScriptResponseData = JSON.parse(runDbScriptResponse.data.body);

      if (runDbScriptResponseData.flag === false) {
        console.error("Data Fetch Error: " + runDbScriptResponseData.message);
      } else {
        console.log("Success: Bulk update successful.");
      }
    }
    catch (error) {
      console.error("Error running DB script:", error);
    } finally {
      setLoading(false);
    }
  }
  const call_2_0_submit = async (parsedData: any, payload: any) => {
    const isTelegence = service_provider.toLowerCase().includes("telegence");
    const isWebbing = service_provider.toLowerCase().includes("webbing");
    const isVerizon = (service_provider.toLowerCase().includes("verizon") || service_provider.toLowerCase().includes("vzn") || service_provider.toLowerCase().includes("vzwcr") || service_provider.toLowerCase().includes("2215-so01"));
    try {
      let prevChangedData
      let newChangedData
      const changeType = change_type ? change_type.toLowerCase() : ""
      delete payload["imeids"]
      if (changeType === "change customer rate plan") {
        let ratePlanNameParts = ""
        let ratePoolNameParts = ""
        prevChangedData = payload?.changed_data?.CustomerRatePlanUpdate || {}
        if (prevChangedData?.CustomerRatePlanId && prevChangedData?.CustomerRatePlanId !== -1) {
          ratePlanNameParts = (prevChangedData?.CustomerRatePlanId || "").split(" -- ")

        }
        if (prevChangedData?.CustomerRatePoolId && prevChangedData?.CustomerRatePoolId !== -1) {
          ratePoolNameParts = (prevChangedData?.CustomerRatePoolId || "").split(" -- ")

        }

        newChangedData = {
          customer_rate_plan_name: ratePlanNameParts && ratePlanNameParts.length > 0 ? ratePlanNameParts[0] : null,
          customer_rate_pool_name: ratePoolNameParts && ratePoolNameParts.length > 0 ? ratePoolNameParts[0] : null,
          effective_date: prevChangedData?.EffectiveDate || "",
        }
        if (isTelegence) {
          payload["msisdns"] = payload?.iccids
          delete payload["iccids"]
        }

      }
      else if (changeType === "update device status") {
        console.log("changed_data", changed_data)
        prevChangedData = payload?.changed_data || {}
        newChangedData = { ...prevChangedData }
        payload["sim_status"] = changed_data?.sim_status || ""
        payload["device_status_id"] = changed_data?.device_status_id || "22"
        delete payload["imeids"]
        delete newChangedData["sim_status"]
        delete newChangedData["device_status_id"]
        if (isTelegence) {
          payload["msisdns"] = payload?.iccids
          payload["effective_date"] = changed_data?.effectiveDate || null
          payload["effective_date"] = changed_data?.effectiveDate || null
          delete payload["iccids"]
          delete newChangedData["effectiveDate"]
        }
      }
      else if (changeType === "change carrier rate plan") {
        let prevChangedData = payload?.changed_data?.CarrierRatePlanUpdate || {}
        payload["effective_date"] = prevChangedData.EffectiveDate || null
        delete payload["changed_data"]
      }
      else {
        prevChangedData = payload?.changed_data || {}
        newChangedData = { ...prevChangedData }
      }
      const url = ENV_ROUTES.BULKCHANGE_PROCESSOR;
      const payloadData = {
        ...payload,
        path: "/bulk_change_processor",
        request_received_at: getCurrentDateTime(),
        bulk_change_id: parsedData?.bulk_chnage_id_20,
        // changed_data: { ...newChangedData }
        changed_data: { ...newChangedData }
      }
      const data = { ...payloadData };
      const response = await axios.post(url, { data });
      const responseData = JSON.parse(response.data.body);
      if (responseData.flag === false) {
        console.log("Failure: 2.0 Bulk change update failed.");
      } else {
        console.log("Success: 2.0 Bulk change update successful.");
      }
    }
    catch (error) {
      console.error("Error running DB script:", error);
    } finally {
      setLoading(false);
    }
  }
  // Helper function to call run_db_script API
  const callRunDbScript = async (parsedData: any) => {
    const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
    const verizon_inventory_flag_condition = ((service_provider.toLowerCase()).includes("verizon") || service_provider.toLowerCase().includes("vzn") || service_provider.toLowerCase().includes("vzwcr") || service_provider.toLowerCase().includes("2215-so01")) && change_type === "Update Device Status" && (changed_data?.UpdateStatus).toLowerCase() === "inventory"
    console.log("parsedData", parsedData)
    try {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/run_db_script",
        role_name: role,
        module_name: "Bulk Change",
        mod_pages: { start: 0, end: 100 },
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        service_provider_id: service_provider_id_,
        bulkchange_id: parsedData?.bulkchange_id?.id,
        data: parsedData?.data,
        bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
        verizon_inventory_flag: verizon_inventory_flag_condition
      };

      const response = await axios.post(url, { data });
      const responseData = JSON.parse(response.data.body);

      if (responseData.flag === false) {
        console.error("Data Fetch Error: " + responseData.message);
      } else {
        console.log("Success: Bulk update successful.");
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const fetchDevices = async (devices_list: any, deviceKey: string) => {
    try {
      setLoading(true);
      const url =
        ENV_ROUTES.BULKCHANGE_PROCESSOR;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_standard_iccid_msisdn_data",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
        service_provider: service_provider,
        change_type: change_type,
        [deviceKey]: devices_list || []
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        // setLoading(false);
        Modal.error({
          title: 'Submit Error',
          content: parsedData.message || 'An error occurred while submitting data. Please try again.',
          centered: true,
        });
        return []
      } else {
        let responseKey = deviceKey === "iccids" ? "msisdns" : "iccids"
        if (isIMEI) {
          responseKey = deviceKey === "iccids_imei_map" ? "msisdns_imei_map" : "iccids_imei_map"
        }
        let devices = parsedData?.[responseKey] || []
        if (isIMEI) {
          devices = devices ? Object.keys(devices) : devices
        }
        console.log("devices", devices)
        return devices
        // setLoading(false);
      }
    } catch (error) {
      Modal.error({
        title: 'Submit Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting data. Please try again.',
        centered: true,
      });
      return []
      // setLoading(false);
    }
    finally {
      // setLoading(false)
    }
  };

  const getIccidList = async (iccids_: any[]): Promise<string[]> => {
    // Pick devices based on subscriberNumber or iccids
    const devices_ = subscriberNumber ? subscriberNumber : iccid;

    // Find matching device type from the map
    const matchedDeviceTypeItem = simIdentifierMap.find((item: any) => {
      return (
        item.service_provider === service_provider &&
        item.change_type === change_type
      );
    });
    const matchedDeviceType = matchedDeviceTypeItem?.sim_identifier || ""
    // Decide expected type
    const selectDeviceType = subscriberNumber ? "msisdns" : "iccids";
    const selectedIMEIType = subscriberNumber ? "msisdns_imei_map" : "iccids_imei_map"
    // Split devices into a list
    let iccidList: any = devices_
      .split(/\s*[\n,]\s*/)
      .map((line) => line.trim())
      .filter((line) => line.length > 0);

    let iccidMap: Record<string, string> = {};

    if (isIMEI) {
      // Convert flat list into key-value pairs
      for (let i = 0; i < iccidList.length; i += 2) {
        const iccidOrMsisdn = iccidList[i].toString();
        const imei = iccidList[i + 1] || ""; // safeguard in case odd count
        iccidMap[iccidOrMsisdn.toString()] = imei;
      }
    }

    console.log("iccidMap", iccidMap)
    console.log("iccidList", iccidList)


    // Fetch devices only if types mismatch
    if (matchedDeviceType !== selectDeviceType) {
      const deviceType = isIMEI ? selectedIMEIType : selectDeviceType
      const deviceList = isIMEI ? iccidMap : iccidList
      iccidList = await fetchDevices(deviceList, deviceType);
    }
    else {
      iccidList = iccids_
    }

    return iccidList;
  };

  const handleSubmit = async () => {
    let hasError = false;
    if (!subscriberNumber && !iccid) {
      setIccidError("Please fill in Devices.")
      return
    }
    else {
      setIccidError("")
    }
    console.log("handle submit")
    // Split and process input, ensuring no unwanted commas or spaces
    const selected_devices = subscriberNumber ? subscriberNumber : iccid
    const inputLines = selected_devices
      .split(/\s*[\n,]\s*/) // Split on newlines or commas
      .map((line) => line.trim())
      .filter((line) => line.length > 0); // Remove empty lines



    const iccids: string[] = [];
    const imeis: string[] = [];

    if (isIMEI) {
      let hasExtraValues = false;
      const devicesList = inputLines
        .map(line => {
          const values = line
            .split(",")
            .map(val => val.trim())
            .filter(Boolean);

          if (values.length > 2) {
            hasExtraValues = true;
          }

          return values.slice(0, 2);
        })
        .flat();
      if ((devicesList.length > 0 && (devicesList.length) % 2 !== 0 || hasExtraValues)) {
        setIccidError("Please fill in both values separated by a comma.")
        return
      }
      // If the field is for both ICCID and IMEI, split the input into two lists
      for (let i = 0; i < inputLines.length; i++) {
        if (i % 2 === 0) {
          iccids.push(inputLines[i]); // Even index: ICCID
        } else {
          imeis.push(inputLines[i]); // Odd index: IMEI
        }
      }
    } else {
      iccids.push(...inputLines); // All values are treated as ICCIDs
    }
    // Check if input is empty
    if (iccids.length === 0) {
      setIccidError("Please fill ICCID field or MSISDN field.");
      hasError = true;
    } else {
      // Validate ICCID format
      if (subscriberNumber && subscriberNumber !== "") {
        let invalidIccidFound = false;
        let invalidIccid = false;
        let nonNumericIccid = false;

        for (const line of iccids) {
          const strLine = String(line);
          if (!/^\d+$/.test(strLine)) {
            nonNumericIccid = true;
            break;
          } else if (strLine.length < 10 || strLine.length > 18) {
            invalidIccid = true;
            break;
          }
        }

        if (nonNumericIccid) {
          setIccidError("Please enter numbers only for Subscriber Number. Letters or special characters are not allowed");
          hasError = true;
          console.log("Validation failed: Non-numeric Subscriber Number.");
        } else if (invalidIccid) {
          setIccidError("Each Subscriber Number must be between 10 to 18 digits long.");
          hasError = true;
          console.log("Validation failed: Invalid Subscriber Number length.");
        } else {
          setIccidError("");
        }

        if (isIMEI) {
          let invalidImei = false;
          let nonNumericImei = false;

          for (const line of imeis) {
            const strLine = String(line);
            if (!/^\d+$/.test(strLine)) {
              nonNumericImei = true;
              break;
            } else if (strLine.length < 12 || strLine.length > 22) {
              invalidImei = true;
              break;
            }
          }

          if (nonNumericImei) {
            setImeiError("Please enter numbers only for IMEI.Letters or special characters are not allowed");
            hasError = true;
            console.log("Validation failed: Non-numeric IMEI.");
          } else if (invalidImei) {
            setImeiError("Each IMEI must be between 12 to 22 digits long.");
            hasError = true;
            console.log("Validation failed: Invalid IMEI length.");
          } else {
            setImeiError("");
          }
        }
      }
      else {

        let invalidIccid = false;
        let nonNumericIccid = false;

        const isTMobile = service_provider.toLowerCase().includes("t-mobile")
        const isTeal = service_provider.toLowerCase().includes("teal")
        for (const line of iccids) {
          const strLine = String(line);
          if ((!/^\d+$/.test(strLine) && !isTMobile)) {
            nonNumericIccid = true;
            break;
          }
          if (!/^[a-zA-Z0-9]+$/.test(strLine) && isTMobile) {
            nonNumericIccid = true;
            break;
          }
          else if (strLine.length < 14 || (strLine.length > 22 && !isTeal) || (isTeal && strLine.length > 32)) {
            invalidIccid = true;
            break;
          }
        }

        if (nonNumericIccid) {
          if(isTMobile){
            setIccidError("ICCID must only contain letters and numbers. Special characters are not allowed");
            hasError = true;
            console.log("Validation failed: Non-numeric ICCID.");
          }
          else {
            setIccidError("Please enter numbers only for ICCID.Letters or special characters are not allowed");
            hasError = true;
            console.log("Validation failed: Non-numeric ICCID.");
          }
        } else if (invalidIccid) {
          setIccidError(`Each ICCID must be between 14 to ${isTeal ? "32":"22"} digits long.`);
          hasError = true;
          console.log("Validation failed: Invalid ICCID length.");
        } else {
          setIccidError("");
        }

        if (isIMEI) {
          let invalidImei = false;
          let nonNumericImei = false;

          for (const line of imeis) {
            const strLine = String(line);
            if (!/^\d+$/.test(strLine)) {
              nonNumericImei = true;
              break;
            } else if (strLine.length < 12 || strLine.length > 22) {
              invalidImei = true;
              break;
            }
          }

          if (nonNumericImei) {
            setImeiError("Please enter numbers only for IMEI.Letters or special characters are not allowed");
            hasError = true;
            console.log("Validation failed: Non-numeric IMEI.");
          } else if (invalidImei) {
            setImeiError("Each IMEI must be between 12 to 22 digits long.");
            hasError = true;
            console.log("Validation failed: Invalid IMEI length.");
          } else {
            setImeiError("");
          }
        }
      }

    }
    if (hasError) {
      console.log("has error")
      return;
    } else {
      setIccidError(""); // Clear error message if all validations pass
      setImeiError("")
    }


    console.log("ICCID List:", iccids);
    console.log("IMEI List:", imeis);

    if (iccids.length > bulkChangeLimit || imeis.length > bulkChangeLimit) {
      setIccidError(`This request exceeds the allowed record limit  of ${bulkChangeLimit} and cannot be processed`);
      console.log("Limit Exceeded");
      hasError = true;
    }

    if (hasError) {
      console.log("Validation failed.");
      return;
    }

    const selectedDevices = await getIccidList(iccids)

    const payload: any = {
      iccids: selectedDevices,
      imeis: imeis,
    };

    console.log("Payload to be sent:", payload);
    setsetActivationPayload(payload)
    if (isNextScreen) {
      fetchTaggedCustomers(payload)
    }
    if (isNextScreen) {
      if (typeof onClose === "function") {
        onClose()
      }
      return
    }

    if (typeof onsubmit === "function") {
      onsubmit(payload);
    } else {
      console.error("onsubmit is not a function.");
    }
  };

  useEffect(() => {
    console.log('Changed Data:', changed_data);

    const changeType = change_type?.toLowerCase() || ""
    const SP = service_provider.toLowerCase() || ""
    const isIMEI_ =
      (
        SP === "kore" &&
        changeType === "update device status" &&
        (changed_data?.UpdateStatus === "Activate" ||
          changed_data?.UpdateStatus === "Active")
      ) ||
      (
        ((SP.includes("verizon") || SP.includes("vzn") || SP.includes("vzwcr") || SP.includes("2215-so01")) &&
          (changed_data?.UpdateStatus === "Active" ||
            changed_data?.UpdateStatus === "Pending activation"))
      )

    setIsIMEI(isIMEI_)

  }, [changed_data]);

  const fetchTaggedCustomers = async (payload: any) => {
    try {
      const isTelegence = service_provider?.toLowerCase().includes("telegence")
      setLoading(true);
      const url =
        ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        path: "/customers_tagged_iccids",
        request_received_at: getCurrentDateTime(),
        username: username,
        firstLastName: firstLastName,
        role_name: role,
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
        service_provider: service_provider,
        change_type: change_type,
        ...(isTelegence ? { msisdns: payload?.iccids || [] } : { iccids: payload?.iccids || [] })

      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        setLoading(false);
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        const options_ = parsedData?.tagged_customers || []
        const formatted_options = options_.map((opt: any) => ({ label: opt, value: opt }))
        if (typeof setSelectedCustomers === "function") {
          setSelectedCustomers(formatted_options)
        }
        setLoading(false);
      }
    } catch (error) {
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    }
  };

  useImperativeHandle(ref, () => ({
    runSubmit:() => { 
      console.log("runSubmit in select devices")
      onsubmit(allChangeTypesDevices) },
  }));

  if (loading) {
    return (
      <div className="flex justify-center items-center h-[400px]">
        <Spin size="large" />
      </div>
    );
  }

  return (

    <div className="flex flex-col mt-2">
      {(isNextScreen && (change_type.toLowerCase()==="change customer rate plan")) && (
                              <UploadComponent
                                  service_provider={service_provider}
                                  change_type={change_type}
                                  changed_data={{
                                      ...changed_data,
                                  }} />
                      )}
      <h2 className="text-500 font-semibold">Select Devices</h2>
      {/* <div className="bg-[#FFEDA6] mb-2 p-2 border border-[#FFCE0E] rounded text-center">
        <h3 className="font-[13px]">
          Processing Time will be approximately 2 minutes to process 100 Bulk Change requests.
        </h3>
      </div>
      <div>
        <div>
          <label className="font-bold mr-2">Processing Time:</label>
          <span>10 requests per 1 second</span>
        </div>
        <div>
          <label className="font-bold mr-2">Maximum Requests allowed:</label>
          <span>100 Requests</span>
        </div>
      </div> */}
      {/* ICCID & IMEI Field (Conditionally Combined) */}
      <div className="space-y-4 flex flex-col">
        <div className="flex flex-col space-y-2">
          <label htmlFor="iccid-imei" className="font-semibold">
            {isIMEI ? "ICCID & IMEI" : "ICCID"}
            <span className="text-red-500">*</span>
          </label>
          <Input.TextArea
            id="iccid-imei"
            rows={6}
            placeholder={isIMEI
              ? "Enter ICCIDs and IMEIs separated by a comma (e.g., ICCID, IMEI)"
              : "Enter ICCIDs here"
            }
            value={iccid}
            onChange={(e) => {
              setIccid(e.target.value);
              if (e.target.value) setSubscriberNumber("");
            }}
            disabled={!!subscriberNumber}
          />
        </div>
        {!isIMEI && (
          <div className="flex flex-col space-y-2">
            <label htmlFor="msisdn-imei" className="font-semibold">
              {isIMEI ? "MSISDN & IMEI" : "MSISDN"}
              <span className="text-red-500">*</span>
            </label>
            <Input.TextArea
              id="iccid-imei"
              rows={6}
              placeholder={isIMEI
                ? "Enter MSISDNs and IMEIs separated by a comma (e.g., MSISDN, IMEI)"
                : "Enter MSISDNs here"
              }
              value={subscriberNumber}
              onChange={(e) => {
                setSubscriberNumber(e.target.value);
                if (e.target.value) setIccid("");
              }}
              disabled={!!iccid}
            />
          </div>
        )}

        {iccidError && <div className="text-red-500 text-sm">{iccidError}</div>}
        {imeiError && <div className="text-red-500 text-sm">{imeiError}</div>}
      </div>



      {/* Buttons */}
      <div className="flex justify-center space-x-4 mt-4">
        <button onClick={onBack} className="cancel-btn">
          Back
        </button>
        <button onClick={handleSubmit} className="save-btn">
          {isNextScreen ? "Continue" : "Submit"}
        </button>
      </div>
    </div>



  );
}
)

export default SelectDevices;
