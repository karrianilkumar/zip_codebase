import { FC, useState } from "react";
import { Input, Button, Modal, Spin, Select } from "antd";
import { useAuth } from "@/app/components/auth_context";
import { useRouter } from 'next/navigation';
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";


interface SelectDevicesProps {
  onContinue: () => void;
  onBack: () => void;
  service_provider: any;
  change_type: any;
  changed_data?: any;
  isNextScreen?: boolean;
  onClose: () => void;
  setDropdownData: (dropdown: any) => void;
  onCancel: () => void;
}

interface Data {
  tenant_name: string;
  path: string;
  request_received_at: string;
  access_token: string | null;
  db_name: string | null;
  service_provider: any;
  sessionID: string | null;
  change_type: any;
  created_by: string | null;
  changed_data: any;
  // iccids?: string[]; // Add the 'iccids' property with optional type
  // iccidList?: { iccid: string; ratePlanCode: string }[]; // Add the 'iccidList' property with optional type
}

const ActivateSelectDevices: FC<SelectDevicesProps> = ({
  onContinue,
  onBack,
  onClose,
  service_provider,
  change_type,
  changed_data: {
    ApplicableRatePlanForAll,
    // RatePlanCodeList,
    Devices,
    ...returnChangedData
  },
  isNextScreen,
  setDropdownData,
  onCancel
}) => {
  console.log("Show returned data",returnChangedData)
  const [iccid, setIccid] = useState([{ iccid: '', ratePlanCode: '' }]);
  const [iccidText, setIccidText] = useState('');
  const [validIccid, setValidIccid] = useState<string[]>([]);
  const [validImei, setValidImei] = useState<string[]>([]);


  const [newIMEI, setNewIMEI] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [loading, setLoading] = useState(false);
  const [processImmediately, setProcessImmediately] = useState(false); // State for checkbox
  const { username, role, partner, token, selectedDb,metaData, firstLastName, sessionId, modulesVersionMap } = useAuth();
  const router = useRouter();
  const { setRowId, setBulkRow, setsetActivationPayload ,bulkChangeLimit} = useFeatureStore();
  const [iccidList, setIccidList] = useState([{ iccid: '', ratePlanCode: '' }]);
  const [iccidError, setIccidError] = useState("");
  const initial_version_flag = modulesVersionMap?.["Sim Management-Bulk Change"] || false
  const isVersionEnabled = localStorage.getItem("switch_user_2_0_bulk_change") === "True";
  const switch_user_2_0 = isVersionEnabled && initial_version_flag ? "True" : "False"
  const { addExport, removeExport, exports } = exportLoadingStore();
  // const onsubmit = async (payload: { iccids: any; imeis: any; }) => {
  //   try {
  //     const changedData = returnChangedData ? returnChangedData : {};
  //     setLoading(true);

  //     const url = ENV_ROUTES.SIM_MANAGEMENT;

  //     // Prepare the data object
  //     const data: any = {
  //       tenant_name: partner || "default_value",
  //       path: "/update_bulk_change_data", // Default path
  //       request_received_at: getCurrentDateTime(),
  //       access_token: token,
  //       db_name: selectedDb,
        // ... metaData,
  //       sessionID: sessionId,
  //       service_provider: service_provider,
  //       change_type: change_type,
  //       created_by: firstLastName,
  //       changed_data: {
  //         ...changedData
  //       },
  //     };

  //     // Handle ICCID and IMEI logic based on ApplicableRatePlanForAll
  //     if (ApplicableRatePlanForAll) {
  //       // if (validIccid.length !== validImei.length) {
  //       //   setErrorMessage("The number of IMEIs must match the number of ICCIDs.");
  //       //   return;
  //       // }
  //       data.Devices=payload.iccids;
  //       data.iccids = payload.iccids; // Use the payload
  //       data.imei = payload.imeis;
  //       console.log("Devices",data.Devices);
  //       console.log("data", data)
  //     } else {
  //       // When ApplicableRatePlanForAll is false
  //       const validIccidList = iccidList.filter(item => item.iccid && item.ratePlanCode);
  //       data.iccidList = validIccidList;
  //       data.iccids = validIccid;
  //       data.Devices = payload.iccids;
  //       console.log("Devices",data.Devices);
  //       console.log("data", data)
  //       const imeis = newIMEI
  //         .split(/[\n,]/)
  //         .map(line => line.trim())
  //         .filter(line => line.length > 0);

  //       data.IMEI = imeis;

  //       // Check if IMEI is provided for each device
  //       for (const item of iccidList) {
  //         if (!item.iccid || !item.ratePlanCode) {
  //           setErrorMessage("ICCID and Rate Plan Code are required.");
  //           return;
  //         }
  //       }
  //     }

  //     // Send the initial request
  //     const response = await axios.post(url, { data });
  //     const parsedData = JSON.parse(response.data.body);

  //     if (parsedData.flag === false) {
  //       setLoading(false);
  //       Modal.error({
  //         title: 'Submit Error',
  //         content: parsedData.message || 'An error occurred while updating data. Please try again.',
  //         centered: true,
  //       });
  //     } else {
  //       const AlliccidList = parsedData.iccid;
  //       const AllimeiList = parsedData.imei;

  //       // Check if all ICCID and IMEI values match
  //       const iccidMatch = payload.iccids.every((iccid: string) => AlliccidList.includes(iccid));
  //       const imeiMatch = payload.imeis.every((imei: string) => AllimeiList.includes(imei));

  //       if (iccidMatch && imeiMatch) {
  //         console.log("All ICCID and IMEI values match.");

  //         // Prepare data for the second request
  //         const data = {
  //           tenant_name: partner || "default_value",
  //           username: username,
  //           firstLastName: firstLastName,
  //           path: "/run_db_script", // Change to the correct path
  //           role_name: role,
  //           module_name: "Bulk Change",
  //           mod_pages: {
  //             start: 0,
  //             end: 100,
  //           },
  //           access_token: token,
  //           db_name: selectedDb,
        // ... metaData,
  //           sessionID: sessionId,
  //           request_received_at: getCurrentDateTime(),
  //           Partner: partner,
  //           bulkchange_id: parsedData?.bulkchange_id?.id,
  //           data: parsedData?.data,
  //           bulk_chnage_id_20: parsedData?.bulk_chnage_id_20
  //         };

  //         // Send the second request
  //         const runDbResponse = await axios.post(url, { data: data });
  //         const runDbResponseData = JSON.parse(runDbResponse.data.body);

  //         if (runDbResponseData.flag === false) {
  //           // Handle error for the second request
  //           Modal.error({
  //             title: "Data Fetch Error",
  //             // content: runDbResponse .message || "An error occurred while fetching updating. Please try again.",
  //             centered: true,
  //           });
  //         } else {
  //           console.log("Run DB script executed successfully.");
  //           const bulkrow_ = parsedData?.bulkchange_id || {};
  //           const bulkRow: any = { row: bulkrow_ };
  //           setBulkRow(bulkRow);
  //           localStorage.setItem('bulk_row', JSON.stringify(bulkRow || "{}"));

  //           // Navigate to the bulk history page
  //           if(bulkRow){
  //             router.push(`/sim_management/bulk_history`);
  //           }
  //         }
          
  //       } else {
  //         console.log("All ICCID and IMEI values do not match. Submission completed without running the script.");
  //         const bulkrow_ = parsedData?.bulkchange_id || {};
  //         const bulkRow: any = { row: bulkrow_ };
  //         setBulkRow(bulkRow);
  //         localStorage.setItem('bulk_row', JSON.stringify(bulkRow || "{}"));

  //         router.push(`/sim_management/bulk_history`);
  //       }
  //     }
  //   } catch (error) {
  //     Modal.error({
  //       title: 'Submit Error',
  //       content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting. Please try again.',
  //       centered: true,
  //     });
  //   } finally {
  //     setLoading(false);
  //   }
  // };

  // const onsubmit = async (payload: { iccids: any; imeis: any; }) => {
  //   try {
  //     const changedData = returnChangedData ? returnChangedData : {};
  //     setLoading(true);
  
  //     const url = ENV_ROUTES.SIM_MANAGEMENT;
  
  //     // Prepare the data object for the initial request
  //     const data: any = {
  //       tenant_name: partner || "default_value",
  //       path: "/update_bulk_change_data", // This path is used for the first request
  //       request_received_at: getCurrentDateTime(),
  //       access_token: token,
  //       db_name: selectedDb,
        // ... metaData,
  //       sessionID: sessionId,
  //       service_provider: service_provider,
  //       change_type: change_type,
  //       created_by: firstLastName,
  //       changed_data: {
  //         ...changedData
  //       },
  //       Devices: payload.iccids,
  //       iccids: payload.iccids,
  //       imei: payload.imeis,
  //     };
  
  //     console.log("Initial Data", data);
  
  //     // Send the initial request
  //     const response = await axios.post(url, { data });
  //     const parsedData = JSON.parse(response.data.body);
  
  //     if (parsedData.flag === false) {
  //       setLoading(false);
  //       Modal.error({
  //         title: 'Submit Error',
  //         content: parsedData.message || 'An error occurred while updating data. Please try again.',
  //         centered: true,
  //       });
  //     } else {
  //       console.log("Initial request successful:", parsedData);
  
  //       // Always call the /run_db_script path
  //       const runDbData = {
  //         tenant_name: partner || "default_value",
  //         username: username,
  //         firstLastName: firstLastName,
  //         path: "/run_db_script", // Always use this path
  //         role_name: role,
  //         module_name: "Bulk Change",
  //         mod_pages: {
  //           start: 0,
  //           end: 100,
  //         },
  //         access_token: token,
  //         db_name: selectedDb,
        // ... metaData,
  //         sessionID: sessionId,
  //         request_received_at: getCurrentDateTime(),
  //         Partner: partner,
  //         bulkchange_id: parsedData?.bulkchange_id?.id,
  //         data: parsedData?.data,
  //         bulk_chnage_id_20: parsedData?.bulk_chnage_id_20
  //       };
  
  //       console.log("Run DB Data", runDbData);
  
  //       // Send the second request
  //       const runDbResponse = await axios.post(url, { data: runDbData });
  //       const runDbResponseData = JSON.parse(runDbResponse.data.body);
  
  //       if (runDbResponseData.flag === false) {
  //         // Handle error for the second request
  //         Modal.error({
  //           title: "Data Fetch Error",
  //           centered: true,
  //         });
  //       } else {
  //         console.log("Run DB script executed successfully.");
  //         const bulkrow_ = parsedData?.bulkchange_id || {};
  //         const bulkRow: any = { row: bulkrow_ };
  //         setBulkRow(bulkRow);
  //         localStorage.setItem('bulk_row', JSON.stringify(bulkRow || "{}"));
  
  //         // Navigate to the bulk history page
  //         if (bulkRow) {
  //           router.push(`/sim_management/bulk_history`);
  //         }
  //       }
  //     }
  //   } catch (error) {
  //     Modal.error({
  //       title: 'Submit Error',
  //       content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting. Please try again.',
  //       centered: true,
  //     });
  //   } finally {
  //     setLoading(false);
  //   }
  // };

  const bulkChangeInsert = async (payload:any) => {
    let partner_name = partner
    let db_name_ = selectedDb
    try {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner_name || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_bulk_change_insertion",
        role_name: role,
        module_name: "Bulk Change History",
        service_provider_name:service_provider,
        change_type:change_type,
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        request_received_at: getCurrentDateTime(),
        Partner: partner_name,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        console.error("Error fetching bulk change data:", parsedData.message ||
          "An error occurred while fetching bulk change data. Please try again.");
          return false
      } else {
        const statusFlag = parsedData?.bulk_change_data?.status || "";
        const response_data = parsedData?.bulk_change_data?.bulk_change_data || "{}";
        const parsedResp = JSON.parse(response_data)
        console.log("status_flag", statusFlag)
        const status_flag = statusFlag ? (statusFlag).toLowerCase() : ""

        if(status_flag && status_flag==="pending"){
          return false
        }
        else if (status_flag && status_flag==="success"){
            call_2_0_submit(parsedResp, payload)
            call_2_0_sync(parsedResp)
            return true
        }
        else if (status_flag && status_flag==="error"){
            Modal.error({
                title: 'Submit Error',
                content: parsedData.message || 'An error occurred while submitting. Please try again.',
                centered: true,
            });
            return true
        }
        else{
          return false
        }
      }
    } catch (error) {
      console.error("Error fetching auto refresh data:", error);
      return false
    } finally {
    }
  };
  const bulkChangePolling = async (data:any) => {
    const result = await bulkChangeInsert(data);
    if (!result) {
      setTimeout(() => bulkChangePolling(data), 5000); // Try again after 5 seconds
    } else {
      removeExport("bulkChangeInsert");
      console.log("Auto-refresh complete.");
    }
    // if (window.location.pathname.includes("/sim_management/bulk_change")) {
    //     window.location.reload();
    // }
  };

  const onsubmit = async (payload: { iccids: any; imeis: any; }) => {
    let data:any
    try {
      const assignCustomer=returnChangedData["assign_customer"] || null
      const assignCustomerParts=(assignCustomer || "") ? assignCustomer.split("--") : []
      console.log("assignCustomer",assignCustomer)
      delete returnChangedData["assign_customer"]
      const changedData = returnChangedData ? returnChangedData : {};
      setLoading(true);
  
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      // Prepare the data object for the initial request
      data = {
        tenant_name: partner || "default_value",
        path: "/update_bulk_change_data", // This path is used for the first request
        role_name: role,
        username: username,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        service_provider: service_provider,
        change_type: change_type,
        created_by: firstLastName,
        customer_name:assignCustomer?assignCustomerParts[0].trim() :null,
        customer_id :assignCustomer?assignCustomerParts[1].trim() :null ,
        changed_data: {
          ...changedData
        },
        Devices: payload.iccids,
        iccids: payload.iccids,
        imei: payload.imeis,
      };
  
      console.log("Initial Data", data);
  
      // Send the initial request
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
  
      if (parsedData.flag === false) {
        setLoading(false);
        Modal.error({
          title: 'Submit Error',
          content: parsedData.message || 'An error occurred while updating data. Please try again.',
          centered: true,
        });
      } else {
        console.log("Initial request successful:", parsedData);
  
        // Navigate to the bulk history page
        const bulkrow_ = parsedData?.bulkchange_id || {};
        const bulkRow: any = { row: bulkrow_ };
        setBulkRow(bulkRow);
        localStorage.setItem('bulk_row', JSON.stringify(bulkRow || "{}"));
        router.push(`/sim_management/bulk_history`);

        // Call the run_db_script without waiting for the response
        if(switch_user_2_0==="True"){
            call_2_0_submit(parsedData,data)
            call_2_0_sync(parsedData)
          }
          else{
            callRunDbScript(parsedData);
          }
      }
    } catch (error) {
      
      if (switch_user_2_0 === "True") {
        onClose()
        setLoading(false)
        addExport("bulkChangeInsert", "Bulk Change Submission");
        bulkChangePolling(data)
      }
      else {
        Modal.error({
          title: 'Submit Error',
          content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting. Please try again.',
          centered: true,
        });
      }
    } finally {
      setLoading(false);
    }
  };
  
  const call_2_0_submit = async (parsedData: any , payload:any) => {
        try {
            const url = ENV_ROUTES.BULKCHANGE_PROCESSOR;
            const prevChangedData = payload?.changed_data || {}
            delete payload["imei"]
            delete payload["changed_data"]
            delete payload["Devices"]
            
            const payloadData={
                ...payload , 
                path:"/bulk_change_processor",
                request_received_at:getCurrentDateTime(),
                bulk_change_id:parsedData?.bulk_chnage_id_20,
            }
            const data = {...payloadData};
            const response = await axios.post(url, { data });
            const responseData = JSON.parse(response.data.body);
            if (responseData.flag === false) {
               console.log("Failure: 2.0 Bulk change update failed.");
            } else {
                console.log("Success: 2.0 Bulk change update successful.");
        }
    }
        catch (error) {
            console.error("Error running DB script:", error);
        } finally {
            setLoading(false);
        }
    }
  const call_2_0_sync = async (parsedData: any) => {
        try {
            const runDbScriptUrl = ENV_ROUTES.SIM_MANAGEMENT;
            const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
            const runDbScriptData = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/update_bulk_change_tables_10",
                role_name: role,
                module_name: "Bulk Change",
                access_token: token,
                db_name: selectedDb,
        ... metaData,
                sessionID: sessionId,
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                // service_provider_id: service_provider_id_,
                // bulkchange_id: parsedData?.bulkchange_id?.id,
                // data: parsedData?.data,
                data:{
                    bulk_change_id: parsedData?.bulk_chnage_id_20,
                },
                is_update: false,
                // bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
            };

            const runDbScriptResponse = await axios.post(runDbScriptUrl, { data: runDbScriptData });
            const runDbScriptResponseData = JSON.parse(runDbScriptResponse.data.body);

            if (runDbScriptResponseData.flag === false) {
                console.error("Data Fetch Error: " + runDbScriptResponseData.message);
            } else {
                console.log("Success: Bulk update successful.");
            }
        }
        catch (error) {
            console.error("Error running DB script:", error);
        } finally {
            setLoading(false);
        }
    }
  
  const callRunDbScript = async (parsedData:any) => {
    try {
      const service_provider_id_=parsedData?.bulkchange_id?.service_provider_id || 1
      const runDbData = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/run_db_script", // Always use this path
        role_name: role,
        module_name: "Bulk Change",
        mod_pages: {
          start: 0,
          end: 100,
        },
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        service_provider_id:service_provider_id_,
        bulkchange_id: parsedData?.bulkchange_id?.id,
        data: parsedData?.data,
        bulk_chnage_id_20: parsedData?.bulk_chnage_id_20
      };
  
      console.log("Run DB Data", runDbData);
  
      // Send the second request
      await axios.post(ENV_ROUTES.SIM_MANAGEMENT, { data: runDbData });
      console.log("Run DB script executed successfully.");
    } catch (error) {
      console.error("Error executing run_db_script:", error);
      // Optionally handle the error here, e.g., show a notification
    }
  };
  
  const handleAddIccid = () => {
    setIccidList([...iccidList, { iccid: '', ratePlanCode: '' }]);
  };

  const handleRemoveIccid = (index: number) => {
    setIccidList(iccidList.filter((_, i) => i !== index));
  };

  const handleIccidChange = (index: number, value: string) => {
    const newIccidList = [...iccidList];
    newIccidList[index].iccid = value;
    setIccidList(newIccidList);
  };

  const handleRatePlanCodeChange = (index: number, value: string) => {
    const newIccidList = [...iccidList];
    newIccidList[index].ratePlanCode = value;
    setIccidList(newIccidList);
    setErrorMessage("");
  };

  const fetchData = async (payload: { iccids: any; imeis: any; }) => {
    try {
      setLoading(true);
      const url =
        ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        path: "/get_new_bulk_change_data",
        request_received_at: getCurrentDateTime(),
        username: username,
        firstLastName: firstLastName,
        role_name: role,
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        service_provider: service_provider,
        change_type: change_type,
        imei: payload?.imeis || [],
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        setLoading(false);
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
        return false
      } else {
        const dropdownData_ = parsedData?.response_data?.dropdown_data || {}
        console.log("dropdownData_",dropdownData_)
        setDropdownData(dropdownData_)
        setLoading(false);
        return true
      }
    } catch (error) {
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
      setLoading(false);
      return false
    }
  };
  const handleSubmit = async() => {
    if (ApplicableRatePlanForAll) {
      let hasError = false;
  
      // Validate and split the input into an array
      const inputValues = iccidText
        .split(/\s*[\n,]\s*/) // Split by new line or comma
        .map((item) => item.trim()) // Trim spaces from each item
        .filter((item) => item.length > 0); // Remove empty strings
  
      // Check if input is empty
      if (inputValues.length === 0) {
        setIccidError("ICCID is required.");
        console.log("Validation failed: ICCID is required.");
        hasError = true;
      }
  
      const iccids: string[] = [];
      const imeis: string[] = [];
  
      // Separate input into ICCIDs and IMEIs alternately
      for (let i = 0; i < inputValues.length; i++) {
        const value = inputValues[i];

        if (i % 2 === 0) {
          // Even index: ICCID
          if (!/^\d+$/.test(value)) {
            setIccidError("Please enter numbers only for ICCID. Letters or special characters are not allowed");
            console.log("Validation failed: ICCID contains non-numeric characters.");
            hasError = true;
            break;
          } else if (value.length < 14 || value.length > 22) {
            setIccidError("Each ICCID must be between 14 and 22 digits long.");
            console.log("Validation failed: ICCID has invalid length.");
            hasError = true;
            break;
          } else {
            iccids.push(value);
          }
        } else {
          // Odd index: IMEI
          if (!/^\d+$/.test(value)) {
            setIccidError("IMEI must contain digits only.");
            console.log("Validation failed: IMEI contains non-numeric characters.");
            hasError = true;
            break;
          } else if (value.length < 12 || value.length > 22) {
            setIccidError("Each IMEI must be between 12 and 22 digits long.");
            console.log("Validation failed: IMEI has invalid length.");
            hasError = true;
            break;
          } else {
            imeis.push(value);
          }
        }
      }

      if (iccids.length > bulkChangeLimit || imeis.length > bulkChangeLimit){
        setIccidError(`This request exceeds the allowed record limit  of ${bulkChangeLimit} and cannot be processed`);
        console.log("Limit Exceeded");
        hasError = true;
      }
  
      if (hasError) {
        return; // Exit if any validation error occurred
      } else {
        setIccidError(""); // Clear error if validation passed
      }
  
      console.log("Valid ICCIDs: ", iccids);
      console.log("Valid IMEIs: ", imeis);
  
      // Prepare the payload
      const payload = {
        iccids: iccids, 
        imeis: imeis,
        Devices: iccids,
      };
  
      console.log("Payload:", payload);
      setsetActivationPayload(payload)
      if(isNextScreen){
      const isIMEIValidated = await fetchData(payload)
      console.log("isIMEIValidated",isIMEIValidated)
      if(isIMEIValidated){
        onClose()
      }
      return
    }else{
      // Pass payload to the submit function
                onsubmit(payload);
    }
      
    }
  };
  


  if (loading) {
    return (
      <div className="flex justify-center items-center h-[400px]">
        <Spin size="large" />
      </div>
    );
  }

  return (
    <div className="flex flex-col space-y-4 mt-4">
      <h2 className="text-500 font-semibold">Select devices</h2>
      {ApplicableRatePlanForAll ? (
        <>
          {/* Combined ICCID & IMEI field */}
          <div className="flex flex-col space-y-2">
            <label htmlFor="iccid-imei" className="font-semibold">ICCID & IMEI<span className="text-red-500">*</span></label>
            <Input.TextArea
              id="iccid-imei"
              rows={6}
              placeholder="Enter ICCID and IMEI (one per line, separated by comma)"
              value={iccidText}
              onChange={(e) => setIccidText(e.target.value)} />
            {iccidError && <div className="text-red-500 text-sm">{iccidError}</div>}
          </div>
        </>
      ) : (
        iccidList.map((item, index) => (
          <div key={index} className="flex space-x-4">
            <Input
              value={item.iccid}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleIccidChange(index, e.target.value)}
              placeholder="ICCID"
              className="w-1/2 h-10"
              required
            />
            {/* <Select
              showSearch
              value={item.ratePlanCode}
              onChange={(value: string) => handleRatePlanCodeChange(index, value)}
              // options={RatePlanCodeList?.map((ratePlanCode: string) => ({ value: ratePlanCode, label: ratePlanCode }))}
              options={RatePlanCodeList?.map((ratePlanCode: string) => ({ value: ratePlanCode, label: ratePlanCode }))}
              className="w-1/2 h-10"
            /> */}
            {iccidList.length > 1 && (
              <Button onClick={() => handleRemoveIccid(index)}>Remove</Button>
            )}
          </div>
        ))
      )}
      {!ApplicableRatePlanForAll && <Button onClick={handleAddIccid}>Add</Button>}
      {errorMessage && <div className="text-red-500">{errorMessage}</div>}
      <div className="flex justify-center space-x-4 mt-4">
        <button
          onClick={onBack}
          className="cancel-btn"
        >
          {/* <ArrowLeftIcon className="h-5 w-5 mr-2" /> */}
          Back
        </button>
        <button
          onClick={handleSubmit}
          className="save-btn"
        >
          {isNextScreen?"Continue":"Submit"}
        </button>
      </div>
    </div>

  );
};

export default ActivateSelectDevices;
