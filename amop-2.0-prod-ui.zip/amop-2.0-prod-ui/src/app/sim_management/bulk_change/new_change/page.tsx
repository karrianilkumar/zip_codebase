"use client";

import { FC, useState, lazy, Suspense, useEffect, Key } from "react";
import Select from "react-select";
import { Modal, Button, Spin } from "antd";
import { PlusIcon } from "@heroicons/react/24/outline";
import { DropdownStyles } from "@/app/components/css/dropdown";
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import UploadComponent from "./upload_component";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import React from "react";
import { useFeatureStore } from "../../inventory/featureStore";

const ArchiveContent = lazy(() => import("./archive_modal_main"));
const ArchiveSummary = lazy(() => import("./archive_modal_summary"));
const AssignCustomerContent = lazy(() => import("./assign_customer_modal_main"));
const ChangeCarrierRatePlan1 = lazy(() => import("./carrier_rate_plan_modal1"));
const ChangeCarrierRatePlan2 = lazy(() => import("./carrier_rate_plan_modal2"));
const ChangeCarrierRatePlan3 = lazy(() => import("./carrier_rate_plan_modal3"));
const ChangeCustomerRatePlan = lazy(() => import("./customer_rate_plan_modal_main"));
const EditUsername = lazy(() => import("./edit_username_modal_main"));
const ChangeICCIDContent = lazy(() => import("./change_iccid_modal_main"));
const ChangePhoneNumber = lazy(() => import("./change_phone_numbers_main"));
const ChangeDeviceStatus = lazy(() => import("./update_device_status_main"));
const ChangeDeviceStatus1 = lazy(() => import("./update_device_status_1"));
const NewService = lazy(() => import("./activate_service_main"));
const UpdatePPUAddress = lazy(() => import("./update_ppu_address_main"));
const UpdateFeatures = lazy(() => import("./update_features_main"));
const RefreshLine = lazy(() => import("./refresh_line_main"));
const IndividualLineSync = lazy(() => import("./individual_line_sync"));
interface NewChangeProps {
    isNavigated: boolean;
    qualification_id: any;
    features:any[];
}

const NewChange: React.FC<NewChangeProps> = ({ isNavigated, qualification_id,features }) => {
    const [isModalVisible, setIsModalVisible] = useState(isNavigated || false);
    const [selectedServiceProvider, setSelectedServiceProvider] = useState<string | null>(null);
    const [selectedAction, setSelectedAction] = useState<string | null>(null);
    const [showInitialScreen, setShowInitialScreen] = useState(true);
    const [errorMessage, setErrorMessage] = useState<string | null>(null);
    const [loading, setLoading] = useState(false);
    const [providerChangeTypemapping, setProviderChangeTypemapping] = useState<any>({})
    const [serviceProviderOptions, setServiceProviderOptions] = useState<any>([])
    const [changeTypeOptions, setChangeTypeOptions] = useState<any>([])
    const [dropdownData, setDropdownData] = useState<any>([])
    const [screenOrder, setScreenOrder] = useState<any>([])
    const [activationData, setActivationData] = useState<any>(null)
    const [isBPEnabled, setIsBPEnabled] = useState(false);
    const { username, role, partner, token, selectedDb, metaData, firstLastName, sessionId } = useAuth();
    const { setSimIdentifierMap } = useFeatureStore();

    const isAdmin = role?.toLowerCase() === "super admin" || role?.toLowerCase() === "partner admin"
    const editableDrp = DropdownStyles;
    const parseList = (value: any) => {
        if (typeof value === 'string') {
            let parsedPlans: any[];
            try {
                parsedPlans = JSON.parse(value)
            }
            catch (err) {
                console.log(err)
                parsedPlans = []
            }
            return Array.isArray(parsedPlans) ? parsedPlans : [];
        }
        if (Array.isArray(value)) {
            return value;
        }
        return [];
    };

    const fetchBpFlag = async () => {
        setLoading(true);
        try {
          const url = ENV_ROUTES.MODULE_MANAGEMENT;
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/get_cross_provider_optimization_status",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "Active Customer Rate Plan",
            feature_module_name: "Customer Rate Plans",
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
            ... metaData,
            sessionID: sessionId,
          };
          const response = await axios.post(url, { data });
          const parsedData = JSON.parse(response.data.body);
          if (parsedData.flag === false) {
            Modal.error({
              title: 'Data Fetch Error',
              content: parsedData.message || 'An error occurred while fetching data. Please try again.',
              centered: true,
            });
          } else {
            const billing_plaform_flag = parsedData?.billing_platform_flag || false
            setIsBPEnabled(billing_plaform_flag)
          }
        } catch (error) {
          console.error("Error fetching data:", error);
          Modal.error({
            title: 'Data Fetch Error',
            content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
            centered: true,
          });
        } finally {
          setLoading(false);
    
        }
      };

    useEffect(() => {
        if (isNavigated) {
            fetchActivationData();
        }

    }, [isNavigated]);

    //To get autopopulating data for Activate new service while navigated from service qualification
    const fetchActivationData = async () => {
        try {
            setLoading(true);
            const url =
                ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/qualification_data",
                role_name: role,
                Partner: partner,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
                ... metaData,
                sessionID: sessionId,
                qualification_id: qualification_id,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                setLoading(false);
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                const provider = parsedData?.service_provider || "AT&T - Telegence"
                setSelectedServiceProvider(provider)
                const change_type = parsedData?.change_type || "Activate New Service"
                setSelectedAction(change_type)
                const activation_data = parsedData?.activation_data || []
                setActivationData(activation_data)
                setLoading(false);
            }
        } catch (error) {
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
            setLoading(false);

        }
    };

    const fetchData = async () => {
        handleClearFields()
        try {
            setLoading(true);
            const url =
                ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_new_bulk_change_data",
                role_name: role,
                Partner: partner,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
                ... metaData,
                sessionID: sessionId,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                setLoading(false);
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                const providerChangeTypemapping_ = parsedData?.response_data?.new_change_SP_CT_map || {}
                setProviderChangeTypemapping(providerChangeTypemapping_)
                const sim_identifier_map = parsedData?.response_data?.sim_identifier_map || {}
                setSimIdentifierMap(sim_identifier_map)
                const serviceProviderOptions_ = Object.keys(providerChangeTypemapping_)
                setServiceProviderOptions(serviceProviderOptions_)
                setLoading(false);
            }
        } catch (error) {
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
            setLoading(false);

        }
    };

    const fetchChangeType = async () => {
        try {
            setLoading(true);
            const url =
                ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                path: "/get_new_bulk_change_data",
                request_received_at: getCurrentDateTime(),
                username: username,
                firstLastName: firstLastName,
                role_name: role,
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ... metaData,
                sessionID: sessionId,
                service_provider: selectedServiceProvider,
                change_type: selectedAction
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                setLoading(false);
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                const screen_order_ = parsedData?.response_data?.screen_names_seq || []
                const parsedOrder = parseList(screen_order_)
                setScreenOrder(parsedOrder)
                const dropdownData_ = parsedData?.response_data?.dropdown_data || {}
                setDropdownData(dropdownData_)
                setLoading(false);
            }
        } catch (error) {
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        }
    };

    const handleClearFields = () => {
        setSelectedServiceProvider('');
        setSelectedAction('');
        setShowInitialScreen(true);
        setErrorMessage(null);
    };

    const handleSelectServiceProvider = (selectedOption: any) => {
        if (selectedOption) {
            setSelectedAction('')
            const value = selectedOption?.value
            setSelectedServiceProvider(value);
            const changeTypeOptions_ = providerChangeTypemapping?.[value] || []
            const filteredOptions=changeTypeOptions_.filter((option:any)=>
                    features.some((feature)=> option==feature))
            setChangeTypeOptions(filteredOptions)
        }
        else {
            setSelectedServiceProvider(null);

        }
    };

    const handleSelectAction = (selectedOption: any) => {
        if (selectedOption) {
            const value = selectedOption?.value
            setSelectedAction(value);

        }
        else {
            setSelectedAction(null);

        }
    };

    const handleFinish = () => {
        setIsModalVisible(false);
        handleClearFields();
    };

    const showModal = () => {
        fetchData();
        setIsModalVisible(true);
    };

    const handleCancel = () => {
        setIsModalVisible(false);
        handleClearFields();
    };

    const handleContinue = async() => {
        if (!selectedServiceProvider || !selectedAction) {
            setErrorMessage("Please select both a Service Provider and a Change Type.");
        } else {
            await fetchBpFlag()
            fetchChangeType()
            setErrorMessage(null);
            setShowInitialScreen(false);
        }
    };

    const renderContent = () => {
        // if (!selectedServiceProvider || !selectedAction) return null;

        // const mapping = screen_mapping.find(
        //     (item) =>
        //         item.service_provider === selectedServiceProvider &&
        //         item.change_type === selectedAction
        // );

        // if (!mapping) return null;

        return screenOrder?.map((screen: any) => {
            switch (screen) {
                case "archive-main":
                    return <ArchiveContent
                        key={screen}
                        onContinue={handleFinish}
                        onBack={() => setShowInitialScreen(true)}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={selectedAction}
                        onCancel={handleCancel}
                    />;
                case "archive-summary":
                    // return <ArchiveSummary onBack={() => setShowInitialScreen(true)} onContinue={handleFinish} iccids={[]}/>;
                    return null;
                case "assign-customer-main":
                    return <AssignCustomerContent
                        key={screen}
                        onContinue={handleFinish}
                        onBack={() => setShowInitialScreen(true)}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={selectedAction}
                        isSubmitScreen={isBPEnabled}
                        onClose={handleCancel}
                    />;
                case "carrier-rate-plan-1":
                    return <ChangeCarrierRatePlan1
                        key={screen}
                        onContinue={handleFinish}
                        onBack={() => setShowInitialScreen(true)}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={selectedAction}
                        onClose={handleCancel} />;
                case "carrier-rate-plan-2":
                    return <ChangeCarrierRatePlan2
                        key={screen} onContinue={handleFinish}
                        onBack={() => setShowInitialScreen(true)}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={selectedAction}
                        onClose={handleCancel} />;
                case "carrier-rate-plan-3":
                    return <ChangeCarrierRatePlan3
                        key={screen}
                        onContinue={handleFinish}
                        onBack={() => setShowInitialScreen(true)}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={selectedAction} 
                        onClose={handleCancel}/>;
                case "customer-rate-plan-main":
                    return <ChangeCustomerRatePlan
                        key={screen}
                        onContinue={handleFinish}
                        onBack={() => setShowInitialScreen(true)}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={selectedAction} 
                        isSubmitScreen={isBPEnabled}
                        onClose={handleCancel}/>;
                case "edit-username-main":
                    return <EditUsername
                        key={screen}
                        onContinue={handleFinish}
                        onBack={() => setShowInitialScreen(true)}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={selectedAction}
                        onClose={handleCancel} />;
                case "iccid-imei-main":
                    return <ChangeICCIDContent
                        key={screen}
                        onContinue={handleFinish}
                        onBack={() => setShowInitialScreen(true)}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={selectedAction} 
                        onClose={handleCancel}/>;
                case "change-phone-number-main":
                    return <ChangePhoneNumber
                        key={screen}
                        onContinue={handleFinish}
                        onBack={() => setShowInitialScreen(true)}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={selectedAction} 
                        onClose={handleCancel}/>;
                case "device-status-main":
                    return <ChangeDeviceStatus
                        key={screen}
                        onContinue={handleFinish}
                        onBack={() => setShowInitialScreen(true)}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={selectedAction}
                        onClose={handleCancel} />;
                case "device-status-1":
                    return <ChangeDeviceStatus1
                        key={screen}
                        onContinue={handleFinish}
                        onBack={() => setShowInitialScreen(true)}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={selectedAction}
                        onClose={handleCancel} />;
                case "new-service-main":
                    return <NewService
                        key={screen}
                        onContinue={handleFinish}
                        onBack={() => setShowInitialScreen(true)}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={selectedAction}
                        activationData={activationData} 
                        isSubmitScreen={!isAdmin}
                        onClose={handleCancel}/>;
                case "update-ppu-address":
                    return <UpdatePPUAddress
                        key={screen}
                        onContinue={handleFinish}
                        onBack={() => setShowInitialScreen(true)}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={selectedAction}
                        activationData={activationData} 
                        isSubmitScreen={false}
                        onClose={handleCancel}/>;
                case "update-features":
                    return <UpdateFeatures
                        key={screen}
                        onContinue={handleFinish}
                        onBack={() => setShowInitialScreen(true)}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={selectedAction}
                        onClose={handleCancel} />;
                case "refresh-aline":
                    return <RefreshLine
                        key={screen}
                        onContinue={handleFinish}
                        onBack={() => setShowInitialScreen(true)}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={selectedAction}
                        onClose={handleCancel} />;
                case "select-devices":
                    return null;
                case "individual-line-sync":
                    return <IndividualLineSync
                        key={screen}
                        onContinue={handleFinish}
                        onBack={() => setShowInitialScreen(true)}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={selectedAction}
                        onClose={handleCancel} />;
                default:
                    return null;
            }
        });
    };

    const modalWidth = typeof window !== 'undefined' ? (window.innerWidth * 2.5) / 4 : 0;
    const modalHeight =
        typeof window !== "undefined" ? (window.innerHeight * 3) / 4 : 0;
    // if (loading) {
    //     return (
    // <>
    //     <Modal
    //         title="Loading"
    //         visible={isModalVisible}
    //         onCancel={handleCancel}
    //         footer={null}
    //         width={modalWidth}
    //         centered
    //     >
    //         <div className="flex justify-center items-center h-[400px]">
    //             <Spin size="large" />
    //         </div>
    //     </Modal>
    // </>
    //     );
    // }

    return (
        <>
            <button className="save-btn flex items-center" onClick={showModal}>
        <PlusIcon className="h-5 w-5 text-black-500" />
        <span className="hidden md:inline">New Change</span>
      </button>
            {loading ?
                (
                    <>
                        <Modal
                            title="Loading"
                            visible={isModalVisible}
                            onCancel={handleCancel}
                            footer={null}
                            width={'550px'}
                            centered
                        >
                            <div className="flex justify-center items-center h-[300px]">
                                <Spin size="large" />
                            </div>
                        </Modal>
                    </>
                ) : (
                    <>


                        <Modal
                            title={
                                // <span className="ml-4">{`Change type: ${ selectedAction ? selectedAction.charAt(0).toUpperCase() + selectedAction.slice(1).toLowerCase(): ""}`}</span>
                                <span className="ml-2">{`Change Type: ${selectedAction ? selectedAction : ''}`}</span>
                            }
                            visible={isModalVisible}
                            onCancel={handleCancel}
                            footer={null}
                            width={'550px'}
                            centered
                            maskClosable={false}
                            styles={{ body: { height: 'auto' } }}

                        >
                            <div className="modal-content container pt-3">
                                {showInitialScreen ? (
                                    <div className="flex flex-col space-y-4">
                                        <div>
                                            <label htmlFor="serviceProvider" className="field-label">Service Provider<span className="text-red-500">*</span></label>
                                            <Select
                                                id="serviceProvider"
                                                options={serviceProviderOptions.map((option: string) => ({
                                                    label: option,
                                                    value: option,
                                                }))}
                                                value={{ label: selectedServiceProvider, value: selectedServiceProvider }}
                                                onChange={handleSelectServiceProvider}
                                                placeholder="Select Service Provider"
                                                styles={editableDrp}
                                                isClearable
                                            />
                                            {errorMessage && !selectedServiceProvider && (
                                                <div >
                                                    <span className="text-red-500 mt-2">Please Select Service Provider</span>
                                                </div>
                                            )}
                                        </div>

                                        <div>
                                            <label htmlFor="action" className="field-label">Change Type<span className="text-red-500">*</span></label>
                                            <Select
                                                id="action"
                                                options={changeTypeOptions.map((option: string) => ({
                                                    label: option,
                                                    value: option,
                                                }))}
                                                value={{ label: selectedAction, value: selectedAction }}
                                                onChange={handleSelectAction}
                                                placeholder="Select Change Type"
                                                styles={editableDrp}
                                                isClearable
                                            />
                                            {errorMessage && !selectedAction && (
                                                <div >
                                                    <span className="text-red-500 mt-2">Please Select Change Type</span>
                                                </div>
                                            )}
                                        </div>


                                        <div className="justify-center flex space-x-4">
                                            <button onClick={handleCancel} className="cancel-btn">
                                                Cancel
                                            </button>
                                            <button onClick={handleContinue} className="save-btn">
                                                Continue
                                            </button>
                                        </div>
                                    </div>
                                ) : (
                                    <Suspense fallback={<div>Loading...</div>}>

                                        {renderContent()}

                                    </Suspense>
                                )}
                            </div>
                        </Modal>
                    </>
                )}
        </>

    );
};

export default NewChange;