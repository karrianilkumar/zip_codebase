import { FC, forwardRef, useEffect, useImperativeHandle, useRef, useState } from "react";
import { Input, Button, Select, Checkbox, Modal, Spin, Tooltip } from "antd";
import ReactSelect from 'react-select';
import { ArrowLeftIcon, ArrowRightIcon, ChevronDownIcon } from "@heroicons/react/24/outline";
import moment from "moment";
import { DatePicker } from "antd/lib";
import UploadComponent from "./upload_component";
import React from "react";
import ActivateSelectDevices from "./activate_new_select_devices";
import { useAuth } from "@/app/components/auth_context";
import { DropdownStyles } from "@/app/components/css/dropdown";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { useFeatureStore } from "../../inventory/featureStore";
import { useRouter } from 'next/navigation';
import SelectDevices from "./select_devices";
import { useAllChangeTypesStore } from "@/app/stores/allChangeTypesStore";
import { SelectContentRef } from "./select_devices";

interface UpdatePPUAddressProps {
    onContinue: () => void;
    onBack: () => void;
    dropdown: any;
    service_provider: any;
    change_type: any;
    activationData?: any;
    isSubmitScreen: boolean;
    onSave?: () => void;
    onClose: () => void;
}
export interface UpdatePPUAddressContentRef {
  runValidation: () => Promise<void> | void;
  runSubmit: ()=> Promise<void> | void;
  returnUpdate: () => React.ReactNode | Promise<React.ReactNode>;
}

const UpdatePPUAddress = forwardRef<UpdatePPUAddressContentRef, UpdatePPUAddressProps>(
    ({ onContinue, onBack, dropdown, service_provider, change_type, activationData, isSubmitScreen, onSave, onClose }, ref) => {
    const [dropdownData, setDropdownData] = useState<any>(dropdown || {});
    const [billingAccountNumber, setBillingAccountNumber] = useState<string | undefined>(undefined);
    const [selectedRole, setSelectedRole] = useState<string>("");
    const [city, setCity] = useState<string>("");
    const [streetName, setStreetName] = useState<string>("");
    const [streetNumber, setStreetNumber] = useState<any>("");
    const [streetDirection, setStreetDirection] = useState<string>("");
    const [showSelectDevices, setShowSelectDevices] = useState(false);
    const [isRedirected, setIsRedirected] = useState(false);
    const [errors, setErrors] = useState<{ [key: string]: string }>({});
    const [subscribeFirstName, setSubscribeFirstName] = useState<string>("");
    const [subscribeLastName, setSubscribeLastName] = useState<string>("");
    const [zipCode, setZipCode] = useState<any | null>(null);
    const [roleOptions, setRoleOptions] = useState<any>([]);
    const [stateOptions, setStateOptions] = useState<any>([]);
    const [selectedStateCode, setSelectedStateCode] = useState("");
    const { username, role, partner, token, selectedDb, firstLastName, sessionId } = useAuth();
    const [loading, setLoading] = useState(false);
    const router = useRouter();
    const { isAllChangeType,setIsValidated,setValidationTrigger, setsuccessFullChangeTypes, activeChange, successFullChangeTypes  } = useAllChangeTypesStore();
    const selectDevicesRef = useRef<SelectContentRef>(null);
    const [saveChanges, setSaveChanges] = useState<boolean>(true);

    useEffect(()=>{
        if(isAllChangeType){
            setDropdownData(dropdown)
        }
    },[dropdown,isAllChangeType])
    
    useEffect(() => {

        const state = dropdownData?.state || [];

        // Map state array to options with 'name' as label and 'code' as value
        const stateOptions = state.map((item: any) => ({
            label: item.name,  // Display state name in the dropdown
            value: item.code,  // Use state code as the value
        }));

        setStateOptions(stateOptions);

    }, [dropdownData]);

        const handleContinue = () => {
            const newErrors: { [key: string]: string } = {};

            // Check for errors in the required fields
            if (!billingAccountNumber) newErrors.billingAccountNumber = "Billing account number is required.";
            if (!selectedRole) newErrors.role = "Role is required.";
            if (!subscribeFirstName) newErrors.subscribeFirstName = "Subscribe first name is required.";
            if (!subscribeLastName) newErrors.subscribeLastName = "Subscribe last name is required.";
            if (!streetNumber) newErrors.streetNumber = "Street number is required.";
            if (!streetName) newErrors.streetName = "Street name is required.";
            if (!city) newErrors.city = "City is required.";
            if (!zipCode) newErrors.zipCode = "Zip code is required.";
            if (zipCode) {
                const regex = /^\d{5}$/; // Only 5 numerical values

                if (!regex.test(zipCode)) {
                    newErrors.zipCode = "Zip code must be exactly 5 digits."
                }
            }
            if (!selectedStateCode) {
                newErrors.state = "State is required.";
            }
            // If there are errors, set them in the state; otherwise, proceed
            if (Object.keys(newErrors).length > 0) {
                setsuccessFullChangeTypes(
                    successFullChangeTypes.filter((c: any) => c !== activeChange)
                );
                if (isAllChangeType) {
                    if (
                        !billingAccountNumber &&
                        selectedRole === "" &&
                        city === "" &&
                        streetName === "" &&
                        streetNumber === "" &&
                        streetDirection === "" &&
                        !showSelectDevices &&
                        !isRedirected &&
                        subscribeFirstName === "" &&
                        subscribeLastName === "" &&
                        (zipCode === null || zipCode === "") &&
                        selectedStateCode === ""
                    ) {
                        setErrors({});
                        setIsValidated(true)
                        setValidationTrigger();
                        return
                    }
                    else {
                        setIsValidated(false)
                        setErrors(newErrors);
                        setValidationTrigger();
                        return
                    }

                }
                else {
                    setErrors(newErrors);
                }
            } else {
                setErrors({});
                if (isAllChangeType) {
                    if (saveChanges) {
                        setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
                    }
                    setIsValidated(true)
                    setValidationTrigger()
                }
                else {
                    setShowSelectDevices(true);
                }
            }
        };

    const handleRoleChange = (selectedOption: any) => {
        if (selectedOption) {
            const value = selectedOption
            setSelectedRole(value)
        }
    }
    const handleSelectedStateChange = (value: any) => {
        // 'value' is the state code, so set it to selectedStateCode
        setSelectedStateCode(value);
    };
    const handleBack = () => {
        setShowSelectDevices(false);
    };
    const returnChangedData = () => {

        const changedData = {
            UserAddress: {
                billingAccount: {
                    id: billingAccountNumber || ""
                },
                relatedParty: {
                    role: selectedRole || "subscriber",
                    firstName: subscribeFirstName || "",
                    lastName: subscribeLastName || "",
                    address:
                    {
                        streetNumber: streetNumber || "",
                        streetDirection: streetDirection || "",
                        streetName: streetName || "",
                        streetType: "",
                        city: city || "",
                        state: selectedStateCode || "",
                        zipCode: zipCode || ""
                    }

                }
            }

        }
        // const changeedData = {
        //     assign_customer: selectedcustomer || null,
        //     TelegenceActivationRequest: {
        //         billingAccount: {
        //             id: isAdmin ? billingAccountNumber : dropdownData?.user_billing_account_number || "287256845357"
        //         },
        //         relatedParty: [
        //             {
        //                 id: "",
        //                 role: "subscriber",
        //                 firstName: subscribeFirstName || "",
        //                 lastName: subscribeLastName || "",
        //                 address: {
        //                     streetNumber: streetNumber || "",
        //                     streetDirection: streetDirection || "",
        //                     streetName: streetName || "",
        //                     streetType: "",
        //                     city: city || "",
        //                     state: selectedStateCode || "",
        //                     zipCode: zipCode || ""
        //                 }
        //             }
        //         ],
        //         service: {
        //             category: {
        //                 id: "",
        //                 name: ""
        //             },
        //             name: "",
        //             serviceSpecification: {
        //                 id: "12",
        //                 href: "Mobility Services"
        //             },
        //             serviceQualification: {},
        //             serviceCharacteristic: [
        //                 { name: "serviceZipCode", value: zipCode },
        //                 { name: "singleUserCode", value: null },
        //                 { name: "equipmentType", value: "G" },
        //                 { name: "deviceTechnologyType", value: "UMTS" },
        //                 { name: "IMEI", value: "" },
        //                 { name: "sim", value: "" },
        //                 // Add offeringCode entries from selectedFeatureCode
        //                 ...selectedFeatureCode.map((fullValue, index) => {
        //                     const parts = fullValue.split('--');
        //                     const code = parts.length > 1 ? parts[1].trim() : fullValue.trim(); // fallback to fullValue if '--' is missing

        //                     return {
        //                         name: `offeringCode${index + 1}`,
        //                         value: code,
        //                     };
        //                 }),

        //             ],
        //             status: "",
        //             subscriberNumber: ""
        //         }
        //     },
        //     CarrierDataGroup: "",
        //     CarrierRatePool: selectedRatePool && selectedRatePool !== 'No options' ? selectedRatePool : "",
        //     AddCustomerRatePlan: false,
        //     CustomerRatePlan: typeof ratePlanCode_ === "string" && !ratePlanCode_.startsWith("missing-code") ? ratePlanCode_ : null,
        //     // CustomerRatePool: selectedRatePool && selectedRatePool !== 'No options' ? selectedRatePool : null,
        //     ...staticIpAddressCheckbox ? {
        //         StaticIPProvision: {
        //             PDPName: selectedPDP || null,
        //             IPAddressCode: "T01", // Defaulted to T01
        //             LteIndicator: LTEDevice,
        //             DefaultAPN: false, //Defaulted to false
        //             StaticIPAPN: selectedAPN || null
        //         }
        //     } : { StaticIPProvision: null }

        // }
        return changedData
    };

    const returnUpdatedValue = () => {
            const newValue: any = {
                "firstName": subscribeFirstName,
                "lastName": subscribeLastName,
                "streetNumber": streetNumber,
                "streetName": streetName,
                "streetDirection": streetDirection,
                "city": city,
                "state": selectedStateCode,
                "zipCode": zipCode,
            }
            const displayOrder = [
                "firstName",
                "lastName",
                "streetNumber",
                "streetName",
                "streetDirection",
                "city",
                "state",
                "zipCode",
            ];
            const tooltipContent = (
                <div style={{ padding: "4px 8px" }}>
                    {displayOrder.map((key) => (
                        <div key={key} style={{ display: "flex", marginBottom: 2 }}>
                            <strong style={{ marginRight: 6, textTransform: "capitalize" }}>
                                {key.replace(/([A-Z])/g, " $1").trim()}&nbsp;&nbsp;:&nbsp;
                            </strong>
                            <span>
                                {newValue[key] !== undefined && newValue[key] !== ""
                                    ? String(newValue[key])
                                    : "N/A"}
                            </span>
                        </div>
                    ))}
                </div>
            );
            return (
                <div className="flex flex-col gap-2">
                    <div className="flex grid grid-cols-2 ">
                        <span className="font-semibold">Billing Account Number:</span>
                        <span>{billingAccountNumber}</span>
                        <span className="font-semibold">Role:</span>
                        <span>{selectedRole ? selectedRole : ""}</span>
                    </div>
                    <div className="flex justify-start"> {/* Center horizontally */}
                        <Tooltip title={tooltipContent}>
                            <span className="cursor-pointer font-semibold">Address Details</span>
                        </Tooltip>
                    </div>
                </div>
            )
        }
    useImperativeHandle(ref, () => ({
        runValidation: handleContinue,
        runSubmit: () => {
            selectDevicesRef.current?.runSubmit();
        },
        returnUpdate: returnUpdatedValue
    }));

    if (loading) {
        return (
            <div className="flex justify-center items-center h-[400px]">
                <Spin size="large" />
            </div>
        );
    }

    return (
        <div className="ActiveNewService px-3">
            {/* {!showSelectDevices ? ( */}
                <>
                <div className={showSelectDevices ? "hidden" : "block"}>
                    <div className="flex justify-end px-4">
                    {isAllChangeType && (
                        <div className="mt-3 mr-2">
                            <span className="mr-2 font-semibold">Save Changes</span>
                            <Checkbox
                                checked={saveChanges}
                                onChange={(e) => {
                                    if (!e.target.checked) {
                                        setsuccessFullChangeTypes(
                                            successFullChangeTypes.filter((c: any) => c !== activeChange)
                                        );
                                    }
                                    setSaveChanges(e.target.checked)
                                }}
                                className="custom-checkbox"
                            >

                            </Checkbox>
                        </div>
                    )}
                    <UploadComponent
                        service_provider={service_provider}
                        change_type={change_type}
                        changed_data={{
                            ...returnChangedData(),
                        }} />
                    </div>
                    
                    <div className={`${!isAllChangeType?"flex flex-col space-y-4 my-4":"flex grid grid-cols-2 gap-4 mt-2"}`}>
                        {
                            <>
                                {/* Billing Account Number */}
                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="billingAccountNumber" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        Billing Account Number<span className="text-red-500">*</span>
                                    </label>
                                    <Input
                                        id="billingAccountNumber"
                                        // placeholder="Enter Billing Account Number"
                                        value={billingAccountNumber}
                                        onChange={(e) => setBillingAccountNumber(e.target.value)}
                                        className={`${!isAllChangeType?"w-2/3 ActiveServiceinput":"input"}`} />
                                        {(errors.billingAccountNumber && isAllChangeType) && <span className="text-red-500">{errors.billingAccountNumber}</span>}
                                </div>
                                {(errors.billingAccountNumber && !isAllChangeType) && <div className="text-red-500">{errors.billingAccountNumber}</div>}

                                {/* Role */}
                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="role" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        Role<span className="text-red-500">*</span>
                                    </label>
                                    <Input
                                        id="role"
                                        // placeholder="Enter First Name"
                                        value={selectedRole}
                                        onChange={(e) => setSelectedRole(e.target.value)}
                                        className={`${!isAllChangeType?"w-2/3 ActiveServiceinput":"input"}`} />
                                        {(errors.role && isAllChangeType) && <span className="text-red-500">{errors.role}</span>}
                                </div>
                                {(errors.role && !isAllChangeType) && <div className="text-red-500">{errors.role}</div>}
                                {/* <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="ratePlanGroup" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        Role
                                    </label>
                                    <Select
                                        showSearch
                                        value={selectedRole === 'No options' ? null : { label: selectedRole, value: selectedRole }}
                                        id="ratePlanGroup"
                                        // placeholder="Select Rate Plan Group"
                                        options={roleOptions > 0 ? roleOptions.map((option: string) => ({
                                            label: option,
                                            value: option,
                                        })) : [{ value: 'No options', label: 'No options' }]}
                                        onChange={handleRoleChange}
                                        suffixIcon={
                                            <ChevronDownIcon className="w-4 h-4 text-gray-600 arrow " />
                                        }
                                        className="w-2/3 mt-1 mb-2" />
                                </div> */}

                                {/* Subscriber First Name */}
                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="subscribeFirstName" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        Subscriber First Name<span className="text-red-500">*</span>
                                    </label>
                                    <Input
                                        id="subscribeFirstName"
                                        // placeholder="Enter First Name"
                                        value={subscribeFirstName}
                                        onChange={(e) => setSubscribeFirstName(e.target.value)}
                                        className={`${!isAllChangeType?"w-2/3 ActiveServiceinput":"input"}`} />
                                        {(errors.subscribeFirstName && isAllChangeType) && <span className="text-red-500">{errors.subscribeFirstName}</span>}
                                </div>
                                {(errors.subscribeFirstName && !isAllChangeType) && <div className="text-red-500">{errors.subscribeFirstName}</div>}

                                {/* Subscriber Last Name */}
                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="subscribeLastName" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        Subscriber Last Name<span className="text-red-500">*</span>
                                    </label>
                                    <Input
                                        id="subscribeLastName"
                                        // placeholder="Enter Last Name"
                                        value={subscribeLastName}
                                        onChange={(e) => setSubscribeLastName(e.target.value)}
                                        className={`${!isAllChangeType?"w-2/3 ActiveServiceinput":"input"}`} />
                                        {(errors.subscribeLastName && isAllChangeType) && <span className="text-red-500">{errors.subscribeLastName}</span>}
                                </div>
                                {(errors.subscribeLastName && !isAllChangeType) && <div className="text-red-500">{errors.subscribeLastName}</div>}

                                {/* Street Number */}
                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="streetNumber" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        Street Number<span className="text-red-500">*</span>
                                    </label>
                                    <Input
                                        id="streetNumber"
                                        // placeholder="Enter Street Number"
                                        value={streetNumber}
                                        onChange={(e) => setStreetNumber(e.target.value)}
                                        className={`${!isAllChangeType?"w-2/3 ActiveServiceinput":"input"}`} />
                                        {(errors.streetNumber && isAllChangeType) && <span className="text-red-500">{errors.streetNumber}</span>}
                                </div>
                                {(errors.streetNumber && !isAllChangeType) && <div className="text-red-500">{errors.streetNumber}</div>}

                                {/* Street Direction */}
                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="streetDirection" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        Street Direction
                                    </label>
                                    <Input
                                        id="streetDirection"
                                        // placeholder="Enter Street Direction"
                                        value={streetDirection}
                                        onChange={(e) => setStreetDirection(e.target.value)}
                                        className={`${!isAllChangeType?"w-2/3 ActiveServiceinput":"input"}`} />
                                        {(errors.streetDirection && isAllChangeType) && <span className="text-red-500">{errors.streetDirection}</span>}
                                </div>
                                {(errors.streetDirection && !isAllChangeType) && <div className="text-red-500">{errors.streetDirection}</div>}

                                {/* Street Name */}
                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="streetName" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        Street Name<span className="text-red-500">*</span>
                                    </label>
                                    <Input
                                        id="streetName"
                                        // placeholder="Enter Street Name"
                                        value={streetName}
                                        onChange={(e) => setStreetName(e.target.value)}
                                        className={`${!isAllChangeType?"w-2/3 ActiveServiceinput":"input"}`} />
                                        {(errors.streetName && isAllChangeType) && <span className="text-red-500">{errors.streetName}</span>}
                                </div>
                                {(errors.streetName && !isAllChangeType) && <div className="text-red-500">{errors.streetName}</div>}

                                {/* City */}
                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="city" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        City<span className="text-red-500">*</span>
                                    </label>
                                    <Input
                                        id="city"
                                        // placeholder="Enter City"
                                        value={city}
                                        onChange={(e) => setCity(e.target.value)}
                                        className={`${!isAllChangeType?"w-2/3 ActiveServiceinput":"input"}`} />
                                    {(errors.city && isAllChangeType) && 
                                    <span className="text-red-500">{errors.city}</span>}
                                </div>
                                {(errors.city && !isAllChangeType) && <div className="text-red-500">{errors.city}</div>}

                                {/* State */}
                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="state" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        State<span className="text-red-500">*</span>
                                    </label>
                                    <Select
                                        showSearch
                                        value={selectedStateCode || null}
                                        id="state"
                                        // placeholder="Select State"
                                        options={stateOptions.length > 0 ? stateOptions : [{ value: 'No options', label: 'No options' }]}
                                        onChange={handleSelectedStateChange}
                                        suffixIcon={
                                            <ChevronDownIcon className="w-4 h-4 arrow  text-gray-600" />
                                        }
                                        className={`${!isAllChangeType?"w-2/3 mb-2":"w-full"}`} />
                                        {(errors.state && isAllChangeType) && <span className="text-red-500">{errors.state}</span>}
                                </div>
                                {(errors.state && !isAllChangeType) && <div className="text-red-500">{errors.state}</div>}

                                {/* Zip Code */}
                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="zipCode" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        Zip Code<span className="text-red-500">*</span>
                                    </label>
                                    <Input
                                        id="zipCode"
                                        // placeholder="Enter Zip Code"
                                        value={zipCode}
                                        onChange={(e) => setZipCode(e.target.value)}
                                        className={`${!isAllChangeType?"w-2/3  mt-1 ActiveServiceinput":"input"}`} />
                                        {(errors.zipCode && isAllChangeType) && <span className="text-red-500">{errors.zipCode}</span>}
                                </div>
                                {(errors.zipCode && !isAllChangeType) && <div className="text-red-500">{errors.zipCode}</div>}

                            </>
                        }
                        {/* Action Buttons */}
                        {!isAllChangeType && (
                            <div className="justify-center flex space-x-4 mt-4">
                            <button onClick={onBack} className="cancel-btn">
                                {/* <ArrowLeftIcon className="h-5 w-5 mr-2" /> */}
                                Back
                            </button>
                            <button onClick={handleContinue} className="save-btn">
                                Continue
                                {/* <ArrowRightIcon className="h-5 w-5 mr-2" /> */}
                            </button>
                        </div>
                        )}
                        
                    </div>
                </div>
                </>
            {/* ) : ( */}
                <div className={showSelectDevices ? "block" : "hidden"}>
                <SelectDevices
                    ref={selectDevicesRef} 
                    onContinue={onContinue}
                    onBack={handleBack}
                    service_provider={service_provider}
                    change_type={change_type}
                    changed_data={returnChangedData()}
                    onCancel={onClose}  
                />
                </div>
            {/* )} */}
        </div>
    );
}
)

export default UpdatePPUAddress;
