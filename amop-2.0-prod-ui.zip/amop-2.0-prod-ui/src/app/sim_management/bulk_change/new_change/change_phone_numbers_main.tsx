"use client";

import { FC, useEffect, useState } from "react";
import Select from "react-select";
import { Checkbox, message, Modal, notification, Spin, Upload } from "antd";
import 'tailwindcss/tailwind.css';
import { useRouter } from "next/navigation";
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { useFeatureStore } from "../../inventory/featureStore";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { ArrowUpTrayIcon } from "@heroicons/react/24/outline";
import { DownloadOutlined, UploadOutlined } from "@ant-design/icons";

interface ChangePhoneNumberProps {
    onContinue: (customerName: string) => void;
    onBack: () => void;
    dropdown: any;
    service_provider: any;
    change_type: any;
    onClose: () => void;
}

type SelectOption = { value: string; label: string };

const messageStyle = {
    fontSize: '14px',
    fontWeight: 'bold',
    padding: '16px',
};

const ChangePhoneNumber: FC<ChangePhoneNumberProps> = ({ onContinue, onBack, dropdown, service_provider, change_type, onClose }) => {
    const [subscriberNumber, setSubscriberNumber] = useState("");
    const [errorMessage, setErrorMessage] = useState<string | null>(null);
    const [loading, setLoading] = useState(false);
    const router = useRouter();
    const { setRowId, setBulkRow, bulkChangeLimit } = useFeatureStore();
    const { username, role, partner, token, selectedDb,metaData, firstLastName, sessionId, modulesVersionMap } = useAuth();
    const [currentDate, setCurrentDate] = useState('');
    const initial_version_flag = modulesVersionMap?.["Sim Management-Bulk Change"] || false
    const isVersionEnabled = localStorage.getItem("switch_user_2_0_bulk_change") === "True";
    const switch_user_2_0 = isVersionEnabled && initial_version_flag ? "True" : "False"
    const { addExport, removeExport, exports } = exportLoadingStore();

    //Upload States
    const [isUploadModalVisible, setIsUploadModalVisible] = useState(false);
    const [uploadKey, setUploadKey] = useState(Date.now());

    useEffect(() => {
        // Get the current date in MM/DD/YYYY format
        const date = new Date();
        const formattedDate =
            `${(date.getMonth() + 1).toString().padStart(2, '0')}/${date.getDate().toString().padStart(2, '0')}/${date.getFullYear()}`;
        setCurrentDate(formattedDate);
    }, []);

    const callMismatchICCID = async (parsedData: any) => {
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/bulk_change_validation_update",
            role_name: role,
            module_name: "Bulk Change",
            access_token: token,
            db_name: selectedDb,
        ... metaData,
            sessionID: sessionId,
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            bulkchange_id: parsedData?.bulkchange_id?.id,
            bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
        };

        const response = await axios.post(url, { data });
        const parsedResponse = JSON.parse(response.data.body);

        if (parsedResponse.flag === false) {
            console.error("Data Fetch Error mismatch ICCID: " + parsedResponse.message);
        } else {
            console.log("Success: Bulk update successful.");
        }
    }

    const callSyncLambda = async (bulkChangeID: any) => {
        try {
            const url = ENV_ROUTES.OPTIMIZATION_SYNC_LAMBDA;
            const data = {
                key_name: "change_phone_number_sync",
                path: "/lambda_sync_jobs_",
                tenant_name: partner,
                bulk_change_id: bulkChangeID
            };

            const response = await axios.post(url, { data });
            const responseData = JSON.parse(response.data.body);

            if (responseData.flag === false) {
                console.error("Data Fetch Error: " + responseData.message);
            } else {
                console.log("Success: Bulk update successful.");
            }
        } catch (error) {
            console.error("Error fetching data:", error);
        }
    };

    const call_2_0_submit = async (parsedData: any, payload: any) => {
        try {
            const url = ENV_ROUTES.BULKCHANGE_PROCESSOR;
            const payloadData = {
                ...payload,
                path: "/bulk_change_processor",
                request_received_at: getCurrentDateTime(),
                bulk_change_id: parsedData?.bulk_chnage_id_20,
            }
            const data = { ...payloadData };
            const response = await axios.post(url, { data });
            const responseData = JSON.parse(response.data.body);
            if (responseData.flag === false) {
                console.log("Failure: 2.0 Bulk change update failed.");
            } else {
                console.log("Success: 2.0 Bulk change update successful.");
            }
        }
        catch (error) {
            console.error("Error running DB script:", error);
        } finally {
            setLoading(false);
        }
    }
    const call_2_0_sync = async (parsedData: any) => {
        try {
            const runDbScriptUrl = ENV_ROUTES.SIM_MANAGEMENT;
            const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
            const runDbScriptData = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/update_bulk_change_tables_10",
                role_name: role,
                module_name: "Bulk Change",
                access_token: token,
                db_name: selectedDb,
        ... metaData,
                sessionID: sessionId,
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                // service_provider_id: service_provider_id_,
                // bulkchange_id: parsedData?.bulkchange_id?.id,
                // data: parsedData?.data,
                data: {
                    bulk_change_id: parsedData?.bulk_chnage_id_20,
                },
                is_update: false,
                // bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
            };

            const runDbScriptResponse = await axios.post(runDbScriptUrl, { data: runDbScriptData });
            const runDbScriptResponseData = JSON.parse(runDbScriptResponse.data.body);

            if (runDbScriptResponseData.flag === false) {
                console.error("Data Fetch Error: " + runDbScriptResponseData.message);
            } else {
                console.log("Success: Bulk update successful.");
            }
        }
        catch (error) {
            console.error("Error running DB script:", error);
        } finally {
            setLoading(false);
        }
    }
    const bulkChangeInsert = async (payload: any) => {
        let partner_name = partner
        let db_name_ = selectedDb
        try {
            const url = ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner_name || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_bulk_change_insertion",
                role_name: role,
                module_name: "Bulk Change History",
                service_provider_name: service_provider,
                change_type: change_type,
                access_token: token,
                db_name: selectedDb,
        ... metaData,
                sessionID: sessionId,
                request_received_at: getCurrentDateTime(),
                Partner: partner_name,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === false) {
                console.error("Error fetching bulk change data:", parsedData.message ||
                    "An error occurred while fetching bulk change data. Please try again.");
                return false
            } else {
                const statusFlag = parsedData?.bulk_change_data?.status || "";
                const response_data = parsedData?.bulk_change_data?.bulk_change_data || "{}";
                const parsedResp = JSON.parse(response_data)
                console.log("status_flag", statusFlag)
                const status_flag = statusFlag ? (statusFlag).toLowerCase() : ""

                if (status_flag && status_flag === "pending") {
                    return false
                }
                else if (status_flag && status_flag === "success") {
                    call_2_0_submit(parsedResp, payload)
                    call_2_0_sync(parsedResp)
                    return true
                }
                else if (status_flag && status_flag === "error") {
                    Modal.error({
                        title: 'Submit Error',
                        content: parsedData.message || 'An error occurred while submitting. Please try again.',
                        centered: true,
                    });
                    return true
                }
                else {
                    return false
                }
            }
        } catch (error) {
            console.error("Error fetching auto refresh data:", error);
            return false
        } finally {
        }
    };
    const bulkChangePolling = async (data: any) => {
        const result = await bulkChangeInsert(data);
        if (!result) {
            setTimeout(() => bulkChangePolling(data), 5000); // Try again after 5 seconds
        } else {
            removeExport("bulkChangeInsert");
            console.log("Auto-refresh complete.");
        }
        // if (window.location.pathname.includes("/sim_management/bulk_change")) {
        //     window.location.reload();
        // }
    };

    const onsubmit = async (oldValues: string[]) => {
        let data: any
        try {
            setLoading(true);

            const url = ENV_ROUTES.SIM_MANAGEMENT;
            data = {
                tenant_name: partner || "default_value",
                path: "/update_bulk_change_data",
                role_name: role,
                username: username,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
        ... metaData,
                sessionID: sessionId,
                service_provider: service_provider,
                change_type: change_type,
                created_by: firstLastName,
                changed_data: {
                    old_msisdn: oldValues,
                    new_msisdn: oldValues,
                    effective_date: currentDate,
                }
            };

            // Send request to the first API
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === false) {
                setLoading(false);
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
                return;
            }
            else {

                const data = {
                    tenant_name: partner || "default_value",
                    path: "/bulk_update_change_phone_number",
                    request_received_at: getCurrentDateTime(),
                    access_token: token,
                    db_name: selectedDb,
        ... metaData,
                    sessionID: sessionId,
                    service_provider: service_provider,
                    change_type: change_type,
                    created_by: firstLastName,
                    bulk_change_id: parsedData?.bulk_chnage_id_20,
                    msisdns: oldValues,
                    changed_data: {
                        old_msisdn: oldValues,
                        new_msisdn: oldValues,
                        effective_date: currentDate,
                    }
                };
                // if (switch_user_2_0 === "True") {
                    call_2_0_submit(parsedData, data)
                    call_2_0_sync(parsedData)
                // }
                // else {
                    // const url = ENV_ROUTES.SM_BULK_CHANGE;
                    // // Send request to the first API
                    // const smResponse = await axios.post(url, { data });
                    // const smParsedData = JSON.parse(response.data.body);
                    // callSyncLambda(parsedData?.bulk_chnage_id_20)

                // }
            }

            const bulkrow_ = parsedData?.bulkchange_id || {};
            const bulkRow: any = { row: bulkrow_ };
            setBulkRow(bulkRow);
            localStorage.setItem('bulk_row', JSON.stringify(bulkRow || "{}"));
            if (bulkRow) {
                router.push(`/sim_management/bulk_history`);
            }
        } catch (error) {
            if (switch_user_2_0 === "True") {
                onClose()
                setLoading(false)
                addExport("bulkChangeInsert", "Bulk Change Submission");
                bulkChangePolling(data)
            }
            else {
                Modal.error({
                    title: 'Submit Error',
                    content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting. Please try again.',
                    centered: true,
                });
            }
        } finally {
            setLoading(false);
        }
    };
    const handleSubmit = async () => {
        let valid = false
        if (!subscriberNumber) {
            valid = false
            setErrorMessage("Please fill new ICCID field or new IMEI field.");
        } else {
            valid = true
            setErrorMessage(null);
            // onContinue(newICCID);
        }
        if (valid) {
            const devices = subscriberNumber || "";
            let errorMessages: Set<string> = new Set();
            let hasError = false;


            const oldValues = devices.split("\n")
            // Validate Subscriber Numbers
            for (const subscriber of oldValues) {
                const value = subscriber.trim();

                if (value.length === 0) {
                    errorMessages.add("Subscriber Number must not be empty.");
                    hasError = true;
                } else if (!/^\d+$/.test(value)) {
                    errorMessages.add("Please enter numbers only for Subscriber Number. Letters or special characters are not allowed");
                    hasError = true;
                } else if (value.length < 10 || value.length > 18) {
                    errorMessages.add("Subscriber Number must be between 10 and 18 digits long.");
                    hasError = true;
                }
                if (oldValues.length > bulkChangeLimit) {
                    errorMessages.add(`This request exceeds the allowed record limit  of ${bulkChangeLimit} and cannot be processed`);
                    console.log("Limit Exceeded");
                    hasError = true;
                }
            }
            // Final check
            if (hasError) {
                setErrorMessage(Array.from(errorMessages).join(" "));
            } else {
                setErrorMessage(null);
                    onsubmit(oldValues);
            }
        }
    };

    //Upload Functions

    const downloadBlob = (base64Blob: string) => {
        // Remove prefix if present
        const base64Data = base64Blob.split(',').pop() || base64Blob;

        const byteCharacters = atob(base64Data);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);

        const blobObject = new Blob([byteArray], {
            type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blobObject);
        link.download = 'Change Phone Number.xlsx';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const handleChange = (info: any) => {
        if (info.file.status === 'done') {
            let blob;
            const file = info.file.originFileObj; // Get the file object
            const reader = new FileReader();
            reader.onload = (e: any) => {
                // Get the file data URL (Base64 string)
                blob = e.target.result;
                console.log('File Base64 String:', blob);
                handleUpload(blob)
                setUploadKey(Date.now());
            };

            if (blob) {
            }

            reader.readAsDataURL(file); // Read the file as data URL
        } else if (info.file.status === 'error') {
            // Handle upload error
            message.error('Upload failed.');
        }
    };
    const uploadProps = {
        key: uploadKey,
        accept: '.xlsx, .xls',
        beforeUpload: (file: any) => {
            // Check if file is an Excel file
            const isExcel = file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || file.type === 'application/vnd.ms-excel';
            if (!isExcel) {
                message.error('You can only upload Excel files!');
            }
            return isExcel;
        },
        onChange: handleChange,
    };
    const handleUpload = async (blob: string) => {
        setLoading(true)
        try {
            const url = ENV_ROUTES.SIM_MANAGEMENT;

            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/bulk_upload_change_phone_number",
                module_name: "Change Phone Number",
                role_name: role,
                Partner: partner,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
        ... metaData,
                sessionID: sessionId,
                blob: blob, // Include the Blob in the data
            };

            const response = await axios.post(url, { data });

            const response_data= JSON.parse(response.data.body);
            const parsedData = response_data?.data || {}
            if (response.data.statusCode === 200) {
                if (parsedData.flag === false) {
                    setLoading(false);
                    Modal.error({
                        title: 'Import Error',
                        content: parsedData.message,
                        centered: true,
                        onOk: handleErrorModalClose,
                        onCancel: handleErrorModalClose
                    });
                    return;
                }
                else {

                    const oldValues = response_data?.msisdns || []
                    onsubmit(oldValues)
                }
            }
            else {
                Modal.error({
                    title: 'Upload Error',
                    content: parsedData.message,
                    centered: true,
                    onOk: handleErrorModalClose,
                    onCancel: handleErrorModalClose
                });
            }



        } catch (error) {
            console.error('Error during file upload:', error);
            Modal.error({
                title: 'Import Error',
                content: 'There was an error uploading the file.',
                centered: true,
                onOk: handleErrorModalClose,
                onCancel: handleErrorModalClose
            });

        }
        finally {
            setLoading(false)
            setIsUploadModalVisible(false)
        }
    }
    const handleErrorModalClose = () => {
        setIsUploadModalVisible(false)
    }
    const handleUploadClick = () => {
        setIsUploadModalVisible(true);

    }
    const handleDownloadTemplate = async () => {
        setLoading(true);
        try {
            const url =
                ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/download_bulk_upload_template",
                table_name: "Change Phone Number",
                module_name: "Change Phone Number",
                role_name: role,
                Partner: partner,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
        ... metaData,
                sessionID: sessionId,
            };

            const response = await axios.post(url, { data });
            const resp = JSON.parse(response.data.body);
            const blob = resp.blob;
            console.log(resp);
            if (response.data.statusCode === 200) {
                if (resp.flag === true) {
                    notification.success({
                        message: 'Success',
                        description: 'Successfully downloaded the template!',
                        style: messageStyle,
                        placement: 'top',
                    });
                    downloadBlob(blob);
                    setLoading(false);
                    setIsUploadModalVisible(false);
                } else {
                    console.log('Error message:', resp.message);
                    Modal.error({
                        title: 'Export Error',
                        content: resp.message,
                        centered: true,
                    });
                }
            } else {
                console.log('Unexpected status code:', response.data.statusCode);
                Modal.error({
                    title: 'Download Error',
                    content: resp.message,
                    centered: true,
                });
            }
        }
        catch (error) {
            Modal.error({
                title: 'Download Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while downloading. Please try again.',
                centered: true,
            });
        }
        finally {
            setLoading(false)
            handleUploadModalClose()
        }

    };
    const handleUploadModalClose = () => {
        setIsUploadModalVisible(false);
    };

    if (loading) {
        return (
            <div className="flex justify-center items-center h-[400px]">
                <Spin size="large" />
            </div>
        );
    }

    return (
        <div className="space-y-3 h-auto">
            <div className="flex justify-end">
                <button className="save-btn" onClick={handleUploadClick}>
                    <ArrowUpTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                    <span>Upload</span>
                </button>
            </div>
            {/* Effective Date (Non-editable) */}
            <div className="flex items-center space-x-4">
                <label className="w-1/4 font-medium">Effective Date<span className='text-red-500'>*</span></label>
                <input
                    type="text"
                    value={currentDate}
                    className="w-3/4 non-editable-input cursor-not-allowed"
                    readOnly
                />
            </div>
            {/* New ICCID Textarea */}
            <div className="flex items-center space-x-4">
                <label className="w-1/4 font-medium">Subscriber Number<span className='text-red-500'>*</span></label>
                <textarea
                    value={subscriberNumber}
                    onChange={(e) => {
                        setSubscriberNumber(e.target.value);// Clear IMEI if ICCID is being entered
                    }}
                    className="w-3/4 border border-gray-300 rounded-md p-2 h-24"
                    placeholder="Enter old Subscriber Number per line"
                />
            </div>

            {/* Error Message */}
            {errorMessage && (
                <div className="text-red-500">{errorMessage}</div>
            )}

            {/* Submit Button */}
            <div className="flex justify-center space-x-4">

                <button
                    onClick={onBack}
                    className="cancel-btn"
                >
                    Back
                </button>
                <button
                    onClick={handleSubmit}
                    className="save-btn"
                >
                    Submit
                </button>
            </div>

            <Modal
                title="Upload Files"
                visible={isUploadModalVisible}
                onCancel={handleUploadModalClose}
                footer={null} // No default footer buttons
                centered
                width={370}
            >
                <div className="flex flex-col gap-4">
                    <div className="flex gap-4 justify-center p-4">
                        <Upload {...uploadProps} className="upload-wrapper">
                            <button
                                className="upload-btn disabled:cursor-not-allowed"
                                style={{ height: '40px', display: 'inline-flex', alignItems: 'center' }}>
                                <span className="mr-2"><UploadOutlined /></span>
                                Upload
                            </button>
                        </Upload>
                        <button
                            onClick={handleDownloadTemplate}
                            className="upload-btn disabled:cursor-not-allowed"
                        // disabled={!appendChecked && !overwriteChecked}
                        >
                            <span className="mr-2"><DownloadOutlined /></span>
                            Download Template
                        </button>
                    </div>
                </div>
            </Modal>
        </div>
    );
};

export default ChangePhoneNumber;
