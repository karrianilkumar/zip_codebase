import React, { FC, useState } from 'react';
import { Modal, Button, Upload, notification, Spin, message } from 'antd';
import { DownloadOutlined, UploadOutlined } from '@ant-design/icons';
import { UploadOutlined as UploadIcon } from '@ant-design/icons';

import * as XLSX from 'xlsx';
import { ENV_ROUTES } from '@/app/components/routes/route_constants';
import { useAuth } from '@/app/components/auth_context';
import { getCurrentDateTime } from '@/app/components/header_constants';
import axios from 'axios';
import { useRouter } from 'next/navigation';
import { useFeatureStore } from '../../inventory/featureStore';

const messageStyle = {
  fontSize: "14px",
  fontWeight: "bold",
  padding: "16px",
};

interface UploadProps {
  service_provider: any;
  change_type: any;
  changed_data: any;
}

const UploadComponent: FC<UploadProps> = ({ service_provider, change_type, changed_data }) => {
  const [isImportModalOpen, setImportModalOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const { username, partner, role, token, selectedDb,metaData, firstLastName, sessionId, modulesVersionMap } = useAuth();
  const [uploadKey, setUploadKey] = useState(Date.now());
  const changeType = change_type.toLowerCase() || ""
  const router = useRouter();
  const initial_version_flag = modulesVersionMap?.["Sim Management-Bulk Change"] || false
  const isVersionEnabled = localStorage.getItem("switch_user_2_0_bulk_change") === "True";
  const switch_user_2_0 = isVersionEnabled && initial_version_flag ? "True" : "False"
  const { setBulkRow } = useFeatureStore();
  const handleImportModalOpen = () => {
    setImportModalOpen(true);
  };

  const handleImportModalClose = () => {
    setImportModalOpen(false);
  };

  //Bulk upload modal

  const downloadBlob = (base64Blob: string) => {
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    const blobObject = new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blobObject);
    link.download = `${changeType === "change customer rate plan" ? 'Customer Rate Plan.xlsx' : 'Bulk Activation.xlsx'}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleUploadClick = () => {
    handleImportModalOpen();

  }
  const handleDownloadTemplate = async () => {
    setLoading(true);
    const url =
      ENV_ROUTES.SIM_MANAGEMENT;
    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/download_bulk_upload_template",
      module_name: `${changeType === "change customer rate plan" ? "Bulk Customer Rate Plan" : "Bulk Change"}`,
      table_name: "",
      role_name: role,
      service_provider: service_provider,
      Partner: partner,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
        ... metaData,
      sessionID: sessionId,
    };

    const response = await axios.post(url, { data });
    const resp = JSON.parse(response.data.body);
    console.log(resp);
    if (response.data.statusCode === 200) {
      if (resp.flag === true) {
        const blob = resp.blob;
        notification.success({
          message: 'Success',
          description: 'Successfully exported the record!',
          style: messageStyle,
          placement: 'top',
        });
        downloadBlob(blob);

        setLoading(false);
        handleImportModalClose()
      } else {
        console.log('Error message:', resp.message);
        Modal.error({
          title: 'Export Error',
          content: resp.message,
          centered: true,
        });
      }
    } else {
      console.log('Unexpected status code:', response.data.statusCode);
      Modal.error({
        title: 'Export Error',
        content: resp.message,
        centered: true,
      });
    }
  };

  const callRunDbScript = async (parsedData: any) => {
    try {
      const runDbData = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/run_db_script", // Always use this path
        role_name: role,
        module_name: "Bulk Change",
        mod_pages: {
          start: 0,
          end: 100,
        },
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        bulkchange_id: parsedData?.bulkchange_id?.id,
        data: parsedData?.data,
        bulk_chnage_id_20: parsedData?.bulk_chnage_id_20
      };

      console.log("Run DB Data", runDbData);

      // Send the second request
      await axios.post(ENV_ROUTES.SIM_MANAGEMENT, { data: runDbData });
      console.log("Run DB script executed successfully.");
    } catch (error) {
      console.error("Error executing run_db_script:", error);
      // Optionally handle the error here, e.g., show a notification
    }
  };

  const callKoreSync = async (data: any) => {
    const koreUrl = ENV_ROUTES.SM_BULK_CHANGE;
    let koreData = { ...data }
    koreData["path"] = "/start_sync"

    try {
      const koreResponse = await axios.post(koreUrl, { data: koreData });
      const koreResponseData = JSON.parse(koreResponse.data.body);

      if (koreResponseData.flag === false) {
        console.log("Data Fetch Error: " + koreResponseData.message);
      } else {
        console.log("Success: Bulk update successful.");
      }

    }
    catch {
      console.log("error in Start Sync");
    }
  }
  const callKoreSubmit = async (parsedData: any) => {
    try {
      let changed_data = { ...parsedData?.changed_data || {} }
      const url = ENV_ROUTES.SM_BULK_CHANGE;
      let data: any = {}
      data = {
        tenant_name: partner || "default_value",
        path: "/update_customer_rate_plan",
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        service_provider: service_provider,
        change_type: change_type,
        bulk_change_id: parsedData?.bulkchange_id?.id,
        data: parsedData?.data,
        created_by: firstLastName,
        iccids: changed_data?.Devices || [],
        imeids: [],
        changed_data: {
          OverrideValidation: false,
          Devices: changed_data?.Devices || [],
          ...changed_data,
        },
        updated_data: {
          CustomerRatePlanUpdate: {
            effective_date: changed_data?.CustomerRatePlanUpdate?.EffectiveDate || "",
            customer_rate_plan_name: changed_data?.CustomerRatePlanUpdate?.CustomerRatePlanId || "",
            customer_rate_pool_name: changed_data?.CustomerRatePlanUpdate?.CustomerRatePoolId || "",

          }
        }
      };
      const kore_response = await axios.post(url, { data });
      const kore_parsedData = JSON.parse(kore_response.data.body);

      if (kore_parsedData.flag === false) {
        console.error("Data Fetch Error: " + kore_parsedData.message);
      } else {
        console.log("Success: Bulk update successful.");
      }
      const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
      data["service_provider_id"] = service_provider_id_
      callKoreSync(data)
    }
    catch (error) {
      console.error("Error executing kore submit:", error);
      // Optionally handle the error here, e.g., show a notification
    }

  }

  const handleUpload = async (blob: string) => {
    try {
      setLoading(true)
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/update_bulk_change_excel",
        module_name: `${changeType === "change customer rate plan" ? "Bulk Customer Rate Plan" : "Bulk Change"}`,
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        service_provider: service_provider,
        change_type: change_type,
        created_by: firstLastName,
        changed_data: { ...changed_data },
        Devices: [],
        iccids: [],
        imei: [],
        upload_xlx: true,
        blob_data: blob,
      };

      const response = await axios.post(url, { data });

      const resp = JSON.parse(response.data.body);
      if (response.data.statusCode === 200) {
        if (resp.flag === true) {
          // Check all items in the data array
          const failedItems = resp.data.filter((item: any) => item.flag === false);
          const successfulItems = resp.data.filter((item: any) => item.flag === true);
          if (failedItems.length > 0) {
            // Display error modal for failed items
            Modal.error({
              title: 'Few bulk changes are not uploaded!',
              content: (
                <div>
                  {failedItems.map((item: any, index: number) => (
                    <p key={index}>{item.message}</p>
                  ))}
                </div>
              ),
              centered: true,
            });
          } else {
            const parsedData_ = successfulItems[0] || {}
            console.log("Initial request successful:", parsedData_);

            // Navigate to the bulk history page
            const bulkrow_ = parsedData_?.bulkchange_id || {};
            const bulkRow: any = { row: bulkrow_ };
            setBulkRow(bulkRow);
            localStorage.setItem('bulk_row', JSON.stringify(bulkRow || "{}"));
            router.push(`/sim_management/bulk_history`);
            // All items were successful
            handleImportModalClose();
            notification.success({
              message: 'Success',
              description: 'All bulk changes are successfully uploaded!',
              placement: 'top',
            });
          }
          if ((service_provider.toLowerCase()) === "kore" && switch_user_2_0 !== "True") {
            callKoreSubmit(resp?.data && resp.data.length > 0 ? resp.data[0] : {})
          }
          else {
            // Call `callRunDbScript` for each successful item
            successfulItems.forEach((item: any) => {
              callRunDbScript(item);
            });
          }
        } else {
          // If the top-level flag is false, show error modal
          Modal.error({
            title: 'Import Error',
            content: resp.message,
            centered: true,
          });
        }
      } else {
        Modal.error({
          title: 'Import Error',
          content: resp.message,
          centered: true,
        });
      }
    } catch (error) {
      console.error('Error during file upload:', error);
      Modal.error({
        title: 'Import Error',
        content: 'There was an error uploading the file.',
        centered: true,
      });

    }
    finally {
      setLoading(false)
    }
  }
  const handleChange = (info: any) => {
    if (info.file.status === 'done') {
      let blob;
      const file = info.file.originFileObj; // Get the file object
      const reader = new FileReader();
      reader.onload = (e: any) => {
        // Get the file data URL (Base64 string)
        blob = e.target.result;
        handleUpload(blob)
        setUploadKey(Date.now());
      };

      if (blob) {
      }

      reader.readAsDataURL(file); // Read the file as data URL
    } else if (info.file.status === 'error') {
      // Handle upload error
      message.error('Upload failed.');
    }
    else if (info.file.status === 'removed') {

    }
  };
  const uploadProps = {
    key: uploadKey,
    accept: '.xlsx, .xls',
    beforeUpload: (file: any) => {
      // Check if file is an Excel file
      const isExcel = file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || file.type === 'application/vnd.ms-excel';
      if (!isExcel) {
        message.error('You can only upload Excel files!');
      }
      return isExcel;
    },
    onChange: handleChange,
  };

  return (
    <div >
      <div className="flex flex-col items-end justify-center">
        <Button onClick={handleImportModalOpen} className='save-btn'>
          <UploadIcon />upload
        </Button>
      </div>
      <Modal
        title={`${changeType === "change customer rate plan" ? "Upload Customer Rate Plan" : "Upload activation information"}`}
        visible={isImportModalOpen}
        onCancel={handleImportModalClose}
        footer={null}
        centered
        width={400}
      >
        {loading ? (
          <div className="flex justify-center items-center h-24">
            <Spin size="large" />
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            <div className="flex flex-col md:flex-row gap-4 justify-center m-auto p-4">
              <Upload {...uploadProps} className="w-full md:w-auto">
                <button className="w-[200px] md:w-full upload-btn disabled:cursor-not-allowed">
                  <span className="mr-2"><UploadOutlined /></span>
                  Upload
                </button>
              </Upload>
              <button
                onClick={handleDownloadTemplate}
                className=" w-[200px] md:w-full upload-btn disabled:cursor-not-allowed"
              // disabled={!appendChecked && !overwriteChecked}
              >
                <span className="mr-2"><DownloadOutlined /></span>
                Download Template
              </button>
            </div>
          </div>
        )}
        {/* <div className="flex flex-col items-center justify-center h-[150px]">
          <div className="flex gap-8 px-2 w-fit mb-3"> */}

      </Modal>
    </div>
  );
};

export default UploadComponent;
