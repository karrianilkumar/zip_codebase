"use client";

import { FC, forwardRef, useEffect, useImperativeHandle, useRef, useState } from "react";
import { Input, Button, DatePicker, Checkbox, Modal } from "antd";
import { ArrowLeftIcon, ArrowRightIcon } from "@heroicons/react/24/outline";
import Select from "react-select";
import SelectDevices from "./select_devices";
import dayjs from "dayjs";
import React from "react";
import UploadComponent from "./upload_component";
import { DropdownStyles } from "@/app/components/css/dropdown";
import { useAuth } from "@/app/components/auth_context";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import axios from "axios";
import { useAllChangeTypesStore } from "@/app/stores/allChangeTypesStore";
import { SelectContentRef } from "./select_devices";
interface UpdateFeaturesProps {
    onContinue: () => void;
    onBack: () => void;
    dropdown: any;
    service_provider: any;
    change_type: any;
    onClose: () => void;
}

export interface UpdateFeaturesContentRef {
  runValidation: () => Promise<void> | void;
  runSubmit: ()=> Promise<void> | void;
  returnUpdate: () => React.ReactNode | Promise<React.ReactNode>;
}

const UpdateFeatures = forwardRef<UpdateFeaturesContentRef, UpdateFeaturesProps>(
    ({ onContinue, onBack, dropdown, service_provider, change_type,onClose }, ref) => {
    const [showSelectDevices, setShowSelectDevices] = useState(false);
    const [errors, setErrors] = useState<any>([]);
    const [loading, setLoading] = useState(false);
    const { username, role, partner, token, selectedDb, firstLastName, sessionId, metaData } = useAuth();
    const [featureCodes, setFeatureCodes] = useState<any[]>([]);
    const [removeFeatureCodes, setRemoveFeatureCodes] = useState<any[]>([]);
    const [featureCodesOptions, setFeatureCodesOptions] = useState<any[]>([]);
    const [overWrite, setOverWrite] = useState<boolean>(false);
    const { isAllChangeType,setIsValidated,setValidationTrigger, setsuccessFullChangeTypes, activeChange, successFullChangeTypes  } = useAllChangeTypesStore();
    const selectDevicesRef = useRef<SelectContentRef>(null);
    const [saveChanges, setSaveChanges] = useState<boolean>(true);

    const fetchData = async () => {
        setLoading(true);
        try {
            const url = ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner || 'default_value',
                username,
                path: '/update_features_pop_up_data',
                role_name: role,
                parent_module: 'Sim Management',
                module_name: 'SimManagement Inventory',
                feature_module_name: 'Inventory',
                Partner: partner,
                service_provider_name: service_provider,
                // service_provider_id: rowData?.service_provider_id,
                // service_provider_id: '6',
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                dropdown: 'Update features',
                modified_by: username
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);

            if (!parsedData.flag) {
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching Inventory data. Please try again.',
                    centered: true,
                });
            } else {
                const feature_codes_map = parsedData?.soc_codes || []


                // Transform options for react-select
                const options_ = feature_codes_map.map((option: any) => ({
                    value: option?.id || "",
                    label: `${option?.friendly_name || ""} - ${option?.soc_code || ""}`,
                    soc_code: option?.soc_code || "",
                    friendly_name: option?.friendly_name || "",
                }));
                setFeatureCodesOptions(options_)

            }
        } catch (error) {
            console.error('Error fetching data:', error);
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchData()
    }, [dropdown]);

    const handleContinue = () => {
        const newErrors: any = {};

        if (featureCodes && featureCodes.length === 0) {
            newErrors.featureCodes = "Feature Codes are required.";
        }

        if (Object.keys(newErrors).length > 0) {
            setsuccessFullChangeTypes(
                    successFullChangeTypes.filter((c: any) => c !== activeChange)
                );
            if (isAllChangeType) {
                if (featureCodes && featureCodes.length === 0 && removeFeatureCodes && removeFeatureCodes.length === 0 && !overWrite) {
                    setErrors({});
                    setIsValidated(true)
                    setValidationTrigger();
                    return
                }
                else {
                    setIsValidated(false)
                    setErrors(newErrors);
                    setValidationTrigger();
                    return
                }

            }
            else{
                setErrors(newErrors);
                return;
            }
        }

        setErrors({});
        if(isAllChangeType){
            if (saveChanges) {
                setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
            }
            setIsValidated(true)
            setValidationTrigger()
        }
        else{
            setShowSelectDevices(true);
        }
        
    };

    const handleBack = () => {
        setShowSelectDevices(false);
    };


    const handleFeatureCodesChange = (selectedOptions: any) => {
        if (!selectedOptions) {
            setFeatureCodes([]);
            return;
        }

        setFeatureCodes(selectedOptions)

    };
    const handleRemoveFeatureCodesChange = (selectedOptions: any) => {
        if (!selectedOptions) {
            setRemoveFeatureCodes([]);
            return;
        }

        setRemoveFeatureCodes(selectedOptions)

    };

    const returnChangedData = () => {
        let add_codes: any = []
        let remove_codes: any = []

        if (featureCodes && featureCodes.length > 0) {
            add_codes = featureCodes.map((opt: any) => (opt?.soc_code))
        }
        if (removeFeatureCodes && removeFeatureCodes.length > 0) {
            remove_codes = removeFeatureCodes.map((opt: any) => (opt?.soc_code))
        }
        const changedData = {
            overwrite:overWrite,
            serviceCharacteristic: [
                {
                    "name": "addOfferingCode",
                    "value": add_codes
                },
                {
                    "name": "removeOfferingCode",
                    "value": remove_codes
                }
            ],
        };
        return changedData;
    };

        const returnUpdatedValue = () => {
            const feature_codes = featureCodes.length > 0 ? featureCodes.map((item: any) => (item?.label || "")) : [];
            const remove_feature_codes = removeFeatureCodes.length > 0 ? removeFeatureCodes.map((item: any) => (item?.label || "")) : [];

            return (
                <div className="flex flex-col gap-2">
                    <div className="flex grid grid-cols-2 ">
                        <span className="font-semibold">Update Feature Codes:</span>
                        <span>{feature_codes.length > 0 ? feature_codes.join(", ") || "" : ""}</span>
                        <span className="font-semibold">Remove Feature Codes:</span>
                        <span>{remove_feature_codes.length > 0 ? remove_feature_codes.join(", ") || "" : ""}</span>
                    </div>
                </div>
            )
        }

    useImperativeHandle(ref, () => ({
        runValidation: handleContinue,
        runSubmit: () => {
            selectDevicesRef.current?.runSubmit();
        },
        returnUpdate: returnUpdatedValue
    }));

    return (
        <div>
            {/* {!showSelectDevices ? ( */}
                <>
                <div className={showSelectDevices ? "hidden" : "block"}>
                    {isAllChangeType && (
                        <div className="flex justify-end px-4">
                            <span className="mr-2 font-semibold">Save Changes</span>
                            <Checkbox
                                checked={saveChanges}
                                onChange={(e) => {
                                    if (!e.target.checked) {
                                        setsuccessFullChangeTypes(
                                            successFullChangeTypes.filter((c: any) => c !== activeChange)
                                        );
                                    }
                                    setSaveChanges(e.target.checked)
                                }}
                                className="custom-checkbox"
                            >

                            </Checkbox>
                        </div>
                    )}
                    <div className={`${!isAllChangeType?"flex flex-col space-y-4 mt-4":"flex grid grid-cols-2 gap-4"}`}>
                        <div>
                            <label className="field-label">Update Feature Codes<span className="text-red-500">*</span></label>
                            <Select
                                isMulti
                                value={featureCodes}
                                options={featureCodesOptions}
                                onChange={handleFeatureCodesChange}
                                placeholder="Select feature codes"
                                styles={DropdownStyles}
                            />
                            {(errors.featureCodes && isAllChangeType) && (
                            <span className="text-red-500">{errors.featureCodes}</span>
                        )}
                        </div>
                        {(errors.featureCodes && !isAllChangeType) && (
                            <span className="text-red-500">{errors.featureCodes}</span>
                        )}

                        <div className='flex'>
                            <label className="field-label">Overwrite Feature Codes</label>
                            <Checkbox
                                id="overwrite"
                                checked={overWrite}
                                onChange={(e) => setOverWrite(e.target.checked)}
                                className='ml-4'
                            />
                        </div>

                        <div>
                            <label className="field-label">Remove Feature Codes</label>
                            <Select
                                isMulti
                                value={removeFeatureCodes}
                                options={featureCodesOptions}
                                onChange={handleRemoveFeatureCodesChange}
                                placeholder="Select feature codes"
                                styles={DropdownStyles}
                            />
                        </div>

                        {!isAllChangeType && (
                            <div className="flex justify-center space-x-4 mt-4">
                            <button onClick={onBack} className="cancel-btn">
                                Back
                            </button>
                            <button onClick={handleContinue} className="save-btn">
                                Continue
                            </button>
                        </div>
                        )}
                        
                    </div>
                </div>
                </>
             {/* ) : ( */}
              <div className={showSelectDevices ? "block" : "hidden"}>
                <SelectDevices ref={selectDevicesRef} onContinue={onContinue} onBack={handleBack} service_provider={service_provider} change_type={change_type} changed_data={returnChangedData()} onCancel={onClose}/>
              </div>
            {/* )} */}
        </div>
    );
}
)

export default UpdateFeatures;