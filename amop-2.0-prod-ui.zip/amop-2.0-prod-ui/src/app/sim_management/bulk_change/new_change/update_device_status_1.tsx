"use client";
import { FC, forwardRef, useEffect, useImperativeHandle, useRef, useState } from "react";
import { Input, Button, Checkbox, Tooltip } from "antd";
import { ArrowLeftIcon, ArrowRightIcon } from "@heroicons/react/24/outline";
import SelectDevices from "./select_devices";
import moment from "moment";
import { DatePicker } from "antd/lib";
import Select from 'react-select';
import React from "react";
import { useAuth } from "@/app/components/auth_context";
import { DropdownStyles } from "@/app/components/css/dropdown";
import { useAllChangeTypesStore } from "@/app/stores/allChangeTypesStore";
import dayjs from "dayjs";
import { SelectContentRef } from "./select_devices";

interface Activated1Props {
    onContinue: () => void;
    onBack: () => void;
    dropdown: any;
    service_provider: any;
    change_type: any;
    onClose: () => void;
}

export interface Activated1ContentRef {
  runValidation: () => Promise<void> | void;
  runSubmit: () => Promise<void> | void;
  returnUpdate: () => React.ReactNode | Promise<React.ReactNode>;
}

const Activated1 = forwardRef<Activated1ContentRef, Activated1Props>(
    ({ onContinue, onBack, dropdown, service_provider, change_type, onClose }, ref) => {
    const [targetStatus, setSelectedTargetStatus] = useState<string | null>(null);
    const [selectedStatus, setSelectedStatus] = useState<string | null>(null);
    const [selectedStatusID, setSelectedStatusId] = useState<string | null>(null);
    const [statusMap, setStatusMap] = useState<any>([]);

    const [reasonCodeMap, setReasonCodeMap] = useState<any>([]);
    const [selectedReasonCode, setSelectedReasonCode] = useState<string | null>(null);
    const [selectedReasonCodeID, setSelectedReasonCodeID] = useState<string | null>(null);
    const [reasonCodeOptions, setReasonCodeOptions] = useState<any>([]);



    const [statusOptions, setStatusOptions] = useState<any>([]);

    const [firstName, setFirstName] = useState<string>("");
    const [lastName, setLastName] = useState<string>("");
    const [addressLine, setAddressLine] = useState<string>("");
    const [ipAddress, setIpAddress] = useState<string>("");
    const [city, setCity] = useState<string>("");
    const [country, setCountry] = useState<string>("");
    const [selectedRatePlan, setSelectedRatePlan] = useState<string | null>('');
    const [notAdminSelectedRatePlan, setNotAdminSelectedRatePlan] = useState<string | null>('');
    const [publicIpRestriction, setPublicIpRestriction] = useState<string | undefined>("restricted");
    const [mdnZipCode, setMdnZipCode] = useState<string>("");
    const [revIoAccountNumber, setRevIoAccountNumber] = useState<string>("");
    const [showSelectDevices, setShowSelectDevices] = useState(false);
    const [errors, setErrors] = useState<{ [key: string]: string }>({});
    const [effectiveDateCheckbox, setEffectiveDateCheckbox] = useState<boolean>(false);
    const [effectiveDateError, setEffectiveDateError] = useState<string | null>(null);
    const [effectiveDate, setEffectiveDate] = useState<Date | null>(null);
    const [ratePlanOptions, setRatePlanOptions] = useState<any>([]);
    const [selectedPublicIpRestriction, setSelectedPublicIpRestriction] = useState<string>('restricted');
    const [publicIpOptions, setPublicIpOptions] = useState<any>([]);

    const [selectedState, setSelectedState] = useState<string>('');
    const [selectedStateCode, setSelectedStateCode] = useState("");
    const [stateOptions, setStateOptions] = useState<any>([]);
    const { role } = useAuth();
    const { isAllChangeType,setIsValidated,setValidationTrigger, setsuccessFullChangeTypes, activeChange, successFullChangeTypes  } = useAllChangeTypesStore();
    const selectDevicesRef = useRef<SelectContentRef>(null);
    const isAdmin = role?.toLowerCase() === "super admin" || role?.toLowerCase() === "partner admin"
    const [saveChanges, setSaveChanges] = useState<boolean>(true);
    useEffect(() => {
        // console.log("dropdown", dropdown)
        const public_ip = dropdown?.public_ip || []
        setPublicIpOptions(public_ip)
        const state = dropdown?.state || [];

        // Map state array to options with 'name' as label and 'code' as value
        const stateOptions = state.map((item: any) => ({
            label: item.name,  // Display state name in the dropdown
            value: item.code,  // Use state code as the value
        }));

        setStateOptions(stateOptions);
        const default_state = stateOptions.length>0 ? stateOptions[0] : null
        setSelectedState(default_state?.label || "")
        setSelectedStateCode(default_state?.value || "")
        const carrier_rate_plan_dropdown = dropdown?.carrier_rate_plan_dropdown || []
        setRatePlanOptions(carrier_rate_plan_dropdown)

        if (typeof service_provider === "string" && service_provider.includes("AT&T - Telegence")) {
            const reason_code = dropdown?.reason_code || []
            setReasonCodeMap(reason_code)
            const Device_Status_dropdown = dropdown?.Device_Status_dropdown || []
            setStatusMap(Device_Status_dropdown || [])
            const statusOptions = Device_Status_dropdown.map((option: any) => (option.display_name));
            setStatusOptions(statusOptions)
            // console.log("statusOptions", statusOptions)
        }
        else {
            const Device_Status_dropdown = dropdown?.Device_Status_dropdown || []
            setStatusMap(Device_Status_dropdown || [])
            const statusOptions = Device_Status_dropdown.map((option: any) => (option.display_name));
            setStatusOptions(statusOptions)
            const reason_code = dropdown?.reason_code || []
            setReasonCodeMap(reason_code) 
            // const reasonCodeOptions = reason_code.map((option: any) => ({ label: option, value: option }));
            // setReasonCodeOptions(reasonCodeOptions)
        }

    }, [dropdown]);
    const getDefaultReasonCode = (targetStatus: any) => {
        const selected_status=targetStatus.toLowerCase()
        switch (selected_status) {
            case "suspended":
                return {label:"Customer Request",value:"CR"};
            case "cancel subscriber":
                return {label:"Customer Cutting Back",value:"CB"};
            case "restore suspended":
                return {label:"Customer Request",value:"CR"};
            case "restore cancelled":
                return {label:"Customer Request",value:"CR"};
            default:
                return null; // or a suitable default value
        }
    };

    // const defaultReasonCode = getDefaultReasonCode(targetStatus);
    // const handleContinue = () => {
    //     const newErrors: { [key: string]: string } = {};
    //     if (!targetStatus) {
    //         setErrors((prevErrors) => ({ ...prevErrors, targetStatus: 'Please select a target status.' }));
    //     }
    //     else {
    //         if (targetStatus === "Active") {
    //             if (!firstName) newErrors.firstName = "First name is required.";
    //             if (!lastName) newErrors.lastName = "Last name is required.";
    //             if (!addressLine) newErrors.addressLine = "Address line is required.";
    //             if (!city) newErrors.city = "City is required.";
    //             if (!country) newErrors.country = "Country is required.";
    //             if (!selectedRatePlan) newErrors.ratePlan = "Rate plan is required.";
    //             if (!mdnZipCode) newErrors.mdnZipCode = "MDN zip code is required.";
    //         }

    //         if (Object.keys(newErrors).length > 0) {
    //             setErrors(newErrors);
    //         } else {
    //             setErrors({});
    //             setShowSelectDevices(true);
    //         }
    //     }


    // };
    const handleContinue = () => {
        const newErrors: { [key: string]: string } = {};

        if (!targetStatus) {
            newErrors.targetStatus = 'Please select a target status.';
            if(isAllChangeType){
                setsuccessFullChangeTypes(
                    successFullChangeTypes.filter((c: any) => c !== activeChange)
                );
                setErrors({});
                setIsValidated(true)
                setValidationTrigger();
            }
        } else {
            if (targetStatus === "Active") {
                if (!firstName) newErrors.firstName = "First name is required.";
                if (!lastName) newErrors.lastName = "Last name is required.";
                if (!addressLine) newErrors.addressLine = "Address line is required.";
                if (!city) newErrors.city = "City is required.";
                if (!country) newErrors.country = "Country is required.";
                if (!selectedRatePlan) newErrors.ratePlan = "Rate plan is required.";
                if (!mdnZipCode) newErrors.mdnZipCode = "MDN zip code is required.";
            }

            // Check for effective date only if the checkbox is checked
            if (effectiveDateCheckbox && !effectiveDate) {
                newErrors.effectiveDate = "Effective date is required.";
            } else if (effectiveDateCheckbox && effectiveDate) {
                // Clear the effective date error if provided
                setErrors((prevErrors) => {
                    const { effectiveDate, ...rest } = prevErrors;
                    return rest;
                });
            }

            if (Object.keys(newErrors).length > 0) {
                setErrors(newErrors);
                if(isAllChangeType){
                    setsuccessFullChangeTypes(
                        successFullChangeTypes.filter((c: any) => c !== activeChange)
                    );
                    setIsValidated(false)
                    setValidationTrigger();
                }
                

            } else {
                setErrors({});
                if(isAllChangeType){
                    if(saveChanges){
                        setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
                    }
                    setIsValidated(true)
                    setValidationTrigger()
                }
                else{
                    setShowSelectDevices(true);
                }
                
            }
        }
    };

    const handleSelectedTargetStatusChange = (selectedOption: any) => {
        if (typeof service_provider === "string" && service_provider.includes("AT&T - Telegence")) {
            handleTelegenceTargetStatusChange(selectedOption)
        }
        else {
            handleVerizonTargetStatusChange(selectedOption)

        }


    }

    const handleTelegenceTargetStatusChange = (selectedOption: any) => {
        console.log("selectedOption", selectedOption)
        if (selectedOption) {
            setSelectedTargetStatus(selectedOption.value)
            const selectedItem = statusMap.find((item: any) => item.display_name === selectedOption.value);
            setSelectedStatusId(selectedItem?.id || "22"); // `id`
            setSelectedStatus(selectedItem?.status || "A"); // `status`
            setSelectedReasonCode(null);
            setSelectedReasonCodeID(null);
            // Filter reasonCodeMap based on the selectedStatusId
            const filteredReasonCodes = reasonCodeMap
                .filter((reason: any) => reason.device_status_id === selectedItem?.id)
                .map((reason: any) => ({
                    label: reason.description,
                    value: reason.reason_code,
                }));
            console.log("filteredReasonCodes", filteredReasonCodes)
            setReasonCodeOptions(filteredReasonCodes);
            // const reason_code=filteredReasonCodes.length>0?filteredReasonCodes[0]:null
            // console.log(reason_code?.label,reason_code?.value,"show label.....")
            const reason_code = getDefaultReasonCode(selectedOption.value)
            setSelectedReasonCode(reason_code?.label || null)
            setSelectedReasonCodeID(reason_code?.value || null)
            setErrors((prevErrors) => ({ ...prevErrors, targetStatus: '' })); // Clear error when an option is selected

        } else {
            setSelectedStatusId(null);
            setSelectedStatus("");
            setReasonCodeOptions([]); // Clear options if no target status is selected
            setSelectedReasonCode(null);
            setSelectedReasonCodeID(null);
            setErrors((prevErrors) => ({ ...prevErrors, targetStatus: 'Please select a target status.' }));

        }
    };

    const handleVerizonTargetStatusChange = (selectedOption: any) => {
        console.log("selectedOption", selectedOption)
        if (selectedOption) {
            const value = selectedOption?.value;
            if (typeof service_provider === "string" && service_provider.toLowerCase()==="verizon - thingspace iot" && value.toLowerCase()==="inventory"){
                const ratePlan=ratePlanOptions.length>0 ? ratePlanOptions[ratePlanOptions.length-1] :null
                const ratePlan_=isAdmin?ratePlan:ratePlan.code || null
                console.log("ratePlan",ratePlan)
                setSelectedRatePlan(ratePlan_)
            }
            if((service_provider.toLowerCase().includes("verizon") || service_provider.toLowerCase().includes("vzn") || service_provider.toLowerCase().includes("vzwcr") || service_provider.toLowerCase().includes("2215-so01")) && value.toLowerCase()==="pending activation"){
                const zip_code = dropdown?.thingspace_zipcode || null
                setMdnZipCode(zip_code)
            }
            setSelectedTargetStatus(selectedOption.value)
            const selectedItem = statusMap.find((item: any) => item.display_name === selectedOption.value);
            setSelectedStatusId(selectedItem?.id || "22"); // `id`
            setSelectedStatus(selectedItem?.status || "A"); // `status`
            setSelectedReasonCode(null);
            setSelectedReasonCodeID(null);
            setErrors((prevErrors) => ({ ...prevErrors, targetStatus: '' })); // Clear error when an option is selected
            setSelectedReasonCode(null);
            setSelectedReasonCodeID(null);
            // Filter reasonCodeMap based on the selectedStatusId
            const filteredReasonCodes = reasonCodeMap
                .map((reason: any) => ({
                    label: reason.description,
                    value: reason.reason_code,
                }));
            console.log("filteredReasonCodes", filteredReasonCodes)
            setReasonCodeOptions(filteredReasonCodes);
        } else {
            setErrors((prevErrors) => ({ ...prevErrors, targetStatus: 'Please select a target status.' }));
            setSelectedTargetStatus(null)
            setSelectedReasonCode(null);
            setSelectedReasonCodeID(null);
            setSelectedStatusId(null);
            setSelectedStatus("");
        }
    };
    const handleSelectedReasonCodeChange = (selectedOption: any) => {
        if (selectedOption) {
            console.log(selectedOption,"showwwwwwww")
            setSelectedReasonCode(selectedOption.label); // Store selected reason_code
            console.log(selectedOption.label,selectedOption.value,"show .........")
            setSelectedReasonCodeID(selectedOption.value); // Store selected reason_code

        } else {
            setSelectedReasonCode("");
            setSelectedReasonCodeID(null); // Store selected reason_code
        }
    };

    const handleSelectedRatePlanChange = (selectedOption: any) => {
        if (selectedOption) {
            const value = selectedOption?.value
            const label = selectedOption?.label
            setSelectedRatePlan(value)
            setNotAdminSelectedRatePlan(label)
        }
        else {
            setSelectedRatePlan(null)

        }
    }
    const handleSelectedPublicIpChange = (selectedOption: any) => {
        if (selectedOption) {
            const value = selectedOption?.value;
            setSelectedPublicIpRestriction(value);
        }
    };

    const handleSelectedStateChange = (option: any) => {
        const code_ =option?.value || null
        const name_ =option?.label || null
        // 'value' is the state code, so set it to selectedStateCode
        setSelectedStateCode(code_);
        setSelectedState(name_);
    };

    const handleBack = () => {
        setShowSelectDevices(false);
    };
    const returnChangedData = () => {
        let changedData: any = {}
        if (typeof service_provider === "string" && service_provider.includes("AT&T - Telegence")) {
            changedData = {
                sim_status:targetStatus,
                device_status_id:selectedStatusID,
                effectiveDate:effectiveDate,
                UpdateStatus: selectedStatus,
                IsIgnoreCurrentStatus: false,
                Request: {
                    mode: selectedStatus,
                    reasonCode: selectedReasonCodeID ? selectedReasonCodeID : "CB"
                }
            }
        }
        else {
            const isDeactiveStatus = targetStatus?.toLowerCase()==="deactive" || targetStatus?.toLowerCase()==="deactivated"
            const isActiveStatus = targetStatus?.toLowerCase()==="active"
            console.log("isDeactiveStatus",isDeactiveStatus)
            console.log("selectedStatus",targetStatus)

            const ratePlan_= typeof selectedRatePlan ==="string" && !selectedRatePlan.startsWith("missing-code")?selectedRatePlan:null
            let selected_rate_plan
            if (isAdmin){
            const ratePlanNameParts=(ratePlan_ || "").split(" -- ")
            selected_rate_plan = ratePlanNameParts.length>0 ? ratePlanNameParts[0] : null
            }
            else{
                selected_rate_plan = ratePlan_
            }
            changedData = {
                sim_status:targetStatus,
                device_status_id:selectedStatusID,
                //previously done
                // effective_date:effectiveDate,
                // selectedPublicIpRestriction:selectedPublicIpRestriction,
                // revIoAccountNumber:revIoAccountNumber,
                effectiveDate:effectiveDate,
                // selected_reason_code:selectedReasonCode,

                UpdateStatus: targetStatus,
                ... (isActiveStatus && {publicIpRestriction:selectedPublicIpRestriction,}),
                // PostUpdateStatusId: 8,
                Request: {
                    // ICCID: "89148000001474951901",
                    RatePlanCode: selected_rate_plan,
                    MdnZipCode: mdnZipCode || null,
                    ipAddress: ipAddress || null,
                    ...isDeactiveStatus?{
                        ReasonCode: selectedReasonCodeID || ""
                    }
                    :{},
                    thingSpacePPU: {
                        FirstName: firstName || null,
                        LastName: lastName || null,
                        AddressLine: addressLine || null,
                        City: city || null,
                        State: selectedStateCode || null,
                        ZipCode: mdnZipCode || null,
                        Country: country || null
                    }
                },
                // IntegrationAuthenticationId: 0

            }

        }
        return changedData
    }
    const disablePastDates = (current: any) => {
      return current && current < dayjs().startOf('day');
    };

    // const returnUpdatedValue = () =>{
    //     return (
    //     <Tooltip title={`${targetStatus}`}>
    //         <span>
    //             {targetStatus}
    //         </span>
    //     </Tooltip>)
    // }

    const returnUpdatedValue = () => {
            return (
                <div className="flex flex-col gap-2">
                    <div className="flex grid grid-cols-2 ">
                        <span className="font-semibold">Status:</span>
                        <span>{targetStatus}</span>
                    </div>
                </div>
            )
        }

        useImperativeHandle(ref, () => ({
            runValidation: handleContinue,
            runSubmit: () => {
            selectDevicesRef.current?.runSubmit();
        },
        returnUpdate: returnUpdatedValue
        }));

    return (

        <div className="flex flex-col h-full">
            <div>
                {/* {!showSelectDevices ? ( */}
                    <div className={showSelectDevices ? "hidden" : "block"}>
                        {isAllChangeType && (
                                        <div className="flex justify-end px-4">
                                            <span className="mr-2 font-semibold">Save Changes</span>
                                            <Checkbox
                                                checked={saveChanges}
                                                onChange={(e) => {
                                                    if (!e.target.checked) {
                                                        setsuccessFullChangeTypes(
                                                            successFullChangeTypes.filter((c: any) => c !== activeChange)
                                                        );
                                                    }
                                                    setSaveChanges(e.target.checked)
                                                }}
                                                className="custom-checkbox"
                                            >
                
                                            </Checkbox>
                                        </div>
                                    )}
                    <div className={`${!isAllChangeType?"flex flex-col space-y-4 my-4":"flex grid grid-cols-2 gap-4"}`}>
                        <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                            <label htmlFor="targetStatus" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                Target Status<span className="text-red-500">*</span>
                            </label>

                            <div className={`${!isAllChangeType?"w-2/3":""}`}>
                                <Select
                                    value={{ label: targetStatus, value: targetStatus }}
                                    id="targetStatus"
                                    placeholder="Select Target Status"
                                    options={statusOptions.map((option: string) => ({
                                        label: option,
                                        value: option,
                                    }))}
                                    onChange={handleSelectedTargetStatusChange}
                                    isClearable
                                    styles={DropdownStyles}
                                />
                                {errors.targetStatus && <div className="text-red-500">{errors.targetStatus}</div>}
                            </div>
                        </div>


                        {(targetStatus === "Active" || targetStatus === "Inventory" || targetStatus === "Pending activation") && (
                            <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                <label htmlFor="ratePlan" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                {isAdmin ? "Rate Plan Code" : "Customer Rate Plan"} {targetStatus === "Active" && <span className="text-red-500">*</span>}
                                </label>
                                <div className={`${!isAllChangeType?"w-2/3":""}`}>
                                    <Select
                                        value={{ label:isAdmin? selectedRatePlan:notAdminSelectedRatePlan, value: selectedRatePlan }}
                                        id="ratePlan"
                                        styles={DropdownStyles}
                                        placeholder={isAdmin ? 'Select Rate Plan Code' : 'Select Customer Rate Plan'}
                                        // options={ratePlanOptions.map((option: string) => ({
                                        //     label: option,
                                        //     value: option,
                                        // }))}
                                        options={ratePlanOptions.map((option: any, index: number) => {
                                                    if (isAdmin) {
                                                        return {
                                                            label: option,
                                                            value: option, // keep it same, but now it's wrapped in an object
                                                        };
                                                    } else {
                                                        return {
                                                            label: option.rate_plan || `Unnamed Plan ${index}`,
                                                            value: option.code ?? `missing-code-${index}`,
                                                        };
                                                    }
                                                })
                                        }
                                        onChange={handleSelectedRatePlanChange}
                                        // isClearable
                                    />
                                    {targetStatus === "Active" && errors.ratePlan && (
                                        <div className="text-red-500">{errors.ratePlan}</div>
                                    )}
                                </div>
                            </div>
                        )}
                        {(targetStatus === "Active" ) && (
                            <>
                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="publicIpRestriction" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        Public IP Restriction
                                    </label>
                                    <div className={`${!isAllChangeType?"w-2/3":""}`}>
                                        <Select
                                            value={{ label: selectedPublicIpRestriction, value: selectedPublicIpRestriction }}
                                            id="publicIpRestriction"
                                            placeholder="Select public IP restriction"
                                            styles={DropdownStyles}
                                            options={publicIpOptions.map((option: string) => ({
                                                label: option,
                                                value: option,
                                            }))}
                                            defaultValue={{ label: 'restricted', value: 'restricted' }}
                                            onChange={handleSelectedPublicIpChange}

                                        />
                                        {errors.publicIpRestriction && <div className="text-red-500">{errors.publicIpRestriction}</div>}

                                    </div>
                                </div>

                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="firstName" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        First Name<span className="text-red-500">*</span>
                                    </label>
                                    <div className={`${!isAllChangeType?"w-2/3":""}`}>
                                        <Input
                                            id="firstName"
                                            placeholder="Enter First Name"
                                            value={firstName}
                                            onChange={(e) => setFirstName(e.target.value)}
                                            className="input"
                                        />
                                        {errors.firstName && <div className="text-red-500">{errors.firstName}</div>}

                                    </div>

                                </div>

                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="lastName" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        Last Name<span className="text-red-500">*</span>
                                    </label>
                                    <div className={`${!isAllChangeType?"w-2/3":""}`}>

                                        <Input
                                            id="lastName"
                                            placeholder="Enter Last Name"
                                            value={lastName}
                                            onChange={(e) => setLastName(e.target.value)}
                                            className="input"
                                        />
                                        {errors.lastName && <div className="text-red-500">{errors.lastName}</div>}
                                    </div>
                                </div>

                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="addressLine" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        Address Line<span className="text-red-500">*</span>
                                    </label>
                                    <div className={`${!isAllChangeType?"w-2/3":""}`}>
                                        <Input
                                            id="addressLine"
                                            placeholder="Enter Address Line"
                                            value={addressLine}
                                            onChange={(e) => setAddressLine(e.target.value)}
                                            className="input"
                                        />
                                        {errors.addressLine && <div className="text-red-500">{errors.addressLine}</div>}
                                    </div>

                                </div>

                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="city" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        City<span className="text-red-500">*</span>
                                    </label>
                                    <div className={`${!isAllChangeType?"w-2/3":""}`}>
                                        <Input
                                            id="city"
                                            placeholder="Enter City"
                                            value={city}
                                            onChange={(e) => setCity(e.target.value)}
                                            className="input"
                                        />
                                        {errors.city && <div className="text-red-500">{errors.city}</div>}

                                    </div>
                                </div>

                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="state" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        State
                                    </label>
                                    <div className={`${!isAllChangeType?"w-2/3":""}`}>
                                        <Select
                                            value={{value:selectedStateCode , label:selectedState}}
                                            id="state"
                                            placeholder="Select State"
                                            options={stateOptions.length > 0 ? stateOptions : [{ value: 'No options', label: 'No options' }]}
                                            styles={DropdownStyles}
                                            onChange={handleSelectedStateChange}
                                        />
                                        {errors.state && <div className="text-red-500">{errors.state}</div>}

                                    </div>
                                </div>

                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="country" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        Country<span className="text-red-500">*</span>
                                    </label>
                                    <div className={`${!isAllChangeType?"w-2/3":""}`}>
                                        <Input
                                            id="country"
                                            placeholder="Enter Country"
                                            value={country} // Assuming this should be the country value
                                            onChange={(e) => setCountry(e.target.value)}
                                            className="input"
                                        />
                                        {errors.country && <div className="text-red-500">{errors.country}</div>}
                                    </div>
                                </div>

                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="mdnZipCode" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        MDN Zip Code<span className="text-red-500">*</span>
                                    </label>
                                    <div className={`${!isAllChangeType?"w-2/3":""}`}>
                                        <Input
                                            id="mdnZipCode"
                                            placeholder="Enter MDN Zip Code"
                                            value={mdnZipCode}
                                            onChange={(e) => setMdnZipCode(e.target.value)}
                                            className="input"
                                        />
                                        {errors.mdnZipCode && <div className="text-red-500">{errors.mdnZipCode}</div>}
                                    </div>
                                </div>
                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="ipAddress" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        IP Address
                                    </label>
                                    <div className={`${!isAllChangeType?"w-2/3":""}`}>
                                        <Input
                                            id="ipAddress"
                                            placeholder="Enter IP Address"
                                            value={ipAddress}
                                            onChange={(e) => setIpAddress(e.target.value)}
                                            className="input"
                                        />
                                        {/* {errors.addressLine && <div className="text-red-500">{errors.addressLine}</div>} */}
                                    </div>

                                </div>

                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="revIoAccountNumber" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                    Billing Account Number (optional)
                                    </label>
                                    <div className={`${!isAllChangeType?"w-2/3":""}`}>
                                        <Input
                                            id="revIoAccountNumber"
                                            placeholder="Enter Billing Account Number"
                                            value={revIoAccountNumber}
                                            onChange={(e) => setRevIoAccountNumber(e.target.value)}
                                            className="input"
                                        />
                                        {errors.revIoAccountNumber && <div className="text-red-500">{errors.revIoAccountNumber}</div>}
                                    </div>
                                </div>
                            </>
                        )}

                        {targetStatus === "Deactivated" && (
                            <>
                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="reasonCode" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        Reason Code
                                    </label>
                                    <Select
                                        value={{ label: selectedReasonCode, value: selectedReasonCode }}
                                        id="reasonCode"
                                        placeholder="Select Reason Code"
                                        options={reasonCodeOptions}
                                        defaultValue={{ label: 'General/Admin Maintainance', value: 'General/Admin Maintainance' }}
                                        onChange={handleSelectedReasonCodeChange}
                                        className={`${!isAllChangeType?"w-2/3":""}`}
                                        styles={DropdownStyles}
                                    />
                                </div>

                            </>
                        )}
                        {(targetStatus === "Inventory") && (
                            <>
                                {(!service_provider.toLowerCase().includes("verizon") && !service_provider.toLowerCase().includes("vzn") && !service_provider.toLowerCase().includes("vzwcr") && !service_provider.toLowerCase().includes("2215-so01")) && (
                                    <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                        <label htmlFor="reasonCode" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                            Reason Code
                                        </label>
                                        <Select
                                            value={{ label: selectedReasonCode, value: selectedReasonCode }}
                                            id="reasonCode"
                                            placeholder="Select Reason Code"
                                            options={reasonCodeOptions}
                                            defaultValue={{ label: 'General/Admin Maintainance', value: 'General/Admin Maintainance' }}
                                            onChange={handleSelectedReasonCodeChange}
                                            className={`${!isAllChangeType?"w-2/3":""}`}
                                            styles={DropdownStyles}
                                        />
                                    </div>
                                )}
                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="revIoAccountNumber" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                    Billing Account Number (optional)
                                    </label>
                                    <Input
                                        id="revIoAccountNumber"
                                        placeholder="Enter Billing Account Number"
                                        value={revIoAccountNumber}
                                        onChange={(e) => setRevIoAccountNumber(e.target.value)}
                                        className="w-2/3 input"
                                    />
                                </div>
                            </>
                        )}
                        {(targetStatus === "Pending activation") && (
                            <>
                                {/* {(
                                    <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                        <label htmlFor="reasonCode" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                            Reason Code
                                        </label>
                                        <Select
                                            value={{ label: selectedReasonCode, value: selectedReasonCode }}
                                            id="reasonCode"
                                            placeholder="Select Reason Code"
                                            options={reasonCodeOptions}
                                            defaultValue={{ label: 'General/Admin Maintainance', value: 'General/Admin Maintainance' }}
                                            onChange={handleSelectedReasonCodeChange}
                                            className={`${!isAllChangeType?"w-2/3":""}`}
                                            styles={DropdownStyles}
                                        />
                                    </div>
                                )} */}
                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="revIoAccountNumber" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                    Billing Account Number (optional)
                                    </label>
                                    <Input
                                        id="revIoAccountNumber"
                                        placeholder="Enter Billing Account Number"
                                        value={revIoAccountNumber}
                                        onChange={(e) => setRevIoAccountNumber(e.target.value)}
                                        className="w-2/3 input"
                                    />
                                </div>
                            </>
                        )}
                        {(targetStatus === "Suspended" || targetStatus === "Restore Suspended" || targetStatus === "Cancel Subscriber" || targetStatus === "Restore Cancelled") && (
                            <>

                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="reasonCode" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        Reason Code
                                    </label>
                                    <Select
                                        value={{ label: selectedReasonCode, value: selectedReasonCode }}
                                        id="reasonCode"
                                        placeholder="Select Reason Code"
                                        options={reasonCodeOptions}
                                        defaultValue={{ label: 'General/Admin Maintainance', value: 'General/Admin Maintainance' }}
                                        onChange={handleSelectedReasonCodeChange}
                                        className={`${!isAllChangeType?"w-2/3":""}`}
                                        styles={DropdownStyles}
                                    />
                                </div>
                                {/* <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                <label htmlFor="effectiveDateCheckbox" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                    Effective date
                                </label>
                                <Checkbox
                                    id="effectiveDateCheckbox"
                                    checked={effectiveDateCheckbox}
                                    onChange={(e) => setEffectiveDateCheckbox(e.target.checked)}
                                />
                            </div> */}

                                {/* Effective Date */}
                                {/* {effectiveDateCheckbox && (
                                <div className="flex flex-col space-y-1">
                                    <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                        <label htmlFor="effectiveDate" className="w-1/3 font-semibold ">
                                            Effective date
                                        </label>
                                        <DatePicker
                                            value={effectiveDate}
                                            onChange={(date) => setEffectiveDate(date)}
                                            className={`${!isAllChangeType?"w-2/3":""}`}
                                            format="DD/MM/YYYY"
                                            placeholder="DD/MM/YYYY"
                                        />
                                    </div>
                                    {effectiveDateError && (
                                        <div className="text-red-500 text-sm">
                                            {effectiveDateError}
                                        </div>
                                    )}
                                </div>
                            )} */}
                                {targetStatus !== "Restore Cancelled" && (
                                    <>
                                        <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                            <label htmlFor="effectiveDateCheckbox" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                                Effective Date
                                            </label>
                                            <Checkbox
                                                id="effectiveDateCheckbox"
                                                checked={effectiveDateCheckbox}
                                                onChange={(e) => setEffectiveDateCheckbox(e.target.checked)}
                                            />
                                        </div>

                                        {/* Effective Date */}
                                        {effectiveDateCheckbox && (
                                            <div className="flex flex-col space-y-1">
                                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                                    <label htmlFor="effectiveDate" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                                        Effective Date <span className="text-red-500">*</span>
                                                    </label>
                                                    <DatePicker
                                                        value={effectiveDate}
                                                        onChange={(date) => setEffectiveDate(date)}
                                                        className={`${!isAllChangeType?"w-2/3":"input"}`}
                                                        format="DD/MM/YYYY"
                                                        placeholder="DD/MM/YYYY"
                                                        disabledDate={disablePastDates}
                                                    />
                                                </div>
                                                {errors.effectiveDate && (
                                                    <div className="text-red-500 text-sm">
                                                        {errors.effectiveDate}
                                                    </div>
                                                )}
                                            </div>
                                        )}
                                    </>
                                )}

                            </>
                        )}


                        {/* Action Buttons */}
                        {!isAllChangeType && (
                            <div className="flex justify-center space-x-4 mt-4">
                            <button onClick={onBack} className="cancel-btn">
                                {/* <ArrowLeftIcon className="h-5 w-5 mr-2" /> */}
                                Back
                            </button>
                            <button onClick={handleContinue} className="save-btn">
                                Continue
                                {/* <ArrowRightIcon className="h-5 w-5 mr-2" /> */}
                            </button>
                        </div>
                        )}
                        
                    </div>
                    </div>
                {/* ) : ( */}
                    <div className={showSelectDevices ? "block" : "hidden"}>
                    <SelectDevices ref={selectDevicesRef} onContinue={handleContinue} onBack={onBack} service_provider={service_provider} change_type={change_type} changed_data={returnChangedData()} onCancel={onClose}/>
                    </div>
                {/* )} */}
            </div>
        </div>
    );
}
)

export default Activated1;
