"use client";

import { FC, useState, lazy, Suspense, useEffect, Key, useRef } from "react";
import { message, Modal, notification, Spin, Table } from "antd";
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import React from "react";
import { useRouter } from 'next/navigation';
import { PerformanceLogStore } from "@/app/stores/performance_matrix_store";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useAllChangeTypesStore } from "@/app/stores/allChangeTypesStore";
import { ArchiveContentRef } from "./archive_modal_main";
import { ActivateServiceContentRef } from "./activate_service_main";
import { DeviceContentRef } from "./all_change_types_devices";
import { AssignCustomerContentRef } from "./assign_customer_duplicate";
import { CarrierRatePlan1ContentRef } from "./carrier_rate_plan_modal1";
import { CarrierRatePlan2ContentRef } from "./carrier_rate_plan_modal2";
import { CarrierRatePlan3ContentRef } from "./carrier_rate_plan_modal3";
import { CustomerRatePlanContentRef } from "./customer_rate_plan_modal_main";
import { EditUsernameContentRef } from "./edit_username_modal_main";
import { IndividualLineSyncContentRef } from "./individual_line_sync";
import { UpdateFeaturesContentRef } from "./update_features_main";
import { Activated1ContentRef } from "./update_device_status_1";
import { Activated2ContentRef } from "./update_device_status_main";
import { RefreshALineContentRef } from "./refresh_line_main";
import { ChangeICCIDContentRef } from "./change_iccid_modal_main";
import { ChangePhoneNumberContentRef } from "./change_phone_numbers_main";
import { UpdatePPUAddressContentRef } from "./update_ppu_address_main";
import { SendSMSContentRef } from "./send_sms_main";
import { VoiceMailPswdContentRef } from "./reset_voicemail_password_main";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";


const messageStyle = {
    fontSize: '14px',
    fontWeight: 'bold',
    padding: '16px',
};
const AllChangeTypesDevices = lazy(() => import("./all_change_types_devices"));
const ArchiveContent = lazy(() => import("./archive_modal_main"));
const AssignCustomerContent = lazy(() => import("./assign_customer_duplicate"));
const ChangeCarrierRatePlan1 = lazy(() => import("./carrier_rate_plan_modal1"));
const ChangeCarrierRatePlan2 = lazy(() => import("./carrier_rate_plan_modal2"));
const ChangeCarrierRatePlan3 = lazy(() => import("./carrier_rate_plan_modal3"));
const ChangeCustomerRatePlan = lazy(() => import("./customer_rate_plan_modal_main"));
const EditUsername = lazy(() => import("./edit_username_modal_main"));
const ChangeICCIDContent = lazy(() => import("./change_iccid_modal_main"));
const ChangePhoneNumber = lazy(() => import("./change_phone_numbers_main"));
const ChangeDeviceStatus = lazy(() => import("./update_device_status_main"));
const ChangeDeviceStatus1 = lazy(() => import("./update_device_status_1"));
const NewService = lazy(() => import("./activate_service_main"));
const UpdatePPUAddress = lazy(() => import("./update_ppu_address_main"));
const UpdateFeatures = lazy(() => import("./update_features_main"));
const RefreshLine = lazy(() => import("./refresh_line_main"));
const IndividualLineSync = lazy(() => import("./individual_line_sync"));
const SendSMS = lazy(() => import("./send_sms_main"));
const ResetVoiceMailPswd = lazy(() => import("./reset_voicemail_password_main"));

interface NewChangeProps {
    originalChangeTypeOptions: any[]
    selectedServiceProvider: any
    handleCancel: () => void;
    handleFinish: () => void;
    onBack: () => void;
    isBPEnabled: boolean;
    activationData: any;
    refreshData: () => void
}

const AllChangeTypes: React.FC<NewChangeProps> = ({ originalChangeTypeOptions, selectedServiceProvider, handleCancel, handleFinish, isBPEnabled, onBack, activationData, refreshData }) => {
    const [selectedAction, setSelectedAction] = useState<string>("");
    const [selectedTempAction, setSelectedTempAction] = useState<string>("Devices");
    const [changeTypeOptions, setChangeTypeOptions] = useState<any>([])
    const [dropdownData, setDropdownData] = useState<any>([])
    const [screenOrder, setScreenOrder] = useState<any>([])
    const [loading, setLoading] = useState(false);
    const { username, role, partner, token, selectedDb, firstLastName, sessionId, metaData } = useAuth();
    const { getTargetTenantProvider } = PerformanceLogStore();
    const { isValidated, setActiveChange, validationTrigger, successFullChangeTypes, successFullScreenOrders, setsuccessFullScreenOrders, allChangeTypesDevices } = useAllChangeTypesStore();
    const [activeScreen, setActiveScreen] = useState<string>(screenOrder?.[0] || "");
    const [isSubmitModalVisible, setIsSubmitModalVisible] = useState(false);
    const [isSubmitClicked, setIsSubmitClicked] = useState(false);
    const { addExport, removeExport, exports } = exportLoadingStore();
    const router = useRouter();
    const containerRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const filtered_change_types = originalChangeTypeOptions.filter((option: any) => (option !== "All Change Types"))
        setChangeTypeOptions(["Devices", ...filtered_change_types])
        setScreenOrder(["devices"])
        setSelectedAction("Devices")
    }, [])

    useEffect(() => {
        console.log("successFullChangeTypes", successFullChangeTypes);

        const activeScreenName = changeTypeMap[activeScreen];
        console.log("activeScreenName", activeScreenName);

        const currentOrders = useAllChangeTypesStore.getState().successFullScreenOrders;
        console.log("successFullChangeTypes", successFullChangeTypes)
        console.log("currentOrders", currentOrders)

        const newOrders = new Set(currentOrders); // use Set to avoid duplicates

        if (successFullChangeTypes.includes(activeScreenName)) {
            newOrders.add(activeScreen);
        } else {
            newOrders.delete(activeScreen);
        }

        console.log("newOrders after modification", Array.from(newOrders));
        setsuccessFullScreenOrders(Array.from(newOrders));
    }, [successFullChangeTypes]);



    useEffect(() => {
        setActiveScreen(screenOrder?.[0] || "")
    }, [screenOrder])

    useEffect(() => {
        setActiveChange(selectedAction || "Devices")
    }, [selectedAction])

    const scroll = (direction: "left" | "right") => {
        if (containerRef.current) {
            const scrollAmount = direction === "left" ? -300 : 300;
            containerRef.current.scrollBy({ left: scrollAmount, behavior: "smooth" });
        }
    };
    const isAdmin = role?.toLowerCase() === "super admin" || role?.toLowerCase() === "partner admin"
    const parseList = (value: any) => {
        if (typeof value === 'string') {
            let parsedPlans: any[];
            try {
                parsedPlans = JSON.parse(value)
            }
            catch (err) {
                console.log(err)
                parsedPlans = []
            }
            return Array.isArray(parsedPlans) ? parsedPlans : [];
        }
        if (Array.isArray(value)) {
            return value;
        }
        return [];
    };

    const fetchCarrierWritesFlag = async () => {
        let parsedData: any
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
            tenant_name: partner || "default_value",
            username,
            path: "/get_writes_enable_for_service_provider",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "Inventory",
            service_provider: selectedServiceProvider || "",
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            environment: "BETA",
            change_type: "All Change Types",
        };

        try {
            setLoading(true);
            const response = await axios.post(url, { data });
            parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === true) {
                const write_is_enabled = parsedData?.write_is_enabled || false;
                // setWritesFlag(write_is_enabled);
                return write_is_enabled;
            }
        } catch (error) {
            console.error("Error fetching data:", error);
            return false; // fallback in case of error
        } finally {
            setLoading(false);
        }
    };
    const submitCarrierStatus = async (write_is_enabled: boolean) => {
        const devices = allChangeTypesDevices?.iccids || []
        let parsedData: any
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
            tenant_name: partner || "default_value",
            username,
            path: "/insert_carrier_status_validation_audit",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "Inventory",
            service_provider: selectedServiceProvider || "",
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            environment: "BETA",
            ...(allChangeTypesDevices?.isIccid ? {
                msisdn: [],
                iccid: [...devices]
            } : {
                msisdn: [...devices],
                iccid: []
            }),
            change_type: "All Change Types",
            write_is_enabled: write_is_enabled,
        };

        try {
            // setLoading(true);
            const response = await axios.post(url, { data });
            parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === true) {

            }
        } catch (error) {
            console.error("Error fetching data:", error);
        } finally {
            // setLoading(false);
        }
    };
    const fetchChangeType = async (change_type: string) => {
        try {
            setLoading(true);
            const url =
                ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                path: "/get_new_bulk_change_data",
                request_received_at: getCurrentDateTime(),
                username: username,
                firstLastName: firstLastName,
                role_name: role,
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: selectedServiceProvider,
                change_type: change_type,
                parent_provider_name: getTargetTenantProvider(selectedServiceProvider || "") || ""
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                setLoading(false);
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                const screen_order_ = parsedData?.response_data?.screen_names_seq || []
                const parsedOrder = parseList(screen_order_)
                setScreenOrder(parsedOrder)
                const dropdownData_ = parsedData?.response_data?.dropdown_data || {}
                setDropdownData(dropdownData_)
                setLoading(false);
            }
        } catch (error) {
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        }
    };

    const handleChangeTypeClick = (changeType: string) => {
        setSelectedAction(changeType)
        if (changeType === "Devices") {
            setScreenOrder(["devices"])
        }
        else {
            fetchChangeType(changeType)
        }
    };

    const archiveRef = useRef<ArchiveContentRef>(null);
    const activeRef = useRef<ActivateServiceContentRef>(null);
    const devicesRef = useRef<DeviceContentRef>(null);
    const assignCustomerRef = useRef<AssignCustomerContentRef>(null);
    const carrier1Ref = useRef<CarrierRatePlan1ContentRef>(null);
    const carrier2Ref = useRef<CarrierRatePlan2ContentRef>(null);
    const carrier3Ref = useRef<CarrierRatePlan3ContentRef>(null);
    const customerRef = useRef<CustomerRatePlanContentRef>(null);
    const editUserNameRef = useRef<EditUsernameContentRef>(null);
    const lineSyncRef = useRef<IndividualLineSyncContentRef>(null);
    const featuresRef = useRef<UpdateFeaturesContentRef>(null);
    const deviceStatus1Ref = useRef<Activated1ContentRef>(null);
    const deviceStatus2Ref = useRef<Activated2ContentRef>(null);
    const refreshLineRef = useRef<RefreshALineContentRef>(null);
    const changeICCIDRef = useRef<ChangeICCIDContentRef>(null);
    const phoneNumberRef = useRef<ChangePhoneNumberContentRef>(null);
    const ppuAddressRef = useRef<UpdatePPUAddressContentRef>(null);
    const sendSMSRef = useRef<SendSMSContentRef>(null);
    const voiceMailRef = useRef<VoiceMailPswdContentRef>(null);


    const refMap: Record<string, React.RefObject<any>> = {
        "archive-main": archiveRef,
        "new-service-main": activeRef,
        "devices": devicesRef,
        "assign-customer-main": assignCustomerRef,
        "update-features": featuresRef,
        "carrier-rate-plan-1": carrier1Ref,
        "carrier-rate-plan-2": carrier2Ref,
        "carrier-rate-plan-3": carrier3Ref,
        "customer-rate-plan-main": customerRef,
        "edit-username-main": editUserNameRef,
        "iccid-imei-main": changeICCIDRef,
        "change-phone-number-main": phoneNumberRef,
        "device-status-main": deviceStatus2Ref,
        "device-status-1": deviceStatus1Ref,
        "update-ppu-address": ppuAddressRef,
        "refresh-aline": refreshLineRef,
        "individual-line-sync": lineSyncRef,
        "send-sms-main": sendSMSRef,
        "reset-voice-mail-password-main": voiceMailRef,
    };
    const changeTypeMap: Record<string, string> = {
        "archive-main": "Archive",
        "new-service-main": "Activate New Service",
        "devices": "Devices",
        "assign-customer-main": "Assign Customer",
        "update-features": "Update Features",
        "carrier-rate-plan-1": "Change Carrier Rate Plan",
        "carrier-rate-plan-2": "Change Carrier Rate Plan",
        "carrier-rate-plan-3": "Change Carrier Rate Plan",
        "customer-rate-plan-main": "Change Customer Rate Plan",
        "edit-username-main": "Edit Username/Cost Center",
        "iccid-imei-main": "Change ICCID/IMEI",
        "change-phone-number-main": "Change Phone Number",
        "device-status-main": "Update Device Status",
        "device-status-1": "Update Device Status",
        "update-ppu-address": "Update PPU address",
        "refresh-aline": "Refresh A Line",
        "individual-line-sync": "Line Sync",
        "send-sms-main": "Send SMS",
        "reset-voice-mail-password-main": "Reset Voicemail Password",
    };


    const onSubmitClick = async () => {
        setSelectedTempAction(selectedAction)
        validationCheck(selectedAction, "submit")

    }

    const confirmSubmit = async () => {
        try {
            addExport("bulkChangeInsert", "Bulk Change Submission");
            handleCancel()
            console.log("successFullScreenOrders", successFullScreenOrders)
            const successScreens: any = [...new Set([...successFullScreenOrders])]
            for (const changeType of successScreens) {
                const ref = refMap[changeType];
                if (ref?.current?.runSubmit) {
                    console.log("Submitting for changeType:", changeType, ref?.current?.runSubmit);
                    await ref.current.runSubmit();
                }
            }
        }
        catch (err) {
            console.log("error occured while submitting all change types", err)
        }
        finally {
            removeExport("bulkChangeInsert");
            notification.success({
                message: "Success",
                description: "Successfully submitted!",
                style: messageStyle,
                placement: "top",
            });
            refreshData()
        }

    }

    const handleSubmit = async () => {
        const writes_flag = await fetchCarrierWritesFlag()
        if (writes_flag) {
            const modal = Modal.confirm({
                title: "Carrier API Enabled",
                content: "Carrier API settings are enabled. Submitting now will trigger the Carrier API directly. Do you want to proceed?",
                centered: true,
                okText: "Submit",
                onOk: () => {
                    // modal.destroy(); // closes the modal
                    // handleCloseModal();
                    setIsSubmitModalVisible(false)
                    confirmSubmit();
                    submitCarrierStatus(writes_flag);
                },
                onCancel: () => {
                    setIsSubmitModalVisible(false)
                }
            });
        }
        else {
            confirmSubmit();
        }

    };



    const validationCheck = async (changeType: string, mode: string) => {
        if (mode === "submit") {
            setIsSubmitClicked(true)
        }
        else {
            setIsSubmitClicked(false)
        }
        setSelectedTempAction(changeType);

        // Find the matching ref dynamically
        const currentRef = refMap[activeScreen];

        // Run validation if ref exists and has the method
        if (currentRef?.current?.runValidation) {
            await currentRef.current.runValidation();
        }

        console.log("isValidated", isValidated, changeType, validationTrigger);
    };

    useEffect(() => {
        console.log("isValidated..", isValidated)
        if (isValidated) {
            handleChangeTypeClick(selectedTempAction)
            if (isSubmitClicked) {
                if (successFullChangeTypes.length > 1) {
                    setTimeout(() => {
                        console.log("successFullScreenOrders", successFullScreenOrders)

                        // handleSubmit()
                    }, 2000);


                    setIsSubmitModalVisible(true)
                }
                else {
                    message.error("Please fill in atleast one change type")
                }

            }

        }
    }, [validationTrigger])

    const renderContent = () => {
        // if (!selectedServiceProvider || !selectedAction) return null;

        // const mapping = screen_mapping.find(
        //     (item) =>
        //         item.service_provider === selectedServiceProvider &&
        //         item.change_type === selectedAction
        // );

        // if (!mapping) return null;
        return (
            <>
                <div className={`flex justify-center items-center h-[400px] ${loading ? "" : "hidden"}`}>
                    <Spin size="large" />
                </div>
                <div className={(activeScreen === "devices" && !loading) ? "" : "hidden"}>
                    <AllChangeTypesDevices
                        ref={devicesRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Devices"}
                        onClose={handleCancel}
                    />
                </div>
                <div className={(activeScreen === "archive-main" && !loading) ? "" : "hidden"}>
                    <ArchiveContent
                        ref={archiveRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Archive"}
                        onCancel={handleCancel}
                    />
                </div>
                <div className={(activeScreen === "assign-customer-main" && !loading) ? "" : "hidden"}>
                    <AssignCustomerContent
                        ref={assignCustomerRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Assign Customer"}
                        isSubmitScreen={isBPEnabled}
                        onClose={handleCancel}
                    />
                </div>
                <div className={(activeScreen === "carrier-rate-plan-1" && !loading) ? "" : "hidden"}>
                    <ChangeCarrierRatePlan1
                        ref={carrier1Ref}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Change Carrier Rate Plan"}
                        onClose={handleCancel} />
                </div>
                <div className={(activeScreen === "carrier-rate-plan-2" && !loading) ? "" : "hidden"}>
                    <ChangeCarrierRatePlan2
                        ref={carrier2Ref}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Change Carrier Rate Plan"}
                        onClose={handleCancel} />
                </div>

                <div className={(activeScreen === "carrier-rate-plan-3" && !loading) ? "" : "hidden"}>
                    <ChangeCarrierRatePlan3
                        ref={carrier3Ref}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Change Carrier Rate Plan"}
                        onClose={handleCancel} />
                </div>
                <div className={(activeScreen === "customer-rate-plan-main" && !loading) ? "" : "hidden"}>
                    <ChangeCustomerRatePlan
                        ref={customerRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Change Customer Rate Plan"}
                        isSubmitScreen={isBPEnabled}
                        onClose={handleCancel} />
                </div>

                <div className={(activeScreen === "edit-username-main" && !loading) ? "" : "hidden"}>
                    <EditUsername
                        ref={editUserNameRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Edit Username/Cost Center"}
                        onClose={handleCancel} />
                </div>

                <div className={(activeScreen === "iccid-imei-main" && !loading) ? "" : "hidden"}>
                    <ChangeICCIDContent
                        ref={changeICCIDRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Change ICCID/IMEI"}
                        onClose={handleCancel} />
                </div>

                <div className={(activeScreen === "change-phone-number-main" && !loading) ? "" : "hidden"}>
                    <ChangePhoneNumber
                        ref={phoneNumberRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Change Phone Number"}
                        onClose={handleCancel} />
                </div>

                <div className={(activeScreen === "device-status-main" && !loading) ? "" : "hidden"}>
                    <ChangeDeviceStatus
                        ref={deviceStatus2Ref}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Update Device Status"}
                        onClose={handleCancel} />
                </div>

                <div className={(activeScreen === "device-status-1" && !loading) ? "" : "hidden"}>
                    <ChangeDeviceStatus1
                        ref={deviceStatus1Ref}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Update Device Status"}
                        onClose={handleCancel} />
                </div>

                <div className={(activeScreen === "new-service-main" && !loading) ? "" : "hidden"}>
                    <NewService
                        ref={activeRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Activate New Service"}
                        activationData={activationData}
                        isSubmitScreen={!isAdmin}
                        onClose={handleCancel} />
                </div>

                <div className={(activeScreen === "update-ppu-address" && !loading) ? "" : "hidden"}>
                    <UpdatePPUAddress
                        ref={ppuAddressRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Update PPU address"}
                        isSubmitScreen={false}
                        onClose={handleCancel} />
                </div>

                <div className={(activeScreen === "update-features" && !loading) ? "" : "hidden"}>
                    <UpdateFeatures
                        ref={featuresRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Update Features"}
                        onClose={handleCancel} />
                </div>
                <div className={(activeScreen === "refresh-aline" && !loading) ? "" : "hidden"}>
                    <RefreshLine
                        ref={refreshLineRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Refresh A Line"}
                        onClose={handleCancel} />
                </div>
                <div className={(activeScreen === "individual-line-sync" && !loading) ? "" : "hidden"}>
                    <IndividualLineSync
                        ref={lineSyncRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Line Sync"}
                        onClose={handleCancel} />
                </div>
                <div className={(activeScreen === "send-sms-main" && !loading) ? "" : "hidden"}>
                    <SendSMS
                        ref={sendSMSRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Send SMS"}
                        onClose={handleCancel} />
                </div>
                <div className={(activeScreen === "reset-voice-mail-password-main" && !loading) ? "" : "hidden"}>
                    <ResetVoiceMailPswd
                        ref={voiceMailRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Reset Voicemail Password"}
                        onClose={handleCancel} />
                </div>
            </>
        )
    }

    const modalWidth = typeof window !== 'undefined' ? (window.innerWidth * 2.5) / 4 : 0;
    const modalHeight =
        typeof window !== "undefined" ? (window.innerHeight * 3) / 4 : 0;
    // if (loading) {
    //     return (
    //         <>
    //             <div className="flex justify-center items-center h-[400px] w-[700px]">
    //                 <Spin size="large" />
    //             </div>
    //         </>
    //     );
    // }

    const getBGColor = (changeType: string) => {
        if (changeType === selectedAction) {
            return "bg-blue-300"
        }
        else if (successFullChangeTypes.includes(changeType)) {
            return "bg-green-400"
        }
        else {
            return "bg-gray-500"
        }
    }
    // Define columns for the Modal table
    const columns = [
        {
            title: "Change Type",
            dataIndex: "changeType",
            key: "changeType",
            width: "50%",
        },
        {
            title: <div className="text-center">Updated Value</div>,
            dataIndex: "updatedValue",
            key: "updatedValue",
            render: (value: React.ReactNode) => value,
            width: "50%",
            //  align: "center",
        },
    ];

    // Build table data dynamically
    const dataSource = [...new Set(successFullChangeTypes)]
        .filter((type) => type !== "Devices") // exclude "Devices"
        .map((type, index) => {
            // Find all keys that map to this change type
            const matchingKeys = Object.keys(changeTypeMap).filter(
                (key) => changeTypeMap[key] === type
            );

            // Pick the first key that exists in successFullScreenOrders
            const validKey = matchingKeys.find((key) =>
                successFullScreenOrders?.includes(key)
            );

            const ref = validKey ? refMap[validKey] : null;

            // Safely call returnUpdate()
            let updatedValue: React.ReactNode = null;
            if (ref?.current?.returnUpdate) {
                try {
                    const value = ref.current.returnUpdate();
                    if (value instanceof Promise) {
                        value.then((res) => {
                            // Update asynchronously if needed
                            dataSource[index].updatedValue = res;
                        });
                    } else {
                        updatedValue = value;
                    }
                } catch (err) {
                    console.error(`Error getting updated value for ${type}:`, err);
                }
            }

            return {
                key: index,
                changeType: type,
                updatedValue,
            };
        });



    return (
        <>

            <div className="pt-3" style={{ width: modalWidth }}>
                <div className="flex justify-center mb-2">
                    <button onClick={() => scroll("left")} className="bulkchange-navigation">
                        <ChevronLeft />
                    </button>

                    <div className="bulkchange-actions-container" ref={containerRef}>
                        {changeTypeOptions.map((item: any, index: number) => (
                            <div key={item.id} className="bulkchange-action-box">
                                <div className="bulkchange-action">
                                    {item}
                                </div>
                                {/* <div className=""> */}
                                <div
                                    className={`bulkchange-status-circle ${getBGColor(item)} hover:cursor-pointer`}
                                    onClick={() => {
                                        if (!loading) {
                                            validationCheck(item, "navigation")
                                        }
                                    }}></div>
                                {/* </div> */}
                                {(index !== changeTypeOptions.length - 1 && index !== 0) && (
                                    <div className="bulkchange-horizontal-dotted-line"></div>
                                )}
                                {index === changeTypeOptions.length - 1 && (
                                    <div className="last-bulkchange-horizontal-dotted-line"></div>
                                )}
                                {index === 0 && (
                                    <div className="start-bulkchange-horizontal-dotted-line"></div>
                                )}

                            </div>
                        ))}
                    </div>
                    <button onClick={() => scroll("right")} className="bulkchange-navigation">
                        <ChevronRight />
                    </button>

                </div>

                {renderContent()}
                <div className="flex justify-center space-x-4 mt-4">
                    <button onClick={onBack} className="cancel-btn">
                        {/* <ArrowLeftIcon className="h-5 w-5 mr-2" /> */}
                        Back
                    </button>
                    <button className={`${successFullChangeTypes.length < 1 ? "cancel-btn cursor-not-allowed" : "save-btn"}`} onClick={onSubmitClick} disabled={successFullChangeTypes.length < 1}>
                        Submit
                        {/* <ArrowRightIcon className="h-5 w-5 ml-2" /> */}
                    </button>
                </div>

            </div >

            <Modal
                title="Successful Change Types"
                visible={isSubmitModalVisible}
                onCancel={() => setIsSubmitModalVisible(false)}
                footer={
                    <div className="justify-center flex space-x-4">
                        <button
                            onClick={() => setIsSubmitModalVisible(false)}
                            className="cancel-btn"
                        >
                            Cancel
                        </button>
                        <button onClick={handleSubmit} className="save-btn">
                            Submit
                        </button>
                    </div>
                }
                centered
                width={800}
            >
                <>
                    {loading ? (
                        <div className={`flex justify-center items-center h-[400px]`}>
                            <Spin size="large" />
                        </div>
                    ) : (
                        successFullChangeTypes.length > 0 ? (
                            <div style={{ maxHeight: "500px", overflowY: "auto" }}>
                                <Table
                                    columns={columns}
                                    dataSource={dataSource}
                                    pagination={false}
                                    bordered
                                    scroll={{ y: 400 }}
                                />
                            </div>
                        ) : (
                            <p className="text-center text-gray-500">No successful change types found.</p>
                        )
                    )}

                </>
            </Modal>

        </>

    );
};

export default AllChangeTypes;