"use client";

import { FC, forwardRef, useEffect, useImperativeHandle, useState } from "react";
import { Checkbox, Input, Modal, Spin, Tooltip } from "antd";
import Select from "react-select";
import SelectDevices from "./select_devices";
import React from "react";
import { DropdownStyles } from "@/app/components/css/dropdown";
import { useAuth } from "@/app/components/auth_context";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import axios from "axios";
import { useFeatureStore } from "../../inventory/featureStore";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { useRouter } from "next/navigation";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { useAllChangeTypesStore } from "@/app/stores/allChangeTypesStore";

interface RefreshALineProps {
    onContinue: () => void;
    onBack: () => void;
    dropdown: any;
    service_provider: any;
    change_type: any;
    onClose: () => void;
}

export interface RefreshALineContentRef {
    runValidation: () => Promise<void> | void;
    runSubmit: () => Promise<void> | void;
    returnUpdate: () => React.ReactNode | Promise<React.ReactNode>;
}

const RefreshALine = forwardRef<RefreshALineContentRef, RefreshALineProps>(
    ({ onContinue, onBack, dropdown, service_provider, change_type, onClose }, ref) => {
        const [errors, setErrors] = useState<string[]>([]);
        const [loading, setLoading] = useState(false);
        const { username, role, partner, token, selectedDb, metaData, firstLastName, sessionId, modulesVersionMap } = useAuth();
        const [billingAccountNumber, setBillingAccountNumber] = useState<string | undefined>(undefined);
        const [BANOptions, setBANOptions] = useState<any>([])
        const [BANError, setBANError] = useState<string>("");
        const [subscriberNumber, setSubscriberNumber] = useState<string>("");
        const [iccids, setIccids] = useState<string>("");
        const [errorMessage, setErrorMessage] = useState("");
        const { setRowId, setBulkRow, bulkChangeLimit, simIdentifierMap } = useFeatureStore();
        const router = useRouter();
        const initial_version_flag = modulesVersionMap?.["Sim Management-Bulk Change"] || false
        const isVersionEnabled = localStorage.getItem("switch_user_2_0_bulk_change") === "True";
        const switch_user_2_0 = isVersionEnabled && initial_version_flag ? "True" : "False"
        const { addExport, removeExport, exports } = exportLoadingStore();
        const { isAllChangeType, setIsValidated, setValidationTrigger, setsuccessFullChangeTypes, activeChange, successFullChangeTypes, allChangeTypesDevices } = useAllChangeTypesStore();
        const [saveChanges, setSaveChanges] = useState<boolean>(true);

        useEffect(() => {
            if (!isAllChangeType) {
                setBillingAccountNumber(undefined)
            }
            fetchBANs()

        }, [dropdown]);

        useEffect(() => {
            if (isAllChangeType) {
                const devices = allChangeTypesDevices?.iccids || []
                const devicesString = devices.join('\n')
                if (allChangeTypesDevices?.isIccid) {
                    setSubscriberNumber("")
                    setIccids(devicesString);
                }
                else {
                    setIccids("")
                    setSubscriberNumber(devicesString);
                }
            }
        }, [isAllChangeType, allChangeTypesDevices]);

        const fetchBANs = async () => {
            try {
                setLoading(true);
                const url =
                    ENV_ROUTES.SIM_MANAGEMENT;
                const data = {
                    tenant_name: partner || "default_value",
                    username: username,
                    firstLastName: firstLastName,
                    path: "/get_user_billing_account_number",
                    role_name: role,
                    Partner: partner,
                    request_received_at: getCurrentDateTime(),
                    access_token: token,
                    db_name: selectedDb,
                    ...metaData,
                    sessionID: sessionId,
                };

                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);
                if (parsedData.flag === false) {
                    Modal.error({
                        title: 'Submit Error',
                        content: parsedData.message || 'An error occurred while submitting data. Please try again.',
                        centered: true,
                    });
                } else {
                    const ban_options = parsedData?.data || []
                    setBANOptions(ban_options)
                }
            } catch (error) {
                Modal.error({
                    title: 'Submit Error',
                    content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching BANs. Please try again.',
                    centered: true,
                });
            }
            finally {
                setLoading(false)
            }
        };

        const handleContinue = async () => {
            if (!billingAccountNumber) {
                setBANError("Billing account number is required.")
            } else { setBANError("") }
            if (!subscriberNumber && !iccids) {
                setErrorMessage("Please fill ICCID field or MSISDN field.")
            }
            else {
                setErrorMessage("")
                const selected_devices = subscriberNumber ? subscriberNumber : iccids
                const iccidList = selected_devices
                    .split(/\s*[\n,]\s*/)
                    .map((line) => line.trim())
                    .filter((line) => line.length > 0);

            const isTelegence = service_provider.toLowerCase().includes("telegence");

                const newErrors: string[] = [];
                console.log("iccid list", iccidList)

                iccidList.forEach((line, index) => {
                    const label = subscriberNumber ? "Subscriber Number" : "ICCID";
                    const minLength = subscriberNumber ? 10 : 14;
                    const maxLength = subscriberNumber ? 18 : 22;

                    if (line.length === 0) {
                        newErrors[index] = `${label} must not be empty`;
                    } else if (!/^\d+$/.test(line)) {
                        newErrors[index] = `Please enter numbers only for ${label}. Letters or special characters are not allowed`;
                    } else if (line.length < minLength || line.length > maxLength) {
                        newErrors[index] = `${label} must be between ${minLength} and ${maxLength} digits long`;
                    }
                });
                if (iccidList.length > bulkChangeLimit) {
                    newErrors.push(`This request exceeds the allowed record limit  of ${bulkChangeLimit} and cannot be processed`);
                    console.log("Limit Exceeded");
                }
                setErrors(newErrors);
                console.log("new errors", newErrors)

                if (newErrors.length === 0 && !errorMessage && !BANError) {
                    if (!isAllChangeType) {
                onsubmit()
                    }
                    else {
                        if (billingAccountNumber) {
                            if (saveChanges) {
                                setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
                            }
                            setIsValidated(true)
                            setValidationTrigger();
                            return
                        }
                        else {
                            setErrorMessage("")
                            setBANError("")
                            setsuccessFullChangeTypes(
                                successFullChangeTypes.filter((c: any) => c !== activeChange)
                            );
                            setIsValidated(true)
                            setValidationTrigger();
                            return
                        }
                    }

                }
                if (newErrors.length > 0) {
                    setErrors(newErrors);
                    return;
                }
            }

            setErrors([]);
        };

    const fetchDevices = async (devices_list: any[], deviceKey: string) => {
            try {
                setLoading(true);
                const url =
                    ENV_ROUTES.BULKCHANGE_PROCESSOR;
                const data = {
                    tenant_name: partner || "default_value",
                    username: username,
                    firstLastName: firstLastName,
                    path: "/get_standard_iccid_msisdn_data",
                    role_name: role,
                    Partner: partner,
                    request_received_at: getCurrentDateTime(),
                    access_token: token,
                    db_name: selectedDb,
                    ...metaData,
                    sessionID: sessionId,
                    service_provider: service_provider,
                    change_type: change_type,
                    [deviceKey]: devices_list || []
                };

                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);
                if (parsedData.flag === false) {
                    // setLoading(false);
                    Modal.error({
                        title: 'Submit Error',
                        content: parsedData.message || 'An error occurred while submitting data. Please try again.',
                        centered: true,
                    });
                    return []
                } else {
                    const responseKey = deviceKey === "iccids" ? "msisdns" : "iccids"
                    const devices = parsedData?.[responseKey] || []
                    console.log("devices", devices)
                    return devices
                    // setLoading(false);
                }
            } catch (error) {
                Modal.error({
                    title: 'Submit Error',
                    content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting data. Please try again.',
                    centered: true,
                });
                return []
                // setLoading(false);
            }
            finally {
                // setLoading(false)
            }
        };

        const getIccidList = async (): Promise<string[]> => {
            // Pick devices based on subscriberNumber or iccids
            const devices_ = subscriberNumber ? subscriberNumber : iccids;

            // Find matching device type from the map
            const matchedDeviceTypeItem = simIdentifierMap.find((item: any) => {
                return (
                    item.service_provider === service_provider &&
                    item.change_type === change_type
                );
            });
            const matchedDeviceType = matchedDeviceTypeItem?.sim_identifier || ""
            // Decide expected type
            const selectDeviceType = subscriberNumber ? "msisdns" : "iccids";
            // Split devices into a list
            let iccidList = devices_
                .split(/\s*[\n,]\s*/)
                .map((line) => line.trim())
                .filter((line) => line.length > 0);

            // Fetch devices only if types mismatch
            if (matchedDeviceType !== selectDeviceType) {
                iccidList = await fetchDevices(iccidList, selectDeviceType);
            }

            return iccidList;
        };
        const call_2_0_submit = async (parsedData: any, payload: any) => {
            try {
                const payload_data = { ...payload }
                const url = ENV_ROUTES.BULKCHANGE_PROCESSOR;
                const prevChangedData = payload_data?.changed_data || {}
                payload_data["msisdns"] = payload_data?.iccids
                delete payload_data["iccids"]
                if (change_type === "Update Features") {
                    delete payload_data["changed_data"]
                }
                const payloadData = {
                    ...payload_data,
                    path: "/bulk_change_processor",
                    request_received_at: getCurrentDateTime(),
                    bulk_change_id: parsedData?.bulk_chnage_id_20,
                }
                const data = { ...payloadData };
                const response = await axios.post(url, { data });
                const responseData = JSON.parse(response.data.body);
                if (responseData.flag === false) {
                    console.log("Failure: 2.0 Bulk change update failed.");
                } else {
                    console.log("Success: 2.0 Bulk change update successful.");
                }
            }
            catch (error) {
                console.error("Error running DB script:", error);
            } finally {
                setLoading(false);
            }
        }

        const call_2_0_sync = async (parsedData: any) => {
            try {
                const runDbScriptUrl = ENV_ROUTES.SIM_MANAGEMENT;
                const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
                const runDbScriptData = {
                    tenant_name: partner || "default_value",
                    username: username,
                    firstLastName: firstLastName,
                    path: "/update_bulk_change_tables_10",
                    role_name: role,
                    module_name: "Bulk Change",
                    access_token: token,
                    db_name: selectedDb,
                    ...metaData,
                    sessionID: sessionId,
                    request_received_at: getCurrentDateTime(),
                    Partner: partner,
                    // service_provider_id: service_provider_id_,
                    // bulkchange_id: parsedData?.bulkchange_id?.id,
                    // data: parsedData?.data,
                    data: {
                        bulk_change_id: parsedData?.bulk_chnage_id_20,
                    },
                    is_update: false,
                    // bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
                };

                const runDbScriptResponse = await axios.post(runDbScriptUrl, { data: runDbScriptData });
                const runDbScriptResponseData = JSON.parse(runDbScriptResponse.data.body);

                if (runDbScriptResponseData.flag === false) {
                    console.error("Data Fetch Error: " + runDbScriptResponseData.message);
                } else {
                    console.log("Success: Bulk update successful.");
                }
            }
            catch (error) {
                console.error("Error running DB script:", error);
            } finally {
                setLoading(false);
            }
        }
        const bulkChangeInsert = async (payload: any) => {
            let partner_name = partner
            let db_name_ = selectedDb
            try {
                const url = ENV_ROUTES.SIM_MANAGEMENT;
                const data = {
                    tenant_name: partner_name || "default_value",
                    username: username,
                    firstLastName: firstLastName,
                    path: "/get_bulk_change_insertion",
                    role_name: role,
                    module_name: "Bulk Change History",
                    service_provider_name: service_provider,
                    change_type: change_type,
                    access_token: token,
                    db_name: selectedDb,
                    ...metaData,
                    sessionID: sessionId,
                    request_received_at: getCurrentDateTime(),
                    Partner: partner_name,
                };

                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);

                if (parsedData.flag === false) {
                    console.error("Error fetching bulk change data:", parsedData.message ||
                        "An error occurred while fetching bulk change data. Please try again.");
                    return false
                } else {
                    const statusFlag = parsedData?.bulk_change_data?.status || "";
                    const response_data = parsedData?.bulk_change_data?.bulk_change_data || "{}";
                    const parsedResp = JSON.parse(response_data)
                    console.log("status_flag", statusFlag)
                    const status_flag = statusFlag ? (statusFlag).toLowerCase() : ""

                    if (status_flag && status_flag === "pending") {
                        return false
                    }
                    else if (status_flag && status_flag === "success") {
                        call_2_0_submit(parsedResp, payload)
                        call_2_0_sync(parsedResp)
                        return true
                    }
                    else if (status_flag && status_flag === "error") {
                        Modal.error({
                            title: 'Submit Error',
                            content: parsedData.message || 'An error occurred while submitting. Please try again.',
                            centered: true,
                        });
                        return true
                    }
                    else {
                        return false
                    }
                }
            } catch (error) {
                console.error("Error fetching auto refresh data:", error);
                return false
            } finally {
            }
        };
        const bulkChangePolling = async (data: any) => {
            const result = await bulkChangeInsert(data);
            if (!result) {
                setTimeout(() => bulkChangePolling(data), 5000); // Try again after 5 seconds
            } else {
                removeExport("bulkChangeInsert");
                console.log("Auto-refresh complete.");
            }
            // if (window.location.pathname.includes("/sim_management/bulk_change")) {
            //     window.location.reload();
            // }
        };
        const onsubmit = async () => {
            let data: any
            const iccidList = await getIccidList()

            try {
                const changedData = {
                    RefreshLine: {
                        requestType: "resendOTAProfile",
                        billingAccount: {
                            id: billingAccountNumber || ""
                        },
                        serviceCharacteristic: [
                            {
                                "name": "sim",
                                "value": ""
                            }
                        ]
                    }
                };
                setLoading(true);

                // Prepare payload for the first API
                const url = ENV_ROUTES.SIM_MANAGEMENT;
                data = {
                    tenant_name: partner || "default_value",
                    path: "/update_bulk_change_data",
                    role_name: role,
                    username: username,
                    request_received_at: getCurrentDateTime(),
                    access_token: token,
                    db_name: selectedDb,
                    ...metaData,
                    sessionID: sessionId,
                    service_provider: service_provider,
                    change_type: change_type,
                    created_by: firstLastName,
                    iccids: iccidList,
                    changed_data: { ...changedData }

                };

                // Send request to the first API
                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);

                if (parsedData.flag === false) {
                    setLoading(false);
                    Modal.error({
                        title: 'Submit Error',
                        content: parsedData.message || 'An error occurred while submitting. Please try again.',
                        centered: true,
                    });
                    return;
                }

                const bulkrow_ = parsedData?.bulkchange_id || {};
                const bulkRow: any = { row: bulkrow_ };
                setBulkRow(bulkRow);
                localStorage.setItem('bulk_row', JSON.stringify(bulkRow || "{}"));
                if (bulkRow) {
                    if (!isAllChangeType) {
                        router.push(`/sim_management/bulk_history`);
                    }
                }

            call_2_0_submit(parsedData, data)
            call_2_0_sync(parsedData)
        } catch (error) {
            const isTelegence = service_provider.toLowerCase().includes("telegence");
            const isWebbing = service_provider.toLowerCase().includes("webbing");
            const isVerizon = (service_provider.toLowerCase().includes("verizon") || service_provider.toLowerCase().includes("vzn") || service_provider.toLowerCase().includes("vzwcr") || service_provider.toLowerCase().includes("2215-so01"));
            const isPod19 = service_provider.toLowerCase().includes("pod19");
            const isPondIOT = service_provider.toLowerCase().includes("pond");
            if (switch_user_2_0 === "True" && (isTelegence || isVerizon || isPod19 || isPondIOT || isWebbing)) {
                onClose()
                setLoading(false)
                addExport("bulkChangeInsert", "Bulk Change Submission");
                bulkChangePolling(data)
            }
            else {
                Modal.error({
                    title: 'Submit Error',
                    content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting. Please try again.',
                    centered: true,
                });
            }
        } finally {
            setLoading(false);
        }
    };

        // const returnUpdatedValue = () =>{
        //     return (
        //     <Tooltip title={`${billingAccountNumber}`}>
        //         <span>
        //             {billingAccountNumber}
        //         </span>
        //     </Tooltip>)
        // }

        const returnUpdatedValue = () => {
            return (
                <div className="flex flex-col gap-2">
                    <div className="flex grid grid-cols-2 ">
                        <span className="font-semibold">Billing Account Number:</span>
                        <span>{billingAccountNumber}</span>
                    </div>
                </div>
            )
        }
        useImperativeHandle(ref, () => ({
            runValidation: handleContinue,
            runSubmit: onsubmit,
            returnUpdate: returnUpdatedValue
        }));
        const handleSelectBAN = (selectedOption: any | null) => {
            if (selectedOption) {
                const value = selectedOption?.value
                setBillingAccountNumber(value)

            }
            else {
                setBillingAccountNumber(undefined); // Clear the selection
            }
        };
        const returnChangedData = () => {

            const changedData = {
                RefreshLine: {
                    requestType: "resendOTAProfile",
                    billingAccount: {
                        id: billingAccountNumber || ""
                    },
                    serviceCharacteristic: [
                        {
                            "name": "sim",
                            "value": ""
                        }
                    ]
                }
            };
            return changedData;
        };

        if (loading) {
            return (
                <>
                    <div className="flex justify-center items-center h-[400px]">
                        <Spin size="large" />
                    </div>
                </>
            );
        }

        return (
            <div>
                <>
                    {isAllChangeType && (
                        <div className="flex justify-end px-4">
                            <span className="mr-2 font-semibold">Save Changes</span>
                            <Checkbox
                                checked={saveChanges}
                                onChange={(e) => {
                                    if (!e.target.checked) {
                                        setsuccessFullChangeTypes(
                                            successFullChangeTypes.filter((c: any) => c !== activeChange)
                                        );
                                    }
                                    setSaveChanges(e.target.checked)
                                }}
                                className="custom-checkbox"
                            >

                            </Checkbox>
                        </div>
                    )}
                    <div className={`${!isAllChangeType ? "flex flex-col space-y-4 my-4" : "flex grid grid-cols-2 gap-4"}`}>
                        {/* Billing Account Number */}
                        <div className="flex flex-col space-y-2">
                            <label htmlFor="billingAccountNumber" className="field-label">
                                Billing Account Number<span className="text-red-500">*</span>
                            </label>
                            {BANOptions.length === 0 ? (
                                <Input
                                    id="billingAccountNumber"
                                    // placeholder="Enter Billing Account Number"
                                    value={billingAccountNumber}
                                    onChange={(e) => setBillingAccountNumber(e.target.value)}
                                    className="input" />
                            ) : (
                                <Select
                                    id="billingAccountNumber"
                                    placeholder="Select Carrier Rate Plan"
                                    options={BANOptions.length > 0 ? BANOptions.map((option: string) => ({
                                        label: option,
                                        value: option,
                                    })) : [{ value: 'No options', label: 'No options' }]}
                                    value={{ label: billingAccountNumber, value: billingAccountNumber }}
                                    onChange={handleSelectBAN}
                                    isClearable
                                    className="w-full"
                                    styles={DropdownStyles}
                                />
                            )}


                        </div>
                        {BANError && <div className="text-red-500">{BANError}</div>}
                        {!isAllChangeType && (
                            <>
                                <div className="flex flex-col space-y-2">
                                    <label htmlFor="iccids" className="font-semibold">{`Devices (Start typing ICCID)`}<span className='text-red-500'>*</span></label>
                                    <Input.TextArea
                                        id="iccids"
                                        rows={4}
                                        placeholder={"Enter ICCIDs here"}
                                        value={iccids}
                                        onChange={(e) => {
                                            setIccids(e.target.value);
                                            if (e.target.value) setSubscriberNumber("");
                                        }}
                                        disabled={!!subscriberNumber}
                                    />
                                </div>
                                <div className="flex flex-col space-y-2">
                                    <label htmlFor="msisdns" className="font-semibold">{`Devices (Start typing Subscriber Number)`}<span className='text-red-500'>*</span></label>
                                    <Input.TextArea
                                        id="msisdns"
                                        rows={4}
                                        placeholder={"Enter Subscriber Numbers here"}
                                        value={subscriberNumber}
                                        onChange={(e) => {
                                            setSubscriberNumber(e.target.value);
                                            if (e.target.value) setIccids("");
                                        }}
                                        disabled={!!iccids}
                                    />
                                    {errors.some((err) => err) && (
                                        <div className="mt-2 space-y-1">
                                            {errors.map((err, idx) =>
                                                err ? (
                                                    <div key={idx} className="text-red-500 text-sm">
                                                        Line {idx + 1}: {err}
                                                    </div>
                                                ) : null
                                            )}
                                        </div>
                                    )}
                                </div>
                                {errorMessage && <div className="text-red-500 text-sm">{errorMessage}</div>}
                            </>
                        )}

                        {!isAllChangeType && (
                            <div className="flex justify-center space-x-4 mt-4">
                                <button onClick={onBack} className="cancel-btn">
                                    Back
                                </button>
                                <button onClick={handleContinue} className="save-btn">
                                    Submit
                                </button>
                            </div>
                        )}

                    </div>
                </>
            </div>
        );
    }
)

export default RefreshALine;