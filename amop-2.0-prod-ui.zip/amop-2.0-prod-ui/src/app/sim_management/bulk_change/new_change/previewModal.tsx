import React, { useEffect, useState } from "react";
import { Input, Modal, Spin, Table, Tooltip } from "antd";
import type { ColumnsType } from "antd/es/table";
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { CheckCircleIcon, XCircleIcon } from "@heroicons/react/24/outline";
import * as XLSX from "xlsx";

interface TableDataResponse<T> {
    data: T[];
}

interface SyncStatusData {
    key: string;
    no: number;
    syncName: string;
    syncType: string;
    status: string;
    dateTime: string;
}

interface UserLogData {
    key: string;
    no: number;
    userName: string;
    loginTime: string;
    logoutTime: string;
}

interface PreviewModalProps {
    change_type: string;
    service_provider: string;
    openPreviewModal: boolean;
    setPreviewModal: (val: boolean) => void;
    getIccids?: () => Promise<string[]>;
    iccids?: any[]
}

const customeCellRenderer = (text: any) => {
    if (text === true) {
        return <CheckCircleIcon className="text-green-500 h-5 w-5" />;
    } else if (text === false) {
        return <XCircleIcon className="text-red-500 h-5 w-5" />;
    } else {
        const displayText = text != null ? text.toString() : "None";
        return (
            <Tooltip title={displayText}>
                <div className="cell-ellipsis">{displayText}</div>
            </Tooltip>
        );
    }
};



const PreviewModal: React.FC<PreviewModalProps> = ({ change_type, service_provider, openPreviewModal, setPreviewModal, getIccids, iccids }) => {
    const { username, role, token, partner, selectedDb, firstLastName, sessionId, metaData } = useAuth();
    const [loading, setLoading] = useState(false);
    const [tableData, setTableData] = useState<any>([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [searchTerm, setSearchTerm] = useState("");
    const pageSize = 10;
    const filteredData = tableData.filter((item: any) => {
        const values = Object.values(item).join(" ").toLowerCase();
        return values.includes(searchTerm.toLowerCase());
    });
    const paginatedData = filteredData.slice((currentPage - 1) * pageSize, currentPage * pageSize);
    const columns = [
        {
            title: "ICCID",
            dataIndex: "iccid",
            key: "iccid",
            width: 210,
            render: (text: any) => (
                <Tooltip title={text}>
                    <div className="cell-ellipsis">{text}</div>
                </Tooltip>
            ),
        },
        {
            title: "Subscriber Number",
            dataIndex: "msisdn",
            key: "msisdn",
            width: 210,
            render: (text: any) => (
                <Tooltip title={text}>
                    <div className="cell-ellipsis">{text}</div>
                </Tooltip>
            ),
        },
        {
            title: "Activation Date",
            dataIndex: "last_activated_date",
            key: "last_activated_date",
            width: 210,
            render: (text: any) => (
                <Tooltip title={text}>
                    <div className="cell-ellipsis">{text&&text!=="None" && text!=="null" ? text : ""}</div>
                </Tooltip>
            ),
        }
    ];

    const closeModal = () => {
        setPreviewModal(false)

    }

    const fetchPreviewTableData = async () => {
        const isTelegence = service_provider?.toLowerCase().includes("telegence")

        try {
            let iccids_
            if(change_type.toLowerCase()==="assign customer" && typeof getIccids === "function"){
              const iccidList = await getIccids()
              iccids_ = iccidList || []
            }else{
                iccids_ = iccids
            }
            setLoading(true)
            const url = ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_iccids_or_msisdns_preview_data",
                role_name: role,
                parent_module: "Sim Management",
                module_name: "Preview",
                feature_module_name: "Preview",
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                mod_pages: {
                    start: 0,
                    end: 100,
                },
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: service_provider,
                change_type: change_type,
                ...(isTelegence ? { msisdns: iccids_ || [] } : { iccids: iccids_ || [] })
            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching Preview data. Please try again.',
                    centered: true,
                });
            } else {
                const tableData_ = parsedData?.preview_data || []
                setTableData(tableData_)
            }
        } catch (error) {
            console.error("Error fetching data:", error);
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        } finally {
            setLoading(false);

        }
    };

    useEffect(() => {
        const fetchInitialData = async () => {
            try {
                // Call your main data fetching function
                if (openPreviewModal) {
                    await fetchPreviewTableData();
                }
            } catch (error) {
                console.error("Error fetching SSM parameters or data:", error);
            }
        };

        fetchInitialData();
    }, [service_provider, openPreviewModal]);


    const exportToExcel = () => {
        if (!filteredData || filteredData.length === 0) return;

        // Build headers from columns
        const headers = columns.map(col => col.title);

        // Build rows by mapping column keys
        const rows = filteredData.map((row: any) =>
            columns.map(col => {
                const value = row[col.dataIndex];
                return value != null ? value : "";
            })
        );

        // Create worksheet and add headers
        const worksheet = XLSX.utils.aoa_to_sheet([headers, ...rows]);

        // Apply gray background to header row
        columns.forEach((col, index) => {
            const cellRef = XLSX.utils.encode_cell({ c: index, r: 0 });
            if (!worksheet[cellRef]) return;
            worksheet[cellRef].s = {
                fill: {
                    patternType: "solid",
                    bgColor: { rgb: "D9D9D9" }, // Light gray background
                },
                font: {
                    bold: true,
                },
                alignment: {
                    horizontal: "center",
                    vertical: "center",
                },
            };
        });

        // Add styles support (needed for styling to work in Excel)
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, "Preview");

        // Export to file
        XLSX.writeFile(workbook, "Preview.xlsx", { bookType: "xlsx", type: "binary" });
    };


    const paginationConfig = {
        current: currentPage,
        pageSize: pageSize,
        total: filteredData.length,
        showSizeChanger: false,
        showLessItems: false,
        showPrevNextJumpers: true,
        onChange: (page: number) => setCurrentPage(page),
    };

    const multiplyFactor = (typeof window !== "undefined" && window.innerWidth < 700) ? 3.5 : 2.5
    const modalHeight =
        typeof window !== "undefined" ? (window.innerHeight * 2.5) / 4 : 0;
    const modalWidth =
        typeof window !== "undefined" ? (window.innerWidth * multiplyFactor) / 4 : 0;

    return (

        <div>
            <Modal
                open={openPreviewModal}
                title={`${change_type} Preview`}
                maskClosable={false}
                centered
                width={modalWidth}
                styles={{
                    body: {
                        height: modalHeight,
                        padding: "0px",
                    },
                }}
                footer={null}
                onCancel={() => { setPreviewModal(false) }}
            >
                <>
                    {loading ? (
                        <div className="flex justify-center items-center h-[400px]">
                            <Spin size="large" />
                        </div>
                    ) : (
                        <div className="mb-8">
                            <div className="flex md:flex-row md:items-center md:justify-between space-y-4 mb-4">

                                {/* <TableSearch
                                searchTerm={searchTerm}
                                setSearchTerm={setSearchTerm}
                                tableName={"Customer_Rate_Plan"}
                                headerMap={headerMap}
                            /> */}
                                <Input.Search
                                    placeholder="Search..."
                                    allowClear
                                    value={searchTerm}
                                    onChange={(e) => {
                                        setSearchTerm(e.target.value);
                                        setCurrentPage(1); // Reset to page 1 on new search
                                    }}
                                    style={{ width: 300 }}
                                    className="mt-4"
                                />
                                <button className={`${filteredData.length === 0 ? 'cancel-btn cursor-not-allowed' : 'save-btn'}`} disabled={filteredData.length === 0} onClick={exportToExcel}>
                                    Export
                                </button>
                            </div>
                            <div className="">
                                <Table
                                    columns={columns || []}
                                    dataSource={paginatedData}
                                    loading={loading}
                                    size="middle"
                                    scroll={{ y: modalHeight-170 }}
                                    pagination={paginationConfig}
                                />
                            </div>
                        </div>
                    )}

                </>
            </Modal>

        </div>


    );
};

export default PreviewModal;
