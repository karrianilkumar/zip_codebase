"use client";

import { FC, forwardRef, useEffect, useImperativeHandle, useRef, useState } from "react";
import { Button, Checkbox, DatePicker, Tooltip } from "antd";
import Select from "react-select";
import { ArrowLeftIcon, ArrowRightIcon } from "@heroicons/react/24/outline";
import SelectDevices from "./select_devices";
import dayjs from 'dayjs'; // Import dayjs
import Partner from "@/app/partner/partner_info/page";
import { useAuth } from "@/app/components/auth_context";
import { DropdownStyles } from "@/app/components/css/dropdown";
import { useAllChangeTypesStore } from "@/app/stores/allChangeTypesStore";
import { SelectContentRef } from "./select_devices";
interface CarrierRatePlanProps {
    onContinue: () => void;
    onBack: () => void;
    dropdown: any;
    service_provider: any;
    change_type: any;
    onClose: () => void;
}
export interface CarrierRatePlan1ContentRef {
  runValidation: () => Promise<void> | void;
  runSubmit: () => Promise<void> | void;
  returnUpdate: () => React.ReactNode | Promise<React.ReactNode>; 
}

const ChangeCarrierRatePlan = forwardRef<CarrierRatePlan1ContentRef, CarrierRatePlanProps>(
    ({ onContinue, onBack, dropdown, service_provider, change_type,onClose }, ref) => {
    const [carrierRatePlan, setCarrierRatePlan] = useState<string|null>('');
    const [communicationPlan, setCommunicationPlan] = useState<string | null>(null);
    const [effectiveDate, setEffectiveDate] = useState<moment.Moment | null>(null); // Change type to moment.Moment
    const [showSelectDevices, setShowSelectDevices] = useState(false);

    const [carrierRatePlanError, setCarrierRatePlanError] = useState<string | null>(null);
    const [communicationPlanError, setCommunicationPlanError] = useState<string | null>(null);
    const [effectiveDateError, setEffectiveDateError] = useState<string | null>(null);
    const [ratePlanOptions, setRatePlanOptions] = useState<any>([])
    const [commPlanOptions, setCommPlanOptions] = useState<any>([])
    const { partner } = useAuth();
    const { isAllChangeType,setIsValidated,setValidationTrigger,allChangeTypesDevices, setsuccessFullChangeTypes, activeChange, successFullChangeTypes  } = useAllChangeTypesStore();
    const selectDevicesRef = useRef<SelectContentRef>(null);
    const [saveChanges, setSaveChanges] = useState<boolean>(true);

    useEffect(() => {
        // console.log("dropdown", dropdown)
        const carrier_rate_plan_dropdown = dropdown?.carrier_rate_plan_dropdown || []
        setRatePlanOptions(carrier_rate_plan_dropdown)
        const comm_plan_dropdown = dropdown?.comm_plan_dropdown || []
        setCommPlanOptions(comm_plan_dropdown)
    }, [dropdown]);

   
      const disablePastDates = (current: dayjs.Dayjs) => {
        // Disable all dates before today
        return current && current.isBefore(dayjs().startOf('day'));
    };

    const handleContinue = () => {
        let valid = true;
        setCarrierRatePlanError(null);
        setCommunicationPlanError(null);

        if (!carrierRatePlan) {
            setCarrierRatePlanError("Carrier rate plan is required.");
            valid = false;
        }
        // if (!communicationPlan) {
        //     setCommunicationPlanError("Communication plan is required.");
        //     valid = false;
        // }
         // Add validation for effectiveDate
    if (!effectiveDate && (partner&& partner.toLowerCase()!=="spectrotel")) {
        setEffectiveDateError("Effective date is required.");
        valid = false;
    }

    if(!valid){
        if(isAllChangeType){
            setsuccessFullChangeTypes(
                    successFullChangeTypes.filter((c: any) => c !== activeChange)
                );
                if (!carrierRatePlan && !communicationPlan && !effectiveDate) {
                    setEffectiveDateError("");
                    setCarrierRatePlanError("");
                    setIsValidated(true)
                    setValidationTrigger();
                }
                else{
                    setIsValidated(false)
                    setValidationTrigger();
                }
        }
        return
    }

    if(isAllChangeType){
        setEffectiveDateError("");
        setCarrierRatePlanError("");
        setIsValidated(true)
        setValidationTrigger();
        if(saveChanges){
            setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
        }
    }
    else{
        setShowSelectDevices(true);
    }
        
    };

    const handleBack = () => {
        // Update parent state with values from SelectDevices
        setCarrierRatePlan(carrierRatePlan);
        setCommunicationPlan(communicationPlan);
        setEffectiveDate(effectiveDate);
        setShowSelectDevices(false);
    };
    const handleSelectRatePlan = (selectedOption: any | null) => {
        if (selectedOption) {
            const value = selectedOption?.value
            setCarrierRatePlan(value)

        }
        else{
            setCarrierRatePlan(null); // Clear the selection
        }
    };
    const handleSelectCommPlan = (selectedOption: any) => {
        if (selectedOption) {
            const value = selectedOption?.value
            setCommunicationPlan(value)

        }
        else{
            setCommunicationPlan(null)

        }
    };

    // const returnUpdatedValue = () =>{
    //     const ratePlan_ = carrierRatePlan && carrierRatePlan !== 'No options' ? carrierRatePlan : ""
    //     return (
    //     <Tooltip title={`${ratePlan_}`}>
    //         <span>
    //             {ratePlan_}
    //         </span>
    //     </Tooltip>)
    // }

        const returnUpdatedValue = () => {
            const ratePlan_ = carrierRatePlan && carrierRatePlan !== 'No options' ? carrierRatePlan : ""
            return (
                <div className="flex flex-col gap-2">
                    <div className="flex grid grid-cols-2 ">
                        <span className="font-semibold">Carrier Rate Plan:</span>
                        <span>{ratePlan_}</span>
                    </div>
                </div>
            )
        }

    useImperativeHandle(ref, () => ({
          runValidation: handleContinue,
          runSubmit: () => {
            selectDevicesRef.current?.runSubmit();
        },
        returnUpdate: returnUpdatedValue
        }));
        
    const returnChangedData = () => {
        const ratePlan_=carrierRatePlan && carrierRatePlan !== 'No options' ? carrierRatePlan : null
        const ratePlanNameParts=(ratePlan_ || "").split(" -- ")
        const changedData = {
            CarrierRatePlanUpdate: {
                CarrierRatePlan: ratePlanNameParts.length>0 ? ratePlanNameParts[0] : null,
                CommPlan: communicationPlan&& communicationPlan!=='No options'?communicationPlan:null,
                EffectiveDate: effectiveDate,
            }
        }
        return changedData
    };
    return (
        <div>
            {/* {!showSelectDevices ? ( */}
                <div className={showSelectDevices ? "hidden" : "block"}>
                    {isAllChangeType && (
                        <div className="flex justify-end px-4">
                            <span className="mr-2 font-semibold">Save Changes</span>
                            <Checkbox
                                checked={saveChanges}
                                onChange={(e) => {
                                    if (!e.target.checked) {
                                        setsuccessFullChangeTypes(
                                            successFullChangeTypes.filter((c: any) => c !== activeChange)
                                        );
                                    }
                                    setSaveChanges(e.target.checked)
                                }}
                                className="custom-checkbox"
                            >

                            </Checkbox>
                        </div>
                    )}
                <div className={`${!isAllChangeType?"flex flex-col space-y-4 mt-4":"flex grid grid-cols-2 gap-4"}`}>
                    {/* Carrier Rate Plan */}
                    <div className={`${!isAllChangeType?"flex flex-col space-y-1":""}`}>
                        <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                            <label htmlFor="carrierRatePlan" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                Carrier Rate Plan<span className="text-red-500">*</span>
                            </label>
                            <Select
                                id="carrierRatePlan"
                                placeholder="Select Carrier Rate Plan"
                                options={ratePlanOptions.length>0?ratePlanOptions.map((option: string) => ({
                                    label: option,
                                    value: option,
                                })):[{value:'No options',label:'No options'}]}
                                value={carrierRatePlan === 'No options' ? null :{ label: carrierRatePlan, value: carrierRatePlan }}
                                onChange={handleSelectRatePlan}
                                isClearable
                                className={`${!isAllChangeType?"w-2/3":"w-full"}`}
                                styles={DropdownStyles}
                            />
                        </div>
                        {carrierRatePlanError && (
                            <div className="text-red-500 text-sm">
                                {carrierRatePlanError}
                            </div>
                        )}
                    </div>

                    {/* Communication Plan */}
                    <div className={`${!isAllChangeType?"flex flex-col space-y-1":""}`}>
                        <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                            <label htmlFor="communicationPlan" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                Communication Plan
                            </label>
                            <Select
                                id="communicationPlan"
                                placeholder="Select Communication Plan"
                                value={communicationPlan === 'No options' ? null :{ label: communicationPlan, value: communicationPlan }}
                                onChange={handleSelectCommPlan}
                                styles={DropdownStyles}
                                className={`${!isAllChangeType?"w-2/3":"w-full"}`}
                                options={commPlanOptions.length>0?commPlanOptions.map((option: string) => ({
                                    label: option,
                                    value: option,
                                })):[{value:'No options',label:'No options'}]}
                                isClearable
                            />
                        </div>
                    </div>

                    {/* Effective Date */}
                    <div className={`${!isAllChangeType?"flex flex-col space-y-1":""}`}>
                        <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                            <label htmlFor="effectiveDate" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                Effective Date {partner&& partner.toLowerCase()!=="spectrotel"&&<span className="text-red-500">*</span>}
                            </label>
                           <DatePicker
                        id="effectiveDate"
                        value={effectiveDate} // Directly use dayjs object
                        onChange={(date) => setEffectiveDate(date)} // Set dayjs object directly
                        className={`${!isAllChangeType?"w-2/3":"input"}`}
                        // disabledDate={disablePastDates}
                    />
                        </div>
                        {effectiveDateError && (
                            <div className="text-red-500 text-sm">
                                {effectiveDateError}
                            </div>
                        )}
                    </div>

                    {/* Action Buttons */}
                    {!isAllChangeType && (
                        <div className="flex justify-center space-x-4 mt-4">
                        <button onClick={onBack} className="cancel-btn">
                            {/* <ArrowLeftIcon className="h-5 w-5 mr-2" /> */}
                            Back
                        </button>
                        <button onClick={handleContinue} className="save-btn">
                            Continue
                            {/* <ArrowRightIcon className="h-5 w-5 ml-2" /> */}
                        </button>
                    </div>
                    )}
                    
                </div>
                </div>
            {/* ) : ( */}
                <div className={showSelectDevices ? "block" : "hidden"}>
                <SelectDevices
                    ref={selectDevicesRef} 
                    onContinue={onContinue}
                    onBack={handleBack}
                    service_provider={service_provider}
                    change_type={change_type}
                    changed_data={returnChangedData()}
                    onCancel={onClose}
                />
                </div>
            {/* )} */}
        </div>
    );
}
)

export default ChangeCarrierRatePlan;
