"use client";

import { FC, forwardRef, useEffect, useImperativeHandle, useRef, useState } from "react";
import { Input, Button, DatePicker, Checkbox, Tooltip } from "antd";
import { ArrowLeftIcon, ArrowRightIcon } from "@heroicons/react/24/outline";
import SelectDevices from "./select_devices";
import Select from "react-select";
import { DropdownStyles } from "@/app/components/css/dropdown";
import { useAllChangeTypesStore } from "@/app/stores/allChangeTypesStore";
import { SelectContentRef } from "./select_devices";

interface CarrierRatePlanProps2 {
    onContinue: (iccids: string[]) => void;
    onBack: () => void;
    dropdown:any;
    service_provider:any;
    change_type:any;
    onClose: () => void;
}

export interface CarrierRatePlan2ContentRef {
  runValidation: () => Promise<void> | void;
  runSubmit: () => Promise<void> | void;
  returnUpdate: () => React.ReactNode | Promise<React.ReactNode>;
}

const ChangeCarrierRatePlan2 = forwardRef<CarrierRatePlan2ContentRef, CarrierRatePlanProps2>(
        ({ onContinue, onBack ,dropdown,service_provider,change_type,onClose}, ref) => {
    const [carrierRatePlan, setCarrierRatePlan] = useState<string | null>(null);
    const [showSelectDevices, setShowSelectDevices] = useState(false);
    const [errors, setErrors] = useState<string[]>([]);
    const [ratePlanOptions, setRatePlanOptions] = useState<any>([])
    const { isAllChangeType,setIsValidated,setValidationTrigger,allChangeTypesDevices, setsuccessFullChangeTypes, activeChange, successFullChangeTypes  } = useAllChangeTypesStore();
    const selectDevicesRef = useRef<SelectContentRef>(null);
    const [saveChanges, setSaveChanges] = useState<boolean>(true);

    useEffect(() => {
        // console.log("dropdown", dropdown)
        const carrier_rate_plan_dropdown = dropdown?.carrier_rate_plan_dropdown || []
        setRatePlanOptions(carrier_rate_plan_dropdown)
        const comm_plan_dropdown= dropdown?.comm_plan_dropdown || []
        // setCommPlanOptions(comm_plan_dropdown)
    }, [dropdown]);
    const handleContinue = () => {
        const newErrors: string[] = [];
        if (!carrierRatePlan) {
            newErrors.push("Carrier rate plan is required.");
        }
       
        if (newErrors.length > 0) {
            if (isAllChangeType) {
                setsuccessFullChangeTypes(
                    successFullChangeTypes.filter((c: any) => c !== activeChange)
                );
                if (!carrierRatePlan) {
                    setErrors([])
                    setIsValidated(true)
                    setValidationTrigger();
                }
                else {
                    setIsValidated(false)
                    setValidationTrigger();
                }
            }
            else {
                setErrors(newErrors);
            }
            return;
        }
        setErrors([]);

        if (isAllChangeType) {
            setIsValidated(true)
            setValidationTrigger();
            if(saveChanges){
                setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
            }
        }
        else {
            setShowSelectDevices(true);
        }
    };

    const handleBack = () => {
        setShowSelectDevices(false);
    };
    const handleSelectRatePlan = (selectedOption: any) => {
        if (selectedOption) {
            const value = selectedOption?.value
            setCarrierRatePlan(value)
        }
        else{
            setCarrierRatePlan(null)
             
        }
    };

    // const returnUpdatedValue = () =>{
    //     const ratePlan_ = carrierRatePlan && carrierRatePlan !== 'No options' ? carrierRatePlan : ""
    //     return (
    //     <Tooltip title={`${ratePlan_}`}>
    //         <span>
    //             {ratePlan_}
    //         </span>
    //     </Tooltip>)
    // }

    const returnUpdatedValue = () => {
            const ratePlan_ = carrierRatePlan && carrierRatePlan !== 'No options' ? carrierRatePlan : ""
            return (
                <div className="flex flex-col gap-2">
                    <div className="flex grid grid-cols-2 ">
                        <span className="font-semibold">Carrier Rate Plan:</span>
                        <span>{ratePlan_}</span>
                    </div>
                </div>
            )
        }

    useImperativeHandle(ref, () => ({
        runValidation: handleContinue,
        runSubmit: () => {
            selectDevicesRef.current?.runSubmit();
        },
        returnUpdate: returnUpdatedValue
    }));
            
    const returnChangedData = () => {
        const ratePlan_=carrierRatePlan && carrierRatePlan !== 'No options' ? carrierRatePlan : null
        const ratePlanNameParts=(ratePlan_ || "").split(" -- ")
        const changedData={
            CarrierRatePlanUpdate: {
                CarrierRatePlan: ratePlanNameParts.length>0 ? ratePlanNameParts[0] : null,
            }            
        }
        return changedData
    };
    return (
        <div>
            {/* {!showSelectDevices ? ( */}
                <div className={showSelectDevices ? "hidden" : "block"}>
                    {isAllChangeType && (
                        <div className="flex justify-end px-4">
                            <span className="mr-2 font-semibold">Save Changes</span>
                            <Checkbox
                                checked={saveChanges}
                                onChange={(e) => {
                                    if (!e.target.checked) {
                                        setsuccessFullChangeTypes(
                                            successFullChangeTypes.filter((c: any) => c !== activeChange)
                                        );
                                    }
                                    setSaveChanges(e.target.checked)
                                }}
                                className="custom-checkbox"
                            >

                            </Checkbox>
                        </div>
                    )}
                <div className={`${!isAllChangeType?"flex flex-col space-y-4 mt-4":"flex grid grid-cols-2 gap-4"}`}>
                    <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                        <label htmlFor="carrierRatePlan" className={`${!isAllChangeType?"font-semibold":"field-label"}`}>Carrier Rate Plan<span className='text-red-500'>*</span></label>
                        <Select
                                id="carrierRatePlan"
                                placeholder="Select Carrier Rate Plan"
                                options={ratePlanOptions.length>0?ratePlanOptions.map((option: string) => ({
                                    label: option,
                                    value: option,
                                })):[{value:'No options',label:'No options'}]}
                                value={carrierRatePlan === 'No options' ? null :{label:carrierRatePlan,value:carrierRatePlan}}
                                onChange={handleSelectRatePlan}
                                styles={DropdownStyles}
                                className={`${!isAllChangeType?"w-2/3":"w-full"}`}
                                isClearable
                            />
                    </div>

                   

                    {errors.length > 0 && (
                        <div className="text-red-500">
                            {errors.map((error, index) => (
                                <div key={index}>{error}</div>
                            ))}
                        </div>
                    )}
                    {!isAllChangeType && (
                        <div className="flex justify-center space-x-4 mt-4">
                        <button onClick={onBack} className="cancel-btn">
                            {/* <ArrowLeftIcon className="h-5 w-5 mr-2" /> */}
                            Back
                        </button>
                        <button onClick={handleContinue} className="save-btn">
                            Continue
                            {/* <ArrowRightIcon className="h-5 w-5 mr-2" /> */}
                        </button>
                    </div>
                    )}
                    
                </div>
                </div>
            {/* ) : ( */}
                <div className={showSelectDevices ? "block" : "hidden"}>
                <SelectDevices ref={selectDevicesRef}  onContinue={handleContinue} onBack={handleBack} service_provider={service_provider} change_type={change_type} changed_data={returnChangedData()} onCancel={onClose}/>
                </div>
            {/* )} */}
        </div>
    );
}
)

export default ChangeCarrierRatePlan2;
