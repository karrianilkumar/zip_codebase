'use client'
import React, { useEffect, useState } from 'react';
import { Modal, Button, message, Spin, notification } from 'antd';
import { useRevStore } from '@/app/stores/revStore';
import RevTableComponent from '@/app/components/revTableComponent/page';
import dayjs from 'dayjs';
import axios from 'axios';
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from '@/app/components/header_constants';
import { ENV_ROUTES } from '@/app/components/routes/route_constants';
import DisconnectProductTable from '@/app/components/revTableComponent/disconnectProductTable';
import { exportLoadingStore } from '@/app/stores/ExportLoadingStore';

const DisconnectServiceProductPage: React.FC<{ onClose: () => void; visible: boolean; onSave: () => void; }> = ({ onClose, visible, onSave }) => {
    const { settabledata, username, role, partner, token, selectedDb,metaData, firstLastName, sessionId } = useAuth();
    const { revHeaders, revActionRows, revRows, revHeaderMap, setRevHeaderMap, setRevHeaders, setRevActionRows, setRevRows, setIsClosed } = useRevStore();
    const [showConfirmModal, setShowConfirmModal] = useState<boolean>(false);
    const [confirmData, setConfirmData] = useState<{ customerIds: number[]; totalProducts: number } | null>(null);
    const [initialRows, setInitialRows] = useState<any[]>([]);
    const [loading, setLoading] = useState(false);
    const { addRevAction, removeRevAction } = exportLoadingStore();
    // Function to reset dates to null
    const resetDates = (rows: any[]) => {
        return rows.map(row => ({
            ...row,
            'Effective Date': null
        }));
    };

    useEffect(() => {
        if (visible) {
            // Reset everything when modal opens
            // settabledata([]);

            // Clear effective dates from revRows
            const clearedRows = resetDates(revRows);
            setInitialRows(clearedRows);
            setRevActionRows([]);

            // Ensure headers include all necessary fields
            const additionalHeaders = ['package_id', 'rate', 'description', 'product_id', 'Effective Date'];
            const updatedHeaders = [...new Set([...revHeaders, ...additionalHeaders])];
            setRevHeaders(updatedHeaders);

            // Update header map
            const updatedHeaderMap = {
                ...revHeaderMap,
                package_id: ['Package ID', null],
                rate: ['Rate', null],
                description: ['Description', null],
                product_id: ['Product ID', null],
                'Effective Date': ['Effective Date', null],
            };
            setRevHeaderMap(updatedHeaderMap);
        }
    }, [visible]);

    const handleDateChange = (rowIndex: number, date: string | null) => {
        const updatedRows = [...initialRows];
        updatedRows[rowIndex]['Effective Date'] = date;
        setInitialRows(updatedRows);
    };

    const handleSubmit = () => {
        const missingDates = initialRows.some(row => !row['Effective Date']);

        if (missingDates) {
            notification.warning({
                message: 'Warning',
                description: 'Effective Date must be selected',
                placement: 'top',
                duration: 3,
            });
            return;
        }

        const customerIds: any[] = initialRows.map(row => ({
            customer_id: row.rev_account_number,
        }));
        const totalProducts = revRows.length;
        console.log("totalProducts", totalProducts)
        setConfirmData({ customerIds, totalProducts });
        setShowConfirmModal(true);
    };

    const handleConfirmSubmit = async () => {
        setLoading(true);
        onSave()
        setShowConfirmModal(false);

        try {
            addRevAction("disconnectService", "Disconnect Service Line")
            const deactivate_data: Record<string, any[]> = {};

            initialRows.forEach((row: any) => {
                const customerId = row.rev_account_number;

                if (!deactivate_data[customerId]) {
                    deactivate_data[customerId] = [];
                }

                deactivate_data[customerId].push({
                    service_product_id: row.service_product_id,
                    effective_date: row['Effective Date'], // Make sure this matches your actual field name
                    generate_proration: true,
                    iccid: row.iccid,
                });
            });
            const selectedICCIDs = revRows.map((row) => row?.['iccid'])
            const selectedServiceNos = revRows.map((row) => row?.['service_number'])
            const selectedProviderss = revRows.map((row) => row?.['service_provider'])
            const customer_name_ = revRows.map((row) => row?.['customer_name'])
            const customer_iccid_dict_: Record<string, any[]> = {};

            initialRows.forEach((row: any) => {
                const customerName_ = row.customer_name;

                if (!customer_iccid_dict_[customerName_]) {
                    customer_iccid_dict_[customerName_] = [];
                }

                customer_iccid_dict_[customerName_].push(row.iccid);
            });

            console.log("customer_iccid_dict_", customer_iccid_dict_)

            const iccid_msisdn_dict_: Record<string, any> = {}
            revRows.map((row: any) => {
                const iccid = row.iccid
                const msisdn = row.service_number
                iccid_msisdn_dict_[iccid] = msisdn
            })
            console.log("iccid_msisdn_dict_", iccid_msisdn_dict_)

            const quantity_: Record<string, any> = {}
            customer_name_.map((option) => { quantity_[option] = customer_iccid_dict_[option].length })
            console.log("quantity_", quantity_)
            const submitData = {
                customer_name:customer_name_,
                deactivate_data: deactivate_data,
                iccid: selectedICCIDs || null,
                service_number: selectedServiceNos || null,
                quantity: quantity_,
                customer_iccid_dict: customer_iccid_dict_,
                iccid_msisdn_dict: iccid_msisdn_dict_
            }
            const payload = {
                data: {
                    tenant_name: partner,
                    username: username,
                    firstLastName: firstLastName,
                    path: "/deactivate_service_product",
                    role_name: role,
                    parent_module: "Sim Management",
                    module_name: "Rev assurance",
                    customer_id: confirmData?.customerIds.map((item: any) => item.customer_id),
                    submit_data: submitData,
                    service_provider: selectedProviderss[0] || null,
                    row_count: revRows.length || 0,
                    request_received_at: getCurrentDateTime(),
                    Partner: partner,
                    access_token: token,
                    db_name: selectedDb,
        ... metaData,
                    sessionID: sessionId,
                },
            };

            const response = await axios.post(ENV_ROUTES.REV_ASSURANCE, payload);
            handleOnClose();
            const parsedData = JSON.parse(response.data.body);

            if (response.data.statusCode === 200) {
                removeRevAction("disconnectService")
                const rev_customer_ids = [...new Set(confirmData?.customerIds.map((item: any) => item.customer_id))].join(', ');

                Modal.success({
                    title: 'Service product Disconnected',
                    centered: true,
                    content: (
                        <div>
                            <p>This will Disconnect Service Product</p>
                            <h2>RevCustomerId: {rev_customer_ids}</h2>
                            <h2>Total Selected Products: {confirmData?.totalProducts}</h2>
                        </div>
                    ),
                    // onOk: handleOnClose,
                });
            } else {
                removeRevAction("disconnectService")
                const err_customer_ids = parsedData.data.map((item: { error_message: any; customer_id: any }) => item.customer_id).join(',');
                // Modal.error({
                //     title: 'Submission failed',
                //     centered: true,
                //     content: (
                //         <div>
                //             <p>Customer id: {err_customer_ids}</p>
                //             <p>{`${parsedData?.message}` || "Service Product id is Missing or Null"}</p>
                //         </div>
                //     ),
                //     // onOk: handleOnClose,
                // });
                message.error(`${parsedData?.message}` || "Service Product id is Missing or Null")
            }
        } catch (error) {
            removeRevAction("disconnectService")
            console.error('Unexpected error:', error);
            message.error('Failed to submit data');
        } finally {
            setLoading(false);
        }
    };

    const clearData = () => {
        // Reset all data states
        // setRevRows([]);
        setIsClosed(true);
        setInitialRows([]); // Clear initialRows completely

        // Remove Effective Date from headers and header map
        const updatedHeaders = revHeaders.filter(header => header !== 'Effective Date');
        setRevHeaders(updatedHeaders);
        const { 'Effective Date': _, ...updatedHeaderMap } = revHeaderMap;
        setRevHeaderMap(updatedHeaderMap);
    };

    const handleOnClose = () => {
        clearData();
        onClose();
    };

    const handleCancelConfirm = () => {
        setShowConfirmModal(false);
    };

    if (loading) {
        return (
            <div className="flex justify-center items-center h-screen">
                <Spin size="large" />
            </div>
        );
    }

    return (
        <>
            <Modal
                visible={visible}
                title="Disconnect Service Product"
                maskClosable={false}
                footer={
                    <div className="justify-center flex space-x-2">
                        <Button key="cancel" className="cancel-btn" onClick={handleOnClose}>
                            Cancel
                        </Button>
                        <Button key="submit" className="save-btn" onClick={handleSubmit} disabled={initialRows.length < 1}>
                            Submit
                        </Button>
                    </div>
                }
                centered
                width={'1400px'}
                bodyStyle={{
                    height: 'auto',
                    overflowY: 'auto',
                }}
                onCancel={handleOnClose}
            >

                <DisconnectProductTable
                    headers={revHeaders}
                    headerMap={revHeaderMap}
                    initialData={initialRows}
                    searchQuery=""
                    visibleColumns={revHeaders}
                    itemsPerPage={10}
                    moduleName="Disconnect Service Product"
                    pagination={{ start: 1, end: 100, total: initialRows.length }}
                    onDateChange={handleDateChange}
                />
            </Modal>

            <Modal
                open={showConfirmModal}
                title="Confirm Submission"
                onCancel={handleCancelConfirm}
                footer={
                    <div className="justify-center flex space-x-2 mt-2">
                        <Button key="cancel" className="cancel-btn" onClick={handleCancelConfirm}>
                            Cancel
                        </Button>
                        <Button key="confirm" className="save-btn" onClick={handleConfirmSubmit}>
                            Confirm
                        </Button>
                    </div>
                }
                centered
                width={'500px'}
                bodyStyle={{
                    height: 'auto',
                    overflowY: 'auto',
                }}
            >
                {confirmData && (
                    <p>Are you sure want to Submit</p>
                )}
            </Modal>
        </>
    );
};

export default DisconnectServiceProductPage;