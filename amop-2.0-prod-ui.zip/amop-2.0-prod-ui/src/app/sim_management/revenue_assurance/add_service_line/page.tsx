'use client'
import React, { lazy, Suspense, useState, useEffect, act } from 'react';
import { Modal, Input, Button, Checkbox, DatePicker, Form, message, Row, Col, notification, Upload, Spin } from 'antd';
import Select from 'react-select';
import { useRevStore } from '@/app/stores/revStore';
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from '@/app/components/header_constants';
import axios from 'axios';
import moment from 'moment';
import { isNumber } from 'lodash';
import { ENV_ROUTES } from '@/app/components/routes/route_constants';
import { exportLoadingStore } from '@/app/stores/ExportLoadingStore';
import { DownloadOutlined, UploadOutlined } from '@ant-design/icons';
import { DropdownStyles } from '@/app/components/css/dropdown';

const RevTableComponent = lazy(() => import('@/app/components/revTableComponent/page'));

interface OptionType {
  value: string;
  label: string;
}
interface ServiceTypeMap {
  m2m?: any[];
  mobility?: any[];
}
interface MyModalProps {
  visible: boolean;
  onCancel: () => void;
  onSave: () => void;
}

const messageStyle = {
  fontSize: "14px",
  fontWeight: "bold",
  padding: "16px",
};

const AddServiceLine: React.FC<MyModalProps> = ({ visible, onCancel, onSave }) => {
  const [form] = Form.useForm();
  const { revRows, revHeaders, revHeaderMap, setIsClosed, setRevRows, setRevHeaderMap } = useRevStore();
  console.log(revRows,"Show rev rows")
  const [isNextClicked, setIsNextClicked] = useState(false);
  const [initialRows, setInitialRows] = useState(revRows)
  const [selectedCustomer, setSelectedCustomer] = useState<string | string[] | null>(null);
  const [isMultiCustomer, setIsMultiCustomer] = useState<boolean>(false);
  const [selectedProvider, setSelectedProvider] = useState(null);
  const [selectedProviderId, setSelectedProviderId] = useState(null);
  const [selectedServiceTypeId, setSelectedServiceTypeId] = useState(null);
  const [selectedServiceType, setSelectedServiceType] = useState(null);
  const [selectedProduct, setSelectedProduct] = useState<any>([]);
  const [usagePlanGroup, setUsagePlanGroup] = useState(null);
  const [selectedPackage, setSelectedPackage] = useState(null);
  const [selectedQuantity, setSelectedQuantity] = useState<number>(1);
  const [description, setDescription] = useState<any>(null);
  const [prorate, setProrate] = useState(true);
  const [addRatePlan, setAddRatePlan] = useState(false);
  const [useCarrierActivation, setUseCarrierActivation] = useState(false);

  const [selectedCustomerRatePlan, setSelectedCustomerRatePlan] = useState(null);
  const [showConfirmation, setShowConfirmation] = useState<boolean>(false);
  const [activationDate, setActivationDate] = useState(null);
  const [customerRatePlanOptions, setCustomerRatePlanOptions] = useState<any[]>([]);
  const [customerOptions, setCustomerOptions] = useState<any[]>([]);
  const [providerOptions, setProviderOptions] = useState<any[]>([]);
  const [serviceTypeMap, setServiceTypeMap] = useState<ServiceTypeMap>({});
  const [serviceTypeOptions, setServiceTypeOptions] = useState<any>([]);
  const [serviceTypeOptionsMap, setServiceTypeOptionsMap] = useState<any>([]);
  const [usagePlanGroupOptions, setUsagePlanGroupOptions] = useState<any[]>([]);
  const [productOptions, setProductOptions] = useState<any[]>([]);
  const [packageOptions, setPackageOptions] = useState<any[]>([]);
  const [providerMap, setProviderMap] = useState<any>({});
  const [serviceproviderType, setServiceproviderType] = useState<any>(null);
  const [providerPackageMap, setProviderPackageMap] = useState<{ [key: string]: string }>({});

  const { revActions, addRevAction,removeRevAction } = exportLoadingStore();
  

  //Rate state variables
  const [rateProductMap, setRateProductMap] = useState<any>({});
  const [ratePackageMap, setRatePackageMap] = useState<any>([]);
  const [selectedRates, setSelectedRates] = useState<any>({});


  const [customerError, setCustomerError] = useState('');
  const [providerError, setProviderError] = useState('');
  const [serviceTypeError, setServiceTypeError] = useState('');
  const [activationDateError, setActivationDateError] = useState('');
  const [productError, setProductError] = useState('');
  const [packageError, setPackageError] = useState('');
  const [quantityError, setQuantityError] = useState('');
  const [originalHeaderMap, setOriginalHeaderMap] = useState<any>(revHeaderMap);

  const { settabledata, username, role, partner, token, selectedDb,metaData, firstLastName, sessionId } = useAuth();

  //Upload state variables
  const [isUploadModalVisible, setIsUploadModalVisible] = useState(false);
  const [appendChecked, setAppendChecked] = useState(false);
  const [overwriteChecked, setOverwriteChecked] = useState(false);
  const [isFileSelected, setIsFileSelected] = useState(false);
  const [uploadKey, setUploadKey] = useState(Date.now());
  const [loading, setLoading] = useState(false);

  const switch_user_2_0 = localStorage.getItem("switch_user_2_0");
    
  useEffect(() => {
    if(visible){
    setInitialRows(revRows)
    const customerOptions_ = Array.from(new Set(revRows.map((row) => row?.['customer_name']))).filter(Boolean);    
    if(customerOptions_.length>0){
      setIsMultiCustomer(true)
      setCustomerOptions(customerOptions_);
      const defaultCustomer = customerOptions_[0] || null;
      // setSelectedCustomer([defaultCustomer]); 
      setSelectedCustomer(customerOptions_); 
      // setSelectedCustomer(defaultCustomer) // set default customer option
      // setSelectedProvider(providerOptions_[0])
      if(visible){
        fetchData(customerOptions_)
      }
    }
    else{
      setIsMultiCustomer(false)
      fetchCustomerNamesData()
    }
    const providerOptions_ = Array.from(new Set(revRows.map((row) => row?.['service_provider'])));
    // setProviderOptions(providerOptions_);
    setIsNextClicked(false)

    
    setSelectedCustomerRatePlan(null)
    setSelectedPackage(null)
    setSelectedProduct([])
    setSelectedRates({})
    
    setSelectedServiceType(null)
    setActivationDate(null)
    setDescription(null)
    setUsagePlanGroup(null)

    setPackageOptions([])
    
    setServiceTypeOptions([])
    setProductOptions([])
    setUsagePlanGroupOptions([])

    setCustomerError('')
    setProviderError('')
    setServiceTypeError('')
    setActivationDateError('')
    setProductError('')
    setQuantityError('')
    setUseCarrierActivation(false)
    setAddRatePlan(false)
    }
   
  }, [visible]);

  const fetchCustomerNamesData = async () => {
    // settabledata([])
    const selectedProviderss = revRows.map((row) => row?.['service_provider'])
    // console.log(selectedProviderss,"show the service providers")
    try {
      const url =
        ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/add_service_line_customer_dropdown_data",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        service_provider: selectedProviderss[0] || null
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        const customer_names = parsedData?.response_data?.customer_names || []
        setCustomerOptions(customer_names)
      }
    } catch (error) {
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });

    }
  };

  const fetchPackageProductOptions = async (service_type_id:any) => {
    setLoading(true)
    try {
      const url =
        ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_rev_packages_selection",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        provider_id:selectedProviderId || "",
        service_type_id:service_type_id || ""
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        const packages = parsedData?.data?.rev_package || []
        const package_options = packages.map((item:any)=>(`${item?.description || ""} -${item?.package_id || ""}` || ""))
        setPackageOptions(package_options)
        const products = parsedData?.data?.rev_product || []
        const product_options = products.map((item:any)=>(`${item?.description || ""} - ${item?.product_id || ""}` || ""))
        setProductOptions(product_options)
      }
    } catch (error) {
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });

    }
    finally{
      setLoading(false)
    }
  };

  //To get the initial data
  const fetchData = async (value: any) => {
    // settabledata([])
    const selectedProviderss = revRows.map((row) => row?.['service_provider'])
    // console.log(selectedProviderss,"show the service providers")
    try {
      const url =
        ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/add_service_line_dropdown_data",
        customer_name: value,
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        service_provider: selectedProviderss[0] || null
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        const providerMap = parsedData?.response_data?.rev_provider || []
        setProviderMap(providerMap)
        const providerType = parsedData?.response_data?.service_type_rev_provider
        setServiceproviderType(providerType)
        const providerOptions_ =providerMap.map((provider: any) => (provider?.description || ""))
        setProviderOptions(providerOptions_)
        const serviceTypeMap = parsedData?.response_data?.service_type || []
        setServiceTypeMap(serviceTypeMap)
        const revIOProductOptions = parsedData?.response_data?.rev_product || []
        // setProductOptions(revIOProductOptions)
        const customerRatePlanOptions = parsedData?.response_data?.customer_rate_plan_dropdown || []
        setCustomerRatePlanOptions(customerRatePlanOptions)
        const rev_usage_plan_group = parsedData?.response_data?.rev_usage_plan_group || []
        setUsagePlanGroupOptions(rev_usage_plan_group)
        const providerPackageMap_ = parsedData?.response_data?.rev_provider_id_map || {}
        const rev_package = parsedData?.response_data?.rev_package || {}
        setProviderPackageMap(rev_package)
        const rateProductMap_ = parsedData?.response_data?.rev_product_rate || {}
        setRateProductMap(rateProductMap_)
        // const productOptions_ = rateProductMap_.map((product: any) => (product?.description || ""))
        // setProductOptions(productOptions_)
        const ratePackageMap_ = parsedData?.response_data?.rev_package_rate || []
        setRatePackageMap(ratePackageMap_)
        // Extract descriptions for packageOptions
        // const packageOptions_ = ratePackageMap_.map((item: any) => {
        //   const packageInfo = item[0]; // First item in the inner array
        //   return packageInfo?.description || ''; // Get the description or fallback to an empty string
        // }).filter(Boolean); // Remove any undefined or empty strings 
        // console.log("packageOptions_", packageOptions_)
        // setPackageOptions(packageOptions_)
      }
    } catch (error) {
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });

    }
  };

  const startPolling = async (serviceIDs: any,bulkChangeId:any) => {
    // Call addServiceID once when polling starts  
    // Start polling for each service_id independently
    await Promise.all(
      serviceIDs.map(async (serviceId: any) => {
        let isPollingComplete = false;
  
        while (!isPollingComplete) {
          isPollingComplete = await pollServiceLineStatus(serviceId,bulkChangeId);
          if (!isPollingComplete) {
            await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
          }
        }
      })
    );
  
    // Call removeServiceID once when all polling is complete
    removeRevAction("addServiceLine");
    console.log("Polling completed for all service IDs.");
  };
  
  const pollServiceLineStatus = async (serviceId: any,bulkChangeId:any) => {
    try {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/add_service_line_process_data",
        role_name: role,
        parent_module: "SIM Management",
        module_name: "Rev Assurance",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        service_id: serviceId,
        bulk_change_id:bulkChangeId
      };
  
      const response = await axios.post(url, { data: data });
      const parsedData = JSON.parse(response.data.body);
  
      if (parsedData.flag) {
        const status = (parsedData?.response_data?.service_number_status || "").toLowerCase();
  
        if (status === "completed" || status === "processed") {
          onCancel();
          onSave()
          notification.success({
            message: "Success",
            description: `${serviceId} - Successfully Processed!`,
            style: messageStyle,
            placement: "top",
          });
  
          return true; // Stop polling
        } else if (status === "processing" || status === "no status found") {
          return false; // Continue polling
        } else {
          Modal.error({
            title: "Update Error",
            content: `${serviceId} - ${status}!` || "An error occurred while updating data. Please try again.",
            centered: true,
          });
  
          return true; // Stop polling
        }
      }
  
      return false; // Continue polling
    } catch (error) {
      return true; // Stop polling
    }
  };

  const callProcessServiceNumbers = async (parsedData:any, service_numbers:any) =>{
    try {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path:"/process_service_numbers",
        role_name: role,
        module_name: "Revenue Assurance",
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        bulkchange_id: parsedData?.bulk_chnage_id_20,
        service_ids:service_numbers

      };

      const response = await axios.post(url, { data });
      const responseData = JSON.parse(response.data.body);

      if (responseData.flag === false) {
        console.log("callProcessServiceNumbers failed")
      } else {
        console.log("callProcessServiceNumbers success")
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
    }

  }
  
  const callRunDBScript = async (parsedData:any) =>{
    const selectedProviderss = revRows.map((row) => row?.['service_provider'])
    const selected_provider = selectedProviderss[0] || ""

    let request_path;
    let request_url;

    if(selected_provider.toLowerCase()==="kore"){
      request_path="/create_rev_io_service"
      request_url=ENV_ROUTES.SM_BULK_CHANGE
    }
    else{
      request_path="/run_db_script"
      request_url=ENV_ROUTES.SIM_MANAGEMENT
    }
   
    try {
      const service_provider_id_=parsedData?.bulkchange_id?.service_provider_id || 1
      const url = request_url;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path:request_path,
        role_name: role,
        module_name: "Bulk Change",
        mod_pages: {
          start: 0,
          end: 100,
        },
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        service_provider_id:service_provider_id_,
        bulkchange_id: parsedData?.bulkchange_id?.id,
        data: parsedData?.data,
        bulk_chnage_id_20: parsedData?.bulk_chnage_id_20

      };

      const response = await axios.post(url, { data });
      const responseData = JSON.parse(response.data.body);

      if (responseData.flag === false) {
        console.log("failed")
      } else {
        console.log("success")
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
    }

  }
  //To submit the requested payload
  const submitData = async () => {
    addRevAction("addServiceLine","Add Service Line");
    const selectedICCIDs = revRows.map((row) => row?.['iccid'])
    const selectedProviderss = revRows.map((row) => row?.['service_provider'])
    // console.log(selectedProviderss,"show the service providers")
    let selectedRates_: any = [];
    if (selectedRates && Object.keys(selectedRates).length > 0) {
      selectedRates_ = Object.values(selectedRates);
    }
    console.log(addRatePlan, "addRatePlan")
    try {
      // const service_numbers = Array.from(new Set(revRows.map((row) => row?.['service_number'])));
      const service_numbers = revRows.map((row) => row?.['service_number']);
      const back_dating_ids = revRows.map((row) => row?.['id']);
      let customer_name_
      if(selectedCustomer){
        if(isMultiCustomer){
          customer_name_=selectedCustomer
        }
        else{
          customer_name_=[selectedCustomer]
        }
      }

      const submitData = {
        customer_name:customer_name_ || [],
        provider_name: selectedProvider && selectedProvider !== 'No options' ? [selectedProvider] : [],
        service_type: selectedServiceType && selectedServiceType !== 'No options' ? [selectedServiceType] : [],
        revio_product: selectedProduct && !selectedProduct.includes('No options') ? selectedProduct : [],
        revio_package: selectedPackage && selectedPackage !== 'No options' ? [selectedPackage] : [],
        rate: selectedRates_ || [],
        rate_plan: selectedCustomerRatePlan && selectedCustomerRatePlan !== 'No options' ? [selectedCustomerRatePlan] : [],
        activation_date: activationDate ? [activationDate] : [],
        quantity: [1],
        add_rate_plan: [addRatePlan],
        prorate: [prorate],
        use_carrier_activation: useCarrierActivation ? [useCarrierActivation] : [],
        description: description ? [description] : [],
        iccid: selectedICCIDs || [],
        usage_plan_group: usagePlanGroup && usagePlanGroup !== 'No options' ? [usagePlanGroup] : [],
        service_number:service_numbers,
        backdating_id:back_dating_ids

      }
      const url =
        ENV_ROUTES.REV_ASSURANCE;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/add_service_line_data",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        submit_data: submitData,
        service_provider: selectedProviderss[0] ? [selectedProviderss[0]] : null 

      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        removeRevAction("addServiceLine");
        if(parsedData.error_type && parsedData.error_type=="Warning"){
          console.log("parsedData.error_type",parsedData.error_type)
          Modal.warning({
            title: 'Warning',
            content: parsedData.message || 'An error occurred while submitting data. Please try again.',
            centered: true,
          });
        }
        else{
          Modal.error({
            title: 'Data Fetch Error',
            content: parsedData.message || 'An error occurred while fetching data. Please try again.',
            centered: true,
          });
        }
        
      } else {
        const service_ids = Array.from(new Set(revRows.map((row) => row?.['service_number'] || "0")));
        const bulk_change_id=parsedData?.bulk_chnage_id_20 || 0
            callProcessServiceNumbers(parsedData,service_ids)
            await callRunDBScript(parsedData);
        await new Promise((resolve) => setTimeout(resolve, 20000));
        await startPolling(service_ids,bulk_change_id);
      }
    } catch (error) {
      removeRevAction("addServiceLine");
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    }

  };

  //Function for handling customer change
  const handleCustomerChange = (selectedOption: any) => {
    // Reset dependent fields
    setPackageOptions([])
    setProviderOptions([])
    setServiceTypeOptions([])
    setProductOptions([])
    setUsagePlanGroupOptions([])
    setSelectedProvider(null);
    setSelectedServiceType(null);
    setSelectedProduct([]);
    setSelectedRates({})
    setSelectedPackage(null);
    setUsagePlanGroup(null)
    setSelectedCustomerRatePlan(null);
    if (isMultiCustomer) {
    const selectedValues = selectedOption ? selectedOption.map((opt: any) => opt.value) : [];
    setSelectedCustomer(selectedValues);
    fetchData(selectedValues)
    // selectedValues.forEach((val:any) => fetchData(val)); 
  } else {
    if (selectedOption) {
      setSelectedCustomer(selectedOption.value);
      fetchData([selectedOption.value]);
    } else {
      setSelectedCustomer(null);
    }
  }
  };

  //Function for handling provider change
  const handleProviderChange = (selectedOption: any) => {
    console.log(selectedOption,"Show the selected option")
    setServiceTypeOptions([])
      setSelectedServiceType(null)
      setSelectedPackage(null)
      setPackageOptions([])
      setSelectedProduct([])
      setProductOptions([])
    if (selectedOption) {
      setSelectedPackage(null)
      const value=selectedOption.value
      const object: any = providerMap.find((item: any) => (
        item.description === value
      ));
      const selectedId = object?.provider_id || ''
      setSelectedProvider(value);
      setSelectedProviderId(selectedId)

    //   // Clear previous package options
    //   const packageOptions_: string[] = [];

    //   // Filter packages with matching provider_id and push descriptions
    //   ratePackageMap.forEach((pkg:any) => {
    //   if (pkg[0].provider_id === selectedId) {
    //     packageOptions_.push(pkg[0].description);
    //   }
    //  });
    //  setPackageOptions(packageOptions_)
    //  console.log(selectedId, "Filtered package options");
     if (serviceproviderType) {
      if (serviceproviderType.m2m && serviceproviderType.m2m.includes(value)) {
        // console.log(`${value} is in m2m providers`);
        // console.log("serviceproviderType.m2m", serviceTypeMap.m2m)
        setServiceTypeOptions((serviceTypeMap.m2m || []).map((item: { description: string }) => item.description));
        setServiceTypeOptionsMap((serviceTypeMap.m2m || []))
      } else if (serviceproviderType.mobility && serviceproviderType.mobility.includes(value)) {
        // console.log(`${value} is in mobility providers`);
        setServiceTypeOptions((serviceTypeMap.mobility || []).map((item: { description: string }) => item.description));
        setServiceTypeOptionsMap((serviceTypeMap.mobility || []))

      } else {
        console.log(`${value} is not found in m2m or mobility providers`);
      }
    }
    }
    else if (selectedOption === null) {
      setSelectedProvider(null)
      setSelectedProviderId(null)
      setServiceTypeOptions([])
      setSelectedServiceType(null)
      setSelectedPackage(null)
      setPackageOptions([])
      setProductOptions([])
    }

  };

  //Function for handling service type change
  const handleServiceTypeChange = (selectedOption: any) => {
    if (selectedOption) {
      setSelectedPackage(null)
      setPackageOptions([])
      setSelectedProduct([])
      setProductOptions([])
      setSelectedServiceType(selectedOption.value);
       const value=selectedOption.value
      const object: any = serviceTypeOptionsMap.find((item: any) => (
        item.description === value
      ));
      const selectedId = object?.service_type_id || ''
      setSelectedServiceTypeId(selectedId)
      // Clear previous package options
      const packageOptions_: string[] = [];

      // Filter packages with matching provider_id and push descriptions
      ratePackageMap.forEach((pkg:any) => {
      if (pkg[0].service_type_id === selectedId && pkg[0].provider_id === selectedProviderId) {
        packageOptions_.push(pkg[0].description);
      }
     });
    //  setPackageOptions(packageOptions_)
     console.log(selectedId, "Filtered package options",packageOptions_);
     fetchPackageProductOptions(selectedId)
    }
    else if (selectedOption === null) {
      setSelectedServiceType(null)
      setSelectedPackage(null)
      setPackageOptions([])
      setSelectedProduct([])
      setPackageOptions([])
      setSelectedServiceTypeId(null)
    }
  };

  //Function for handling rev.io product change
  const handleProductChange = (selectedOptions: any) => {
    if (selectedOptions) {
      setSelectedPackage(null);
      if (Array.isArray(selectedOptions)) {
        const values = selectedOptions.map((option: any) => option.value);

        // Create an object mapping descriptions to rates
        const matchedRates = values.reduce((acc: any, description: string) => {
          const match = rateProductMap.find(
            (product: any) => product.description === description
          );
          if (match) {
            acc[description] = match?.rate || "0.0";
          }
          return acc;
        }, {});

        setSelectedRates(matchedRates)
        setSelectedProduct(values);
        setSelectedPackage(null);
        console.log("matchedRates", matchedRates)


      } else {
        setSelectedProduct([]);
        setSelectedRates({})
      }
    }
    else if (selectedOptions === null) {
      setSelectedProduct([])
      setSelectedRates({})
    }
  };

  //Function for handling rev.io package change
  const handlePackageChange = (selectedOption: any) => {
    if (selectedOption) {
      const selectedValue = selectedOption.value;
      console.log("selectedValue",selectedValue)
      const package_parts = selectedValue.split("-")
      const package_id = package_parts.length>0 ? package_parts[package_parts.length-1] : "0"
      console.log("package_id",package_id)
      // Find the matched list in ratePackageMap
      const matchedItem = ratePackageMap.find(
        (item: any) => item[0]?.package_id === package_id
      );

      // Assign the second item of the matched list to matchedList
      const matchedList = matchedItem ? matchedItem[1] : null;

      // Transform the matched item into a key-value pair object
const selectedRates = matchedList
  ? matchedList.reduce((acc: Record<string, number>, curr: any) => {
      const key = `${curr.subdescription} - ${curr.product_id}`;
      acc[key] = curr.rate;
      return acc;
    }, {})
  : {};

  if(matchedItem){
      setSelectedRates(selectedRates)
  }
  else{
    const default_rate = {
      [selectedValue]:0
    }
    setSelectedRates(default_rate)
  }

      // Update the selected package and optionally log or use matchedList
      setSelectedPackage(selectedValue);
      console.log("matchedItem:", matchedItem);
      console.log("selectedRates:", selectedRates);
      console.log("Matched List:", matchedList);

      // Perform further actions with matchedList if needed
    } else if (selectedOption === null) {
      setSelectedPackage(null);
      setSelectedRates({})
    }
  };


  //Function for handling usage plan change
  const handleUsagePlanGroup = (selectedOption: any) => {
    if (selectedOption) {
      setUsagePlanGroup(selectedOption.value);
    }
    else if (selectedOption === null) {
      setUsagePlanGroup(null)
    }
  };

  //Function for handling customer rate plan change
  const handleCustomerRatePlanChange = (selectedOption: any) => {
    if (selectedOption) {
      setSelectedCustomerRatePlan(selectedOption.value);
    }
    else if (selectedOption === null) {
      setSelectedCustomerRatePlan(null)
    }
  };

  const handleSubmit = () => {
    setShowConfirmation(true)
  };

  //Function for handling confirm submit change
  const confirmSubmit = () => {
    setRevHeaderMap(originalHeaderMap)
    setRevRows([]);
    setInitialRows([]);
    setIsClosed(true)
    submitData()
    // message.success('Data submitted successfully!');
    notification.success({
      message: "Success",
      description: "Data submitted successfully!",
      style: messageStyle,
      placement: "top",
    });
    setShowConfirmation(false);
    onCancel()
  };

  //upload functions
  const downloadBlob = (base64Blob: string) => {
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    const blobObject = new Blob([byteArray], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blobObject);
    link.download = `Add Service Line.xlsx`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
   const handleDownloadTemplate = async () => {
    setIsUploadModalVisible(false)
    const selectedICCIDs = revRows.map((row) => row?.['iccid'])
    const selectedProviders = revRows.map((row) => row?.['service_provider'])
    const service_numbers = revRows.map((row) => row?.['service_number']);
    const customerIds = revRows.map((row) => row?.['rev_account_number']);
    const customerNames_ = revRows.map((row) => row?.['customer_name'])
    setLoading(true);
    const url =
      ENV_ROUTES.SIM_MANAGEMENT;
    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/rev_assurance_button_upload_download",
      button_name: "add_service_line",
      module_name: "Revenue Assurance",
      role_name: role,
      Partner: partner,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
        ... metaData,
      sessionID: sessionId,
      iccid:selectedICCIDs || [],
      msisdn:service_numbers || [],
      service_provider:selectedProviders || [],
      customer_id : customerIds || [],
      customer_name:customerNames_ || []
    };

    const response = await axios.post(url, { data });
    const resp = JSON.parse(response.data.body);
    const blob = resp.blob;
    console.log(resp);
    if (response.data.statusCode === 200) {
      if (resp.flag === true) {
        notification.success({
          message: 'Success',
          description: 'Successfully downloaded the template!',
          style: messageStyle,
          placement: 'top',
        });
        downloadBlob(blob);
        // fetchData();
        setLoading(false);
        setIsUploadModalVisible(false);
      } else {
        console.log('Error message:', resp.message);
        Modal.error({
          title: 'Export Error',
          content: resp.message,
          centered: true,
        });
      }
    } else {
      console.log('Unexpected status code:', response.data.statusCode);
      Modal.error({
        title: 'Export Error',
        content: resp.message,
        centered: true,
      });
    }
  };
  const handleUploadModalClose = () => {
    setIsUploadModalVisible(false);
  };
  const AddServiceLineUploadSyncs = async(parsedData:any) =>{
    const service_ids = parsedData?.service_ids || []
        const bulk_change_id=parsedData?.bulk_chnage_id_20 || 0
        callProcessServiceNumbers(parsedData,service_ids)
        await callRunDBScript(parsedData);
        await new Promise((resolve) => setTimeout(resolve, 20000));
        await startPolling(service_ids,bulk_change_id);
  }
  const handleUpload = async (blob: string) => {
    setLoading(true)
    const selectedProviders = revRows.map((row) => row?.['service_provider'])
    const customerNames_ = revRows.map((row) => row?.['customer_name'])    
    try {
      const url = ENV_ROUTES.REV_ASSURANCE;
      let flag: string = appendChecked ? "append" : "overwrite";

      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path:  "/handle_add_service_line_upload",
        insert_flag: "append",
        module_name: "Revenue Assurance",
        role_name: role,
        button_name: "add_service_line",
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        blob: blob, // Include the Blob in the data
        service_provider:selectedProviders[0] || [],
        customer_name:customerNames_ || []
      };

      const response = await axios.post(url, { data });

      const resp = JSON.parse(response.data.body);
      if (response.data.statusCode === 200) {
        if (resp.flag === true) {
          AddServiceLineUploadSyncs(resp)
          onCancel()
          onSave()
          notification.success({
            message: 'Success',
            description: 'Successfully uploaded the record!',
            placement: 'top',
          });
        } else {
          Modal.error({
            title: 'Import Error',
            content: resp.message,
            centered: true,
            onOk: handleErrorModalClose,
            onCancel: handleErrorModalClose
          });
        }
      } else {
        Modal.error({
          title: 'Import Error',
          content: resp.message,
          centered: true,
          onOk: handleErrorModalClose,
          onCancel: handleErrorModalClose
        });
      }
    } catch (error) {
      console.error('Error during file upload:', error);
      Modal.error({
        title: 'Import Error',
        content: 'There was an error uploading the file.',
        centered: true,
        onOk: handleErrorModalClose,
        onCancel: handleErrorModalClose
      });

    }
    finally {
      setLoading(false)
      setIsUploadModalVisible(false)
    }
  }
  const handleErrorModalClose = () => {
    setIsUploadModalVisible(false)
  }
  const handleChange = (info: any) => {
    if (info.file.status === 'done') {
      setIsFileSelected(true);
      let blob;
      const file = info.file.originFileObj; // Get the file object
      const reader = new FileReader();
      reader.onload = (e: any) => {
        // Get the file data URL (Base64 string)
        blob = e.target.result;
        console.log('File Base64 String:', blob);
        handleUpload(blob)
        setUploadKey(Date.now());
      };

      if (blob) {
      }

      reader.readAsDataURL(file); // Read the file as data URL
    } else if (info.file.status === 'error') {
      // Handle upload error
      message.error('Upload failed.');
    }
    else if (info.file.status === 'removed') {
      setIsFileSelected(false);
      setAppendChecked(false);
      setOverwriteChecked(false);
    }
  };
  const uploadProps = {
    key: uploadKey,
    accept: '.xlsx, .xls',
    beforeUpload: (file: any) => {
      // Check if file is an Excel file
      const isExcel = file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || file.type === 'application/vnd.ms-excel';
      if (!isExcel) {
        message.error('You can only upload Excel files!');
      }
      return isExcel;
    },
    onChange: handleChange,
  };

  //Function to display custom label
  const renderLabel = (label: string, required: boolean) => (
    <span className="field-label">
      {label}{" "}
      {required && (
        <span className="required-indicator" style={{ color: "red" }}>
          *
        </span>
      )}
    </span>
  );

  const handleNext = () => {
    let isValid = true;
    // Validate customer
    if(isMultiCustomer){
      if(selectedCustomer &&selectedCustomer.length===0){
        setCustomerError("Please select a customer!");
        isValid = false;
    } else {
      setCustomerError('');
    }
    }
    else{
      if (!selectedCustomer) {
      setCustomerError("Please select a customer!");
      isValid = false;
    } else {
      setCustomerError('');
    }
    }
    
    // Validate provider
    if (!selectedProvider) {
      setProviderError("Please select a provider!");
      isValid = false;
    } else {
      setProviderError('');
    }

    // Validate service type
    if (!selectedServiceType) {
      setServiceTypeError("Please select a service type!");
      isValid = false;
    } else {
      setServiceTypeError('');
    }

    // Validate activation date
    if (!activationDate && !useCarrierActivation) {
      setActivationDateError("Please select an activation date!");
      isValid = false;
    } else {
      setActivationDateError('');
    }

    // Validate product
    if (selectedProduct.length < 1 && !selectedPackage) {
      setProductError("Please select a either  product or package");
      isValid = false;
    } else {
      setProductError('');
    }

    // Validate package
    // if (!selectedPackage) {
    //   setPackageError("Please select a package!");
    //   isValid = false;
    // } else {
    //   setPackageError('');
    // }

    // Validate quantity
    // if (!selectedQuantity || isNumber(selectedQuantity) || Number(selectedQuantity) <= 0) {
    //   setQuantityError("Please input a valid quantity!");
    //   isValid = false;
    // } else {
    //   setQuantityError('');
    // }

    // If the form is valid, proceed to the next step
    if (isValid) {
      handleSubmit()
      // const headerMap_ = {
      //   "service_number": [
      //     "Service id",
      //     null
      //   ],
      //   "customer_rate_plan_name": [
      //     "Customer rate plan",
      //     null
      //   ],
      //   "carrier_rate_plan_name": [
      //     "Carrier rate plan",
      //     null
      //   ]
      // }
      // setRevHeaderMap(headerMap_)

    } else {
      message.error("Please fill all required fields.");
    }
  };
  const cancelConfirmation = () => {
    setShowConfirmation(false);
    setIsNextClicked(false)
  };
  const handleBack = () => {
    setIsNextClicked(false)
  }
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    // Prevent default behavior for specific keys
    const invalidKeys = ['+', '-', 'e']; // List of invalid keys
    if (invalidKeys.includes(e.key)) {
      e.preventDefault(); // Prevent the default action for these keys
      console.log(`${e.key} key pressed - blocked`);
    }
  };

  const disablePastDates = (current: any) => {
    // Disable all dates before today
    return current && current < moment().startOf('day'); // Start of the current day to include today's date
  };

  const modalHeight = typeof window !== 'undefined' ? (window.innerHeight * 2.5) / 4 : 0;

  return (
    <>
      <Modal
        // title="Create new Billing Platform Service Line"
        title={
          <div className='md:flex flex-col md:flex-row justify-between'>
            <span className='font-semibold text-[18px]'>Create new Billing Platform Service Line</span>
              <button
                onClick={() => { setIsUploadModalVisible(true) }}
                className="save-btn mr-8 mt-4" 
              >
                <span className="md:mr-2"><UploadOutlined /></span>
                Upload
              </button>
            </div>
        }
        visible={visible}
        onCancel={onCancel}
        width={800}
        maskClosable={false}
        centered
        style={{ top: 40 }}
        footer={
          <div className='justify-center flex space-x-2'>
            <>
              <button key="cancel" className='cancel-btn' onClick={onCancel}>
                Cancel
              </button>
              <button key="submit" className="save-btn" onClick={handleNext}>
                Submit
              </button>
            </>
          </div>
        }
        styles={{ body: { height: modalHeight, padding: '4px' } }}
      >
        {loading?(
          <div className="flex justify-center items-center" style={{ height: modalHeight }}>
            <Spin size="large" />
          </div>
        ):(
          <div className='popup'>
          <>
          {/* <div className='flex justify-end'>
              <button
                onClick={() => { setIsUploadModalVisible(true) }}
                className="save-btn"
              >
                <span className="mr-2"><UploadOutlined /></span>
                Upload
              </button>
            </div> */}
            <div className='grid grid-cols-1 md:grid-cols-2 gap-4'>
              <div>
                <label>{renderLabel("Billing Platform Customer", true)}</label>
                <Select
                  options={customerOptions.length > 0 ? customerOptions.map((option) => ({
                    label: option,
                    value: option,
                  })) : [{ value: null, label: 'No options' }]}
                  // placeholder="Select a Rev.io customer"
                  value={
                    isMultiCustomer
                     ? (selectedCustomer as string[] | null)?.map((cust) => ({
                       label: cust,
                        value: cust,
                         })) || null
                         : selectedCustomer
                          ? { label: selectedCustomer as string, value: selectedCustomer as string }
                          : null
                        }
                  onChange={handleCustomerChange}
                  isClearable
                  styles={DropdownStyles}
                  isMulti={isMultiCustomer}
                />
                {customerError && <p className="error text-red-500">Please Select a Customer</p>}
              </div>
              <div>
                <label>{renderLabel("Billing Platform Provider", true)}</label>
                <Select
                  options={providerOptions.length > 0 ? providerOptions.map((option) => ({
                    label: option,
                    value: option,
                  })) : [{ value: 'No options', label: 'No options' }]}
                  // placeholder="Please select a Rev.io provider"
                  value={selectedProvider === 'No options' ? null : { label: selectedProvider, value: selectedProvider }}
                  onChange={handleProviderChange}
                  // isDisabled={!selectedCustomer || selectedCustomer === 'No options'}
                  isClearable
                  styles={DropdownStyles}
                />
                {providerError && <p className="error text-red-500">Please Select a Provider</p>}
              </div>

              <div>
                <label>{renderLabel("Service type", true)}</label>
                <Select
                  options={serviceTypeOptions.length > 0 ? serviceTypeOptions.map((option:any) => ({
                    label: option,
                    value: option,
                  })) : [{ value: 'No options', label: 'No options' }]}
                  // placeholder="Please select a service type"
                  value={selectedServiceType === 'No options' ? null : { label: selectedServiceType, value: selectedServiceType }}
                  onChange={handleServiceTypeChange}
                  isDisabled={!selectedCustomer}
                  isClearable
                  styles={DropdownStyles}
                />
                {serviceTypeError && <p className="error text-red-500">Please Select a Service Type</p>}
              </div>

              <div>
                <label>{renderLabel("Activation date", true)}</label>
                <DatePicker
                  style={{ width: '100%' }}
                  value={activationDate}
                  onChange={(date) => setActivationDate(date)}
                  className='input p-[7px]'
                  // disabledDate={disablePastDates}
                  disabled={useCarrierActivation}
                />
                {activationDateError && <p className="error text-red-500">Please Select an Activation Date</p>}
              </div>


              <div>
                <label>{renderLabel("Billing Platform Product", true)}</label>
                <Select
                  options={productOptions.length > 0 ? productOptions.map((option) => ({
                    label: option,
                    value: option,
                  })) : [{ value: 'No options', label: 'No options' }]}
                  // placeholder="Select a product"
                  value={selectedProduct.length > 0 ? selectedProduct.map((option: any) => ({ label: option, value: option })) : null}
                  onChange={handleProductChange}
                  isDisabled={!!(!selectedCustomer || selectedPackage)}
                  isMulti
                  className='mb-4'
                  styles={DropdownStyles}
                />
                <span className="font-medium">OR</span>
                {productError && <p className="error text-red-500">Please Select either Product or Package</p>}
              </div>

              <div>
                <label>{renderLabel("Usage plan group", false)}</label>
                <Select
                  options={usagePlanGroupOptions.length > 0 ? usagePlanGroupOptions.map((option) => ({
                    label: option,
                    value: option,
                  })) : [{ value: 'No options', label: 'No options' }]}
                  value={usagePlanGroup === 'No options' ? null : { label: usagePlanGroup, value: usagePlanGroup }}
                  onChange={handleUsagePlanGroup}
                  isDisabled={!selectedCustomer}
                  isClearable
                  styles={DropdownStyles}
                />
              </div>

              <div>
                <label>{renderLabel("Billing Platform Package", true)}</label>
                <Select
                  options={packageOptions.length > 0 ? packageOptions.map((option) => ({
                    label: option,
                    value: option,
                  })) : [{ value: 'No options', label: 'No options' }]}
                  placeholder="Please Select a Billing Platform Package"
                  value={selectedPackage === 'No options' ? null : { label: selectedPackage, value: selectedPackage }}
                  onChange={handlePackageChange}
                  isDisabled={!selectedCustomer || selectedProduct.length > 0}
                  isClearable
                  styles={DropdownStyles}
                />
                {productError && <p className="error text-red-500">Please Select Either Product or Package</p>}
              </div>
              
              <div>
                <label className='font-600'>{renderLabel("Rates", false)}</label>
                {selectedRates && Object.keys(selectedRates).length > 0 && (
                  <div className="grid grid-cols-2 gap-4">
                    {Object.entries(selectedRates).map(([product, rate], index) => (
                      <React.Fragment key={index}>
                        {/* Left Column: Label */}
                        <div className="text-left pr-4">{product}:</div>

                        {/* Right Column: Input Field */}
                        <div>
                          <input
                            type="number"
                            value={Number(rate)}
                            min="0.0"
                            step="0.01"
                            className="w-[100px] border border-gray-400 rounded pl-2"
                            onChange={(e) => {
                              // const newRate = e.target.value;
                              const newRate = e.target.value === "" ? "0.0" : e.target.value;
                              console.log("newRate",newRate)
                              setSelectedRates((prevRates: any) => ({
                                ...prevRates,
                                [product]: newRate,
                              }));
                            }}
                          />
                        </div>
                      </React.Fragment>
                    ))}
                  </div>
                )}
              </div>

              {/* <div>
                <label>{renderLabel("Quantity", true)}</label>
                <input
                  type="number"
                  value={selectedQuantity}
                  // onChange={(e) => {
                  //   const value = Math.max(1, Number(e.target.value)); // Ensure the value is at least 1
                  //   setSelectedQuantity(value); // Update the state with the new value
                  // }}
                  className="input"
                  min={1}
                  onChange={(e) => {
                    const value = Math.max(1, parseInt(e.target.value, 10)); // Ensure quantity is not less than 1
                    setSelectedQuantity(value.toString());
                  }}
                onKeyDown={handleKeyDown} // Add the keydown event listener

                />
                {quantityError && <p className="error text-red-500">Please Input the Quantity</p>}
              </div> */}
              <div>
                <label>{renderLabel("Service line description", false)}</label>
                <input
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className='input'
                />
              </div>
              { (role?.toLowerCase() === "super admin" || role?.toLowerCase() === "partner admin" || role?.toLowerCase() === "agent partner admin" || role?.toLowerCase() === "agent") &&
              <div>
              <Checkbox
                checked={useCarrierActivation}
                onChange={(e) => setUseCarrierActivation(e.target.checked)}
                className='mt-4'
              >
                Use Carrier Activation
              </Checkbox>
              {/* <label>Use Carrier Activation?</label> */}
            </div>
              }
              
              <div>
                <Checkbox
                  checked={prorate}
                  onChange={(e) => setProrate(e.target.checked)}
                  className='mt-4'
                >
                  Prorate
                </Checkbox>
                {/* <label>Prorate?</label> */}
              </div>
              <div>
                <Checkbox
                  checked={addRatePlan}
                  onChange={(e) => setAddRatePlan(e.target.checked)}
                  className='mt-4'
                >
                  Add Rate Plan
                </Checkbox>
                {/* <label>Add Customer Rate Plan?</label> */}
              </div>
              {addRatePlan && (
                <div>
                  <label>{renderLabel("Customer rate plan", false)}</label>
                  <Select
                    options={customerRatePlanOptions.length > 0 ? customerRatePlanOptions.map((option) => ({
                      label: option,
                      value: option,
                    })) : [{ value: 'No options', label: 'No options' }]}
                    value={{ label: selectedCustomerRatePlan, value: selectedCustomerRatePlan }}
                    onChange={handleCustomerRatePlanChange}
                    isClearable
                  />
                </div>
              )}

            </div>
          </>
        </div>
        )
        }
        

      </Modal>

      {/* Upload Modal*/}
      <Modal
        title="Upload Files"
        visible={isUploadModalVisible}
        onCancel={handleUploadModalClose}
        footer={null}
        centered
        width={400}
      >
        <div className="flex flex-col gap-4">
          <div className="flex flex-col md:flex-row gap-4 justify-center m-auto p-4">
            <Upload {...uploadProps} className="w-full md:w-auto">
              <button className="w-[200px] md:w-full upload-btn disabled:cursor-not-allowed">
                <span className="mr-2"><UploadOutlined /></span>
                Upload
              </button>
            </Upload>
            <button
              onClick={handleDownloadTemplate}
              className=" w-[200px] md:w-full upload-btn disabled:cursor-not-allowed"
            >
              <span className="mr-2"><DownloadOutlined /></span>
              Download Template
            </button>
          </div>
        </div>
      </Modal>

      <Modal
        title="Submit data"
        visible={showConfirmation}
        onCancel={cancelConfirmation}
        centered
        footer={
          <div className="justify-center flex space-x-2">
            <button key="cancel" className='cancel-btn' onClick={cancelConfirmation}>
              Cancel
            </button>
            <button key="confirm" className='save-btn' onClick={confirmSubmit}>
              OK
            </button>
          </div>
        }
      >
        <p>Are you sure you want to Submit this data</p>
      </Modal>
    </>
  );
};

export default AddServiceLine;
