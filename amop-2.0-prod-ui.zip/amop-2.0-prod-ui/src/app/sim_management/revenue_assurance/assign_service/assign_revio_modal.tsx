import React, { lazy, Suspense, useEffect, useState } from 'react';
import { Modal, Button, message, DatePicker, notification, Spin } from 'antd';
import Select from 'react-select';
import { useRevStore } from '@/app/stores/revStore';
import { useAuth } from '@/app/components/auth_context';
import { getCurrentDateTime } from '@/app/components/header_constants';
import axios from 'axios';
import VirtualizedSelect from '@/app/components/virtualized_dropdown';
import { ENV_ROUTES } from '@/app/components/routes/route_constants';
import moment from 'moment';
import DisconnectProductTable from '@/app/components/revTableComponent/disconnectProductTable';
import { exportLoadingStore } from '@/app/stores/ExportLoadingStore';
import { DropdownStyles } from '@/app/components/css/dropdown';

// Define the props interface for MyModal
interface MyModalProps {
  visible: boolean;
  onCancel: () => void;
  onSave: () => void;
}

const messageStyle = {
  fontSize: "14px",
  fontWeight: "bold",
  padding: "16px",
};
// Lazy load the RevTableComponent
const RevTableComponent = lazy(() => import('@/app/components/revTableComponent/page'));

const AssignService: React.FC<MyModalProps> = ({ visible, onCancel, onSave }) => {
  const [selectedCustomer, setSelectedCustomer] = useState<any[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<any>([]);
  const [selectedPackage, setSelectedPackage] = useState(null);
  const [selectedService, setSelectedService] = useState(null);
  const [isNextClicked, setIsNextClicked] = useState<boolean>(false); // To track if "Next" is clicked
  const { revRows, revActionRows, revHeaders, revHeaderMap, setIsClosed, setRevRows, setRevHeaders, setRevHeaderMap } = useRevStore();
  const [initialRows, setInitialRows] = useState(revRows)
  const [serviceOptions, setServiceOptions] = useState<any[]>([]);
  const [packageOptions, setPackageOptions] = useState<any[]>([]);
  const [productOptions, setProductOptions] = useState<any[]>([]);
  const [customerOptions, setCustomerOptions] = useState<any[]>([]);
  const { settabledata, username, role, partner, token, selectedDb, metaData,firstLastName, sessionId } = useAuth();
  const [serviceMap, setServiceMap] = useState<{ [key: string]: string }>({});
  const [servicePackageMap, setServicePackageMap] = useState<{ [key: string]: string }>({});
  const [serviceProductMap, setServiceProductMap] = useState<{ [key: string]: string }>({});
  const [isListViewNextClicked, setIsListViewNextClicked] = useState<boolean>(false);
  const [showConfirmation, setShowConfirmation] = useState<boolean>(false);
  const [effectiveDate, setEffectiveDate] = useState(null);
  const [originalHeaderMap, setOriginalHeaderMap] = useState<any>(revHeaderMap);
  const { addRevAction } = exportLoadingStore();
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({
    customer: false,
    service: false,
    productOrPackage: false,
  });

  const clearAll = () => {
    setSelectedCustomer([]);
    setSelectedProduct([]);
    setSelectedPackage(null);
    setSelectedService(null);
    setIsNextClicked(false);
    setInitialRows(revRows); // Reset to the current state of revRows from useRevStore
    setServiceOptions([]);
    setPackageOptions([]);
    setProductOptions([]);
    setCustomerOptions([]);
    setServiceMap({});
    setServicePackageMap({});
    setServiceProductMap({});
    setIsListViewNextClicked(false);
    setShowConfirmation(false);
    setEffectiveDate(null);
    setOriginalHeaderMap(revHeaderMap); // Reset to the current state of revHeaderMap from useRevStore
  };


  useEffect(() => {

    if (visible) {
      clearAll()
      setInitialRows(revRows)
      const customerOptions_ = Array.from(new Set(revRows.map((row) => row?.['customer_name']))).filter(Boolean);
      setCustomerOptions(customerOptions_)
      const defaultCustomers = customerOptions_.map((opt: any) => ({ label: opt, value: opt }));
      setSelectedCustomer(defaultCustomers);
      setIsNextClicked(false)
      setIsListViewNextClicked(false)
      fetchData(customerOptions_)
    }

  }, [visible]);

  //to load the initial data
  const fetchData = async (value: any) => {
    // settabledata([])
    setLoading(true);
    try {
      const url =
        ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/assign_service_dropdown_data",
        customer_name: value,
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        const rev_service = parsedData?.response_data?.rev_service || []
        setServiceOptions(rev_service)
        const rev_product = parsedData?.response_data?.rev_product || []
        setServiceProductMap(rev_product)
        const serviceMap_ = parsedData?.response_data?.rev_service_id_map || {}
        setServiceMap(serviceMap_)
        const rev_package = parsedData?.response_data?.rev_package || {}
        setServicePackageMap(rev_package)

      }
    } catch (error) {
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    }
    finally {
      setLoading(false)
    }
  };

  //To submit the data (requested payload)
  const submitData = async () => {
    const selectedICCIDs = revRows.map((row) => row?.['iccid'])
    const selectedServiceNos = revRows.map((row) => row?.['service_number'])
    const selectedProviderss = revRows.map((row) => row?.['service_provider'])
    const customer_name_ = selectedCustomer.length > 0 ? selectedCustomer.map((option) => (option?.value || "")) : []
    const customer_iccid_dict_: Record<string, any[]> = {};

    initialRows.forEach((row: any) => {
      const customerName_ = row.customer_name;

      if (!customer_iccid_dict_[customerName_]) {
        customer_iccid_dict_[customerName_] = [];
      }

      customer_iccid_dict_[customerName_].push(row.iccid);
    });

    console.log("customer_iccid_dict_", customer_iccid_dict_)

    const iccid_msisdn_dict_: Record<string, any> = {}
    revRows.map((row: any) => {
      const iccid = row.iccid
      const msisdn = row.service_number
      iccid_msisdn_dict_[iccid] = msisdn
    })
    console.log("iccid_msisdn_dict_", iccid_msisdn_dict_)

    const quantity_: Record<string, any> = {}
    customer_name_.map((option) => { quantity_[option] = customer_iccid_dict_[option].length })
    console.log("quantity_", quantity_)

    try {
      addRevAction("assignService", "Assign Service")
      const submitData = {
        customer_name: selectedCustomer.length > 0 ? selectedCustomer.map((option) => (option?.value || "")) : [],
        service_type: selectedService && selectedService !== 'No options' ? selectedService : null,
        revio_product: selectedProduct && !selectedProduct.includes('No options') ? selectedProduct : null,
        revio_package: selectedPackage && selectedPackage !== 'No options' ? selectedPackage : null,
        iccid: selectedICCIDs || null,
        service_number: selectedServiceNos || null,
        effective_date: effectiveDate,
        quantity: quantity_,
        customer_iccid_dict: customer_iccid_dict_,
        iccid_msisdn_dict: iccid_msisdn_dict_
      }
      const url =
        ENV_ROUTES.REV_ASSURANCE;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/submit_assign_service_data",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        submit_data: submitData,
        service_provider: selectedProviderss[0] || null,
        row_count: revRows.length || 0

      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        // message.success('Data submitted successfully!');
        notification.success({
          message: "Success",
          description: "Data submitted successfully!",
          style: messageStyle,
          placement: "top",
        });
      }
    } catch (error) {
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    }

  };

  //function to handle the customer change
  const handleCustomerChange = (selectedOption: any) => {
    setSelectedPackage(null)
    setSelectedProduct([])
    setSelectedService(null)
    setPackageOptions([])
    setProductOptions([])
    setServiceOptions([])
    console.log("selected customers", selectedOption)
    setSelectedCustomer(selectedOption);
    const selectedOptions = selectedOption.map((option: any) => (option?.value))
    fetchData(selectedOptions)
  };
  //function to handle the rev.io product change
  const handleProductChange = (selectedOptions: any) => {
    if (selectedOptions) {
      setSelectedPackage(null);
      console.log("values", selectedOptions)
      if (Array.isArray(selectedOptions)) {
        const values = selectedOptions.map((option: any) => option.value);
        console.log("values", values)
        setSelectedProduct(values);
      } else {
        setSelectedProduct([]);
      }
    }
    else if (selectedOptions === null) {
      setSelectedProduct([])
    }
  };
  //function to handle the rev.io package change
  const handlePackageChange = (selectedOption: any) => {
    if (selectedOption) {
      setSelectedPackage(selectedOption.value);
      setSelectedProduct([]);
    }
    else if (selectedOption === null) {
      setSelectedPackage(null)
    }
  };

  //function to handle the service change
  const handleServiceChange = (selectedOption: any) => {
    setPackageOptions([]);
    setProductOptions([]);
    setSelectedPackage(null)
    setSelectedProduct([])
    if (selectedOption) {
      setSelectedService(selectedOption.value);
      const providerID = serviceMap?.[selectedOption.value]
      if (providerID) {
        // Extract package options and rate options using the provider ID
        const packageOptions: any = servicePackageMap?.[providerID] || [];
        const productOptions: any = serviceProductMap?.[providerID] || [];

        // Update the state with the extracted options
        setPackageOptions(packageOptions);
        setProductOptions(productOptions);
      } else {
        setPackageOptions([]);
        setProductOptions([]);
      }
    }
    else if (selectedOption === null) {
      setSelectedService(null)
    }
  };
  const handleNext = () => {
    const hasErrors = {
      customer: !selectedCustomer,
      service: !selectedService,
      productOrPackage: selectedProduct.length === 0 && !selectedPackage,
    };

    setErrors(hasErrors);

    if (!Object.values(hasErrors).some((e) => e)) {
      setIsNextClicked(true);
      const headerMap_ = {
        "service_number": [
          "Service id",
          null
        ],
        "customer_rate_plan_name": [
          "Customer rate plan",
          null
        ],
        "carrier_rate_plan_name": [
          "Carrier rate plan",
          null
        ]
      }
      setRevHeaderMap(headerMap_)
    }
  };
  const handleSubmit = () => {
    setShowConfirmation(true)
  };

  //To reset the values
  const cancelConfirmation = () => {
    setShowConfirmation(false);
    setIsNextClicked(false)
    setIsListViewNextClicked(false);
  };

  //To reset the values
  const confirmSubmit = () => {
    // setRevRows([]);
    setInitialRows([]);
    setIsClosed(true)
    submitData()
    setShowConfirmation(false);
    setRevHeaderMap(originalHeaderMap)
    onCancel()
    onSave()
  };

  //to handle navigation
  const handleBack = () => {
    setIsNextClicked(false)
  }

  //to handle navigation
  const handleListViewBack = () => {
    setIsListViewNextClicked(false)
    setIsNextClicked(true)
  }

  //to handle navigation
  const handleListViewNext = () => {
    setIsListViewNextClicked(true)
    setIsNextClicked(false)
  }
  const disablePastDates = (current: any) => {
    // Disable all dates before today
    return current && current < moment().startOf('day'); // Start of the current day to include today's date
  };

  return (
    <>
      <Modal
        title="Assign Billing Platform Service"
        visible={visible}
        onCancel={onCancel}
        maskClosable={false}
        centered
        footer={
          <div className="justify-center flex space-x-2">

            {isListViewNextClicked ? (
              <>
                <button key="cancel" className="cancel-btn" onClick={handleListViewBack}>
                  Back
                </button>
                <button key="submit" className="save-btn" onClick={handleSubmit}>
                  Submit
                </button>
              </>
            ) : isNextClicked ? (
              <>
                <button key="cancel" className="cancel-btn" onClick={handleBack}>
                  Back
                </button>
                <button key="submit" className={`save-btn`} onClick={handleListViewNext}>
                  Next
                </button>
              </>
            ) : (
              <>
                <button key="cancel" className="cancel-btn" onClick={onCancel}>
                  Cancel
                </button>
                <button key="next" className="save-btn" onClick={handleNext}>
                  Next
                </button>
              </>
            )}

          </div>
        }
      >
        {loading ? (
          <div className="flex justify-center items-center h-[200px]">
            <Spin size="large" />
          </div>
        ) : (
          <>
            {
              isListViewNextClicked ? (
                <div>
                  <div>
                    <label style={{ marginRight: 8 }}>Quantity</label>
                    <input
                      type="text"
                      value={revRows.length || 0}
                      readOnly
                      className='non-editable-input' />
                  </div>
                  <div style={{ marginBottom: 16 }}>
                    <label style={{ marginRight: 8 }}>Effective Date</label>
                    <DatePicker
                      value={effectiveDate}
                      onChange={(date) => setEffectiveDate(date)}
                      className='input'
                    // disabledDate={disablePastDates}
                    />
                  </div>
                </div>
              ) : isNextClicked ? (
                <>
                  <Suspense fallback={<div>Loading...</div>}>
                    <DisconnectProductTable
                      headerMap={revHeaderMap}
                      headers={revHeaders}
                      initialData={initialRows}
                      searchQuery=""
                      visibleColumns={revHeaders}
                      itemsPerPage={10}
                      moduleName="Rev.io data"
                      pagination={{
                        start: 1,
                        end: 100,
                        total: initialRows.length,
                      }}
                      advancedFilters={{}}
                      onDateChange={() => { }}
                    />
                  </Suspense>
                </>
              ) :
                (
                  <>
                    <div className="form-group">
                      <label>
                        Billing Platform Customer <span style={{ color: 'red' }}>*</span>
                      </label>
                      <Select
                        // className="multi-select-wrap"
                        options={customerOptions.length > 0 ? customerOptions.map((option) => ({
                          label: option,
                          value: option,
                        })) : [{ value: 'No options', label: 'No options' }]}
                        placeholder="Select Customer"
                        value={selectedCustomer}
                        onChange={handleCustomerChange}
                        isClearable
                        isMulti
                        isDisabled
                        className='cursor-not-allowed'
                        styles={{
                          valueContainer: (base) => ({
                            ...base,
                            flexWrap: 'wrap',
                            maxHeight: '120px', // height of the selected options area
                            overflowY: 'auto',
                          }),
                          control: (base) => ({
                            ...base,
                            minHeight: 'auto', // let it grow naturally
                          }),
                          menuPortal: (base) => ({ ...base, zIndex: 9999 }),
                        }}
                        menuPortalTarget={document.body}
                      />
                      {errors.customer && <p style={{ color: 'red' }}>Customer is Required</p>}
                    </div>

                    <div className="form-group" style={{ marginTop: '16px' }}>
                      <label>
                        Billing Platform Service <span style={{ color: 'red' }}>*</span>
                      </label>
                      <VirtualizedSelect
                        isDisabled={!selectedCustomer}
                        value={selectedService === 'No options' ? null : { label: selectedService, value: selectedService }}
                        onChange={handleServiceChange}
                        options={serviceOptions.length > 0 ? serviceOptions.map((option: string) => ({
                          label: option,
                          value: option,
                        })) : [{ value: 'No options', label: 'No options' }]}
                        isMulti={false}
                        placeholder="Please Select Customer"
                        maxHeight={300} // Define the max height for the dropdown
                        styles={DropdownStyles}
                      />
                      {errors.service && <p style={{ color: 'red' }}>Service is Required</p>}
                    </div>

                    <div className="form-group" style={{ marginTop: '16px' }}>
                      <label>
                        Billing Platform Product <span style={{ color: 'red' }}>*</span>
                      </label>
                      <Select
                        options={productOptions.length > 0 ? productOptions.map((option) => ({
                          label: option,
                          value: option,
                        })) : [{ value: 'No options', label: 'No options' }]}
                        placeholder="Select Product"
                        value={selectedProduct.length > 0 ? selectedProduct.map((option: any) => ({ label: option, value: option })) : null}
                        onChange={handleProductChange}
                        isDisabled={!!selectedPackage || !selectedCustomer || !selectedService}
                        isClearable
                        isMulti
                        styles={DropdownStyles}
                      />
                    </div>

                    <label style={{ display: 'block', marginTop: '8px' }}>Or</label>

                    <div className="form-group" style={{ marginTop: '16px' }}>
                      <label>
                        Billing Platform Package <span style={{ color: 'red' }}>*</span>
                      </label>
                      <Select
                        options={packageOptions.length > 0 ? packageOptions.map((option) => ({
                          label: option,
                          value: option,
                        })) : [{ value: 'No options', label: 'No options' }]}
                        placeholder="Select Package"
                        value={selectedPackage === 'No options' ? null : { label: selectedPackage, value: selectedPackage }}
                        onChange={handlePackageChange}
                        isDisabled={selectedProduct.length > 0 || !selectedCustomer || !selectedService}
                        isClearable
                        styles={DropdownStyles}
                      />
                    </div>

                    {errors.productOrPackage && (
                      <p style={{ color: 'red' }}>
                        Either Billing Platform Product or Billing Platform Package is Required
                      </p>
                    )}
                  </>
                )
            }
          </>
        )}

      </Modal>
      <Modal
        title="Submit Data"
        visible={showConfirmation}
        onCancel={cancelConfirmation}
        centered
        footer={
          <div className="justify-center flex space-x-2">
            <button key="cancel" className='cancel-btn' onClick={cancelConfirmation}>
              Cancel
            </button>
            <button key="confirm" className='save-btn' onClick={confirmSubmit}>
              OK
            </button>
          </div>
        }
      >
        <p>Are you sure you want to Submit this data</p>
      </Modal>
    </>
  );
};

export default AssignService;
