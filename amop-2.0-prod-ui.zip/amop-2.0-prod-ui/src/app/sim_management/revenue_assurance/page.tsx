"use client";
import React, {
  useEffect,
  useState,
  lazy,
  Suspense,
  useRef,
  useCallback,
} from "react";
import { ArrowDownTrayIcon } from "@heroicons/react/24/outline";
import { Button, Modal, Spin, DatePicker, notification, Switch, message, Upload } from "antd";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import dayjs, { Dayjs } from "dayjs";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { DownloadOutlined, MinusCircleOutlined, MinusOutlined, PlusOutlined, UploadOutlined } from "@ant-design/icons";
import AssignService from "./assign_service/assign_revio_modal";
import { useRevStore } from "@/app/stores/revStore";
import DisconnectServiceProductPage from "./disconnect-service-product/page";
import AddServiceLine from "./add_service_line/page";
import AddServiceProduct from "./add_service_product/add_service_product";
import moment from "moment";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useCustomerRatePlanStore } from "@/app/stores/customerRateplanStore";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";

type ExportData = {
  path: string;
  username: string | null;
  module_name: string;
  request_received_at: string;
  start_date: string;
  end_date: string;
  Partner: string | null;
  access_token: string | null;
  db_name: string | null;
};

const { RangePicker } = DatePicker;
const RevTableComponent = lazy(
  () => import("@/app/components/revTableComponent/page")
);
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));
const TableSearch = lazy(() => import("@/app/components/entire_table_search"));
const AdvancedMultiFilter = lazy(
  () => import("@/app/components/advanced_search")
);

const RevAssurance: React.FC = () => {
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, token, tenantId, tenantName, selectedDb,metaData, advancedStoredpagination, storedpagination, firstLastName, sessionId, combineAdnvaceStoredpagination, setCombineAdnvaceStoredpagination, setAdvancedStoredPagination, setStoredPagination, settabledata, dynamicColumns, setDynamicColumns } = useAuth();
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([
    null,
    null,
  ]);
  const [selectedDate, setSelectedDate] = useState<string | null>(moment().format('YYYY-MM-DD')); // Default to current date

  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  // const {showAdvanced, setShowAdvanced} = useCustomerRatePlanStore();
  const { revRows, setRevRows, setRevHeaders, setRevHeaderMap, setShowVarianceStatus } = useRevStore();
  const [duplicateWarning, setDuplicateWarning] = useState(false);
  const [isDuplicates, setIsDuplicates] = useState(false); // Tracks whether duplicates are present
  const [isActiveStatuses, setIsActiveStatuses] = useState(false); // Tracks whether active statuses are present
  const [isNotAllActiveStatuses, setIsNotAllActiveStatuses] = useState(false); // Tracks whether all selected rows has active statuses

  //upload states
  const [isUploadModalVisible, setIsUploadModalVisible] = useState(false);
  const [appendChecked, setAppendChecked] = useState(false);
  const [overwriteChecked, setOverwriteChecked] = useState(false);
  const [isFileSelected, setIsFileSelected] = useState(false);
  const [uploadKey, setUploadKey] = useState(Date.now());
  const [uploadModuleName, setUploadModuleName] = useState<string | null>(null);
  const [uploadButtonName, setUploadButtonName] = useState<string | null>(null);

  const { customerShowActive, setCustomerShowActive } = useCustomerRatePlanStore();

  const [isAssignServiceModalOpen, setIsAssignServiceModalOpen] = useState(false);
  const [showVariance, setShowVariance] = useState(true);
  const [isServiceModalOpen, setisServiceModalOpen] = useState(false);
  const [isDisconnectServiceProductModalOpen, setDisconnectServiceProductModalOpen] = useState(false);
  const [isAddServiceLineModalOpen, setIsAddServiceLineModalOpen] = useState(false);
  const [performanceMatrix, setPerformanceMatrix] = useState<any>({});
  const [isLogModalOpen, setIsLogModalOpen] = useState(false); // State to manage log modal visibility
  const [logs, setLogs] = useState<{ step: string; time: string }[]>([]); // State for logs
  const [loading, setLoading] = useState(true);
  const [notHasCustomer, setNotHasCustomer] = useState(false);

  const [latestNavClick, setLatestNavClick] = useState<{
    label: string;
    clickTime: string;
  } | null>(null);
  //export functionality
  // const [exportLoading, setExportLoading] = useState(false);
  const { addExport, removeExport, exports, removeRevAction } = exportLoadingStore();
  const exportKey = "RevenueAssurence"
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  // Add state for the new modal
  const [isMobileActionsModalVisible, setIsMobileActionsModalVisible] = useState(false);
  // Add state to track screen width
  const [isSmallScreen, setIsSmallScreen] = useState(false);

  // Check for small screen on component mount and window resize
  useEffect(() => {
    const checkScreenSize = () => {
      setIsSmallScreen(window.innerWidth < 700);
    };

    // Initial check
    checkScreenSize();

    // Add event listener for window resize
    window.addEventListener('resize', checkScreenSize);

    // Clean up
    return () => window.removeEventListener('resize', checkScreenSize);
  }, []);


  const showMobileActionsModal = () => {
    setIsMobileActionsModalVisible(true);
  };

  const closeMobileActionsModal = () => {
    setIsMobileActionsModalVisible(false);
  };


  useEffect(() => {
    // Retrieve the latest navigation click time from localStorage
    const storedNavClick = localStorage.getItem("latestNavClick");
    if (storedNavClick) {
      setLatestNavClick(JSON.parse(storedNavClick));
    }
  }, []);

  const checkHasCustomer = () => {
    const isValid = revRows.every(row =>
      row?.customer_name && row.customer_name !== "None"
    );

    console.log("isValid", isValid);
    return isValid;
  };

  const checkForDuplicates = () => {
    // const customerNames = revRows.map(row => row.customer_name);
    const carrierNames = revRows.map(row => row.service_provider);

    // Check if all names in customerNames are the same
    // const allNamesSame = customerNames.every(name => name === customerNames[0]);
    const allCarrierNamesSame = carrierNames.every(name => name === carrierNames[0]);
    // If names are not the same, show the warning and set isDuplicates to true
    if (!allCarrierNamesSame) {
      setDuplicateWarning(true); // Show warning if names are different
      setIsDuplicates(true); // Treat different names as 'duplicates' for disabling the button
    } else {
      setIsDuplicates(false); // If all names are the same, no issues
    }
  };

  const checkForActiveStatusForServiceLine = () => {
    const total_statuses = revRows.map(row => row.rev_io_status);
    // Check if selected statuses has active
    const hasActives = total_statuses.find(status => status && status.toLowerCase() === "active");
    if (hasActives) {
      setIsActiveStatuses(true); // Show warning if active status present
    } else {
      setIsActiveStatuses(false);
      setIsAddServiceLineModalOpen(true);
    }
  };

  const checkForActiveStatusForServiceProduct = (action: any) => {
    const total_statuses = revRows.map(row => row.rev_io_status);
    // Check if all selected statuses are active
    const isAllActive = total_statuses.every(status => status && status.toLowerCase() === "active");
    console.log("isAllActive", isAllActive)
    if (isAllActive) {
      setIsNotAllActiveStatuses(false); // Proceed if all are active statuses
      if (action === "add") {
        setisServiceModalOpen(true);
      }
      else {
        setDisconnectServiceProductModalOpen(true);
      }
    } else {
      setIsNotAllActiveStatuses(true);
    }
  };

  // Check for duplicates when revRows changes
  useEffect(() => {
    checkForDuplicates();
  }, [revRows]);
  const handleClose = () => {
    setDuplicateWarning(false);
    setIsDuplicates(true)
    setNotHasCustomer(false)
  };

  const handleActiveClose = () => {
    setIsActiveStatuses(false);
  };

  const handleCustomerClose = () => {
    setNotHasCustomer(false)
  };

  const handleNotAllActiveClose = () => {
    setIsNotAllActiveStatuses(false);
  };

  // Function to add a log
  const addLog = (step: string) => {
    const now = dayjs().format("HH:mm:ss.SSS"); // 24-hour format with milliseconds
    setLogs((prevLogs) => [...prevLogs, { step, time: now }]);
  };

  type HeaderMap = Record<string, [string, number]>;


  //function to display the headers in order
  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);

  // Function to handle opening the modal
  const openAssignServiceModal = () => {
    if (revRows.length === 0) {
      setUploadButtonName("assign_service")
      setUploadModuleName("Assign Service")
      handleUploadClick()
    }
    else {
      if (checkHasCustomer()) {
        console.log("true")

        setNotHasCustomer(false);
        setIsAssignServiceModalOpen(true);
      }
      else {
        console.log("false")
        setNotHasCustomer(true);
      }
    }

  };
  const openServiceProductModal = () => {
    if (revRows.length === 0) {
      setUploadButtonName("add_service_product")
      setUploadModuleName("Add Service Product")
      handleUploadClick()
    }
    else {
      checkForActiveStatusForServiceProduct("add")
    }
  }
  const openDisconnectServiceProductModal = () => {
    if (revRows.length === 0) {
      setUploadButtonName("disconnect_service_product")
      setUploadModuleName("Disconnect Service Product")
      handleUploadClick()
    }
    else {
      if (checkHasCustomer()) {
        console.log("true")
        setNotHasCustomer(false);
        checkForActiveStatusForServiceProduct("disconnect")
      }
      else {
        console.log("false")
        setNotHasCustomer(true);
      }
    }
  };
  const closeAddServiceLineModal = () => {
    setIsAddServiceLineModalOpen(false);
  }


  // Function to handle closing the modal
  const closeAssignServiceModal = () => {
    setIsAssignServiceModalOpen(false);
  };
  const closeServiceProduct = () => {
    setisServiceModalOpen(false);
  }
  const closeDisconnectServiceProductModal = () => {
    setDisconnectServiceProductModalOpen(false);
  };

  const openAddServiceLineModal = () => {
    if (revRows.length === 0) {
      setUploadButtonName("add_service_line")
      setUploadModuleName("Add Service Line")
      handleUploadClick()
    }
    else {
      checkForActiveStatusForServiceLine()
    }
  }

  useEffect(() => {
    setDynamicColumns((prev: any) => ({ ...prev, "rev assurance": visibleColumns }))
  }, [visibleColumns]);
  //To initially load the data
  const fetchData = async () => {
    setAdvancedStoredPagination(null)
    setStoredPagination(null)
    setCombineAdnvaceStoredpagination(null);
    setShowAdvanced(false)
    setSearchTerm("")
    settabledata([])
    // setShowVarianceStatus(true)
    try {
      setLoading(true);
      addLog("UI API call");
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_rev_assurance_data",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Rev assurance",
        feature_module_name: "Revenue Assurance",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        variance: showVariance
      };
      console.log(getCurrentDateTime(), "Show the log time request sent from ui to lambda");
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      // setPerformanceMatrix(JSON.parse(response.data.performance_matrix));
      addLog("Lambda response to UI");
      console.log(getCurrentDateTime(), "Show the log time response sent from lambda to ui");
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching rev assurance data. Please try again.',
          centered: true,
        });
      } else {
        removeRevAction("addServiceProduct")
        removeRevAction("assignService")
        removeRevAction("disconnectService")
        const headersMap_ = parsedData?.header_map?.["rev assurance"]?.header_map || {}
        const sortedheaderMap = sortHeaderMap(headersMap_)
        setHeaderMap(sortedheaderMap)
        setRevHeaderMap(sortedheaderMap)
        const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : []
        setHeaders(headers_)
        setRevHeaders(headers_)
        const dynamic_cols=dynamicColumns?.["rev assurance"]&& dynamicColumns["rev assurance"].length>0 ?dynamicColumns["rev assurance"] :headers_ || headers_
        setVisibleColumns(dynamic_cols)
        const tableData_ = parsedData?.rev_assurance_data || []
        setTableData(tableData_)
        setRevRows([])
        const features_ = parsedData?.header_map?.["rev assurance"]?.module_features || []
        setFeatures(features_)
        const pagination_ = parsedData?.pages || {}
        setPagination(pagination_)
      }
      // addLog('BulkChange Table Data Processing Data Completed');
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [partner, showVariance]);

  const closeLogModal = () => {
    setIsLogModalOpen(false);
  };

  //To handle the Variance feature
  const handleSwitchChange = (checked: any) => {
    setShowVariance(checked)
    setShowVarianceStatus(checked)
    setCustomerShowActive(checked);
  };

  //To handle the export feature
  const exportMutation = useMutation<any, Error, ExportData>({
    mutationFn: async (exportData) => {
      addLog("Rev assurance Export API Call Started");
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const response = await axios.post(
        url,
        { data: exportData },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      addLog("Rev assurance Export API Call Completed");
      return JSON.parse(response.data.body);
    },
    onSuccess: (data) => {
      if (data.flag === true) {
        notification.success({
          message: "Success",
          description: "Successfully exported the record!",
          style: messageStyle,
          placement: "top",
        });
        downloadBlob(data.blob);
      } else {
        Modal.error({
          title: "Export Error",
          content: data.message,
          centered: true,
        });
      }
      handleExportModalClose();
    },
    onError: (error) => {
      console.error("Error downloading the file:", error);
      Modal.error({
        title: "Export Error",
        content:
          "An error occurred while exporting the file. Please try again.",
      });
    },
  });

  const handleFilter = useCallback((advancedFilters: any) => {
    setAdvancedFilters(advancedFilters)
  }, []);

  const handleReset = useCallback((EmptyFilters: any) => {
    setFilteredData(EmptyFilters);
  }, []);

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "bold",
    padding: "16px",
  };


  //To handle the opening and closing of the export modals
  const handleExportModalOpen = () => {
    setExportModalOpen(true);
  };

  const handleExportModalClose = () => {
    setExportModalOpen(false);
  };


  //Main function of export (calling route)
  // const handleExport = () => {
  //   if (!dateRange || dateRange[0] === null || dateRange[1] === null) {
  //     Modal.error({ title: "Error", content: "Please select a date range." });
  //     return;
  //   }

  //   const [startDate, endDate] = dateRange;

  //   const exportData: ExportData = {
  //     path: "/export",
  //     username: username,
  //     module_name: showVariance ? "rev assurance variance" : "rev assurance",
  //     request_received_at: getCurrentDateTime(),
  //     start_date: startDate.format("YYYY-MM-DD 00:00:00"),
  //     end_date: endDate.format("YYYY-MM-DD 23:59:59"),
  //     Partner: partner,
  //     access_token: token,
  //     db_name: selectedDb,
        // ... metaData,
  //   };

  //   exportMutation.mutate(exportData);
  // };

  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }

  const ExportWithoutSearch = async () => {
    // setExportLoading(true)
    // const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
    //   return new Promise((resolve, reject) => {
    //     const timer = setTimeout(() => {
    //       reject(new Error("Request timed out"));
    //     }, timeout);

    //     promise
    //       .then((res) => {
    //         clearTimeout(timer);
    //         resolve(res);
    //       })
    //       .catch((err) => {
    //         clearTimeout(timer);
    //         reject(err);
    //       });
    //   });
    // };
    try {
      // setExportLoading(true)
      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Request timed out"));
          }, timeout);

          promise
            .then((res) => {
              clearTimeout(timer);
              resolve(res);
            })
            .catch((err) => {
              clearTimeout(timer);
              reject(err);
            });
        });
      };
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/export_to_s3_bucket",
        role_name: role,
        parent_module: "Sim Management",
        module_name: showVariance ? "Rev assurance variance" : "Rev assurance",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        start_date: getFirstDayOfCurrentMonth(),
        end_date: getLastDayOfCurrentMonth(),
      };
      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000); // Timeout of 10 seconds
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }

      // Wait for 20 seconds before polling
      await new Promise((resolve) => setTimeout(resolve, 20000));
      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      // setExportLoading(false);
      // removeExport(exportKey); // Remove the export from the store
    }
  }
  const pollExportStatus = async () => {
    // Polling for the second API
    const export_url = ENV_ROUTES.MODULE_MANAGEMENT;
    const export_data = {
      tenant_name: partner || "default_value",
      username,
      path: "/get_export_status",
      role_name: role,
      parent_module: "Sim Management",
      module_name: showVariance ? "Rev assurance variance" : "Rev assurance",
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
        ... metaData,
      sessionID: sessionId,
    };
    try {
      const export_response = await axios.post(export_url, { data: export_data });
      const export_parsedData = JSON.parse(export_response.data.body);

      if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
        const s3Url = export_parsedData?.export_status_data?.url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
            .then(response => response.blob())
            .then(blob => {
              const url = window.URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'Revenue Assurance.xlsx';
              a.click();
              a.remove();
              window.URL.revokeObjectURL(url);
              notification.success({
                message: "Success",
                description: "Successfully exported the record!",
                style: messageStyle,
                placement: "top",
              });
            })
            .catch((err) => {
              console.log("error", err)
              Modal.error({
                title: "Export Error",
                content: "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            });
        } else {
          Modal.error({
            title: "Export Error",
            content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
        return true; // Stop polling
      }

      if (export_parsedData?.export_status_data?.status_flag === "Failure") {
        Modal.error({
          title: "Export Error",
          content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
        return true; // Stop polling
      }
      if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
        Modal.info({
          title: "Export Error",
          content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
        return true; // Stop polling
      }

      return false; // Continue polling
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
      return true; // Stop polling
    }
  };


  const startPolling = async () => {
    let isPollingComplete = false;

    while (!isPollingComplete) {
      isPollingComplete = await pollExportStatus();
      if (!isPollingComplete) {
        await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
      }
    }
  };

  const handleExport = async (key: string, heading: string) => {
    console.log("test")
    try {
      // setExportLoading(true)
      addExport(key, heading);
      let parsedData
      let url
      let data: any
      let response
      if (combineAdnvaceStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: showVariance ? "rev_assurance" : "rev_assurance_variance",
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
        ... metaData,
          sessionID: sessionId,
          module_name: "Rev assurance",
        };
        console.log("combineAdnvaceStoredpagination", data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
      else if (advancedStoredpagination && !storedpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          module_name: "Rev assurance",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name: showVariance ? "rev_assurance" : "rev_assurance_variance",
          pages: {
            start: 0,
            end: 100
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
        ... metaData,
          tenant_id: tenantId,
          sessionID: sessionId,
          // }
        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

      }
      else if (storedpagination && !advancedStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          module_name: "Rev assurance",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: showVariance ? "rev_assurance" : "rev_assurance_variance",
          search: "whole",
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
        ... metaData,
          tenant_id: tenantId,
          sessionID: sessionId,
        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

      }
      else {
        await ExportWithoutSearch();
        return;
      }
      if (parsedData.flag) {
        console.log("flag")
        const s3Url = parsedData?.download_url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the  record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
            .then(response => response.blob())
            .then(blob => {
              const url = window.URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'Revenue Assurance.xlsx';
              a.click();
              a.remove();
              window.URL.revokeObjectURL(url);
              notification.success({
                message: "Success",
                description: "Successfully exported the record!",
                style: messageStyle,
                placement: "top",
              });
            })
            .catch((err) => {
              console.log("error", err)
              Modal.error({
                title: "Export Error",
                content: "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            });
        } else {
          // setExportLoading(false)
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }

      } else {
        console.log("!flag")
        Modal.error({
          title: "Export Error",
          content: parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
      }

    } catch (error) {
      console.log("catch")
      await startPolling()
      // Modal.error({
      //   title: "Export Error",
      //   content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
      //   centered: true,
      // });
    } finally {
      // setExportLoading(false)
      removeExport(key);
    }
  };

  //To conver the blob to xlsx
  const downloadBlob = (base64Blob: string) => {
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    const blobObject = new Blob([byteArray], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blobObject);
    link.download = `${uploadModuleName}.xlsx`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  useEffect(() => {
    addLog("Component rendered");
  }, []);

  // useEffect(() => {
  //   if (!loading) {
  //     addLog("Data Displayed in UI");
  //   }
  // }, [loading]);
  useEffect(() => {
    if (!loading) {
      console.log("Data Displayed in UI", getCurrentDateTime());
    }
  }, [loading]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  //Upload Functions

  const startUploadPolling = async (serviceIDs: any,bulkChangeId:any) => {
      // Call addServiceID once when polling starts  
      // Start polling for each service_id independently
      await Promise.all(
        serviceIDs.map(async (serviceId: any) => {
          let isPollingComplete = false;
    
          while (!isPollingComplete) {
            isPollingComplete = await pollServiceLineStatus(serviceId,bulkChangeId);
            if (!isPollingComplete) {
              await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
            }
          }
        })
      );
    
      // Call removeServiceID once when all polling is complete
      removeRevAction("addServiceLine");
      console.log("Polling completed for all service IDs.");
    };
    
    const pollServiceLineStatus = async (serviceId: any,bulkChangeId:any) => {
      try {
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username,
          path: "/add_service_line_process_data",
          role_name: role,
          parent_module: "SIM Management",
          module_name: "Rev Assurance",
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
        ... metaData,
          sessionID: sessionId,
          service_id: serviceId,
          bulk_change_id:bulkChangeId
        };
    
        const response = await axios.post(url, { data: data });
        const parsedData = JSON.parse(response.data.body);
    
        if (parsedData.flag) {
          const status = (parsedData?.response_data?.service_number_status || "").toLowerCase();
    
          if (status === "completed" || status === "processed") {
            notification.success({
              message: "Success",
              description: `${serviceId} - Successfully Processed!`,
              style: messageStyle,
              placement: "top",
            });
    
            return true; // Stop polling
          } else if (status === "processing" || status === "no status found") {
            return false; // Continue polling
          } else {
            Modal.error({
              title: "Update Error",
              content: `${serviceId} - ${status}!` || "An error occurred while updating data. Please try again.",
              centered: true,
            });
    
            return true; // Stop polling
          }
        }
    
        return false; // Continue polling
      } catch (error) {
        return true; // Stop polling
      }
    };
  
    const callProcessServiceNumbers = async (parsedData:any, service_numbers:any) =>{
      try {
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path:"/process_service_numbers",
          role_name: role,
          module_name: "Revenue Assurance",
          access_token: token,
          db_name: selectedDb,
        ... metaData,
          sessionID: sessionId,
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          bulkchange_id: parsedData?.bulk_chnage_id_20,
          service_ids:service_numbers
  
        };
  
        const response = await axios.post(url, { data });
        const responseData = JSON.parse(response.data.body);
  
        if (responseData.flag === false) {
          console.log("callProcessServiceNumbers failed")
        } else {
          console.log("callProcessServiceNumbers success")
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
      }
  
    }
    
    const callRunDBScript = async (parsedData:any) =>{
      const selectedProviderss = revRows.map((row) => row?.['service_provider'])
      const selected_provider = selectedProviderss[0] || ""
  
      let request_path;
      let request_url;
  
      if(selected_provider.toLowerCase()==="kore"){
        request_path="/create_rev_io_service"
        request_url=ENV_ROUTES.SM_BULK_CHANGE
      }
      else{
        request_path="/run_db_script"
        request_url=ENV_ROUTES.SIM_MANAGEMENT
      }
     
      try {
        const service_provider_id_=parsedData?.bulkchange_id?.service_provider_id || 1
        const url = request_url;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path:request_path,
          role_name: role,
          module_name: "Bulk Change",
          mod_pages: {
            start: 0,
            end: 100,
          },
          access_token: token,
          db_name: selectedDb,
        ... metaData,
          sessionID: sessionId,
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          service_provider_id:service_provider_id_,
          bulkchange_id: parsedData?.bulkchange_id?.id,
          data: parsedData?.data,
          bulk_chnage_id_20: parsedData?.bulk_chnage_id_20
  
        };
  
        const response = await axios.post(url, { data });
        const responseData = JSON.parse(response.data.body);
  
        if (responseData.flag === false) {
          console.log("failed")
        } else {
          console.log("success")
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
      }
  
    }

  const AddServiceLineUploadSyncs = async(parsedData:any) =>{
    const service_ids = parsedData?.service_ids || []
        const bulk_change_id=parsedData?.bulk_chnage_id_20 || 0
        callProcessServiceNumbers(parsedData,service_ids)
        await callRunDBScript(parsedData);
        await new Promise((resolve) => setTimeout(resolve, 20000));
        await startUploadPolling(service_ids,bulk_change_id);
  }

  const handleUploadClick = () => {
    setIsUploadModalVisible(true);

  }
  const handleDownloadTemplate = async () => {
    setLoading(true);
    const url =
      ENV_ROUTES.SIM_MANAGEMENT;
    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/rev_assurance_button_upload_download",
      button_name: uploadButtonName || "",
      module_name: "Revenue Assurance",
      role_name: role,
      Partner: partner,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
        ... metaData,
      sessionID: sessionId,
    };

    const response = await axios.post(url, { data });
    const resp = JSON.parse(response.data.body);
    const blob = resp.blob;
    console.log(resp);
    if (response.data.statusCode === 200) {
      if (resp.flag === true) {
        notification.success({
          message: 'Success',
          description: 'Successfully downloaded the template!',
          style: messageStyle,
          placement: 'top',
        });
        downloadBlob(blob);
        fetchData();
        setLoading(false);
        setIsUploadModalVisible(false);
      } else {
        console.log('Error message:', resp.message);
        Modal.error({
          title: 'Export Error',
          content: resp.message,
          centered: true,
        });
      }
    } else {
      console.log('Unexpected status code:', response.data.statusCode);
      Modal.error({
        title: 'Export Error',
        content: resp.message,
        centered: true,
      });
    }
  };
  const handleUploadModalClose = () => {
    setIsUploadModalVisible(false);
  };
  const handleUpload = async (blob: string) => {
    setLoading(true)
    try {
      const url = ENV_ROUTES.REV_ASSURANCE;
      let flag: string = appendChecked ? "append" : "overwrite";

      const pathMap :any = {
        add_service_line: "/handle_add_service_line_upload",
        add_service_product: "/handle_add_service_product_upload",
        disconnect_service_product: "/handle_deactivate_service_product",
        assign_service: "/handle_assign_service",
      };
      const path_ =uploadButtonName ? pathMap[uploadButtonName] : "/import_bulk_data";

      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: path_,
        insert_flag: "append",
        module_name: "Revenue Assurance",
        role_name: role,
        button_name: uploadButtonName || "",
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        blob: blob, // Include the Blob in the data
      };

      const response = await axios.post(url, { data });

      const resp = JSON.parse(response.data.body);
      if (response.data.statusCode === 200) {
        if (resp.flag === true) {
          if(uploadButtonName==="add_service_line"){
            AddServiceLineUploadSyncs(resp)
          }
          fetchData()
          notification.success({
            message: 'Success',
            description: 'Successfully uploaded the record!',
            placement: 'top',
          });
        } else {
          Modal.error({
            title: 'Import Error',
            content: resp.message,
            centered: true,
            onOk: handleErrorModalClose,
            onCancel: handleErrorModalClose
          });
        }
      } else {
        Modal.error({
          title: 'Import Error',
          content: resp.message,
          centered: true,
          onOk: handleErrorModalClose,
          onCancel: handleErrorModalClose
        });
      }
    } catch (error) {
      console.error('Error during file upload:', error);
      Modal.error({
        title: 'Import Error',
        content: 'There was an error uploading the file.',
        centered: true,
        onOk: handleErrorModalClose,
        onCancel: handleErrorModalClose
      });

    }
    finally {
      setLoading(false)
      setIsUploadModalVisible(false)
    }
  }
  const handleErrorModalClose = () => {
    setIsUploadModalVisible(false)
  }
  const handleChange = (info: any) => {
    if (info.file.status === 'done') {
      setIsFileSelected(true);
      let blob;
      const file = info.file.originFileObj; // Get the file object
      const reader = new FileReader();
      reader.onload = (e: any) => {
        // Get the file data URL (Base64 string)
        blob = e.target.result;
        console.log('File Base64 String:', blob);
        handleUpload(blob)
        setUploadKey(Date.now());
      };

      if (blob) {
      }

      reader.readAsDataURL(file); // Read the file as data URL
    } else if (info.file.status === 'error') {
      // Handle upload error
      message.error('Upload failed.');
    }
    else if (info.file.status === 'removed') {
      setIsFileSelected(false);
      setAppendChecked(false);
      setOverwriteChecked(false);
    }
  };
  const uploadProps = {
    key: uploadKey,
    accept: '.xlsx, .xls',
    beforeUpload: (file: any) => {
      // Check if file is an Excel file
      const isExcel = file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || file.type === 'application/vnd.ms-excel';
      if (!isExcel) {
        message.error('You can only upload Excel files!');
      }
      return isExcel;
    },
    onChange: handleChange,
  };

  //To disable the future dates in datepicker
  const disableFutureDates = (current: any) => {
    return current && current > dayjs().endOf("day");
  };

  return (
    <>
      <Suspense
        fallback={
          <div className="flex justify-center items-center h-screen">
            <Spin size="large" />
          </div>
        }
      >
        <div className="relative">
          <div className="pl-4 pr-4 flex flex-col md:flex-row md:items-center md:justify-between mt-2 space-y-6 md:space-y-0">
            {/* Search and Advanced Filter Container */}
            <div className="hidden md:flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last">
              {features.includes("Add service line-Rev assurance") && (
                <button
                  // type="default"
                  // icon={<PlusOutlined />}
                  // className={`${revRows.length > 0 ? "active" : "deactive"}`}
                  // className={`${revRows.length > 0 && !isDuplicates ? "save-btn" : "deactive"} p-[4px] min-h-[40px] w-[200px] pr-[8px]`}
                  className={`${!isDuplicates ? "save-btn" : "deactive"} min-h-[20px] w-full md:w-[213px] px-4 flex items-center justify-center space-x-2`}
                  onClick={openAddServiceLineModal}
                  disabled={isDuplicates}
                >
                  <PlusOutlined style={{ marginRight: '8px' }} />
                  Add Service Line
                </button>
              )}
              {features.includes("Add service product-Rev assurance") && (
                <button
                  // type="default"
                  // icon={<PlusOutlined />}
                  onClick={openServiceProductModal}
                  // className={`${revRows.length > 0 && !isDuplicates ? "save-btn" : "deactive"} p-[4px] min-h-[40px] w-[213px] pr-[8px]`}
                  className={`${!isDuplicates ? "save-btn" : "deactive"} min-h-[40px] w-full md:w-[213px] px-4 flex items-center justify-center space-x-2`}
                  disabled={isDuplicates}
                >
                  <PlusOutlined style={{ marginRight: '8px' }} />
                  Add Service Product
                </button>
              )}
              {features.includes("Dissconnect service product-Rev assurance") && (
                <button
                  // type="default"
                  // icon={<PlusOutlined />}
                  // className={`${revRows.length > 0 && !isDuplicates ? "save-btn" : "deactive"} p-[4px] min-h-[40px] w-[215px] pr-[8px]`}
                  className={`${!isDuplicates ? "save-btn" : "deactive"} min-h-[40px] w-full md:w-[213px] px-4 flex items-center justify-center space-x-2`}
                  onClick={openDisconnectServiceProductModal}
                  disabled={isDuplicates}
                >
                  <MinusOutlined style={{ marginRight: '4px' }} />
                  Disconnect Service Product
                </button>
              )}
              {features.includes("Assign service-Rev assurance") && (
                <button
                  // type="default"
                  // icon={<PlusOutlined />}
                  // className="flex items-center border-[#00C1F1] text-[#00C1F1] border-3 rounded-3xl py-4 px-4 font-semibold hover:bg-[#00C1F1] font-normal"
                  // className={`${revRows.length > 0 && !isDuplicates ? "save-btn" : "deactive"} p-[4px] min-h-[40px] w-[213px] pr-[8px]`}
                  className={`${!isDuplicates ? "save-btn" : "deactive"} min-h-[40px] w-full md:w-[213px] px-4 flex items-center justify-center space-x-2`}
                  onClick={openAssignServiceModal} // Open modal on click
                  disabled={isDuplicates}
                >
                  <PlusOutlined style={{ marginRight: '8px' }} />
                  Assign Service
                </button>
              )}
            </div>
            <div className="flex items-center space-x-2 justify-end">
              <Switch onChange={handleSwitchChange} checked={showVariance} className="custom-switch" />
              <span className="font-bold text-lg">Show Variance Only</span>
            </div>
          </div>
          <div className="pr-4 pl-4 flex flex-col md:flex-row md:items-center md:justify-between mt-1 mb-4 space-y-4">
            {/* Search and Advanced Filter Container */}
            <div className="flex space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last ">
              {features.includes("Search-Rev assurance") && (
                <TableSearch
                  searchTerm={searchTerm}
                  setSearchTerm={setSearchTerm}
                  tableName={showVariance ? "rev_assurance" : "rev_assurance_variance"}
                  headerMap={headerMap}
                // loader={loading}
                />
              )}
              {features.includes("Advanced filter-Rev assurance") && (
                <AdvancedMultiFilter
                  showAdvanced={showAdvanced}
                  setShowAdvanced={setShowAdvanced}
                  onFilter={handleFilter}
                  onReset={handleReset}
                  headers={headers}
                  headerMap={headerMap}
                  tableName={showVariance ? "rev_assurance" : "rev_assurance_variance"}
                />
              )}
            </div>

            {/* Export and ColumnFilter Container */}
            <div className="hidden md:flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2  md:order-none order-first pb-2 md:pb-4">
              {features.includes("Export-Rev assurance") && (
                <button className="save-btn"
                  onClick={() => {
                    if (!exports.some((exportItem) => exportItem.popupHeading === "Revenue Assurance")) {
                      handleExport("RevenueAssurance", "Revenue Assurance");
                    }
                  }} >
                  <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                  <span>Export</span>
                </button>
              )}
              <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
              />
            </div>
          </div>

          <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
            <RevTableComponent
              headers={headers}
              headerMap={headerMap}
              initialData={tableData}
              searchQuery={searchTerm}
              visibleColumns={visibleColumns}
              itemsPerPage={100}
              // selectedDate={selectedDate} 
              // handleDateChange={handleDateChange} 
              moduleName="Rev assurance"
              pagination={pagination}
              advancedFilters={filteredData}
              onDateChange={() => { }}
              height={showAdvanced ? 340 : 270}
            />
          </div>

          {/* Sticky Footer for Small Screens */}
          <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-40">
            {features.includes("Export-Rev assurance") && (
              <button className="save-btn"
                onClick={() => {
                  if (!exports.some((exportItem) => exportItem.popupHeading === "Revenue Assurance")) {
                    handleExport("RevenueAssurance", "Revenue Assurance");
                  }
                }}
              >
                <ArrowDownTrayIcon className="h-5 w-5 text-black-500" />
              </button>
            )}
            <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
            />

            {/* Add the plus icon button in the mobile footer */}
            <button
              onClick={showMobileActionsModal}
              // className="bg-blue-500 hover:bg-blue-600 text-white rounded-full w-10 h-10 flex items-center justify-center"
              className="save-btn"
            >
              <PlusOutlined className="h-5 w-5 text-black-500" />
            </button>
          </div>

          {/* Floating action button - only visible on mobile (alternative approach) */}
          {/* <div className="md:hidden fixed bottom-16 right-4 z-50">
            <button 
              onClick={showMobileActionsModal}
              className="bg-blue-500 hover:bg-blue-600 text-white rounded-full w-14 h-14 flex items-center justify-center shadow-lg"
            >
              <PlusOutlined style={{ fontSize: '24px' }} />
            </button>
          </div> */}

          {/* Mobile Actions Modal */}
          <Modal
            title="Actions"
            visible={isMobileActionsModalVisible}
            onCancel={closeMobileActionsModal}
            footer={null}
            centered
          >
            <div className="flex flex-col space-y-3">
              {features.includes("Add service line-Rev assurance") && (
                <button
                  className={`${!isDuplicates ? "save-btn" : "deactive"} min-h-[40px] w-full px-4 flex items-center justify-center space-x-2`}
                  onClick={() => {
                    closeMobileActionsModal();
                    openAddServiceLineModal();
                  }}
                  disabled={isDuplicates}
                >
                  <PlusOutlined style={{ marginRight: '8px' }} />
                  Add Service Line
                </button>
              )}

              {features.includes("Add service product-Rev assurance") && (
                <button
                  className={`${!isDuplicates ? "save-btn" : "deactive"} min-h-[40px] w-full px-4 flex items-center justify-center space-x-2`}
                  onClick={() => {
                    closeMobileActionsModal();
                    openServiceProductModal();
                  }}
                  disabled={isDuplicates}
                >
                  <PlusOutlined style={{ marginRight: '8px' }} />
                  Add Service Product
                </button>
              )}

              {features.includes("Dissconnect service product-Rev assurance") && (
                <button
                  className={`${!isDuplicates ? "save-btn" : "deactive"} min-h-[40px] w-full px-4 flex items-center justify-center space-x-2`}
                  onClick={() => {
                    closeMobileActionsModal();
                    openDisconnectServiceProductModal();
                  }}
                  disabled={isDuplicates}
                >
                  <MinusOutlined style={{ marginRight: '4px' }} />
                  Disconnect Service Product
                </button>
              )}

              {features.includes("Assign service-Rev assurance") && (
                <button
                  className={`${!isDuplicates ? "save-btn" : "deactive"} min-h-[40px] w-full px-4 flex items-center justify-center space-x-2`}
                  onClick={() => {
                    closeMobileActionsModal();
                    openAssignServiceModal();
                  }}
                  disabled={isDuplicates}
                >
                  <PlusOutlined style={{ marginRight: '8px' }} />
                  Assign Service
                </button>
              )}
            </div>
          </Modal>

          <Modal
            title={
              <span className="font-semibold text-xl space-y-3">
                Export Output
              </span>
            }
            visible={isExportModalOpen}
            onCancel={() => {
              handleExportModalClose();
              setDateRange([null, null]);
            }}
            footer={null}
            centered
            afterClose={() => setDateRange([null, null])}
            style={{ top: "-4%" }}
          >
            <div className="flex flex-col space-y-4">
              <span>Select Date Range</span>
              <RangePicker
                value={
                  dateRange[0] && dateRange[1]
                    ? [dateRange[0], dateRange[1]]
                    : null
                }
                onChange={(dates) => {
                  if (dates && dates.length === 2) {
                    setDateRange([dates[0], dates[1]] as [Dayjs, Dayjs]);
                  } else {
                    setDateRange([null, null]);
                  }
                }}
                format="YYYY-MM-DD"
                popupClassName="custom-range-popup"
                disabledDate={disableFutureDates}
              />
              <div
                style={{ marginTop: "2rem" }}
                className="flex  justify-center gap-2 space-x-2"
              >
                <button
                  className="cancel-btn text-[16px] font-medium "
                  onClick={handleExportModalClose}
                  style={{ fontFamily: "Calibri" }}
                >
                  <span>Cancel</span>
                </button>
                {/* <button
                  className="save-btn text-[16px] font-medium"
                  onClick={handleExport}
                  style={{ fontFamily: "Calibri" }}
                >
                  Export
                </button> */}
              </div>
            </div>
          </Modal>

          {/* Rest of your modals */}
          <AssignService
            visible={isAssignServiceModalOpen}
            onCancel={closeAssignServiceModal}
            onSave={fetchData}
          />
          <AddServiceProduct
            visible={isServiceModalOpen}
            onCancel={closeServiceProduct}
            onOk={(data) => {
              closeServiceProduct();
            }}
            onSave={fetchData}
          />
          <DisconnectServiceProductPage
            visible={isDisconnectServiceProductModalOpen}
            onClose={closeDisconnectServiceProductModal}
            onSave={fetchData}
          />
          <AddServiceLine
            visible={isAddServiceLineModalOpen}
            onCancel={closeAddServiceLineModal}
            onSave={fetchData}
          />

          {/* Upload Modal*/}
          <Modal
            title="Upload Files"
            visible={isUploadModalVisible}
            onCancel={handleUploadModalClose}
            footer={null}
            centered
            width={400}
          >
            <div className="flex flex-col gap-4">
              <div className="flex flex-col md:flex-row gap-4 justify-center m-auto p-4">
                <Upload {...uploadProps} className="w-full md:w-auto">
                  <button className="w-[200px] md:w-full upload-btn disabled:cursor-not-allowed">
                    <span className="mr-2"><UploadOutlined /></span>
                    Upload
                  </button>
                </Upload>
                <button
                  onClick={handleDownloadTemplate}
                  className=" w-[200px] md:w-full upload-btn disabled:cursor-not-allowed"
                >
                  <span className="mr-2"><DownloadOutlined /></span>
                  Download Template
                </button>
              </div>
            </div>
          </Modal>

          {/* Warning Modals */}
          {duplicateWarning && (
            <Modal
              title="Warning"
              visible={duplicateWarning}
              onOk={handleClose}
              onCancel={handleClose}
              centered
            >
              <p>Multiple Carrier Names are not Allowed.</p>
            </Modal>
          )}

          {isActiveStatuses && (
            <Modal
              title="Warning"
              visible={isActiveStatuses}
              onOk={handleActiveClose}
              onCancel={handleActiveClose}
              centered
            >
              <p>{`Selected Service ${revRows.length > 1 ? "IDs are" : "ID is"} already active in Billing Platform`}</p>
            </Modal>
          )}

          {isNotAllActiveStatuses && (
            <Modal
              title="Warning"
              visible={isNotAllActiveStatuses}
              onOk={handleNotAllActiveClose}
              onCancel={handleNotAllActiveClose}
              centered
            >
              <p>{`The selected Service ${revRows.length > 1 ? "IDs are" : "ID is"} not active in billing platform.`}</p>
            </Modal>
          )}

          {notHasCustomer && (
            <Modal
              title="Warning"
              visible={notHasCustomer}
              onOk={handleCustomerClose}
              onCancel={handleCustomerClose}
              centered
            >
              <p>{`The selected Service ${revRows.length > 1 ? "IDs doesn't has" : "ID doesn't have"} assigned customers`}</p>
            </Modal>
          )}
        </div>
      </Suspense>
    </>
  );
};

export default RevAssurance;
