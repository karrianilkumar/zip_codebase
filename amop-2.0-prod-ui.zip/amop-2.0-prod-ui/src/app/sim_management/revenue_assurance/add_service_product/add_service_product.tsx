"use client";
import React, { useState, useEffect } from "react";
import {
  Modal,
  Input,
  Button,
  Checkbox,
  Form,
  message,
  Row,
  Col,
  DatePicker,
  Spin,
  notification,
} from "antd";
import Select from "react-select";
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { useRevStore } from "@/app/stores/revStore";
import { format } from "date-fns";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import moment from 'moment';
import { DropdownStyles } from "@/app/components/css/dropdown";
import { Console } from "console";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";

interface OptionType {
  value: string;
  label: string;
}

interface MyModalProps {
  visible: boolean;
  onCancel: () => void;
  onOk: (data: any) => void;
  onSave: () => void;
}

const messageStyle = {
  fontSize: "14px",
  fontWeight: "bold",
  padding: "16px",
};

const AddServiceProduct: React.FC<MyModalProps> = ({
  visible,
  onCancel,
  onOk,
  onSave
}) => {
  const [form] = Form.useForm();
  const [loading, setLoading] = useState(false);
  const [submitDisabled, setSubmitDisabled] = useState(true); // State to control Submit button
  const { username, role, partner, token, selectedDb, metaData,firstLastName, sessionId } = useAuth();
  const { revRows } = useRevStore();
  // console.log(revRows,"Show revRows")

  const [serviceOptions, setServiceOptions] = useState<OptionType[]>([]);
  const [productOptions, setProductOptions] = useState<OptionType[]>([]);
  const [productIdMap, setProductIdMap] = useState<Record<string, string>>({});
  const [selectedService, setSelectedService] = useState<OptionType | null>(null);
  const [selectedProduct, setSelectedProduct] = useState<OptionType | null>(null);
  const [quantity, setQuantity] = useState<string>("1"); // Start with 1 as minimum
  const [prorate, setProrate] = useState<boolean>(false);
  const [effectiveDate, setEffectiveDate] = useState<Date | null>(null);
  const [description, setDescription] = useState<string>("");

  //Rate state variables
  const [rateProductMap, setRateProductMap] = useState<any>({});
  const [selectedRate, setSelectedRate] = useState<any>("");
  console.log(revRows, "Show revRows")
  // New state to store rev_service_ids
  const [revServiceIds, setRevServiceIds] = useState<any>({});
  // State for confirmation modal
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);

  const { addRevAction } = exportLoadingStore();

  // Function to extract and deduplicate service numbers
  const getUniqueServiceNumbers = (rows: any[]) => {
    const serviceNumbers = rows.map(row => row.service_number);
    return Array.from(new Set(serviceNumbers)); // Remove duplicates
  };

  useEffect(() => {
    if (visible && revRows.length > 0) {
      const customerName = revRows[0].customer_name;
      const customerOptions_ = Array.from(new Set(revRows.map((row) => row?.['customer_name']))).filter(Boolean);
      fetchDropdownData(customerOptions_);
    } else if (!visible) {
      // Reset form fields when modal is closed
      form.resetFields();
      setSelectedService(null);
      setSelectedProduct(null);
      setSelectedRate("")
      form.setFieldValue("rate", "");
      setQuantity("1");
      setProrate(false);
      setEffectiveDate(null);
      setDescription("");
      setSubmitDisabled(true); // Disable Submit button when modal is closed
      setRevServiceIds([]); // Reset rev_service_ids when modal is closed
    }
  }, [visible, revRows, form]);

  const isValidCustomerName = (name: string): boolean => {
    // Define the expected format for `customer_name`
    const expectedFormatRegex = /^\d+ - Service id: \d+ - Service Type: \w+$/;
    return expectedFormatRegex.test(name);
  };

  const fetchDropdownData = async (customerName: any) => {
    try {
      setLoading(true);
      // Get unique service numbers
      const uniqueServiceNumbers = getUniqueServiceNumbers(revRows);
      console.log("Unique Service Numbers:", uniqueServiceNumbers);
      const url =
        ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/add_service_product_dropdown_data",
        customer_name: customerName,
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        service_id: uniqueServiceNumbers, // Add unique service numbers to the payload
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response?.data?.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching data. Please try again.",
          centered: true,
        });
        setSubmitDisabled(true); // Disable Submit button on fetch error
        return
      }
      const customerNumbers = parsedData?.response_data?.customer_name.map((customer: { number: any; }) => customer.number);
      console.log("customer names", customerNumbers)
      const allMatch = uniqueServiceNumbers.every((number) => customerNumbers?.includes(number));
      console.log(allMatch, "Show all match")
      const anyMatch = uniqueServiceNumbers.some((number) => customerNumbers?.includes(number));
      console.log(anyMatch, "any match")

      if (customerName === null) {
        Modal.warning({
          title: "Warning",
          content: `Customer name is not available`,
          centered: true,
          onOk: () => {
            onCancel();
          },
        });
      }

      if (anyMatch && !allMatch) {
        const unmatchedServiceNumbers = uniqueServiceNumbers.filter(number => !customerNumbers.includes(number));

        Modal.warning({
          title: "Partial Match Found",
          content: `Some Selected Service id for customer doesn't have Rev Account, but not all: ${unmatchedServiceNumbers.join(', ')}`,
          centered: true,
        });
        console.error("Error: Selected service provider does not have an account.");

      }
      else if (allMatch) {
        console.log("All selected service ids have Rev accounts.");
      } else if (!customerName) {
        // Skip showing the error modal if customer_name is null or undefined
        console.log("Customer name is null or undefined. Skipping 'Submit Error' modal.");
      }
      else {
        const unmatchedServiceNumbers = uniqueServiceNumbers.filter(number => !customerNumbers.includes(number));
        Modal.warning({
          title: "Warning",
          content: `The following Service ids are not active: ${unmatchedServiceNumbers.join(', ')}`,
          centered: true,
          onOk: () => {
            onCancel();
          },
        });
        console.error("No service provider has an account. Closing modal.");
      }


      if (parsedData.flag === false && customerName) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching data. Please try again.",
          centered: true,
        });
        setSubmitDisabled(true); // Disable Submit button on fetch error
      } else if (!customerName) {
        console.log("Customer name is null or undefined. Skipping 'Data Fetch Error' modal.");
      }
      else {
        // const customerName = parsedData.response_data.customer_name;

        // if (!isValidCustomerName(customerName)) {
        //   // Handle invalid customer_name format
        //   setSubmitDisabled(true);
        //   setServiceOptions([{ value: customerName, label: customerName }]);
        // }
        const services = parsedData.response_data.customer_name; // Get the array of services
        const serviceOptions = services.map((service: any) => ({
          value: `${service.number} - Service id: ${service.rev_service_id} - Service Type: ${service.description}`,
          label: `${service.number} - Service id: ${service.rev_service_id} - Service Type: ${service.description}`,
        }));

        // Extract rev_service_ids and store them in state
        const revServiceIds_: Record<string, any[]> = {};

        services.forEach((row: any) => {
          const customerId = row.customer_name;

          if (!revServiceIds_[customerId]) {
            revServiceIds_[customerId] = [];
          }

          revServiceIds_[customerId].push(row.rev_service_id);
        });
        const revServiceIds = services.map((service: any) => service.rev_service_id);
        console.log("revServiceIds_", revServiceIds_)
        setRevServiceIds(revServiceIds_);

        // Handle valid customer_name format
        setServiceOptions(serviceOptions);

        // Map product options with IDs
        const productIdMap: Record<string, string> =
          parsedData.response_data.rev_product_id_map;


        const rateProductMap_ = parsedData?.response_data?.rev_product_rate || {}
        setRateProductMap(rateProductMap_)
        const productOptions_ = rateProductMap_.map((product: any) => ({ label: product?.description || "", value: product?.description || "" }))
        setProductOptions(productOptions_)

        // // Map rates by product ID
        // const productRateMap: Record<string, string[]> = {};
        // Object.entries(parsedData.response_data.rate).forEach(([id, rates]) => {
        //   productRateMap[id] = rates as string[];
        // });

        setServiceOptions(serviceOptions);
        // setProductOptions(productOptions);
        setProductIdMap(productIdMap);
        setSubmitDisabled(false); // Enable Submit button if format is valid
      }
    } catch (error) {
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
      setSubmitDisabled(true); // Disable Submit button on fetch error
    } finally {
      setLoading(false);
    }
  };

  //To handle necessary changes of rev.io product
  const handleProductChange = (selectedOption: OptionType | null) => {
    setSelectedProduct(selectedOption);

    if (selectedOption && selectedOption.value) {
      const value = selectedOption.label;

      // Ensure rateProductMap is an array
      const productsArray = Array.isArray(rateProductMap)
        ? rateProductMap
        : Object.values(rateProductMap || {});

      const match = productsArray.find(
        (product: any) => product.description === value
      );

      const newRate = (match?.rate || "0").toString();
      setSelectedRate(newRate); // Update the selectedRate state
      console.log("matchedRates", match, selectedOption);

      form.setFieldValue("rate", newRate); // Explicitly update the rate field in the form
    } else {
      setSelectedProduct(null);
      setSelectedRate("");
      form.setFieldValue("rate", ""); // Reset the rate field in the form
    }
  };

  const customerName = revRows[0]?.customer_name;
  const customerOptions_ = Array.from(new Set(revRows.map((row) => row?.['customer_name']))).filter(Boolean);
  console.log(customerName, "show the customer name")
  const iccids_ = Array.from(new Set(revRows.map((row) => row?.['iccid']))).filter(Boolean);
  const msisdn_ = Array.from(new Set(revRows.map((row) => row?.['service_number']))).filter(Boolean);

  //To submit the requested payload
  const handleSubmit = async () => {
    try {
      addRevAction("addServiceProduct", "Add Service Product")
      const values = await form.validateFields();
      setLoading(true);
      // Get unique service numbers
      const uniqueServiceNumbers = getUniqueServiceNumbers(revRows);
      console.log("Unique Service Numbers:", uniqueServiceNumbers);
      const customer_iccid_dict_: Record<string, any[]> = {};

      revRows.forEach((row: any) => {
        const customerName_ = row.customer_name;

        if (!customer_iccid_dict_[customerName_]) {
          customer_iccid_dict_[customerName_] = [];
        }

        customer_iccid_dict_[customerName_].push(row.iccid);
      });

      console.log("customer_iccid_dict_", customer_iccid_dict_)

      const customer_msisdn_dict_: Record<string, any[]> = {};

      revRows.forEach((row: any) => {
        const customerName_ = row.customer_name;

        if (!customer_msisdn_dict_[customerName_]) {
          customer_msisdn_dict_[customerName_] = [];
        }

        customer_msisdn_dict_[customerName_].push(row.service_number);
      });

      console.log("customer_msisdn_dict_", customer_msisdn_dict_)
      const submitData = {
        revio_service: revServiceIds,
        customer_name: customerOptions_,
        product_name: selectedProduct?.label === 'No options' ? null : selectedProduct?.label,
        rate: parseFloat(selectedRate) || 0, // Parse selectedRate to an integer
        quantity: quantity || null,
        prorate: prorate ?? false,
        effective_date: effectiveDate ? effectiveDate.toISOString() : '', // Convert Date to ISO string
        description: description || null,
        iccids: customer_iccid_dict_,
        msisdn: customer_msisdn_dict_,
      };

      const url =
        ENV_ROUTES.REV_ASSURANCE;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/submit_service_product_data",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        submit_data: submitData,
        service_provider: revRows[0]?.service_provider,
        // service_id: uniqueServiceNumbers, // Add unique service numbers to the payload
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: "Submission Error",
          content:
            parsedData.message ||
            "An error occurred while submitting the data. Please try again.",
          centered: true,
        });
      } else {
        // message.success("Data submitted successfully!");
        notification.success({
          message: "Success",
          description: "Data submitted successfully!",
          style: messageStyle,
          placement: "top",
        });
        onOk(submitData);
        onCancel();
        onSave()
      }
    } catch (error) {
      if (error instanceof Error) {
        message.error("Validation failed: " + error.message);
      } else {
        Modal.error({
          title: "Submission Error",
          content:
            "An unexpected error occurred while submitting the data. Please try again.",
          centered: true,
        });
      }
    } finally {
      setLoading(false);
    }
  };
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    // Prevent default behavior for specific keys
    const invalidKeys = ['+', '-', 'e']; // List of invalid keys
    if (invalidKeys.includes(e.key)) {
      e.preventDefault(); // Prevent the default action for these keys
      console.log(`${e.key} key pressed - blocked`);
    }
  };

  const handleDateChange = (date: any) => {
    if (date) {
      const safeDate = date.hour(12).minute(0).second(0).millisecond(0);
      console.log(safeDate)
      setEffectiveDate(safeDate);
    } else {
      setEffectiveDate(null);
    }
    // Convert date from DatePicker to native Date object
    // setEffectiveDate(date ? date.toDate() : null);
  };

  //To display the custom label of fields
  const renderLabel = (label: string, required: boolean) => (
    <span className="field-label">
      {label}{" "}
      {required && (
        <span className="required-indicator" style={{ color: "red" }}>
          *
        </span>
      )}
    </span>
  );
  const disablePastDates = (current: any) => {
    // Disable all dates before today
    return current && current < moment().startOf('day'); // Start of the current day to include today's date
  };

  const handleConfirmSubmit = () => {
    setIsConfirmationOpen(true);
  };

  const handleConfirmSave = () => {
    setIsConfirmationOpen(false);
    handleSubmit();
    onCancel();

  };

  const handleCancelConfirmation = () => {
    setIsConfirmationOpen(false);
  };

  return (
    <>
      {loading ?
        (
          <>
            <Modal
              title="Loading"
              visible={visible}
              onCancel={onCancel}
              footer={null}
              width={'550px'}
              centered
            >
              <div className="flex justify-center items-center h-[300px]">
                <Spin size="large" />
              </div>
            </Modal>
          </>
        ) : (
          <>
            <Modal
              title="Create New Billing Platform Service Product"
              visible={visible}
              onCancel={onCancel}
              width={800}
              maskClosable={false}
              centered
              style={{ top: 40 }}
              footer={
                <div className="justify-center flex space-x-2">
                  <button key="cancel" className="cancel-btn" onClick={onCancel}>
                    Cancel
                  </button>
                  <button
                    key="submit"
                    className="save-btn disabled:cursor-not-allowed"
                    onClick={handleConfirmSubmit}
                  // loading={loading}
                  // disabled={submitDisabled} // Disable based on state
                  >
                    Submit
                  </button>
                </div>
              }
            >

              <Form layout="vertical" form={form} requiredMark={false}>

                <Row gutter={16}>
                  <Col span={12}>
                    <Form.Item
                      label={renderLabel("Billing Platform Product", true)}
                      name="product"
                      rules={[{ required: true, message: "Please select a product!" }]}
                    >
                      <Select
                        options={productOptions.length > 0 ? productOptions : [{ value: 'No options', label: 'No options' }]}
                        placeholder="Select a Billing Platform Product"
                        value={selectedProduct?.value === 'No options' ? null : selectedProduct}
                        onChange={handleProductChange}
                        styles={DropdownStyles}
                      // isDisabled={!selectedService} // Disable if no service selected
                      />
                    </Form.Item>
                  </Col>
                  <Col span={12}>
                    <Form.Item
                      label={renderLabel("Rate", true)}
                      name="rate"
                      rules={[{ required: true, message: "Please input a rate!" }]}
                    >
                      <Input
                        type="number"
                        value={selectedRate || ""}
                        min="0"
                        step="0.01"
                        className="input"
                        // style={{
                        //   width: "100px",
                        //   padding: "4px",
                        //   textAlign: "right",
                        // }}
                        onChange={(e) => {
                          const newRate = e.target.value;
                          console.log("newRate", newRate)
                          setSelectedRate(newRate); // Update the state with the new rate
                          form.setFieldValue("rate", newRate); // Update the Form field value explicitly
                        }}
                      />
                    </Form.Item>
                  </Col>

                </Row>

                <Row gutter={16}>


                  <Col span={12}>
                    <Form.Item
                      label={renderLabel("Effective date", true)}
                      name="effectiveDate"
                      rules={[{ required: prorate, message: "Please select a date!" }]}
                    >
                      <DatePicker
                        value={
                          effectiveDate ? format(effectiveDate, "yyyy-MM-dd") : null
                        }
                        onChange={handleDateChange}
                        format="YYYY-MM-DD"
                        style={{ width: "100%" }}
                        // disabledDate={disablePastDates}
                        disabled={!prorate} // Disable if prorate is not checked
                      />
                    </Form.Item>
                  </Col>
                  <Col span={12} className="mt-10">
                    <Form.Item name="prorate" valuePropName="checked">
                      <Checkbox
                        checked={prorate}
                        onChange={(e) => setProrate(e.target.checked ? true : false)}
                      >
                        Prorate
                      </Checkbox>
                    </Form.Item>
                  </Col>
                </Row>
                <Row gutter={16}>
                  {/* <Col span={12}>
                          <Form.Item
                            label={renderLabel("Rev.io service", true)}
                            name="service"
                            rules={[{ required: true, message: "Please select a service!" }]}
                          >
                            <Select
                              options={serviceOptions.length > 0 ? serviceOptions : [{ value: 'No options', label: 'No options' }]}
                              placeholder="Select a rev.io Service"
                              value={selectedService?.value === 'No options' ? null : selectedService}
                              onChange={setSelectedService}
                            />
                          </Form.Item>
                        </Col> */}
                  <Col span={12}>
                    <Form.Item
                      label={renderLabel("Quantity", true)}
                      name="quantity"
                      rules={[{ required: true, message: "Please enter a quantity!" }]}
                    >
                      <Input
                        className="forminput"
                        type="number"
                        value={quantity}
                        min={1}
                        onChange={(e) => {
                          const value = Math.max(1, parseInt(e.target.value, 10)); // Ensure quantity is not less than 1
                          setQuantity(value.toString());
                        }}
                        onKeyDown={handleKeyDown} // Add the keydown event listener
                      />
                    </Form.Item>
                  </Col>

                </Row>


                <Row gutter={16}>
                  <Col span={24}>
                    <Form.Item
                      label={renderLabel("Product description", false)}
                      name="description"
                    >
                      <Input.TextArea
                        rows={4}
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                      />
                    </Form.Item>
                  </Col>
                </Row>
              </Form>
            </Modal>
            <Modal
              visible={isConfirmationOpen}
              onOk={handleConfirmSave}
              onCancel={handleCancelConfirmation}
              style={{ zIndex: 10000 }}
              title="Confirmation"
              footer={
                <div className="justify-center flex space-x-2 mt-10">
                  <button onClick={handleCancelConfirmation} className="cancel-btn">
                    Cancel
                  </button>
                  <button onClick={handleConfirmSave} className="save-btn">
                    Ok
                  </button>
                </div>
              }
              centered
            >
              <p>Are you sure you want to Save the Changes?</p>
            </Modal>
          </>
        )}
    </>
  );
};

export default AddServiceProduct;
