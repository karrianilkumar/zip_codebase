"use client";

import React, { useEffect, useState } from "react";
import { Modal, Button, notification, Input, Spin } from "antd";
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import Select from "react-select";
import { DropdownStyles } from "@/app/components/css/dropdown";

interface CreateCustomerFeatureCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
  // serviceProviderMap: Record<string, string[]>;
  onSuccess: () => void;
}

const CreateCustomerModal: React.FC<CreateCustomerFeatureCodeModalProps> = ({
  isOpen,
  onClose,
  // serviceProviderMap,
  onSuccess,
}) => {
  const [selectedProvider, setSelectedProvider] = useState<string | null>(null);
  const [ratePlans, setRatePlans] = useState<string[]>([]);
  const [aliasName, setAliasName] = useState<string>("");
  const [optimizationGroupName, setOptmizationGroupName] = useState<string>("");
  const { username, token, partner, selectedDb,metaData, role,firstLastName,sessionId} = useAuth();
  const [loading, setLoading] = useState(false);
  const [providerError, setProviderError] = useState(false);
  const [groupNameError, setGroupNameError] = useState(false);
  const [ratePlansError, setRatePlansError] = useState(false);
  const [serviceProviderMap, setServiceProviderMap] = useState<Record<string, string[]>>({});
const [dropdownOptions, setDropdownOptions] = useState<{ value: string; label: string }[]>([]);
const [ratePlanOptions, setRatePlanOptions] = useState<{ value: string; label: string }[]>([]);
const [selectedRatePlans, setSelectedRatePlans] = useState<string[]>([]);
const [ratePlanCodeOptions, setRatePlanCodeOptions] = useState<any[]>([]);
const [originalRatePlanOptions, setOriginalRatePlanOptions] = useState<any[]>([]);
  const [ratePlanCodeMap, setRatePlanCodeMap] = useState<Record<string, string[]>>({});


const handleProviderChange = (selectedOption: any) => {
  const provider = selectedOption?.value || null;
  setSelectedProvider(provider);

  if (provider && serviceProviderMap[provider]) {
    const plans = serviceProviderMap[provider].map((plan) => ({
      value: plan,
      label: plan,
    }));

    const plan_codes=ratePlanCodeMap[provider] || []
    const original_rate_plans=serviceProviderMap[provider] || []
    setRatePlanOptions(plans);
    setRatePlanCodeOptions(plan_codes)
    setOriginalRatePlanOptions(original_rate_plans)
  } else {
    setRatePlanOptions([]);
    setRatePlanCodeOptions([])
    setOriginalRatePlanOptions([])
  }

  setSelectedRatePlans([]); // Reset selected rate plans
};

  // const handleRatePlanChange = (selectedOptions: any) => {
  //   setSelectedRatePlans(selectedOptions ? selectedOptions.map((opt: any) => opt.value) : []);
  //   setRatePlansError(false);
  // };
  const handleRatePlanChange = (selectedOptions: any) => {
    const selectedValues = selectedOptions ? selectedOptions.map((opt: any) => opt.value) : [];
    setSelectedRatePlans(selectedValues);
    setRatePlans(selectedValues);
    setRatePlansError(selectedValues.length === 0);
  };

  const handleSave = async () => {
    let isValid = true
    if (!selectedProvider) {
      setProviderError(true);
      isValid = false
    }
    if (!optimizationGroupName.trim()) {
      setGroupNameError(true);
      isValid = false
    }
    if (ratePlans.length === 0) {
      console.log(ratePlans)
      setRatePlansError(true);
      isValid = false
    }
    if (isValid) {
      setLoading(true);
      const planToCodeMap: Record<string, string> = {};
originalRatePlanOptions.forEach((plan: string, index: number) => {
  planToCodeMap[plan] = ratePlanCodeOptions[index];
});

const selectedRatePlanCodes = ratePlans.map((plan) => planToCodeMap[plan]);
      const formData = {
        optimization_group_name: optimizationGroupName,
        alias_name: aliasName,
        service_provider_name: selectedProvider,
        rate_plans_list: selectedRatePlanCodes,
        created_by: firstLastName,
        modified_by: firstLastName,
        is_deleted: "False",
        is_active: "True",
        created_date: getCurrentDateTime(),
      };

      const requestData = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName:firstLastName,
        path: "/update_sim_management_modules_data",
        module_name: "Optimization Group",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        new_data: formData,
        action: "create",
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        table_name: "optimization_group",
      };

      try {
        const response = await axios.post(ENV_ROUTES.SIM_MANAGEMENT, {
          data: requestData,
        });
        if (response.data.statusCode === 200) {
          onSuccess();
          notification.success({
            message: "Success",
            description: "Successfully created the record!",
            placement: "top",
          });
          clearFields();
        } else {
          const errorMsg = JSON.parse(response.data.body).message;
          Modal.error({ title: "Saving Error", content: errorMsg, centered: true });
        }
      } catch (err) {
        notification.error({
          message: "Error",
          description: "Failed to create the record. Please try again.",
          placement: "top",
        });
      } finally {
        setLoading(false);
      }
    }

  };

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const url = ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName:firstLastName,
          path: "/rate_plan_dropdown_data_optimization_groups",
          role_name: role,
          parent_module: "Sim Management",
          module_name: "Optimization Group",
          feature_module_name: "Optimization Groups",
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
        ... metaData,
          sessionID: sessionId,
        };
  
        const response = await axios.post(url, { data });
        const fetchedData = JSON.parse(response.data.body);
        console.log(fetchedData, "fetchedOptions");
  
        if (fetchedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              fetchedData.message ||
              "An error occurred while fetching Inventory data. Please try again.",
            centered: true,
            onOk: handleCancel,
          });
        } else {
          setLoading(false);

          const ratePlansMap = fetchedData.rate_plans_list;

          // Store rate plans map
          setServiceProviderMap(ratePlansMap);

          const ratePlansCodeMap = fetchedData.rate_plan_codes;
          setRatePlanCodeMap(ratePlansCodeMap);

  
          // Extract keys (service provider names) from rate_plans_list
          const serviceProviderOptions = Object.keys(fetchedData.rate_plans_list).map(
            (provider) => ({
              value: provider,
              label: provider,
            })
          );
  
          console.log("Service provider options:", serviceProviderOptions);
          // setServiceProviderMap(fetchedData.rate_plans_list); // Store the map
          setDropdownOptions(serviceProviderOptions); // Update dropdown options
        }
      } catch (error) {
        setLoading(false);
        console.error("Error fetching data:", error);
        Modal.error({
          title: "Data Fetch Error",
          content:
            error instanceof Error
              ? error.message
              : "An unexpected error occurred while fetching data. Please try again.",
          centered: true,
          onOk: handleCancel,
        });
      } finally {
        setLoading(false);
      }
    };
  
    if (isOpen) {
      console.log(isOpen, "visible check");
      fetchData();
    }
  }, [isOpen]);
  

  const clearFields = () => {
    setSelectedProvider(null);
    setRatePlans([]);
    setAliasName("");
    setOptmizationGroupName("");
    setProviderError(false)
    setGroupNameError(false)
    setRatePlansError(false)
  };

  const handleCancel = () => {
    clearFields();
    onClose();
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  return (
    <Modal
      title="Create Optimization Groups"
      visible={isOpen}
      onCancel={handleCancel}
      footer={null}
      centered
      width={600}
    >
      <div className="field-container mb-4 space-y-2">
        <label className="field-label">
          Optimization Group Name <span className="text-red-500">*</span>
        </label>
        <Input
          value={optimizationGroupName}
          onChange={(e) => {
            setOptmizationGroupName(e.target.value);
            setGroupNameError(false);
          }}
          // placeholder="Enter the optimization group name"
          className="input"
        />
        {groupNameError && <span className="text-red-500">Optimization Group Name is Required</span>}
      </div>
      <div className="field-container mb-4 space-y-2">
        <label className="field-label">Alias Name</label>
        <Input
          value={aliasName}
          onChange={(e) => setAliasName(e.target.value)}
          // placeholder="Enter Alias name"
          className="input"
        />
      </div>
      <div className="field-container mb-4 space-y-2">
        <label className="field-label">
          Service Provider <span className="text-red-500">*</span>
        </label>
        <Select
          options={dropdownOptions}
          value={selectedProvider ? { value: selectedProvider, label: selectedProvider } : null}
          onChange={handleProviderChange}
          // placeholder="Select a service provider"
          className="select"
          styles={DropdownStyles}
        />
        {providerError && <span className="text-red-500">Service Provider is Required</span>}
      </div>
      <div className="field-container mb-4 space-y-2">
        <label className="field-label">
          Rate Plans <span className="text-red-500">*</span>
        </label>
        <Select
          isMulti
          options={ratePlanOptions}
          value={selectedRatePlans.map((plan) => ({ value: plan, label: plan }))}
          onChange={handleRatePlanChange}
          // placeholder="Select rate plans"
          className="select"
          styles={DropdownStyles}
        />
        {ratePlansError && <span className="text-red-500">Rate Plans are Required</span>}
      </div>
      <div className="flex justify-center space-x-2 mt-4">
        <button className="cancel-btn" onClick={handleCancel}>
          Cancel
        </button>
        <button className="save-btn" onClick={handleSave}>
          Save
        </button>
      </div>
    </Modal>
  );
};

export default CreateCustomerModal;
