"use client";

import React, { useState, useEffect } from "react";
import { Modal, Select, Button, Form, notification, Input, Spin } from "antd";
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { ChevronDownIcon } from "@heroicons/react/24/outline";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";

const { Option } = Select;

interface CreateCustomerFeatureCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
  serviceProviders: string[];
  ratePlans: any;
  aliasName?: string;
  optimizationGroupName?: string;
  onSuccess: () => void;
}

const CreateCustomerModal: React.FC<CreateCustomerFeatureCodeModalProps> = ({
  isOpen,
  onClose,
  serviceProviders,
  ratePlans,
  aliasName,
  optimizationGroupName,
  onSuccess,
}) => {
  const [form] = Form.useForm();
  const [selectedProvider, setSelectedProvider] = useState<string>("");
  const [ratePlansSet, setRatePlans] = useState<string[]>([]);
  const { username, token, partner, selectedDb,metaData, firstLastName,sessionId} = useAuth();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (selectedProvider) {
      if (ratePlans?.[selectedProvider]) {
        setRatePlans(ratePlans?.[selectedProvider]);
      } else {
        setRatePlans([]);
      }
    } else {
      setRatePlans([]);
    }
  }, [selectedProvider, ratePlans]);

  useEffect(() => {
    if (!isOpen) {
      form.resetFields();
      setSelectedProvider("");
      setRatePlans([]);
    }
  }, [isOpen, form]);
  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }
  const handleProviderChange = (value: string) => {
    setSelectedProvider(value);
    form.resetFields(["ratePlansSet"]);
  };

  const handleRatePlanChange = (value: string[]) => {
    form.setFieldsValue({ ratePlansSet: value });
  };

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "bold",
    padding: "16px",
  };

  const renderLabel = (label: string, required: boolean) => (
    <span className="field-label">
      {label}{" "}
      {required && (
        <span className="text-red-500">*</span>
      )}
    </span>
  );

  const onFinish = async (values: { [key: string]: any }) => {
    setLoading(true)

    const formData = {
      optimization_group_name:
        values.optimizationGroupName || optimizationGroupName,
      alias_name: values.aliasName || aliasName,
      service_provider_name: selectedProvider,
      rate_plans_list: values.ratePlans,
      created_by: firstLastName,
      modified_by: firstLastName,
      is_deleted: "False",
      is_active: "True",
      created_date: getCurrentDateTime(),
    };

    const requestData = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName:firstLastName,
      path: "/update_sim_management_modules_data",
      module_name: "Optimization Group",
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      new_data: formData,
      action: "create",
      access_token: token,
      db_name: selectedDb,
        ... metaData,
      sessionID: sessionId,
      table_name: "optimization_group",
    };

    try {
      const response = await axios.post(
        ENV_ROUTES.SIM_MANAGEMENT,
        {
          data: requestData,
        }
      );
      if (response.data.statusCode === 200) {
        onSuccess();
        notification.success({
          message: "Success",
          description: "Successfully created the record!",
          style: messageStyle,
          placement: "top",
        });
        setLoading(false)

      } else {
        const errorMsg = JSON.parse(response.data.body).message;
        Modal.error({
          title: "Saving Error",
          content: errorMsg,
          centered: true,
        });
        setLoading(false)

      }
    } catch (err) {
      console.error("Error fetching data:", err);
      notification.error({
        message: "Error",
        description: "Failed to create the record. Please try again.",
        style: messageStyle,
        placement: "top",
      });
      setLoading(false)

    }
  };

  return (
    <Modal
      title="Create Optimization Groups"
      visible={isOpen}
      onCancel={onClose}
      footer={null}
      centered
      width={600}
    >
      <Form
        form={form}
        layout="vertical"
        initialValues={{
          provider: selectedProvider,
          ratePlansSet: ratePlansSet,
        }}
        onFinish={onFinish}
        requiredMark={false}
      >
        <Form.Item
          label={renderLabel("Optimization Group Name", true)}
          rules={[
            {
              required: true,
              message: "Optimization group name is required",
            },
          ]}
          name="optimizationGroupName"
        >
          <Input
            placeholder="Enter The Optimization Group Name"
            value={optimizationGroupName}
            className="input"
          />
        </Form.Item>
        <Form.Item label="Alias Name" name="aliasName">
          <Input placeholder="Enter Alias Name"  value={aliasName} className="input"/>
        </Form.Item>
        <Form.Item
          label={renderLabel("Service Provider", true)}
          name="provider"
          rules={[
            { required: true, message: "Service provider is required" },
          ]}
        >
          <Select
            value={selectedProvider}
            onChange={handleProviderChange}
            placeholder="Select a Service Provider"
            className="mb-2"
            suffixIcon={
              <ChevronDownIcon className="w-5 h-5 mt-2 text-gray-600" />
            }
          >
            {serviceProviders.map((provider) => (
              <Option key={provider} value={provider}>
                {provider}
              </Option>
            ))}
          </Select>
        </Form.Item>
        <Form.Item
          label={renderLabel("Rate Plans", true)}
          name="ratePlans"
          rules={[{ required: true, message: "Rate plans are required" }]}
        >
          <Select
            mode="multiple"
            placeholder="Select Rate Plans"
            onChange={handleRatePlanChange}
            maxTagCount="responsive"
            maxTagPlaceholder={(omittedValues) =>
              `+${omittedValues.length} more`
            }
            
            suffixIcon={
              <ChevronDownIcon className="w-5 h-5 mt-2 text-gray-600" />
            }
          >
            {ratePlansSet.map((plan, index) => (
              <Option key={index} value={plan}>
                {plan}
              </Option>
            ))}
          </Select>
        </Form.Item>
        <div className="flex justify-center space-x-2 mt-4">
          <button className="cancel-btn" onClick={onClose}>
            Cancel
          </button>
          <button className="save-btn" type="submit">
            Save
          </button>
        </div>
      </Form>
    </Modal>
  );
};

export default CreateCustomerModal;
