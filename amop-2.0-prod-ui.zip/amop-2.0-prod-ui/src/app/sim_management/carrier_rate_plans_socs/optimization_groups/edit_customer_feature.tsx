/* eslint-disable react-hooks/rules-of-hooks */
import React, { useState, useEffect } from "react";
import { Modal, Form, Select, Input, Button, notification } from "antd";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { useAuth } from "@/app/components/auth_context";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";

const { Option } = Select;

export interface OptimizationCodeRowData {
  service_provider_name: string;
  optimization_group_name: string;
  customer_name: string;
  rate_plans_list: string[];
  id: any;
}

interface EditCustomerFeatureCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
  rowData: any;
  generalFields: any;
  isEditable:boolean;
}

const EditCustomerModal: React.FC<EditCustomerFeatureCodeModalProps> = ({
  isOpen,
  onClose,
  rowData,
  generalFields,
  isEditable
}) => {
  const [form] = Form.useForm();
  const [selectedProvider, setSelectedProvider] = useState<string>("");
  const [selectedRatePlans, setSelectedRatePlans] = useState<string[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [serviceProviderOptions, setServiceProvidersOptions] = useState<
    string[]
  >([]);
  const [ratePlanOptions, setRatePlanOptions] = useState<string[]>([]);
  const [providerMap, setProviderMap] = useState<any>({});

  const { username, tenantNames, role, partner, settabledata, token,selectedDb,metaData,firstLastName,sessionId} =
    useAuth();

  const optionss = ["Altaworx LLC - 500kB Group A Plan", "Custom Plan"];

  const parseCarrierRatePlans = (value: any) => {
    if (typeof value === "string") {
      let parsedPlans: string[];
      try {
        parsedPlans = JSON.parse(value);
      } catch (err) {
        console.log("Error parsing JSON:", err);
        parsedPlans = [];
      }
      return Array.isArray(parsedPlans) ? parsedPlans : [];
    }

    if (Array.isArray(value)) {
      return value;
    }

    return [];
  };

  const customOptionRenderer = (value: any) => {
    return ratePlanOptions.includes(value) ? (
      <Option key={value} value={value}>
        {value}
      </Option>
    ) : (
      <Option key={value} value={value} disabled>
        {value} (Not in options)
      </Option>
    );
  };

  useEffect(() => {
    console.log("opt",rowData)
    if (isOpen) {
      const selectedRatePlans_ = parseCarrierRatePlans(
        rowData?.rate_plans_list
      );
      form.setFieldsValue({
        provider: rowData?.service_provider_name || "",
        optimizationGroupName: rowData.optimization_group_name || "",
        aliasname: rowData.alias_name || "",
        ratePlan: selectedRatePlans_,
      });

      const provider_ = rowData?.service_provider_name || "";
      setSelectedProvider(provider_);
      setSelectedRatePlans(selectedRatePlans_);

      const providerMap_ = generalFields?.rate_plans_list || {};
      setProviderMap(providerMap_);

      const providerOptions_ = Object.keys(providerMap_) || [];
      setServiceProvidersOptions(providerOptions_);

      const rateplanOptions_ = providerMap_?.[provider_] || [];
      setRatePlanOptions(rateplanOptions_);
    }
  }, [isOpen, rowData, form]);

  const handleProviderChange = (value: string) => {
    setSelectedProvider(value);
    const ratePlanOptions_ = providerMap?.[value] || [];
    setRatePlanOptions(ratePlanOptions_);
    form.setFieldsValue({ ratePlan: [] }); // Reset the rate plan field
    setSelectedRatePlans([]);
  };

  const handleCarrierRatePlanChange = (value: string[]) => {
    setSelectedRatePlans(value);
  };

  const renderLabel = (label: string, required: boolean) => (
    <span className="field-label">
      {label}{" "}
      {required && (
        <span className="required-indicator" style={{ color: "red" }}>
          *
        </span>
      )}
    </span>
  );

  const onFinish = async (values: { [key: string]: any }) => {
    setLoading(true);
    try {
      const { provider, optimizationGroupName, aliasname, ratePlan } = values;

      const formData = {
        service_provider_name: provider,
        alias_name: aliasname,
        optimization_group_name: optimizationGroupName,
        rate_plans_list: ratePlan,
        is_active: "True",
        id: rowData?.id,
      };

      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName:firstLastName,
        path: "/update_sim_management_modules_data",
        role_name: role,
        parent_module: "Sim Management",
        module: "Optimization Group",
        table_name: "optimization_group",
        action: "update",
        changed_data: formData,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(
        ENV_ROUTES.SIM_MANAGEMENT,
        { data }
      );
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Update Error",
          content:
            parsedData.message ||
            "An error occurred while updating data. Please try again.",
          centered: true,
        });
      } else {
        try {
          const fetchResponse = await axios.post(
            ENV_ROUTES.MODULE_MANAGEMENT,
            {
              data: {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName:firstLastName,
                path: "/get_module_data",
                role_name: role,
                parent_module: "Sim Management",
                module_name: "Optimization Group",
                feature_module_name:"Optimization Groups",
                mod_pages: {
                  start: 0,
                  end: 100,
                },
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
        ... metaData,
                sessionID: sessionId,
              },
            }
          );

          const fetchParsedData = JSON.parse(fetchResponse.data.body);
          const tableData_ = fetchParsedData?.data?.optimization_group || [];
          settabledata(tableData_);

          notification.success({
            message: "Success",
            description: "Record updated successfully.",
          });

          onClose();
        } catch (fetchError) {
          console.error("Error fetching data:", fetchError);
          Modal.error({
            title: "Data Fetch Error",
            content:
              fetchError instanceof Error
                ? fetchError.message
                : "An unexpected error occurred while fetching data. Please try again.",
            centered: true,
          });
        }
      }
    } catch (error) {
      notification.error({
        message: "Error",
        description: "Failed to update the record. Please try again.",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      title={<span className="pl-2">{`${isEditable?'Edit Optimization Groups':'Optimization Groups Details'}`}</span>}
      visible={isOpen}
      onCancel={onClose}
      footer={null}
      centered
      width={600}
    >
      <Form
        form={form}
        layout="vertical"
        onFinish={onFinish}
        requiredMark={false}
      >
        <Form.Item
          label={renderLabel("Optimization Group Name", true)}
          name="optimizationGroupName"
          rules={[
            {
              required: true,
              message: "Optimization group name is required",
            },
          ]}
        >
          <Input  className="input" disabled={!isEditable}/>
        </Form.Item>
        <Form.Item label="Alias Name" name="aliasname">
          <Input  className={`${isEditable?'input':'non-editable-input'}`} disabled={!isEditable}/>
        </Form.Item>
        <Form.Item
          label={renderLabel("Service Provider", true)}
          name="provider"
          rules={[
            { required: true, message: "Service Provider name is required" },
          ]}
        >
          <Select
            value={selectedProvider}
            onChange={handleProviderChange}
            style={{ width: "100%" }}
            disabled={!isEditable}
          >
            {serviceProviderOptions.map((provider: string) => (
              <Option key={provider} value={provider}>
                {provider}
              </Option>
            ))}
          </Select>
        </Form.Item>
        <Form.Item
          label={renderLabel("Carrier Rate Plan", true)}
          name="ratePlan"
          rules={[
            { required: true, message: "Carrier rate plans are required" },
          ]}
        >
          <Select
            mode="multiple"
            style={{ width: "100%" }}
            value={selectedRatePlans}
            onChange={handleCarrierRatePlanChange}
            maxTagCount="responsive"
            maxTagPlaceholder={(omittedValues) =>
              `+${omittedValues.length} more`
            }
            disabled={!isEditable}
          >
            {ratePlanOptions.map((carrier) => (
              <Option key={carrier} value={carrier}>
                {carrier}
              </Option>
            ))}
            {optionss
              .filter((option) => !ratePlanOptions.includes(option))
              .map((customOption) => customOptionRenderer(customOption))}
          </Select>
        </Form.Item>

        <div className="flex justify-center space-x-2 mt-4">
          <button onClick={onClose} className="cancel-btn">
            Cancel
          </button>
          <button
            type="submit"
            className="save-btn"
            style={{ color: "#333" }}
          >
            Save
          </button>
        </div>
      </Form>
    </Modal>
  );
};

export default EditCustomerModal;
