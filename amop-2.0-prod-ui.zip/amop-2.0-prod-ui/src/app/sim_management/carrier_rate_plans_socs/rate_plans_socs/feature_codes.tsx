import React, { useEffect, useState, lazy, Suspense, useCallback, useRef } from "react";
import { PlusIcon, ArrowDownTrayIcon, ArrowUpTrayIcon } from "@heroicons/react/24/outline";
import { Button, Modal, Spin, DatePicker, notification, message, Upload } from "antd";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import dayjs, { Dayjs } from "dayjs";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import CustomerModal from "./create_customer_feature_code"; // Import the CustomerModal component
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { DownloadOutlined, UploadOutlined } from "@ant-design/icons";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { useCustomerRatePlanStore } from "@/app/stores/customerRateplanStore";

const { RangePicker } = DatePicker;
const TableComponent = lazy(() => import("@/app/components/TableComponent/page"));
const CreateModal = lazy(() => import("@/app/components/createPopup"));
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));
const TableSearch = lazy(() => import("@/app/components/entire_table_search"));
const AdvancedMultiFilter = lazy(() => import("@/app/components/advanced_search"));

const FeatureCodes: React.FC = () => {
    const [isExportModalOpen, setExportModalOpen] = useState(false);
    const [isCustomerModalOpen, setCustomerModalOpen] = useState(false); // State for CustomerModal
    
    const [searchTerm, setSearchTerm] = useState("");
    const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
    const { username, partner, role, token, tenantId, tenantName, selectedDb,metaData,settabledata, advancedStoredpagination, storedpagination, firstLastName,sessionId,combineAdnvaceStoredpagination,setCombineAdnvaceStoredpagination,dynamicColumns,setDynamicColumns} = useAuth();
    const [loading, setLoading] = useState(true);
    const [pagination, setPagination] = useState<any>({});
    const [tableData, setTableData] = useState<any>([]);
    const [features, setFeatures] = useState<string[]>([]);
    const [headers, setHeaders] = useState<any[]>([]);
    const [headerMap, setHeaderMap] = useState<any>({});
    const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([null, null]);
    const [filteredData, setFilteredData] = useState([]);
    const [showAdvanced, setShowAdvanced] = useState(false);
    // const { showAdvanced, setShowAdvanced} = useCustomerRatePlanStore();
    const [createModalData, setcreateModalData] = useState<any[]>([]);
    const [generalFields, setgeneralFields] = useState<any[]>([]);
    //Edit Feature Codes
    const [allowedActions, setAllowedActions] = useState<any[]>([]);
    const [appendChecked, setAppendChecked] = useState(false);
    const [isUploadModalVisible, setIsUploadModalVisible] = useState(false);
    const [uploadKey, setUploadKey] = useState(Date.now());
    const [isFileSelected, setIsFileSelected] = useState(false);
    const [overwriteChecked, setOverwriteChecked] = useState(false);
      //export functionality
      // const [exportLoading, setExportLoading] = useState(false);
      const { addExport, removeExport,exports } = exportLoadingStore();
      const exportKey = "Feature Codes";
      const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
      const {
        features: moduleFeatures,
        setFeatures: setModuleFeatures,
      } = useFeatureStore();

    // const { features: moduleFeatures, setFeatures: setModuleFeatures } = useFeatureStore();
    const hasFetchedData = useRef(false);

    type HeaderMap = Record<string, [string, number]>;

    const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
        const entries = Object.entries(headerMap) as [string, [string, number]][];
        entries.sort((a, b) => a[1][1] - b[1][1]);
        return Object.fromEntries(entries) as HeaderMap;
    }, []);

    const sortPopup = (fields: any[]): any[] => {
        return fields.sort((a: any, b: any) => a?.id - b?.id);
    };

    const handleFilter = useCallback((advancedFilters: any) => {
        console.log(advancedFilters);
        setAdvancedFilters(advancedFilters)
    }, []);

    const handleReset = useCallback((EmptyFilters: any) => {
        console.log(EmptyFilters);
        setFilteredData(EmptyFilters);
    }, []);

    useEffect(() => {
          setDynamicColumns((prev:any)=>({...prev,"Feature Codes":visibleColumns}))
        }, [visibleColumns]);

    const fetchData = useCallback(async () => {
        setCombineAdnvaceStoredpagination(null);
        setLoading(true);
        settabledata([])
        try {
            const url = ENV_ROUTES.MODULE_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName:firstLastName,
                path: "/get_module_data",
                role_name: role,
                parent_module: "Sim Management",
                module_name: "Feature Codes",
                feature_module_name:"Rate Plans/SOCs",
                mod_pages: {
                    start: 0,
                    end: 100,
                },
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
        ... metaData,
                sessionID: sessionId,
            };
            console.log(getCurrentDateTime(),"Show the log time request sent from ui to lambda");
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            console.log(getCurrentDateTime(),"Show the log time response sent from lambda to ui");

            if (parsedData.flag === false) {
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                const headersMap_ = parsedData?.headers_map?.["Feature Codes"]?.header_map || {}
                const sortedheaderMap = sortHeaderMap(headersMap_)
                setHeaderMap(sortedheaderMap)
                const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : []
                setHeaders(headers_)
                const dynamic_cols=dynamicColumns?.["Feature Codes"] && dynamicColumns["Feature Codes"] .length>0 ?dynamicColumns["Feature Codes"]  :headers_ || headers_
                setVisibleColumns(dynamic_cols)
                const tableData_ = parsedData?.data?.mobility_feature || []
                setTableData(tableData_)
                const features_ = parsedData?.headers_map?.["Feature Codes"]?.module_features || []
                setFeatures(features_)
                const allowedActions_:any=[]
                if(features_.includes("Edit-Feature Codes")){
                  allowedActions_.push("formEditFeatureModal")
                }
                if(features_.includes("Delete-Feature Codes")){
                  allowedActions_.push("delete")
                }
                setAllowedActions(allowedActions_)
                const createModalData_ = parsedData?.headers_map?.["Feature Codes"]?.pop_up || []
                const sortedCreatemodeldata_ = sortPopup(createModalData_)
                setcreateModalData(sortedCreatemodeldata_)
                const generalFields_ = parsedData?.data || {}
                setgeneralFields(generalFields_)
                setModuleFeatures(features_)
                const pagination_ = parsedData?.pages || {}
                setPagination(pagination_)
            }
        } catch (error) {
            console.error("Error fetching data:", error);
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        } finally {
            setLoading(false);
        }
    }, [username, partner, role, token, sortHeaderMap, setModuleFeatures]);

    useEffect(() => {
        if (!hasFetchedData.current) {
            fetchData();
            hasFetchedData.current = true;
        }
    }, [fetchData]);

    const messageStyle = {
        fontSize: '14px',
        fontWeight: 'bold',
        padding: '16px',
    };

   
    const handleExportModalOpen = () => {
        setExportModalOpen(true);
    };

    const handleExportModalClose = () => {
        setExportModalOpen(false);
        console.log("Modal closed, resetting date range.");
    };
    const handleUploadClick = () => {
        setIsUploadModalVisible(true);
    
      }
      const handleUploadModalClose = () => {
        setIsUploadModalVisible(false);
      };
      const handleErrorModalClose = () => {
        setIsUploadModalVisible(false)
      }

    // const handleExport = async () => {
    //     // if (!dateRange || dateRange[0] === null || dateRange[1] === null) {
    //     //     Modal.error({ title: 'Error', content: 'Please select a date range.' });
    //     //     return;
    //     // }

    //     // const [startDate, endDate] = dateRange;

    //     const data = {
    //         path: "/export",
    //         username: username,
    //         module_name: "Feature Codes",
    //         request_received_at: getCurrentDateTime(),
    //         // start_date: startDate.format("YYYY-MM-DD 00:00:00"),
    //         // end_date: endDate.format("YYYY-MM-DD 23:59:59"),
    //         Partner: partner,
    //         access_token: token,
    //         db_name: selectedDb,
        // ... metaData,
    //     };

    //     try {
    //         const url = ENV_ROUTES.MODULE_MANAGEMENT;
    //         const response = await axios.post(url, { data: data }, {
    //             headers: {
    //                 'Content-Type': 'application/json',
    //             },
    //         });

    //         const resp = JSON.parse(response.data.body);
    //         const blob = resp.blob;

    //         if (response.data.statusCode === 200) {
    //             if (resp.flag === true) {
    //                 notification.success({
    //                     message: 'Success',
    //                     description: 'Successfully exported the record!',
    //                     style: messageStyle,
    //                     placement: 'top',
    //                 });
    //                 downloadBlob(blob);
    //             } else {
    //                 console.log('Error message:', resp.message);
    //                 Modal.error({
    //                     title: 'Export Error',
    //                     content: resp.message,
    //                     centered: true,
    //                 });
    //             }
    //         } else {
    //             console.log('Unexpected status code:', response.data.statusCode);
    //             Modal.error({
    //                 title: 'Export Error',
    //                 content: resp.message,
    //                 centered: true,
    //             });
    //         }

    //         handleExportModalClose();
    //     } catch (error) {
    //         console.error("Error downloading the file:", error);
    //         Modal.error({ title: 'Export Error', content: 'An error occurred while exporting the file. Please try again.' });
    //     }
    // };

     
  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }

  const ExportWithoutSearch = async () => {
    // setExportLoading(true)
    // const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
    //   return new Promise((resolve, reject) => {
    //     const timer = setTimeout(() => {
    //       reject(new Error("Request timed out"));
    //     }, timeout);

    //     promise
    //       .then((res) => {
    //         clearTimeout(timer);
    //         resolve(res);
    //       })
    //       .catch((err) => {
    //         clearTimeout(timer);
    //         reject(err);
    //       });
    //   });
    // };
    try {
      // setExportLoading(true)
      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Request timed out"));
          }, timeout);
  
          promise
            .then((res) => {
              clearTimeout(timer);
              resolve(res);
            })
            .catch((err) => {
              clearTimeout(timer);
              reject(err);
            });
        });
      };
  
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/export_to_s3_bucket",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Feature Codes",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ... metaData,
        sessionID: sessionId,
        feature_module_name: "Rate Plans/SOCs",
        start_date: getFirstDayOfCurrentMonth(),
        end_date: getLastDayOfCurrentMonth(),
      };
      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000); // Timeout of 10 seconds
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }

      // Wait for 20 seconds before polling
      await new Promise((resolve) => setTimeout(resolve, 20000));
      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      // setExportLoading(false);
      // removeExport(exportKey); // Remove the export from the store
    }
  }
  const pollExportStatus = async () => {
    // Polling for the second API
  const export_url = ENV_ROUTES.MODULE_MANAGEMENT;
  const export_data = {
    tenant_name: partner || "default_value",
    username,
    path: "/get_export_status",
    role_name: role,
    parent_module: "Sim Management",
    module_name:"Feature Codes",
    request_received_at: getCurrentDateTime(),
    Partner: partner,
    access_token: token,
    db_name: selectedDb,
        ... metaData,
    sessionID: sessionId,
  };
    try {
      const export_response = await axios.post(export_url, { data: export_data });
      const export_parsedData = JSON.parse(export_response.data.body);

      if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
        const s3Url = export_parsedData?.export_status_data?.url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
                          .then(response => response.blob())
                          .then(blob => {
                            const url = window.URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = 'Feature Codes.xlsx';
                            a.click();
                            a.remove();
                            window.URL.revokeObjectURL(url);
                            notification.success({
                              message: "Success",
                              description: "Successfully exported the record!",
                              style: messageStyle,
                              placement: "top",
                            });
                          })
                        .catch((err) => {
                          console.log("error",err)
                          Modal.error({
                            title: "Export Error",
                            content: "An error occurred while exporting data. Please try again.",
                            centered: true,
                          });
                        });
        } else {
          Modal.error({
            title: "Export Error",
            content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
        return true; // Stop polling
      }

      if (export_parsedData?.export_status_data?.status_flag === "Failure") {
        Modal.error({
          title: "Export Error",
          content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
        return true; // Stop polling
      }
      if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
                Modal.info({
                  title: "Export Error",
                  content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
                  centered: true,
                });
                return true; // Stop polling
              }

      return false; // Continue polling
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
      return true; // Stop polling
    }
  };

  const startPolling = async () => {
    let isPollingComplete = false;

    while (!isPollingComplete) {
      isPollingComplete = await pollExportStatus();
      if (!isPollingComplete) {
        await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
      }
    }
  };
  const handleExport = async (key: string, heading: string) => {
    try {
      // setExportLoading(true)
      addExport(key, heading);
      let parsedData
      let url
      let data: any
      let response
      if(combineAdnvaceStoredpagination){
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
        ... metaData,
          sessionID: sessionId,
          index_name: "Feature_Codes",
          module_name: "Feature Codes",
        };
        console.log("combineAdnvaceStoredpagination",data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
      else if (advancedStoredpagination && !storedpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          module_name: "Feature Codes",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name: "Feature_Codes",
          pages: {
            start: 0,
            end: 100
          },
          partner:partner,
          username: username,
          db_name: selectedDb,
        ... metaData,
          sessionID: sessionId,
          tenant_id: tenantId,
          // }
        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

      }
      else if (storedpagination && !advancedStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          module_name: "Feature Codes",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "Feature_Codes",
          search: "whole",
          pages: {
            start: 0,
            end: 100,
          },
          partner:partner,
          username: username,
          db_name: selectedDb,
        ... metaData,
          sessionID: sessionId,
          tenant_id: tenantId,
        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

      }
      else {
        // ExportWithoutSearch()
        await ExportWithoutSearch();
        return;
      }

      // if (advancedStoredpagination || storedpagination || combineAdnvaceStoredpagination) {
      //   if (parsedData.flag === true) {
      //     const s3Url = parsedData?.download_url || null;
      //     if (s3Url) {
      //       window.location.href = s3Url;
      //       setExportLoading(false)
      //       notification.success({
      //         message: 'Success',
      //         description: 'Successfully exported the record!',
      //         style: messageStyle,
      //         placement: 'top',
      //       });
      //     }
      //     else {
      //       setExportLoading(false)
      //       Modal.error({
      //         title: "Export Error",
      //         content: parsedData.message || "An error occurred while exporting data. Please try again.",
      //         centered: true,
      //       });
      //     }

      if (parsedData.flag) {
        console.log("flag")
        const s3Url = parsedData?.download_url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the  record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
fetch(s3Url)
                .then(response => response.blob())
                .then(blob => {
                  const url = window.URL.createObjectURL(blob);
                  const a = document.createElement('a');
                  a.href = url;
                  a.download = 'Feature Codes.xlsx';
                  a.click();
                  a.remove();
                  window.URL.revokeObjectURL(url);
                  notification.success({
                    message: "Success",
                    description: "Successfully exported the record!",
                    style: messageStyle,
                    placement: "top",
                  });
                })
              .catch((err) => {
                console.log("error",err)
                Modal.error({
                  title: "Export Error",
                  content: "An error occurred while exporting data. Please try again.",
                  centered: true,
                });
              });
        } else {
          // setExportLoading(false)
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      
    } else {
      console.log("!flag")
      Modal.error({
        title: "Export Error",
        content: parsedData.message || "An error occurred while exporting data. Please try again.",
        centered: true,
      });
    }
    } catch (error) {
      console.log("catch")
      await startPolling()
      // Modal.error({
      //   title: "Export Error",
      //   content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
      //   centered: true,
      // });
    } finally {
      // setExportLoading(false)
      removeExport(key);
    }
  };
    const handleFormSubmitSuccess = () => {
        fetchData();// Re-fetch data to get the latest row
        setCustomerModalOpen(false) 
      };

      const handleUpload = async (blob: string) => {
        try {
          const url = ENV_ROUTES.SIM_MANAGEMENT;
          let flag: string = appendChecked ? "append" : "overwrite";
    
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName:firstLastName,
            path: "/import_bulk_data",
            table_name: "mobility_feature",
            insert_flag: "append",
            module_name: "Feature Codes",
            role_name: role,
            Partner: partner,
    
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
        ... metaData,
            sessionID: sessionId,
            blob: blob, // Include the Blob in the data
          };
    
          const response = await axios.post(url, { data });
          const resp = JSON.parse(response.data.body);
          if (response.data.statusCode === 200) {
            if (resp.flag === true) {
              setIsUploadModalVisible(false)
              notification.success({
                message: 'Success',
                description: 'Successfully imported the record!',
                placement: 'top',
              });
              fetchData();
    
            } else {
              Modal.error({
                title: 'Import Error',
                content: resp.message,
                centered: true,
                onOk: handleErrorModalClose,
                onCancel: handleErrorModalClose
              });
            }
          } else {
            Modal.error({
              title: 'Import Error',
              content: resp.message,
              centered: true,
              onOk: handleErrorModalClose,
              onCancel: handleErrorModalClose
            });
          }
        } catch (error) {
          console.error('Error during file upload:', error);
          Modal.error({
            title: 'Import Error',
            content: 'There was an error uploading the file.',
            centered: true,
            onOk: handleErrorModalClose,
            onCancel: handleErrorModalClose
          });
    
        }
      }
      const handleChange = (info: any) => {
        if (info.file.status === 'done') {
          setIsFileSelected(true);
          let blob;
          const file = info.file.originFileObj; // Get the file object
          const reader = new FileReader();
          reader.onload = (e: any) => {
            // Get the file data URL (Base64 string)
            blob = e.target.result;
            console.log('File Base64 String:', blob);
            handleUpload(blob)
            setUploadKey(Date.now());
          };
    
          if (blob) {
          }
    
          reader.readAsDataURL(file); // Read the file as data URL
        } else if (info.file.status === 'error') {
          // Handle upload error
          message.error('Upload failed.');
        }
        else if (info.file.status === 'removed') {
          setIsFileSelected(false);
          setAppendChecked(false);
          setOverwriteChecked(false);
        }
      };
      const uploadProps = {
        key: uploadKey,
        accept: '.xlsx, .xls',
        beforeUpload: (file: any) => {
          // Check if file is an Excel file
          const isExcel = file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || file.type === 'application/vnd.ms-excel';
          if (!isExcel) {
            message.error('You can only upload Excel files!');
          }
          return isExcel;
        },
        onChange: handleChange,
      };
      const handleDownloadTemplate = async () => {
        setLoading(true);
        const url =
          ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName:firstLastName,
          path: "/bulk_upload_download_template",
          table_name: "mobility_feature",
          module_name: "Feature Codes",
          role_name: role,
          Partner: partner,
          request_received_at: getCurrentDateTime(),
          access_token: token,
          db_name: selectedDb,
        ... metaData,
          sessionID: sessionId,
        };
    
        const response = await axios.post(url, { data });
        const resp = JSON.parse(response.data.body);
        const blob = resp.blob;
        if (response.data.statusCode === 200) {
          if (resp.flag === true) {
            handleUploadModalClose()
            notification.success({
              message: 'Success',
              description: 'Successfully downloaded template!',
              style: messageStyle,
              placement: 'top',
            });
            downloadBlob(blob);
            setLoading(false);
          } else {
            console.log('Error message:', resp.message);
            Modal.error({
              title: 'Export Error',
              content: resp.message,
              centered: true,
              onOk: handleErrorModalClose,
              onCancel: handleErrorModalClose
            });
          }
        } else {
          console.log('Unexpected status code:', response.data.statusCode);
          Modal.error({
            title: 'Export Error',
            content: resp.message,
            centered: true,
            onOk: handleErrorModalClose,
            onCancel: handleErrorModalClose
          });
        }
      };
   
    const downloadBlob = (base64Blob: string) => {
        const byteCharacters = atob(base64Blob);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);

        const blobObject = new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blobObject);
        link.download = 'Feature_Codes.xlsx';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };
    useEffect(() => {
      if (!loading) {
        console.log("Data Displayed in UI", getCurrentDateTime());
      }
    }, [loading]);

    if (loading) {
        return (
            <div className="flex justify-center items-center h-screen">
                <Spin size="large" />
            </div>
        );
    }
   

    const disableFutureDates = (current: any) => {
        return current && current > dayjs().endOf('day');
    };

    return (
        <Suspense fallback={<div className="flex justify-center items-center h-screen"><Spin size="large" /></div>}>
            <div className="relative">
            <div className="pr-4 pl-4  pt-2 flex  md:flex-row md:items-center md:justify-between mt-1 mb-4 space-y-4">
          {/* Search and Advanced Filter Container */}
          <div className="flex  space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last ">
                    {features.includes("Search-Feature Codes") && (
                        <TableSearch
                            searchTerm={searchTerm}
                            setSearchTerm={setSearchTerm}
                            tableName={"Feature_Codes"} // Need to Change
                            headerMap={headerMap}
                        />
                    )}
                        {features.includes("Advanced filter-Feature Codes") && (
                        <AdvancedMultiFilter
                            showAdvanced={showAdvanced}
                            setShowAdvanced={setShowAdvanced}
                            onFilter={handleFilter}
                            onReset={handleReset}
                            headers={headers}
                            headerMap={headerMap}
                            tableName={"Feature_Codes"} // Need to Change
                        />
                        )}
                    </div>
                    {/* Export and ColumnFilter Container */}
           <div className="hidden md:flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2  md:order-none order-first pb-2 md:pb-4">
                    {features.includes("Create-Feature Codes") && (
                    <button className="save-btn" onClick={() => setCustomerModalOpen(true)}>
                            <PlusIcon className="h-5 w-5 text-black-500 mr-2" />
                            <span>Create</span>
                        </button>
                    )}
                        {/* {features.includes("Upload-Feature Codes") && ( */}

                      <button className="save-btn" onClick={handleUploadClick}>
                        <ArrowUpTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                        <span>Upload</span>
                      </button>
                      {/* )} */}
                      <Modal
                      title="Upload Files"
                      visible={isUploadModalVisible}
                      onCancel={handleUploadModalClose}
                      footer={null} // No default footer buttons
                      centered
                      width={400}
                      >
                     <div className="flex flex-col gap-4">
                        <div className="flex flex-col md:flex-row gap-4 justify-center m-auto p-4">
                         <Upload {...uploadProps} className="w-full md:w-auto">
                            <button className="w-[200px] md:w-full upload-btn disabled:cursor-not-allowed">
                            <span className="mr-2"><UploadOutlined /></span>
                            Upload
                           </button>
                          </Upload>
                          <button
                            onClick={handleDownloadTemplate}
                            className=" w-[200px] md:w-full upload-btn disabled:cursor-not-allowed"
                          // disabled={!appendChecked && !overwriteChecked}
                          >
                            <span className="mr-2"><DownloadOutlined /></span>
                            Download Template
                          </button>
                        </div>
                      </div>
                      </Modal>
                    {features.includes("Export-Feature Codes") && (
                        <button className="save-btn"
                        onClick={() => {
                          if (!exports.some((exportItem) => exportItem.popupHeading === "Feature Codes")) {
                            handleExport("FeatureCodes", "Feature Codes");
                          }
                        }}>
                            <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                            <span>Export</span>
                        </button>
                    )}
                        <ColumnFilter
                            headers={headers}
                            visibleColumns={visibleColumns}
                            setVisibleColumns={setVisibleColumns}
                            headerMap={headerMap}
                        />
                    </div>
                </div>
                <div className={`${showAdvanced ? 'mt-[70px]' : ''}`}>
                    <TableComponent
                        headers={headers}
                        headerMap={headerMap}
                        initialData={tableData}
                        searchQuery={searchTerm}
                        visibleColumns={visibleColumns}
                        itemsPerPage={100}
                        allowedActions={allowedActions}
                        popupHeading="Feature Codes"
                        pagination={pagination}
                        advancedFilters={filteredData}
                        createModalData={createModalData}
                        generalFields={generalFields}
                        height = {showAdvanced?360:300}
                    />
                </div>
                <CustomerModal
                    isOpen={isCustomerModalOpen}
                    onClose={() => setCustomerModalOpen(false)}
                    onSuccess={handleFormSubmitSuccess}
                />
                {/* <Modal
                    title="Export output"
                    visible={isExportModalOpen}
                    onCancel={() => {
                        handleExportModalClose();
                        setDateRange([null, null]);
                    }}
                    footer={null}
                    centered
                    afterClose={() => setDateRange([null, null])}
                >
                    <div className="flex flex-col space-y-4">
                        <span>Select date range</span>
                        <RangePicker
                            value={dateRange[0] && dateRange[1] ? [dateRange[0], dateRange[1]] : null}
                            onChange={(dates) => {
                                if (dates && dates.length === 2) {
                                    setDateRange([dates[0], dates[1]] as [Dayjs, Dayjs]);
                                } else {
                                    setDateRange([null, null]);
                                }
                            }}
                            format="YYYY-MM-DD"
                            disabledDate={disableFutureDates}
                        />
                        <div className="flex justify-center space-x-2">
                            <button onClick={handleExportModalClose} className="cancel-btn">Cancel</button>
                            <button onClick={handleExport} className="save-btn" style={{color:'#333'}}>Export</button>
                        </div>
                    </div>
                </Modal> */}
                    {/* {exportLoading && (
            <div className="export-processing-div">
              Export Processing...
            </div>
          )} */}
              {/* Sticky Footer for Small Screens */}
         <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
         {features.includes("Create-Feature Codes") && (
                    <button className="save-btn" onClick={() => setCustomerModalOpen(true)}>
                            <PlusIcon className="h-5 w-5 text-black-500 " />
                        </button>
                    )}
                        {/* {features.includes("Upload-Feature Codes") && ( */}

                      <button className="save-btn" onClick={handleUploadClick}>
                        <ArrowUpTrayIcon className="h-5 w-5 text-black-500 " />
                      </button>
                      {/* )} */}
                      {features.includes("Export-Feature Codes") && (
                        <button className="save-btn"
                        onClick={() => {
                          if (!exports.some((exportItem) => exportItem.popupHeading === "Feature Codes")) {
                            handleExport("FeatureCodes", "Feature Codes");
                          }
                        }}>
                            <ArrowDownTrayIcon className="h-5 w-5 text-black-500" />
                        </button>
                    )}
                        <ColumnFilter
                            headers={headers}
                            visibleColumns={visibleColumns}
                            setVisibleColumns={setVisibleColumns}
                            headerMap={headerMap}
                        />
         </div>
            </div>
        </Suspense>
    );
};

export default FeatureCodes;
