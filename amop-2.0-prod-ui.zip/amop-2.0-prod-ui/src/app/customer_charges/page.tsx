"use client";
import React, {
  useEffect,
  useState,
  lazy,
  Suspense,
  useRef,
  useCallback,
} from "react";
import { ArrowDownTrayIcon, ArrowUpTrayIcon } from "@heroicons/react/24/outline";
import { Modal, Spin, DatePicker, notification, message, Upload } from "antd";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import dayjs, { Dayjs } from "dayjs";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { DownloadOutlined, MinusCircleOutlined, MinusOutlined, PlusOutlined, SettingOutlined, UploadOutlined } from "@ant-design/icons";
import { useRevStore } from "@/app/stores/revStore";
import moment from "moment";
import Select from 'react-select';
import { ENV_ROUTES } from "../components/routes/route_constants";
type ExportData = {
  path: string;
  username: string | null;
  module_name: string;
  request_received_at: string;
  start_date: string;
  end_date: string;
  Partner: string | null;
  access_token: string | null;
  db_name: string | null;
};

const { RangePicker } = DatePicker;
const RevTableComponent = lazy(
  () => import("@/app/components/revTableComponent/page")
);
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));
const TableSearch = lazy(() => import("@/app/components/entire_table_search"));
const AdvancedMultiFilter = lazy(
  () => import("@/app/components/advanced_search")
);

const CustomerCharges: React.FC = () => {
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, token, selectedDb,metaData, firstLastName,sessionId} = useAuth();
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([
    null,
    null,
  ]);
  const [selectedDate, setSelectedDate] = useState<string | null>(moment().format('YYYY-MM-DD')); // Default to current date

  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const { setRevRows, setRevHeaders, setRevHeaderMap } = useRevStore();
  const [duplicateWarning, setDuplicateWarning] = useState(false);
  const [isDuplicates, setIsDuplicates] = useState(false); // Tracks whether duplicates are present
  const [loading, setLoading] = useState(true);
  const [exportLoading, setExportLoading] = useState(true);
  const [customerSessionsMap, setCustomerSessionsMap] = useState<any>({})
  const [customerOptions, setCustomerOptions] = useState<any[]>([])
  const [sessionOptions, setSessionOptions] = useState<any[]>([])
  const [selectedCustomer, setSelectedCustomer] = useState<string | null>(null);
  const [selectedSessions, setSelectedSessions] = useState<any[]>([]);
  const [exportCustomerError, setExportCustomerError] = useState<boolean>(false);
  const [isUploadModalVisible, setIsUploadModalVisible] = useState(false);
  const [uploadKey, setUploadKey] = useState(Date.now());
  const [isFileSelected, setIsFileSelected] = useState(false);
  const [appendChecked, setAppendChecked] = useState(false);
  const [overwriteChecked, setOverwriteChecked] = useState(false);
  const [allowedActions, setAllowedActions] = useState<any[]>([]);

  const handleClose = () => {
    setDuplicateWarning(false);
    setIsDuplicates(true)
  };


  type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);

  const fetchExportData = async () => {
    setExportCustomerError(false)
    setCustomerOptions([])
    setSelectedCustomer(null)
    setSessionOptions([])
    setSelectedSessions([])
    setCustomerSessionsMap({})
    try {
      setExportLoading(true);
      const url = ENV_ROUTES.SIM_MANAGEMENT
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/customers_sessions_customer_charges_export_dropdown_data",
        role_name: role,
        module_name: "Customer charges",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching customer charges data. Please try again.',
          centered: true,
        });
      } else {
        const customerSessionsMap_ = parsedData?.customer_sessions || {}
        setCustomerSessionsMap(customerSessionsMap_)
        const customerOptions_ = Object.keys(customerSessionsMap_) || []
        setCustomerOptions(customerOptions_)

      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      setExportLoading(false);
    }
  };
  const fetchData = async () => {
    try {
      setLoading(true);
      const url = ENV_ROUTES.SIM_MANAGEMENT
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_customer_charges_data",
        role_name: role,
        module_name: "Customer charges",
        feature_module_name:"Customer Charges",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
      };
      console.log(getCurrentDateTime(),"Show the log time request sent from ui to lambda");
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      console.log(getCurrentDateTime(),"Show the log time response sent from lambda to ui");
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching customer charges data. Please try again.',
          centered: true,
        });
      } else {
        const headersMap_ = parsedData?.header_map?.["Customer charges"]?.header_map || {}
        const sortedheaderMap = sortHeaderMap(headersMap_)
        setHeaderMap(sortedheaderMap)
        setRevHeaderMap(sortedheaderMap)
        const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : []
        setHeaders(headers_)
        setRevHeaders(headers_)
        setVisibleColumns(headers_)
        const tableData_ = parsedData?.customer_charges_data || []
        setTableData(tableData_)
        setRevRows([])
        const features_ = parsedData?.header_map?.["Customer charges"]?.module_features || []
        setFeatures(features_)
        const allowedActions_:any=[]
        if(features_.includes("Downlaod-Customer charges")){
          allowedActions_.push("download")
        }
        setAllowedActions(allowedActions_)
        const pagination_ = parsedData?.pages || {}
        setPagination(pagination_)
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [partner]);

  const handleCustomerChange = (selectedOption: any) => {
    setSessionOptions([])
    setSelectedSessions([])
    if (selectedOption) {
      const value = selectedOption.value
      setSelectedCustomer(value);
      const sessionOptions = customerSessionsMap[value] || []
      setSessionOptions(sessionOptions)
    }
    else if (selectedOption === null) {
      setSessionOptions([])
      setSelectedCustomer(null)
    }
  };
  const handleSessionChange = (selectedOptions: any) => {
    if (selectedOptions) {
      if (Array.isArray(selectedOptions)) {
        const values = selectedOptions.map((option: any) => option.value);
        console.log("values", values)

        setSelectedSessions(values);

      } else {
        setSelectedSessions([]);
      }
    }
    else if (selectedOptions === null) {
      setSelectedSessions([])
    }
  };

  const exportMutation = useMutation<any, Error, ExportData>({
    mutationFn: async (exportData) => {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const response = await axios.post(
        url,
        { data: exportData },
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      return JSON.parse(response.data.body);
    },
    onSuccess: (data) => {
      if (data.flag === true) {
        notification.success({
          message: "Success",
          description: "Successfully exported the record!",
          style: messageStyle,
          placement: "top",
        });
        downloadZipBlob(data.blob);
      } else {
        Modal.error({
          title: "Export Error",
          content: data.message,
          centered: true,
        });
      }
      handleExportModalClose();
    },
    onError: (error) => {
      console.error("Error downloading the file:", error);
      Modal.error({
        title: "Export Error",
        content:
          "An error occurred while exporting the file. Please try again.",
      });
    },
  });

  const handleFilter = useCallback((advancedFilters: any) => {
  }, []);

  const handleReset = useCallback((EmptyFilters: any) => {
    setFilteredData(EmptyFilters);
  }, []);

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "bold",
    padding: "16px",
  };

  const handleExportModalOpen = () => {
    fetchExportData()
    setExportModalOpen(true);
  };

  const handleExportModalClose = () => {
    setExportModalOpen(false);
  };

  const handleExport = () => {
    // if (!dateRange || dateRange[0] === null || dateRange[1] === null) {
    //     Modal.error({ title: "Error", content: "Please select a date range." });
    //     return;
    // }

    const [startDate, endDate] = dateRange;
    const isValid = selectedCustomer ? true : false

    const exportData: any = {
      path: "/export_customer_charges",
      username: username,
      firstLastName: firstLastName,
      module_name: "Customer charges",
      request_received_at: getCurrentDateTime(),
      // start_date: startDate.format("YYYY-MM-DD 00:00:00"),
      // end_date: endDate.format("YYYY-MM-DD 23:59:59"),
      customer_name: selectedCustomer || null,
      session_ids: selectedSessions.length > 0 ? selectedSessions : sessionOptions,
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
                ...metaData,
      sessionID: sessionId,
    };
    if (isValid) {
      exportMutation.mutate(exportData);
    }
    else {
      setExportCustomerError(true)
    }

  };

  const downloadZipBlob = (base64Blob: string) => {
    // Convert base64 string to binary data
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    // Create a Blob from the byteArray with a type of zip
    const blobObject = new Blob([byteArray], {
      type: "application/zip",
    });

    // Create a download link and trigger it to download the .zip file
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blobObject);
    link.download = "Customer charges.zip"; // Ensure to download as .zip
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };


  //Bulk upload modal

  const downloadBlob = (base64Blob: string) => {
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    const blobObject = new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blobObject);
    link.download = 'ExampleCustomerCharges.xlsx';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleUploadClick = () => {
    setIsUploadModalVisible(true);

  }
  const handleDownloadTemplate = async () => {
    setLoading(true);
    const url =
      ENV_ROUTES.SIM_MANAGEMENT;
    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/customer_charges_template",
      module_name: "Customer charges",
      role_name: role,
      Partner: partner,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
                ...metaData,
      sessionID: sessionId,
    };

    const response = await axios.post(url, { data });
    const resp = JSON.parse(response.data.body);
    const blob = resp.blob;
    console.log(resp);
    if (response.data.statusCode === 200) {
      if (resp.flag === true) {
        notification.success({
          message: 'Success',
          description: 'Successfully exported the record!',
          style: messageStyle,
          placement: 'top',
        });
        downloadBlob(blob);
        fetchData();

        setLoading(false);
        handleUploadModalClose()
      } else {
        console.log('Error message:', resp.message);
        Modal.error({
          title: 'Export Error',
          content: resp.message,
          centered: true,
        });
      }
    } else {
      console.log('Unexpected status code:', response.data.statusCode);
      Modal.error({
        title: 'Export Error',
        content: resp.message,
        centered: true,
      });
    }
  };
  const handleUploadModalClose = () => {
    setIsUploadModalVisible(false);
  };

  const handleUpload = async (blob: string) => {
    try {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      let flag: string = appendChecked ? "append" : "overwrite";

      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/upload_customer_charges_data",
        module_name: "Customer charges",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
        blob: blob, // Include the Blob in the data
      };

      const response = await axios.post(url, { data });

      const resp = JSON.parse(response.data.body);
      if (response.data.statusCode === 200) {
        if (resp.flag === true) {
          setIsUploadModalVisible(false)
          notification.success({
            message: 'Success',
            description: 'Successfully uploaded!',
            placement: 'top',
          });
          fetchData();

        } else {
          Modal.error({
            title: 'Import Error',
            content: resp.message,
            centered: true,
            onOk: handleErrorModalClose,
            onCancel: handleErrorModalClose
          });
        }
      } else {
        Modal.error({
          title: 'Import Error',
          content: resp.message,
          centered: true,
          onOk: handleErrorModalClose,
          onCancel: handleErrorModalClose
        });
      }
    } catch (error) {
      console.error('Error during file upload:', error);
      Modal.error({
        title: 'Import Error',
        content: 'There was an error uploading the file.',
        centered: true,
        onOk: handleErrorModalClose,
        onCancel: handleErrorModalClose
      });

    }
  }
  const handleErrorModalClose = () => {
    setIsUploadModalVisible(false)
  }
  const handleChange = (info: any) => {
    if (info.file.status === 'done') {
      setIsFileSelected(true);
      let blob;
      const file = info.file.originFileObj; // Get the file object
      const reader = new FileReader();
      reader.onload = (e: any) => {
        // Get the file data URL (Base64 string)
        blob = e.target.result;
        handleUpload(blob)
        setUploadKey(Date.now());
      };

      if (blob) {
      }

      reader.readAsDataURL(file); // Read the file as data URL
    } else if (info.file.status === 'error') {
      // Handle upload error
      message.error('Upload failed.');
    }
    else if (info.file.status === 'removed') {
      setIsFileSelected(false);
      setAppendChecked(false);
      setOverwriteChecked(false);
    }
  };
  const uploadProps = {
    key: uploadKey,
    accept: '.xlsx, .xls',
    beforeUpload: (file: any) => {
      // Check if file is an Excel file
      const isExcel = file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || file.type === 'application/vnd.ms-excel';
      if (!isExcel) {
        message.error('You can only upload Excel files!');
      }
      return isExcel;
    },
    onChange: handleChange,
  };
  const handleAppendChange = (e: any) => {
    setAppendChecked(e.target.checked);
    if (e.target.checked) setOverwriteChecked(false);
  };
  const handleOverwriteChange = (e: any) => {
    setOverwriteChecked(e.target.checked);
    if (e.target.checked) setAppendChecked(false);
  };
  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  const disableFutureDates = (current: any) => {
    return current && current > dayjs().endOf("day");
  };

  return (
    <>
      <Suspense
        fallback={
          <div className="flex justify-center items-center h-screen">
            <Spin size="large" />
          </div>
        }
      >
        <div className="relative">
        <div className="pr-4 pl-4  pt-2 flex md:flex-row md:items-center md:justify-between mt-1 mb-4 space-y-4">
          {/* Search and Advanced Filter Container */}
          <div className="flex space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last ">
            {features.includes("Search-Customer charges") && (
              <TableSearch
                searchTerm={searchTerm}
                setSearchTerm={setSearchTerm}
                tableName={"optimization_smi_result"}
                headerMap={headerMap}
              // loader={loading}
              />
            )}
              {features.includes("Advanced filter-Customer charges") && (
              <AdvancedMultiFilter
                showAdvanced={showAdvanced}
                setShowAdvanced={setShowAdvanced}
                onFilter={handleFilter}
                onReset={handleReset}
                headers={headers}
                headerMap={headerMap}
                tableName={"optimization_smi_result"}
              />
              )}
            </div>
              {/* Export and ColumnFilter Container */}
              <div className="flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2  md:order-none order-first pb-2 md:pb-4">
            {features.includes("Upload-Customer charges") && (
              <button className="save-btn" onClick={handleUploadClick}>
                {/* <ArrowUpTrayIcon className="h-5 w-5 text-black-500 mr-2" /> */}
                <span>Upload</span>
              </button>
            )}
              {features.includes("Export-Customer charges") && (
              <button className="save-btn" onClick={handleExportModalOpen}>
                {/* <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" /> */}
                <span>Export</span>
              </button>
              )}
              <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
              />

            </div>
          </div>

          <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
            <RevTableComponent
              headers={headers}
              headerMap={headerMap}
              initialData={tableData}
              searchQuery={searchTerm}
              visibleColumns={visibleColumns}
              itemsPerPage={100}
              // selectedDate={selectedDate} 
              // handleDateChange={handleDateChange} 
              moduleName="Customer charges"
              pagination={pagination}
              advancedFilters={filteredData}
              onDateChange={() => { }}
              allowedActions={allowedActions}
            />
          </div>
          <Modal
            title={
              <span className="font-semibold text-xl space-y-3">
                Export Output
              </span>
            }
            visible={isExportModalOpen}
            onCancel={() => {
              handleExportModalClose();
              setDateRange([null, null]);
            }}
            footer={null}
            centered
            afterClose={() => setDateRange([null, null])}
            style={{ top: "-4%" }}
          >
            {exportLoading ? (
              <div className="flex justify-center items-center h-56">
                <Spin size="large" />
              </div>
            ) : (
              <div className="flex flex-col space-y-4">
                <div className="">
                  <label>
                    Customer<span className="text-red-500">*</span>
                  </label>
                  <Select
                    options={customerOptions.map((option: string) => ({
                      label: option,
                      value: option,
                    }))}
                    onChange={handleCustomerChange}
                    value={selectedCustomer ? { label: selectedCustomer, value: selectedCustomer } : null}
                    isClearable
                  />
                  {exportCustomerError && (<span className="text-red-500">Please Select Customer</span>)}

                </div>
                <div className="">
                  <label>
                    Sessions
                  </label>
                  <Select
                    options={sessionOptions.map((option: string) => ({
                      label: option,
                      value: option,
                    }))}
                    onChange={handleSessionChange}
                    value={selectedSessions.length > 0 ? selectedSessions.map((option: any) => ({ label: option, value: option })) : null}
                    isMulti
                    isDisabled={!selectedCustomer}
                  />
                </div>
                <div className="flex space-x-4 justify-center">
                  <button className="cancel-btn" onClick={() => {
                    handleExportModalClose();
                  }}>
                    Cancel
                  </button>
                  <button className="save-btn" onClick={handleExport}>
                    Export
                  </button>
                </div>
              </div>
            )}

          </Modal>
          <Modal
            title="Upload Files"
            visible={isUploadModalVisible}
            onCancel={handleUploadModalClose}
            footer={null} // No default footer buttons
            centered
            width={400}
          //  styles={{ body: { height: '150px' } }}

          >
              <div className="flex flex-col gap-4">
                        <div className="flex flex-col md:flex-row gap-4 justify-center m-auto p-4">
                          <Upload {...uploadProps} className="w-full md:w-auto">
                              <button className="w-[200px] md:w-full upload-btn disabled:cursor-not-allowed">
                              <span className="mr-2"><UploadOutlined /></span>
                                Upload
                              </button>
                          </Upload>
                              <button
                                onClick={handleDownloadTemplate}
                                className=" w-[200px] md:w-full upload-btn disabled:cursor-not-allowed"
                                // disabled={!appendChecked && !overwriteChecked}
                              >
                                <span className="mr-2"><DownloadOutlined /></span>
                                Download Template
                              </button>
                        </div>
                      </div>
          </Modal>
        </div>
      </Suspense>
      <div>
      </div>
    </>

  );

};

export default CustomerCharges;
