// stores/logoStore.ts
import { create } from 'zustand';

interface SearchState {
    searchData: any;
    setSearchData: (searchData: any) => void;
    advancedSearchData: any;
    setAdvancedSearchData: (advancedSearchData: any) => void;
    activeFilters: any;
    setActiveFilters: (activeFilters: any) => void;
    combineAdnvaceSearchData: any;
    setCombineAdnvaceSearchData: (combineAdnvaceSearchData: any) => void;
    optimizationErrorsData: any;
    setOptimizationErrorsData: (optimizationErrorsData: any) => void;

    glCodeTableData: any;
    setGLCodeTableData: (glCodeTableData: any) => void;

    serviceProviderData: any;
    setserviceProviderData: (serviceProviderData: any) => void;

    billableOnSuspensionData: any;
    setbillableOnSuspensionData: (billableOnSuspensionData: any) => void;

    withoutAPISearchData: any;
    setWithoutAPISearchData: (withoutAPISearchData: any) => void;
    optimizationErrorsPagination: any | null;
    setOptimizationErrorsPagination: (optimizationErrorsPagination: any | null) => void;
    isSearchComponentCall: boolean;
    setIsSearchComponentCall: (isSearchComponentCall: boolean) => void;

    searchTerm: string;
    setSearchTerm: (searchTerm: string) => void;

    detailsRedirectedSearchTerm: string;
    setDetailsRedirectedSearchTerm: (value: string) => void
    detailsRedirectedFilters: any;
    setDetailsRedirectedFilters: (value: any) => void
    isRedirectedFromDetails: boolean;
    setIsRedirectedFromDetails: (value: boolean) => void
}

export const useSearchStore = create<SearchState>((set) => ({
    searchData: {},
    setSearchData: (searchData: string) => set({ searchData }),
    advancedSearchData: {},
    setAdvancedSearchData: (advancedSearchData: string) => set({ advancedSearchData }),
    activeFilters: {},
    setActiveFilters: (activeFilters: string) => set({ activeFilters }),
    combineAdnvaceSearchData: {},
    setCombineAdnvaceSearchData: (combineAdnvaceSearchData: string) => set({ combineAdnvaceSearchData }),
    optimizationErrorsData: [],
    setOptimizationErrorsData: (optimizationErrorsData: string) => set({ optimizationErrorsData }),

    glCodeTableData: [],
    setGLCodeTableData: (glCodeTableData: string) => set({ glCodeTableData }),

    serviceProviderData: [],
    setserviceProviderData: (serviceProviderData: string) => set({ serviceProviderData }),

    billableOnSuspensionData: [],
    setbillableOnSuspensionData: (serviceProviderData: string) => set({ serviceProviderData }),

    withoutAPISearchData: [],
    setWithoutAPISearchData: (withoutAPISearchData: string) => set({ withoutAPISearchData }),
    optimizationErrorsPagination: null,
    setOptimizationErrorsPagination: (optimizationErrorsPagination: string) => set({ optimizationErrorsPagination }),
    isSearchComponentCall: false,
    setIsSearchComponentCall: (isSearchComponentCall: boolean) => set({ isSearchComponentCall }),

    searchTerm: "",
    setSearchTerm: (searchTerm) => set({ searchTerm }),

    detailsRedirectedSearchTerm: "",
    setDetailsRedirectedSearchTerm: (detailsRedirectedSearchTerm) => set({ detailsRedirectedSearchTerm }),
    detailsRedirectedFilters: {},
    setDetailsRedirectedFilters: (detailsRedirectedFilters) => set({ detailsRedirectedFilters }),
    isRedirectedFromDetails: false,
    setIsRedirectedFromDetails: (isRedirectedFromDetails) => set({ isRedirectedFromDetails }),
}));
