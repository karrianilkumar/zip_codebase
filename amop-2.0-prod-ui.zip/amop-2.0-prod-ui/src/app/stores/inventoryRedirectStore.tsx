import { create } from 'zustand';

interface InventoryRedirectStore {
  filters: {
    service_provider: string;
    start_date?: string;
    end_date?: string;
    created_date?: string[];   // Optional new date range key for simVsService and serviceVsStatus
    date_activated?: string[]; // Optional new date range key for simActivation
    // tenant?: string; // Uncomment if tenant filter is required
  };
  isRedirected: boolean;
  setFilters: (filters: Partial<InventoryRedirectStore['filters']>) => void;
  setRedirected: (redirected: boolean) => void;
  clearFilters: () => void;
  totalFeatures: any[];
  setTotalFeatures: (totalFeatures: any[]) => void
  selectedFeatures: any[];
  setSelectedFeatures: (selectedFeatures: any[]) => void

  tabNames: { key: string; name: string; }[];
  addTab: (key: string, name: string) => void;
  removeTab: (key: string) => void;
}

export const useInventoryRedirectStore = create<InventoryRedirectStore>((set) => ({
  filters: {
    service_provider: '',
    start_date: undefined,
    end_date: undefined,
    created_date: undefined,
    date_activated: undefined,
    // tenant: '',
  },
  isRedirected: false,

  setFilters: (newFilters) =>
    set((state) => {
      // If created_date or date_activated present in newFilters, remove start_date and end_date to avoid conflict
      const hasCreatedDate = 'created_date' in newFilters && newFilters.created_date !== undefined;
      const hasDateActivated = 'date_activated' in newFilters && newFilters.date_activated !== undefined;

      let updatedFilters = {
        ...state.filters,
        ...newFilters,
      };

      if (hasCreatedDate || hasDateActivated) {
        updatedFilters = {
          ...updatedFilters,
          // start_date: undefined,
          // end_date: undefined,
        };
      }

      return { filters: updatedFilters };
    }),

  setRedirected: (redirected) =>
    set({ isRedirected: redirected }),

  clearFilters: () =>
    set({
      filters: {
        service_provider: '',
        // start_date: undefined,
        // end_date: undefined,
        created_date: undefined,
        date_activated: undefined,
        // tenant: '',
      },
      isRedirected: false,
    }),
  totalFeatures: [],
  setTotalFeatures: (totalFeatures: any[]) => set({ totalFeatures }),
  selectedFeatures: [],
  setSelectedFeatures: (selectedFeatures: any[]) => set({ selectedFeatures }),

  tabNames: [],
  addTab: (key, name) =>
    set((state) => ({
      tabNames: [...state.tabNames, { key, name }],
    })),
  removeTab: (key) =>
    set((state) => ({
      tabNames: state.tabNames.filter((action) => action.key !== key),
    })),
}));
