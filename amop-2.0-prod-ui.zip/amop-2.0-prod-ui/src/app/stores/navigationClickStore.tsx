// stores/navigationClickStore.ts
import create from 'zustand';

interface NavigationClickStore {
  clickTime: string | null;
  setClickTime: (time: string) => void;
}

export const useNavigationClickStore = create<NavigationClickStore>((set) => ({
  clickTime: null,
  setClickTime: (time) => set({ clickTime: time }),
}));
