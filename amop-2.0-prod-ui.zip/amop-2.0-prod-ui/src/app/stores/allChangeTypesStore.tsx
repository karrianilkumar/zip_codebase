import create from 'zustand';

interface AllChangeTypesState {
  isValidated: boolean;
  setIsValidated: (value: boolean) => void;
  validationTrigger: number;
  setValidationTrigger: () => void;
  isAllChangeType: boolean;
  setIsAllChangeType: (value: boolean) => void;
  activeChange: string;
  setActiveChange: (value: string) => void;
  allChangeTypesDevices: any;
  setAllChangeTypesDevices: (value: any ) => void;
  successFullChangeTypes: any;
  setsuccessFullChangeTypes: (value: any ) => void;
  successFullScreenOrders: any;
  setsuccessFullScreenOrders: (value: any ) => void;
}

export const useAllChangeTypesStore = create<AllChangeTypesState>((set) => ({
  isValidated: false, // Default value
  setIsValidated: (value) => set({ isValidated: value }),
  validationTrigger: 0, // Default value
  setValidationTrigger: () => set((state) => ({
    validationTrigger: state.validationTrigger + 1
  })),
  isAllChangeType: false, // Default value
  setIsAllChangeType: (value) => set({ isAllChangeType: value }),
  activeChange: "Devices",
  setActiveChange: (value) => set({ activeChange: value }),
  allChangeTypesDevices: { iccid: [], imei: [], Devices: [], isICCID:true},
  setAllChangeTypesDevices: (allChangeTypesDevices) => set({ allChangeTypesDevices }),
  successFullChangeTypes: [],
  setsuccessFullChangeTypes: (value) => set({ successFullChangeTypes: value }),
  successFullScreenOrders: [],
  setsuccessFullScreenOrders: (value) => set({ successFullScreenOrders: value }),
}));
