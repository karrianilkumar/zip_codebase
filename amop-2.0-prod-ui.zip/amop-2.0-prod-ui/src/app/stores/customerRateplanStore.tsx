import create from 'zustand';

interface CustomerRatePlanState {
    customerShowActive: boolean;
    setCustomerShowActive: (value: boolean) => void;
    emailConditionModal: boolean;
    setEmailConditionModal: (value: boolean) => void;
    showAdvanced: boolean; // Add this
  setShowAdvanced: (value: boolean) => void; // Add this
}

export const useCustomerRatePlanStore = create<CustomerRatePlanState>((set) => ({
  customerShowActive: true, // Default value
  setCustomerShowActive: (value) => set({ customerShowActive: value }),
  emailConditionModal: true, // Default value
  setEmailConditionModal: (value) => set({ emailConditionModal: value }),
  showAdvanced: false, // Default value
  setShowAdvanced: (value) => set({ showAdvanced: value }),
}));
