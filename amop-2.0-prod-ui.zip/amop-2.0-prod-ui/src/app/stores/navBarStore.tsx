// store/sidebarStore.ts
import { create } from 'zustand';

interface SidebarState {
  isExpanded: boolean;
  setIsExpanded: (title: boolean) => void;
  isDeploying:boolean;
  setIsDeploying: (isDeploying: boolean) => void;
  deployMsg:string;
  setDeployMsg: (deployMsg: string) => void;
}

export const useSidebarStore = create<SidebarState>((set) => ({
  isExpanded: true,
  setIsExpanded: (isExpanded: boolean) => set({ isExpanded }),
  isDeploying: false,
  setIsDeploying: (isDeploying: boolean) => set({ isDeploying }),
  deployMsg: "",
  setDeployMsg: (deployMsg: string) => set({ deployMsg }),
}));
