import create from "zustand";

interface ExportState {
  exports: { key: string; popupHeading: string; loading: boolean }[]; // Track multiple exports
  addExport: (key: string, popupHeading: string) => void;
  removeExport: (key: string) => void;

  revActions: { key: any; id: any }[]; // Track multiple exports
  addRevAction: (key: any, id: any) => void;
  removeRevAction: (key: any) => void;
}

export const exportLoadingStore = create<ExportState>((set) => ({
  exports: [],
  addExport: (key, popupHeading) =>
    set((state) => ({
      exports: [...state.exports, { key, popupHeading, loading: true }],
    })),
  removeExport: (key) =>
    set((state) => ({
      exports: state.exports.filter((exportItem) => exportItem.key !== key),
    })),

    revActions: [],
    addRevAction: (key, id) =>
    set((state) => ({
      revActions: [...state.revActions, { key, id }],
    })),
    removeRevAction: (key) =>
    set((state) => ({
      revActions: state.revActions.filter((action) => action.key !== key),
    })),
}));
