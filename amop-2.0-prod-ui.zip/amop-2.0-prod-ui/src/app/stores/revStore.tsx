// stores/revStore.tsx
import { create } from 'zustand';

interface RevState {
  revRows:any[]
  setRevRows:(revRows:any)=>void
  revActionRows:any[]
  setRevActionRows:(revActionRows:any)=>void
  revHeaders:any[]
  setRevHeaders:(revRows:any)=>void
  revHeaderMap:any
  setRevHeaderMap:(revHeaderMap:any)=>void
  isClosed:boolean
  setIsClosed:(isClosed:boolean)=>void
  showVarianceStatus:boolean;
  setShowVarianceStatus:(value: boolean) => void;
}

export const useRevStore = create<RevState>((set) => ({
    revRows:[],
    setRevRows:(revRows:any)=>set({revRows}),
    revActionRows:[],
    setRevActionRows:(revActionRows:any)=>set({revActionRows}),
    revHeaders:[],
    setRevHeaders:(revHeaders:any)=>set({revHeaders}),
    revHeaderMap:{},
    setRevHeaderMap:(revHeaderMap:any)=>set({revHeaderMap}),
    isClosed:false,
    setIsClosed:(isClosed:boolean)=>set({isClosed}),
    showVarianceStatus:true,
    setShowVarianceStatus: (value) => set({ showVarianceStatus: value }),
}));
