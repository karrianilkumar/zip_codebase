// stores/revStore.tsx
import { create } from 'zustand';

interface PerformanceLogState {
  logStatement: string
  setLogStatement: (logStatement: string) => void
  getTargetTenantProvider: (value: string) => string;
  IsTargetTenantProvider: (value: string) => boolean;

}

export const PerformanceLogStore = create<PerformanceLogState>((set) => ({
  logStatement: "",
  setLogStatement: (logStatement: any) => set({ logStatement }),
  getTargetTenantProvider: (value: string) => {
    // Step 1: validate input
    if (!value || value === "None" || value === "null") {
      return value;
    }

    try {
      // Step 2: get mapping from localStorage
      const mapStr = localStorage.getItem("tenant_provider_map");
      if (!mapStr) return value;

      const tenantMap = JSON.parse(mapStr) as Record<string, string | null>;

      // Step 3: lookup match
      const match = tenantMap[value];

      // Step 4: validate match
      if (match && match !== "None" && match !== "null") {
        return match;
      }

      return value;
    } catch (err) {
      console.error("Error parsing tenant_provider_map:", err);
      return value;
    }
  },
  IsTargetTenantProvider: (value: string) => {
    // Step 1: validate input
    if (!value || value === "None" || value === "null") {
      return false;
    }

    try {
      // Step 2: get mapping from localStorage
      const mapStr = localStorage.getItem("tenant_provider_map");
      if (!mapStr) return false;

      const tenantMap = JSON.parse(mapStr) as Record<string, string | null>;

      // Step 3: lookup match
      const match = tenantMap[value];

      // Step 4: validate match
      if (match && match !== "None" && match !== "null") {
        return true;
      }

      return false;
    } catch (err) {
      console.error("Error parsing tenant_provider_map:", err);
      return false;
    }
  },
}));
