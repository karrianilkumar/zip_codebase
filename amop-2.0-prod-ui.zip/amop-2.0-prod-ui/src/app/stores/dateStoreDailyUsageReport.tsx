import { create } from 'zustand';
import dayjs from 'dayjs';

interface DateRangeState {
  startDateDailyReport: string | null;
  endDateDailyReport: string | null;
  setDateRange: (start: string | null, end: string | null) => void;
  setToday: () => void;
  setCurrentWeek: () => void;
  setCurrentMonth: () => void;
  setActionHistoryCurrentMonth: () => void;
  setCustomRange: (start: string | null, end: string | null) => void;
}

export const useDateRangeStore = create<DateRangeState>((set) => ({
  // Initialize with today's date
  startDateDailyReport: dayjs().format('YYYY-MM-DD'),
  endDateDailyReport: dayjs().format('YYYY-MM-DD'),

  // General setter
  setDateRange: (start, end) => set({ 
    startDateDailyReport: start, 
    endDateDailyReport: end 
  }),

  // Preset date range setters
  setToday: () => {
    const today = dayjs().format('YYYY-MM-DD');
    set({ 
      startDateDailyReport: today, 
      endDateDailyReport: today 
    });
  },

  setCurrentWeek: () => {
    const startOfWeek = dayjs().startOf('week').format('YYYY-MM-DD');
    const endOfWeek = dayjs().endOf('week').format('YYYY-MM-DD');
    set({ 
      startDateDailyReport: startOfWeek, 
      endDateDailyReport: endOfWeek 
    });
  },

  setCurrentMonth: () => {
    const startOfMonth = dayjs().startOf('month').format('YYYY-MM-DD');
    const endOfMonth = dayjs().endOf('month').format('YYYY-MM-DD');
    set({ 
      startDateDailyReport: startOfMonth, 
      endDateDailyReport: endOfMonth 
    });
  },

  setActionHistoryCurrentMonth: () => {
    const startOfMonth = dayjs().subtract(1, "month").date(dayjs().date()).format("YYYY-MM-DD");
        const endOfMonth = dayjs().format("YYYY-MM-DD");
    set({ 
      startDateDailyReport: startOfMonth, 
      endDateDailyReport: endOfMonth 
    });
  },

  // Custom range setter
  setCustomRange: (start, end) => {
    set({ 
      startDateDailyReport: start, 
      endDateDailyReport: end 
    });
  },
}));