// stores/logoStore.ts
import { create } from 'zustand';

interface LogoState {
  // logoUrl: string | null;
  swiched20User: boolean;
  title: string;
  // setLogoUrl: (url: string) => void;
  setTitle: (title: string) => void;
  setSwiched20User: (swiched20User: boolean) => void;
}

export const useLogoStore = create<LogoState>((set) => ({
  // logoUrl: null,
  title: '',
  // setLogoUrl: (url: string) => set({ logoUrl: url }),
  setTitle: (title: string) => set({ title }),
  swiched20User:false,
  setSwiched20User: (swiched20User: boolean) => set({ swiched20User }),

}));
