// useCrossProviderStore.ts
import create from 'zustand';

interface CrossProviderStore {
  crossProviderCustomerOptimizationStore: boolean;
  setCrossProviderCustomerOptimizationStore: (value: boolean) => void;
  usageByLineFilter: boolean;
  setUsageByLineFilter: (value: boolean) => void;
  usageByLineFilterData: any;
  setUsageByLineFilterData: (value: any) => void;
}

const useCrossProviderStore = create<CrossProviderStore>((set) => ({
  crossProviderCustomerOptimizationStore: false,
  setCrossProviderCustomerOptimizationStore: (value) => set({ crossProviderCustomerOptimizationStore: value }),
  usageByLineFilter: false,
  setUsageByLineFilter: (usageByLineFilter) => set({ usageByLineFilter }),
  usageByLineFilterData: [],
  setUsageByLineFilterData: (usageByLineFilterData) => set({ usageByLineFilterData }),

}));

export default useCrossProviderStore;