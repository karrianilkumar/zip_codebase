// stores/logoStore.ts
import { create } from 'zustand';

interface PartnerAPIState {
  selectedEnvironment: string ;
  selectedPartner: string;
  setSelectedEnvironment: (selectedEnvironment: string) => void;
  setSelectedPartner: (selectedPartner: string) => void;
}

export const usePartnerAPIStore = create<PartnerAPIState>((set) => ({
  selectedEnvironment: '',
  selectedPartner: '',
  setSelectedEnvironment: (selectedEnvironment: string) => set({ selectedEnvironment }),
  setSelectedPartner: (selectedPartner: string) => set({ selectedPartner }),
}));
