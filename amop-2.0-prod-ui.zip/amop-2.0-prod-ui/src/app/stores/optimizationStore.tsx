// stores/revStore.tsx
import { create } from 'zustand';

interface OptimizationState {
    optimizationRow:any
    setOptimizationRow:(optimizationRow:any)=>void
    optimizationType:string
    setOptimizationType:(optimizationType:string)=>void
    chargesSummaryRows:any
    setChargesSummaryRows:(chargesSummaryRows:any)=>void
    IDActionMap:any
    setIDActionMap:(IDActionMap:any)=>void
    selectAll:boolean
    setSelectAll:(selectAll:boolean)=>void
    deselectedRowIds: number[]; // New state for deselected row IDs
    setDeselectedRowIds: (ids: number[]) => void; // New setter for deselected row IDs
}

export const useOptimizationStore = create<OptimizationState>((set) => ({
    optimizationRow:null,
    setOptimizationRow:(optimizationRow:any)=>set({optimizationRow}),
    optimizationType:"",
    setOptimizationType:(optimizationType:any)=>set({optimizationType}),
    chargesSummaryRows:[],
    setChargesSummaryRows:(chargesSummaryRows:any)=>set({chargesSummaryRows}),
    IDActionMap:{},
    setIDActionMap:(IDActionMap:any)=>set({IDActionMap}),
    selectAll:false,
    setSelectAll:(selectAll:boolean)=>set({selectAll}),
    deselectedRowIds: [], // Initialize the deselected row IDs
    setDeselectedRowIds: (ids: number[]) => set({ deselectedRowIds: ids }), // Setter for deselected row IDs
}));
