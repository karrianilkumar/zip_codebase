"""
@Author1 : Phaneendra.Y
Created Date: 03-02-26
"""
# Importing the necessary Libraries
import os
import time
import logging
import requests
import xml.etree.ElementTree as ET
import xmltodict
import json
from datetime import datetime, date, timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading
import numpy as np
import pandas as pd

## Importing the necessary modules
from common_utils.db_utils import DB
from common_utils.email_trigger import send_email

# Database configuration
common_utils_db_config = {
     "host": os.environ["HOST"],
     "port": os.environ["PORT"],
     "user": os.environ["USER"],
     "password": os.environ["PASSWORD"],
 }

##function caller where the functions begins
def funtion_caller(data,path):
    """
    Main function caller that handles database configuration setup and routes requests.
    
    Args:
        data (dict): Request data containing user/tenant information
        path (str): API endpoint path being called
        
    Returns:
        Result of the called endpoint function or error response
    """
    # Route to appropriate endpoint handler
    if path == "/run_webbing_sync":
        result = run_webbing_sync(data)
    ##else condition to handle the invalid path method
    else:
        result = {"flag":False,"error": "Invalid path or method"}
        logging.info(f"Invalid path or method requested: {path}")
    return result

## webbing carrier daily sync function
def run_webbing_sync(data):
    """
    Webbing Carrier Daily Sync

    Performs the daily carrier sync for Webbing by:
    - Retrieving device details and usage data from the carrier
    - Retrieving products/rate plans from the carrier
    - Converting usage values to standard units
    - Storing data in staging tables and syncing it to main AMOP tables
    - Recording sync progress and status in audit tables
    - Sending success or failure notification emails

    Returns:
        dict: Sync result with success or failure details.
    """
    logging.info(f"Received data webbing sync: %s", data)
    start_time = time.time()
    start_time_dt = datetime.now()
    start_time_ts = time.time()
    
    # Fetch required fields
    service_provider_name = data.get("service_provider_name")
    username              = data.get("username")
    service_provider_id   = data.get("service_provider_id")
    integration_id        = data.get("integration_id")
    tenant_id             = data.get("tenant_id")
    tenant_name           = data.get("tenant_name")
    tenant_db_config      = data.get("tenant_db_config", {})
    api_details_map       = data.get("api_details_map", {})
    db_name               = data.get("db_name", {})
    progress_tracker_id   = data.get("progress_tracker_id", {})
    
    # Fetch delayed_days from the request data
    delayed_days          = data.get("delayed_days", 1)
    today = datetime.now()
    start_date_obj = today - timedelta(days=delayed_days)
    end_date_obj = today - timedelta(days=delayed_days)
    start_date = start_date_obj.strftime("%Y-%m-%dT00:00:00Z")
    end_date = end_date_obj.strftime("%Y-%m-%dT23:59:59Z")
    data['start_date'] = start_date
    data['end_date'] = end_date
    data["usage_date"] = start_date_obj.strftime("%Y-%m-%d %H:%M:%S")
    data["created_by"] = username
    
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Initialize tracking variables for email
    staging_table_cleanup = False
    devices_fetch = False
    usage_fetch = False
    products_fetch = False
    staging_insert = False
    staging_to_main_tables_sync = False
    device_usage_sync = False
    history_tables_sync = False
    email_trigger = False
    total_records_processed = 0
    inserted_count = 0
    updated_count = 0
    usage_count = 0
    products_count = 0
    total_devices_count = 0
    module_name = "Carrier Sync"
    
    logging.info(f"### run_webbing_sync devices and {tenant_name} time is {now}")
    logging.info(f"### run_webbing_sync devices and {tenant_name} delayed_days: {delayed_days}")
    
    #Step 1: Database connection
    try:
        tenant_database = DB(db_name, **tenant_db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_db_config)
    except Exception as e:
        logging.error(f"### run_webbing_sync and {tenant_name} DB connection error: %s", e)
        return {"flag":False,"message": "DB connection failed in run_webbing_sync", "details": str(e)}
    
    ### send email for initiating sync 
    sync_data = {
        "Sync Type": "Daily Sync",    
        "Partner Name": tenant_name,    
        "Carrier Name": service_provider_name,    
        "Start Time": start_time_dt.strftime("%m-%d-%Y %H:%M:%S"),    
        "System / Job Name": "Scheduler"
    }
    trigger_sync_email(
        template_name="Sync Initiated",
        subject=f"Sync Initiated - {tenant_name} - {service_provider_name} - Daily Sync - {start_date_obj.strftime('%m-%d-%Y')}",
        data_dict=sync_data,
        tenant_name=tenant_name,
        log_prefix="### run_webbing_sync Sync Initiated"
    )
    
    #Step 2: Progress Tracking - Staging cleanup started
    try:
        update_progress_tracker(progress_tracker_id, current_status="Staging cleanup started", status="In Progress",
                                 common_utils_database=common_utils_database, action="update", now=now, progress=5, data=data)
        logging.info(f"### run_webbing_sync devices and {tenant_name} Staging cleanup Started")
    except Exception as e:
        logging.exception(f"### run_webbing_sync devices and {tenant_name} Error updating progress tracker: {e}")
    
    try:
        ##Step 3: Cleaning the staging tables
        cleanup_response = clean_staging_table(
            tenant_database, 
            [
                "webbing_carrier_sync_staging",
                "webbing_carrier_rate_plan_stagging"
            ], 
            username
        )
        logging.info(f"### run_webbing_sync devices and {tenant_name} cleanup_response: {cleanup_response}")
        
        if all(result.get("flag", False) for result in cleanup_response.get("details", {}).values()):
            cleanup_message = "Successful"
            cleanup_progress = 10
            cleanup_status = "In Progress"
            staging_table_cleanup = True
        else:
            cleanup_message = "Failed"
            cleanup_progress = 100
            cleanup_status = "Failed"

        logging.info(f"### run_webbing_sync devices and {tenant_name} Staging cleanup {cleanup_message}: {cleanup_response.get('message')}")
        
        #Progress Tracking: Update progress tracker - Staging cleanup status
        try:
            update_progress_tracker(progress_tracker_id, current_status=f"Staging cleanup {cleanup_message}", status=cleanup_status,
                                     common_utils_database=common_utils_database, action="update", now=now, progress=cleanup_progress, data=data)
            logging.info(f"### run_webbing_sync devices and {tenant_name} Staging cleanup {cleanup_message}")
            if cleanup_message == "Failed":
                raise Exception("Staging tables cleanup failed")
        except Exception as e:
            logging.exception(f"### run_webbing_sync devices and {tenant_name} Error updating progress tracker: {e}")
            raise Exception("Staging tables cleanup failed")
        
        if not cleanup_response.get("flag"):
            return {"flag": False, "message": "Staging cleanup failed", "details": cleanup_response.get("details")}
        
        ##Step 4: Billing Period Logic
        billing_info = get_or_create_billing_period(
            tenant_id=tenant_id,
            service_provider_id=service_provider_id,
            service_provider_name=service_provider_name,
            tenant_database=tenant_database,
            common_utils_database=common_utils_database,
            progress_tracker_id=progress_tracker_id,
            billing_cycle_day=1,
            force_end_of_day=True,
            data=data
        )
        
        # Check if billing_info has flag and extract billing_period_id correctly
        if not billing_info.get("flag", True):
            logging.error(f"### run_webbing_sync devices and {tenant_name} - Billing period error: {billing_info.get('message')}")
            return billing_info
            
        billing_period_id = billing_info["billing_period_id"]
        data["billing_period_id"] = billing_period_id
        billing_cycle_start_date = billing_info["billing_period_details"]["billing_cycle_start_date"]
        billing_cycle_end_date = billing_info["billing_period_details"]["billing_cycle_end_date"]

        # Update progress tracker - Billing period determined
        try:
            update_progress_tracker(progress_tracker_id, current_status="Billing period determined", status="In Progress", common_utils_database=common_utils_database,
                                     action="update", now=now, progress=15, data=data)
            logging.info(f"### run_webbing_sync devices and {tenant_name} Billing period determined")
        except Exception as e:
            logging.exception(f"### run_webbing_sync devices and {tenant_name} Error updating progress tracker: {e}")

        ##Step 5: Fetch Integration Details
        integration_response = fetch_integration_details(tenant_database, integration_id, tenant_name, tenant_id)
        
        if not integration_response.get("flag"):
            try:
                update_progress_tracker(progress_tracker_id, current_status=f"Integration details fetch failed", status="Failed", 
                                        common_utils_database=common_utils_database, action="update", now=now, progress=100, data=data)
                logging.info(f"### run_webbing_sync devices and {tenant_name} Integration details fetch failed")
            except Exception as e:
                logging.exception(f"### run_webbing_sync devices and {tenant_name} Error updating progress tracker: {e}")
            return integration_response

        # Get the first integration detail from the list
        integration_details_list = integration_response.get("integration_details", [])
        if not integration_details_list:
            try:
                update_progress_tracker(progress_tracker_id, current_status=f"No integration details found", status="Failed",
                                         common_utils_database=common_utils_database, action="update", now=now, progress=100, data=data)
                logging.info(f"### run_webbing_sync devices and {tenant_name} No integration details found")
            except Exception as e:
                logging.exception(f"### run_webbing_sync devices and {tenant_name} Error updating progress tracker: {e}")
            return {"flag": False, "message": "No integration details found"}

        # Get the first integration detail
        integration_detail = integration_details_list[0]
        api_username = integration_detail.get("username")
        api_password = integration_detail.get("password")
        api_ws_key = integration_detail.get("token_value")
        
        #Progress Tracking: Update progress tracker - API credentials fetched
        try:
            update_progress_tracker(progress_tracker_id, current_status=f"API credentials loaded", status="In Progress",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=20, data=data)
            logging.info(f"### run_webbing_sync devices and {tenant_name} API credentials loaded")
        except Exception as e:
            logging.exception(f"### run_webbing_sync devices and {tenant_name} Error updating progress tracker: {e}")
        
        # Fetch API details from the request
        api_limit = api_details_map.get("api_limit", 0)
        retries = api_details_map.get("retries", 0)
        page_limit = api_details_map.get("page_limit", 1000)
        bill_period = api_details_map.get("bill_period", 1)
        
        custom_url1 = data.get("custom_url1", {}).get("url")
        custom_url2 = data.get("custom_url2", {}).get("url")
        get_device_usage_url = data.get("get_device_usage_url", {}).get("url")
        custom_url3 = data.get("custom_url3", {}).get("url")
        
        logging.info(f"### run_webbing_sync devices and {tenant_name} Using get_device_usage_url: {get_device_usage_url}")
        logging.info(f"### run_webbing_sync devices and {tenant_name} Using get_products_url: {custom_url3}")
        
        ##Step 6: Calculate Sync Run Count
        try:
            # Get the latest sync_run_count
            result = tenant_database.get_data(
                table_name="webbing_carrier_sync_staging_audit",
                columns=["sync_run_count", "sync_date"],
                order={"id": "desc"},
                mod_pages={"start": 0, "end": 1}
            )
            
            today_date = datetime.now().date()
            
            if not result.empty:
                last_sync_date = result.iloc[0]["sync_date"]
                
                # Convert to date if it's datetime
                if isinstance(last_sync_date, datetime):
                    last_sync_date = last_sync_date.date()
                
                # Check if last sync was today
                if last_sync_date == today_date:
                    sync_run_count = int(result.iloc[0]["sync_run_count"]) + 1
                    logging.info(f"### Same day sync detected for {tenant_name} - Incrementing sync_run_count to {sync_run_count}")
                else:
                    sync_run_count = 0 
                    logging.info(f"### New day sync detected for {tenant_name} - Resetting sync_run_count to 0")
            else:
                sync_run_count = 0
                logging.info(f"### First sync for {tenant_name} - Setting sync_run_count to 0")
                
        except Exception as e:
            logging.error(f"Error getting sync run count: {e}")
            sync_run_count = 0
        
        logging.info(f"### run_webbing_sync for {tenant_name} - Final sync run count: {sync_run_count}")
        
        ##Step 7: Fetch all device data (active + disconnected)
        try:
            # Update progress - Starting device fetch
            update_progress_tracker(progress_tracker_id, current_status="Fetching device details from carrier", status="In Progress",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=25, data=data)
            
            # Create a cache to track seen devices across both active and disconnected calls
            seen_devices_cache = set()
            
            # Fetch active devices
            try:
                # Update progress - Starting active devices fetch
                update_progress_tracker(progress_tracker_id, current_status="Fetching active devices from carrier", status="In Progress",
                                         common_utils_database=common_utils_database, action="update", now=now, progress=30, data=data)
                logging.info(f"### Fetching active devices from carrier for {tenant_name}")
                
                active_devices_list = fetch_webbing_devices(
                    username=api_username,
                    password=api_password,
                    ws_key=api_ws_key,
                    only_active=True,
                    tenant_name=tenant_name,
                    devices_url=custom_url1,
                    service_url=custom_url2,
                    page_limit=page_limit,
                    tenant_database=tenant_database,
                    service_provider_id=service_provider_id,
                    service_provider_name=service_provider_name,
                    billing_period_id=billing_period_id,
                    sync_run_count=sync_run_count,
                    seen_devices_cache=seen_devices_cache
                )
                
                active_count = len(active_devices_list) if active_devices_list else 0
                devices_fetch = True
                
                # Update progress - Active devices fetched
                update_progress_tracker(progress_tracker_id, current_status=f"Active devices fetched ({active_count} records)", status="In Progress",
                                         common_utils_database=common_utils_database, action="update", now=now, progress=40, data=data)
                logging.info(f"### Active devices fetched for {tenant_name}: {active_count} records")
                
            except Exception as e:
                logging.exception(f"### Error fetching active devices for {tenant_name}: {e}")
                active_devices_list = []
                devices_fetch = False
                raise Exception(f"Failed to fetch active devices")
            
            # Fetch disconnected devices
            try:
                # Update progress - Starting disconnected devices fetch
                update_progress_tracker(progress_tracker_id, current_status="Fetching disconnected devices from carrier", status="In Progress",
                                         common_utils_database=common_utils_database, action="update", now=now, progress=50, data=data)
                logging.info(f"### Fetching disconnected devices from carrier for {tenant_name}")
                
                disconnected_devices_list = fetch_webbing_devices(
                    username=api_username,
                    password=api_password,
                    ws_key=api_ws_key,
                    only_active=False,
                    tenant_name=tenant_name,
                    devices_url=custom_url1,
                    service_url=custom_url2,
                    page_limit=page_limit,
                    tenant_database=tenant_database,
                    service_provider_id=service_provider_id,
                    service_provider_name=service_provider_name,
                    billing_period_id=billing_period_id,
                    sync_run_count=sync_run_count,
                    seen_devices_cache=seen_devices_cache
                )
                
                disconnected_count = len(disconnected_devices_list) if disconnected_devices_list else 0
                
                # Update progress - Disconnected devices fetched
                update_progress_tracker(progress_tracker_id, current_status=f"Disconnected devices fetched ({disconnected_count} records)", status="In Progress",
                                         common_utils_database=common_utils_database, action="update", now=now, progress=60, data=data)
                logging.info(f"### Disconnected devices fetched for {tenant_name}: {disconnected_count} records")
                
            except Exception as e:
                logging.exception(f"### Error fetching disconnected devices for {tenant_name}: {e}")
                disconnected_devices_list = []
            
            # Combine device lists
            all_devices_list = []
            if active_devices_list:
                all_devices_list.extend(active_devices_list)
            if disconnected_devices_list:
                all_devices_list.extend(disconnected_devices_list)
                
            total_devices_count = len(all_devices_list)
            
            # Update progress - All devices fetched
            try:
                update_progress_tracker(progress_tracker_id, current_status=f"All devices fetched ({total_devices_count} total records)", status="In Progress",
                                         common_utils_database=common_utils_database, action="update", now=now, progress=65, data={**data, "total_records_synced": total_devices_count})
                logging.info(f"### All devices fetched for {tenant_name}: {total_devices_count} total records")
            except Exception as e:
                logging.exception(f"### Error updating progress tracker for {tenant_name}: {e}")
            
        except Exception as e:
            logging.exception(f"### run_webbing_sync devices and {tenant_name} Error fetching device data: {e}")
            all_devices_list = []
            devices_fetch = False
            raise Exception(f"Device fetch failed")
        
        ##Step 8: Fetch usage data separately
        try:
            # Update progress - Starting usage data fetch
            update_progress_tracker(progress_tracker_id, current_status="Fetching usage data from carrier", status="In Progress",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=70, data=data)
            logging.info(f"### Fetching usage data from carrier for {tenant_name}")
            
            usage_data_list = fetch_webbing_usage_data(
                username=api_username,
                password=api_password,
                ws_key=api_ws_key,
                tenant_name=tenant_name,
                usage_url=get_device_usage_url,
                page_limit=page_limit,
                delayed_days=delayed_days,
                retries=retries,
                service_provider_id=service_provider_id,
                service_provider_name=service_provider_name,
                billing_period_id=billing_period_id,
                sync_run_count=sync_run_count
            )
            
            usage_count = len(usage_data_list) if usage_data_list else 0
            usage_fetch = True if usage_data_list else False
            logging.info(f"### Usage data fetched for {tenant_name}: {usage_count} records")
            
            # Update progress - Usage data fetched
            update_progress_tracker(progress_tracker_id, current_status=f"Usage data fetched ({usage_count} records)", status="In Progress",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=75, data=data)
            
        except Exception as e:
            logging.exception(f"### Error fetching usage data for {tenant_name}: {e}")
            usage_data_list = []
            usage_fetch = False
            raise Exception(f"Usage data fetch failed")
        
        ##Step 9: Fetch and insert products/rate plans data
        try:
            # Update progress - Starting products fetch
            update_progress_tracker(progress_tracker_id, current_status="Fetching and inserting products/rate plans from carrier", status="In Progress",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=80, data=data)
            logging.info(f"### Fetching and inserting products/rate plans from carrier for {tenant_name}")
            
            # Fetch AND insert products in one call using combined function
            products_result = fetch_and_insert_webbing_products(
                tenant_database=tenant_database,
                username=api_username,
                password=api_password,
                ws_key=api_ws_key,
                tenant_name=tenant_name,
                products_url=custom_url3,
                page_limit=page_limit,
                now=now
            )
            
            products_count = products_result.get("products_count", 0)
            products_fetch = products_result.get("flag", False)
            
            if products_result.get("flag"):
                logging.info(f"### Products/rate plans fetched and inserted successfully for {tenant_name}: {products_count} records")
            else:
                logging.warning(f"### Products/rate plans fetch/insert issue for {tenant_name}: {products_result.get('message')}")
            
            # Update progress - Products fetched and inserted
            update_progress_tracker(progress_tracker_id, current_status=f"Products/rate plans processed ({products_count} records)", status="In Progress",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=85, data=data)
            logging.info(f"### Products/rate plans processed for {tenant_name}: {products_count} records")
            
        except Exception as e:
            logging.exception(f"### Error fetching and inserting products/rate plans for {tenant_name}: {e}")
            products_count = 0
            products_fetch = False
        
        ##Step 10: Insert device data into staging tables
        try:
            staging_insert_response = insert_devices_into_staging_table(
                tenant_database, 
                all_devices_list,
                usage_data_list,
                tenant_name,
                sync_run_count,
                now
            )
            
            staging_insert_flag = staging_insert_response.get("flag")
            staging_insert = staging_insert_flag
            if not staging_insert_flag:
                raise Exception(f"Staging table insert failed")
            
        except Exception as e:
            logging.exception(f"### run_webbing_sync devices and {tenant_name} Error inserting into staging tables: {e}")
            staging_insert_flag = False
            staging_insert_response = {"message": f"Error inserting into staging tables: {str(e)}"}
            raise Exception(f"Staging table insert failed")
        
        ##Step 11: Sync staging to main tables
        try:
            sync_main_response = sync_staging_to_main(
                data=data,
                tenant_database=tenant_database,
                common_utils_database=common_utils_database,
                progress_tracker_id=progress_tracker_id
            )
            
            logging.info(f"### run_webbing_sync - Staging to main sync result: {sync_main_response}")
            
            if sync_main_response.get("flag"):
                staging_to_main_tables_sync = True
                sync_summary = sync_main_response.get("summary", {})
                total_records_processed = sync_summary.get("total_staging_records", 0)
                inserted_count = sync_summary.get("new_devices_inserted", 0)
                updated_count = sync_summary.get("existing_devices_updated", 0)
            else:
                logging.error(f"### run_webbing_sync - Staging to main sync failed: {sync_main_response.get('message')}")
                raise Exception(f"Staging to main sync failed")
                
        except Exception as e:
            logging.exception(f"### run_webbing_sync devices and {tenant_name} Error syncing staging to main: {e}")
            sync_main_response = {"flag": False, "message": f"Error syncing staging to main: {str(e)}"}
            raise Exception(f"Staging to main sync failed")
        
        ##Step 12: Insert/Update device usage table 
        try:
            # Update progress - Starting device usage update
            update_progress_tracker(progress_tracker_id, current_status="Updating device usage table", status="In Progress",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=90, data=data)
            
            device_usage_response = update_device_usage_table(
                data=data,
                tenant_database=tenant_database,
                common_utils_database=common_utils_database
            )
            
            if device_usage_response.get("flag"):
                logging.info(f"### Device usage table updated successfully for {tenant_name}")
                device_usage_sync = True
            else:
                logging.warning(f"### Device usage table update had issues for {tenant_name}: {device_usage_response.get('message')}")
                raise Exception(f"Device usage table update failed")
                
        except Exception as e:
            logging.exception(f"### Error updating device usage table for {tenant_name}: {e}")
            device_usage_response = {"flag": False, "message": f"Error updating device usage: {str(e)}"}
            raise Exception(f"Device usage table update failed")
        
        ##Step 13: Update history tables (cross_provider_device_history, device_history, smi_device_history)
        try:
            # Update progress - Starting history tables update
            update_progress_tracker(progress_tracker_id, current_status="Updating history tables", status="In Progress",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=92, data=data)
            
            history_tables_response = history_table_updates(
                data=data,
                tenant_database=tenant_database,
                common_utils_database=common_utils_database
            )
            
            if history_tables_response.get("flag"):
                logging.info(f"### History tables updated successfully for {tenant_name}: {history_tables_response.get('records_inserted', 0)} inserted, {history_tables_response.get('records_updated', 0)} updated")
                history_tables_sync = True
            else:
                logging.warning(f"### History tables update had issues for {tenant_name}: {history_tables_response.get('message')}")
                raise Exception(f"History tables update failed")
                
        except Exception as e:
            logging.exception(f"### Error updating history tables for {tenant_name}: {e}")
            history_tables_response = {"flag": False, "message": f"Error updating history tables: {str(e)}"}
            raise Exception(f"History tables update failed")
        
        ##Step 14: Calculate execution time and update final progress
        end_time = time.time()
        execution_duration = end_time - start_time
        
        # Get summary from sync_main_response if not already set
        if not total_records_processed:
            sync_summary = sync_main_response.get("summary", {})
            total_records_processed = sync_summary.get("total_staging_records", total_devices_count)
            inserted_count = sync_summary.get("new_devices_inserted", 0)
            updated_count = sync_summary.get("existing_devices_updated", 0)
        
        # Update progress tracker with completion
        sync_successful = staging_insert_flag and sync_main_response.get("flag", False)
        try:
            update_progress_tracker(progress_tracker_id, current_status="Webbing sync completed successfully" if sync_successful else "Webbing sync completed with errors",
                                    status="Completed" if sync_successful else "Failed", common_utils_database=common_utils_database, action="update", now=now, progress=100,
                                    data={**data, "total_records_synced": total_records_processed, "sync_end_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "execution_duration": execution_duration})
        except Exception as e:
            logging.exception(f"### run_webbing_sync devices and {tenant_name} Error updating final progress tracker: {e}")
        
        logging.info(f"### run_webbing_sync devices and {tenant_name} completed in {execution_duration:.2f} seconds")
        
        ### step 15: getting inventory details to send sync details in email in Sync Completion case 
        # Fetch Query from the database based on the module name -> to get counts per status and total usage
        module_query_df = common_utils_database.get_data(
            "export_queries", {"module_name": module_name}
        )
        
        # checking the dataframe is empty or not
        if module_query_df.empty:
            logging.error(f"### No query found for module name: {module_name} for tenant: {tenant_name}")
            # Don't return, just log error and continue with empty data
            result = None
        else:
            # Extract the query string from the DataFrame
            query = module_query_df.iloc[0]["module_query"]
            if not query:
                logging.error(f"### Empty query for module name: {module_name} for tenant: {tenant_name}")
                result = None
            else:
                # Execute the query
                try:
                    result = tenant_database.execute_query(query, params=[service_provider_id])
                except Exception as e:
                    logging.error(f"### Error executing inventory query for {tenant_name}: {e}")
                    result = None
        
        status_variables = {}
        aggregate_usage_bytes = 0
        total_devices = 0
        total_devices_with_usage = 0
        
        # Map result to variables
        if result is not None and not result.empty:
            for _, row in result.iterrows():
                status_name = row['sim_status'].lower() if row['sim_status'] else 'unknown'
                count = row['device_count']
                usage = row['total_usage_bytes']
                devices_with_usage_count = row['devices_with_usage_count']
                
                # Create a dynamic key in the dictionary for each status
                status_variables[f"{status_name}_devices"] = count

                # Add to totals
                total_devices += count
                total_devices_with_usage += devices_with_usage_count
                aggregate_usage_bytes += usage
        
        logging.info(f"### run_webbing_sync - Inventory stats: total_devices={total_devices}, devices_with_usage={total_devices_with_usage}, aggregate_usage_bytes={aggregate_usage_bytes}")

        ### step 16 : sending email in sync successful case  
        # First, create a statuses dictionary that the replace_placeholders_with_table function expects
        statuses_dict = {}
        for status_key, count in status_variables.items():
            # Extract just the status name (remove '_devices' suffix)
            status_name = status_key.replace('_devices', '').title()
            statuses_dict[status_name] = count

        # Construct dynamic sync summary with the special 'statuses' key
        end_time_ts = time.time()
        end_time_dt = datetime.now()
        duration_seconds = int(end_time_ts - start_time_ts)
        duration_mm_ss = f"{duration_seconds // 60}:{duration_seconds % 60:02d}"
        sync_summary_data = {
            "Partner Name": tenant_name,
            "Carrier Name": service_provider_name,
            "Sync Timeline": f"{start_time_dt.strftime('%m-%d-%Y %H:%M:%S')} - {end_time_dt.strftime('%m-%d-%Y %H:%M:%S')} (Duration: {duration_mm_ss} minutes)",            "Device Sync Status": "Success" if sync_successful else "Failed",
            "Total Devices": total_devices,
            "Usage Sync Status": "Success" if usage_fetch else "Failed",
            "Bill Cycle": f"{billing_cycle_start_date.strftime('%m-%d-%Y %H:%M:%S')} - {billing_cycle_end_date.strftime('%m-%d-%Y %H:%M:%S')}",
            "Devices with Usage": total_devices_with_usage,
            "Aggregate Usage": f"{round(aggregate_usage_bytes / (1024 * 1024), 2):,} MB",
            "Error Description": "NA" if sync_successful else "Check logs for details",
            "statuses": statuses_dict
        }
        logging.info(f"### run_webbing_sync sync_summary_data : {sync_summary_data}")

        email_response = trigger_sync_email(
            template_name="Sync Completed",
            subject=f"{tenant_name} - {service_provider_name} - Device and Usage Sync Summary - {start_date_obj.strftime('%m-%d-%Y')}",
            data_dict=sync_summary_data,
            tenant_name=tenant_name,
            log_prefix="### run_webbing_sync Sync Completed"
        )

        # Update current_status based on email response
        if not email_response["flag"]:
            current_status = "Sync Completed but Email Notification Failed"
        else:
            current_status = "Sync Completed & Email sent successfully"
            email_trigger = True

        ## Updating the Sync Completion Email Trigger in Progress Tracker
        try:
            logging.info(f"### run_webbing_sync tenant : {tenant_name} updating the progress tracker for email trigger")
            update_progress_tracker(progress_tracker_id, current_status=current_status, status="Completed",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=100, data=data)
            if current_status == "Sync Completed but Email Notification Failed":
                raise Exception("Sync Completion Email sending failed")
        except Exception as e:
            logging.exception(f"### run_webbing_sync devices and {tenant_name} Error updating progress tracker: {e}")
            raise Exception("Sync Completion Email sending failed")
        
        # Prepare final response
        final_response = {
            "flag": sync_successful, 
            "message": "Webbing sync completed successfully" if sync_successful else "Webbing sync completed with errors", 
            "total_devices": total_devices_count, 
            "usage_records": usage_count,
            "products_records": products_count,
            "staging_insert_status": staging_insert_response.get("message"),
            "main_sync_status": sync_main_response.get("message"),
            "device_usage_status": device_usage_response.get("message"),
            "history_tables_status": history_tables_response.get("message"),
            "main_sync_summary": {
                "total_staging_records": total_records_processed,
                "new_devices_inserted": inserted_count,
                "existing_devices_updated": updated_count
            },
            "history_tables_summary": {
                "inserted": history_tables_response.get("records_inserted", 0),
                "updated": history_tables_response.get("records_updated", 0)
            },
            "execution_duration": execution_duration
        }
        
        ##auditing the final response
        try:
            logging.info(f"### run_webbing_sync audit in success case for {tenant_name}")
            audit_comment = {
                "total_devices": total_devices_count,
                "usage_records": usage_count,
                "products_records": products_count,
                "new_devices_inserted": inserted_count,
                "existing_devices_updated": updated_count,
                "history_records_inserted": history_tables_response.get("records_inserted", 0),
                "history_records_updated": history_tables_response.get("records_updated", 0)
            }
            audit_data_user_actions = {
                "service_name": "run_webbing_sync",
                "created_date": data.get("request_received_at"),
                "created_by": username,
                "status": "Success" if sync_successful else "Failed",
                "session_id": data.get("session_id", ""),
                "tenant_name": tenant_name,
                "comments": json.dumps(audit_comment),
                "module_name": "Carrier Sync",
                "request_received_at": data.get("request_received_at"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.error(f"### run_webbing_sync auditing failed in success case :{e}")
        
        return final_response

    except Exception as e:
        logging.exception(f"run_webbing_sync and {tenant_name} Error during carrier sync {str(e)}")
        error_message = f"Error during carrier sync: {str(e)}"
        logging.error(f"### run_webbing_sync and {tenant_name} Error during carrier sync: {str(e)}")
        
        ### step 17 : sending email in Error case : 
        sync_stages = {
            "Staging Table Cleanup": staging_table_cleanup,
            "Carrier Rate Plans Fetch": products_fetch,
            "Devices Fetch": devices_fetch,
            "Device Usages Fetch": usage_fetch,
            "Staging → Main Tables Sync": staging_to_main_tables_sync,
            "Device Usage Sync": device_usage_sync,
            "History Tables Sync": history_tables_sync,
            "Sync Completion Email Trigger": email_trigger
        }
        
        # Get the first stage that failed
        failed_stage = next((name for name, flag in sync_stages.items() if not flag), "Unknown")
        # Map failed stage to a meaningful error category
        stage_error_mapping = {
            "Staging Table Cleanup": "Issue during Staging Tables Cleanup",
            "Carrier Rate Plans Fetch": "Rate Plan Fetch Processing Issue",
            "Devices Fetch": "Devices Fetch Issue",
            "Device Usages Fetch": "Devices Usage Processing Issue",
            "Staging → Main Tables Sync": "Staging to Main Table Sync Issue",
            "Device Usage Sync": "Devices Usage Table Update Issue",
            "History Tables Sync": "History Tables Update Issue",
            "Sync Completion Email Trigger": "Email Trigger Issue",
            "Unknown": "Unknown Issue Encountered"
        }
        
        # Define device and usage stage sets for Data Type determination
        device_stages = {"Staging Table Cleanup", "Carrier Rate Plans Fetch", "Devices Fetch"}
        usage_stages = {"Device Usages Fetch", "Staging → Main Tables Sync", "Device Usage Sync", "History Tables Sync", "Sync Completion Email Trigger"}
        
        # Assign Data Type dynamically
        if failed_stage in device_stages:
            data_type = "Device"
        elif failed_stage in usage_stages:
            data_type = "Usage"
        else:
            data_type = "Device and Usage"

        error_category = stage_error_mapping.get(failed_stage, "Unknown Error")
        end_time_ts = time.time()
        end_time_dt = datetime.now()
        duration_seconds = int(end_time_ts - start_time)
        duration_mm_ss = f"{duration_seconds // 60}:{duration_seconds % 60:02d}"
        
        sync_failed_data = {
            "Sync Type": "Daily Sync",
            "Sync Timeline": f"{start_date_obj.strftime('%Y-%m-%d %H:%M:%S')} - {end_time_dt.strftime('%Y-%m-%d %H:%M:%S')} (Duration: {duration_mm_ss} minutes)",
            "Partner Name": tenant_name,
            "Carrier Name": service_provider_name,
            "Start Time": start_date_obj.strftime('%Y-%m-%d %H:%M:%S'),
            "End Time": end_time_dt.strftime('%Y-%m-%d %H:%M:%S'),
            "Job ID": "Webbing_Container",
            "Error Category": error_category,
            "Error Message": error_message,
            "Stage of Failure": failed_stage,
            "Impacted Count": total_records_processed if total_records_processed != 0 else "N/A",
            "Data Type": data_type,
            "Partial Sync": "Yes" if total_records_processed != 0 else "No"
        }
        
        email_response = trigger_sync_email(
            template_name="Sync Error",
            subject=f"Sync Failed - {tenant_name} - {service_provider_name} - Daily Sync - {start_date_obj.strftime('%m-%d-%Y')}",
            data_dict=sync_failed_data,
            tenant_name=tenant_name,
            log_prefix="### run_webbing_sync Failed"
        )
        
        # Update current_status based on email response
        if not email_response["flag"]:
            current_status = "Sync failed. Error Email delivery was unsuccessful."
        else:
            current_status = "Sync failed. Error Email was sent successfully."
            email_trigger = True
            
        ## Updating the Sync Completion Email Trigger in Progress Tracker
        try:
            logging.info(f"### run_webbing_sync tenant : {tenant_name} updating the progress tracker for Sync failed & Error Email delivery")
            update_progress_tracker(progress_tracker_id, current_status=current_status, status="Failed",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=100, data=data)
        except Exception as e:
            logging.exception(f"### run_webbing_sync devices and {tenant_name} Error updating progress tracker: {e}")
        
        response = {
            "flag": False,
            "message": error_message
        }
        
        try:
            # Update progress tracker with failure
            update_progress_tracker(progress_tracker_id, current_status=f"Sync failed: {error_message}", status="Failed",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=100, data={**data, "error_message": error_message})
        except Exception as e:
            logging.exception(f"### run_webbing_sync and {tenant_name} Exception in updating progress tracker: {e}")
        
        try:
            # Log error to database
            error_data = {
                "service_name": "run_webbing_sync",
                "error_message": error_message,
                "error_type": error_category,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during carrier sync for tenant {tenant_name}: {str(e)}",
                "module_name": "Carrier Sync",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### run_webbing_sync and {tenant_name} Exception in logging error data to DB: {e}")
        
        return response
    
## Helper function to trigger sync emails with consistent logging
def trigger_sync_email(template_name, subject, data_dict, tenant_name, log_prefix):
    """
    Send an email for carrier/device sync with consistent logging.
    Args:
        template_name (str): Email template name.
        subject (str): Email subject line.
        data_dict (dict): Data to populate the email template.
        tenant_name (str): Tenant name for email context.
        log_prefix (str): Prefix used in logging messages.

    Returns:
        dict -> { "flag": True/False, "message": "..."}
    """
    try:
        result = send_email(
            template_name=template_name,
            email_subject=subject,
            is_html=True,
            data_dict=data_dict,
            tenant_name=tenant_name
        )
        if isinstance(result, tuple):
            to_emails, cc_emails, subject, body, from_email, partner_name = result
            logging.info(f"{log_prefix} Email sent successfully!")
            logging.info(f"{log_prefix} Email Log | To: {to_emails} | CC: {cc_emails} | Subject: {subject} | From: {from_email} | Partner: {partner_name}")
            return {"flag": True, "message": "Email sent successfully"}
         # Email failed
        logging.error(f"{log_prefix} Email sending failed: {result}")
        return {"flag": False, "message": "Email sending failed"}
    
    except Exception as e:
        logging.info(f"{log_prefix} Email sending Failed with error: {e}")
        return {"flag": False, "message": str(e)}
 

##function to update progress tracker
def update_progress_tracker(
    progress_tracker_id,
    current_status=None, status=None,
    common_utils_database=None,
    action="insert", now=None,
    progress=None,
    data=None
):
    """
    Insert or update carrier sync audit records.

    Args:
        common_utils_database (DB): Common utils DB connection
        action (str): "insert" or "update"
        audit_id (int): Required for update
        data (dict): Audit data payload

    Returns:
        dict: Response with flag and message
    """
    try:
        if action == "insert":
            insert_data = {
                "tenant_name": data.get("tenant_name"),
                "service_provider_name": data.get("service_provider_name"),
                "sync_start_time": now,
                "sync_end_time": None,
                "estimated_time": data.get("estimated_time"),
                "execution_duration": None,
                "total_records_synced": 0,
                "current_status": current_status or data.get("current_status", "Sync started"),
                "status": status or data.get("status", "In Progress"),
                "error_code": None,
                "error_message": None,
                "attempt_count": data.get("attempt_count", 0),
                "triggered_by": f"{data.get('service_provider_name')}_{data.get('tenant_name')}_{data.get('username')}",
                "sync_type": data.get("sync_type"),
                "created_by": f"{data.get('service_provider_name')}_{data.get('tenant_name')}_{data.get('username')}",
                "modified_by": data.get("modified_by", "Webbing Sync Container"),
                "sync_run_count": data.get("sync_run_count", 1),
                "progress": progress or 0
            }
            progress_tracker_id = common_utils_database.insert_data(insert_data, "carrier_sync_audit_logs")
            logging.info(f"Carrier sync audit inserted | id={progress_tracker_id} | status={insert_data['current_status']}")
            return {"flag": True, "message": "Progress tracker inserted successfully", "progress_tracker_id": progress_tracker_id}
        
        elif action == "update":
            update_data = {
                "current_status": current_status or data.get("current_status"),
                "status": status or data.get("status"),
                "total_records_synced": data.get("total_records_synced"),
                "attempt_count": data.get("attempt_count"),
                "error_code": data.get("error_code"),
                "error_message": data.get("error_message"),
                "sync_end_time": data.get("sync_end_time"),
                "execution_duration": data.get("execution_duration"),
                "modified_by": data.get("modified_by", "Webbing Sync Container"),
                "progress": progress or data.get("progress") or 0
            }
            update_data = {k: v for k, v in update_data.items() if v is not None}
            common_utils_database.update_dict(
                "carrier_sync_audit_logs",
                update_data,
                and_conditions={"id": progress_tracker_id}
            )
            logging.info(f"Carrier sync audit updated | id={progress_tracker_id} | status={update_data.get('current_status')}")
            return {"flag": True, "message": "Progress tracker updated successfully"}
    except Exception as e:
        logging.exception("Error in update_progress_tracker")
        return {"flag": False, "message": "Error in update_progress_tracker", "details": str(e)}

##function to clean staging table
def clean_staging_table(tenant_database, table_names, username):
    """
    Cleans one or more staging tables in the tenant database.

    Args:
        tenant_database (DB): Database connection object for tenant
        table_names (str or list): Single table name or list of table names
        username (str): User performing the cleanup

    Returns:
        dict: Cleanup results for each table
    """
    results = {}
    if isinstance(table_names, str):
        table_names = [table_names]

    for table in table_names:
        try:
            status = tenant_database.delete_data(table, reset_sequence=True)
            logging.info(f"Staging table {table} cleaned successfully by {username}")

            results[table] = {
                "flag": True,
                "status": status,
                "message": f"Staging table {table} cleaned successfully"
            }

        except Exception as e:
            logging.exception(f"Error cleaning staging table {table}: {e}")
            results[table] = {
                "flag": False,
                "status": False,
                "message": f"Error cleaning staging table {table}",
                "details": str(e)
            }
    
    # Return combined results
    all_success = all(result.get("flag", False) for result in results.values())
    if all_success:
        return {"flag": True, "message": "All staging tables cleaned successfully", "details": results}
    else:
        return {"flag": False, "message": "Error cleaning one or more staging tables", "details": results}
 
##function to get or create billing period
def get_or_create_billing_period(
    tenant_id,
    service_provider_id,
    service_provider_name,
    tenant_database,
    common_utils_database,
    progress_tracker_id,  
    billing_cycle_day,
    force_end_of_day=True,
    start_hour=0,
    start_minute=0,
    start_second=0,
    created_by="Webbing Sync Container",
    data=None  
):
    """
    Determines or creates a billing period for the current sync run.

    Returns:
        dict: {
            "flag": bool,
            "billing_period_id": int (if flag True),
            "is_new_period": bool (if flag True),
            "billing_period_details": dict (if flag True),
            "message": str (if flag False)
        }
    """
    today = date.today()
    now = datetime.utcnow()

    try:
        # 1. Check existing billing period
        query = """
            SELECT id, billing_cycle_start_date, billing_cycle_end_date
            FROM billing_period
            WHERE tenant_id = %s
            AND service_provider_id = %s
            AND billing_cycle_start_date <= %s
            AND billing_cycle_end_date >= %s
            AND is_deleted = false
            LIMIT 1
        """
        today_str = today.strftime("%Y-%m-%d")
        
        result = tenant_database.execute_query(
            query,
            params=[tenant_id, service_provider_id, today_str, today_str]
        )
        
        logging.info(f"### billing period query result : {result}")
        
        if result is not False and not result.empty:
            billing_period_id = result.iloc[0]["id"]
            billing_cycle_start_date = result.iloc[0]["billing_cycle_start_date"]
            billing_cycle_end_date = result.iloc[0]["billing_cycle_end_date"]
            logging.info(f"Billing period reused | billing_period_id={billing_period_id}")
            return { 
                "flag": True,
                "billing_period_id": billing_period_id,
                "is_new_period": False,
                "billing_period_details": {
                    "billing_cycle_start_date": billing_cycle_start_date,
                    "billing_cycle_end_date": billing_cycle_end_date
                }
            }
            
        # 2. Calculate billing cycle start date
        year = today.year
        month = today.month

        if today.day >= billing_cycle_day:
            start_year = year
            start_month = month
        else:
            start_month = month - 1 or 12
            start_year = year if month > 1 else year - 1

        billing_cycle_start_date = datetime(
            start_year,
            start_month,
            billing_cycle_day,
            start_hour,
            start_minute,
            start_second
        )
        
        # 3. Calculate billing cycle end date
        if start_month == 12:
            end_year = start_year + 1
            end_month = 1
        else:
            end_year = start_year
            end_month = start_month + 1

        next_cycle_start = datetime(
            end_year,
            end_month,
            billing_cycle_day,
            start_hour,
            start_minute,
            start_second
        )

        if force_end_of_day:
            billing_cycle_end_date = next_cycle_start.replace(hour=23, minute=59, second=59)
        else:
            billing_cycle_end_date = next_cycle_start
            
        # 4. Insert new billing period
        billing_data = {
            "tenant_id": tenant_id,
            "service_provider_id": service_provider_id,
            "service_provider": service_provider_name,
            "bill_year": billing_cycle_start_date.year,
            "bill_month": billing_cycle_start_date.month,
            "billing_cycle_start_date": billing_cycle_start_date,
            "billing_cycle_end_date": billing_cycle_end_date,
            "billing_period_status_id": 1,
            "is_active": True,
            "is_deleted": False,
            "created_by": created_by,
            "created_date": now,
            "modified_by": created_by,
            "modified_date": now,
            "deleted_by": None,
            "deleted_date": None
        }
        logging.info(f"### billing_data : {billing_data}")

        billing_period_id = tenant_database.insert_data(billing_data, "billing_period")
        logging.info(f"New billing period created | billing_period_id={billing_period_id}")
            
        return {
            "flag": True,
            "billing_period_id": billing_period_id,
            "is_new_period": True,
            "billing_period_details": {
                "billing_cycle_start_date": billing_cycle_start_date,
                "billing_cycle_end_date": billing_cycle_end_date
            }
        }
        
    except Exception as e:
        logging.exception("Error determining billing period")
        return {
            "flag": False, 
            "message": "Error determining billing period", 
            "details": str(e)
        }

# function to fetch integration details
def fetch_integration_details(tenant_database, integration_id, tenant_name, tenant_id):
    """
    Fetch active integration authentication details for a given integration ID.

    Args:
        tenant_database (DB): Tenant database connection
        integration_id (str): Integration identifier
        tenant_name (str): Tenant name (for logging)
        tenant_id (str): Tenant ID
    Returns:
        dict: {
            "flag": True/False,
            "integration_details": list (if flag True),
            "message": str (if flag False)
        }
    """
    try:
        integration_df = tenant_database.get_data(
            "integration_authentication",
            {
                "is_active": True,
                "integration_id": integration_id,
                "tenant_id": tenant_id
            }
        )
        logging.info(f"### run_webbing_sync devices and {tenant_name}")
        
        if integration_df.empty:
            message = "No active integration found for the given integration_id"
            logging.error(f"### run_webbing_sync devices and {tenant_name} {message}")
            return {"flag": False, "message": message}
        
        integration_details = integration_df.to_dict(orient="records")
        return {"flag": True, "integration_details": integration_details}
    except Exception as e:
        logging.exception(f"### run_webbing_sync devices and {tenant_name} Error fetching integration details: {e}")
        return {"flag": False, "message": str(e)}

##function to bulk fetch Webbing devices
def fetch_webbing_devices(username, password, ws_key, only_active=True, tenant_name="", 
                         devices_url=None, service_url=None, page_limit=1000, tenant_database=None,
                         service_provider_id=None, service_provider_name=None, 
                         billing_period_id=None, sync_run_count=None,
                         seen_devices_cache=None):
    """
    Fetch and process Webbing devices with pagination
    Includes deduplication to prevent duplicate records across active/disconnected calls
    
    Args:
        username (str): API username
        password (str): API password
        ws_key (str): Web service key
        only_active (bool): True for active devices, False for disconnected devices
        tenant_name (str): Tenant name for logging
        devices_url (str): URL for devices API (custom_url1)
        service_url (str): URL for service API (custom_url2)
        page_limit (int): Page size for pagination
        tenant_database (DB): Tenant database connection
        service_provider_id (str): Service provider ID
        service_provider_name (str): Service provider name
        billing_period_id (int): Billing period ID
        sync_run_count (int): Sync run count for audit records
        seen_devices_cache (set): Set of already seen device identifiers to prevent duplicates
    
    Returns:
        list: List of device records fetched and prepared for staging
    """
    page_number = 1
    total_devices = []
    device_type = "active" if only_active else "disconnected"
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Initialize seen_cache if not provided
    if seen_devices_cache is None:
        seen_devices_cache = set()
    
    logging.info(f"### fetch_webbing_devices for {tenant_name} - Fetching {device_type} devices")
    logging.info(f"### fetch_webbing_devices for {tenant_name} - Sync run count: {sync_run_count}")
    
    while True:
        logging.info(f"### fetch_webbing_devices for {tenant_name} - Fetching page {page_number} of {device_type} devices")
        
        try:
            # Fetch devices from API
            devices = get_webbing_service_devices(
                page_number=page_number,
                username=username,
                password=password,
                ws_key=ws_key,
                only_active=only_active,
                devices_url=devices_url,
                page_limit=page_limit
            )
        except Exception as e:
            logging.error(f"### fetch_webbing_devices for {tenant_name} - Error fetching page {page_number}: {e}")
            break
        
        if not devices:
            logging.info(f"### fetch_webbing_devices for {tenant_name} - No more {device_type} devices found on page {page_number}")
            break
        
        try:
            # Process devices with parallel processing - pass the seen cache
            batch_staging_records = process_webbing_device_batch(
                devices=devices,
                username=username,
                password=password,
                ws_key=ws_key,
                service_url=service_url,
                tenant_name=tenant_name,
                device_type=device_type,
                syncrun_count=sync_run_count,
                now=now,
                service_provider_id=service_provider_id,
                service_provider_name=service_provider_name,
                billing_period_id=billing_period_id,
                seen_devices_cache=seen_devices_cache
            )
            
            total_devices.extend(batch_staging_records)
            logging.info(f"### fetch_webbing_devices for {tenant_name} - Processed {device_type} devices from page {page_number}")
        except Exception as e:
            logging.error(f"### fetch_webbing_devices for {tenant_name} - Error processing batch from page {page_number}: {e}")
        
        # Check if we should continue pagination
        if len(devices) < page_limit:
            logging.info(f"### fetch_webbing_devices for {tenant_name} - Last page of {device_type} devices reached (page {page_number})")
            break
        
        page_number += 1
        time.sleep(0.5)
    
    logging.info(f"### fetch_webbing_devices for {tenant_name} - Total {device_type} devices: {len(total_devices)}")
    return total_devices

##function to get service devices from Webbing API
def get_webbing_service_devices(page_number, username, password, ws_key, only_active=True, devices_url=None, page_limit=1000):
    """
    Fetch service devices from Webbing API with pagination
    
    Args:
        page_number (int): Page number for pagination
        username (str): API username
        password (str): API password
        ws_key (str): Web service key
        only_active (bool): True for active devices, False for disconnected devices
        devices_url (str): URL for devices API (custom_url1)
        page_limit (int): Page size for pagination
    
    Returns:
        list: List of device dictionaries (empty list on error)
    """
    if not devices_url:
        logging.error("Devices URL is required")
        return []
    
    url = devices_url
    headers = {"Content-Type": "application/soap+xml; charset=utf-8"}

    if only_active:
        soap_body = f"""<?xml version="1.0" encoding="utf-8"?>
    <soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                     xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                     xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
      <soap12:Header>
        <Credentials xmlns="http://wws.iamwebbing.com/">
          <Username>{username}</Username>
          <Password>{password}</Password>
          <WSKey>{ws_key}</WSKey>
        </Credentials>
      </soap12:Header>
      <soap12:Body>
        <GetServiceDevices xmlns="http://wws.iamwebbing.com/">
          <GetServiceDevicesRequest>
            <OnlyActivePlansDevices>true</OnlyActivePlansDevices>
            <PaginationRequest>
              <PageSize>{page_limit}</PageSize>
              <PageNumber>{page_number}</PageNumber>
            </PaginationRequest>
          </GetServiceDevicesRequest>
        </GetServiceDevices>
      </soap12:Body>
    </soap12:Envelope>"""
    else:
        soap_body = f"""<?xml version="1.0" encoding="utf-8"?>
    <soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                     xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                     xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
      <soap12:Header>
        <Credentials xmlns="http://wws.iamwebbing.com/">
          <Username>{username}</Username>
          <Password>{password}</Password>
          <WSKey>{ws_key}</WSKey>
        </Credentials>
      </soap12:Header>
      <soap12:Body>
        <GetServiceDevices xmlns="http://wws.iamwebbing.com/">
          <GetServiceDevicesRequest>
            <OnlyActivePlansDevices>false</OnlyActivePlansDevices>
            <SDStatusID>5</SDStatusID>
            <PaginationRequest>
              <PageSize>{page_limit}</PageSize>
              <PageNumber>{page_number}</PageNumber>
            </PaginationRequest>
          </GetServiceDevicesRequest>
        </GetServiceDevices>
      </soap12:Body>
    </soap12:Envelope>"""
    
    try:
        response = requests.post(url, data=soap_body, headers=headers, timeout=30)
        device_type = "active" if only_active else "disconnected"
        logging.info(f"Webbing API Response Status Code (Page {page_number}, {device_type}): {response.status_code}")
        
        if response.status_code != 200:
            logging.error(f"API Error: Status {response.status_code}, Reason: {response.reason}")
            return []
        
        # Parse the response - returns list of devices
        devices = parse_webbing_xml_response(response.text)
        
        logging.info(f"Parsed {len(devices)} {device_type} devices from XML response")
        return devices
        
    except requests.exceptions.Timeout:
        logging.error("API request timeout - Request timed out after 30 seconds")
        return []
    except Exception as e:
        logging.error(f"Unexpected error in get_webbing_service_devices: {str(e)}")
        return []

##function to parse XML response
def parse_webbing_xml_response(xml_string):
    """Convert XML response to a list of device dictionaries"""
    if not xml_string:
        logging.warning("Empty XML string provided")
        return []
    
    try:
        root = ET.fromstring(xml_string)
        
        namespace = {"soap": "http://www.w3.org/2003/05/soap-envelope"}
        body = root.find("soap:Body", namespace)
        if body is None:
            logging.warning("No SOAP Body found in XML response")
            return []
        
        result_element = None
        for elem in body.iter():
            if 'GetServiceDevicesResult' in elem.tag:
                result_element = elem
                break
        
        if result_element is None:
            logging.warning("No GetServiceDevicesResult found in XML response")
            return []
        
        service_devices = []
        
        for elem in result_element.iter():
            if 'ServiceDeviceRecord' in elem.tag:
                device_dict = {}
                for child in elem:
                    tag_name = child.tag.split('}', 1)[-1] if '}' in child.tag else child.tag
                    device_dict[tag_name] = child.text if child.text is not None else ""
                service_devices.append(device_dict)
        
        logging.info(f"Parsed {len(service_devices)} devices from XML response")
        return service_devices
        
    except ET.ParseError as e:
        logging.exception(f"Error parsing XML response: {e}")
        if xml_string:
            logging.info(f"XML content (first 500 chars): {xml_string[:500]}...")
        return []
    except Exception as e:
        logging.exception(f"Unexpected error in parse_webbing_xml_response: {e}")
        return []

##function to process a batch of Webbing devices in parallel
def process_webbing_device_batch(devices, username, password, ws_key, service_url, tenant_name, 
                                device_type, syncrun_count, now, service_provider_id, 
                                service_provider_name, billing_period_id, seen_devices_cache):
    """
    Process a batch of Webbing devices in parallel to fetch ICCIDs and prepare staging records
    Includes deduplication to prevent duplicate records
    
    Args:
        devices (list): List of device dictionaries
        username (str): API username
        password (str): API password
        ws_key (str): Web service key
        service_url (str): Service URL for ICCID lookup
        tenant_name (str): Tenant name for logging
        device_type (str): "active" or "disconnected"
        syncrun_count (int): Sync run count for audit
        now (str): Current timestamp
        service_provider_id (str): Service provider ID
        service_provider_name (str): Service provider name
        billing_period_id (int): Billing period ID
        seen_devices_cache (set): Set of already seen device identifiers
    
    Returns:
        list: Batch of staging records
    """
    inserted_count = 0
    skipped_count = 0
    insert_lock = threading.Lock()
    batch_staging_records = []
    
    def process_single_device(device):
        """Process a single device - fetch ICCID if missing and prepare staging record"""
        nonlocal inserted_count, skipped_count
        iccid = device.get("ICCID", "")
        service_device_id = device.get("ServiceDeviceID", "")
        serial = device.get("Serial", "")
        
        # Generate a unique identifier for this device
        if iccid:
            device_identifier = f"iccid_{iccid}"
        elif service_device_id:
            device_identifier = f"sdid_{service_device_id}"
        else:
            device_identifier = f"serial_{serial}"
        
        # Check if we've already processed this device
        with insert_lock:
            if device_identifier in seen_devices_cache:
                skipped_count += 1
                return None
        
        # If ICCID is missing, try to fetch it using ServiceDeviceID
        if not iccid and service_device_id:
            try:
                iccid_response = get_iccid_from_service_device_id(
                    service_device_id=service_device_id,
                    username=username,
                    password=password,
                    ws_key=ws_key,
                    service_url=service_url
                )
                if iccid_response and iccid_response.get("flag") and iccid_response.get("iccid"):
                    iccid = iccid_response.get("iccid")
                    logging.info(f"Retrieved ICCID {iccid} for ServiceDeviceID {service_device_id}")
                    # Update device_identifier with the new ICCID
                    device_identifier = f"iccid_{iccid}"
                    
                    # Check again with the new identifier
                    with insert_lock:
                        if device_identifier in seen_devices_cache:
                            # logging.debug(f"Skipping duplicate device after ICCID fetch: {device_identifier}")
                            skipped_count += 1
                            return None
                else:
                    logging.info(f"Failed to retrieve ICCID for ServiceDeviceID {service_device_id}")
                    skipped_count += 1
                    return None
            except Exception as e:
                logging.warning(f"Error retrieving ICCID for ServiceDeviceID {service_device_id}: {e}")
                skipped_count += 1
                return None
        
        # Skip if still no ICCID
        if not iccid:
            logging.warning(f"Skipping device without ICCID: ServiceDeviceID={service_device_id}")
            skipped_count += 1
            return None
        
        # Prepare staging record for insertion 
        staging_record = {
            "iccid": iccid,
            "serial": device.get("Serial", ""),
            "device_type_id": device.get("DeviceTypeID", ""),
            "device_type_name": device.get("DeviceTypeName", ""),
            "product_id": device.get("ProductID", ""),
            "product_name": device.get("ProductName", ""),
            "status_id": device.get("StatusID", ""),
            "status_name": device.get("StatusName", ""),
            "order_id": device.get("OrderID", ""),
            "service_device_id": device.get("ServiceDeviceID", ""),
            "assignment_id": device.get("AssignmentID", ""),
            "branch_id": device.get("BranchID", ""),
            "branch_name": device.get("BranchName", ""),
            "account_id": device.get("AccountID", ""),
            "usage_control_id": device.get("UsageControlID", ""),
            "msisdn": device.get("MSISDN", ""),
            "apn_id": device.get("ApnID", ""),
            "apn_name": device.get("ApnName", ""),
            "imei": device.get("IMEI", ""),
            "total_usage": 0,      
            "total_usage_mb": 0,
            "total_usage_days": 0,
            "service_provider_id": service_provider_id,
            "service_provider_name": service_provider_name,
            "billing_period_id": int(billing_period_id) if billing_period_id else None,
            "created_by": "webbing sync container",
            "modified_by": "webbing sync container"
        }
        
        # Add to seen cache
        with insert_lock:
            seen_devices_cache.add(device_identifier)
            inserted_count += 1
        
        return staging_record
    
    # Use ThreadPoolExecutor for parallel processing
    max_workers = min(400, len(devices))  
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(process_single_device, device): device for device in devices}
        
        for future in as_completed(futures):
            try:
                staging_record = future.result()
                if staging_record:
                    batch_staging_records.append(staging_record)
            except Exception as e:
                device = futures[future]
                logging.error(f"Error processing device {device.get('ServiceDeviceID')} for {tenant_name}: {e}")
                skipped_count += 1
    
    logging.info(f"### process_webbing_device_batch for {tenant_name} - Prepared {len(batch_staging_records)} staging records from {len(devices)} devices, skipped {skipped_count} duplicates/invalid")
    
    return batch_staging_records

##function to get ICCID from ServiceDeviceID if missing
def get_iccid_from_service_device_id(service_device_id, username, password, ws_key, service_url=None):
    """Fetch ICCID using ServiceDeviceID from Multi-Carrier SIM SOAP API"""
    if not service_url:
        return {"flag": False, "message": "Service URL is required", "details": "Missing service_url"}
    
    if not service_device_id:
        return {"flag": False, "message": "Service Device ID is required", "details": "Missing service_device_id"}
    
    url = service_url
    headers = {"Content-Type": "application/soap+xml; charset=utf-8"}

    soap_body = f"""<?xml version="1.0" encoding="utf-8"?>
    <soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                     xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                     xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
      <soap12:Header>
        <Credentials xmlns="http://wws.iamwebbing.com/">
          <Username>{username}</Username>
          <Password>{password}</Password>
          <WSKey>{ws_key}</WSKey>
        </Credentials>
      </soap12:Header>
      <soap12:Body>
        <GetSDLiveData xmlns="http://wws.iamwebbing.com/">
          <GetSDLiveDataRequest>
            <ServiceDeviceIdentifier>
              <ServiceDeviceID>{service_device_id}</ServiceDeviceID>
            </ServiceDeviceIdentifier>
          </GetSDLiveDataRequest>
        </GetSDLiveData>
      </soap12:Body>
    </soap12:Envelope>"""

    try:
        response = requests.post(url, data=soap_body, headers=headers, timeout=30)
        
        if response.status_code != 200:
            return {"flag": False, "message": f"API Error: Status {response.status_code}", "details": response.reason}
        
        root = ET.fromstring(response.text)
        iccid = None
        
        # Try with namespace
        for elem in root.iter():
            if 'ICCID' in elem.tag:
                iccid = elem.text
                break
        
        # If not found with namespace, try without
        if not iccid:
            for elem in root.iter():
                tag = elem.tag.split('}', 1)[-1] if '}' in elem.tag else elem.tag
                if tag == 'ICCID':
                    iccid = elem.text
                    break
        
        if iccid:
            return {"flag": True, "message": "ICCID fetched successfully", "iccid": iccid.strip()}
        else:
            return {"flag": False, "message": f"No ICCID found for ServiceDeviceID {service_device_id}", "details": "ICCID not present in response"}
            
    except requests.exceptions.Timeout:
        return {"flag": False, "message": "API request timeout", "details": "Request timed out after 30 seconds"}
    except ET.ParseError as e:
        return {"flag": False, "message": "Failed to parse XML response", "details": str(e)}
    except Exception as e:
        return {"flag": False, "message": f"Unexpected error: {str(e)}", "details": str(e)}

##function to fetch and process Webbing usage data
def fetch_webbing_usage_data(username, password, ws_key, tenant_name="", usage_url=None, 
                            page_limit=1000, delayed_days=1, retries=3,
                            service_provider_id=None, service_provider_name=None, 
                            billing_period_id=None, sync_run_count=None):
    """
    Fetch and process Webbing usage data with pagination
    
    Args:
        username (str): API username
        password (str): API password
        ws_key (str): Web service key
        tenant_name (str): Tenant name for logging
        usage_url (str): URL for usage API
        page_limit (int): Page size for pagination
        delayed_days (int): Number of days to look back for usage data (passed from main function)
        retries (int): Number of retries for API calls
        service_provider_id (str): Service provider ID
        service_provider_name (str): Service provider name
        billing_period_id (int): Billing period ID
        sync_run_count (int): Sync run count for audit records
    
    Returns:
        list: List of processed usage records (includes total_usage in bytes and total_usage_mb)
    """
    logging.info(f"### fetch_webbing_usage_data for {tenant_name} - Fetching usage data for last {delayed_days} days")
    logging.info(f"### fetch_webbing_usage_data for {tenant_name} - Sync run count: {sync_run_count}")
    
    try:
        # Calculate date range based on delayed_days
        today = datetime.now()
        target_date = today - timedelta(days=delayed_days)
        start_date = target_date.strftime("%m/%d/%Y")
        end_date = target_date.strftime("%m/%d/%Y")
        
        logging.info(f"### fetch_webbing_usage_data for {tenant_name} - Fetching usage from {start_date} to {end_date}")
        
        page_number = 1
        all_usage_records = []
        seen_iccids = set()
        
        while True:
            logging.info(f"### fetch_webbing_usage_data for {tenant_name} - Fetching page {page_number} of usage data")
            
            try:
                usage_records = get_webbing_device_usage(
                    start_date=start_date,
                    end_date=end_date,
                    page_number=page_number,
                    username=username,
                    password=password,
                    ws_key=ws_key,
                    usage_url=usage_url,
                    page_limit=page_limit
                )
            except Exception as e:
                logging.error(f"### fetch_webbing_usage_data for {tenant_name} - Error fetching page {page_number}: {e}")
                break
            
            if not usage_records:
                logging.info(f"### fetch_webbing_usage_data for {tenant_name} - No more usage records found on page {page_number}")
                break
            
            try:
                processed_records = process_webbing_usage_batch(
                    usage_records=usage_records,
                    tenant_name=tenant_name,
                    syncrun_count=sync_run_count,
                    now=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    service_provider_id=service_provider_id,
                    service_provider_name=service_provider_name,
                    billing_period_id=billing_period_id,
                    seen_iccids=seen_iccids  # Pass seen ICCIDs for deduplication
                )
                
                all_usage_records.extend(processed_records)
                logging.info(f"### fetch_webbing_usage_data for {tenant_name} - Processed {len(usage_records)} usage records from page {page_number}")
            except Exception as e:
                logging.error(f"### fetch_webbing_usage_data for {tenant_name} - Error processing batch from page {page_number}: {e}")
            
            if len(usage_records) < page_limit:
                logging.info(f"### fetch_webbing_usage_data for {tenant_name} - Last page of usage data reached (page {page_number})")
                break
            
            page_number += 1
            time.sleep(0.5)
        
        logging.info(f"### fetch_webbing_usage_data for {tenant_name} - Total unique usage records: {len(all_usage_records)}")
        return all_usage_records
        
    except Exception as e:
        logging.exception(f"### fetch_webbing_usage_data for {tenant_name} - Error: {e}")
        return []

##function to get Webbing device usage
def get_webbing_device_usage(start_date, end_date, page_number, username, password, ws_key, usage_url=None, page_limit=1000):
    """
    Fetch device usage from Webbing API with pagination
    
    Args:
        start_date (str): Start date in MM/DD/YYYY format
        end_date (str): End date in MM/DD/YYYY format
        page_number (int): Page number for pagination
        username (str): API username
        password (str): API password
        ws_key (str): Web service key
        usage_url (str): URL for usage API
        page_limit (int): Page size for pagination
    
    Returns:
        list: List of usage record dictionaries (empty list on error)
    """
    if not usage_url:
        logging.error("Usage URL is required")
        return []
    
    if not all([start_date, end_date]):
        logging.error(f"Start date and end date are required: start_date={start_date}, end_date={end_date}")
        return []
    
    url = usage_url
    headers = {
        "Content-Type": "text/xml; charset=utf-8",
        "SOAPAction": "http://wws.iamwebbing.com/GetDeviceUsage",
    }
    
    soap_body = f"""<?xml version="1.0" encoding="utf-8"?>
    <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
                   xmlns:xsd="http://www.w3.org/2001/XMLSchema"
                   xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
    <soap:Header>
    <Credentials xmlns="http://wws.iamwebbing.com/">
    <Username>{username}</Username>
    <Password>{password}</Password>
    <WSKey>{ws_key}</WSKey>
    </Credentials>
    </soap:Header>
    <soap:Body>
    <GetDeviceUsage xmlns="http://wws.iamwebbing.com/">
    <GetDeviceUsageRequest>
    <StartDate>{start_date}</StartDate>
    <EndDate>{end_date}</EndDate>
    <PaginationRequest>
    <PageSize>{page_limit}</PageSize>
    <PageNumber>{page_number}</PageNumber>
    </PaginationRequest>
    </GetDeviceUsageRequest>
    </GetDeviceUsage>
    </soap:Body>
    </soap:Envelope>"""
    
    try:
        response = requests.post(url, data=soap_body, headers=headers, timeout=60)
        logging.info(f"Webbing Usage API Response Status Code (Page {page_number}): {response.status_code}")
        
        if response.status_code != 200:
            logging.error(f"API Error: Status {response.status_code}, Reason: {response.reason}")
            return []
        
        response_dict = xmltodict.parse(response.text)
        json_data = json.loads(json.dumps(response_dict))
        
        device_usage_records = json_data.get("soap:Envelope", {}).get("soap:Body", {}).get(
            "GetDeviceUsageResponse", {}).get("GetDeviceUsageResult", {}).get("Usage", {}).get("DeviceUsageRecord", [])
        
        if not device_usage_records:
            logging.info(f"No usage records found for page {page_number}")
            return []
        
        if not isinstance(device_usage_records, list):
            device_usage_records = [device_usage_records]
        
        record_count = len(device_usage_records)
        logging.info(f"Parsed {record_count} usage records from XML response")
        
        return device_usage_records
        
    except requests.exceptions.Timeout:
        logging.error("API request timeout - Request timed out after 60 seconds")
        return []
    except xmltodict.expat.ExpatError as e:
        logging.error(f"Failed to parse XML response: {str(e)}")
        return []
    except Exception as e:
        logging.error(f"Unexpected error in get_webbing_device_usage: {str(e)}")
        return []

##function to process a batch of Webbing usage records in parallel
def process_webbing_usage_batch(usage_records, tenant_name, syncrun_count, now, 
                               service_provider_id, service_provider_name, billing_period_id,
                               seen_iccids=None):
    """
    Process a batch of Webbing usage records in parallel
    
    Args:
        usage_records (list): List of usage records
        tenant_name (str): Tenant name for logging
        syncrun_count (int): Sync run count for audit
        now (str): Current timestamp
        service_provider_id (str): Service provider ID
        service_provider_name (str): Service provider name
        billing_period_id (int): Billing period ID
        seen_iccids (set): Set of already seen ICCIDs to prevent duplicates
    
    Returns:
        list: Processed usage records (includes total_usage in bytes and total_usage_mb as raw MB from API)
    """
    if not usage_records:
        return []
    
    processed_records = []
    processed_lock = threading.Lock()
    
    if seen_iccids is None:
        seen_iccids = set()
    
    def process_single_usage_record(record):
        """Process a single usage record"""
        iccid = record.get("ICCID", "")
        
        # Skip if no ICCID
        if not iccid:
            return None
            
        # Check for duplicates
        with processed_lock:
            if iccid in seen_iccids:
                # logging.debug(f"Skipping duplicate usage record for ICCID: {iccid}")
                return None
        
        imei = record.get("IMEI", "")
        total_usage_days = record.get("TotalUsageDays", "")
        total_usage = record.get("TotalUsage", "")

        if iccid and total_usage:
            try:
                MB_TO_BYTES = 1024 * 1024
                
                #Get the raw MB value from API and ensure it's float
                if isinstance(total_usage, str):
                    raw_mb_value = float(total_usage)
                elif isinstance(total_usage, (int, float)):
                    raw_mb_value = float(total_usage)
                else:
                    raw_mb_value = 0.0
                
                # Convert to bytes for the total_usage column
                total_usage_bytes = int(raw_mb_value * MB_TO_BYTES)
                
                # Handle total_usage_days
                if isinstance(total_usage_days, (int, float)):
                    total_usage_days_int = int(total_usage_days)
                elif isinstance(total_usage_days, str) and total_usage_days.strip():
                    try:
                        total_usage_days_int = int(float(total_usage_days))
                    except (ValueError, TypeError):
                        total_usage_days_int = 0
                else:
                    total_usage_days_int = 0
                    
            except (ValueError, TypeError) as e:
                logging.error(f"Conversion error for ICCID {iccid}: {e}")
                total_usage_bytes = 0
                raw_mb_value = 0.0
                total_usage_days_int = 0
            
            processed_record = {
                "iccid": str(iccid),
                "imei": str(imei) if imei else "",
                "total_usage_days": total_usage_days_int,
                "total_usage": total_usage_bytes,
                "total_usage_mb": raw_mb_value,
                "service_provider_id": service_provider_id,
                "service_provider_name": service_provider_name,
                "billing_period_id": int(billing_period_id) if billing_period_id else None
            }
            
            # Add to seen set
            with processed_lock:
                seen_iccids.add(iccid)
                processed_records.append(processed_record)
        
        return processed_record
    
    max_workers = min(400, len(usage_records))
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(process_single_usage_record, record): record for record in usage_records}
        
        for future in as_completed(futures):
            try:
                future.result()
            except Exception as e:
                record = futures[future]
                logging.error(f"Error processing usage record for {tenant_name}: {e}")
    
    logging.info(f"### process_webbing_usage_batch for {tenant_name} - Processed {len(processed_records)} unique usage records")
    return processed_records

##combined function to fetch and insert Webbing products/rate plans
def fetch_and_insert_webbing_products(
    tenant_database,
    username, 
    password, 
    ws_key, 
    tenant_name="", 
    products_url=None, 
    page_limit=1000,
    now=None
):
    """
    Fetch Webbing products/rate plans with pagination and insert directly into staging table.
    
    Args:
        tenant_database (DB): Tenant database connection object.
        username (str): API username
        password (str): API password
        ws_key (str): Web service key
        tenant_name (str): Tenant name for logging
        products_url (str): URL for products API
        page_limit (int): Page size for pagination
        now (str): Current timestamp (if None, will use datetime.now())
    
    Returns:
        dict: {
            "flag": bool,
            "message": str,
            "products_count": int,
            "products_list": list (optional, for debugging)
        }
    """
    if now is None:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    logging.info(f"### fetch_and_insert_webbing_products for {tenant_name} - Starting products fetch and insert")
    
    try:
        page_number = 1
        all_products = []
        seen_product_ids = set()
        
        while True:
            logging.info(f"### fetch_and_insert_webbing_products for {tenant_name} - Fetching page {page_number} of products")
            
            try:
                products = get_webbing_products_list(
                    page_number=page_number,
                    username=username,
                    password=password,
                    ws_key=ws_key,
                    products_url=products_url,
                    page_limit=page_limit
                )
            except Exception as e:
                logging.error(f"### fetch_and_insert_webbing_products for {tenant_name} - Error fetching page {page_number}: {e}")
                break
            
            if not products:
                logging.info(f"### fetch_and_insert_webbing_products for {tenant_name} - No more products found on page {page_number}")
                break
            
            try:
                # Process products and deduplicate
                for product in products:
                    product_id = product.get("ID", "")
                    product_name = product.get("Name", "")
                    
                    if product_id and product_id not in seen_product_ids:
                        seen_product_ids.add(product_id)
                        all_products.append({
                            "product_id": str(product_id),
                            "product_name": str(product_name) if product_name else ""
                        })
                
                logging.info(f"### fetch_and_insert_webbing_products for {tenant_name} - Processed {len(products)} products from page {page_number}")
                
            except Exception as e:
                logging.error(f"### fetch_and_insert_webbing_products for {tenant_name} - Error processing batch from page {page_number}: {e}")
            
            if len(products) < page_limit:
                logging.info(f"### fetch_and_insert_webbing_products for {tenant_name} - Last page of products reached (page {page_number})")
                break
            
            page_number += 1
            time.sleep(0.5)
        
        # Check if we found any products
        if not all_products:
            logging.info(f"### fetch_and_insert_webbing_products for {tenant_name} - No products found")
            return {
                "flag": False,
                "message": "No products found from Webbing API",
                "products_count": 0,
                "products_list": []
            }
        
        # Deduplicate products by product_id
        unique_products = {}
        for product in all_products:
            product_id = product.get("product_id")
            if product_id and product_id not in unique_products:
                unique_products[product_id] = product
        
        deduped_products = list(unique_products.values())
        
        if len(all_products) != len(deduped_products):
            logging.info(f"### fetch_and_insert_webbing_products for {tenant_name} - Removed {len(all_products) - len(deduped_products)} duplicate products")
        
        # Prepare records for staging table insertion
        staging_records = []
        for product in deduped_products:
            staging_record = {
                "product_id": product.get("product_id", ""),
                "product_name": product.get("product_name", ""),
                "created_by": "webbing sync container",
                "created_date": now,
                "modified_by": "webbing sync container",
                "modified_date": now
            }
            staging_records.append(staging_record)
        
        # Insert into staging table
        if staging_records:
            tenant_database.insert_data(staging_records, "webbing_carrier_rate_plan_stagging")
            logging.info(
                f"### fetch_and_insert_webbing_products for {tenant_name} - "
                f"Inserted {len(staging_records)} records into webbing_carrier_rate_plan_stagging table"
            )
            
            return {
                "flag": True,
                "message": f"{len(staging_records)} product records fetched and inserted successfully into staging table.",
                "products_count": len(staging_records),
                "products_list": staging_records
            }
        else:
            return {
                "flag": False,
                "message": "No valid product records to insert after processing.",
                "products_count": 0,
                "products_list": []
            }
            
    except Exception as e:
        logging.exception(f"### fetch_and_insert_webbing_products for {tenant_name} - Error: {e}")
        return {
            "flag": False,
            "message": f"Error fetching and inserting product records: {str(e)}",
            "products_count": 0,
            "products_list": []
        }

##function to get Webbing products list
def get_webbing_products_list(page_number, username, password, ws_key, products_url=None, page_limit=1000):
    """
    Fetch products list from Webbing API with pagination
    
    Args:
        page_number (int): Page number for pagination
        username (str): API username
        password (str): API password
        ws_key (str): Web service key
        products_url (str): URL for products API
        page_limit (int): Page size for pagination
    
    Returns:
        list: List of product records (empty list on error)
    """
    if not products_url:
        logging.error("Products URL is required")
        return []
    
    url = products_url
    headers = {
        "Content-Type": "text/xml; charset=utf-8",
        "SOAPAction": "http://wws.iamwebbing.com/GetProductsList"
    }

    soap_body = f"""<?xml version="1.0" encoding="utf-8"?>
    <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" 
                   xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
                   xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
    <soap:Header>
    <Credentials xmlns="http://wws.iamwebbing.com/">
    <Username>{username}</Username>
    <Password>{password}</Password>
    <WSKey>{ws_key}</WSKey>
    </Credentials>
    </soap:Header>
    <soap:Body>
    <GetProductsList xmlns="http://wws.iamwebbing.com/">
    <GetProductsRequest>
    <PaginationRequest>
    <PageSize>{page_limit}</PageSize>
    <PageNumber>{page_number}</PageNumber>
    </PaginationRequest>
    </GetProductsRequest>
    </GetProductsList>
    </soap:Body>
    </soap:Envelope>"""
    
    try:
        response = requests.post(url, data=soap_body, headers=headers, timeout=30)
        logging.info(f"Webbing Products API Response Status Code (Page {page_number}): {response.status_code}")
        
        if response.status_code != 200:
            logging.error(f"API Error: Status {response.status_code}, Reason: {response.reason}")
            return []
        
        response_dict = xmltodict.parse(response.text)
        json_data = json.loads(json.dumps(response_dict))
        
        # Extract the products list
        try:
            products = json_data["soap:Envelope"]["soap:Body"]["GetProductsListResponse"]["GetProductsListResult"]["Products"]["ProductRecord"]
            
            if not products:
                logging.info("No products found")
                return []
            
            if not isinstance(products, list):
                products = [products]
            
            logging.info(f"Parsed {len(products)} products from XML response")
            return products
            
        except KeyError as e:
            logging.error(f"Error parsing products from response: {e}")
            return []
        
    except Exception as e:
        logging.error(f"Unexpected error in get_webbing_products_list: {str(e)}")
        return []

##function to insert device data into staging tables
def insert_devices_into_staging_table(tenant_database, total_devices, usage_data_records, tenant_name, sync_run_count, now):
    """
    Inserts device records into staging and audit tables after mapping usage data.
    Includes deduplication to prevent duplicate records.
    
    Args:
        tenant_database (DB): Tenant database connection object.
        total_devices (list): List of device records to insert.
        usage_data_records (list): List of usage records containing valid usage values.
        tenant_name (str): Tenant name used for logging.
        sync_run_count (int): Sync run count for audit records.
        now (str): Current timestamp.

    Returns:
        dict: {
            "flag": bool,
            "message": str
        }
    """
    try:
        # Create lookup dictionary for fast ICCID matching
        usage_lookup = {}
        for record in usage_data_records:
            iccid = record.get("iccid")
            if iccid:
                usage_lookup[iccid] = {
                    "imei": record.get("imei", ""),
                    "total_usage_days": record.get("total_usage_days", 0),
                    "total_usage": record.get("total_usage", 0),          
                    "total_usage_mb": record.get("total_usage_mb", 0.0)
                }
        
        # Deduplicate devices by ICCID or service_device_id
        unique_devices = {}
        for device in total_devices:
            iccid = device.get("iccid")
            service_device_id = device.get("service_device_id")
            serial = device.get("serial", "")
            
            # Use ICCID as primary key, fallback to service_device_id or combination
            if iccid:
                device_key = iccid
            elif service_device_id:
                device_key = f"sdid_{service_device_id}"
            else:
                device_key = f"serial_{serial}"
            
            # If we haven't seen this device before, add it
            if device_key not in unique_devices:
                unique_devices[device_key] = device
            else:
                # If we have seen it, keep the one with more complete data
                existing = unique_devices[device_key]
                
                # Prefer device with ICCID
                if iccid and not existing.get("iccid"):
                    unique_devices[device_key] = device
                # Prefer device with active status
                elif device.get("status_name") == "Active" and existing.get("status_name") != "Active":
                    unique_devices[device_key] = device
                # Keep the one with more complete data
                elif len(str(device)) > len(str(existing)):
                    unique_devices[device_key] = device
        
        # Use deduplicated devices
        deduped_devices = list(unique_devices.values())
        
        if len(total_devices) != len(deduped_devices):
            logging.info(f"### insert_devices_into_staging_table for {tenant_name} - Removed {len(total_devices) - len(deduped_devices)} duplicate devices")
        
        # Prepare separate lists for staging and audit
        staging_records = []
        audit_records = []
        
        # Update deduped_devices where ICCID matches and prepare records
        for device in deduped_devices:
            iccid = device.get("iccid")
            if iccid and iccid in usage_lookup:
                usage_record = usage_lookup[iccid]
                # Copy required fields - INCLUDING total_usage_mb (float)
                device["imei"] = usage_record.get("imei", "")
                device["total_usage_days"] = usage_record.get("total_usage_days", 0)
                device["total_usage"] = usage_record.get("total_usage", 0)
                device["total_usage_mb"] = usage_record.get("total_usage_mb", 0.0)
            
            # Add audit-specific fields to the device record
            device["sync_run_count"] = sync_run_count
            device["sync_date"] = now
            device["triggered_by"] = "webbing sync container"
            
            # Staging record (without audit-specific columns)
            staging_record = {k: v for k, v in device.items() 
                            if k not in ["sync_run_count", "sync_date", "triggered_by"]}
            staging_records.append(staging_record)
            
            # Audit record (with all columns including audit-specific ones)
            audit_records.append(device)

        # Insert into tables if records exist
        if staging_records:
            try:
                # Insert into staging table
                tenant_database.insert_data(staging_records, "webbing_carrier_sync_staging")
                logging.info(f"### insert_devices_into_staging_table for {tenant_name} - Inserted {len(staging_records)} records into staging table")
                
                # Insert into audit table
                tenant_database.insert_data(audit_records, "webbing_carrier_sync_staging_audit")
                logging.info(
                    f"### insert_devices_into_staging_table for {tenant_name} - "
                    f"Inserted {len(audit_records)} records into audit table"
                )
                
                return {
                    "flag": True, 
                    "message": f"{len(staging_records)} records inserted successfully into staging and audit tables."
                }

            except Exception as e:
                logging.error(f"### insert_devices_into_staging_table for {tenant_name} - Error inserting into staging/audit tables: {e}")
                return {
                    "flag": False, 
                    "message": f"Error inserting records into staging/audit tables: {str(e)}"
                }
        else:
            logging.info(f"### insert_devices_into_staging_table for {tenant_name} - No records to insert into staging and audit tables")
            return {
                "flag": False, 
                "message": "No records available to insert into staging and audit tables."
            }
    except Exception as e:
        logging.exception(f"### insert_devices_into_staging_table for {tenant_name} - Unexpected error: {e}")
        return {
            "flag": False, 
            "message": f"Unexpected error occurred: {str(e)}"
        }

###syncing the main table ,inserting the data from staging to main table and then updating the devices
def sync_staging_to_main(data, tenant_database, common_utils_database, progress_tracker_id):
    """
    Syncs data from Webbing staging tables to main AMOP tables.
    
    Args:
        data (dict): Request data containing necessary information for syncing.
        tenant_database: Database connection object for tenant-specific operations.
        common_utils_database: Database connection object for common utilities.
        progress_tracker_id: Progress tracker ID for audit logging.
    
    Returns:
        dict: Result of the sync operation with success or failure details.
    """
    logging.info("###### sync_staging_to_main - Webbing Sync from staging to main started")
    
    ## Fetching the necessary variables
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    integration_id = int(data.get("integration_id")) if data.get("integration_id") is not None else None
    service_provider_id = int(data.get("service_provider_id")) if data.get("service_provider_id") is not None else None
    service_provider_name = data.get("service_provider_name", "Multi-Carrier SIM")
    tenant_id = int(data.get("tenant_id")) if data.get("tenant_id") is not None else None
    username = data.get('username', 'webbing_sync_container')
    staging_table_name = data.get('staging_table_name', 'webbing_carrier_sync_staging')
    integration_authentication_id = int(data.get('integration_authentication_id')) if data.get('integration_authentication_id') is not None else None
    tenant_name = data.get("tenant_name")
    billing_period_id = int(data["billing_period_id"]) if data.get("billing_period_id") is not None else None
    
    ## Initializing the variables
    device_status_map = {}
    plan_map = {}
    insert_payload = []
    update_dict = []
    
    try:
        ## Step 1 : Fetching the staging table data 
        staging_df = tenant_database.get_data(staging_table_name)
        if staging_df is None or staging_df.empty:
            logging.info("### sync_staging_to_main No staging data found")
            return {"flag": False, "message": "No staging data found."}
        logging.info(f"### sync_staging_to_main Staging records fetched: {len(staging_df)}")
        
        try:
            logging.info(f"### sync_staging_to_main tenant : {tenant_name} updating the progress tracker for Fetched Staging records")
            update_progress_tracker(progress_tracker_id, current_status="Fetched Staging records Successfully", status="In Progress",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=72, data=data)
        except Exception as e:
            logging.exception(f"### sync_staging_to_main devices and {tenant_name} Error updating progress tracker: {e}")
        
        ##Step 2: Fetching the statuses from staging table and checking with status in device_status table
        staging_statuses = []
        if "status_name" in staging_df.columns:
            staging_statuses = (staging_df["status_name"].dropna().astype(str).str.strip().str.lower().unique())
        
        ##device_status table
        existing_status_df = tenant_database.get_data(
            "device_status",
            {"integration_id": integration_id},
            ["id", "status","display_name"]
        )
        
        if existing_status_df is not None and not existing_status_df.empty:
            existing_status_df["status"] = (
                existing_status_df["status"]
                .astype(str)
                .str.strip()
                .str.lower()
            )
            existing_status_map = dict(zip(existing_status_df["status"], existing_status_df["id"]))
        else:
            existing_status_map = {}
        
        ##checking for new statuses
        if len(staging_statuses) > 0:
            new_statuses = [
                status for status in staging_statuses
                if status and status not in existing_status_map
            ]
            
            ##Step 3:handling New status If new status comes need to insert them in device_status table
            if new_statuses:
                active_status_values = {"activate", "active", "activated", "active plan"}
                status_insert_payload = [
                    {
                        "status": status.strip(),
                        "display_name": status.strip().title(),
                        "description": f"Auto-created from {service_provider_name} carrier sync",
                        "created_by": username,
                        "modified_by": username,
                        "integration_id": integration_id,
                        "is_active": True,
                        "is_deleted": False,
                        # Business flags
                        "is_active_status": status.strip().lower() in active_status_values,
                        "should_have_billed_service": True,
                        "is_restorable_from_archive": status.strip().lower() in active_status_values,
                        "is_apply_for_automation_rule": status.strip().lower() in active_status_values,
                    }
                    for status in new_statuses
                    if status and str(status).strip()
                ]
                
                if status_insert_payload:
                    tenant_database.insert_data(status_insert_payload, "device_status")
                    logging.info(f"###sync_staging_to_main Inserted {len(new_statuses)} new device statuses")
                    
                    # Refetch after insert to get the latest ids
                    existing_status_df = tenant_database.get_data(
                        "device_status",
                        {"integration_id": integration_id},
                        ["id", "status","display_name"]
                    )
                    ##preparing the device_status map
                    if existing_status_df is not None and not existing_status_df.empty:
                        existing_status_df["status"] = (
                            existing_status_df["status"]
                            .astype(str)
                            .str.strip()
                            .str.lower()
                        )
                        existing_status_map = dict(zip(existing_status_df["status"], existing_status_df["id"]))
        
        ##preparing the device_status map
        if existing_status_df is not None and not existing_status_df.empty:
            existing_status_df["status"] = (
                existing_status_df["status"]
                .astype(str)
                .str.strip()
                .str.lower()
            )
            device_status_map = dict(zip(existing_status_df["status"], existing_status_df["id"]))
            status_display_map = dict(zip(existing_status_df["status"], existing_status_df["display_name"]))
        else:
            device_status_map = {}
            status_display_map = {}
        
        try:
            logging.info(f"### sync_staging_to_main tenant : {tenant_name} updating the progress tracker for Device Statuses Fetched Successfully")
            update_progress_tracker(progress_tracker_id, current_status="Device Statuses Fetched Successfully", status="In Progress", common_utils_database=common_utils_database,
                                     action="update", now=now, progress=74, data=data)
        except Exception as e:
            logging.exception(f"### sync_staging_to_main devices and {tenant_name} Error updating progress tracker: {e}")
        
        ##Step 4: Preparing the rate plan map using staging products/plans
        staging_plan_df = None
        if "product_name" in staging_df.columns:
            staging_plan_df = (
                staging_df[["product_name", "product_id"]]
                .dropna(subset=["product_name"])
                .copy()
            )
            staging_plan_df["product_name"] = (
                staging_plan_df["product_name"]
                .astype(str)
                .str.strip()
            )
            staging_plan_df = staging_plan_df.drop_duplicates(subset=["product_name"])
        
        ##Step 5: Fetching the existing carrier rate plans
        existing_plan_df = tenant_database.get_data(
            "carrier_rate_plan",
            {
                "service_provider_id": service_provider_id,
                "is_active": True
            },
            ["id", "friendly_name", "rate_plan_code"]
        )
        
        if existing_plan_df is not None and not existing_plan_df.empty:
            existing_plan_df["friendly_name"] = (
                existing_plan_df["friendly_name"]
                .astype(str)
                .str.strip()
            )
            existing_plan_map = dict(zip(existing_plan_df["friendly_name"], existing_plan_df["id"]))
        else:
            existing_plan_map = {}
        insert_payload = []
        ##Step 6: Inserting new rate plans from Webbing products
        if staging_plan_df is not None and not staging_plan_df.empty:
            for _, row in staging_plan_df.iterrows():
                product_name = row["product_name"]
                product_id = row.get("product_id", "")
                
                if product_name and product_name not in existing_plan_map:
                    # INSERT NEW PLAN
                    insert_payload.append({
                        "rate_plan_code": str(product_id) if product_id else str(product_name),
                        "friendly_name": product_name,
                        "rate_plan_short_name": product_name,
                        "service_provider": service_provider_name,
                        "service_provider_id": service_provider_id,
                        "is_active": True,
                        "is_deleted": False,
                        "is_retired": False,
                        "is_exclude_from_optimization": False,
                        "assigned": False,
                        "allows_sim_pooling": True,
                        "created_by": username,
                        "modified_by": username,
                        "description": product_name
                    })
            
            if insert_payload:
                logging.info(f"### sync_staging_to_main - Inserting {len(insert_payload)} new rate plans for Webbing")
                rate_plan_insert_flag = tenant_database.insert_data(insert_payload, "carrier_rate_plan")
                logging.info(f"### sync_staging_to_main - Rate plan insertion completed, flag: {rate_plan_insert_flag}")
        
        ## Refetch plans after insertions
        existing_plan_df = tenant_database.get_data(
            "carrier_rate_plan",
            {"service_provider_id": service_provider_id},
            ["id", "friendly_name"]
        )
        
        if existing_plan_df is not None and not existing_plan_df.empty:
            existing_plan_df["friendly_name"] = (
                existing_plan_df["friendly_name"]
                .astype(str)
                .str.strip()
            )
            plan_map = dict(zip(existing_plan_df["friendly_name"], existing_plan_df["id"]))
        else:
            plan_map = {}
        
        try:
            logging.info(f"### sync_staging_to_main tenant : {tenant_name} updating the progress tracker for fetching carrier rate plans")
            update_progress_tracker(progress_tracker_id, current_status=f"Fetched Carrier Rate Plans Successfully", status="In Progress",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=75, data=data)
        except Exception as e:
            logging.exception(f"### sync_staging_to_main devices and {tenant_name} Error updating progress tracker: {e}")
        
        ##Step 7: Fetching the bill cycle values to insert or update 
        billing_df = tenant_database.get_data("billing_period",{"id":billing_period_id},['billing_cycle_end_date','billing_cycle_start_date','bill_year','bill_month'])
        if billing_df is not None and not billing_df.empty:
            billing_record = billing_df.to_dict("records")[0]
            bill_year = billing_record.get("bill_year")
            bill_month = billing_record.get("bill_month")
            billing_cycle_end_date = billing_record.get("billing_cycle_end_date")
            billing_cycle_start_date = billing_record.get("billing_cycle_start_date")
        else:
            billing_period_id = None
            bill_year = None
            bill_month = None
            billing_cycle_end_date = None
            billing_cycle_start_date = None
        
        ##Step 8: Prepare the column mappings
        columns_mapping = {
            "iccid": "iccid",
            "imei": "imei",
            "msisdn": "msisdn",
            "service_provider_id": "service_provider_id",
            "service_provider_name": "service_provider_display_name",
            "status_name": "sim_status",
            "product_name": "carrier_rate_plan_name",
            "total_usage": "carrier_cycle_usage_bytes",
            "total_usage_mb": "carrier_cycle_usage_mb",
        }
        
        # Only keep columns that exist in the staging dataframe
        available_columns = {k: v for k, v in columns_mapping.items() if k in staging_df.columns}
        transformed_df = staging_df.rename(columns=available_columns)
        
        ##Step 9: Keep only mapped columns that exist after rename
        mapped_columns = list(available_columns.values())
        transformed_df = transformed_df[[col for col in mapped_columns if col in transformed_df.columns]]
        
        ##Step 10: Updating device_status_id using the status map and display map
        if "sim_status" in transformed_df.columns:
            normalized_status = (
                transformed_df["sim_status"]
                .astype(str)
                .str.strip()
                .str.lower()
            )
            # Map ID
            transformed_df["device_status_id"] = normalized_status.map(device_status_map)
            # Map Display Name
            transformed_df["sim_status"] = normalized_status.map(status_display_map)
        
        ##Step 11: Map carrier rate plan id
        if "carrier_rate_plan_name" in transformed_df.columns:
            transformed_df["carrier_rate_plan_name"] = (
                transformed_df["carrier_rate_plan_name"]
                .astype(str)
                .str.strip()
            )
            transformed_df["carrier_rate_plan_id"] = (
                transformed_df["carrier_rate_plan_name"]
                .map(plan_map)
            )
        
        ### Additional Step for sub tenant handling--->Duplicate columns
        transformed_df["sub_tenant_carrier_rate_plan_name"] = transformed_df["carrier_rate_plan_name"]
        transformed_df["sub_tenant_carrier_rate_plan_name_id"] = transformed_df["carrier_rate_plan_id"]
        
        ##Step 12: Add standard fields for sim_management_inventory
        transformed_df["tenant_id"] = tenant_id
        transformed_df["is_active"] = True
        transformed_df["is_deleted"] = False
        transformed_df["tenant_is_active"] = True
        transformed_df["tenant_is_deleted"] = False
        transformed_df["created_by"] = username
        transformed_df["modified_by"] = username
        transformed_df["billing_period_id"] = int(billing_period_id) if billing_period_id else None
        transformed_df["bill_year"] = int(bill_year) if bill_year else None
        transformed_df["bill_month"] = int(bill_month) if bill_month else None
        transformed_df["integration_id"] = int(integration_id) if integration_id else None
        transformed_df["billing_cycle_end_date"] = billing_cycle_end_date if billing_cycle_end_date else None
        transformed_df["billing_cycle_start_date"] = billing_cycle_start_date if billing_cycle_start_date else None
        transformed_df["account_number_integration_authentication_id"] = integration_authentication_id
        
        ##Step 13: Fetch existing inventory ICCIDs
        main_iccids_data = tenant_database.get_data(
            "sim_management_inventory",
            {
                "service_provider_id": service_provider_id,
                "tenant_id": tenant_id,
                "is_active": True
            },
            ["iccid"]
        )
        
        if main_iccids_data is not None and not main_iccids_data.empty:
            main_iccids = set(
                main_iccids_data["iccid"]
                .dropna()
                .astype(str)
                .str.strip()
            )
        else:
            main_iccids = set()
        
        ##Step 14: Split into insert and update dataframes
        if "iccid" in transformed_df.columns:
            transformed_df["iccid"] = transformed_df["iccid"].astype(str).str.strip()
            
            insert_df = transformed_df[
                ~transformed_df["iccid"].isin(main_iccids)
            ].copy()
            
            update_df = transformed_df[
                transformed_df["iccid"].isin(main_iccids)
            ].copy()
        else:
            insert_df = pd.DataFrame()
            update_df = pd.DataFrame()
            logging.error("### sync_staging_to_main - ICCID column missing in transformed dataframe")
        
        ##Step 15: Insert new devices
        new_devices_insert_flag = True
        inserted_count = 0
        
        if not insert_df.empty:
            # logging.info(f"### sync_staging_to_main ICCIDs being inserted: {insert_df['iccid'].tolist()}")
            
            # Clean NaN values
            insert_df = insert_df.replace({np.nan: None})
            
            # Convert integer columns 
            integer_columns = [
                "carrier_cycle_usage_bytes",
                "carrier_rate_plan_id", 
                "sub_tenant_carrier_rate_plan_name_id",
                "service_provider_id", 
                "device_status_id", 
                "billing_period_id",
                "bill_year", 
                "bill_month", 
                "integration_id", 
                "tenant_id"
            ]
            
            # Float columns
            float_columns = [
                "carrier_cycle_usage_mb"
            ]
            
            # Convert integer columns
            for col in integer_columns:
                if col in insert_df.columns:
                    insert_df[col] = insert_df[col].apply(
                        lambda x: int(float(x)) if pd.notnull(x) and x != "" and x != "None" else None
                    )
            
            # Convert float columns
            for col in float_columns:
                if col in insert_df.columns:
                    insert_df[col] = insert_df[col].apply(
                        lambda x: float(x) if pd.notnull(x) and x != "" and x != "None" else None
                    )
            
            insert_payload = insert_df.to_dict(orient="records")
            
            try:
                new_devices_insert_flag = tenant_database.insert_data(
                    insert_payload,
                    "sim_management_inventory"
                )
                inserted_count = len(insert_payload)
                logging.info(f"### sync_staging_to_main - Inserted {inserted_count} new Webbing devices into inventory")
                
                try:
                    update_progress_tracker(progress_tracker_id, current_status=f"Inserted {inserted_count} records Successfully into Inventory", status="In Progress",
                                             common_utils_database=common_utils_database, action="update", now=now, progress=76, data=data)
                except Exception as e:
                    logging.exception(f"### sync_staging_to_main - {tenant_name} Error updating progress tracker: {e}")
                    
            except Exception as e:
                logging.exception(f"### sync_staging_to_main - Error inserting new devices: {e}")
                new_devices_insert_flag = False
        else:
            logging.info(f"### sync_staging_to_main - No new Webbing devices to insert")
        
        ##Step 16: Update existing devices
        bulk_update_flag = True
        updated_count = 0
        
        if not update_df.empty:
            ##for update only we will remove tenant id filter
            if "tenant_id" in update_df.columns:
                update_df = update_df.drop(columns=["tenant_id"], errors="ignore")
            
            # logging.info(f"### sync_staging_to_main ICCIDs being updated: {update_df['iccid'].tolist()}")
            
            # Clean NaN values
            update_df = update_df.replace({np.nan: None})
            
            # Convert integer columns 
            integer_columns = [
                "carrier_cycle_usage_bytes",
                "carrier_rate_plan_id", 
                "sub_tenant_carrier_rate_plan_name_id",
                "service_provider_id", 
                "device_status_id", 
                "billing_period_id",
                "bill_year", 
                "bill_month", 
                "integration_id"
            ]
            
            # Float columns
            float_columns = [
                "carrier_cycle_usage_mb"
            ]
            
            # Convert integer columns
            for col in integer_columns:
                if col in update_df.columns:
                    update_df[col] = update_df[col].apply(
                        lambda x: int(float(x)) if pd.notnull(x) and x != "" and x != "None" else 0
                    )
            
            # Convert float columns
            for col in float_columns:
                if col in update_df.columns:
                    update_df[col] = update_df[col].apply(
                        lambda x: float(x) if pd.notnull(x) and x != "" and x != "None" else 0.0
                    )
            
            update_dict = update_df.to_dict(orient="records")
            
            try:
                bulk_update_flag = tenant_database.bulk_update_data(
                    table_name="sim_management_inventory",
                    data_list=update_dict,
                    search_column="iccid",
                    static_conditions={
                        "service_provider_id": service_provider_id
                    }
                )
                updated_count = len(update_dict)
                logging.info(f"### sync_staging_to_main - Updated {updated_count} existing Webbing devices in inventory")
                
                try:
                    update_progress_tracker(progress_tracker_id, current_status=f"Updated {updated_count} records Successfully in Inventory", status="In Progress",
                                             common_utils_database=common_utils_database, action="update", now=now, progress=78, data=data)
                except Exception as e:
                    logging.exception(f"### sync_staging_to_main - {tenant_name} Error updating progress tracker: {e}")
                    
            except Exception as e:
                logging.exception(f"### sync_staging_to_main - Error updating devices: {e}")
                bulk_update_flag = False
        else:
            logging.info(f"### sync_staging_to_main - No existing Webbing devices to update")
        
        ##Step 17: Prepare audit summary
        audit_comments = {
            "sync_type": "Carrier Sync Staging → Main Inventory",
            "service_provider": service_provider_name,
            "tenant_name": tenant_name,
            "summary": {
                "total_staging_records": len(staging_df),
                "new_devices_inserted": inserted_count,
                "existing_devices_updated": updated_count
            }
        }
        
        ##Step 18: Return result
        if bulk_update_flag and new_devices_insert_flag:
            logging.info("### sync_staging_to_main Sync completed successfully")
            
            try:
                audit_data_user_actions = {
                    "service_name": "sync_staging_to_main",
                    "created_by": username,
                    "status": "Success",
                    "session_id": data.get("session_id", ""),
                    "tenant_name": tenant_name,
                    "comments": json.dumps(audit_comments),
                    "module_name": "Carrier Sync",
                    "request_received_at": data.get("request_received_at", now),
                }
                common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            except Exception as e:
                logging.error(f"### sync_staging_to_main auditing failed in success case :{e}")
            
            return {
                "flag": True,
                "message": "Sync successful",
                "summary": {
                    "total_staging_records": len(staging_df),
                    "new_devices_inserted": inserted_count,
                    "existing_devices_updated": updated_count
                }
            }
        else:
            return {
                "flag": False,
                "message": "Sync failed",
                "summary": {
                    "total_staging_records": len(staging_df),
                    "new_devices_inserted": inserted_count if 'inserted_count' in locals() else 0,
                    "existing_devices_updated": updated_count if 'updated_count' in locals() else 0
                }
            }
            
    except Exception as e:
        error_message = f"Error during sync_staging_to_main : {str(e)}"
        error_type = str(type(e).__name__)
        logging.exception(f"### sync_staging_to_main Sync failed: {e}")
        
        # Log error to database
        try:
            error_data = {
                "service_name": "sync_staging_to_main",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during sync_staging_to_main for tenant {tenant_name}: {str(e)}",
                "module_name": "Carrier Sync",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### sync_staging_to_main and {tenant_name} Exception in logging error data to DB: {e}")
        
        return {
            "flag": False,
            "message": str(e),
            "Sync failed": "Sync failed"
        }

## Update device usage table 
def update_device_usage_table(data, tenant_database, common_utils_database):
    """
    Updates device usage table with data from staging table.
    
    Args:
        data (dict): Request data containing:
            - created_by (str): User performing the operation
            - delayed_days (int): Number of days to delay usage date
            - staging_table (str): Name of staging table
            - tenant_name (str): Tenant name
            - service_provider (str): Service provider name
            - iccids (list): List of ICCIDs to process
    
    Returns:
        dict: Result with flag and message
    """
    logging.info(f"update_device_usage_table request received {data}")
    # Step 1: Extract required parameters from request data
    created_by = data.get("created_by", "Webbing Sync Container")
    delayed_days = data.get("delayed_days", 1)
    staging_table = data.get("staging_table",'webbing_carrier_sync_staging')
    tenant_name = data.get("tenant_name",None)
    tenant_id=data.get('tenant_id',None)
    service_provider_id=data.get('service_provider_id',None)
    # tenant_db_config      = data.get("tenant_db_config", {})
    iccids = []
    try:
        # Step 2: Fetch active ICCIDs from sim_management_inventory
        inventory_df = tenant_database.get_data(
            "sim_management_inventory",
            {"service_provider_id": service_provider_id,"tenant_id":tenant_id,"is_active":True},
            ["id", "iccid", "device_id", "mobility_device_id", "device_status_id"]
        )
        if inventory_df is not None and not inventory_df.empty:
            iccids = inventory_df["iccid"].astype(str).tolist()

        logging.info(f"Fetched {len(iccids)} active ICCIDs from main table")
        if not iccids:
            logging.info(f"No ICCIDs provided for {tenant_name}")
            return {"flag": False, "message": "No ICCIDs provided"}
        
        # Step 3: Calculate usage date based on delayed_days parameter
        usage_date = datetime.now().date() - timedelta(days=delayed_days)
        
        # Step 4: Fetch usage data from staging table for active ICCIDs
        staging_usage_df = tenant_database.get_data(
            staging_table,
            {"iccid": iccids},
            ["iccid", "total_usage"],
        )
        if staging_usage_df.empty:
            logging.warning(f"No staging usage records found for {tenant_name}")
            return {"flag": False, "message": "No staging usage records found"}
        
        # Step 5: Rename total_usage to data_usage for compatibility
        staging_usage_df = staging_usage_df.rename(columns={"total_usage": "data_usage"})
        
        # Step 6: Merge inventory and staging data on ICCID and remove duplicates
        usage_df = (
            pd.merge(inventory_df, staging_usage_df, on="iccid", how="inner")
            .drop_duplicates(subset=["iccid"])
            .reset_index(drop=True)
        )
        if usage_df.empty:
            logging.warning(f"No matched usage records after merge for {tenant_name}")
            return {"flag": False, "message": "No matched usage records"}

        # Webbing doesn't have sms_usage and voice_usage, so set them to 0
        if "sms_usage" not in usage_df.columns:
            usage_df["sms_usage"] = 0
        if "voice_usage" not in usage_df.columns:
            usage_df["voice_usage"] = 0

        device_ids = usage_df["device_id"].tolist()
        
        # Step 7: Check which device IDs already have usage records for the usage_date
        device_usage_present_df = tenant_database.get_data(
            "device_usage",
            {"m2m_device_id": device_ids, "usage_date": usage_date},
            ["m2m_device_id"],
        )
        existing_device_ids = set(
            device_usage_present_df["m2m_device_id"].tolist() if not device_usage_present_df.empty else []
        )
        
        # Step 8: Split merged data into new records (insert) and existing records (update)
        new_usage_df = usage_df[~usage_df["device_id"].isin(existing_device_ids)]
        update_usage_df = usage_df[usage_df["device_id"].isin(existing_device_ids)]
        
        # Step 9: Build and insert new device usage records
        if not new_usage_df.empty:
            insert_records = [
                {
                    "sim_management_inventory_id": row["id"],
                    "m2m_device_id": row["device_id"],
                    "mobility_device_id": row["mobility_device_id"],
                    "data_usage": row["data_usage"],
                    "sms_usage": 0,
                    "voice_usage": 0,
                    "usage_date": usage_date,
                    "device_status_id": row["device_status_id"],
                    "created_by": created_by,
                    "modified_by":created_by
                }
                for _, row in new_usage_df.iterrows()
            ]

            usage_insert_flag = tenant_database.insert_data(insert_records, "device_usage")
            logging.info(f"Inserted {len(insert_records)} usage records and usage_insert_flag is {usage_insert_flag}")
        
        # Step 10: Build and update existing device usage records
        if not update_usage_df.empty:
            update_records = [
                {
                    "sim_management_inventory_id": row["id"],
                    "m2m_device_id": row["device_id"],
                    "mobility_device_id": row["mobility_device_id"],
                    "data_usage": row["data_usage"],
                    "sms_usage": 0,
                    "voice_usage": 0,
                    "device_status_id": row["device_status_id"],
                    "modified_by":created_by
                }
                for _, row in update_usage_df.iterrows()
            ]

            usage_update_flag = tenant_database.bulk_update_data(
                "device_usage",
                update_records,
                search_column="m2m_device_id",
                static_conditions={"usage_date": usage_date}
            )
            logging.info(f"Updated {len(update_records)} usage records and usage_update_flag is {usage_update_flag}")
        
        # Step 11: Log success audit entry
        try:
            audit_data = {
                "service_name": "update_device_usage_table",
                "created_date": datetime.now(),
                "created_by": created_by,
                "status": "Success",
                "tenant_name": tenant_name,
                "comments": f"Updated device usage for {len(iccids)} ICCIDs on {usage_date}",
                "module_name": "Carrier Sync",
                "request_received_at": datetime.now(),
                "session_id": None
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Audit logging failed: {e}")
        
        # Step 12: Return success response
        return {"flag": True, "message": "Device usage updated successfully"}
        
    except Exception as e:
        logging.exception(f"Error in update_device_usage_table: {e}")
        
        # Step 13: Log error audit entry on failure
        try:
            error_data = {
                "service_name": "update_device_usage_table",
                "error_message": str(e),
                "error_type": str(type(e).__name__),
                "users": data.get("created_by", "Webbing Sync Container"),
                "session_id": None,
                "tenant_name": data.get("tenant_name", ""),
                "comments": f"Failed to update device usage for {data.get('service_provider', '')}",
                "module_name": "Carrier Sync",
                "request_received_at": datetime.now()
            }
            # common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as audit_error:
            logging.error(f"Error audit logging failed: {audit_error}")
        return {"flag": False, "message": "Failed to update device usage"}

# Function to handle history table updates for Webbing
def history_table_updates(data,tenant_database,common_utils_database):
    """
    Synchronizes cross-provider device history by identifying devices with usage
    that are not already in cross-provider history and inserting them.
    
    This function filters device usage records to find devices that have data usage
    but are not present in the cross-provider device history table, then creates
    cross-provider history records for those devices.
    
    Args:
        data (dict): Request data containing:
            - tenant_name (str): Name of the tenant
            - service_provider (str): Service provider name
            - created_by (str, optional): User who created the sync. Defaults to "Kore_Container"
            - usage_date (str): Date for which to sync usage data
    
    Returns:
        dict: Response containing:
            - flag (bool): Success/failure indicator
            - message (str): Status message
            - records_synced (int, optional): Number of records synchronized
    
    Raises:
        Exception: Any errors during database operations or data processing
    """
    logging.info(f"Received data for history_table_updates: {data}")
    # Step 1: Extract required parameters from request data
    tenant_id = int(data.get("tenant_id")) if data.get("tenant_id") else None
    service_provider_id = int(data.get("service_provider_id")) if data.get("service_provider_id") else None
    service_provider=data.get("service_provider_name",None)
    created_by = data.get("username", "webbing_container")
    tenant_name=data.get('tenant_name',None)
    raw_usage_date = data.get("usage_date")
    billing_period_id= int(data.get('billing_period_id')) if data.get('billing_period_id') else None
    if "telegence" in service_provider.lower():
        is_mobility = True
        history_dt_column = "mobility_device_tenant_id"
        inventory_dt_column = "mdt_id"
    else:
        is_mobility = False
        history_dt_column = "device_tenant_id"  
        inventory_dt_column = "dt_id"
    
    # Step 2: Parse usage date and calculate start/end datetime range
    # Handle both date formats: 'YYYY-MM-DD HH:MM:SS' and 'MM/DD/YYYY'
    try:
        usage_date = datetime.strptime(raw_usage_date, "%Y-%m-%d %H:%M:%S")
    except Exception as e:
        logging.exception(f"Exception while fetching usage_date{e}")
        usage_date = datetime.strptime(raw_usage_date, "%m/%d/%Y")
    # Start of day: 2026-02-03 00:00:00
    start_dt = usage_date.replace(hour=0, minute=0, second=0, microsecond=0)
    # End of day (exclusive): 2026-02-04 00:00:00
    end_dt = start_dt + timedelta(days=1)
    try:
        device_id_column = ("mobility_device_id" if "telegence" in service_provider.lower() else "device_id")
        # Fetch all active device IDs from sim_management_inventory
        active_devices_df = tenant_database.get_data(
            table_name="sim_management_inventory",
            condition={
                "is_active": True,
                "service_provider_id": service_provider_id
            },
            columns=[device_id_column]
        )
        # Convert device IDs into a Python list
        if active_devices_df is not None and not active_devices_df.empty:
            device_id_list = (active_devices_df[device_id_column].dropna().astype(int).tolist())     # Convert float → int
        else:
            device_id_list = []
        if not device_id_list:
            logging.warning("No active devices found in inventory table")
            return {"flag": False, "message": "No active devices found in Inventory table"}

        # Fetch device usage records (only devices with data_usage > 0)
        device_usage_query = f"""
            SELECT *
            FROM device_usage
            WHERE m2m_device_id = ANY(%s)
            AND usage_date >= %s
            AND usage_date < %s
            AND data_usage > 0
        """
        device_usage_df = tenant_database.execute_query(
            device_usage_query,
            params=[device_id_list, start_dt, end_dt]
        )
        logging.info(f"### history_table_updates length of device_usage_df : {len(device_usage_df)} and billing_period_id is {billing_period_id}")
        
        # Step 5: Fetch existing cross-provider device history records
        cross_provider_device_column = "mobility_device_id" if "Telegence" in service_provider else "m2m_device_id"
        cross_provider_devices_df = tenant_database.get_data(
            "cross_provider_device_history",
            {"service_provider_id": service_provider_id, 
             "billing_period_id": billing_period_id,
             "is_active": True
             },
             [cross_provider_device_column]
        )
        logging.info(f"### history_table_updates length of cross_provider_devices_df : {len(cross_provider_devices_df)}")
        
        # Step 6: Get all device IDs from usage records and fetch inventory data
        if device_usage_df is not None and not device_usage_df.empty:
            all_device_ids = (device_usage_df["m2m_device_id"].dropna().astype(int).tolist())     # Convert float → int
        else:
            all_device_ids = []
        if not all_device_ids:
            logging.info(f"### history_table_updates No device usage records found")
            return {"flag": True, "message": "No device usage records found."}
        logging.info(f"### history_table_updates all_device_ids : {all_device_ids}")
         
        inventory_device_column = "mobility_device_id" if "Telegence" in service_provider else "device_id"
        inventory_df = tenant_database.get_data(
            "sim_management_inventory",
            {inventory_device_column: all_device_ids, "is_active": True, "service_provider_id": service_provider_id}
        )
        logging.info(f"### history_table_updates inventory_df size : {len(inventory_df)}")
        
        # Step 7: Split device IDs into new and existing records
        if not cross_provider_devices_df.empty:
            cross_provider_device_ids = set(cross_provider_devices_df[cross_provider_device_column].tolist())
            new_device_ids = [did for did in all_device_ids if did not in cross_provider_device_ids]
            existing_device_ids = [did for did in all_device_ids if did in cross_provider_device_ids]
        else:
            new_device_ids = all_device_ids
            existing_device_ids = []

        # Step 8: Sync device history tables (device_history, mobility_device_history, smi_device_history)
        device_history_response=device_history_sync(billing_period_id,inventory_df,tenant_database,service_provider_id,service_provider,usage_date,created_by,common_utils_database,tenant_name,tenant_id)
        
        # Step 9: Define helper function to build cross-provider device history record   
        def build_record(row):
            """
            This function extracts SIM, device, customer, usage, and billing details
            from the given inventory row and prepares a dictionary payload for inserting or
            updating device history records.

            Args:
                row (dict/Series): Inventory row containing device and subscription data.
            Returns:
                dict: Device history record payload with tenant, plan, and usage fields.
            """
            record = {
                "m2m_device_id": row.get("device_id"),
                "mobility_device_id": row.get("mobility_device_id"),
                "service_provider_id": row.get("service_provider_id"),
                "iccid": row.get("iccid"),
                "msisdn": row.get("msisdn"),
                "imsi": row.get("imsi"),
                "imei": row.get("imei"),
                "carrier_rate_plan_id": row.get("carrier_rate_plan_id"),
                "created_by": row.get("created_by"),
                "created_date": row.get("created_date"),
                "modified_by": created_by,
                "modified_date": datetime.now(),
                "account_number": row.get("rev_customer_id"),
                "account_number_integration_authentication_id": row.get("account_number_integration_authentication_id"),
                "customer_id": row.get("customer_id"),
                "customer_rate_plan_id": row.get("customer_rate_plan_id"),
                "customer_rate_pool_id": row.get("customer_rate_pool_id"),
                "tenant_id": row.get("tenant_id"),
                "customer_data_allocation_mb": row.get("customer_data_allocation_mb"),
                "provider_date_added": row.get("date_added"),
                "provider_date_activated": row.get("date_activated"),
                "username": row.get("username"),
                "device_status_id": row.get("device_status_id"),
                "status": row.get("sim_status"),
                "rate_plan": row.get("carrier_rate_plan_name"),
                "last_usage_date": row.get("last_usage_date"),
                "carrier_cycle_usage": row.get("carrier_cycle_usage_bytes"),
                "ctd_sms_usage": row.get("ctd_sms_usage"),
                "ctd_voice_usage": row.get("ctd_voice_usage"),
                "ctd_session_count": row.get("ctd_session_count"),
                "last_activated_date": row.get("last_activated_date"),
                "billing_period_id": billing_period_id,
                "package": row.get("package"),
                "billing_cycle_end_date": row.get("billing_cycle_end_date"),
                "cost_center": row.get("cost_center"),
                "communication_plan": row.get("communication_plan"),
                "foundation_account_number": row.get("foundation_account_number"),
                "billing_account_number": row.get("billing_account_number"),
                "is_active": True,
                "is_deleted": False,
            }
            if tenant_id != row.get("tenant_id"):
                record["sub_tenant_carrier_rate_plan_name"] = record.get("sub_tenant_carrier_rate_plan_name")
                record["sub_tenant_carrier_rate_plan_name_id"] = int(record.get("sub_tenant_carrier_rate_plan_name_id")) if record.get("sub_tenant_carrier_rate_plan_name_id") else None
            if is_mobility:
                record["mobility_device_tenant_id"] = row.get("mdt_id")
                record["mobility_device_id"] = row.get("mobility_device_id")
            else:
                record["device_tenant_id"] = row.get("dt_id")
                record["m2m_device_id"] = row.get("device_id")
            return record
        
        # Step 10: Build records for new devices to insert
        new_records = []
        if new_device_ids:
            new_inventory_df = inventory_df[inventory_df["device_id"].isin(new_device_ids)]
            new_records = [build_record(row) for _, row in new_inventory_df.iterrows()]
            
        # Step 11: Build records for existing devices to update
        update_records = []
        if existing_device_ids:
            existing_inventory_df = inventory_df[inventory_df["device_id"].isin(existing_device_ids)]
            update_records = [build_record(row) for _, row in existing_inventory_df.iterrows()]
        
        # Step 12: Insert new cross-provider device history records
        inserted_count = 0
        inserted_ids = []
        if new_records:
            inserted_ids = tenant_database.insert_data_return_ids(new_records,"cross_provider_device_history", "id")
            inserted_count = len(inserted_ids)
            logging.info(f"Inserted {inserted_count} new cross-provider device history records")
        else:    
            logging.info(f"### history_table_updates No Records to insert into cross_provider_device_history table")    
        
        # Step 13: Update existing cross-provider device history records
        updated_count = 0
        updated_ids = []
        if update_records:
            # remove created_by and created_date from update records to avoid updating those fields
            for record in update_records:
                record.pop("created_by", None)
                record.pop("created_date", None)
            updated_ids = tenant_database.bulk_update_return_ids(
                "cross_provider_device_history", 
                update_records, 
                search_column=cross_provider_device_column,
                static_conditions={"service_provider_id": service_provider_id, "billing_period_id": billing_period_id, "tenant_id": tenant_id},
                return_id_column="id"
            )
            if updated_ids:
                updated_count = len(updated_ids)
                logging.info(f"Updated {updated_count} existing cross-provider device history records")
        else:
            logging.info(f"### history_table_updates No records found to update in cross_provider_device_history table")    
            
        ####################################### smi_cross_provider_device_history table ################################################
        
        # Step 14 : Combine inserted and updated IDs for smi_cross_provider_device_history sync
        smi_update_ids = inserted_ids + updated_ids
        logging.info(f"### smi_update_ids size : {len(smi_update_ids)} and inserted_ids size : {len(inserted_ids)} and updated_ids size: {len(updated_ids)}")
        ids_to_update_in_smi = []
        ids_to_insert_in_smi = []
        # Step 10: Check which device history IDs already exist in smi_cross_provider_device_history
        if smi_update_ids:
            smi_device_history_df = tenant_database.get_data(
                "smi_cross_provider_device_history",
                {"cdhid": smi_update_ids},
                ["id","cdhid"]
            )
            logging.info(f"### smi_device_history_df size :{len(smi_device_history_df)}")
            if not smi_device_history_df.empty:
                smi_device_history_ids = smi_device_history_df["cdhid"].tolist()
                ids_to_update_in_smi = [id for id in smi_update_ids if id in smi_device_history_ids]
                ids_to_insert_in_smi = [id for id in smi_update_ids if id not in smi_device_history_ids]
            else:
                ids_to_update_in_smi = []
                ids_to_insert_in_smi = smi_update_ids
        else:
            logging.info(f"### smi_update_ids size : {len(smi_update_ids)}") 

        # Step 11: Fetch updated device history records to get device_tenant_id mapping
        updated_device_history_df = tenant_database.get_data(
            "cross_provider_device_history",
            {"id": smi_update_ids},
            [history_dt_column,"id"]
        )

        logging.info(f"#### updated_device_history_df size:{len(updated_device_history_df)} ")
        if not updated_device_history_df.empty:
            updated_device_tenant_ids = updated_device_history_df[history_dt_column].tolist()
            device_history_dict = updated_device_history_df.set_index(history_dt_column)["id"].to_dict()
        else:
            updated_device_tenant_ids = []
            device_history_dict = {}
    
        # Step 15 : Fetch inventory records for devices that need smi_cross_provider_device_history sync
        inventory_df_for_smi = tenant_database.get_data(
            "sim_management_inventory",
            {inventory_dt_column: updated_device_tenant_ids, "is_active": True, "service_provider_id": service_provider_id}
        )
        logging.info(f"### inventory_df_for_smi size : {len(inventory_df_for_smi)}")
        
        # Step 16: Define helper function to build smi_cross_provider_device_history record
        def build_smi_cross_provider_record(row):
            """
                Build a record dictionary for inserting/updating `smi_cross_provider_device_history`.
                Args:
                    row (Series/dict): Inventory row containing device and usage details.
                Returns:
                    dict: Prepared SMI device history record.
            """
            device_tenant_id = row.get(inventory_dt_column)
            device_history_id = device_history_dict.get(device_tenant_id)
            record = {
                "changed_date": datetime.now(),
                "sim_management_inventory_id": row.get("id"),
                "service_provider_id": row.get("service_provider_id"),
                "iccid": row.get("iccid"),
                "imsi": row.get("imsi"),
                "msisdn": row.get("msisdn"),
                "imei": row.get("imei"),
                "device_status_id": row.get("device_status_id"),
                "carrier_rate_plan_id": row.get("carrier_rate_plan_id"),
                "communication_plan": row.get("communication_plan"),
                "communication_plan_id": row.get("communication_plan_id"),
                "customer_id": row.get("customer_id"),
                "customer_rate_plan_id": row.get("customer_rate_plan_id"),
                "customer_rate_plan_name": row.get("customer_rate_plan_name"),
                "customer_rate_pool_id": row.get("customer_rate_pool_id"),
                "customer_rate_pool_name": row.get("customer_rate_pool_name"),
                "last_usage_date": row.get("last_usage_date"),
                "carrier_cycle_usage": row.get("carrier_cycle_usage_bytes"),
                "created_by": created_by,
                "created_date": datetime.now(),
                "modified_by": created_by,
                "modified_date": datetime.now(),
                "last_activated_date": row.get("last_activated_date"),
                "is_active": True,
                "is_deleted": False,
                "account_number": row.get("rev_customer_id"),
                "provider_date_added": row.get("date_added"),
                "provider_date_activated": row.get("date_activated"),
                "cost_center": row.get("cost_center"),
                "username": row.get("username"),
                "account_number_integration_authentication_id": row.get("account_number_integration_authentication_id"),
                "billing_period_id": billing_period_id,
                "tenant_id": row.get("tenant_id"),
                "customer_data_allocation_mb": row.get("customer_data_allocation_mb"),
                "device_tenant_id": row.get("dt_id"),
                "mobility_device_tenant_id": row.get("mdt_id"),
                "foundation_account_number": row.get("foundation_account_number"),
                "billing_account_number": row.get("billing_account_number"),
                "ip_address": row.get("ip_address"),    
                "device_status":row.get("sim_status"),
                "carrier_sms_usage":row.get("carrier_sms_usage"),
                "carrier_voice_usage":row.get("carrier_voice_usage"),     
            }
            record["cdhid"] = device_history_id
            active_in_cycle = True if (row.get("sim_status").lower() in ["active","activated","a"]) else False
            if active_in_cycle:
                record["active_in_cycle"] = True
            else:
                record["active_in_cycle"] = False
                
            if tenant_id != row.get("tenant_id"):
                record["sub_tenant_carrier_rate_plan_name"] = record.get("sub_tenant_carrier_rate_plan_name")
                record["sub_tenant_carrier_rate_plan_name_id"] = int(record.get("sub_tenant_carrier_rate_plan_name_id")) if record.get("sub_tenant_carrier_rate_plan_name_id") else None
            if is_mobility:
                record["mobility_device_tenant_id"] = row.get("mdt_id")
                record["m2m_device_id"] =  row.get("device_id")
            else:
                record["device_tenant_id"] = row.get("dt_id")
                record["mobility_device_id"] =  row.get("device_id") 
            return record
        
        # Step 17: Build records for smi_cross_provider_device_history update
        smi_update_records = []
        smi_insert_records = [] 
        if ids_to_update_in_smi or ids_to_insert_in_smi : 
            for _, row in inventory_df_for_smi.iterrows():
                history_id = device_history_dict.get(row.get(inventory_dt_column))

                if history_id in ids_to_update_in_smi:
                    smi_update_records.append(build_smi_cross_provider_record(row))

                elif history_id in ids_to_insert_in_smi:
                    smi_insert_records.append(build_smi_cross_provider_record(row))
        logging.info(f"### smi_update_records : {len(smi_update_records)} and smi_insert_records size :{len(smi_insert_records)} ")        
                
        # Step 18 : Update existing smi_cross_provider_device_history records
        if smi_update_records:
            # remove created_by and created_date from update records to avoid updating those fields
            for record in smi_update_records:
                record.pop("created_by", None)
                record.pop("created_date", None)
            tenant_database.bulk_update_data(
                "smi_cross_provider_device_history",
                smi_update_records,
                search_column=history_dt_column,
                static_conditions={"service_provider_id": service_provider_id, "billing_period_id": billing_period_id}
            )
            logging.info(f"Updated {len(smi_update_records)} records in smi_cross_provider_device_history")
        else:
            logging.info(f"### No records found to update in smi_cross_provider_device_history smi_update_records : {len(smi_update_records)}")    

        # Step 19: Insert new smi_cross_provider_device_history records
        if smi_insert_records:
            tenant_database.insert_data(smi_insert_records, "smi_cross_provider_device_history")
            logging.info(f"Inserted {len(smi_insert_records)} records in smi_cross_provider_device_history")
        else:
            logging.info(f"### No records found to insert into smi_cross_provider_device_history table smi_insert_records size: {len(smi_insert_records)}")     
        # Step 20: Log success audit entry
        try:
            audit_data = {
                "service_name": "history_table_updates",
                "created_date": datetime.now(),
                "created_by": created_by,
                "status": "Success",
                "tenant_name": tenant_name,
                "comments": f"Cross-provider device history sync completed for {service_provider} on {usage_date}",
                "module_name": "Carrier Sync",
                "request_received_at": datetime.now(),
                "session_id": None
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Audit logging failed: {e}")            
        
        # Step 21: Return success response with sync summary
        response={
            "flag": True, 
            "message": f"Successfully synced cross-provider device history: {inserted_count} inserted, {updated_count} updated",
            "records_inserted": inserted_count,
            "records_updated": updated_count
        }
        return response
    except Exception as e:
        logging.error(f"Error in history_table_updates: {e}")
        
        # Error audit logging
        try:
            error_data = {
                "service_name": "history_table_updates",
                "error_message": str(e),
                "error_type": str(type(e).__name__),
                "users": created_by,
                "session_id": None,
                "tenant_name": tenant_name,
                "comments": f"Cross-provider device history sync failed for {service_provider} on {usage_date}",
                "module_name": "Carrier Sync",
                "request_received_at": datetime.now()
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as audit_error:
            logging.error(f"Error audit logging failed: {audit_error}")     
        response={"flag": False, "message": f"Error in history_table_updates: {str(e)}"}
        return response
    
# Function to sync device history records for a billing period based on inventory data
def device_history_sync(billing_period_id,inventory_df,tenant_database,service_provider_id,service_provider,usage_date,created_by,common_utils_database,tenant_name,tenant_id):
    """
    Sync device history records for a billing period.

    Inserts new device history entries and updates existing ones based on the
    current inventory data. Also maintains corresponding records in the
    `smi_device_history` table for reporting and auditing.

    Supports both Telegence (mobility) and standard service providers.

    Args:
        billing_period_id (int): Billing cycle identifier.
        inventory_df (DataFrame): Latest inventory/device data.
        tenant_database (DB): Tenant database connection object.
        service_provider_id (int): Service provider identifier.
        service_provider (str): Service provider name.
        usage_date (date/str): Usage date for sync reference.
        created_by (str): User triggering the sync.
        common_utils_database (DB): Common utilities database connection.
        tenant_name (str): Tenant name for audit logging.

    Returns:
        None
    """
    logging.info(f"Starting device_history_sync for billing_period_id: {billing_period_id}, service_provider_id: {service_provider_id} usage_date: {usage_date}")
    billing_period_id = int(billing_period_id) if billing_period_id else None
    service_provider_id = int(service_provider_id) if service_provider_id else None
    tenant_id = int(tenant_id) if tenant_id else None
    try:
        # Step 1: Determine table and column names based on service provider type
        if "telegence" in service_provider.lower():
            device_tenant_ids = inventory_df["mdt_id"].unique().tolist()
            history_table = "mobility_device_history"
            history_dt_column = "mobility_device_tenant_id"
            inventory_dt_column = "mdt_id"
            history_id_column = "mhid"
            is_mobility = True
        else:
            history_table = "device_history"
            device_tenant_ids = inventory_df["dt_id"].unique().tolist()
            history_dt_column = "device_tenant_id"
            inventory_dt_column = "dt_id"
            history_id_column = "dhid"
            is_mobility = False
        
        # Step 2: Fetch existing device history records for the billing period
        device_history_df = tenant_database.get_data(
            history_table,
            {"service_provider_id": service_provider_id, 
            "billing_period_id": billing_period_id,
            "is_active": True
            },
            [history_dt_column]
        )

        # Step 3: Split device IDs into new and existing based on history table
        if not device_history_df.empty:
            device_history_ids = set(device_history_df[history_dt_column].tolist())
            new_device_ids = [did for did in device_tenant_ids if did not in device_history_ids]
            existing_device_ids = [did for did in device_tenant_ids if did in device_history_ids]
        else:
            new_device_ids = device_tenant_ids
            existing_device_ids = []
        logging.info(f"device_history_sync - new_device_ids count: {len(new_device_ids)}, existing_device_ids count: {len(existing_device_ids)} , device_history_df size : {len(device_history_df)}")
        
        # Step 4: Define helper function to build device history record from inventory row
        def build_record(row):
            """
            Build a device history record from an inventory row. Prepares a dictionary for inserting/updating records in the
            device_history or mobility_device_history table, including service provider, SIM details, usage, and tenant mapping.
            
            Args:
                row (Series/dict): Inventory row containing device information.
            Returns:
                dict: Formatted device history record.
            """
            record = {
                "service_provider_id": row.get("service_provider_id"),
                "iccid": row.get("iccid"),
                "imsi": row.get("imsi"),
                "msisdn": row.get("msisdn"),
                "imei": row.get("imei"),
                "changed_date": datetime.now(),
                "device_status_id": row.get("device_status_id"),
                "status": row.get("sim_status"),
                "carrier_rate_plan_id": row.get("carrier_rate_plan_id"),
                "rate_plan": row.get("carrier_rate_plan_name"),
                "communication_plan": row.get("communication_plan"),
                "last_usage_date": row.get("last_usage_date"),
                "package": row.get("package"),
                "billing_cycle_end_date": row.get("billing_cycle_end_date"),
                "carrier_cycle_usage": row.get("carrier_cycle_usage_bytes"),
                "ctd_sms_usage": row.get("ctd_sms_usage"),
                "ctd_voice_usage": row.get("ctd_voice_usage"),
                "ctd_session_count": row.get("ctd_session_count"),
                "created_by": created_by,
                "created_date": datetime.now(),
                "modified_by": created_by,
                "modified_date": datetime.now(),
                "last_activated_date": row.get("last_activated_date"),
                "is_active": True,
                "is_deleted": False,
                "is_pushed": False,
                "account_number": row.get("rev_customer_id"),
                "provider_date_added": row.get("date_added"),
                "provider_date_activated": row.get("date_activated"),
                "cost_center": row.get("cost_center"),
                "username": row.get("username"),
                "account_number_integration_authentication_id": row.get("account_number_integration_authentication_id"),
                "billing_period_id": billing_period_id,
                "customer_id": row.get("customer_id"),
                "customer_rate_plan_id": row.get("customer_rate_plan_id"),
                "customer_rate_pool_id": row.get("customer_rate_pool_id"),
                "tenant_id": row.get("tenant_id")
            }
            if tenant_id != row.get("tenant_id"):
                record["sub_tenant_carrier_rate_plan_name"] = record.get("sub_tenant_carrier_rate_plan_name")
                record["sub_tenant_carrier_rate_plan_name_id"] = int(record.get("sub_tenant_carrier_rate_plan_name_id")) if record.get("sub_tenant_carrier_rate_plan_name_id") else None
            if is_mobility:
                record["id"] = row.get("mobility_device_id")
                record["mobility_device_tenant_id"] = row.get("mdt_id")
            else:
                record["id"] = row.get("device_id")
                record["device_tenant_id"] = row.get("dt_id")
            return record
        
        # Step 5: Build records for new devices to insert into device history
        new_records = []
        if new_device_ids:
            new_inventory_df = inventory_df[inventory_df[inventory_dt_column].isin(new_device_ids)]
            new_records = [build_record(row) for _, row in new_inventory_df.iterrows()]
        else:
            logging.info(f"### new_device_ids size: {len(new_device_ids)}")    
            
        # Step 6: Build records for existing devices to update in device history
        update_records = []
        if existing_device_ids:
            existing_inventory_df = inventory_df[inventory_df[inventory_dt_column].isin(existing_device_ids)]
            update_records = [build_record(row) for _, row in existing_inventory_df.iterrows()]
        else:
            logging.info(f"### existing_device_ids size: {len(existing_device_ids)}")    
        
        # Step 7: Insert new device history records and capture returned IDs
        inserted_count = 0
        inserted_ids = []
        if new_records:
            inserted_ids = tenant_database.insert_data_return_ids(new_records, history_table, "device_history_id")
            inserted_count = len(new_records)
            logging.info(f"Inserted {inserted_count} new device history records")
        else:
            logging.info(f"### device_history_sync No records found into Insert into : {history_table} table")    
        
        # Step 8: Update existing device history records and capture returned IDs
        updated_count = 0
        updated_ids = []
        if update_records:
            # remove created_by and created_date from update records to avoid updating those fields
            for record in update_records:
                record.pop("created_by", None)
                record.pop("created_date", None)
            updated_ids = tenant_database.bulk_update_return_ids(
                history_table,
                update_records, 
                search_column=history_dt_column,
                static_conditions={"service_provider_id": service_provider_id, "billing_period_id": billing_period_id},
                return_id_column="device_history_id"
            )
            if updated_ids:
                updated_count = len(update_records)
                logging.info(f"Updated {updated_count} existing device history records")
        else:
            logging.info(f"### device_history_sync No records found into Update into : {history_table} table")           
        
        # Step 9: Combine inserted and updated IDs for smi_device_history sync
        smi_update_ids = inserted_ids + updated_ids
        logging.info(f"### smi_update_ids size : {len(smi_update_ids)} and inserted_ids size : {len(inserted_ids)} and updated_ids size: {len(updated_ids)}")
        ids_to_update_in_smi = []
        ids_to_insert_in_smi = []
        # Step 10: Check which device history IDs already exist in smi_device_history
        if smi_update_ids:
            smi_device_history_df = tenant_database.get_data(
                "smi_device_history",
                {history_id_column: smi_update_ids},
                [history_id_column,"id"]
            )
            logging.info(f"### smi_device_history_df size :{len(smi_device_history_df)}")
            if not smi_device_history_df.empty:
                smi_device_history_ids = smi_device_history_df[history_id_column].tolist()
                ids_to_update_in_smi = [id for id in smi_update_ids if id in smi_device_history_ids]
                ids_to_insert_in_smi = [id for id in smi_update_ids if id not in smi_device_history_ids]
            else:
                ids_to_update_in_smi = []
                ids_to_insert_in_smi = smi_update_ids
        else:
            logging.info(f"### smi_update_ids size : {len(smi_update_ids)}")        

        # Step 11: Fetch updated device history records to get device_tenant_id mapping
        updated_device_history_df = tenant_database.get_data(
            history_table,
            {"device_history_id": smi_update_ids},
            [history_dt_column,"device_history_id"]
        )

        # updated_device_tenant_ids = updated_device_history_df[history_dt_column].tolist()
        # device_history_dict = (
        #     updated_device_history_df
        #     .set_index(history_dt_column)["device_history_id"]
        #     .to_dict()
        # )
        logging.info(f"#### updated_device_history_df size:{len(updated_device_history_df)} ")
        if not updated_device_history_df.empty:
            updated_device_tenant_ids = updated_device_history_df[history_dt_column].tolist()
            device_history_dict = updated_device_history_df.set_index(history_dt_column)["device_history_id"].to_dict()
        else:
            updated_device_tenant_ids = []
            device_history_dict = {}
    
        # Step 12: Fetch inventory records for devices that need smi_device_history sync
        inventory_df_for_smi = tenant_database.get_data(
            "sim_management_inventory",
            {inventory_dt_column: updated_device_tenant_ids, "is_active": True, "service_provider_id": service_provider_id}
        )
        logging.info(f"### inventory_df_for_smi size : {len(inventory_df_for_smi)}")
        
        # Step 13: Define helper function to build smi_device_history record
        def build_smi_record(row):
            """
                Build a record dictionary for inserting/updating `smi_device_history`.
                Args:
                    row (Series/dict): Inventory row containing device and usage details.
                Returns:
                    dict: Prepared SMI device history record.
            """
            device_tenant_id = row.get(inventory_dt_column)
            device_history_id = device_history_dict.get(device_tenant_id)
            record = {
                "changed_date": datetime.now(),
                "sim_management_inventory_id": row.get("id"),
                "service_provider_id": row.get("service_provider_id"),
                "service_provider_name": row.get("service_provider_display_name"),
                "iccid": row.get("iccid"),
                "imsi": row.get("imsi"),
                "msisdn": row.get("msisdn"),
                "imei": row.get("imei"),
                "device_status_id": row.get("device_status_id"),
                "status": row.get("sim_status"),
                "carrier_rate_plan_id": row.get("carrier_rate_plan_id"),
                "carrier_rate_plan_name": row.get("carrier_rate_plan_name"),
                "communication_plan": row.get("communication_plan"),
                "communication_plan_id": row.get("communication_plan_id"),
                "customer_id": row.get("customer_id"),
                "customer_name": row.get("customer_name"),
                "customer_rate_plan_id": row.get("customer_rate_plan_id"),
                "customer_rate_plan_name": row.get("customer_rate_plan_name"),
                "customer_rate_pool_id": row.get("customer_rate_pool_id"),
                "customer_rate_pool_name": row.get("customer_rate_pool_name"),
                "last_usage_date": row.get("last_usage_date"),
                "billing_cycle_end_date": row.get("billing_cycle_end_date"),
                "carrier_cycle_usage": row.get("carrier_cycle_usage_bytes"),
                "ctd_sms_usage": row.get("ctd_sms_usage"),
                "ctd_voice_usage": row.get("ctd_voice_usage"),
                "ctd_session_count": row.get("ctd_session_count"),
                "created_by": created_by,
                "created_date": datetime.now(),
                "modified_by": created_by,
                "modified_date": datetime.now(),
                "last_activated_date": row.get("last_activated_date"),
                "is_active": True,
                "is_deleted": False,
                "account_number": row.get("rev_customer_id"),
                "provider_date_added": row.get("date_added"),
                "provider_date_activated": row.get("date_activated"),
                "cost_center": row.get("cost_center"),
                "username": row.get("username"),
                "account_number_integration_authentication_id": row.get("account_number_integration_authentication_id"),
                "billing_period_id": billing_period_id,
                "tenant_id": row.get("tenant_id"),
                "customer_data_allocation_mb": row.get("customer_data_allocation_mb"),
                "device_id": row.get("device_id"),
                "device_tenant_id": row.get("dt_id"),
                "mobility_device_tenant_id": row.get("mdt_id"),
                "foundation_account_number": row.get("foundation_account_number"),
                "billing_account_number": row.get("billing_account_number"),
                "ip_address": row.get("ip_address"),                
            }
            if is_mobility:
                record["mhid"] = device_history_id
            else:
                record["dhid"] = device_history_id
            active_in_cycle = True if (row.get("sim_status").lower() in ["active","activated","a"]) else False
            if active_in_cycle:
                record["active_in_cycle"] = True
            else:
                record["active_in_cycle"] = False
            return record
        
        # Step 14: Build records for smi_device_history update
        smi_update_records = []
        smi_insert_records = []
        if ids_to_update_in_smi or ids_to_insert_in_smi : 
            for _, row in inventory_df_for_smi.iterrows():
                history_id = device_history_dict.get(row.get(inventory_dt_column))

                if history_id in ids_to_update_in_smi:
                    smi_update_records.append(build_smi_record(row))

                elif history_id in ids_to_insert_in_smi:
                    smi_insert_records.append(build_smi_record(row))
        logging.info(f"### smi_update_records : {len(smi_update_records)} and smi_insert_records size :{len(smi_insert_records)} ")        
                

        # Step 16: Update existing smi_device_history records
        if smi_update_records:
            # remove created_by and created_date from update records to avoid updating those fields
            for record in smi_update_records:
                record.pop("created_by", None)
                record.pop("created_date", None)
            tenant_database.bulk_update_data(
                "smi_device_history",
                smi_update_records,
                search_column=history_dt_column,
                static_conditions={"service_provider_id": service_provider_id, "billing_period_id": billing_period_id}
            )
            logging.info(f"Updated {len(smi_update_records)} records in smi_device_history")
        else:
            logging.info(f"### No records found to update in smi_device_history smi_update_records : {len(smi_update_records)}")    

        # Step 17: Insert new smi_device_history records
        if smi_insert_records:
            tenant_database.insert_data(smi_insert_records, "smi_device_history")
            logging.info(f"Inserted {len(smi_insert_records)} records in smi_device_history")
        else:
            logging.info(f"### No records found to insert into smi_device_history table smi_insert_records size: {len(smi_insert_records)}")    
        
        # Step 18: Log success audit entry
        try:
            audit_data = {
                "service_name": "device_history_sync",
                "created_date": datetime.now(),
                "created_by": created_by,
                "status": "Success",
                "tenant_name": tenant_name,
                "comments": f"device history sync completed for {service_provider_id} on {usage_date}",
                "module_name": "Carrier Sync",
                "request_received_at": datetime.now(),
                "session_id": None
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Audit logging failed: {e}")

    except Exception as e:
        logging.error(f"Error in device_history_sync: {e}")
        
        # Step 19: Log error audit entry on failure
        try:
            error_data = {
                "service_name": "device_history_sync",
                "error_message": str(e),
                "error_type": str(type(e).__name__),
                "users": created_by,
                "session_id": None,
                "tenant_name": tenant_name,
                "comments": f"device history sync failed for {service_provider_id} on {usage_date}",
                "module_name": "Carrier Sync",
                "request_received_at": datetime.now()
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as audit_error:
            logging.error(f"Error audit logging failed: {audit_error}")