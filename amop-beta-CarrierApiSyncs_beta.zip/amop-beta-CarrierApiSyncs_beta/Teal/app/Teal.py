"""
@Author: Phaneenndra
Created Date: 2026-02-2
"""
# Importing the necessary Libraries
import os
import time
import logging
import requests
import xml.etree.ElementTree as ET
import xmltodict
import json
from datetime import datetime, date, timedelta
from concurrent.futures import ThreadPoolExecutor, as_completed
import threading
import numpy as np
import pandas as pd
from urllib.parse import urlencode

## Importing the necessary modules
from common_utils.db_utils import DB
from common_utils.email_trigger import send_email

# Database configuration
common_utils_db_config = {
     "host": os.environ["HOST"],
     "port": os.environ["PORT"],
     "user": os.environ["USER"],
     "password": os.environ["PASSWORD"],
 }

##function caller where the functions begins
def funtion_caller(data,path):
    """
    Main function caller that handles database configuration setup and routes requests.
    
    Args:
        data (dict): Request data containing user/tenant information
        path (str): API endpoint path being called
        
    Returns:
        Result of the called endpoint function or error response
    """
    # Route to appropriate endpoint handler
    if path == "/run_teal_sync":
        result = run_teal_sync(data)
    ##else condition to handle the invalid path method
    else:
        result = {"flag":False,"error": "Invalid path or method"}
        logging.info(f"Invalid path or method requested: {path}")
    return result

## Helper function to normalize pending_plan_id
def normalize_pending_plan_id(value):
    """Normalize pending_plan_id: convert int/float → str or None"""
    if value is None or pd.isna(value) or value == "":
        return None
    val = str(value).strip().lower()
    return None if val in ["", "nan", "none"] else str(value)

## Teal carrier daily sync function
def run_teal_sync(data):
    """
    Teal Carrier Daily Sync

    Performs the daily carrier sync for Teal by:
    - Retrieving device details and usage data from the carrier
    - Retrieving carrier rate plans from the carrier
    - Storing data in staging tables
    - Syncing staging data to main AMOP tables
    - Recording sync progress and status in audit tables
    - Sending success or failure notification emails

    Returns:
        dict: Sync result with success or failure details.
    """
    logging.info(f"Received data teal sync: %s", data)
    start_time = time.time()
    start_time_dt = datetime.now()
    start_time_ts = time.time()
    
    # Fetch required fields
    service_provider_name = data.get("service_provider_name")
    username              = data.get("username", "Teal_Container")
    service_provider_id   = data.get("service_provider_id")
    integration_id        = data.get("integration_id")
    tenant_id             = data.get("tenant_id")
    tenant_name           = data.get("tenant_name")
    tenant_db_config      = data.get("tenant_db_config", {})
    api_details_map       = data.get("api_details_map", {})
    db_name               = data.get("db_name")
    progress_tracker_id   = data.get("progress_tracker_id")
    
    # Fetch delayed_days from the request data
    delayed_days          = data.get("delayed_days", 1)
    today = datetime.now()
    start_date_obj = today - timedelta(days=delayed_days)
    end_date_obj = today - timedelta(days=delayed_days)
    start_date = start_date_obj.strftime("%Y-%m-%d")
    end_date = end_date_obj.strftime("%Y-%m-%d")
    data['start_date'] = start_date
    data['end_date'] = end_date
    data["usage_date"] = start_date_obj.strftime("%Y-%m-%d %H:%M:%S")
    data["created_by"] = username
    
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # Initialize tracking variables for email
    staging_table_cleanup = False
    devices_fetch = False
    usage_fetch = False
    carrier_rate_plans_fetch = False
    staging_to_main_tables_sync = False
    device_usage_sync = False
    history_tables_sync = False
    email_trigger = False
    total_devices_count = 0
    usage_count = 0
    carrier_rate_plans_count = 0
    module_name = "Carrier Sync"
    
    logging.info(f"### run_teal_sync devices and {tenant_name} time is {now}")
    logging.info(f"### run_teal_sync devices and {tenant_name} delayed_days: {delayed_days}")
    
    #Step 1: Database connection
    try:
        tenant_database = DB(db_name, **tenant_db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_db_config)
    except Exception as e:
        logging.error(f"### run_teal_sync and {tenant_name} DB connection error: %s", e)
        return {"flag": False, "message": "DB connection failed in run_teal_sync", "details": str(e)}
    
    ### send email for initiating sync 
    sync_data = {
        "Sync Type": "Daily Sync",    
        "Partner Name": tenant_name,    
        "Carrier Name": service_provider_name,    
        "Start Time": start_time_dt.strftime("%m-%d-%Y %H:%M:%S"),    
        "System / Job Name": "Scheduler"
    }
    trigger_sync_email(
        template_name="Sync Initiated",
        subject=f"Sync Initiated - {tenant_name} - {service_provider_name} - Daily Sync - {start_date_obj.strftime('%m-%d-%Y')}",
        data_dict=sync_data,
        tenant_name=tenant_name,
        log_prefix="### run_teal_sync Sync Initiated"
    )
    
    #Step 2: Progress Tracking - Staging cleanup started
    try:
        update_progress_tracker(progress_tracker_id, current_status="Staging cleanup started", status="In Progress",
                                 common_utils_database=common_utils_database, action="update", now=now, progress=5, data=data)
        logging.info(f"### run_teal_sync devices and {tenant_name} Staging cleanup Started")
    except Exception as e:
        logging.exception(f"### run_teal_sync devices and {tenant_name} Error updating progress tracker: {e}")
    
    try:
        ##Step 3: Cleaning the staging tables
        cleanup_response = clean_staging_table(
            tenant_database, 
            [
                "teal_carrier_sync_staging",
                "teal_carrier_rate_plan_staging",
                "teal_carrier_usage_staging"
            ], 
            username
        )
        logging.info(f"### run_teal_sync devices and {tenant_name} cleanup_response: {cleanup_response}")
        
        if all(result.get("flag", False) for result in cleanup_response.get("details", {}).values()):
            staging_table_cleanup = True
            cleanup_message = "Successful"
            cleanup_progress = 10
            cleanup_status = "In Progress"
        else:
            cleanup_message = "Failed"
            cleanup_progress = 100
            cleanup_status = "Failed"
            raise Exception("Staging tables cleanup failed")

        logging.info(f"### run_teal_sync devices and {tenant_name} Staging cleanup {cleanup_message}")
        
        #Progress Tracking: Update progress tracker - Staging cleanup status
        try:
            update_progress_tracker(progress_tracker_id, current_status=f"Staging cleanup {cleanup_message}", status=cleanup_status,
                                     common_utils_database=common_utils_database, action="update", now=now, progress=cleanup_progress, data=data)
        except Exception as e:
            logging.exception(f"### run_teal_sync devices and {tenant_name} Error updating progress tracker: {e}")
        
        ##Step 4: Billing Period Logic
        billing_info = get_or_create_billing_period(
            tenant_id=tenant_id,
            service_provider_id=service_provider_id,
            service_provider_name=service_provider_name,
            tenant_database=tenant_database,
            common_utils_database=common_utils_database,
            progress_tracker_id=progress_tracker_id,
            billing_cycle_day=1,
            force_end_of_day=True,
            data=data
        )
        
        # Check if billing_info has flag and extract billing_period_id correctly
        if not billing_info.get("flag", True):
            logging.error(f"### run_teal_sync devices and {tenant_name} - Billing period error: {billing_info.get('message')}")
            return billing_info
            
        billing_period_id = billing_info["billing_period_id"]
        data["billing_period_id"] = billing_period_id

        # Update progress tracker - Billing period determined
        try:
            update_progress_tracker(progress_tracker_id, current_status="Billing period determined", status="In Progress", common_utils_database=common_utils_database,
                                     action="update", now=now, progress=15, data=data)
        except Exception as e:
            logging.exception(f"### run_teal_sync devices and {tenant_name} Error updating progress tracker: {e}")

        ##Step 5: Fetch Integration Details from tenant database
        integration_response = fetch_integration_details(
            tenant_database, 
            integration_id,
            tenant_name,
            tenant_id
        )
        
        if not integration_response.get("flag"):
            try:
                update_progress_tracker(progress_tracker_id, current_status=f"Integration details fetch failed", status="Failed", 
                                        common_utils_database=common_utils_database, action="update", now=now, progress=100, data=data)
            except Exception as e:
                logging.exception(f"### run_teal_sync devices and {tenant_name} Error updating progress tracker: {e}")
            return integration_response

        # Get the integration details from the list
        integration_details_list = integration_response.get("integration_details", [])
        if not integration_details_list:
            try:
                update_progress_tracker(progress_tracker_id, current_status=f"No integration details found", status="Failed",
                                         common_utils_database=common_utils_database, action="update", now=now, progress=100, data=data)
            except Exception as e:
                logging.exception(f"### run_teal_sync devices and {tenant_name} Error updating progress tracker: {e}")
            return {"flag": False, "message": "No integration details found"}

        # Get the first integration detail
        integration_detail = integration_details_list[0]
        # Map from integration_authentication table:
        api_key = integration_detail.get("username")  # This is the ApiKey
        api_secret = integration_detail.get("password")  # This is the ApiSecret
        
        logging.info(f"### run_teal_sync for {tenant_name} - API credentials fetched - api_key present: {bool(api_key)}, api_secret present: {bool(api_secret)}")
        
        #Progress Tracking: Update progress tracker - API credentials fetched
        try:
            update_progress_tracker(progress_tracker_id, current_status=f"API credentials loaded", status="In Progress",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=20, data=data)
        except Exception as e:
            logging.exception(f"### run_teal_sync devices and {tenant_name} Error updating progress tracker: {e}")
        
        # Fetch API details from the request
        api_limit = api_details_map.get("api_limit", 100)
        retries = api_details_map.get("retries", 10)
        page_limit = api_details_map.get("page_limit", 100)
        sleep_time = api_details_map.get("sleep_time", 60)
        bill_period = api_details_map.get("bill_period", 1)
        
        # Teal API URLs from data.get()
        teal_esim_url = data.get("custom_url1", {}).get("url")  # For eSIM devices
        teal_callback_url = data.get("custom_url2", {}).get("url")  # For callback
        teal_plan_url = data.get("custom_url3", {}).get("url")  # For carrier rate plans
        teal_usage_url = data.get("get_device_usage_url", {}).get("url")  # For usage data
        
        logging.info(f"### run_teal_sync devices and {tenant_name} Using teal_esim_url: {teal_esim_url}")
        logging.info(f"### run_teal_sync devices and {tenant_name} Using teal_usage_url: {teal_usage_url}")
        logging.info(f"### run_teal_sync devices and {tenant_name} Using teal_plan_url: {teal_plan_url}")
        
        ##Step 6: Calculate Sync Run Count
        try:
            # Get the latest sync_run_count
            result = tenant_database.get_data(
                table_name="teal_carrier_sync_staging_audit",
                columns=["sync_run_count", "sync_date"],
                order={"id": "desc"},
                mod_pages={"start": 0, "end": 1}
            )
            
            today_date = datetime.now().date()
            
            if not result.empty:
                last_sync_date = result.iloc[0]["sync_date"]
                
                # Convert to date if it's datetime
                if isinstance(last_sync_date, datetime):
                    last_sync_date = last_sync_date.date()
                
                # Check if last sync was today
                if last_sync_date == today_date:
                    sync_run_count = int(result.iloc[0]["sync_run_count"]) + 1
                    logging.info(f"### Same day sync detected for {tenant_name} - Incrementing sync_run_count to {sync_run_count}")
                else:
                    sync_run_count = 0 
                    logging.info(f"### New day sync detected for {tenant_name} - Resetting sync_run_count to 0")
            else:
                sync_run_count = 0
                logging.info(f"### First sync for {tenant_name} - Setting sync_run_count to 0")
                
        except Exception as e:
            logging.error(f"Error getting sync run count: {e}")
            sync_run_count = 0
        
        logging.info(f"### run_teal_sync for {tenant_name} - Final sync run count: {sync_run_count}")
        
        ##Step 7: Fetch all device data from Teal and insert into staging
        try:
            # Update progress - Starting device fetch
            update_progress_tracker(progress_tracker_id, current_status="Fetching device details from carrier", status="In Progress",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=25, data=data)
            
            # Create a cache to track seen ICCIDs
            seen_iccids_cache = set()
            
            # Fetch devices with pagination and parallel insertion
            try:
                # Update progress - Starting devices fetch
                update_progress_tracker(progress_tracker_id, current_status="Fetching devices from carrier", status="In Progress",
                                         common_utils_database=common_utils_database, action="update", now=now, progress=30, data=data)
                logging.info(f"### Fetching devices from carrier for {tenant_name}")
                
                devices_list, total_devices_count = fetch_teal_devices_parallel_insert(
                    api_key=api_key,
                    api_secret=api_secret,
                    tenant_name=tenant_name,
                    base_url=teal_esim_url,
                    callback_url=teal_callback_url,
                    page_limit=page_limit,
                    sleep_time=sleep_time,
                    max_retries=retries,
                    tenant_database=tenant_database,
                    service_provider_id=service_provider_id,
                    service_provider_name=service_provider_name,
                    billing_period_id=billing_period_id,
                    sync_run_count=sync_run_count,
                    seen_iccids_cache=seen_iccids_cache,
                    created_by=username,
                    now=now
                )
                
                devices_fetch = True
                
                # Update progress - Devices fetched
                update_progress_tracker(progress_tracker_id, current_status=f"Devices fetched and inserted ({total_devices_count} records)", status="In Progress",
                                         common_utils_database=common_utils_database, action="update", now=now, progress=45, data={**data, "total_records_synced": total_devices_count})
                logging.info(f"### Devices fetched and inserted for {tenant_name}: {total_devices_count} records")
                
            except Exception as e:
                logging.exception(f"### Error fetching devices for {tenant_name}: {e}")
                devices_fetch = False
                raise Exception(f"Failed to fetch devices: {str(e)}")
            
        except Exception as e:
            logging.exception(f"### run_teal_sync devices and {tenant_name} Error fetching device data: {e}")
            devices_fetch = False
            raise Exception(f"Device fetch failed: {str(e)}")
        
        ##Step 8: Fetch and insert carrier rate plans data
        try:
            # Update progress - Starting carrier rate plans fetch
            update_progress_tracker(progress_tracker_id, current_status="Fetching and inserting carrier rate plans from carrier", status="In Progress",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=50, data=data)
            logging.info(f"### Fetching and inserting carrier rate plans from carrier for {tenant_name}")
            
            # Fetch AND insert carrier rate plans
            carrier_rate_plans_result = fetch_and_insert_teal_carrier_rate_plans_parallel(
                tenant_database=tenant_database,
                api_key=api_key,
                api_secret=api_secret,
                tenant_name=tenant_name,
                base_url=teal_plan_url,
                callback_url=teal_callback_url,
                page_limit=page_limit,
                sleep_time=sleep_time,
                max_retries=retries,
                now=now,
                created_by=username
            )
            
            carrier_rate_plans_count = carrier_rate_plans_result.get("carrier_rate_plans_count", 0)
            carrier_rate_plans_fetch = carrier_rate_plans_result.get("flag", False)
            
            if carrier_rate_plans_result.get("flag"):
                logging.info(f"### Carrier rate plans fetched and inserted successfully for {tenant_name}: {carrier_rate_plans_count} records")
            else:
                logging.warning(f"### Carrier rate plans fetch/insert issue for {tenant_name}: {carrier_rate_plans_result.get('message')}")
            
            # Update progress - Carrier rate plans fetched and inserted
            update_progress_tracker(progress_tracker_id, current_status=f"Carrier rate plans processed ({carrier_rate_plans_count} records)", status="In Progress",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=60, data=data)
            
        except Exception as e:
            logging.exception(f"### Error fetching and inserting carrier rate plans for {tenant_name}: {e}")
            carrier_rate_plans_count = 0
            carrier_rate_plans_fetch = False
            # Don't raise exception here - continue with usage fetch even if plans fail
        
        ##Step 9: Fetch usage data and insert into staging
        try:
            # Update progress - Starting usage data fetch
            update_progress_tracker(progress_tracker_id, current_status="Fetching usage data from carrier", status="In Progress",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=65, data=data)
            logging.info(f"### Fetching usage data from carrier for {tenant_name}")
            
            usage_count = fetch_teal_usage_data_parallel_insert(
                api_key=api_key,
                api_secret=api_secret,
                tenant_name=tenant_name,
                base_url=teal_usage_url,
                callback_url=teal_callback_url,
                page_limit=page_limit,
                sleep_time=sleep_time,
                max_retries=retries,
                start_date=start_date,
                end_date=end_date,
                service_provider_id=service_provider_id,
                service_provider_name=service_provider_name,
                billing_period_id=billing_period_id,
                sync_run_count=sync_run_count,
                tenant_database=tenant_database,
                created_by=username,
                now=now
            )
            
            usage_fetch = True if usage_count > 0 else False
            logging.info(f"### Usage data fetched and inserted for {tenant_name}: {usage_count} records")
            
            # Update progress - Usage data fetched
            update_progress_tracker(progress_tracker_id, current_status=f"Usage data fetched and inserted ({usage_count} records)", status="In Progress",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=70, data=data)
            
        except Exception as e:
            logging.exception(f"### Error fetching usage data for {tenant_name}: {e}")
            usage_count = 0
            usage_fetch = False
            raise Exception(f"Usage data fetch failed: {str(e)}")
        
        ##Step 10: Sync staging data to main tables
        try:
            # Update progress - Starting staging to main sync
            update_progress_tracker(progress_tracker_id, current_status="Syncing staging data to main tables", status="In Progress",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=75, data=data)
            logging.info(f"### Syncing staging data to main tables for {tenant_name}")
            
            sync_main_table_response = sync_staging_to_main(
                data=data,
                tenant_database=tenant_database,
                common_utils_database=common_utils_database,
                progress_tracker_id=progress_tracker_id
            )
            
            if not sync_main_table_response.get("flag"):
                logging.error(f"### Staging to main sync failed for {tenant_name}: {sync_main_table_response.get('message')}")
                current_status = "Failed syncing data from staging to main tables"
                staging_to_main_tables_sync = False
            else:
                staging_to_main_tables_sync = True
                logging.info(f"### Staging to main sync successful for {tenant_name}")
                current_status = "Successfully synced data from staging to main tables"
            
            # Update progress - Staging to main sync completed
            update_progress_tracker(progress_tracker_id, current_status=current_status, status="In Progress",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=80, data=data)
            
            if not staging_to_main_tables_sync:
                raise Exception("Failed syncing data from staging to main tables")
            
        except Exception as e:
            logging.exception(f"### Error syncing staging to main for {tenant_name}: {e}")
            staging_to_main_tables_sync = False
            raise Exception(f"Staging to main sync failed: {str(e)}")
        
        ##Step 11: Update device usage table
        try:
            # Update progress - Starting device usage update
            update_progress_tracker(progress_tracker_id, current_status="Updating device usage table", status="In Progress",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=85, data=data)
            logging.info(f"### Updating device usage table for {tenant_name}")
            
            device_usage_response = update_teal_device_usage_table(
                data=data,
                tenant_database=tenant_database,
                common_utils_database=common_utils_database
            )
            
            if not device_usage_response.get("flag"):
                logging.error(f"### Device usage update failed for {tenant_name}: {device_usage_response.get('message')}")
                current_status = "Failed to Update or Insert in Device Usage Table"
                device_usage_sync = False
            else:
                device_usage_sync = True
                logging.info(f"### Device usage update successful for {tenant_name}")
                current_status = "Successfully Updated or Inserted in Device Usage Table"
            
            # Update progress - Device usage update completed
            update_progress_tracker(progress_tracker_id, current_status=current_status, status="In Progress",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=90, data=data)
            
            if not device_usage_sync:
                raise Exception("Failed to Update or Insert in Device Usage Table")
            
        except Exception as e:
            logging.exception(f"### Error updating device usage for {tenant_name}: {e}")
            device_usage_sync = False
            raise Exception(f"Device usage update failed: {str(e)}")
        
        ##Step 12: Update history tables
        try:
            # Update progress - Starting history tables update
            update_progress_tracker(progress_tracker_id, current_status="Updating history tables", status="In Progress",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=92, data=data)
            logging.info(f"### Updating history tables for {tenant_name}")
            
            history_response = history_table_updates(
                data=data,
                tenant_database=tenant_database,
                common_utils_database=common_utils_database
            )
            
            if not history_response.get("flag"):
                logging.error(f"### History tables update failed for {tenant_name}: {history_response.get('message')}")
                current_status = "Failed to Update or Insert in History Tables"
                history_tables_sync = False
            else:
                history_tables_sync = True
                logging.info(f"### History tables update successful for {tenant_name}")
                current_status = "Successfully Updated or Inserted data into History Tables"
            
            # Update progress - History tables update completed
            update_progress_tracker(progress_tracker_id, current_status=current_status, status="In Progress",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=95, data=data)
            
            if not history_tables_sync:
                raise Exception("Failed to Update or Insert in History Tables")
            
        except Exception as e:
            logging.exception(f"### Error updating history tables for {tenant_name}: {e}")
            history_tables_sync = False
            raise Exception(f"History tables update failed: {str(e)}")
        
        ##Step 13: Get inventory details for email
        # Fetch Query from the database based on the module name -> to get counts per status and total usage
        module_query_df = common_utils_database.get_data(
            "export_queries", {"module_name": module_name}
        )
        
        ##checking the dataframe is empty or not
        if module_query_df.empty:
            return {"flag": False, "message": f"No query found for module name: {module_name}"}
        
        # Extract the query string from the DataFrame
        query = module_query_df.iloc[0]["module_query"]
        if not query:
            return {"flag": False, "message": f"Unknown module name : {module_name} for tenant :{tenant_name}"}
        
        # Execute the query
        result = tenant_database.execute_query(query, params=[service_provider_id])
        status_variables = {}
        aggregate_usage_bytes = 0
        total_devices = 0
        total_devices_with_usage = 0

        # Map result to variables
        if result is not None and not result.empty:
            for _, row in result.iterrows():
                status_name = row['sim_status'].lower()
                count = row['device_count']
                usage = row['total_usage_bytes']
                devices_with_usage_count = row['devices_with_usage_count']
                
                # Create a dynamic key in the dictionary for each status
                status_variables[f"{status_name}_devices"] = count
                # Add to totals
                total_devices += count
                total_devices_with_usage += devices_with_usage_count
                aggregate_usage_bytes += usage

        ##Step 14: Send email in sync successful case  
        # First, create a statuses dictionary that the replace_placeholders_with_table function expects
        statuses_dict = {}
        for status_key, count in status_variables.items():
            # Extract just the status name (remove '_devices' suffix)
            status_name = status_key.replace('_devices', '').title()
            statuses_dict[status_name] = count
        
        # Construct dynamic sync summary with the special 'statuses' key
        end_time_ts = time.time()
        end_time_dt = datetime.now()
        duration_seconds = int(end_time_ts - start_time_ts)
        duration_mm_ss = f"{duration_seconds // 60}:{duration_seconds % 60:02d}"
        
        billing_cycle_start_date = billing_info.get("billing_period_details", {}).get("billing_cycle_start_date")
        billing_cycle_end_date = billing_info.get("billing_period_details", {}).get("billing_cycle_end_date")
        
        sync_summary_data = {
            "Partner Name": tenant_name,
            "Carrier Name": service_provider_name,
            "Sync Timeline": f"{start_time_dt.strftime('%m-%d-%Y %H:%M:%S')} - {end_time_dt.strftime('%m-%d-%Y %H:%M:%S')} (Duration: {duration_mm_ss} minutes)",
            "Device Sync Status": "Success",
            "Total Devices": total_devices,  # All devices (including those with zero usage)
            "Usage Sync Status": "Success",
            "Bill Cycle": f"{billing_cycle_start_date.strftime('%m-%d-%Y %H:%M:%S')} - {billing_cycle_end_date.strftime('%m-%d-%Y %H:%M:%S')}",
            "Devices with Usage": total_devices_with_usage,  # Only devices with usage > 0
            "Aggregate Usage": f"{round(aggregate_usage_bytes / (1024 * 1024), 2):,} MB",
            "Error Description": "NA",
            "statuses": statuses_dict  # This is what the replace_placeholders_with_table function looks for
        }
        logging.info(f"### run_teal_sync sync_summary_data : {sync_summary_data}")

        email_response = trigger_sync_email(
            template_name="Sync Completed",
            subject=f"{tenant_name} - {service_provider_name} - Device and Usage Sync Summary - {start_date_obj.strftime('%m-%d-%Y')}",
            data_dict=sync_summary_data,
            tenant_name=tenant_name,
            log_prefix="### run_teal_sync Sync Completed"
        )
        
        # Update current_status based on email response
        if not email_response["flag"]:
            current_status = "Sync Completed but Email Notification Failed"
        else:
            current_status = "Sync Completed & Email sent successfully"
            email_trigger = True
        
        ##Step 15: Calculate execution time and update final progress
        end_time = time.time()
        execution_duration = end_time - start_time
        
        # Update progress tracker with completion
        sync_successful = all([
            devices_fetch, 
            usage_fetch, 
            staging_to_main_tables_sync,
            device_usage_sync,
            history_tables_sync
        ])
        
        try:
            update_progress_tracker(progress_tracker_id, 
                                    current_status=current_status,
                                    status="Completed" if sync_successful else "Completed with warnings", 
                                    common_utils_database=common_utils_database, 
                                    action="update", now=now, progress=100,
                                    data={**data, "total_records_synced": total_devices_count + usage_count, 
                                          "sync_end_time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), 
                                          "execution_duration": execution_duration})
        except Exception as e:
            logging.exception(f"### run_teal_sync devices and {tenant_name} Error updating final progress tracker: {e}")
        
        logging.info(f"### run_teal_sync devices and {tenant_name} sync completed in {execution_duration:.2f} seconds")
        
        # Step 16: Audit in success case
        try:
            logging.info(f"### run_teal_sync audit in success case")
            audit_comment = {
                "total_devices": total_devices_count,
                "usage_records": usage_count,
                "carrier_rate_plans_records": carrier_rate_plans_count
            }
            audit_data_user_actions = {
                "service_name": "run_teal_sync",
                "created_date": data.get("request_received_at"),
                "created_by": data.get("username", ""),
                "status": "Success",
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": json.dumps(audit_comment),
                "module_name": "Carrier Sync",
                "request_received_at": data.get("request_received_at"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.error(f"### run_teal_sync auditing failed in success case :{e}")
        
        # Prepare final response
        final_response = {
            "flag": sync_successful, 
            "message": "Teal sync completed successfully" if sync_successful else "Teal sync completed with warnings", 
            "total_devices": total_devices_count, 
            "usage_records": usage_count,
            "carrier_rate_plans_records": carrier_rate_plans_count,
            "execution_duration": execution_duration
        }
        
        return final_response

    except Exception as e:
        logging.exception(f"run_teal_sync and {tenant_name} Error during carrier sync {str(e)}")
        error_message = f"Error during carrier sync: {str(e)}"
        
        ### sending email in Error case
        sync_stages = {
            "Staging Table Cleanup": staging_table_cleanup,
            "Carrier Rate Plans Fetch": carrier_rate_plans_fetch,
            "Devices Fetch": devices_fetch,
            "Device Usages Fetch": usage_fetch,
            "Staging → Main Tables Sync": staging_to_main_tables_sync,
            "Device Usage Sync": device_usage_sync,
            "History Tables Sync": history_tables_sync,
            "Sync Completion Email Trigger": email_trigger
        }
        
        # Get the first stage that failed
        failed_stage = next((name for name, flag in sync_stages.items() if not flag), "Unknown")
        
        # Determine data type based on failed stage
        device_stages = {"Staging Table Cleanup", "Carrier Rate Plans Fetch", "Devices Fetch"}
        usage_stages = {"Device Usages Fetch", "Staging → Main Tables Sync", "Device Usage Sync", "History Tables Sync", "Sync Completion Email Trigger"}
        
        if failed_stage in device_stages:
            data_type = "Device"
        elif failed_stage in usage_stages:
            data_type = "Usage"
        else:
            data_type = "Device and Usage"
        
        # Map failed stage to a meaningful error category
        stage_error_mapping = {
            "Staging Table Cleanup": "Issue during Staging Tables Cleanup",
            "Carrier Rate Plans Fetch": "Carrier Rate Plan Fetch Processing Issue",
            "Devices Fetch": "Devices Fetch Issue",
            "Device Usages Fetch": "Devices Usage Processing Issue",
            "Staging → Main Tables Sync": "Staging to Main Table Sync Issue",
            "Device Usage Sync": "Devices Usage Table Update Issue",
            "History Tables Sync": "History Tables Update Issue",
            "Sync Completion Email Trigger": "Email Trigger Issue",
            "Unknown": "Unknown Issue Encountered"
        }
        
        error_category = stage_error_mapping.get(failed_stage, "Unknown Error")
        end_time_ts = time.time()
        end_time_dt = datetime.now()
        duration_seconds = int(end_time_ts - start_time_ts)
        duration_mm_ss = f"{duration_seconds // 60}:{duration_seconds % 60:02d}"
        
        sync_failed_data = {
            "Sync Type": "Daily Sync",
            "Sync Timeline": f"{start_time_dt.strftime('%m-%d-%Y %H:%M:%S')} - {end_time_dt.strftime('%m-%d-%Y %H:%M:%S')} (Duration: {duration_mm_ss} minutes)",
            "Partner Name": tenant_name,
            "Carrier Name": service_provider_name,
            "Start Time": start_time_dt.strftime('%m-%d-%Y %H:%M:%S'),
            "End Time": end_time_dt.strftime('%m-%d-%Y %H:%M:%S'),
            "Job ID": "Teal_Container",
            "Error Category": error_category,
            "Error Message": error_message,
            "Stage of Failure": failed_stage,
            "Impacted Count": total_devices_count if total_devices_count != 0 else "N/A",
            "Data Type": data_type,
            "Partial Sync": "Yes" if total_devices_count != 0 else "No"
        }
        
        email_response = trigger_sync_email(
            template_name="Sync Error",
            subject=f"Sync Failed - {tenant_name} - {service_provider_name} - Daily Sync - {start_date_obj.strftime('%m-%d-%Y')}",
            data_dict=sync_failed_data,
            tenant_name=tenant_name,
            log_prefix="### run_teal_sync Failed"
        )
        
        # Update current_status based on email response
        if not email_response["flag"]:
            current_status = "Sync failed. Error Email delivery was unsuccessful."
        else:
            current_status = "Sync failed. Error Email was sent successfully."
            email_trigger = True
        
        ## Updating the progress tracker for failure
        try:
            update_progress_tracker(progress_tracker_id, current_status=current_status, status="Failed",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=100, data=data)
        except Exception as e:
            logging.exception(f"### run_teal_sync and {tenant_name} Exception in updating progress tracker: {e}")
        
        try:
            # Log error to database
            error_data = {
                "service_name": "run_teal_sync",
                "error_message": error_message,
                "error_type": error_category,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during carrier sync for tenant {tenant_name}: {str(e)}",
                "module_name": "Carrier Sync",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### run_teal_sync and {tenant_name} Exception in logging error data to DB: {e}")
        
        return {"flag": False, "message": error_message}


## Helper function to trigger sync emails
def trigger_sync_email(template_name, subject, data_dict, tenant_name, log_prefix):
    """
    Send an email for carrier/device sync with consistent logging.
    Args:
        template_name (str): Email template name.
        subject (str): Email subject line.
        data_dict (dict): Data to populate the email template.
        tenant_name (str): Tenant name for email context.
        log_prefix (str): Prefix used in logging messages.

    Returns:
        dict -> { "flag": True/False, "message": "..."}
    """
    try:
        result = send_email(
            template_name=template_name,
            email_subject=subject,
            is_html=True,
            data_dict=data_dict,
            tenant_name=tenant_name
        )
        if isinstance(result, tuple):
            to_emails, cc_emails, subject, body, from_email, partner_name = result
            logging.info(f"{log_prefix} Email sent successfully!")
            logging.info(f"{log_prefix} Email Log | To: {to_emails} | CC: {cc_emails} | Subject: {subject} | From: {from_email} | Partner: {partner_name}")
            return {"flag": True, "message": "Email sent successfully"}
         # Email failed
        logging.error(f"{log_prefix} Email sending failed: {result}")
        return {"flag": False, "message": "Email sending failed"}
    
    except Exception as e:
        logging.info(f"{log_prefix} Email sending Failed with error: {e}")
        return {"flag": False, "message": str(e)}


##function to update progress tracker
def update_progress_tracker(
    progress_tracker_id,
    current_status=None, status=None,
    common_utils_database=None,
    action="insert", now=None,
    progress=None,
    data=None
):
    """
    Insert or update carrier sync audit records.
    """
    try:
        if action == "insert":
            insert_data = {
                "tenant_name": data.get("tenant_name"),
                "service_provider_name": data.get("service_provider_name"),
                "sync_start_time": now,
                "sync_end_time": None,
                "estimated_time": data.get("estimated_time"),
                "execution_duration": None,
                "total_records_synced": 0,
                "current_status": current_status or data.get("current_status", "Sync started"),
                "status": status or data.get("status", "In Progress"),
                "error_code": None,
                "error_message": None,
                "attempt_count": data.get("attempt_count", 0),
                "triggered_by": f"{data.get('service_provider_name')}_{data.get('tenant_name')}_{data.get('username')}",
                "sync_type": data.get("sync_type"),
                "created_by": f"{data.get('service_provider_name')}_{data.get('tenant_name')}_{data.get('username')}",
                "modified_by": data.get("modified_by", "Teal Sync Container"),
                "sync_run_count": data.get("sync_run_count", 1),
                "progress": progress or 0
            }
            progress_tracker_id = common_utils_database.insert_data(insert_data, "carrier_sync_audit_logs")
            logging.info(f"Carrier sync audit inserted | id={progress_tracker_id} | status={insert_data['current_status']}")
            return {"flag": True, "message": "Progress tracker inserted successfully", "progress_tracker_id": progress_tracker_id}
        
        elif action == "update":
            update_data = {
                "current_status": current_status or data.get("current_status"),
                "status": status or data.get("status"),
                "total_records_synced": data.get("total_records_synced"),
                "attempt_count": data.get("attempt_count"),
                "error_code": data.get("error_code"),
                "error_message": data.get("error_message"),
                "sync_end_time": data.get("sync_end_time"),
                "execution_duration": data.get("execution_duration"),
                "modified_by": data.get("modified_by", "Teal Sync Container"),
                "progress": progress or data.get("progress") or 0
            }
            update_data = {k: v for k, v in update_data.items() if v is not None}
            common_utils_database.update_dict(
                "carrier_sync_audit_logs",
                update_data,
                and_conditions={"id": progress_tracker_id}
            )
            logging.info(f"Carrier sync audit updated | id={progress_tracker_id} | status={update_data.get('current_status')}")
            return {"flag": True, "message": "Progress tracker updated successfully"}
    except Exception as e:
        logging.exception("Error in update_progress_tracker")
        return {"flag": False, "message": "Error in update_progress_tracker", "details": str(e)}

##function to clean staging table
def clean_staging_table(tenant_database, table_names, username):
    """
    Cleans one or more staging tables in the tenant database.
    """
    results = {}
    if isinstance(table_names, str):
        table_names = [table_names]

    for table in table_names:
        try:
            status = tenant_database.delete_data(table, reset_sequence=True)
            logging.info(f"Staging table {table} cleaned successfully by {username}")

            results[table] = {
                "flag": True,
                "status": status,
                "message": f"Staging table {table} cleaned successfully"
            }

        except Exception as e:
            logging.exception(f"Error cleaning staging table {table}: {e}")
            results[table] = {
                "flag": False,
                "status": False,
                "message": f"Error cleaning staging table {table}",
                "details": str(e)
            }
    
    # Return combined results
    all_success = all(result.get("flag", False) for result in results.values())
    if all_success:
        return {"flag": True, "message": "All staging tables cleaned successfully", "details": results}
    else:
        return {"flag": False, "message": "Error cleaning one or more staging tables", "details": results}
 
##function to get or create billing period
def get_or_create_billing_period(
    tenant_id,
    service_provider_id,
    service_provider_name,
    tenant_database,
    common_utils_database,
    progress_tracker_id,  
    billing_cycle_day,
    force_end_of_day=True,
    start_hour=0,
    start_minute=0,
    start_second=0,
    created_by="Teal Sync Container",
    data=None  
):
    """
    Determines or creates a billing period for the current sync run.
    """
    today = date.today()
    now = datetime.utcnow()

    try:
        # 1. Check existing billing period
        query = """
            SELECT id, billing_cycle_start_date, billing_cycle_end_date
            FROM billing_period
            WHERE tenant_id = %s
            AND service_provider_id = %s
            AND billing_cycle_start_date <= %s
            AND billing_cycle_end_date >= %s
            AND is_deleted = false
            LIMIT 1
        """
        today_str = today.strftime("%Y-%m-%d")
        
        result = tenant_database.execute_query(
            query,
            params=[tenant_id, service_provider_id, today_str, today_str]
        )
        
        if result is not False and not result.empty:
            billing_period_id = result.iloc[0]["id"]
            billing_cycle_start_date = result.iloc[0]["billing_cycle_start_date"]
            billing_cycle_end_date = result.iloc[0]["billing_cycle_end_date"]
            logging.info(f"Billing period reused | billing_period_id={billing_period_id}")
            return { 
                "flag": True,
                "billing_period_id": billing_period_id,
                "is_new_period": False,
                "billing_period_details": {
                    "billing_cycle_start_date": billing_cycle_start_date,
                    "billing_cycle_end_date": billing_cycle_end_date
                }
            }
            
        # 2. Calculate billing cycle start date
        year = today.year
        month = today.month

        if today.day >= billing_cycle_day:
            start_year = year
            start_month = month
        else:
            start_month = month - 1 or 12
            start_year = year if month > 1 else year - 1

        billing_cycle_start_date = datetime(
            start_year,
            start_month,
            billing_cycle_day,
            start_hour,
            start_minute,
            start_second
        )
        
        # 3. Calculate billing cycle end date
        if start_month == 12:
            end_year = start_year + 1
            end_month = 1
        else:
            end_year = start_year
            end_month = start_month + 1

        next_cycle_start = datetime(
            end_year,
            end_month,
            billing_cycle_day,
            start_hour,
            start_minute,
            start_second
        )

        if force_end_of_day:
            billing_cycle_end_date = next_cycle_start.replace(hour=23, minute=59, second=59)
        else:
            billing_cycle_end_date = next_cycle_start
            
        # 4. Insert new billing period
        billing_data = {
            "tenant_id": tenant_id,
            "service_provider_id": service_provider_id,
            "service_provider": service_provider_name,
            "bill_year": billing_cycle_start_date.year,
            "bill_month": billing_cycle_start_date.month,
            "billing_cycle_start_date": billing_cycle_start_date,
            "billing_cycle_end_date": billing_cycle_end_date,
            "billing_period_status_id": 1,
            "is_active": True,
            "is_deleted": False,
            "created_by": created_by,
            "created_date": now,
            "modified_by": created_by,
            "modified_date": now,
            "deleted_by": None,
            "deleted_date": None
        }

        billing_period_id = tenant_database.insert_data(billing_data, "billing_period")
        logging.info(f"New billing period created | billing_period_id={billing_period_id}")
            
        return {
            "flag": True,
            "billing_period_id": billing_period_id,
            "is_new_period": True,
            "billing_period_details": {
                "billing_cycle_start_date": billing_cycle_start_date,
                "billing_cycle_end_date": billing_cycle_end_date
            }
        }
        
    except Exception as e:
        logging.exception("Error determining billing period")
        return {
            "flag": False, 
            "message": "Error determining billing period", 
            "details": str(e)
        }

##function to fetch integration details from tenant database
def fetch_integration_details(
    tenant_database,
    integration_id,
    tenant_name,
    tenant_id
):
    """
    Fetch active integration authentication details from tenant database.
    """
    try:
        integration_df = tenant_database.get_data(
            "integration_authentication",
            {
                "is_active": True,
                "integration_id": integration_id,
                "tenant_id": tenant_id
            }
        )
        
        if integration_df.empty:
            message = "No active integration found for the given integration_id"
            logging.error(f"### fetch_integration_details for {tenant_name} {message}")
            return {"flag": False, "message": message}
            
        integration_details = integration_df.to_dict(orient="records")
        return {"flag": True, "integration_details": integration_details}
        
    except Exception as e:
        logging.exception(f"### fetch_integration_details for {tenant_name} Error fetching integration details: {e}")
        return {"flag": False, "message": str(e)}

## Fetch Teal devices with parallel page processing and insertion
def fetch_teal_devices_parallel_insert(api_key, api_secret, tenant_name, base_url, callback_url, 
                       page_limit=100, sleep_time=60, max_retries=10, 
                       tenant_database=None, service_provider_id=None, 
                       service_provider_name=None, billing_period_id=None, 
                       sync_run_count=None, seen_iccids_cache=None,
                       created_by="Teal_Container", now=None):
    """
    Fetch and process Teal devices with pagination
    Inserts devices into staging tables as each page is fetched
    """
    page_number = 1
    total_devices_count = 0
    all_devices = []
    
    if now is None:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    if seen_iccids_cache is None:
        seen_iccids_cache = set()
    
    logging.info(f"### fetch_teal_devices_parallel_insert for {tenant_name} - Fetching devices")
    
    headers = {
        "ApiKey": api_key,
        "ApiSecret": api_secret,
        "Content-Type": "application/json"
    }
    
    with ThreadPoolExecutor(max_workers=3) as executor:
        futures = []
        
        while True:
            logging.info(f"### Fetching page {page_number} of devices")
            
            try:
                request_id = datetime.now().strftime("%Y%m%d%H%M%S") + f"_{page_number}"
                params = {
                    "callbackUrl": callback_url,
                    "requestId": request_id,
                    "offset": (page_number - 1) * page_limit,
                    "limit": page_limit
                }
                url = f"{base_url}?{urlencode(params)}"
                
                response = requests.get(url, headers=headers, timeout=60)
                
                if response.status_code != 200:
                    logging.error(f"### HTTP {response.status_code} on page {page_number}")
                    break
                    
                data = response.json()
                
                operation_result_url = data.get("_links", {}).get("operationResult", {}).get("href")
                if not operation_result_url:
                    logging.error(f"### No operationResult URL on page {page_number}")
                    break
                
                result_data = poll_teal_operation(
                    operation_result_url, 
                    headers, 
                    sleep_time, 
                    max_retries,
                    tenant_name,
                    "devices"
                )
                
                entries = result_data.get("entries", [])
                if not entries:
                    logging.info(f"### No entries found on page {page_number}")
                    break
                
                logging.info(f"### Received {len(entries)} devices from page {page_number}")
                
                future = executor.submit(
                    process_and_insert_device_page,
                    entries=entries,
                    page_number=page_number,
                    tenant_name=tenant_name,
                    syncrun_count=sync_run_count,
                    now=now,
                    service_provider_id=service_provider_id,
                    service_provider_name=service_provider_name,
                    billing_period_id=billing_period_id,
                    seen_iccids_cache=seen_iccids_cache,
                    tenant_database=tenant_database,
                    created_by=created_by
                )
                futures.append(future)
                
                if len(entries) < page_limit:
                    logging.info(f"### Last page reached (page {page_number})")
                    break
                
                page_number += 1
                time.sleep(1)
                
            except Exception as e:
                logging.error(f"### Error fetching page {page_number}: {e}")
                break
        
        for future in as_completed(futures):
            try:
                page_devices, page_count = future.result()
                all_devices.extend(page_devices)
                total_devices_count += page_count
            except Exception as e:
                logging.error(f"### Error processing page: {e}")
    
    logging.info(f"### Total devices processed and inserted: {total_devices_count}")
    return all_devices, total_devices_count

## Process and insert a single page of devices
def process_and_insert_device_page(entries, page_number, tenant_name, syncrun_count, now,
                                  service_provider_id, service_provider_name, 
                                  billing_period_id, seen_iccids_cache, tenant_database, created_by):
    """
    Process a page of Teal devices and insert them into staging tables
    """
    page_devices = []
    inserted_count = 0
    skipped_count = 0
    staging_records = []
    audit_records = []
    
    logging.info(f"### Processing page {page_number} with {len(entries)} devices")
    
    for device in entries:
        iccid = device.get("iccid", "")
        
        if not iccid:
            skipped_count += 1
            continue
        
        if iccid in seen_iccids_cache:
            skipped_count += 1
            continue
        
        seen_iccids_cache.add(iccid)
        
        staging_record = {
            "iccid": iccid,
            "imsi": str(device.get("imsi", "")) if device.get("imsi") else None,
            "imei": str(device.get("imei", "")) if device.get("imei") else None,
            "msisdn": str(device.get("msisdn", "")) if device.get("msisdn") else None,
            "eid": device.get("eid", ""),
            "plan_id": str(device.get("planId", "")) if device.get("planId") else None,
            "plan_uuid": device.get("planUuid", ""),
            "plan_name": device.get("planName", ""),
            "pending_plan_id": normalize_pending_plan_id(device.get("pendingPlanId")),
            "pending_plan_uuid": device.get("pendingPlanUuid", ""),
            "pending_plan_name": device.get("pendingPlanName", ""),
            "plan_volume_unit": device.get("planVolumeUnit", ""),
            "plan_price": float(device.get("planPrice", 0)) if device.get("planPrice") else None,
            "suspended": device.get("suspended", False),
            "device_name": device.get("deviceName", ""),
            "device_status": device.get("deviceStatus", ""),
            "plan_change_status": device.get("planChangeStatus", ""),
            "client_id": str(device.get("clientId", "")) if device.get("clientId") else None,
            "client_name": device.get("clientName", ""),
            "client_title": device.get("clientTitle", ""),
            "client_uuid": device.get("clientUuid", ""),
            "batch_number": device.get("batchNumber", ""),
            "device_group_name": device.get("deviceGroupName", ""),
            "client_change_timestamp": device.get("clientChangeTimestamp", ""),
            "profile_change_status": device.get("profileChangeStatus", ""),
            "bootstrap_iccid": device.get("bootstrapIccid", ""),
            "initial_bootstrap_iccid": device.get("initialBootstrapIccid", ""),
            "bootstrap_imsi": device.get("bootstrapImsi", ""),
            "meerkat_public_ip_enabled": device.get("meerkatPublicIpEnabled", False),
            "meerkat_private_ip_enabled": device.get("meerkatPrivateIpEnabled", False),
            "last_connected_network": json.dumps(device.get("lastConnectedNetwork")) if device.get("lastConnectedNetwork") and
             isinstance(device.get("lastConnectedNetwork"), dict) else str(device.get("lastConnectedNetwork", "")),
            "meerkat_ip_entries": json.dumps(device.get("meerkatIpEntries")) if device.get("meerkatIpEntries") else None,
            "profile_only": device.get("profileOnly", False),
            "meerkat_public_vpn_enabled": device.get("meerkatPublicVpnEnabled", False),
            "meerkat_private_vpn_enabled": device.get("meerkatPrivateVpnEnabled", False),
            "store_unit_id": device.get("storeUnitId", ""),
            "store_unit_uuid": device.get("storeUnitUuid", ""),
            "sku": device.get("sku", ""),
            "cap": str(device.get("cap", "")) if device.get("cap") else None,
            "usage": int(device.get("usage", 0)) if device.get("usage") else None,
            "capped": device.get("capped", False),
            "total_usage": 0,
            "total_usage_mb": 0,
            "service_provider_id": service_provider_id,
            "service_provider_name": service_provider_name,
            "billing_period_id": int(billing_period_id) if billing_period_id else None,
            "created_by": "Teal sync container",
            "modified_by": "Teal sync container"
        }
        
        for field in ["profile_pools", "skus", "coverage_countries", "network_tech_types"]:
            if field in device and device[field]:
                staging_record[field] = json.dumps(device[field])
        
        audit_record = staging_record.copy()
        audit_record.update({
            "sync_run_count": syncrun_count,
            "sync_date": now,
            "triggered_by": created_by
        })
        
        staging_records.append(staging_record)
        audit_records.append(audit_record)
        page_devices.append(staging_record)
        inserted_count += 1
    
    if staging_records:
        try:
            tenant_database.insert_data(staging_records, "teal_carrier_sync_staging")
            
            if audit_records:
                tenant_database.insert_data(audit_records, "teal_carrier_sync_staging_audit")
            
            logging.info(f"### Page {page_number}: Inserted {inserted_count} devices, skipped {skipped_count} duplicates")
        except Exception as e:
            logging.error(f"### Error inserting page {page_number}: {e}")
            raise
    
    return page_devices, inserted_count

##function to poll Teal async operation
def poll_teal_operation(url, headers, sleep_time, max_retries, tenant_name, operation_type):
    """Poll the operationResult URL until entries are available."""
    for attempt in range(max_retries):
        try:
            resp = requests.get(url, headers=headers, timeout=60)
            
            if resp.status_code == 102:
                logging.info(f"### {operation_type} processing in progress (102). Retry {attempt+1}/{max_retries}")
                time.sleep(sleep_time)
                continue
                
            if resp.status_code != 200:
                logging.error(f"### HTTP {resp.status_code} on attempt {attempt+1}")
                time.sleep(sleep_time)
                continue
            
            try:
                data = resp.json()
            except Exception as e:
                logging.error(f"### Invalid JSON on attempt {attempt+1}: {e}")
                time.sleep(sleep_time)
                continue
            
            if "entries" in data:
                return data
            
            logging.info(f"### No entries yet on attempt {attempt+1}")
            time.sleep(sleep_time)
            
        except Exception as e:
            logging.error(f"### Error on attempt {attempt+1}: {e}")
            time.sleep(sleep_time)
    
    logging.warning(f"### Max retries reached for {operation_type}")
    return {}

## Fetch Teal usage data and insert into staging table
def fetch_teal_usage_data_parallel_insert(api_key, api_secret, tenant_name, base_url, callback_url,
                          page_limit=100, sleep_time=60, max_retries=10,
                          start_date=None, end_date=None,
                          service_provider_id=None, service_provider_name=None, 
                          billing_period_id=None, sync_run_count=None,
                          tenant_database=None, created_by="Teal_Container", now=None):
    """
    Fetch usage data from Teal API and insert into teal_carrier_usage_staging table
    """
    logging.info(f"### fetch_teal_usage_data_parallel_insert for {tenant_name} - Fetching usage data")
    
    if now is None:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    try:
        if not start_date or not end_date:
            today = datetime.now()
            target_date = today - timedelta(days=1)
            start_date = target_date.strftime("%Y-%m-%d")
            end_date = target_date.strftime("%Y-%m-%d")
        
        logging.info(f"### Fetching usage from {start_date} to {end_date}")
        
        # Define the fetch operation function inside
        def fetch_operation_result(url, headers, sleep_time, max_retries, operation_type):
            """Poll the operationResult URL until entries are available."""
            for attempt in range(max_retries):
                try:
                    resp = requests.get(url, headers=headers, timeout=60)
                    
                    if resp.status_code == 102:
                        logging.info(f"### {operation_type} processing in progress (102). Retry {attempt+1}/{max_retries}")
                        time.sleep(sleep_time)
                        continue
                        
                    if resp.status_code != 200:
                        logging.error(f"### {operation_type} HTTP {resp.status_code} on attempt {attempt+1}")
                        time.sleep(sleep_time)
                        continue
                    
                    try:
                        data = resp.json()
                    except Exception as e:
                        logging.error(f"### {operation_type} Invalid JSON on attempt {attempt+1}: {e}")
                        time.sleep(sleep_time)
                        continue
                    
                    if "entries" in data:
                        return data
                    
                    logging.info(f"### {operation_type} No entries yet on attempt {attempt+1}")
                    time.sleep(sleep_time)
                    
                except Exception as e:
                    logging.error(f"### {operation_type} Error on attempt {attempt+1}: {e}")
                    time.sleep(sleep_time)
            
            logging.warning(f"### {operation_type} Max retries reached")
            return {}

        headers = {
            "ApiKey": api_key,
            "ApiSecret": api_secret,
            "Content-Type": "application/json"
        }

        table_name = "teal_carrier_usage_staging"
        
        # Track seen records to avoid duplicates (using eid + period as unique identifier)
        seen_usage_ids = set()
        
        page_number = 1
        total_inserted = 0
        
        # Start paginated fetching from API
        while True:
            logging.info(f"### Fetching page {page_number} of usage data")
            
            try:
                request_id = datetime.now().strftime("%Y%m%d%H%M%S") + f"_usage_{page_number}"
                
                # Parameters for usage API
                params = {
                    "requestId": request_id,
                    "offset": (page_number - 1) * page_limit,
                    "limit": page_limit,
                    "dataType": "DAILY_P_N"
                }
                
                # Add date filters if provided
                if start_date:
                    parsed_start = datetime.strptime(start_date, '%Y-%m-%d')
                    params["periodStart"] = f"{parsed_start.strftime('%Y-%m-%d')} 00:00:00"
                if end_date:
                    parsed_end = datetime.strptime(end_date, '%Y-%m-%d')
                    params["periodEnd"] = f"{parsed_end.strftime('%Y-%m-%d')} 23:59:59"
                
                url = f"{base_url}?{urlencode(params)}"
                logging.info(f"### Request URL: {url}")
                
                # Fetch the current page of usage data
                response = requests.get(url, headers=headers, timeout=60)
                
                if response.status_code != 200:
                    logging.error(f"### HTTP {response.status_code} on page {page_number}")
                    break
                    
                data = response.json()
                
                # Get operation result URL for async processing
                operation_result_url = data.get("_links", {}).get("operationResult", {}).get("href")
                if not operation_result_url:
                    logging.error(f"### No operationResult URL on page {page_number}")
                    break
                
                # Add requestId to headers for polling
                headers_with_request = {**headers, "requestId": request_id}
                
                # Poll for results
                result_data = fetch_operation_result(
                    operation_result_url, 
                    headers_with_request, 
                    sleep_time, 
                    max_retries,
                    "usage"
                )
                
                entries = result_data.get("entries", [])
                
                if not entries:
                    logging.info(f"### No entries found on page {page_number}")
                    break
                
                logging.info(f"### Received {len(entries)} usage records from page {page_number}")
                
                # Log first record for debugging
                if entries and len(entries) > 0:
                    logging.info(f"### First record sample: {json.dumps(entries[0], default=str)[:500]}")
                
                # Process the page data
                staging_records = []
                page_inserted = 0
                page_skipped = 0
                page_seen_ids = set()
                
                for record in entries:
                    # Extract fields from API response
                    eid = record.get("eid", "")
                    period = record.get("period", "")  # Format: "2026-01-31 00:00:00"
                    usage_bytes = record.get("usage", 0)
                    operational_imsi = record.get("operationalImsi", "")
                    mcc_mnc = record.get("mccMnc", "")
                    pmn = record.get("pmn", "")
                    
                    # Skip records without required fields
                    if not eid or not period:
                        page_skipped += 1
                        continue
                    
                    # Create unique ID to avoid duplicates
                    record_id = f"{eid}_{period}"
                    if record_id in seen_usage_ids or record_id in page_seen_ids:
                        page_skipped += 1
                        continue
                    
                    page_seen_ids.add(record_id)
                    
                    # Parse the period string to datetime
                    try:
                        # Format: "2026-01-31 00:00:00"
                        start_time = datetime.strptime(period, '%Y-%m-%d %H:%M:%S')
                    except:
                        try:
                            # Try without time part
                            start_time = datetime.strptime(period.split()[0], '%Y-%m-%d')
                        except:
                            start_time = None
                            logging.warning(f"### Could not parse period: {period}")
                    
                    # Prepare record for staging table
                    staging_record = {
                        "eid": str(eid),
                        "operational_imsi": str(operational_imsi) if operational_imsi else None,
                        "start_time": start_time,
                        "mcc_mnc": str(mcc_mnc) if mcc_mnc else None,
                        "pmn": str(pmn) if pmn else None,
                        "total_usage": usage_bytes,
                        "bootstrap_iccid": None,
                        "stop_time": None,
                        "cell_id": None,
                        "plan_uuid": None,
                        "service_provider_id": str(service_provider_id) if service_provider_id else None,
                        "service_provider_name": service_provider_name,
                        "created_by": created_by,
                        "created_date": now,
                        "modified_by": created_by,
                        "modified_date": now
                    }
                    
                    staging_records.append(staging_record)
                    page_inserted += 1
                
                logging.info(f"### Page {page_number}: Prepared {page_inserted} records for insertion, skipped {page_skipped}")
                
                # Insert this page's records into staging table
                if staging_records:
                    try:
                        logging.info(f"### Page {page_number}: Inserting {len(staging_records)} records into {table_name}")
                        
                        # Insert in batches of 100
                        batch_size = 100
                        for i in range(0, len(staging_records), batch_size):
                            batch = staging_records[i:i+batch_size]
                            tenant_database.insert_data(batch, table_name)
                            logging.info(f"### Inserted batch {i//batch_size + 1} with {len(batch)} records")
                        
                        logging.info(f"### Page {page_number}: Successfully inserted {page_inserted} usage records")
                        
                        # Add page's seen IDs to global set
                        seen_usage_ids.update(page_seen_ids)
                        total_inserted += page_inserted
                        
                    except Exception as e:
                        logging.error(f"### Error inserting page {page_number}: {e}")
                        import traceback
                        logging.error(f"### Traceback: {traceback.format_exc()}")
                        raise
                
                # Stop if last page reached
                if len(entries) < page_limit:
                    logging.info(f"### Last page reached (page {page_number})")
                    break

                page_number += 1
                time.sleep(1)  # Small delay between pages
                
            except Exception as e:
                logging.error(f"### Error processing page {page_number}: {e}")
                import traceback
                logging.error(f"### Traceback: {traceback.format_exc()}")
                break
        
        logging.info(f"### Total usage records inserted: {total_inserted}")
        return total_inserted
        
    except Exception as e:
        logging.exception(f"### Error in fetch_teal_usage_data_parallel_insert: {e}")
        return 0
    
## Fetch and insert Teal carrier rate plans with parallel page processing
def fetch_and_insert_teal_carrier_rate_plans_parallel(tenant_database, api_key, api_secret, tenant_name,
                                  base_url, callback_url, page_limit=100, 
                                  sleep_time=60, max_retries=10, now=None, created_by="Teal_Container"):
    """
    Fetch Teal carrier rate plans with pagination and insert directly into staging table
    """
    if now is None:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    logging.info(f"### fetch_and_insert_teal_carrier_rate_plans_parallel for {tenant_name} - Starting carrier rate plans fetch and insert")
    
    try:
        # Define the fetch operation function inside
        def fetch_operation_result(url, headers, sleep_time, max_retries, operation_type):
            """Poll the operationResult URL until entries are available."""
            for attempt in range(max_retries):
                try:
                    resp = requests.get(url, headers=headers, timeout=60)
                    
                    if resp.status_code == 102:
                        logging.info(f"### {operation_type} processing in progress (102). Retry {attempt+1}/{max_retries}")
                        time.sleep(sleep_time)
                        continue
                        
                    if resp.status_code != 200:
                        logging.error(f"### {operation_type} HTTP {resp.status_code} on attempt {attempt+1}")
                        time.sleep(sleep_time)
                        continue
                    
                    try:
                        data = resp.json()
                    except Exception as e:
                        logging.error(f"### {operation_type} Invalid JSON on attempt {attempt+1}: {e}")
                        time.sleep(sleep_time)
                        continue
                    
                    if "entries" in data:
                        return data
                    
                    logging.info(f"### {operation_type} No entries yet on attempt {attempt+1}")
                    time.sleep(sleep_time)
                    
                except Exception as e:
                    logging.error(f"### {operation_type} Error on attempt {attempt+1}: {e}")
                    time.sleep(sleep_time)
            
            logging.warning(f"### {operation_type} Max retries reached")
            return {}

        headers = {
            "ApiKey": api_key,
            "ApiSecret": api_secret,
            "Content-Type": "application/json"
        }

        table_name = "teal_carrier_rate_plan_staging"
        
        # Fetch existing plan names once to avoid duplicates
        existing_plans = tenant_database.get_data(table_name, None, ["name"])
        existing_plan_names = (
            set(existing_plans["name"].dropna().tolist()) 
            if not existing_plans.empty 
            else set()
        )
        logging.info(f"### Found {len(existing_plan_names)} existing plans in staging")
        
        page_number = 1
        total_inserted = 0
        all_carrier_rate_plans = []
        
        # Start paginated fetching from API
        while True:
            logging.info(f"### Fetching page {page_number} of carrier rate plans")
            
            try:
                request_id = datetime.now().strftime("%Y%m%d%H%M%S") + f"_plan_{page_number}"
                params = {
                    "callbackUrl": callback_url,
                    "requestId": request_id,
                    "offset": (page_number - 1) * page_limit,
                    "limit": page_limit
                }
                url = f"{base_url}?{urlencode(params)}"
                
                # Fetch the current page of plan data
                response = requests.get(url, headers=headers, timeout=60)
                
                if response.status_code != 200:
                    logging.error(f"### HTTP {response.status_code} on page {page_number}")
                    break
                    
                data = response.json()
                
                # Get operation result URL
                operation_result_url = data.get("_links", {}).get("operationResult", {}).get("href")
                if not operation_result_url:
                    logging.error(f"### No operationResult URL on page {page_number}")
                    break
                
                # Poll for results
                result_data = fetch_operation_result(
                    operation_result_url, 
                    headers, 
                    sleep_time, 
                    max_retries,
                    "carrier_rate_plans"
                )
                
                entries = result_data.get("entries", [])
                if not entries:
                    logging.info(f"### No entries found on page {page_number}")
                    break
                
                logging.info(f"### Received {len(entries)} carrier rate plans from page {page_number}")
                
                # Process the page data
                df_page = pd.json_normalize(entries, sep=".")
                
                # Rename columns to match database schema
                rename_map = {
                    "smsPrice": "sms_price",
                    "volumeUnit": "volume_unit",
                    "validityTime": "validity_time",
                    "validityTimeUnit": "validity_time_unit",
                    "maxReliability": "max_reliability",
                    "networkTechType": "network_tech_type",
                    "networkTechTypeTitle": "network_tech_type_title",
                    "profilePools": "profile_pools",
                    "minUnitPriceBilling": "min_unit_price_billing",
                    "minUnitPrice": "min_unit_price",
                    "minUnitVolume": "min_unit_volume",
                    "minUnitVolumeUnit": "min_unit_volume_unit",
                    "coverageCountries": "coverage_countries",
                    "meerkatEnabled": "meerkat_enabled",
                    "networkTechTypes": "network_tech_types",
                    "coverageType": "coverage_type",
                    "credentialsType": "credentials_type",
                    "networkType": "network_type"
                }
                df_page.rename(columns=rename_map, inplace=True)

                # Convert list/dict fields to JSON
                json_cols = ["profile_pools", "skus", "coverage_countries", "network_tech_types"]
                for col in json_cols:
                    if col in df_page.columns:
                        df_page[col] = df_page[col].apply(
                            lambda x: json.dumps(x) if isinstance(x, (list, dict)) else x
                        )

                # Ensure all DB columns exist
                db_columns = [
                    "name", "description", "price", "sms_price", "volume",
                    "volume_unit", "validity_time", "validity_time_unit", "max_reliability",
                    "reliability", "network_tech_type", "network_tech_type_title", "uuid",
                    "profile_pools", "skus", "min_unit_price_billing", "min_unit_price",
                    "min_unit_volume", "min_unit_volume_unit", "coverage_countries",
                    "meerkat_enabled", "network_tech_types", "coverage_type",
                    "credentials_type", "network_type", "created_date", "modified_date"
                ]
                
                for col in db_columns:
                    if col not in df_page.columns:
                        df_page[col] = None
                
                # Add created_date and modified_date
                df_page["created_date"] = now
                df_page["modified_date"] = now
                
                # Convert current page to dicts
                page_entries = df_page[db_columns].to_dict(orient="records")

                # Split into update vs insert based on existing plan names
                entries_to_update = [r for r in page_entries if r["name"] in existing_plan_names]
                entries_to_insert = [r for r in page_entries if r["name"] not in existing_plan_names]

                # Perform database operations for this page
                if entries_to_update:
                    logging.info(f"### Page {page_number}: Updating {len(entries_to_update)} existing plan records")
                    try:
                        tenant_database.bulk_update_data(table_name, entries_to_update, search_column="name")
                    except Exception as e:
                        logging.error(f"### Page {page_number}: Error updating records: {e}")
                        # Log the first record for debugging
                        if entries_to_update:
                            logging.error(f"### First record that failed update: {entries_to_update[0]}")
                        raise

                if entries_to_insert:
                    logging.info(f"### Page {page_number}: Inserting {len(entries_to_insert)} new plan records")
                    try:
                        tenant_database.insert_data(entries_to_insert, table_name)
                        # Add new names to the set to prevent duplicates in next pages
                        existing_plan_names.update([r["name"] for r in entries_to_insert])
                        total_inserted += len(entries_to_insert)
                        all_carrier_rate_plans.extend(entries_to_insert)
                    except Exception as e:
                        logging.error(f"### Page {page_number}: Error inserting records: {e}")
                        # Log the first record for debugging
                        if entries_to_insert:
                            logging.error(f"### First record that failed insert: {entries_to_insert[0]}")
                        raise

                logging.info(f"### Page {page_number}: Processed {len(entries)} plans (Updated: {len(entries_to_update)}, Inserted: {len(entries_to_insert)})")

                # Stop if last page reached
                if len(entries) < page_limit:
                    logging.info(f"### Last page reached (page {page_number})")
                    break

                page_number += 1
                time.sleep(1)  # Small delay between pages
                
            except Exception as e:
                logging.error(f"### Error processing page {page_number}: {e}")
                import traceback
                logging.error(f"### Traceback: {traceback.format_exc()}")
                break
        
        if total_inserted == 0 and not all_carrier_rate_plans:
            logging.warning(f"### No carrier rate plans were inserted")
            return {
                "flag": False,
                "message": "No carrier rate plans found from Teal API",
                "carrier_rate_plans_count": 0,
                "carrier_rate_plans_list": []
            }
        
        logging.info(f"### Total inserted: {total_inserted} new records into teal_carrier_rate_plan_staging")
        
        return {
            "flag": True,
            "message": f"{total_inserted} carrier rate plan records fetched and inserted successfully",
            "carrier_rate_plans_count": total_inserted,
            "carrier_rate_plans_list": all_carrier_rate_plans
        }
            
    except Exception as e:
        logging.exception(f"### Error in fetch_and_insert_teal_carrier_rate_plans_parallel: {e}")
        return {
            "flag": False,
            "message": f"Error fetching and inserting carrier rate plan records: {str(e)}",
            "carrier_rate_plans_count": 0,
            "carrier_rate_plans_list": []
        }

# Function to sync data from staging tables to main tables
def sync_staging_to_main(data, tenant_database, common_utils_database, progress_tracker_id):
    """
    Syncs data from Teal staging tables to main AMOP tables.
    
    Args:
        data (dict): Request data containing necessary information for syncing.
        tenant_database: Database connection object for tenant-specific operations.
        common_utils_database: Database connection object for common utilities.
        progress_tracker_id: Progress tracker ID for audit logging.
    
    Returns:
        dict: Result of the sync operation with success or failure details.
    """
    logging.info("###### sync_staging_to_main - Teal Sync from staging to main started")
    
    ## Fetching the necessary variables
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    integration_id = int(data.get("integration_id")) if data.get("integration_id") is not None else None
    service_provider_id = int(data.get("service_provider_id")) if data.get("service_provider_id") is not None else None
    service_provider_name = data.get("service_provider_name")
    tenant_id = int(data.get("tenant_id")) if data.get("tenant_id") is not None else None
    username = data.get('username', 'Teal_Container')
    staging_table_name = "teal_carrier_sync_staging"  # Teal staging table
    integration_authentication_id = int(data.get('integration_authentication_id')) if data.get('integration_authentication_id') is not None else None
    tenant_name = data.get("tenant_name")
    billing_period_id = int(data["billing_period_id"]) if data.get("billing_period_id") is not None else None
    
    ## Initializing the variables
    device_status_map = {}
    plan_map = {}
    insert_payload = []
    update_dict = []
    
    try:
        ## Step 1 : Fetching the staging table data 
        staging_df = tenant_database.get_data(staging_table_name)
        if staging_df is None or staging_df.empty:
            logging.info("### sync_staging_to_main No staging data found")
            return {"flag": False, "message": "No staging data found."}
        logging.info(f"### sync_staging_to_main Staging records fetched: {len(staging_df)}")
        
        try:
            logging.info(f"### sync_staging_to_main tenant : {tenant_name} updating the progress tracker for Fetched Staging records")
            update_progress_tracker(progress_tracker_id, current_status="Fetched Staging records Successfully", status="In Progress",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=72, data=data)
        except Exception as e:
            logging.exception(f"### sync_staging_to_main devices and {tenant_name} Error updating progress tracker: {e}")
        
        ##Step 2: Fetching the statuses from staging table and checking with status in device_status table
        staging_statuses = []
        if "device_status" in staging_df.columns:
            staging_statuses = (staging_df["device_status"].dropna().astype(str).str.strip().str.lower().unique())
        
        ##device_status table
        existing_status_df = tenant_database.get_data(
            "device_status",
            {"integration_id": integration_id},
            ["id", "status","display_name"]
        )
        
        if existing_status_df is not None and not existing_status_df.empty:
            existing_status_df["status"] = (
                existing_status_df["status"]
                .astype(str)
                .str.strip()
                .str.lower()
            )
            existing_status_map = dict(zip(existing_status_df["status"], existing_status_df["id"]))
        else:
            existing_status_map = {}
        
        ##checking for new statuses
        if len(staging_statuses) > 0:
            new_statuses = [
                status for status in staging_statuses
                if status and status not in existing_status_map
            ]
            
            ##Step 3:handling New status If new status comes need to insert them in device_status table
            if new_statuses:
                active_status_values = {"online", "ONLINE", "Online", "activate", "active", "activated", "provisioned", "enabled"}
                status_insert_payload = [
                    {
                        "status": status.strip(),
                        "display_name": status.strip().title(),
                        "description": f"Auto-created from {service_provider_name} carrier sync",
                        "created_by": username,
                        "modified_by": username,
                        "integration_id": integration_id,
                        "is_active": True,
                        "is_deleted": False,
                        # Business flags
                        "is_active_status": status.strip().lower() in [v.lower() for v in active_status_values],
                        "should_have_billed_service": True,
                        "is_restorable_from_archive": status.strip().lower() in [v.lower() for v in active_status_values],
                        "is_apply_for_automation_rule": status.strip().lower() in [v.lower() for v in active_status_values],
                    }
                    for status in new_statuses
                    if status and str(status).strip()
                ]
                
                if status_insert_payload:
                    tenant_database.insert_data(status_insert_payload, "device_status")
                    logging.info(f"###sync_staging_to_main Inserted {len(new_statuses)} new device statuses")
                    
                    # Refetch after insert to get the latest ids
                    existing_status_df = tenant_database.get_data(
                        "device_status",
                        {"integration_id": integration_id},
                        ["id", "status","display_name"]
                    )
                    ##preparing the device_status map
                    if existing_status_df is not None and not existing_status_df.empty:
                        existing_status_df["status"] = (
                            existing_status_df["status"]
                            .astype(str)
                            .str.strip()
                            .str.lower()
                        )
                        existing_status_map = dict(zip(existing_status_df["status"], existing_status_df["id"]))
        
        ##preparing the device_status map
        if existing_status_df is not None and not existing_status_df.empty:
            existing_status_df["status"] = (
                existing_status_df["status"]
                .astype(str)
                .str.strip()
                .str.lower()
            )
            device_status_map = dict(zip(existing_status_df["status"], existing_status_df["id"]))
            status_display_map = dict(zip(existing_status_df["status"], existing_status_df["display_name"]))
        else:
            device_status_map = {}
            status_display_map = {}
        
        try:
            logging.info(f"### sync_staging_to_main tenant : {tenant_name} updating the progress tracker for Device Statuses Fetched Successfully")
            update_progress_tracker(progress_tracker_id, current_status="Device Statuses Fetched Successfully", status="In Progress", common_utils_database=common_utils_database,
                                     action="update", now=now, progress=74, data=data)
        except Exception as e:
            logging.exception(f"### sync_staging_to_main devices and {tenant_name} Error updating progress tracker: {e}")
        
        ##Step 4: Preparing the rate plan map using staging plans
        staging_plan_df = None
        if "plan_name" in staging_df.columns:
            staging_plan_df = (
                staging_df[["plan_name", "plan_id"]]
                .dropna(subset=["plan_name"])
                .copy()
            )
            staging_plan_df["plan_name"] = (
                staging_plan_df["plan_name"]
                .astype(str)
                .str.strip()
            )
            staging_plan_df = staging_plan_df.drop_duplicates(subset=["plan_name"])
        
        ##Step 5: Fetching the existing carrier rate plans
        existing_plan_df = tenant_database.get_data(
            "carrier_rate_plan",
            {
                "service_provider_id": service_provider_id,
                "is_active": True
            },
            ["id", "friendly_name", "rate_plan_code"]
        )
        
        if existing_plan_df is not None and not existing_plan_df.empty:
            existing_plan_df["friendly_name"] = (
                existing_plan_df["friendly_name"]
                .astype(str)
                .str.strip()
            )
            existing_plan_map = dict(zip(existing_plan_df["friendly_name"], existing_plan_df["id"]))
        else:
            existing_plan_map = {}
        
        insert_payload = []
        ##Step 6: Inserting new rate plans from Teal plans
        if staging_plan_df is not None and not staging_plan_df.empty:
            for _, row in staging_plan_df.iterrows():
                plan_name = row["plan_name"]
                plan_id = row.get("plan_id", "")
                
                if plan_name and plan_name not in existing_plan_map:
                    # INSERT NEW PLAN
                    insert_payload.append({
                        "rate_plan_code": str(plan_id) if plan_id else str(plan_name),
                        "friendly_name": plan_name,
                        "rate_plan_short_name": plan_name,
                        "service_provider": service_provider_name,
                        "service_provider_id": service_provider_id,
                        "is_active": True,
                        "is_deleted": False,
                        "is_retired": False,
                        "is_exclude_from_optimization": False,
                        "assigned": False,
                        "allows_sim_pooling": True,
                        "created_by": username,
                        "modified_by": username,
                        "description": plan_name
                    })
            
            if insert_payload:
                logging.info(f"### sync_staging_to_main - Inserting {len(insert_payload)} new rate plans for Teal")
                rate_plan_insert_flag = tenant_database.insert_data(insert_payload, "carrier_rate_plan")
                logging.info(f"### sync_staging_to_main - Rate plan insertion completed, flag: {rate_plan_insert_flag}")
        
        ## Refetch plans after insertions
        existing_plan_df = tenant_database.get_data(
            "carrier_rate_plan",
            {"service_provider_id": service_provider_id},
            ["id", "friendly_name"]
        )
        
        if existing_plan_df is not None and not existing_plan_df.empty:
            existing_plan_df["friendly_name"] = (
                existing_plan_df["friendly_name"]
                .astype(str)
                .str.strip()
            )
            plan_map = dict(zip(existing_plan_df["friendly_name"], existing_plan_df["id"]))
        else:
            plan_map = {}
        
        try:
            logging.info(f"### sync_staging_to_main tenant : {tenant_name} updating the progress tracker for fetching carrier rate plans")
            update_progress_tracker(progress_tracker_id, current_status=f"Fetched Carrier Rate Plans Successfully", status="In Progress",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=75, data=data)
        except Exception as e:
            logging.exception(f"### sync_staging_to_main devices and {tenant_name} Error updating progress tracker: {e}")
        
        ##Step 7: Fetching the bill cycle values to insert or update 
        billing_df = tenant_database.get_data("billing_period",{"id":billing_period_id},['billing_cycle_end_date','billing_cycle_start_date','bill_year','bill_month'])
        if billing_df is not None and not billing_df.empty:
            billing_record = billing_df.to_dict("records")[0]
            bill_year = billing_record.get("bill_year")
            bill_month = billing_record.get("bill_month")
            billing_cycle_end_date = billing_record.get("billing_cycle_end_date")
            billing_cycle_start_date = billing_record.get("billing_cycle_start_date")
        else:
            billing_period_id = None
            bill_year = None
            bill_month = None
            billing_cycle_end_date = None
            billing_cycle_start_date = None
        
        ##Step 8: Prepare the column mappings for Teal
        columns_mapping = {
            "iccid": "iccid",
            "imsi": "imsi",
            "imei": "imei",
            "msisdn": "msisdn",
            "eid": "eid",
            "service_provider_id": "service_provider_id",
            "service_provider_name": "service_provider_display_name",
            "device_status": "sim_status",
            "plan_name": "carrier_rate_plan_name",
            "device_name": "device_model",  # Maps device_name from staging to device_model in main
            "total_usage": "carrier_cycle_usage_bytes",
            "total_usage_mb": "carrier_cycle_usage_mb",
        }
        
        # Only keep columns that exist in the staging dataframe
        available_columns = {k: v for k, v in columns_mapping.items() if k in staging_df.columns}
        transformed_df = staging_df.rename(columns=available_columns)
        
        ##Step 9: Keep only mapped columns that exist after rename
        mapped_columns = list(available_columns.values())
        transformed_df = transformed_df[[col for col in mapped_columns if col in transformed_df.columns]]
        
        ##Step 10: Updating device_status_id using the status map and display map
        if "sim_status" in transformed_df.columns:
            normalized_status = (
                transformed_df["sim_status"]
                .astype(str)
                .str.strip()
                .str.lower()
            )
            # Map ID
            transformed_df["device_status_id"] = normalized_status.map(device_status_map)
            # Map Display Name
            transformed_df["sim_status"] = normalized_status.map(status_display_map)
        
        ##Step 11: Map carrier rate plan id
        if "carrier_rate_plan_name" in transformed_df.columns:
            transformed_df["carrier_rate_plan_name"] = (
                transformed_df["carrier_rate_plan_name"]
                .astype(str)
                .str.strip()
            )
            transformed_df["carrier_rate_plan_id"] = (
                transformed_df["carrier_rate_plan_name"]
                .map(plan_map)
            )
        
        ### Additional Step for sub tenant handling--->Duplicate columns
        transformed_df["sub_tenant_carrier_rate_plan_name"] = transformed_df["carrier_rate_plan_name"]
        transformed_df["sub_tenant_carrier_rate_plan_name_id"] = transformed_df["carrier_rate_plan_id"]
        
        ##Step 12: Add standard fields for sim_management_inventory
        transformed_df["tenant_id"] = tenant_id
        transformed_df["is_active"] = True
        transformed_df["is_deleted"] = False
        transformed_df["tenant_is_active"] = True
        transformed_df["tenant_is_deleted"] = False
        transformed_df["created_by"] = username
        transformed_df["modified_by"] = username
        transformed_df["billing_period_id"] = int(billing_period_id) if billing_period_id else None
        transformed_df["bill_year"] = int(bill_year) if bill_year else None
        transformed_df["bill_month"] = int(bill_month) if bill_month else None
        transformed_df["integration_id"] = int(integration_id) if integration_id else None
        transformed_df["billing_cycle_end_date"] = billing_cycle_end_date if billing_cycle_end_date else None
        transformed_df["billing_cycle_start_date"] = billing_cycle_start_date if billing_cycle_start_date else None
        transformed_df["account_number_integration_authentication_id"] = integration_authentication_id
        
        ##Step 13: Fetch existing inventory ICCIDs
        main_iccids_data = tenant_database.get_data(
            "sim_management_inventory",
            {
                "service_provider_id": service_provider_id,
                "tenant_id": tenant_id,
                "is_active": True
            },
            ["iccid"]
        )
        
        if main_iccids_data is not None and not main_iccids_data.empty:
            main_iccids = set(
                main_iccids_data["iccid"]
                .dropna()
                .astype(str)
                .str.strip()
            )
        else:
            main_iccids = set()
        
        ##Step 14: Split into insert and update dataframes
        if "iccid" in transformed_df.columns:
            transformed_df["iccid"] = transformed_df["iccid"].astype(str).str.strip()
            
            insert_df = transformed_df[
                ~transformed_df["iccid"].isin(main_iccids)
            ].copy()
            
            update_df = transformed_df[
                transformed_df["iccid"].isin(main_iccids)
            ].copy()
        else:
            insert_df = pd.DataFrame()
            update_df = pd.DataFrame()
            logging.error("### sync_staging_to_main - ICCID column missing in transformed dataframe")
        
        ##Step 15: Insert new devices
        new_devices_insert_flag = True
        inserted_count = 0
        
        if not insert_df.empty:
            logging.info(f"### sync_staging_to_main ICCIDs being inserted: {insert_df['iccid'].tolist()}")
            
            # Clean NaN values
            insert_df = insert_df.replace({np.nan: None})
            
            # Convert integer columns 
            integer_columns = [
                "carrier_cycle_usage_bytes",
                "carrier_rate_plan_id", 
                "sub_tenant_carrier_rate_plan_name_id",
                "service_provider_id", 
                "device_status_id", 
                "billing_period_id",
                "bill_year", 
                "bill_month", 
                "integration_id", 
                "tenant_id"
            ]
            
            # Float columns
            float_columns = [
                "carrier_cycle_usage_mb"
            ]
            
            # Convert integer columns
            for col in integer_columns:
                if col in insert_df.columns:
                    insert_df[col] = insert_df[col].apply(
                        lambda x: int(float(x)) if pd.notnull(x) and x != "" and x != "None" else None
                    )
            
            # Convert float columns
            for col in float_columns:
                if col in insert_df.columns:
                    insert_df[col] = insert_df[col].apply(
                        lambda x: float(x) if pd.notnull(x) and x != "" and x != "None" else None
                    )
            
            insert_payload = insert_df.to_dict(orient="records")
            
            try:
                new_devices_insert_flag = tenant_database.insert_data(
                    insert_payload,
                    "sim_management_inventory"
                )
                inserted_count = len(insert_payload)
                logging.info(f"### sync_staging_to_main - Inserted {inserted_count} new Teal devices into inventory")
                
                try:
                    update_progress_tracker(progress_tracker_id, current_status=f"Inserted {inserted_count} records Successfully into Inventory", status="In Progress",
                                             common_utils_database=common_utils_database, action="update", now=now, progress=76, data=data)
                except Exception as e:
                    logging.exception(f"### sync_staging_to_main - {tenant_name} Error updating progress tracker: {e}")
                    
            except Exception as e:
                logging.exception(f"### sync_staging_to_main - Error inserting new devices: {e}")
                new_devices_insert_flag = False
        else:
            logging.info(f"### sync_staging_to_main - No new Teal devices to insert")
        
        ##Step 16: Update existing devices
        bulk_update_flag = True
        updated_count = 0
        
        if not update_df.empty:
            ##for update only we will remove tenant id filter
            if "tenant_id" in update_df.columns:
                update_df = update_df.drop(columns=["tenant_id"], errors="ignore")
            
            logging.info(f"### sync_staging_to_main ICCIDs being updated: {update_df['iccid'].tolist()}")
            
            # Clean NaN values
            update_df = update_df.replace({np.nan: None})
            
            # Convert integer columns 
            integer_columns = [
                "carrier_cycle_usage_bytes",
                "carrier_rate_plan_id", 
                "sub_tenant_carrier_rate_plan_name_id",
                "service_provider_id", 
                "device_status_id", 
                "billing_period_id",
                "bill_year", 
                "bill_month", 
                "integration_id"
            ]
            
            # Float columns
            float_columns = [
                "carrier_cycle_usage_mb"
            ]
            
            # Convert integer columns
            for col in integer_columns:
                if col in update_df.columns:
                    update_df[col] = update_df[col].apply(
                        lambda x: int(float(x)) if pd.notnull(x) and x != "" and x != "None" else 0
                    )
            
            # Convert float columns
            for col in float_columns:
                if col in update_df.columns:
                    update_df[col] = update_df[col].apply(
                        lambda x: float(x) if pd.notnull(x) and x != "" and x != "None" else 0.0
                    )
            
            update_dict = update_df.to_dict(orient="records")
            
            try:
                bulk_update_flag = tenant_database.bulk_update_data(
                    table_name="sim_management_inventory",
                    data_list=update_dict,
                    search_column="iccid",
                    static_conditions={
                        "service_provider_id": service_provider_id
                    }
                )
                updated_count = len(update_dict)
                logging.info(f"### sync_staging_to_main - Updated {updated_count} existing Teal devices in inventory")
                
                try:
                    update_progress_tracker(progress_tracker_id, current_status=f"Updated {updated_count} records Successfully in Inventory", status="In Progress",
                                             common_utils_database=common_utils_database, action="update", now=now, progress=78, data=data)
                except Exception as e:
                    logging.exception(f"### sync_staging_to_main - {tenant_name} Error updating progress tracker: {e}")
                    
            except Exception as e:
                logging.exception(f"### sync_staging_to_main - Error updating devices: {e}")
                bulk_update_flag = False
        else:
            logging.info(f"### sync_staging_to_main - No existing Teal devices to update")
        
        ##Step 17: Prepare audit summary
        audit_comments = {
            "sync_type": "Teal Carrier Sync Staging → Main Inventory",
            "service_provider": service_provider_name,
            "tenant_name": tenant_name,
            "summary": {
                "total_staging_records": len(staging_df),
                "new_devices_inserted": inserted_count,
                "existing_devices_updated": updated_count
            }
        }
        
        ##Step 18: Return result
        if bulk_update_flag and new_devices_insert_flag:
            logging.info("### sync_staging_to_main Sync completed successfully")
            
            try:
                audit_data_user_actions = {
                    "service_name": "sync_staging_to_main",
                    "created_by": username,
                    "status": "Success",
                    "session_id": data.get("session_id", ""),
                    "tenant_name": tenant_name,
                    "comments": json.dumps(audit_comments),
                    "module_name": "Carrier Sync",
                    "request_received_at": data.get("request_received_at", now),
                }
                common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            except Exception as e:
                logging.error(f"### sync_staging_to_main auditing failed in success case :{e}")
            
            return {
                "flag": True,
                "message": "Sync successful",
                "summary": {
                    "total_staging_records": len(staging_df),
                    "new_devices_inserted": inserted_count,
                    "existing_devices_updated": updated_count
                }
            }
        else:
            return {
                "flag": False,
                "message": "Sync failed",
                "summary": {
                    "total_staging_records": len(staging_df),
                    "new_devices_inserted": inserted_count if 'inserted_count' in locals() else 0,
                    "existing_devices_updated": updated_count if 'updated_count' in locals() else 0
                }
            }
            
    except Exception as e:
        error_message = f"Error during sync_staging_to_main : {str(e)}"
        error_type = str(type(e).__name__)
        logging.exception(f"### sync_staging_to_main Sync failed: {e}")
        
        # Log error to database
        try:
            error_data = {
                "service_name": "sync_staging_to_main",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during sync_staging_to_main for tenant {tenant_name}: {str(e)}",
                "module_name": "Carrier Sync",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### sync_staging_to_main and {tenant_name} Exception in logging error data to DB: {e}")
        
        return {
            "flag": False,
            "message": str(e),
            "Sync failed": "Sync failed"
        }
    
    
# Function to update device usage table from Teal staging data
def update_teal_device_usage_table(data, tenant_database, common_utils_database):
    """
    Updates device usage table with data from Teal staging table.
    
    Args:
        data (dict): Request data containing:
            - created_by (str): User performing the operation
            - delayed_days (int): Number of days to delay usage date
            - tenant_name (str): Tenant name
            - service_provider_id (str): Service provider ID
            - tenant_id (str): Tenant ID
            
    Returns:
        dict: Result with flag and message
    """
    logging.info(f"update_teal_device_usage_table request received: {data}")
    
    # Step 1: Extract required parameters from request data
    created_by = data.get("created_by", "Teal_Container")
    delayed_days = data.get("delayed_days", 1)
    tenant_name = data.get("tenant_name")
    tenant_id = data.get('tenant_id')
    service_provider_id = data.get('service_provider_id')
    
    # Teal staging table for usage
    staging_table = "teal_carrier_sync_staging"
    
    try:
        # Step 2: Fetch active ICCIDs from sim_management_inventory
        inventory_df = tenant_database.get_data(
            "sim_management_inventory",
            {"service_provider_id": service_provider_id, "tenant_id": tenant_id, "is_active": True},
            ["id", "iccid", "device_id", "mobility_device_id", "device_status_id"]
        )
        
        if inventory_df is not None and not inventory_df.empty:
            iccids = inventory_df["iccid"].astype(str).tolist()
        else:
            iccids = []
        
        logging.info(f"Fetched {len(iccids)} active ICCIDs from main table")
        
        if not iccids:
            logging.info(f"No ICCIDs provided for {tenant_name}")
            return {"flag": False, "message": "No ICCIDs provided"}
        
        # Step 3: Calculate usage date based on delayed_days parameter
        usage_date = datetime.now().date() - timedelta(days=delayed_days)
        
        # Step 4: Fetch usage data from staging table for active ICCIDs
        # For Teal, usage is stored in the main device staging table
        staging_usage_df = tenant_database.get_data(
            staging_table,
            {"iccid": iccids},
            ["iccid", "usage", "total_usage", "total_usage_mb"],
        )
        
        if staging_usage_df.empty:
            logging.warning(f"No staging usage records found for {tenant_name}")
            return {"flag": False, "message": "No staging usage records found"}
        
        # Rename columns to standard names
        if "usage" in staging_usage_df.columns:
            staging_usage_df.rename(columns={"usage": "data_usage"}, inplace=True)
        elif "total_usage" in staging_usage_df.columns:
            staging_usage_df.rename(columns={"total_usage": "data_usage"}, inplace=True)
        
        # Step 5: Merge inventory and staging data on ICCID
        usage_df = (
            pd.merge(inventory_df, staging_usage_df, on="iccid", how="inner")
            .drop_duplicates(subset=["iccid"])
            .reset_index(drop=True)
        )
        
        if usage_df.empty:
            logging.warning(f"No matched usage records after merge for {tenant_name}")
            return {"flag": False, "message": "No matched usage records"}
        
        # Get device IDs
        device_ids = []
        if "device_id" in usage_df.columns:
            device_ids = usage_df["device_id"].tolist()
        
        # Step 6: Check which device IDs already have usage records for the usage_date
        device_usage_present_df = tenant_database.get_data(
            "device_usage",
            {"m2m_device_id": device_ids, "usage_date": usage_date},
            ["m2m_device_id"],
        )
        
        existing_device_ids = set()
        if device_usage_present_df is not None and not device_usage_present_df.empty:
            existing_device_ids = set(device_usage_present_df["m2m_device_id"].tolist())
        
        # Step 7: Split merged data into new records (insert) and existing records (update)
        new_usage_df = usage_df[~usage_df["device_id"].isin(existing_device_ids)]
        update_usage_df = usage_df[usage_df["device_id"].isin(existing_device_ids)]
        
        # Step 8: Build and insert new device usage records
        if not new_usage_df.empty:
            insert_records = [
                {
                    "sim_management_inventory_id": row["id"],
                    "m2m_device_id": row["device_id"],
                    "mobility_device_id": row["mobility_device_id"] if "mobility_device_id" in row else None,
                    "data_usage": row["data_usage"] if "data_usage" in row else 0,
                    "sms_usage": 0,  # Teal doesn't provide SMS usage separately
                    "voice_usage": 0,  # Teal doesn't provide voice usage separately
                    "usage_date": usage_date,
                    "device_status_id": row["device_status_id"],
                    "created_by": created_by,
                    "modified_by": created_by,
                }
                for _, row in new_usage_df.iterrows()
            ]
            
            usage_insert_flag = tenant_database.insert_data(insert_records, "device_usage")
            logging.info(f"Inserted {len(insert_records)} usage records, flag: {usage_insert_flag}")
        
        # Step 9: Build and update existing device usage records
        if not update_usage_df.empty:
            update_records = [
                {
                    "sim_management_inventory_id": row["id"],
                    "m2m_device_id": row["device_id"],
                    "mobility_device_id": row["mobility_device_id"] if "mobility_device_id" in row else None,
                    "data_usage": row["data_usage"] if "data_usage" in row else 0,
                    "device_status_id": row["device_status_id"],
                    "modified_by": created_by,
                }
                for _, row in update_usage_df.iterrows()
            ]
            
            usage_update_flag = tenant_database.bulk_update_data(
                "device_usage",
                update_records,
                search_column="m2m_device_id",
                static_conditions={"usage_date": usage_date}
            )
            logging.info(f"Updated {len(update_records)} usage records, flag: {usage_update_flag}")
        
        # Step 10: Log success audit entry
        try:
            audit_data = {
                "service_name": "update_teal_device_usage_table",
                "created_date": datetime.now(),
                "created_by": created_by,
                "status": "Success",
                "tenant_name": tenant_name,
                "comments": f"Updated device usage for {len(iccids)} ICCIDs on {usage_date}",
                "module_name": "Carrier Sync",
                "request_received_at": datetime.now(),
                "session_id": None
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Audit logging failed: {e}")
        
        # Step 11: Return success response
        return {"flag": True, "message": "Device usage updated successfully"}
        
    except Exception as e:
        logging.exception(f"Error in update_teal_device_usage_table: {e}")
        
        # Step 12: Log error audit entry on failure
        try:
            error_data = {
                "service_name": "update_teal_device_usage_table",
                "error_message": str(e),
                "error_type": str(type(e).__name__),
                "users": data.get("created_by", "system"),
                "session_id": None,
                "tenant_name": data.get("tenant_name", ""),
                "comments": f"Failed to update device usage for {data.get('service_provider_name', '')}",
                "module_name": "Carrier Sync",
                "request_received_at": datetime.now()
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as audit_error:
            logging.error(f"Error audit logging failed: {audit_error}")
        
        return {"flag": False, "message": "Failed to update device usage"}


# Function to handle history table updates for Webbing
def history_table_updates(data,tenant_database,common_utils_database):
    """
    Synchronizes cross-provider device history by identifying devices with usage
    that are not already in cross-provider history and inserting them.
    
    This function filters device usage records to find devices that have data usage
    but are not present in the cross-provider device history table, then creates
    cross-provider history records for those devices.
    
    Args:
        data (dict): Request data containing:
            - tenant_name (str): Name of the tenant
            - service_provider (str): Service provider name
            - created_by (str, optional): User who created the sync. Defaults to "Kore_Container"
            - usage_date (str): Date for which to sync usage data
    
    Returns:
        dict: Response containing:
            - flag (bool): Success/failure indicator
            - message (str): Status message
            - records_synced (int, optional): Number of records synchronized
    
    Raises:
        Exception: Any errors during database operations or data processing
    """
    logging.info(f"Received data for history_table_updates: {data}")
    # Step 1: Extract required parameters from request data
    tenant_id = int(data.get("tenant_id")) if data.get("tenant_id") else None
    service_provider_id = int(data.get("service_provider_id")) if data.get("service_provider_id") else None
    service_provider=data.get("service_provider_name",None)
    created_by = data.get("username", "webbing_container")
    tenant_name=data.get('tenant_name',None)
    raw_usage_date = data.get("usage_date")
    billing_period_id= int(data.get('billing_period_id')) if data.get('billing_period_id') else None
    if "telegence" in service_provider.lower():
        is_mobility = True
        history_dt_column = "mobility_device_tenant_id"
        inventory_dt_column = "mdt_id"
    else:
        is_mobility = False
        history_dt_column = "device_tenant_id"  
        inventory_dt_column = "dt_id"
    
    # Step 2: Parse usage date and calculate start/end datetime range
    # Handle both date formats: 'YYYY-MM-DD HH:MM:SS' and 'MM/DD/YYYY'
    try:
        usage_date = datetime.strptime(raw_usage_date, "%Y-%m-%d %H:%M:%S")
    except Exception as e:
        logging.exception(f"Exception while fetching usage_date{e}")
        usage_date = datetime.strptime(raw_usage_date, "%m/%d/%Y")
    # Start of day: 2026-02-03 00:00:00
    start_dt = usage_date.replace(hour=0, minute=0, second=0, microsecond=0)
    # End of day (exclusive): 2026-02-04 00:00:00
    end_dt = start_dt + timedelta(days=1)
    try:
        device_id_column = ("mobility_device_id" if "telegence" in service_provider.lower() else "device_id")
        # Fetch all active device IDs from sim_management_inventory
        active_devices_df = tenant_database.get_data(
            table_name="sim_management_inventory",
            condition={
                "is_active": True,
                "service_provider_id": service_provider_id
            },
            columns=[device_id_column]
        )
        # Convert device IDs into a Python list
        if active_devices_df is not None and not active_devices_df.empty:
            device_id_list = (active_devices_df[device_id_column].dropna().astype(int).tolist())     # Convert float → int
        else:
            device_id_list = []
        if not device_id_list:
            logging.warning("No active devices found in inventory table")
            return {"flag": False, "message": "No active devices found in Inventory table"}

        # Fetch device usage records (only devices with data_usage > 0)
        device_usage_query = f"""
            SELECT *
            FROM device_usage
            WHERE m2m_device_id = ANY(%s)
            AND usage_date >= %s
            AND usage_date < %s
            AND data_usage > 0
        """
        device_usage_df = tenant_database.execute_query(
            device_usage_query,
            params=[device_id_list, start_dt, end_dt]
        )
        logging.info(f"### history_table_updates length of device_usage_df : {len(device_usage_df)} and billing_period_id is {billing_period_id}")
        
        # Step 5: Fetch existing cross-provider device history records
        cross_provider_device_column = "mobility_device_id" if "Telegence" in service_provider else "m2m_device_id"
        cross_provider_devices_df = tenant_database.get_data(
            "cross_provider_device_history",
            {"service_provider_id": service_provider_id, 
             "billing_period_id": billing_period_id,
             "is_active": True
             },
             [cross_provider_device_column]
        )
        logging.info(f"### history_table_updates length of cross_provider_devices_df : {len(cross_provider_devices_df)}")
        
        # Step 6: Get all device IDs from usage records and fetch inventory data
        if device_usage_df is not None and not device_usage_df.empty:
            all_device_ids = (device_usage_df["m2m_device_id"].dropna().astype(int).tolist())     # Convert float → int
        else:
            all_device_ids = []
        if not all_device_ids:
            logging.info(f"### history_table_updates No device usage records found")
            return {"flag": True, "message": "No device usage records found."}
        logging.info(f"### history_table_updates all_device_ids : {all_device_ids}")
         
        inventory_device_column = "mobility_device_id" if "Telegence" in service_provider else "device_id"
        inventory_df = tenant_database.get_data(
            "sim_management_inventory",
            {inventory_device_column: all_device_ids, "is_active": True, "service_provider_id": service_provider_id}
        )
        logging.info(f"### history_table_updates inventory_df size : {len(inventory_df)}")
        
        # Step 7: Split device IDs into new and existing records
        if not cross_provider_devices_df.empty:
            cross_provider_device_ids = set(cross_provider_devices_df[cross_provider_device_column].tolist())
            new_device_ids = [did for did in all_device_ids if did not in cross_provider_device_ids]
            existing_device_ids = [did for did in all_device_ids if did in cross_provider_device_ids]
        else:
            new_device_ids = all_device_ids
            existing_device_ids = []

        # Step 8: Sync device history tables (device_history, mobility_device_history, smi_device_history)
        device_history_response=device_history_sync(billing_period_id,inventory_df,tenant_database,service_provider_id,service_provider,usage_date,created_by,common_utils_database,tenant_name,tenant_id)
        
        # Step 9: Define helper function to build cross-provider device history record   
        def build_record(row):
            """
            This function extracts SIM, device, customer, usage, and billing details
            from the given inventory row and prepares a dictionary payload for inserting or
            updating device history records.

            Args:
                row (dict/Series): Inventory row containing device and subscription data.
            Returns:
                dict: Device history record payload with tenant, plan, and usage fields.
            """
            record = {
                "m2m_device_id": row.get("device_id"),
                "mobility_device_id": row.get("mobility_device_id"),
                "service_provider_id": row.get("service_provider_id"),
                "iccid": row.get("iccid"),
                "msisdn": row.get("msisdn"),
                "imsi": row.get("imsi"),
                "imei": row.get("imei"),
                "carrier_rate_plan_id": row.get("carrier_rate_plan_id"),
                "created_by": row.get("created_by"),
                "created_date": row.get("created_date"),
                "modified_by": created_by,
                "modified_date": datetime.now(),
                "account_number": row.get("rev_customer_id"),
                "account_number_integration_authentication_id": row.get("account_number_integration_authentication_id"),
                "customer_id": row.get("customer_id"),
                "customer_rate_plan_id": row.get("customer_rate_plan_id"),
                "customer_rate_pool_id": row.get("customer_rate_pool_id"),
                "tenant_id": row.get("tenant_id"),
                "customer_data_allocation_mb": row.get("customer_data_allocation_mb"),
                "provider_date_added": row.get("date_added"),
                "provider_date_activated": row.get("date_activated"),
                "username": row.get("username"),
                "device_status_id": row.get("device_status_id"),
                "status": row.get("sim_status"),
                "rate_plan": row.get("carrier_rate_plan_name"),
                "last_usage_date": row.get("last_usage_date"),
                "carrier_cycle_usage": row.get("carrier_cycle_usage_bytes"),
                "ctd_sms_usage": row.get("ctd_sms_usage"),
                "ctd_voice_usage": row.get("ctd_voice_usage"),
                "ctd_session_count": row.get("ctd_session_count"),
                "last_activated_date": row.get("last_activated_date"),
                "billing_period_id": billing_period_id,
                "package": row.get("package"),
                "billing_cycle_end_date": row.get("billing_cycle_end_date"),
                "cost_center": row.get("cost_center"),
                "communication_plan": row.get("communication_plan"),
                "foundation_account_number": row.get("foundation_account_number"),
                "billing_account_number": row.get("billing_account_number"),
                "is_active": True,
                "is_deleted": False,
            }
            if tenant_id != row.get("tenant_id"):
                record["sub_tenant_carrier_rate_plan_name"] = record.get("sub_tenant_carrier_rate_plan_name")
                record["sub_tenant_carrier_rate_plan_name_id"] = int(record.get("sub_tenant_carrier_rate_plan_name_id")) if record.get("sub_tenant_carrier_rate_plan_name_id") else None
            if is_mobility:
                record["mobility_device_tenant_id"] = row.get("mdt_id")
                record["mobility_device_id"] = row.get("mobility_device_id")
            else:
                record["device_tenant_id"] = row.get("dt_id")
                record["m2m_device_id"] = row.get("device_id")
            return record
        
        # Step 10: Build records for new devices to insert
        new_records = []
        if new_device_ids:
            new_inventory_df = inventory_df[inventory_df["device_id"].isin(new_device_ids)]
            new_records = [build_record(row) for _, row in new_inventory_df.iterrows()]
            
        # Step 11: Build records for existing devices to update
        update_records = []
        if existing_device_ids:
            existing_inventory_df = inventory_df[inventory_df["device_id"].isin(existing_device_ids)]
            update_records = [build_record(row) for _, row in existing_inventory_df.iterrows()]
        
        # Step 12: Insert new cross-provider device history records
        inserted_count = 0
        inserted_ids = []
        if new_records:
            inserted_ids = tenant_database.insert_data_return_ids(new_records,"cross_provider_device_history", "id")
            inserted_count = len(inserted_ids)
            logging.info(f"Inserted {inserted_count} new cross-provider device history records")
        else:    
            logging.info(f"### history_table_updates No Records to insert into cross_provider_device_history table")    
        
        # Step 13: Update existing cross-provider device history records
        updated_count = 0
        updated_ids = []
        if update_records:
            # remove created_by and created_date from update records to avoid updating those fields
            for record in update_records:
                record.pop("created_by", None)
                record.pop("created_date", None)
            updated_ids = tenant_database.bulk_update_return_ids(
                "cross_provider_device_history", 
                update_records, 
                search_column=cross_provider_device_column,
                static_conditions={"service_provider_id": service_provider_id, "billing_period_id": billing_period_id, "tenant_id": tenant_id},
                return_id_column="id"
            )
            if updated_ids:
                updated_count = len(updated_ids)
                logging.info(f"Updated {updated_count} existing cross-provider device history records")
        else:
            logging.info(f"### history_table_updates No records found to update in cross_provider_device_history table")    
            
        ####################################### smi_cross_provider_device_history table ################################################
        
        # Step 14 : Combine inserted and updated IDs for smi_cross_provider_device_history sync
        smi_update_ids = inserted_ids + updated_ids
        logging.info(f"### smi_update_ids size : {len(smi_update_ids)} and inserted_ids size : {len(inserted_ids)} and updated_ids size: {len(updated_ids)}")
        ids_to_update_in_smi = []
        ids_to_insert_in_smi = []
        # Step 10: Check which device history IDs already exist in smi_cross_provider_device_history
        if smi_update_ids:
            smi_device_history_df = tenant_database.get_data(
                "smi_cross_provider_device_history",
                {"cdhid": smi_update_ids},
                ["id","cdhid"]
            )
            logging.info(f"### smi_device_history_df size :{len(smi_device_history_df)}")
            if not smi_device_history_df.empty:
                smi_device_history_ids = smi_device_history_df["cdhid"].tolist()
                ids_to_update_in_smi = [id for id in smi_update_ids if id in smi_device_history_ids]
                ids_to_insert_in_smi = [id for id in smi_update_ids if id not in smi_device_history_ids]
            else:
                ids_to_update_in_smi = []
                ids_to_insert_in_smi = smi_update_ids
        else:
            logging.info(f"### smi_update_ids size : {len(smi_update_ids)}") 

        # Step 11: Fetch updated device history records to get device_tenant_id mapping
        updated_device_history_df = tenant_database.get_data(
            "cross_provider_device_history",
            {"id": smi_update_ids},
            [history_dt_column,"id"]
        )

        logging.info(f"#### updated_device_history_df size:{len(updated_device_history_df)} ")
        if not updated_device_history_df.empty:
            updated_device_tenant_ids = updated_device_history_df[history_dt_column].tolist()
            device_history_dict = updated_device_history_df.set_index(history_dt_column)["id"].to_dict()
        else:
            updated_device_tenant_ids = []
            device_history_dict = {}
    
        # Step 15 : Fetch inventory records for devices that need smi_cross_provider_device_history sync
        inventory_df_for_smi = tenant_database.get_data(
            "sim_management_inventory",
            {inventory_dt_column: updated_device_tenant_ids, "is_active": True, "service_provider_id": service_provider_id}
        )
        logging.info(f"### inventory_df_for_smi size : {len(inventory_df_for_smi)}")
        
        # Step 16: Define helper function to build smi_cross_provider_device_history record
        def build_smi_cross_provider_record(row):
            """
                Build a record dictionary for inserting/updating `smi_cross_provider_device_history`.
                Args:
                    row (Series/dict): Inventory row containing device and usage details.
                Returns:
                    dict: Prepared SMI device history record.
            """
            device_tenant_id = row.get(inventory_dt_column)
            device_history_id = device_history_dict.get(device_tenant_id)
            record = {
                "changed_date": datetime.now(),
                "sim_management_inventory_id": row.get("id"),
                "service_provider_id": row.get("service_provider_id"),
                "iccid": row.get("iccid"),
                "imsi": row.get("imsi"),
                "msisdn": row.get("msisdn"),
                "imei": row.get("imei"),
                "device_status_id": row.get("device_status_id"),
                "carrier_rate_plan_id": row.get("carrier_rate_plan_id"),
                "communication_plan": row.get("communication_plan"),
                "communication_plan_id": row.get("communication_plan_id"),
                "customer_id": row.get("customer_id"),
                "customer_rate_plan_id": row.get("customer_rate_plan_id"),
                "customer_rate_plan_name": row.get("customer_rate_plan_name"),
                "customer_rate_pool_id": row.get("customer_rate_pool_id"),
                "customer_rate_pool_name": row.get("customer_rate_pool_name"),
                "last_usage_date": row.get("last_usage_date"),
                "carrier_cycle_usage": row.get("carrier_cycle_usage_bytes"),
                "created_by": created_by,
                "created_date": datetime.now(),
                "modified_by": created_by,
                "modified_date": datetime.now(),
                "last_activated_date": row.get("last_activated_date"),
                "is_active": True,
                "is_deleted": False,
                "account_number": row.get("rev_customer_id"),
                "provider_date_added": row.get("date_added"),
                "provider_date_activated": row.get("date_activated"),
                "cost_center": row.get("cost_center"),
                "username": row.get("username"),
                "account_number_integration_authentication_id": row.get("account_number_integration_authentication_id"),
                "billing_period_id": billing_period_id,
                "tenant_id": row.get("tenant_id"),
                "customer_data_allocation_mb": row.get("customer_data_allocation_mb"),
                "device_tenant_id": row.get("dt_id"),
                "mobility_device_tenant_id": row.get("mdt_id"),
                "foundation_account_number": row.get("foundation_account_number"),
                "billing_account_number": row.get("billing_account_number"),
                "ip_address": row.get("ip_address"),    
                "device_status":row.get("sim_status"),
                "carrier_sms_usage":row.get("carrier_sms_usage"),
                "carrier_voice_usage":row.get("carrier_voice_usage"),     
            }
            record["cdhid"] = device_history_id
            active_in_cycle = True if (row.get("sim_status").lower() in ["online","ONLINE","Online","active","activated","a"]) else False
            if active_in_cycle:
                record["active_in_cycle"] = True
            else:
                record["active_in_cycle"] = False
                
            if tenant_id != row.get("tenant_id"):
                record["sub_tenant_carrier_rate_plan_name"] = record.get("sub_tenant_carrier_rate_plan_name")
                record["sub_tenant_carrier_rate_plan_name_id"] = int(record.get("sub_tenant_carrier_rate_plan_name_id")) if record.get("sub_tenant_carrier_rate_plan_name_id") else None
            if is_mobility:
                record["mobility_device_tenant_id"] = row.get("mdt_id")
                record["m2m_device_id"] =  row.get("device_id")
            else:
                record["device_tenant_id"] = row.get("dt_id")
                record["mobility_device_id"] =  row.get("device_id") 
            return record
        
        # Step 17: Build records for smi_cross_provider_device_history update
        smi_update_records = []
        smi_insert_records = [] 
        if ids_to_update_in_smi or ids_to_insert_in_smi : 
            for _, row in inventory_df_for_smi.iterrows():
                history_id = device_history_dict.get(row.get(inventory_dt_column))

                if history_id in ids_to_update_in_smi:
                    smi_update_records.append(build_smi_cross_provider_record(row))

                elif history_id in ids_to_insert_in_smi:
                    smi_insert_records.append(build_smi_cross_provider_record(row))
        logging.info(f"### smi_update_records : {len(smi_update_records)} and smi_insert_records size :{len(smi_insert_records)} ")        
                
        # Step 18 : Update existing smi_cross_provider_device_history records
        if smi_update_records:
            # remove created_by and created_date from update records to avoid updating those fields
            for record in smi_update_records:
                record.pop("created_by", None)
                record.pop("created_date", None)
            tenant_database.bulk_update_data(
                "smi_cross_provider_device_history",
                smi_update_records,
                search_column=history_dt_column,
                static_conditions={"service_provider_id": service_provider_id, "billing_period_id": billing_period_id}
            )
            logging.info(f"Updated {len(smi_update_records)} records in smi_cross_provider_device_history")
        else:
            logging.info(f"### No records found to update in smi_cross_provider_device_history smi_update_records : {len(smi_update_records)}")    

        # Step 19: Insert new smi_cross_provider_device_history records
        if smi_insert_records:
            tenant_database.insert_data(smi_insert_records, "smi_cross_provider_device_history")
            logging.info(f"Inserted {len(smi_insert_records)} records in smi_cross_provider_device_history")
        else:
            logging.info(f"### No records found to insert into smi_cross_provider_device_history table smi_insert_records size: {len(smi_insert_records)}")     
        # Step 20: Log success audit entry
        try:
            audit_data = {
                "service_name": "history_table_updates",
                "created_date": datetime.now(),
                "created_by": created_by,
                "status": "Success",
                "tenant_name": tenant_name,
                "comments": f"Cross-provider device history sync completed for {service_provider} on {usage_date}",
                "module_name": "Carrier Sync",
                "request_received_at": datetime.now(),
                "session_id": None
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Audit logging failed: {e}")            
        
        # Step 21: Return success response with sync summary
        response={
            "flag": True, 
            "message": f"Successfully synced cross-provider device history: {inserted_count} inserted, {updated_count} updated",
            "records_inserted": inserted_count,
            "records_updated": updated_count
        }
        return response
    except Exception as e:
        logging.error(f"Error in history_table_updates: {e}")
        
        # Error audit logging
        try:
            error_data = {
                "service_name": "history_table_updates",
                "error_message": str(e),
                "error_type": str(type(e).__name__),
                "users": created_by,
                "session_id": None,
                "tenant_name": tenant_name,
                "comments": f"Cross-provider device history sync failed for {service_provider} on {usage_date}",
                "module_name": "Carrier Sync",
                "request_received_at": datetime.now()
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as audit_error:
            logging.error(f"Error audit logging failed: {audit_error}")     
        response={"flag": False, "message": f"Error in history_table_updates: {str(e)}"}
        return response
    
# Function to sync device history records for a billing period based on inventory data
def device_history_sync(billing_period_id,inventory_df,tenant_database,service_provider_id,service_provider,usage_date,created_by,common_utils_database,tenant_name,tenant_id):
    """
    Sync device history records for a billing period.

    Inserts new device history entries and updates existing ones based on the
    current inventory data. Also maintains corresponding records in the
    `smi_device_history` table for reporting and auditing.

    Supports both Telegence (mobility) and standard service providers.

    Args:
        billing_period_id (int): Billing cycle identifier.
        inventory_df (DataFrame): Latest inventory/device data.
        tenant_database (DB): Tenant database connection object.
        service_provider_id (int): Service provider identifier.
        service_provider (str): Service provider name.
        usage_date (date/str): Usage date for sync reference.
        created_by (str): User triggering the sync.
        common_utils_database (DB): Common utilities database connection.
        tenant_name (str): Tenant name for audit logging.

    Returns:
        None
    """
    logging.info(f"Starting device_history_sync for billing_period_id: {billing_period_id}, service_provider_id: {service_provider_id} usage_date: {usage_date}")
    billing_period_id = int(billing_period_id) if billing_period_id else None
    service_provider_id = int(service_provider_id) if service_provider_id else None
    tenant_id = int(tenant_id) if tenant_id else None
    try:
        # Step 1: Determine table and column names based on service provider type
        if "telegence" in service_provider.lower():
            device_tenant_ids = inventory_df["mdt_id"].unique().tolist()
            history_table = "mobility_device_history"
            history_dt_column = "mobility_device_tenant_id"
            inventory_dt_column = "mdt_id"
            history_id_column = "mhid"
            is_mobility = True
        else:
            history_table = "device_history"
            device_tenant_ids = inventory_df["dt_id"].unique().tolist()
            history_dt_column = "device_tenant_id"
            inventory_dt_column = "dt_id"
            history_id_column = "dhid"
            is_mobility = False
        
        # Step 2: Fetch existing device history records for the billing period
        device_history_df = tenant_database.get_data(
            history_table,
            {"service_provider_id": service_provider_id, 
            "billing_period_id": billing_period_id,
            "is_active": True
            },
            [history_dt_column]
        )

        # Step 3: Split device IDs into new and existing based on history table
        if not device_history_df.empty:
            device_history_ids = set(device_history_df[history_dt_column].tolist())
            new_device_ids = [did for did in device_tenant_ids if did not in device_history_ids]
            existing_device_ids = [did for did in device_tenant_ids if did in device_history_ids]
        else:
            new_device_ids = device_tenant_ids
            existing_device_ids = []
        logging.info(f"device_history_sync - new_device_ids count: {len(new_device_ids)}, existing_device_ids count: {len(existing_device_ids)} , device_history_df size : {len(device_history_df)}")
        
        # Step 4: Define helper function to build device history record from inventory row
        def build_record(row):
            """
            Build a device history record from an inventory row. Prepares a dictionary for inserting/updating records in the
            device_history or mobility_device_history table, including service provider, SIM details, usage, and tenant mapping.
            
            Args:
                row (Series/dict): Inventory row containing device information.
            Returns:
                dict: Formatted device history record.
            """
            record = {
                "service_provider_id": row.get("service_provider_id"),
                "iccid": row.get("iccid"),
                "imsi": row.get("imsi"),
                "msisdn": row.get("msisdn"),
                "imei": row.get("imei"),
                "changed_date": datetime.now(),
                "device_status_id": row.get("device_status_id"),
                "status": row.get("sim_status"),
                "carrier_rate_plan_id": row.get("carrier_rate_plan_id"),
                "rate_plan": row.get("carrier_rate_plan_name"),
                "communication_plan": row.get("communication_plan"),
                "last_usage_date": row.get("last_usage_date"),
                "package": row.get("package"),
                "billing_cycle_end_date": row.get("billing_cycle_end_date"),
                "carrier_cycle_usage": row.get("carrier_cycle_usage_bytes"),
                "ctd_sms_usage": row.get("ctd_sms_usage"),
                "ctd_voice_usage": row.get("ctd_voice_usage"),
                "ctd_session_count": row.get("ctd_session_count"),
                "created_by": created_by,
                "created_date": datetime.now(),
                "modified_by": created_by,
                "modified_date": datetime.now(),
                "last_activated_date": row.get("last_activated_date"),
                "is_active": True,
                "is_deleted": False,
                "is_pushed": False,
                "account_number": row.get("rev_customer_id"),
                "provider_date_added": row.get("date_added"),
                "provider_date_activated": row.get("date_activated"),
                "cost_center": row.get("cost_center"),
                "username": row.get("username"),
                "account_number_integration_authentication_id": row.get("account_number_integration_authentication_id"),
                "billing_period_id": billing_period_id,
                "customer_id": row.get("customer_id"),
                "customer_rate_plan_id": row.get("customer_rate_plan_id"),
                "customer_rate_pool_id": row.get("customer_rate_pool_id"),
                "tenant_id": row.get("tenant_id")
            }
            if tenant_id != row.get("tenant_id"):
                record["sub_tenant_carrier_rate_plan_name"] = record.get("sub_tenant_carrier_rate_plan_name")
                record["sub_tenant_carrier_rate_plan_name_id"] = int(record.get("sub_tenant_carrier_rate_plan_name_id")) if record.get("sub_tenant_carrier_rate_plan_name_id") else None
            if is_mobility:
                record["id"] = row.get("mobility_device_id")
                record["mobility_device_tenant_id"] = row.get("mdt_id")
            else:
                record["id"] = row.get("device_id")
                record["device_tenant_id"] = row.get("dt_id")
            return record
        
        # Step 5: Build records for new devices to insert into device history
        new_records = []
        if new_device_ids:
            new_inventory_df = inventory_df[inventory_df[inventory_dt_column].isin(new_device_ids)]
            new_records = [build_record(row) for _, row in new_inventory_df.iterrows()]
        else:
            logging.info(f"### new_device_ids size: {len(new_device_ids)}")    
            
        # Step 6: Build records for existing devices to update in device history
        update_records = []
        if existing_device_ids:
            existing_inventory_df = inventory_df[inventory_df[inventory_dt_column].isin(existing_device_ids)]
            update_records = [build_record(row) for _, row in existing_inventory_df.iterrows()]
        else:
            logging.info(f"### existing_device_ids size: {len(existing_device_ids)}")    
        
        # Step 7: Insert new device history records and capture returned IDs
        inserted_count = 0
        inserted_ids = []
        if new_records:
            inserted_ids = tenant_database.insert_data_return_ids(new_records, history_table, "device_history_id")
            inserted_count = len(new_records)
            logging.info(f"Inserted {inserted_count} new device history records")
        else:
            logging.info(f"### device_history_sync No records found into Insert into : {history_table} table")    
        
        # Step 8: Update existing device history records and capture returned IDs
        updated_count = 0
        updated_ids = []
        if update_records:
            # remove created_by and created_date from update records to avoid updating those fields
            for record in update_records:
                record.pop("created_by", None)
                record.pop("created_date", None)
            updated_ids = tenant_database.bulk_update_return_ids(
                history_table,
                update_records, 
                search_column=history_dt_column,
                static_conditions={"service_provider_id": service_provider_id, "billing_period_id": billing_period_id},
                return_id_column="device_history_id"
            )
            if updated_ids:
                updated_count = len(update_records)
                logging.info(f"Updated {updated_count} existing device history records")
        else:
            logging.info(f"### device_history_sync No records found into Update into : {history_table} table")           
        
        # Step 9: Combine inserted and updated IDs for smi_device_history sync
        smi_update_ids = inserted_ids + updated_ids
        logging.info(f"### smi_update_ids size : {len(smi_update_ids)} and inserted_ids size : {len(inserted_ids)} and updated_ids size: {len(updated_ids)}")
        ids_to_update_in_smi = []
        ids_to_insert_in_smi = []
        # Step 10: Check which device history IDs already exist in smi_device_history
        if smi_update_ids:
            smi_device_history_df = tenant_database.get_data(
                "smi_device_history",
                {history_id_column: smi_update_ids},
                [history_id_column,"id"]
            )
            logging.info(f"### smi_device_history_df size :{len(smi_device_history_df)}")
            if not smi_device_history_df.empty:
                smi_device_history_ids = smi_device_history_df[history_id_column].tolist()
                ids_to_update_in_smi = [id for id in smi_update_ids if id in smi_device_history_ids]
                ids_to_insert_in_smi = [id for id in smi_update_ids if id not in smi_device_history_ids]
            else:
                ids_to_update_in_smi = []
                ids_to_insert_in_smi = smi_update_ids
        else:
            logging.info(f"### smi_update_ids size : {len(smi_update_ids)}")        

        # Step 11: Fetch updated device history records to get device_tenant_id mapping
        updated_device_history_df = tenant_database.get_data(
            history_table,
            {"device_history_id": smi_update_ids},
            [history_dt_column,"device_history_id"]
        )

        # updated_device_tenant_ids = updated_device_history_df[history_dt_column].tolist()
        # device_history_dict = (
        #     updated_device_history_df
        #     .set_index(history_dt_column)["device_history_id"]
        #     .to_dict()
        # )
        logging.info(f"#### updated_device_history_df size:{len(updated_device_history_df)} ")
        if not updated_device_history_df.empty:
            updated_device_tenant_ids = updated_device_history_df[history_dt_column].tolist()
            device_history_dict = updated_device_history_df.set_index(history_dt_column)["device_history_id"].to_dict()
        else:
            updated_device_tenant_ids = []
            device_history_dict = {}
    
        # Step 12: Fetch inventory records for devices that need smi_device_history sync
        inventory_df_for_smi = tenant_database.get_data(
            "sim_management_inventory",
            {inventory_dt_column: updated_device_tenant_ids, "is_active": True, "service_provider_id": service_provider_id}
        )
        logging.info(f"### inventory_df_for_smi size : {len(inventory_df_for_smi)}")
        
        # Step 13: Define helper function to build smi_device_history record
        def build_smi_record(row):
            """
                Build a record dictionary for inserting/updating `smi_device_history`.
                Args:
                    row (Series/dict): Inventory row containing device and usage details.
                Returns:
                    dict: Prepared SMI device history record.
            """
            device_tenant_id = row.get(inventory_dt_column)
            device_history_id = device_history_dict.get(device_tenant_id)
            record = {
                "changed_date": datetime.now(),
                "sim_management_inventory_id": row.get("id"),
                "service_provider_id": row.get("service_provider_id"),
                "service_provider_name": row.get("service_provider_display_name"),
                "iccid": row.get("iccid"),
                "imsi": row.get("imsi"),
                "msisdn": row.get("msisdn"),
                "imei": row.get("imei"),
                "device_status_id": row.get("device_status_id"),
                "status": row.get("sim_status"),
                "carrier_rate_plan_id": row.get("carrier_rate_plan_id"),
                "carrier_rate_plan_name": row.get("carrier_rate_plan_name"),
                "communication_plan": row.get("communication_plan"),
                "communication_plan_id": row.get("communication_plan_id"),
                "customer_id": row.get("customer_id"),
                "customer_name": row.get("customer_name"),
                "customer_rate_plan_id": row.get("customer_rate_plan_id"),
                "customer_rate_plan_name": row.get("customer_rate_plan_name"),
                "customer_rate_pool_id": row.get("customer_rate_pool_id"),
                "customer_rate_pool_name": row.get("customer_rate_pool_name"),
                "last_usage_date": row.get("last_usage_date"),
                "billing_cycle_end_date": row.get("billing_cycle_end_date"),
                "carrier_cycle_usage": row.get("carrier_cycle_usage_bytes"),
                "ctd_sms_usage": row.get("ctd_sms_usage"),
                "ctd_voice_usage": row.get("ctd_voice_usage"),
                "ctd_session_count": row.get("ctd_session_count"),
                "created_by": created_by,
                "created_date": datetime.now(),
                "modified_by": created_by,
                "modified_date": datetime.now(),
                "last_activated_date": row.get("last_activated_date"),
                "is_active": True,
                "is_deleted": False,
                "account_number": row.get("rev_customer_id"),
                "provider_date_added": row.get("date_added"),
                "provider_date_activated": row.get("date_activated"),
                "cost_center": row.get("cost_center"),
                "username": row.get("username"),
                "account_number_integration_authentication_id": row.get("account_number_integration_authentication_id"),
                "billing_period_id": billing_period_id,
                "tenant_id": row.get("tenant_id"),
                "customer_data_allocation_mb": row.get("customer_data_allocation_mb"),
                "device_id": row.get("device_id"),
                "device_tenant_id": row.get("dt_id"),
                "mobility_device_tenant_id": row.get("mdt_id"),
                "foundation_account_number": row.get("foundation_account_number"),
                "billing_account_number": row.get("billing_account_number"),
                "ip_address": row.get("ip_address"),                
            }
            if is_mobility:
                record["mhid"] = device_history_id
            else:
                record["dhid"] = device_history_id
            active_in_cycle = True if (row.get("sim_status").lower() in ["online","ONLINE","Online","active","activated","a"]) else False
            if active_in_cycle:
                record["active_in_cycle"] = True
            else:
                record["active_in_cycle"] = False
            return record
        
        # Step 14: Build records for smi_device_history update
        smi_update_records = []
        smi_insert_records = []
        if ids_to_update_in_smi or ids_to_insert_in_smi : 
            for _, row in inventory_df_for_smi.iterrows():
                history_id = device_history_dict.get(row.get(inventory_dt_column))

                if history_id in ids_to_update_in_smi:
                    smi_update_records.append(build_smi_record(row))

                elif history_id in ids_to_insert_in_smi:
                    smi_insert_records.append(build_smi_record(row))
        logging.info(f"### smi_update_records : {len(smi_update_records)} and smi_insert_records size :{len(smi_insert_records)} ")        
                

        # Step 16: Update existing smi_device_history records
        if smi_update_records:
            # remove created_by and created_date from update records to avoid updating those fields
            for record in smi_update_records:
                record.pop("created_by", None)
                record.pop("created_date", None)
            tenant_database.bulk_update_data(
                "smi_device_history",
                smi_update_records,
                search_column=history_dt_column,
                static_conditions={"service_provider_id": service_provider_id, "billing_period_id": billing_period_id}
            )
            logging.info(f"Updated {len(smi_update_records)} records in smi_device_history")
        else:
            logging.info(f"### No records found to update in smi_device_history smi_update_records : {len(smi_update_records)}")    

        # Step 17: Insert new smi_device_history records
        if smi_insert_records:
            tenant_database.insert_data(smi_insert_records, "smi_device_history")
            logging.info(f"Inserted {len(smi_insert_records)} records in smi_device_history")
        else:
            logging.info(f"### No records found to insert into smi_device_history table smi_insert_records size: {len(smi_insert_records)}")    
        
        # Step 18: Log success audit entry
        try:
            audit_data = {
                "service_name": "device_history_sync",
                "created_date": datetime.now(),
                "created_by": created_by,
                "status": "Success",
                "tenant_name": tenant_name,
                "comments": f"device history sync completed for {service_provider_id} on {usage_date}",
                "module_name": "Carrier Sync",
                "request_received_at": datetime.now(),
                "session_id": None
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Audit logging failed: {e}")

    except Exception as e:
        logging.error(f"Error in device_history_sync: {e}")
        
        # Step 19: Log error audit entry on failure
        try:
            error_data = {
                "service_name": "device_history_sync",
                "error_message": str(e),
                "error_type": str(type(e).__name__),
                "users": created_by,
                "session_id": None,
                "tenant_name": tenant_name,
                "comments": f"device history sync failed for {service_provider_id} on {usage_date}",
                "module_name": "Carrier Sync",
                "request_received_at": datetime.now()
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as audit_error:
            logging.error(f"Error audit logging failed: {audit_error}")