"""
@Author1 : Phaneendra.Y
@Author2 :
@Author3 : 
Created Date: 11-06-24
"""
# Importing the necessary Libraries
from decimal import Decimal
import json
import logging
import os
import ast
import requests
import os
import pandas as pd
from common_utils.db_utils import DB
import psycopg2
from pandas import Timestamp
from datetime import datetime, timezone
from dotenv import load_dotenv
from dateutil.relativedelta import relativedelta
from concurrent.futures import ThreadPoolExecutor, as_completed
import concurrent.futures
import time
from io import BytesIO
from sqlalchemy import create_engine, text
import base64
import re
import pytds
import uuid
import threading
from pytz import timezone as pytz_timezone
import numpy as np
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment, PatternFill
from io import BytesIO
import base64
import json
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed
import uuid
import time, random

# Database configuration
db_config = {
     "host": os.environ["HOST"],
     "port": os.environ["PORT"],
     "user": os.environ["USER"],
     "password": os.environ["PASSWORD"],

 }

'''
Change types Developed for pondiot are:
1. Archive Devices
2. Change Customer Rate Plan    
3. Change Carrier Rate Plan
4. Update Device Status
5. Assign Customer
6. Edit Username and Cost Center
'''



##function caller where the functions begins
def funtion_caller(data,path):
    """
    Main function caller that handles database configuration setup and routes requests.
    
    This function:
    1. Sets up initial database configuration
    2. Determines user type (regular user or service account)
    3. Builds appropriate database filters based on user permissions
    4. Routes the request to the appropriate endpoint handler
    
    Args:
        data (dict): Request data containing user/tenant information
        path (str): API endpoint path being called
        access_token (str): Optional access token for service accounts
        
    Returns:
        Result of the called endpoint function or error response
    """
    # Route to appropriate endpoint handler
    
    if path == "/pondiot_bc_change_customer_rate_plan":
        result = pondiot_bc_change_customer_rate_plan(data)
    elif path == "/pondiot_bc_change_carrier_rate_plan":
        result = pondiot_bc_change_carrier_rate_plan(data)
    elif path== "/pondiot_bc_update_device_status":
        result = pondiot_bc_update_device_status(data)
    elif path== "/pondiot_bc_assign_customer":
        result = pondiot_bc_assign_customer(data)
    elif path== "/pondiot_bc_line_sync":
        result = pondiot_bc_line_sync(data)
    ##else condition to handle the invalid path method
    else:
        result = {"flag":False,"error": "Invalid path or method"}
        logging.info(f"### Invalid path or method requested: {path}")
    return result


## Function to get Carrier API details
def get_carrier_api_details(service_provider,change_type,common_utils_database):
    '''
    Function to get the Carrier API URL for a given service provider and change event type.
    Args:
        service_provider (str): The service provider name.
        change_type (str): The type of change event.
        common_utils_database (DB): Database connection object for common utils database.
    Returns:
        str: The Carreir API URL,app_id,app_secret if found, otherwise None.'''
    # Initialize variables
    carrier_api_url=None
    app_id=None
    app_secret=None
    carrier_limit=None
    alternative_api_url=None
    ##carrier api query and their limits query
    carrier_details= common_utils_database.get_data(
    "bulk_change_carrier_limits", {"service_provider": service_provider,
                                 'change_event_type':change_type},
    ["carrier_api_url","app_id","app_secret","carrier_limit","alternative_api_url"]
    )
    logging.info(f"### carrier_details: {carrier_details}")
    if not carrier_details.empty:
        ##fetching the carrier API limits
        carrier_api_url=carrier_details.iloc[0]['carrier_api_url']
        app_id=carrier_details.iloc[0]['app_id']
        app_secret=carrier_details.iloc[0]['app_secret']
        carrier_limit=carrier_details.iloc[0]['carrier_limit']
        alternative_api_url=carrier_details.iloc[0].get('alternative_api_url', None)
        return carrier_api_url,carrier_limit,app_id,app_secret,alternative_api_url
    else:
        return carrier_api_url,carrier_limit,app_id,app_secret,alternative_api_url


## Change customer rate plan function
def pondiot_bc_change_customer_rate_plan(data):
    """
    Change the customer rate plan for the given devices as part of a bulk change operation.
   
    this function is typically triggered during a bulk change operation where a list of SIM cards needs to have their customer rate plans updated.
    Args:
        data (dict): Request data containing:
            - iccids (list of str): List of ICCIDs used to identify devices.
            -changed_data (dict): Dictionary containing the rate plan changes.
            - tenant_name (str): Name of the tenant performing the change.
            - bulk_change_id (str): Unique identifier for the bulk change request.
            - created_by (str): Username of the person initiating the request.
    Returns:
        bool: True if the operation completes successfully (actual logic to be implemented).
        dict: Result of the operation with flags, messages, and details.
        
    """
    logging.info(f"### Received data for changing customer rate plan: %s", data)
    # Start timing the function execution
    start_time = time.time()
    # Extract all required fields from input data
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id", "")
    created_by = data.get("created_by", "")
    tenant_name = data.get("tenant_name", "")
    tenant_id= data.get("tenant_id", "")
    source=data.get("source","")
    service_provider = data.get("service_provider", "")
    service_provider_id = data.get("service_provider_id", "")
    username = data.get("username", "")
    changed_data = data.get("changed_data", {})
    invalid_iccids = data.get("invalid_iccids", [])
    # Validate required fields
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    role_name=data.get("role_name", "")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"###pondiot_bc_change_customer_rate_plan and {tenant_name} time is {now}")
    try:
        # Connect to main and audit databases
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.error(f"### DB connection error: %s", e)
        return {"flag": False, "message": "DB connection failed", "details": str(e)}
    try:
        # Audit - Start
        bulk_change_audit_action(
            data, common_utils_database,
            action="Bulk Change Process Initiated"
        )
        live_progress_percentage_tracker(database, bulk_change_id,20)
        
        # Fetch bulk change request entries for valid ICCIDs
        bulk_change_requests = database.get_data(
            'sim_management_bulk_change_request',
            {"bulk_change_id": bulk_change_id},
            ['id', 'iccid','change_request']
        )
        if not bulk_change_requests.empty:
            change_request_json = bulk_change_requests.iloc[0]["change_request"]
            if not change_request_json:
                message="Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "pondiot_bc_change_customer_rate_plan",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                    live_progress_percentage_tracker(database, bulk_change_id,100)
                except Exception as e:
                    logging.warning(f"### pondiot_bc_change_customer_rate_plan and tenant name : {tenant_name} Audit logging failed: {e}")
                return response
            
        live_progress_percentage_tracker(database, bulk_change_id,25)
        # Map iccids to request IDs
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
        customer_rate_plan_update=change_request_json.get("CustomerRatePlanUpdate","")
        customer_rate_plan_id=customer_rate_plan_update.get("CustomerRatePlanId","")
        customer_rate_pool_id=customer_rate_plan_update.get("CustomerPoolId","")
        effective_date=customer_rate_plan_update.get("EffectiveDate","")
        rate_plan_db_name=None
        rate_pool_db_name=None
        plan_mb=None

        # Validate input data
        if customer_rate_plan_id:
            rate_plan_data = database.get_data(
                "customerrateplan",
                {"id": customer_rate_plan_id, "is_active": True},
                ["rate_plan_name","plan_mb"]   
            )
            if not rate_plan_data.empty:
                rate_plan_db_name = rate_plan_data["rate_plan_name"].to_list()[0]
                plan_mb = rate_plan_data["plan_mb"].to_list()[0]

        if customer_rate_pool_id and str(customer_rate_pool_id)!="-1":
            rate_pool_data = database.get_data(
                "customer_rate_pool",
                {"id": customer_rate_pool_id, "is_active": True},
                ["name"]
            )
            if not rate_pool_data.empty:
                rate_pool_db_name = rate_pool_data["name"].to_list()[0]
        
        update_fields={}
        if source == "Inventory":
            old_inventory_data = database.get_data(
                "sim_management_inventory",
                {"is_active": True, "iccid": iccids,"tenant_id": tenant_id},
                ["id","iccid","msisdn","customer_rate_plan_name"]
            ).to_dict(orient="records")
        # Extract valid ICCIDs
        # Prepare an update dict dynamically
        if customer_rate_plan_id is None:
            update_fields["customer_rate_plan_id"] = None
            update_fields["customer_rate_plan_name"] = None
        elif str(customer_rate_plan_id).strip() != "-1":
            update_fields["customer_rate_plan_id"] = customer_rate_plan_id
            update_fields["customer_rate_plan_name"] = rate_plan_db_name
        if not customer_rate_pool_id:
            update_fields["customer_rate_pool_id"] = None
            update_fields["customer_rate_pool_name"] = None
        elif str(customer_rate_pool_id) != "-1":
            update_fields["customer_rate_pool_id"] = customer_rate_pool_id	
            update_fields["customer_rate_pool_name"] = rate_pool_db_name

        if effective_date:
            update_fields["effective_date"] = effective_date
        if plan_mb is not None:
            update_fields["customer_data_allocation_mb"] = plan_mb
        else:
            update_fields["customer_data_allocation_mb"] = None
 
        # Map ICCID to request ID for logging
        iccid_to_request_id = dict(zip(bulk_change_requests["iccid"], bulk_change_requests["id"]))
        log_entries = []
        invalid_log_entries=[]
        inventory_update = False # defulat 
        live_progress_percentage_tracker(database, bulk_change_id,40)
        
        # Update the SIM management inventory with the new rate plan
        if iccids:
            logging.info(f"### pondiot_bc_change_customer_rate_plan and tenant name : {tenant_name} Updating SIM management inventory with updated fields: {update_fields}")
            inventory_update =  database.update_dict(
            "sim_management_inventory",update_fields,
            and_conditions={"tenant_id":tenant_id,"is_active": True, "service_provider_id": service_provider_id},
            in_conditions={"iccid": iccids},
            
            )
            
            logging.info(f"### pondiot_bc_change_customer_rate_plan and {tenant_name} Inventory update status: {inventory_update}")
            if inventory_update:  # success case
                logging.info(f"### pondiot_bc_change_customer_rate_plan and {tenant_name} customer rate plan updated for {len(iccids)} devices in inventory")
            else:    # failure case 
                logging.info(f"### pondiot_bc_change_customer_rate_planive_devices and {tenant_name} Error updating inventory for ICCIDs: {iccids}")
                for iccid in iccids:
                    request_id = iccid_to_request_id.get(iccid)
                    if request_id:
                        log_entries.append({
                        "bulk_change_id": bulk_change_id,
                        "bulk_change_request_id": request_id,
                        "log_entry_description": f"Change Customer Rate Plan for iccid : {iccid} failed",
                        "request_text": "Update AMOP",
                        "has_errors": not inventory_update,
                        "response_status": "ERROR",
                        "response_text":  "Customer Rate plan is not updated",
                        "error_text": "Rate plan not found or inactive",
                        "processed_date": now,
                        "processed_by": created_by,
                        "created_by": created_by,
                        "created_date": now,
                        "is_deleted": False,
                        "is_active": True
                    })
                if log_entries:
                    database.insert_data(log_entries,"sim_management_bulk_change_log")
            
                database.update_dict(
                    "sim_management_bulk_change_request",
                    {"status": "ERROR","errors": len(iccids),"is_processed": True,"has_errors": True,"processed_date": now,"status_details":"Customer Rate plan is not updated"},
                    and_conditions={"bulk_change_id": bulk_change_id},in_conditions={"iccid": iccids},)
            
            # Also update main bulk change record
                database.update_dict(
                    "sim_management_bulk_change",
                    {"status": "ERROR","errors": len(iccids),"processed_date": now},and_conditions={"bulk_change_id": bulk_change_id},
                )
                return {"flag": False,"message": "Inventory update failed","bulk_change_id": bulk_change_id}
                
            
        # Log valid ICCIDs
        for iccid in iccids:
            request_id = iccid_to_request_id.get(iccid)
            log_entries.append({
                "bulk_change_id": bulk_change_id,
                "bulk_change_request_id": request_id,
                "log_entry_description": f"Change Customer Rate Plan for iccid : {iccid} successful",
                "request_text": "Update AMOP",
                "has_errors": False,
                "response_status": "PROCESSED",
                "response_text": "Updated Customer Rate Plan Succesfully",
                "error_text": "",
                "processed_date": now,
                "processed_by": created_by,
                "created_by": created_by,
                "created_date": now,
                "is_deleted": False,
                "is_active": True
            })
        #update       
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "PROCESSED","sucess":len(iccids),"is_processed":True,"has_errors":False,
                    "processed_date": now , "status_details":"OK" },
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": iccids},
        )
        # Prepare payload for history table update
        if iccids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids": iccids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            if effective_date:
                payload_history_table["data"]["effective_date"] = effective_date
            #api call to update the history table
            try:
                logging.info(f"### pondiot_bc_change_customer_rate_plan and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### pondiot_bc_change_customer_rate_plan and {tenant_name} Exception in thread: {e}")

        if source == "Inventory":
                action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
                action_history_payload = {
                    "data": {
                        "tenant_name": tenant_name,
                        "tenant_id": tenant_id,
                        "username": username,
                        "path": "/sim_management_action_history_update",
                        "iccids": iccids,
                        "msisdns": [],
                        "service_provider": service_provider,
                        "Partner": tenant_name,
                        "access_token": access_token,
                        "db_name": tenant_database,
                        "change_type": "Change Customer Rate Plan",
                        "old_inventory_data": old_inventory_data,
                        "bulk_change_id": bulk_change_id,
                        "changed_field": "customer_rate_plan_name",
                    }
                }
                
                # API call to update action history
                try:
                    logging.info(f"### pondiot_bc_change_customer_rate_plan and {tenant_name} sync call has started for action history")
                    threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
                except Exception as e:
                    logging.exception(f"### pondiot_bc_change_customer_rate_plan and {tenant_name} Exception in action history thread: {e}")
            
        live_progress_percentage_tracker(database, bulk_change_id,70)    
            
        if invalid_iccids:
            logging.info(f"### pondiot_bc_change_customer_rate_plan and {tenant_name} Invalid ICCIDs found: {invalid_iccids}")
            # Log invalid ICCIDs
            for iccid in invalid_iccids:
                request_id = iccid_to_request_id.get(iccid)
                invalid_log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": f"Change Customer Rate Plan Failed",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid ICCID - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR","errors":len(invalid_iccids),"is_processed":True,"has_errors":True,
                    "processed_date": now , "status_details":"Invalid ICCID - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": invalid_iccids},
        )
        if invalid_log_entries : 
            database.insert_data(invalid_log_entries,"sim_management_bulk_change_log")
            
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
        logging.info(f"### pondiot_bc_change_customer_rate_plan and {tenant_name} inserted {len(log_entries)} log entries for bulk change request")
        # Update bulk change status to PROCESSED
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",
                "success": len(iccids),
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        live_progress_percentage_tracker(database, bulk_change_id,80)
        # Call sync API in separate thread after delay
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #sync api call to update the 1.0 inventory tables
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "pondiot_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        bulk_change_audit_action(
            data, common_utils_database,
            action="Sync To 1.0 Tables"
        )
        try:
            if iccids:
                logging.info(f"### pondiot_bc_change_customer_rate_plan and {tenant_name} sync call for billing  has started")
                billing_platform_bulk_change_20_sync(data)
        except Exception as e:
            logging.exception(f"### pondiot_bc_change_customer_rate_plan and {tenant_name} Exception in thread: {e}")
        live_progress_percentage_tracker(database, bulk_change_id,85)
        try:
            logging.info(f"### pondiot_bc_change_customer_rate_plan and {tenant_name} sync call has started")
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### pondiot_bc_change_customer_rate_plan and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### pondiot_bc_change_customer_rate_plan: Exception while scheduling sync call for tenant '{tenant_name}': {e}")

        # Return success
        logging.info(f"### pondiot_bc_change_customer_rate_plan and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### pondiot_bc_change_customer_rate_plan and {tenant_name} Total time taken for processing:{time.time() - start_time} seconds" )
        # Prepare success response
        response = {
            "flag": True,
            "message": "Bulk change request processed successfully.",
            "msisdns": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        # audit the auditing log
        
        live_progress_percentage_tracker(database, bulk_change_id,95)
        # Attempt to audit the action
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "pondiot_bc_change_customer_rate_plan",
                "created_by": username,
                "time_consumed_secs": time_consumed,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for changing customer rate plan for devices : {bulk_change_id}",
                "request_received_at":now,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(data, common_utils_database, action=f"Auditing")
        except Exception as e:
            logging.exception(f"### pondiot_bc_change_customer_rate_plan and {tenant_name} Audit logging failed: {e}")
        # audit the auditing log
        bulk_change_audit_action(data, common_utils_database, action=f"Bulk Change Process Completed")
        live_progress_percentage_tracker(database, bulk_change_id,100)
        logging.info(f"### pondiot_bc_change_customer_rate_plan and {tenant_name} Total time taken for processing:{time.time() - start_time} seconds" )
        return response
 
    except Exception as e:
        # Main exception block
        logging.exception(f"### pondiot_bc_change_customer_rate_plan and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = "Error during bulk change processing"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(iccids),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "pondiot_bc_change_customer_rate_plan",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": now,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### pondiot_bc_change_customer_rate_plan and {tenant_name} Exception in logging error data to DB: {e}")
 
        return response
 



##Update Device Status function
def pondiot_bc_update_device_status(data):
    """
   Update the device status using the pondIOT API.

    This function processes a list of iccids and updates their device status in the pondIOT system.
    It performs the following steps:
        - Retrieves API credentials and configuration limits based on the service provider and change type.
        - Fetches bulk change requests and maps iccids to their respective request payloads.
        - Iteratively calls the pondIOT API for each iccid with retry logic.
        - Updates status in the request and inventory tables based on API responses.
        - Logs both success and failure results into the bulk change log table.
        - Handles any invalid iccids or request IDs by logging them appropriately.
        - Marks the bulk change as processed.
        - Records an audit entry and error logs in case of exceptions.

    Args:
        data (dict): Input dictionary containing the following keys:
            - iccids (list): List of iccids to be updated.
            - bulk_change_id (str): Identifier for the bulk change operation.
            - changed_data (dict): Contains the payload structure to send to the pondIOT API.
            - created_by (str): Username of the user initiating the request.
            - service_provider (str): Name of the carrier or service provider.
            - change_type (str): Type of update being performed (e.g., SIM status or device status).
            - tenant_id (str): ID of the tenant initiating the request.
            - tenant_name (str): Name of the tenant for logging/auditing purposes.
            - db_name (str): Database name associated with the tenant.
            - username (str): Username to use in audit logs.
            - invalid_iccids (list): iccids that failed validation before processing.
            - request_received_at (str): Timestamp when the request was received (optional).

    Returns:
        dict: A response object indicating the result of the operation, containing:
            - flag (bool): True if processing completed without unhandled exceptions.
            - message (str): Summary message indicating the result.
            - processed (int): Number of iccids processed.
            - iccids (list): List of iccids attempted.
            - invalid_iccids (list): List of iccids skipped due to invalid state.
            - bulk_change_id (str): ID of the bulk change request.
            - error (str, optional): Error message in case of failure.
    """
    logging.info(f"### Received data for updating device status: {data}")
    start_time = time.time()
    # Extract required fields
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    username = data.get("username", "")
    source=data.get("source","")
    invalid_iccids = data.get("invalid_iccids", [])
    service_provider_id = data.get("service_provider_id", "")


    # current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### pondiot_bc_update_device_status and {tenant_name} time is : {now}")

    # Validate bulk_change_id
    if not bulk_change_id:
        logging.error(f"### pondiot_bc_update_device_status and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    role_name=data.get("role_name", "")
    # DB Connections
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.error(f"### pondiot_bc_update_device_status and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": "DB connection failed"}

    # Initial audit log
    bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Initiated")
    live_progress_percentage_tracker(database, bulk_change_id,10)
    
    try:
        # Get carrier API credentials and configuration
        carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(service_provider, change_type, common_utils_database)
        if isinstance(carrier_limits, str):
            carrier_limits = json.loads(carrier_limits)
        if not carrier_api_url:
            logging.error(f"### pondiot_bc_update_device_status and {tenant_name} Missing carrier_api_url")
            return {"flag": False, "message": "Missing carrier_api_url"}

        logging.info(f"### pondiot_bc_update_device_status and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        # Fetch bulk change requests from DB
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "iccid", "change_request"]
        )
        remaining = list(iccids)
        successful_iccids = []
        if not bulk_requests_df.empty:
            change_request_json=bulk_requests_df.iloc[0]["change_request"]
            if not change_request_json:
                message="Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "pondiot_bc_update_device_status",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                    live_progress_percentage_tracker(database, bulk_change_id,100)
                except Exception as e:
                    logging.warning(f"### pondiot_bc_update_device_status and {tenant_name} Audit logging failed: {e}")
                return response
        live_progress_percentage_tracker(database, bulk_change_id,25)    
        if isinstance(change_request_json, str):
            change_request_json = json.loads(change_request_json)
        update_status=change_request_json.get("UpdateStatus","")
        logging.info(f"### pondiot_bc_update_device_status and {tenant_name} Update status: {update_status}")
        device_status_id = change_request_json.get("PostUpdateStatusId","") 
           
        # Add this near the top with other initializations
        device_status_data = pd.DataFrame()

        # Then modify the device status lookup section to:
        if device_status_id:
            device_status_data = database.get_data(
                "device_status",
                {"id": device_status_id, "is_active": True},
                ["id", "display_name"]
            )
        logging.info(f"### device_status_data = {device_status_data}")  
    
        # And modify the check to:
        if not device_status_data.empty:
            device_status = device_status_data["display_name"].iloc[0]
            device_status_id = int(device_status_data["id"].iloc[0])
        else:
            # Handle case where device status wasn't found
            device_status = None
            device_status_id = None

        if source == "Inventory":
            old_inventory_data = database.get_data(
                "sim_management_inventory",
                {"is_active": True, "iccid": iccids,"tenant_id": tenant_id},
                ["id","iccid","msisdn","sim_status"]
            ).to_dict(orient="records")
        
        iccid_to_request_id = dict(zip(bulk_requests_df.iccid, bulk_requests_df.id))
        BATCH_SIZE = carrier_limits.get("batch_size")
        PARALLEL_REQUESTS = carrier_limits.get("parallel_requests")
        if PARALLEL_REQUESTS>10:
           logging.info(f"###pondiot_bc_update_device_status and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
        PARALLEL_REQUESTS=10
        INTERVAL = carrier_limits.get("interval_minutes", 0) * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        logs = []
        logging.info(f"### pondiot_bc_update_device_status and {tenant_name} Fetching access token and session ID")
        
        #constracting header 
        headers = {
            "Authorization": app_id,
            "ApiKey": app_secret,
            "Accept": "application/json",
        }
        url=None
        # device_status = "Active"

        device_status_mapping = {
            "Active": "ENABLED",
            "Suspended": "DISABLED",
            "Terminated": "DISABLED"
        }

        # Get mapped value
        mapped_status = device_status_mapping.get(device_status)

        # Build payload with mapped value
        payload = {
            "simDataServiceStatus": mapped_status,
            "simVoiceServiceStatus": mapped_status,
            "simSmsServiceStatus": mapped_status
        }
  
        # Execute API calls in parallel using ThreadPoolExecutor

        bulk_change_audit_action(data, common_utils_database, action="Processing With Carrier APIs") 
        live_progress_percentage_tracker(database, bulk_change_id,40)
        
        # Execute API calls in parallel using ThreadPoolExecutor
        with ThreadPoolExecutor(max_workers=PARALLEL_REQUESTS) as executor:
            for i in range(0, len(iccids), BATCH_SIZE):
                batch = iccids[i:i + BATCH_SIZE]
                futures = {}

                for iccid in batch:
                    url = f"{carrier_api_url}/sim/{iccid}/status"  
                    # payload = {"mode": mode, "reasonCode": reason_code}

                    def task(iccid=iccid, url=url, payload=payload):
                        success = False
                        result = ""
                        status = "API_FAILED"
                        # Retry logic
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### pondiot_bc_update_device_status and {tenant_name} Attempting {attempt} for iccid: {iccid} with URL: {url}")
                                resp = requests.post(url, json=payload, 
                                headers=headers , timeout=60)
                                logging.info(f"### pondiot_bc_update_device_status and {tenant_name} Response Code: {resp.status_code} for iccid: {iccid}")
                                success = 200 <= resp.status_code < 300
                                # result = resp.text
                                # result = "Request successful for device status update" if 200 <= resp.status_code < 300 else "Request failed for device status update"
                                # result = f"{resp}" if 200 <= resp.status_code < 300 else f"{resp.text}"
                                result = resp.text.strip() if resp.text and resp.text.strip() else "OK"
                                status = "PROCESSED" if success else "API_FAILED"
                                if success: 
                                    successful_iccids.append(iccid)
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### pondiot_bc_update_device_status and {tenant_name} Attempt {attempt} failed for iccid: {iccid}: {result}")
                                time.sleep(RETRY_DELAY)

                        # Update request status in DB
                        
                        update_data = {
                                "status": status,
                                "has_errors": not success,
                                "is_processed": True,
                                "processed_date": now,
                                "status_details": result
                            }
                            
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            update_data,
                            and_conditions={"iccid": iccid, "bulk_change_id": bulk_change_id}
                        )
                        
                        log = {
                                "bulk_change_id": bulk_change_id,
                                "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                "log_entry_description": f"update device status Carrier API Request for iccid :{iccid} ",
                                "request_text": json.dumps(payload),
                                "has_errors": not success,
                                "response_status": status,
                                "response_text": result,
                                "error_text": "" if success else result,
                                "processed_date": now,
                                "processed_by": created_by,
                                "created_by": created_by,
                                "created_date": now,
                                "is_deleted": False,
                                "is_active": True
                            }
                        database.insert_data(log, "sim_management_bulk_change_log")
                        update_inventory_flag = False # default to False

                        # Update inventory if successful
                        if success:
                            device_status_id_int = int(device_status_id) if isinstance(device_status_id, np.int64) else device_status_id
                            update_inventory_flag = database.update_dict(
                                "sim_management_inventory",
                                {"sim_status": device_status, "device_status_id": device_status_id_int},
                                and_conditions={"tenant_id": tenant_id, "is_active": True , "service_provider_id": service_provider_id},
                                in_conditions={"iccid": [iccid]}
                            )
                            
                            inventory_log = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                    "log_entry_description": "Inventory update for iccid",
                                    "request_text": json.dumps({"iccid": iccid, "device_status": device_status}),
                                    "has_errors": not bool(update_inventory_flag),   # True if update failed
                                    "response_status": "PROCESSED" if update_inventory_flag else "INVENTORY_UPDATE_FAILED",
                                    "response_text": f"Inventory updated with status : {device_status}" if update_inventory_flag else "Inventory update failed",
                                    "error_text": "" if update_inventory_flag else "DB update returned False",
                                    "processed_date": now,
                                    "processed_by": created_by,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "is_deleted": False,
                                    "is_active": True
                                }
                            database.insert_data(inventory_log, "sim_management_bulk_change_log")    

                        return iccid

                    futures[executor.submit(task)] = iccid

                for fut in as_completed(futures):
                    try:
                        iccid = fut.result()
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.exception(f"### pondiot_bc_update_device_status and {tenant_name} Error processing iccid: {e}")

        if INTERVAL and i + BATCH_SIZE < len(iccids):
            time.sleep(INTERVAL)
        
        
        live_progress_percentage_tracker(database, bulk_change_id,70)
        # Handle and log invalid iccid
        if invalid_iccids:
            for iccid in invalid_iccids:
                request_id = iccid_to_request_id.get(iccid)
                logs.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": "Update pondiot Subscriber: Invalid iccid",
                    "request_text": "N/A",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid ICCID - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })

        if logs:
            database.insert_data(logs,"sim_management_bulk_change_log")
            
        # Prepare payload for history table update
        if successful_iccids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids": successful_iccids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            #api call to update the history table
            try:
                logging.info(f"### pondiot_bc_update_device_status and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### pondiot_bc_update_device_status and {tenant_name} Exception in thread: {e}")

        if source == "Inventory":
                action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
                action_history_payload = {
                    "data": {
                        "tenant_name": tenant_name,
                        "tenant_id": tenant_id,
                        "username": username,
                        "path": "/sim_management_action_history_update",
                        "iccids": successful_iccids,
                        "msisdns": [],
                        "service_provider": service_provider,
                        "Partner": tenant_name,
                        "access_token": access_token,
                        "db_name": tenant_database,
                        "change_type": "Update Device Status",
                        "old_inventory_data": old_inventory_data,
                        "bulk_change_id": bulk_change_id,
                        "changed_field": "sim_status"
                    }
                }
                
                # API call to update action history
                try:
                    logging.info(f"### PondIOT_bc_update_device_status and {tenant_name} sync call has started for action history")
                    threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
                except Exception as e:
                    logging.exception(f"### PondIOT_bc_update_device_status and {tenant_name} Exception in action history thread: {e}")
                

        # Mark invalid request IDs as processed
        if invalid_iccids:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR", "errors":len(invalid_iccids),"is_processed": True, "has_errors": True,
                    "processed_date": now ,"status_details": "Invalid ICCID - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"iccid": invalid_iccids}
            )

        # Update bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {"status": "PROCESSED", "processed_date": now},
            {'id': bulk_change_id}
        )
        live_progress_percentage_tracker(database, bulk_change_id,80)
        # Call sync API in separate thread after delay
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #sync api call to update the 1.0 inventory tables
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "pondiot_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        bulk_change_audit_action(
            data, common_utils_database,
            action="Sync To 1.0 Tables"
        )
        live_progress_percentage_tracker(database, bulk_change_id,85)
        try:
            logging.info(f"### pondiot_bc_update_device_status and {tenant_name} sync call has started")
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### pondiot_bc_update_device_status and {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### pondiot_bc_update_device_status: Exception while scheduling sync call for tenant '{tenant_name}': {e}")

        try:
            if successful_iccids:
                data["iccids"]=successful_iccids
                logging.info(f"### pondiot_bc_update_device_status and {tenant_name} sync call for billing  has started")
                billing_platform_bulk_change_20_sync(data)
        except Exception as e:
            logging.exception(f"### pondiot_bc_update_device_status and {tenant_name} Exception in thread: {e}")

        # Return success
        logging.info(f"### pondiot_bc_update_device_status and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### pondiot_bc_update_device_status and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        # Prepare response
        response={
            "flag": True,
            "processed": len(iccids) - len(remaining),
            "remaining": len(remaining),
            "message": "Bulk change request processed successfully.",
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        # audit the final bulk change log
        
        live_progress_percentage_tracker(database, bulk_change_id,95)
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "pondiot_bc_update_device_status",
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for updating device status for devices : {bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            bulk_change_audit_action(
                data, common_utils_database,
                action="Auditing"
            )
        except Exception as e:
            logging.exception(f"### pondiot_bc_update_device_status and {tenant_name} Audit logging failed: {e}")
        ##final auditing the success log
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        # Prepare success response
        logging.info(f"### pondiot_bc_update_device_status and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        return response

    except Exception as e:
        # Global exception handling and logging
        logging.exception(f"### pondiot_bc_update_device_status and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = "Bulk change request processing failed."
        error_type = type(e).__name__
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        ## Prepare error response
        try:
            error_data = {
                "service_name": "pondiot_bc_update_device_status",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during bulk change for: {iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or now
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.error(f"### pondiot_bc_update_device_status and {tenant_name} Exception in logging error data to DB: {e}")
        response={
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        return response


## Change Carrier Rate Plan function
def pondiot_bc_change_carrier_rate_plan(data):
    """
    Change the carrier rate plan for the given devices/iccids.This function processes a list of iccids and updates their carrier rate plan in the pondiot system.
    It handles bulk requests, updates the database, and logs the results.   
    Args:
        data (dict): Input data containing the following keys:
            - iccids (list): List of ICCIDS to process.
            - bulk_change_id (str): ID of the bulk change request.
            - changed_data (dict): Data to be sent to the pondiot API.
            - created_by (str): User who initiated the request.
            - service_provider (str): Service provider name.
            - change_type (str): Type of change being made.
            
    Returns:
        dict: Result of the operation with flags, messages, and logs.
    """
    logging.info(f"### Recevied data for change carrier rate plan :{data}")
    start_time = time.time()
    # Required inputs
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    changed_data = data.get("changed_data")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    source=data.get("source","")
    invalid_iccids = data.get("invalid_iccids", [])
    username= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    role_name= data.get("role_name", "")
    access_token=data.get("access_token", "")
    service_provider_id = data.get("service_provider_id", "")
    # Initialize for log entries
    log_entries = []
    success_iccids = []
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### pondiot_bc_change_carrier_rate_plan and {tenant_name} time is {now}")
    # Basic validation
    if not bulk_change_id:
        logging.error(f"### pondiot_bc_change_carrier_rate_plan and tenant : {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    # connect to the database
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.error(f"### pondiot_bc_change_carrier_rate_plan and tenant: {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": "DB connection failed"}
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id,10)
    except Exception as e:
        logging.error(f"### pondiot_bc_change_carrier_rate_plan and tenant : {tenant_name} Audit logging failed: {e}")
    try:
        # Carrier API details
        try:
            ## Fetch carrier API details
            logging.info(f"### pondiot_bc_change_carrier_rate_plan and tenant : {tenant_name} Fetching carrier API details for service provider: {service_provider}, change type: {change_type}")
            carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(
                service_provider, change_type, common_utils_database
            )
        except Exception as e:
            logging.error(f"### pondiot_bc_change_carrier_rate_plan and tenant : {tenant_name} Carrier API lookup failed: {e}")
            return {"flag": False, "message": "Carrier API lookup failed"}
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}
        logging.info(f"### pondiot_bc_change_carrier_rate_plan and tenant : {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        # Fetch bulk change rows
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "iccid", "change_request"]
        )
        if not bulk_requests_df.empty:
            change_request_json = bulk_requests_df.iloc[0]["change_request"]
            if not change_request_json:
                message="Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "pondiot_bc_change_carrier_rate_plan",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                    live_progress_percentage_tracker(database, bulk_change_id,100)
                except Exception as e:
                    logging.warning(f"### pondiot_bc_change_carrier_rate_plan and tenant : {tenant_name} Audit logging failed: {e}")
                return response
        
        live_progress_percentage_tracker(database, bulk_change_id,25)        
        # Map iccids to request IDs
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
        carrier_rate_plan_update=change_request_json.get("CarrierRatePlanUpdate","")
        carrie_rate_plan=carrier_rate_plan_update.get("CarrierRatePlan","") 
        effective_date=carrier_rate_plan_update.get("EffectiveDate","")
        communication_plan = carrier_rate_plan_update.get("CommPlan","")


        iccid_to_request_id = dict(zip(bulk_requests_df.iccid, bulk_requests_df.id))
        ## Prepare headers for API call
        rate_plan_id=None
        rate_plan_code=None
        # Validate input data for rateplan and optimization
        logging.info(f"### pondiot_bc_change_carrier_rate_plan and tenant : {tenant_name} Validating input data for rate plan and optimization group")

        if carrie_rate_plan:
           rate_plan_data = database.get_data(
            "carrier_rate_plan",
            {"rate_plan_code": carrie_rate_plan, "is_active": True},
            ["id","jasper_rate_plan_id"]
            )
 
        if not rate_plan_data.empty:
            jasper_rate_plan_id = rate_plan_data["jasper_rate_plan_id"].to_list()[0]
            rate_plan_id = rate_plan_data["id"].to_list()[0]
            # rate_plan_code=rate_plan_data["rate_plan_code"].to_list()[0]
        logging.info(f"### pondiot_bc_change_carrier_rate_plan and tenant : {tenant_name} Rate plan ID: {rate_plan_id} ")
        # Prepare an update dict 
        if carrie_rate_plan:
           update_fields = {"carrier_rate_plan_id": rate_plan_id,"carrier_rate_plan_name": carrie_rate_plan}       
        if effective_date:
           update_fields["effective_date"] = effective_date
        if communication_plan:
           update_fields["communication_plan"] = communication_plan
        # Validate iccids
        remaining = iccids.copy()
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.error(f"### pondiot_bc_change_carrier_rate_plan and tenant : {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": "Invalid carrier_limits JSON"}
            
        if source == "Inventory":
            old_inventory_data = database.get_data(
                "sim_management_inventory",
                {"is_active": True, "iccid": iccids,"tenant_id": tenant_id},
                ["id","iccid","msisdn","carrier_rate_plan_name"]
            ).to_dict(orient="records")
        ##carrier limits 
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        if parallel_requests>10:
            logging.info(f"###pondiot_bc_change_carrier_rate_plan and tenant : {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            parallel_requests=10
        interval = carrier_limits["interval_minutes"] * 60
        logging.info(f"### pondiot_bc_change_carrier_rate_plan and tenant : {tenant_name} Batch size: {batch_size}, Parallel requests: {parallel_requests}, Interval: {interval} seconds")
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))

        # Get access token and session ID
        logging.info(f"### pondiot_bc_change_carrier_rate_plan and tenant : {tenant_name} Fetching access token and session ID")        
        
        headers = {
            "Authorization": app_id,
            "ApiKey": app_secret,
            "Accept": "application/json",
        }
        
        bulk_change_audit_action(data, common_utils_database, action="Processing With Carrier APIs")
        live_progress_percentage_tracker(database, bulk_change_id, 40)
        
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            for i in range(0, len(iccids), batch_size):
                batch = iccids[i:i + batch_size]
                futures = {}

                logging.info(f"### pondiot_bc_change_carrier_rate_plan and tenant : {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} ICCIDs")

                for iccid in batch:
                    url_add_package = f"{carrier_api_url}/sim/{iccid}/addPackage"
                    package_type_id = jasper_rate_plan_id
                    payload_add_package = {"packageTypeId": package_type_id}


                    def task(iccid=iccid, url=url_add_package, payload=payload_add_package):
                        success = False
                        api_success = False
                        package_id = None
                        status = "API_FAILED"
                        result = ""
                        activate_result = ""

                        # Step 1: Add Package API
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### tenant:{tenant_name} Attempt {attempt} AddPackage ICCID={iccid}")
                                resp = requests.post(url, json=payload, headers=headers, timeout=60)
                                logging.info(f"### tenant:{tenant_name} AddPackage Response {resp.status_code} ICCID={iccid}")
                                success = 200 <= resp.status_code < 300 
                                status = "PROCESSED" if success else "API_FAILED"
                                result = resp.text
                                if success:                                
                                    try:
                                        resp_json = resp.json()
                                        package_id = resp_json.get("packageId")
                                    except ValueError:
                                        logging.warning(f"### tenant:{tenant_name} Response not JSON for ICCID={iccid}: {resp.text}")

                                    success_iccids.append(iccid)
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### tenant:{tenant_name} AddPackage Exception Attempt {attempt} ICCID={iccid}: {result}")
                                time.sleep(RETRY_DELAY)

                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                            "log_entry_description": "AddPackage API",
                            "request_text": json.dumps(payload),
                            "has_errors": not success,
                            "response_status": "PROCESSED" if success else "API_FAILED",
                            "response_text": result,
                            "error_text": "" if success else result,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
                        database.insert_data(log, "sim_management_bulk_change_log")

                        # Step 2: Activate Package (only if package_id exists) 
                        if package_id:
                            activate_url = f"{carrier_api_url}/package/{package_id}/status"
                            activate_payload = {"packageStatus": "ACTIVE"}

                            for attempt in range(1, MAX_RETRIES + 1):
                                try:
                                    logging.info(f"### tenant:{tenant_name} Attempt {attempt} Activate Package={package_id} ICCID={iccid}")
                                    activate_resp = requests.post(activate_url, json=activate_payload, headers=headers, timeout=60)
                                    logging.info(f"### tenant:{tenant_name} Activate Response {activate_resp.status_code} ICCID={iccid}")
                                    api_success = 200 <= activate_resp.status_code < 300 
                                    status = "PROCESSED" if api_success else "API_FAILED"
                                    activate_result = activate_resp.text.strip() if activate_resp.text and activate_resp.text.strip() else "OK"

                                    if api_success:
                                        success_iccids.append(iccid)
                                        break
                                except Exception as e:
                                    activate_result = str(e)
                                    logging.warning(f"### tenant:{tenant_name} Activate Exception Attempt {attempt} ICCID={iccid}: {activate_result}")
                                    time.sleep(RETRY_DELAY)

                            # Update DB after Activate
                            update_data = {
                                "status": status,
                                "has_errors": not api_success,
                                "is_processed": True,
                                "processed_date": now,
                                "status_details": activate_result,
                            }
                            database.update_dict(
                                "sim_management_bulk_change_request",
                                update_data,
                                and_conditions={"bulk_change_id": bulk_change_id},
                                in_conditions={"iccid": [iccid]}
                            )

                            log = {
                                "bulk_change_id": bulk_change_id,
                                "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                "log_entry_description": "ActivatePackage API",
                                "request_text": json.dumps(activate_payload),
                                "has_errors": not api_success,
                                "response_status": "PROCESSED" if api_success else "API_FAILED",
                                "response_text": activate_result,
                                "error_text": "" if api_success else activate_result,
                                "processed_date": now,
                                "processed_by": created_by,
                                "created_by": created_by,
                                "created_date": now,
                                "is_deleted": False,
                                "is_active": True
                            }
                            database.insert_data(log, "sim_management_bulk_change_log")
                            inventory_update_flag = False  # default
                            # Update inventory only if both APIs succeed 
                            if success and api_success:
                                inventory_update_flag = database.update_dict(
                                    "sim_management_inventory",
                                    update_fields,
                                    and_conditions={"tenant_id": tenant_id, "is_active": True , "service_provider_id": service_provider_id},
                                    in_conditions={"iccid": [iccid]}
                                )

                                #  Insert final log after inventory update 
                                log = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                    "log_entry_description": "Inventory Updated after successful Add+Activate package" if inventory_update_flag else "Failed to update inventory after Add+Activate package",
                                    "request_text": json.dumps({"iccid": iccid, "update_fields": update_fields}),
                                    "has_errors": not inventory_update_flag,
                                    "response_status": "PROCESSED" if inventory_update_flag else "API_FAILED",
                                    "response_text": f"Inventory updated successfully for ICCID={iccid}" if inventory_update_flag else f"Failed to update inventory for ICCID={iccid}",
                                    "error_text": "" if inventory_update_flag else f"Inventory update failed for ICCID={iccid}",
                                    "processed_date": now,
                                    "processed_by": created_by,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "is_deleted": False,
                                    "is_active": True
                                }
                                database.insert_data(log, "sim_management_bulk_change_log")
    

                        logging.info(f"### tenant:{tenant_name} Completed processing ICCID={iccid}, Success={success}, Activated={api_success}, PackageId={package_id}")
                        return iccid

                    futures[executor.submit(task)] = iccid

                for fut in as_completed(futures):
                    try:
                        iccid = fut.result()
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.exception(f"### tenant:{tenant_name} Error processing ICCID: {e}")

        if interval and i + batch_size < len(iccids):
            time.sleep(interval)

        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",#status
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        # Update the bulk change request status   
        logging.info(f"### pondiot_bc_change_carrier_rate_plan and tenant : {tenant_name} Processed {len(iccids) - len(remaining)} iccids, {len(remaining)} remaining")
        ## Handle invalid ICCIDs
        
        # Prepare payload for history table update
        if success_iccids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids": success_iccids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            if effective_date:
                payload_history_table["data"]["effective_date"] = effective_date
            #api call to update the history table
            try:
                logging.info(f"### pondiot_bc_change_carrier_rate_plan and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### pondiot_bc_change_carrier_rate_plan and {tenant_name} Exception in thread: {e}")

        if source == "Inventory":
                action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
                action_history_payload = {
                    "data": {
                        "tenant_name": tenant_name,
                        "tenant_id": tenant_id,
                        "username": username,
                        "path": "/sim_management_action_history_update",
                        "iccids": success_iccids,
                        "msisdns": [],
                        "service_provider": service_provider,
                        "Partner": tenant_name,
                        "access_token": access_token,
                        "db_name": tenant_database,
                        "change_type": "Change Carrier Rate Plan",
                        "old_inventory_data": old_inventory_data,
                        "bulk_change_id": bulk_change_id,
                        "changed_field": "carrier_rate_plan_name",
                    }
                }
                
                # API call to update action history
                try:
                    logging.info(f"### pondiot_bc_change_carrier_rate_plan and {tenant_name} sync call has started for action history")
                    threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
                except Exception as e:
                    logging.exception(f"### pondiot_bc_change_carrier_rate_plan and {tenant_name} Exception in action history thread: {e}")
        
        live_progress_percentage_tracker(database, bulk_change_id,70)
        if invalid_iccids:
            logging.info(f"### Invalid ICCIDs found: {invalid_iccids}")
            # Log invalid ICCIDs
            for iccid in invalid_iccids:
                request_id = iccid_to_request_id.get(iccid)
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": "Update change carrier rate plan",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR", "errors":len(invalid_iccids),"is_processed":True,"has_errors":True,
                    "processed_date": now ,"status_details":"Invalid SIM - could not be processed"},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": invalid_iccids},
        )
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
        logging.info(f"### pondiot_bc_change_carrier_rate_plan and tenant : {tenant_name} Inserted {len(log_entries)} log entries for bulk change request")
        logging.info(f"### pondiot_bc_change_carrier_rate_plan and tenant : {tenant_name} Bulk change completed in {time.time() - start_time:.1f} seconds")
        response={"flag": True, "processed": len(iccids)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "iccids": iccids, "invalid_iccids": invalid_iccids, "bulk_change_id": bulk_change_id}

        # Call sync API in separate thread after delay
        live_progress_percentage_tracker(database, bulk_change_id,80)
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #sync api call to update the 1.0 inventory tables
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "pondiot_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info('### pondiot_bc_change_carrier_rate_plan and tenant : {tenant_name} sync call has started')
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,90)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info('### pondiot_bc_change_carrier_rate_plan and tenant : {tenant_name} sync call has ended') 
        except Exception as e:
            logging.exception(f"### pondiot_bc_change_carrier_rate_plan: Exception while scheduling sync call for tenant '{tenant_name}': {e}")

        # Return success
        logging.info(f"### pondiot_bc_change_carrier_rate_plan and tenant : {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### pondiot_bc_change_carrier_rate_plan and tenant : {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")

        live_progress_percentage_tracker(database, bulk_change_id,95)
        # Attempt to audit the action
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "pondiot_bc_change_carrier_rate_plan",
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for changing carrier rate plan for devices : {bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            ##auditing the sync completion
            bulk_change_audit_action(
                data, common_utils_database,
                action="Auditing"
            )
        except Exception as e:
            logging.exception(f"### pondiot_bc_change_carrier_rate_plan and tenant : {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action="Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### pondiot_bc_change_carrier_rate_plan and tenant : {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = "Error during bulk change processing"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        # Attempt to audit the action
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "pondiot_bc_change_carrier_rate_plan",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{iccids}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### pondiot_bc_change_carrier_rate_plan and tenant :{tenant_name} Exception in logging error data to DB: {e}")
 
        return response


## Assign customer function
def pondiot_bc_assign_customer(data):
    """Assigns a customer to the selected devices.
    This function processes a list of iccids and assign a customer account with the iccids in the pondiot system.
    It handles bulk requests, updates the database, and logs the results.
    Args:
        data (dict): Input data containing the following keys:
            - iccids (list): List of ICCIDs to process.
            - bulk_change_id (str): ID of the bulk change request.
            - changed_data (dict): Data to be sent to the pondiot API.
            - created_by (str): User who initiated the request.
            - service_provider (str): Service provider name.
            - change_type (str): Type of change being made.
        context (dict): Lambda context object containing execution details.
    Returns:
        dict: Result of the operation with flags, messages, and logs.
    
    """
    logging.info(f"### Received data for assign customer: %s", data)
    ## Start timing the function execution
    start_time = time.time()
    # Required inputs
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    source=data.get("source","")
    invalid_iccids = data.get("invalid_iccids", [])
    username= data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    invalid_ids= data.get("invalid_ids", [])
    role_name= data.get("role_name", "")
    access_token=data.get("access_token", "")
    service_provider_id = data.get("service_provider_id", "")
    # Initialize for log entries
    log_entries = []
    ## current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### pondiot_bc_assign_customer and tenant : {tenant_name} time is {now}")

    # DB setup
    try:
        tenant_database = data.get("db_name", "")
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.error(f"### pondiot_bc_assign_customer and tenant : {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": "DB connection failed"}
    try:
        bulk_change_audit_action(data,common_utils_database,action="Bulk Change Process Initiated")
        live_progress_percentage_tracker(database, bulk_change_id,10)
    except Exception as e:
        logging.exception(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Audit logging failed while inserting logs: {e}")
    try:
        # Carrier API details
        try:
            carrier_api_url, carrier_limits, app_id, app_secret, alternative_api_url = get_carrier_api_details(
                service_provider, change_type, common_utils_database
            )
            logging.info(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Carrier API details fetched successfully")

        except Exception as e:
            logging.error(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Carrier API lookup failed: {e}")
            return {"flag": False, "message": "Carrier API lookup failed"}
        
        if not carrier_api_url:
            return {"flag": False, "message": "Missing carrier_api_url"}


        # Fetch bulk change rows
       
        bulk_requests = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "iccid", "change_request"]
        )
        # Validate iccids
        remaining = iccids.copy()
        successful_iccids = []
        # Validate input data 
       
        if not bulk_requests.empty:
            change_request_json = bulk_requests.iloc[0]["change_request"]
            if not change_request_json:
                message="Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "pondiot_bc_assign_customer",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                    live_progress_percentage_tracker(database, bulk_change_id,100)
                except Exception as e:
                    logging.warning(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Audit logging failed: {e}")
                return response
        live_progress_percentage_tracker(database, bulk_change_id,25)    
        # Parse the change request JSON
        if isinstance(change_request_json, str):
           change_request_json = json.loads(change_request_json)
        #Extract relevant fields from the change request 
        customer_rate_plan_id=change_request_json.get("CustomerRatePlan","")
        customer_rate_pool_id=change_request_json.get("CustomerRatePool","")
        rev_customer_id=change_request_json.get("RevCustomerId","")
        service_type_id=change_request_json.get("ServiceTypeId","")
        effective_date=change_request_json.get("EffectiveDate","")
        activated_date=change_request_json.get("ActivatedDate","")
        usageplangroupid=change_request_json.get("UsagePlanGroupId","")
        revproductidlist=change_request_json.get("RevProductIdList",[0])
        product_id = revproductidlist[0] if revproductidlist else None
        provider_id=change_request_json.get("ProviderId","")
        number=change_request_json.get("Number","")
        integration_authentication_id=change_request_json.get("IntegrationAuthenticationId","")
        device_id=change_request_json.get("DeviceId")
        description=change_request_json.get("Description","")
        rate= change_request_json.get("RateList", [0])
        revpackageid=change_request_json.get("RevPackageId", None)

        rate_plan_id = None
        customer_rate_plan = None
        customer_rate_pool = None
        rev_customer = None
        provider_data=pd.DataFrame()
        rev_customer_uuid = None
        customer_id=None
        customer_name=None
       # Fetch customer and rate plan details from the database
        if customer_rate_plan_id:
            rate_plan_data = database.get_data(
                "customerrateplan",
                {"id": customer_rate_plan_id, "is_active": True},
                ["rate_plan_code","rate_plan_name"]
            )
            if not rate_plan_data.empty:
                # rate_plan_id = rate_plan_data["rate_plan_code"].to_list()[0]
                customer_rate_plan=rate_plan_data["rate_plan_name"].to_list()[0]
        if customer_rate_pool_id:
            rate_pool_data = database.get_data(
                "customer_rate_pool",
                {"id": customer_rate_pool_id, "is_active": True},
                ["name"]
            )
            if not rate_pool_data.empty:
                customer_rate_pool = rate_pool_data["name"].to_list()[0]
        if rev_customer_id:
            rev_data = database.get_data(
                "revcustomer",
                {"rev_customer_id": rev_customer_id, "is_active": True},
                ["customer_name", "id"]
            )
            if not rev_data.empty:
                rev_customer = rev_data["customer_name"].to_list()[0]
                rev_customer_uuid = rev_data["id"].to_list()[0]
        # Initialize as empty DataFrame       
        customer_data = pd.DataFrame()  
        if rev_customer:
               customer_data = database.get_data(
                    "customers", 
                    {"customer_name": rev_customer, "is_active": True},
                    ["id", "customer_name"]
                )

        if not customer_data.empty:
                customer_id = customer_data["id"].to_list()[0]
                customer_name = customer_data["customer_name"].to_list()[0]
        else:
            customer_id = None
            customer_name = None
        if provider_id:
            provider_data = database.get_data(
                "rev_provider",
                {"provider_id": provider_id, "is_active": True,"integration_authentication_id": integration_authentication_id},
                ["id"]
            )
            if not provider_data.empty:
                rev_provider_id = provider_data["id"].to_list()[0] 
       # Prepare update fields for the database
        update_fields = {"customer_rate_plan_id": customer_rate_plan_id,"customer_rate_plan_name": customer_rate_plan}
        if customer_rate_pool_id:
            update_fields["customer_rate_pool_id"] = customer_rate_pool_id
            update_fields["customer_rate_pool_name"] = customer_rate_pool
        if rev_customer_id:
            update_fields["rev_customer_id"] = rev_customer_id
            update_fields["rev_customer_name"] = rev_customer
        if effective_date:
            update_fields["effective_date"] = effective_date
        if integration_authentication_id:
            update_fields["account_number_integration_authentication_id"] = integration_authentication_id
        if device_id:
            update_fields["device_id"] = device_id
        update_fields["customer_id"] = customer_id if customer_id is not None else None
        update_fields["customer_name"] = customer_name if customer_name is not None else None
        # Load bulk requests and map to ICCIDs
       # Prepare the data for the API request
        iccid_to_request_id = dict(zip(bulk_requests.iccid, bulk_requests.id))
        iccid_to_changerequest = dict(zip(bulk_requests.iccid, bulk_requests.change_request))
        ## Prepare headers for API call
        headers = {
            "Authorization": app_id,
            "Ocp-Apim-Subscription-Key": app_secret,
        }
        # Prepare data for database insertion
        product_data={}
        if revpackageid:
            product_data["package_id"] = revpackageid
        if rate:
           product_data["rate"] = Decimal(str(rate[0]))
        if product_id:
            product_data["product_id"] = product_id
            
        # Parse string if needed
        if isinstance(carrier_limits, str):
            try:
                carrier_limits = json.loads(carrier_limits)
            except json.JSONDecodeError as e:
                logging.exception(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Invalid carrier_limits JSON: {carrier_limits}")
                return {"flag": False, "message": f"Invalid carrier_limits JSON: {carrier_limits}"}
            
        if source == "Inventory":
            old_inventory_data = database.get_data(
                "sim_management_inventory",
                {"is_active": True, "iccid": iccids,"tenant_id": tenant_id},
                ["id","iccid","msisdn","customer_name"]
            ).to_dict(orient="records")
        ##carrier limits and chunking processing
        batch_size = carrier_limits["batch_size"]
        parallel_requests = carrier_limits["parallel_requests"]
        if parallel_requests>10:
            logging.info(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
            parallel_requests=10
        interval = carrier_limits["interval_minutes"] * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        
        bulk_change_audit_action(data,common_utils_database,action="Processing With Carrier APIs")  
        live_progress_percentage_tracker(database, bulk_change_id,40)
        ## Chunking iccids and processing each batch in parallel using ThreadPoolExecutor with retry, DB updates, and logging
        with ThreadPoolExecutor(max_workers=parallel_requests) as executor:
            # Process each batch of ICCIDs
            for i in range(0, len(iccids), batch_size):
                # Create a batch of iccids
                batch = iccids[i:i + batch_size]
                # craete a dictionary to hold futures
                futures = {}
                logging.info(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Processing batch {i // batch_size + 1} with {len(batch)} ICCIDs")
                for iccid in batch:
                    url = f"{carrier_api_url}"
                    logging.info(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Processing ICCID: {iccid}")
                    payload_str = iccid_to_changerequest.get(iccid)
                    logging.info(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Payload for ICCID {iccid}: {payload_str}")
                    request_payload = json.loads(payload_str)
                    #extract the create rev service flag
                    rev_service = request_payload.get("CreateRevService", False)
                    # Build payloads for all APIs
                    rev_api_payload = {
                        "customer_id": rev_customer_id,
                        "provider_id": provider_id,
                        "service_type_id": service_type_id,
                        "number": number,
                        "activated_date": activated_date,
                    }
                    product_api_payload={
                        "CustomerId": rev_customer_id,
                        "service_type_id": service_type_id,
                        "number": number,
                        "effective_date": effective_date,
                        "activated_date": activated_date,
                        "product_id": product_id,
                        }
                    #task function
                    def task(iccid=iccid, rev_service=rev_service):
                        """ 1. If CreateRevService is True:
                            - Step 1: Call API to create RevService (POST with retries)
                            - Step 2: On success, extract RevService ID from response
                            - Step 3: Use RevService ID to create Service Product (POST)
                        
                           2. If CreateRevService is False:
                            - Skip RevService creation and directly insert into DB"""
                        success = False
                        result = ""
                        status = "API_FAILED"
                        id = None
                        productid = None
                        try:
                            if rev_service:
                                # Step 1:  First API Call to create the revservice
                                for attempt in range(1, MAX_RETRIES + 1):
                                    try:
                                        logging.info(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Attempt {attempt} - URL: {url}, Payload: {rev_api_payload}")
                                        
                                        resp = requests.post(url, json=rev_api_payload, headers=headers, timeout=60)
                                        success = 200 <= resp.status_code < 300
                                        result = "updated successfully" if success else resp.text
                                        logging.info(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Response Code: {resp.status_code}")
                                        logging.info(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Response Text: {result}")
                                        status = "PROCESSED" if success else "API_Failed"
                                        if success:
                                            try:
                                                response_data = resp.json()
                                                id = response_data.get("id")
                                                successful_iccids.append(iccid)
                                                
                                            except Exception:
                                                id = None
                                            break
                                    except Exception as e:
                                        result = str(e)
                                        status = "API_EXCEPTION"
                                        logging.exception(f"### pondiot_bc_assign_customer and tenant :{tenant_name} Exception in API call: {e}")
                                        time.sleep(RETRY_DELAY) 
                                # --- Update DB after API call ---
                                update_data = {
                                        "status": status,
                                        "has_errors": not success,
                                        "is_processed": True,
                                        "processed_date": now,
                                        "status_details": "OK"
                                    }
                                
                                database.update_dict(
                                    "sim_management_bulk_change_request",
                                    update_data,
                                    and_conditions={"bulk_change_id": bulk_change_id},
                                    in_conditions={"iccid": [iccid]},
                                    )            
                                if success:  
                                    #inserting values in rev service 
                                    rev_data={
                                    "rev_customer_id":rev_customer_uuid,
                                    "number":iccid,
                                    "rev_service_id":id,
                                    "activated_date":activated_date,
                                    "is_active":True,
                                    "integration_authentication_id":integration_authentication_id,
                                    "rev_provider_id":rev_provider_id,
                                    "rev_service_type_id":service_type_id
                                    }
                                    database.insert_data(rev_data,"rev_service")
                                    #updating inventory table
                                    rev_service_log=database.update_dict(
                                        "sim_management_inventory",update_fields,
                                        and_conditions={"tenant_id":tenant_id,"is_active": True , "service_provider_id": service_provider_id},
                                        in_conditions={"iccid": [iccid]}
                                    )
                                # Inserting logs based on api result
                                rev_log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                        "log_entry_description": "Create Rev.io Service: Rev.io API",
                                        "request_text": json.dumps(rev_api_payload),
                                        "has_errors": status == "API_Failed",
                                        "response_status": "PROCESSED" if success else "API_Failed",
                                        "response_text": result,
                                        "error_text": "" if status == "PROCESSED" else result,
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                                database.insert_data(rev_log,"sim_management_bulk_change_log") 
                                logging.info(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Inserting log for rev service creation: {rev_log}")
                                #inserting logs after updating inventory table
                                if rev_service_log:
                                    data_log = {
                                        "bulk_change_id": bulk_change_id,
                                        "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                        "log_entry_description": "Create Rev.io Service: Update AMOP",
                                        "request_text": json.dumps(rev_api_payload),
                                        "has_errors":False,
                                        "response_status": "PROCESSED",
                                        "response_text": "OK" ,
                                        "error_text": "",
                                        "processed_date": now,
                                        "processed_by": created_by,
                                        "created_by": created_by,
                                        "created_date": now,
                                        "is_deleted": False,
                                        "is_active": True
                                    }
                                    database.insert_data(data_log,"sim_management_bulk_change_log")
                                    logging.info(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Inserting log for inventory update: {data_log}")
                                # Step 2:  Second API Call
                                logging.info(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Creating Rev.io Service Product for ICCID: {iccid} with ID: {id}")
                                if id:
                                    second_url = f"{alternative_api_url}"
                                    #constracting payload 
                                    product_api_payload["service_id"]=id
                                    logging.info(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Product API Payload: {product_api_payload}, URL: {second_url}")

                                    for attempt in range(1, MAX_RETRIES + 1):
                                        try:
                                            get_resp = requests.post(second_url,json=product_api_payload, headers=headers, timeout=60)
                                            api_success = 200 <= get_resp.status_code < 300
                                            api_result =  "updated successfully" if api_success else get_resp.text
                                            logging.info(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Response Code: {get_resp.status_code}")
                                            logging.info(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Response Text: {api_result}")
                                            status = "PROCESSED" if api_success else "API_FAILED"
                                            if api_success:
                                                response_data = get_resp.json()
                                                productid = response_data.get("id")
                                                break
                                        except Exception as e:
                                            result = str(e)
                                            status = "API_EXCEPTION"
                                            time.sleep(RETRY_DELAY)
                                    if api_success:
                                        product_data.update({
                                               "service_product_id": productid,  
                                                "customer_id":rev_customer_id,  
                                                "service_id": id,  
                                                "description":description,  
                                                "activated_date": activated_date,     
                                                "status": "ACTIVE",  
                                                "created_by": created_by,  
                                                "created_date": now,  
                                                "is_active": True,  
                                                "is_deleted": False,  
                                                "integration_authentication_id": integration_authentication_id,
                                        })
                                        #inserting values into revservice product table 
                                        database.insert_data(product_data,"rev_service_product")
                                        logging.info(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Inserting log for rev service product creation: {product_data}")
                                        rev_service_log=database.update_dict(
                                            "sim_management_inventory",update_fields,
                                            and_conditions={"tenant_id":tenant_id,"is_active": True , "service_provider_id": service_provider_id},
                                            in_conditions={"iccid": [iccid]}
                                        )
                                    #constracting logs 
                                    log = {
                                            "bulk_change_id": bulk_change_id,
                                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                            "log_entry_description": "Create Rev.io Service Product: Rev.io API",
                                            "request_text": json.dumps(product_api_payload),
                                            "has_errors": status == "API_FAILED",
                                            "response_status": "PROCESSED" if api_success else "API_Failed",
                                            "response_text": api_result,
                                            "error_text": "" if status == "PROCESSED" else result,
                                            "processed_date": now,
                                            "processed_by": created_by,
                                            "created_by": created_by,
                                            "created_date": now,
                                            "is_deleted": False,
                                            "is_active": True
                                        }
                    
                                    if log:
                                        database.insert_data(log,"sim_management_bulk_change_log")
                                    logging.info(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Inserting log for product creation: {log}") 
                                    if rev_service_log:
                                        data_log = {
                                            "bulk_change_id": bulk_change_id,
                                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                            "log_entry_description": "Create Rev.io Service: Update AMOP",
                                            "request_text": json.dumps(product_api_payload),
                                            "has_errors":False,
                                            "response_status": "PROCESSED",
                                            "response_text": "OK" ,
                                            "error_text": "",
                                            "processed_date": now,
                                            "processed_by": created_by,
                                            "created_by": created_by,
                                            "created_date": now,
                                            "is_deleted": False,
                                            "is_active": True
                                        }
                                        database.insert_data(data_log,"sim_management_bulk_change_log")
                                        logging.info(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Inserting log for inventory update: {data_log}")
                            else:
                                #if createrevservice flag false then directly updating values into table
                                rev_service_log=database.update_dict(
                                        "sim_management_inventory",update_fields,
                                        and_conditions={"tenant_id":tenant_id,"is_active": True ,"service_provider_id": service_provider_id},
                                        in_conditions={"iccid": [iccid]}
                                    )
                                successful_iccids.append(iccid)

                                database.update_dict(
                                        "sim_management_bulk_change_request",
                                        {"status": "PROCESSED","is_processed":True,"has_errors":False,"processed_date": now,"status_details": "OK" if rev_service_log else "failed to update in inventory table"},
                                        and_conditions={"bulk_change_id": bulk_change_id},
                                        in_conditions={"iccid": iccids},
                                    )

                                #constracting logs
                                data_log = {
                                    "bulk_change_id": bulk_change_id,
                                    "bulk_change_request_id": iccid_to_request_id.get(iccid),
                                    "log_entry_description": "Create Rev.io Service: Update AMOP",
                                    "request_text": json.dumps(rev_api_payload),
                                    "has_errors": False,
                                    "response_status": "PROCESSED" if rev_service_log else "FAILED",
                                    "response_text": "updated successfully" if rev_service_log else "failed to update in inventory table",
                                    "error_text":  "" if rev_service_log else "failed to update in inventory table",
                                    "processed_date": now,
                                    "processed_by": created_by,
                                    "created_by": created_by,
                                    "created_date": now,
                                    "is_deleted": False,
                                    "is_active": True
                                }
                                database.insert_data(data_log,"sim_management_bulk_change_log")
                                logging.info(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Inserting log for inventory update: {data_log}")

                        except Exception as e:
                            logging.exception(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Unexpected error for ICCID {iccid}: {e}")
                        logging.info(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Completed processing ICCID: {iccid}, Success: {success}, ID: {id}, Product ID: {productid}")
                        return iccid
                    futures[executor.submit(task)] = iccid
                for fut in as_completed(futures):
                    try:
                        iccid = fut.result()
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.error(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Error processing iccid: {e}")
        if interval and i + batch_size < len(iccids):
            time.sleep(interval)
       
        #  Mark the bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {
                "status": "PROCESSED",
                "processed_date": now
            },
            {'id': bulk_change_id}
        )
        logging.info(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Processed %d iccids, %d remaining", len(iccids) - len(remaining), len(remaining))
        
        # Prepare payload for history table update
        if successful_iccids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids": successful_iccids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            if effective_date:
                payload_history_table["data"]["effective_date"] = effective_date
            #api call to update the history table
            try:
                logging.info(f"### pondiot_bc_assign_customer and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### pondiot_bc_assign_customer and {tenant_name} Exception in thread: {e}")

        if source == "Inventory":
                action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
                action_history_payload = {
                    "data": {
                        "tenant_name": tenant_name,
                        "tenant_id": tenant_id,
                        "username": username,
                        "path": "/sim_management_action_history_update",
                        "iccids": successful_iccids,
                        "msisdns": [],
                        "service_provider": service_provider,
                        "Partner": tenant_name,
                        "access_token": access_token,
                        "db_name": tenant_database,
                        "change_type": "Assign Customer",
                        "old_inventory_data": old_inventory_data,
                        "bulk_change_id": bulk_change_id,
                        "changed_field": "customer_name",
                    }
                }
                
                # API call to update action history
                try:
                    logging.info(f"### pondiot_bc_assign_customer and {tenant_name} sync call has started for action history")
                    threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
                except Exception as e:
                    logging.exception(f"### pondiot_bc_assign_customer and {tenant_name} Exception in action history thread: {e}")
            
        live_progress_percentage_tracker(database, bulk_change_id,70)    
        if invalid_iccids:
            logging.info(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Invalid iccids found: {invalid_iccids}")
            # Log invalid IDs
            for iccid in invalid_iccids:
                request_id = iccid_to_request_id.get(iccid)
                log_entries.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": request_id,
                    "log_entry_description": "Assign customer",
                    "request_text": "Update AMOP",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid ICCID - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })
        database.update_dict(
            "sim_management_bulk_change_request",
            {"status": "ERROR", "errors":len(invalid_iccids),"is_processed":True,"has_errors":True ,"status_details": "Invalid ICCID - could not be processed", "processed_date": now},
            and_conditions={"bulk_change_id": bulk_change_id},
            in_conditions={"iccid": invalid_iccids},
        )
        # Insert log entries into DB
        if log_entries:
            database.insert_data(log_entries,"sim_management_bulk_change_log")
        logging.info(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Inserted %d log entries for bulk change request", len(log_entries))
        logging.info(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Bulk Change Completed in %.1fs", time.time() - start_time)
        response={"flag": True, "processed": len(iccids)-len(remaining), "remaining": len(remaining),"message": "Bulk change request processed successfully.",
                  "iccids": iccids, "invalid_iccids": invalid_iccids, "bulk_change_id": bulk_change_id}
        
        live_progress_percentage_tracker(database, bulk_change_id,80)
        # Call sync API in separate thread after delay
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #sync api call to update the 1.0 inventory tables
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "pondiot_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f"### pondiot_bc_assign_customer and tenant : {tenant_name} sync call has started")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
            live_progress_percentage_tracker(database, bulk_change_id,90)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### pondiot_bc_assign_customer and tenant : {tenant_name} sync call has ended")
        except Exception as e:
            logging.exception(f"### pondiot_bc_assign_customer: Exception while scheduling sync call for tenant : '{tenant_name}': {e}")

        try:
            if successful_iccids:
                data["iccids"]=successful_iccids
                logging.info(f"### pondiot_bc_assign_customer and {tenant_name} sync call for billing  has started")
                billing_platform_bulk_change_20_sync(data)
        except Exception as e:
            logging.exception(f"### pondiot_bc_assign_customer and {tenant_name} Exception in thread: {e}")
 
        live_progress_percentage_tracker(database, bulk_change_id,95)
        # Attempt to audit the action
        try:
            audit_data_user_actions = {
                "service_name": "pondiot_bc_assign_customer",   
                "created_by": username,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for Assign customer for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            ##auditing the sync completion
            bulk_change_audit_action(
                    data, common_utils_database,
                    action="Auditing"
                )
        except Exception as e:
            logging.warning(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Audit logging failed: {e}")
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        return response
    except Exception as e:
        # Main exception block
        logging.exception(f"### pondiot_bc_assign_customer and tenant : {tenant_name} Error during bulk change processing: {e}")
        error_message = "Error during bulk change processing"
        error_type = str(type(e).__name__)
        response = {
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        error_update_data={"errors":len(remaining),"status":"ERROR"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "pondiot_bc_assign_customer",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error occurred while processing bulk change request for:{iccids}",
                "module_name": "Pondiot Container",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### pondiot_bc_assign_customer and tenant name : {tenant_name} auditing error to DB failed: {e}")
 
        return response
    

def pondiot_bc_line_sync(data):
    """
    Sync SIM inventory and bulk change requests with the pondiot API.

    This function processes a list of ICCIDs for a given bulk change operation
    and updates their details by calling the carrier's pondiot API. It includes
    retry logic, database updates, inventory synchronization, error handling,
    and audit logging.

    Args:
        data (dict): Input dictionary containing the following keys:
            - iccids (list): List of ICCIDs to be updated.
            - bulk_change_id (str): Identifier for the bulk change operation.
            - changed_data (dict): Contains request payload and UpdateStatus information.
            - service_provider (str): Name of the carrier/service provider.
            - change_type (str): Type of update (e.g., SIM/device status).
            - tenant_id (str): ID of the tenant.
            - tenant_name (str): Name of the tenant (for logs/audit).
            - db_name (str): Tenant-specific database name.
            - service_provider_id (str): Identifier for the service provider.
            - invalid_iccids (list): ICCIDs that failed validation before processing.

    Returns:
        dict: Response object summarizing the processing result:
            - flag (bool): True if operation completed without unhandled errors.
            - message (str): Summary of result (success or failure).
            - processed (int): Number of ICCIDs successfully processed.
            - remaining (int): Number of ICCIDs not processed.
            - iccids (list): List of ICCIDs attempted.
            - invalid_iccids (list): ICCIDs skipped due to invalid input.
            - bulk_change_id (str): Bulk change request ID.
            - error (str, optional): Error message if processing failed.
    """
    logging.info(f"### Received data for line sync: {data}")
    start_time = time.time()
    # Extract required fields
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    source=data.get("source","")
    tenant_name = data.get("tenant_name", "")
    username = data.get("username", "")
    service_provider_id = data.get("service_provider_id", "")
    invalid_iccids = data.get("invalid_iccids", [])
   
    # current time
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"### pondiot_bc_line_sync and {tenant_name} time is {now}")
    successfull_ids = []
    # Validate bulk_change_id
    if not bulk_change_id:
        logging.error(f"### pondiot_bc_line_sync and {tenant_name} Missing required field: bulk_change_id")
        return {"flag": False, "message": "bulk_change_id is required field"}
    tenant_database=data.get("db_name", "")
    access_token=data.get("access_token", "")
    role_name=data.get("role_name", "")
    # DB Connections
    try:
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as e:
        logging.error(f"### pondiot_bc_line_sync and {tenant_name} DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}

    # Initial audit log
    bulk_change_audit_action(data, common_utils_database, action="Bulk Change Process Initiated")
    live_progress_percentage_tracker(database, bulk_change_id,20)
    
    try:
        # Get carrier API credentials and configuration
        carrier_api_url, carrier_limits, app_id, app_secret,alternative_api_url = get_carrier_api_details(service_provider, change_type, common_utils_database)
        if isinstance(carrier_limits, str):
            carrier_limits = json.loads(carrier_limits)
        if not carrier_api_url:
            logging.error(f"### pondiot_bc_line_sync and {tenant_name} Missing carrier_api_url")
            return {"flag": False, "message": "Missing carrier_api_url"}

        logging.info(f"### pondiot_bc_line_sync and {tenant_name} Carrier API URL: {carrier_api_url} and Limits: {carrier_limits}")
        # Fetch bulk change requests from DB
        bulk_requests_df = database.get_data(
            "sim_management_bulk_change_request",
            {"bulk_change_id": bulk_change_id},
            ["id", "iccid"]
        ).rename(columns={"iccid": "iccid"})
        if  bulk_requests_df.empty:
            
                message=f"Bulk Change Request data is empty"
                response={"flag":False,"message":message}
                error_update_data={"errors":len(iccids),"status":"ERROR"}
                database.update_dict(
                        "sim_management_bulk_change",
                        error_update_data,
                        and_conditions={"id": bulk_change_id},
                        )
                # Attempt to audit the action
                try:
                    end_time = time.time()
                    time_consumed = end_time - start_time  # e.g. 0.7694284915924072
                    time_consumed = int(round(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "pondiot_bc_line_sync",
                        "created_by": username,
                        "status": json.dumps(response["flag"]),
                        "time_consumed_secs": time_consumed,
                        "tenant_name": tenant_name,
                        "module_name": "Bulk Change",
                        "comments": message,
                        "request_received_at": now,
                    }
                
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"### pondiot_bc_line_sync and {tenant_name} Audit logging failed: {e}")
                return response
        
        old_inventory_data = database.get_data(
            "sim_management_inventory",
            {"is_active": True, "iccid": iccids,"tenant_id": tenant_id}
        ).to_dict(orient="records")

        ##fetching the requests ids
        iccid_to_request_id = dict(zip(bulk_requests_df.iccid, bulk_requests_df.id))
        BATCH_SIZE = carrier_limits.get("batch_size")
        PARALLEL_REQUESTS = carrier_limits.get("parallel_requests") 
        if PARALLEL_REQUESTS>10:
           logging.info(f"### pondiot_bc_line_sync and {tenant_name} Requests are more than 10 worker cant handle that so making it to 10")
           PARALLEL_REQUESTS=10
        INTERVAL = carrier_limits.get("interval_minutes", 0) * 60
        MAX_RETRIES = int(os.getenv("MAX_RETRIES", 3))
        RETRY_DELAY = int(os.getenv("RETRY_DELAY", 5))
        logs = []
        changed_data = []
        remaining = list(iccids)
        # Execute API calls in parallel using ThreadPoolExecutor
        bulk_change_audit_action(data, common_utils_database, action="Processing With Carrier APIs")
        live_progress_percentage_tracker(database, bulk_change_id,40)
        with ThreadPoolExecutor(max_workers=PARALLEL_REQUESTS) as executor:
            for i in range(0, len(iccids), BATCH_SIZE):
                batch = iccids[i:i + BATCH_SIZE]
                futures = {}

                for iccid in batch:
                    url = f"{carrier_api_url}/{iccid}"                

                    def task(iccid=iccid, url=url):
                        success = False
                        result = ""
                        status = "API_FAILED"
                        updated = None
                        
                        # Retry logic
                        for attempt in range(1, MAX_RETRIES + 1):
                            try:
                                logging.info(f"### pondiot_bc_line_sync and {tenant_name} Attempting {attempt} for ICCID: {iccid} with URL: {url}")
                                resp = requests.get(url,      
                                            headers={
                                                        "Authorization": f"Bearer {app_id}",
                                                        "Content-Type": "application/json"
                                                    }, timeout=60)
                                logging.info(f"### pondiot_bc_line_sync and {tenant_name} Response Code: {resp.status_code} for ICCID: {iccid}")
                                success = 200 <= resp.status_code < 300
                                result = resp.text
                                status = "PROCESSED" if success else "API_FAILED"
                                if success:
                                    successfull_ids.append(iccid)
                                    break
                            except Exception as e:
                                result = str(e)
                                logging.warning(f"### pondiot_bc_line_sync and {tenant_name} Attempt {attempt} failed for ICCID: {iccid}: {result}")
                                time.sleep(RETRY_DELAY)

                        # Update request status in DB
                        database.update_dict(
                            "sim_management_bulk_change_request",
                            {"status": status, "has_errors": not success, "is_processed": True,
                           "processed_date": now,"status_details":resp.text},
                            and_conditions={"iccid": iccid, "bulk_change_id": bulk_change_id}
                        )

                        # Update inventory if successful
                        if success:
                            api_data = resp.json()

                            provisioned_ts = api_data.get("provisioned_date")  # e.g., 1713910533000
                            last_activation_date = None
                            if provisioned_ts:
                                # Convert ms → seconds → UTC datetime
                                last_activation_date = datetime.fromtimestamp(provisioned_ts / 1000, tz=timezone.utc)

                            to_update = {
                                "iccid": api_data.get("iccid"),
                                "sim_status": api_data.get("sim_status"),
                                "last_activation_date": last_activation_date,   # store as proper datetime
                                "modified_by": username,
                            }

                            # Handle imsis array - take the first IMSI
                            imsis_list = api_data.get("imsis", [])
                            if imsis_list:
                                to_update["imsi"] = imsis_list[0].get("imsi")

                            old_record = next((item for item in old_inventory_data if item.get("iccid") == api_data.get("iccid")), {})
                            exclude_fields = ["iccid","imsi","msisdn","imei"]  
                            keys_to_check = [key for key in to_update.keys() if key not in exclude_fields]
                            to_update, field_changes = build_detailed_update_dict(to_update, old_record, keys_to_check)
                            if to_update:
                                # Include the ID for update
                                to_update["id"] = old_record["id"]
                                to_update["modified_by"] = username
                                updated = database.update_dict(
                                    "sim_management_inventory",
                                    values=to_update,
                                    and_conditions={"id": old_record["id"]},
                                )
                            # Store field changes for batch processing
                            if field_changes:
                                
                                changed_data.append({
                                    "field_changes": field_changes, 
                                    "id": old_record["id"],
                                    "iccid": api_data.get("iccid"),
                                    "msisdn": api_data.get("msisdn"),
                                    "old_record": old_record  # Add the old data for history
                                })
                        

                        # Prepare log entry
                        log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                            "log_entry_description": "Update pondiot Subscriber: pondiot API",
                            "request_text": None,
                            "has_errors": not success,
                            "response_status": status,
                            "response_text": result,
                            "error_text": "" if success else result,
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }
                        if log:
                            database.insert_data(log, "sim_management_bulk_change_log")
                            
                        # Prepare log entry
                        # Determine inventory update success
                        inventory_success = updated  

                        # Prepare inventory log entry
                        inventory_log = {
                            "bulk_change_id": bulk_change_id,
                            "bulk_change_request_id": iccid_to_request_id.get(iccid),
                            "log_entry_description": "Update AMOP",
                            "request_text": None,
                            "has_errors": not inventory_success,
                            "response_status": "PROCESSED" if inventory_success else "ERROR",
                            "response_text": "inventory updated successfully" if inventory_success else "inventory update failed",
                            "error_text": "" if inventory_success else "Inventory update failed",
                            "processed_date": now,
                            "processed_by": created_by,
                            "created_by": created_by,
                            "created_date": now,
                            "is_deleted": False,
                            "is_active": True
                        }

                        if inventory_log:
                            database.insert_data(inventory_log, "sim_management_bulk_change_log")   
                            
                         
                        return iccid

                    futures[executor.submit(task)] = iccid

                for fut in as_completed(futures):
                    try:
                        iccid = fut.result()
                        remaining.remove(iccid)
                    except Exception as e:
                        logging.exception(f"### pondiot_bc_line_sync and {tenant_name} Error processing ICCID: {e}")

            if INTERVAL and i + BATCH_SIZE < len(iccids):
                time.sleep(INTERVAL)
        # Handle and log invalid ICCIDs
        #prepare the payload for history table
        if successfull_ids:
            url_history_table=os.getenv("MODULEMANAGEMENTSYNCURL", " ")
            payload_history_table = {
                                "data": {
                                        "tenant_name": tenant_name,
                                        "username":username,
                                        "path": "/update_device_history_tables",
                                        "iccids": successfull_ids,
                                        "msisdns":[],
                                        "service_provider":service_provider,
                                        "Partner": tenant_name,
                                        "access_token": access_token,
                                        "db_name": tenant_database,
                                        }
                                    }
            #api call to update the history table
            try:
                logging.info(f"### pondiot_bc_line_sync and {tenant_name} sync call has started for history table")
                threading.Timer(10.0, call_sync_api, args=(url_history_table, payload_history_table)).start()
            except Exception as e:
                logging.exception(f"### pondiot_bc_line_sync and {tenant_name} Exception in thread: {e}")

        if source == "Inventory" and changed_data:
            action_history_url = os.getenv("INVENTORYLAMBDAURL", "")
            
            # Use json.dumps with default=str for the entire payload
            action_history_payload = json.loads(json.dumps({
                "data": {
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "username": username,
                    "path": "/sim_management_action_history_update",
                    "iccids": successfull_ids,
                    "msisdns": [],
                    "service_provider": service_provider,
                    "Partner": tenant_name,
                    "access_token": access_token,
                    "db_name": tenant_database,
                    "change_type": "Line Sync",
                    "old_inventory_data": old_inventory_data,
                    "bulk_change_id": bulk_change_id,
                    "changed_data": changed_data
                }
            }, default=str))
            # API call to update action history
            try:
                logging.info(f"###  pondiot_bc_line_sync and {tenant_name} sync call has started for action history")
                threading.Timer(10.0, call_sync_api, args=(action_history_url, action_history_payload)).start()
            except Exception as e:
                logging.exception(f"###  pondiot_bc_line_sync and {tenant_name} Exception in action history thread: {e}")
        # Handle and log invalid ICCIDs
        if invalid_iccids:
            for iccid in invalid_iccids:
                logs.append({
                    "bulk_change_id": bulk_change_id,
                    "bulk_change_request_id": iccid_to_request_id.get(iccid),
                    "log_entry_description": "Update pondiot Subscriber: Invalid ICCID",
                    "request_text": "N/A",
                    "has_errors": True,
                    "response_status": "ERROR",
                    "response_text": "Invalid SIM - could not be processed",
                    "error_text": "Invalid ICCID",
                    "processed_date": now,
                    "processed_by": created_by,
                    "created_by": created_by,
                    "created_date": now,
                    "is_deleted": False,
                    "is_active": True
                })

        if logs:
            database.insert_data(logs,"sim_management_bulk_change_log")

        # Mark invalid request IDs as processed
        if invalid_iccids:
            database.update_dict(
                "sim_management_bulk_change_request",
                {"status": "ERROR", "is_processed": True, "has_errors": True,
                    "processed_date": now, "status_details": "Invalid SIM - could not be processed"},
                and_conditions={"bulk_change_id": bulk_change_id},
                in_conditions={"iccid": invalid_iccids}
            )

        # Update bulk change as processed
        database.update_dict(
            'sim_management_bulk_change',
            {"status": "PROCESSED", "processed_date": now},
            {'id': bulk_change_id}
        )

        #  sync API trigger
        api_url = os.getenv("SIMMANAGEMENTREQUESTURL", " ")
        api_payload = {
                "data": {
                    "access_token": access_token,
                    "data": {
                        "bulk_change_id": bulk_change_id
                    },
                    "db_name": tenant_database,
                    "is_update": True,
                    "module_name": "Bulk Change",
                    "Partner": tenant_name,
                    "path": "/update_bulk_change_tables_10",
                    "request_received_at": now,
                    "role_name": role_name,
                    "tenant_name": tenant_name,
                    "username": username
                }
            }
        #sync api to update the inventry tables in 1.0
        api_sync_url = os.getenv("BULKCHANGEONEPOINTOSYNCURL", " ")
        api_sync_payload = {
                "data": {
                    "access_token": access_token,
                    "key_name": "pondiot_bulkchange_sync",
                    "path": "/bulk_change_sync_10_updated",
                    "tenant_name": tenant_name,
                    "bulk_change_id": bulk_change_id
                }
            }
        try:
            logging.info(f"### pondiot_bc_line_sync and {tenant_name} sync call has started")
            
            live_progress_percentage_tracker(database, bulk_change_id,80)
            threading.Timer(10.0, call_sync_api, args=(api_url, api_payload)).start()
            threading.Timer(10.0, call_sync_api, args=(api_sync_url, api_sync_payload)).start()
            logging.info(f"### pondiot_bc_line_sync and {tenant_name} sync call has ended")
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Sync To 1.0 Tables"
            )
        except Exception as e:
            logging.exception(f"### pondiot_bc_line_sync and {tenant_name} Exception in thread: {e}")
        # Return success
        logging.info(f"### pondiot_bc_line_sync and {tenant_name} Bulk change request processed successfully.")
        logging.info(f"### pondiot_bc_line_sync and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        # Prepare response
        response={
            "flag": True,
            "processed": len(iccids) - len(remaining),
            "remaining": len(remaining),
            "message": "Bulk change request processed successfully.",
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
       
        live_progress_percentage_tracker(database, bulk_change_id,95)
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = end_time - start_time  # e.g. 0.7694284915924072
            time_consumed = int(round(time_consumed))
            audit_data_user_actions = {
                "service_name": "pondiot_bc_line_sync",
                "created_by": username,
                "status": "Success",
                "time_consumed_secs": time_consumed,
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Successfully processed bulk change request for update device status for devices.{bulk_change_id}",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
             ##auditing the auditing log
            bulk_change_audit_action(
                data, common_utils_database,
                action=f"Auditing"
            )
        except Exception as e:
            logging.exception(f"### pondiot_bc_line_sync and {tenant_name} Audit logging failed: {e}")
        ##final auditing the success log
        bulk_change_audit_action(
                data, common_utils_database,
                action=f"Bulk Change Process Completed"
            )
        live_progress_percentage_tracker(database, bulk_change_id,100)
        # Prepare success response
        logging.info(f"### pondiot_bc_line_sync and {tenant_name} Total time taken for processing: {time.time() - start_time} seconds")
        return response

    except Exception as e:
        # Global exception handling and logging
        logging.exception(f"### pondiot_bc_line_sync and {tenant_name} Error during bulk change processing: {str(e)}")
        error_message = str(e)
        error_type = type(e).__name__
        error_update_data={"errors":len(remaining),"status":"ERROR","status_details":"Something went wrong while processing!"}
        database.update_dict(
                "sim_management_bulk_change",
                error_update_data,
                and_conditions={"id": bulk_change_id},
                )
        ## Prepare error response
        try:
            error_data = {
                "service_name": "pondiot_bc_line_sync",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during bulk change for bulk_change_id: {bulk_change_id}",
                "module_name": "Bulk Change",
                "request_received_at": data.get("request_received_at") or now
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as log_e:
            logging.error(f"### pondiot_bc_line_sync and {tenant_name} Exception in logging error data to DB: {log_e}")
        response={
            "flag": False,
            "message": "Bulk change request processing failed.",
            "error": error_message,
            "iccids": iccids,
            "invalid_iccids": invalid_iccids,
            "bulk_change_id": bulk_change_id
        }
        return response
    
def build_detailed_update_dict(api_record, inventory_row, keys_to_check):
    """
    Build update dictionary with detailed field-level change tracking
   
    Args:
        api_record (dict): Data from carrier API
        inventory_row (pd.Series): Current inventory data
        keys_to_check (list): Fields to compare
   
    Returns:
        tuple: (to_update_dict, field_changes_list)
    """
    to_update = {}
    field_changes = []
   
    for key in keys_to_check:
        api_value = api_record.get(key)
        current_value = inventory_row.get(key)
       
        # Handle different data types and None values
        if pd.isna(current_value) or current_value is None:
            current_value = ""
        if pd.isna(api_value) or api_value is None:
            api_value = ""
           
        # Convert to string for comparison
        str_current = str(current_value).strip() if current_value is not None else ""
        str_api = str(api_value).strip() if api_value is not None else ""
       
        if str_current != str_api:
            to_update[key] = api_value
            field_changes.append({
                'field': key,
                'previous_value': str_current,
                'current_value': str_api
            })
            logging.info(f"### Field changed: {key}, From: '{str_current}', To: '{str_api}'")
   
    return to_update, field_changes
  


def billing_platform_bulk_change_20_sync(data):
    """
    This function orchestrates the execution billing platform API call to sync the required data
    """
    msisdns = data.get("msisdns", [])
    iccids = data.get("iccids", [])
    bulk_change_id = data.get("bulk_change_id")
    created_by = data.get("created_by")
    service_provider = data.get("service_provider")
    change_type = data.get("change_type")
    tenant_id = data.get("tenant_id", "")
    tenant_name = data.get("tenant_name", "")
    db_name = data.get("db_name", "")
    username = data.get("username", "")
    username= data.get("username", "")
    access_token=data.get("access_token", "")
    role_name= data.get("role_name", "")
    service_provider_id=data.get("service_provider_id","")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    try:
        logging.info(f"bulk_change_billing_platform_sync function is called with data: {data}")

        try:
            db_name = data.get("db_name", "")
            database = DB(db_name, **db_config)
            common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        except Exception as e:
            logging.error(f"### billing_platform_bulk_change_20_sync(data,change_request_type):and{tenant_name} DB connection error:{e}")
            return {"flag": False, "message": f"DB connection failed: {e}"}

        path_map = {
            "Update Device Status": "/bulk_update_device_status",
            "Change Customer Rate Plan": "/bulk_update_customer_rate_plan_service_line_creation",
            "Assign Customer": "/bulk_update_assign_customer_service_line_creation",
            "Change ICCID/IMEI": "/bulk_update_iccid_imei_service_line_creation"
        }
        filters = {"bulk_change_id": bulk_change_id}
        if iccids:
            filters["iccid"] = iccids         
        elif msisdns:
            filters["subscriber_number"] = msisdns
        billing_flag=False
        carrier_enabled=False
        billing_platform_flag=common_utils_database.get_data(
            "tenant",
            {"tenant_name": tenant_name},
            ["billing_platform_flag"]
        )
        if not billing_platform_flag.empty:
            billing_flag= bool(billing_platform_flag.iloc[0]["billing_platform_flag"])
        service_provider_data=database.get_data(
        "serviceprovider", {"service_provider_name": service_provider}, ["write_is_enabled"])
        if not service_provider_data.empty:
            carrier_enabled=bool(service_provider_data.iloc[0]["write_is_enabled"])
        if change_type in path_map:
            logging.info(f"Processing change request type: {change_type}")

            path = path_map[change_type]
            data['path'] = path
        columns = [
                "iccid",
                "subscriber_number",
                "m2m_id",
                "bulk_change_id",
                "tenant_name",
                "created_by",
                "processed_by",
                "status",
                "device_id",
                "is_active",
                "is_deleted",
                "change_request",
                "id"
            ]
        request_data = database.get_data(
            "sim_management_bulk_change_request",
            filters,
            columns
        )
        bulk_change_requests = []
        if not request_data.empty:
            bulk_change_requests = request_data.to_dict(orient="records")
        for rec in bulk_change_requests:
            rec["device_change_request_id"] = rec["iccid"]
        change_columns = [
            "service_provider",
            "change_request_type_id",
            "change_request_type",
            "service_provider_id",
            "modified_by",
            "status",
            "uploaded",
            "is_active",
            "is_deleted",
            "created_by",
            "processed_by",
            "tenant_id",
            "id_10"
        ]
        change_data = database.get_data(
            "sim_management_bulk_change",
            {"id": bulk_change_id,"status":"PROCESSED"},
            change_columns
        )
        bulk_change_records = []
        if not change_data.empty:
            bulk_change_records = change_data.to_dict(orient="records")
        
        api_url=os.getenv("BILLINGSYNCURL","")
        data_sync={
                "path":path,
                "data": {
                    "tenant_name":tenant_name,
                    "username": username,
                    "firstLastName": username,
                    "path": path,
                    "role_name": role_name,
                    "module_name": "Bulk Change",
                    "mod_pages": {
                    "start": 0,
                    "end": 100
                    },
                    "access_token": access_token,
                    "db_name": db_name,
                    "sessionID": None,
                    "request_received_at": now,
                    "Partner": tenant_name,
                    "service_provider_id":service_provider_id,
                    "bulkchange_id": bulk_change_id,
                    "data": {
                    "sim_management_bulk_change": bulk_change_records,         
                    "sim_management_bulk_change_request": bulk_change_requests
                    },
                    "bulk_chnage_id_20": bulk_change_id,
                    "use_carrier_activation": carrier_enabled,
                    "carrier_api_status": True,
                    "billing_platform_flag": billing_flag
                }
                }
        try:
        # Make the API call
            logging.info(f"### Calling sync API: {api_url} with payload: {data_sync}")
            response = requests.post(api_url, json=data_sync)
            if response.status_code == 200:
                logging.info("Bulk Change API call successful. Data sync call successfully done.")
            else:
                logging.error(f"API call failed with status code: {response.status_code}")
        except Exception as e:
            logging.error(f"Error making API call: {e}")
        

        audit_data_user_actions = {
                "service_name": "bulk_change_billing_platform_sync",
                "created_by": data.get("username",""),
                "status": str(["flag"]),
                "session_id": data.get("session_id",""),
                "tenant_name": data.get("Partner",""),
                "comments": f"Billing Platform Sync, change type is {change_type}",
                "module_name": "Sim Management",
                "request_received_at": data.get("request_received_at",""),
            }
        common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        logging.info("Successfully finished the process for bulk_change_billing_platform_sync")
        return {"flag":True}

    except Exception as e:
        logging.exception(f"Exception occurred while syncing billing platform: {e}")
        error_type = type(e).__name__
        error_data = {
            "service_name": f"Billing Platform Sync, change type is {change_type}",
            "error_message": "Exception occurred while syncing billing platform",
            "error_type": error_type,
            "users": data.get("username",""),
            "session_id": data.get("session_id",""),
            "tenant_name": data.get("Partner",""),
            "comments": json.dumps((data)),
            "module_name": "Sim Management",
            "request_received_at": data.get("request_received_at",""),
        }
        common_utils_database.log_error_to_db(error_data, "error_log_table")
        return {"flag":False}





##SYNC API call function
def call_sync_api(api_url, api_payload):
    '''
    Call the sync API with the provided URL and payload.
    This function is designed to be run in a separate thread after a delay.
    '''
    try:
        # Make the API call
        logging.info(f"### Calling sync API: {api_url} with payload: {api_payload}")
        response = requests.post(api_url, json=api_payload)
        if response.status_code == 200:
            logging.info("Bulk Change API call successful. Data sync call successfully done.")
        else:
            logging.error(f"API call failed with status code: {response.status_code}")
    except Exception as e:
        logging.error(f"Error making API call: {e}")

## Function to audit user actions in bulk change processing
def bulk_change_audit_action(data, common_utils_database,action):
    """
    Audits user actions by logging them into the bulk change auditing table.
 
    Args:
        data (dict): Data containing user action details.
        common_utils_database (DB): Database connection object.
 
    Returns:
        None
    """
    service_provider = data.get("service_provider", "")
    change_event_type = data.get("change_type", "")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
   
    request_received_at = data.get("request_received_at", "") or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    bulk_change_id = data.get("bulk_change_id", "")
    try:
        audit_data_user_actions = {
                "tenant_name": tenant_name,
                "bulk_change_id":bulk_change_id,
                "serviceprovider": service_provider,
                "change_event_type": change_event_type,
                "action": action,
                "created_date": request_received_at,
                "created_by": username,
               
        }
        common_utils_database.update_audit(audit_data_user_actions, "bulk_change_auditing")
        logging.info("User action audited successfully.")
    except Exception as e:
        logging.exception(f"### Error logging user actions: {e}")


def live_progress_percentage_tracker(database, bulk_change_id,progress_percent):
    """
    Updates the live_progress_percentage column in sim_management_bulk_change_request table.
    """
    try:
        update_fields={}
        #updating sync status when progress percentage reached 100
        if progress_percent==100:
            update_fields["live_progress_percentage"]=progress_percent
            update_fields["progress"]="Sync Completed"
        else:
            update_fields["live_progress_percentage"]=progress_percent

        database.update_dict(
            "sim_management_bulk_change",
            update_fields,
            and_conditions={"id": bulk_change_id}
        )
        return True
    except Exception as e:
        logging.error(f"Error updating live progress: {e}")
        return False

