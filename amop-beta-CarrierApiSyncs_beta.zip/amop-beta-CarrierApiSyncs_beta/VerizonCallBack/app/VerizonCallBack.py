"""
@Author1 : Anvesh
@Author2 : Phaneendra Y
@Author3 : Gopi Teja B
Created Date: 2025-09-16
"""
# Importing the necessary Libraries

import logging
import os
import pandas as pd
import numpy as np
import json
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
from common_utils.timezone_conversion import *
from pandas import Timestamp
from datetime import datetime
from dateutil.relativedelta import relativedelta
from sqlalchemy import create_engine, text
from pytz import timezone
from openpyxl.utils import get_column_letter
from concurrent.futures import ThreadPoolExecutor, as_completed
import time, random

logging = Logging(name="verizon_callback")
# Database configuration
# db_config = {
#      "host": os.environ["HOST"],
#      "port": os.environ["PORT"],
#      "user": os.environ["USER"],
#      "password": os.environ["PASSWORD"],

#  }

db_config_beta = {
     "host": os.environ["HOST"],
     "port": os.environ["PORT"],
     "user": os.environ["USER"],
     "password": os.environ["PASSWORD"],

 }
def funtion_caller(data, path):
    """
    Main function caller that handles database configuration setup and routes requests.
    
    This function:
    1. Sets up initial database configuration
    2. Determines user type (regular user or service account)
    3. Builds appropriate database filters based on user permissions
    4. Routes the request to the appropriate endpoint handler
    
    Args:
        data (dict): Request data containing user/tenant information
        path (str): API endpoint path being called
        access_token (str): Optional access token for service accounts
        
    Returns:
        Result of the called endpoint function or error response
    """
    # Route to appropriate endpoint handler
    if path == "/verizon_request_processor":
        result = verizon_request_processor(data) 
    elif path=="/verizon_callback_flow_10":
        result= verizon_callback_flow_10(data)  
    elif path=="/verizon_tenant_request":
        result= verizon_tenant_request(data)  
    else:
        result = {"flag":False,"error": "Invalid path or method"}
        logging.info(f"Invalid path or method requested: {path}")
    return result
    
def verizon_request_processor(data):
    """
    this function processes the verizon callback response and inserts the data into the amop common utils database.
    Args:
        data (dict): The request data containing callback information.
    Returns:
        dict: A dictionary indicating success or failure of the operation.
    """
    logging.info(f"request recieved for verizon_request_processor with data {data}")
    try:
        #common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config_beta)
    except Exception as e:
        logging.error(f"### DB connection error: {e}")
        return {"flag": False, "message": f"DB connection failed: {e}"}
    #getting the response parameters
    start_time = time.time()
    has_usage=data.get('has_usage',False)
    try:
        ##Step 1: Passing the request based on the usage or device actions details
        if has_usage:
            request_id = data.get("requestId",None)
            if not request_id:
                response={"flag": False, "message": "No usage to process or missing requestId."}
                try:
                    # End time calculation
                    end_time = time.time()
                    time_consumed = f"{end_time - start_time:.4f}"
                    time_consumed = int(float(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "verizon_request_processor",
                        "created_by": "verizon_request_processor",
                        "time_consumed_secs": time_consumed,
                        "status": "Response Inserted",
                        "tenant_name": "",
                        "module_name": "Verizon Callback for Usage Failed",
                        "comments": f"Audited request id  and response No usage to process or missing requestId",
                        "request_received_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    }
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"### Audit logging failed: {e}")
                return response
            # --- Fetch tenant_id using request_id ---
            callback_df = common_utils_database.get_data(
                "bulk_change_verizon_callback",
                {"request_id": request_id},
                ["tenant_id"]
            )
            if callback_df.empty:
                response={"flag": False, "message": "No callback entry found for request_id."}
                try:
                    # End time calculation
                    end_time = time.time()
                    time_consumed = f"{end_time - start_time:.4f}"
                    time_consumed = int(float(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "verizon_request_processor",
                        "created_by": "verizon_request_processor",
                        "time_consumed_secs": time_consumed,
                        "status": "Response Inserted",
                        "tenant_name": "",
                        "module_name": "Verizon Callback for Usage",
                        "comments": f"Audited request id {request_id} and response No callback entry found for request_id.",
                        "request_received_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    }
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"### Audit logging failed: {e}")
            tenant_id = callback_df["tenant_id"].to_list()[0]
            logging.info(f"###verizon_request_processor tenant_id found: {tenant_id}")
            # --- Fetch tenant DB info using tenant_id ---
            tenant_df = common_utils_database.get_data(
                "tenant",
                {"id": tenant_id},
                ["db_name", "db_config"]
            )
            if tenant_df.empty:
                return {"flag": False, "message": "Tenant not found for tenant_id."}

            tenant_db_name = tenant_df["db_name"].iloc[0]
            db_config_json = tenant_df.iloc[0]["db_config"]
            # Parse db_config if it's a string
            if isinstance(db_config_json, str):
                db_config_json = json.loads(db_config_json)

            # Build the configuration dictionary
            tenant_db_config = {
                "host": db_config_json.get("hostname"),
                "port": db_config_json.get("port"),
                "user": db_config_json.get("user"),
                "password": db_config_json.get("password"),
                "multi_schema": False
            }

            logging.info(f"###verizon_request_processor Tenant DB info: {tenant_db_name}")
            # Create tenant DB connection
            tenant_db = DB(tenant_db_name, **tenant_db_config)
            # --- Prepare staging JSON list ---
            staging_records=[]
            staging_records = [
                {
                    "imsi": next((d["id"] for d in usage.get("deviceIds", []) if d["kind"] == "imsi"), None),
                    "iccid": next((d["id"] for d in usage.get("deviceIds", []) if d["kind"] == "iccid"), None),
                    "imei": next((d["id"] for d in usage.get("deviceIds", []) if d["kind"] == "imei"), None),
                    "data_usage": usage.get("dataUsage", "0"),
                    "sms_usage": usage.get("smsUsage", "0"),
                    "usage_start_date": usage.get("startDate"),
                    "usage_end_date": usage.get("endDate"),
                    "mo_sms": usage.get("moSms", "0"),
                    "mt_sms": usage.get("mtSms", "0"),
                    "created_by": "verizon_request_processor",
                    "modified_by": "verizon_request_processor",
                    "request_id":request_id
                }
                for usage in data["deviceResponse"]["usageResponse"]
            ]
            logging.info(f"###verizon_request_processor Prepared staging JSON with {len(staging_records)} records")
            inserted_id = tenant_db.insert_data(staging_records, "verizon_carrier_usage_staging")
            response={"flag": True,
                    "message": f"Inserted {len(staging_records)} staging records successfully.",
                    "inserted_id": inserted_id}
            try:
                # End time calculation
                end_time = time.time()
                time_consumed = f"{end_time - start_time:.4f}"
                time_consumed = int(float(time_consumed))
                audit_data_user_actions = {
                    "service_name": "verizon_request_processor",
                    "created_by": "verizon_request_processor",
                    "time_consumed_secs": time_consumed,
                    "status": "Response Inserted",
                    "tenant_name": "",
                    "module_name": "Verizon Callback for Usage",
                    "comments": f"Audited request id {request_id} and response for usage Inserted {len(staging_records)} staging records successfully",
                    "request_received_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                }
                common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            except Exception as e:
                logging.warning(f"### Audit logging failed: {e}")
            return response
        else:
            request_id = data.get("requestId",None)
            iccid = data.get("deviceIds", [{}])[0].get("id")
            fault_code = data.get("faultResponse", {}).get("faultcode",None)
            fault_string = data.get("faultResponse", {}).get("faultstring",None)
            callback_count = data.get("callbackCount",None)
            max_callback_threshold = data.get("maxCallbackThreshold",None)
            status = data.get("status",None)
            device_response = data.get("deviceResponse", {})
            change_plan_resp = device_response.get("changeServicePlanResponse", {})
            service_plan = change_plan_resp.get("servicePlan")

            # Extract ICCID and MSISDN from device IDs
            device_ids = data.get("deviceIds", [])
            iccid = next((d["id"] for d in device_ids if d.get("kind") == "iccid"), None)
            activate_resp = (
            data.get("deviceResponse", {})
                .get("activateResponse", {})
            )
            inner_device_ids = activate_resp.get("deviceIds", [])
            msisdn = next((d["id"] for d in inner_device_ids if d.get("kind") == "msisdn"), None)
            sim_status = activate_resp.get("state")
            callback_data={}
            if service_plan and not fault_string:
                fault_string = service_plan
            # Insert the callback data into the database
            callback_data = {
                "request_id": request_id,
                "iccid": iccid,
                "fault_code": fault_code,
                "fault_string": fault_string,
                "callback_count":callback_count,
                "msisdn": msisdn,
                "sim_status": sim_status,
                "max_callback_threshold": max_callback_threshold,
                "status": status,
            }
            logging.info(f"verizon callback responsedata is{callback_data} ")
            try:
                request_data = common_utils_database.insert_data(callback_data, "bulk_change_verizon_callback")
                logging.info(f"verizon callback response inserted successfully for request id {request_id}")
            except Exception as e:
                logging.error(f"Failed to insert in prod DB: {e}")
            # Inserting into prod db
            # try:
            #     request_data_beta = common_utils_database_beta.insert_data(callback_data, "bulk_change_verizon_callback")
            #     logging.info(f"verizon callback response inserted successfully for request id  with {request_data_beta} in beta db")
            # except Exception as e:
            #     logging.error(f"Failed to insert in beta DB: {e}")
            # Audit logging for user actions
            if request_data:
                response = {"flag": True, "message": "Received verizon callback response"}
                try:
                    # End time calculation
                    end_time = time.time()
                    time_consumed = f"{end_time - start_time:.4f}"
                    time_consumed = int(float(time_consumed))
                    audit_data_user_actions = {
                        "service_name": "verizon_request_processor",
                        "created_by": "verizon_request_processor",
                        "time_consumed_secs": time_consumed,
                        "status": "Response Inserted",
                        "tenant_name": "",
                        "module_name": "Verizon Callback",
                        "comments": f"Audited request id {request_id} and response: {fault_string}",
                        "request_received_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    }
                    common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
                except Exception as e:
                    logging.warning(f"### Audit logging failed: {e}")
            else:
                response={"flag": True, "message": "verizon callback response failed to insert"}

        return response
    except Exception as e:
        logging.exception(f"inserting into table failed: {request_id}:  {e}")
        response = {"flag": False, "error": "verizon callback response failed to insert"}
        error_message = f"Error during bulk change processing"
        error_type = str(type(e).__name__)
        try:
            # Log failure to error log table
            error_data = {
                "service_name": "verizon_callback_processor",
                "created_by": "verizon_request_processor",
                "error_message": error_message,
                "error_type": error_type,
                "users": "",
                "tenant_name": "",
                "comments": f"Error while inserting response deatils into table with {request_id}: and has_usage flag is {has_usage} ",
                "module_name": "verizon callback ",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### Logging error to DB failed: {e}")
        return response
    
def verizon_callback_flow_10(data):
    """
    Lambda to fetch stored Verizon callback response
    Input: JSON { "request_id": "<id>", "iccid": "<optional>" }
    Output: JSON with stored response or error message
    """
    logging.info(f"request recieved for verizon_callback_flow_10 with data {data}")
    start_time = time.time()

    try:
        # Parse API Gateway body
       # body = json.loads(data.get("body", "{}"))
        request_id = data.get("request_id")
        iccid = data.get("iccid")
        env_value=data.get("environment","uat")

        if not request_id:
            response = {
            "statusCode": 400,
            "flag": True,
            "error": "request_id is required"
            }
        try:
            # if env_value.lower() == ["prod","production"]:
            #     common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
            if env_value.lower() == ["Beta","beta"]:
                common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config_beta)
        except Exception as e:
            logging.error(f"### DB connection error: {e}")
            return {"flag": False, "message": f"DB connection failed: {e}"}
        # Build query & parameters
        callback_df =common_utils_database.get_data(
                "bulk_change_verizon_callback",
                {"request_id": request_id,"iccid":iccid},
                ["fault_code", "fault_string", "msisdn", "sim_status","status"]
            )

        if callback_df.empty:
            response={  "statusCode":404,"flag": True,"message": "No record found for given request_id"}
        # Convert entire DataFrame to list of dicts
        response_payload = callback_df.to_dict(orient="records")
        logging.info(f"response_payload is {response_payload}")
        response={"statusCode":200, "flag": True,"data": response_payload}
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "verizon_tenant_request",
                "created_by": "System",
                "time_consumed_secs": time_consumed,
                "status": "Response Fetched and Returned",
                "tenant_name": "",
                "module_name": "Verizon Callback",
                "comments": f"Audited request data  {data} and response: {response}",
                "request_received_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Audit logging failed: {e}")
        return response
    except Exception as e:
            response={"statusCode":500,"flag": True,"error": str(e)}
            error_message = f"Error during bulk change processing"
            error_type = str(type(e).__name__)
            try:
                # Log failure to error log table
                error_data = {
                    "service_name": "verizon_tenant_request",
                    "created_by": "System",
                    "error_message": error_message,
                    "error_type": error_type,
                    "users": "",
                    "tenant_name": "",
                    "comments": f"Error while fetching response deatils into table with {request_id}: ",
                    "module_name": "verizon callback ",
                    "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                }
                common_utils_database.log_error_to_db(error_data, "error_log_table")
            except Exception as e:
                logging.exception(f"### Logging error to DB failed: {e}")
            return response
def verizon_tenant_request(data):
    """
    Placeholder for future Verizon callback processing flow (Flow 20)
    """
    logging.info(f"request recieved for verizon_callback_flow_20 with data {data}")
    start_time = time.time()
    # Future implementation goes here
    try:
        # Parse API Gateway body
       # body = json.loads(data.get("body", "{}"))
        request_id = data.get("request_id")
        tenant_id= data.get("tenant_id")
        env_value=data.get("environment","uat")
        service_provider_id=data.get("service_provider_id")

        if not request_id:
            response = {
            "statusCode": 400,
            "flag": True,
            "error": "request_id is required"
            }
        try:
            #common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
            common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config_beta)
        except Exception as e:
            logging.error(f"### DB connection error: {e}")
            return {"flag": False, "message": f"DB connection failed: {e}"}
        # Build query & parameters
        callback_data = {
                "request_id": request_id,
                "tenant_id": tenant_id,
                #"service_provider_id":service_provider_id,
            }
        logging.info(f"verizon callback responsedata is{callback_data} ")
        try:
            request_data = common_utils_database.insert_data(callback_data, "bulk_change_verizon_callback")
            if request_data:
                response = {"flag": True, "message": "Received verizon callback tenant request"}
            logging.info(f"verizon callback response inserted successfully for request id {request_id}")
        except Exception as e:
            logging.error(f"Failed to insert in prod DB: {e}")
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "verizon_tenant_request",
                "created_by": "System",
                "time_consumed_secs": time_consumed,
                "status": "Response Fetched and Returned",
                "tenant_name": "",
                "module_name": "Verizon Callback",
                "comments": f"Audited request data  {data} and response: {response}",
                "request_received_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"### Audit logging failed: {e}")
        return response
    except Exception as e:
            response={"statusCode":500,"flag": True,"error": str(e)}
            error_message = f"Error during bulk change processing"
            error_type = str(type(e).__name__)
            try:
                # Log failure to error log table
                error_data = {
                    "service_name": "verizon_tenant_request",
                    "created_by": "System",
                    "error_message": error_message,
                    "error_type": error_type,
                    "users": "",
                    "tenant_name": "",
                    "comments": f"Error while fetching response deatils into table with {request_id}: ",
                    "module_name": "verizon callback ",
                    "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                }
                common_utils_database.log_error_to_db(error_data, "error_log_table")
            except Exception as e:
                logging.exception(f"### Logging error to DB failed: {e}")
            return response