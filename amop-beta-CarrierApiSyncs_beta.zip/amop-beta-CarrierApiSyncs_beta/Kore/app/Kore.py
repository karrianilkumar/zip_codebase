"""
@Author1 : Phaneendra.Y
Created Date: 03-02-26
"""
# Importing the necessary Libraries
import time
import logging
from datetime import datetime, date, timedelta
import requests
from concurrent.futures import ThreadPoolExecutor, as_completed, wait, FIRST_COMPLETED
from datetime import datetime, timedelta
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from psycopg2 import extras
import pandas as pd
import threading
import random
from datetime import datetime
from psycopg2.extras import execute_values
from datetime import datetime, timezone
from dateutil.relativedelta import relativedelta
from sqlalchemy import create_engine, text
from psycopg2.extras import execute_values
from concurrent.futures import ThreadPoolExecutor, as_completed
import numpy as np
import psycopg2
from psycopg2 import extras

import xml.etree.ElementTree as ET
from psycopg2.extras import execute_values
# import xmltodict
import json
from datetime import datetime, timedelta
# import paramiko
import io
import openpyxl


## Importing the necessary modules
from common_utils.db_utils import DB
from common_utils.email_trigger import send_email


# Database configuration
common_utils_db_config = {
     "host": os.environ["HOST"],
     "port": os.environ["PORT"],
     "user": os.environ["USER"],
     "password": os.environ["PASSWORD"],

 }

##function caller where the functions begins
def funtion_caller(data,path):
    """
    Main function caller that handles database configuration setup and routes requests.
    
    This function:
    1. Sets up initial database configuration
    2. Determines user type (regular user or service account)
    3. Builds appropriate database filters based on user permissions
    4. Routes the request to the appropriate endpoint handler
    
    Args:
        data (dict): Request data containing user/tenant information
        path (str): API endpoint path being called
        access_token (str): Optional access token for service accounts
        
    Returns:
        Result of the called endpoint function or error response
    """
    # Route to appropriate endpoint handler
    if path == "/run_kore_sync":
        result = run_kore_sync(data)
       
        
    ##else condition to handle the invalid path method
    else:
        result = {"flag":False,"error": "Invalid path or method"}
        logging.info(f"Invalid path or method requested: {path}")
    return result


##kore carrier daily sync function
def run_kore_sync(data):
    """
    kore Carrier Daily Sync

    Performs the daily carrier sync for kore by:
    - Retrieving device details and usage data from the carrier
    - Converting usage values to standard units
    - Storing data in staging tables and syncing it to main AMOP tables
    - Recording sync progress and status in audit tables
    - Sending success or failure notification emails

    Returns:
        dict: Sync result with success or failure details.
    """
    logging.info(f"### run_kore_sync Received data {data}")
    start_time_ts = time.time()
    start_time_dt = datetime.now()
    # Fetch required fields
    service_provider_name = data.get("service_provider_name",None)
    username             = data.get("username",None)
    service_provider_id   = int(data.get("service_provider_id")) if data.get("service_provider_id") else None
    integration_id        = data.get("integration_id",None)
    tenant_id             = data.get("tenant_id",None)
    tenant_name           = data.get("tenant_name",None)
    tenant_db_config      = data.get("tenant_db_config", {})
    db_name               = data.get("db_name", {})
    progress_tracker_id     = data.get("progress_tracker_id", {})
    delayed_days       = data.get("delayed_days", 3)
    ## setting up the date variables for kore sync api calls
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")    
    today = datetime.now()
    # Get data from 7 days ago to yesterday (more likely to have usage data)
    start_date_obj = today - timedelta(days=delayed_days)
    end_date_obj = today - timedelta(days=delayed_days)
    start_date = start_date_obj.strftime("%Y-%m-%dT00:00:00Z")
    end_date = end_date_obj.strftime("%Y-%m-%dT23:59:59Z")
    data['start_date'] = start_date
    data['end_date'] = end_date
    data["usage_date"] = start_date_obj.strftime("%Y-%m-%d %H:%M:%S")  # Remove 'T' and 'Z'
    data["created_by"] = username
    total_records_processed = 0 
    module_name = "Carrier Sync"
    ### for tracking different stages in the Carrier Sync
    staging_table_cleanup = False
    devices_fetch = False
    device_usages_fetch = False
    staging_to_main_tables_sync = False
    device_usage_sync = False
    history_tables_sync = False
    email_trigger = False
    carrier_rate_plans_fetch = False
    processed_records = 0 
    logging.info(f"###run_kore_sync start_date: {start_date} and end_date: {end_date} to fetch the data for kore carrier sync")
    ### extacting carrier specific details from environment variables
    base_url = data.get("get_devices_url_method", {}).get("url")
    token_url = data.get("custom_url1", {}).get("url")
    logging.info(f"### run_kore_sync base_url : {base_url} and token_url : {token_url}")

    #Step 1 :database connection
    try:
        tenant_database = DB(db_name, **tenant_db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_db_config)
    except Exception as e:
        logging.error(f"### run_kore_sync and {tenant_name} DB connection error: %s", e)
        return {"flag":False,"message": "DB connection failed in run_kore_sync", "details": str(e)}
    
    ### Step 2 : send email for initiating sync 
    sync_data = {
        "Sync Type": "Daily Sync",    
        "Partner Name": tenant_name,    
        "Carrier Name": service_provider_name,    
        "Start Time": start_time_dt.strftime("%m-%d-%Y %H:%M:%S"),  
        "System / Job Name": "Scheduler"
    }
    trigger_sync_email(template_name="Sync Initiated",subject=f"Sync Initiated - {tenant_name} - {service_provider_name} - Daily Sync - {start_date_obj.strftime('%m-%d-%Y')}",
    data_dict=sync_data,tenant_name=tenant_name,log_prefix="### run_kore_sync Sync Initiated")
    
    #Progress Tracking: Update progress tracker - Staging cleanup started
    try:
        update_progress_tracker(progress_tracker_id, current_status="Staging cleanup started", status="In Progress", common_utils_database=common_utils_database, action="update", now=now, progress=10, data=data)
        logging.info(f"### run_kore_sync devices and {tenant_name} Staging cleanup Started")
    except Exception as e:
        logging.exception(f"### run_kore_sync devices and {tenant_name} Error updating progress tracker: {e}")
    
    try:
        ##Step 3:Cleaning the staging tables
        cleanup_response=clean_staging_table(tenant_database,["kore_carrier_rate_plan_staging","kore_carrier_sync_staging"], username)
        logging.info(f"### run_kore_sync devices and {tenant_name} cleanup_response: {cleanup_response}")
        if all(result["flag"] for result in cleanup_response.values()):
            staging_table_cleanup = True
            logging.info("### run_kore_sync Staging cleanup successful")
            cleanup_message="Successful"
            cleanup_progress=15
            cleanup_status="In Progress"
        else:
            logging.error("#### run_kore_sync Staging cleanup failed")
            cleanup_message="Failed"
            cleanup_progress=100
            cleanup_status="Failed"
        logging.info(f"### run_kore_sync devices and {tenant_name} Staging cleanup {cleanup_message}: {cleanup_response.get('message')}")
        #Progress Tracking: Update progress tracker - Staging cleanup successful or failed based on the cleanup response
        try:
            update_progress_tracker(progress_tracker_id, current_status=f"Staging cleanup {cleanup_message}", status=cleanup_status, common_utils_database=common_utils_database, action="update", now=now, progress=cleanup_progress, data=data)
            if cleanup_message == "Failed":
                raise Exception("Staging tables cleanup failed")
            logging.info(f"### run_kore_sync devices and {tenant_name} Staging cleanup {cleanup_message}")
        except Exception as e:
            logging.exception(f"### run_kore_sync devices and {tenant_name} Error updating progress tracker: {e}") 
            raise Exception("Staging tables cleanup failed")
            # return {"flag":False,"message": "Staging cleanup failed in run_kore_sync", "details": cleanup_response.get("details")}
        ##Step 4: Fetch Integration Details
        integration_response = fetch_integration_details(tenant_database,integration_id,tenant_name,tenant_id)
        if not integration_response.get("flag"):
            try:
                update_progress_tracker(progress_tracker_id, current_status=f"Integration details fetch failed", status="Failed", common_utils_database=common_utils_database, action="update", now=now, progress=100, data=data)
                logging.info(f"### run_kore_sync devices and {tenant_name}  Integration details fetch failed")
            except Exception as e:
                logging.exception(f"### run_kore_sync devices and {tenant_name} Error updating progress tracker: {e}")
                return {"flag":False,"message": "Integration details fetch failed in run_kore_sync", "details": integration_response.get("details")}
            return integration_response
        ##Extract required integration details for authentication and API calls
        integration_details = integration_response.get("integration_details", [])
        # Take first record (since query returns 1 row)
        auth_data = integration_details[0]
        # Map DB columns to required variables
        email = auth_data.get("token_variable_name")
        client_id = auth_data.get("oauth2_client_id")
        client_secret = auth_data.get("oauth2_client_secret")
        api_key = auth_data.get("token_value")
        # Logging for verification (do not log secrets in production!)
        logging.info(f"### Integration Auth Loaded for {tenant_name} | Email={email} | client_id : {client_id} | client_secret : {client_secret} | api_key : {api_key}")
        # Optional fallback if any value missing
        if not all([email, client_id, client_secret, api_key]):
            return {
                "flag": False,
                "message": "Missing required authentication values in integration_authentication table"
            }
        try:
            update_progress_tracker(progress_tracker_id, current_status=f"Integration details fetched", status="In Progress", common_utils_database=common_utils_database, action="update", now=now, progress=20, data=data)
            logging.info(f"### run_kore_sync devices and {tenant_name} Integration details fetched")
        except Exception as e:
            logging.exception(f"### run_kore_sync devices and {tenant_name} Error updating progress tracker: {e}")
            return {"flag":False,"message": "Integration details fetch failed in run_kore_sync", "details": integration_response.get("message")}
        
        ##Step 5: Billing Period Logic: Implement billing period logic to determine the billing period for which the sync should be performed based on the current date and the provided bill_period value.
        billing_info = get_or_create_billing_period(
            tenant_id=tenant_id,
            service_provider_id=service_provider_id,
            service_provider_name=service_provider_name,
            tenant_database=tenant_database,
            common_utils_database=common_utils_database,
            progress_tracker_id=progress_tracker_id,
            billing_cycle_day=24,
            force_end_of_day=True,
            data=data
        )
        billing_period_id = billing_info["billing_period_id"]
        data["billing_period_id"] = billing_period_id
        billing_cycle_start_date = billing_info["billing_period_details"]["billing_cycle_start_date"]
        billing_cycle_end_date = billing_info["billing_period_details"]["billing_cycle_end_date"]
        try:
            update_progress_tracker(progress_tracker_id,current_status="Fetching device details and usage data from carrier",status="In Progress",common_utils_database=common_utils_database,action="update",now=now,progress=25,data=data)
        except Exception as e:
            logging.exception(f"### run_kore_sync devices and {tenant_name} Error updating progress tracker: {e}")
        ### Step 6 : Fetching the Access and Refresh Tokens for authentication and API calls which are necessary for API calls
        access_token = get_access_token(client_id, client_secret, token_url)
        final_headers = {
            "Authorization": f"Bearer {access_token}",
            'Accept': 'application/json',
            'x-api-key': api_key
        }
        ### Step 7: get account_id
        account_id = get_account_id(base_url, email, access_token, api_key)
        if not account_id and not access_token:
            logging.info(f"### run_kore_sync tenant : {tenant_name} failed to obtained account ID")
            return {"flag":False,'Message':'failed while fetching account id'}
        try:
            logging.info(f"### run_kore_sync tenant : {tenant_name} Successfully obtained access token and account ID")
            update_progress_tracker(progress_tracker_id,current_status="Fetching Access token and AccountID successfully",status="In Progress",common_utils_database=common_utils_database,action="update",now=now,progress=45,data=data)
        except Exception as e:
            logging.exception(f"### run_kore_sync devices and {tenant_name} Error updating progress tracker: {e}")
 
        #Step 8: Fetch Carrier Rate Plan Mapping: Fetch carrier rate plan mapping or reference data from the tenant database that will be used for enriching the device details with plan information.
        carrier_rate_plans_insertion_response = fetch_and_insert_carrier_rate_plans(tenant_database,base_url,account_id,final_headers,username,data)
        if not carrier_rate_plans_insertion_response["flag"]:
            logging.error(f"### run_kore_sync tenant : {tenant_name} Rate Plan processing failed: {carrier_rate_plans_insertion_response['message']} {carrier_rate_plans_insertion_response.get('details')}")
        else:
            carrier_rate_plans_fetch = True
            logging.info(f"### run_kore_sync tenant : {tenant_name} Plan processing success: {carrier_rate_plans_insertion_response['message']}")
        try:
            logging.info(f"### run_kore_sync tenant : {tenant_name} Successfully fetched and inserted carrier rate plans into staging table")
            update_progress_tracker(progress_tracker_id,current_status="Successfully fetched and inserted carrier rate plans into staging table",status="In Progress",common_utils_database=common_utils_database,action="update",now=now,progress=50,data=data)
        except Exception as e:
            logging.exception(f"### run_kore_sync devices and {tenant_name} Error updating progress tracker: {e}")
        ##Step 9:fetch_all_subscriptions: Fetch all device subscriptions from the carrier API using the obtained access token and account ID. Implement pagination to ensure all subscriptions are retrieved, especially for accounts with a large number of devices.
        all_subscriptions_response = fetch_all_subscriptions(base_url, account_id, final_headers, max_page_item=1000, max_retries=3, max_workers=3, timeout=30)
        all_subscriptions = all_subscriptions_response.get("subscriptions",[])
        if not all_subscriptions_response["flag"]:
            logging.error(f"### run_kore_sync tenant : {tenant_name} Fetching subscriptions failed: {all_subscriptions_response.get('error_message',"Unknown Error")}")
            current_status ="Fetching Devices Failed"
        else:
            devices_fetch = True
            logging.info(f"### run_kore_sync tenant : {tenant_name} Fetching subscriptions successful: {len(all_subscriptions)}")
            current_status ="Successfully Fetched All Devices"
        try:
            logging.info(f"### run_kore_sync tenant : {tenant_name} updating the progress tracker for fetch_all_subscriptions")
            update_progress_tracker(progress_tracker_id,current_status=current_status,total_records_synced = len(all_subscriptions),status="In Progress",common_utils_database=common_utils_database,action="update",now=now,progress=60,data=data)
            if current_status =="Fetching Devices Failed":
                raise Exception("Fetching Devices Failed")
            
        except Exception as e:
            logging.exception(f"### run_kore_sync devices and {tenant_name} Error updating progress tracker: {e}")
            raise Exception("Fetching Devices Failed")   
            
        ##step 10: Fectch Carrier Plan Name and usage for each sim using parallel processing
        fetch_device_profile_and_usage_response = fetch_device_profile_and_usage(all_subscriptions,base_url,final_headers,account_id , data ,tenant_database)
        processed_records = fetch_device_profile_and_usage_response.get("processed_records")
        if not fetch_device_profile_and_usage_response["flag"]:
            logging.error(f"### run_kore_sync tenant : {tenant_name} failed Fetching profile and usage details and processed_records : {len(processed_records)}")
            current_status ="Failed Fetching Profile and Usage details for all Devices" 
        else:
            device_usages_fetch = True
            logging.info(f"### run_kore_sync tenant : {tenant_name} Successfully Fetched profile and usage details and processed records : {len(processed_records)}")
            current_status ="Successfully Fetched Profile and Usage details for all Devices" 
        try:
            logging.info(f"### run_kore_sync tenant : {tenant_name} updating the progress tracker for fetch_device_profile_and_usage")
            update_progress_tracker(progress_tracker_id,current_status=current_status, total_records_synced = len(processed_records),status="In Progress",common_utils_database=common_utils_database,action="update",now=now,progress=70,data=data)
            if current_status =="Failed Fetching Profile and Usage details for all Devices":
                raise Exception("Failed Fetching Profile and Usage details for all Devices")
        except Exception as e:
            logging.exception(f"### run_kore_sync devices and {tenant_name} Error updating progress tracker: {e}")
            raise Exception("Failed Fetching Profile and Usage details for all Devices")
            
        '''Step 11: Sync to Main Tables: After successfully inserting the enriched device details into the staging table, 
                    execute a stored procedure or a series of SQL queries to transform and load the data from the staging tables 
                    into the main AMOP tables. This step may involve complex transformations, data validations, and handling of 
                    duplicates or conflicts based on the business rules.
        '''
        sync_main_table_response = sync_staging_to_main(data, tenant_database, common_utils_database,progress_tracker_id)
        if not sync_main_table_response["flag"]:
            logging.error(f"### run_kore_sync tenant : {tenant_name} failed syncing data from staging to main tables: {sync_main_table_response.get('message')}")
            current_status ="Failed syncing data from staging to main tables"
        else:
            staging_to_main_tables_sync = True
            logging.info(f"### run_kore_sync tenant : {tenant_name} Successfully synced data from staging to main tables")
            current_status ="Successfully synced data from staging to main tables"
        sync_summary = sync_main_table_response.get("summary", {})
        total_records_processed = sync_summary.get("total_staging_records", 0)
        inserted_count = sync_summary.get("new_devices_inserted", 0)
        updated_count = sync_summary.get("existing_devices_updated", 0)    
        try:
            logging.info(f"### run_kore_sync tenant : {tenant_name} updating the progress tracker for sync_staging_to_main")
            update_progress_tracker(progress_tracker_id,current_status=current_status,status="In Progress",common_utils_database=common_utils_database,action="update",now=now,progress=80,data=data)
            if current_status =="Failed syncing data from staging to main tables":
                raise Exception("Failed syncing data from staging to main tables")
        except Exception as e:
            logging.exception(f"### run_kore_sync devices and {tenant_name} Error updating progress tracker: {e}")
            raise Exception("Failed syncing data from staging to main tables")

        ##Step 12:Inserting or Updating the device_usage table with is_active:True Sims
        device_usage_insertion_response=update_device_usage_table(data,tenant_database,common_utils_database)
        if not device_usage_insertion_response.get("flag"):
            logging.error(f"### run_kore_sync tenant : {tenant_name} failed syncing data into Device Usage Table : {sync_main_table_response.get('message')}")
            current_status ="Failed to Update or Insert in Device Usage Table"
        else:
            device_usage_sync = True
            logging.info(f"### run_kore_sync tenant : {tenant_name} Successfully Update or Inserted in Device Usage Table")
            current_status ="Successfully Update or Inserted in Device Usage Table"
        ##Updating the Device Usage Progress Tracker
        try:
            logging.info(f"### run_kore_sync tenant : {tenant_name} updating the progress tracker for update_device_usage_table")
            update_progress_tracker(progress_tracker_id,current_status=current_status,status="In Progress",common_utils_database=common_utils_database,action="update",now=now,progress=85,data=data)
            if current_status =="Failed to Update or Insert in Device Usage Table":
                raise Exception("Failed to Update or Insert in Device Usage Table")
        except Exception as e:
            logging.exception(f"### run_kore_sync devices and {tenant_name} Error updating progress tracker: {e}")
            raise Exception("Failed to Update or Insert in Device Usage Table")

        ##Step 13: Updating or Inserting the data in History Table
        history_table_updates_response = history_table_updates(data,tenant_database,common_utils_database)
        if not history_table_updates_response.get("flag"):
            logging.error(f"### run_kore_sync tenant : {tenant_name} failed Update or Insert into History Tables: {sync_main_table_response.get('message')}")
            current_status ="Failed to Update or Insert in History Tables"
        else:
            history_tables_sync = True
            logging.info(f"### run_kore_sync tenant : {tenant_name} Successfully Updated or Inserted data into History Tables")
            current_status ="Successfully Updated or Inserted data into History Tables"
        ##Updating the Device Usage Progress Tracker
        try:
            logging.info(f"### run_kore_sync tenant : {tenant_name} updating the progress tracker for history_table_updates_response")
            update_progress_tracker(progress_tracker_id,current_status=current_status,status="In Progress",common_utils_database=common_utils_database,action="update",now=now,progress=90,data=data)
            if current_status =="Failed to Update or Insert in History Tables":
                raise Exception("Failed to Update or Insert in History Tables")
        except Exception as e:
            logging.exception(f"### run_kore_sync devices and {tenant_name} Error updating progress tracker: {e}")
            raise Exception("Failed to Update or Insert in History Tables")
        ### step 14 : getting inventory details to send sync details in email in Sync Completion case 
        # Fetch Query from the database based on the module name -> to get counts per status and total usage
        module_query_df = common_utils_database.get_data(
            "export_queries", {"module_name": module_name}
        )
        ##checking the dataframe is empty or not
        if module_query_df.empty:
            return {"flag": False,"message": f"No query found for module name: {module_name}"}
        # Extract the query string from the DataFrame
        query = module_query_df.iloc[0]["module_query"]
        if not query:
            return {"flag": False, "message": f"Unknown module name : {module_name} for tenant :{tenant_name}"}
        # Execute the query
        result = tenant_database.execute_query(query, params=[service_provider_id])
        status_variables = {}
        aggregate_usage_bytes = 0
        total_devices = 0
        total_devices_with_usage = 0

        # Map result to variables
        if result is not None and not result.empty:
            for _, row in result.iterrows():
                status_name = row['sim_status'].lower()
                count = row['device_count']
                usage = row['total_usage_bytes']
                devices_with_usage_count = row['devices_with_usage_count']
                
                # Create a dynamic key in the dictionary for each status
                status_variables[f"{status_name}_devices"] = count
                # Add to totals
                total_devices += count
                total_devices_with_usage += devices_with_usage_count
                aggregate_usage_bytes += usage

        ### step 15 : sending email in sync sucessful case  
        # First, create a statuses dictionary that the replace_placeholders_with_table function expects
        statuses_dict = {}
        for status_key, count in status_variables.items():
            # Extract just the status name (remove '_devices' suffix)
            status_name = status_key.replace('_devices', '').title()
            statuses_dict[status_name] = count
        
        # Construct dynamic sync summary with the special 'statuses' key
        end_time_ts = time.time()
        end_time_dt = datetime.now()
        duration_seconds = int(end_time_ts - start_time_ts)
        duration_mm_ss = f"{duration_seconds // 60}:{duration_seconds % 60:02d}"
        sync_summary_data = {
            "Partner Name": tenant_name,
            "Carrier Name": service_provider_name,
            "Sync Timeline": f"{start_time_dt.strftime('%m-%d-%Y %H:%M:%S')} - {end_time_dt.strftime('%m-%d-%Y %H:%M:%S')} (Duration: {duration_mm_ss} minutes)",
            "Device Sync Status": "Success",
            "Total Devices": total_devices,  # All devices (including those with zero usage)
            "Usage Sync Status": "Success",
            "Bill Cycle": f"{billing_cycle_start_date.strftime('%m-%d-%Y %H:%M:%S')} - {billing_cycle_end_date.strftime('%m-%d-%Y %H:%M:%S')}",
            "Devices with Usage": total_devices_with_usage,  # Only devices with usage > 0
            "Aggregate Usage": f"{round(aggregate_usage_bytes / (1024 * 1024), 2):,}",
            "Error Description": "NA",
            "statuses": statuses_dict  # This is what the replace_placeholders_with_table function looks for
        }
        logging.info(f"### run_kore_sync sync_summary_data : {sync_summary_data}")

        email_response = trigger_sync_email(
            template_name="Sync Completed",
            subject=f"{tenant_name} - {service_provider_name} - Device and Usage Sync Summary - {start_date_obj.strftime('%m-%d-%Y')}",
            data_dict=sync_summary_data,
            tenant_name=tenant_name,
            log_prefix="### run_kore_sync Sync Completed"
        )
        # Update current_status based on email response
        if not email_response["flag"]:
            current_status = "Sync Completed but Email Notification Failed"
        else:
            current_status = "Sync Completed & Email sent successfully"
            email_trigger = True
        ## Updating the Sync Completion Email Trigger in Progress Tracker
        try:
            logging.info(f"### run_kore_sync tenant : {tenant_name} updating the progress tracker for history_table_updates_response")
            update_progress_tracker(progress_tracker_id,current_status=current_status,status="Completed",common_utils_database=common_utils_database,action="update",now=now,progress=100,data=data)
            if current_status =="Sync Completion Email sending failed":
                raise Exception("Sync Completion Email sending failed")
        except Exception as e:
            logging.exception(f"### run_kore_sync devices and {tenant_name} Error updating progress tracker: {e}") 
            raise Exception("Sync Completion Email sending failed")   

        final_response = {"flag":True,"message": "Sync completed successfully" , "processed_records":len(processed_records)}
        ## step 16 : auditing the final response 
        try :
            logging.info(f"### run_kore_sync audit in success case")
            audit_comment = {"total_staging_records": total_records_processed,"new_devices_inserted": inserted_count,"existing_devices_updated": updated_count}
            audit_data_user_actions = {
                "service_name": "run_kore_sync",
                "created_date": data.get("request_received_at"),
                "created_by": data.get("username", ""),
                "status": "Success",
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": json.dumps(audit_comment),
                "module_name": "Carrier Sync",
                "request_received_at": data.get("request_received_at"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e :
           logging.error(f"### run_kore_sync auditing failed in success case :{e}") 
        return final_response
    except Exception as e:
        logging.exception(f"run_kore_sync and {tenant_name} Error during carrier sync {str(e)}")
        # Log the error
        error_message = f"Error during {service_provider_name} carrier sync : {str(e)}"
        
        ### step 17 : sending email in Error case : 
        sync_stages = {
            "Staging Table Cleanup": staging_table_cleanup,
            "Carrier Rate Plans Fetch":carrier_rate_plans_fetch,
            "Devices Fetch": devices_fetch,
            "Device Usages Fetch": device_usages_fetch,
            "Staging → Main Tables Sync": staging_to_main_tables_sync,
            "Device Usage Sync": device_usage_sync,
            "History Tables Sync": history_tables_sync,
            "Sync Completion Email Trigger": email_trigger
        }
         # Get the first stage that failed
        failed_stage = next((name for name, flag in sync_stages.items() if not flag), "Unknown")
        # Map failed stage to a meaningful error category
        stage_error_mapping = {
            "Staging Table Cleanup": "Issue during Staging Tables Cleanup",
            "Carrier Rate Plans Fetch": "Rate Plan Fetch Processing Issue",
            "Devices Fetch": "Devices Fetch Issue",
            "Device Usages Fetch": "Devices Usage Processing Issue",
            "Staging → Main Tables Sync": "Staging to Main Table Sync Issue",
            "Device Usage Sync": "Devices Usage Table Update Issue",
            "History Tables Sync": "History Tables Update Issue",
            "Sync Completion Email Trigger": "Email Trigger Issue",
            "Unknown": "Unknown Issue Encountered"
        }
        device_stages = {"Staging Table Cleanup","Carrier Rate Plans Fetch","Devices Fetch"}
        usage_stages = {"Device Usages Fetch","Staging → Main Tables Sync","Device Usage Sync","History Tables Sync","Sync Completion Email Trigger"}
        # Assign Data Type dynamically
        if failed_stage in device_stages:
            data_type = "Device"
        elif failed_stage in usage_stages:
            data_type = "Usage"
        else:
            data_type = "Device and Usage"

        error_type = stage_error_mapping.get(failed_stage, "Unknown Error")
        error_message = str(e)
        end_time_ts = time.time()
        end_time_dt = datetime.now()
        duration_seconds = int(end_time_ts - start_time_ts)
        duration_mm_ss = f"{duration_seconds // 60}:{duration_seconds % 60:02d}"
        sync_failed_data = {
            "Sync Type": "Daily Sync",
            "Sync Timeline": f"{start_time_dt.strftime('%m-%d-%Y %H:%M:%S')} - {end_time_dt.strftime('%m-%d-%Y %H:%M:%S')} (Duration: {duration_mm_ss} minutes)",
            "Partner Name": tenant_name,
            "Carrier Name": service_provider_name,
            "Start Time": start_time_dt.strftime('%m-%d-%Y %H:%M:%S'),
            "End Time": end_time_dt.strftime('%m-%d-%Y %H:%M:%S'),
            "Job ID": "Kore_Container",
            "Error Category": error_type,
            "Error Message": error_message,
            "Stage of Failure": failed_stage,
            "Impacted Count": total_records_processed if total_records_processed != 0 else "N/A",
            "Data Type": data_type,
            "Partial Sync": "Yes" if total_records_processed != 0 else "No"
        }
        email_response = trigger_sync_email(
            template_name="Sync Error",
            subject=f"Sync Failed - {tenant_name} - {service_provider_name} - Daily Sync - {start_date_obj.strftime('%m-%d-%Y')}",
            data_dict=sync_failed_data,
            tenant_name=tenant_name,
            log_prefix="### run_kore_sync Failed"
        )
        # Update current_status based on email response
        if not email_response["flag"]:
            current_status = "Sync failed. Error Email delivery was unsuccessful."
        else:
            current_status = "Sync failed. Error Email was sent successfully."
            email_trigger = True
        ## Updating the Sync Completion Email Trigger in Progress Tracker
        try:
            logging.info(f"### run_kore_sync tenant : {tenant_name} updating the progress tracker for Sync failed & Error Email delivery")
            update_progress_tracker(progress_tracker_id,current_status=current_status,status="Failed",common_utils_database=common_utils_database,action="update",now=now,progress=100,data=data)
        except Exception as e:
            logging.exception(f"### run_kore_sync devices and {tenant_name} Error updating progress tracker: {e}")  

        # Prepare error response
        response = {
            "flag": False,
            "message": error_message
        }
        try:
            # step 18 :Log error to database
            error_data = {
                "service_name": "run_kore_sync",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during carrier sync for tenant {tenant_name} : {str(e)}",
                "module_name": "Carrier Sync",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### run_kore_sync and {tenant_name} Exception in logging error data to DB: {e}")
        return response


##function to update progress tracker
def update_progress_tracker(
    progress_tracker_id,
    current_status=None,total_records_synced = None ,status=None,
    common_utils_database=None,
    action="insert",now=None,
    progress=0,
    data=None
):
    """
    Insert or update carrier sync audit records.

    Args:
        common_utils_database (DB): Common utils DB connection
        action (str): "insert" or "update"
        audit_id (int): Required for update
        data (dict): Audit data payload

    Returns:
        int | bool
            - insert → returns audit_id
            - update → returns True
    """
    try:
        # INSERT (Sync Start)
        if action == "insert":
            insert_data = {
                "tenant_name": data.get("tenant_name"),
                "service_provider_name": data.get("service_provider_name"),
                "sync_start_time": now,
                "sync_end_time": None,
                "estimated_time": data.get("estimated_time"),
                "execution_duration": None,
                "total_records_synced": 0,
                "current_status": current_status or data.get("current_status", "Sync started"),
                "status": status or data.get("status", "In Progress"),
                "error_code": None,
                "error_message": None,
                "attempt_count": data.get("attempt_count", 0),
                "triggered_by": f"{data.get('service_provider_name')}_{data.get('tenant_name')}_{data.get('username')}",
                "sync_type": data.get("sync_type"),
                "created_by": f"{data.get('service_provider_name')}_{data.get('tenant_name')}_{data.get('username')}",
                "modified_by": f"{data.get('service_provider_name')}_{data.get('tenant_name')}_{data.get('username')}",
                "sync_run_count": data.get("sync_run_count", 1),
                "progress":progress or 0
            }
            progress_tracker_id = common_utils_database.insert_data(insert_data,"carrier_sync_audit_logs")
            logging.info(
                f"Carrier sync audit inserted | id={progress_tracker_id} | status={insert_data['current_status']}"
            )
            return {"flag": True, "message": "Progress tracker inserted successfully", "progress_tracker_id": progress_tracker_id}
        # UPDATE (Progress / Completion / Failure)
        elif action == "update":
            update_data = {
                "current_status": current_status or data.get("current_status"),
                "status": status or data.get("status"),
                "total_records_synced": total_records_synced or 0,
                "attempt_count": data.get("attempt_count") or 0,
                "error_code": data.get("error_code"),
                "error_message": data.get("error_message"),
                "sync_end_time": data.get("sync_end_time"),
                "execution_duration": data.get("execution_duration"),
                "modified_by": f"{data.get('service_provider_name')}_{data.get('tenant_name')}_{data.get('username')}",
                "progress": progress or 0
            }
            # remove None values (VERY important)
            update_data = {k: v for k, v in update_data.items() if v is not None}
            common_utils_database.update_dict(
                "carrier_sync_audit_logs",
                update_data,
                and_conditions={"id": progress_tracker_id}
            )
            logging.info(
                f"Carrier sync audit updated | id={progress_tracker_id} | status={update_data.get('current_status')}"
            )
            return {"flag": True, "message": "Progress tracker updated successfully"}
    except Exception as e:
        logging.exception("Error in update_progress_tracker")
        return {"flag": False, "message": "Error in update_progress_tracker", "details": str(e)}
    
##function to clean staging table
def clean_staging_table(tenant_database, table_names, username):
    """
    Cleans one or more staging tables in the tenant database.

    Args:
        tenant_database (DB): Database connection object for tenant
        table_names (str or list): Single table name or list of table names
        username (str): User performing the cleanup

    Returns:
        dict: Cleanup results for each table
    """
    results = {}
    # Normalize to list
    if isinstance(table_names, str):
        table_names = [table_names]

    for table in table_names:
        try:
            status = tenant_database.delete_data(table , reset_sequence=True)
            logging.info(f"Staging table {table} cleaned successfully by {username}")

            results[table] = {
                "flag": True,
                "status": status,
                "message": f"Staging table {table} cleaned successfully"
            }

        except Exception as e:
            logging.exception(f"Error cleaning staging table {table}: {e}")
            results[table] = {
                "flag": False,
                "status": False,
                "message": f"Error cleaning staging table {table}",
                "details": str(e)
            }
    return results


##function to fetch integration details
def fetch_integration_details(
    tenant_database,
    integration_id,
    tenant_name,tenant_id
):
    """
    Fetch active integration authentication details for a given integration ID.

    Args:
        tenant_database (DB): Tenant database connection
        integration_id (str): Integration identifier
        tenant_name (str): Tenant name (for logging)
    Returns:
        dict:
            {
                "flag": True,
                "data": [integration_details]
            }
            OR
            {
                "flag": False,
                "message": "<error message>"
            }
    """
    try:
        ##Query the tenant database for active integration authentication details matching the provided integration_id and tenant_id
        integration_df = tenant_database.get_data(
            "integration_authentication",
            {
                "is_active": True,
                "integration_id": integration_id,
                "tenant_id": tenant_id
            }
        )
        logging.info(
            f"### run_kore_sync devices and {tenant_name} "
            f"integration_details_dataframe: {integration_df}"
        )
        if integration_df.empty:
            message = "No active integration found for the given integration_id"
            logging.error(
                f"### run_kore_sync devices and {tenant_name} {message}"
            )
            return {"flag": False, "message": message}
        integration_details = integration_df.to_dict(orient="records")

        logging.info(
            f"### run_kore_sync devices and {tenant_name} "
            f"integration_details: {integration_details}"
        )
        return {"flag": True, "integration_details": integration_details}
    except Exception as e:
        logging.exception(
            f"### run_kore_sync devices and {tenant_name} "
            f"Error fetching integration details: {e}"
        )
        return {"flag": False, "message": str(e)}
        
##function to get or create billing period
def get_or_create_billing_period(
    tenant_id,
    service_provider_id,
    service_provider_name,
    tenant_database,
    common_utils_database,
    progress_tracker_id,  # Changed from audit_id for consistency
    billing_cycle_day,
    force_end_of_day=True,
    start_hour=0,
    start_minute=0,
    start_second=0,
    created_by="system",
    data=None  # Added data parameter
):
    """
    Determines or creates a billing period based on input data.start_date.
    If start_date is missing or invalid, it falls back to today's UTC date.
    """
    logging.info(f"###run_kore_sync get_or_create_billing_period for tenant_id={tenant_id} and service_provider_id={service_provider_id} started.")
    try:
        # 1️⃣ Determine sync_date
        sync_date = None

        if data and data.get("start_date"):
            start_date_str = data["start_date"]
            try:
                # Extract date portion (before 'T')
                date_part = start_date_str.split("T")[0]
                sync_date = datetime.strptime(date_part, "%Y-%m-%d").date()
                logging.info(f"###run_kore_sync Derived sync_date from start_date: {sync_date}")
            except Exception:
                logging.warning(
                    f"###run_kore_sync Invalid start_date format ({start_date_str}). "
                    f"Falling back to today's UTC date."
                )

        # Fallback to today's UTC date if start_date was missing/invalid
        if not sync_date:
            sync_date = datetime.utcnow().date()
            logging.info(f"### Using fallback sync_date: {sync_date}")

        today_str = sync_date.strftime("%Y-%m-%d")
        # 2️⃣ Check existing billing period
        query = """
            SELECT id,billing_cycle_start_date, billing_cycle_end_date
            FROM billing_period
            WHERE tenant_id = %s
              AND service_provider_id = %s
              AND billing_cycle_start_date <= %s
              AND billing_cycle_end_date >= %s
              AND is_deleted = false
            LIMIT 1
        """
        result = tenant_database.execute_query(
            query,
            params=[tenant_id, service_provider_id, today_str, today_str]
        )

        logging.info(f"###run_kore_sync Existing billing_period query result: {result}")

        if result is not False and not result.empty:
            billing_period_id = result.iloc[0]["id"]

            if data:
                data["current_status"] = "Billing period determined"
                ##function to update progress tracker
                update_progress_tracker(
                    progress_tracker_id=progress_tracker_id,
                    common_utils_database=common_utils_database,
                    action="update",
                    progress=30,
                    data=data
                )
            logging.info(
                f"Billing period reused | billing_period_id={billing_period_id}"
            )
            response = { 
                "flag": True,
                "billing_period_id": billing_period_id,
                "is_new_period": False,
                "billing_period_details":{"billing_cycle_start_date":result.iloc[0]["billing_cycle_start_date"] , "billing_cycle_end_date":result.iloc[0]["billing_cycle_end_date"]}
            }
            return response

        # 3️⃣ Compute new billing period boundaries
        year = sync_date.year
        month = sync_date.month

        if sync_date.day >= billing_cycle_day:
            start_year = year
            start_month = month
        else:
            start_month = month - 1 or 12
            start_year = year if month > 1 else year - 1

        billing_cycle_start_date = datetime(
            start_year, start_month, billing_cycle_day,
            start_hour, start_minute, start_second
        )

        # Next cycle start
        if start_month == 12:
            end_year = start_year + 1
            end_month = 1
        else:
            end_year = start_year
            end_month = start_month + 1

        next_cycle_start = datetime(
            end_year, end_month, billing_cycle_day,
            start_hour, start_minute, start_second
        )

        billing_cycle_end_date = (
            next_cycle_start.replace(hour=23, minute=59, second=59)
            if force_end_of_day else next_cycle_start
        )

        # 4️ Insert new billing period
        billing_data = {
            "tenant_id": tenant_id,
            "service_provider_id": service_provider_id,
            "service_provider": service_provider_name,
            "bill_year": billing_cycle_start_date.year,
            "bill_month": billing_cycle_start_date.month,
            "billing_cycle_start_date": billing_cycle_start_date,
            "billing_cycle_end_date": billing_cycle_end_date,
            "billing_period_status_id": 1,
            "is_active": True,
            "is_deleted": False,
            "created_by": created_by,
            "modified_by": created_by,
        }

        logging.info(f"###run_kore_sync billing_data: {billing_data}")

        billing_period_id = tenant_database.insert_data(
            billing_data,
            "billing_period"
        )
        logging.info(
            f"###run_kore_sync New billing period created | billing_period_id={billing_period_id}"
        )
        # 5. Update progress tracker
        if data:  # Check if data is provided
            data["current_status"] = "Billing period determined"
            update_progress_tracker(
                progress_tracker_id=progress_tracker_id,
                common_utils_database=common_utils_database,
                action="update",
                progress=30,
                data=data
            )

        response = {
            "flag": True,
            "billing_period_id": billing_period_id,
            "is_new_period": True,
            "billing_period_details":{"billing_cycle_start_date": billing_cycle_start_date,"billing_cycle_end_date": billing_cycle_end_date}
        }
        return response

    except Exception as e:
        logging.exception("###run_kore_sync Error determining billing period")
        response = {
            "flag": False,
            "message": "Error determining billing period",
            "details": str(e)
        }
        return response
        
##Kore API Authentication - Get Access Token    
def get_access_token(client_id, client_secret, token_url):
    """
    Generates an access token using the client credentials flow.
    Args:
        client_id (str): OAuth client ID provided by the carrier.
        client_secret (str): OAuth client secret key.
        token_url (str): Token API endpoint URL.
    Returns:
        str | None: Access token string if successful, otherwise None.
    """
    payload = {
        "grant_type": "client_credentials",
        "client_id": client_id,
        "client_secret": client_secret
    }
    try:
        response = requests.post(token_url, data=payload)
        response.raise_for_status()
        token_data = response.json()
        access_token = token_data.get("access_token")
        if access_token:
            logging.info(f"### Access Token Generated Successfully Access Token: {access_token}")
            return access_token
        else:
            logging.error(f"### Error: Access token not found in response token_data : {token_data}.")
            return None
    except requests.exceptions.RequestException as e:
        logging.error(f"### Error fetching access token: {e}")
        return None

##function to get account id using email
def get_account_id(base_url, email, access_token, api_key=None):
    """
    Fetches the Kore account ID linked to the given email.

    Args:
        base_url (str): Kore carrier base API URL.
        email (str): Email address used to identify the account.
        access_token (str): OAuth2 bearer token for authentication.
        api_key (str, optional): API key header value if Kore requires it.

    Returns:
        str | None: Account ID if found, otherwise None.
    """
    url = f"{base_url}/v1/accounts?email={email}"
    headers = {
        'Accept': 'application/json',
        'Authorization': f"Bearer {access_token}"
    }
    if api_key:
        headers['x-api-key'] = api_key  # Include API Key if required
    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()
        account_data = response.json()

        # Extract account-id from the list inside 'account'
        accounts = account_data.get('account', [])
        if accounts and isinstance(accounts, list):
            account_id = accounts[0].get('account-id')  # Get the first account's account-id
            logging.info(f"### Account Details account_data :{account_data}")
            return account_id
        else:
            logging.error("### Error: No accounts found or invalid response structure.")
            return None
    except requests.exceptions.RequestException as e:
        logging.error(f"### Error fetching account ID: {e}")
        logging.error(f"### Error Response: {response.text}")  # Debugging: Log the raw response
        return None
            

def fetch_and_insert_carrier_rate_plans(tenant_database,
                                    base_url,account_id,
                                    headers,username,data={},
                                    table_name="kore_carrier_rate_plan_staging"):

    """
    Fetches plans and inserts into the staging table using threading.

    Args:
        tenant_database: db connection object
        base_url: Kore API base URL
        account_id: account to fetch plans for
        headers: auth headers
        created_by: user performing action
        created_date: timestamp for records
        table_name: staging table name
        max_workers: number of threads for requests

    Returns:
        dict: {flag: bool, message: str, details: list or errors}
    """
    ##fetching the api details from the original data 
    api_details_map       = data.get("api_details_map", {})
    max_workers = api_details_map.get("api_limit", 0)
    max_retries = api_details_map.get("retries", 0)
    def fetch_plans(max_retries):
        """
        Fetch plans with retry on failure using exponential backoff.
        Args:
            max_retries (int): Maximum number of retry attempts
        Returns:
            dict: {"flag": bool, "plans": list, "error": str (optional)}
        """
        url = f"{base_url}/v1/accounts/{account_id}/plans"
        retry_count = 0
        backoff_factor = 1  # base for exponential backoff
        while retry_count < max_retries:
            try:
                resp = requests.get(url, headers=headers, timeout=10)
                # Success
                if resp.status_code == 200:
                    data = resp.json().get("plans", [])
                    return {"flag": True, "plans": data}

                # Retryable status codes (e.g., temporary server errors)
                if resp.status_code >= 500:
                    logging.warning(
                        f"Attempt {retry_count + 1}/{max_retries} failed "
                        f"with status {resp.status_code}: {resp.text}"
                    )
                else:
                    # For non-retryable status codes, return immediately
                    logging.error(
                        f"Non-retryable status {resp.status_code} received"
                    )
                    return {"flag": False, "plans": [], "error": resp.text}
            except requests.exceptions.RequestException as e:
                logging.warning(
                    f"Request exception on attempt {retry_count + 1}/{max_retries}: {e}"
                )
            # If we reach here, it means we should retry
            retry_count += 1
            # Exponential backoff delay: 2^(retry_count) seconds
            delay = backoff_factor * (2 ** (retry_count - 1))
            logging.info(f"Retrying after {delay} seconds...")
            time.sleep(delay)
        # Exhausted retries
        logging.error(f"Failed to fetch plans after {max_retries} attempts")
        response = {"flag": False, "plans": [], "error": "max retries exceeded"}
        return response
    def format_plans(plans):
        formatted = []
        for plan in plans:
            try:
                formatted.append(
                    {
                        "plan_id": plan["plan"]["plan-id"],
                        "plan_name": plan["plan"]["plan-name"],
                        "plan_type_id": plan["plan"]["plan-type-id"],
                        "usage_type": plan["plan"]["usage-type"],
                        "service_type_id": plan["plan"]["service-type-id"],
                        "created_by": username,
                        "modified_by": username,
                    }
                )
            except KeyError as e:
                logging.warning(f"Missing field {e} in plan, skipping")
        return formatted
    # 1. Fetch rate plans from carrier API
    fetch_result = fetch_plans(max_retries)
    if not fetch_result.get("flag"):
        response = {
            "flag": False,
            "message": "Failed to fetch plans",
            "details": fetch_result.get("error"),
        }
        return response
    plans = fetch_result.get("plans", [])
    if not plans:
        response = {"flag": False, "message": "No plans available", "details": []}
        return response
    # 2. Format the fetched plans for database insertion
    plan_data_list = format_plans(plans)
    if not plan_data_list:
        return {
            "flag": False,
            "message": "No valid plans to insert after formatting",
            "details": [],
        }
    # 3. Insert in parallel chunks using threads
    def insert_chunk(chunk):
        try:
            inserted_id = tenant_database.insert_data(chunk, table_name)
            return {"flag": True, "inserted_id": inserted_id}
        except Exception as e:
            logging.exception("Error inserting plan chunk")
            return {"flag": False, "error": str(e)}
    # chunk splitting helper
    def split_chunks(lst, size=500):
        for i in range(0, len(lst), size):
            yield lst[i : i + size]
    chunks = list(split_chunks(plan_data_list, 500))
    insert_results = []
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = {executor.submit(insert_chunk, chunk): chunk for chunk in chunks}
        for future in as_completed(futures):
            insert_results.append(future.result())
    # check for any failures
    failed = [r for r in insert_results if not r.get("flag")]
    if failed:
        response= {
            "flag": False,
            "message": "Some inserts failed",
            "details": failed,
        }
        return response
    response={
        "flag": True,
        "message": f"Inserted all plan chunks ({len(chunks)}) successfully",
        "details": insert_results,
    }
    return response

##fetching all the subscriptions
def fetch_all_subscriptions(
    base_url: str,
    account_id: str,
    headers: dict,
    max_page_item: int = 1000,
    max_retries: int = 3,
    max_workers: int = 3,
    timeout: int = 30
) -> dict:
    """
    Fetches all unique subscriptions using threading & retry logic.

    Args:
        base_url (str): API base URL
        account_id (str): Account ID for subscriptions
        headers (dict): Request headers
        max_page_item (int): Number of records per page
        max_retries (int): Number of retry attempts per page
        max_workers (int): ThreadPool size for parallel requests
        timeout (int): Request timeout in seconds
    Returns:
        list: Unique subscription objects
    """
    all_subscriptions = []
    seen_ids = set()
    # Helper: fetch one page with retries and exponential backoff
    def fetch_page(page_index: int):
        url = f"{base_url}/v1/accounts/{account_id}/subscriptions"
        params = {
            "page-index": page_index,
            "max-page-item": max_page_item,
            "show-state-history": True,
        }
        attempt = 0
        backoff = 1
        while attempt < max_retries:
            try:
                resp = requests.get(url, headers=headers, params=params, timeout=timeout)
                if resp.status_code == 200:
                    subs = resp.json().get("subscriptions", [])
                    return {"page": page_index, "subscriptions": subs, "error_message": None}
                #retry on server errors
                if resp.status_code >= 500:
                    logging.warning(
                        f"Page {page_index} attempt {attempt+1} got {resp.status_code}"
                    )
                else:
                    # Non-retryable error
                    logging.error(
                        f"Page {page_index} non-retryable error {resp.status_code}"
                    )
                    return {"page": page_index, "subscriptions": [], "error_message": resp.text}

            except Exception as e:
                logging.warning(f"Page {page_index} request exception: {e}")
            attempt += 1
            sleep_time = backoff * (2 ** (attempt - 1))
            logging.info(f"Retry {attempt}/{max_retries} for page {page_index} after {sleep_time}s")
            time.sleep(sleep_time)
        # Failed after retries
        return {"flag":False,"page": page_index, "subscriptions": [], "error_message": "max retries exceeded"}
    # Start pagination at 0
    initial_pages = list(range(0, max_workers))
    # Kick off initial set of pages
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        # Dictionary of futures to page indices
        future_to_page = {executor.submit(fetch_page, p): p for p in initial_pages}
        while future_to_page:
            for future in as_completed(list(future_to_page.keys())):
                p = future_to_page[future]
                try:
                    res = future.result()
                except Exception as e:
                    logging.error(f"Error fetching page {p}: {e}")
                    res = {"page": p, "subscriptions": [], "error": str(e)}

                subs = res.get("subscriptions", [])

                # Add unique subscriptions
                for sub in subs:
                    sid = sub.get("subscription-id")
                    if sid and sid not in seen_ids:
                        seen_ids.add(sid)
                        all_subscriptions.append(sub)

                logging.info(
                    f"Page {p} fetched | count={len(subs)} | unique total={len(all_subscriptions)}"
                )

                # If this page had subscriptions, schedule the next one
                if subs:
                    next_page = p + max_workers
                    future_to_page[executor.submit(fetch_page, next_page)] = next_page
                # Remove completed future
                future_to_page.pop(future)
    
    subscriptions_preview = str(all_subscriptions)[:1000]
    logging.info(
        f"Total Unique Subscriptions Loaded = {len(all_subscriptions)} | Preview(1000 char.s): {subscriptions_preview}..."
    )
    return {"flag": True, "subscriptions": all_subscriptions}
            
##fetching the carrier rate plan(profile) details and usage information for each subscription in parallel using batch workers to optimize the processing time
def fetch_device_profile_and_usage(all_subscriptions, base_url, final_headers, account_id,data,tenant_database):
    """
    Fetches device profile details and usage information for each subscription.

    Args:
        all_subscriptions (list): List of subscription objects fetched from the carrier API.
        access_token (str): Access token for authenticating API requests.
        base_url (str): Base URL for the carrier API.
        final_headers (dict): Headers to include in the API requests.
        account_id (str): Account ID used to fetch subscriptions.

    Returns:
        list: A list of processed subscription device records with profile and usage details.
    """
    processed_records = []
    ##fetching the api details from the original data 
    api_details_map       = data.get("api_details_map", {})
    test_flag = data.get("test_flag",False)
    tenant_name = data.get("tenant_name")
    max_workers = api_details_map.get("api_limit", 0)
    max_page_item = api_details_map.get("page_limit", 0)
    base_url = data.get("get_devices_url_method", {}).get("url")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    logging.info(f"###run_kore_sync fetch_device_details_and_usage for {tenant_name} Started fetching device details and usage data from carrier for all_subscriptions : {len(all_subscriptions)}")
    #featching all devices from inventory table
    today = date.today()
    result = tenant_database.get_data(
        table_name="kore_carrier_sync_staging_audit",
        condition={"sync_date": today},   #  only today's record
        columns=["sync_run_count", "sync_date"],
        order={"id": "desc"},
        mod_pages={"start": 0, "end": 1}
    )
    #  Daily Reset Logic
    if result is not None and not result.empty:
        sync_run_count = int(result.iloc[0]["sync_run_count"])
    else:
        sync_run_count = -1   # reset if no record for today

    # increment by 1
    sync_run_count += 1
    logging.info(f"### fetch_device_profile_and_usage Today's sync run count: {sync_run_count}")
    # PROCESS SUBSCRIPTIONS IN PARALLEL (BATCH WORKERS)
    batch_size = max_page_item
    # Only one thread is allowed to enter the locked block at a time.
    insert_lock = threading.Lock()
    def process_batch(batch_subscriptions):
        """
        This function is executed inside a parallel worker thread. It performs
        the following steps:
        1. Creates a new tenant database connection.
        2. Iterates through all subscriptions in the given batch.
        3. Calls `process_single_subscription()` for each subscription to fetch: - Device profile details & Usage information
        4. Collects all valid processed records.
        5. Performs a bulk insert into the staging table (`kore_carrier_sync_staging`) for efficient database loading.
       
        Args:
            batch_subscriptions (list): A list of subscription objects fetched from
                                    the carrier API that need to be processed.
        Returns:
            list: A list of processed subscription device records successfully
            inserted into the staging table. Returns an empty list if no valid records are generated.
        """
        batch_records = []
        audit_batch_records = []
        for subscription in batch_subscriptions:
            record = process_single_subscription(
                subscription,
                base_url,
                final_headers,
                account_id,
                data
            )
            if record:
                batch_records.append(record)
                audit_record = record.copy()
                audit_record["sync_run_count"] = sync_run_count
                audit_record["sync_date"] = now
                audit_record["triggered_by"] = data.get("username")
                audit_batch_records.append(audit_record)
        # Bulk Insert batch
        if batch_records and audit_batch_records :
            with insert_lock:
                tenant_database.insert_data(batch_records, "kore_carrier_sync_staging")
                tenant_database.insert_data(audit_batch_records, "kore_carrier_sync_staging_audit")
                logging.info(
                    f"####run_kore_sync Inserted Batch Records={len(batch_records)}"
                )
        return batch_records
    # Create batches
    batches = [
        all_subscriptions[i : i + batch_size]
        for i in range(0, len(all_subscriptions), batch_size)
    ]
    logging.info(
        f"###run_kore_sync Processing {len(batches)} batches with {max_workers} workers"
    )
    # TEST MODE: Process only first batch
    if test_flag:
        logging.warning("###run_kore_sync TEST FLAG is TRUE → Processing ONLY the first batch")
        batches = batches[:1]
    logging.info(
        f"###run_kore_sync Processing {len(batches)} batches with {max_workers} workers"
    )
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(process_batch, batch) for batch in batches]

        for future in as_completed(futures):
            try:
                batch_result = future.result()
                # only single thered can extend shared all_device_records list to avoid the data correption 
                with insert_lock:
                    processed_records.extend(batch_result)
            except Exception as e:
                logging.exception(f"Batch processing error: {e}")
    logging.info(
        f"### Completed All Processing. Total Records Inserted={len(processed_records)}"
    )
    return {"flag":True , "message":"device's profile and usage data fetched sucessfully" , "processed_records": processed_records}

#  PROCESS SINGLE SUBSCRIPTION (Profile + Usage)
def process_single_subscription(
    subscription,
    base_url,
    headers,
    account_id,
    data
):
    """
    Processes a single subscription record by fetching device profile details
    and usage information from the Kore Wireless carrier APIs.

    Args:
        subscription (dict): Subscription object returned from the carrier API.
        base_url (str): Base URL for Kore Wireless connectivity APIs.
        account_id (str): Kore account ID used for subscription API calls.
        df (DataFrame): Mapping or reference DataFrame used in profile enrichment.
        start_date (str): Billing period start date in ISO format.
        end_date (str): Billing period end date in ISO format.
        max_retries (int): Maximum retry attempts for profile API requests.

    Returns:
        dict: A fully enriched subscription record containing:
              - Device identifiers (ICCID, IMEI, EID)
              - Plan and carrier profile details
              - Usage metrics (data, SMS, voice)
              - Data usage converted into MB
    """
    api_details_map       = data.get("api_details_map", {})
    service_provider_id = data.get("service_provider_id")
    billing_period_id = data.get("billing_period_id")
    max_retries = api_details_map.get("retries", 0)
    subscription_id = subscription.get("subscription-id")
    last_effective_states = subscription.get('states', [])
    sim_status = ''
    if isinstance(last_effective_states, list) and len(last_effective_states) > 0:
        current_dict = next((item for item in last_effective_states if item.get("is-current") == True), {})
        sim_status = current_dict.get('state', '').lower()
        date_activated = None
        # If the SIM status is Active, get the activation date
        if sim_status and sim_status.lower() in ["active", "activated"]:
            date_activated = current_dict.get("start-datetime-utc", None)
    else:
        sim_status = ''
        date_activated = None
    # Prepare the data in the required format    
    record = {
        "subscription_id": subscription_id,
        "iccid": subscription.get("iccid", ""),
        "eid": subscription.get("eid", ""),
        "imei": subscription.get("imei", ""),
        "model": subscription.get("model", ""),
        "msisdns": ", ".join(
            str(msisdn.get("msisdn", "")) for msisdn in subscription.get("msisdns", [])
        ),
        "service_type_id": subscription.get("service-type-id", ""),
        "plan_id": None,
        "plan_name": None,
        "sms_usage": 0,
        "data_usage": 0,
        "voice_usage": 0,
        "data_usage_mb": 0.0,
        'cost_center_id': subscription.get('cost-center-id', 0),
        'sim_status': sim_status,
        'sim_last_effective_date': date_activated ,
        "created_by":"kore sync container" ,
        "modified_by": "kore sync container",
        "service_provider_id": int(service_provider_id) if service_provider_id else None,
        "service_provider_name": data.get("service_provider_name"),
        "billing_period_id": int(billing_period_id) if billing_period_id else None
    }
    # --- Profile API ---
    profile_data = fetch_profile_details(
        subscription, base_url, headers, account_id,max_retries
    )
    # logging.info(f"### fetch_profile_details profile_data : {profile_data} for subscription id : {subscription.get('subscription-id')} ")
    logging.info(f"### fetch_profile_details profile_data for subscription id : {subscription.get('subscription-id')} ")
    if profile_data:
        record.update(profile_data)
    # --- Usage API ---
    usage_data = get_subscription_usage(
        base_url,
        headers,
        account_id,
        subscription_id,
        data
    )
    if usage_data:
        data_usage_bytes = usage_data.get("data", {}).get("total-usage", 0)
        sms_usage_bytes = usage_data.get("sms", {}).get("total-usage", 0)
        voice_usage_bytes = usage_data.get("voice", {}).get("total-usage", 0)

        record["data_usage"] = data_usage_bytes
        record["sms_usage"] = sms_usage_bytes
        record["voice_usage"] = voice_usage_bytes
        record["data_usage_mb"] = round(data_usage_bytes / 1048576, 6)
    return record

def fetch_profile_details(subscription, base_url, headers, account_id, max_retries = 7 ):
    """
    This function:
    - Extracts the profile-id from the subscription's last-active-profile field
    - Calls the Kore profile endpoint to retrieve rate plan information

    Args:
        subscription (dict): Subscription object containing profile reference data.
        base_url (str): Kore carrier API base URL.
        headers (dict): Authentication headers for the API request.
        account_id (str): Kore account identifier.
        df (DataFrame): Mapping table of carrier rate plans (plan_id/plan_name → id)..

    Returns:
        dict | None: Dictionary with plan_id, plan_name, and carrier_rate_plan_id
        if successful, otherwise None.
    """
    try:
        profile_info = subscription.get('last-active-profile', [])
        # logging.info(f"### profile_info : {profile_info} for subscription id : {subscription.get('subscription-id')}")
        if not profile_info or not isinstance(profile_info, list):
            return None
        
        profile_id = profile_info[0].get('profile-id') if profile_info else None
        if not profile_id:
            logging.info(f"### profile_id : {profile_id} for subscription id : {subscription.get('subscription-id')}")
            return None
        
        url = f"{base_url}/v1/accounts/{account_id}/profiles/{profile_id}"
        response = None
        
        for attempt in range(max_retries):
            try:
                response = requests.get(url, headers=headers, timeout=30)
                logging.info(
                    f"Profile API status: {response.status_code} for subscription id : {subscription.get('subscription-id')}"
                )
                # logging.info(f"Response text: {response.text}")
                if response.status_code == 429:
                    wait_time = (2 ** attempt) + 1
                    logging.warning(f"Rate limited on profile {profile_id} (attempt {attempt + 1}/{max_retries}). Retrying in {wait_time:.2f}s...")
                    time.sleep(wait_time)
                    continue
                
                if response.status_code == 200:
                    break
                
                if response.status_code != 200:
                    logging.warning(f"Failed to fetch profile {profile_id}: status {response.status_code} (attempt {attempt + 1}/{max_retries})")
                    if attempt < max_retries - 1:
                        time.sleep(2 ** attempt)
                        continue
                    else:
                        return None
                        
            except requests.exceptions.RequestException as e:
                logging.error(f"Request exception for profile {profile_id} (attempt {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    time.sleep(2 ** attempt)
                    continue
                else:
                    return None
        
        if not response or response.status_code != 200:
            return None
        
        response_json = response.json()
        # logging.info(f"#### rate plan deatils  for subscription : {subscription}: {response_json.get('plans', [])}")
        logging.info(f"#### rate plan deatils  for subscription : {subscription}")
        data_plan = next((p for p in response_json.get("plans", []) if p.get("usage-type") == "DATA"), None)
        
        if not data_plan:
            return None
        
        plan_id = data_plan.get("plan-id")
        plan_name = data_plan.get("plan-name")
        return {
            "plan_id": plan_id,
            "plan_name": plan_name
        }
        
    except Exception as e:
        logging.exception(f"### Error fetching profile: {e}")
        return None
    
def get_subscription_usage(base_url, headers, account_id, subscription_id,data):
    """
    Fetches usage records (data, SMS, voice) for a specific subscription
    from the Kore Wireless Usage API within a given billing date range.
    Handles rate-limiting (HTTP 429) using exponential backoff retry logic.

    Args:
        base_url (str): Kore carrier API base URL.
        headers (dict): Authentication headers for the API request.
        account_id (str): Kore account identifier.
        subscription_id (str): Unique subscription ID to fetch usage for.
        start_date (str): Usage start date (ISO format).
        end_date (str): Usage end date (ISO format).

    Returns:
        dict: Usage JSON response if successful, otherwise an empty dictionary.
    """
    api_details_map       = data.get("api_details_map", {})
    max_retries = api_details_map.get("retries", 0)
    start_date = data.get("start_date")
    end_date = data.get("end_date")
    url = f"{base_url}/v1/accounts/{account_id}/subscriptions/{subscription_id}/usage-records"
    params = {
        "start-date": start_date,
        "end-date": end_date,
        "source": "cdr"
    }
    # logging.info(f"### get_subscription_usage url :{url} \n params : {params}")
    params = {key: value for key, value in params.items() if value is not None}

    retries = 0
    while retries < max_retries:
        try:
            response = requests.get(url, headers=headers, params=params)
            if response.status_code == 200:
                logging.info(f"### get_subscription_usage response.status_code : {response.status_code}")
                return response.json()
            elif response.status_code == 429:
                retries += 1
                wait_time = 2 ** retries + random.uniform(0, 2)
                logging.info(f"### Rate limit exceeded {subscription_id}. Retrying in {wait_time:.2f} seconds...")
                time.sleep(wait_time)
            else:
                logging.error(f"### Error in fetching get_subscription_usage: {response.status_code} - {response.text}")
                return {}
        except requests.exceptions.RequestException as e:
            logging.error(f"### An error occurred: {e}")
            return {}
    logging.info("### Max retries reached. Could not fetch subscription usage.")
    return {}

##syncing the main table ,inserting the data from staging to main table and then updating the devices
def sync_staging_to_main(data, tenant_database, common_utils_database,progress_tracker_id):
    """
    Syncs data from staging tables to main AMOP tables by executing stored procedures or SQL queries.

    Args:
        data (dict): Request data containing necessary information for syncing.
        tenant_database: Database connection object for tenant-specific operations.
        common_utils_database: Database connection object for common utilities.
    Returns:
        dict: Result of the sync operation with success or failure details.
    """
    logging.info("###### sync_staging_to_main Sync from staging to main started")
    ##Fetching the necessary variables
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    integration_id = int(data.get("integration_id")) if data.get("integration_id") is not None else None
    service_provider_id = int(data.get("service_provider_id"))  if data.get("service_provider_id") is not None else None
    service_provider_name = data.get("service_provider_name",None)
    tenant_id =   int(data.get("tenant_id")) if data.get("tenant_id") is not None else None
    username=data.get('username',None)
    staging_table_name=data.get('staging_table_name','kore_carrier_sync_staging')
    integration_authentication_id= int(data.get('integration_authentication_id')) if data.get('integration_authentication_id') is not None else None
    tenant_name = data.get("tenant_name")
    billing_period_id = int(data["billing_period_id"]) if data.get("billing_period_id") is not None else None
    ##initializing the variables
    device_status_map={}
    existing_plan_map={}
    insert_payload = []
    update_dict = []

    try:
        ##Step 1 : Fetching the staging table data 
        staging_df = tenant_database.get_data(staging_table_name)
        if staging_df is None or staging_df.empty:
            logging.info("### sync_staging_to_main No staging data found")
            return {"flag": False, "message": "No staging data found."}
        logging.info(f"### sync_staging_to_main Staging records fetched: {len(staging_df)}")
        try:
            logging.info(f"### sync_staging_to_main tenant : {tenant_name} updating the progress tracker for Fetched Staging records")
            update_progress_tracker(progress_tracker_id,current_status="Fetched Staging records Successfully",status="In Progress",common_utils_database=common_utils_database,action="update",now=now,progress=72,data=data)
        except Exception as e:
            logging.exception(f"### sync_staging_to_main devices and {tenant_name} Error updating progress tracker: {e}")
            
        ##Step 2: Fetching the statuses from staging table and checking with status in device_status table
        staging_statuses = (staging_df["sim_status"].dropna().astype(str).str.strip().str.lower().unique())
        ##device_status table
        existing_status_df = tenant_database.get_data(
            "device_status",
            {"integration_id": integration_id},
            ["id", "status","display_name"]
        )
        existing_status_df["status"] = (
            existing_status_df["status"]
            .astype(str)
            .str.strip()
            .str.lower()
        )
        ##preparing the existing_status_map
        existing_status_map = dict(
            zip(existing_status_df["status"], existing_status_df["id"])
        )
        ##checking for new statuses
        new_statuses = [
            status for status in staging_statuses
            if status not in existing_status_map
        ]
        ##Step 3:handling New status If new status comes need to insert them in device_status table
        if new_statuses:
            active_status_values = {"activate", "active", "activated"}
            status_insert_payload = [
                {
                    "status": status.strip(),
                    "display_name": status.strip().title(),
                    "description": f"Auto-created from {service_provider_name} carrier sync",
                    "created_by": username,
                    "modified_by": username,
                    "integration_id": integration_id,
                    "is_active": True,
                    "is_deleted": False,
                    # Business flags
                    "is_active_status": status.strip().lower() in active_status_values,
                    "should_have_billed_service": True,
                    "is_restorable_from_archive": status.strip().lower() in active_status_values,
                    "is_apply_for_automation_rule": status.strip().lower() in active_status_values,
                }
                for status in new_statuses
                if status and str(status).strip()
            ]
            tenant_database.insert_data(status_insert_payload, "device_status")
            logging.info(f"###sync_staging_to_main Inserted {len(new_statuses)} new device statuses")
            # Refetch after insert to get the latest ids
            existing_status_df = tenant_database.get_data(
                "device_status",
                {"integration_id": integration_id},
                ["id", "status","display_name"]
            )
        ##preparing the device_status map
        if existing_status_df is not None and not existing_status_df.empty:
            existing_status_df["status"] = (
                existing_status_df["status"]
                .astype(str)
                .str.strip()
                .str.lower()
            )
        
            device_status_map = dict(
                zip(existing_status_df["status"], existing_status_df["id"])
            )
        
            status_display_map = dict(
                zip(existing_status_df["status"], existing_status_df["display_name"])
            )
        else:
            device_status_map = {}
            status_display_map = {}
        try:
            logging.info(f"### sync_staging_to_main tenant : {tenant_name} updating the progress tracker for Device Statuses Fetched Successfully")
            update_progress_tracker(progress_tracker_id,current_status="Device Statuses Fetched Successfully",status="In Progress",common_utils_database=common_utils_database,action="update",now=now,progress=74,data=data)
        except Exception as e:
            logging.exception(f"### sync_staging_to_main devices and {tenant_name} Error updating progress tracker: {e}")    
        ##Step 4: Preparing the rate plan map using staging plans
        staging_plan_df = (
            staging_df[["plan_name", "plan_id"]]
            .dropna(subset=["plan_name"])
            .copy()
        )
        staging_plan_df["plan_name"] = (
            staging_plan_df["plan_name"]
            .astype(str)
            .str.strip()
        )
        ##Step 5: Preparing the existing carrier rate plan from existing plans
        existing_plan_df = tenant_database.get_data(
            "carrier_rate_plan",
            {
                "service_provider_id": service_provider_id,
                "is_active": True
            },
            ["id", "friendly_name", "rate_plan_code"]
        )
        if existing_plan_df is not None and not existing_plan_df.empty:
            existing_plan_df["friendly_name"] = (
                existing_plan_df["friendly_name"]
                .astype(str)
                .str.strip()
            )
            existing_plan_map = dict(
                zip(existing_plan_df["friendly_name"], existing_plan_df["id"])
            )
        else:
            existing_plan_map = {}
        insert_payload = []
        ##Step 6: Inserting the new plans from Carrier plans staging
        for _, row in staging_plan_df.iterrows():
            plan_name = row["plan_name"]
            staging_plan_id = row["plan_id"]
            if plan_name not in existing_plan_map:
                # INSERT NEW PLAN
                insert_payload.append({
                    "rate_plan_code": staging_plan_id,   #from staging
                    "friendly_name": plan_name,
                    "rate_plan_short_name": plan_name,
                    "service_provider":service_provider_name,
                    "service_provider_id": service_provider_id,
                    "is_active": True,
                    "is_deleted": False,
                    "is_retired":False,
                    "is_exclude_from_optimization":False,
                    "assigned":False,
                    "allows_sim_pooling":True,
                    "created_by": username,
                    "modified_by":username,
                })
        if insert_payload:
            logging.info(f"###run_kore_sync -> sync_staging_to_main inserted payload for carrier rate plans is: {insert_payload}")
            rate_plan_insert_flag=tenant_database.insert_data(insert_payload, "carrier_rate_plan")
            logging.info(f"###run_kore_sync -> sync_staging_to_main inserted flag is {rate_plan_insert_flag}")
        ##Refetch after insetions
        existing_plan_df = tenant_database.get_data(
            "carrier_rate_plan",
            {"service_provider_id": service_provider_id},
            ["id", "friendly_name"]
        )
        if existing_plan_df is not None and not existing_plan_df.empty:
            existing_plan_df["friendly_name"] = (
                existing_plan_df["friendly_name"]
                .astype(str)
                .str.strip()
            )
            
            plan_map = dict(
                zip(existing_plan_df["friendly_name"], existing_plan_df["id"])
            )
        try:
            logging.info(f"### sync_staging_to_main tenant : {tenant_name} updating the progress tracker for fetching carrier rate plans")
            update_progress_tracker(progress_tracker_id,current_status=f"Fetched Carrier Rate Plans Successfully",status="In Progress",common_utils_database=common_utils_database,action="update",now=now,progress=75,data=data)
        except Exception as e:
            logging.exception(f"### sync_staging_to_main devices and {tenant_name} Error updating progress tracker: {e}")      
        ##Step 7: Fetching the bill cycle values to insert or update 
        billing_df = tenant_database.get_data("billing_period",{"id":billing_period_id},['billing_cycle_end_date','billing_cycle_start_date','bill_year','bill_month'])
        if billing_df is not None and not billing_df.empty:
            billing_record = billing_df.to_dict("records")[0]
            bill_year = billing_record.get("bill_year")
            bill_month = billing_record.get("bill_month")
            billing_cycle_end_date = billing_record.get("billing_cycle_end_date")
            billing_cycle_start_date = billing_record.get("billing_cycle_start_date")
        else:
            billing_period_id = None
            bill_year = None
            bill_month = None
            billing_cycle_end_date = None
            billing_cycle_start_date=None
        ##Step 8: Prepare the column mappings ->Rename staging columns → main table columns columns mappings will be different for each provider based on the staging table
        columns_mapping = {
            "subscription_id": "subscription_id",
            "iccid": "iccid",
            "service_provider_id":"service_provider_id",
            "service_provider_name":"service_provider_display_name",
            "imei": "imei",
            "eid":"eid",
            "msisdns": "msisdn",
            "data_usage": "carrier_cycle_usage_bytes",
            "sim_status": "sim_status",
            "plan_name": "carrier_rate_plan_name",
            "data_usage_mb": "carrier_cycle_usage_mb",
            "sms_usage":"ctd_sms_usage",
            "voice_usage":"ctd_voice_usage"
        }
        transformed_df = staging_df.rename(columns=columns_mapping)
        ##Step 9: Prepare the column mappings -- Keep only mapped columns
        transformed_df = transformed_df[list(columns_mapping.values())]
        ##Step 10: Updating device_status_id using the status map and display map
        normalized_status = (
            transformed_df["sim_status"]
            .astype(str)
            .str.strip()
            .str.lower()
        )
        # Map ID
        transformed_df["device_status_id"] = normalized_status.map(device_status_map)
        # Map Display Name
        transformed_df["sim_status"] = normalized_status.map(status_display_map)
        
        ##carrier rate plan id
        transformed_df["carrier_rate_plan_id"] = (
            transformed_df["carrier_rate_plan_name"]
            .astype(str)
            .str.strip()
            .map(plan_map)
        )
        #Step11 Special Handling: sim_management_inventory Table
        transformed_df["tenant_id"] = tenant_id
        transformed_df["is_active"] = True
        transformed_df["tenant_is_active"] = True  
        transformed_df["tenant_is_deleted"] = False 
        transformed_df["is_deleted"] = False
        transformed_df["created_by"] = username
        transformed_df["modified_by"] = username
        transformed_df["billing_period_id"] = int(billing_period_id) if billing_period_id else None
        transformed_df["bill_year"] = int(bill_year) if bill_year else None
        transformed_df["bill_month"] = int(bill_month) if bill_month else None
        transformed_df["integration_id"] = int(integration_id) if integration_id else None
        transformed_df["billing_cycle_end_date"] = billing_cycle_end_date if billing_cycle_end_date else None
        transformed_df["billing_cycle_start_date"] = billing_cycle_start_date if billing_cycle_start_date else None
        transformed_df["account_number_integration_authentication_id"] = integration_authentication_id 
        ##Step 12: need to fetch the inventory iccids to check with staging iccids
        main_iccids_data = tenant_database.get_data(
            "sim_management_inventory",
            {"service_provider_id": service_provider_id,"tenant_id":tenant_id,"is_active":True},
            ["iccid"]
        )
        if main_iccids_data is not None and not main_iccids_data.empty:
            main_iccids = set(
                main_iccids_data["iccid"]
                .dropna()
                .astype(str)
                .str.strip()
            )
        else:
            main_iccids = set()
        ### Additional Step for sub tenant handling--->Duplicate columns
        transformed_df["sub_tenant_carrier_rate_plan_name"] = transformed_df["carrier_rate_plan_name"]
        transformed_df["sub_tenant_carrier_rate_plan_name_id"] = transformed_df["carrier_rate_plan_id"]
        ##Step 13: Prepare the inserting data 
        insert_df = transformed_df[
            ~transformed_df["iccid"].astype(str).isin(main_iccids)
        ]
        logging.info(f"###run_kore_sync->sync_staging_to_main")
        ##Step 14:Insert the data  in to inventory 
        new_devices_insert_flag = True
        if not insert_df.empty:
            insert_df = insert_df.replace({np.nan: None})
            logging.info(f"### sync_staging_to_main ICCIDs being inserted: {insert_df['iccid'].tolist()}")
            insert_payload = insert_df.to_dict(orient="records")
            new_devices_insert_flag = tenant_database.insert_data(
                insert_payload,
                "sim_management_inventory"
            )

            try:
                logging.info(f"### sync_staging_to_main tenant : {tenant_name} updating the progress tracker for sync_staging_to_main in Inventory Insertion case")
                update_progress_tracker(progress_tracker_id,current_status=f"Inserted {len(insert_payload)} records Successfully into Inventory",status="In Progress",common_utils_database=common_utils_database,action="update",now=now,progress=76,data=data)
            except Exception as e:
                logging.exception(f"### sync_staging_to_main devices and {tenant_name} Error updating progress tracker: {e}")
        else:
            logging.info(f"### No records Found to insert into Inventory table size of insert_df : {len(insert_df)}")        
        
        update_df = transformed_df[
            transformed_df["iccid"].astype(str).isin(main_iccids)
        ]
        bulk_update_flag = True
        if not update_df.empty:
            update_df = update_df.replace({np.nan: None})
            ##for update only we will remove tenant id filter
            update_df = update_df.drop(columns=["tenant_id"], errors="ignore")
            logging.info(f"### sync_staging_to_main ICCIDs being updated size : {len(update_df)} and iccids are : {update_df['iccid'].tolist()}")
            update_dict = update_df.to_dict(orient="records")
            bulk_update_flag = tenant_database.bulk_update_data(
            table_name="sim_management_inventory",
            data_list=update_dict,
            search_column="iccid",
            static_conditions={
                "service_provider_id": service_provider_id
            })
            try:
                logging.info(f"### sync_staging_to_main tenant : {tenant_name} updating the progress tracker for sync_staging_to_main in Inventory Updation case")
                update_progress_tracker(progress_tracker_id,current_status=f"Updated {len(update_dict)} records Successfully in Inventory",status="In Progress",common_utils_database=common_utils_database,action="update",now=now,progress=78,data=data)
            except Exception as e:
                logging.exception(f"### sync_staging_to_main devices and {tenant_name} Error updating progress tracker: {e}")
        audit_comments = {
            "sync_type": "Carrier Sync Staging → Main Inventory",
            "service_provider": service_provider_name,
            "tenant_name": tenant_name,
            "summary": {
                "total_staging_records": len(staging_df),
                "new_devices_inserted": len(insert_payload),
                "existing_devices_updated": len(update_dict)
            }
        }
        if bulk_update_flag and new_devices_insert_flag:
            logging.info("### sync_staging_to_main Sync completed successfully")
            try :
                audit_data_user_actions = {
                    "service_name": "sync_staging_to_main",
                    "created_by": data.get("username", ""),
                    "status": "Success",
                    "session_id": data.get("session_id", ""),
                    "tenant_name": data.get("tenant_name", ""),
                    "comments": json.dumps(audit_comments),
                    "module_name": "Carrier Sync",
                    "request_received_at": data.get("request_received_at"),
                }
                common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            except Exception as e :
                logging.error(f"### sync_staging_to_main auditing failed in success case :{e}") 
            return {"flag": True, "message": "Sync successful","summary": {"total_staging_records": len(staging_df), "new_devices_inserted": len(insert_payload), "existing_devices_updated": len(update_dict)}}
        else:
            return {"flag": False, "message": "Sync failed" , "summary": {"total_staging_records": 0, "new_devices_inserted": 0, "existing_devices_updated": 0}}
    except Exception as e:
        # Log the error
        error_message = f"Error during sync_staging_to_main : {str(e)}"
        error_type = str(type(e).__name__)
        logging.exception(f"### sync_staging_to_main Sync failed: {e}")
        # Log error to database
        try:
            error_data = {
                "service_name": "sync_staging_to_main",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during sync_staging_to_main for tenant {tenant_name}: {str(e)}",
                "module_name": "Carrier Sync",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### sync_staging_to_main and {tenant_name} Exception in logging error data to DB: {e}")
        return {"flag": False, "message": str(e) , "Sync failed":"Sync failed"}
    
    
def deactivate_inactive_devices(tenant_database, data):
    """
    Deactivates ICCIDs from sim_management_inventory if they are NOT present
    in kore_device_usage_stagging table.

    Logic:
    - Fetch all active ICCIDs from inventory for Verizon-Kore Wireless
    - Fetch all ICCIDs present in usage staging
    - Find inventory ICCIDs missing in usage
    - Bulk update those inventory records → set is_active = FALSE

    Uses tenant_database.bulk_update_data() for update (no raw SQL cursor).
    """
    tenant_id = data.get("tenant_id")
    service_provider_name = data.get("service_provider_name")
    try:
        # Step 1: Fetch all active ICCIDs from inventory
        sim_inventory_df = tenant_database.get_data(
            table_name="sim_management_inventory",
            where_conditions ={
            "tenant_id": tenant_id,
            "service_provider_display_name": service_provider_name,
            "is_active": True},
            columns=["id", "iccid", "is_active"]
        )
        logging.info(f"#### deactivate_inactive_devices Fetched {len(sim_inventory_df)} rows from sim_management_inventory")
        if sim_inventory_df is None or sim_inventory_df.empty:
            logging.info("### deactivate_inactive_devices No active inventory ICCIDs found in inventory table")
            return True

        # Step 2: Fetch ICCIDs present in kore_carrier_sync_staging
        usage_df = tenant_database.get_data(
            table_name="kore_carrier_sync_staging",
            where_conditions={},  # no filter → full table
            columns=["iccid"]
        )
        logging.info(f"### deactivate_inactive_devices Fetched {len(usage_df)} rows from kore_carrier_sync_staging table")
        # Convert usage ICCIDs into a set for fast lookup
        usage_iccids = set(usage_df["iccid"].dropna().astype(str).unique())

        # Step 3: Find inventory ICCIDs NOT present in usage table
        sim_inventory_df["iccid"] = sim_inventory_df["iccid"].astype(str)
        ### taking iccids which are present in the carrier side 
        to_deactivate_df = sim_inventory_df.loc[(~sim_inventory_df["iccid"].isin(usage_iccids))]
        logging.info(f"### deactivate_inactive_devices Number of ICCIDs to deactivate: {len(to_deactivate_df)}")
        if to_deactivate_df.empty:
            logging.info("### deactivate_inactive_devices Nothing to deactivate. Exiting.")
            return True

        # Step 4: Prepare bulk update payload
        # EX : [{"id": 1, "is_active": False}, ...]
        update_payload = [
            {"id": row["id"], "is_active": False}
            for _, row in to_deactivate_df.iterrows()]
        # If nothing to deactivate
        if not update_payload:
            logging.info("### deactivate_inactive_devices No ICCIDs to deactivate.")
            return True  

        # Step 5: Perform bulk update only if list has data
        bulk_update_data_flag = False
        bulk_update_data_flag = tenant_database.bulk_update_data(
            table_name = "sim_management_inventory",
            data_list = update_payload,
            search_column ="id",
            static_conditions={
                "tenant_id": tenant_id,
                "service_provider_display_name": service_provider_name
            })
        if bulk_update_data_flag:
            logging.info(f"### deactivate_inactive_devices Successfully deactivated {len(update_payload)} ICCIDs.")
        else:
            logging.warning("### deactivate_inactive_devices Bulk update did not affect any rows.")
 
        return bulk_update_data_flag

    except Exception as e:
        logging.exception(f"Error in deactivate_inactive_devices : {e}")
        return False
    
    
    
def history_table_updates(data,tenant_database,common_utils_database):
    """
    Synchronizes cross-provider device history by identifying devices with usage
    that are not already in cross-provider history and inserting them.
    
    This function filters device usage records to find devices that have data usage
    but are not present in the cross-provider device history table, then creates
    cross-provider history records for those devices.
    
    Args:
        data (dict): Request data containing:
            - tenant_name (str): Name of the tenant
            - service_provider (str): Service provider name
            - created_by (str, optional): User who created the sync. Defaults to "Kore_Container"
            - usage_date (str): Date for which to sync usage data
    
    Returns:
        dict: Response containing:
            - flag (bool): Success/failure indicator
            - message (str): Status message
            - records_synced (int, optional): Number of records synchronized
    
    Raises:
        Exception: Any errors during database operations or data processing
    """
    logging.info(f"Received data for history_table_updates: {data}")
    # Step 1: Extract required parameters from request data
    tenant_id = int(data.get("tenant_id")) if data.get("tenant_id") else None
    service_provider_id = int(data.get("service_provider_id")) if data.get("service_provider_id") else None
    service_provider=data.get("service_provider_name",None)
    created_by = data.get("username", "Kore_Container")
    tenant_name=data.get('tenant_name',None)
    raw_usage_date = data.get("usage_date")
    billing_period_id= int(data.get('billing_period_id')) if data.get('billing_period_id') else None
    if "telegence" in service_provider.lower():
        is_mobility = True
        history_dt_column = "mobility_device_tenant_id"
        inventory_dt_column = "mdt_id"
    else:
        is_mobility = False
        history_dt_column = "device_tenant_id"  
        inventory_dt_column = "dt_id"
    
    # Step 2: Parse usage date and calculate start/end datetime range
    # Handle both date formats: 'YYYY-MM-DD HH:MM:SS' and 'MM/DD/YYYY'
    try:
        usage_date = datetime.strptime(raw_usage_date, "%Y-%m-%d %H:%M:%S")
    except Exception as e:
        logging.exception(f"Exception while fetching usage_date{e}")
        usage_date = datetime.strptime(raw_usage_date, "%m/%d/%Y")
    # Start of day: 2026-02-03 00:00:00
    start_dt = usage_date.replace(hour=0, minute=0, second=0, microsecond=0)
    # End of day (exclusive): 2026-02-04 00:00:00
    end_dt = start_dt + timedelta(days=1)
    try:
        device_id_column = ("mobility_device_id" if "telegence" in service_provider.lower() else "device_id")
        # Fetch all active device IDs from sim_management_inventory
        active_devices_df = tenant_database.get_data(
            table_name="sim_management_inventory",
            condition={
                "is_active": True,
                "service_provider_id": service_provider_id
            },
            columns=[device_id_column]
        )
        # Convert device IDs into a Python list
        if active_devices_df is not None and not active_devices_df.empty:
            device_id_list = (active_devices_df[device_id_column].dropna().astype(int).tolist())     # Convert float → int
        else:
            device_id_list = []
        if not device_id_list:
            logging.warning("No active devices found in inventory table")
            return {"flag": False, "message": "No active devices found in Inventory table"}

        # Fetch device usage records (only devices with data_usage > 0)
        device_usage_query = f"""
            SELECT *
            FROM device_usage
            WHERE m2m_device_id = ANY(%s)
            AND usage_date >= %s
            AND usage_date < %s
            AND data_usage > 0
        """
        device_usage_df = tenant_database.execute_query(
            device_usage_query,
            params=[device_id_list, start_dt, end_dt]
        )
        logging.info(f"### history_table_updates length of device_usage_df : {len(device_usage_df)} and billing_period_id is {billing_period_id}")
        
        # Step 5: Fetch existing cross-provider device history records
        cross_provider_device_column = "mobility_device_id" if "Telegence" in service_provider else "m2m_device_id"
        cross_provider_devices_df = tenant_database.get_data(
            "cross_provider_device_history",
            {"service_provider_id": service_provider_id, 
             "billing_period_id": billing_period_id,
             "is_active": True
             },
             [cross_provider_device_column]
        )
        logging.info(f"### history_table_updates length of cross_provider_devices_df : {len(cross_provider_devices_df)}")
        
        # Step 6: Get all device IDs from usage records and fetch inventory data
        if device_usage_df is not None and not device_usage_df.empty:
            all_device_ids = (device_usage_df["m2m_device_id"].dropna().astype(int).tolist())     # Convert float → int
        else:
            all_device_ids = []
        if not all_device_ids:
            logging.info(f"### history_table_updates No device usage records found")
            return {"flag": True, "message": "No device usage records found."}
        logging.info(f"### history_table_updates all_device_ids size: {len(all_device_ids)}")
         
        inventory_device_column = "mobility_device_id" if "Telegence" in service_provider else "device_id"
        inventory_df = tenant_database.get_data(
            "sim_management_inventory",
            {inventory_device_column: all_device_ids, "is_active": True, "service_provider_id": service_provider_id}
        )
        logging.info(f"### history_table_updates inventory_df size : {len(inventory_df)}")
        
        # Step 7: Split device IDs into new and existing records
        if not cross_provider_devices_df.empty:
            cross_provider_device_ids = set(cross_provider_devices_df[cross_provider_device_column].tolist())
            new_device_ids = [did for did in all_device_ids if did not in cross_provider_device_ids]
            existing_device_ids = [did for did in all_device_ids if did in cross_provider_device_ids]
        else:
            new_device_ids = all_device_ids
            existing_device_ids = []

        # Step 8: Sync device history tables (device_history, mobility_device_history, smi_device_history)
        device_history_response=device_history_sync(billing_period_id,inventory_df,tenant_database,service_provider_id,service_provider,usage_date,created_by,common_utils_database,tenant_name,tenant_id)
        
        # Step 9: Define helper function to build cross-provider device history record   
        def build_record(row):
            """
            This function extracts SIM, device, customer, usage, and billing details
            from the given inventory row and prepares a dictionary payload for inserting or
            updating device history records.

            Args:
                row (dict/Series): Inventory row containing device and subscription data.
            Returns:
                dict: Device history record payload with tenant, plan, and usage fields.
            """
            record = {
                "m2m_device_id": row.get("device_id"),
                "mobility_device_id": row.get("mobility_device_id"),
                "service_provider_id": row.get("service_provider_id"),
                "iccid": row.get("iccid"),
                "msisdn": row.get("msisdn"),
                "imsi": row.get("imsi"),
                "imei": row.get("imei"),
                "carrier_rate_plan_id": row.get("carrier_rate_plan_id"),
                "created_by": row.get("created_by"),
                "created_date": row.get("created_date"),
                "modified_by": created_by,
                "modified_date": datetime.now(),
                "account_number": row.get("rev_customer_id"),
                "account_number_integration_authentication_id": row.get("account_number_integration_authentication_id"),
                "customer_id": row.get("customer_id"),
                "customer_rate_plan_id": row.get("customer_rate_plan_id"),
                "customer_rate_pool_id": row.get("customer_rate_pool_id"),
                "tenant_id": row.get("tenant_id"),
                "customer_data_allocation_mb": row.get("customer_data_allocation_mb"),
                "provider_date_added": row.get("date_added"),
                "provider_date_activated": row.get("date_activated"),
                "username": row.get("username"),
                "device_status_id": row.get("device_status_id"),
                "status": row.get("sim_status"),
                "rate_plan": row.get("carrier_rate_plan_name"),
                "last_usage_date": row.get("last_usage_date"),
                "carrier_cycle_usage": row.get("carrier_cycle_usage_bytes"),
                "ctd_sms_usage": row.get("ctd_sms_usage"),
                "ctd_voice_usage": row.get("ctd_voice_usage"),
                "ctd_session_count": row.get("ctd_session_count"),
                "last_activated_date": row.get("last_activated_date"),
                "billing_period_id": billing_period_id,
                "package": row.get("package"),
                "billing_cycle_end_date": row.get("billing_cycle_end_date"),
                "cost_center": row.get("cost_center"),
                "communication_plan": row.get("communication_plan"),
                "foundation_account_number": row.get("foundation_account_number"),
                "billing_account_number": row.get("billing_account_number"),
                "is_active": True,
                "is_deleted": False,
            }
            if tenant_id != row.get("tenant_id"):
                record["sub_tenant_carrier_rate_plan_name"] = record.get("sub_tenant_carrier_rate_plan_name")
                record["sub_tenant_carrier_rate_plan_name_id"] = int(record.get("sub_tenant_carrier_rate_plan_name_id")) if record.get("sub_tenant_carrier_rate_plan_name_id") else None
            if is_mobility:
                record["mobility_device_tenant_id"] = row.get("mdt_id")
                record["mobility_device_id"] = row.get("mobility_device_id")
            else:
                record["device_tenant_id"] = row.get("dt_id")
                record["m2m_device_id"] = row.get("device_id")
            return record
        
        # Step 10: Build records for new devices to insert
        new_records = []
        if new_device_ids:
            new_inventory_df = inventory_df[inventory_df["device_id"].isin(new_device_ids)]
            new_records = [build_record(row) for _, row in new_inventory_df.iterrows()]
            
        # Step 11: Build records for existing devices to update
        update_records = []
        if existing_device_ids:
            existing_inventory_df = inventory_df[inventory_df["device_id"].isin(existing_device_ids)]
            update_records = [build_record(row) for _, row in existing_inventory_df.iterrows()]
        
        # Step 12: Insert new cross-provider device history records
        inserted_count = 0
        inserted_ids = []
        if new_records:
            inserted_ids = tenant_database.insert_data_return_ids(new_records,"cross_provider_device_history", "id")
            inserted_count = len(inserted_ids)
            logging.info(f"Inserted {inserted_count} new cross-provider device history records")
        else:    
            logging.info(f"### history_table_updates No Records to insert into cross_provider_device_history table")    
        
        # Step 13: Update existing cross-provider device history records
        updated_count = 0
        updated_ids = []
        if update_records:
            # remove created_by and created_date from update records to avoid updating those fields
            for record in update_records:
                record.pop("created_by", None)
                record.pop("created_date", None)
            updated_ids = tenant_database.bulk_update_return_ids(
                "cross_provider_device_history", 
                update_records, 
                search_column=cross_provider_device_column,
                static_conditions={"service_provider_id": service_provider_id, "billing_period_id": billing_period_id, "tenant_id": tenant_id},
                return_id_column="id"
            )
            if updated_ids:
                updated_count = len(updated_ids)
                logging.info(f"Updated {updated_count} existing cross-provider device history records")
        else:
            logging.info(f"### history_table_updates No records found to update in cross_provider_device_history table")    
            
        ####################################### smi_cross_provider_device_history table ################################################
        
        # Step 14 : Combine inserted and updated IDs for smi_cross_provider_device_history sync
        smi_update_ids = inserted_ids + updated_ids
        logging.info(f"### smi_update_ids size : {len(smi_update_ids)} and inserted_ids size : {len(inserted_ids)} and updated_ids size: {len(updated_ids)}")
        ids_to_update_in_smi = []
        ids_to_insert_in_smi = []
        # Step 10: Check which device history IDs already exist in smi_cross_provider_device_history
        if smi_update_ids:
            smi_device_history_df = tenant_database.get_data(
                "smi_cross_provider_device_history",
                {"cdhid": smi_update_ids},
                ["id","cdhid"]
            )
            logging.info(f"### smi_device_history_df size :{len(smi_device_history_df)}")
            if not smi_device_history_df.empty:
                smi_device_history_ids = smi_device_history_df["cdhid"].tolist()
                ids_to_update_in_smi = [id for id in smi_update_ids if id in smi_device_history_ids]
                ids_to_insert_in_smi = [id for id in smi_update_ids if id not in smi_device_history_ids]
            else:
                ids_to_update_in_smi = []
                ids_to_insert_in_smi = smi_update_ids
        else:
            logging.info(f"### smi_update_ids size : {len(smi_update_ids)}") 

        # Step 11: Fetch updated device history records to get device_tenant_id mapping
        updated_device_history_df = tenant_database.get_data(
            "cross_provider_device_history",
            {"id": smi_update_ids},
            [history_dt_column,"id"]
        )

        logging.info(f"#### updated_device_history_df size:{len(updated_device_history_df)} ")
        if not updated_device_history_df.empty:
            updated_device_tenant_ids = updated_device_history_df[history_dt_column].tolist()
            device_history_dict = updated_device_history_df.set_index(history_dt_column)["id"].to_dict()
        else:
            updated_device_tenant_ids = []
            device_history_dict = {}
    
        # Step 15 : Fetch inventory records for devices that need smi_cross_provider_device_history sync
        inventory_df_for_smi = tenant_database.get_data(
            "sim_management_inventory",
            {inventory_dt_column: updated_device_tenant_ids, "is_active": True, "service_provider_id": service_provider_id}
        )
        logging.info(f"### inventory_df_for_smi size : {len(inventory_df_for_smi)}")
        
        # Step 16: Define helper function to build smi_cross_provider_device_history record
        def build_smi_cross_provider_record(row):
            """
                Build a record dictionary for inserting/updating `smi_cross_provider_device_history`.
                Args:
                    row (Series/dict): Inventory row containing device and usage details.
                Returns:
                    dict: Prepared SMI device history record.
            """
            device_tenant_id = row.get(inventory_dt_column)
            device_history_id = device_history_dict.get(device_tenant_id)
            record = {
                "changed_date": datetime.now(),
                "sim_management_inventory_id": row.get("id"),
                "service_provider_id": row.get("service_provider_id"),
                "iccid": row.get("iccid"),
                "imsi": row.get("imsi"),
                "msisdn": row.get("msisdn"),
                "imei": row.get("imei"),
                "device_status_id": row.get("device_status_id"),
                "carrier_rate_plan_id": row.get("carrier_rate_plan_id"),
                "communication_plan": row.get("communication_plan"),
                "communication_plan_id": row.get("communication_plan_id"),
                "customer_id": row.get("customer_id"),
                "customer_rate_plan_id": row.get("customer_rate_plan_id"),
                "customer_rate_plan_name": row.get("customer_rate_plan_name"),
                "customer_rate_pool_id": row.get("customer_rate_pool_id"),
                "customer_rate_pool_name": row.get("customer_rate_pool_name"),
                "last_usage_date": row.get("last_usage_date"),
                "carrier_cycle_usage": row.get("carrier_cycle_usage_bytes"),
                "created_by": created_by,
                "created_date": datetime.now(),
                "modified_by": created_by,
                "modified_date": datetime.now(),
                "last_activated_date": row.get("last_activated_date"),
                "is_active": True,
                "is_deleted": False,
                "account_number": row.get("rev_customer_id"),
                "provider_date_added": row.get("date_added"),
                "provider_date_activated": row.get("date_activated"),
                "cost_center": row.get("cost_center"),
                "username": row.get("username"),
                "account_number_integration_authentication_id": row.get("account_number_integration_authentication_id"),
                "billing_period_id": billing_period_id,
                "tenant_id": row.get("tenant_id"),
                "customer_data_allocation_mb": row.get("customer_data_allocation_mb"),
                "device_tenant_id": row.get("dt_id"),
                "mobility_device_tenant_id": row.get("mdt_id"),
                "foundation_account_number": row.get("foundation_account_number"),
                "billing_account_number": row.get("billing_account_number"),
                "ip_address": row.get("ip_address"),    
                "device_status":row.get("sim_status"),
                "carrier_sms_usage":row.get("carrier_sms_usage"),
                "carrier_voice_usage":row.get("carrier_voice_usage"),     
            }
            record["cdhid"] = device_history_id
            active_in_cycle = True if (row.get("sim_status").lower() in ["active","activated","a"]) else False
            if active_in_cycle:
                record["active_in_cycle"] = True
            else:
                record["active_in_cycle"] = False    
                
            if tenant_id != row.get("tenant_id"):
                record["sub_tenant_carrier_rate_plan_name"] = record.get("sub_tenant_carrier_rate_plan_name")
                record["sub_tenant_carrier_rate_plan_name_id"] = int(record.get("sub_tenant_carrier_rate_plan_name_id")) if record.get("sub_tenant_carrier_rate_plan_name_id") else None
            if is_mobility:
                record["mobility_device_tenant_id"] = row.get("mdt_id")
                record["m2m_device_id"] =  row.get("device_id")
            else:
                record["device_tenant_id"] = row.get("dt_id")
                record["mobility_device_id"] =  row.get("device_id") 
            return record
        
        # Step 17: Build records for smi_cross_provider_device_history update
        smi_update_records = []
        smi_insert_records = [] 
        if ids_to_update_in_smi or ids_to_insert_in_smi : 
            for _, row in inventory_df_for_smi.iterrows():
                history_id = device_history_dict.get(row.get(inventory_dt_column))

                if history_id in ids_to_update_in_smi:
                    smi_update_records.append(build_smi_cross_provider_record(row))

                elif history_id in ids_to_insert_in_smi:
                    smi_insert_records.append(build_smi_cross_provider_record(row))
        logging.info(f"### smi_update_records : {len(smi_update_records)} and smi_insert_records size :{len(smi_insert_records)} ")        
                
        # Step 18 : Update existing smi_cross_provider_device_history records
        if smi_update_records:
            # remove created_by and created_date from update records to avoid updating those fields
            for record in smi_update_records:
                record.pop("created_by", None)
                record.pop("created_date", None)
            tenant_database.bulk_update_data(
                "smi_cross_provider_device_history",
                smi_update_records,
                search_column=history_dt_column,
                static_conditions={"service_provider_id": service_provider_id, "billing_period_id": billing_period_id}
            )
            logging.info(f"Updated {len(smi_update_records)} records in smi_cross_provider_device_history")
        else:
            logging.info(f"### No records found to update in smi_cross_provider_device_history smi_update_records : {len(smi_update_records)}")    

        # Step 19: Insert new smi_cross_provider_device_history records
        if smi_insert_records:
            tenant_database.insert_data(smi_insert_records, "smi_cross_provider_device_history")
            logging.info(f"Inserted {len(smi_insert_records)} records in smi_cross_provider_device_history")
        else:
            logging.info(f"### No records found to insert into smi_cross_provider_device_history table smi_insert_records size: {len(smi_insert_records)}")     
        # Step 20: Log success audit entry
        try:
            audit_data = {
                "service_name": "history_table_updates",
                "created_date": datetime.now(),
                "created_by": created_by,
                "status": "Success",
                "tenant_name": tenant_name,
                "comments": f"Cross-provider device history sync completed for {service_provider} on {usage_date}",
                "module_name": "Carrier Sync",
                "request_received_at": datetime.now(),
                "session_id": None
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Audit logging failed: {e}")            
        
        # Step 21: Return success response with sync summary
        response={
            "flag": True, 
            "message": f"Successfully synced cross-provider device history: {inserted_count} inserted, {updated_count} updated",
            "records_inserted": inserted_count,
            "records_updated": updated_count
        }
        return response
    except Exception as e:
        logging.error(f"Error in history_table_updates: {e}")
        
        # Error audit logging
        try:
            error_data = {
                "service_name": "history_table_updates",
                "error_message": str(e),
                "error_type": str(type(e).__name__),
                "users": created_by,
                "session_id": None,
                "tenant_name": tenant_name,
                "comments": f"Cross-provider device history sync failed for {service_provider} on {usage_date}",
                "module_name": "Carrier Sync",
                "request_received_at": datetime.now()
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as audit_error:
            logging.error(f"Error audit logging failed: {audit_error}")     
        response={"flag": False, "message": f"Error in history_table_updates: {str(e)}"}
        return response
    
     
def device_history_sync(billing_period_id,inventory_df,tenant_database,service_provider_id,service_provider,usage_date,created_by,common_utils_database,tenant_name,tenant_id):
    """
    Sync device history records for a billing period.

    Inserts new device history entries and updates existing ones based on the
    current inventory data. Also maintains corresponding records in the
    `smi_device_history` table for reporting and auditing.

    Supports both Telegence (mobility) and standard service providers.

    Args:
        billing_period_id (int): Billing cycle identifier.
        inventory_df (DataFrame): Latest inventory/device data.
        tenant_database (DB): Tenant database connection object.
        service_provider_id (int): Service provider identifier.
        service_provider (str): Service provider name.
        usage_date (date/str): Usage date for sync reference.
        created_by (str): User triggering the sync.
        common_utils_database (DB): Common utilities database connection.
        tenant_name (str): Tenant name for audit logging.

    Returns:
        None
    """
    logging.info(f"Starting device_history_sync for billing_period_id: {billing_period_id}, service_provider_id: {service_provider_id} usage_date: {usage_date}")
    billing_period_id = int(billing_period_id) if billing_period_id else None
    service_provider_id = int(service_provider_id) if service_provider_id else None
    tenant_id = int(tenant_id) if tenant_id else None
    try:
        # Step 1: Determine table and column names based on service provider type
        if "telegence" in service_provider.lower():
            device_tenant_ids = inventory_df["mdt_id"].unique().tolist()
            history_table = "mobility_device_history"
            history_dt_column = "mobility_device_tenant_id"
            inventory_dt_column = "mdt_id"
            history_id_column = "mhid"
            is_mobility = True
        else:
            history_table = "device_history"
            device_tenant_ids = inventory_df["dt_id"].unique().tolist()
            history_dt_column = "device_tenant_id"
            inventory_dt_column = "dt_id"
            history_id_column = "dhid"
            is_mobility = False
        
        # Step 2: Fetch existing device history records for the billing period
        device_history_df = tenant_database.get_data(
            history_table,
            {"service_provider_id": service_provider_id, 
            "billing_period_id": billing_period_id,
            "is_active": True
            },
            [history_dt_column]
        )

        # Step 3: Split device IDs into new and existing based on history table
        if not device_history_df.empty:
            device_history_ids = set(device_history_df[history_dt_column].tolist())
            new_device_ids = [did for did in device_tenant_ids if did not in device_history_ids]
            existing_device_ids = [did for did in device_tenant_ids if did in device_history_ids]
        else:
            new_device_ids = device_tenant_ids
            existing_device_ids = []
        logging.info(f"device_history_sync - new_device_ids count: {len(new_device_ids)}, existing_device_ids count: {len(existing_device_ids)} , device_history_df size : {len(device_history_df)}")
        
        # Step 4: Define helper function to build device history record from inventory row
        def build_record(row):
            """
            Build a device history record from an inventory row. Prepares a dictionary for inserting/updating records in the
            device_history or mobility_device_history table, including service provider, SIM details, usage, and tenant mapping.
            
            Args:
                row (Series/dict): Inventory row containing device information.
            Returns:
                dict: Formatted device history record.
            """
            record = {
                "service_provider_id": row.get("service_provider_id"),
                "iccid": row.get("iccid"),
                "imsi": row.get("imsi"),
                "msisdn": row.get("msisdn"),
                "imei": row.get("imei"),
                "changed_date": datetime.now(),
                "device_status_id": row.get("device_status_id"),
                "status": row.get("sim_status"),
                "carrier_rate_plan_id": row.get("carrier_rate_plan_id"),
                "rate_plan": row.get("carrier_rate_plan_name"),
                "communication_plan": row.get("communication_plan"),
                "last_usage_date": row.get("last_usage_date"),
                "package": row.get("package"),
                "billing_cycle_end_date": row.get("billing_cycle_end_date"),
                "carrier_cycle_usage": row.get("carrier_cycle_usage_bytes"),
                "ctd_sms_usage": row.get("ctd_sms_usage"),
                "ctd_voice_usage": row.get("ctd_voice_usage"),
                "ctd_session_count": row.get("ctd_session_count"),
                "created_by": created_by,
                "created_date": datetime.now(),
                "modified_by": created_by,
                "modified_date": datetime.now(),
                "last_activated_date": row.get("last_activated_date"),
                "is_active": True,
                "is_deleted": False,
                "is_pushed": False,
                "account_number": row.get("rev_customer_id"),
                "provider_date_added": row.get("date_added"),
                "provider_date_activated": row.get("date_activated"),
                "cost_center": row.get("cost_center"),
                "username": row.get("username"),
                "account_number_integration_authentication_id": row.get("account_number_integration_authentication_id"),
                "billing_period_id": billing_period_id,
                "customer_id": row.get("customer_id"),
                "customer_rate_plan_id": row.get("customer_rate_plan_id"),
                "customer_rate_pool_id": row.get("customer_rate_pool_id"),
                "tenant_id": row.get("tenant_id")
            }
            if tenant_id != row.get("tenant_id"):
                record["sub_tenant_carrier_rate_plan_name"] = record.get("sub_tenant_carrier_rate_plan_name")
                record["sub_tenant_carrier_rate_plan_name_id"] = int(record.get("sub_tenant_carrier_rate_plan_name_id")) if record.get("sub_tenant_carrier_rate_plan_name_id") else None
            if is_mobility:
                record["id"] = row.get("mobility_device_id")
                record["mobility_device_tenant_id"] = row.get("mdt_id")
            else:
                record["id"] = row.get("device_id")
                record["device_tenant_id"] = row.get("dt_id")
            return record
        
        # Step 5: Build records for new devices to insert into device history
        new_records = []
        if new_device_ids:
            new_inventory_df = inventory_df[inventory_df[inventory_dt_column].isin(new_device_ids)]
            new_records = [build_record(row) for _, row in new_inventory_df.iterrows()]
        else:
            logging.info(f"### new_device_ids size: {len(new_device_ids)}")    
            
        # Step 6: Build records for existing devices to update in device history
        update_records = []
        if existing_device_ids:
            existing_inventory_df = inventory_df[inventory_df[inventory_dt_column].isin(existing_device_ids)]
            update_records = [build_record(row) for _, row in existing_inventory_df.iterrows()]
        else:
            logging.info(f"### existing_device_ids size: {len(existing_device_ids)}")    
        
        # Step 7: Insert new device history records and capture returned IDs
        inserted_count = 0
        inserted_ids = []
        if new_records:
            inserted_ids = tenant_database.insert_data_return_ids(new_records, history_table, "device_history_id")
            inserted_count = len(new_records)
            logging.info(f"Inserted {inserted_count} new device history records")
        else:
            logging.info(f"### device_history_sync No records found into Insert into : {history_table} table")    
        
        # Step 8: Update existing device history records and capture returned IDs
        updated_count = 0
        updated_ids = []
        if update_records:
            # remove created_by and created_date from update records to avoid updating those fields
            for record in update_records:
                record.pop("created_by", None)
                record.pop("created_date", None)
            updated_ids = tenant_database.bulk_update_return_ids(
                history_table,
                update_records, 
                search_column=history_dt_column,
                static_conditions={"service_provider_id": service_provider_id, "billing_period_id": billing_period_id},
                return_id_column="device_history_id"
            )
            if updated_ids:
                updated_count = len(update_records)
                logging.info(f"Updated {updated_count} existing device history records")
        else:
            logging.info(f"### device_history_sync No records found into Update into : {history_table} table")           
        
        # Step 9: Combine inserted and updated IDs for smi_device_history sync
        smi_update_ids = inserted_ids + updated_ids
        logging.info(f"### smi_update_ids size : {len(smi_update_ids)} and inserted_ids size : {len(inserted_ids)} and updated_ids size: {len(updated_ids)}")
        ids_to_update_in_smi = []
        ids_to_insert_in_smi = []
        # Step 10: Check which device history IDs already exist in smi_device_history
        if smi_update_ids:
            smi_device_history_df = tenant_database.get_data(
                "smi_device_history",
                {history_id_column: smi_update_ids},
                [history_id_column,"id"]
            )
            logging.info(f"### smi_device_history_df size :{len(smi_device_history_df)}")
            if not smi_device_history_df.empty:
                smi_device_history_ids = smi_device_history_df[history_id_column].tolist()
                ids_to_update_in_smi = [id for id in smi_update_ids if id in smi_device_history_ids]
                ids_to_insert_in_smi = [id for id in smi_update_ids if id not in smi_device_history_ids]
            else:
                ids_to_update_in_smi = []
                ids_to_insert_in_smi = smi_update_ids
        else:
            logging.info(f"### smi_update_ids size : {len(smi_update_ids)}")        

        # Step 11: Fetch updated device history records to get device_tenant_id mapping
        updated_device_history_df = tenant_database.get_data(
            history_table,
            {"device_history_id": smi_update_ids},
            [history_dt_column,"device_history_id"]
        )

        # updated_device_tenant_ids = updated_device_history_df[history_dt_column].tolist()
        # device_history_dict = (
        #     updated_device_history_df
        #     .set_index(history_dt_column)["device_history_id"]
        #     .to_dict()
        # )
        logging.info(f"#### updated_device_history_df size:{len(updated_device_history_df)} ")
        if not updated_device_history_df.empty:
            updated_device_tenant_ids = updated_device_history_df[history_dt_column].tolist()
            device_history_dict = updated_device_history_df.set_index(history_dt_column)["device_history_id"].to_dict()
        else:
            updated_device_tenant_ids = []
            device_history_dict = {}
    
        # Step 12: Fetch inventory records for devices that need smi_device_history sync
        inventory_df_for_smi = tenant_database.get_data(
            "sim_management_inventory",
            {inventory_dt_column: updated_device_tenant_ids, "is_active": True, "service_provider_id": service_provider_id}
        )
        logging.info(f"### inventory_df_for_smi size : {len(inventory_df_for_smi)}")
        
        # Step 13: Define helper function to build smi_device_history record
        def build_smi_record(row):
            """
                Build a record dictionary for inserting/updating `smi_device_history`.
                Args:
                    row (Series/dict): Inventory row containing device and usage details.
                Returns:
                    dict: Prepared SMI device history record.
            """
            device_tenant_id = row.get(inventory_dt_column)
            device_history_id = device_history_dict.get(device_tenant_id)
            record = {
                "changed_date": datetime.now(),
                "sim_management_inventory_id": row.get("id"),
                "service_provider_id": row.get("service_provider_id"),
                "service_provider_name": row.get("service_provider_display_name"),
                "iccid": row.get("iccid"),
                "imsi": row.get("imsi"),
                "msisdn": row.get("msisdn"),
                "imei": row.get("imei"),
                "device_status_id": row.get("device_status_id"),
                "status": row.get("sim_status"),
                "carrier_rate_plan_id": row.get("carrier_rate_plan_id"),
                "carrier_rate_plan_name": row.get("carrier_rate_plan_name"),
                "communication_plan": row.get("communication_plan"),
                "communication_plan_id": row.get("communication_plan_id"),
                "customer_id": row.get("customer_id"),
                "customer_name": row.get("customer_name"),
                "customer_rate_plan_id": row.get("customer_rate_plan_id"),
                "customer_rate_plan_name": row.get("customer_rate_plan_name"),
                "customer_rate_pool_id": row.get("customer_rate_pool_id"),
                "customer_rate_pool_name": row.get("customer_rate_pool_name"),
                "last_usage_date": row.get("last_usage_date"),
                "billing_cycle_end_date": row.get("billing_cycle_end_date"),
                "carrier_cycle_usage": row.get("carrier_cycle_usage_bytes"),
                "ctd_sms_usage": row.get("ctd_sms_usage"),
                "ctd_voice_usage": row.get("ctd_voice_usage"),
                "ctd_session_count": row.get("ctd_session_count"),
                "created_by": created_by,
                "created_date": datetime.now(),
                "modified_by": created_by,
                "modified_date": datetime.now(),
                "last_activated_date": row.get("last_activated_date"),
                "is_active": True,
                "is_deleted": False,
                "account_number": row.get("rev_customer_id"),
                "provider_date_added": row.get("date_added"),
                "provider_date_activated": row.get("date_activated"),
                "cost_center": row.get("cost_center"),
                "username": row.get("username"),
                "account_number_integration_authentication_id": row.get("account_number_integration_authentication_id"),
                "billing_period_id": billing_period_id,
                "tenant_id": row.get("tenant_id"),
                "customer_data_allocation_mb": row.get("customer_data_allocation_mb"),
                "device_id": row.get("device_id"),
                "device_tenant_id": row.get("dt_id"),
                "mobility_device_tenant_id": row.get("mdt_id"),
                "foundation_account_number": row.get("foundation_account_number"),
                "billing_account_number": row.get("billing_account_number"),
                "ip_address": row.get("ip_address"),                
            }
            if is_mobility:
                record["mhid"] = device_history_id
            else:
                record["dhid"] = device_history_id
            active_in_cycle = True if (row.get("sim_status").lower() in ["active","activated","a"]) else False
            if active_in_cycle:
                record["active_in_cycle"] = True
            else :
                record["active_in_cycle"] = False  
            return record
        
        # Step 14: Build records for smi_device_history update
        smi_update_records = []
        smi_insert_records = []
        if ids_to_update_in_smi or ids_to_insert_in_smi : 
            for _, row in inventory_df_for_smi.iterrows():
                history_id = device_history_dict.get(row.get(inventory_dt_column))

                if history_id in ids_to_update_in_smi:
                    smi_update_records.append(build_smi_record(row))

                elif history_id in ids_to_insert_in_smi:
                    smi_insert_records.append(build_smi_record(row))
        logging.info(f"### smi_update_records : {len(smi_update_records)} and smi_insert_records size :{len(smi_insert_records)} ")        
                

        # Step 16: Update existing smi_device_history records
        if smi_update_records:
            # remove created_by and created_date from update records to avoid updating those fields
            for record in smi_update_records:
                record.pop("created_by", None)
                record.pop("created_date", None)
            tenant_database.bulk_update_data(
                "smi_device_history",
                smi_update_records,
                search_column=history_dt_column,
                static_conditions={"service_provider_id": service_provider_id, "billing_period_id": billing_period_id}
            )
            logging.info(f"Updated {len(smi_update_records)} records in smi_device_history")
        else:
            logging.info(f"### No records found to update in smi_device_history smi_update_records : {len(smi_update_records)}")    

        # Step 17: Insert new smi_device_history records
        if smi_insert_records:
            tenant_database.insert_data(smi_insert_records, "smi_device_history")
            logging.info(f"Inserted {len(smi_insert_records)} records in smi_device_history")
        else:
            logging.info(f"### No records found to insert into smi_device_history table smi_insert_records size: {len(smi_insert_records)}")    
        
        # Step 18: Log success audit entry
        try:
            audit_data = {
                "service_name": "device_history_sync",
                "created_date": datetime.now(),
                "created_by": created_by,
                "status": "Success",
                "tenant_name": tenant_name,
                "comments": f"device history sync completed for {service_provider_id} on {usage_date}",
                "module_name": "Carrier Sync",
                "request_received_at": datetime.now(),
                "session_id": None
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Audit logging failed: {e}")

    except Exception as e:
        logging.error(f"Error in device_history_sync: {e}")
        
        # Step 19: Log error audit entry on failure
        try:
            error_data = {
                "service_name": "device_history_sync",
                "error_message": str(e),
                "error_type": str(type(e).__name__),
                "users": created_by,
                "session_id": None,
                "tenant_name": tenant_name,
                "comments": f"device history sync failed for {service_provider_id} on {usage_date}",
                "module_name": "Carrier Sync",
                "request_received_at": datetime.now()
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as audit_error:
            logging.error(f"Error audit logging failed: {audit_error}")

  
def update_device_usage_table(data,tenant_database,common_utils_database):
    """
    Updates device usage table with data from staging table.
    
    Args:
        data (dict): Request data containing:
            - created_by (str): User performing the operation
            - delayed_days (int): Number of days to delay usage date
            - staging_table (str): Name of staging table
            - tenant_name (str): Tenant name
            - service_provider (str): Service provider name
            - iccids (list): List of ICCIDs to process
    
    Returns:
        dict: Result with flag and message
    """
    logging.info(f"update_device_usage_table request received {data}")
    # Step 1: Extract required parameters from request data
    created_by = data.get("created_by", "Kore_Container")
    delayed_days = data.get("delayed_days", 3)
    staging_table = data.get("staging_table",'kore_carrier_sync_staging')
    tenant_name = data.get("tenant_name",None)
    tenant_id=data.get('tenant_id',None)
    service_provider_id=data.get('service_provider_id',None)
    # tenant_db_config      = data.get("tenant_db_config", {})
    iccids = []
    try:
        # Step 2: Fetch active ICCIDs from sim_management_inventory
        inventory_df = tenant_database.get_data(
            "sim_management_inventory",
            {"service_provider_id": service_provider_id,"tenant_id":tenant_id,"is_active":True},
            ["id", "iccid", "device_id", "mobility_device_id", "device_status_id"]
        )
        if inventory_df is not None and not inventory_df.empty:
            iccids = inventory_df["iccid"].astype(str).tolist()

        logging.info(f"Fetched {len(iccids)} active ICCIDs from main table")
        if not iccids:
            logging.info(f"No ICCIDs provided for {tenant_name}")
            return {"flag": False, "message": "No ICCIDs provided"}
        
        # Step 3: Calculate usage date based on delayed_days parameter
        usage_date = datetime.now().date() - timedelta(days=delayed_days)
        
        # Step 4: Fetch usage data from staging table for active ICCIDs
        staging_usage_df = tenant_database.get_data(
            staging_table,
            {"iccid": iccids},
            ["iccid", "sms_usage", "data_usage", "voice_usage"],
        )
        if staging_usage_df.empty:
            logging.warning(f"No staging usage records found for {tenant_name}")
            return {"flag": False, "message": "No staging usage records found"}
        
        # Step 5: Merge inventory and staging data on ICCID and remove duplicates
        usage_df = (
            pd.merge(inventory_df, staging_usage_df, on="iccid", how="inner")
            .drop_duplicates(subset=["iccid"])
            .reset_index(drop=True)
        )
        if usage_df.empty:
            logging.warning(f"No matched usage records after merge for {tenant_name}")
            return {"flag": False, "message": "No matched usage records"}

        device_ids = usage_df["device_id"].tolist()
        
        # Step 6: Check which device IDs already have usage records for the usage_date
        device_usage_present_df = tenant_database.get_data(
            "device_usage",
            {"m2m_device_id": device_ids, "usage_date": usage_date},
            ["m2m_device_id"],
        )
        existing_device_ids = set(
            device_usage_present_df["m2m_device_id"].tolist()
        )
        
        # Step 7: Split merged data into new records (insert) and existing records (update)
        new_usage_df = usage_df[~usage_df["device_id"].isin(existing_device_ids)]
        update_usage_df = usage_df[usage_df["device_id"].isin(existing_device_ids)]
        
        # Step 8: Build and insert new device usage records
        if not new_usage_df.empty:
            insert_records = [
                {
                    "sim_management_inventory_id": row["id"],
                    "m2m_device_id": row["device_id"],
                    "mobility_device_id": row["mobility_device_id"],
                    "data_usage": row["data_usage"],
                    "sms_usage": row["sms_usage"],
                    "voice_usage": row["voice_usage"],
                    "usage_date": usage_date,
                    "device_status_id": row["device_status_id"],
                    "created_by": created_by,
                    "modified_by":created_by,
                }
                for _, row in new_usage_df.iterrows()
            ]

            usage_insert_flag=tenant_database.insert_data(insert_records,"device_usage")
            logging.info(f"Inserted {len(insert_records)} usage records and usage_insert_flag is {usage_insert_flag}")
        
        # Step 9: Build and update existing device usage records
        if not update_usage_df.empty:
            update_records = [
                {
                    "sim_management_inventory_id": row["id"],
                    "m2m_device_id": row["device_id"],
                    "mobility_device_id": row["mobility_device_id"],
                    "data_usage": row["data_usage"],
                    "sms_usage": row["sms_usage"],
                    "voice_usage": row["voice_usage"],
                    "device_status_id": row["device_status_id"],
                    "modified_by":created_by,
                }
                for _, row in update_usage_df.iterrows()
            ]

            usage_update_flag=tenant_database.bulk_update_data(
                "device_usage",
                update_records,
                search_column="m2m_device_id",
                static_conditions={"usage_date": usage_date}
            )
            logging.info(f"Updated {len(update_records)} usage records and usage_update_flag is {usage_update_flag}")
        
        # Step 10: Log success audit entry
        try:
            audit_data = {
                "service_name": "update_device_usage_table",
                "created_date": datetime.now(),
                "created_by": created_by,
                "status": "Success",
                "tenant_name": tenant_name,
                "comments": f"Updated device usage for {len(iccids)} ICCIDs on {usage_date}",
                "module_name": "Carrier Sync",
                "request_received_at": datetime.now(),
                "session_id": None
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Audit logging failed: {e}")
        
        # Step 11: Return success response
        return {"flag": True, "message": "Device usage updated successfully"}
    except Exception as e:
        logging.exception(f"Error in update_device_usage_table: {e}")
        
        # Step 12: Log error audit entry on failure
        try:
            error_data = {
                "service_name": "update_device_usage_table",
                "error_message": str(e),
                "error_type": str(type(e).__name__),
                "users": data.get("created_by", "system"),
                "session_id": None,
                "tenant_name": data.get("tenant_name", ""),
                "comments": f"Failed to update device usage for {data.get('service_provider', '')}",
                "module_name": "Carrier Sync",
                "request_received_at": datetime.now()
            }
            # common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as audit_error:
            logging.error(f"Error audit logging failed: {audit_error}")
        return {"flag": False, "message": "Failed to update device usage"}
        
def trigger_sync_email(template_name, subject, data_dict, tenant_name, log_prefix):
    """
    Send an email for carrier/device sync with consistent logging.
    Args:
        template_name (str): Email template name.
        subject (str): Email subject line.
        data_dict (dict): Data to populate the email template.
        tenant_name (str): Tenant name for email context.
        log_prefix (str): Prefix used in logging messages.

    Returns:
        dict -> { "flag": True/False, "message": "..."}
    """
    try:
        result = send_email(
            template_name=template_name,
            email_subject=subject,
            is_html=True,
            data_dict=data_dict,
            tenant_name=tenant_name
        )
        if isinstance(result, tuple):
            to_emails, cc_emails, subject, body, from_email, partner_name = result
            logging.info(f"{log_prefix} Email sent successfully!")
            logging.info(f"{log_prefix} Email Log | To: {to_emails} | CC: {cc_emails} | Subject: {subject} | From: {from_email} | Partner: {partner_name}")
            return {"flag": True, "message": "Email sent successfully"}
         # Email failed
        logging.error(f"{log_prefix} Email sending failed: {result}")
        return {"flag": False, "message": "Email sending failed"}
    
    except Exception as e:
        logging.info(f"{log_prefix} Email sending Failed with error: {e}")
        return {"flag": False, "message": str(e)}
        