"""
@Author1 : Phaneendra.Y
Created Date: 03-02-26
"""
# Importing the necessary Libraries
from concurrent.futures import ThreadPoolExecutor, as_completed
import json
import math
import os
from random import random
from threading import Lock
import time
import logging
from datetime import datetime, date, timedelta

import pandas as pd
import requests

## Importing the necessary modules
from common_utils.db_utils import DB
from common_utils.email_trigger import send_email  # Make sure this is uncommented


# Database configuration
common_utils_db_config = {
     "host": os.environ["HOST"],
     "port": os.environ["PORT"],
     "user": os.environ["USER"],
     "password": os.environ["PASSWORD"],

 }

##function caller where the functions begins
def function_caller(data,path):
    """
    Main function caller that handles database configuration setup and routes requests.
    
    This function:
    1. Sets up initial database configuration
    2. Determines user type (regular user or service account)
    3. Builds appropriate database filters based on user permissions
    4. Routes the request to the appropriate endpoint handler
    
    Args:
        data (dict): Request data containing user/tenant information
        path (str): API endpoint path being called
        access_token (str): Optional access token for service accounts
        
    Returns:
        Result of the called endpoint function or error response
    """
    # Route to appropriate endpoint handler
    if path == "/run_pod19_sync":
        result = run_pod19_sync(data)
       
        
    ##else condition to handle the invalid path method
    else:
        result = {"flag":False,"error": "Invalid path or method"}
        logging.info(f"Invalid path or method requested: {path}")
    return result


##pod19 carrier daily sync function
def run_pod19_sync(data):
    """
    POD19 Carrier Daily Sync

    Performs the daily carrier sync for POD19 by:
    - Retrieving device details and usage data from the carrier
    - Converting usage values to standard units
    - Storing data in staging tables and syncing it to main AMOP tables
    - Recording sync progress and status in audit tables
    - Sending success or failure notification emails

    Returns:
        dict: Sync result with success or failure details.
    """
    logging.info(f"Received data for archiving devices: %s", data)
    start_time = time.time()
    # Fetch required fields
    service_provider_name = data.get("service_provider_name")
    username              = data.get("username")
    service_provider_id   = data.get("service_provider_id")
    integration_id        = data.get("integration_id")
    tenant_id             = data.get("tenant_id")
    tenant_name           = data.get("tenant_name")
    tenant_db_config      = data.get("tenant_db_config", {})
    db_name               = data.get("db_name", {})
    progress_tracker_id     = data.get("progress_tracker_id", {})
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    progress_tracker_id     = data.get("progress_tracker_id", {})
    delayed_days       = data.get("delayed_days", 1)
    module_name = "Carrier Sync"
    
    ## setting up the date variables for kore sync api calls
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")    
    today = datetime.now()
    start_time_dt = datetime.now()
    start_time_ts = time.time()
    # Get data from 7 days ago to yesterday (more likely to have usage data)
    start_date_obj = today - timedelta(days=delayed_days)
    end_date_obj = today - timedelta(days=delayed_days)
    start_date = start_date_obj.strftime("%Y-%m-%dT00:00:00Z")
    end_date = end_date_obj.strftime("%Y-%m-%dT23:59:59Z")
    data['start_date'] = start_date
    data['end_date'] = end_date
    data["usage_date"] = start_date_obj.strftime("%Y-%m-%d %H:%M:%S")  # Remove 'T' and 'Z'
    data["created_by"] = username
    logging.info(f"### run_pod19_sync devices and {tenant_name} time is {now}")
    
    # Initialize tracking variables for email
    staging_table_cleanup = False
    devices_fetch = False
    usage_fetch = False
    staging_insert = False
    staging_to_main_tables_sync = False
    device_usage_sync = False
    history_tables_sync = False
    email_trigger = False
    total_records_processed = 0
    
    #Step 1 :database connection
    try:
        tenant_database = DB(db_name, **tenant_db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **common_utils_db_config)
    except Exception as e:
        logging.error(f"### run_pod19_sync and {tenant_name} DB connection error: %s", e)
        return {"flag":False,"message": "DB connection failed in run_pod19_sync", "details": str(e)}
    
    ### send email for initiating sync 
    sync_data = {
        "Sync Type": "Daily Sync",    
        "Partner Name": tenant_name,    
        "Carrier Name": service_provider_name,    
        "Start Time": start_time_dt.strftime("%m-%d-%Y %H:%M:%S"),    
        "System / Job Name": "Scheduler"
    }
    trigger_sync_email(
        template_name="Sync Initiated",
        subject=f"Sync Initiated - {tenant_name} - {service_provider_name} - Daily Sync - {start_date_obj.strftime('%m-%d-%Y')}",
        data_dict=sync_data,
        tenant_name=tenant_name,
        log_prefix="### run_pod19_sync Sync Initiated"
    )
    
    #Progress Tracking: Update progress tracker - Staging cleanup started
    try:
        update_progress_tracker(progress_tracker_id, current_status="Staging cleanup started", status="In Progress", common_utils_database=common_utils_database, action="update", now=now, progress=10, data=data)
        logging.info(f"### run_pod19_sync devices and {tenant_name} Staging cleanup Started")
    except Exception as e:
        logging.exception(f"### run_pod19_sync devices and {tenant_name} Error updating progress tracker: {e}")
    
    try:
        ##Step 2:Cleaning the staging tables
        cleanup_response=clean_staging_table(tenant_database,"pod19_carrier_sync_staging", username)
        logging.info(f"### run_pod19_sync devices and {tenant_name} cleanup_response: {cleanup_response}")
        if not cleanup_response.get("flag") and cleanup_response.get("status")!=True:
            cleanup_message="Failed"
            cleanup_progress=100
            cleanup_status="Failed"
            staging_table_cleanup = False
        else:
            cleanup_message="Successful"
            cleanup_progress=15
            cleanup_status="In Progress"
            staging_table_cleanup = True

        logging.info(f"### run_pod19_sync devices and {tenant_name} Staging cleanup {cleanup_message}: {cleanup_response.get('message')}")
        #Progress Tracking: Update progress tracker - Staging cleanup successful or failed based on the cleanup response
        try:
            update_progress_tracker(progress_tracker_id, current_status=f"Staging cleanup {cleanup_message}", status=cleanup_status, common_utils_database=common_utils_database, action="update", now=now, progress=cleanup_progress, data=data)
            logging.info(f"### run_pod19_sync devices and {tenant_name} Staging cleanup {cleanup_message}")
            if cleanup_message == "Failed":
                raise Exception("Staging tables cleanup failed")
        except Exception as e:
            logging.exception(f"### run_pod19_sync devices and {tenant_name} Error updating progress tracker: {e}")
            raise Exception("Staging tables cleanup failed")
        
        if not cleanup_response.get("flag"):
            return {"flag":False,"message": "Staging cleanup failed in run_pod19_sync", "details": cleanup_response.get("details")}
        
        ##Step 3: Fetch Integration Details
        integration_response = fetch_integration_details(tenant_database,integration_id,tenant_name,tenant_id)
        if not integration_response.get("flag"):
            try:
                update_progress_tracker(progress_tracker_id, current_status=f"Integration details fetch failed", status="Failed", common_utils_database=common_utils_database, action="update", now=now, progress=100, data=data)
                logging.info(f"### run_pod19_sync devices and {tenant_name}  Integration details fetch failed")
            except Exception as e:
                logging.exception(f"### run_pod19_sync devices and {tenant_name} Error updating progress tracker: {e}")
            return integration_response

        integration_details = integration_response.get("integration_details", [])
        try:
            update_progress_tracker(progress_tracker_id, current_status=f"Integration details fetched", status="In Progress", common_utils_database=common_utils_database, action="update", now=now, progress=20, data=data)
            logging.info(f"### run_pod19_sync devices and {tenant_name} Integration details fetched")
        except Exception as e:
            logging.exception(f"### run_pod19_sync devices and {tenant_name} Error updating progress tracker: {e}")
            return {"flag":False,"message": "Integration details fetch failed in run_pod19_sync", "details": integration_response.get("details")}
        
        ##Step 4: Billing Period Logic: Implement billing period logic to determine the billing period for which the sync should be performed based on the current date and the provided bill_period value.
        billing_info = get_or_create_billing_period(
            tenant_id=tenant_id,
            service_provider_id=service_provider_id,
            service_provider_name=service_provider_name,
            tenant_database=tenant_database,
            common_utils_database=common_utils_database,
            progress_tracker_id=progress_tracker_id,
            billing_cycle_day=24,
            force_end_of_day=True,
            data=data
        )
        
        # Check if billing_info has flag and extract billing_period_id correctly
        if not billing_info.get("flag", True):
            logging.error(f"### run_pod19_sync devices and {tenant_name} - Billing period error: {billing_info.get('message')}")
            return billing_info
            
        billing_period_id = billing_info["billing_period_id"]
        data["billing_period_id"] = billing_period_id
        billing_cycle_start_date = billing_info.get("billing_period_details", {}).get("billing_cycle_start_date", "")
        billing_cycle_end_date = billing_info.get("billing_period_details", {}).get("billing_cycle_end_date", "")
        
        try:
            update_progress_tracker(progress_tracker_id,current_status="Fetching device details and usage data from carrier",status="In Progress",common_utils_database=common_utils_database,action="update",now=now,progress=40,data=data)
        except Exception as e:
            logging.exception(f"### run_pod19_sync devices and {tenant_name} Error updating progress tracker: {e}")
        
        ##Step 5: Fetch Device Details and Usage Data: Fetch device details and usage data from the carrier based on the integration details and billing period. Store the fetched data in the staging tables.
        fetch_device_details_response = fetch_device_details_and_usage(
            integration_details,tenant_database,tenant_name,tenant_id, billing_period_id, progress_tracker_id, common_utils_database, data
        )
        
        if not fetch_device_details_response.get("flag"):
            logging.error(f"### run_pod19_sync tenant : {tenant_name} failed fetching device details and usage")
            raise Exception(f"Failed to fetch device details and usage: {fetch_device_details_response.get('message')}")
        else:
            devices_fetch = True
            usage_fetch = True
            staging_insert = True
            
        processed_records = fetch_device_details_response.get("processed count")
        
        sync_main_table_response = sync_staging_to_main(data, tenant_database, common_utils_database,billing_period_id,progress_tracker_id)
        if not sync_main_table_response["flag"]:
            logging.error(f"### run_pod19_sync tenant : {tenant_name} failed syncing data from staging to main tables: {sync_main_table_response.get('message')}")
            current_status ="Failed syncing data from staging to main tables"
            staging_to_main_tables_sync = False
            raise Exception(f"Staging to main sync failed: {sync_main_table_response.get('message')}")
        else:
            logging.info(f"### run_pod19_sync tenant : {tenant_name} Successfully synced data from staging to main tables")
            current_status ="Successfully synced data from staging to main tables"
            staging_to_main_tables_sync = True
            
        sync_summary = sync_main_table_response.get("summary", {})
        total_records_processed = sync_summary.get("total_staging_records", 0)
        inserted_count = sync_summary.get("new_devices_inserted", 0)
        updated_count = sync_summary.get("existing_devices_updated", 0)    
        
        try:
            logging.info(f"### run_pod19_sync tenant : {tenant_name} updating the progress tracker for sync_staging_to_main")
            update_progress_tracker(progress_tracker_id,current_status=current_status,status="In Progress",common_utils_database=common_utils_database,action="update",now=now,progress=80,data=data)
        except Exception as e:
            logging.exception(f"### run_pod19_sync devices and {tenant_name} Error updating progress tracker: {e}")

        ##Step 11:Inserting or Updating the device_usage table with is_active:True Sims
        device_usage_insertion_response=update_device_usage_table(data,tenant_database,common_utils_database)
        if not device_usage_insertion_response.get("flag"):
            logging.error(f"### run_pod19_sync tenant : {tenant_name} failed syncing data into Device Usage Table : {sync_main_table_response.get('message')}")
            current_status ="Failed to Update or Insert in Device Usage Table"
            device_usage_sync = False
            raise Exception(f"Device usage table update failed: {device_usage_insertion_response.get('message')}")
        else:
            logging.info(f"### run_pod19_sync tenant : {tenant_name} Successfully Update or Inserted in Device Usage Table")
            current_status ="Successfully Update or Inserted in Device Usage Table"
            device_usage_sync = True
            
        ##Updating the Device Usage Progress Tracker
        try:
            logging.info(f"### run_pod19_sync tenant : {tenant_name} updating the progress tracker for update_device_usage_table")
            update_progress_tracker(progress_tracker_id,current_status=current_status,status="In Progress",common_utils_database=common_utils_database,action="update",now=now,progress=85,data=data)
        except Exception as e:
            logging.exception(f"### run_pod19_sync devices and {tenant_name} Error updating progress tracker: {e}")

        ##Step 12: Updating or Inserting the data in History Table
        history_table_updates_response = history_table_updates(data,tenant_database,common_utils_database)
        if not history_table_updates_response.get("flag"):
            logging.error(f"### run_pod19_sync tenant : {tenant_name} failed Update or Insert into History Tables: {sync_main_table_response.get('message')}")
            current_status ="Failed to Update or Insert in History Tables"
            history_tables_sync = False
            raise Exception(f"History tables update failed: {history_table_updates_response.get('message')}")
        else:
            logging.info(f"### run_pod19_sync tenant : {tenant_name} Successfully Updated or Inserted data into History Tables")
            current_status ="Successfully Updated or Inserted data into History Tables"
            history_tables_sync = True
            
        ##Updating the Device Usage Progress Tracker
        try:
            logging.info(f"### run_pod19_sync tenant : {tenant_name} updating the progress tracker for history_table_updates_response")
            update_progress_tracker(progress_tracker_id,current_status=current_status,status="In Progress",common_utils_database=common_utils_database,action="update",now=now,progress=90,data=data)
        except Exception as e:
            logging.exception(f"### run_pod19_sync devices and {tenant_name} Error updating progress tracker: {e}")

        ### step 13: getting inventory details to send sync details in email in Sync Completion case 
        # Fetch Query from the database based on the module name -> to get counts per status and total usage
        module_query_df = common_utils_database.get_data(
            "export_queries", {"module_name": module_name}
        )
        
        # checking the dataframe is empty or not
        if module_query_df.empty:
            logging.error(f"### No query found for module name: {module_name} for tenant: {tenant_name}")
            # Don't return, just log error and continue with empty data
            result = None
        else:
            # Extract the query string from the DataFrame
            query = module_query_df.iloc[0]["module_query"]
            if not query:
                logging.error(f"### Empty query for module name: {module_name} for tenant: {tenant_name}")
                result = None
            else:
                # Execute the query
                try:
                    result = tenant_database.execute_query(query, params=[service_provider_id])
                except Exception as e:
                    logging.error(f"### Error executing inventory query for {tenant_name}: {e}")
                    result = None
        
        status_variables = {}
        aggregate_usage_bytes = 0
        total_devices = 0
        total_devices_with_usage = 0
        
        # Map result to variables
        if result is not None and not result.empty:
            for _, row in result.iterrows():
                status_name = row['sim_status'].lower() if row['sim_status'] else 'unknown'
                count = row['device_count']
                usage = row['total_usage_bytes']
                devices_with_usage_count = row['devices_with_usage_count']
                
                # Create a dynamic key in the dictionary for each status
                status_variables[f"{status_name}_devices"] = count

                # Add to totals
                total_devices += count
                total_devices_with_usage += devices_with_usage_count
                aggregate_usage_bytes += usage
        
        logging.info(f"### run_pod19_sync - Inventory stats: total_devices={total_devices}, devices_with_usage={total_devices_with_usage}, aggregate_usage_bytes={aggregate_usage_bytes}")

        ### step 14 : sending email in sync successful case  
        # First, create a statuses dictionary that the replace_placeholders_with_table function expects
        statuses_dict = {}
        for status_key, count in status_variables.items():
            # Extract just the status name (remove '_devices' suffix)
            status_name = status_key.replace('_devices', '').title()
            statuses_dict[status_name] = count

        # Construct dynamic sync summary with the special 'statuses' key
        end_time_ts = time.time()
        end_time_dt = datetime.now()
        duration_seconds = int(end_time_ts - start_time_ts)
        duration_mm_ss = f"{duration_seconds // 60}:{duration_seconds % 60:02d}"

        sync_successful = staging_to_main_tables_sync and device_usage_sync and history_tables_sync
        
        sync_summary_data = {
            "Partner Name": tenant_name,
            "Carrier Name": service_provider_name,
            "Sync Timeline": f"{start_time_dt.strftime('%m-%d-%Y %H:%M:%S')} - {end_time_dt.strftime('%m-%d-%Y %H:%M:%S')} (Duration: {duration_mm_ss} minutes)",            "Device Sync Status": "Success" if sync_successful else "Failed",
            "Device Sync Status": "Success" if sync_successful else "Failed",
            "Total Devices": total_devices,
            "Usage Sync Status": "Success" if usage_fetch else "Failed",
            "Bill Cycle": f"{billing_cycle_start_date.strftime('%m-%d-%Y %H:%M:%S')} - {billing_cycle_end_date.strftime('%m-%d-%Y %H:%M:%S')}",
            "Devices with Usage": total_devices_with_usage,
            "Aggregate Usage": f"{round(aggregate_usage_bytes / (1024 * 1024), 2):,} MB",
            "Error Description": "NA" if sync_successful else "Check logs for details",
            "statuses": statuses_dict
        }
        logging.info(f"### run_pod19_sync sync_summary_data : {sync_summary_data}")

        email_response = trigger_sync_email(
            template_name="Sync Completed",
            subject=f"{tenant_name} - {service_provider_name} - Device and Usage Sync Summary - {start_date_obj.strftime('%m-%d-%Y')}",
            data_dict=sync_summary_data,
            tenant_name=tenant_name,
            log_prefix="### run_pod19_sync Sync Completed"
        )
        
        # Update current_status based on email response
        if not email_response["flag"]:
            current_status = "Sync Completed but Email Notification Failed"
        else:
            current_status = "Sync Completed & Email sent successfully"
            email_trigger = True

        ## Updating the Sync Completion Email Trigger in Progress Tracker
        try:
            logging.info(f"### run_pod19_sync tenant : {tenant_name} updating the progress tracker for email trigger")
            update_progress_tracker(progress_tracker_id, current_status=current_status, status="Completed",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=100, data=data)
            if current_status == "Sync Completed but Email Notification Failed":
                raise Exception("Sync Completion Email sending failed")
        except Exception as e:
            logging.exception(f"### run_pod19_sync devices and {tenant_name} Error updating progress tracker: {e}")
            raise Exception("Sync Completion Email sending failed")

        final_response = {"flag":True,"message": "Sync completed successfully" , "processed_records":processed_records}
        ##auditing the final response 
        try :
            logging.info(f"### run_pod19_sync audit in success case")
            audit_comment = {"total_staging_records": total_records_processed,"new_devices_inserted": inserted_count,"existing_devices_updated": updated_count}
            audit_data_user_actions = {
                "service_name": "run_pod19_sync",
                "created_date": data.get("request_received_at"),
                "created_by": data.get("username", ""),
                "status": "Success",
                "session_id": data.get("session_id", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": json.dumps(audit_comment),
                "module_name": "Carrier Sync",
                "request_received_at": data.get("request_received_at"),
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e :
           logging.error(f"### run_pod19_sync auditing failed in success case :{e}") 
        return final_response
    except Exception as e:
        logging.exception(f"run_pod19_sync and {tenant_name} Error during carrier sync {str(e)}")
        # Update the status of the bulk change request to ERROR
        # Log the error
        error_message = f"Error during carrier sync: {str(e)}"
        error_type = str(type(e).__name__)
        logging.error(f"### run_pod19_sync and {tenant_name} Error during carrier sync: {str(e)}")
        
        ### step 15 : sending email in Error case : 
        sync_stages = {
            "Staging Table Cleanup": staging_table_cleanup,
            "Devices Fetch": devices_fetch,
            "Device Usages Fetch": usage_fetch,
            "Staging Table Insert": staging_insert,
            "Staging → Main Tables Sync": staging_to_main_tables_sync,
            "Device Usage Sync": device_usage_sync,
            "History Tables Sync": history_tables_sync,
            "Sync Completion Email Trigger": email_trigger
        }
        
        # Get the first stage that failed
        failed_stage = next((name for name, flag in sync_stages.items() if not flag), "Unknown")
        # Map failed stage to a meaningful error category
        stage_error_mapping = {
            "Staging Table Cleanup": "Issue during Staging Tables Cleanup",
            "Devices Fetch": "Devices Fetch Issue",
            "Device Usages Fetch": "Devices Usage Processing Issue",
            "Staging Table Insert": "Staging Table Insert Issue",
            "Staging → Main Tables Sync": "Staging to Main Table Sync Issue",
            "Device Usage Sync": "Devices Usage Table Update Issue",
            "History Tables Sync": "History Tables Update Issue",
            "Sync Completion Email Trigger": "Email Trigger Issue",
            "Unknown": "Unknown Issue Encountered"
        }
        
        device_stages = {"Staging Table Cleanup", "Devices Fetch"}
        usage_stages = {"Device Usages Fetch", "Staging Table Insert", "Staging → Main Tables Sync", "Device Usage Sync", "History Tables Sync", "Sync Completion Email Trigger"}
        
        # Assign Data Type dynamically
        if failed_stage in device_stages:
            data_type = "Device"
        elif failed_stage in usage_stages:
            data_type = "Usage"
        else:
            data_type = "Device and Usage"

        error_category = stage_error_mapping.get(failed_stage, "Unknown Error")
        error_message = str(e)
        end_time_ts = time.time()
        end_time_dt = datetime.now()
        duration_seconds = int(end_time_ts - start_time)
        duration_mm_ss = f"{duration_seconds // 60}:{duration_seconds % 60:02d}"
        
        sync_failed_data = {
            "Sync Type": "Daily Sync",
            "Sync Timeline": f"{start_date_obj.strftime('%Y-%m-%d %H:%M:%S')} - {end_time_dt.strftime('%Y-%m-%d %H:%M:%S')} (Duration: {duration_mm_ss} minutes)",
            "Partner Name": tenant_name,
            "Carrier Name": service_provider_name,
            "Start Time": start_date_obj.strftime('%Y-%m-%d %H:%M:%S'),
            "End Time": end_time_dt.strftime('%Y-%m-%d %H:%M:%S'),
            "Job ID": "POD19_Container",
            "Error Category": error_category,
            "Error Message": error_message,
            "Stage of Failure": failed_stage,
            "Impacted Count": total_records_processed if total_records_processed != 0 else "N/A",
            "Data Type": data_type,
            "Partial Sync": "Yes" if total_records_processed != 0 else "No"
        }
        
        email_response = trigger_sync_email(
            template_name="Sync Error",
            subject=f"Sync Failed - {tenant_name} - {service_provider_name} - Daily Sync - {start_date_obj.strftime('%Y-%m-%d')}",
            data_dict=sync_failed_data,
            tenant_name=tenant_name,
            log_prefix="### run_pod19_sync Failed"
        )
        
        # Update current_status based on email response
        if not email_response["flag"]:
            current_status = "Sync failed. Error Email delivery was unsuccessful."
        else:
            current_status = "Sync failed. Error Email was sent successfully."
            email_trigger = True
            
        ## Updating the Sync Completion Email Trigger in Progress Tracker
        try:
            logging.info(f"### run_pod19_sync tenant : {tenant_name} updating the progress tracker for Sync failed & Error Email delivery")
            update_progress_tracker(progress_tracker_id, current_status=current_status, status="Failed",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=100, data=data)
        except Exception as e:
            logging.exception(f"### run_pod19_sync devices and {tenant_name} Error updating progress tracker: {e}")
        
        try:
            # Update progress tracker with failure
            update_progress_tracker(progress_tracker_id, current_status=f"Sync failed: {error_message}", status="Failed",
                                     common_utils_database=common_utils_database, action="update", now=now, progress=100, data={**data, "error_message": error_message})
        except Exception as e:
            logging.exception(f"### run_pod19_sync and {tenant_name} Exception in updating progress tracker: {e}")
        
        # Prepare error response
        response = {
            "flag": False,
            "message": error_message
        }
        try:
            # Log error to database
            error_data = {
                "service_name": "run_pod19_sync",
                "error_message": error_message,
                "error_type": error_category,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during carrier sync for tenant {tenant_name}: {str(e)}",
                "module_name": "Carrier Sync",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### run_pod19_sync and {tenant_name} Exception in logging error data to DB: {e}")
        return response
    
## Helper function to trigger sync emails with consistent logging
def trigger_sync_email(template_name, subject, data_dict, tenant_name, log_prefix):
    """
    Send an email for carrier/device sync with consistent logging.
    Args:
        template_name (str): Email template name.
        subject (str): Email subject line.
        data_dict (dict): Data to populate the email template.
        tenant_name (str): Tenant name for email context.
        log_prefix (str): Prefix used in logging messages.

    Returns:
        dict -> { "flag": True/False, "message": "..."}
    """
    try:
        result = send_email(
            template_name=template_name,
            email_subject=subject,
            is_html=True,
            data_dict=data_dict,
            tenant_name=tenant_name
        )
        if isinstance(result, tuple):
            to_emails, cc_emails, subject, body, from_email, partner_name = result
            logging.info(f"{log_prefix} Email sent successfully!")
            logging.info(f"{log_prefix} Email Log | To: {to_emails} | CC: {cc_emails} | Subject: {subject} | From: {from_email} | Partner: {partner_name}")
            return {"flag": True, "message": "Email sent successfully"}
         # Email failed
        logging.error(f"{log_prefix} Email sending failed: {result}")
        return {"flag": False, "message": "Email sending failed"}
    
    except Exception as e:
        logging.info(f"{log_prefix} Email sending Failed with error: {e}")
        return {"flag": False, "message": str(e)}


def sync_staging_to_main(data, tenant_database, common_utils_database, billing_period_id,progress_tracker_id):
    """
    Syncs data from staging tables to main AMOP tables by executing stored procedures or SQL queries.

    Args:
        data (dict): Request data containing necessary information for syncing.
        tenant_database: Database connection object for tenant-specific operations.
        common_utils_database: Database connection object for common utilities.
    Returns:
        dict: Result of the sync operation with success or failure details.
    """
    logging.info("###### sync_staging_to_main Sync from staging to main started")
    ##Fetching the necessary variables
    integration_id = data.get("integration_id",None)
    service_provider_id = data.get("service_provider_id",None)
    service_provider_name = data.get("service_provider_name",None)
    tenant_id = data.get("tenant_id")
    username=data.get('username',None)
    tenant_id=data.get('tenant_id',None)
    tenant_name=data.get('tenant_name',None)
    staging_table_name=data.get('staging_table_name','pod19_carrier_sync_staging')
    integration_authentication_id=data.get('integration_authentication_id',None)
    ##initializing the variables
    device_status_map={}
    existing_plan_map={}
    update_dict = []
    insert_payload = []
    billing_period_id=int(billing_period_id) if billing_period_id else None
    try:
        ##Step 1 : Fetching the staging table data 
        staging_df = tenant_database.get_data(staging_table_name)
        if staging_df is None or staging_df.empty:
            logging.info("###sync_staging_to_main No staging data found")
            return {"flag": False, "message": "No staging data found."}
        logging.info(f"###sync_staging_to_main Staging records fetched: {len(staging_df)}")
        ##Step 2: Fetching the statuses from staging table and checking with status in device_status table
        staging_statuses = (staging_df["status"].dropna().astype(str).str.strip().str.lower().unique())
        ##device_status table
        existing_status_df = tenant_database.get_data(
            "device_status",
            {"integration_id": integration_id},
            ["id", "status","display_name"]
        )
        existing_status_df["status"] = (
            existing_status_df["status"]
            .astype(str)
            .str.strip()
            .str.lower()
        )
        ##preparing the existing_status_map
        existing_status_map = dict(
            zip(existing_status_df["status"], existing_status_df["id"])
        )
        ##checking for new statuses
        new_statuses = [
            status for status in staging_statuses
            if status not in existing_status_map
        ]
        ##Step 3:handling New status If new status comes need to insert them in device_status table
        if new_statuses:
            active_status_values = {"activate", "active", "activated"}
            status_insert_payload = [
                {
                    "status": status.strip(),
                    "display_name": status.strip().title(),
                    "description": f"Auto-created from {service_provider_name} carrier sync",
                    "created_by": username,
                    "modified_by": username,
                    "integration_id": integration_id,
                    "is_active": True,
                    "is_deleted": False,
                    # Business flags
                    "is_active_status": status.strip().lower() in active_status_values,
                    "should_have_billed_service": True,
                    "is_restorable_from_archive": status.strip().lower() in active_status_values,
                    "is_apply_for_automation_rule": status.strip().lower() in active_status_values,
                }
                for status in new_statuses
                if status and str(status).strip()
            ]
            tenant_database.insert_data(status_insert_payload, "device_status")
            logging.info(f"###sync_staging_to_main Inserted {len(new_statuses)} new device statuses")
            # Refetch after insert to get the latest ids
            existing_status_df = tenant_database.get_data(
                "device_status",
                {"integration_id": integration_id},
                ["id", "status","display_name"]
            )
        ##preparing the device_status map
        if existing_status_df is not None and not existing_status_df.empty:
            existing_status_df["status"] = (
                existing_status_df["status"]
                .astype(str)
                .str.strip()
                .str.lower()
            )
        
            device_status_map = dict(
                zip(existing_status_df["status"], existing_status_df["id"])
            )
        
            status_display_map = dict(
                zip(existing_status_df["status"], existing_status_df["display_name"])
            )
        else:
            device_status_map = {}
            status_display_map = {}
        ##Step 4: Preparing the rate plan map using staging plans
        staging_plan_df = (
            staging_df[["rate_plan"]]
            .dropna(subset=["rate_plan"])
            .copy()
        )
        staging_plan_df["rate_plan"] = (
            staging_plan_df["rate_plan"]
            .astype(str)
            .str.strip()
        )
        ##Step 5: Preparing the existing carrier rate plan from existing plans
        existing_plan_df = tenant_database.get_data(
            "carrier_rate_plan",
            {
                "service_provider_id": service_provider_id,
                "is_active": True
            },
            ["id", "friendly_name", "rate_plan_code"]
        )
        if existing_plan_df is not None and not existing_plan_df.empty:
            existing_plan_df["friendly_name"] = (
                existing_plan_df["friendly_name"]
                .astype(str)
                .str.strip()
            )
            existing_plan_map = dict(
                zip(existing_plan_df["friendly_name"], existing_plan_df["id"])
            )
        else:
            existing_plan_map = {}
        insert_payload = []
        ##Step 6: Inserting the new plans from Carrier plans staging
        for _, row in staging_plan_df.iterrows():
            plan_name = row["rate_plan"]
            #staging_plan_id = row["plan_id"]
            if plan_name not in existing_plan_map:
                # INSERT NEW PLAN
                insert_payload.append({
                    "rate_plan_code": plan_name,   #from staging
                    "friendly_name": plan_name,
                    "rate_plan_short_name": plan_name,
                    "service_provider":service_provider_name,
                    "service_provider_id": service_provider_id,
                    "is_active": True,
                    "is_deleted": False,
                    "is_retired":False,
                    "is_exclude_from_optimization":False,
                    "assigned":False,
                    "allows_sim_pooling":True,
                    "created_by": username,
                    "modified_by":username,
                })
        if insert_payload:
            logging.info(f"###sync_staging_to_main -> sync_staging_to_main inserted payload for carrier rate plans is: {insert_payload}")
            rate_plan_insert_flag=tenant_database.insert_data(insert_payload, "carrier_rate_plan")
            logging.info(f"###sync_staging_to_main -> sync_staging_to_main inserted flag is {rate_plan_insert_flag}")
        ##Refetch after insetions
        existing_plan_df = tenant_database.get_data(
            "carrier_rate_plan",
            {"service_provider_id": service_provider_id},
            ["id", "friendly_name"]
        )
        if existing_plan_df is not None and not existing_plan_df.empty:
            existing_plan_df["friendly_name"] = (
                existing_plan_df["friendly_name"]
                .astype(str)
                .str.strip()
            )
            
            plan_map = dict(
                zip(existing_plan_df["friendly_name"], existing_plan_df["id"])
            )
        ##
        staging_plan_df = (
            staging_df[["communication_plan"]]
            .dropna(subset=["communication_plan"])
            .copy()
        )
        staging_plan_df["communication_plan"] = (
            staging_plan_df["communication_plan"]
            .astype(str)
            .str.strip()
        )
        ##Step 5: Preparing the existing communication plan from existing plans
        existing_plan_df = tenant_database.get_data(
            "sim_management_communication_plan",
            {
                "service_provider_id": service_provider_id,
                "is_active": True
            },
            ["id", "communication_plan_name"]
        )
        if existing_plan_df is not None and not existing_plan_df.empty:
            existing_plan_df["communication_plan_name"] = (
                existing_plan_df["communication_plan_name"]
                .astype(str)
                .str.strip()
            )
            existing_plan_map = dict(
                zip(existing_plan_df["communication_plan_name"], existing_plan_df["id"])
            )
        else:
            existing_plan_map = {}
        insert_payload = []
        ##Step 6: Inserting the new plans from Carrier plans staging
        for _, row in staging_plan_df.iterrows():
            plan_name = row["communication_plan"]
            #staging_plan_id = row["plan_id"]
            if plan_name not in existing_plan_map:
                # INSERT NEW PLAN
                insert_payload.append({
                    "communication_plan_name": plan_name,   #from staging
                    "service_provider_name":service_provider_name,
                    "service_provider_id": service_provider_id,
                    "is_active": True,
                    "is_deleted": False,
                    "created_by": username,
                    "modified_by":username,
                    "tenant_name": tenant_name,
                    "tenant_id": tenant_id,
                    "carrier_rate_plans": [plan_name],
                })
        if insert_payload:
            logging.info(f"###sync_staging_to_main -> sync_staging_to_main inserted payload for sim_management_communication_plan is: {insert_payload}")
            rate_plan_insert_flag=tenant_database.insert_data(insert_payload, "sim_management_communication_plan")
            logging.info(f"###sync_staging_to_main -> sync_staging_to_main inserted flag is {rate_plan_insert_flag}")
        ##Refetch after insetions
        existing_plan_df = tenant_database.get_data(
            "sim_management_communication_plan",
            {"service_provider_id": service_provider_id},
            ["id", "communication_plan_name"]
        )
        if existing_plan_df is not None and not existing_plan_df.empty:
            existing_plan_df["communication_plan_name"] = (
                existing_plan_df["communication_plan_name"]
                .astype(str)
                .str.strip()
            )
            
            comm_plan_map = dict(
                zip(existing_plan_df["communication_plan_name"], existing_plan_df["id"])
            )
        ##Step 7: Fetching the bill cycle values to insert or update 
        billing_df = tenant_database.get_data("billing_period",{"id":billing_period_id},['billing_cycle_end_date','billing_cycle_start_date','bill_year','bill_month'])
        if billing_df is not None and not billing_df.empty:
            billing_record = billing_df.to_dict("records")[0]
            bill_year = billing_record.get("bill_year")
            bill_month = billing_record.get("bill_month")
            billing_cycle_end_date = billing_record.get("billing_cycle_end_date")
            billing_cycle_start_date = billing_record.get("billing_cycle_start_date")
        else:
            billing_period_id = None
            bill_year = None
            bill_month = None
            billing_cycle_end_date = None
            billing_cycle_start_date=None
        ##Step 8: Prepare the column mappings ->Rename staging columns → main table columns columns mappings will be different for each provider based on the staging table
        columns_mapping = {
            "service_provider_id":"service_provider_id",
            "service_provider_name":"service_provider_display_name",
            "iccid":"iccid",
            "imsi":"imsi",
            "msisdn":"msisdn",
            "imei":"imei",
            "status":"sim_status",
            "rate_plan":"carrier_rate_plan_name",
            "communication_plan":"communication_plan",
            "aggregated_usage_bytes":"carrier_cycle_usage_bytes",
            "ctd_sms_usage":"ctd_sms_usage",
            "ctd_voice_usage":"ctd_voice_usage",
            "ctd_session_count":"ctd_session_count",
            "overage_limit_reached":"overage_limit_reached",
            "overage_limit_override":"overage_limit_override",
            #"ctd_data_usage_mb":"carrier_cycle_usage_mb",
            "aggregated_usage":"carrier_cycle_usage_mb"
            
        }
        transformed_df = staging_df.rename(columns=columns_mapping)
        ##Step 9: Prepare the column mappings -- Keep only mapped columns
        transformed_df = transformed_df[list(columns_mapping.values())]
        ##Step 10: Updating device_status_id using the status map and display map
        normalized_status = (
            transformed_df["sim_status"]
            .astype(str)
            .str.strip()
            .str.lower()
        )
        # Map ID
        transformed_df["device_status_id"] = normalized_status.map(device_status_map)
        # Map Display Name
        transformed_df["sim_status"] = normalized_status.map(status_display_map)
        
        ##carrier rate plan id
        transformed_df["carrier_rate_plan_id"] = (
            transformed_df["carrier_rate_plan_name"]
            .astype(str)
            .str.strip()
            .map(plan_map)
        )
        transformed_df["communication_plan_id"] = (
            transformed_df["communication_plan"]
            .astype(str)
            .str.strip()
            .map(comm_plan_map)
        )
        #Step11 Special Handling: sim_management_inventory Table
        transformed_df["tenant_id"] = tenant_id
        transformed_df["is_active"] = True
        transformed_df["tenant_is_active"] = True  
        transformed_df["service_provider_is_active"] = True
        transformed_df["tenant_is_deleted"] = False 
        transformed_df["is_deleted"] = False
        transformed_df["created_by"] = username
        transformed_df["modified_by"] = username
        transformed_df["billing_period_id"] = int(billing_period_id) if billing_period_id else None
        transformed_df["bill_year"] = int(bill_year) if bill_year else None
        transformed_df["bill_month"] = int(bill_month) if bill_month else None
        transformed_df["integration_id"] = int(integration_id) if integration_id else None
        transformed_df["billing_cycle_end_date"] = billing_cycle_end_date if billing_cycle_end_date else None
        transformed_df["billing_cycle_start_date"] = billing_cycle_start_date if billing_cycle_start_date else None
        transformed_df["account_number_integration_authentication_id"] = integration_authentication_id 
        ##Step 12: need to fetch the inventory iccids to check with staging iccids
        main_iccids_data = tenant_database.get_data(
            "sim_management_inventory",
            {"service_provider_id": service_provider_id,"tenant_id":tenant_id,"is_active":True},
            ["iccid"]
        )
        if main_iccids_data is not None and not main_iccids_data.empty:
            main_iccids = set(
                main_iccids_data["iccid"]
                .dropna()
                .astype(str)
                .str.strip()
            )
        else:
            main_iccids = set()
        ##Additional Step for sub tenant handling--->Duplicate columns
        transformed_df["sub_tenant_carrier_rate_plan_name"] = transformed_df["carrier_rate_plan_name"]
        transformed_df["sub_tenant_carrier_rate_plan_name_id"] = transformed_df["carrier_rate_plan_id"]
        ##Step 13: Prepare the inserting data 
        insert_df = transformed_df[
            ~transformed_df["iccid"].astype(str).isin(main_iccids)
        ]
        logging.info(f"###sync_staging_to_main->sync_staging_to_main")
        ##Step 14:Insert the data  in to inventory 
        new_devices_insert_flag = True
        if not insert_df.empty:
            insert_payload = insert_df.to_dict(orient="records")
            new_devices_insert_flag = tenant_database.insert_data(
                insert_payload,
                "sim_management_inventory"
            )
        
        update_df = transformed_df[
            transformed_df["iccid"].astype(str).isin(main_iccids)
        ]
        bulk_update_flag = True
        if not update_df.empty:
            ##for update only we will remove tenant id filter
            update_df = update_df.drop(columns=["tenant_id"], errors="ignore")
            update_dict = update_df.to_dict(orient="records")
            bulk_update_flag = tenant_database.bulk_update_data(
            table_name="sim_management_inventory",
            data_list=update_dict,
            search_column="iccid",
            static_conditions={
                "service_provider_id": service_provider_id
            }
        )
        try:
                logging.info(f"### sync_staging_to_main tenant : {tenant_name} updating the progress tracker for sync_staging_to_main in Inventory Updation case")
                update_progress_tracker(progress_tracker_id,current_status=f"Updated {len(update_dict)} records Successfully in Inventory",status="In Progress",common_utils_database=common_utils_database,action="update",progress=78,data=data)
        except Exception as e:
            logging.exception(f"### sync_staging_to_main devices and {tenant_name} Error updating progress tracker: {e}")
        audit_comments = {
            "sync_type": "Carrier Sync Staging → Main Inventory",
            "service_provider": service_provider_name,
            "tenant_name": tenant_name,
            "summary": {
                "total_staging_records": len(staging_df),
                "new_devices_inserted": len(insert_payload),
                "existing_devices_updated": len(update_dict)
            }
        }
        if bulk_update_flag and new_devices_insert_flag:
            logging.info("### sync_staging_to_main Sync completed successfully")
            try :
                audit_data_user_actions = {
                    "service_name": "sync_staging_to_main",
                    "created_by": data.get("username", ""),
                    "status": "Success",
                    "session_id": data.get("session_id", ""),
                    "tenant_name": data.get("tenant_name", ""),
                    "comments": json.dumps(audit_comments),
                    "module_name": "Carrier Sync",
                    "request_received_at": data.get("request_received_at"),
                }
                common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
            except Exception as e :
                logging.error(f"### sync_staging_to_main auditing failed in success case :{e}") 
            return {"flag": True, "message": "Sync successful","summary": {"total_staging_records": len(staging_df), "new_devices_inserted": len(insert_payload), "existing_devices_updated": len(update_dict)}}
        else:
            return {"flag": False, "message": "Sync failed" , "summary": {"total_staging_records": 0, "new_devices_inserted": 0, "existing_devices_updated": 0}}
    except Exception as e:
        # Log the error
        error_message = f"Error during sync_staging_to_main : {str(e)}"
        error_type = str(type(e).__name__)
        logging.exception(f"### sync_staging_to_main Sync failed: {e}")
        # Log error to database
        try:
            error_data = {
                "service_name": "sync_staging_to_main",
                "error_message": error_message,
                "error_type": error_type,
                "users": username,
                "tenant_name": tenant_name,
                "comments": f"Error during sync_staging_to_main for tenant {tenant_name}: {str(e)}",
                "module_name": "Carrier Sync",
                "request_received_at": data.get("request_received_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"### sync_staging_to_main and {tenant_name} Exception in logging error data to DB: {e}")
        return {"flag": False, "message": str(e) , "Sync failed":"Sync failed"}
    
def fetch_device_details_and_usage(
            integration_details,tenant_database,tenant_name,tenant_id, billing_period_id, progress_tracker_id, common_utils_database, data
        ):
    """
    Fetch device details and usage data from the carrier based on the integration details and billing period.
    Args:
        integration_details (list): List of integration authentication details
        tenant_database (DB): Tenant database connection
        tenant_name (str): Tenant name for logging
        tenant_id (int): Tenant ID for database queries
        billing_period_id (int): Billing period ID for which to fetch data
        progress_tracker_id (int): Progress tracker ID for updating sync status
        common_utils_database (DB): Common utils database connection for updating progress
        data (dict): Original request data for context in progress updates
    Returns:
        dict: Result of the fetch operation with success or failure details.
    """
    logging.info(f"### fetch_device_details_and_usage for {tenant_name} Started fetching device details and usage data from carrier for billing_period_id: {billing_period_id}")
    api_details_map       = data.get("api_details_map", {})
    ##fetching the api details from the request body
    api_limit             = api_details_map.get("api_limit", 0)
    retries               = api_details_map.get("retries", 0)
    page_limit            = api_details_map.get("page_limit", 0)
    bill_period           = api_details_map.get("bill_period")
    custom_url1           = data.get("custom_url1", {}).get("url")
    service_provider_name = data.get("service_provider_name", "")
    service_provider_id   = data.get("service_provider_id", "")
    delayed_days          = data.get("delayed_days", 1)
    syncrun_count = 0
    auth_details = integration_details[0] if integration_details else {}
    token = auth_details.get("oauth2_access_token","")
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    today = datetime.now()
    start_date_obj = today - timedelta(days=delayed_days)
    start_date = start_date_obj.strftime("%Y-%m-%dT00:00:00Z")
    try:

        # Placeholder for actual API calls to fetch device details and usage data
        # This would involve iterating over integration_details, making API calls using the credentials, and storing results in staging tables
        logging.info(f"### fetch_device_details_and_usage for {tenant_name} started with billing period: {billing_period_id}")

        headers = {
            "Authorization": f"Basic {token} ",
            "Content-Type": "application/json"
        }
        page_size = page_limit
        activated_iccids = []
        deactivated_list = []
        billing_cycle_start_date=None
        billing_cycle_end_date=None
        inventory_devices_list = []
        #featching all devices from inventory table
        result = tenant_database.get_data(
        table_name="pod19_carrier_sync_staging_audit",
        columns=["sync_run_count", "sync_date"],
        order={"id": "desc"},
        mod_pages={"start": 0, "end": 1}
         )
        if not result.empty:
            last_sync_date = result.iloc[0]["sync_date"]

            if last_sync_date.date() == today.date():
                syncrun_count = int(result.iloc[0]["sync_run_count"]) + 1
            else:
                syncrun_count = 0
        else:
            syncrun_count = 0

        #Step1:featching the devices from inventory table to get the activated and deactivated devices
        iccid_to_cycle_usage = {}
        inventory_devices = tenant_database.get_data(
            "sim_management_inventory",
             {"tenant_id": tenant_id,"service_provider_id": service_provider_id,
              "is_active": True},
             )
        if not inventory_devices.empty:
            inventory_devices_list = inventory_devices.to_dict(orient="records")
            iccid_to_cycle_usage = {
                record.get("iccid"): record.get("carrier_cycle_usage_mb", 0) or 0
                for record in inventory_devices_list
            }
            activated_iccids = [
                    r.get("iccid")
                    for r in inventory_devices_list
                    if r.get("sim_status", "").lower() in [
                        "activated", "inventory", "activation ready"
                    ]
                ]
            deactivated_list = [
                {
                    "iccid": record.get("iccid"),
                    "deactivated_date": record.get("deactivation_date")
                }
                for record in inventory_devices_list
                if record.get("sim_status", "").lower() not in [
                    "activated", "inventory", "activation ready","test ready"
                ]
            ]
        #featching biiling period start date and end date
        billng_data=tenant_database.get_data(
            "billing_period",
            {
                "id": int(billing_period_id),
                "tenant_id": tenant_id,
            }
        )
        if not billng_data.empty:
            billing_cycle_start_date = billng_data.iloc[0]["billing_cycle_start_date"]
            billing_cycle_end_date = billng_data.iloc[0]["billing_cycle_end_date"]
            logging.info(f"### fetch_device_details_and_usage for {tenant_name} Billing cycle start date: {billing_cycle_start_date}, end date: {billing_cycle_end_date}")
        try:
            #deactivated iccids in the billing cycle
            deactivated_iccids_in_cycle = []
            cycle_start = normalize_date(billing_cycle_start_date)
            cycle_end = normalize_date(billing_cycle_end_date)
            deactivated_iccids_in_cycle = [
                item["iccid"]
                for item in deactivated_list
                if item.get("iccid")
                and item.get("deactivated_date")
                and cycle_start
                <= normalize_date(item["deactivated_date"])
                <= cycle_end
            ]
        except Exception as e:
            logging.exception(f"### run_pod19_sync devices and {tenant_name} Error processing deactivated ICCIDs: {e}")
            deactivated_iccids_in_cycle = []
        #fetching the iccids from api which are not in inventory table
        api_iccids = fetch_api_devices(page_size, headers, custom_url1, tenant_name,start_date,retries)
        #fetching the usage for each iccid and storing in staging table with parallel requests
        iccids = list(set(activated_iccids)| set(deactivated_iccids_in_cycle)| set(api_iccids))
        logging.info(f"### fetch_device_details_and_usage for {tenant_name} Total devices in inventory: {len(iccids)} and API devices: {len(api_iccids)}, Activated ICCIDs: {len(activated_iccids)}, Deactivated ICCIDs in cycle: {len(deactivated_iccids_in_cycle)}")
        usage_responses = process_iccid_usage(iccids,headers,tenant_database,syncrun_count,api_iccids,data,billing_period_id,iccid_to_cycle_usage)
        if usage_responses.get("flag"):
            count= usage_responses.get("devices_processed", 0)
            data["current_status"] = "Device details and usage data fetched successfully"
            data["total_records_synced"] = count
            data["status"] = "success"
            update_progress_tracker(progress_tracker_id,common_utils_database=common_utils_database,action="update",data=data,progress=70)
        logging.info(f"### fetch_device_details_and_usage for {tenant_name} Device details and usage data fetched and stored successfully for billing_period_id: {billing_period_id}")
        return {"flag": True, "message": "Device details and usage data fetched successfully","processed count":count}
    except Exception as e:
        logging.exception(f"### fetch_device_details_and_usage for {tenant_name} Error fetching device details and usage data: {e}")
        return {"flag": False, "message": "Error fetching device details and usage data", "details": str(e)}
        
def history_table_updates(data,tenant_database,common_utils_database):
    """
    Synchronizes cross-provider device history by identifying devices with usage
    that are not already in cross-provider history and inserting them.
    
    This function filters device usage records to find devices that have data usage
    but are not present in the cross-provider device history table, then creates
    cross-provider history records for those devices.
    
    Args:
        data (dict): Request data containing:
            - tenant_name (str): Name of the tenant
            - service_provider (str): Service provider name
            - created_by (str, optional): User who created the sync. Defaults to "pod19_Container"
            - usage_date (str): Date for which to sync usage data
    
    Returns:
        dict: Response containing:
            - flag (bool): Success/failure indicator
            - message (str): Status message
            - records_synced (int, optional): Number of records synchronized
    
    Raises:
        Exception: Any errors during database operations or data processing
    """
    logging.info(f"Received data for history_table_updates: {data}")
    # Step 1: Extract required parameters from request data
    tenant_id = int(data.get("tenant_id")) if data.get("tenant_id") else None
    service_provider_id = int(data.get("service_provider_id")) if data.get("service_provider_id") else None
    service_provider=data.get("service_provider_name",None)
    created_by = data.get("username", "pod19_Container")
    tenant_name=data.get('tenant_name',None)
    raw_usage_date = data.get("usage_date")
    billing_period_id= int(data.get('billing_period_id')) if data.get('billing_period_id') else None
    if "telegence" in service_provider.lower():
        is_mobility = True
        history_dt_column = "mobility_device_tenant_id"
        inventory_dt_column = "mdt_id"
    else:
        is_mobility = False
        history_dt_column = "device_tenant_id"  
        inventory_dt_column = "dt_id"
    
    # Step 2: Parse usage date and calculate start/end datetime range
    # Handle both date formats: 'YYYY-MM-DD HH:MM:SS' and 'MM/DD/YYYY'
    try:
        usage_date = datetime.strptime(raw_usage_date, "%Y-%m-%d %H:%M:%S")
    except Exception as e:
        logging.exception(f"Exception while fetching usage_date{e}")
        usage_date = datetime.strptime(raw_usage_date, "%m/%d/%Y")
    # Start of day: 2026-02-03 00:00:00
    start_dt = usage_date.replace(hour=0, minute=0, second=0, microsecond=0)
    # End of day (exclusive): 2026-02-04 00:00:00
    end_dt = start_dt + timedelta(days=1)
    try:
        device_id_column = ("mobility_device_id" if "telegence" in service_provider.lower() else "device_id")
        # Fetch all active device IDs from sim_management_inventory
        active_devices_df = tenant_database.get_data(
            table_name="sim_management_inventory",
            condition={
                "is_active": True,
                "service_provider_id": service_provider_id
            },
            columns=[device_id_column]
        )
        # Convert device IDs into a Python list
        if active_devices_df is not None and not active_devices_df.empty:
            device_id_list = (active_devices_df[device_id_column].dropna().astype(int).tolist())     # Convert float → int
        else:
            device_id_list = []
        if not device_id_list:
            logging.warning("No active devices found in inventory table")
            return {"flag": False, "message": "No active devices found in Inventory table"}

        # Fetch device usage records (only devices with data_usage > 0)
        device_usage_query = f"""
            SELECT *
            FROM device_usage
            WHERE m2m_device_id = ANY(%s)
            AND usage_date >= %s
            AND usage_date < %s
            AND data_usage > 0
        """
        device_usage_df = tenant_database.execute_query(
            device_usage_query,
            params=[device_id_list, start_dt, end_dt]
        )
        logging.info(f"### history_table_updates length of device_usage_df : {len(device_usage_df)} and billing_period_id is {billing_period_id}")
        
        # Step 5: Fetch existing cross-provider device history records
        cross_provider_device_column = "mobility_device_id" if "Telegence" in service_provider else "m2m_device_id"
        cross_provider_devices_df = tenant_database.get_data(
            "cross_provider_device_history",
            {"service_provider_id": service_provider_id, 
             "billing_period_id": billing_period_id,
             "is_active": True
             },
             [cross_provider_device_column]
        )
        logging.info(f"### history_table_updates length of cross_provider_devices_df : {len(cross_provider_devices_df)}")
        
        # Step 6: Get all device IDs from usage records and fetch inventory data
        if device_usage_df is not None and not device_usage_df.empty:
            all_device_ids = (device_usage_df["m2m_device_id"].dropna().astype(int).tolist())     # Convert float → int
        else:
            all_device_ids = []
        if not all_device_ids:
            logging.info(f"### history_table_updates No device usage records found")
            return {"flag": True, "message": "No device usage records found."}
        logging.info(f"### history_table_updates all_device_ids : {all_device_ids}")
         
        inventory_device_column = "mobility_device_id" if "Telegence" in service_provider else "device_id"
        inventory_df = tenant_database.get_data(
            "sim_management_inventory",
            {inventory_device_column: all_device_ids, "is_active": True, "service_provider_id": service_provider_id}
        )
        logging.info(f"### history_table_updates inventory_df size : {len(inventory_df)}")
        
        # Step 7: Split device IDs into new and existing records
        if not cross_provider_devices_df.empty:
            cross_provider_device_ids = set(cross_provider_devices_df[cross_provider_device_column].tolist())
            new_device_ids = [did for did in all_device_ids if did not in cross_provider_device_ids]
            existing_device_ids = [did for did in all_device_ids if did in cross_provider_device_ids]
        else:
            new_device_ids = all_device_ids
            existing_device_ids = []

        # Step 8: Sync device history tables (device_history, mobility_device_history, smi_device_history)
        device_history_response=device_history_sync(billing_period_id,inventory_df,tenant_database,service_provider_id,service_provider,usage_date,created_by,common_utils_database,tenant_name,tenant_id)
        
        # Step 9: Define helper function to build cross-provider device history record   
        def build_record(row):
            """
            This function extracts SIM, device, customer, usage, and billing details
            from the given inventory row and prepares a dictionary payload for inserting or
            updating device history records.

            Args:
                row (dict/Series): Inventory row containing device and subscription data.
            Returns:
                dict: Device history record payload with tenant, plan, and usage fields.
            """
            record = {
                "m2m_device_id": row.get("device_id"),
                "mobility_device_id": row.get("mobility_device_id"),
                "service_provider_id": row.get("service_provider_id"),
                "iccid": row.get("iccid"),
                "msisdn": row.get("msisdn"),
                "imsi": row.get("imsi"),
                "imei": row.get("imei"),
                "carrier_rate_plan_id": row.get("carrier_rate_plan_id"),
                "created_by": row.get("created_by"),
                "created_date": row.get("created_date"),
                "modified_by": created_by,
                "modified_date": datetime.now(),
                "account_number": row.get("rev_customer_id"),
                "account_number_integration_authentication_id": row.get("account_number_integration_authentication_id"),
                "customer_id": row.get("customer_id"),
                "customer_rate_plan_id": row.get("customer_rate_plan_id"),
                "customer_rate_pool_id": row.get("customer_rate_pool_id"),
                "tenant_id": row.get("tenant_id"),
                "customer_data_allocation_mb": row.get("customer_data_allocation_mb"),
                "provider_date_added": row.get("date_added"),
                "provider_date_activated": row.get("date_activated"),
                "username": row.get("username"),
                "device_status_id": row.get("device_status_id"),
                "status": row.get("sim_status"),
                "rate_plan": row.get("carrier_rate_plan_name"),
                "last_usage_date": row.get("last_usage_date"),
                "carrier_cycle_usage": row.get("carrier_cycle_usage_bytes"),
                "ctd_sms_usage": row.get("ctd_sms_usage"),
                "ctd_voice_usage": row.get("ctd_voice_usage"),
                "ctd_session_count": row.get("ctd_session_count"),
                "last_activated_date": row.get("last_activated_date"),
                "billing_period_id": billing_period_id,
                "package": row.get("package"),
                "billing_cycle_end_date": row.get("billing_cycle_end_date"),
                "cost_center": row.get("cost_center"),
                "communication_plan": row.get("communication_plan"),
                "foundation_account_number": row.get("foundation_account_number"),
                "billing_account_number": row.get("billing_account_number"),
                "is_active": True,
                "is_deleted": False,
            }
            if tenant_id != row.get("tenant_id"):
                record["sub_tenant_carrier_rate_plan_name"] = record.get("sub_tenant_carrier_rate_plan_name")
                record["sub_tenant_carrier_rate_plan_name_id"] = int(record.get("sub_tenant_carrier_rate_plan_name_id")) if record.get("sub_tenant_carrier_rate_plan_name_id") else None
            if is_mobility:
                record["mobility_device_tenant_id"] = row.get("mdt_id")
                record["mobility_device_id"] = row.get("mobility_device_id")
            else:
                record["device_tenant_id"] = row.get("dt_id")
                record["m2m_device_id"] = row.get("device_id")
            return record
        
        # Step 10: Build records for new devices to insert
        new_records = []
        if new_device_ids:
            new_inventory_df = inventory_df[inventory_df["device_id"].isin(new_device_ids)]
            new_records = [build_record(row) for _, row in new_inventory_df.iterrows()]
            
        # Step 11: Build records for existing devices to update
        update_records = []
        if existing_device_ids:
            existing_inventory_df = inventory_df[inventory_df["device_id"].isin(existing_device_ids)]
            update_records = [build_record(row) for _, row in existing_inventory_df.iterrows()]
        
        # Step 12: Insert new cross-provider device history records
        inserted_count = 0
        inserted_ids = []
        if new_records:
            inserted_ids = tenant_database.insert_data_return_ids(new_records,"cross_provider_device_history", "id")
            inserted_count = len(inserted_ids)
            logging.info(f"Inserted {inserted_count} new cross-provider device history records")
        else:    
            logging.info(f"### history_table_updates No Records to insert into cross_provider_device_history table")    
        
        # Step 13: Update existing cross-provider device history records
        updated_count = 0
        updated_ids = []
        if update_records:
            # remove created_by and created_date from update records to avoid updating those fields
            for record in update_records:
                record.pop("created_by", None)
                record.pop("created_date", None)
            updated_ids = tenant_database.bulk_update_return_ids(
                "cross_provider_device_history", 
                update_records, 
                search_column=cross_provider_device_column,
                static_conditions={"service_provider_id": service_provider_id, "billing_period_id": billing_period_id, "tenant_id": tenant_id},
                return_id_column="id"
            )
            if updated_ids:
                updated_count = len(updated_ids)
                logging.info(f"Updated {updated_count} existing cross-provider device history records")
        else:
            logging.info(f"### history_table_updates No records found to update in cross_provider_device_history table")    
            
        ####################################### smi_cross_provider_device_history table ################################################
        
        # Step 14 : Combine inserted and updated IDs for smi_cross_provider_device_history sync
        smi_update_ids = inserted_ids + updated_ids
        logging.info(f"### smi_update_ids size : {len(smi_update_ids)} and inserted_ids size : {len(inserted_ids)} and updated_ids size: {len(updated_ids)}")
        ids_to_update_in_smi = []
        ids_to_insert_in_smi = []
        # Step 10: Check which device history IDs already exist in smi_cross_provider_device_history
        if smi_update_ids:
            smi_device_history_df = tenant_database.get_data(
                "smi_cross_provider_device_history",
                {"cdhid": smi_update_ids},
                ["id","cdhid"]
            )
            logging.info(f"### smi_device_history_df size :{len(smi_device_history_df)}")
            if not smi_device_history_df.empty:
                smi_device_history_ids = smi_device_history_df["cdhid"].tolist()
                ids_to_update_in_smi = [id for id in smi_update_ids if id in smi_device_history_ids]
                ids_to_insert_in_smi = [id for id in smi_update_ids if id not in smi_device_history_ids]
            else:
                ids_to_update_in_smi = []
                ids_to_insert_in_smi = smi_update_ids
        else:
            logging.info(f"### smi_update_ids size : {len(smi_update_ids)}") 

        # Step 11: Fetch updated device history records to get device_tenant_id mapping
        updated_device_history_df = tenant_database.get_data(
            "cross_provider_device_history",
            {"id": smi_update_ids},
            [history_dt_column,"id"]
        )

        logging.info(f"#### updated_device_history_df size:{len(updated_device_history_df)} ")
        if not updated_device_history_df.empty:
            updated_device_tenant_ids = updated_device_history_df[history_dt_column].tolist()
            device_history_dict = updated_device_history_df.set_index(history_dt_column)["id"].to_dict()
        else:
            updated_device_tenant_ids = []
            device_history_dict = {}
    
        # Step 15 : Fetch inventory records for devices that need smi_cross_provider_device_history sync
        inventory_df_for_smi = tenant_database.get_data(
            "sim_management_inventory",
            {inventory_dt_column: updated_device_tenant_ids, "is_active": True, "service_provider_id": service_provider_id}
        )
        logging.info(f"### inventory_df_for_smi size : {len(inventory_df_for_smi)}")
        
        # Step 16: Define helper function to build smi_cross_provider_device_history record
        def build_smi_cross_provider_record(row):
            """
                Build a record dictionary for inserting/updating `smi_cross_provider_device_history`.
                Args:
                    row (Series/dict): Inventory row containing device and usage details.
                Returns:
                    dict: Prepared SMI device history record.
            """
            device_tenant_id = row.get(inventory_dt_column)
            device_history_id = device_history_dict.get(device_tenant_id)
            record = {
                "changed_date": datetime.now(),
                "sim_management_inventory_id": row.get("id"),
                "service_provider_id": row.get("service_provider_id"),
                "iccid": row.get("iccid"),
                "imsi": row.get("imsi"),
                "msisdn": row.get("msisdn"),
                "imei": row.get("imei"),
                "device_status_id": row.get("device_status_id"),
                "carrier_rate_plan_id": row.get("carrier_rate_plan_id"),
                "communication_plan": row.get("communication_plan"),
                "communication_plan_id": row.get("communication_plan_id"),
                "customer_id": row.get("customer_id"),
                "customer_rate_plan_id": row.get("customer_rate_plan_id"),
                "customer_rate_plan_name": row.get("customer_rate_plan_name"),
                "customer_rate_pool_id": row.get("customer_rate_pool_id"),
                "customer_rate_pool_name": row.get("customer_rate_pool_name"),
                "last_usage_date": row.get("last_usage_date"),
                "carrier_cycle_usage": row.get("carrier_cycle_usage_bytes"),
                "created_by": created_by,
                "created_date": datetime.now(),
                "modified_by": created_by,
                "modified_date": datetime.now(),
                "last_activated_date": row.get("last_activated_date"),
                "is_active": True,
                "is_deleted": False,
                "account_number": row.get("rev_customer_id"),
                "provider_date_added": row.get("date_added"),
                "provider_date_activated": row.get("date_activated"),
                "cost_center": row.get("cost_center"),
                "username": row.get("username"),
                "account_number_integration_authentication_id": row.get("account_number_integration_authentication_id"),
                "billing_period_id": billing_period_id,
                "tenant_id": row.get("tenant_id"),
                "customer_data_allocation_mb": row.get("customer_data_allocation_mb"),
                "device_tenant_id": row.get("dt_id"),
                "mobility_device_tenant_id": row.get("mdt_id"),
                "foundation_account_number": row.get("foundation_account_number"),
                "billing_account_number": row.get("billing_account_number"),
                "ip_address": row.get("ip_address"),    
                "device_status":row.get("sim_status"),
                "carrier_sms_usage":row.get("carrier_sms_usage"),
                "carrier_voice_usage":row.get("carrier_voice_usage"),     
            }
            record["cdhid"] = device_history_id
            active_in_cycle = True if (row.get("sim_status").lower() in ["active","activated","a"]) else False
            if active_in_cycle:
                record["active_in_cycle"] = True
            else:
                record["active_in_cycle"] = False
                
            if tenant_id != row.get("tenant_id"):
                record["sub_tenant_carrier_rate_plan_name"] = record.get("sub_tenant_carrier_rate_plan_name")
                record["sub_tenant_carrier_rate_plan_name_id"] = int(record.get("sub_tenant_carrier_rate_plan_name_id")) if record.get("sub_tenant_carrier_rate_plan_name_id") else None
            if is_mobility:
                record["mobility_device_tenant_id"] = row.get("mdt_id")
                record["m2m_device_id"] =  row.get("device_id")
            else:
                record["device_tenant_id"] = row.get("dt_id")
                record["mobility_device_id"] =  row.get("device_id") 
            return record
        
        # Step 17: Build records for smi_cross_provider_device_history update
        smi_update_records = []
        smi_insert_records = [] 
        if ids_to_update_in_smi or ids_to_insert_in_smi : 
            for _, row in inventory_df_for_smi.iterrows():
                history_id = device_history_dict.get(row.get(inventory_dt_column))

                if history_id in ids_to_update_in_smi:
                    smi_update_records.append(build_smi_cross_provider_record(row))

                elif history_id in ids_to_insert_in_smi:
                    smi_insert_records.append(build_smi_cross_provider_record(row))
        logging.info(f"### smi_update_records : {len(smi_update_records)} and smi_insert_records size :{len(smi_insert_records)} ")        
                
        # Step 18 : Update existing smi_cross_provider_device_history records
        if smi_update_records:
            # remove created_by and created_date from update records to avoid updating those fields
            for record in smi_update_records:
                record.pop("created_by", None)
                record.pop("created_date", None)
            tenant_database.bulk_update_data(
                "smi_cross_provider_device_history",
                smi_update_records,
                search_column=history_dt_column,
                static_conditions={"service_provider_id": service_provider_id, "billing_period_id": billing_period_id}
            )
            logging.info(f"Updated {len(smi_update_records)} records in smi_cross_provider_device_history")
        else:
            logging.info(f"### No records found to update in smi_cross_provider_device_history smi_update_records : {len(smi_update_records)}")    

        # Step 19: Insert new smi_cross_provider_device_history records
        if smi_insert_records:
            tenant_database.insert_data(smi_insert_records, "smi_cross_provider_device_history")
            logging.info(f"Inserted {len(smi_insert_records)} records in smi_cross_provider_device_history")
        else:
            logging.info(f"### No records found to insert into smi_cross_provider_device_history table smi_insert_records size: {len(smi_insert_records)}")     
        # Step 20: Log success audit entry
        try:
            audit_data = {
                "service_name": "history_table_updates",
                "created_date": datetime.now(),
                "created_by": created_by,
                "status": "Success",
                "tenant_name": tenant_name,
                "comments": f"Cross-provider device history sync completed for {service_provider} on {usage_date}",
                "module_name": "Carrier sync",
                "request_received_at": datetime.now(),
                "session_id": None
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Audit logging failed: {e}")            
        
        # Step 21: Return success response with sync summary
        response={
            "flag": True, 
            "message": f"Successfully synced cross-provider device history: {inserted_count} inserted, {updated_count} updated",
            "records_inserted": inserted_count,
            "records_updated": updated_count
        }
        return response
    except Exception as e:
        logging.error(f"Error in history_table_updates: {e}")
        
        # Error audit logging
        try:
            error_data = {
                "service_name": "history_table_updates",
                "error_message": str(e),
                "error_type": str(type(e).__name__),
                "users": created_by,
                "session_id": None,
                "tenant_name": tenant_name,
                "comments": f"Cross-provider device history sync failed for {service_provider} on {usage_date}",
                "module_name": "Carrier sync",
                "request_received_at": datetime.now()
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as audit_error:
            logging.error(f"Error audit logging failed: {audit_error}")     
        response={"flag": False, "message": f"Error in history_table_updates: {str(e)}"}
        return response
      
def update_device_usage_table(data,tenant_database,common_utils_database):
    """
    Updates device usage table with data from staging table.
    
    Args:
        data (dict): Request data containing:
            - created_by (str): User performing the operation
            - delayed_days (int): Number of days to delay usage date
            - staging_table (str): Name of staging table
            - tenant_name (str): Tenant name
            - service_provider (str): Service provider name
            - iccids (list): List of ICCIDs to process
    
    Returns:
        dict: Result with flag and message
    """
    logging.info(f"update_device_usage_table request received {data}")
    # Step 1: Extract required parameters from request data
    created_by = data.get("created_by", "pod19_container")
    delayed_days = data.get("delayed_days", 1)
    staging_table = data.get("staging_table",'pod19_carrier_sync_staging')
    tenant_name = data.get("tenant_name",None)
    tenant_id=data.get('tenant_id',None)
    service_provider_id=data.get('service_provider_id',None)
    # tenant_db_config      = data.get("tenant_db_config", {})
    iccids = []
    try:
        # Step 2: Fetch active ICCIDs from sim_management_inventory
        inventory_df = tenant_database.get_data(
            "sim_management_inventory",
            {"service_provider_id": service_provider_id,"tenant_id":tenant_id,"is_active":True},
            ["id", "iccid", "device_id", "mobility_device_id", "device_status_id"]
        )
        if inventory_df is not None and not inventory_df.empty:
            iccids = inventory_df["iccid"].astype(str).tolist()

        logging.info(f"Fetched {len(iccids)} active ICCIDs from main table")
        if not iccids:
            logging.info(f"No ICCIDs provided for {tenant_name}")
            return {"flag": False, "message": "No ICCIDs provided"}
        
        # Step 3: Calculate usage date based on delayed_days parameter
        usage_date = datetime.now().date() - timedelta(days=delayed_days)
        
        # Step 4: Fetch usage data from staging table for active ICCIDs
        staging_usage_df = tenant_database.get_data(
            staging_table,
            {"iccid": iccids},
            ["iccid", "ctd_sms_usage", "ctd_data_usage", "ctd_voice_usage"],
        )
        if staging_usage_df.empty:
            logging.warning(f"No staging usage records found for {tenant_name}")
            return {"flag": False, "message": "No staging usage records found"}
        
        # Step 5: Merge inventory and staging data on ICCID and remove duplicates
        usage_df = (
            pd.merge(inventory_df, staging_usage_df, on="iccid", how="inner")
            .drop_duplicates(subset=["iccid"])
            .reset_index(drop=True)
        )
        if usage_df.empty:
            logging.warning(f"No matched usage records after merge for {tenant_name}")
            return {"flag": False, "message": "No matched usage records"}

        device_ids = usage_df["device_id"].tolist()
        
        # Step 6: Check which device IDs already have usage records for the usage_date
        device_usage_present_df = tenant_database.get_data(
            "device_usage",
            {"m2m_device_id": device_ids, "usage_date": usage_date},
            ["m2m_device_id"],
        )
        existing_device_ids = set(
            device_usage_present_df["m2m_device_id"].tolist()
        )
        
        # Step 7: Split merged data into new records (insert) and existing records (update)
        new_usage_df = usage_df[~usage_df["device_id"].isin(existing_device_ids)]
        update_usage_df = usage_df[usage_df["device_id"].isin(existing_device_ids)]
        
        # Step 8: Build and insert new device usage records
        if not new_usage_df.empty:
            insert_records = [
                {
                    "sim_management_inventory_id": row["id"],
                    "m2m_device_id": row["device_id"],
                    "mobility_device_id": row["mobility_device_id"],
                    "data_usage": row["ctd_data_usage"],
                    "sms_usage": row["ctd_sms_usage"],
                    "voice_usage": row["ctd_voice_usage"],
                    "usage_date": usage_date,
                    "device_status_id": row["device_status_id"],
                    "created_by": created_by,
                    "modified_by":created_by
                }
                for _, row in new_usage_df.iterrows()
            ]

            usage_insert_flag=tenant_database.insert_data(insert_records,"device_usage")
            logging.info(f"Inserted {len(insert_records)} usage records and usage_insert_flag is {usage_insert_flag}")
        
        # Step 9: Build and update existing device usage records
        if not update_usage_df.empty:
            update_records = [
                {
                    "sim_management_inventory_id": row["id"],
                    "m2m_device_id": row["device_id"],
                    "mobility_device_id": row["mobility_device_id"],
                    "data_usage": row["ctd_data_usage"],
                    "sms_usage": row["ctd_sms_usage"],
                    "voice_usage": row["ctd_voice_usage"],
                    "device_status_id": row["device_status_id"],
                    "modified_by":created_by
                }
                for _, row in update_usage_df.iterrows()
            ]

            usage_update_flag=tenant_database.bulk_update_data(
                "device_usage",
                update_records,
                search_column="m2m_device_id",
                static_conditions={"usage_date": usage_date}
            )
            logging.info(f"Updated {len(update_records)} usage records and usage_update_flag is {usage_update_flag}")
        
        # Step 10: Log success audit entry
        try:
            audit_data = {
                "service_name": "update_device_usage_table",
                "created_date": datetime.now(),
                "created_by": created_by,
                "status": "Success",
                "tenant_name": tenant_name,
                "comments": f"Updated device usage for {len(iccids)} ICCIDs on {usage_date}",
                "module_name": "Carrier Sync",
                "request_received_at": datetime.now(),
                "session_id": None
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Audit logging failed: {e}")
        
        # Step 11: Return success response
        return {"flag": True, "message": "Device usage updated successfully"}
    except Exception as e:
        logging.exception(f"Error in update_device_usage_table: {e}")
        
        # Step 12: Log error audit entry on failure
        try:
            error_data = {
                "service_name": "update_device_usage_table",
                "error_message": str(e),
                "error_type": str(type(e).__name__),
                "users": data.get("created_by", "pod19 sync container"),
                "session_id": None,
                "tenant_name": data.get("tenant_name", ""),
                "comments": f"Failed to update device usage for {data.get('service_provider', '')}",
                "module_name": "Carrier Sync",
                "request_received_at": datetime.now()
            }
            # common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as audit_error:
            logging.error(f"Error audit logging failed: {audit_error}")
        return {"flag": False, "message": "Failed to update device usage"}
        

def normalize_date(d):
    """Utility function to normalize date inputs to date objects."""
    if not d:
        return None
    if isinstance(d, datetime):
        return d.date()
    if isinstance(d, date):
        return d
    return datetime.strptime(str(d), "%Y-%m-%d").date()
# 
def process_iccid_usage(iccids,headers,tenant_database,syncrun_count,api_iccids,data,billing_period_id,iccid_to_cycle_usage):
    """Process a list of ICCIDs to fetch usage data and store in staging tables with parallel requests.
    Args:        iccids (list): List of ICCIDs to process
        custom_url1 (str): Base URL for fetching device usage data
        retries (int): Number of retries for API calls  
        headers (dict): Headers to include in API requests"""
    service_provider_name = data.get("service_provider_name", "")
    service_provider_id   = data.get("service_provider_id", "")
    tenant_name           = data.get("tenant_name", "")
    api_limit             = data.get("api_details_map", {}).get("api_limit", 0)
    custom_url1           = data.get("custom_url1", {}).get("url")
    retries               = data.get("api_details_map", {}).get("retries", 0)
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    parllel_requests = 10
    with ThreadPoolExecutor(max_workers=parllel_requests) as executor:
            for i in range(0, len(iccids), api_limit):
                batch = iccids[i:i + api_limit]
                futures = {}
                logging.info(
                    f"[{tenant_name}] Processing batch {i // api_limit + 1} with {len(batch)} ICCIDs")
                batch_staging_records = []
                batch_audit_records = []
                for iccid in batch:
                    def task(iccid=iccid):
                        usage = fetch_device_usage(iccid,custom_url1,retries,headers) or {}
                        ctd_data_usage = usage.get("ctdDataUsage", 0) or 0
                        carrier_cycle_usage_mb = iccid_to_cycle_usage.get(iccid, 0)
                        total_cycle_usage_mb = round((ctd_data_usage / (1024 * 1024)), 3)
                        today_usage_mb = total_cycle_usage_mb- carrier_cycle_usage_mb
                        today_usage_bytes = int(today_usage_mb * 1024 * 1024)
                        # storing the records in staging table
                        records= {
                            "service_provider_id": service_provider_id,
                            "service_provider_name": service_provider_name,
                            "bill_period_id": int(billing_period_id),
                            "iccid": usage.get("iccid", iccid),
                            "imsi": usage.get("imsi"),
                            "msisdn": usage.get("msisdn"),
                            "imei": usage.get("imei"),
                            "status": usage.get("status"),
                            "rate_plan": usage.get("ratePlan"),
                            "communication_plan": usage.get("communicationPlan"),
                            "ctd_data_usage": today_usage_bytes,
                            "ctd_data_usage_mb": today_usage_mb,
                            "ctd_sms_usage": usage.get("ctdSMSUsage", 0),
                            "ctd_voice_usage": usage.get("ctdVoiceUsage", 0),
                            "ctd_session_count": usage.get("ctdSessionCount"),
                            "aggregated_usage": total_cycle_usage_mb,
                            "aggregated_usage_bytes":ctd_data_usage,
                            "overage_limit_reached": usage.get("overageLimitReached"),
                            "overage_limit_override": usage.get("overageLimitOverride"),
                            "created_by": "pod19 sync container",
                            "modified_by": "pod19 sync container",
                            "from_api": iccid in api_iccids,
                        }
                        audit_record = records.copy()
                        audit_record.update({
                            "sync_run_count": syncrun_count,
                            "sync_date": now,
                            "triggered_by": "pod19 sync container",
                        })
        
                        return records, audit_record
                    futures[executor.submit(task)] = iccid

                for fut in as_completed(futures):
                    try:
                        records, audit_record = fut.result()
                        batch_staging_records.append(records)
                        batch_audit_records.append(audit_record)
                    except Exception as e:
                        logging.exception(
                            f"[{tenant_name}] Error processing ICCID: {e}"
                        )
                if batch_staging_records:
                    tenant_database.insert_data(
                        batch_staging_records,
                        "pod19_carrier_sync_staging"
                    )
        
                if batch_audit_records:
                    tenant_database.insert_data(
                        batch_audit_records,
                        "pod19_carrier_sync_staging_audit"
                    )
                # Optional throttle between batches
                if i + api_limit < len(iccids):
                    time.sleep(1)  
    logging.info(f"### process_iccid_usage for {tenant_name} Completed processing ICCIDs for usage data fetch and storage with {len(batch_staging_records)} ICCIDs")
    response = {
        "flag": True,
        "message": "Completed processing ICCIDs for usage data fetch and storage.",
        "devices_processed": len(batch_staging_records)
    }
    return response      
        
def fetch_device_usage(iccid,custom_url1,retries,headers):
    if not iccid:
        return {}
    logging.info(f"Fetching usage for ICCID: {iccid}")
    url2 = f"{custom_url1}/{iccid}/ctdUsages"

    for attempt in range(1, retries + 1):
        try:
            resp = requests.get(url2, headers=headers, timeout=60)
            if resp.status_code == 200:
                return resp.json()
            elif 500 <= resp.status_code < 600:
                wait_time = 2 ** retries + random.uniform(0, 2)
                logging.info(
                    f" Usage fetch for {iccid} returned status {resp.status_code}. Retrying in {wait_time} seconds..."
                )
                time.sleep(wait_time)
            else:
                logging.info(
                    f" Usage fetch for {iccid} returned status {resp.status_code}. No retry."
                )
                return {}
        except Exception as e:
            logging.info(
                f" Usage failed for {iccid} attempt {attempt}: {e}"
            )
            if attempt == retries:
                return {}
            time.sleep(2 * attempt)
# fetching the devices from api with pagination and parallel requests
def fetch_devices_page(page_number, retries, headers, custom_url1,start_date):
    """Fetch one page from API"""
    # here modifiedSince is set to 1 day back to fetch the recent data 
    # but it can be modified based on the requirement
    params = {
        "modifiedSince":start_date,
        "pageNumber": page_number,
    }
    for attempt in range(1, retries + 1):
        try:
            response = requests.get(
                custom_url1,
                headers=headers,
                params=params,
                timeout=30
            )
            if response.status_code == 200:
                return response.json()
            elif 500 <= response.status_code < 600:
                wait_time = 2 ** retries + random.uniform(0, 2)
                if attempt == retries:
                    return {}
                time.sleep(wait_time)
            else:
                logging.info(
                    f"Request to {custom_url1} returned status {response.status_code}. No retry."
                )
                return {}
        except Exception as e:
            logging.info(
                f"Request failed for {custom_url1} attempt {attempt}: {e}"
            )
            if attempt == retries:
                return {}
            time.sleep(2 * attempt)

    return {}


# Function to fetch all ICCIDs using parallel pagination
def fetch_api_devices( page_size,headers, custom_url1, tenant_name,start_date,retries):
    """
    Fetch all ICCIDs using parallel pagination
    """
    page_count=1
    first_page_response = fetch_devices_page(page_count,retries, headers, custom_url1,start_date)

    total_count = first_page_response.get("totalCount", 0)
    devices = first_page_response.get("devices", [])

    total_pages = math.ceil(total_count / page_size)

    all_iccids = [
        device["iccid"]
        for device in devices
        if device.get("iccid")
    ]

    # Fetch remaining pages in parallel
    if total_pages > 1:
        with ThreadPoolExecutor(max_workers=10) as executor:
            futures = {
                executor.submit(fetch_devices_page,
                    page,
                    retries,
                    headers,
                    custom_url1,
                    start_date): page
                for page in range(2, total_pages + 1)
            }

            for future in as_completed(futures):
                data = future.result()
                for device in data.get("devices", []):
                    iccid = device.get("iccid")
                    if iccid:
                        all_iccids.append(iccid)

    all_iccids = list(set(all_iccids))

    return all_iccids

##function to get or create billing period
def get_or_create_billing_period(
    tenant_id,
    service_provider_id,
    service_provider_name,
    tenant_database,
    common_utils_database,
    progress_tracker_id,  # Changed from audit_id for consistency
    billing_cycle_day,
    force_end_of_day=True,
    start_hour=0,
    start_minute=0,
    start_second=0,
    created_by="pod19 sync container",
    data=None  # Added data parameter
):
    """
    Determines or creates a billing period based on input data.start_date.
    If start_date is missing or invalid, it falls back to today's UTC date.
    """
    logging.info(f"###run_pod19_sync get_or_create_billing_period for tenant_id={tenant_id} and service_provider_id={service_provider_id} started.")
    try:
        # 1️⃣ Determine sync_date
        sync_date = None

        if data and data.get("start_date"):
            start_date_str = data["start_date"]
            try:
                # Extract date portion (before 'T')
                date_part = start_date_str.split("T")[0]
                sync_date = datetime.strptime(date_part, "%Y-%m-%d").date()
                logging.info(f"###run_pod19_sync Derived sync_date from start_date: {sync_date}")
            except Exception:
                logging.warning(
                    f"###run_pod19_sync Invalid start_date format ({start_date_str}). "
                    f"Falling back to today's UTC date."
                )

        # Fallback to today's UTC date if start_date was missing/invalid
        if not sync_date:
            sync_date = datetime.utcnow().date()
            logging.info(f"### Using fallback sync_date: {sync_date}")

        today_str = sync_date.strftime("%Y-%m-%d")
        # 2️⃣ Check existing billing period
        query = """
            SELECT id
            FROM billing_period
            WHERE tenant_id = %s
              AND service_provider_id = %s
              AND billing_cycle_start_date <= %s
              AND billing_cycle_end_date >= %s
              AND is_deleted = false
            LIMIT 1
        """
        result = tenant_database.execute_query(
            query,
            params=[tenant_id, service_provider_id, today_str, today_str]
        )

        logging.info(f"###run_pod19_sync Existing billing_period query result: {result}")

        if result is not False and not result.empty:
            billing_period_id = result.iloc[0]["id"]

            if data:
                data["current_status"] = "Billing period determined"
                ##function to update progress tracker
                update_progress_tracker(
                    progress_tracker_id=progress_tracker_id,
                    common_utils_database=common_utils_database,
                    action="update",
                    progress=30,
                    data=data
                )
            logging.info(
                f"Billing period reused | billing_period_id={billing_period_id}"
            )
            response = { 
                "flag": True,
                "billing_period_id": billing_period_id,
                "is_new_period": False
            }
            return response

        # 3️⃣ Compute new billing period boundaries
        year = sync_date.year
        month = sync_date.month

        if sync_date.day >= billing_cycle_day:
            start_year = year
            start_month = month
        else:
            start_month = month - 1 or 12
            start_year = year if month > 1 else year - 1

        billing_cycle_start_date = datetime(
            start_year, start_month, billing_cycle_day,
            start_hour, start_minute, start_second
        )

        # Next cycle start
        if start_month == 12:
            end_year = start_year + 1
            end_month = 1
        else:
            end_year = start_year
            end_month = start_month + 1

        next_cycle_start = datetime(
            end_year, end_month, billing_cycle_day,
            start_hour, start_minute, start_second
        )

        billing_cycle_end_date = (
            next_cycle_start.replace(hour=23, minute=59, second=59)
            if force_end_of_day else next_cycle_start
        )

        # 4️⃣ Insert new billing period
        billing_data = {
            "tenant_id": tenant_id,
            "service_provider_id": service_provider_id,
            "service_provider": service_provider_name,
            "bill_year": billing_cycle_start_date.year,
            "bill_month": billing_cycle_start_date.month,
            "billing_cycle_start_date": billing_cycle_start_date,
            "billing_cycle_end_date": billing_cycle_end_date,
            "billing_period_status_id": 1,
            "is_active": True,
            "is_deleted": False,
            "created_by": created_by,
            "modified_by": created_by,
        }

        logging.info(f"###run_pod19_sync billing_data: {billing_data}")

        billing_period_id = tenant_database.insert_data(
            billing_data,
            "billing_period"
        )
        logging.info(
            f"###run_pod19_sync New billing period created | billing_period_id={billing_period_id}"
        )
        # 5. Update progress tracker
        if data:  # Check if data is provided
            data["current_status"] = "Billing period determined"
            update_progress_tracker(
                progress_tracker_id=progress_tracker_id,
                common_utils_database=common_utils_database,
                action="update",
                progress=30,
                data=data
            )

        response = {
            "flag": True,
            "billing_period_id": billing_period_id,
            "is_new_period": True
        }
        return response

    except Exception as e:
        logging.exception("###run_pod19_sync Error determining billing period")
        response = {
            "flag": False,
            "message": "Error determining billing period",
            "details": str(e)
        }
        return response

##function to fetch integration details
def fetch_integration_details(
    tenant_database,
    integration_id,
    tenant_name,tenant_id
):
    """
    Fetch active integration authentication details for a given integration ID.

    Args:
        tenant_database (DB): Tenant database connection
        integration_id (str): Integration identifier
        tenant_name (str): Tenant name (for logging)
    Returns:
        dict:
            {
                "flag": True,
                "data": [integration_details]
            }
            OR
            {
                "flag": False,
                "message": "<error message>"
            }
    """
    try:
        ##Query the tenant database for active integration authentication details matching the provided integration_id and tenant_id
        integration_df = tenant_database.get_data(
            "integration_authentication",
            {
                "is_active": True,
                "integration_id": integration_id,
                "tenant_id": tenant_id
            }
        )
        logging.info(
            f"### run_pod19_sync devices and {tenant_name} "
            f"integration_details_dataframe: {integration_df}"
        )
        if integration_df.empty:
            message = "No active integration found for the given integration_id"
            logging.error(
                f"### run_pod19_sync devices and {tenant_name} {message}"
            )
            return {"flag": False, "message": message}
        integration_details = integration_df.to_dict(orient="records")

        logging.info(
            f"### run_pod19_sync devices and {tenant_name} "
            f"integration_details: {integration_details}"
        )
        return {"flag": True, "integration_details": integration_details}
    except Exception as e:
        logging.exception(
            f"### run_pod19_sync devices and {tenant_name} "
            f"Error fetching integration details: {e}"
        )
        return {"flag": False, "message": str(e)}

##function to clean staging table
def clean_staging_table(tenant_database, table_names, username):
    """
    Cleans one or more staging tables in the tenant database.

    Args:
        tenant_database (DB): Database connection object for tenant
        table_names (str or list): Single table name or list of table names
        username (str): User performing the cleanup

    Returns:
        dict: Cleanup results for each table
    """
    results = {}
    # Normalize to list
    if isinstance(table_names, str):
        table_names = [table_names]
    
    for table in table_names:
        query=f"""SELECT setval(pg_get_serial_sequence('{table}', 'id'),1,false);"""
        try:
            status = tenant_database.delete_data(table)
            logging.info(f"Staging table {table} cleaned successfully by {username}")
            reset_id=tenant_database.execute_query(query,True)  
            logging.info(f"Staging table {table} ID reset successfully by {username},{reset_id}")      
            results[table] = {
                "flag": True,
                "status": status,
                "message": f"Staging table {table} cleaned successfully"
            }

        except Exception as e:
            logging.exception(f"Error cleaning staging table {table}: {e}")
            results[table] = {
                "flag": False,
                "status": False,
                "message": f"Error cleaning staging table {table}",
                "details": str(e)
            }
    return results
    
def device_history_sync(billing_period_id,inventory_df,tenant_database,service_provider_id,service_provider,usage_date,created_by,common_utils_database,tenant_name,tenant_id):
    """
    Sync device history records for a billing period.

    Inserts new device history entries and updates existing ones based on the
    current inventory data. Also maintains corresponding records in the
    `smi_device_history` table for reporting and auditing.

    Supports both Telegence (mobility) and standard service providers.

    Args:
        billing_period_id (int): Billing cycle identifier.
        inventory_df (DataFrame): Latest inventory/device data.
        tenant_database (DB): Tenant database connection object.
        service_provider_id (int): Service provider identifier.
        service_provider (str): Service provider name.
        usage_date (date/str): Usage date for sync reference.
        created_by (str): User triggering the sync.
        common_utils_database (DB): Common utilities database connection.
        tenant_name (str): Tenant name for audit logging.

    Returns:
        None
    """
    logging.info(f"Starting device_history_sync for billing_period_id: {billing_period_id}, service_provider_id: {service_provider_id} usage_date: {usage_date}")
    billing_period_id = int(billing_period_id) if billing_period_id else None
    service_provider_id = int(service_provider_id) if service_provider_id else None
    tenant_id = int(tenant_id) if tenant_id else None
    try:
        # Step 1: Determine table and column names based on service provider type
        if "telegence" in service_provider.lower():
            device_tenant_ids = inventory_df["mdt_id"].unique().tolist()
            history_table = "mobility_device_history"
            history_dt_column = "mobility_device_tenant_id"
            inventory_dt_column = "mdt_id"
            history_id_column = "mhid"
            is_mobility = True
        else:
            history_table = "device_history"
            device_tenant_ids = inventory_df["dt_id"].unique().tolist()
            history_dt_column = "device_tenant_id"
            inventory_dt_column = "dt_id"
            history_id_column = "dhid"
            is_mobility = False
        
        # Step 2: Fetch existing device history records for the billing period
        device_history_df = tenant_database.get_data(
            history_table,
            {"service_provider_id": service_provider_id, 
            "billing_period_id": billing_period_id,
            "is_active": True
            },
            [history_dt_column]
        )

        # Step 3: Split device IDs into new and existing based on history table
        if not device_history_df.empty:
            device_history_ids = set(device_history_df[history_dt_column].tolist())
            new_device_ids = [did for did in device_tenant_ids if did not in device_history_ids]
            existing_device_ids = [did for did in device_tenant_ids if did in device_history_ids]
        else:
            new_device_ids = device_tenant_ids
            existing_device_ids = []
        logging.info(f"device_history_sync - new_device_ids count: {len(new_device_ids)}, existing_device_ids count: {len(existing_device_ids)} , device_history_df size : {len(device_history_df)}")
        
        # Step 4: Define helper function to build device history record from inventory row
        def build_record(row):
            """
            Build a device history record from an inventory row. Prepares a dictionary for inserting/updating records in the
            device_history or mobility_device_history table, including service provider, SIM details, usage, and tenant mapping.
            
            Args:
                row (Series/dict): Inventory row containing device information.
            Returns:
                dict: Formatted device history record.
            """
            record = {
                "service_provider_id": row.get("service_provider_id"),
                "iccid": row.get("iccid"),
                "imsi": row.get("imsi"),
                "msisdn": row.get("msisdn"),
                "imei": row.get("imei"),
                "changed_date": datetime.now(),
                "device_status_id": row.get("device_status_id"),
                "status": row.get("sim_status"),
                "carrier_rate_plan_id": row.get("carrier_rate_plan_id"),
                "rate_plan": row.get("carrier_rate_plan_name"),
                "communication_plan": row.get("communication_plan"),
                "last_usage_date": row.get("last_usage_date"),
                "package": row.get("package"),
                "billing_cycle_end_date": row.get("billing_cycle_end_date"),
                "carrier_cycle_usage": row.get("carrier_cycle_usage_bytes"),
                "ctd_sms_usage": row.get("ctd_sms_usage"),
                "ctd_voice_usage": row.get("ctd_voice_usage"),
                "ctd_session_count": row.get("ctd_session_count"),
                "created_by": created_by,
                "created_date": datetime.now(),
                "modified_by": created_by,
                "modified_date": datetime.now(),
                "last_activated_date": row.get("last_activated_date"),
                "is_active": True,
                "is_deleted": False,
                "is_pushed": False,
                "account_number": row.get("rev_customer_id"),
                "provider_date_added": row.get("date_added"),
                "provider_date_activated": row.get("date_activated"),
                "cost_center": row.get("cost_center"),
                "username": row.get("username"),
                "account_number_integration_authentication_id": row.get("account_number_integration_authentication_id"),
                "billing_period_id": billing_period_id,
                "customer_id": row.get("customer_id"),
                "customer_rate_plan_id": row.get("customer_rate_plan_id"),
                "customer_rate_pool_id": row.get("customer_rate_pool_id"),
                "tenant_id": row.get("tenant_id")
            }
            if tenant_id != row.get("tenant_id"):
                record["sub_tenant_carrier_rate_plan_name"] = record.get("sub_tenant_carrier_rate_plan_name")
                record["sub_tenant_carrier_rate_plan_name_id"] = int(record.get("sub_tenant_carrier_rate_plan_name_id")) if record.get("sub_tenant_carrier_rate_plan_name_id") else None
            if is_mobility:
                record["id"] = row.get("mobility_device_id")
                record["mobility_device_tenant_id"] = row.get("mdt_id")
            else:
                record["id"] = row.get("device_id")
                record["device_tenant_id"] = row.get("dt_id")
            return record
        
        # Step 5: Build records for new devices to insert into device history
        new_records = []
        if new_device_ids:
            new_inventory_df = inventory_df[inventory_df[inventory_dt_column].isin(new_device_ids)]
            new_records = [build_record(row) for _, row in new_inventory_df.iterrows()]
        else:
            logging.info(f"### new_device_ids size: {len(new_device_ids)}")    
            
        # Step 6: Build records for existing devices to update in device history
        update_records = []
        if existing_device_ids:
            existing_inventory_df = inventory_df[inventory_df[inventory_dt_column].isin(existing_device_ids)]
            update_records = [build_record(row) for _, row in existing_inventory_df.iterrows()]
        else:
            logging.info(f"### existing_device_ids size: {len(existing_device_ids)}")    
        
        # Step 7: Insert new device history records and capture returned IDs
        inserted_count = 0
        inserted_ids = []
        if new_records:
            inserted_ids = tenant_database.insert_data_return_ids(new_records, history_table, "device_history_id")
            inserted_count = len(new_records)
            logging.info(f"Inserted {inserted_count} new device history records")
        else:
            logging.info(f"### device_history_sync No records found into Insert into : {history_table} table")    
        
        # Step 8: Update existing device history records and capture returned IDs
        updated_count = 0
        updated_ids = []
        if update_records:
            # remove created_by and created_date from update records to avoid updating those fields
            for record in update_records:
                record.pop("created_by", None)
                record.pop("created_date", None)
            updated_ids = tenant_database.bulk_update_return_ids(
                history_table,
                update_records, 
                search_column=history_dt_column,
                static_conditions={"service_provider_id": service_provider_id, "billing_period_id": billing_period_id},
                return_id_column="device_history_id"
            )
            if updated_ids:
                updated_count = len(update_records)
                logging.info(f"Updated {updated_count} existing device history records")
        else:
            logging.info(f"### device_history_sync No records found into Update into : {history_table} table")           
        
        # Step 9: Combine inserted and updated IDs for smi_device_history sync
        smi_update_ids = inserted_ids + updated_ids
        logging.info(f"### smi_update_ids size : {len(smi_update_ids)} and inserted_ids size : {len(inserted_ids)} and updated_ids size: {len(updated_ids)}")
        ids_to_update_in_smi = []
        ids_to_insert_in_smi = []
        # Step 10: Check which device history IDs already exist in smi_device_history
        if smi_update_ids:
            smi_device_history_df = tenant_database.get_data(
                "smi_device_history",
                {history_id_column: smi_update_ids},
                [history_id_column,"id"]
            )
            logging.info(f"### smi_device_history_df size :{len(smi_device_history_df)}")
            if not smi_device_history_df.empty:
                smi_device_history_ids = smi_device_history_df[history_id_column].tolist()
                ids_to_update_in_smi = [id for id in smi_update_ids if id in smi_device_history_ids]
                ids_to_insert_in_smi = [id for id in smi_update_ids if id not in smi_device_history_ids]
            else:
                ids_to_update_in_smi = []
                ids_to_insert_in_smi = smi_update_ids
        else:
            logging.info(f"### smi_update_ids size : {len(smi_update_ids)}")        

        # Step 11: Fetch updated device history records to get device_tenant_id mapping
        updated_device_history_df = tenant_database.get_data(
            history_table,
            {"device_history_id": smi_update_ids},
            [history_dt_column,"device_history_id"]
        )

        # updated_device_tenant_ids = updated_device_history_df[history_dt_column].tolist()
        # device_history_dict = (
        #     updated_device_history_df
        #     .set_index(history_dt_column)["device_history_id"]
        #     .to_dict()
        # )
        logging.info(f"#### updated_device_history_df size:{len(updated_device_history_df)} ")
        if not updated_device_history_df.empty:
            updated_device_tenant_ids = updated_device_history_df[history_dt_column].tolist()
            device_history_dict = updated_device_history_df.set_index(history_dt_column)["device_history_id"].to_dict()
        else:
            updated_device_tenant_ids = []
            device_history_dict = {}
    
        # Step 12: Fetch inventory records for devices that need smi_device_history sync
        inventory_df_for_smi = tenant_database.get_data(
            "sim_management_inventory",
            {inventory_dt_column: updated_device_tenant_ids, "is_active": True, "service_provider_id": service_provider_id}
        )
        logging.info(f"### inventory_df_for_smi size : {len(inventory_df_for_smi)}")
        
        # Step 13: Define helper function to build smi_device_history record
        def build_smi_record(row):
            """
                Build a record dictionary for inserting/updating `smi_device_history`.
                Args:
                    row (Series/dict): Inventory row containing device and usage details.
                Returns:
                    dict: Prepared SMI device history record.
            """
            device_tenant_id = row.get(inventory_dt_column)
            device_history_id = device_history_dict.get(device_tenant_id)
            record = {
                "changed_date": datetime.now(),
                "sim_management_inventory_id": row.get("id"),
                "service_provider_id": row.get("service_provider_id"),
                "service_provider_name": row.get("service_provider_display_name"),
                "iccid": row.get("iccid"),
                "imsi": row.get("imsi"),
                "msisdn": row.get("msisdn"),
                "imei": row.get("imei"),
                "device_status_id": row.get("device_status_id"),
                "status": row.get("sim_status"),
                "carrier_rate_plan_id": row.get("carrier_rate_plan_id"),
                "carrier_rate_plan_name": row.get("carrier_rate_plan_name"),
                "communication_plan": row.get("communication_plan"),
                "communication_plan_id": row.get("communication_plan_id"),
                "customer_id": row.get("customer_id"),
                "customer_name": row.get("customer_name"),
                "customer_rate_plan_id": row.get("customer_rate_plan_id"),
                "customer_rate_plan_name": row.get("customer_rate_plan_name"),
                "customer_rate_pool_id": row.get("customer_rate_pool_id"),
                "customer_rate_pool_name": row.get("customer_rate_pool_name"),
                "last_usage_date": row.get("last_usage_date"),
                "billing_cycle_end_date": row.get("billing_cycle_end_date"),
                "carrier_cycle_usage": row.get("carrier_cycle_usage_bytes"),
                "ctd_sms_usage": row.get("ctd_sms_usage"),
                "ctd_voice_usage": row.get("ctd_voice_usage"),
                "ctd_session_count": row.get("ctd_session_count"),
                "created_by": created_by,
                "created_date": datetime.now(),
                "modified_by": created_by,
                "modified_date": datetime.now(),
                "last_activated_date": row.get("last_activated_date"),
                "is_active": True,
                "is_deleted": False,
                "account_number": row.get("rev_customer_id"),
                "provider_date_added": row.get("date_added"),
                "provider_date_activated": row.get("date_activated"),
                "cost_center": row.get("cost_center"),
                "username": row.get("username"),
                "account_number_integration_authentication_id": row.get("account_number_integration_authentication_id"),
                "billing_period_id": billing_period_id,
                "tenant_id": row.get("tenant_id"),
                "customer_data_allocation_mb": row.get("customer_data_allocation_mb"),
                "device_id": row.get("device_id"),
                "device_tenant_id": row.get("dt_id"),
                "mobility_device_tenant_id": row.get("mdt_id"),
                "foundation_account_number": row.get("foundation_account_number"),
                "billing_account_number": row.get("billing_account_number"),
                "ip_address": row.get("ip_address"),                
            }
            if is_mobility:
                record["mhid"] = device_history_id
            else:
                record["dhid"] = device_history_id
            active_in_cycle = True if (row.get("sim_status").lower() in ["active","activated","a"]) else False
            if active_in_cycle:
                record["active_in_cycle"] = True
            else:
                record["active_in_cycle"] = False
            return record
        
        # Step 14: Build records for smi_device_history update
        smi_update_records = []
        smi_insert_records = []
        if ids_to_update_in_smi or ids_to_insert_in_smi : 
            for _, row in inventory_df_for_smi.iterrows():
                history_id = device_history_dict.get(row.get(inventory_dt_column))

                if history_id in ids_to_update_in_smi:
                    smi_update_records.append(build_smi_record(row))

                elif history_id in ids_to_insert_in_smi:
                    smi_insert_records.append(build_smi_record(row))
        logging.info(f"### smi_update_records : {len(smi_update_records)} and smi_insert_records size :{len(smi_insert_records)} ")        
                

        # Step 16: Update existing smi_device_history records
        if smi_update_records:
            # remove created_by and created_date from update records to avoid updating those fields
            for record in smi_update_records:
                record.pop("created_by", None)
                record.pop("created_date", None)
            tenant_database.bulk_update_data(
                "smi_device_history",
                smi_update_records,
                search_column=history_dt_column,
                static_conditions={"service_provider_id": service_provider_id, "billing_period_id": billing_period_id}
            )
            logging.info(f"Updated {len(smi_update_records)} records in smi_device_history")
        else:
            logging.info(f"### No records found to update in smi_device_history smi_update_records : {len(smi_update_records)}")    

        # Step 17: Insert new smi_device_history records
        if smi_insert_records:
            tenant_database.insert_data(smi_insert_records, "smi_device_history")
            logging.info(f"Inserted {len(smi_insert_records)} records in smi_device_history")
        else:
            logging.info(f"### No records found to insert into smi_device_history table smi_insert_records size: {len(smi_insert_records)}")    
        
        # Step 18: Log success audit entry
        try:
            audit_data = {
                "service_name": "device_history_sync",
                "created_date": datetime.now(),
                "created_by": created_by,
                "status": "Success",
                "tenant_name": tenant_name,
                "comments": f"device history sync completed for {service_provider_id} on {usage_date}",
                "module_name": "Carrier sync",
                "request_received_at": datetime.now(),
                "session_id": None
            }
            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Audit logging failed: {e}")

    except Exception as e:
        logging.error(f"Error in device_history_sync: {e}")
        
        # Step 19: Log error audit entry on failure
        try:
            error_data = {
                "service_name": "device_history_sync",
                "error_message": str(e),
                "error_type": str(type(e).__name__),
                "users": created_by,
                "session_id": None,
                "tenant_name": tenant_name,
                "comments": f"device history sync failed for {service_provider_id} on {usage_date}",
                "module_name": "Carrier sync",
                "request_received_at": datetime.now()
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as audit_error:
            logging.error(f"Error audit logging failed: {audit_error}")

 
##function to update progress tracker
def update_progress_tracker(
    progress_tracker_id,
    current_status=None,status=None,total_records_synced = None,
    common_utils_database=None,
    action="insert",now=None,
    progress=0,
    data=None
):
    """
    Insert or update carrier sync audit records.

    Args:
        common_utils_database (DB): Common utils DB connection
        action (str): "insert" or "update"
        audit_id (int): Required for update
        data (dict): Audit data payload

    Returns:
        int | bool
            - insert → returns audit_id
            - update → returns True
    """
    try:
        # INSERT (Sync Start)
        if action == "insert":
            insert_data = {
                "tenant_name": data.get("tenant_name"),
                "service_provider_name": data.get("service_provider_name"),
                "sync_start_time": now,
                "sync_end_time": None,
                "estimated_time": data.get("estimated_time"),
                "execution_duration": None,
                "total_records_synced": 0,
                "current_status": current_status or data.get("current_status", "Sync started"),
                "status": status or data.get("status", "In Progress"),
                "error_code": None,
                "error_message": None,
                "attempt_count": data.get("attempt_count", 0),
                "triggered_by": f"{data.get('service_provider_name')}_{data.get('tenant_name')}_{data.get('username')}",
                "sync_type": data.get("sync_type"),
                "created_by": f"{data.get('service_provider_name')}_{data.get('tenant_name')}_{data.get('username')}",
                "modified_by": data.get("modified_by", "pod19 sync container"),
                "sync_run_count": data.get("sync_run_count", 1),
                "progress":progress or 0
            }
            progress_tracker_id = common_utils_database.insert_data(insert_data,"carrier_sync_audit_logs")
            logging.info(
                f"Carrier sync audit inserted | id={progress_tracker_id} | status={insert_data['current_status']}"
            )
            return {"flag": True, "message": "Progress tracker inserted successfully", "progress_tracker_id": progress_tracker_id}
        # UPDATE (Progress / Completion / Failure)
        elif action == "update":
            update_data = {
                "current_status": current_status or data.get("current_status"),
                "status": status or data.get("status"),
                "total_records_synced": total_records_synced or data.get("total_records_synced") or 0,
                "attempt_count": data.get("attempt_count") or 0,
                "error_code": data.get("error_code"),
                "error_message": data.get("error_message"),
                "sync_end_time": data.get("sync_end_time"),
                "execution_duration": data.get("execution_duration"),
                "modified_by": f"{data.get('service_provider_name')}_{data.get('tenant_name')}_{data.get('username')}",
                "progress": progress or 0
            }
            # remove None values (VERY important)
            update_data = {k: v for k, v in update_data.items() if v is not None}
            common_utils_database.update_dict(
                "carrier_sync_audit_logs",
                update_data,
                and_conditions={"id": progress_tracker_id}
            )
            logging.info(
                f"Carrier sync audit updated | id={progress_tracker_id} | status={update_data.get('current_status')}"
            )
            return {"flag": True, "message": "Progress tracker updated successfully"}
    except Exception as e:
        logging.exception("Error in update_progress_tracker")
        return {"flag": False, "message": "Error in update_progress_tracker", "details": str(e)}