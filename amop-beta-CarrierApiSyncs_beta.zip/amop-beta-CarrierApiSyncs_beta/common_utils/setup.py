from setuptools import setup, find_packages

setup(
    name="common_utils",
    version="0.1",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "common_utils": ["logging.conf", "*.json", "schemas/*.json"],
    },
)