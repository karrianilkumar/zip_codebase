# Importing the necessary Libraries
from py_zipkin.storage import get_default_tracer
import logging
import logging.config
import logging.handlers
import subprocess
import os
import traceback
import common_utils
from inspect import getframeinfo, stack


def sanitize_msg(msg):
    try:
        msg = ascii(msg)
    except:
        pass
    return msg


# class Logging(logging.Logger):
#     def __init__(self, name="common_services", **kwargs):
#         super().__init__(name)
#         self.log_levels = {
#             "debug": logging.DEBUG,
#             "info": logging.INFO,
#             "warning": logging.WARNING,
#             "error": logging.ERROR,
#             "critical": logging.CRITICAL,
#         }
#         print('came here')
#         package_dir = os.path.dirname(__file__)
#         new_conf = os.path.join(package_dir, "logging.conf")
#         print('new_conf',new_conf)
#         self.load_logging_conf(new_conf)
#         self.extra = {"tenantID": None, "service_name": name}
#         self.set_ids(**kwargs)

#     def load_logging_conf(self, file_path):
#         logging.config.fileConfig(file_path)
#         logging.getLogger().setLevel(self.log_levels["info"])

#     def set_ids(self, **kwargs):
#         service_name = None
#         line_no = None
#         file_name = None
#         current_func_name = None

#         try:
#             caller = getframeinfo(stack()[2][0])
#             file_name = caller.filename
#             line_no = caller.lineno
#             current_func_name = caller.function
#         except Exception as e:
#             message = "Failed to get caller stack"
#             logging.error("########", message, e)

#         self.service_name = service_name
#         self.line_no = line_no
#         self.file_name = file_name
#         self.current_func_name = current_func_name
#         self.extra = {
#             "service_name": self.service_name,
#             "fileName": self.file_name,
#             "lineNo": self.line_no,
#             "currentFuncName": self.current_func_name,
#         }

#     def basicConfig(self, *args, **kwargs):
#         logging.basicConfig(**kwargs)

#     def debug(self, msg, *args, **kwargs):
#         self.set_ids()
#         msg = sanitize_msg(msg)
#         logging.debug(msg, extra=self.extra, *args, **kwargs)

#     def info(self, msg, *args, **kwargs):
#         self.set_ids()
#         msg = sanitize_msg(msg)
#         logging.info(msg, extra=self.extra, *args, **kwargs)

#     def warning(self, msg, *args, **kwargs):
#         self.set_ids()
#         msg = sanitize_msg(msg)
#         logging.warning(msg, extra=self.extra, *args, **kwargs)

#     def error(self, msg, *args, **kwargs):
#         self.set_ids()
#         msg = sanitize_msg(msg)
#         logging.error(msg, extra=self.extra, *args, **kwargs)

#     def critical(self, msg, *args, **kwargs):
#         self.set_ids()
#         msg = sanitize_msg(msg)
#         logging.critical(msg, extra=self.extra, *args, **kwargs)

#     def exception(self, msg, *args, **kwargs):
#         self.set_ids()
#         msg = sanitize_msg(msg)
#         logging.exception(msg, extra=self.extra, *args, **kwargs)

#     def getLogger(self, name=None):
#         return logging.getLogger(name=name)

#     def disable(self, level):
#         logging.disable(level)


class Logging:
    def __init__(self, name="common_services", **kwargs):
        self.log_levels = {
            "debug": logging.DEBUG,
            "info": logging.INFO,
            "warning": logging.WARNING,
            "error": logging.ERROR,
            "critical": logging.CRITICAL,
        }
        package_dir = os.path.dirname(__file__)
        new_conf = os.path.join(package_dir, "logging.conf")
        self.load_logging_conf(new_conf)
        self.logger = logging.getLogger(name)
        self.extra = {"tenantID": None, "service_name": name}
        self.set_ids(**kwargs)

    def load_logging_conf(self, file_path):
        if not os.path.exists(file_path):
            raise FileNotFoundError(f"{file_path} doesn't exist")
        logging.config.fileConfig(file_path, disable_existing_loggers=False)

    def set_ids(self, **kwargs):
        try:
            caller = getframeinfo(stack()[2][0])
            self.extra.update({
                "fileName": os.path.basename(caller.filename),
                "lineNo": caller.lineno,
                "currentFuncName": caller.function,
            })
        except Exception as e:
            self.logger.warning("Could not extract caller context: %s", e)

    def debug(self, msg, *args, **kwargs):
        self.set_ids()
        self.logger.debug(sanitize_msg(msg), extra=self.extra, *args, **kwargs)

    def info(self, msg, *args, **kwargs):
        self.set_ids()
        self.logger.info(sanitize_msg(msg), extra=self.extra, *args, **kwargs)

    def warning(self, msg, *args, **kwargs):
        self.set_ids()
        self.logger.warning(sanitize_msg(msg), extra=self.extra, *args, **kwargs)

    def error(self, msg, *args, **kwargs):
        self.set_ids()
        self.logger.error(sanitize_msg(msg), extra=self.extra, *args, **kwargs)

    def critical(self, msg, *args, **kwargs):
        self.set_ids()
        self.logger.critical(sanitize_msg(msg), extra=self.extra, *args, **kwargs)

    def exception(self, msg, *args, **kwargs):
        self.set_ids()
        self.logger.exception(sanitize_msg(msg), extra=self.extra, *args, **kwargs)
