"""
@Author1 : Phaneendra.Y
@Author2 : Nikhil .N
Created Date: 21-06-24
"""
# Importing the necessary Libraries
import requests
import datetime
from datetime import time
from datetime import datetime, timedelta
import time
from io import BytesIO
# from common_utils.data_transfer_main import DataTransfer
import json
import base64
import re
from io import BytesIO
from pytz import timezone
import base64
import os
import boto3
from openpyxl.styles import Alignment, PatternFill, Font
from openpyxl.utils import get_column_letter
#authorize.net dependencies
import xml.etree.ElementTree as ET



# import apicontractsv1
# import createCustomerProfileController
from io import StringIO
# from lxml import etree
import xml.etree.ElementTree as ET
import csv

# Importing the necessary Libraries
import psycopg2
from time import time
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine, exc
from sqlalchemy.exc import OperationalError
from time import time
import pandas as pd
import re
from sqlalchemy import text
from sqlalchemy import literal
from sqlalchemy.orm import sessionmaker
from sqlalchemy import delete, and_, or_
from sqlalchemy import create_engine, Table, MetaData, select, desc, asc, and_,update,or_,insert,func
from sqlalchemy import Integer, String, Float, DateTime, Boolean, Column, Table, MetaData
from sqlalchemy import insert
#from common_utils.logging_utils import Logging
import numpy as np
import json
import os
from datetime import datetime
#logging = Logging(name="db_utils")


##test jenkins
class DB(object):
    def __init__(self, database, host='127.0.0.1', user='root', password='', port='3306' ,customers = None ,service_providers = None,service_provider_id=None ,db_type='postgresql'):
        """
        Initialization of databse object.

        Args:
            databse (str): The database to connect to.
            host (str): Host IP address. For dockerized app, it is the name of
                the service set in the compose file.
            user (str): Username of PostgresSQL server. (default = 'root')
            password (str): Password of PostgresSQL server. For dockerized app, the
                password is set in the compose file. (default = '')
            port (str): Port number for PostgresSQL. For dockerized app, the port that
                is mapped in the compose file. (default = '3306')
        """
        # Assigning instance variables with the given arguments or default values
        self.HOST = host
        self.USER = user
        self.PASSWORD = password
        self.PORT = port
        self.DATABASE = f'{database}'
        self.DB_TYPE = db_type
        self.customers = customers
        self.service_providers = service_providers
        self.service_provider_id = service_provider_id
        # Logging the connection details for debugging purposes
        #print(f'Host: {self.HOST}')
        #print(f'User: {self.USER}')
        #print(f'Port: {self.PORT}')
        #print(f'Database: {self.DATABASE}')
        # Calling the connect method to establish a connection to the database
        self.connect()
        self.file_path = f"C:/Users/Admin/Documents/local/common_utils/schemas/{database}.json"

        # Check if the file exists
        if not os.path.exists(self.file_path):
            print(
                f"File for '{database}' not found. Using default 'default_schema' instead."
            )
            # Replace with default database if file is not found
            self.file_path = f"C:/Users/Admin/Documents/local/common_utils/schemas/default_schema.json"
        self.metadata, self.tables = self.load_schema(self.file_path)

    def __del__(self):
        # This method is called when the object is about to be destroyed
        try:
            print("############### DETROYING THE DB CONNECTION")
            # Attempting to close the database connection
            self.engine.close()
            # Disposing of the database engine to free up resources
            # if self.engine:
            #     self.engine.dispose()
            print('connections are closed')

        except Exception as e:
            print('########### Failed to destroy the DB COnenctions', e)


    def connect(self, max_retry=3):
        retry = 1
        try:
            #start = time.time()
            print(f'Making connection to `{self.DATABASE}`...')
            config = f'postgresql://{self.USER}:{self.PASSWORD}@{self.HOST}:{self.PORT}/{self.DATABASE}'
            #print(f"connection : {config}")
            self.engine = create_engine(config, connect_args={'connect_timeout': 10}, pool_recycle=300)
            print(f'Engine created for `{self.DATABASE}`')
            while retry <= max_retry:
                try:
                    self.engine = self.engine.connect()
                    self.session = sessionmaker(bind=self.engine)()
                    #print(f'Connection established successfully to `{self.DATABASE}`! ({round(time() - start, 2)} secs to connect)')
                    break
                except Exception as e:
                    print(f'Connection failed. Retrying... ({retry}) [{e}]')
                    retry += 1
                    self.engine.dispose()
                    if retry > max_retry:
                        raise Exception('Max retry attempts reached. Could not connect to the database.')
        except Exception as e:
            raise Exception(f'Something went wrong while connecting. Check trace. {e}')


    def type_from_string(self,type_str):
        # Map type strings to SQLAlchemy types
        type_map = {
            'Integer': Integer,
            'String': String,
            'Float': Float,
            'DateTime': DateTime,
            'Boolean': Boolean
            # Add other types as needed
        }
        return type_map.get(type_str, String)  # Default to String if type is not found

    def load_schema(self, schema_file):
        metadata = MetaData()
        tables = {}

        with open(schema_file, 'r') as f:
            schema = json.load(f)

        for table_name, columns in schema.items():
            column_objects = []
            for col in columns:
                col_type = self.type_from_string(col['type'])  # Convert type string to actual type
                column_objects.append(Column(col['name'], col_type, nullable=col['nullable'], primary_key=col['primary_key']))

            tables[table_name] = Table(table_name, metadata, *column_objects)

        return metadata, tables


    def combine_records_excluding_columns(self,data, exclude_columns=['id', 'schema_tag']):
        # Create a DataFrame from the input data
        df = pd.DataFrame(data)

        # Determine which columns to include by excluding the specified columns
        include_columns = df.columns.difference(exclude_columns)

        # Group by the include_columns and perform aggregation
        result = (
            df.groupby(include_columns.tolist(), as_index=False)
            .agg(
                id=('id', lambda x: '-'.join(map(str, x))),  # Join original IDs
                schema_tag=('schema_tag', lambda x: '-'.join(set(x)))  # Aggregate schema tags
            )
        )

        return result


    def fetch_schemas(self):
        schema_query = """
        SELECT nspname AS schema_name
        FROM pg_catalog.pg_namespace
        WHERE nspname NOT LIKE 'pg_%'
        AND nspname != 'information_schema';
        """

        with self.engine as connection:
            schemas_result = connection.execute(text(schema_query)).fetchall()

        schemas = [row[0] for row in schemas_result]  # Getting the result returns a list of schema names
        if not schemas:
            print("No schemas found.")
            return []
        return schemas


    def set_shema_path(self,schema):
        # Set the search path to the schema
        set_path=f"SET search_path TO {schema}"
        try:
            if self.engine.closed:
                print('Connection is closed. Attempting to reconnect...')
                self.connect()
            pd.read_sql(set_path, self.engine)
        except exc.ResourceClosedError:
            print('Query executed, but it does not have any result to return.')
            return None


    def execute_query_multi_schemas(self, query, flag=False,insert=[],update=[],schemas=[],attempt=0, **kwargs):
        """
        Executes an SQL query.

        Args:
            query (str): The query that needs to be executed.
            flag (bool): A flag to indicate if the query should proceed without parameters.
            direct_query (bool): If True, executes the query across all available schemas.
            attempt (int): Number of attempts made for retries in case of connection errors.
            kwargs: Additional arguments like 'params' for the query.

        Returns:
            (DataFrame): A pandas DataFrame containing the result of the query, or None if an error occurs.
        """

        try:
            # Initialize data variable
            data = None
            print(f'Executing Query in execute_query_multi_schemas: {query} and insert is {insert} and update is {update} and schemas is {schemas}')

            combined_results = []
            # Handle direct query for executing across schemas
            if insert:
                schemas=insert
            elif update:
                schemas=update

            for schema in schemas:
                try:
                    # Check if the query is parameterized
                    if 'params' not in kwargs and not flag:
                        print('Cannot execute query (Expecting parameterized query).')
                        return None

                    # Extract parameters from kwargs, if available
                    params = tuple(kwargs.get('params', ()))
                    print(f'Params: {params}')

                    print(f"Running query on schema: {schema}")
                    self.set_shema_path(schema)

                    if hasattr(query, 'compile'):
                        query_str = str(query.compile(compile_kwargs={"literal_binds": True}))
                    else:
                        query_str = str(query)

                    print(f'####### Query: {query_str}')
                    print(f'####### Params: {params}')

                    # Execute the query using pandas read_sql method
                    try:
                        query_str=query_str.replace("`","")
                        query_str=query_str.replace('"','')
                    except:
                        pass

                    if self.engine.closed:
                        print('Connection is closed. Attempting to reconnect...')
                        self.connect()

                    # Execute the query using pandas read_sql method
                    schema_data = pd.read_sql(query_str, self.engine, params=params)
                    print(f"Query executed successfully.and data is {schema_data}")

                    if not insert and not update:
                        schema_data['schema_tag']=schema
                        combined_results.append(schema_data)
                except exc.ResourceClosedError:
                    print('Query executed, but it does not have any result to return.')

            # Combine results across schemas and return as one DataFrame
            if combined_results:
                return self.combine_records_excluding_columns(pd.concat(combined_results, ignore_index=True))
            else:
                print("No results obtained across schemas.")
                return True

        except exc.ResourceClosedError:
            print('Query executed, but it does not have any result to return.')
            return None

        except exc.IntegrityError as e:
            print(f'Integrity Error: {e}')
            return None

        except (exc.StatementError, OperationalError) as e:
            # Handle statement and operational errors (e.g., connection issues)
            print(f'Error encountered: {e}. Retrying (attempt #{attempt + 1})...')
            attempt += 1
            if attempt <= 3:
                # Retry the connection and execution
                self.connect()
                return self.execute_query(query, flag=flag,insert=insert,update=update, attempt=attempt, **kwargs)
            else:
                print('Maximum retry attempts reached.')
                return None

        except Exception as e:
            print(f'Error executing query: {e}')
            return None


    def append_conditions(self,query):

        try:
            exception_tables=["users"]
            query = query.replace("\n", " ").replace("\t", " ")
            # Remove extra spaces
            query = " ".join(query.split())
            query=query.replace(";","")
            # tables = re.findall(r'(FROM|JOIN)\s+([a-zA-Z0-9_]+)(?:\s+AS\s+([a-zA-Z0-9_]+))?', query, re.IGNORECASE)
            tables = re.findall(r'(FROM|JOIN)\s+([a-zA-Z0-9_]+\.[a-zA-Z0-9_]+|\S+)(?:\s+AS\s+([a-zA-Z0-9_]+))?', query, re.IGNORECASE)

            # Extract table names and aliases into a list (ignoring 'FROM' and 'JOIN' keywords)
            table_info = [(table[1], table[2] if len(table) > 2 else table[1]) for table in tables]
            print("TABLES AND ALIASES:", table_info)

            # Step 2: Define the additional conditions based on the table(s)
            additional_conditions = ""

            # Loop through the list of tables and append conditions for each
            for table_name, alias in table_info:

                if table_name in exception_tables:
                    continue

                customer_columns = ['customer_name']
                service_provider_column = ['serviceprovider', 'serviceprovidername', 'serviceproviderdisplayname', 'serviceproviders']
                service_provider_id_column=['serviceproviderid']

                if self.customers or self.service_providers:
                    parts=table_name.split('.')
                    if len(parts)>1:
                        cols = self.get_columns(parts[1])
                    else:
                        cols = self.get_columns(parts[0])
                    print('COLUMNS ARE', cols, self.customers, self.service_providers)

                    if self.service_providers and self.service_providers[0]:
                        found=False
                        if 'vw' in table_name.lower():
                            for col_ in cols:
                                col=re.sub(r'[^a-zA-Z]', '', col_).lower()
                                print(self.service_provider_id)
                                if col in service_provider_id_column and (self.service_provider_id and self.service_provider_id[0]) :
                                    found=True
                                    print(self.service_provider_id)
                                    if len(self.service_provider_id) == 1:
                                        if alias:
                                            additional_conditions += f" AND {alias}.{col_} = '{self.service_provider_id[0]}'"
                                        else:
                                            additional_conditions += f" AND {col_} = '{self.service_provider_id[0]}'"
                                    else:
                                        if alias:
                                            additional_conditions += f" AND {alias}.{col_} IN {self.service_provider_id}"
                                        else:
                                            additional_conditions += f" AND {col_} IN {self.service_provider_id}"
                                    break

                        if not found:
                            for col_ in cols:
                                col=re.sub(r'[^a-zA-Z]', '', col_).lower()
                                if col in service_provider_column:
                                    if len(self.service_providers) == 1:
                                        if alias:
                                            additional_conditions += f" AND {alias}.{col_} = '{self.service_providers[0]}'"
                                        else:
                                            additional_conditions += f" AND {col_} = '{self.service_providers[0]}'"
                                    else:
                                        if alias:
                                            additional_conditions += f" AND {alias}.{col_} IN {self.service_providers}"
                                        else:
                                            additional_conditions += f" AND {col_} IN {self.service_providers}"
                                    break

                    if self.customers and self.customers[0]:
                        for col_ in cols:
                            if col_ in customer_columns:
                                col=re.sub(r'[^a-zA-Z]', '', col_).lower()
                                if len(self.customers) == 1:
                                    if alias:
                                        additional_conditions += f" AND {alias}.{col_} = '{self.customers[0]}'"
                                    else:
                                        additional_conditions += f" AND {col_} = '{self.customers[0]}'"
                                else:
                                    if alias:
                                        additional_conditions += f" AND {alias}.{col_} IN {self.customers}"
                                    else:
                                        additional_conditions += f" AND {col_} IN {self.customers}"
                                break

            query_parts = re.split(r"(\sGROUP\sBY\s.+)", query, flags=re.IGNORECASE)
            order_limit_clause = "".join(query_parts[1:])
            if not order_limit_clause:
                query_parts= re.split(r"(\sORDER\sBY\s.+|\sLIMIT\s\d+)", query, flags=re.IGNORECASE)
                order_limit_clause = "".join(query_parts[1:])
                if not order_limit_clause:
                    query_parts = re.split(r"(\sLIMIT\s(?:\d+|\%s)\sOFFSET\s(?:\d+|\%s)|\sLIMIT\s(?:\d+|\%s))", query, flags=re.IGNORECASE)
                    order_limit_clause = "".join(query_parts[1:])
            print(order_limit_clause,'order_limit_clause')
            # Remove any WHERE, ORDER BY, and LIMIT clauses to avoid conflicts
            if order_limit_clause:
                query = base_query = query_parts[0]  # Base query without ORDER BY/LIMIT   # Remove only ORDER BY and LIMIT
                print(query)

            # Step 4: Add the WHERE clause if additional conditions exist
            if additional_conditions:
                if "WHERE" in query.upper():
                    query += additional_conditions
                else:
                    query += " WHERE 1=1" + additional_conditions

            # Step 5: Re-attach any ORDER BY and LIMIT clauses back to the query
            if order_limit_clause:
                query += order_limit_clause # Append ORDER BY / LIMIT
        except Exception as e:
            print(f'Error appending conditions: {e}')

        return query


    def execute_query(self, query,flag=False,no_filter_append=False, insert=[],update=[],attempt=0, **kwargs):
        """
        Executes an SQL query.

        Args:
            query (str): The query that needs to be executed.
            params (list/tuple/dict): List of parameters to pass to in the query.

        Returns:
            (DataFrame) A pandas dataframe containing the data from the executed
            query. (None if an error occurs)
        """
        # Initialize data variable
        data = None
        print(f'Query: {query}')
        schemas=[]
        if not insert and not update:
            schemas=self.fetch_schemas()
        print(f'schemas: {schemas}')

        if len(schemas)>1 or len(update)>0 or len(insert)>1:
            return self.execute_query_multi_schemas(query,flag,insert,update,schemas)
        Session = sessionmaker(bind=self.engine)
        session = Session()  # Create a new session
        try:
            # Check if the query is parameterized
            if 'params' not in kwargs and not flag:
                print('Cannot execute query (Expecting parametarized query).')
                return True
            # Extract parameters from kwargs if available
            params = kwargs['params'] if 'params' in kwargs else None
            if params:
                params=tuple(params)
            else:
                params=()

            if self.engine.closed:
                print('Connection is closed. Attempting to reconnect...')
                self.connect()

            if hasattr(query, 'compile'):
                query_str = str(query.compile(compile_kwargs={"literal_binds": True}))
            else:
                query_str = str(query)

            print(f'####### Query: {query_str}')
            print(f'####### Params: {params}')

            # Execute the query using pandas read_sql method
            try:
                query_str=query_str.replace("`","")
                query_str=query_str.replace('"','')
            except:
                pass

            if self.customers or self.service_providers and "SELECT" in query_str.upper() and not no_filter_append:
                query_str=self.append_conditions(query_str)

            print(f'####### after additional add ons Query: {query_str}')

            data = pd.read_sql(query_str, self.engine, params=params)
            # data =  self.engine.execute(query, params=params)
            print(f"########### Data")
        except exc.ResourceClosedError:
            print('Query does not have any value to return.')
            return True
        except exc.IntegrityError as e:
            print(f'Integrity Error - {e}')
            return None
        except (exc.StatementError, OperationalError) as e:
            # Handle statement errors and operational errors (e.g., connection issues)
            print(f'Creating new connection. Engine/Connection is probably None. [{e}]')
            attempt += 1
            if attempt <= 3:
                # Reconnect to the database
                self.connect()
                print(f'Attempt #{attempt}')
                # Execute the query using execute_query
                return self.execute_query(query, attempt=attempt, **kwargs)
            else:
                print(f'Maximum attempts reached. ({3})')
                return False
        except Exception as e:
            print(f'Something went wrong executing query. Check trace. {e}')
            params = kwargs['params'] if 'params' in kwargs else None
            return False
        finally:
            session.close()
            print('connections are closed')
        # Replace NaN values in the resulting DataFrame with None and return
        return data.replace({np.nan: None})


    def _build_filters(self,table, filters, combine_logic=[]):

        filter_conditions = []
        count=0
        for key, value in filters.items():
            # Check if condition is a tuple (value, logic) e.g., ("not Null", "OR")
            if str(count) in combine_logic:
                logic = "OR"
            else:
                logic = "AND"  # Default logic if not specified

            # Handle NULL and NOT NULL conditions
            if value == "not Null":
                filter_condition = table.c[key].isnot(None)
            elif value == "Null":
                filter_condition = table.c[key].is_(None)
            elif isinstance(value, (list, tuple)):
                # Handle WHERE IN condition
                filter_condition = table.c[key].in_(value)
            else:
                filter_condition = table.c[key] == value
            count=count+1
            filter_conditions.append((filter_condition, logic))

        # Combine conditions based on the specified logic
        and_conditions = [cond for cond, logic in filter_conditions if logic == 'AND']
        or_conditions = [cond for cond, logic in filter_conditions if logic == 'OR']

        combined_condition = "None"
        if and_conditions:
            combined_condition = and_(*and_conditions)
        if or_conditions:
            or_combined = or_(*or_conditions)

            if combined_condition != "None":
                combined_condition = and_(combined_condition, or_combined)
            else:
                combined_condition = or_combined

        return combined_condition


    def get_data(self, table_name=None, condition=None, columns=None, order=None, combine=[], joins=None, mod_pages=None, concat_columns=None,coalesce_columns=None):
        Session = sessionmaker(bind=self.engine)
        session = Session()  # Create a new session

        try:
            print(table_name, condition, columns, order, joins)

            # Reflect the table from the database schema
            # metadata = MetaData()
            # metadata.reflect(bind=self.engine)
            # table = Table(table_name, metadata, autoload_with=self.engine)
            table = self.tables.get(table_name)

            if columns:
                columns = [table.c[col] if isinstance(col, str) else col for col in columns]
            else:
                columns = [table]

            # Handle concatenation if `concat_columns` is provided
            if concat_columns:
                name_column, id_column = concat_columns
                concat_expr = func.concat(
                    table.c[name_column],
                    str(' -- '),
                    table.c[id_column]
                )
                columns.append(concat_expr.label('concat_column'))

            if coalesce_columns:
                coalesce_expr = func.coalesce(
                    *[table.c[col] for col in coalesce_columns]
                )
                columns.append(coalesce_expr.label('coalesce_column'))


            # Create the base query
            query = select(*columns)

            # Handle joins
            if joins:
                for join_table, on_condition in joins.items():
                    join_table = Table(join_table, metadata, autoload_with=self.engine)
                    query = query.join(join_table, on_condition)

            # Apply filters
            if condition:
                where = self._build_filters(table, condition, combine)
                query = query.where(where)

            # Apply ordering
            if order:
                order_by = list(order.keys())[0]
                order_direction = list(order.values())[0]
                order_clause = asc(order_by) if order_direction == 'asc' else desc(order_by)
                query = query.order_by(order_clause)

            # Apply pagination
            if mod_pages:
                start = mod_pages.get('start', 0)
                end = mod_pages.get('end', 500)
                query = query.offset(start).limit(end - start)

            print(f"Final query that is going to get executed is {query}")
            return self.execute_query(query, True)

        except Exception as e:
            # Logging an exception if any error occurs during the update process
            print(f'Error getting data: {e}')
            return False
        finally:
            session.close()  # Ensure the session is closed


    def update_dict(self, table_name, values, and_conditions=None, or_conditions=None, in_conditions=None):
        """
        Updates a table in the database using SQLAlchemy.

        Parameters:
        - table_name: The name of the table to update.
        - values: A dictionary of column-value pairs to update.
        - and_conditions: A list of `AND` conditions (tuples of column and value).
        - or_conditions: A list of `OR` conditions (tuples of column and value).
        - in_conditions: A list of `IN` conditions (tuples of column and list of values).

        Example:
        update_table('users', {'name': 'New Name'},
                    and_conditions={'age':30},
                    or_conditions={'city':'New York'},
                    in_conditions={'id':[1, 2, 3]})
        """

        try:
            # Create connection string
            # metadata = MetaData()
            # metadata.bind = self.engine  # Bind the metadata to the engine
            # table = Table(table_name, metadata, autoload_with=self.engine)
            table = self.tables.get(table_name)

            # Create the base update statement
            stmt = update(table).values(**values)

            # Apply AND conditions
            if and_conditions:
                and_clause = and_(*[table.c[column] == value for column, value in and_conditions.items()])
                stmt = stmt.where(and_clause)

            # Apply OR conditions
            if or_conditions:
                or_clause = or_(*[table.c[column] == value for column, value in or_conditions.items()])
                stmt = stmt.where(or_clause)

            # Apply IN conditions
            if in_conditions:
                in_clause = and_(*[table.c[column].in_(values) for column, values in in_conditions.items()])
                stmt = stmt.where(in_clause)
            print(stmt)
            result = self.engine.execute(stmt)
            self.engine.commit()

            # print("update successful")
            if result.rowcount > 0:
                print("Update successful")
                return True
            else:
                print("No rows were updated")
                return False

        except Exception as e:
            # Logging an exception if any error occurs during the insertion process
            print(f'Error updating data: {e}')
            return False
        finally:
            # Ensure that the cursor and connection are closed
            if 'conn' in locals() and self.engine:
                self.engine.close()

    def update_dict_back(self, table_name, values, and_conditions=None, or_conditions=None, in_conditions=None):
        """
        Updates a table in the database using SQLAlchemy.

        Parameters:
        - table_name: The name of the table to update.
        - values: A dictionary of column-value pairs to update.
        - and_conditions: A dictionary of `AND` conditions (tuples of column and value).
        - or_conditions: A dictionary of `OR` conditions (tuples of column and value).
        - in_conditions: A dictionary of `IN` conditions (tuples of column and list of values).

        Example:
        update_dict('users', {'name': 'New Name'},
                    and_conditions={'age': 30, 'id': '123-456-789'},
                    or_conditions={'city': 'New York'},
                    in_conditions={'id': ['123-456-789', '987-654-321']})
        """

        try:
            # Extract and split the schema_tag from values or conditions
            schema_tag = values.pop('schema_tag', None) or \
                        (and_conditions and and_conditions.pop('schema_tag', None)) or \
                        (or_conditions and or_conditions.pop('schema_tag', None)) or \
                        (in_conditions and in_conditions.pop('schema_tag', None))

            # Split schema_tag by '-' for index use
            schema_tag = schema_tag.split('-') if schema_tag else []
            for ind,tag in enumerate(schema_tag):
                print(f" schema_tag is {tag} and ind is {ind}")
                # Retrieve the table from the schema specified by schema_tag
                table = self.tables.get(table_name)

                # Function to split the id based on schema_tag index
                def process_id_condition(condition_dict):
                    condition={}
                    for key, values_list in condition_dict.items():
                        condition[key]=values_list
                        if key == 'id' and schema_tag:
                            condition['id'] = condition_dict['id'].split('-')[ind]  # Use schema_tag index
                    return condition

                # Process the `and_conditions`, `or_conditions`, and `in_conditions`
                and_condition_dict={}
                if and_conditions:
                    and_condition_dict = process_id_condition(and_conditions)
                or_condition_dict={}
                if or_conditions:
                    or_condition_dict = process_id_condition(or_conditions)
                in_condition_dict={}
                if in_conditions:
                    for key, values_list in in_conditions.items():
                        in_condition_dict[key]=values_list
                        if key == 'id' and schema_tag:
                            in_condition_dict[key] = [value.split('-')[ind] for value in values_list]

                print(and_condition_dict,or_condition_dict,in_condition_dict)

                # Create the base update statement
                stmt = update(table).values(**values)

                # Apply AND conditions
                if and_condition_dict:
                    and_clause = and_(*[table.c[column] == value for column, value in and_condition_dict.items()])
                    stmt = stmt.where(and_clause)

                # Apply OR conditions
                if or_condition_dict:
                    or_clause = or_(*[table.c[column] == value for column, value in or_condition_dict.items()])
                    stmt = stmt.where(or_clause)

                # Apply IN conditions
                if in_condition_dict:
                    in_clause = and_(*[table.c[column].in_(values) for column, values in in_condition_dict.items()])
                    stmt = stmt.where(in_clause)

                # Print the statement for debugging purposes
                print(stmt)

        #       Execute the query
                result = self.execute_query(stmt,True, update=[tag])
                self.engine.commit()

            print("Update successful")
            return True

        except Exception as e:
            # Logging an exception if any error occurs during the process
            print(f'Error updating data: {e}')
            return False

        finally:
            # Ensure that the connection is closed
            if 'conn' in locals() and self.engine:
                self.engine.close()



    def insert_dict(self, data, table):
        """
        Insert dictionary into a SQL database table.

        Args:
            data (dict): The dictionary containing column names and values to insert.
            table (str): The table in which the records should be inserted.

        Returns:
            (bool) True if successfully inserted, else False.
        """
        print(f'Inserting dictionary data into `{table}`...')
        print('testing')
        print(f'Data:\n{data}')

        try:

            # metadata = MetaData()
            # metadata.bind = self.engine  # Bind the metadata to the engine
            # table = Table(table, metadata, autoload_with=self.engine)
            table = self.tables.get(table)

            if not isinstance(data,list):
                data=[data]

            stmt = insert(table).values(data)

            # Executing the constructed query with the parameters
            result = self.execute_query(stmt,True,insert=self.fetch_schemas())
            self.engine.commit()

            print("Insert successful")
            return True

        except Exception as e:
            # Logging an exception if any error occurs during the insertion process
            print(f'Error inserting data: {e}')
            return False
        finally:
            # Ensure that the cursor and connection are closed
            if 'conn' in locals() and self.engine:
                self.engine.close()


    def update_audit(self, data, table):
        """
        Insert dictionary into a SQL database table.

        Args:
            data (dict): The dictionary containing column names and values to insert.
            table (str): The table in which the records should be inserted.

        Returns:
            (bool) True if successfully inserted, else False.
        """
        print(f'Inserting dictionary data into `{table}`...')
        print('testing')
        print(f'Data:\n{data}')

        try:
            # Create connection string
            connection_string = (
                f"{self.DB_TYPE}://{self.USER}:{self.PASSWORD}@{self.HOST}:{self.PORT}/{self.DATABASE}"
            )

            # Establish database connection
            conn = psycopg2.connect(connection_string)
            cursor = conn.cursor()

            # Extracting column names and values
            column_names = [f'"{column_name}"' for column_name in data.keys()]
            params = list(data.values())

            print(f'Column names: {column_names}')
            print(f'Params: {params}')

            # Constructing the SQL query dynamically
            columns_string = ', '.join(column_names)
            param_placeholders = ', '.join(['%s'] * len(column_names))
            print(f"Columns inserting: {columns_string} and values: {param_placeholders}")

            # Making the Insert query
            query = f'INSERT INTO {table} ({columns_string}) VALUES ({param_placeholders})'

            # Executing the constructed query with the parameters
            cursor.execute(query, params)
            conn.commit()

            print("Insert successful")
            return True
        except Exception as e:
            # Logging an exception if any error occurs during the insertion process
            print(f'Error inserting data: {e}')
            return False
        finally:
            # Ensure that the cursor and connection are closed
            if 'cursor' in locals() and cursor:
                cursor.close()
            if 'conn' in locals() and conn:
                conn.close()


    def log_error_to_db(self, data, table):
        """
        Insert dictionary into a SQL database table.

        Args:
            data (dict): The dictionary containing column names and values to insert.
            table (str): The table in which the records should be inserted.

        Returns:
            (bool) True if successfully inserted, else False.
        """
        print(f'Inserting dictionary data into `{table}`...')
        print('testing')
        print(f'Data:\n{data}')

        try:
            # Create connection string
            connection_string = (
                f"{self.DB_TYPE}://{self.USER}:{self.PASSWORD}@{self.HOST}:{self.PORT}/{self.DATABASE}"
            )

            # Establish database connection
            conn = psycopg2.connect(connection_string)
            cursor = conn.cursor()

            # Extracting column names and values
            column_names = [f'"{column_name}"' for column_name in data.keys()]
            params = list(data.values())

            print(f'Column names: {column_names}')
            print(f'Params: {params}')

            # Constructing the SQL query dynamically
            columns_string = ', '.join(column_names)
            param_placeholders = ', '.join(['%s'] * len(column_names))
            print(f"Columns inserting: {columns_string} and values: {param_placeholders}")

            # Making the Insert query
            query = f'INSERT INTO {table} ({columns_string}) VALUES ({param_placeholders})'

            # Executing the constructed query with the parameters
            cursor.execute(query, params)
            conn.commit()
            # # Send success email
            #     # Create dynamic subject and content for the email
            # service_name = data.get('service_name', '')
            # error_message = data.get('error_message', '')
            # error_type = data.get('error_type', '')
            # timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            #     # Create email subject and content
            # subject = f"Error Notification: {service_name} - {error_type}"
            # content = f"""
            #     <p>Hi,</p>
            #     <p>There was an error reported in the service <strong>{service_name}</strong>:</p>
            #     <p><strong>Error Message:</strong> {error_message}</p>
            #     <p><strong>Error Type:</strong> {error_type}</p>
            #     <p><strong>Timestamp:</strong> {timestamp}</p>
            #     <p>Details:</p>
            #     <pre>{data}</pre>
            #     <p>Please investigate the issue as soon as possible.</p>
            #     """

            #     # Send the email
            # template_name = data.get("template_name", 'Log Errors')
            # to_emails, cc_emails, subject, body, from_email, partner_name = send_email(template_name, content=content, is_html=True)
            # message = "Mail sent successfully"

            print("Insert successful")
            return True
        except Exception as e:
            # Logging an exception if any error occurs during the insertion process
            print(f'Error inserting data: {e}')
            return False
        finally:
            # Ensure that the cursor and connection are closed
            if 'cursor' in locals() and cursor:
                cursor.close()
            if 'conn' in locals() and conn:
                conn.close()


    def insert(self, data, table, database=None, if_exists='replace', index=False, method=None):
        """
        Write records stored in a DataFrame to a SQL database.

        Args:
            data (DataFrame): The DataFrame that needs to be write to SQL database.
            table (str): The table in which the rcords should be written to.
            kwargs: Keyword arguments for pandas to_sql function.
                See https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.to_sql.html
                to know the arguments that can be passed.

        Returns:
            (bool) True is succesfully inserted, else false.
        """
        #print(f'Inserting into `{table}`')

        try:
            data.to_sql(table, self.engine, if_exists=if_exists, index=index, method=method)
            return True
        except:
            print('exception')
            return False

    def insert_data(self, data, table):
        """
        Insert dictionary into a SQL database table and return the inserted ID.

        Args:
            data (dict): The dictionary containing column names and values to insert.
            table (str): The table in which the records should be inserted.

        Returns:
            (int) The ID of the inserted row if successful, else None.
        """
        print(f'Inserting dictionary data into `{table}`...')
        print('testing')
        print(f'Data:\n{data}')

        try:
            # Get the table object from metadata
            table = self.tables.get(table)

            if not isinstance(data, list):
                data = [data]

            # Assuming the table has an 'id' column to return after insert
            stmt = insert(table).values(data).returning(table.c.id)

            # Executing the constructed query
            result = self.engine.execute(stmt)
            inserted_id = result.scalar()

            # Committing the transaction
            self.engine.commit()

            print(f"Insert successful, inserted ID: {inserted_id}")
            return inserted_id

        except Exception as e:
            # Logging any error that occurs during the insertion process
            print(f'Error inserting data: {e}')
            return None

        finally:
            # Ensure that the connection is closed
            if 'conn' in locals() and self.engine:
                self.engine.close()

    def get_table_columns(self, table_name):
        query = f"""
        SELECT column_name
        FROM information_schema.columns
        WHERE table_name = '{table_name}'
        ORDER BY ordinal_position;
        """
        return pd.read_sql(query, self.engine)


    def get_columns(self, table):
        """
        Get all column names from an SQL table.
        """
        try:
            print(f'Getting column names of table `{table}`')

            # Query to fetch column names from the database schema

            with open(self.file_path, "r") as f:
                schema = json.load(f)

            if table not in schema:
                with open(f"/opt/python/lib/python3.9/site-packages/common_utils/schemas/default_schema.json", "r") as f:
                    schema = json.load(f)

            column_names = []
            for cols in schema[table]:
                column_names.append(cols['name'])

            return column_names

        except Exception as e:
            print(f"Something went wrong getting column names. Error: {e}")
            return []


    def execute_default_index(self, query, **kwargs):
        """
        Executes an SQL query.

        Args:
            query (str): The query that needs to be executed.
            database (str): Name of the database to execute the query in. Leave
                it none if you want use database during object creation.
            params (list/tuple/dict): List of parameters to pass to in the query.

        Returns:
            (DataFrame) A pandas dataframe containing the data from the executed
            query. (None if an error occurs)
        """
        data = None

        try:
            # Execute the SQL query using pandas read_sql function
            data = pd.read_sql(query, self.engine, **kwargs).replace({pd.np.nan: None})
        except exc.ResourceClosedError:
            # Handle the case where the query is executed successfully but returns no data
            return True
        except:
            # Log and handle any other exceptions that occur during query execution
            print(f'Something went wrong while executing query. Check trace.')
            params = kwargs['params'] if 'params' in kwargs else None
            return False

        return data.where((pd.notnull(data)), None)



    def delete_data(self, table_name, and_conditions=None, or_conditions=None, in_conditions=None):
        """
        Deletes rows from a table in the database using SQLAlchemy.
        """
        # Fetch the table object
        table = self.tables.get(table_name)
        if table is None:
            raise ValueError(f"Table {table_name} not found.")
        print(f"Table found: {table}")

        # Start with a base delete statement
        stmt = delete(table)

        # Construct AND conditions
        if and_conditions:
            and_clauses = [table.c[column] == value for column, value in and_conditions.items()]
            stmt = stmt.where(and_(*and_clauses))

        # Construct OR conditions
        if or_conditions:
            or_clauses = [table.c[column] == value for column, value in or_conditions.items()]
            stmt = stmt.where(or_(*or_clauses))

        # Construct IN conditions
        if in_conditions:
            in_clauses = [table.c[column].in_(values) for column, values in in_conditions.items()]
            stmt = stmt.where(and_(*in_clauses))

        # Debugging: Print the final delete statement
        print(f"Final delete statement: {stmt}")

        # Execute the delete statement using self.engine.execute() directly
        result = self.engine.execute(stmt)

        # Commit the changes
        self.engine.commit()

        print("Delete operation successful.")
        return True
db_config = {
'host': "amoppostoct19.c3qae66ke1lg.us-east-1.rds.amazonaws.com",
'port': "5432",
'user':"root",
'password':"AmopTeam123"
}
def convert_timestamp(df_dict, tenant_time_zone):
    """
    Convert timestamp columns in the provided dictionary list to the tenant's timezone.

    Parameters:
        df_dict (list of dict): A list of dictionaries where each dictionary represents a record
                                containing timestamp fields.
        tenant_time_zone (str): The timezone to which the timestamps should be converted.

    Returns:
        list of dict: The updated list of dictionaries with timestamps converted to the tenant's timezone.
    """
    # Create a timezone object
    target_timezone = timezone(tenant_time_zone)

    # List of timestamp columns to convert
    timestamp_columns = ['created_date', 'modified_date', 'last_email_triggered_at']  # Adjust as needed based on your data

    # Convert specified timestamp columns to the tenant's timezone
    for record in df_dict:
        for col in timestamp_columns:
            if col in record and record[col] is not None:
                # Convert to datetime if it's not already
                timestamp = pd.to_datetime(record[col], errors='coerce')
                if timestamp.tz is None:
                    # If the timestamp is naive, localize it to UTC first
                    timestamp = timestamp.tz_localize('UTC')
                # Now convert to the target timezone
                record[col] = timestamp.tz_convert(target_timezone).strftime('%m-%d-%Y %H:%M:%S')  # Ensure it's a string
    return df_dict
def get_features_by_feature_name(
    user_name, tenant_id, feature_name, common_utils_database, parent_module_name
):
    """
    Fetches features for a given user and tenant by feature name from the database.
    It first looks for the features under a specified parent module name.
    If no features are found under the parent module, it checks other modules.

    Args:
        user_name (str): The username for which features need to be retrieved.
        tenant_id (str): The tenant ID associated with the user.
        feature_name (str): The specific feature name to search for.
        common_utils_database (object): Database utility object to interact with the database.
        parent_module_name (str): The name of the parent module to search for features under.

    Returns:
        list: A list of features for the specified feature name, or an empty list if none are found.
    """

    features_list = []  # Initialize an empty list to store the retrieved features

    try:
        # Fetch user features from the database for the given user and tenant
        user_features_raw = common_utils_database.get_data(
            "user_module_tenant_mapping",  # Table to query
            {"user_name": user_name, "tenant_id": tenant_id},  # Query parameters
            ["module_features"],  # Columns to fetch
        )[
            "module_features"
        ].to_list()  # Convert the result to a list

        print("Raw user features fetched: %s", user_features_raw)

        # Parse the JSON string into a dictionary of user features
        user_features = json.loads(
            user_features_raw[0]
        )  # Assuming the result is a list with one JSON string

        # Initialize a list to hold features for the specified feature name
        features_list = []

        # First, check by parent_module_name for the specified feature
        for module, features in user_features.items():
            if module == parent_module_name and feature_name in features:
                features_list.extend(
                    features[feature_name]
                )  # Add features if found under parent module

        # If no features found under parent_module_name, check other modules
        if not features_list:
            for module, features in user_features.items():
                if feature_name in features:  # Check for the feature in other modules
                    features_list.extend(features[feature_name])

        print(
            "Retrieved features: %s", features_list
        )  # Log the retrieved features

    except Exception as e:
        # Catch any exceptions and log a warning
        print("There was an error while fetching features: %s", e)

    return features_list  # Return the list of retrieved features

def get_headers_mapping(tenant_database, module_list, role, user, tenant_id, sub_parent_module, parent_module, data,):
    """
    Retrieves and organizes field mappings, headers, and module features based on the provided parameters.

    This function:
    - Connects to the database.
    - Fetches field mappings and categorizes them into pop-ups, general fields, and table fields.
    - Retrieves and processes module features based on user roles.
    - Returns a structured dictionary containing headers and features for each module.

    Parameters:
        tenant_database (str): The database name of the tenant.
        module_list (list): List of module names to fetch field mappings for.
        role (str): The role of the user (e.g., 'Super Admin').
        user (str): The username of the user.
        tenant_id (int): The ID of the tenant.
        sub_parent_module (str): The name of the sub-parent module.
        parent_module (str): The name of the parent module.
        data (dict): Additional input data, which may contain:
            - feature_module_name (str): The feature module name.
            - username/user_name/user (str): The username.
            - tenant_name/tenant (str): The tenant name.

    Returns:
        dict: A dictionary where each module name maps to its corresponding headers and features.
    """
    # Establish database connections
    database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)

    # Extract relevant details from the input data dictionary
    feature_module_name = data.get("feature_module_name", "")
    user_name = data.get("username") or data.get("user_name") or data.get("user")
    tenant_name = data.get("tenant_name") or data.get("tenant")

    try:
        # Retrieve tenant ID based on tenant name
        tenant_id = database.get_data(
            "tenant", {"tenant_name": tenant_name}["id"]
        )["id"].to_list()[0]
    except Exception as e:
        print(f"Getting exception at fetching tenant id {e}")
    
    ret_out = {}
    
    # Iterate over each module name in the provided module list
    for module_name in module_list:
        out = database.get_data(
            "field_column_mapping", {"module_name": module_name}
        ).to_dict(orient="records")
        pop_up = []
        general_fields = []
        table_fileds = {}
        # Categorize the fetched data based on field types
        for data in out:
            if data["pop_col"]:
                pop_up.append(data)
            elif data["table_col"]:
                table_fileds.update(
                    {
                        data["db_column_name"]: [
                            data["display_name"],
                            data["table_header_order"],
                        ]
                    }
                )
            else:
                general_fields.append(data)
        # Create a dictionary to store categorized fields
        headers = {}
        headers["general_fields"] = general_fields
        pop_up = sorted(pop_up, key=lambda x: x['id'])
        headers["pop_up"] = pop_up
        headers["header_map"] = table_fileds
        try:
            final_features = []

            # Fetch all features for the 'super admin' role
            if role.lower() == "super admin":
                all_features = database.get_data(
                    "module_features", {"module": feature_module_name}, ["features"]
                )["features"].to_list()
                if all_features:
                    final_features = json.loads(all_features[0])
            else:
                final_features = get_features_by_feature_name(
                    user_name, tenant_id, feature_module_name, database
                )

        except Exception as e:
            print(f"there is some error {e}")
            pass
        # Add the final features to the headers dictionary
        headers["module_features"] = final_features
        ret_out[module_name] = headers

    return ret_out

def serialize_data(data):
    """Recursively convert pandas objects in the data structure to serializable types."""
    if isinstance(data, list):
        return [serialize_data(item) for item in data]
    elif isinstance(data, dict):
        return {key: serialize_data(value) for key, value in data.items()}
    elif isinstance(data, pd.Timestamp):
        return data.strftime('%m-%d-%Y %H:%M:%S')  # Convert to string
    else:
        return data  # Return as is if not a pandas object
def collections_list_view(data):
    """
    Retrieves a list of customer profiles for display, including pagination, filtering, and dropdown options.

    Args:
        data (dict): A dictionary containing:
            - db_name (str): Tenant database name (default: 'altaworx_central').
            - role_name (str): User's role for permissions.
            - tenant_name (str): Tenant name for fetching timezone.
            - mod_pages (dict): Pagination details {start, end}.
            - col_sort (dict, optional): Sorting preferences.

    Returns:
        dict: Response structure:
            - flag (bool): Success/failure status.
            - message (str): Success/error message.
            - data (dict): Customer profiles with pagination.
            - header_map (dict): Mapped headers for UI display.
            - dropdown (dict): Dropdown values for filters.
            - pages (dict): Pagination details.
    """
    # Database connections
    database = DB('billing_platform_common_utils', **db_config)
    killbill_database =  DB('billing_platform' ,**db_config)
    
    # Extract relevant details from the input data dictionary
    table_name = data.get('table_name','customer_profiles')
    role_name = data.get('role_name', '')
    col_sort = data.get("col_sort", "")
    tenant_name =data.get('tenant_name','')

    # Set default pagination if not provided
    start = data.get('mod_pages', {}).get('start', 0)
    end = data.get('mod_pages', {}).get('end', 100)

    limit = end - start
    offset = start
    
    # Get tenant's timezone
    tenant_name = data.get('tenant_name', '')
    tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
    tenant_timezone = database.execute_query(tenant_timezone_query, params=[tenant_name])

        # Ensure timezone is valid
    if tenant_timezone.empty or tenant_timezone.iloc[0]['time_zone'] is None:
            raise ValueError("No valid timezone found for tenant.")

    tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
    match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
    if match:
        tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly

    # Get total customer profile count
    total_count_result = killbill_database.get_data(
            table_name, {"is_deleted": "false"},["id"]
        )["id"].to_list()
    total_count=len(total_count_result)

    # Pagination information
    pages_data = {
        "start": start,
        "end": end,
        "total": total_count
    }

    # Sort order handling (ensure valid keys)
    if col_sort:
        order =  {k: v.lower() for k, v in col_sort.items()}
        # print("orderis",order)
    else:
        order= {"modified_date":"desc"}

    # Fetch paginated customer profiles from the database
    df_dict= killbill_database.get_data(
        table_name=table_name,
        condition=None,
        columns=None,
        order=order,
        mod_pages={"start": start, "end": end}
    ).to_dict(orient="records")

    # Convert timestamps to the tenant's timezone
    df_dict = convert_timestamp(df_dict, tenant_time_zone)
    # print('####df_dict',df_dict)

    #dropdown values for account_type
    account_type=['Standard','Parent','Child']

    # Fetch unique service provider names
    service_provider_query=killbill_database.get_data(table_name="serviceprovider",columns=["id","display_name"])
    provider_list_dup = service_provider_query['display_name'].tolist()
    provider_list = sorted(list(set(provider_list_dup)))

    # Fetch list of usernames
    users_query=database.get_data(table_name="users",columns=["first_name","last_name"])
    users_list = users_query.apply(lambda row: f"{row['first_name']} {row['last_name']}", axis=1).tolist()
    users_list = sorted(set(users_list))
    
    # Fetch parent account numbers
    account_numbers=killbill_database.get_data(table_name,{"account_type":'Parent'},["account_number"])
    account_numbers_list_ = account_numbers["account_number"].to_list()
    account_numbers_list = sorted(list(account_numbers_list_))

    # Compile dropdown options
    dropdown={
        'account_type':account_type,
        'btn_provider':provider_list,
        'sales_person': users_list,
        'parent_accounts': account_numbers_list
    }
    try:
        # Fetch mapped headers
        header_map = get_headers_mapping(killbill_database,["Billing-Collections"],role_name, '', '', '', '',data)

        # Serialize customer profiles
        data_dict_all = {"billing_customer_profiles": serialize_data(df_dict)}
        print('###data_dict_all',data_dict_all)

         # Construct success response
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "dropdown":dropdown,
            "pages": pages_data
        }
        return response

    except Exception as e:
        print(f"Exception occurred: {e}")

        # Construct error response
        response = {
            "flag": False,
            "message": "Something went wrong fetching email list",
            "data": {}  # Return empty dictionary on error
        }
        return response
    
# def altaworx_billing_report(data):

#     report_content = data.get('reportContent',{})
#     #date_range = report_content.get('dateRange',{})
#     start = report_content.get('start_date',None)
#     end = report_content.get('end_date',None)

#     start_date = datetime.strptime(start + ' 00:00:00', "%Y-%m-%d %H:%M:%S")
#     end_date = datetime.strptime(end + ' 23:59:59', "%Y-%m-%d %H:%M:%S")

#     print(f"####start_date = {start_date} ####end_date = {end_date}")

#     main_report_list = []

#     Killbill_db_connection = DB('killbill', **db_config)
 
#     account_id_query=f"select id from accounts;"
#     account_ids=Killbill_db_connection.execute_(account_id_query)['id'].to_list()
#     print(f"####account_ids is {account_ids}")
 
#     kilbill_base_url ="http://98.82.152.66:8080/1.0/kb"
#     main_dict = {}

#     val = False
#     if val:
#         print("###### this will be commented for fast report generation ########")
#         for accountid in account_ids:

#             print(f"##accountid is {accountid}")

#             headers = get_killbill_headers()
#             accounts_url = f"{kilbill_base_url}/accounts/{accountid}"
#             accounts_url_response = requests.get(accounts_url, headers=headers)
#             print('### accounts_url_response', accounts_url_response)

#             if accounts_url_response.status_code == 200:
#                 print(" Fetch existing fields:", accounts_url_response.content)

#                 accounts_url_response = accounts_url_response.json()
#                 print(f"#####account ")

#                 all_invoices_url = f"{kilbill_base_url}/accounts/{accountid}/invoicePayments"

#                 all_invoices_url_response = requests.get(all_invoices_url, headers=headers)
#                 print('### all_invoices_url_response', all_invoices_url_response) 

#                 if all_invoices_url_response.status_code == 200:
#                     print(" Fetch existing fields:", all_invoices_url_response.content)

#                     all_invoices_url_response = all_invoices_url_response.json()
#                     print(f"########## all_invoices_url_response= {all_invoices_url_response}")

                    

#                     for each_invoice in all_invoices_url_response:

#                         invoice = each_invoice.get('targetInvoiceId','')

#                         invoices_url = f"{kilbill_base_url}/invoices/{invoice}"
#                         invoices_url_response = requests.get(invoices_url, headers=headers)
#                         print('### invoices_url_response', invoices_url_response) 

#                         if invoices_url_response.status_code == 200:
#                             print(" Fetch existing fields:", invoices_url_response.content)
                        
#                             invoices_url_response = invoices_url_response.json()
#                             print(f"########## invoices_url_response= {invoices_url_response}")


#                             if "transactions" in each_invoice:
#                                 for transaction in each_invoice["transactions"]:

#                                     effective_date = datetime.strptime(transaction["effectiveDate"], "%Y-%m-%dT%H:%M:%S.%fZ")
#                                     # Check if within the date range
#                                     if start_date <= effective_date <= end_date:

#                                         #report_fields
#                                         report_fields = {"client_id":"", "account_type":"", "client":"", "agent":"", "balance_forward": "", "mrc":"", "nrc":"", 
#                                                         "network_access_fee":"", "admin_recovery_tax":"", "other_tax":"", "total":"", "payment":"", "payment_date":"", "balance":"", "state":""}

                                        
#                                         #client id
#                                         client_id = accounts_url_response.get('accountId','')
#                                         report_fields['client_id'] = client_id

#                                         try:
#                                             unposted_url = f"{kilbill_base_url}/invoices/{invoice}/customFields"
#                                             print('###unposted_url',unposted_url)
#                                             headers = get_killbill_headers()
#                                             unposted_response = requests.get(unposted_url, headers=headers)
#                                             print('###unposted_url',unposted_response)
#                                             if unposted_response.status_code == 200:
#                                                 unposted_res = unposted_response.json()
#                                             else:
#                                                 unposted_res = []
#                                                 print("####response exception error")
                                    
#                                             if not unposted_res:
#                                                 unposted_amount = '0'
#                                             else:
#                                                 try:
#                                                     unposted_amount = unposted_res[-1].get('value','0')
#                                                     unposted_amount = float(unposted_amount)
#                                                 except ValueError:
#                                                     unposted_amount = 0
#                                         except:
#                                             unposted_amount = '0'
            
#                                         figure = (
#                                             float(invoices_url_response.get('amount', '0')) +
#                                             float(invoices_url_response.get('credits_amount', '0')) +
#                                             float(invoices_url_response.get('refund', '0')) +
#                                             float(invoices_url_response.get('discount', '0')) +
#                                             float(unposted_amount)
#                                         )

#                                         purchased_amount = each_invoice.get('purchasedAmount','0')
#                                         balance_forward = figure - purchased_amount

#                                         report_fields['balance_forward'] = balance_forward
#                                         mrc = '0'
#                                         nrc = '0'
#                                         network_access_fee = '0'
#                                         admin_recovery_tax = '0'
#                                         other_tax = '0'

#                                         report_fields['mrc'] = mrc
#                                         report_fields['nrc'] = nrc
#                                         report_fields['network_access_fee'] = network_access_fee
#                                         report_fields['admin_recovery_tax'] = admin_recovery_tax
#                                         report_fields['other_tax'] = other_tax

#                                         total = (
#                                             float(mrc) +
#                                             float(nrc) +
#                                             float(network_access_fee) +
#                                             float(admin_recovery_tax) +
#                                             float(other_tax)
#                                         )
#                                         report_fields['total'] = total

#                                         payment = transaction.get('amount','0')
#                                         report_fields['payment'] = payment
#                                         report_fields['payment_date'] = transaction.get('effectiveDate','')
#                                         report_fields['balance'] = float(balance_forward) + float(total)
#                                         report_fields['effective_date'] = transaction["effectiveDate"]

#                                         main_report_list.append(report_fields)

                    

#     report_list = [{'client_id': 'bbe1c82b-14d4-46e8-b040-1722193ccdbb', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 160.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 10.0, 'payment_date': '2024-10-15T05:10:32.000Z', 'balance': 160.0, 'state': '', 'effective_date': '2024-10-15T05:10:32.000Z'}, {'client_id': 'bbe1c82b-14d4-46e8-b040-1722193ccdbb', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 160.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 10.0, 'payment_date': '2024-10-15T05:13:12.000Z', 'balance': 160.0, 'state': '', 'effective_date': '2024-10-15T05:13:12.000Z'}, {'client_id': 'bbe1c82b-14d4-46e8-b040-1722193ccdbb', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 165.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 5.0, 'payment_date': '2024-10-15T09:54:30.000Z', 'balance': 165.0, 'state': '', 'effective_date': '2024-10-15T09:54:30.000Z'}, {'client_id': 'bbe1c82b-14d4-46e8-b040-1722193ccdbb', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 169.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 1.0, 'payment_date': '2024-10-15T09:56:13.000Z', 'balance': 169.0, 'state': '', 'effective_date': '2024-10-15T09:56:13.000Z'}, {'client_id': 'bbe1c82b-14d4-46e8-b040-1722193ccdbb', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 160.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 10.0, 'payment_date': '2024-10-15T13:42:20.000Z', 'balance': 160.0, 'state': '', 'effective_date': '2024-10-15T13:42:20.000Z'}, {'client_id': 'bbe1c82b-14d4-46e8-b040-1722193ccdbb', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 160.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 10.0, 'payment_date': '2024-10-15T14:25:16.000Z', 'balance': 160.0, 'state': '', 'effective_date': '2024-10-15T14:25:16.000Z'}, {'client_id': 'bbe1c82b-14d4-46e8-b040-1722193ccdbb', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 5.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 5.0, 'payment_date': '2024-11-02T10:26:53.000Z', 'balance': 5.0, 'state': '', 'effective_date': '2024-11-02T10:26:53.000Z'}, {'client_id': 'bbe1c82b-14d4-46e8-b040-1722193ccdbb', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 5.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 5.0, 'payment_date': '2024-11-02T11:40:04.000Z', 'balance': 5.0, 'state': '', 'effective_date': '2024-11-02T11:40:04.000Z'}, {'client_id': 'bbe1c82b-14d4-46e8-b040-1722193ccdbb', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 6.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 4.0, 'payment_date': '2024-11-02T11:41:50.000Z', 'balance': 6.0, 'state': '', 'effective_date': '2024-11-02T11:41:50.000Z'}, {'client_id': 'bbe1c82b-14d4-46e8-b040-1722193ccdbb', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 4.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 6.0, 'payment_date': '2024-11-02T12:35:54.000Z', 'balance': 4.0, 'state': '', 'effective_date': '2024-11-02T12:35:54.000Z'}, {'client_id': 'bbe1c82b-14d4-46e8-b040-1722193ccdbb', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 0.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 410.0, 'payment_date': '2024-11-04T06:06:59.000Z', 'balance': 0.0, 'state': '', 'effective_date': '2024-11-04T06:06:59.000Z'}, {'client_id': 'bbe1c82b-14d4-46e8-b040-1722193ccdbb', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 0.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 326.67, 'payment_date': '2024-11-04T06:07:54.000Z', 'balance': 0.0, 'state': '', 'effective_date': '2024-11-04T06:07:54.000Z'}, {'client_id': 'bbe1c82b-14d4-46e8-b040-1722193ccdbb', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 0.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 410.0, 'payment_date': '2024-11-04T06:08:56.000Z', 'balance': 0.0, 'state': '', 'effective_date': '2024-11-04T06:08:56.000Z'}, {'client_id': 'bbe1c82b-14d4-46e8-b040-1722193ccdbb', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 0.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 258.39, 'payment_date': '2024-11-05T14:11:25.000Z', 'balance': 0.0, 'state': '', 'effective_date': '2024-11-05T14:11:25.000Z'}, {'client_id': 'bbe1c82b-14d4-46e8-b040-1722193ccdbb', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 0.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 260.0, 'payment_date': '2024-11-06T07:14:02.000Z', 'balance': 0.0, 'state': '', 'effective_date': '2024-11-06T07:14:02.000Z'}, {'client_id': 'bbe1c82b-14d4-46e8-b040-1722193ccdbb', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 0.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 260.0, 'payment_date': '2024-11-06T07:14:38.000Z', 'balance': 0.0, 'state': '', 'effective_date': '2024-11-06T07:14:38.000Z'}, {'client_id': 'bbe1c82b-14d4-46e8-b040-1722193ccdbb', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 0.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 360.0, 'payment_date': '2024-11-06T07:16:32.000Z', 'balance': 0.0, 'state': '', 'effective_date': '2024-11-06T07:16:32.000Z'}, {'client_id': 'bbe1c82b-14d4-46e8-b040-1722193ccdbb', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 0.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 360.0, 'payment_date': '2024-11-06T07:17:36.000Z', 'balance': 0.0, 'state': '', 'effective_date': '2024-11-06T07:17:36.000Z'}, {'client_id': 'bbe1c82b-14d4-46e8-b040-1722193ccdbb', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 0.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 118.39, 'payment_date': '2024-11-06T07:19:33.000Z', 'balance': 0.0, 'state': '', 'effective_date': '2024-11-06T07:19:33.000Z'}, {'client_id': 'bbe1c82b-14d4-46e8-b040-1722193ccdbb', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 0.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 208.39, 'payment_date': '2024-11-06T07:26:40.000Z', 'balance': 0.0, 'state': '', 'effective_date': '2024-11-06T07:26:40.000Z'}, {'client_id': 'bbe1c82b-14d4-46e8-b040-1722193ccdbb', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 700.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 460.0, 'payment_date': '2024-11-07T07:14:55.000Z', 'balance': 700.0, 'state': '', 'effective_date': '2024-11-07T07:14:55.000Z'}, {'client_id': 'bbe1c82b-14d4-46e8-b040-1722193ccdbb', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 0.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 360.0, 'payment_date': '2024-11-07T07:16:28.000Z', 'balance': 0.0, 'state': '', 'effective_date': '2024-11-07T07:16:28.000Z'}, {'client_id': 'bbe1c82b-14d4-46e8-b040-1722193ccdbb', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 0.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 360.0, 'payment_date': '2024-11-07T07:21:24.000Z', 'balance': 0.0, 'state': '', 'effective_date': '2024-11-07T07:21:24.000Z'}, {'client_id': 'bbe1c82b-14d4-46e8-b040-1722193ccdbb', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 0.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 205.16, 'payment_date': '2024-11-07T12:16:41.000Z', 'balance': 0.0, 'state': '', 'effective_date': '2024-11-07T12:16:41.000Z'}, {'client_id': 'bbe1c82b-14d4-46e8-b040-1722193ccdbb', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 0.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 205.16, 'payment_date': '2024-11-07T12:16:41.000Z', 'balance': 0.0, 'state': '', 'effective_date': '2024-11-07T12:16:41.000Z'}, {'client_id': 'bbe1c82b-14d4-46e8-b040-1722193ccdbb', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 0.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 360.0, 'payment_date': '2024-11-07T12:41:38.000Z', 'balance': 0.0, 'state': '', 'effective_date': '2024-11-07T12:41:38.000Z'}, {'client_id': 'bbe1c82b-14d4-46e8-b040-1722193ccdbb', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 0.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 360.0, 'payment_date': '2024-11-07T14:49:14.000Z', 'balance': 0.0, 'state': '', 'effective_date': '2024-11-07T14:49:14.000Z'}, {'client_id': 'bbe1c82b-14d4-46e8-b040-1722193ccdbb', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 0.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 960.0, 'payment_date': '2024-11-11T06:37:16.000Z', 'balance': 0.0, 'state': '', 'effective_date': '2024-11-11T06:37:16.000Z'}, {'client_id': 'bbe1c82b-14d4-46e8-b040-1722193ccdbb', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 357.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 3.0, 'payment_date': '2024-11-11T06:59:32.000Z', 'balance': 357.0, 'state': '', 'effective_date': '2024-11-11T06:59:32.000Z'}, {'client_id': 'd2e547ba-f317-4064-8b57-52c2c886647f', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 250.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 10.0, 'payment_date': '2024-11-07T12:05:11.000Z', 'balance': 250.0, 'state': '', 'effective_date': '2024-11-07T12:05:11.000Z'}, {'client_id': 'd2e547ba-f317-4064-8b57-52c2c886647f', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 555.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 5.0, 'payment_date': '2024-11-11T07:05:19.000Z', 'balance': 555.0, 'state': '', 'effective_date': '2024-11-11T07:05:19.000Z'}, {'client_id': 'd62b6b7e-62ca-49e9-9333-a4882bc0f332', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 0.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 166.0, 'payment_date': '2024-10-14T06:47:41.000Z', 'balance': 0.0, 'state': '', 'effective_date': '2024-10-14T06:47:41.000Z'}, {'client_id': 'd62b6b7e-62ca-49e9-9333-a4882bc0f332', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 0.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 60.0, 'payment_date': '2024-10-14T08:00:23.000Z', 'balance': 0.0, 'state': '', 'effective_date': '2024-10-14T08:00:23.000Z'}, {'client_id': 'd62b6b7e-62ca-49e9-9333-a4882bc0f332', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 0.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 6.0, 'payment_date': '2024-10-25T07:39:15.000Z', 'balance': 0.0, 'state': '', 'effective_date': '2024-10-25T07:39:15.000Z'}, {'client_id': 'd62b6b7e-62ca-49e9-9333-a4882bc0f332', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 160.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 16.0, 'payment_date': '2024-10-25T12:35:42.000Z', 'balance': 160.0, 'state': '', 'effective_date': '2024-10-25T12:35:42.000Z'}, {'client_id': 'd62b6b7e-62ca-49e9-9333-a4882bc0f332', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 0.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 174.0, 'payment_date': '2024-10-28T15:25:19.000Z', 'balance': 0.0, 'state': '', 'effective_date': '2024-10-28T15:25:19.000Z'}, {'client_id': 'd62b6b7e-62ca-49e9-9333-a4882bc0f332', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 0.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 163.0, 'payment_date': '2024-10-28T15:35:04.000Z', 'balance': 0.0, 'state': '', 'effective_date': '2024-10-28T15:35:04.000Z'}, {'client_id': 'd62b6b7e-62ca-49e9-9333-a4882bc0f332', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 0.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 166.0, 'payment_date': '2024-11-01T15:28:40.000Z', 'balance': 0.0, 'state': '', 'effective_date': '2024-11-01T15:28:40.000Z'}, {'client_id': 'd62b6b7e-62ca-49e9-9333-a4882bc0f332', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 260.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 260.0, 'payment_date': '2024-11-01T16:41:50.000Z', 'balance': 260.0, 'state': '', 'effective_date': '2024-11-01T16:41:50.000Z'}, {'client_id': 'd62b6b7e-62ca-49e9-9333-a4882bc0f332', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 260.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 260.0, 'payment_date': '2024-11-01T17:19:33.000Z', 'balance': 260.0, 'state': '', 'effective_date': '2024-11-01T17:19:33.000Z'}, {'client_id': 'd62b6b7e-62ca-49e9-9333-a4882bc0f332', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 360.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 29.92, 'payment_date': '2024-11-04T11:43:19.000Z', 'balance': 360.0, 'state': '', 'effective_date': '2024-11-04T11:43:19.000Z'}, {'client_id': 'd62b6b7e-62ca-49e9-9333-a4882bc0f332', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 160.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 10.0, 'payment_date': '2024-11-04T17:18:09.000Z', 'balance': 160.0, 'state': '', 'effective_date': '2024-11-04T17:18:09.000Z'}, {'client_id': 'd62b6b7e-62ca-49e9-9333-a4882bc0f332', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 160.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 10.0, 'payment_date': '2024-11-04T17:27:46.000Z', 'balance': 160.0, 'state': '', 'effective_date': '2024-11-04T17:27:46.000Z'}, {'client_id': 'd62b6b7e-62ca-49e9-9333-a4882bc0f332', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 159.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 11.0, 'payment_date': '2024-11-04T18:59:05.000Z', 'balance': 159.0, 'state': '', 'effective_date': '2024-11-04T18:59:05.000Z'}, {'client_id': 'd62b6b7e-62ca-49e9-9333-a4882bc0f332', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 143.8, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 26.2, 'payment_date': '2024-11-04T19:03:17.000Z', 'balance': 143.8, 'state': '', 'effective_date': '2024-11-04T19:03:17.000Z'}, {'client_id': 'd62b6b7e-62ca-49e9-9333-a4882bc0f332', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 157.2, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 12.8, 'payment_date': '2024-11-05T16:58:27.000Z', 'balance': 157.2, 'state': '', 'effective_date': '2024-11-05T16:58:27.000Z'}, {'client_id': 'd62b6b7e-62ca-49e9-9333-a4882bc0f332', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 157.2, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 12.8, 'payment_date': '2024-11-05T17:11:29.000Z', 'balance': 157.2, 'state': '', 'effective_date': '2024-11-05T17:11:29.000Z'}, {'client_id': 'd62b6b7e-62ca-49e9-9333-a4882bc0f332', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 159.8, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 10.2, 'payment_date': '2024-11-05T17:14:14.000Z', 'balance': 159.8, 'state': '', 'effective_date': '2024-11-05T17:14:14.000Z'}, {'client_id': 'd62b6b7e-62ca-49e9-9333-a4882bc0f332', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 93.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 77.0, 'payment_date': '2024-11-05T17:46:55.000Z', 'balance': 93.0, 'state': '', 'effective_date': '2024-11-05T17:46:55.000Z'}, {'client_id': 'd62b6b7e-62ca-49e9-9333-a4882bc0f332', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 0.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 260.0, 'payment_date': '2024-11-05T17:55:43.000Z', 'balance': 0.0, 'state': '', 'effective_date': '2024-11-05T17:55:43.000Z'}, {'client_id': 'd62b6b7e-62ca-49e9-9333-a4882bc0f332', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 0.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 260.0, 'payment_date': '2024-11-05T17:57:13.000Z', 'balance': 0.0, 'state': '', 'effective_date': '2024-11-05T17:57:13.000Z'}, {'client_id': 'd62b6b7e-62ca-49e9-9333-a4882bc0f332', 'account_type': '', 'client': '', 'agent': '', 'balance_forward': 800.0, 'mrc': '0', 'nrc': '0', 'network_access_fee': '0', 'admin_recovery_tax': '0', 'other_tax': '0', 'total': 0.0, 'payment': 10.0, 'payment_date': '2024-11-06T05:58:26.000Z', 'balance': 800.0, 'state': '', 'effective_date': '2024-11-06T05:58:26.000Z'}]

#     for entry in report_list:
#         if entry['payment_date']:
#             entry['payment_date'] = datetime.strptime(entry['payment_date'], "%Y-%m-%dT%H:%M:%S.%fZ").date().isoformat()


#     main_report_list = []

#     for item in report_list:
#         effective_date = datetime.strptime(item["effective_date"], "%Y-%m-%dT%H:%M:%S.%fZ")
#         if start_date <= effective_date <= end_date:
#             main_report_list.append(item)

#     print(f"######## Final main_report_list is ---------> {main_report_list}")


#     if flag == 'run_report':
#         headers = [
#             "Client id","Account type","Client","Agent","Balance forward","MRC","NRC","Network access fee", "Admin recovery tax",
#             "Other tax","Total","Payment","Payment date","Balance","State"]


#         balance_forward_val = 0
#         mrc_val = 0
#         nrc_val = 0
#         network_access_fee_val = 0
#         admin_recovery_tax_val = 0
#         other_tax_val = 0
#         total_val = 0
#         payment_val = 0
#         balnce_val = 0

#         row_data = []
#         for item in main_report_list:
#             d = {}
#             d["Client id"] = item["client_id"]
#             d["Account type"] = item["account_type"]
#             d["Client"] = item["client"]
#             d["Agent"] = item["agent"]
#             d["Balance forward"] = item["balance_forward"]
#             d["MRC"] = item["mrc"]
#             d["NRC"] = item["nrc"]
#             d["Network access fee"] = item["network_access_fee"]
#             d["Admin recovery tax"] = item["admin_recovery_tax"]
#             d["Other tax"] = item["other_tax"]
#             d["Total"] = item["total"]
#             d["Payment"] = item["payment"]
#             d["Payment date"] = item["payment_date"]
#             d["Balance"] = item["balance"]
#             d["State"] = item["state"]
#             row_data.append(d)

#             try:
#                 balance_forward_val = float(item["balance_forward"]) if item.get("balance_forward", '') != '' else 0
#                 mrc_val = float(item["mrc"]) if item.get("mrc", '') != '' else 0
#                 nrc_val = float(item["nrc"]) if item.get("nrc", '') != '' else 0
#                 network_access_fee_val = float(item["network_access_fee"]) if item.get("network_access_fee", '') != '' else 0
#                 admin_recovery_tax_val = float(item["admin_recovery_tax"]) if item.get("admin_recovery_tax", '') != '' else 0
#                 other_tax_val = float(item["other_tax"]) if item.get("other_tax", '') != '' else 0
#                 total_val = float(item["total"]) if item.get("total", '') != '' else 0
#                 payment_val = float(item["payment"]) if item.get("payment", '') != '' else 0
#                 balnce_val = float(item["balance"]) if item.get("balance", '') != '' else 0
#             except:
#                 pass

#         # sum_headers = ["","Balance Forward","MRC","NRC","Network Access Fee","Admin Recovery Tax","Other Tax","Total","Payment","Balance"]
#         # row_data2 = [{"": "Sum"},{"Balance Forward": balance_forward_val},{"MRC": mrc_val},{"NRC": nrc_val},{"Network Access Fee": network_access_fee_val},
#         #              {"Admin Recovery Tax": admin_recovery_tax_val},{"Other Tax": other_tax_val},{"Total": total_val},{"Payment": payment_val},{"Balance": balnce_val}]


#         sum_headers = ["","Sum"]
#         row_data2 = [{"": "Balance Forward","Sum":balance_forward_val},{"": "MRC","Sum":mrc_val},{"": "NRC","Sum":nrc_val}
#                      ,{"": "Network Access Fee","Sum":network_access_fee_val},{"": "Admin Recovery Tax","Sum":admin_recovery_tax_val},{"": "Other Tax","Sum":other_tax_val},
#                      {"": "Total","Sum":total_val},{"": "Payment","Sum":payment_val},{"": "Balance","Sum":balnce_val}]


#         us_timezone = pytz.timezone('US/Central')
#         # Get the current time in CST
#         us_current_time = datetime.now(us_timezone)
#         # Format the time as "DD-MM-YYYY HH:mmpm CST"
#         us_formatted_time = us_current_time.strftime("%d-%m-%Y %I:%M%p").lower() + " CST"

#         no_of_records = len(main_report_list)

#         top_header = {
#             "printedBy": "admin",
#             "Date&Time": us_formatted_time,
#             "Records": no_of_records
#         }
        

#         response_data = {
#             "run_report":{
#                 "headers" : headers,
#                 "rowData" : row_data
#             },
#             "sum":{
#                 "headers" : sum_headers,
#                 "rowData" : row_data2
#             },
#             "headers": top_header
#         }

#         print(f"######RETURNED RESPONSE DATA {response_data}")
#         return jsonify(response_data)
    
#     if flag == 'download':
#         response_data = altaworx_billing_report_excel_blob(main_report_list)
#         print('response_data',response_data)
#         encoded_xl = base64.b64encode(response_data).decode('utf-8')
#         return jsonify({"xl_data": encoded_xl})
    
def calculationo():
    killbill_database = DB('billing_platform', **db_config)
    batch_list_df=killbill_database.get_data("customer_profiles",None,["account_number"])
    if batch_list_df is not None and not batch_list_df.empty:
        bill_list=batch_list_df['account_number'].tolist()
    else:
        bill_list=[]
    # bill_id_df=killbill_database.get_data('customer_bills',{'id':bill_list},["id","payments","total","amount_due",'remaining'],{'created_date':'asc'}).to_dict(orient="records")
    print(bill_list)
calculationo()   