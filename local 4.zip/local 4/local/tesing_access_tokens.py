from common_utils.email_trigger import send_email
"""
@Author1 : Phaneendra.Y
@Author2 :Ajay
@Author3 :Puja
Created Date: 05-09-2025
"""

# Importing the necessary Libraries
import os
import json
import time
import threading
import boto3 # type: ignore
import pandas as pd # type: ignore
from datetime import datetime
import numpy as np
import base64
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
from concurrent.futures import ThreadPoolExecutor, as_completed
# from config.carrier_config_manager import CarrierConfigManager

import logging

class ColorFormatter(logging.Formatter):
    COLORS = {
        "DEBUG": "\033[94m",   # Blue
        "INFO": "\033[92m",    # Green
        "WARNING": "\033[93m", # Yellow
        "ERROR": "\033[91m",   # Red
        "CRITICAL": "\033[95m" # Purple
    }
    RESET = "\033[0m"

    def format(self, record):
        color = self.COLORS.get(record.levelname, self.RESET)
        message = super().format(record)
        return f"{color}{message}{self.RESET}"

# Create logger
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

# Remove old handlers (important in Jupyter)
logger.handlers.clear()

# Add new handler
handler = logging.StreamHandler()
handler.setFormatter(ColorFormatter("%(levelname)s: %(message)s"))
logger.addHandler(handler)

import requests

def get_verizon_token_details(app_id,app_secret,username_value,password_value):
    """
    Obtain an OAuth access token and session token from Verizon  API.
 
    Args:
        app_id (str): The client ID (application ID) for Verizon API.
        app_secret (str): The client secret associated with the app_id.
 
    Returns:
        tuple[str, str]: A tuple containing the access token and the session token.
 
    Raises:
        requests.exceptions.HTTPError: If any of the HTTP requests fail.
        Exception: For unexpected decoding or response format issues.
    """
    main_url = "https://thingspace.verizon.com"
    client_id = app_id
    client_secret = app_secret
    username = username_value
    password_encoded = password_value
    logging.info(f"### get_verizon_token_details: with credentials {client_id}, {username},")
    # Decode password from base64
    password = base64.b64decode(password_encoded).decode('utf-8')
 
    token_url = f"{main_url}/api/ts/v1/oauth2/token"
    session_url = f"{main_url}/api/m2m/v1/session/login"
 
    # Prepare Basic Auth header
    auth_header = base64.b64encode(f"{client_id}:{client_secret}".encode()).decode()
 
    # Get OAuth access token
    token_response = requests.post(
        token_url,
        headers={
            "Authorization": f"Basic {auth_header}",
            "Accept": "application/json",
        },
        data={"grant_type": "client_credentials"},
    )
    token_response.raise_for_status()
    access_token_id = token_response.json().get("access_token")
    logging.info(f"### get_verizon_token_details Access token: {access_token_id}")
 
    # Get session token
    session_response = requests.post(
        session_url,
        headers={
            "Authorization": f"Bearer {access_token_id}",
            "Accept": "application/json",
            "Content-Type": "application/json"
        },
        json={"username": username, "password": password},
    )
    # session_response.raise_for_status()
    if session_response.status_code != 200:
        logger.error(f"Session login failed: {session_response.text}")
        session_response.raise_for_status()
    session_token = session_response.json().get("sessionToken")
    logging.info(f"## get_verizon_token_details Session token: {session_token}")
    # return access_token_id,session_token
    return {
            "access_token": access_token_id,
            "session_token": session_token
        }

app_id = "RvxMbfpulNVNBU2FpSnBZ2QSai8a"
app_secrete = "5Con_pshpyYfjZ1PMCuBePGS7fQa"
username = "AMOPAPI2022"
password = "VzJhc1ZFcmNKZjlVemlKIQ=="



#   {
#         "service_provider_id": 10,
#         "service_provider_name": "Verizon - HDP",
#         "username": "AMOPAPI2022",
#         "password": "VzJhc1ZFcmNKZjlVemlKIQ==",
#         "oauth2_client_id": "RvxMbfpulNVNBU2FpSnBZ2QSai8a",
#         "oauth2_client_secret": "5Con_pshpyYfjZ1PMCuBePGS7fQa",
#     },
res = get_verizon_token_details(app_id, app_secrete, username, password)
access_token, session_token = res["access_token"], res["session_token"]
print("Access Token:", access_token)
print("Session Token:", session_token)