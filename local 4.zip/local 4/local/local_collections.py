"""
@Author1 : Phaneendra.Y
@Author2 : Nikhil .N
Created Date: 21-06-24
"""
# Importing the necessary Libraries
import requests
import datetime
from datetime import time
from datetime import datetime, timedelta
import time
from io import BytesIO
# from common_utils.data_transfer_main import DataTransfer
import json
import base64
import re
from io import BytesIO
from pytz import timezone
import base64
import os
import boto3
from openpyxl.styles import Alignment, PatternFill, Font
from openpyxl.utils import get_column_letter
#authorize.net dependencies
import xml.etree.ElementTree as ET



# import apicontractsv1
# import createCustomerProfileController
from io import StringIO
# from lxml import etree
import xml.etree.ElementTree as ET
import csv

# Importing the necessary Libraries
import psycopg2
from time import time
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine, exc
from sqlalchemy.exc import OperationalError
from time import time
import pandas as pd
import re
from sqlalchemy import text
from sqlalchemy import literal
from sqlalchemy.orm import sessionmaker
from sqlalchemy import delete, and_, or_
from sqlalchemy import create_engine, Table, MetaData, select, desc, asc, and_,update,or_,insert,func
from sqlalchemy import Integer, String, Float, DateTime, Boolean, Column, Table, MetaData
from sqlalchemy import insert
#from common_utils.logging_utils import Logging
import numpy as np
import json
import os
from datetime import datetime
#logging = Logging(name="db_utils")


##test jenkins
class DB(object):
    def __init__(self, database, host='127.0.0.1', user='root', password='', port='3306' ,customers = None ,service_providers = None,service_provider_id=None ,db_type='postgresql'):
        """
        Initialization of databse object.

        Args:
            databse (str): The database to connect to.
            host (str): Host IP address. For dockerized app, it is the name of
                the service set in the compose file.
            user (str): Username of PostgresSQL server. (default = 'root')
            password (str): Password of PostgresSQL server. For dockerized app, the
                password is set in the compose file. (default = '')
            port (str): Port number for PostgresSQL. For dockerized app, the port that
                is mapped in the compose file. (default = '3306')
        """
        # Assigning instance variables with the given arguments or default values
        self.HOST = host
        self.USER = user
        self.PASSWORD = password
        self.PORT = port
        self.DATABASE = f'{database}'
        self.DB_TYPE = db_type
        self.customers = customers
        self.service_providers = service_providers
        self.service_provider_id = service_provider_id
        # Logging the connection details for debugging purposes
        #print(f'Host: {self.HOST}')
        #print(f'User: {self.USER}')
        #print(f'Port: {self.PORT}')
        #print(f'Database: {self.DATABASE}')
        # Calling the connect method to establish a connection to the database
        self.connect()
        self.file_path = f"C:/Users/Admin/Documents/local/common_utils/schemas/{database}.json"

        # Check if the file exists
        if not os.path.exists(self.file_path):
            print(
                f"File for '{database}' not found. Using default 'default_schema' instead."
            )
            # Replace with default database if file is not found
            self.file_path = f"C:/Users/Admin/Downloads/local 4/local/common_utils/schemas/default_schema.json"
        self.metadata, self.tables = self.load_schema(self.file_path)

    def __del__(self):
        # This method is called when the object is about to be destroyed
        try:
            print("############### DETROYING THE DB CONNECTION")
            # Attempting to close the database connection
            self.engine.close()
            # Disposing of the database engine to free up resources
            # if self.engine:
            #     self.engine.dispose()
            print('connections are closed')

        except Exception as e:
            print('########### Failed to destroy the DB COnenctions', e)


    def connect(self, max_retry=3):
        retry = 1
        try:
            #start = time.time()
            print(f'Making connection to `{self.DATABASE}`...')
            config = f'postgresql://{self.USER}:{self.PASSWORD}@{self.HOST}:{self.PORT}/{self.DATABASE}'
            #print(f"connection : {config}")
            self.engine = create_engine(config, connect_args={'connect_timeout': 10}, pool_recycle=300)
            print(f'Engine created for `{self.DATABASE}`')
            while retry <= max_retry:
                try:
                    self.engine = self.engine.connect()
                    self.session = sessionmaker(bind=self.engine)()
                    #print(f'Connection established successfully to `{self.DATABASE}`! ({round(time() - start, 2)} secs to connect)')
                    break
                except Exception as e:
                    print(f'Connection failed. Retrying... ({retry}) [{e}]')
                    retry += 1
                    self.engine.dispose()
                    if retry > max_retry:
                        raise Exception('Max retry attempts reached. Could not connect to the database.')
        except Exception as e:
            raise Exception(f'Something went wrong while connecting. Check trace. {e}')


    def type_from_string(self,type_str):
        # Map type strings to SQLAlchemy types
        type_map = {
            'Integer': Integer,
            'String': String,
            'Float': Float,
            'DateTime': DateTime,
            'Boolean': Boolean
            # Add other types as needed
        }
        return type_map.get(type_str, String)  # Default to String if type is not found

    def load_schema(self, schema_file):
        metadata = MetaData()
        tables = {}

        with open(schema_file, 'r') as f:
            schema = json.load(f)

        for table_name, columns in schema.items():
            column_objects = []
            for col in columns:
                col_type = self.type_from_string(col['type'])  # Convert type string to actual type
                column_objects.append(Column(col['name'], col_type, nullable=col['nullable'], primary_key=col['primary_key']))

            tables[table_name] = Table(table_name, metadata, *column_objects)

        return metadata, tables


    def combine_records_excluding_columns(self,data, exclude_columns=['id', 'schema_tag']):
        # Create a DataFrame from the input data
        df = pd.DataFrame(data)

        # Determine which columns to include by excluding the specified columns
        include_columns = df.columns.difference(exclude_columns)

        # Group by the include_columns and perform aggregation
        result = (
            df.groupby(include_columns.tolist(), as_index=False)
            .agg(
                id=('id', lambda x: '-'.join(map(str, x))),  # Join original IDs
                schema_tag=('schema_tag', lambda x: '-'.join(set(x)))  # Aggregate schema tags
            )
        )

        return result


    def fetch_schemas(self):
        schema_query = """
        SELECT nspname AS schema_name
        FROM pg_catalog.pg_namespace
        WHERE nspname NOT LIKE 'pg_%'
        AND nspname != 'information_schema';
        """

        with self.engine as connection:
            schemas_result = connection.execute(text(schema_query)).fetchall()

        schemas = [row[0] for row in schemas_result]  # Getting the result returns a list of schema names
        if not schemas:
            print("No schemas found.")
            return []
        return schemas


    def set_shema_path(self,schema):
        # Set the search path to the schema
        set_path=f"SET search_path TO {schema}"
        try:
            if self.engine.closed:
                print('Connection is closed. Attempting to reconnect...')
                self.connect()
            pd.read_sql(set_path, self.engine)
        except exc.ResourceClosedError:
            print('Query executed, but it does not have any result to return.')
            return None


    def execute_query_multi_schemas(self, query, flag=False,insert=[],update=[],schemas=[],attempt=0, **kwargs):
        """
        Executes an SQL query.

        Args:
            query (str): The query that needs to be executed.
            flag (bool): A flag to indicate if the query should proceed without parameters.
            direct_query (bool): If True, executes the query across all available schemas.
            attempt (int): Number of attempts made for retries in case of connection errors.
            kwargs: Additional arguments like 'params' for the query.

        Returns:
            (DataFrame): A pandas DataFrame containing the result of the query, or None if an error occurs.
        """

        try:
            # Initialize data variable
            data = None
            print(f'Executing Query in execute_query_multi_schemas: {query} and insert is {insert} and update is {update} and schemas is {schemas}')

            combined_results = []
            # Handle direct query for executing across schemas
            if insert:
                schemas=insert
            elif update:
                schemas=update

            for schema in schemas:
                try:
                    # Check if the query is parameterized
                    if 'params' not in kwargs and not flag:
                        print('Cannot execute query (Expecting parameterized query).')
                        return None

                    # Extract parameters from kwargs, if available
                    params = tuple(kwargs.get('params', ()))
                    print(f'Params: {params}')

                    print(f"Running query on schema: {schema}")
                    self.set_shema_path(schema)

                    if hasattr(query, 'compile'):
                        query_str = str(query.compile(compile_kwargs={"literal_binds": True}))
                    else:
                        query_str = str(query)

                    print(f'####### Query: {query_str}')
                    print(f'####### Params: {params}')

                    # Execute the query using pandas read_sql method
                    try:
                        query_str=query_str.replace("`","")
                        query_str=query_str.replace('"','')
                    except:
                        pass

                    if self.engine.closed:
                        print('Connection is closed. Attempting to reconnect...')
                        self.connect()

                    # Execute the query using pandas read_sql method
                    schema_data = pd.read_sql(query_str, self.engine, params=params)
                    print(f"Query executed successfully.and data is {schema_data}")

                    if not insert and not update:
                        schema_data['schema_tag']=schema
                        combined_results.append(schema_data)
                except exc.ResourceClosedError:
                    print('Query executed, but it does not have any result to return.')

            # Combine results across schemas and return as one DataFrame
            if combined_results:
                return self.combine_records_excluding_columns(pd.concat(combined_results, ignore_index=True))
            else:
                print("No results obtained across schemas.")
                return True

        except exc.ResourceClosedError:
            print('Query executed, but it does not have any result to return.')
            return None

        except exc.IntegrityError as e:
            print(f'Integrity Error: {e}')
            return None

        except (exc.StatementError, OperationalError) as e:
            # Handle statement and operational errors (e.g., connection issues)
            print(f'Error encountered: {e}. Retrying (attempt #{attempt + 1})...')
            attempt += 1
            if attempt <= 3:
                # Retry the connection and execution
                self.connect()
                return self.execute_query(query, flag=flag,insert=insert,update=update, attempt=attempt, **kwargs)
            else:
                print('Maximum retry attempts reached.')
                return None

        except Exception as e:
            print(f'Error executing query: {e}')
            return None


    def append_conditions(self,query):

        try:
            exception_tables=["users"]
            query = query.replace("\n", " ").replace("\t", " ")
            # Remove extra spaces
            query = " ".join(query.split())
            query=query.replace(";","")
            # tables = re.findall(r'(FROM|JOIN)\s+([a-zA-Z0-9_]+)(?:\s+AS\s+([a-zA-Z0-9_]+))?', query, re.IGNORECASE)
            tables = re.findall(r'(FROM|JOIN)\s+([a-zA-Z0-9_]+\.[a-zA-Z0-9_]+|\S+)(?:\s+AS\s+([a-zA-Z0-9_]+))?', query, re.IGNORECASE)

            # Extract table names and aliases into a list (ignoring 'FROM' and 'JOIN' keywords)
            table_info = [(table[1], table[2] if len(table) > 2 else table[1]) for table in tables]
            print("TABLES AND ALIASES:", table_info)

            # Step 2: Define the additional conditions based on the table(s)
            additional_conditions = ""

            # Loop through the list of tables and append conditions for each
            for table_name, alias in table_info:

                if table_name in exception_tables:
                    continue

                customer_columns = ['customer_name']
                service_provider_column = ['serviceprovider', 'serviceprovidername', 'serviceproviderdisplayname', 'serviceproviders']
                service_provider_id_column=['serviceproviderid']

                if self.customers or self.service_providers:
                    parts=table_name.split('.')
                    if len(parts)>1:
                        cols = self.get_columns(parts[1])
                    else:
                        cols = self.get_columns(parts[0])
                    print('COLUMNS ARE', cols, self.customers, self.service_providers)

                    if self.service_providers and self.service_providers[0]:
                        found=False
                        if 'vw' in table_name.lower():
                            for col_ in cols:
                                col=re.sub(r'[^a-zA-Z]', '', col_).lower()
                                print(self.service_provider_id)
                                if col in service_provider_id_column and (self.service_provider_id and self.service_provider_id[0]) :
                                    found=True
                                    print(self.service_provider_id)
                                    if len(self.service_provider_id) == 1:
                                        if alias:
                                            additional_conditions += f" AND {alias}.{col_} = '{self.service_provider_id[0]}'"
                                        else:
                                            additional_conditions += f" AND {col_} = '{self.service_provider_id[0]}'"
                                    else:
                                        if alias:
                                            additional_conditions += f" AND {alias}.{col_} IN {self.service_provider_id}"
                                        else:
                                            additional_conditions += f" AND {col_} IN {self.service_provider_id}"
                                    break

                        if not found:
                            for col_ in cols:
                                col=re.sub(r'[^a-zA-Z]', '', col_).lower()
                                if col in service_provider_column:
                                    if len(self.service_providers) == 1:
                                        if alias:
                                            additional_conditions += f" AND {alias}.{col_} = '{self.service_providers[0]}'"
                                        else:
                                            additional_conditions += f" AND {col_} = '{self.service_providers[0]}'"
                                    else:
                                        if alias:
                                            additional_conditions += f" AND {alias}.{col_} IN {self.service_providers}"
                                        else:
                                            additional_conditions += f" AND {col_} IN {self.service_providers}"
                                    break

                    if self.customers and self.customers[0]:
                        for col_ in cols:
                            if col_ in customer_columns:
                                col=re.sub(r'[^a-zA-Z]', '', col_).lower()
                                if len(self.customers) == 1:
                                    if alias:
                                        additional_conditions += f" AND {alias}.{col_} = '{self.customers[0]}'"
                                    else:
                                        additional_conditions += f" AND {col_} = '{self.customers[0]}'"
                                else:
                                    if alias:
                                        additional_conditions += f" AND {alias}.{col_} IN {self.customers}"
                                    else:
                                        additional_conditions += f" AND {col_} IN {self.customers}"
                                break

            query_parts = re.split(r"(\sGROUP\sBY\s.+)", query, flags=re.IGNORECASE)
            order_limit_clause = "".join(query_parts[1:])
            if not order_limit_clause:
                query_parts= re.split(r"(\sORDER\sBY\s.+|\sLIMIT\s\d+)", query, flags=re.IGNORECASE)
                order_limit_clause = "".join(query_parts[1:])
                if not order_limit_clause:
                    query_parts = re.split(r"(\sLIMIT\s(?:\d+|\%s)\sOFFSET\s(?:\d+|\%s)|\sLIMIT\s(?:\d+|\%s))", query, flags=re.IGNORECASE)
                    order_limit_clause = "".join(query_parts[1:])
            print(order_limit_clause,'order_limit_clause')
            # Remove any WHERE, ORDER BY, and LIMIT clauses to avoid conflicts
            if order_limit_clause:
                query = base_query = query_parts[0]  # Base query without ORDER BY/LIMIT   # Remove only ORDER BY and LIMIT
                print(query)

            # Step 4: Add the WHERE clause if additional conditions exist
            if additional_conditions:
                if "WHERE" in query.upper():
                    query += additional_conditions
                else:
                    query += " WHERE 1=1" + additional_conditions

            # Step 5: Re-attach any ORDER BY and LIMIT clauses back to the query
            if order_limit_clause:
                query += order_limit_clause # Append ORDER BY / LIMIT
        except Exception as e:
            print(f'Error appending conditions: {e}')

        return query


    def execute_query(self, query,flag=False,no_filter_append=False, insert=[],update=[],attempt=0, **kwargs):
        """
        Executes an SQL query.

        Args:
            query (str): The query that needs to be executed.
            params (list/tuple/dict): List of parameters to pass to in the query.

        Returns:
            (DataFrame) A pandas dataframe containing the data from the executed
            query. (None if an error occurs)
        """
        # Initialize data variable
        data = None
        print(f'Query: {query}')
        schemas=[]
        if not insert and not update:
            schemas=self.fetch_schemas()
        print(f'schemas: {schemas}')

        if len(schemas)>1 or len(update)>0 or len(insert)>1:
            return self.execute_query_multi_schemas(query,flag,insert,update,schemas)
        Session = sessionmaker(bind=self.engine)
        session = Session()  # Create a new session
        try:
            # Check if the query is parameterized
            if 'params' not in kwargs and not flag:
                print('Cannot execute query (Expecting parametarized query).')
                return True
            # Extract parameters from kwargs if available
            params = kwargs['params'] if 'params' in kwargs else None
            if params:
                params=tuple(params)
            else:
                params=()

            if self.engine.closed:
                print('Connection is closed. Attempting to reconnect...')
                self.connect()

            if hasattr(query, 'compile'):
                query_str = str(query.compile(compile_kwargs={"literal_binds": True}))
            else:
                query_str = str(query)

            print(f'####### Query: {query_str}')
            print(f'####### Params: {params}')

            # Execute the query using pandas read_sql method
            try:
                query_str=query_str.replace("`","")
                query_str=query_str.replace('"','')
            except:
                pass

            if self.customers or self.service_providers and "SELECT" in query_str.upper() and not no_filter_append:
                query_str=self.append_conditions(query_str)

            print(f'####### after additional add ons Query: {query_str}')

            data = pd.read_sql(query_str, self.engine, params=params)
            # data =  self.engine.execute(query, params=params)
            print(f"########### Data")
        except exc.ResourceClosedError:
            print('Query does not have any value to return.')
            return True
        except exc.IntegrityError as e:
            print(f'Integrity Error - {e}')
            return None
        except (exc.StatementError, OperationalError) as e:
            # Handle statement errors and operational errors (e.g., connection issues)
            print(f'Creating new connection. Engine/Connection is probably None. [{e}]')
            attempt += 1
            if attempt <= 3:
                # Reconnect to the database
                self.connect()
                print(f'Attempt #{attempt}')
                # Execute the query using execute_query
                return self.execute_query(query, attempt=attempt, **kwargs)
            else:
                print(f'Maximum attempts reached. ({3})')
                return False
        except Exception as e:
            print(f'Something went wrong executing query. Check trace. {e}')
            params = kwargs['params'] if 'params' in kwargs else None
            return False
        finally:
            session.close()
            print('connections are closed')
        # Replace NaN values in the resulting DataFrame with None and return
        return data.replace({np.nan: None})


    def _build_filters(self,table, filters, combine_logic=[]):

        filter_conditions = []
        count=0
        for key, value in filters.items():
            # Check if condition is a tuple (value, logic) e.g., ("not Null", "OR")
            if str(count) in combine_logic:
                logic = "OR"
            else:
                logic = "AND"  # Default logic if not specified

            # Handle NULL and NOT NULL conditions
            if value == "not Null":
                filter_condition = table.c[key].isnot(None)
            elif value == "Null":
                filter_condition = table.c[key].is_(None)
            elif isinstance(value, (list, tuple)):
                # Handle WHERE IN condition
                filter_condition = table.c[key].in_(value)
            else:
                filter_condition = table.c[key] == value
            count=count+1
            filter_conditions.append((filter_condition, logic))

        # Combine conditions based on the specified logic
        and_conditions = [cond for cond, logic in filter_conditions if logic == 'AND']
        or_conditions = [cond for cond, logic in filter_conditions if logic == 'OR']

        combined_condition = "None"
        if and_conditions:
            combined_condition = and_(*and_conditions)
        if or_conditions:
            or_combined = or_(*or_conditions)

            if combined_condition != "None":
                combined_condition = and_(combined_condition, or_combined)
            else:
                combined_condition = or_combined

        return combined_condition


    def get_data(self, table_name=None, condition=None, columns=None, order=None, combine=[], joins=None, mod_pages=None, concat_columns=None,coalesce_columns=None):
        Session = sessionmaker(bind=self.engine)
        session = Session()  # Create a new session

        try:
            print(table_name, condition, columns, order, joins)

            # Reflect the table from the database schema
            # metadata = MetaData()
            # metadata.reflect(bind=self.engine)
            # table = Table(table_name, metadata, autoload_with=self.engine)
            table = self.tables.get(table_name)

            if columns:
                columns = [table.c[col] if isinstance(col, str) else col for col in columns]
            else:
                columns = [table]

            # Handle concatenation if `concat_columns` is provided
            if concat_columns:
                name_column, id_column = concat_columns
                concat_expr = func.concat(
                    table.c[name_column],
                    str(' -- '),
                    table.c[id_column]
                )
                columns.append(concat_expr.label('concat_column'))

            if coalesce_columns:
                coalesce_expr = func.coalesce(
                    *[table.c[col] for col in coalesce_columns]
                )
                columns.append(coalesce_expr.label('coalesce_column'))


            # Create the base query
            query = select(*columns)

            # Handle joins
            if joins:
                for join_table, on_condition in joins.items():
                    join_table = Table(join_table, metadata, autoload_with=self.engine)
                    query = query.join(join_table, on_condition)

            # Apply filters
            if condition:
                where = self._build_filters(table, condition, combine)
                query = query.where(where)

            # Apply ordering
            if order:
                order_by = list(order.keys())[0]
                order_direction = list(order.values())[0]
                order_clause = asc(order_by) if order_direction == 'asc' else desc(order_by)
                query = query.order_by(order_clause)

            # Apply pagination
            if mod_pages:
                start = mod_pages.get('start', 0)
                end = mod_pages.get('end', 500)
                query = query.offset(start).limit(end - start)

            print(f"Final query that is going to get executed is {query}")
            return self.execute_query(query, True)

        except Exception as e:
            # Logging an exception if any error occurs during the update process
            print(f'Error getting data: {e}')
            return False
        finally:
            session.close()  # Ensure the session is closed


    def update_dict(self, table_name, values, and_conditions=None, or_conditions=None, in_conditions=None):
        """
        Updates a table in the database using SQLAlchemy.

        Parameters:
        - table_name: The name of the table to update.
        - values: A dictionary of column-value pairs to update.
        - and_conditions: A list of `AND` conditions (tuples of column and value).
        - or_conditions: A list of `OR` conditions (tuples of column and value).
        - in_conditions: A list of `IN` conditions (tuples of column and list of values).

        Example:
        update_table('users', {'name': 'New Name'},
                    and_conditions={'age':30},
                    or_conditions={'city':'New York'},
                    in_conditions={'id':[1, 2, 3]})
        """

        try:
            # Create connection string
            # metadata = MetaData()
            # metadata.bind = self.engine  # Bind the metadata to the engine
            # table = Table(table_name, metadata, autoload_with=self.engine)
            table = self.tables.get(table_name)

            # Create the base update statement
            stmt = update(table).values(**values)

            # Apply AND conditions
            if and_conditions:
                and_clause = and_(*[table.c[column] == value for column, value in and_conditions.items()])
                stmt = stmt.where(and_clause)

            # Apply OR conditions
            if or_conditions:
                or_clause = or_(*[table.c[column] == value for column, value in or_conditions.items()])
                stmt = stmt.where(or_clause)

            # Apply IN conditions
            if in_conditions:
                in_clause = and_(*[table.c[column].in_(values) for column, values in in_conditions.items()])
                stmt = stmt.where(in_clause)
            print(stmt)
            result = self.engine.execute(stmt)
            self.engine.commit()

            # print("update successful")
            if result.rowcount > 0:
                print("Update successful")
                return True
            else:
                print("No rows were updated")
                return False

        except Exception as e:
            # Logging an exception if any error occurs during the insertion process
            print(f'Error updating data: {e}')
            return False
        finally:
            # Ensure that the cursor and connection are closed
            if 'conn' in locals() and self.engine:
                self.engine.close()

    def update_dict_back(self, table_name, values, and_conditions=None, or_conditions=None, in_conditions=None):
        """
        Updates a table in the database using SQLAlchemy.

        Parameters:
        - table_name: The name of the table to update.
        - values: A dictionary of column-value pairs to update.
        - and_conditions: A dictionary of `AND` conditions (tuples of column and value).
        - or_conditions: A dictionary of `OR` conditions (tuples of column and value).
        - in_conditions: A dictionary of `IN` conditions (tuples of column and list of values).

        Example:
        update_dict('users', {'name': 'New Name'},
                    and_conditions={'age': 30, 'id': '123-456-789'},
                    or_conditions={'city': 'New York'},
                    in_conditions={'id': ['123-456-789', '987-654-321']})
        """

        try:
            # Extract and split the schema_tag from values or conditions
            schema_tag = values.pop('schema_tag', None) or \
                        (and_conditions and and_conditions.pop('schema_tag', None)) or \
                        (or_conditions and or_conditions.pop('schema_tag', None)) or \
                        (in_conditions and in_conditions.pop('schema_tag', None))

            # Split schema_tag by '-' for index use
            schema_tag = schema_tag.split('-') if schema_tag else []
            for ind,tag in enumerate(schema_tag):
                print(f" schema_tag is {tag} and ind is {ind}")
                # Retrieve the table from the schema specified by schema_tag
                table = self.tables.get(table_name)

                # Function to split the id based on schema_tag index
                def process_id_condition(condition_dict):
                    condition={}
                    for key, values_list in condition_dict.items():
                        condition[key]=values_list
                        if key == 'id' and schema_tag:
                            condition['id'] = condition_dict['id'].split('-')[ind]  # Use schema_tag index
                    return condition

                # Process the `and_conditions`, `or_conditions`, and `in_conditions`
                and_condition_dict={}
                if and_conditions:
                    and_condition_dict = process_id_condition(and_conditions)
                or_condition_dict={}
                if or_conditions:
                    or_condition_dict = process_id_condition(or_conditions)
                in_condition_dict={}
                if in_conditions:
                    for key, values_list in in_conditions.items():
                        in_condition_dict[key]=values_list
                        if key == 'id' and schema_tag:
                            in_condition_dict[key] = [value.split('-')[ind] for value in values_list]

                print(and_condition_dict,or_condition_dict,in_condition_dict)

                # Create the base update statement
                stmt = update(table).values(**values)

                # Apply AND conditions
                if and_condition_dict:
                    and_clause = and_(*[table.c[column] == value for column, value in and_condition_dict.items()])
                    stmt = stmt.where(and_clause)

                # Apply OR conditions
                if or_condition_dict:
                    or_clause = or_(*[table.c[column] == value for column, value in or_condition_dict.items()])
                    stmt = stmt.where(or_clause)

                # Apply IN conditions
                if in_condition_dict:
                    in_clause = and_(*[table.c[column].in_(values) for column, values in in_condition_dict.items()])
                    stmt = stmt.where(in_clause)

                # Print the statement for debugging purposes
                print(stmt)

        #       Execute the query
                result = self.execute_query(stmt,True, update=[tag])
                self.engine.commit()

            print("Update successful")
            return True

        except Exception as e:
            # Logging an exception if any error occurs during the process
            print(f'Error updating data: {e}')
            return False

        finally:
            # Ensure that the connection is closed
            if 'conn' in locals() and self.engine:
                self.engine.close()



    def insert_dict(self, data, table):
        """
        Insert dictionary into a SQL database table.

        Args:
            data (dict): The dictionary containing column names and values to insert.
            table (str): The table in which the records should be inserted.

        Returns:
            (bool) True if successfully inserted, else False.
        """
        print(f'Inserting dictionary data into `{table}`...')
        print('testing')
        print(f'Data:\n{data}')

        try:

            # metadata = MetaData()
            # metadata.bind = self.engine  # Bind the metadata to the engine
            # table = Table(table, metadata, autoload_with=self.engine)
            table = self.tables.get(table)

            if not isinstance(data,list):
                data=[data]

            stmt = insert(table).values(data)

            # Executing the constructed query with the parameters
            result = self.execute_query(stmt,True,insert=self.fetch_schemas())
            self.engine.commit()

            print("Insert successful")
            return True

        except Exception as e:
            # Logging an exception if any error occurs during the insertion process
            print(f'Error inserting data: {e}')
            return False
        finally:
            # Ensure that the cursor and connection are closed
            if 'conn' in locals() and self.engine:
                self.engine.close()


    def update_audit(self, data, table):
        """
        Insert dictionary into a SQL database table.

        Args:
            data (dict): The dictionary containing column names and values to insert.
            table (str): The table in which the records should be inserted.

        Returns:
            (bool) True if successfully inserted, else False.
        """
        print(f'Inserting dictionary data into `{table}`...')
        print('testing')
        print(f'Data:\n{data}')

        try:
            # Create connection string
            connection_string = (
                f"{self.DB_TYPE}://{self.USER}:{self.PASSWORD}@{self.HOST}:{self.PORT}/{self.DATABASE}"
            )

            # Establish database connection
            conn = psycopg2.connect(connection_string)
            cursor = conn.cursor()

            # Extracting column names and values
            column_names = [f'"{column_name}"' for column_name in data.keys()]
            params = list(data.values())

            print(f'Column names: {column_names}')
            print(f'Params: {params}')

            # Constructing the SQL query dynamically
            columns_string = ', '.join(column_names)
            param_placeholders = ', '.join(['%s'] * len(column_names))
            print(f"Columns inserting: {columns_string} and values: {param_placeholders}")

            # Making the Insert query
            query = f'INSERT INTO {table} ({columns_string}) VALUES ({param_placeholders})'

            # Executing the constructed query with the parameters
            cursor.execute(query, params)
            conn.commit()

            print("Insert successful")
            return True
        except Exception as e:
            # Logging an exception if any error occurs during the insertion process
            print(f'Error inserting data: {e}')
            return False
        finally:
            # Ensure that the cursor and connection are closed
            if 'cursor' in locals() and cursor:
                cursor.close()
            if 'conn' in locals() and conn:
                conn.close()


    def log_error_to_db(self, data, table):
        """
        Insert dictionary into a SQL database table.

        Args:
            data (dict): The dictionary containing column names and values to insert.
            table (str): The table in which the records should be inserted.

        Returns:
            (bool) True if successfully inserted, else False.
        """
        print(f'Inserting dictionary data into `{table}`...')
        print('testing')
        print(f'Data:\n{data}')

        try:
            # Create connection string
            connection_string = (
                f"{self.DB_TYPE}://{self.USER}:{self.PASSWORD}@{self.HOST}:{self.PORT}/{self.DATABASE}"
            )

            # Establish database connection
            conn = psycopg2.connect(connection_string)
            cursor = conn.cursor()

            # Extracting column names and values
            column_names = [f'"{column_name}"' for column_name in data.keys()]
            params = list(data.values())

            print(f'Column names: {column_names}')
            print(f'Params: {params}')

            # Constructing the SQL query dynamically
            columns_string = ', '.join(column_names)
            param_placeholders = ', '.join(['%s'] * len(column_names))
            print(f"Columns inserting: {columns_string} and values: {param_placeholders}")

            # Making the Insert query
            query = f'INSERT INTO {table} ({columns_string}) VALUES ({param_placeholders})'

            # Executing the constructed query with the parameters
            cursor.execute(query, params)
            conn.commit()
            # # Send success email
            #     # Create dynamic subject and content for the email
            # service_name = data.get('service_name', '')
            # error_message = data.get('error_message', '')
            # error_type = data.get('error_type', '')
            # timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            #     # Create email subject and content
            # subject = f"Error Notification: {service_name} - {error_type}"
            # content = f"""
            #     <p>Hi,</p>
            #     <p>There was an error reported in the service <strong>{service_name}</strong>:</p>
            #     <p><strong>Error Message:</strong> {error_message}</p>
            #     <p><strong>Error Type:</strong> {error_type}</p>
            #     <p><strong>Timestamp:</strong> {timestamp}</p>
            #     <p>Details:</p>
            #     <pre>{data}</pre>
            #     <p>Please investigate the issue as soon as possible.</p>
            #     """

            #     # Send the email
            # template_name = data.get("template_name", 'Log Errors')
            # to_emails, cc_emails, subject, body, from_email, partner_name = send_email(template_name, content=content, is_html=True)
            # message = "Mail sent successfully"

            print("Insert successful")
            return True
        except Exception as e:
            # Logging an exception if any error occurs during the insertion process
            print(f'Error inserting data: {e}')
            return False
        finally:
            # Ensure that the cursor and connection are closed
            if 'cursor' in locals() and cursor:
                cursor.close()
            if 'conn' in locals() and conn:
                conn.close()


    def insert(self, data, table, database=None, if_exists='replace', index=False, method=None):
        """
        Write records stored in a DataFrame to a SQL database.

        Args:
            data (DataFrame): The DataFrame that needs to be write to SQL database.
            table (str): The table in which the rcords should be written to.
            kwargs: Keyword arguments for pandas to_sql function.
                See https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.to_sql.html
                to know the arguments that can be passed.

        Returns:
            (bool) True is succesfully inserted, else false.
        """
        #print(f'Inserting into `{table}`')

        try:
            data.to_sql(table, self.engine, if_exists=if_exists, index=index, method=method)
            return True
        except:
            print('exception')
            return False

    def insert_data(self, data, table):
        """
        Insert dictionary into a SQL database table and return the inserted ID.

        Args:
            data (dict): The dictionary containing column names and values to insert.
            table (str): The table in which the records should be inserted.

        Returns:
            (int) The ID of the inserted row if successful, else None.
        """
        print(f'Inserting dictionary data into `{table}`...')
        print('testing')
        print(f'Data:\n{data}')

        try:
            # Get the table object from metadata
            table = self.tables.get(table)

            if not isinstance(data, list):
                data = [data]

            # Assuming the table has an 'id' column to return after insert
            stmt = insert(table).values(data).returning(table.c.id)

            # Executing the constructed query
            result = self.engine.execute(stmt)
            inserted_id = result.scalar()

            # Committing the transaction
            self.engine.commit()

            print(f"Insert successful, inserted ID: {inserted_id}")
            return inserted_id

        except Exception as e:
            # Logging any error that occurs during the insertion process
            print(f'Error inserting data: {e}')
            return None

        finally:
            # Ensure that the connection is closed
            if 'conn' in locals() and self.engine:
                self.engine.close()

    def get_table_columns(self, table_name):
        query = f"""
        SELECT column_name
        FROM information_schema.columns
        WHERE table_name = '{table_name}'
        ORDER BY ordinal_position;
        """
        return pd.read_sql(query, self.engine)


    def get_columns(self, table):
        """
        Get all column names from an SQL table.
        """
        try:
            print(f'Getting column names of table `{table}`')

            # Query to fetch column names from the database schema

            with open(self.file_path, "r") as f:
                schema = json.load(f)

            if table not in schema:
                with open(f"/opt/python/lib/python3.9/site-packages/common_utils/schemas/default_schema.json", "r") as f:
                    schema = json.load(f)

            column_names = []
            for cols in schema[table]:
                column_names.append(cols['name'])

            return column_names

        except Exception as e:
            print(f"Something went wrong getting column names. Error: {e}")
            return []


    def execute_default_index(self, query, **kwargs):
        """
        Executes an SQL query.

        Args:
            query (str): The query that needs to be executed.
            database (str): Name of the database to execute the query in. Leave
                it none if you want use database during object creation.
            params (list/tuple/dict): List of parameters to pass to in the query.

        Returns:
            (DataFrame) A pandas dataframe containing the data from the executed
            query. (None if an error occurs)
        """
        data = None

        try:
            # Execute the SQL query using pandas read_sql function
            data = pd.read_sql(query, self.engine, **kwargs).replace({pd.np.nan: None})
        except exc.ResourceClosedError:
            # Handle the case where the query is executed successfully but returns no data
            return True
        except:
            # Log and handle any other exceptions that occur during query execution
            print(f'Something went wrong while executing query. Check trace.')
            params = kwargs['params'] if 'params' in kwargs else None
            return False

        return data.where((pd.notnull(data)), None)



    def delete_data(self, table_name, and_conditions=None, or_conditions=None, in_conditions=None):
        """
        Deletes rows from a table in the database using SQLAlchemy.
        """
        # Fetch the table object
        table = self.tables.get(table_name)
        if table is None:
            raise ValueError(f"Table {table_name} not found.")
        print(f"Table found: {table}")

        # Start with a base delete statement
        stmt = delete(table)

        # Construct AND conditions
        if and_conditions:
            and_clauses = [table.c[column] == value for column, value in and_conditions.items()]
            stmt = stmt.where(and_(*and_clauses))

        # Construct OR conditions
        if or_conditions:
            or_clauses = [table.c[column] == value for column, value in or_conditions.items()]
            stmt = stmt.where(or_(*or_clauses))

        # Construct IN conditions
        if in_conditions:
            in_clauses = [table.c[column].in_(values) for column, values in in_conditions.items()]
            stmt = stmt.where(and_(*in_clauses))

        # Debugging: Print the final delete statement
        print(f"Final delete statement: {stmt}")

        # Execute the delete statement using self.engine.execute() directly
        result = self.engine.execute(stmt)

        # Commit the changes
        self.engine.commit()

        print("Delete operation successful.")
        return True
db_config = {
'host': "amoppostoct19.c3qae66ke1lg.us-east-1.rds.amazonaws.com",
'port': "5432",
'user':"root",
'password':"AmopTeam123"
}
def convert_timestamp(df_dict, tenant_time_zone):
    """
    Convert timestamp columns in the provided dictionary list to the tenant's timezone.

    Parameters:
        df_dict (list of dict): A list of dictionaries where each dictionary represents a record
                                containing timestamp fields.
        tenant_time_zone (str): The timezone to which the timestamps should be converted.

    Returns:
        list of dict: The updated list of dictionaries with timestamps converted to the tenant's timezone.
    """
    # Create a timezone object
    target_timezone = timezone(tenant_time_zone)

    # List of timestamp columns to convert
    timestamp_columns = ['created_date', 'modified_date', 'last_email_triggered_at']  # Adjust as needed based on your data

    # Convert specified timestamp columns to the tenant's timezone
    for record in df_dict:
        for col in timestamp_columns:
            if col in record and record[col] is not None:
                # Convert to datetime if it's not already
                timestamp = pd.to_datetime(record[col], errors='coerce')
                if timestamp.tz is None:
                    # If the timestamp is naive, localize it to UTC first
                    timestamp = timestamp.tz_localize('UTC')
                # Now convert to the target timezone
                record[col] = timestamp.tz_convert(target_timezone).strftime('%m-%d-%Y %H:%M:%S')  # Ensure it's a string
    return df_dict
def get_features_by_feature_name(
    user_name, tenant_id, feature_name, common_utils_database, parent_module_name
):
    """
    Fetches features for a given user and tenant by feature name from the database.
    It first looks for the features under a specified parent module name.
    If no features are found under the parent module, it checks other modules.

    Args:
        user_name (str): The username for which features need to be retrieved.
        tenant_id (str): The tenant ID associated with the user.
        feature_name (str): The specific feature name to search for.
        common_utils_database (object): Database utility object to interact with the database.
        parent_module_name (str): The name of the parent module to search for features under.

    Returns:
        list: A list of features for the specified feature name, or an empty list if none are found.
    """

    features_list = []  # Initialize an empty list to store the retrieved features

    try:
        # Fetch user features from the database for the given user and tenant
        user_features_raw = common_utils_database.get_data(
            "user_module_tenant_mapping",  # Table to query
            {"user_name": user_name, "tenant_id": tenant_id},  # Query parameters
            ["module_features"],  # Columns to fetch
        )[
            "module_features"
        ].to_list()  # Convert the result to a list

        print("Raw user features fetched: %s", user_features_raw)

        # Parse the JSON string into a dictionary of user features
        user_features = json.loads(
            user_features_raw[0]
        )  # Assuming the result is a list with one JSON string

        # Initialize a list to hold features for the specified feature name
        features_list = []

        # First, check by parent_module_name for the specified feature
        for module, features in user_features.items():
            if module == parent_module_name and feature_name in features:
                features_list.extend(
                    features[feature_name]
                )  # Add features if found under parent module

        # If no features found under parent_module_name, check other modules
        if not features_list:
            for module, features in user_features.items():
                if feature_name in features:  # Check for the feature in other modules
                    features_list.extend(features[feature_name])

        print(
            "Retrieved features: %s", features_list
        )  # Log the retrieved features

    except Exception as e:
        # Catch any exceptions and log a warning
        print("There was an error while fetching features: %s", e)

    return features_list  # Return the list of retrieved features

def get_headers_mapping(tenant_database, module_list, role, user, tenant_id, sub_parent_module, parent_module, data,):
    """
    Retrieves and organizes field mappings, headers, and module features based on the provided parameters.

    This function:
    - Connects to the database.
    - Fetches field mappings and categorizes them into pop-ups, general fields, and table fields.
    - Retrieves and processes module features based on user roles.
    - Returns a structured dictionary containing headers and features for each module.

    Parameters:
        tenant_database (str): The database name of the tenant.
        module_list (list): List of module names to fetch field mappings for.
        role (str): The role of the user (e.g., 'Super Admin').
        user (str): The username of the user.
        tenant_id (int): The ID of the tenant.
        sub_parent_module (str): The name of the sub-parent module.
        parent_module (str): The name of the parent module.
        data (dict): Additional input data, which may contain:
            - feature_module_name (str): The feature module name.
            - username/user_name/user (str): The username.
            - tenant_name/tenant (str): The tenant name.

    Returns:
        dict: A dictionary where each module name maps to its corresponding headers and features.
    """
    # Establish database connections
    database = DB('billing_platform_common_utils', **db_config)
    killbill_database =  DB('billing_platform', **db_config)

    # Extract relevant details from the input data dictionary
    feature_module_name = data.get("feature_module_name", "")
    user_name = data.get("username") or data.get("user_name") or data.get("user")
    tenant_name = data.get("tenant_name") or data.get("tenant")

    try:
        # Retrieve tenant ID based on tenant name
        tenant_id = database.get_data(
            "tenant", {"tenant_name": tenant_name}["id"]
        )["id"].to_list()[0]
    except Exception as e:
        print(f"Getting exception at fetching tenant id {e}")
    
    ret_out = {}
    
    # Iterate over each module name in the provided module list
    for module_name in module_list:
        out = database.get_data(
            "field_column_mapping", {"module_name": module_name}
        ).to_dict(orient="records")
        pop_up = []
        general_fields = []
        table_fileds = {}
        # Categorize the fetched data based on field types
        for data in out:
            if data["pop_col"]:
                pop_up.append(data)
            elif data["table_col"]:
                table_fileds.update(
                    {
                        data["db_column_name"]: [
                            data["display_name"],
                            data["table_header_order"],
                        ]
                    }
                )
            else:
                general_fields.append(data)
        # Create a dictionary to store categorized fields
        headers = {}
        headers["general_fields"] = general_fields
        pop_up = sorted(pop_up, key=lambda x: x['id'])
        headers["pop_up"] = pop_up
        headers["header_map"] = table_fileds
        try:
            final_features = []

            # Fetch all features for the 'super admin' role
            if role.lower() == "super admin":
                all_features = database.get_data(
                    "module_features", {"module": feature_module_name}, ["features"]
                )["features"].to_list()
                if all_features:
                    final_features = json.loads(all_features[0])
            else:
                final_features = get_features_by_feature_name(
                    user_name, tenant_id, feature_module_name, database
                )

        except Exception as e:
            print(f"there is some error {e}")
            pass
        # Add the final features to the headers dictionary
        headers["module_features"] = final_features
        ret_out[module_name] = headers

    return ret_out

def serialize_data(data):
    """Recursively convert pandas objects in the data structure to serializable types."""
    if isinstance(data, list):
        return [serialize_data(item) for item in data]
    elif isinstance(data, dict):
        return {key: serialize_data(value) for key, value in data.items()}
    elif isinstance(data, pd.Timestamp):
        return data.strftime('%m-%d-%Y %H:%M:%S')  # Convert to string
    else:
        return data  # Return as is if not a pandas object
def collections_list_view(data):
    """
    Retrieves a list of customer profiles for display, including pagination, filtering, and dropdown options.

    Args:
        data (dict): A dictionary containing:
            - db_name (str): Tenant database name (default: 'altaworx_central').
            - role_name (str): User's role for permissions.
            - tenant_name (str): Tenant name for fetching timezone.
            - mod_pages (dict): Pagination details {start, end}.
            - col_sort (dict, optional): Sorting preferences.

    Returns:
        dict: Response structure:
            - flag (bool): Success/failure status.
            - message (str): Success/error message.
            - data (dict): Customer profiles with pagination.
            - header_map (dict): Mapped headers for UI display.
            - dropdown (dict): Dropdown values for filters.
            - pages (dict): Pagination details.
    """
    # Database connections
    database = DB('billing_platform_common_utils', **db_config)
    killbill_database =  DB('billing_platform' ,**db_config)
    
    # Extract relevant details from the input data dictionary
    table_name = data.get('table_name','customer_profiles')
    role_name = data.get('role_name', '')
    col_sort = data.get("col_sort", "")
    tenant_name =data.get('tenant_name','')

    # Set default pagination if not provided
    start = data.get('mod_pages', {}).get('start', 0)
    end = data.get('mod_pages', {}).get('end', 100)

    limit = end - start
    offset = start
    
    # Get tenant's timezone
    tenant_name = data.get('tenant_name', '')
    tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
    tenant_timezone = database.execute_query(tenant_timezone_query, params=[tenant_name])

        # Ensure timezone is valid
    if tenant_timezone.empty or tenant_timezone.iloc[0]['time_zone'] is None:
            raise ValueError("No valid timezone found for tenant.")

    tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
    match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
    if match:
        tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly

    # Get total customer profile count
    total_count_result = killbill_database.get_data(
            table_name, {"is_deleted": "false"},["id"]
        )["id"].to_list()
    total_count=len(total_count_result)

    # Pagination information
    pages_data = {
        "start": start,
        "end": end,
        "total": total_count
    }

    # Sort order handling (ensure valid keys)
    if col_sort:
        order =  {k: v.lower() for k, v in col_sort.items()}
        # print("orderis",order)
    else:
        order= {"modified_date":"desc"}

    # Fetch paginated customer profiles from the database
    df_dict= killbill_database.get_data(
        table_name=table_name,
        condition=None,
        columns=None,
        order=order,
        mod_pages={"start": start, "end": end}
    ).to_dict(orient="records")

    # Convert timestamps to the tenant's timezone
    df_dict = convert_timestamp(df_dict, tenant_time_zone)
    # print('####df_dict',df_dict)

    #dropdown values for account_type
    account_type=['Standard','Parent','Child']

    # Fetch unique service provider names
    service_provider_query=killbill_database.get_data(table_name="serviceprovider",columns=["id","display_name"])
    provider_list_dup = service_provider_query['display_name'].tolist()
    provider_list = sorted(list(set(provider_list_dup)))

    # Fetch list of usernames
    users_query=database.get_data(table_name="users",columns=["first_name","last_name"])
    users_list = users_query.apply(lambda row: f"{row['first_name']} {row['last_name']}", axis=1).tolist()
    users_list = sorted(set(users_list))
    
    # Fetch parent account numbers
    account_numbers=killbill_database.get_data(table_name,{"account_type":'Parent'},["account_number"])
    account_numbers_list_ = account_numbers["account_number"].to_list()
    account_numbers_list = sorted(list(account_numbers_list_))

    # Compile dropdown options
    dropdown={
        'account_type':account_type,
        'btn_provider':provider_list,
        'sales_person': users_list,
        'parent_accounts': account_numbers_list
    }
    try:
        # Fetch mapped headers
        header_map = get_headers_mapping(killbill_database,["Billing-Collections"],role_name, '', '', '', '',data)

        # Serialize customer profiles
        data_dict_all = {"billing_customer_profiles": serialize_data(df_dict)}
        print('###data_dict_all',data_dict_all)

         # Construct success response
        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "dropdown":dropdown,
            "pages": pages_data
        }
        return response

    except Exception as e:
        print(f"Exception occurred: {e}")

        # Construct error response
        response = {
            "flag": False,
            "message": "Something went wrong fetching email list",
            "data": {}  # Return empty dictionary on error
        }
        return response
data={
  "tenant_name": "Altaworx",
  "username": "superadmin",
  "firstLastName": "lohitha v",
  "path": "/collections_list_view",
  "role_name": "Super Admin",
  "parent_module": "Billing Platform",
  "module_name": "Billing-Collections",
  "mod_pages": {
    "start": 0,
    "end": 100
  },
  "request_received_at": "2025-02-27 19:27:50.901",
  "Partner": "Altaworx",
  "access_token": "eyJhbGciOiJSUzI1NiIsImtpZCI6IjMwODk3MDk4OTIxMzk3ODc0NSIsInR5cCI6IkpXVCJ9.eyJhdWQiOlsiMjc4MDg2NzkwODI3NTY1NTIyIiwiMjU2ODkwNjQ5MzM5NTk0NTc2QGF1dGhlbnRpY2F0aW9uYXBpIiwiMjU2ODg5OTc1MzE0ODc2MjQwIl0sImNsaWVudF9pZCI6IjI1Njg5MDY0OTMzOTU5NDU3NkBhdXRoZW50aWNhdGlvbmFwaSIsImVtYWlsIjoicGhhbmVlbmRyYTkxODIyQGdtYWlsLmNvbSIsImVtYWlsX3ZlcmlmaWVkIjp0cnVlLCJleHAiOjE3NDA2ODYxNjIsImZhbWlseV9uYW1lIjoieWVudWd1IiwiZ2l2ZW5fbmFtZSI6IlBoYW5lZW5kcmEiLCJpYXQiOjE3NDA2NjQ1NjIsImlzcyI6Imh0dHBzOi8vYW1vcC1kZXZlbG9wbWVudC14Mmttb2Eueml0YWRlbC5jbG91ZCIsImp0aSI6IlYyXzMwODk4MzU3NDk2MTMyODI0OS1hdF8zMDg5ODM1NzQ5NjEzOTM3ODUiLCJsb2NhbGUiOm51bGwsIm5hbWUiOiJQaGFuZWVuZHJhIFkiLCJuYmYiOjE3NDA2NjQ1NjIsInByZWZlcnJlZF91c2VybmFtZSI6InN1cGVyYWRtaW4iLCJzdWIiOiIyODAwODU3MTU1MzMxMDI2MDYiLCJ1cGRhdGVkX2F0IjoxNzIzNDQwMDk2LCJ1cm46eml0YWRlbDppYW06dXNlcjptZXRhZGF0YSI6eyJwZXJtaXNzaW9uIjoiZXlKMWMyVnlVbTlzWlhNaU9sdDdJbkp2YkdWSlpDSTZNU3dpY205c1pVNWhiV1VpT2lKVGRYQmxjaUJCWkcxcGJpSXNJbk5wZEdWSlpDSTZiblZzYkN3aWMybDBaVWR5YjNWd1NXUWlPbTUxYkd3c0luUmxibUZ1ZEVsa0lqb3hMQ0owWlc1aGJuUk9ZVzFsSWpvaVFXeDBZWGR2Y25naWZWMHNJblZ6WlhKVVpXNWhiblJ6SWpwYmV5SnBaQ0k2TVN3aWJtRnRaU0k2SWtGc2RHRjNiM0o0SWl3aWFYTlRkWEJsY2tGa2JXbHVJanAwY25WbExDSnBjMUJoY21WdWRFRmtiV2x1SWpwMGNuVmxMQ0pwYzBOb2FXeGtRV1J0YVc0aU9tWmhiSE5sTENKcGMxQmhjbVZ1ZEU5eVEyaHBiR1JCWkcxcGJpSTZkSEoxWlN3aWFYTlZjMlZ5VW05c1pTSTZabUZzYzJVc0ltbHpRV2RsYm5RaU9tWmhiSE5sTENKcGMxRjFZV3hwWm1sallYUnBiMjVQYm14NVZYTmxjaUk2Wm1Gc2MyVXNJbU5oYmtGalkyVnpjMDF2WkhWc1pYTWlPbHRkZlYwc0luUmxibUZ1ZEUxdlpIVnNaWE1pT2x0N0ltbGtJam94TENKdGIyUjFiR1ZKWkhNaU9sc3hMRElzTXl3MExEVXNOaXc0TERFd0xERXhMREV5TERFekxERTBMREUxTERFM0xERTJMREU1TERFNExESXdMREl4TERJeUxESXpMREkxTERJMExESTJMREkzTERJNExESTVMRE13TERNeExETXlMRE16TERNMFhYMHNleUpwWkNJNk1USTVMQ0p0YjJSMWJHVkpaSE1pT2xzeExESXNNeXcwTERVc05pdzRMREV3TERFeExERXlMREUwTERFMUxERTJMREU0TERFNUxESXdMREl4TERJeUxESXpMREkwTERJMUxESTJMREkzTERJNExESTVMRE13TERNeExETXlMRE0wWFgwc2V5SnBaQ0k2TWpFeUxDSnRiMlIxYkdWSlpITWlPbHMwTERFeUxERTJMREU0TERJeExESXlMREkwTERJMUxESTJMREkzTERJNUxETXlMRE16TERNMFhYMHNleUpwWkNJNk1qSTJMQ0p0YjJSMWJHVkpaSE1pT2xzeUxERXhMREUwTERFeUxERXdMREUxTERVc01Td3hNeXcyTERNc05Dd3lNQ3d4T0N3eU1Td3lOQ3d5Tml3ek1pd3pORjE5TEhzaWFXUWlPakV4TlRrc0ltMXZaSFZzWlVsa2N5STZXeklzTVRFc01qSXNNVFFzTVRBc01UVXNNVElzTWpBc05Td3hMREUyTERJeExEWXNPQ3d4T0N3ekxESTFMREkyTERJM0xESTRYWDBzZXlKcFpDSTZNVEUyTlN3aWJXOWtkV3hsU1dSeklqcGJOU3cyTERnc01UWmRmU3g3SW1sa0lqb3hNVFkyTENKdGIyUjFiR1ZKWkhNaU9sc3pMRGdzTVRRc01UVXNNakJkZlN4N0ltbGtJam94TVRZM0xDSnRiMlIxYkdWSlpITWlPbHN6TERRc01UQXNNVElzTVRNc01UUXNNVFVzTVRnc01qQXNNakVzTWpRc01qWXNNeklzTVRGZGZTeDdJbWxrSWpveE1UWTRMQ0p0YjJSMWJHVkpaSE1pT2xzekxEUXNOU3cyTERnc01UQXNNVEVzTVRJc01UUXNNVFVzTVRZc01UZ3NNakFzTWpFc016RXNNalFzTWpVc01qWXNNelJkZlN4N0ltbGtJam94TVRjeUxDSnRiMlIxYkdWSlpITWlPbHRkZlYxOSJ9fQ.oQje3IC6ioZ1JnmSkoMvPG3cQ4lAyx15_1BazIMWj8mcn6VSjfTEmKZqqn2rcXhCtNbVnKOIotpPf3fNITwow6yZPo-WM8Fd4CUa-La3hjn2Tsb-OXsahrAV4QE5id3TVUEMUVXcL5rf7_YFd-jacV5nh6cazv4yt9dAtvtYc8MRUVFVGHQlc2PCsNUgp8wE5yNqNXBpCBYFgje1Pf5Rk_Ial1sUydYnxVpzE-EfnZ1Xen3N8J2kt8IpqKhRVnKeKEBmcxomgvwsRMIahQkmKNj9eiKR6YEk1QoEPiAgRrYg1I5OOqh23Rqi3nyL91MVcncx7aw8QM6-DojKcWJ3eg",
  "db_name": "billing_platform",
  "sessionID": '',
  "feature_module_name": "Billing-Collections"
}
# collections_list_view(data)


import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

# Email credentials
sender_email = "info@algonox.com"
receiver_email = "srikanth.rekkala@algonox.com"
password = "Speed@1235!44"

# SMTP server details (Gmail example)
smtp_server = "smtp.gmail.com"
smtp_port = 587

# Create message
msg = MIMEMultipart()
msg["From"] = sender_email
msg["To"] = receiver_email
msg["Subject"] = "Test Email from Python"

# Email body
body = "Hello, this is a test email sent using Python."
msg.attach(MIMEText(body, "plain"))

try:
    # Connect to the server
    server = smtplib.SMTP(smtp_server, smtp_port)
    server.starttls()  # Secure connection
    server.login(sender_email, password)
    
    # Send the email
    server.sendmail(sender_email, receiver_email, msg.as_string())
    
    print("Email sent successfully!")

except Exception as e:
    print(f"Error: {e}")

finally:
    server.quit()




 
# killbill_database = DB('billing_platform', **db_config)
# create_new_collection(data)


# def collections_template_edit_view(data):
#     """
#     Retrieves a list of customer profiles for display, including pagination, filtering, and dropdown options.

#     Args:
#         data (dict): A dictionary containing:
#             - db_name (str): Tenant database name (default: 'altaworx_central').
#             - role_name (str): User's role for permissions.
#             - tenant_name (str): Tenant name for fetching timezone.
#             - mod_pages (dict): Pagination details {start, end}.
#             - col_sort (dict, optional): Sorting preferences.

#     Returns:
#         dict: Response structure:
#             - flag (bool): Success/failure status.
#             - message (str): Success/error message.
#             - data (dict): Customer profiles with pagination.
#             - header_map (dict): Mapped headers for UI display.
#             - dropdown (dict): Dropdown values for filters.
#             - pages (dict): Pagination details.
#     """
#     # Database connections
#     database = DB(os.environ["BILLING_PLATFORM_COMMON_UTILS_DATABASE"], **db_config)
#     killbill_database =  DB(os.environ["BILLING_PLATFORM"] ,**db_config)
    
#     # Extract relevant details from the input data dictionary
#     table_name = data.get('table_name','collection_templates')
#     role_name = data.get('role_name', '')
#     col_sort = data.get("col_sort", "")
#     tenant_name =data.get('tenant_name','')
#     module_name=data.get('module_name', '')
#     template_id=data.get('template_id','')

#     # Set default pagination if not provided
#     start = data.get('mod_pages', {}).get('start', 0)
#     end = data.get('mod_pages', {}).get('end', 100)

#     limit = end - start
#     offset = start

#     # Get tenant's timezone
#     tenant_name = data.get('tenant_name', '')
#     tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
#     tenant_timezone = database.execute_query(tenant_timezone_query, params=[tenant_name])

#         # Ensure timezone is valid
#     if tenant_timezone.empty or tenant_timezone.iloc[0]['time_zone'] is None:
#             raise ValueError("No valid timezone found for tenant.")

#     tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
#     match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
#     if match:
#         tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly

#     # Get total customer profile count
#     total_count_result = killbill_database.get_data(
#             table_name, {"is_deleted": "false","template_id":template_id},["id"]
#         )["id"].to_list()
#     total_count=len(total_count_result)

#     # Pagination information
#     pages_data = {
#         "start": start,
#         "end": end,
#         "total": total_count
#     }

#     # Sort order handling (ensure valid keys)
#     if col_sort:
#         order =  {k: v.lower() for k, v in col_sort.items()}
#         # print("orderis",order)
#     else:
#         order= {"modified_date":"desc"}

#     # Fetch paginated customer profiles from the database
#     df_dict= killbill_database.get_data(
#         table_name=table_name,
#         condition={"is_deleted": "false","template_id":template_id},
#         columns=None,
#         order=order,
#         mod_pages={"start": start, "end": end}
#     ).to_dict(orient="records")

#     # Convert timestamps to the tenant's timezone
#     df_dict = convert_timestamp(df_dict, tenant_time_zone)
#     # print('####df_dict',df_dict)
#     add_a_step=['Letter','Email','Phone Call','Text Message (SMS)','2-Way Suspend','1-Way Suspend','Block LD','Disconnect','Manual Step']
#     # Compile dropdown options
#     collection_steps={
#         "step_type":add_a_step
#     }
#     try:
#         # Fetch mapped headers
#         header_map = get_headers_mapping(killbill_database,[module_name],role_name, '', '', '', '',data)

#         # Serialize customer profiles
#         data_dict_all = {"collection_templates": serialize_data(df_dict)}
#         print(f'###data_dict_all {data_dict_all}')

#          # Construct success response
#         response = {
#             "flag": True,
#             "message": "Data fetched successfully",
#             "data": data_dict_all,
#             "header_map": header_map,
#             "dropdown":collection_steps,
#             "pages": pages_data
#         }
#         return response

#     except Exception as e:
#         print(f"Exception occurred: {e}")

#         # Construct error response
#         response = {
#             "flag": False,
#             "message": "Something went wrong fetching Collections list",
#             "data": {}  # Return empty dictionary on error
#         }
#         return response
    

def collection_step_edit(data):
    """
    Retrieves step-specific data for collection processes, including relevant columns, dropdown options, and header mappings.

    Args:
        data (dict): A dictionary containing:
            - options (str): The type of collection step (e.g., 'Letter', 'Email', 'Phone Call', etc.).
            - role_name (str, optional): User's role for permissions.
            - module_name (str, optional): Module name for header mapping.

    Returns:
        dict: Response structure:
            - flag (bool): Success/failure status.
            - message (str): Success/error message.
            - columns (list): List of relevant columns for the selected step.
            - dropdown (dict): Dropdown values for applicable fields.
            - header_map (dict): Mapped headers with filtered pop-up data.

    Raises:
        ValueError: If an invalid step type is provided.
    """
    try:
        # Extract input values with defaults
        changed_data=data.get("changed_data","")
        option = changed_data.get("step_type", "")
        if not option:
            return {'flag': False, "message": 'Empty Step Type'}
        role_name = data.get('role_name', '')
        module_name = data.get('module_name', '')
        # Initialize database connection
        try:
            killbill_database = DB('billing_platform', **db_config)
        except KeyError:
            print("Environment variable 'BILLING_PLATFORM' is missing.")
            return {"flag": False, "message": "Server configuration error: Missing database environment variable."}
        except Exception as e:
            print(f"Database connection failed: {str(e)}")
            return {"flag": False, "message": "Database connection failed."}

        # Define default dropdown values
        display_options = ['PDF', 'PDF Zip', 'Pitney Bowes', 'SpanDocs']
        copy_to_ftp = ['None']
        to_contacts = ['Administrative', 'Agent', 'Billing', 'DocuSign Approver', 'General', '--None--', 
                       'Notifications', 'Other', 'Primary', 'Secondary', 'Technical', 'Vendor']
        include_invoice = ['None', 'Most Recent Invoice', 'All Overdue Invoices']
        close_reason = ['Business Downturn', 'Collections', 'Competitive Loss', 
                        'Non Payment', 'Upgrade_Migration', 'Write-Off']

        # Group dropdowns in a dictionary
        dropdown = {
            "display_options": display_options,
            "copy_to_ftp": copy_to_ftp,
            "to_contacts": to_contacts,
            "contact_override":to_contacts,
            "include_invoice": include_invoice,
            "close_reason": close_reason
        }

        # Retrieve header mapping based on module and role
        try:
            header_map = get_headers_mapping(killbill_database, [module_name], role_name, '', '', '', '', data)
        except Exception as e:
            print(f"Error fetching header mapping: {str(e)}")
            return {"flag": False, "message": "Failed to fetch header mappings."}

        print(f'### header_map: {header_map}')

        # Define step-specific columns
        step_columns = {
            "Letter": ['step_description', 'grace_period', 'display_option', 'copy_to_ftp_site'],
            "Email": ['step_description', 'grace_period', 'from_email', 'to_contacts', 'cc', 'bcc', 
                      'subject', 'include_invoice', 'preview_email'],
            "Phone Call": ['step_description', 'grace_period', 'contact_override'],
            "Text Message (SMS)": ['step_description', 'grace_period', 'contact_override'],
            "2-Way Suspend": ['step_description', 'grace_period'],
            "1-Way Suspend": ['step_description', 'grace_period'],
            "Block LD": ['step_description', 'grace_period'],
            "Disconnect": ['step_description', 'grace_period', 'close_reason'],
            "Manual Step": ['step_description', 'grace_period']
        }

        # Convert case-insensitive step names for matching
        columns = step_columns.get(option, None)

        if columns is None:
            print(f"Invalid step option provided: {option}")
            return {"flag": False, "message": "Invalid Step"}

        # Filter pop-up data to only include relevant columns
        pop_up_data = header_map.get(module_name, {}).get('pop_up', [])
        filtered_pop_up = [i for i in pop_up_data if i.get('db_column_name') in columns]

        # Update the header map with filtered pop-up data
        header_map[module_name]['pop_up'] = filtered_pop_up

        return {
            "flag": True,
            "columns": columns,
            "message": "Data fetched successfully",
            "dropdown": dropdown,
            "header_map": header_map,
            "changed_data":changed_data
        }

    except Exception as e:
        print(f"Unexpected error in add_step_data: {str(e)}")
        return {"flag": False, "message": "An unexpected error occurred while processing the request."}


data={
    "tenant_name": "Altaworx",
    "username": "superadmin",
    "firstLastName": "lohitha v",
    "path": "/collection_step_edit",
    "role_name": "Super Admin",
    "parent_module": "Billing Platform",
    "module_name": "Collection Steps",
    "mod_pages": {
      "start": 0,
      "end": 100
    },
    "changed_data": {
      "id": 19,
      "template_id": 27,
      "step_description": "Test message test",
      "grace_period": 12,
      "step_type": "Letter",
      "day": 12,
      "created_date": "03-10-2025 05:50:25",
      "modified_date": "03-10-2025 05:50:25"
    },
    "request_received_at": "2025-03-10 18:03:59.617",
    "Partner": "Altaworx",
    "access_token": "null",
    "db_name": "billing_platform",
    "feature_module_name": "Collection Steps"
  }

# collection_step_edit(data)



def billing_collections_ledger_list_view(data):
    """
    Retrieves a paginated list of billing packages along with relevant dropdown values for service types and providers.
    The function queries the database for a list of billing packages and prepares the necessary data for display,
    including pagination information and dropdown options for selecting service types and providers.

    Args:
        data (dict): A dictionary containing the following keys:
            - db_name (str): Tenant database name. Defaults to 'altaworx_central'.
            - role_name (str): The user's role name for permissions and data access.
            - tenant_name (str): Tenant name used to fetch tenant-specific timezone information.
            - mod_pages (dict): Pagination information, containing:
                - start (int): The starting index for records to fetch.
                - end (int): The ending index for records to fetch.
            - other fields as necessary for query execution.

    Returns:
        dict: A dictionary containing:
            - flag (bool): Status of the operation (True for success, False for failure).
            - message (str): Success or failure message.
            - data (dict): Contains the fetched data, including:
                - billing_packages: A list of billing packages.
            - header_map (dict): Mapping for headers based on user role.
            - pages (dict): Pagination details (start, end, total).
            - dropdown (dict): Contains options for dropdowns such as 'service_type' and 'provider'.
    """

    database = DB('billing_platform_common_utils', **db_config)
    killbill_database = DB('billing_platform', **db_config)
    # database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    # killbill_database = DB(os.environ['BILLING_PLATFORM'], **db_config)
    tenant_database=data.get('db_name','altaworx_central')
    role_name = data.get('role_name', '')
    tenant_name =data.get('tenant_name','')
    module_name=data.get('module_name','Billing and Collections Ledger')
    table_name=data.get('table_name','ledger')
    # Set default pagination if not provided
    start = data.get('mod_pages', {}).get('start', 0)
    end = data.get('mod_pages', {}).get('end', 100)
    flag = data.get('status', '')
    col_sort=data.get('col_sort',{})
    account_number=data.get("account_number", '')
    if not account_number:
        return {"flag": False, "message": "Account number is required"}

    limit = end - start
    offset = start
    
    # Get tenant's timezone
    tenant_name = data.get('tenant_name', '')
    tenant_time_zone = database.get_data(
            "tenant", {"tenant_name": tenant_name},["time_zone"]
        )["time_zone"].to_list()[0]
    print("**tenant_time_zone",tenant_time_zone)

    if tenant_time_zone is None:
            raise ValueError("No valid timezone found for tenant.")
    match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
    if match:
        tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly

    # Query to get the total number of rows for pagination
    total_count_query = f"""SELECT COUNT(*) AS total FROM {table_name} where account={account_number}"""
    total_count_result = killbill_database.execute_query(total_count_query, flag=True)
    print(f"total_count_result: {type(total_count_result)} - {total_count_result}")
    total_count = int(total_count_result.iloc[0]['total'])

    # Pagination information
    pages_data = {
        "start": start,
        "end": end,
        "total": total_count
    }
    
    # query to get listview
    base_query = f"""
    SELECT * FROM {table_name} where account={account_number}
    """
    if col_sort:
        order={k: v.lower() for k, v in col_sort.items()}
        order_by = list(order.keys())[0]  
        order_direction = order[order_by].lower()  
        base_query += f" ORDER BY {order_by} {order_direction}"
    else:
        base_query += " ORDER BY date"  

    base_query += " LIMIT %s OFFSET %s"

    # Execute query with limit and offset for pagination
    params = [limit, offset]
    df = killbill_database.execute_query(base_query, params=params)  # Get the DataFrame directly
    print(f'###df {df}')
    df_dict = df.to_dict(orient="records")  # Convert to dictionary for processing
    df_dict = convert_timestamp(df_dict, tenant_time_zone)
    try:
        # Prepare response data
        header_map = get_headers_mapping(tenant_database,[module_name],role_name, '', '', '', '',data)
        data_dict_all = {"billing_and_collections_ledger": serialize_data(df_dict)}

        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data
            }
        return response

    except Exception as e:
        print(f"Exception occurred: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching email list",
            "data": {}  # Return empty dictionary on error
        }
        return response

# data={
#     "tenant_name": "Altaworx",
#     "username": "superadmin",
#     "firstLastName": "lohitha v",
#     "path": "/collection_step_edit",
#     "role_name": "Super Admin",
#     "parent_module": "Billing Platform",
#     "module_name": "Collection Steps",
#     "mod_pages": {
#       "start": 0,
#       "end": 100
#     },
#     "changed_data": {
#       "id": 19,
#       "template_id": 27,
#       "step_description": "Test message test",
#       "grace_period": 12,
#       "step_type": "Letter",
#       "day": 12,
#       "created_date": "03-10-2025 05:50:25",
#       "modified_date": "03-10-2025 05:50:25"
#     },
#     "request_received_at": "2025-03-10 18:03:59.617",
#     "Partner": "Altaworx",
#     "access_token": "null",
#     "db_name": "billing_platform",
#     "feature_module_name": "Collection Steps"
#   }

# print(billing_collections_ledger_list_view(data))




def billing_collections_ledger_list_view(data):
    """
    Retrieves a paginated list of billing packages along with relevant dropdown values for service types and providers.
    The function queries the database for a list of billing packages and prepares the necessary data for display,
    including pagination information and dropdown options for selecting service types and providers.

    Args:
        data (dict): A dictionary containing the following keys:
            - db_name (str): Tenant database name. Defaults to 'altaworx_central'.
            - role_name (str): The user's role name for permissions and data access.
            - tenant_name (str): Tenant name used to fetch tenant-specific timezone information.
            - mod_pages (dict): Pagination information, containing:
                - start (int): The starting index for records to fetch.
                - end (int): The ending index for records to fetch.
            - other fields as necessary for query execution.

    Returns:
        dict: A dictionary containing:
            - flag (bool): Status of the operation (True for success, False for failure).
            - message (str): Success or failure message.
            - data (dict): Contains the fetched data, including:
                - billing_packages: A list of billing packages.
            - header_map (dict): Mapping for headers based on user role.
            - pages (dict): Pagination details (start, end, total).
            - dropdown (dict): Contains options for dropdowns such as 'service_type' and 'provider'.
    """

    database = DB('billing_platform_common_utils', **db_config)
    killbill_database = DB('billing_platform', **db_config)
    # database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
    # killbill_database = DB(os.environ['BILLING_PLATFORM'], **db_config)
    tenant_database=data.get('db_name','altaworx_central')
    role_name = data.get('role_name', '')
    tenant_name =data.get('tenant_name','')
    module_name=data.get('module_name','Billing and Collections Ledger')
    table_name=data.get('table_name','ledger')
    # Set default pagination if not provided
    start = data.get('mod_pages', {}).get('start', 0)
    end = data.get('mod_pages', {}).get('end', 100)
    flag = data.get('status', '')
    col_sort=data.get('col_sort',{})
    account_number=data.get("account_number", '')
    if not account_number:
        return {"flag": False, "message": "Account number is required"}
    limit = end - start
    offset = start
    
    # Get tenant's timezone
    tenant_name = data.get('tenant_name', '')
    tenant_time_zone = database.get_data(
            "tenant", {"tenant_name": tenant_name},["time_zone"]
        )["time_zone"].to_list()[0]
    print("**tenant_time_zone",tenant_time_zone)

    if tenant_time_zone is None:
            raise ValueError("No valid timezone found for tenant.")
    match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
    if match:
        tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly

    # Query to get the total number of rows for pagination
    total_count_query = f"""SELECT COUNT(*) AS total FROM {table_name} where account='{account_number}'"""
    total_count_result = killbill_database.execute_query(total_count_query, flag=True)
    print(f"total_count_result: {type(total_count_result)} - {total_count_result}")
    total_count = int(total_count_result.iloc[0]['total'])

    # Pagination information
    pages_data = {
        "start": start,
        "end": end,
        "total": total_count
    }
    
    # query to get listview
    base_query = f"""
    SELECT * FROM {table_name} where account='{account_number}'
    """
    if col_sort:
        order={k: v.lower() for k, v in col_sort.items()}
        order_by = list(order.keys())[0]  
        order_direction = order[order_by].lower()  
        base_query += f" ORDER BY {order_by} {order_direction}"
    else:
        base_query += " ORDER BY date"  

    base_query += " LIMIT %s OFFSET %s"

    # Execute query with limit and offset for pagination
    params = [limit, offset]
    df = killbill_database.execute_query(base_query, params=params)  # Get the DataFrame directly
    print(f'###df {df}')
    df_dict = df.to_dict(orient="records")  # Convert to dictionary for processing
    df_dict = convert_timestamp(df_dict, tenant_time_zone)
    try:
        # Prepare response data
        header_map = get_headers_mapping(tenant_database,[module_name],role_name, '', '', '', '',data)
        data_dict_all = {"billing_and_collections_ledger": serialize_data(df_dict)}

        response = {
            "flag": True,
            "message": "Data fetched successfully",
            "data": data_dict_all,
            "header_map": header_map,
            "pages": pages_data
            }
        return response

    except Exception as e:
        print(f"Exception occurred: {e}")
        response = {
            "flag": False,
            "message": "Something went wrong fetching email list",
            "data": {}  # Return empty dictionary on error
        }
        return response





# def create_new_collection(data):
#     """
#     Inserts a new collection step and its associated template into the database while logging the action.
#     """
#     # database = DB(os.environ['BILLING_PLATFORM_COMMON_UTILS_DATABASE'], **db_config)
#     # killbill_database = DB(os.environ['BILLING_PLATFORM'], **db_config)
#     database = DB('billing_platform_common_utils', **db_config)
#     killbill_database = DB('billing_platform', **db_config)

#     tenant_database = data.get('db_name', 'altaworx_central')
#     step_table_name = data.get('step_table_name', 'collection_steps')
#     template_table_name = data.get('template_table_name', 'collection_templates')
#     module_name = data.get('module_name', 'Collections Steps')
#     created_by = data.get('username', '')
#     modified_by = data.get('username', '')
#     modified_date = data.get('request_received_at', '')
#     Partner = data.get("Partner", "")
#     username = data.get("username", "")
#     session_id = data.get("session_id", "")
#     role_name = data.get('role_name', '')
#     tenant_name = data.get('tenant_name', '')
#     changed_data = data.get('changed_data', {})
#     # step_changed_data = data.get('changed_data', {}).copy()  # Use copy to avoid modifying the original dict
#     step_changed_data=changed_data.get('stepsData','')
#     if "stepsData" in changed_data:
#         changed_data.pop('stepsData','')
#     template_change_data = {}

#     # Move specific keys to the template data
#     if 'template_description' in changed_data:
#         template_change_data['template_description'] = changed_data.pop('template_description')
#     if 'balance_limit' in changed_data:
#         template_change_data['balance_limit'] = changed_data.pop('balance_limit')

#     template_change_data['created_by'] = created_by
#     template_change_data['modified_by'] = modified_by

#     # step_changed_data = {k: str(v) for k, v in step_changed_data.items() if v not in (None, "None", "")}
#     print(f'##after step_changed_data {step_changed_data}')
#     template_change_data = {k: str(v) for k, v in template_change_data.items() if v not in (None, "None", "")}
#     print(f'##after template_change_data {template_change_data}')
#     conn = psycopg2.connect(
#             dbname='billing_platform',
#             user='root',
#             password='AmopTeam123',
#             host='amoppostoct19.c3qae66ke1lg.us-east-1.rds.amazonaws.com',
#             port='5432'
#         )
#     cur = conn.cursor()

#     # Insert into collection_templates and return the template ID
#     insert_template_query = f"""
#         INSERT INTO {template_table_name} (template_description, balance_limit, created_by, modified_by) 
#         VALUES (%s, %s, %s, %s) RETURNING id;
#     """
#     cur.execute(insert_template_query, (
#         template_change_data.get('template_description', ''),
#         template_change_data.get('balance_limit', 0),
#         template_change_data.get('created_by', ''),
#         template_change_data.get('modified_by', '')
#     ))
#     template_id = cur.fetchone()[0]  # Fetch the returned ID
#     if template_id:
#         print(f'####template_id {template_id}')
#         print(f'type-------{type(template_id)}')
#         # Iterate through each step and add template_id
#         for step in step_changed_data:
#             step['template_id'] = template_id
#     else:
#         return {'flag':False,"message":"Template Id Empty"}
#     print(f'####step_changed_data2 {step_changed_data}')
#     conn.commit()
#     cur.close()
#     conn.close()
#     print(f'Fetched template_id: {template_id}, Type: {type(template_id)}')
#     status=killbill_database.insert_data(step_changed_data, step_table_name)
#     if status:
#         response = {
#             "flag": True,
#             "message": "Successfully added a Step"
#         }
#     else:
#         response = {
#             "flag": False,
#             "message": "Error Adding a Step"
#         }

#     return response
# data={
#   "tenant_name": "Altaworx",
#   "username": "superadmin",
#   "firstLastName": "lohitha v",
#   "path": "/create_new_collection",
#   "role_name": "Super Admin",
#   "module_name": "Collection Steps",
#   "feature_module_name": "Billing Platform",
#   "Partner": "Altaworx",
#   "access_token": "null",
#   "db_name": "billing_platform",
#   "template_table_name": "collection_templates",
#   "step_table_name": "collection_steps",
#   "request_received_at": "2025-03-12 11:55:36.384",
#   "sessionID": '',
#   "action": "create",
#   "modified_by": "lohitha v",
#   "changed_data": {
#     "template_description": "Email",
#     "balance_limit": "33",
#     "step_type": "Letter",
#     "stepsData": [
#       {
#         "step_description": "Email #1",
#         "grace_period": "10",
#         "to_contacts": "Billing",
#         "from_email": "srikanth.rekkala@algonox.com",
#         "include_invoice": "Most Recent Invoice",
#         "step_type": "Email",
#         "day": "10"
#       },
#       {
#         "step_description": "Phone #6",
#         "grace_period": "5",
#         "contact_override": "General",
#         "step_type": "Phone Call",
#         "day": "15"
#       },
#       {
#         "step_description": "Letter#5",
#         "grace_period": "7",
#         "step_type": "Letter",
#         "day": "22"
#       }
#     ]
#   }
# }

# create_new_collection(data)
import ast
def checkkk():
    killbill_database = DB('billing_platform', **db_config)
    batch_list_df=killbill_database.get_data("payment_batch_info",{"id":"5"},["bill_list"])
    bill_list=batch_list_df['bill_list'].tolist()[0]
    bill_list=ast.literal_eval(bill_list)
    print(bill_list)
    # print(type(bill_list))
    
    account_number_df=killbill_database.get_data("customer_bills",{"id":bill_list[0]},["account_number"])
    if account_number_df is not None and not account_number_df.empty:
        account_number = str(account_number_df['account_number'].tolist()[0])
        # print(f'###account_number {account_number}')
    else:
        account_number=''
    # print(account_number)
    
    transaction_history_rows=[]
    for bill_num in bill_list:
        print(bill_num)
        transaction_data = {
        "ref": '123',
        "status": 'S',
        "date": '3345',
        "amount": '33',
        "method": 'sdsd',
        "source": "Authorize.net",
        "bill_id":str(bill_num) ,
        "auth_code": 'sdhdsd',
        "account_number": account_number,
        "agent":'dsd'
    }
        transaction_history_rows.append(transaction_data)
    print(transaction_history_rows)
# checkkk()

def calculationo():
    amount=100
    killbill_database = DB('billing_platform', **db_config)
    batch_id='5'
    batch_list_df=killbill_database.get_data("payment_batch_info",{"id":batch_id},["bill_list"])
    bill_list=batch_list_df['bill_list'].tolist()[0]
    bill_list=ast.literal_eval(bill_list)
    bill_id_df=killbill_database.get_data('customer_bills',{'id':bill_list},["id","payments","total","amount_due",'remaining'],{'created_date':'asc'}).to_dict(orient="records")
    
    print("bill_id_df")
    print(bill_id_df)
    bill_list_len=len(bill_id_df)
    row_index=0
    while (amount>0 and row_index<bill_list_len):
        bill_dict=bill_id_df[row_index]
        if 'id' in bill_dict:
            current_bill_id=bill_dict['id']
        else:
            current_bill_id=''
            continue
        if 'payments' in bill_dict:
            payments = float(bill_dict['payments'])
        else:
            payments=0
        if 'total' in bill_dict:
            total = float(bill_dict['total'])
        else:
            total=0
        if 'amount_due' in bill_dict:
            amount_due = float(bill_dict['amount_due'])
        else:
            amount_due=0
        if 'remaining' in bill_dict:
            remaining = float(bill_dict['remaining'])
        else:
            remaining=0
        if amount>=remaining:
            amount=amount-remaining
            payments=payments+remaining
            remaining=0
            amount_due=0
        else:
            payments=payments+amount
            remaining=remaining-amount
            amount_due=amount_due-amount
            amount=0
        row_index+=1
        updated_data={"payments":str(payments),"total":str(total),"amount_due":str(amount_due),"remaining":str(remaining)}
        print('updated_data')
        print(updated_data)
        # try:
        #     status=killbill_database.update_dict('customer_bills', updated_data, {"id": current_bill_id})
        #     if status:
        #         print(f'### Updated customer_bills')
        #     else:
        #         raise Exception("Database Insert Failed")
        # except Exception as db_error:
        #     print(f"### Database Error: {str(db_error)}")
        #     return {"flag": False, "message": "Database insertion failed"}



# calculationo()





def authorize_net_webhook_response(event, context): 
    """
    Processes webhook events from Authorize.Net, extracting transaction details and updating the payment history 
    in the billing platform database. The function verifies the event structure, retrieves necessary transaction 
    details such as ID, amount, invoice number, and authorization code, and associates them with the corresponding 
    customer account. It then inserts the transaction data into the payment_history table. If the transaction is successful, 
    a confirmation message is returned; otherwise, an error message is provided.
    Args:
    event (dict): The webhook event data containing transaction details.
    context (dict): Additional context for the function execution.
    Returns:
    A dictionary indicating the success or failure of the transaction processing, along with a relevant message.
    """
    # Log the full event to verify structure
    print(f"---> Full event received: {json.dumps(event, indent=2)}")
    
    # Extract JSON correctly from `event`
    data = event.get("data")  # Fix: Get "data" instead of "body"
    # Database object (assuming DB is a custom class)
    killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)
    if not data:
        print('### Missing or empty data in event')
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "Missing or empty data"})
        }

    print(f"####Parsed data: {json.dumps(data, indent=2)}")

    # Ensure the payload exists
    if "payload" not in data:
        print('### Invalid data structure')
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "Invalid data structure"})
        }

    payload = data["payload"]

    # Extract required fields safely
    transaction_id = payload.get("id")  # Correct field from webhook payload
    amount = payload.get("authAmount")  # Correct field from webhook payload
    status = "Successful" if payload.get("responseCode") == 1 else "Failed"
    invoice_number = payload.get("invoiceNumber","")
    batch_id=invoice_number
    auth_code = payload.get("authCode", "")
    event_date = data.get("eventDate","")
    webhook_id = data.get("webhookId","")

    # Ensure required fields exist
    if not transaction_id:
        print("### Missing transaction ID")
        return {
            "statusCode": 400,
            "body": json.dumps({"error": "Missing transaction ID"})
        }
        
    method=''
    if transaction_id:
        res=parse_transaction_method(str(transaction_id))
        if res:
            method = res.get("method", "")
    ledger_description=''
    if status == 'Successful':
        ledger_description = f'''Payment Received - Thank you!
Amount Paid : {amount}  Date : {event_date}'''
    else:
        ledger_description = f'''Payment Failed
Amount : {amount}   Date: {event_date}'''

    batch_list_df=killbill_database.get_data("payment_batch_info",{"id":batch_id},["bill_list"])
    if not batch_list_df.empty:
        bill_list = batch_list_df['bill_list'].tolist()[0]
        bill_list = ast.literal_eval(bill_list) if bill_list else []
    else:
        bill_list = []
    print(f'{bill_list}')
    bill_id_df=killbill_database.get_data('customer_bills',{'id':bill_list},["id","payments","total","amount_due",'remaining'],{'created_date':'asc'}).to_dict(orient="records")
    bill_list_len=len(bill_id_df)
    account_number_df=killbill_database.get_data("customer_bills",{"id":bill_list[0]},["account_number"])
    if account_number_df is not None and not account_number_df.empty:
        account_number = str(account_number_df['account_number'].tolist()[0])
        # print(f'###account_number {account_number}')
    else:
        account_number=''
    if account_number:
        agent_df=killbill_database.get_data("customer_profiles",{"account_number":account_number},["sales_person"])
        sales_person=agent_df['sales_person'].tolist()[0]
        print(f'##sales_personm {sales_person}')
    else:
        sales_person=''
    row_index=0
    amount_paid=float(amount)
    transaction_history_rows=[]
    while (amount_paid>0 and row_index<bill_list_len):
        bill_dict=bill_id_df[row_index]
        if 'id' in bill_dict:
            current_bill_id=bill_dict['id']
        else:
            current_bill_id=''
            continue
        if 'payments' in bill_dict:
            payments = float(bill_dict['payments'])
        else:
            payments=0
        if 'total' in bill_dict:
            total = float(bill_dict['total'])
        else:
            total=0
        if 'amount_due' in bill_dict:
            amount_due = float(bill_dict['amount_due'])
        else:
            amount_due=0
        if 'remaining' in bill_dict:
            remaining = float(bill_dict['remaining'])
        else:
            remaining=0
        if amount_paid>=remaining:
            amount_for_invoice=remaining
            amount_paid=amount_paid-remaining
            payments=payments+remaining
            remaining=0
            amount_due=0
        else:
            amount_for_invoice=amount_paid
            payments=payments+amount_paid
            remaining=remaining-amount_paid
            amount_due=amount_due-amount_paid
            amount_paid=0
        row_index+=1
        updated_data={"payments":str(payments),"total":str(total),"amount_due":str(amount_due),"remaining":str(remaining)}
        transaction_data = {
        "ref": transaction_id,
        "status": status,
        "date": event_date,
        "amount": amount_for_invoice,
        "method": method,
        "source": "Authorize.net",
        "bill_id": str(current_bill_id),
        "auth_code": auth_code,
        "account_number": account_number,
        "agent":sales_person,
        "ledger_description":ledger_description
        }
        transaction_data = {key: str(value) for key, value in transaction_data.items()}
        transaction_history_rows.append(transaction_data)
    try:
        db_status = killbill_database.insert_dict(transaction_history_rows, 'payment_history')
        if db_status:
            print(f'### Success - Webhook processed')
            message = f"Transaction Done Successfully for Bill: {invoice_number}"
            # data={"account_number":account_number,"amount":amount,"bill_id":invoice_number}
            # payments_calculation_data=payments_calculation(data)
            # print(f'---->payments_calculation_data-----{payments_calculation_data}')
            return {"flag": True, "message": message}
        else:
            print(f'### Database Insert Failed')
            {"flag": False, "message": "Database insertion failed"}
    except Exception as db_error:
        print(f"### Database Error: {str(db_error)}")
        message=f'### Database Error: {str(db_error)}'
        return {"flag": False, "message": message}
def tessssst():
    transaction_id = '120059438575'
    amount = '100'
    status = "Successful"
    invoice_number = '14'
    batch_id=invoice_number
    auth_code = 'Q0NEM6'
    event_date = ''
    killbill_database = DB('billing_platform', **db_config)
    batch_list_df=killbill_database.get_data("payment_batch_info",{"id":'15'},["bill_list"])
    if not batch_list_df.empty:
        bill_list = batch_list_df['bill_list'].tolist()[0]
        bill_list = ast.literal_eval(bill_list) if bill_list else []
    else:
        bill_list = []
    print(f'{bill_list}')
    bill_id_df=killbill_database.get_data('customer_bills',{'id':bill_list},["id","payments","total","amount_due",'remaining'],{'created_date':'asc'}).to_dict(orient="records")
    bill_list_len=len(bill_id_df)
    account_number_df=killbill_database.get_data("customer_bills",{"id":bill_list[0]},["account_number"])
    if account_number_df is not None and not account_number_df.empty:
        account_number = str(account_number_df['account_number'].tolist()[0])
        # print(f'###account_number {account_number}')
    else:
        account_number=''
    if account_number:
        agent_df=killbill_database.get_data("customer_profiles",{"account_number":account_number},["sales_person"])
        sales_person=agent_df['sales_person'].tolist()[0]
        print(f'##sales_personm {sales_person}')
    else:
        sales_person=''
    row_index=0
    amount_paid=float(amount)
    transaction_history_rows=[]
    while (amount_paid>0 and row_index<bill_list_len):
        bill_dict=bill_id_df[row_index]
        if 'id' in bill_dict:
            current_bill_id=bill_dict['id']
        else:
            current_bill_id=''
            continue
        if 'payments' in bill_dict:
            payments = float(bill_dict['payments'])
        else:
            payments=0
        if 'total' in bill_dict:
            total = float(bill_dict['total'])
        else:
            total=0
        if 'amount_due' in bill_dict:
            amount_due = float(bill_dict['amount_due'])
        else:
            amount_due=0
        if 'remaining' in bill_dict:
            remaining = float(bill_dict['remaining'])
        else:
            remaining=0
        if amount_paid>=remaining:
            amount_for_invoice=remaining
            amount_paid=amount_paid-remaining
            payments=payments+remaining
            remaining=0
            amount_due=0
        else:
            amount_for_invoice=amount_paid
            payments=payments+amount_paid
            remaining=remaining-amount_paid
            amount_due=amount_due-amount_paid
            amount_paid=0
        row_index+=1
        updated_data={"payments":str(payments),"total":str(total),"amount_due":str(amount_due),"remaining":str(remaining)}
        transaction_data = {
        "ref": transaction_id,
        "status": status,
        "date": '2025-03-18 10:49:56.582168'  ,
        "amount": amount_for_invoice,
        "method": 'XXXX1111',
        "source": "Authorize.net",
        "bill_id": str(current_bill_id),
        "auth_code": auth_code,
        "account_number": account_number,
        "agent":sales_person,
        "ledger_description":'Transaction Success'
        }
        transaction_data = {key: str(value) for key, value in transaction_data.items()}
        print(f'{transaction_data}')
        transaction_history_rows.append(transaction_data)
    print('###transaction_history_rows')
    print(f'{transaction_history_rows}')
    try:
        db_status = killbill_database.insert_dict(transaction_history_rows, 'payment_history')
        print(f'{db_status}')
        if db_status:
            print(f'### Success - Webhook processed')
            message = f"Transaction Done Successfully for Bill: {invoice_number}"
            # data={"account_number":account_number,"amount":amount,"bill_id":invoice_number}
            # payments_calculation_data=payments_calculation(data)
            # print(f'---->payments_calculation_data-----{payments_calculation_data}')
            return {"flag": True, "message": message}
        else:
            print(f'### Database Insert Failed')
            {"flag": False, "message": "Database insertion failed"}
    except Exception as db_error:
        print(f"### Database Error: {str(db_error)}")
        message=f'### Database Error: {str(db_error)}'
        return {"flag": False, "message": message}

# tessssst()
# import time
# def update_transaction_status():
#     """
#     Retrieves and updates the transaction status for a given bill ID from the billing database, 
#     retrying with exponential backoff if not found. Returns a success message if the transaction is successful, 
#     a failure message if unsuccessful, or an error if the bill ID is not found.

#     Args:
#         data (dict): A dictionary containing the following keys:
#             - username (str, optional): The username associated with the transaction. Defaults to an empty string.
#             - table_name (str, optional): The database table to query. Defaults to "payment_history".
#             - bill_id (str): The bill ID for which the transaction status needs to be retrieved.

#     Returns:
#         dict: A dictionary containing:
#             - flag (bool): True if the transaction is successful, False otherwise.
#             - message (str): A descriptive message about the transaction status.
#     """
    
#     # Extract values from the input dictionary
#     table_name = "payment_batch_info"
#     # bill_id = data.get("bill_id", "")
#     batch_id='5'
#     try:
#         # Initialize database connection
#         # killbill_database = DB(os.environ['BILLING_PLATFORM'], **db_config)
#         killbill_database = DB('billing_platform', **db_config)
#     except Exception as e:
#         # print(f"Database connection failed: {e}")
#         print(f"Database connection failed: {e}")
#         return {"flag": False, "message": "Database connection error"}

#     # Define retry parameters
#     retries = 3  # Number of retry attempts
#     delay = 2    # Initial delay in seconds for exponential backoff

#     bill_id_df = None  # Initialize variable to store query result
#     # Retry mechanism to fetch transaction status
#     message='Transaction is Pending'
#     flag=True
#     for attempt in range(retries):
#         try:
#             #Fetch the transaction tratus of a Bill ID
#             batch_id_df = killbill_database.get_data(table_name, {"id": batch_id}, ["batch_id"])
            
            
#             if batch_id_df is not None and not batch_id_df.empty:
#                 # Extract the transaction status if data is found
#                 batch_status = str(batch_id_df['batch_id'].tolist()[0])
#                 print(f'##batch_status{batch_status}')
#                 print(f'type({batch_status})')
#                 if str(batch_status)=='1':
#                     message = "Transaction Successful"
#                     break  # Exit loop if status is found
#                 elif str(batch_status)=='0':
#                     message = "Transaction Failed"
#                     flag=False
#                     break  # Exit loop if status is found
#                 else:
#                     message="Transaction is Pending"
#             else:
#                 # If transaction is not found, retry after a delay
#                 # print(f"Transaction not found, retrying ({attempt+1}/{retries})...")
#                 print(f"Transaction not found, retrying ({attempt+1}/{retries})...")
#                 time.sleep(delay)
#                 delay *= 2  # Exponential backoff (2s -> 4s -> 8s)
#         except Exception as e:
#             # print(f"Error retrieving transaction data (attempt {attempt+1}): {e}")
#             print(f"Error retrieving transaction data (attempt {attempt+1}): {e}")
#             time.sleep(delay)
#             delay *= 2
#     return {'flag':flag,message:message}
# print(update_transaction_status())

# deposit_amount_df=killbill_database.get_data('customer_profiles', {"account_number": account_number},["account_balance"])
# if deposit_amount_df is not None and not deposit_amount_df.empty:
#     account_balance = float(deposit_amount_df['account_balance'].tolist()[0])
# else:
#     account_balance=0
# account_balance=account_balance-amount
# update_account_balance_data={"account_balance":account_balance}
# killbill_database.update_dict('customer_profiles', update_account_balance_data, {"account_number": account_number})


# def authorize_net_webhook_response(event, context): 
#     """
#     Processes webhook events from Authorize.Net, extracting transaction details and updating the payment history 
#     in the billing platform database. The function verifies the event structure, retrieves necessary transaction 
#     details such as ID, amount, invoice number, and authorization code, and associates them with the corresponding 
#     customer account. It then inserts the transaction data into the payment_history table. If the transaction is successful, 
#     a confirmation message is returned; otherwise, an error message is provided.
#     Args:
#     event (dict): The webhook event data containing transaction details.
#     context (dict): Additional context for the function execution.
#     Returns:
#     A dictionary indicating the success or failure of the transaction processing, along with a relevant message.
#     """
#     # Log the full event to verify structure
#     print(f"---> Full event received: {json.dumps(event, indent=2)}")
    
#     # Extract JSON correctly from `event`
#     data = event.get("data")  # Fix: Get "data" instead of "body"
#     # Database object (assuming DB is a custom class)
#     killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)
#     if not data:
#         print('### Missing or empty data in event')
#         return {
#             "statusCode": 400,
#             "body": json.dumps({"error": "Missing or empty data"})
#         }

#     print(f"####Parsed data: {json.dumps(data, indent=2)}")

#     # Ensure the payload exists
#     if "payload" not in data:
#         print('### Invalid data structure')
#         return {
#             "statusCode": 400,
#             "body": json.dumps({"error": "Invalid data structure"})
#         }

#     payload = data["payload"]

#     # Extract required fields safely
#     transaction_id = payload.get("id")  # Correct field from webhook payload
#     amount = payload.get("authAmount")  # Correct field from webhook payload
#     status = "Successful" if payload.get("responseCode") == 1 else "Failed"
#     invoice_number = payload.get("invoiceNumber","")
#     batch_id=str(invoice_number)
#     auth_code = payload.get("authCode", "")
#     event_date = data.get("eventDate","")
#     webhook_id = data.get("webhookId","")

#     # Ensure required fields exist
#     if not transaction_id:
#         print("### Missing transaction ID")
#         return {
#             "statusCode": 400,
#             "body": json.dumps({"error": "Missing transaction ID"})
#         }
        
#     method=''
#     if transaction_id:
#         res=parse_transaction_method(str(transaction_id))
#         if res:
#             method = res.get("method", "")
#     ledger_description=''
#     if status == 'Successful':
#         ledger_description = f'''Payment Received - Thank you!
# Amount Paid : {amount}  Date : {event_date}'''
#     else:
#         ledger_description = f'''Payment Failed
# Amount : {amount}   Date: {event_date}'''

#     batch_list_df=killbill_database.get_data("payment_batch_info",{"id":batch_id},["bill_list"])
#     if not batch_list_df.empty:
#         bill_list = batch_list_df['bill_list'].tolist()[0]
#         bill_list = ast.literal_eval(bill_list) if bill_list else []
#     else:
#         bill_list = []
#     print(f'{bill_list}')
#     # bill_id_df=killbill_database.get_data('customer_bills',{'id':bill_list},["id","payments","total","amount_due",'remaining'],{'created_date':'asc'}).to_dict(orient="records")
#     result = killbill_database.get_data('customer_bills',{'id':bill_list},["id","payments","total","amount_due",'remaining'],{'created_date':'asc'})
#     if isinstance(result, bool) or result is None or result.empty:
#         bill_id_df = []
#     else:
#         bill_id_df = result.to_dict(orient="records")
#     bill_list_len=len(bill_id_df)
#     print(f'#####{bill_id_df}')
#     account_number_df=killbill_database.get_data("customer_bills",{"id":bill_list[0]},["account_number"])
#     if account_number_df is not None and not account_number_df.empty:
#         account_number = str(account_number_df['account_number'].tolist()[0])
#         # print(f'###account_number {account_number}')
#     else:
#         account_number=''
#     if account_number:
#         agent_df=killbill_database.get_data("customer_profiles",{"account_number":account_number},["sales_person"])
#         sales_person=agent_df['sales_person'].tolist()[0]
#         print(f'##sales_personm {sales_person}')
#     else:
#         sales_person=''
#     print(f'##account_number{account_number}')
#     print(f'##sales_personm {sales_person}')
#     deposit_amount_df=killbill_database.get_data('customer_profiles', {"account_number": account_number},["account_balance"])
#     if deposit_amount_df is not None and not deposit_amount_df.empty:
#         account_balance = float(deposit_amount_df['account_balance'].tolist()[0])
#     else:
#         account_balance=0
#     account_balance=account_balance-float(amount)
#     update_account_balance_data={"account_balance":account_balance}
#     killbill_database.update_dict('customer_profiles', update_account_balance_data, {"account_number": account_number})
#     row_index=0
#     amount_paid=float(amount)
#     transaction_history_rows=[]
#     while (amount_paid>0 and row_index<bill_list_len):
#         bill_dict=bill_id_df[row_index]
#         if 'id' in bill_dict:
#             current_bill_id=bill_dict['id']
#         else:
#             current_bill_id=''
#             continue
#         if 'payments' in bill_dict:
#             payments = float(bill_dict['payments'])
#         else:
#             payments=0
#         if 'total' in bill_dict:
#             total = float(bill_dict['total'])
#         else:
#             total=0
#         if 'amount_due' in bill_dict:
#             amount_due = float(bill_dict['amount_due'])
#         else:
#             amount_due=0
#         if 'remaining' in bill_dict:
#             remaining = float(bill_dict['remaining'])
#         else:
#             remaining=0
#         if amount_paid>=remaining:
#             amount_for_invoice=remaining
#             amount_paid=amount_paid-remaining
#             payments=payments+remaining
#             remaining=0
#             amount_due=0
#         else:
#             amount_for_invoice=amount_paid
#             payments=payments+amount_paid
#             remaining=remaining-amount_paid
#             amount_due=amount_due-amount_paid
#             amount_paid=0
#         row_index+=1
#         updated_data={"payments":str(payments),"total":str(total),"amount_due":str(amount_due),"remaining":str(remaining)}
#         update_status=killbill_database.update_dict('customer_bills', updated_data, {"id": current_bill_id})
#         transaction_data = {
#         "ref": transaction_id,
#         "status": status,
#         "date": event_date,
#         "amount": amount_for_invoice,
#         "method": method,
#         "source": "Authorize.net",
#         "bill_id": str(current_bill_id),
#         "auth_code": auth_code,
#         "account_number": account_number,
#         "agent":sales_person,
#         "ledger_description":ledger_description
#         }
#         transaction_data = {key: str(value) for key, value in transaction_data.items()}
#         transaction_history_rows.append(transaction_data)
#     print(f'#####transaction_history_rows{transaction_history_rows}')
#     try:
#         db_status = killbill_database.insert_dict(transaction_history_rows, 'payment_history')
#         if db_status:
#             print(f'### Success - Webhook processed')
#             message = f"Transaction Done Successfully for Bill: {invoice_number}"
#             # data={"account_number":account_number,"amount":amount,"bill_id":invoice_number}
#             # payments_calculation_data=payments_calculation(data)
#             # print(f'---->payments_calculation_data-----{payments_calculation_data}')
#             return {"flag": True, "message": message}
#         else:
#             print(f'### Database Insert Failed')
#             {"flag": False, "message": "Database insertion failed"}
#     except Exception as db_error:
#         print(f"### Database Error: {str(db_error)}")
#         message=f'### Database Error: {str(db_error)}'
#         return {"flag": False, "message": message}

# import time
# def update_transaction_status(data):
#     """
#     Retrieves and updates the transaction status for a given bill ID from the billing database, 
#     retrying with exponential backoff if not found. Returns a success message if the transaction is successful, 
#     a failure message if unsuccessful, or an error if the bill ID is not found.

#     Args:
#         data (dict): A dictionary containing the following keys:
#             - username (str, optional): The username associated with the transaction. Defaults to an empty string.
#             - table_name (str, optional): The database table to query. Defaults to "payment_history".
#             - bill_id (str): The bill ID for which the transaction status needs to be retrieved.

#     Returns:
#         dict: A dictionary containing:
#             - flag (bool): True if the transaction is successful, False otherwise.
#             - message (str): A descriptive message about the transaction status.
#     """
    
#     # Extract values from the input dictionary
#     username = data.get("username", "")
#     table_name = "payment_batch_info"
#     batch_id = data.get("batch_id", "")
#     if not batch_id:
#         return {"flag": False, "message": "Batch ID is Empty"}
#     try:
#         # Initialize database connection
#         killbill_database = DB('billing_platform', **db_config)
#     except Exception as e:
#         print(f"Database connection failed: {e}")
#         return {"flag": False, "message": "Database connection error"}

#     # Define retry parameters
#     retries = 3  # Number of retry attempts
#     delay = 2    # Initial delay in seconds for exponential backoff

#     bill_id_df = None  # Initialize variable to store query result
#     message='Transaction is Pending'
#     flag=True
#     # Retry mechanism to fetch transaction status
#     for attempt in range(retries):
#         try:
#             #Fetch the transaction tratus of a Bill ID
#             batch_id_df = killbill_database.get_data(table_name, {"id": batch_id}, ["batch_id"])
#             if batch_id_df is not None and not batch_id_df.empty:
#                 # Extract the transaction status if data is found
#                 batch_status = str(batch_id_df['batch_id'].tolist()[0])
#                 print(f'##batch_status attempt {attempt+1}: {batch_status}')
#                 if str(batch_status)=='1':
#                     message = "Transaction Successful"
#                     break  # Exit loop if status is found
#                 elif str(batch_status)=='0':
#                     message = "Transaction Failed"
#                     flag=False
#                     break  # Exit loop if status is found
#                 else:
#                     message="Transaction is Pending"
#             else:
#                 # If transaction is not found, retry after a delay
#                 print(f"Transaction not found, retrying ({attempt+1}/{retries})...")
#                 time.sleep(delay)
#                 delay *= 2  # Exponential backoff (2s -> 4s -> 8s)
#         except Exception as e:
#             print(f"Error retrieving transaction data (attempt {attempt+1}): {e}")
#             time.sleep(delay)
#             delay *= 2
#     return {'flag':flag,message:message}

# data={
#   "tenant_name": "Altaworx Test",
#   "username": "superadmin",
#   "firstLastName": "super admin",
#   "path": "/update_transaction_status",
#   "role_name": "Super Admin",
#   "parent_module": "Billing Platform",
#   "module_name": "Payment History",
#   "mod_pages": {
#     "start": 0,
#     "end": 100
#   },
#   "account_number": "3000005505",
#   "bill_id": '',
#   "batch_id": "37",
#   "request_received_at": "2025-03-19 12:45:58.803",
#   "Partner": "Altaworx Test",
#   "access_token": "null",
#   "db_name": "billing_platform",
#   "sessionID": '',
#   "feature_module_name": "Payment History",
#   "table_name": "payment_history"
# }
# print(update_transaction_status(data))







# def authorize_net_webhook_response(event, context): 
#     """
#     Processes webhook events from Authorize.Net, extracting transaction details and updating the payment history 
#     in the billing platform database. The function verifies the event structure, retrieves necessary transaction 
#     details such as ID, amount, invoice number, and authorization code, and associates them with the corresponding 
#     customer account. It then inserts the transaction data into the payment_history table. If the transaction is successful, 
#     a confirmation message is returned; otherwise, an error message is provided.
#     Args:
#     event (dict): The webhook event data containing transaction details.
#     context (dict): Additional context for the function execution.
#     Returns:
#     A dictionary indicating the success or failure of the transaction processing, along with a relevant message.
#     """
#     # Log the full event to verify structure
#     print(f"---> Full event received: {json.dumps(event, indent=2)}")
    
#     # Extract JSON correctly from `event`
#     data = event.get("data")  # Fix: Get "data" instead of "body"
#     # Database object (assuming DB is a custom class)
#     killbill_database =  DB(os.environ['BILLING_PLATFORM'], **db_config)
#     if not data:
#         print('### Missing or empty data in event')
#         return {
#             "statusCode": 400,
#             "body": json.dumps({"error": "Missing or empty data"})
#         }

#     print(f"####Parsed data: {json.dumps(data, indent=2)}")

#     # Ensure the payload exists
#     if "payload" not in data:
#         print('### Invalid data structure')
#         return {
#             "statusCode": 400,
#             "body": json.dumps({"error": "Invalid data structure"})
#         }

#     payload = data["payload"]

#     # Extract required fields safely
#     transaction_id = payload.get("id")  # Correct field from webhook payload
#     amount = payload.get("authAmount")  # Correct field from webhook payload
#     status = "Successful" if payload.get("responseCode") == 1 else "Failed"
#     invoice_number = payload.get("invoiceNumber","")
#     batch_id=str(invoice_number)
#     auth_code = payload.get("authCode", "")
#     event_date = data.get("eventDate","")
#     webhook_id = data.get("webhookId","")

#     # Ensure required fields exist
#     if not transaction_id:
#         print("### Missing transaction ID")
#         return {
#             "statusCode": 400,
#             "body": json.dumps({"error": "Missing transaction ID"})
#         }
        
#     method=''
#     if transaction_id:
#         res=parse_transaction_method(str(transaction_id))
#         if res:
#             method = res.get("method", "")
#     ledger_description=''
#     batch_list_df=killbill_database.get_data("payment_batch_info",{"id":batch_id},["bill_list"])
#     if not batch_list_df.empty:
#         bill_list = batch_list_df['bill_list'].tolist()[0]
#         bill_list = ast.literal_eval(bill_list) if bill_list else []
#     else:
#         bill_list = []
#     print(f'{bill_list}')
#     # bill_id_df=killbill_database.get_data('customer_bills',{'id':bill_list},["id","payments","total","amount_due",'remaining'],{'created_date':'asc'}).to_dict(orient="records")
#     result = killbill_database.get_data('customer_bills',{'id':bill_list},["id","payments","total","amount_due",'remaining'],{'created_date':'asc'})
#     if isinstance(result, bool) or result is None or result.empty:
#         bill_id_df = []
#     else:
#         bill_id_df = result.to_dict(orient="records")
#     bill_list_len=len(bill_id_df)
#     print(f'#####{bill_id_df}')
#     account_number_df=killbill_database.get_data("customer_bills",{"id":bill_list[0]},["account_number"])
#     if account_number_df is not None and not account_number_df.empty:
#         account_number = str(account_number_df['account_number'].tolist()[0])
#         # print(f'###account_number {account_number}')
#     else:
#         account_number=''
#     if account_number:
#         agent_df=killbill_database.get_data("customer_profiles",{"account_number":account_number},["sales_person"])
#         sales_person=agent_df['sales_person'].tolist()[0]
#         print(f'##sales_personm {sales_person}')
#     else:
#         sales_person=''
#     print(f'##account_number{account_number}')
#     print(f'##sales_personm {sales_person}')
#     if status=='Failed':
#         ledger_description = f'''Payment Failed
# Amount : {amount}   Date: {event_date}'''
#         batch_updated_data={"batch_id":'0'}
#         batch_update_status=killbill_database.update_dict('payment_batch_info', batch_updated_data, {"id": str(invoice_number)})
#         print(f'###batch_update_status{batch_update_status}')
#         transaction_history_rows=[]
#         for bill_dict in bill_id_df:
#             if 'id' in bill_dict:
#                 current_bill_id=bill_dict['id']
#             else:
#                 current_bill_id=''
#             transaction_data = {
#             "ref": transaction_id,
#             "status": status,
#             "date": event_date,
#             "amount": str(amount),
#             "method": method,
#             "source": "Authorize.net",
#             "bill_id": str(current_bill_id),
#             "auth_code": auth_code,
#             "account_number": account_number,
#             "agent":sales_person,
#             "ledger_description":ledger_description
#             }
#             transaction_data = {key: str(value) for key, value in transaction_data.items()}
#             transaction_history_rows.append(transaction_data)
#         print(f'#####transaction_history_rows{transaction_history_rows}')
#         try:
#             db_status = killbill_database.insert_dict(transaction_history_rows, 'payment_history')
#             if db_status:
#                 print(f'### Success - Webhook processed')
#                 message = f"Transaction Failed for Batch ID: {invoice_number}"
#                 # data={"account_number":account_number,"amount":amount,"bill_id":invoice_number}
#                 # payments_calculation_data=payments_calculation(data)
#                 # print(f'---->payments_calculation_data-----{payments_calculation_data}')
#                 return {"flag": True, "message": message}
#             else:
#                 print(f'### Database Insert Failed')
#                 {"flag": False, "message": "Database insertion failed"}
#         except Exception as db_error:
#             print(f"### Database Error: {str(db_error)}")
#             message=f'### Database Error: {str(db_error)}'
#             return {"flag": False, "message": message}
#     deposit_amount_df=killbill_database.get_data('customer_profiles', {"account_number": account_number},["account_balance"])
#     if deposit_amount_df is not None and not deposit_amount_df.empty:
#         account_balance = float(deposit_amount_df['account_balance'].tolist()[0])
#     else:
#         account_balance=0
#     account_balance=account_balance-float(amount)
#     update_account_balance_data={"account_balance":account_balance}
#     killbill_database.update_dict('customer_profiles', update_account_balance_data, {"account_number": account_number})
#     row_index=0
#     amount_paid=float(amount)
#     transaction_history_rows=[]
#     while (amount_paid>0 and row_index<bill_list_len):
#         bill_dict=bill_id_df[row_index]
#         if 'id' in bill_dict:
#             current_bill_id=bill_dict['id']
#         else:
#             current_bill_id=''
#             continue
#         if 'payments' in bill_dict:
#             payments = float(bill_dict['payments'])
#         else:
#             payments=0
#         if 'total' in bill_dict:
#             total = float(bill_dict['total'])
#         else:
#             total=0
#         if 'amount_due' in bill_dict:
#             amount_due = float(bill_dict['amount_due'])
#         else:
#             amount_due=0
#         if 'remaining' in bill_dict:
#             remaining = float(bill_dict['remaining'])
#         else:
#             remaining=0
#         if amount_paid>=remaining:
#             amount_for_invoice=remaining
#             amount_paid=amount_paid-remaining
#             payments=payments+remaining
#             remaining=0
#             amount_due=0
#         else:
#             amount_for_invoice=amount_paid
#             payments=payments+amount_paid
#             remaining=remaining-amount_paid
#             amount_due=amount_due-amount_paid
#             amount_paid=0
#         row_index+=1
#         updated_data={"payments":str(payments),"total":str(total),"amount_due":str(amount_due),"remaining":str(remaining)}
#         update_status=killbill_database.update_dict('customer_bills', updated_data, {"id": current_bill_id})
#         ledger_description = f'''Payment Received - Thank you!
# Amount Paid : {amount_for_invoice}  Date : {event_date}'''
#         transaction_data = {
#         "ref": transaction_id,
#         "status": status,
#         "date": event_date,
#         "amount": amount_for_invoice,
#         "method": method,
#         "source": "Authorize.net",
#         "bill_id": str(current_bill_id),
#         "auth_code": auth_code,
#         "account_number": account_number,
#         "agent":sales_person,
#         "ledger_description":ledger_description
#         }
#         transaction_data = {key: str(value) for key, value in transaction_data.items()}
#         transaction_history_rows.append(transaction_data)
#     print(f'#####transaction_history_rows{transaction_history_rows}')
#     batch_updated_data={"batch_id":'1'}
#     batch_update_status=killbill_database.update_dict('payment_batch_info', batch_updated_data, {"id": str(invoice_number)})
#     print(f'###batch_update_status{batch_update_status}')
#     try:
#         db_status = killbill_database.insert_dict(transaction_history_rows, 'payment_history')
#         if db_status:
#             print(f'### Success - Webhook processed')
#             message = f"Transaction Done Successfully for Bill: {invoice_number}"
#             # data={"account_number":account_number,"amount":amount,"bill_id":invoice_number}
#             # payments_calculation_data=payments_calculation(data)
#             # print(f'---->payments_calculation_data-----{payments_calculation_data}')
#             return {"flag": True, "message": message}
#         else:
#             print(f'### Database Insert Failed')
#             {"flag": False, "message": "Database insertion failed"}
#     except Exception as db_error:
#         print(f"### Database Error: {str(db_error)}")
#         message=f'### Database Error: {str(db_error)}'
#         return {"flag": False, "message": message}


# def create_new_collection(data):
#     """
#     Inserts a new collection step and its associated template into the database while logging the action.
#     """
#     database = DB('billing_platform_common_utils', **db_config)
#     killbill_database = DB('billing_platform', **db_config)

#     tenant_database = data.get('db_name', 'altaworx_central')
#     step_table_name = data.get('step_table_name', 'collection_steps')
#     template_table_name = data.get('template_table_name', 'collection_templates')
#     module_name = data.get('module_name', 'Collections Steps')
#     created_by = data.get('username', '')
#     modified_by = data.get('username', '')
#     modified_date = data.get('request_received_at', '')
#     Partner = data.get("Partner", "")
#     username = data.get("username", "")
#     session_id = data.get("session_id", "")
#     role_name = data.get('role_name', '')
#     tenant_name = data.get('tenant_name', '')
#     changed_data = data.get('changed_data', {})
#     # step_changed_data = data.get('changed_data', {}).copy()  # Use copy to avoid modifying the original dict
#     step_changed_data=changed_data.get('stepsData','')
#     print(f'step_changed_data--------{step_changed_data}')
#     if "stepsData" in changed_data:
#         changed_data.pop('stepsData','')
#     template_change_data = {}

#     # Move specific keys to the template data
#     if 'template_description' in changed_data:
#         template_change_data['template_description'] = changed_data.pop('template_description')
#     if 'balance_limit' in changed_data:
#         template_change_data['balance_limit'] = changed_data.pop('balance_limit')

#     template_change_data['created_by'] = created_by
#     template_change_data['modified_by'] = modified_by

#     # step_changed_data = {k: str(v) for k, v in step_changed_data.items() if v not in (None, "None", "")}
#     print(f'##after step_changed_data {step_changed_data}')
#     template_change_data = {k: str(v) for k, v in template_change_data.items() if v not in (None, "None", "")}
#     print(f'##after template_change_data {template_change_data}')
#     conn = psycopg2.connect(
#             dbname='billing_platform',
#             user='root',
#             password='AmopTeam123',
#             host='amoppostoct19.c3qae66ke1lg.us-east-1.rds.amazonaws.com',
#             port='5432'
#         )
#     cur = conn.cursor()

#     # Insert into collection_templates and return the template ID
#     insert_template_query = f"""
#         INSERT INTO {template_table_name} (template_description, balance_limit, created_by, modified_by) 
#         VALUES (%s, %s, %s, %s) RETURNING id;
#     """
#     cur.execute(insert_template_query, (
#         template_change_data.get('template_description', ''),
#         template_change_data.get('balance_limit', 0),
#         template_change_data.get('created_by', ''),
#         template_change_data.get('modified_by', '')
#     ))
#     template_id = cur.fetchone()[0]  # Fetch the returned ID
#     if template_id:
#         print(f'####template_id {template_id}')
#         print(f'type-------{type(template_id)}')
#         # Iterate through each step and add template_id
#         for step in step_changed_data:
#             step['template_id'] = template_id
#     else:
#         return {'flag':False,"message":"Template Id Empty"}
#     print(f'####step_changed_data2 {step_changed_data}')
    
#     conn.commit()
#     cur.close()
#     conn.close()
#     print(f'Fetched template_id: {template_id}, Type: {type(template_id)}')
#     status=killbill_database.insert_data(step_changed_data, step_table_name)
#     if status:
#         response = {
#             "flag": True,
#             "message": "Successfully added a Step"
#         }
#     else:
#         response = {
#             "flag": False,
#             "message": "Error Adding a Step"
#         }

#     return response

# data={

#   "tenant_name": "Altaworx Test",

#   "username": "superadmin",

#   "firstLastName": "super admin",

#   "path": "/create_new_collection",

#   "role_name": "Super Admin",

#   "module_name": "Collection Steps",

#   "feature_module_name": "Billing Platform",

#   "Partner": "Altaworx Test",

#   "access_token": "null",

#   "db_name": "billing_platform",

#   "template_table_name": "collection_templates",

#   "step_table_name": "collection_steps",

#   "request_received_at": "2025-03-19 15:42:37.488",

#   "sessionID": '',

#   "action": "create",

#   "modified_by": "super admin",

#   "changed_data": {

#     "step_type": "Letter",

#     "template_description": "collection test",

#     "balance_limit": "1000",

#     "stepsData": [

#       {

#         "step_description": "Step 1 ",

#         "step_type": "Letter",

#         "grace_period": "10",

#         "display_option": "",

#         "copy_to_ftp": "",

#         "day": "10"

#       },

#       {

#         "step_description": "Letter test 123",

#         "step_type": "Letter",

#         "grace_period": "10",

#         "display_option": "",

#         "copy_to_ftp": "",

#         "day": "20"

#       }

#     ]

#   }

# }
 
# print(create_new_collection(data))


# def tessssst():
#     killbill_database = DB('billing_platform', **db_config)
#     collection_step = killbill_database.get_data("collection_templates", None, ["template_description", "id"])

#     collection_step_list_ = collection_step["template_description"].to_list()
#     collection_step_id_list = collection_step["id"].to_list()

#     # Filter out unwanted values (None, "", "null")
#     filtered_steps = [
#         (desc, step_id) for desc, step_id in zip(collection_step_list_, collection_step_id_list)
#         if desc and desc.lower() != "null"
#     ]

#     # Unzipping filtered data
#     filtered_collection_step_list, filtered_collection_step_id_list = zip(*filtered_steps) if filtered_steps else ([], [])

#     # Creating and sorting dictionary
#     steps_data = dict(zip(filtered_collection_step_list, filtered_collection_step_id_list))
#     sorted_step_data = dict(sorted(steps_data.items(), key=lambda item: item[0].lower()))  # Case-insensitive sorting

#     print(sorted_step_data)

# tessssst()

def tesssst():
    killbill_database =  DB("billing_platform" ,**db_config)
    # df_dict= killbill_database.get_data(
    #     table_name='collection_steps',
    #     condition={"is_deleted": "false","template_id":"21"},
    #     columns=None
    # ).to_dict(orient="records")
    # return df_dict
    customer_profiles_data = killbill_database.get_data(
            "customer_profiles",
            None,
            ["account_number", "collection_step"]
        )
    filtered_data = customer_profiles_data[customer_profiles_data['collection_step'].notnull()]
    # Get account numbers from the filtered data
    collection_steps = filtered_data['collection_step'].tolist()
    account_numbers = filtered_data['account_number'].tolist()
    zipped_dict = dict(zip(account_numbers, collection_steps))
    final_zipped_list = []
    print("Unique Collection Steps:", collection_steps)
    print("Account Numbers:", account_numbers)
    print(f'zipped_list--------{zipped_dict}')
    all_steps_data={}
    # all_steps_data_dict = killbill_database.get_data(
    #         "collection_templates",
    #         [collection_steps],
    #         ["account_number", "collection_step"]
    #     ).to_dict(orient="records")
    # if all_steps_data_dict:
    #     all_steps_data=all_steps_data_dict
    print(all_steps_data)
print(tesssst())
# def collection_steps_list_view(data):
#     """
#     Retrieves a list of customer profiles for display, including pagination, filtering, and dropdown options.

#     Args:
#         data (dict): A dictionary containing:
#             - db_name (str): Tenant database name (default: 'altaworx_central').
#             - role_name (str): User's role for permissions.
#             - tenant_name (str): Tenant name for fetching timezone.
#             - mod_pages (dict): Pagination details {start, end}.
#             - col_sort (dict, optional): Sorting preferences.

#     Returns:
#         dict: Response structure:
#             - flag (bool): Success/failure status.
#             - message (str): Success/error message.
#             - data (dict): Customer profiles with pagination.
#             - header_map (dict): Mapped headers for UI display.
#             - dropdown (dict): Dropdown values for filters.
#             - pages (dict): Pagination details.
#     """
#     # Database connections
#     database = DB("billing_platform_common_utils", **db_config)
#     killbill_database =  DB("billing_platform" ,**db_config)
    
#     # Extract relevant details from the input data dictionary
#     table_name = data.get('table_name','collection_steps')
#     role_name = data.get('role_name', '')
#     tenant_name =data.get('tenant_name','')
#     module_name=data.get('module_name', '')
#     template_id=data.get('template_id','')
#     account_number=data.get('account_number','')
#     # Get tenant's timezone
#     tenant_name = data.get('tenant_name', '')
#     tenant_timezone_query = """SELECT time_zone FROM tenant WHERE tenant_name = %s"""
#     tenant_timezone = database.execute_query(tenant_timezone_query, params=[tenant_name])

#         # Ensure timezone is valid
#     if tenant_timezone.empty or tenant_timezone.iloc[0]['time_zone'] is None:
#             raise ValueError("No valid timezone found for tenant.")

#     tenant_time_zone = tenant_timezone.iloc[0]['time_zone']
#     match = re.search(r'\(\w+\s[+\-]?\d{2}:\d{2}:\d{2}\)\s*(Asia\s*/\s*Kolkata)', tenant_time_zone)
#     if match:
#         tenant_time_zone = match.group(1).replace(' ', '')  # Ensure it's formatted correctly

#     # Fetch paginated customer profiles from the database
#     df_dict= killbill_database.get_data(
#         table_name=table_name,
#         condition={"account_number": account_number},
#         columns=['steps_data']
#     )['steps_data'].to_list()

#     tenant_id = database.get_data(
#             table_name=table_name, {"tenant_name": tenant_name}["id"]
#         )["id"].to_list()[0]
    
#     data_dict_all={}
#     if df_dict:
#         data_dict_all=df_dict[0]
#     # Convert timestamps to the tenant's timezone
#     df_dict = convert_timestamp(df_dict, tenant_time_zone)
#     # print('####df_dict',df_dict)
#     add_a_step=['Letter','Email','Phone Call','Text Message (SMS)','2-Way Suspend','1-Way Suspend','Block LD','Disconnect','Manual Step']
#     # Compile dropdown options
#     collection_steps={
#         "step_type":add_a_step
#     }
#     try:
#         # Fetch mapped headers
#         header_map = get_headers_mapping(killbill_database,[module_name],role_name, '', '', '', '',data)

#         # Serialize customer profiles
#         data_dict_all = {"collection_steps": serialize_data(df_dict)}
#         print(f'###data_dict_all {data_dict_all}')

#          # Construct success response
#         response = {
#             "flag": True,
#             "message": "Data fetched successfully",
#             "data": data_dict_all,
#             "header_map": header_map,
#             "dropdown":collection_steps
#         }
#         return response

#     except Exception as e:
#         print(f"Exception occurred: {e}")

#         # Construct error response
#         response = {
#             "flag": False,
#             "message": "Something went wrong fetching Collections list",
#             "data": {}  # Return empty dictionary on error
#         }
#         return response
# data={
#   "tenant_name": "Altaworx Test",
#   "username": "superadmin",
#   "firstLastName": "super admin",
#   "path": "/collection_steps_list_view",
#   "account_number": "300009797",
#   "role_name": "Super Admin",
#   "parent_module": "Billing Platform",
#   "module_name": "Basic Details Collection Steps",
#   "table_name": "customer_profiles",
#   "flag": "fetch",
#   "request_received_at": "2025-03-25 17:13:34.714",
#   "Partner": "Altaworx Test",
#   "access_token": "null",
#   "db_name": "billing_platform",
#   "template_id": 85,
#   "sessionID": "null",
#   "feature_module_name": "Basic Details Collection Steps"
# }
# print(collection_steps_list_view(data))

