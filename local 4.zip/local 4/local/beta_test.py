"""
@Author1 : Phaneendra.Y
@Author2 : Nikhil .N
@Author3 : Vyshnavi
Created Date: 01-11-24
"""


import re
import os
import time
import json
import psycopg2
import datetime
import base64
import pandas as pd
from psycopg2 import sql
from pytz import timezone
from common_utils.db_utils import DB
# from common_utils.email_trigger import send_email
# from common_utils.permission_manager import PermissionManager
# from common_utils.timezone_conversion import fetch_tenant_timezone
import io
import base64


# common_utils db_config from environment
common_utils_database_config = {
        "host": "amopuatpostgresoct23.c3qae66ke1lg.us-east-1.rds.amazonaws.com",
        "port": "5432",
        "user": "root",
        "password": "AmopTeam123",
        "multi_schema":False
    }

def db_config_maker(user,db_config_making):
    """
    Generates and updates a database configuration dictionary with user-specific access filters.

    This function retrieves the list of customers and service providers associated with the given user
    from the 'users' table in the database. It then updates the provided db_config_making dictionary
    with these values under the keys 'customers' and 'service_providers'.

    Args:
        user (str): The username for which to fetch access filters.
        db_config_making (dict): The base database configuration dictionary to update.

    Returns:
        dict: The updated db_config_making dictionary with user-specific access filters.
    """

    common_utils_database = DB('common_utils', **common_utils_database_config)

    query=f"select customers,service_provider from users where username ='{user}'"
    filters=common_utils_database.execute_query(query,True)
    try:
        customer=tuple(json.loads(filters['customers'].to_list()[0]))
    except Exception as e:
        print(f"### db_config_maker customer exception : {e}")
        customer=None
    try:
        service_provider=tuple(json.loads(filters['service_provider'].to_list()[0]))
    except Exception as e:
        print(f"### db_config_maker service_provider exception : {e}")
        service_provider=None

    db_config_making["customers"]= customer
    db_config_making["service_providers"]=service_provider

    return db_config_making

def update_group_table(database,table_name,group_column,item_column,group_id,new_ids,created_by = None):
    """
    Updates a group mapping table by deactivating existing links and inserting/updating new ones.

    This function performs a full refresh of the item mappings for a given group:
    - Deactivates all existing records (marks as deleted).
    - Inserts new records for IDs not previously present.
    - Reactivates existing records for IDs already present.

    Args:
        database: Database connection object with required query methods.
        table_name (str): Name of the group mapping table to update.
        group_column (str): Column name representing the group identifier (e.g., group_id).
        item_column (str): Column name representing the individual items linked to the group.
        group_id (str): Identifier of the group whose mappings are to be updated.
        new_ids (list): List of new item IDs to be associated with the group.

    Returns:
        None: Function returns nothing. Logs errors if exceptions occur.

    """
    try:
        if not group_id or not new_ids:
            return
        existing_df = database.get_data(table_name, {group_column: group_id}, [item_column])
        existing_ids = set(existing_df[item_column].to_list())

        # Disable all existing links
        database.update_dict(table_name,{"is_active": False, "is_deleted": True}, {group_column: group_id})
        new_ids_set = set(new_ids)
        to_insert = new_ids_set - existing_ids
        to_update = new_ids_set & existing_ids

        #insert new reocrds
        if to_insert:
            insert_data = [
                {
                    group_column: group_id,
                    item_column: item_id,
                    "is_active": True,
                    "is_deleted": False
                } for item_id in to_insert
            ]
            # if  table is notification_rule_recipient the add created_by to insert data
            if table_name == "notification_rule_recipient":
                for data in insert_data:
                    data["created_by"] = created_by
            database.insert_data(insert_data, table_name)
        #update existing records
        if to_update:
            database.update_dict(
                table_name,
                {"is_active":True, "is_deleted":False},
                and_conditions={group_column: group_id},
                in_conditions={item_column: list(to_update)}
            )
    except Exception as e:
        print(f"### update_group_table Exception is : {e}")
        return

def bulk_upload_customer_groups(
    uploaded_file_blob,
    username,
    created_date,
    tenant_id,
    table_name,
    database,
    session_id=None,
    request_received_at=None,
):
    """
    Handle bulk upload for Customer Groups module.
    Expects `uploaded_dataframe` already loaded from Excel (before generic column checks).
    Adds auditing of user actions and error logging.
    """
    start_time = time.time()
    try:
        common_utils_database = DB('common_utils', **common_utils_database_config)
        try:
            # If UI sends base64 string, decode it
            if isinstance(uploaded_file_blob, str):
                uploaded_file_blob = base64.b64decode(uploaded_file_blob)

            # Read the Excel file
            excel_buffer = BytesIO(uploaded_file_blob)
            uploaded_dataframe = pd.read_excel(excel_buffer, dtype=str)

        except Exception as e:
            response = {"flag": False, "message": f"Failed to read uploaded Excel file: {str(e)}"}
            raise Exception(response["message"])

        # --------------------------
        # Normalization & preparation
        # --------------------------
        uploaded_dataframe.columns = uploaded_dataframe.columns.str.replace(" ", "_").str.lower()

        if "tenant_name" not in uploaded_dataframe.columns and "tenant" in uploaded_dataframe.columns:
            uploaded_dataframe = uploaded_dataframe.rename(columns={"tenant": "tenant_name"})

        uploaded_dataframe["created_by"] = username
        uploaded_dataframe["modified_by"] = username
        uploaded_dataframe["modified_date"] = created_date
        uploaded_dataframe["is_active"] = True
        uploaded_dataframe["is_deleted"] = False
        uploaded_dataframe["deleted_by"] = ""
        uploaded_dataframe["deleted_date"] = created_date
        uploaded_dataframe["created_date"] = created_date
        uploaded_dataframe["id_10"] = None
        uploaded_dataframe["tenant_id"] = tenant_id
        uploaded_dataframe["enable_private_networks"] = False

        # Multi-value columns
        multi_value_columns = ["rate_plan_name", "feature_codes", "customer_names", "child_account", "notification_rules", "tenant_name"]

        def clean_and_process_value(value):
            if pd.isna(value) or str(value).strip() == "":
                return None
            value_str = str(value).strip().replace("\n", ",")
            items = [item.strip() for item in value_str.split(",") if item.strip()]
            if not items:
                return None
            if len(items) == 1:
                return items[0]
            return json.dumps(items)

        for column in multi_value_columns:
            if column in uploaded_dataframe.columns:
                uploaded_dataframe[column] = uploaded_dataframe[column].apply(clean_and_process_value)
            else:
                uploaded_dataframe[column] = None

        if "billing_account_number" in uploaded_dataframe.columns:
            uploaded_dataframe["billing_account_number"] = uploaded_dataframe["billing_account_number"].apply(
                lambda x: str(x).strip() if pd.notna(x) and str(x).strip() != "" else None
            )

        # Private networks
        private_networks_list = []
        for _, row in uploaded_dataframe.iterrows():
            private_network_entry = {}
            for col, key in [("service_provider", "service_provider"), ("apn", "apn"), ("pdp", "pdp"),
                             ("ip_range", "ip_text"), ("ip_version", "ip_version")]:
                if col in row and pd.notna(row.get(col)) and str(row[col]).strip() != "":
                    private_network_entry[key] = str(row[col]).strip()
            if private_network_entry:
                private_networks_list.append([private_network_entry])
            else:
                private_networks_list.append([])
        uploaded_dataframe["private_networks_json"] = [json.dumps(networks) for networks in private_networks_list]

        for index, row in uploaded_dataframe.iterrows():
            if pd.notna(row.get("private_networks_json")) and row["private_networks_json"] not in ["", "[]"]:
                uploaded_dataframe.at[index, "enable_private_networks"] = True

        # Merge rows with same name
        def merge_same_name_rows(df):
            if len(df) <= 1:
                return df
            merged_rows = []
            for name, group in df.groupby("name"):
                if len(group) == 1:
                    merged_rows.append(group.iloc[0])
                else:
                    first_row = group.iloc[0].copy()
                    all_networks = []
                    for _, row in group.iterrows():
                        if pd.notna(row.get("private_networks_json")) and row["private_networks_json"].strip() != "":
                            try:
                                networks = json.loads(row["private_networks_json"])
                                if isinstance(networks, list):
                                    for network in networks:
                                        if network and network not in all_networks:
                                            all_networks.append(network)
                            except Exception as e:
                                print(f"Error merging private networks: {e}")
                    first_row["private_networks_json"] = json.dumps(all_networks) if all_networks else json.dumps([])
                    if all_networks:
                        first_row["enable_private_networks"] = True
                    merged_rows.append(first_row)
            return pd.DataFrame(merged_rows)
        print(f"## bulk_upload_customer_groups before merge uploaded_dataframe {uploaded_dataframe}")
        uploaded_dataframe = merge_same_name_rows(uploaded_dataframe)
        print(f"## bulk_upload_customer_groups after merge uploaded_dataframe {uploaded_dataframe}")

        # Required column check
        required_columns_with_values = ["name"]
        columns_with_missing_values = []
        for col in required_columns_with_values:
            null_mask = uploaded_dataframe[col].isnull() | (uploaded_dataframe[col].astype(str).str.strip() == "") | (uploaded_dataframe[col].astype(str).str.strip().str.lower() == "na")
            if null_mask.any():
                columns_with_missing_values.append(col)
        if columns_with_missing_values:
            response = {"flag": False, "message": "Empty values found in required column(s): " + ", ".join(columns_with_missing_values)}
            raise Exception(response["message"])

        # DB duplicate check
        existing_groups_df = database.get_data(table_name, {"tenant_id": tenant_id, "is_active": True}, ["name"])
        print(f"## bulk_upload_customer_groups existing_groups_df {existing_groups_df}")
        if existing_groups_df is not None and not existing_groups_df.empty:
            existing_names = set(existing_groups_df["name"].astype(str).str.strip().str.lower())
            uploaded_names = set(uploaded_dataframe["name"].astype(str).str.strip().str.lower())
            duplicate_names = existing_names.intersection(uploaded_names)
            if duplicate_names:
                dup_list = list(duplicate_names)
                print(f"## bulk_upload_customer_groups dup_list {dup_list}")
                response = {"flag": False, "message": "Customer group name(s) already exist in database: " + ", ".join(dup_list[:5]) + ("..." if len(dup_list) > 5 else "")}
                raise Exception(response["message"])

        # Drop private network source columns
        private_network_columns = ["service_provider", "apn", "pdp", "ip_range", "ip_version"]
        uploaded_dataframe = uploaded_dataframe.drop(columns=[c for c in private_network_columns if c in uploaded_dataframe.columns])

        # Insert into DB
        records = uploaded_dataframe.to_dict(orient="records")
        print(f"## bulk_upload_customer_groups inserting records {records}")
        inserted_ids = database.insert_data(records, table_name)

        response_data = []
        if inserted_ids:
            print(f"## bulk_upload_customer_groups inserted_ids {inserted_ids}")
            if isinstance(inserted_ids, list):
                inserted_groups = database.get_data(table_name, {"id": inserted_ids}, [
                    "id","name","tenant_name","child_account","billing_account_number","rate_plan_name",
                    "feature_codes","customer_names","notification_rules","private_networks_json",
                    "enable_private_networks","created_date","created_by"
                ])
            else:
                print(f"## bulk_upload_customer_groups inserted_ids is not a list")
                inserted_groups = database.get_data(table_name, {"created_by": username, "tenant_id": tenant_id}, [
                    "id","name","tenant_name","child_account","billing_account_number","rate_plan_name",
                    "feature_codes","customer_names","notification_rules","private_networks_json",
                    "enable_private_networks","created_date","created_by"
                ])
            print(f"## bulk_upload_customer_groups inserted_groups {inserted_groups}")
            for _, group in inserted_groups.iterrows():
                print(f"## bulk_upload_customer_groups group {group}")
                created_date_val = group.get("created_date")
                created_date_str = created_date_val.strftime("%Y-%m-%d %H:%M:%S") if hasattr(created_date_val, "strftime") else created_date_val

                group_data = {
                    "id": group.get("id"),
                    "name": group.get("name", ""),
                    "tenant_name": group.get("tenant_name"),
                    "child_account": group.get("child_account"),
                    "billing_account_number": group.get("billing_account_number"),
                    "rate_plan_name": group.get("rate_plan_name"),
                    "feature_codes": group.get("feature_codes"),
                    "customer_names": group.get("customer_names"),
                    "notification_rules": group.get("notification_rules"),
                    "enable_private_networks": group.get("enable_private_networks", False),
                    "created_by": group.get("created_by"),
                    "created_date": created_date_str,
                }

                private_networks = []
                if group.get("private_networks_json"):
                    try:
                        networks = json.loads(group["private_networks_json"])
                        if isinstance(networks, list):
                            for network in networks:
                                private_networks.append({
                                    "service_provider": network.get("service_provider", ""),
                                    "apn": network.get("apn", ""),
                                    "pdp": network.get("pdp", ""),
                                    "ip_range": network.get("ip_text", ""),
                                    "ip_version": network.get("ip_version", ""),
                                })
                    except Exception as e:
                        print("Error parsing private networks: %s", e)
                group_data["private_networks"] = private_networks

                # ----------------------------
                # MAP RELATED TABLES
                # ----------------------------
                customer_group_id = group.get("id")

                # Customers
                customer_names = group.get("customer_names", [])
                print(f"## bulk_upload_customer_groups customer_names {customer_names}")
                if isinstance(customer_names, str):
                    try:
                        customer_names = json.loads(customer_names)
                    except:
                        customer_names = [customer_names]
                customer_id_df = database.get_data(
                    "customers",
                    {"customer_name": customer_names, "tenant_id": tenant_id, "is_active": True},
                    ["id"],
                )
                if not customer_id_df.empty:
                    print(f"## bulk_upload_customer_groups customer_id_df {customer_id_df}")
                    customer_ids = customer_id_df["id"].to_list()
                    update_group_table(
                        database=database,
                        table_name="customer_group_customer",
                        group_column="customer_group_id",
                        item_column="customer_id",
                        group_id=customer_group_id,
                        new_ids=customer_ids,
                    )

                # Rate plans
                rate_plan_names = group.get("rate_plan_name", [])
                print(f"## bulk_upload_customer_groups rate_plan_names {rate_plan_names}")
                if isinstance(rate_plan_names, str):
                    try:
                        rate_plan_names = json.loads(rate_plan_names)
                    except:
                        rate_plan_names = [rate_plan_names]
                rate_plan_id_df = database.get_data(
                    "customerrateplan",
                    {"rate_plan_name": rate_plan_names, "tenant_id": tenant_id, "is_active": True},
                    ["id"],
                )
                if not rate_plan_id_df.empty:
                    print(f"## bulk_upload_customer_groups rate_plan_id_df {rate_plan_id_df}")
                    rate_plan_ids = rate_plan_id_df["id"].to_list()
                    update_group_table(
                        database=database,
                        table_name="customer_group_customer_rate_plan",
                        group_column="customer_group_id",
                        item_column="customer_rate_plan_id",
                        group_id=customer_group_id,
                        new_ids=rate_plan_ids,
                    )

                # Feature codes
                feature_codes = group.get("feature_codes", [])
                print(f"## bulk_upload_customer_groups feature_codes {feature_codes}")
                if isinstance(feature_codes, str):
                    try:
                        feature_codes = json.loads(feature_codes)
                    except:
                        feature_codes = [feature_codes]
                feature_codes_df = database.get_data(
                    "mobility_feature",
                    {"soc_code": feature_codes, "is_active": True},
                    ["id"],
                )
                if not feature_codes_df.empty:
                    print(f"## bulk_upload_customer_groups feature_codes_df {feature_codes_df}")
                    feature_codes_ids = feature_codes_df["id"].to_list()
                    update_group_table(
                        database=database,
                        table_name="customer_group_mobility_feature",
                        group_column="customer_group_id",
                        item_column="mobility_feature_id",
                        group_id=customer_group_id,
                        new_ids=feature_codes_ids,
                    )

                # Notification rules
                notification_rules = group.get("notification_rules", [])
                print(f"## bulk_upload_customer_groups notification_rules {notification_rules}")
                if isinstance(notification_rules, str):
                    try:
                        notification_rules = json.loads(notification_rules)
                    except:
                        notification_rules = [notification_rules]
                notification_rules_df = database.get_data(
                    "rule_rule_definition",
                    {"name": notification_rules, "is_active": True},
                    ["id"],
                )
                if not notification_rules_df.empty:
                    print(f"## bulk_upload_customer_groups notification_rules_df {notification_rules_df}")
                    notification_rules_ids = notification_rules_df["id"].to_list()
                    update_group_table(
                        database=database,
                        table_name="notification_rule_recipient",
                        group_column="customer_group_id",
                        item_column="rule_id",
                        group_id=customer_group_id,
                        new_ids=notification_rules_ids,
                        created_by=username,
                    )

                response_data.append(group_data)

        response = {"flag": True, "message": f"Successfully imported {len(records)} customer groups", "data": response_data, "imported_count": len(records)}

        # ----------------------------
        # AUDIT LOG
        # ----------------------------
        end_time = time.time()
        time_consumed = int(end_time - start_time)
        try:
            audit_data_user_actions = {
                "service_name": "bulk_upload_customer_groups",
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": uploaded_dataframe["tenant_name"].iloc[0] if not uploaded_dataframe.empty else "",
                "comments": json.dumps(records),
                "module_name": "Customer Groups",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            print(f"### Exception in audit logging: {e}")

        return response

    except Exception as e:
        print(f"### Error in bulk_upload_customer_groups: {e}")
        message = str(e)
        response = {"flag": False, "message": message}
        error_type = str(type(e).__name__)
        try:
            error_data = {
                "service_name": "bulk_upload_customer_groups",
                "error_message": str(e),
                "error_type": error_type,
                "users": username,
                "session_id": session_id,
                "tenant_name": uploaded_dataframe["tenant_name"].iloc[0] if not uploaded_dataframe.empty else "",
                "comments": message,
                "module_name": "Customer Groups",
                "request_received_at": request_received_at,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e2:
            print(f"### Exception logging error: {e2}")
        return response


# -------------
def test_file(data):
    uploaded_file_blob = 'UEsDBBQAAAAIAAAAIQBMQQIRXwEAAJAEAAATAAAAW0NvbnRlbnRfVHlwZXNdLnhtbKyUTU7DMBCF90jcIfIWJW5ZIISadMHPEipRDmDiSWPVsS3PtLS3Z+K2CKHSgtqNLcee9768sTwarzqbLSGi8a4Uw2IgMnC118bNSvE2fcpvRYaknFbWOyjFGlCMq8uL0XQdADOudliKlijcSYl1C53CwgdwvNP42CniZZzJoOq5moG8HgxuZO0dgaOceg1RjR6gUQtL2eOKP29IIlgU2f3mYO9VChWCNbUiJpVLp3+45FuHgivTGWxNwCvGEHKvQ7/zu8G27oWjiUZDNlGRnlXHGHJl5YeP83fv58VhkT2UvmlMDdrXi44TKDBEUBpbAOpskeaiU8btuPf5c/Ek+oAcY4T/E+xy6qvzwEIQycBXUgcduQUn/zL0Tdag/+i9TTtFgzJNwzPH3nczCR9KnTmIbzdsxtMRktgRQ6S1BTz3JUuix5xbFUG/UuR34OwA37V3HDK9J9UnAAAA//8DAFBLAwQUAAAACAAAACEAtVUwI/QAAABMAgAACwAAAF9yZWxzLy5yZWxzrJJNT8MwDIbvSPyHyPfV3ZAQQkt3QUi7IVR+gEncD7WNoyQb3b8nHBBUGoMDR3+9fvzK2908jerIIfbiNKyLEhQ7I7Z3rYaX+nF1ByomcpZGcazhxBF21fXV9plHSnkodr2PKqu4qKFLyd8jRtPxRLEQzy5XGgkTpRyGFj2ZgVrGTVneYviuAdVCU+2thrC3N6Dqk8+bf9eWpukNP4g5TOzSmRXIc2Jn2a58yGwh9fkaVVNoOWmwYp5yOiJ5X2RswPNEm78T/XwtTpzIUiI0Evgyz0fHJaD1f1q0NPHLnXnENwnDq8jwyYKLH6jeAQAA//8DAFBLAwQUAAAACAAAACEAH5tdi+8AAACKAQAAEAAAAGRvY1Byb3BzL2FwcC54bWyckE1PwzAMhu9I/Ico9zUZSBOa0kzjS1wmOIzdo9TtIlo7SsLU/nsMEwVx5Gb7tR+/ttmMQy9OkHIgrOWy0lIAemoCdrV83T8ubqTIxWHjekKo5QRZbuzlhXlJFCGVAFkwAnMtj6XEtVLZH2FwuWIZWWkpDa5wmjpFbRs83JN/HwCLutJ6pWAsgA00izgD5Zm4PpX/Qhvyn/7yYT9FNmzNNsY+eFf4SrsLPlGmtoiH0UMvnrEPCEb97jE7h66DZI2aozsaosOJS3P0xPjE02+3LgMLf3ImHs6vtctVpa+1/tryXTPq54n2AwAA//8DAFBLAwQUAAAACAAAACEANTZ71JoBAAAmAwAAEQAAAGRvY1Byb3BzL2NvcmUueG1sjFLBTuMwEL0j7T9EvqdOAgFktUHaRZxAWm2LQHsz9rT1JrEte0rI3+PEJW1XPXDzzHvz/Pw887uPtknewXll9ILks4wkoIWRSm8W5Hn1kN6SxCPXkjdGw4L04Mld9eNiLiwTxsFvZyw4VOCToKQ9E3ZBtoiWUerFFlruZ4GhA7g2ruUYSrehlouab4AWWXZNW0AuOXI6CKZ2UiR7SSkmSbtzzSggBYUGWtDoaT7L6YGL4Fp/dmBEjpitwt6GN+3tHmtLEcGJ/eHVROy6btZdjjaC/5y+Pj0ux6emSg9ZCSDVXAqGChuo5vRwDCe/e/sHAmN7KgIgHHA0LgJTEWKuoe+Mkz4gJ1WYkeCFUxbD58W5k0ZgN9zjU/jNtQL5s6+WTtVc4zb5A3XNGz4q/scZftbBuxo2Il55qKQYM4xeQSYhFRYz/EJeLn/drx5IVWRFmeZFmpWrPGN5wa6u/g5JnMwPKcVGu/f4HcXbVXbDypIV5ZHil0A1LiZH2BjXR/tiqsad1RiWZokcd/tEhTnTOt7s6hMAAP//AwBQSwMEFAAAAAgAAAAhAIE+lJfzAAAAugIAABoAAAB4bC9fcmVscy93b3JrYm9vay54bWwucmVsc6xSTUvEMBC9C/6HMHebdhUR2XQvIuxV6w8IybQp2yYhM3703xsqul1Y1ksvA2+Gee/Nx3b3NQ7iAxP1wSuoihIEehNs7zsFb83zzQMIYu2tHoJHBRMS7Orrq+0LDppzE7k+ksgsnhQ45vgoJRmHo6YiRPS50oY0as4wdTJqc9Adyk1Z3su05ID6hFPsrYK0t7cgmilm5f+5Q9v2Bp+CeR/R8xkJSTwNeQDR6NQhK/jBRfYI8rz8Zk15zmvBo/oM5RyrSx6qNT18hnQgh8hHH38pknPlopm7Ve/hdEL7yim/2/Isy/TvZuTJx9XfAAAA//8DAFBLAwQUAAAACAAAACEAVrLK+UYDAABjCAAADQAAAHhsL3N0eWxlcy54bWykVttu2zgQfV+g/0DwXaEkW17bkFTEcQQU6BYFkgJ9pSVKJsqLQNJZuYv99w4l2VLQS7pZ+EHkcObwzBkO6fRtJwV6YsZyrTIc3YQYMVXqiqsmw58ei2CNkXVUVVRoxTJ8Zha/zd/8kVp3FuzhyJhDAKFsho/OtVtCbHlkktob3TIFK7U2kjqYmobY1jBaWR8kBYnDcEUk5QoPCFtZ/g6IpObLqQ1KLVvq+IEL7s49Fkay3L5rlDb0IIBqFy1pibpoZWLUmcsmvfW7fSQvjba6djeAS3Rd85J9T3dDNoSWExIgvw4pSkgYP8u9M69EWhLDnrgvH87TWitnUalPymU4Hg15ar+iJyqgvBEmeVpqoQ1yUCUQqbcoKtngcds6bdEHaoz+2/vWVHJxHtZib+irOzpLDlp7I/H7Drvn6cF7Pdtwgr+jgh8Mn8X0oRZiuRBX5gvPHAx5CiV2zKgCJmgcP55b4K3gNA4wvd8L3o2h5yhOfj/AasErz6K569UyzSHDRbFf+J+HOfxsgcwoe2V6ev0HsjxoU0GvzSs0mPJUsNoBruHN0X+dbv0u2jk4j3lacdpoRYUX+xIxj4QehXbMsDtCO11KTE9OjxUmHn5Ef9G359BTeNEVaF5Yvug7JPPjXMakQKKSCfHgk/lcX3WKIKWuRuokC+neVRmGW8ofucsQNB6HgybDxGs1RxuwZ7C+Qf47LOrqK/7PoiPgN5KKMZpIgf0SjWjbinMBWfgSjTOImWa7/rBM81vBGyXZEJCn0ErDFB214V8ByLd4CesMLju40h0vZxavRlePkoAIM6Wf6XxVDPm2zfAHf3+LGe/DiQvH1Q80Bsyqm6oW+j5x/i7u63ndBYpXsZqehHu8LmZ4Gv/FKn6SoNvo9ZE/addDZHgaD14bvwfr3HsLpxu+6GR4hv+53/252d8XcbAOd+tguWBJsEl2+yBZ3u32+2ITxuHdv7MX4X+8B/0DBucoWm6tgFfDjMmO5B8mW4Znk/e+z/vLlwDtOfdNvApvkygMikUYBcsVXQfr1SIJiiSK96vl7j4pkhn35JXvRkiiaHiBPPlk67hkgqtLrS4VmluhSDD9RRI+lb4SZPp3kH8DAAD//wMAUEsDBBQAAAAIAAAAIQBB38tMyAcAABEiAAATAAAAeGwvdGhlbWUvdGhlbWUxLnhtbOxazY8btxW/F+j/MJi7rNFo9LWwHOjTG3t3vfDKLnKkJEpDL2c4IKndFQIDhXPqJUCAtOilQG89BEECJECDXvrHGLDRpn9EH8mRZriiYq8/gLTYFbCY4fze44/vPT6+IefuJ1cJ9S4wF4SlXb92J/A9nM7YnKTLrv9kMq60fU9IlM4RZSnu+mss/E/u/fY3d9GBjHGCPZBPxQHq+rGU2UG1KmbQjMQdluEUni0YT5CEW76szjm6BL0JrYZB0KwmiKS+l6IE1D5aLMgMexOl0r+3UT6icJtKoRpmlJ8p1diS0Nj5eU0hxFoMKPcuEO360M+cXU7wlfQ9ioSEB10/0H9+9d7dKjrIhajcI1uSG+u/XC4XmJ+Huk++nG47DUZhO6pt9WsAlbu4UVv9tvo0AM1mMFLDpayzFjXG7TDHlkDm0qW7Va9vOJRA5rK+w7nWbg7CyNKvQQYf7Y5x3BkNGxZegwy+sYPvBWG/U7fwGmTwzR18NOq1wpGF16CYkvR8F91stdvNHL2FLBg9dMI7zWbQGubwAgXRsI0u1cWCpXJfrCXoGeNjACggRZKknlxneIFmEMW9TDLhDYnIKFr7XoZSJqA5CINxUIf/6hfpK21xdIBRSVrxAiZip0nx8cSMk0x2/Qeg1S9BXv3008sXP7588feXX3zx8sV33hFZxtKosuQOUbosy/38t6/+85ffe//+4a8/f/1HN16U8a+//cPrf/zzl9TDVCtM8epP37/+8ftXf/7yX9987dDe42hahk9IgoV3gi+9xyyBAWpT2PzxlN9MYhIjYkmgGHQ7VI9kbAFP1oi6cH1sm/AphyzjAt5fPbO4nsV8JYmj54dxYgGPGaN9xp0GeKj6Kll4skqX7s75qox7jNCFq+8BSi0Hj1YZpFfiUjmIsUXzlKJUoiVOsfTUM3aOsWN0nxFi2fWYzDgTbCG9z4jXR8RpkgmZWoFUCB2SBPyydhEEV1u2OX7q9Rl1jXqIL2wkTAtEHeQnmFpmvI9WEiUulROU0LLBj5CMXSTP1nxWxo2EBE8vMWXeaI6FcMk84jDektMfIkhsTrcf03ViI7kk5y6dR4ixMnLIzgcxSjInZ5LGZeyn4hxCFHmnTLrgx8yeIeoe/IDSve5+SrDl7jcngieQ4MqUigBRT1bc4cv7mNnzcU0XCLuyTI8nVnbtceKMjv5qaYX2EcYUXaI5xt6TTx0M+iyzbF6QfhBDVjnErsB6gOxYVfcpFlAmqbpmN0UeEWGF7Blesj18jtfXEs8apQni+zSfgNet0J1ymIwOCo/o7LwMPCFQ/kG8OI3ySICOUnCP9mk9jZG1dql74Y7XNbf89zZzDObls5vOS5DBN5aBxP7WtpkganVQBMwEEe/IlW5BxHJ/IaLWVS22csot7ElbuAEKI6veSUj6puLnBHHOLsu1T60GZXeUVz+6AjJx8+Frn49W9bgVv0+9sy+vHF6rcvbh/gdrmyFapacYlpPdxHVb2tyWNv7/fWmzby7fFjS3Bc1tQeN6BfsoBU1Rw0B5U2z16I2fZO++z4JQeibXFB8JvfUj4LVmPoZGvSelNya3+4BZDJdqPNCBhVtypGU8zuTviIzPYpTB/lBN72IuRa56KbyMCdg20s16PxVf0603n1bJMZub7U5dYwXGhALJoj1oQPFl2mGrShp0s5U3Kn4b6prtUm+1bggo2ZuQKHVmk6g7SLQ2jW8goarHD8Oi42DRVuo3rtoxBVDbegXeuz14W+/6jcgwgh05qNHnyk/G1RvvKud8UE/vMyYtRwAU2Lue7iiue4enRmdC7S08bZHQTjFhZZPQvtIFnojhbTiPzvK++y8F3E193SlcatFTptjMhoJGq/0xfK2SyLXcQNNypqCpdwlzPIRJ53szlHX9Bewbw2WSQfAI9e6F6BIOX2aSmxn/Lqkl40IOkYiNxXXWMf5JiMTcoyTp+mr823CgqU4ihlwHpu6vlVyoJtyvjRx43fYyXizwTJb9XmpRlja3kOJNsnA+1eLvDlaSbAXuPovnl96UrvhjBCHWaNWUd+dEwPFBzbh6TuA8bJvJivi7tjLl2d865CryMaJZjPIlpZzNDVwvKFs6+m5rg9JdPmYw6K4Jp0u1wr73svvmtVpZrlgfO8WiaaUVtWy6s+nHW+VLrIpV1GJlcvf1nNvZJDsIVOcy8f5rf4la0ZlFTTHezcMqaeetNrUPWBGUVp/mHrttFwmnJd516Qe561GrVohNYakDXx+cl8+22fQZJI8hnCKuqDntpinc6dIyO+Xat1M2X+eXVJhEY3yuilKTyh/jhUfmV10/dFWO+eFxXg3QFNC65oUZthV0Vnu2oFrsclEzYbfCpoy9Vq/awluJzTHrVlhvLbpoy6vNabaq1XXPymFm1DoNa0vB1a4VYZucIyidzWGuyb2QZ65kXmnDlbfipOt/HjR60SBsDCpBuzGqRPUoqLQbvXql12jUa6NGLRj2w+dAT8ZJrWG+fBjDaRBd598/6PadbyCSzYHXnRlLqkx/41DV3tffQNTC/d9AgCOBVjMcd+qdfrPSqffGlWjYb1c6g2a/MmwOWsPxcNBod8bPfe9Cg6NefRA1R+1KszYYVKJmoOi3O5VWFIa9qNVrj6Le89z9MHKTg3NbgPk0r3v/BQAA//8DAFBLAwQUAAAACAAAACEA2R9c/ggDAACOBwAADwAAAHhsL3dvcmtib29rLnhtbKxUW0/bMBR+n7T/EPk9xE6dSyPK1Nw0JEAIOtiekElcapHEkePSIsR/33HatCCmqWKLEjvH5/jzdy4+x9/WdWU9cdUJ2UwQOcLI4k0hS9E8TNCPWW6HyOo0a0pWyYZP0DPv0LeTr1+OV1I93kv5aAFA003QQus2cpyuWPCadUey5Q1o5lLVTIOoHpyuVZyV3YJzXVeOi7Hv1Ew0aIMQqUMw5HwuCp7KYlnzRm9AFK+YBvrdQrTdgFYXh8DVTD0uW7uQdQsQ96IS+rkHRVZdRKcPjVTsvgK318Sz1gpeHz6CYXCHk0D14ahaFEp2cq6PANrZkP7gP8EOIe9CsP4Yg8OQqKP4kzA53LFS/idZ+Tssfw9G8D+jESitvlYiCN4n0bwdNxedHM9FxW82pWuxtr1gtclUhayKdTorheblBAUgyhXfL1BkqWUbL0UFWnfsjTByTnblfKlAWKtoiOelVhb8n6ZngHnNnuCEESCU2wo8BQxC7nBMUs+Ps3GSJkkWjvwYu0kWTL08ximdjuM4T0nim5pRflRIttSLLXODO0EUaH5QnbP1oCE4Wopyz+ElSJJ4lI48exwH1KYEJ3ZIaWCHhKYZTVI/wO6rcczc0RvBV93eRyNa61vRlHIFIaCQmOdBIthD1qpX3YpSL8A9Gu7XvnPxsAC+Ie7TqVxDa4Je8PaxYU7NgO0cnn4YdD0d5w2fvhUAr362mj5916Y9EOg5Zu6jC+mKzBnqtCTGIWfYVrCquFSWmXrDMcFuaCz4Wp91up+tpRJAj1A8DfCY2jiDkNFw7EK0Rq6d0NTNvCBLs9h7/Z8XGmqIeNHQIw3LBVN6pljxCJ31is9j1kEpbRwCvm/Jxl4Y4xFQpDnJIbVjbMexT20vzUdeQNIk8/I9WeP+/JPXKXT63ZzppYK+DqR7OTJjvl3dLc43C9s8vetL0VVq4r7d/TfDa/C+4gca5zcHGiYX57PzA23PstndbX6o8fQ8TqeH20+vrqa/ZtnP4QjnjwF1+oSbsS9TZyiTk98AAAD//wMAUEsDBBQAAAAIAAAAIQDy5z2tPgMAAPUIAAAYAAAAeGwvd29ya3NoZWV0cy9zaGVldDEueG1snFRdj9owEHyv1P9g+Z0kDkkgiHCq2p56D5Wqfj4bxyEWcZza5uBU9b/f2kngJCoaHQLPEntmdtcL67uTbNAj10aotsAkiDDiLVOlaHcF/vH9frbEyFjalrRRLS/wEzf4bvP2zfqo9N7UnFsECq0pcG1ttwpDw2ouqQlUx1vYqZSW1MJXvQtNpzktPUk2YRxFWSipaHGvsNJTNFRVCcY/KHaQvLW9iOYNtZC/qUVnRjXJpshJqveHbsaU7EBiKxphn7woRpKtHnat0nTbQN0nklCGThreMXzmo41/fuUkBdPKqMoGoBz2OV+Xn4d5SNlZ6br+STIkCTV/FO4CL1Lx61Ii6VkrvojNXymWncVcu/TqIMoC/4mG1wyQuCW6LOPeX7xZlwJu2FWFNK8K/I6sPsc43Kz9/PwU/GhexMjS7TfecGY5eBCM3Hhuldq7gw/wKAJF4w84RcqseOTvedMU+COBmTe/vYmLwSI8e7yMR797P9JfNCp5RQ+N/aqOn7jY1RaMU0dnqoGzsCIp4EcFnZT05PEoSltDlAXxMiVpFqcYsYOxSv7qd8jA75nQNs8EHJgkD5ZpmmTLxW1mMjABB2YSBwsS5fP/EEHWWwKOltkkYjYQAccqoa83ilsMBMAzYVpb4C/J5wh4acukhuYDE3BkgsiNJN1seC8XjJT5tDQJjGHPdfM43G8eJHG6WJJ/33zoR+cZAAD//wAAAP//bNJbCoMwEAXQrUg2kCZR+yAGan32sQgRwa+2GLHbb7RFmZn8ydwjyL1q23fdmDVjY/Tw+gRDwgQL7Lt5Wvd0EooZ3c7X83xewjFh1l0ns9N8Mpq3f5FSIaC4UCGhyKhQUORUhFAUVERQlFTEUFRU7KGoqThAcaXiCMXN0xgq9e4hqNWHh2y1crfqOq30T+vO66gC9Z2CEFWdyeVHkFKpMIyiOBbo23LwNpqhACFaoAQhKr8CIeq9BuFW+a8Jvv3wXwAAAP//AAAA//+yKUhMT/VNLErPzCtWyElNK7FVMtAzV1IoykzPgLFL8gvAoqZKCkn5JSX5uTBeRmpiSmoRiGespJCWn18C4+jb2eiX5xdlF2ekppbYAQAAAP//AwBQSwMEFAAAAAgAAAAhAEZqV3xvAQAA9wIAABQAAAB4bC9zaGFyZWRTdHJpbmdzLnhtbGxSy07DMBC8I/EPKx84FZJWAvFIgtqmRSBUohIQ1yVZWkt+FHtT4O8xqQAp6cXSzux4ZtdOrj+1gi05L61JxfAkFkCmsrU0q1Q8lfPjcwGe0dSorKFUfJEX19nhQeI9Q9Aan4o18+Yyiny1Jo3+xG7IBObNOo0cSreK/MYR1n5NxFpFozg+izRKI6CyjeFUjIJtY+R7Q9M/IEu8zBLOFqgpiThLop96h5Vk0DDso6ZrqWoYV+3NXd1EKhUm+6Vh0ehXct2uJTJBodDsNZgTcuMIprYm35VOG89Wk2uVPXZhWb7JCjksG5aN6usfyW1lFdyd3cq6H21cLLqWRV50odsClmhWvbUF/Hn31P2Feh51wbFi/LDuc18zHKHeXEFO2kLxkA8v2oUNhvHNBHJkDEw7yOkNHMOSaNufdZIXt8XdeTwbPObzcnI/m730E6wsMHkelOHYl2PYMv3oZZuvDOZtun9pFD5u9g0AAP//AwBQSwECCgAUAAAACAAAACEATEECEV8BAACQBAAAEwAAAAAAAAAAAAAAAAAAAAAAW0NvbnRlbnRfVHlwZXNdLnhtbFBLAQIKABQAAAAIAAAAIQC1VTAj9AAAAEwCAAALAAAAAAAAAAAAAAAAAJABAABfcmVscy8ucmVsc1BLAQIKABQAAAAIAAAAIQAfm12L7wAAAIoBAAAQAAAAAAAAAAAAAAAAAK0CAABkb2NQcm9wcy9hcHAueG1sUEsBAgoAFAAAAAgAAAAhADU2e9SaAQAAJgMAABEAAAAAAAAAAAAAAAAAygMAAGRvY1Byb3BzL2NvcmUueG1sUEsBAgoAFAAAAAgAAAAhAIE+lJfzAAAAugIAABoAAAAAAAAAAAAAAAAAkwUAAHhsL19yZWxzL3dvcmtib29rLnhtbC5yZWxzUEsBAgoAFAAAAAgAAAAhAFayyvlGAwAAYwgAAA0AAAAAAAAAAAAAAAAAvgYAAHhsL3N0eWxlcy54bWxQSwECCgAUAAAACAAAACEAQd/LTMgHAAARIgAAEwAAAAAAAAAAAAAAAAAvCgAAeGwvdGhlbWUvdGhlbWUxLnhtbFBLAQIKABQAAAAIAAAAIQDZH1z+CAMAAI4HAAAPAAAAAAAAAAAAAAAAACgSAAB4bC93b3JrYm9vay54bWxQSwECCgAUAAAACAAAACEA8uc9rT4DAAD1CAAAGAAAAAAAAAAAAAAAAABdFQAAeGwvd29ya3NoZWV0cy9zaGVldDEueG1sUEsBAgoAFAAAAAgAAAAhAEZqV3xvAQAA9wIAABQAAAAAAAAAAAAAAAAA0RgAAHhsL3NoYXJlZFN0cmluZ3MueG1sUEsFBgAAAAAKAAoAgAIAAHIaAAAAAA=='
    username = 'Lohitha V'
    created_date ='2025-12-08 13:32:24.972'
    tenant_id = '1'
    table_name = 'customergroups'
    altaworx_central_beta = DB('altaworx_central_beta', **common_utils_database_config)
    result=bulk_upload_customer_groups(
        uploaded_file_blob,
        username,
        created_date,
        tenant_id,
        table_name,
        altaworx_central_beta,
        session_id=None,
        request_received_at=created_date,
    )
    return result



def bulk_update_roles_from_excel(df,tenant_id,modified_by,session_id,partner,request_received_at):
    """
    Updates role records in the database in bulk and writes audit/error logs.
 
    This function validates incoming payload data, extracts the records to update,
    and performs a bulk update on the `roles` (or specified) table.
    It also logs audit information on success or error details on failure.
 
    Args:
        data (dict): Payload containing update details and metadata.
            Expected keys include:
                - table_name (str, optional): Target table name (default: "roles").
                - changed_data (list[dict] | dict): Records to update.
                  Each must contain "id" and the fields to be updated.
                - username (str, optional): User performing the action.
                - request_received_at (str | datetime, optional): Request timestamp.
                - sub_module (str, optional): Module/sub-module name (default: "Sim Management").
 
    Returns:
        dict: A result object with:
            - flag (bool): True if update succeeded, False otherwise.
            - message (str): Human-readable status message.
    """
 
    try:
        start_time = time.time()
        # Normalize column names if needed
        df.columns = [c.strip() for c in df.columns]
        df = df.rename(
            columns={
                "Role": "role_name",
                "Status": "is_active",
                "Timeout": "ui_timeout",
            }
        )
        excel_role_names = [str(r).strip() for r in df["role_name"].tolist()]
        print(f'## --------excel_role_names {excel_role_names}')
        # 2. Get roles from DB for this tenant
        common_utils_database = DB('common_utils', **common_utils_database_config)
        roles_filter_condition = {"tenant_id": tenant_id,"role_name": excel_role_names}
        roles_df = common_utils_database.get_data(
            "roles", roles_filter_condition, ["id", "role_name"]
        )
        roles_df = roles_df.to_dict(orient="records") if not df.empty else []
        # 3. Build lookup: role_name -> id
        role_name_to_id = {}

        for r in roles_df:
            if isinstance(r, dict):
                role_name = str(r.get("role_name", "")).strip()
                role_id = r.get("id")
            else:
                # tuple fallback (index based)
                role_id, role_name = r[0], r[1]
                role_name = str(role_name).strip()

            role_name_to_id[role_name] = role_id
        print(f'--------------role_name_to_id {role_name_to_id}')
        # 4. Build changed_data from Excel rows
        changed_data = []
        for _, row in df.iterrows():
            role_name = str(row.get("role_name", "")).strip()
            role_id = role_name_to_id.get(role_name)
            if not role_id:
                continue

            status_raw = str(row.get("is_active", "")).strip().lower()
            # map status text to boolean
            if status_raw in ("true", "1", "yes", "y", "active"):
                is_active = True
            elif status_raw in ("false", "0", "no", "n", "inactive"):
                is_active = False
            # else:
            #     is_active = False

            ui_timeout = row.get("ui_timeout", 15)

            changed_data.append(
                {
                    "id": role_id,
                    "role_name": role_name,
                    "is_active": is_active,
                    "modified_by": modified_by,
                    "ui_timeout": ui_timeout,
                }
            )

        print(f'### bulk_update_roles_from_excel changed_data {changed_data}')
        # Validate each record
        to_update = []
        for record in changed_data:
            if "id" not in record:
                response = {"flag": False, "message": "Each record must contain an 'id' field."}
                print("### bulk_update_roles_from_excel Missing 'id' in record.")
                return response
            # Extract id and prepare update data
            record_id = record["id"]
            update_data = {k: v for k, v in record.items() if k != "id"}
            to_update.append({"id": record_id, **update_data})
 
        
        # Call db_utils bulk_update_data
        response_flag = common_utils_database.bulk_update_data(
            table_name='roles',
            data_list=to_update,
            search_column="id",
        )
        print(f"response_flag : {response_flag}")
 
        # Return proper response message
        if response_flag:
            response =  {"flag": True, "message": f"{len(to_update)} record(s) updated successfully"}
           
            # End time calculation
            end_time = time.time()
            time_consumed = int(end_time - start_time)
 
            try :
                # Prepare audit log
                audit_data_user_actions = {
                    "service_name": "bulk_update_roles_from_excel",
                    "created_by": modified_by,
                    "status": str(response_flag),
                    "time_consumed_secs": time_consumed,
                    "session_id": session_id,
                    "tenant_name": partner,
                    "comments": f"Updated {len(to_update)} record(s) in roles table",
                    "module_name": "Sim Management",
                    "request_received_at": request_received_at,
                }
                common_utils_database.update_audit(
                    audit_data_user_actions, "audit_user_actions"
                )
            except Exception as e:
                print(f"### Exception during audit logging: {e}")    
           
            return response
        else:
            return {"flag": False, "message": "No records updated"}
 
    except Exception as e:
        print(f"## bulk_update_roles_from_excel Error Ocuured While updating the Roles {e}")
        message = "Something went wrong while performing update"
        try:
            # Prepare error data
            error_data = {
                "service_name": "bulk_update_roles_from_excel",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": modified_by,
                "session_id": session_id,
                "tenant_name": partner,
                "comments": message,
                "module_name": "Sim Management",
                "request_received_at": request_received_at,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            print(f"### Exception while logging error to DB: {e}")    
        return {"flag": False, "message": message}

#---- bulk_update_roles_from_excel  Test ---------
changed_data = [
    {
      "role_name": "Agent Partner Admin",
      "is_active": False,
      "ui_timeout": 15
    },
    {
      "role_name": "Notification Only User",
      "is_active": True,
      "ui_timeout": 15
    },
    {
      "role_name": "User",
      "is_active": True,
      "ui_timeout": 15
    },
    {
      "role_name": "Agent",
      "is_active": True,
      "ui_timeout": 15
    },
    {
      "role_name": "Qualification Only User",
      "is_active": True,
      "ui_timeout": 15
    },
    {
      "role_name": "Partner Admin",
      "is_active": True,
      "ui_timeout": 15
    }
  ]
tenant_id ='1168'
modified_by = 'superadmin'
partner = 'Altaworx'
session_id = None
request_received_at = '08-29-2025 12:05:25 PM'
dataframe = pd.DataFrame(changed_data)
# result = bulk_update_roles_from_excel(dataframe,tenant_id,modified_by,session_id,partner,request_received_at)
#---- bulk_update_roles_from_excel  Test -----------