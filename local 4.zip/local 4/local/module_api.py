"""
@Author : Nikhil .N
@Author : Phaneendra.Y
Created Date: 21-06-24
"""

# Importing necessary libraries
import time
import math
import datetime
from io import BytesIO
from io import StringIO
import base64
import json
import psycopg2
import boto3
import pandas as pd
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
from common_utils.email_trigger import send_email
from common_utils.timezone_conversion import *
from common_utils.permission_manager import PermissionManager
import os
import re
import pytz
from pytz import timezone
import concurrent.futures
import logging
import numpy as np
from openpyxl.styles import Alignment, PatternFill, Font
from openpyxl.utils import get_column_letter
import csv
from openpyxl import load_workbook
from openpyxl import Workbook
from pytz import UnknownTimeZoneError, timezone
from sqlalchemy import text
import requests
import hashlib
from common_utils.kore import *
import xml.etree.ElementTree as ET


logging = Logging(name="module_api")


##to fetch the service providers ids for each tenants separately used to get the serviceprovider ids in generic way
def load_json():
    """
    Loads a JSON file and returns the data.

    :param file_path: Absolute path to the JSON file.
    :return: Parsed JSON data as a dictionary, or None if an error occurs.

    """
    # Define the JSON file path
    FILE_PATH = "tenant_based_serviceproviders.json"
    file_path=FILE_PATH
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        logging.warning(f"Error: JSON file not found at {file_path}")
    except json.JSONDecodeError:
        logging.warning(f"Error: Invalid JSON format in {file_path}")
    except Exception as e:
        logging.exception(f"Unexpected error while reading JSON: {e}")

    return {}  # Return None if an error occurs


def tenant_load_json():
    """
    Loads a JSON file and returns the data.

    :param file_path: Absolute path to the JSON file.
    :return: Parsed JSON data as a dictionary, or None if an error occurs.

    """
    # Define the JSON file path
    FILE_PATH = "tenant_sub_tenant.json"
    file_path=FILE_PATH
    try:
        with open(file_path, "r", encoding="utf-8") as file:
            return json.load(file)
    except FileNotFoundError:
        logging.warning(f"Error: JSON file not found at {file_path}")
    except json.JSONDecodeError:
        logging.warning(f"Error: Invalid JSON format in {file_path}")
    except Exception as e:
        logging.exception(f"Unexpected error while reading JSON: {e}")

    return {}

def get_tenant_ids(tenant_name):
    """
    Fetches the tenant ID(s) based on the tenant_name in the payload from 'tenant_sub_tenant.json'.

    :param data: A dictionary containing "tenant_name".
    :return: A list with tenant_ids (as a single value or a tuple) based on the data.
    """
    logging.info("Received tenant_name: %s", tenant_name)

    if not tenant_name:
        logging.error("Error: 'tenant_name' is missing in the payload")
        return []  # Return an empty list for failure

    tenants = tenant_load_json()
    logging.info("Loaded tenants data type: %s", type(tenants))
    logging.info("Loaded tenants data: %s", tenants)

    # If the loaded data is a tuple, extract the first element which should be the list.
    if isinstance(tenants, tuple):
        tenants = tenants[0]
        logging.info("Extracted tenants list from tuple")

    if not isinstance(tenants, list):
        logging.error("Error: Expected a list but got %s", type(tenants))
        return []  # Return an empty list for failure

    for tenant in tenants:
        if not isinstance(tenant, dict):
            logging.error("Unexpected data format for tenant: %s", tenant)
            continue

        if tenant.get('parent_tenant_name') == tenant_name:
            sub_tenant_ids = tuple(sub_tenant['id'] for sub_tenant in tenant.get('sub_tenants', [])
                                   if isinstance(sub_tenant, dict))

            all_tenant_ids = (tenant.get('tenant_id', tenant.get('parent_tenant_id')),) + sub_tenant_ids

            # Return all tenant IDs as a list (if one tenant ID, return a list with that value)
            tenant_ids=list(all_tenant_ids) if len(all_tenant_ids) > 1 else [all_tenant_ids[0]]
            return tenant_ids

        for sub_tenant in tenant.get('sub_tenants', []):
            if not isinstance(sub_tenant, dict):
                logging.error("Unexpected data format for sub_tenant: %s", sub_tenant)
                continue

            if sub_tenant.get('tenant_name') == tenant_name:
                tenant_id = (sub_tenant.get('id'),)
                tenant_ids=list(tenant_id) if len(tenant_id) > 1 else [tenant_id[0]]
                return tenant_ids

    return []  # Return an empty list if no matching tenant is found


##helper function to remove the hardcodes using the
def get_provider_ids(json_data, tenant_name, provider_names):
    """Fetches only the IDs of specified providers for a given tenant."""
    return [
        details["id"]
        for provider_name, details in json_data.get(tenant_name, {}).items()
        if provider_name in provider_names
    ]

def get_integration_id_by_unique_name(json_data, tenant_name, unique_name):
    """Fetches 'main_name' of a provider based on its unique name."""
    return json_data.get(tenant_name, {}).get(unique_name, {}).get("integration_id", None)

def clean_tenant_tuple(tpl):
    try:
        if tpl is None:
            return ()  # Return empty tuple if input is None
        if not isinstance(tpl, tuple):
            return ()  # Return empty tuple if input is None

        if len(tpl) == 1:
            return f"({tpl[0]})"  # Return formatted string without trailing comma

        return f"{tpl}"  # Default tuple representation
    except Exception as e:
        print(f"Exception while converting")
        return ()

def clean_tuple(tpl):
    try:
        if tpl is None:
            return ()  # Return empty tuple if input is None
        if not isinstance(tpl, tuple):
            return ()  # Return empty tuple if input is None

        if len(tpl) == 1:
            return f"('{tpl[0]}')"  # Return formatted string without trailing comma

        return f"{tpl}"  # Default tuple representation
    except Exception as e:
        print(f"Exception while converting")
        return ()

def db_config_maker(user, db_config_making, tenant_database,tenant_name):

    common_utils_database = DB('common_utils', **db_config_making)

    query = f"select customers,service_provider,customer_group from users where username ='{user}'"
    filters = common_utils_database.execute_query(query, True)

    try:
        database = DB(tenant_database, **db_config)
    except:
        database = DB('altaworx_central', **db_config)
    try:
        customer_group = filters["customer_group"].to_list()[0]
    except:
        customer_group = None

    customer_group_data = None
    billing_account_number = None
    feature_codes = None
    customer_rate_plan_name=None
    customer_names=None
    tenant_ids=None
    if customer_group:
        customer_group_data = database.get_data(
            "customergroups", {"name": customer_group}, ["customer_names","rate_plan_name", "billing_account_number", "feature_codes"]
        )

        if not customer_group_data.empty:
            try:
                customer_rate_plan_name = tuple(json.loads(customer_group_data["rate_plan_name"].to_list()[0]))
            except Exception as e:
                logging.exception("Error extracting rate_plan_name:", e)
            try:
                customer_names = tuple(json.loads(customer_group_data["customer_names"].to_list()[0]))

            except Exception as e:
                logging.exception("Error extracting rate_plan_name:", e)
                customer_names=None

            try:
                billing_data = customer_group_data["billing_account_number"].to_list()[0]
                if billing_data:
                    billing_account_number = (billing_data,)  # Wrap int in a tuple
                else:
                    billing_account_number=None


            except Exception as e:
                logging.exception("Error extracting billing_account_number:", e)
                billing_account_number=None

            try:
                feature_data = customer_group_data["feature_codes"].to_list()[0]

                if isinstance(feature_data, str):
                    feature_codes = tuple(json.loads(feature_data))
                elif isinstance(feature_data, list):
                    feature_codes = tuple(feature_data)
                else:
                    feature_codes = (feature_data,)  # Convert non-list types to tuple

            except Exception as e:
                logging.exception("Error extracting feature_codes:", e)
    if customer_names is None:
        try:
            customer = tuple(json.loads(filters["customers"].to_list()[0]))
        except:
            customer = None
    else:
        customer=customer_names
    customer=clean_tuple(customer)
    try:
        service_provider = tuple(json.loads(filters["service_provider"].to_list()[0]))
        if len(service_provider) == 1:
            query = f"select id from serviceprovider where service_provider_name ='{service_provider[0]}'"
        else:
            query = f"select id from serviceprovider where service_provider_name in '{service_provider[0]}'"
        service_provider_id = tuple(database.execute_query(query, True)["id"].to_list())
    except:
        service_provider = None
        service_provider_id = None
    try:
        if customer:
            customer_rate_plan_names=()
            customer_rate_plan_name_query = f"""
                SELECT distinct customer_rate_plan_name FROM sim_management_inventory
                WHERE customer_name IN {customer} and customer_rate_plan_name is not null order by customer_rate_plan_name asc
            """

            result = database.execute_query(customer_rate_plan_name_query, True)

            # Convert the result into a tuple format
            if not result.empty:
                try:
                    customer_rate_plan_names = tuple(result["customer_rate_plan_name"].to_list())
                except Exception as e:
                    logging.exception("Error processing customer_rate_plan_name:", e)
                    customer_rate_plan_names = None
            else:
                customer_rate_plan_names = None
        customer_rate_plan_name += customer_rate_plan_names
    except Exception as e:
        logging.exception("Error processing customer_rate_plan_name:", e)
        customer_rate_plan_name = None
    tenant_ids=get_tenant_ids(tenant_name)
    if tenant_ids:
        tenant_ids = tuple(tenant_ids)
        tenant_ids=clean_tenant_tuple(tenant_ids)
    else:
        tenant_ids=None

    db_config_making["customers"] = customer
    db_config_making["service_providers"] = service_provider
    db_config_making["service_provider_id"] = service_provider_id
    db_config_making["customer_rate_plan_name"] = customer_rate_plan_name
    db_config_making["feature_codes"] = feature_codes
    db_config_making["billing_account_number"] = billing_account_number
    db_config_making["tenant_ids"] = tenant_ids
    return db_config_making



def funtion_caller(data, path):
    global db_config

    db_config = {
        "host": "amoppostgres.c3qae66ke1lg.us-east-1.rds.amazonaws.com",
        "port": 5432,
        "user": "root",
        "password": "AmopTeam123",
    }

    user = data.get("username")
    if not user:
        user = data.get("user_name")
    tenant_name = data.get("tenant_name", "") or data.get('tenant', "")
    if tenant_name=='Altaworx Test':
        tenant_name='Altaworx'
    tenant_database = data.get("db_name", "altaworx_central")
    db_config_making = db_config_maker(user, db_config, tenant_database,tenant_name)
    db_config = db_config_making
    logging.info(f"db_config is created")

    # Route based on the path and method
    if path == "/get_modules":
        result = get_modules(data)
    elif path == "/get_module_data":
        result = get_module_data(data)
    elif path == "/get_partner_info":
        result = get_partner_info(data)
    elif path == "/update_partner_info":
        result = update_partner_info(data)
    elif path == "/export":
        result = export(data)
    elif path == "/get_user_module_map":
        result = get_user_module_map(data)
    elif path == "/get_status_history":
        result = get_status_history(data)
    elif path == "/customers_dropdown_data":
        result = customers_dropdown_data(data)
    elif path == "/user_data":
        result = user_data(data)
    elif path == "/reports_data":
        result = reports_data(data)
    elif path == "/rate_plan_dropdown_data":
        result = rate_plan_dropdown_data(data)
    elif path == "/rate_plan_dropdown_data_optimization_groups":
        result = rate_plan_dropdown_data_optimization_groups(data)
    elif path == "/service_provider_list_view":
        result = service_provider_list_view(data)
    elif path == "/submit_update_edit_service_provider":
        result = submit_update_edit_service_provider(data)
    elif path == "/submit_update_edit_service_provider":
        result = submit_update_edit_service_provider(data)
    elif path == "/export_to_s3_bucket":
        result = export_to_s3_bucket(data)
    elif path == "/get_export_status":
        result = get_export_status(data)
    elif path == "/reports_data_with_date_filter":
        result = reports_data_with_date_filter(data)
    elif path == "/reports_dropdown_data_export":
        result = reports_dropdown_data_export(data)
    elif path == "/get_optimization_setting_details":
        result = get_optimization_setting_details(data)
    elif path == "/update_optimization_setting_details":
        result = update_optimization_setting_details(data)
    elif path == "/get_integration_data":
        result = get_integration_data(data)
    elif path == "/save_integration_details":
        result = save_integration_details(data)
    elif path == "/get_service_provider_config":
        result = get_service_provider_config(data)
    elif path == "/save_service_provider_config":
        result = save_service_provider_config(data)
    elif path == "/get_cross_provider_optimization_status":
        result = get_cross_provider_optimization_status(data)

    elif path == "/get_cross_carrier_optimization":
        result = get_cross_carrier_optimization(data)

    elif path == "/get_customer_user_by_line_report_view_data":
        result = get_customer_user_by_line_report_view_data(data)
    elif path == "/customer_info_details":
        result = customer_info_details(data)

    else:
        result = {"flag": False, "error": "Invalid path or method"}
        logging.warning("Invalid path or method requested: %s", path)

    return result


logging = Logging(name="module_api")


def get_headers_mapping(
    tenant_database,
    module_list,
    role,
    user,
    tenant_id,
    sub_parent_module,
    parent_module,
    data,
    common_utils_database,
):
    """
    Description: The  function retrieves and organizes field mappings,headers,and module features
    based on the provided module_list, role, user, and other parameters.
    It connects to a database, fetches relevant data, categorizes fields,and
    compiles features into a structured dictionary for each module.
    """
    ##Database connection
    ret_out = {}
    try:
        logging.info(f"Module name is :{module_list} and role is {role}")
        # common_utils_database = DB(os.environ['COMMON_UTILS_DATABASE'], **db_config)
        feature_module_name = data.get("feature_module_name", "")
        user_name = data.get("username") or data.get("user_name") or data.get("user")
        tenant_name = data.get("tenant_name") or data.get("tenant")
        parent_module_name = data.get("parent_module_name") or data.get("parent_module")
        if parent_module_name == "Sim Management":
            parent_module_name = "Sim Management"
        try:
            tenant_id = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["id"]
            )["id"].to_list()[0]
            logging.info(f"tenant_id  is :{tenant_id}")
        except Exception as e:
            logging.exception(f"Getting exception at fetching tenant id {e}")
        # Iterate over each module name in the provided module list
        for module_name in module_list:
            out = common_utils_database.get_data(
                "field_column_mapping", {"module_name": module_name}
            ).to_dict(orient="records")
            pop_up = []
            general_fields = []
            table_fileds = {}
            # Categorize the fetched data based on field types
            for data in out:
                if data["pop_col"]:
                    pop_up.append(data)
                elif data["table_col"]:
                    table_fileds.update(
                        {
                            data["db_column_name"]: [
                                data["display_name"],
                                data["table_header_order"],
                            ]
                        }
                    )
                else:
                    general_fields.append(data)
            # Create a dictionary to store categorized fields
            headers = {}
            headers["general_fields"] = general_fields
            headers["pop_up"] = pop_up
            headers["header_map"] = table_fileds
            logging.info(f"Got the header map here")
            try:
                final_features = []

                # Fetch all features for the 'super admin' role
                if role.lower() == "super admin":
                    all_features = common_utils_database.get_data(
                        "module_features",
                        {
                            "module": feature_module_name,
                            "parent_module_name": parent_module_name,
                        },
                        ["features"],
                    )["features"].to_list()
                    if all_features:
                        final_features = json.loads(all_features[0])
                else:
                    final_features = get_features_by_feature_name(
                        user_name,
                        tenant_id,
                        feature_module_name,
                        common_utils_database,
                        role,
                        parent_module_name,
                    )

            except Exception as e:
                logging.warning(f"there is some error {e}")
                pass
            # Add the final features to the headers dictionary
            headers["module_features"] = final_features
            ret_out[module_name] = headers
    except Exception as e:
        logging.warning("there is some error %s", e)

    return ret_out


def get_features_by_feature_name(
    user_name, tenant_id, feature_name, common_utils_database, role, parent_module
):
    """
    Description:
        This function retrieves a list of features associated with a specific
        feature name for a user within a tenant.
        It fetches user-module-tenant mapping data, processes the features,
        and extracts relevant features
        linked to the specified feature name.

    Parameters:
    ----------
    user_name : str
        The name or identifier of the user for whom the features are being fetched.
    tenant_id : str
        The tenant ID associated with the user.
    feature_name : str
        The specific feature name for which features need to be extracted.
    common_utils_database : object
        Utility database object to query data from the required tables.

    Returns:
    -------
    list
        A list of features associated with the specified feature name for the user.
    """

    # Fetch user features from the database based on user name and tenant ID
    user_features_raw = common_utils_database.get_data(
        "user_module_tenant_mapping",
        {"user_name": user_name, "tenant_id": tenant_id},
        ["module_features"],
    )["module_features"].to_list()
    logging.info("Raw user features fetched: %s", user_features_raw)

    # Parse the JSON string to a dictionary
    try:
        features = json.loads(
            user_features_raw[0]
        )  # Assuming it's a list with one JSON string
    except:
        features = {}

    if not features:
        features = common_utils_database.get_data(
            "role_module",
            {"role": role},
            ["module_features"],
        )["module_features"].to_list()
        features = json.loads(features[0])

    # Initialize a list to hold features for the specified feature name
    features_list = []

    # Loop through all modules to find the specified feature name and collect its features
    for par_module, modules in features.items():
        if parent_module == par_module:
            for module, features_l in modules.items():
                if module == feature_name:
                    features_list = features_l

    # Log the retrieved features for debugging purposes
    logging.info("Retrieved features: %s", features_list)

    # Return the list of features associated with the specified feature name
    return features_list


def form_modules_dict(data, sub_modules, tenant_modules, role_name):
    """
    Description:
        The form_modules_dict function constructs a nested dictionary that maps parent modules
        to their respective submodules and child modules. It filters and organizes modules based on
        the user's role, tenant permissions, and specified submodules.

    Parameters:
    ----------
    data : list of dict
        List of dictionaries representing modules and submodules, where each dictionary contains
        details such as module name, submodule name, and parent module name.
    sub_modules : list of str
        List of submodule names that are relevant to the user or tenant.
    tenant_modules : list of str
        List of modules assigned to the tenant.
    role_name : str
        The role of the user, which influences module access and visibility.

    Returns:
    -------
    dict
        A nested dictionary where parent modules map to submodules and child modules, organized
        based on user role and permissions.
    """
    logging.info("Starting to form modules dictionary.")

    # Initialize an empty dictionary to store the output
    out = {}

    # Iterate through the list of modules in the data
    for item in data:
        parent_module = item["parent_module_name"]
        logging.info("Processing parent module: %s", parent_module)

        # Skip modules not assigned to the tenant unless the role is 'super admin'
        if (
            parent_module not in tenant_modules and parent_module
        ) and role_name.lower() != "super admin":
            continue

        # If there's no parent module, initialize an empty dictionary for the module
        if not parent_module:
            out[item["module_name"]] = {}
            continue
        else:
            out[item["parent_module_name"]] = {}

        # Iterate through the data again to find related modules and submodules
        for module in data:
            temp = {}

            # Skip modules not in the specified submodules unless the role is 'super admin'
            if (
                module["module_name"] not in sub_modules
                and module["submodule_name"] not in sub_modules
            ) and role_name.lower() != "super admin":
                logging.info(
                    "Skipping parent module: %s (not in tenant modules)", parent_module
                )
                continue

            # Handle modules without submodules and create a list for them
            if (
                module["parent_module_name"] == parent_module
                and module["module_name"]
                and not module["submodule_name"]
            ):
                temp = {module["module_name"]: []}

            # Handle modules with submodules and map them accordingly
            elif (
                module["parent_module_name"] == parent_module
                and module["module_name"]
                and module["submodule_name"]
            ):
                temp = {module["submodule_name"]: [module["module_name"]]}

            # Update the output dictionary with the constructed module mapping
            if temp:
                for key, value in temp.items():
                    if key in out[item["parent_module_name"]]:
                        out[item["parent_module_name"]][key].append(value[0])
                    elif temp:
                        out[item["parent_module_name"]].update(temp)

    # Return the final dictionary containing the module mappings
    logging.info("Finished forming modules dictionary: %s", out)

    return out


def transform_structure(input_data):
    """
    Description:
        The transform_structure function transforms a nested dictionary of modules into a list of
        structured dictionaries, each with a queue_order to maintain the order of parent modules,
        child modules, and sub-children. The transformation ensures the proper hierarchical
        structure
        with an explicit ordering mechanism for all levels of modules.

    Parameters:
    ----------
    input_data : dict
        A nested dictionary where the keys represent parent modules, and the values
        represent dictionaries
        of child modules. Each child module contains a list of sub-children.

    Returns:
    -------
    list of dict
        A list of dictionaries representing the structured transformation of the input data,
        where each dictionary contains the parent module, child module, sub-children, and
        their corresponding queue orders.
    """

    logging.info("Starting transformation of input data.")

    # Initialize an empty list to store the transformed data
    transformed_data = []

    # Initialize the queue order for parent modules
    queue_order = 1

    # Iterate over each parent module and its children in the input data
    for parent_module, children in input_data.items():
        transformed_children = []
        child_queue_order = 1

        # Iterate over each child module and its sub-children
        for child_module, sub_children in children.items():
            transformed_sub_children = []
            sub_child_queue_order = 1

            # Iterate over each sub-child module
            for sub_child in sub_children:
                transformed_sub_children.append(
                    {
                        "sub_child_module_name": sub_child,
                        "queue_order": sub_child_queue_order,
                        "sub_children": [],
                    }
                )
                sub_child_queue_order += 1

            # Append the transformed child module with its sub-children
            transformed_children.append(
                {
                    "child_module_name": child_module,
                    "queue_order": child_queue_order,
                    "sub_children": transformed_sub_children,
                }
            )
            child_queue_order += 1

        # Append the transformed parent module with its children
        transformed_data.append(
            {
                "parent_module_name": parent_module,
                "queue_order": queue_order,
                "children": transformed_children,
            }
        )
        queue_order += 1

    # Return the list of transformed data
    return transformed_data


def convert_timestamp_datadict(df_dict, tenant_time_zone, timestamp_columns=None):
    logging.info("Started converting timestamps...")

    try:
        if timestamp_columns is None:
            timestamp_columns = [
                "created_date",
                "modified_date",
                "deleted_date",
                "processed_date",
                "last_login",
                "date_added",
                "date_activated",
                "run_start_time",
                "session_created_date",
            ]

        target_timezone = timezone(tenant_time_zone)
        utc_timezone = timezone("UTC")

        def process_record(record):
            for col in timestamp_columns:
                if col in record:  # Ensure column exists
                    try:
                        # Handle 'None' or invalid strings gracefully
                        if record[col] in ["None", None, ""]:
                            record[col] = None
                            continue

                        # Parse timestamp string to datetime
                        timestamp = pd.to_datetime(record[col], errors="coerce")

                        if pd.notna(timestamp):  # Check if parsing was successful
                            if timestamp.tzinfo is None:
                                # Localize naive timestamps to UTC
                                timestamp = timestamp.tz_localize(utc_timezone)
                            # Convert to the target timezone
                            timestamp = timestamp.tz_convert(target_timezone)

                            # Format the datetime to include AM/PM
                            record[col] = timestamp.strftime("%m-%d-%Y %I:%M:%S %p")
                            # print(f"Updated {col}: {record[col]}")
                        else:
                            logging.info(
                                f"Column '{col}' could not be parsed or is invalid: {record[col]}"
                            )
                    except Exception as e:
                        logging.warning(
                            f"Error processing column '{col}': {record[col]} - {e}"
                        )
            return record

        def traverse_data(data):
            if isinstance(data, list):  # Process each item if data is a list
                return [traverse_data(item) for item in data]
            elif isinstance(
                data, dict
            ):  # Process each key-value pair if data is a dictionary
                for key, value in data.items():
                    if isinstance(value, list):  # Handle lists under dictionary keys
                        data[key] = [process_record(item) for item in value]
                    elif isinstance(value, dict):  # Handle nested dictionaries
                        data[key] = traverse_data(value)
                return data
            return data  # Return data as-is for non-dict/non-list

        # Process the data and return the result
        processed_data = traverse_data(df_dict)
        return processed_data

    except Exception as e:
        logging.exception(f"Error in conversion process:{e}")


def get_module_data(
    data,
    flag=False,
):
    """
    Retrieves module data for a specified module by checking user and tenant
    to get the features by querying the database for column mappings and view
    names.

    It constructs and executes a SQL query to fetch data from the
    appropriate view, handles errors, and logs relevant information.

    Args:
    - data (dict): A dictionary containing various parameters like 'request_received_at',
      'session_id', 'username', 'tenant_name', 'role_name', etc.
    - flag (bool, optional): A flag to control the flow of response. Default is False.

    Returns:
    - dict: A dictionary containing the fetched data along with the status and any errors.
    """
    # Start time  and date calculation
    start_time = time.time()
    logging.info(f"Request Data: {data}")
    # Extract  fields from Request Data
    request_received_at = data.get("request_received_at", "")
    session_id = data.get("session_id", "")
    username = data.get("username", None)
    tenant_name = data.get("tenant_name", None)
    role = data.get("role_name", None)
    module_name = data.get("module_name", None)
    session_id = data.get("session_id", None)
    sub_parent_module = data.get("sub_parent_module", None)
    parent_module = data.get("parent_module", None)
    col_sort = data.get("col_sort", "")
    Partner = data.get("Partner", "")
    tenant_database = data.get("db_name", "")

    db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    database = DB(tenant_database, **db_config)

    if module_name == "Bulk Change" or module_name == "Sim Order Form":
        query = (
            f"select customers,service_provider from users where username ='{username}'"
        )
        filters = db.execute_query(query, True)
        try:
            customer = filters["customers"].to_list()[0]
        except:
            customer = None

        users = None
        if customer:
            if module_name == "Bulk Change":
                query = "select CONCAT(first_name, ' ', last_name) AS full_name from users where customers = %s"
                filters = db.execute_query(query, params=[customer])
                users = filters["full_name"].to_list()
                logging.info(f"users are {users}")
            if module_name == "Sim Order Form":
                query = "select username from users where customers = %s"
                filters = db.execute_query(query, params=[customer])
                users = filters["username"].to_list()
                logging.info(f"users are {users}")
    users = None
    customer = None

    # # Get tenant's timezone
    tenant_name = data.get("tenant_name", "")
    tenant_timezone_query = """SELECT time_zone,id FROM tenant WHERE tenant_name = %s"""
    tenant_timezone = db.execute_query(tenant_timezone_query, params=[tenant_name])

    if tenant_name == "Altaworx Test":
        tenant_id = 1
    else:
        tenant_id = tenant_timezone["id"].to_list()[0]

    tenant_time_zone = fetch_tenant_timezone(db, data)

    try:
        data_list = {}
        pages = {}
        features = []
        # query to find the column mapping for the module
        module_mappings_df = db.get_data(
            "module_column_mappings",
            {"module_name": module_name},
            [
                "columns_mapped",
                "master_data_flag",
                "tables_mapped",
                "view_name",
                "condition",
                "drop_down_col",
                "main_update_table",
                "order_by",
                "tenant_filter",
                "combine",
            ],
        )
        columns_data = module_mappings_df["columns_mapped"].to_list()[0]
        main_update_table = module_mappings_df["main_update_table"].to_list()[0]
        tenant_filter = module_mappings_df["tenant_filter"].to_list()[0]
        try:
            tenant_filter = json.loads(tenant_filter)
        except:
            tenant_filter = []
        try:
            columns_data = json.loads(columns_data)
        except Exception as e:
            logging.warning(f"Exception is {e}")
        # logging.info('master_data_flag',master_data_flag)
        tables_list = module_mappings_df["tables_mapped"].to_list()[0]
        try:
            tables_list = json.loads(tables_list)
        except Exception as e:
            logging.warning(f"Exception is {e}")
        # logging.info('view_name',view_name)
        condition = module_mappings_df["condition"].to_list()[0]
        try:
            condition = json.loads(condition)
        except:
            condition = {}

        drop_down_col = module_mappings_df["drop_down_col"].to_list()[0]
        try:
            drop_down_col = json.loads(drop_down_col)
        except Exception as e:
            logging.warning(f"Exception is {e}")
        order_by = module_mappings_df["order_by"].to_list()[0]
        try:
            order_by = json.loads(order_by)
        except Exception as e:
            logging.warning(f"Exception is {e}")
        combine_all = module_mappings_df["combine"].to_list()[0]
        try:
            combine_all = json.loads(combine_all)
        except Exception as e:
            logging.warning(f"Exception is {e}")
        # Check if tables_list is not empty
        if tables_list:
            for table in tables_list:

                if (
                    (module_name == "Bulk Change" or module_name == "Sim Order Form")
                    and customer
                    and (
                        table == "sim_management_bulk_change"
                        or table == "sim_order_form"
                    )
                ):
                    if table not in condition:
                        condition[table] = {}
                    condition[table]["created_by"] = users

                # if table is 'tenant' or 'users'
                if table in [
                    "tenant",
                    "roles",
                    "users",
                    "amop_apis",
                    "carrier_apis",
                    "mapping_table",
                    "master_amop_apis",
                    "master_carrier_apis",
                    "master_roles",
                    "module",
                    "tenant_module",
                    "module_features",
                ]:
                    current_db = db  # Use common_utils connection
                else:
                    current_db = database  # Use tenant-specific connection
                # Use order_by if current table is main_update_table
                if table == main_update_table:
                    if col_sort:
                        # Extract the single key-value pair
                        key, value = list(col_sort.items())[
                            0
                        ]  # Get the first and only pair
                        # Construct the ORDER BY clause
                        if table == "optimization_group" and key == "rate_plans_list":
                            # Modify the ordering logic for 'rate_plans_list'
                            order = {text("length(rate_plans_list)"): value.lower()}
                        else:
                            # Construct the ORDER BY clause for other columns
                            order = {key: value.lower()}
                    else:
                        order = order_by
                else:
                    order = None

                if tenant_filter:
                    temp = {}
                    if table in tenant_filter:
                        temp["tenant_id"] = str(tenant_id)
                        if table not in condition:
                            condition[table] = {}
                        condition[table].update(temp)
                        
                if table in {"customerrateplane", "serviceprovider", "customergroups"} and table in condition:
                    condition[table].setdefault("tenant_id", str(tenant_id))


                if combine_all and table in combine_all:
                    combine = combine_all[table]
                else:
                    combine = []
                if (
                    drop_down_col
                    and columns_data
                    and table in drop_down_col
                    and table in columns_data
                ):
                    mod_pages = None
                else:
                    # Get pagination details from data
                    mod_pages = data.get("mod_pages", {})
                    logging.info(mod_pages, "mod_pages")
                # Fetch data based on table, condition, and columns
                if columns_data and table in columns_data and condition:
                    if table in condition:
                        ##fetching the data for the table using conditions
                        data_dataframe = current_db.get_data(
                            table,
                            condition[table],
                            columns_data[table],
                            order,
                            combine,
                            None,
                            mod_pages,
                        )
                    else:
                        ##fetching the data for the table using conditions
                        data_dataframe = current_db.get_data(
                            table,
                            {},
                            columns_data[table],
                            order,
                            combine,
                            None,
                            mod_pages,
                        )
                elif columns_data and table in columns_data:
                    ##fetching the data for the table using conditions
                    data_dataframe = current_db.get_data(
                        table, {}, columns_data[table], order, combine, None, mod_pages
                    )
                elif condition and table in condition and columns_data:
                    if table in columns_data:
                        ##fetching the data for the table using conditions
                        data_dataframe = current_db.get_data(
                            table,
                            condition[table],
                            columns_data[table],
                            order,
                            combine,
                            None,
                            mod_pages,
                        )
                    else:
                        ##fetching the data for the table using conditions
                        data_dataframe = current_db.get_data(
                            table,
                            condition[table],
                            None,
                            order,
                            combine,
                            None,
                            mod_pages,
                        )
                else:
                    ##fetching the data for the table using conditions
                    if table not in condition:
                        data_dataframe = current_db.get_data(
                            table, {}, None, order, combine, None, mod_pages
                        )
                    else:
                        data_dataframe = current_db.get_data(
                            table,
                            condition[table],
                            None,
                            order,
                            combine,
                            None,
                            mod_pages,
                        )
                # Handle dropdown columns differently
                if (
                    drop_down_col
                    and columns_data
                    and table in drop_down_col
                    and table in columns_data
                ):
                    for col in columns_data[table]:
                        # data_list[col]=data_dataframe[col].to_list()
                        data_list[col] = list(set(data_dataframe[col].tolist()))
                else:
                    if (
                        module_name == "Bulk Change"
                        and table == "sim_management_bulk_change"
                    ):
                        if "id" in data_dataframe.columns:
                            data_dataframe["bulk_change_id"] = data_dataframe["id"]
                    ##converting the dataframe to dict
                    df = data_dataframe.to_dict(orient="records")
                    if parent_module.lower() not in ("people"):
                        if "mod_pages" in data and table == main_update_table:
                            # Calculate pages
                            pages["start"] = data["mod_pages"]["start"]
                            pages["end"] = data["mod_pages"]["end"]
                            count_params = [table]
                            if module_name in (
                                "Sim Order Form",
                                "Feature Codes",
                                "Customer Rate Plan",
                            ):
                                count_query = "SELECT COUNT(*) FROM %s" % table
                            else:
                                count_query = (
                                    "SELECT COUNT(*) FROM %s where is_active=True"
                                    % table
                                )

                            count_result = current_db.execute_query(
                                count_query, count_params
                            ).iloc[0, 0]
                            pages["total"] = int(count_result)
                    # Add fetched data to data_list
                    data_list[table] = df
        message = "Data fetched successfully"

        new_data = {
            table: (
                values
                if values and isinstance(values[0], str)
                else [
                    {
                        key: (
                            str(value).split(".")[0]
                            if key == "modified_date"
                            else str(value)
                        )
                        for key, value in item.items()
                    }
                    for item in values
                ]
            )
            for table, values in data_list.items()
        }

        if module_name == "Customer Rate Plan":
            # If columns are correct, select them as follows:
            try:
                json_data = load_json()
                telegence_ids = get_provider_ids(json_data, tenant_name, ["Telegence"])
                telegence_id = telegence_ids[0] if telegence_ids else None
                df = database.execute_query(
                    f"SELECT rate_plan_short_name,friendly_name FROM carrier_rate_plan WHERE is_active=True AND is_deleted=False AND service_provider_id={telegence_id} ORDER BY rate_plan_short_name, friendly_name",
                    True,
                ).to_dict(orient="records")

                # Check if the result is empty
                if not df:
                    new_data["soc_code"] = []
                else:
                    # Combine the required fields into a single string for each record
                    combined_list = [
                        f"{record['friendly_name']} - {record['rate_plan_short_name']}"
                        for record in df
                        if all(
                            key in record
                            for key in ["friendly_name", "rate_plan_short_name"]
                        )  # Ensure keys exist
                    ]

                    # Assign the list to 'soc_combined'
                    new_data["soc_code"] = combined_list

            except Exception as e:
                logging.warning(f"Failed to fetch automation_rule data: {e}")
            try:
                df = database.get_data(
                    "customerrateplan",
                    {"is_active": True},
                    ["rate_plan_code", "service_provider_name"],
                ).drop_duplicates(subset=["rate_plan_code", "service_provider_name"])
                new_data["soc_list"] = (
                    df[["rate_plan_code", "service_provider_name"]]
                    .to_records(index=False)
                    .tolist()
                )
            except Exception as e:
                logging.warning(f"Failed to fetch automation_rule data: {e}")
            try:
                automation_rule_list = database.get_data(
                    "automation_rule", {"is_active": True}, ["automation_rule_name"]
                )["automation_rule_name"].to_list()
                new_data["automation_rule"] = automation_rule_list
                service_provider_mapping = database.get_data(
                    "serviceprovider",
                    {"is_active": True},
                    ["id", "service_provider_name"],
                ).to_dict(orient="records")
                service_provider_mapping = {
                    item["service_provider_name"]: item["id"]
                    for item in service_provider_mapping
                }
                new_data["service_provider_mapping"] = service_provider_mapping
            except Exception as e:
                logging.warning(f"Failed to fetch automation_rule data: {e}")
            # List of keys that need rounding
            keys_to_round = {
                "surcharge_3g",
                "base_rate",
                "rate_charge_amt",
                "sms_rate",
            }
            keys_with_dollar_symbol = {
                "base_rate",
                "rate_charge_amt",
                "sms_rate",
                "display_rate",
            }

            # Use a single loop for rounding and formatting
            for records in new_data.values():
                if isinstance(records, list):
                    for record in records:
                        if isinstance(record, dict):
                            for key in keys_to_round & record.keys():
                                value = record[key]
                                if isinstance(value, (int, float)):
                                    rounded_value = round(value, 2)
                                    record[key] = (
                                        f"${rounded_value}"
                                        if key in keys_with_dollar_symbol
                                        else rounded_value
                                    )
                                elif isinstance(value, str):
                                    try:
                                        rounded_value = round(float(value), 2)
                                        record[key] = (
                                            f"${rounded_value}"
                                            if key in keys_with_dollar_symbol
                                            else rounded_value
                                        )
                                    except ValueError:
                                        logging.warning(
                                            f"Cannot round non-numeric string: {value}"
                                        )
        if module_name == "Active Customer Rate Plan":
            # If columns are correct, select them as follows:

            try:
                json_data = load_json()
                telegence_ids = get_provider_ids(json_data, tenant_name, ["Telegence"])
                telegence_id = telegence_ids[0] if telegence_ids else None
                df = database.execute_query(
                    f"SELECT rate_plan_short_name,friendly_name FROM carrier_rate_plan WHERE is_active=True AND is_deleted=False AND service_provider_id={telegence_id} ORDER BY rate_plan_short_name, friendly_name",
                    True,
                ).to_dict(orient="records")

                # Check if the result is empty
                if not df:
                    new_data["soc_code"] = []
                else:
                    # Combine the required fields into a single string for each record
                    combined_list = [
                        f"{record['friendly_name']} - {record['rate_plan_short_name']}"
                        for record in df
                        if all(
                            key in record
                            for key in ["friendly_name", "rate_plan_short_name"]
                        )  # Ensure keys exist
                    ]

                    # Assign the list to 'soc_combined'
                    new_data["soc_code"] = combined_list
            except Exception as e:
                logging.warning(f"Failed to fetch automation_rule data: {e}")
            try:
                df = database.get_data(
                    "customerrateplan",
                    {"is_active": True},
                    ["rate_plan_code", "service_provider_name"],
                ).drop_duplicates(subset=["rate_plan_code", "service_provider_name"])
                new_data["soc_list"] = (
                    df[["rate_plan_code", "service_provider_name"]]
                    .to_records(index=False)
                    .tolist()
                )
            except Exception as e:
                logging.warning(f"Failed to fetch automation_rule data: {e}")
            try:
                automation_rule_list = database.get_data(
                    "automation_rule", {"is_active": True}, ["automation_rule_name"]
                )["automation_rule_name"].to_list()
                new_data["automation_rule"] = sorted(automation_rule_list)
                service_provider_mapping = database.get_data(
                    "serviceprovider",
                    {"is_active": True},
                    ["id", "service_provider_name"],
                ).to_dict(orient="records")
                service_provider_mapping = {
                    item["service_provider_name"]: item["id"]
                    for item in service_provider_mapping
                }
                new_data["service_provider_mapping"] = service_provider_mapping
            except Exception as e:
                logging.warning(f"Failed to fetch automation_rule data: {e}")
            # List of keys that need rounding
            keys_to_round = {
                "surcharge_3g",
                "base_rate",
                "rate_charge_amt",
                "sms_rate",
                "overage_rate_cost",
            }
            keys_with_dollar_symbol = {
                "base_rate",
                "rate_charge_amt",
                "sms_rate",
                "overage_rate_cost",
                "display_rate",
            }

            # Use a single loop for rounding and formatting
            for records in new_data.values():
                if isinstance(records, list):
                    for record in records:
                        if isinstance(record, dict):
                            for key in keys_to_round & record.keys():
                                value = record[key]
                                if isinstance(value, (int, float)):
                                    rounded_value = round(value, 2)
                                    record[key] = (
                                        f"${rounded_value}"
                                        if key in keys_with_dollar_symbol
                                        else rounded_value
                                    )
                                elif isinstance(value, str):
                                    try:
                                        rounded_value = round(float(value), 2)
                                        record[key] = (
                                            f"${rounded_value}"
                                            if key in keys_with_dollar_symbol
                                            else rounded_value
                                        )
                                    except ValueError:
                                        logging.warning(
                                            f"Cannot round non-numeric string: {value}"
                                        )
        if module_name == "Bulk Change":
            new_data = {
                table: [
                    {
                        **{
                            key: (
                                int(float(value))
                                if key in ["errors", "uploaded", "success"]
                                and value.replace(".", "", 1).isdigit()
                                and not value.endswith(".")
                                else value
                            )
                            for key, value in item.items()
                        }
                    }
                    for item in values
                ]
                for table, values in new_data.items()
            }

        if not flag:
            # calling get header to get headers mapping
            headers_map = get_headers_mapping(
                tenant_database,
                [module_name],
                role,
                username,
                tenant_id,
                sub_parent_module,
                parent_module,
                data,
                db,
            )
            # Convert timestamps to string format before returning
            new_data = convert_timestamp_datadict(new_data, tenant_time_zone)
            try:
                # Attempt to retrieve the value from the 'tenant' table
                cross_carrier_optimization = database.get_data(
                    "optimization_setting",
                    {},
                    ["optino_cross_providercustomer_optimization"],
                )["optino_cross_providercustomer_optimization"].to_list()[0]
            except Exception as e:
                logging.exception(f"Failed to get the cross_carrier_optimization{e}")
                cross_carrier_optimization = False
            response = {
                "flag": True,
                "message": message,
                "data": serialize_data(new_data),
                "pages": pages,
                "features": features,
                "headers_map": headers_map,
                "cross_carrier_optimization":cross_carrier_optimization
            }
            # End time calculation
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            try:
                audit_data_user_actions = {
                    "service_name": "Module Management",
                    "created_date": request_received_at,
                    "created_by": username,
                    "status": str(response["flag"]),
                    "time_consumed_secs": time_consumed,
                    "session_id": session_id,
                    "tenant_name": Partner,
                    "comments": message,
                    "module_name": "get_module_data",
                    "request_received_at": request_received_at,
                }
                db.update_audit(audit_data_user_actions, "audit_user_actions")
            except Exception as e:
                logging.warning(f"Exception is {e}")
            return response
        else:
            return serialize_data(new_data), pages
    except Exception as e:
        logging.warning(f"Something went wrong and error is {e}")
        message = "Something went wrong fetching module data {e}"
        # response={"flag": False, "message": message}
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "get_module_data",
                "created_date": request_received_at,
                "error_message": message,
                "error_type": error_type,
                "users": username,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": "",
                "module_name": "Module Managament",
                "request_received_at": request_received_at,
            }
            db.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"Exception is {e}")
        # calling get header to get headers mapping
        headers_map = get_headers_mapping(
            tenant_database, [module_name], role, username, "", "", "", data, db
        )
        response = {
            "flag": True,
            "message": message,
            "data": {},
            "pages": {},
            "features": {},
            "headers_map": headers_map,
        }
        return response


def user_data(data):
    """
    Retrieves user-specific data along with the role modules from the database.

    This function queries two databases (one for user-specific data and one for role modules)
    and returns a response containing the user-specific data and role modules.

    Args:
    - data (dict): A dictionary containing the necessary parameters such as 'user_name',
      'db_name', and 'role_name'.

    Returns:
    - dict: A dictionary containing:
        - 'flag': A boolean indicating whether the operation was successful.
        - 'user_specific_data': A list of user-specific data.
        - 'role_module': A list of role modules.
    """
    logging.info("Starting to retrieve user data.")
    try:
        del db_config['customers']
        del db_config['service_providers']
        del db_config['billing_account_number']
        del db_config['feature_codes']
        del db_config['tenant_ids']
        # Extracting parameters from the input data
        user_name = data.get("user_name", None)
        user_tenant_name=data.get("user_tenant_name","")
        tenant_database = data.get("db_name", None)
        database = DB(tenant_database, **db_config)  # Connect to tenant database
        common_utils_database = DB(
            os.environ["COMMON_UTILS_DATABASE"], **db_config
        )  # Connect to common utils database
        user_tenant_id=common_utils_database.get_data("tenant",{"tenant_name":user_tenant_name},['id'])['id'].to_list()[0]
        user_tenant_id=int(user_tenant_id)
        role_name = data.get(
            "role_name", "Agent"
        )  # Default to 'Agent' if no role_name provided
        logging.info("Fetching role modules for role: %s", role_name)

        # Fetch role modules from the tenant database
        role_module = common_utils_database.get_data(
            "role_module", {"role": role_name}
        ).to_dict(orient="records")

        logging.info("Retrieved role modules: %s", role_module)

        # Fetch user-specific data from the common utils database
        logging.info("Fetching user-specific data for user: %s", user_name)
        user_specific_data = common_utils_database.get_data(
            "user_module_tenant_mapping",
            {"user_name": user_name,"tenant_id":user_tenant_id},
            ["sub_module", "module_names", "module_features"],
        ).to_dict(orient="records")
        logging.info("Retrieved user-specific data: %s", user_specific_data)

        # Check if user_specific_data is empty and return role module if so
        if not user_specific_data:
            logging.warning("No user-specific data found for user: %s", user_name)
            response = {
                "flag": True,
                "user_specific_data": [],  # Empty list if no data found
                "role_module": role_module,  # Include the role_module data
            }
            return response

        # Process the JSON fields in the user-specific data
        for item in user_specific_data:
            item["sub_module"] = json.loads(item["sub_module"]) if isinstance(item.get("sub_module"), str) else {}
            item["module_names"] = json.loads(item["module_names"]) if isinstance(item.get("module_names"), str) else []
            item["module_features"] = json.loads(item["module_features"]) if isinstance(item.get("module_features"), str) else []


        # Prepare the final response
        response = {
            "flag": True,  # Indicate that the operation was successful
            "user_specific_data": user_specific_data,
            "role_module": role_module,
        }
        logging.info("Final response data prepared successfully.")
        try:
            audit_data_user_actions = {
                "service_name": "Module_management",
                "created_date": data.get("request_received_at", ""),
                "created_by": data.get("username", ""),
                "status": "Success",
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("tenant_name", ""),
                "module_name": "Module_management",
                "comments": "user_data",
                "request_received_at": data.get("request_received_at", ""),
            }

            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"Exception is {e}")
        return response

    except Exception as e:
        # Handle exceptions by logging the error and returning a default response
        logging.exception(f"Exception is when fetching the user data: {e}")
        response = {
            "flag": True,  # Indicate failure due to exception
            "user_specific_data": [],  # Empty list if an error occurred
            "role_module": [],  # Empty list if an error occurred
        }
        message = "Something went wrong while fetching Partner info"
        response = {"flag": True, "message": message}
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "Module Management",
                "created_date": data.get("request_received_at", ""),
                "error_message": message,
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": "",
                "module_name": "get_user_data",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"Exception is {e}")
        return response


def customers_dropdown_data(data):
    """
    Retrieves a list of customers for active service providers and associated feature codes.
    The function queries the database to fetch data for service providers, tenants, customers,
    and feature codes, and organizes the data in a response format.

    Args:
    - data (dict): A dictionary containing parameters such as the database name ('db_name').

    Returns:
    - dict: A dictionary containing:
        - 'flag': A boolean indicating the success or failure of the operation.
        - 'service_provider_customers': A dictionary mapping service provider
          names to lists of customer names.
        - 'feature_codes': A list of unique feature codes (if available).
    """
    # Set the default database name to 'altaworx_central' if not provided
    tenant_database = data.get("db_name", "altaworx_central")
    database = DB(tenant_database, **db_config)  # Connect to the tenant database
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    logging.info("Request Received")

    try:
        # Fetch all active service providers with their IDs (only AT&T - Telegence - UAT ONLY)
        service_providers_df = database.get_data(
            "serviceprovider",
            {"is_active": True, "service_provider_name": "AT&T - Telegence - UAT ONLY"},
            ["id", "service_provider_name"],
        )
        # Extract service provider IDs and names
        service_provider_ids = service_providers_df["id"].to_list()
        service_provider_names = service_providers_df["service_provider_name"].to_list()

        # Fetch all tenant configurations for the active service providers
        tenant_ids_df = database.get_data(
            "service_provider_tenant_configuration",
            {
                "service_provider_id": service_provider_ids
            },  # Batch query for relevant service provider IDs
            ["service_provider_id", "tenant_id"],
        )

        # Fetch all customers for the retrieved tenant IDs
        tenant_ids = tenant_ids_df["tenant_id"].to_list()
        customers_df = database.get_data(
            "customers",
            {"tenant_id": tenant_ids, "is_active": True},  # Only active customers
            ["tenant_id", "customer_name"],
        )

        # Initialize a dictionary to map service providers to their customers
        service_provider_customers = {}
        for index, row in customers_df.iterrows():
            tenant_id = row["tenant_id"]
            customer_name = row["customer_name"]
            # Find the associated service provider ID for the customer
            service_provider_id = tenant_ids_df[
                tenant_ids_df["tenant_id"] == tenant_id
            ]["service_provider_id"].to_list()

            if service_provider_id:
                service_provider_id = service_provider_id[
                    0
                ]  # Assuming a one-to-one mapping between service provider and tenant
                service_provider_name = service_provider_names[
                    service_provider_ids.index(service_provider_id)
                ]

                # Append the customer to the respective service provider's list
                if service_provider_name not in service_provider_customers:
                    service_provider_customers[service_provider_name] = []
                service_provider_customers[service_provider_name].append(customer_name)

        # Fetch feature codes (if required)
        feature_codes = database.get_data("mobility_feature", {"is_active": True}, ["soc_code"])[
            "soc_code"
        ].to_list()
        feature_codes = list(set(feature_codes))
        used_feature_codes = database.get_data(
            "sim_management_carrier_feature_codes_uat",
            {"is_active": True},
            ["feature_codes"],
        )["feature_codes"].to_list()
        # Prepare the final response with unique feature codes

        final_feature_codes = [
            item for item in feature_codes if item not in used_feature_codes
        ]

        response = {
            "flag": True,
            "service_provider_customers": service_provider_customers,
            "feature_codes": list(
                set(final_feature_codes)
            ),  # Ensure feature codes are unique
        }
        try:
            audit_data_user_actions = {
                "service_name": "Module_management",
                "created_date": data.get("request_received_at", ""),
                "created_by": data.get("username", ""),
                "status": "Success",
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("tenant_name", ""),
                "module_name": "Module_management",
                "comments": "get_user_module_map",
                "request_received_at": data.get("request_received_at", ""),
            }

            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"Exception is {e}")
        return response

    except Exception as e:
        # Log exception and return a response indicating failure
        logging.exception(f"Data fetch issue: {e}")
        message = "Something went wrong while fetching Partner info"
        response = {"flag": True, "message": message}
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "Module Management",
                "created_date": data.get("request_received_at", ""),
                "error_message": message,
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": "",
                "module_name": "customers_dropdown_data",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"Exception is {e}")
        return {"flag": False, "service_provider_customers": {}, "feature_codes": []}


def rate_plan_dropdown_data(data):
    """
    Retrieves rate plans for active service providers from the database.
    The function organizes the rate plans by service provider and returns the
    result in a structured format.

    Args:
    - data (dict): A dictionary containing parameters such as the database name ('db_name').

    Returns:
    - dict: A dictionary containing:
        - 'flag': A boolean indicating the success of the operation.
        - 'carrier_rate_plans': A dictionary with service provider names as keys and
          lists of their rate plan codes as values.
    """
    try:
        # Get the tenant database name from input data
        tenant_database = data.get("db_name", None)
        common_utils_database = DB(
            os.environ["COMMON_UTILS_DATABASE"], **db_config
        )  # Connect to common utils database
        database = DB(tenant_database, **db_config)  # Connect to the tenant database

        # Fetch all unique active service provider names
        serviceproviders = database.get_data(
            "serviceprovider", {"is_active": True}, ["service_provider_name"]
        )["service_provider_name"].to_list()

        # Ensure uniqueness by converting to a set and back to a list
        service_provider_names = list(set(serviceproviders))

        # Initialize an empty dictionary to store rate plans for each service provider
        rate_plans_list = {}

        # Iterate over each service provider name
        for service_provider_name in service_provider_names:
            # Fetch the active rate plan codes for the current service provider
            rate_plan_items = database.get_data(
                "carrier_rate_plan",
                {"service_provider": service_provider_name, "is_active": True},
                ["rate_plan_code"],
            )["rate_plan_code"].to_list()

            # Add the rate plans to the dictionary under the respective service provider
            rate_plans_list[service_provider_name] = rate_plan_items

        # Return the final dictionary containing service providers and their rate plans
        try:
            audit_data_user_actions = {
                "service_name": "Module_management",
                "created_date": data.get("request_received_at", ""),
                "created_by": data.get("username", ""),
                "status": "Success",
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("tenant_name", ""),
                "module_name": "Module_management",
                "comments": "rate_plan_dropdown_data",
                "request_received_at": data.get("request_received_at", ""),
            }

            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"Exception is {e}")
        return {"flag": True, "carrier_rate_plans": rate_plans_list}
    except Exception as e:
        message = "Something went wrong while fetching Partner info"
        response = {"flag": True, "message": message}
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "Module Management",
                "created_date": data.get("request_received_at", ""),
                "error_message": message,
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": "",
                "module_name": "rate_plan_dropdown_data",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"Exception is {e}")
        return {"flag": False, "carrier_rate_plans": []}


def form_Partner_module_access(tenant_id, module_data):
    """
    Description:
    Forms access information for a specific tenant by filtering and organizing modules.

    This function processes tenant-specific module data and structures it
    for use in the system.

    Args:
    - tenant_id (str or int): The tenant ID for which module access is being processed.
    - module_data (dict): The module data containing 'tenant_module' and 'module' information.

    Returns:
    - dict: A modified dictionary with tenant-specific module access details.
    """
    # Extract 'tenant_module' from module_data, which contains information on the modules
    tenant_module = module_data.get("tenant_module", [])

    # Initialize a list to store the module names assigned to the specified tenant
    modules_names = []

    # Filter modules for the specific tenant_id and store module names in the list
    for data_item in tenant_module:
        if str(data_item["tenant_id"]) == str(tenant_id):
            modules_names.append(data_item["module_name"])
            logging.info(
                "Matched tenant_id: %s with module_name: %s",
                tenant_id,
                data_item["module_name"],
            )

    # Extract 'module' data which contains details about the parent-child module structure
    modules_data = module_data.get("module", [])

    # Initialize lists and dictionaries to structure the modules
    return_modules = []
    modules = {}
    logging.info(
        "Filtered modules names for tenant_id %s: %s", tenant_id, modules_names
    )

    # Organize modules by their parent module and filter out the "Super admin" module
    for data_item in modules_data:
        parent_module_name = data_item.get("parent_module_name", None)

        # Skip items with no parent module name or with 'None' as the parent
        if not parent_module_name or parent_module_name == "None":
            continue

        # Add parent module name to return_modules if not already added
        if parent_module_name not in return_modules:
            return_modules.append(parent_module_name)

        # Initialize an empty list for each parent module in the 'modules' dictionary
        if parent_module_name not in modules:
            modules[parent_module_name] = []

        # Append the module name under its parent module in the dictionary
        modules[parent_module_name].append(data_item["module_name"])

    # List of modules to remove from the final response (e.g., "Super admin")
    modules_to_remove = {"Super admin"}

    # Remove "Super admin" from return_modules if it exists
    return_modules = [
        module for module in return_modules if module not in modules_to_remove
    ]

    # Remove "Super admin" from the 'modules' dictionary if it exists
    if "Super admin" in modules:
        del modules["Super admin"]

    # Update module_data with the processed modules
    module_data["tenant_module"] = return_modules
    module_data["module"] = modules_dict()

    # Log the final structure of module_data
    logging.info("Final module_data structure: %s", module_data)

    # Return the modified module_data containing the tenant-specific access information
    return module_data


def modules_dict():
    """
    Description:
    Retrieves module mappings from the 'common_utils' database and returns them in a
    structured dictionary format. The dictionary organizes the data based on parent modules
    and includes modules or submodules as needed.

    Returns:
    - dict: A structured dictionary containing parent modules, modules, and submodules.
    """
    logging.info("Starting the retrieval of module mappings.")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    # Step 1: Retrieve the data
    module_mappings_df = common_utils_database.get_data(
        "module", {}, ["parent_module_name", "module_name", "submodule_name"]
    )
    logging.info("Retrieved module mappings data: %s", module_mappings_df)

    # Step 2: Create the desired output format
    result = {}

    for _, row in module_mappings_df.iterrows():
        parent = row["parent_module_name"]
        module = row["module_name"]
        submodule = row["submodule_name"]

        # Initialize the list for the parent module if it doesn't exist
        if parent not in result:
            result[parent] = []
            logging.info("Initialized list for parent module: %s", parent)

        # Include submodule_name if it exists, otherwise include module_name
        if submodule and submodule not in result[parent]:
            result[parent].append(submodule)
            logging.info("Added submodule: %s to parent module: %s", submodule, parent)
        elif not submodule and module and module not in result[parent]:
            result[parent].append(module)
            logging.info("Added module: %s to parent module: %s", module, parent)
        # If both module_name and submodule_name are absent, add parent_module_name
        elif not module and not submodule and parent not in result[parent]:
            result[parent].append(parent)
            logging.info("Added parent module name: %s to itself", parent)

    formatted_result_json = result
    logging.info("Successfully formatted the result: %s", formatted_result_json)

    return formatted_result_json


def get_user_module_map(data):
    """
    Description:
    This function retrieves the module mapping for a user based on their role
    and tenant information. It first checks if a user-specific mapping exists
    in the database. If not, it falls back to role-based mappings.

    Parameters:
    - data (dict): A dictionary containing the user's information:
      - 'username' (str): The username of the user.
      - 'role' (str): The role assigned to the user.
      - 'tenant_name' (str): The tenant name under which the user operates.
      - 'db_name' (str): The name of the tenant-specific database.

    Returns:
    - dict: A dictionary containing the result of the operation:
      - 'flag' (bool): Indicates if the operation was successful (True) or failed (False).
      - 'data' (dict): The module mapping data, which can either be user-specific or role-based.
    """
    logging.info(f"Request Data: {data}")
    try:
        # Extract username, role, and tenant_name from the input data dictionary
        username = data.get("username", None)
        role = data.get("role", None)
        tenant_name = data.get("tenant_name", None)
        # Initialize the database connection
        tenant_database = data.get("db_name", None)
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        return_dict = {}
        # Retrieve tenant_id based on tenant_name
        tenant_id = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id"]
        )["id"].to_list()[0]
        flag = False
        # Fetch the user-module mapping from the database
        user_map = database.get_data(
            "user_module_tenant_mapping",
            {"user_name": username, "tenant_id": tenant_id},
            ["module_names", "sub_module", "module_features"],
        ).to_dict(orient="records")
        # Check if a user-specific module map exists
        if user_map:
            user_map = user_map[0]
            logging.info("User map found: %s", user_map)
            for key, value in user_map.items():
                if value:
                    flag = True
                    break
            if flag:
                # Rename 'module_names' to 'module'
                return_dict = user_map
                return_dict["module"] = user_map["module_names"]
                return_dict.pop("module_names")
                logging.info("Returning user-specific module mapping: %s", return_dict)
            else:
                # If the user map is empty, fall back to role-based mapping
                return_dict = common_utils_database.get_data(
                    "role_module",
                    {"role": role},
                    ["module", "sub_module", "module_features"],
                ).to_dict(orient="records")
                logging.info(
                    "User map is empty; falling back to role-based mapping: %s",
                    return_dict,
                )
        else:
            # If no user-specific map is found, retrieve the role-based module map
            return_dict = common_utils_database.get_data(
                "role_module",
                {"role": role},
                ["module", "sub_module", "module_features"],
            ).to_dict(orient="records")
            logging.info(
                "No user-specific map found; retrieved role-based mapping: %s",
                return_dict,
            )
        try:
            audit_data_user_actions = {
                "service_name": "Module_management",
                "created_date": data.get("request_received_at", ""),
                "created_by": username,
                "status": "Success",
                "session_id": data.get("sessionID", ""),
                "tenant_name": tenant_name,
                "module_name": "Module_management",
                "comments": "get_user_module_map",
                "request_received_at": data.get("request_received_at", ""),
            }

            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"Exception is {e}")
        return {"flag": True, "data": return_dict}

    except Exception as e:
        # Handle any exceptions that occur during data retrieval
        logging.exception(f"error in fetching data {e}")
        message = "Something went wrong while fetching Partner info"
        response = {"flag": True, "message": message}
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "Module Management",
                "created_date": data.get("request_received_at", ""),
                "error_message": message,
                "error_type": error_type,
                "users": username,
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": "",
                "module_name": "get_user_module_map",
                "request_received_at": data.get("request_received_at", ""),
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"Exception is {e}")
        response = {"Flag": False, "data": {}}
        return response


def get_partner_info(data):
    """
    Fetches and returns partner-related information, including tenant details, partner
    authentication data, module access details, customer group information, and partner
      user data based on provided request data.

    The function performs the following actions:
    1. Checks if the partner has necessary permissions via the PermissionManager.
    2. Retrieves tenant-specific data such as timezone, email, logo, and service provider details.
    3. Collects partner and sub-partner information and formats it for the response.
    4. Fetches authentication data and adds it to the response.
    5. Loops through requested modules to format and return data for each module, including
    Partner Access, Customer Groups, Partner Users, etc.
    6. Logs the request and response details, including time consumed.

    Parameters:
    data (dict): Input data containing various parameters such as tenant_name, session_id,
    modules_list, etc.

    Returns:
    dict: A dictionary containing partner info, module data, headers mapping, and response status.
    """
    # Start time  and date calculation
    start_time = time.time()
    # logging.info(f"Request Data: {data}")
    ##Restriction Check for the Amop API's
    try:
        # Create an instance of the PermissionManager class
        permission_manager_instance = PermissionManager(db_config)

        # Call the permission_manager method with the data dictionary and validation=True
        result = permission_manager_instance.permission_manager(data, validation=True)

        # Check the result and handle accordingly
        if isinstance(result, dict) and result.get("flag") is False:
            return result
        else:
            # Continue with other logic if needed
            pass
    except Exception:
        logging.warning("got exception in the restriction")

    request_received_at = data.get("request_received_at", "")
    session_id = data.get("session_id", "")
    Partner = data.get("Partner", "")
    ##database connection
    del db_config['customers']
    del db_config['service_providers']
    del db_config['billing_account_number']
    del db_config['feature_codes']
    del db_config['tenant_ids']
    tenant_database = data.get("db_name", None)
    database = DB(tenant_database, **db_config)
    db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    username = data.get("username", None)
    tenant_name = data.get("tenant_name", None)
    session_id = data.get("session_id", None)
    col_sort = data.get("col_sort", "")
    # role = data.get('role_name', None)
    role = data.get("role_name") or data.get("role") or "Super Admin"
    modules_list = data.get("modules_list", None)
    parent_module = data.get("parent_module", None)
    sub_parent_module = data.get("sub_parent_module", None)

    # # Get tenant's timezone
    tenant_time_zone = fetch_tenant_timezone(db, data)

    try:
        counts = {}
        returning_partner_module_data = {}
        partner = tenant_name
        sub_partner = ""
        tenant_df = db.get_data(
            "tenant",
            {"tenant_name": tenant_name},
            [
                "parent_tenant_id",
                "id",
                "email_ids",
                "logo",
                "service_provider_to",
                "service_provider_status",
            ],
        )
        parent_tenant_id = tenant_df["parent_tenant_id"].to_list()[0]
        tenant_id = tenant_df["id"].to_list()[0]
        email_id = tenant_df["email_ids"].to_list()[0]
        service_provider_to = tenant_df["service_provider_to"].to_list()[0]
        service_provider_status = tenant_df["service_provider_status"].to_list()[0]
        logo = tenant_df["logo"].to_list()[0]
        if parent_tenant_id:
            sub_partner = tenant_name
            partner = db.get_data("tenant", {"id": parent_tenant_id}, ["tenant_name"])[
                "tenant_name"
            ].to_list()[0]

        # formating data for partner info
        if "Partner info" in modules_list:
            try:
                # Load email_id if it's a JSON string
                email_id = json.loads(email_id)
            except Exception as e:
                logging.warning(f"Exception is {e}")

            if col_sort:
                # Extract the single key-value pair
                key, value = list(col_sort.items())[0]  # Get the first and only pair
                # Construct the ORDER BY clause
                order_condition = f"ORDER BY {key} {value.upper()}"
            else:
                # If users is None or empty, we skip the WHERE clause entirely
                order_condition = f""

            # Fetch the required tenant information including addresses
            query = f"""
                SELECT
                    billing_address_1,
                    billing_address_2,
                    billing_city,
                    billing_state,
                    billing_zip_code,
                    billing_notes,
                    cross_provider_customer_optimization,
                    physical_address_1,
                    physical_addresss_2,
                    physical_apt_or_suite,
                    physical_city,
                    physical_state,
                    physical_zip_code,
                    physical_country,
                    physical_county,
                    time_zone
                FROM
                    tenant
                WHERE
                    tenant_name = '{tenant_name}'
                    {order_condition}
                """
            params = [tenant_name]

            # Execute the query with the tenant_name as a parameter
            tenant_info = db.execute_query(query, True)

            # Convert the result to a dictionary (assuming tenant_info is a DataFrame)
            tenant_info_dict = (
                tenant_info.to_dict(orient="records")[0]
                if not tenant_info.empty
                else {}
            )

            # Prepare the tenant names list
            tenant_names = db.get_data("tenant", {"is_active": True}, ["tenant_name"])[
                "tenant_name"
            ].to_list()

            # Add partner info along with addresses
            returning_partner_module_data["Partner info"] = {
                "partner": partner,
                "sub_partner": sub_partner,
                "email_id": email_id,
                "logo": logo,
                "service_provider_to": service_provider_to,
                "service_provider_status": service_provider_status,
                **tenant_info_dict,  # Merge tenant info dictionary into the partner info
                "tenant_names": tenant_names,
            }

            # Remove "Partner info" from modules_list to avoid redundant processing
            modules_list.remove("Partner info")
            # logging.info(returning_partner_module_data)

        # formating data for athentication
        if "Partner authentication" in modules_list:
            returning_partner_module_data["Partner authentication"] = {}
            modules_list.remove("Partner authentication")
            try:
                db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
                query = """SELECT * FROM partner_authentication"""
                partner_auth_data = db.execute_query(query, True)

                # Convert the result to a list of dictionaries (key-value pairs)
                partner_auth_dict_list = partner_auth_data.to_dict(orient="records")

                # Ensure the data is sent as an object (not a list)
                if partner_auth_dict_list:
                    partner_auth_dict = partner_auth_dict_list[
                        0
                    ]  # Extract the first dictionary (object)
                else:
                    partner_auth_dict = {}

                # Add the partner authentication data to the response dictionary as an object
                returning_partner_module_data["Partner authentication"] = (
                    partner_auth_dict
                )

                # Add the partner authentication data to the response dictionary
                returning_partner_module_data["Partner authentication"] = (
                    partner_auth_dict
                )

                # Remove "Partner authentication" from modules_list to avoid redundant processing
                modules_list.remove("Partner authentication")

                # logging.info(f"Partner authentication data added: {partner_auth_dict}")

            except Exception as e:
                logging.warning(f"Failed to fetch Partner authentication data: {e}")
            # logging.info(returning_partner_module_data)

        for module in modules_list:
            data["module_name"] = module
            if module in data["pages"]:
                data["mod_pages"] = data["pages"][module]
            module_data, pages = get_module_data(data, True)
            logging.info(f'###module_data {module_data}')
            if pages:
                counts[module] = {
                    "start": pages["start"],
                    "end": pages["end"],
                    "total": pages["total"],
                }
            # formating data for Partner module Access
            if module == "Partner module access":
                module_data = form_Partner_module_access(tenant_id, module_data)
                filtered_roles = [
                    role for role in module_data["role_name"] if role != "Super Admin"
                ]
                role_df = db.get_data(
                    "roles", {"tenant_id": tenant_id, "is_active": True}, ["role_name"]
                )
                # Filter role_df to include only roles in filtered_roles
                filtered_role_df = role_df[role_df["role_name"].isin(filtered_roles)]
                # Update module_data with unique role names from the filtered roles
                module_data["role_name"] = list(set(filtered_role_df["role_name"]))
                try:
                    role_module_query = f"select * from role_module"
                    role_module_dataframe = db.execute_query(
                        role_module_query, True
                    ).to_dict(orient="records")
                    module_data["role_module"] = role_module_dataframe
                    logging.info(f'###role_module_dataframe {role_module_dataframe}')
                except:
                    logging.info(f'###role_module_dataframe is Empty')
                    pass
                tenant_modules = db.get_data(
                    table_name="tenant_module",
                    condition={"tenant_name": tenant_name, "is_active": True},
                    columns=["tenant_id", "module_name"],
                    order={"id": "asc"},
                ).to_dict(orient="records")
                # Extract module names into a list
                module_list = [module["module_name"] for module in tenant_modules]
                module_list = [
                    module for module in module_list if module != "Super admin"
                ]
                logging.info(f'###module_list {module_list}')
                module_data["tenant_module"] = module_list
            # formating data for Customer groups
            if module == "Customer groups":
                module_data_new = {}
                module_data_new["customer_names"] = []
                module_data_new["billing_account_number"] = []

                if col_sort:
                    # Extract the single key-value pair
                    key, value = list(col_sort.items())[
                        0
                    ]  # Get the first and only pair
                    # Construct the ORDER BY clause
                    order_condition = f"ORDER BY {key} {value.upper()}"
                else:
                    # If col_sort is None or empty, skip the WHERE clause entirely
                    order_condition = f""
                # Loop through each dictionary in the list
                for dic in module_data["customers"]:
                    # Create new dictionaries for each key-value pair
                    first_key, first_value = list(dic.items())[0]
                    second_key, second_value = list(dic.items())[1]
                    # logging.info('second_key',second_key)
                    if first_key == "billing_account_number":
                        if first_value and first_value != "None":
                            module_data_new["billing_account_number"].append(
                                first_value
                            )
                        if second_value and second_value != "None":
                            module_data_new["customer_names"].append(second_value)
                    else:
                        if first_value and first_value != "None":
                            module_data_new["customer_names"].append(first_value)
                        if second_value and second_value != "None":
                            module_data_new["billing_account_number"].append(
                                second_value
                            )
                module_data.update(module_data_new)
                module_data.pop("customers")
                soc_codes_pop_up_query = """SELECT distinct(soc_code) FROM public.mobility_feature
                where soc_code is not null
                """
                soc_codes_pop_up_values = database.execute_query(
                    soc_codes_pop_up_query, True
                )["soc_code"].to_list()
                # Add SOC codes to the module_data
                module_data["feature_codes"] = soc_codes_pop_up_values
                logging.info(f'###feature_codes {feature_codes}')
                tenant_id_val=''
                try:
                    tenant_dff = database.get_data(
                                        "tenant",
                                        {"tenant_name": tenant_name},
                                        ["id"]
                                    )
                    if not tenant_dff.empty:
                        tenant_id_val=tenant_dff["id"].to_list()[0]
                        print(f'###tenant_id_val {tenant_id_val}')
                except Exception as e:
                    tenant_id_val=''
                    print(f'Error occured {e}')
                if tenant_id_val:
                    customers_data_query = f"""SELECT distinct customer_name FROM public.customers where is_active=True and tenant_id={tenant_id} order by customer_name asc"""
                else:
                    customers_data_query = f"""SELECT distinct customer_name FROM public.customers where is_active=True order by customer_name asc"""
                # customers_data_query = """SELECT distinct customer_name FROM public.customers where is_active=True order by customer_name asc
                
                customer_names = database.execute_query(
                    customers_data_query, True
                )["customer_name"].to_list()
                module_data["customer_names"] = customer_names
                logging.info(f'###customer_names {customer_names}')
                notifications_data_query = """SELECT distinct name FROM public.rule_rule_definition where is_active=True order by name asc
                """
                notification_rules = database.execute_query(
                    notifications_data_query, True
                )["name"].to_list()
                module_data["notification_rules"] = notification_rules
                tenant_data = db.get_data("tenant", {"is_active": True}, ["id", "tenant_name"]).to_dict(orient="records")
                # Convert list of dictionaries to desired format
                tenant_id_map = {item["tenant_name"]: item["id"] for item in tenant_data}

                # Assign the transformed data to module_data
                module_data["tenant_id_map"] = tenant_id_map
                
                if tenant_id_val:
                    condition={"billing_account_number": "not Null","tenant_id":tenant_id_val,"is_active": True}
                else:
                    condition={"billing_account_number": "not Null", "is_active": True, "tenant_id": tenant_id_val}

                # billing_account_numbers = database.get_data(
                #     "sim_management_inventory",
                #     {"billing_account_number": "not Null", "is_active": True},
                #     ["billing_account_number"],
                # )["billing_account_number"].to_list()
                billing_account_numbers = database.get_data(
                    "sim_management_inventory",
                    condition,
                    ["billing_account_number"],
                )["billing_account_number"].to_list()
                # Remove duplicates
                billing_account_numbers = list(set(billing_account_numbers))
                module_data["billing_account_number"] = billing_account_numbers
                logging.info(f'###billing_account_number {billing_account_number}')
                module_data["tenant_name"] = sorted(module_data["tenant_name"])
                try:
                    sub_tanant=[]
                    tenant_dff = db.get_data(
                                        "tenant",
                                        {"tenant_name": tenant_name},
                                        ["id","parent_tenant_id"],
                                    )
                    logging.info(f'##tenant_dff {tenant_dff}')
                    logging.info(f'##tenant_dff type {type(tenant_dff)}')
                    if not tenant_dff.empty:
                        parent_tenant_id=tenant_dff["parent_tenant_id"].to_list()[0]
                        tenant_id=tenant_dff["id"].to_list()[0]
                    else:
                        parent_tenant_id=''
                        tenant_id=''
                    logging.info(f'##parent_tenant_id {parent_tenant_id}')
                    logging.info(f'##tenant_id {tenant_id}')
                    if parent_tenant_id:
                        sub_tanant_df = db.get_data(
                                        "tenant",
                                        {"tenant_name": tenant_name},
                                        ["id","tenant_name"]
                                    )
                        if not sub_tanant_df.empty:
                            id_list=sub_tanant_df["id"].to_list()
                            name_list=sub_tanant_df["tenant_name"].to_list()
                            sub_tanant = dict(zip(id_list, name_list))
                        else:
                            sub_tanant=[]
                    else:
                        sub_tanant_df = db.get_data(
                                        "tenant",
                                        {"parent_tenant_id": parent_tenant_id},
                                        ["id","tenant_name"]
                                    )
                        if not sub_tanant_df.empty:
                            id_list=sub_tanant_df["id"].to_list()
                            name_list=sub_tanant_df["tenant_name"].to_list()
                            sub_tanant = dict(zip(id_list, name_list))
                        else:
                            sub_tanant=[]
                    logging.info(f'##sub_tanant {sub_tanant}')
                except Exception as e:
                    logging.info(f'###Error occurec {e}')
                    sub_tanant=[]
                module_data["sub_tanant"] = sub_tanant
            # formating data for Partner users
            if module == "Partner users":
                result_dict = {}

                roles = db.get_data(
                    "roles", {"is_active": "True"}, ["role_name", "tenant_id"]
                ).to_dict(orient="records")
                tenants_df = db.get_data(
                    "tenant", {"is_active": "True"}, ["tenant_name", "id"]
                ).to_dict(orient="records")
                tenants = {}
                for tenant in tenants_df:
                    tenants[tenant["id"]] = tenant["tenant_name"]
                out_roles = {}
                for role_item in roles:
                    if role_item["tenant_id"] in tenants:
                        if tenants[role_item["tenant_id"]] not in out_roles:
                            out_roles[tenants[role_item["tenant_id"]]] = []
                        out_roles[tenants[role_item["tenant_id"]]].append(
                            role_item["role_name"]
                        )
                module_data["role_name"] = out_roles

                # Sort module_data['tenant'] by tenant_name
                sorted_tenants = sorted(
                    module_data["tenant"], key=lambda x: x["tenant_name"]
                )

                if tenant_name != "Altaworx Test":
                    user_df = db.get_data(
                        "users", {"tenant_name": tenant_name}, ["is_active", "migrated"]
                    ).to_dict(orient="records")
                else:
                    user_df = db.get_data(
                        "users", {"tenant_name": "Altaworx"}, ["is_active", "migrated"]
                    ).to_dict(orient="records")

                for d in sorted_tenants:
                    tenant_id = d["id"]
                    tenant_name = d["tenant_name"]
                    parent_id = d["parent_tenant_id"]
                    sub_temp = []
                    if parent_id == "None":
                        for di in sorted_tenants:
                            if di["parent_tenant_id"] != "None" and float(
                                di["parent_tenant_id"]
                            ) == float(tenant_id):
                                sub_temp.append(di["tenant_name"])
                        # Sort sub_temp in alphabetical order
                        result_dict[tenant_name] = sorted(sub_temp)
                # Update module_data with the sorted result_dict
                module_data["tenant"] = result_dict

                total_count = len(user_df)
                active_user_count = 0
                migrated_count = 0
                for user in user_df:
                    if user["is_active"]:
                        active_user_count = active_user_count + 1
                    if user["migrated"]:
                        migrated_count = migrated_count + 1
                module_data["total_count"] = total_count
                module_data["active_user_count"] = active_user_count
                module_data["migrated_count"] = migrated_count

            # final addition of modules data into the retuting dict
            returning_partner_module_data[module] = convert_timestamp_data(
                module_data, tenant_time_zone
            )
            returning_partner_module_data["pages"] = counts
            # returning_partner_module_data = convert_timestamp_data_dictionary(returning_partner_module_data, tenant_time_zone=tenant_time_zone)

        # calling get header to get headers mapping
        headers_map = get_headers_mapping(
            tenant_database,
            modules_list,
            role,
            username,
            tenant_id,
            sub_parent_module,
            parent_module,
            data,
            db,
        )
        message = "partner data fetched successfully"
        # if "Customer groups" in modules_list:
        #     returning_partner_module_data = convert_timestamp_datadict(returning_partner_module_data, tenant_time_zone=tenant_time_zone)
        if "Partner users" in modules_list:
            returning_partner_module_data = convert_timestamp_data_dictionary(
                returning_partner_module_data, tenant_time_zone=tenant_time_zone
            )
        if module == "Customer groups":
            pop_up = header_map['Customer groups']['pop_up']
            # Sort the pop_up list based on 'id' in ascending order
            pop_up.sort(key=lambda x: x['id'])
            header_map['Customer groups']['pop_up'] = pop_up
        response = {
            "flag": True,
            "data": serialize_data(returning_partner_module_data),
            "headers_map": headers_map,
            "message": message,
        }
        # End time calculation
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        try:
            audit_data_user_actions = {
                "service_name": "Module Management",
                "created_date": start_time,
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": message,
                "module_name": "get_partner_info",
                "request_received_at": request_received_at,
            }
            db.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.exception(f"Exception is {e}")
        return response
    except Exception as e:
        logging.exception(f"Something went wrong and error is {e}")
        message = "Something went wrong while fetching Partner info"
        response = {"flag": True, "message": message}
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "Module Management",
                "created_date": start_time,
                "error_message": message,
                "error_type": error_type,
                "users": username,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": "",
                "module_name": "get_partner_info",
                "request_received_at": request_received_at,
            }
            db.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"Exception is {e}")
        return response


def convert_timestamp_data_dictionary(
    df_dict, tenant_time_zone, timestamp_columns=None
):
    logging.info("Started converting timestamps...")

    try:
        if timestamp_columns is None:
            timestamp_columns = [
                "created_date",
                "modified_date",
                "deleted_date",
                "processed_date",
                "last_login",
                "date_added",
                "date_activated",
                "run_start_time",
                "session_created_date",
            ]

        utc_timezone = timezone("UTC")

        def process_record(record):
            if isinstance(record, dict):
                # Extract timezone from the user data or use tenant_time_zone as fallback
                user_timezone = record.get("timezone", tenant_time_zone)
                try:
                    if user_timezone:
                        target_timezone = timezone(user_timezone)
                    else:
                        target_timezone = timezone(tenant_time_zone)
                except UnknownTimeZoneError:
                    # Handle unknown timezones by falling back to the tenant's default timezone
                    logging.exception(
                        f"Unknown timezone '{user_timezone}', falling back to tenant timezone."
                    )
                    target_timezone = timezone(tenant_time_zone)

                for col in timestamp_columns:
                    if col in record:
                        try:
                            if record[col] in ["None", None, ""]:
                                record[col] = None
                                continue

                            # Parse timestamp string to datetime
                            timestamp = pd.to_datetime(record[col], errors="coerce")

                            if pd.notna(timestamp):
                                if timestamp.tzinfo is None:
                                    timestamp = timestamp.tz_localize(utc_timezone)
                                timestamp = timestamp.tz_convert(target_timezone)
                                record[col] = timestamp.strftime("%m-%d-%Y %I:%M:%S %p")
                            else:
                                logging.info(
                                    f"Column '{col}' could not be parsed or is invalid: {record[col]}"
                                )
                        except Exception as e:
                            logging.exception(
                                f"Error processing column '{col}': {record[col]} - {e}"
                            )
            return record

        def traverse_data(data):
            if isinstance(data, list):
                return [traverse_data(item) for item in data]
            elif isinstance(data, dict):
                for key, value in data.items():
                    if isinstance(value, list):
                        data[key] = [process_record(item) for item in value]
                    elif isinstance(value, dict):
                        data[key] = traverse_data(value)
                return data
            return data

        processed_data = traverse_data(df_dict)
        return processed_data

    except Exception as e:
        logging.exception(f"Error in conversion process: {e}")


def create_module_access_info(data):
    """Processes role-based access data to generate a dictionary with module,
    submodule, and feature information.

    Args:
        data (dict): Dictionary containing roles as keys and their
        corresponding modules and features as values.

    Returns:
        dict: A dictionary with roles as keys
        and JSON-encoded strings of modules, submodules, and features as values.
    """
    return_dict = {}
    modules_list = []
    submodules_list = {}
    features_dict = {}
    # Iterate over each role and its associated features
    for role, user_features in data.items():
        logging.info("Processing role: %s", role)
        # logging.info(user_features)
        for main_module, content in user_features.items():
            logging.info("Main module: %s, Content: %s", main_module, content)
            modules_list.append(main_module)
            submodules_list[main_module] = content["Module"]
            # Initialize the features dictionary for the current main module
            features_dict[main_module] = {}
            features = content["Feature"]
            # Iterate over each submodule of the main module
            for submodule in content["Module"]:
                if submodule in features:
                    features_dict[main_module][submodule] = features[submodule]
        # Store the processed data for the current role
        return_dict[role] = {
            "module": json.dumps(modules_list),
            "sub_module": json.dumps(submodules_list),
            "module_features": json.dumps(features_dict),
        }
    logging.info("Final return dictionary: %s", return_dict)
    # Return the final dictionary with role-based access information
    return return_dict


def generate_hash(password, salt):
    """
    Generates a hash for the given password and salt using SHA1.
    The encoding is designed to match C# Unicode encoding.
    """
    combined = (password + salt).encode("utf-16-le")
    hash_object = hashlib.sha1(combined)
    return base64.b64encode(hash_object.digest()).decode("utf-8")


def add_username(username, password):
    """
    Authenticates a user by sending a POST request to the authentication endpoint with the username and password.
    """
    try:
        # url = 'https://sandbox-device-api.amop.services/api/auth/update-password'
        url = os.getenv("ZITADEL_USERNAME", " ")
        data = {"username": username, "password": password}
        headers = {
            "x-api-key": "IiI1IV82XAsdkfPFQpqWFLLvQAiWR0xB",
        }
        response = requests.post(url, json=data, headers=headers)
        logging.info(response.status_code)
    except Exception as e:
        logging.exception(f"Exception is {e}")
        return {
            "flag": False,
            "message": "Something went wrong fetching sessionid and sessiontoken using Zitadel",
        }


def update_partner_info(data):
    """Updates partner information in the database based on provided data and
    performs various operations such as validation, updating, or inserting
    records in different modules.

    Args:
        data (dict): Dictionary containing details such as Partner,
                     request timestamps, session IDs,
                     access tokens, and other data needed for updating or inserting records.

    Returns:
        dict: Response indicating the success or
        failure of the operation with a message.
    """
    logging.info(f"Request Data: {data}")
    Partner = data.get("Partner", "")
    ##Restriction Check for the Amop API's
    try:
        # Create an instance of the PermissionManager class
        permission_manager_instance = PermissionManager(db_config)

        # Call the permission_manager method with the data dictionary and validation=True
        result = permission_manager_instance.permission_manager(data, validation=True)

        # Check the result and handle accordingly
        if isinstance(result, dict) and result.get("flag") is False:
            logging.warning("Permission check failed: %s", result)
            return result
        else:
            # Continue with other logic if needed
            pass
    except Exception:
        logging.warning("got exception in the restriction")

    request_received_at = data.get("request_received_at", "")
    session_id = data.get("session_id", "")
    ##database connection
    # Start time  and date calculation
    start_time = time.time()
    username = data.get("username", None)
    tenant_name = data.get("tenant_name", None)
    updated_data_ui = data.get("changed_data", [])
    session_id = data.get("session_id", None)
    where_dict = data.get("where_dict", {})
    role = data.get("role_name", None)
    action = data.get("action", None)
    module_name = data.get("module_name", None)
    list_view_id = data.get("list_view_id", "")
    module_name = module_name.lower()
    template_name = data.get("template_name", "Create User")
    # database Connection
    tenant_database = data.get("db_name", None)
    database = DB(tenant_database, **db_config)
    db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    try:
        # Fetch tenant ID based on tenant name
        tenant_id = db.get_data("tenant", {"tenant_name": tenant_name}, ["id"])[
            "id"
        ].to_list()[0]
        # Prepare updated data for database operations
        updated_data = {}
        for key, value in updated_data_ui.items():
            if type(value) != str:
                updated_data[key] = json.dumps(value)
            elif value == "None" or value == "":
                updated_data[key] = None
            else:
                updated_data[key] = value
        # Remove 'id' field if present and module_name is not 'customer groups'
        if "id" in updated_data and module_name != "customer groups":
            updated_data.pop("id")
        # Perform database operations based on the module_name and action
        if module_name == "partner info":
            where_dict = {"tenant_name": tenant_name}
            if action in ("update", "delete"):
                db.update_dict("tenant", updated_data, where_dict)
            elif action == "create":
                tenant_id = db.insert_data(updated_data, "tenant")

        if module_name == "partner module access":
            if action in ("update", "delete"):
                role_module_acess = create_module_access_info(updated_data_ui)
                for role, value_dict in role_module_acess.items():
                    where_dict = {"role": role}
                    db.update_dict("role_module", value_dict, where_dict)
            elif action == "create":
                role_module_acess = create_module_access_info(updated_data_ui)
                for role, value_dict in role_module_acess.items():
                    value_dict["role"] = role
                    db.insert_data(value_dict, "role_module")

        if module_name == "customer groups":
            if action == "update" or action == "delete":
                if "id_10" in updated_data:
                    updated_data.pop("id_10")
                if "tenant_id" in updated_data:
                    updated_data.pop("tenant_id")
                where_dict = {"id": updated_data["id"]}
                database.update_dict("customergroups", updated_data, where_dict)
            elif action == "create":
                if "id" in updated_data:
                    updated_data.pop("id")
                if "modified_date" in updated_data:
                    updated_data.pop("modified_date")
                database.insert_data(updated_data, "customergroups")

        if module_name == "partner users":
            if "tenant_id" in updated_data and updated_data["tenant_id"]:
                updated_data["tenant_id"] = str(int(float(updated_data["tenant_id"])))

            if action == "delete":
                db.update_dict(
                    "users", updated_data, {"username": updated_data["username"]}
                )
            elif action == "delete_":
                db.delete_data(
                    "users", and_conditions={"id": updated_data_ui.get("id")}
                )

            elif action == "update":
                customer_info = updated_data.get("customer_info")
                try:
                    customer_info = json.loads(customer_info)
                except Exception as e:
                    logging.warning(f"Exception is {e}")

                if customer_info:
                    db_customer_info = {}

                    for key, value in customer_info.items():
                        # logging.info(value,'value')
                        if type(value) != str:
                            db_customer_info[key] = json.dumps(value)
                        elif value == "None":
                            db_customer_info[key] = None
                        elif value == "true":
                            db_customer_info[key] = True
                        elif value == "false":
                            db_customer_info[key] = False
                        else:
                            db_customer_info[key] = value
                    username_to_update = db_customer_info.get("username")
                    db.update_dict(
                        "users",
                        db_customer_info,
                        {"username": username_to_update},
                    )

                user_update = updated_data.get("user_info")
                try:
                    user_update = json.loads(user_update)
                except Exception as e:
                    logging.warning(f"Exception is {e}")
                if user_update:
                    db_user_update = {}
                    for key, value in user_update.items():
                        if type(value) != str:
                            db_user_update[key] = json.dumps(value)
                        elif value == "None":
                            db_user_update[key] = None
                        elif str(value).lower() == "true":
                            db_user_update[key] = True
                        elif str(value).lower() == "false":
                            db_user_update[key] = False
                        else:
                            db_user_update[key] = value
                    try:
                        tenant_name_update=db_user_update['tenant_name']
                        previous_tenant=data.get('changed_tenant','')

                        changed_tenant_id = db.get_data('tenant', {'tenant_name': previous_tenant}, ['id'])['id'].to_list()[0]
                        user_name_update=db_user_update['username']

                        tenant_id = db.get_data('tenant', {'tenant_name': tenant_name_update}, ['id'])['id'].to_list()[0]
                        logging.info(f"previous tenant {previous_tenant}, previous_tenant_id {changed_tenant_id}",)
                        db.update_dict(
                                "user_module_tenant_mapping",
                                {"tenant_id": int(tenant_id)},
                                {"user_name": user_name_update,"tenant_id":int(changed_tenant_id)},
                            )
                    except Exception as e:
                        logging.warning(f"Exception while updating user_module_tenant_mapping {e}")
                    try:
                        sub_partner_names=data.get('sub_partner_names',[])
                        user_name_insert=db_user_update['username']
                        if sub_partner_names:
                            logging.info('sub_partner_names',sub_partner_names)
                            # Handle single-item tuples correctly
                            sub_partner_names_tuple = f"({', '.join(map(repr, sub_partner_names))})" if len(sub_partner_names) > 1 else f"('{sub_partner_names[0]}')"

                            sub_partner_ids_query = f'''SELECT id FROM tenant WHERE tenant_name IN {sub_partner_names_tuple}'''
                            logging.info("Executing Query:", sub_partner_ids_query)  # Debugging

                            # Execute query to get tenant IDs
                            sub_partner_ids = db.execute_query(sub_partner_ids_query, True)

                            # Convert DataFrame to list of dictionaries if needed
                            if hasattr(sub_partner_ids, "to_dict"):
                                sub_partner_ids = sub_partner_ids.to_dict(orient="records")

                            if isinstance(sub_partner_ids, list) and all(isinstance(row, dict) for row in sub_partner_ids):
                                tenant_ids = [row['id'] for row in sub_partner_ids]

                                # Ensure correct formatting for SQL (avoid single-element tuple issues)
                                if tenant_ids:
                                    tenant_ids_tuple = f"({', '.join(map(str, tenant_ids))})"

                                    # Query to get already existing tenant IDs
                                    sub_tenant_query = f'''SELECT tenant_id FROM user_module_tenant_mapping WHERE tenant_id IN {tenant_ids_tuple} and user_name='{user_name_insert}'
                                    '''
                                    existing_tenant_ids_result = db.execute_query(sub_tenant_query,True)
                                    logging.info('existing_tenant_ids_result',existing_tenant_ids_result)
                                    # Convert DataFrame to list of dictionaries if needed
                                    if hasattr(existing_tenant_ids_result, "to_dict"):
                                        existing_tenant_ids_result = existing_tenant_ids_result.to_dict(orient="records")

                                    existing_tenant_ids = [row['tenant_id'] for row in existing_tenant_ids_result] if isinstance(existing_tenant_ids_result, list) else []

                                    # Filter out exissting tenant IDs
                                    new_tenant_ids = [tid for tid in tenant_ids if tid not in existing_tenant_ids]
                                    logging.info('new_tenant_ids',new_tenant_ids)
                                    for tenant_id in new_tenant_ids:
                                        sub_tenant_data = {
                                            "tenant_id": tenant_id,
                                            "user_name": user_name_insert,
                                        }
                                        try:
                                            db.insert_data(sub_tenant_data, "user_module_tenant_mapping")
                                        except Exception as e:
                                            print(f"Error inserting data: {e}")

                                    if not new_tenant_ids:
                                        logging.info("All tenant IDs already exist in user_module_tenant_mapping. No new inserts.")
                                else:
                                    logging.info("No valid tenant IDs found.")
                            else:
                                logging.info("Unexpected query result format:", sub_partner_ids)
                        else:
                            logging.info("No sub-partner names provided.")
                    except Exception as e:
                        logging.info(f"Exception while inserting user_module_tenant_mapping {e}")


                    db.update_dict(
                        "users",
                        db_user_update,
                        {"id": int(list_view_id)},
                    )

                user_modules_update = updated_data.get("data")
                try:
                    user_modules_update = json.loads(user_modules_update)
                except Exception as e:
                    logging.warning(f"Exception is {e}")
                if user_modules_update:
                    tenant_id = db.get_data(
                        "tenant",
                        {"tenant_name": updated_data["Selected Partner"]},
                        ["id"],
                    )["id"].to_list()[0]
                    user_module_acess = create_module_access_info(user_modules_update)
                    db.update_dict(
                        "users",
                        {"modified_by": username},
                        {"user_name": updated_data["Username"]},
                    )
                    # logging.info(user_module_acess,updated_data)
                    for user, value_dict in user_module_acess.items():
                        value_dict["module_names"] = value_dict["module"]
                        value_dict.pop("module")
                        db.update_dict(
                            "user_module_tenant_mapping",
                            value_dict,
                            {
                                "tenant_id": tenant_id,
                                "user_name": updated_data["Username"],
                            },
                        )

            elif action == "create":
                user_update = updated_data.get("user_info")

                try:
                    user_update = json.loads(user_update)
                    tenant = user_update.get("tenant_name")
                    tenant_id = db.get_data("tenant", {"tenant_name": tenant}, ["id"])[
                        "id"
                    ].to_list()[0]
                except Exception as e:
                    logging.warning(f"Exception is {e}")

                user = user_update["username"]
                out = db.get_data("users", {"username": user}, ["username"])
                if not out.empty:
                    return {
                        "flag": False,
                        "error_type": "Warning",
                        "message": "Username is already taken, Please Update Username",
                    }

                email = user_update.get("email", "")
                email_username = user_update.get("username", "")
                tenants_list = []
                tenants_list.append(user_update["tenant_name"])
                #tenants_list.extend(user_update["subtenant_name"])

                for tenant_name in tenants_list:
                    tenant_id = db.get_data(
                        "tenant", {"tenant_name": tenant_name}, ["id"]
                    )["id"].to_list()[0]
                    db_user = {
                        "tenant_id": tenant_id,
                        "user_name": user_update["username"],
                    }
                    db.insert_data(db_user, "user_module_tenant_mapping")
                try:
                    sub_partner_names=data.get('sub_partner_names',[])
                    user_name_insert=user_update.get("username", "")
                    if sub_partner_names:
                        # Handle single-item tuples correctly
                        sub_partner_names_tuple = tuple(sub_partner_names) if len(sub_partner_names) > 1 else f"('{sub_partner_names[0]}')"

                        sub_partner_ids_query = f'''SELECT distinct id FROM tenant WHERE tenant_name IN {sub_partner_names_tuple} and is_active=True'''
                        logging.info("Executing Query:", sub_partner_ids_query)  # Debugging

                        # Execute query
                        sub_partner_ids = db.execute_query(sub_partner_ids_query, True)

                        # Check if it's a DataFrame-like object (common case)
                        if hasattr(sub_partner_ids, "to_dict"):
                            sub_partner_ids = sub_partner_ids.to_dict(orient="records")  # Convert to list of dicts

                        # Ensure result is a list of dictionaries
                        if isinstance(sub_partner_ids, list) and all(isinstance(row, dict) for row in sub_partner_ids):
                            tenant_ids = [row['id'] for row in sub_partner_ids]  # Extract IDs safely

                            for tenant_id in tenant_ids:
                                sub_tenant_data = {
                                    "tenant_id": tenant_id,
                                    "user_name": user_name_insert,
                                }
                                db.insert_data(sub_tenant_data, "user_module_tenant_mapping")
                        else:
                            logging.info("Unexpected query result format:", sub_partner_ids)
                    else:
                        logging.info("No sub-partner names provided.")
                except Exception as e:
                    logging.info(f"Exception while inserting user_module_tenant_mapping {e}")
                if user_update:

                    db_user_update = {}
                    for key, value in user_update.items():
                        if key == "password":
                            salt = os.urandom(16).hex()
                            hashed_password = generate_hash(value, salt)
                            db_user_update[key] = hashed_password
                            db_user_update["salt"] = salt
                        elif type(value) != str:
                            db_user_update[key] = json.dumps(value)
                        elif value == "None":
                            db_user_update[key] = None
                        else:
                            db_user_update[key] = value

                    add_username(
                        user_update.get("username"), user_update.get("password")
                    )

                    db_user_update["tenant_id"] = tenant_id
                    db.insert_data(db_user_update, "users")
                    to_email = db.get_data("users", {"username": username}, ["email"])[
                        "email"
                    ].to_list()[0]
                    try:
                        db.update_dict(
                            "email_templates",
                            {
                                "last_email_triggered_at": request_received_at,
                                "to_mail": email,
                            },
                            {"template_name": template_name},
                        )

                        # Call send_email and assign the result to 'result'
                        result = send_email(
                            template_name,
                            username=email_username,
                            user_mail=to_email,
                            is_html=True,
                        )
                    except:
                        pass

                    # Check the result and handle accordingly
                    if isinstance(result, dict) and result.get("flag") is False:
                        logging.info(result)
                    else:
                        # Continue with other logic if needed
                        (
                            to_emails,
                            cc_emails,
                            subject,
                            body,
                            from_email,
                            partner_name,
                        ) = result
                        # to_emails,cc_emails,subject,body,from_email,partner_name=
                        # send_email(template_name,username=username,user_mail=to_email)
                        db.update_dict(
                            "email_templates",
                            {"last_email_triggered_at": request_received_at},
                            {"template_name": template_name},
                        )
                        query = """
                            SELECT parents_module_name, sub_module_name,
                              child_module_name, partner_name
                            FROM email_templates
                            WHERE template_name = %s
                        """

                        params = [template_name]
                        # Execute the query with template_name as the parameter
                        email_template_data = db.execute_query(query, params=params)
                        if not email_template_data.empty:
                            # Unpack the results
                            (
                                parents_module_name,
                                sub_module_name,
                                child_module_name,
                                partner_name,
                            ) = email_template_data.iloc[0]
                        else:
                            # If no data is found, assign default values or log an error
                            parents_module_name = ""
                            sub_module_name = ""
                            child_module_name = ""
                            partner_name = ""

                        try:
                            ##email audit
                            email_audit_data = {
                                "template_name": template_name,
                                "email_type": "Application",
                                "partner_name": partner_name,
                                "email_status": "success",
                                "from_email": from_email,
                                "to_email": to_emails,
                                "cc_email": cc_emails,
                                "comments": "update inventory data",
                                "subject": subject,
                                "body": body,
                                "role": role,
                                "action": "Email triggered",
                                "parents_module_name": parents_module_name,
                                "sub_module_name": sub_module_name,
                                "child_module_name": child_module_name,
                            }
                            db.update_audit(email_audit_data, "email_audit")
                        except:
                            pass
                    message = "mail sent sucessfully"
                    # End time calculation
                    end_time = time.time()
                    time_consumed = end_time - start_time
                    try:
                        # Email audit
                        email_audit_data = {
                            "template_name": template_name,
                            "email_type": "Send Grid",
                            "partner_name": partner_name,
                            "email_status": "success",
                            "from_email": from_email,
                            "to_email": to_emails,
                            "cc_email": cc_emails,
                            "comments": "Account creation confirmation",
                            "subject": subject,
                            "body": body,
                            "role": role,
                            "action_performed": "account creation confirmation",
                        }
                        db.update_audit(email_audit_data, "email_audit")
                    except Exception as e:
                        logging.warning(f"Exception during audit logging: {e}")
        message = "Updated sucessfully"
        response = {"flag": True, "message": message}
        # End time calculation
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))
        try:
            audit_data_user_actions = {
                "service_name": "Module Management",
                "created_date": request_received_at,
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": json.dumps(updated_data_ui),
                "module_name": "update_partner_info",
                "request_received_at": request_received_at,
            }
            db.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Exception is {e}")
        return response
    except Exception as e:
        logging.exception(f"Something went wrong {e}")
        message = "Something went wrong while updating Partner info"
        response = {"flag": False, "message": message}
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "Module Management",
                "created_date": request_received_at,
                "error_message": message,
                "error_type": error_type,
                "users": username,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": message,
                "module_name": "update_partner_info",
                "request_received_at": request_received_at,
            }
            db.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"Exception is {e}")
        return response


# Function to convert Timestamps to strings
def convert_timestamps(obj):
    """
    Recursively converts pandas Timestamp objects in the given object
    (dictionary, list, or other types) into a human-readable string format
    'MM-DD-YYYY HH:MM:SS'. Other data types are returned unchanged.

    Args:
        obj: The input object, which can be a dictionary, list, pandas.Timestamp,
             or any other data type.

    Returns:
        The processed object with all pandas.Timestamp instances converted
        to string format.
    """
    logging.info("Converting timestamps in the object: %s", obj)
    if isinstance(obj, dict):
        logging.info("Processing a dictionary.")
        return {k: convert_timestamps(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        logging.info("Processing a list with %d elements.", len(obj))
        return [convert_timestamps(elem) for elem in obj]
    elif isinstance(obj, pd.Timestamp):
        logging.info("Converting pandas Timestamp: %s", obj)
        return obj.strftime("%m-%d-%Y %H:%M:%S")
    logging.info("No conversion applied for object: %s", obj)
    return obj


def dataframe_to_blob(data_frame):
    """Description:The Function is used to convert the dataframe to blob."""
    logging.info("Converting DataFrame to blob.")
    # Create a BytesIO buffer
    bio = BytesIO()

    # Use ExcelWriter within a context manager to ensure proper saving
    with pd.ExcelWriter(bio, engine="openpyxl") as writer:
        logging.info("Writing DataFrame to Excel.")
        data_frame.to_excel(writer, index=False)

        # Apply styles to the header row
        sheet = writer.sheets["Sheet1"]
        for cell in sheet[1]:
            cell.alignment = Alignment(
                horizontal="center", vertical="center"
            )  # Center align
            cell.fill = PatternFill(
                start_color="D3D3D3", end_color="D3D3D3", fill_type="solid"
            )  # Grey background

        # Adjust column widths based on content
        for col_idx, col_cells in enumerate(sheet.columns, 1):
            max_length = max(len(str(cell.value or "")) for cell in col_cells)
            sheet.column_dimensions[get_column_letter(col_idx)].width = max_length + 2

        logging.info("DataFrame written to Excel successfully.")

    # Get the value from the buffer
    bio.seek(0)
    blob_data = base64.b64encode(bio.read())
    logging.info("DataFrame converted to blob successfully.")

    return blob_data


def export(data, max_rows=500):
    """
    Exports data from a database into an Excel file while enforcing a row limit.

    The function processes input data to retrieve relevant database queries based on the
    module name,
    executes the query, formats the results, and converts them into a blob representation if the row
    count is within the specified limit. The function also audits user actions and logs errors
    to a database if an exception occurs.

    Args:
        data (dict): Request data containing parameters such as 'Partner', 'module_name',
                     'start_date', 'end_date', 'user_name', 'session_id', and 'db_name'.
        max_rows (int): The maximum allowed number of rows for export. Defaults to 500.

    Returns:
        dict: A JSON response with the status (`flag`), a message, and the blob data if successful.

    Raises:
        Exception: Captures and logs all errors that occur during execution.
    """
    # logging.info the request data for debugging
    logging.info(f"Request Data: {data}")
    ### Extract parameters from the Request Data
    Partner = data.get("Partner", "")
    request_received_at = data.get("request_received_at", None)
    module_name = data.get("module_name", "")
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")
    user_name = data.get("user_name", "")
    session_id = data.get("session_id", "")
    tenant_database = data.get("db_name", "")
    ids = data.get("ids", "")
    ##database connection for common utilss
    db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    logging.info(f"Fetching export query for module: {module_name}")
    # Start time  and date calculation
    start_time = time.time()
    try:
        ##databse connenction
        database = DB(tenant_database, **db_config)
        # Fetch the query from the database based on the module name
        module_query_df = db.get_data("export_queries", {"module_name": module_name})
        # logging.info(module_query_df,'module_query_df')
        ##checking the dataframe is empty or not
        if module_query_df.empty:
            return {
                "flag": False,
                "message": f"No query found for module name: {module_name}",
            }
        # Extract the query string from the DataFrame
        query = module_query_df.iloc[0]["module_query"]
        if not query:
            logging.warning(f"Unknown module name: {module_name}")
            return {"flag": False, "message": f"Unknown module name: {module_name}"}
        ##params for the specific module
        if module_name in ("inventory status history", "bulkchange status history"):
            params = [ids]
        else:
            params = [start_date, end_date]
        if module_name == "Users":
            data_frame = db.execute_query(query, params=params)
        else:
            data_frame = database.execute_query(query, params=params)
        # Check the number of rows in the DataFrame
        row_count = data_frame.shape[0]
        # logging.info(row_count,'row_count')
        ##checking the max_rows count
        if row_count > max_rows:
            return {
                "flag": False,
                "message": f"Cannot export more than {max_rows} rows.",
            }
        if module_name == "NetSapiens Customers":
            data_frame["NetSapiensType"] = "Reseller"
        # Capitalize each word and add spaces
        data_frame.columns = [
            col.replace("_", " ").capitalize() for col in data_frame.columns
        ]
        data_frame["S.No"] = range(1, len(data_frame) + 1)
        # Reorder columns dynamically to put S.NO at the first position
        columns = ["S.No"] + [col for col in data_frame.columns if col != "S.No"]

        # Format specific columns with dollar symbol for "Rate Plan Socs" module
        if module_name == "Rate Plan Socs":
            if "Overage dollar mb" in data_frame.columns:
                data_frame["Overage dollar mb"] = data_frame["Overage dollar mb"].apply(
                    lambda x: f"${x}"
                )
            if "Base rate" in data_frame.columns:
                data_frame["Base rate"] = data_frame["Base rate"].apply(
                    lambda x: f"${x}"
                )

        if module_name == "Customer Rate Plan":
            # Check if "Id" column exists in data_frame
            if "Id" in data_frame.columns:
                try:
                    # Convert all "Id" values into a list for a single query
                    ids_list = data_frame["Id"].tolist()

                    # Use a single SQL query to get the counts for each ID at once
                    count_query = """
                        SELECT customer_rate_plan_id, COUNT(*) AS count
                        FROM sim_management_inventory
                        WHERE customer_rate_plan_id IN %s
                        GROUP BY customer_rate_plan_id
                    """

                    # Execute the single query with the list of IDs
                    count_results = database.execute_query(
                        count_query, params=(tuple(ids_list),)
                    )

                    # Convert the count results to a dictionary for quick lookup
                    tn_counts_dict = {
                        int(row["customer_rate_plan_id"]): row["count"]
                        for _, row in count_results.iterrows()
                    }

                    # Map counts back to the DataFrame
                    data_frame["# of TNs"] = (
                        data_frame["Id"]
                        .map(tn_counts_dict)
                        .fillna(0)
                        .astype(int)
                        .astype(str)
                    )
                    columns.append("# of TNs")
                    columns.remove("Id")

                except Exception as e:
                    logging.exception(
                        f"Failed to retrieve count for Customer Rate Plan: {e}"
                    )
                    return {
                        "flag": False,
                        "message": f"An error occurred while fetching count for Rate Plan: {e}",
                    }

        data_frame = data_frame[columns]
        # Proceed with the export if row count is within the allowed limit
        data_frame = data_frame.astype(str)
        data_frame.replace(to_replace="None", value="", inplace=True)
        logging.info("Converting DataFrame to blob.")

        blob_data = dataframe_to_blob(data_frame)
        # End time calculation
        end_time = time.time()
        time_consumed = f"{end_time - start_time:.4f}"
        time_consumed = int(float(time_consumed))

        # Return JSON response
        response = {"flag": True, "blob": blob_data.decode("utf-8")}
        audit_data_user_actions = {
            "service_name": "Module Management",
            "created_date": request_received_at,
            "created_by": user_name,
            "status": str(response["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": "",
            "module_name": "export",
            "request_received_at": request_received_at,
        }
        db.update_audit(audit_data_user_actions, "audit_user_actions")
        logging.info("Auditing user actions.")
        return response
    except Exception as e:
        error_type = str(type(e).__name__)
        logging.exception(f"An error occurred: {e}")
        message = f"Error is {e}"
        response = {"flag": False, "message": message}
        try:
            # Log error to database
            error_data = {
                "service_name": "Module Management",
                "created_date": request_received_at,
                "error_message": message,
                "error_type": error_type,
                "users": user_name,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": message,
                "module_name": "export",
                "request_received_at": request_received_at,
            }
            db.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"Exception is {e}")
        return response


def rate_plan_dropdown_data_optimization_groups(data):
    """
    Retrieves active rate plan codes grouped by service provider.

    Args:
        data (dict): Input dictionary containing the tenant database name.
            - db_name (str): The name of the tenant database.

    Returns:
        dict: A dictionary containing a success flag and the rate plans list.
            - flag (bool): Indicates whether the operation was successful.
            - rate_plans_list (dict): A dictionary where keys are service provider names
              and values are lists of active rate plan codes.
    """

    logging.info(f"Request Data is {data}")
    tenant_database = data.get("db_name", None)
    database = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    env=os.environ["ENV"]
    if env=='PROD':
        service_provider_names = ["AT&T - Telegence"]
    else:
        service_provider_names = ["AT&T - Telegence - UAT ONLY"]
    # Initialize an empty dictionary to store the results
    rate_plans_list = {}
    # Iterate over each service provider name
    for service_provider_name in service_provider_names:
        # Get the rate plan codes for the current service provider name
        rate_plan_items = database.get_data(
            "carrier_rate_plan",
            {"service_provider": service_provider_name, "is_active": True},
            ["rate_plan_code"],
        )["rate_plan_code"].to_list()
        # Add the result to the dictionary
        rate_plans_list[service_provider_name] = rate_plan_items
    try:
        audit_data_user_actions = {
            "service_name": "Module_management",
            "created_date": data.get("request_received_at", ""),
            "created_by": data.get("username", ""),
            "status": "Success",
            "session_id": data.get("sessionID", ""),
            "tenant_name": data.get("Partner", ""),
            "module_name": "Module_management",
            "comments": "rate_plan_dropdown_data_optimization_groups",
            "request_received_at": data.get("request_received_at", ""),
        }

        common_utils_database.update_audit(
            audit_data_user_actions, "audit_user_actions"
        )
    except Exception as e:
        logging.warning(f"Exception is {e}")

    # Return the resulting dictionary
    return {"flag": True, "rate_plans_list": rate_plans_list}


def get_status_history(data):
    """Retrieves the status history of a SIM management inventory item based on
    the provided ID.

    Parameters:
    - data (dict): Dictionary containing the 'list_view_data_id' for querying the status history.

    Returns:
    - dict: A dictionary containing the status history data, header mapping,
    and a success message or an error message.
    """
    # Start time  and date calculation
    start_time = time.time()
    ##fetching the request data
    list_view_data_id = data.get("list_view_data_id", "")
    session_id = data.get("session_id", "")
    username = data.get("username", "")
    Partner = data.get("Partner", "")
    role_name = data.get("role_name", "")
    list_view_data_id = int(list_view_data_id)
    iccid = data.get("iccid", "")
    request_received_at = data.get("request_received_at", None)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_database = data.get("db_name", "altaworx_central")
    logging.info(f"Received request to get status history for ID: {list_view_data_id}")
    try:
        ##Database connection
        database = DB(tenant_database, **db_config)
        # Fetch status history data from the database
        sim_management_inventory_action_history_dict = database.get_data(
            "sim_management_inventory_action_history",
            {"iccid": iccid},
            [
                "service_provider",
                "iccid",
                "msisdn",
                "customer_account_number",
                "customer_account_name",
                "previous_value",
                "current_value",
                "date_of_change",
                "change_event_type",
                "changed_by",
            ],
        ).to_dict(orient="records")
        logging.info(
            f"""Fetched {len(sim_management_inventory_action_history_dict)}
            records for ID: {list_view_data_id}
            """
        )
        # Handle case where no data is returned
        if not sim_management_inventory_action_history_dict:
            ##Fetching the header map for the inventory status history
            headers_map = get_headers_mapping(
                tenant_database,
                ["inventory status history"],
                role_name,
                "username",
                "main_tenant_id",
                "sub_parent_module",
                "parent_module",
                data,
                common_utils_database,
            )
            logging.info("Status history data fetched successfully.")
            message = "No status history data found for the provided SIM management inventory ID."
            response = {
                "flag": True,
                "status_history_data": [],
                "header_map": headers_map,
                "message": message,
            }
            return response

        # Helper function to serialize datetime objects to strings
        def serialize_dates(data):
            for key, value in data.items():
                if isinstance(value, datetime):
                    data[key] = value.strftime("%m-%d-%Y %H:%M:%S")
            return data

        # Apply date serialization to each record
        sim_management_inventory_action_history_dict = [
            serialize_dates(record)
            for record in sim_management_inventory_action_history_dict
        ]
        ##Fetching the header map for the inventory status history
        headers_map = get_headers_mapping(
            tenant_database,
            ["inventory status history"],
            role_name,
            "username",
            "main_tenant_id",
            "sub_parent_module",
            "parent_module",
            data,
            common_utils_database,
        )
        message = "Status History data Fetched Successfully"
        # Prepare success response
        response = {
            "flag": True,
            "status_history_data": sim_management_inventory_action_history_dict,
            "header_map": headers_map,
            "message": message,
        }
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "Module Management",
                "created_date": request_received_at,
                "created_by": username,
                "status": str(response["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": list_view_data_id,
                "module_name": "Reports",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.exception(f"exception is {e}")
        return response
    except Exception as e:
        logging.exception(f"An error occurred: {e}")
        message = "Unable to fetch the status history data"
        response = {"flag": False, "message": message}
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "update_superadmin_data",
                "created_date": request_received_at,
                "error_message": message,
                "error_type": error_type,
                "users": username,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": "",
                "module_name": "Module Managament",
                "request_received_at": request_received_at,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"exception is {e}")
        return response


def reports_data(data):
    """Retrieve report data and logs audit and error details to the database."""
    # Start time and date calculation
    start_time = time.time()
    module_name = data.get("module_name", "")
    request_received_at = data.get("request_received_at", "")
    session_id = data.get("session_id", "")
    username = data.get("username", None)
    Partner = data.get("Partner", "")
    mod_pages = data.get("mod_pages", {})
    role_name = data.get("role_name", "")
    col_sort = data.get("col_sort", "")
    limit = mod_pages.get("", 100)
    offset = mod_pages.get("start", 0)
    table = data.get("table_name", "")
    tenant_name = data.get("tenant_name", "")
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    return_json_data = {}
    pages = {}

    try:
        tenant_id = common_utils_database.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id"]
        )["id"].to_list()[0]

        if (
            db_config.get("customers") or db_config.get("service_providers")
        ) and module_name in ["Usage By Line Report"]:
            cutomers = list(db_config["customers"])
            try:
                service_provider_ids = list(db_config["service_provider_id"])
                service_provider_ids = [str(i) for i in service_provider_ids]
            except:
                service_provider_ids = []
                logging.exception(f"Exception while fetching service provider ids")
            if cutomers and service_provider_ids:
                query = f"""SELECT * FROM public.fetch_usage_by_service_provider_for_mul(ARRAY{service_provider_ids},ARRAY{cutomers},100,{offset});"""
            elif cutomers:
                query = f"""SELECT * FROM public.fetch_usage_by_service_provider_for_mul(NULL,ARRAY{cutomers},100,{offset});"""
            else:
                query = f"""SELECT * FROM public.fetch_usage_by_service_provider_for_mul(ARRAY{service_provider_ids},NULL,100,{offset});"""
            df = database.execute_query(query, flag=True, no_filter_append=True)

        else:
            module_query_df = common_utils_database.get_data(
                "export_queries", {"module_name": module_name}
            )
            if module_query_df.empty:
                raise ValueError(f"No query found for module name: {module_name}")
            if module_name == "Usage By Line Report":
                p = database.get_data(
                "optimization_setting",
                {},
                ["optino_cross_providercustomer_optimization"],
            ).iloc[0, 0]
                if p == False:
                    query = """
                            SELECT service_provider_display_name,billing_cycle_end_date,iccid,msisdn,foundation_account_number,billing_account_number,customer_rate_pool_name,customer_name,username,carrier_rate_plan,rate_plan_name,integration_id,data_usage_mb,status_display_name,date_activated,tenant_id FROM public.vw_usage_by_line_report  where tenant_id= %s LIMIT %s OFFSET %s
                            """
                else:
                    query = """
                            select service_provider_display_name,billing_cycle_end_date,iccid,msisdn,foundation_account_number,billing_account_number,customer_rate_pool_name,customer_name,username,carrier_rate_plan,rate_plan_name,integration_id,data_usage_mb,status_display_name,date_activated,tenant_id from usp_report_customer_usage_by_line where tenant_id= %s LIMIT %s OFFSET %s
                            """
            else:
                query = module_query_df.iloc[0]["module_query"]
            if not query:
                raise ValueError(f"Unknown module name: {module_name}")

            if module_name in [
                "Usage By Line Report",
                "Customer Rate Pool Usage Report",
                "Zero Usage Report",
                "Newly Activated Report",
            ]:
                params = [tenant_id, limit, offset]
            elif module_name in [

                "Status History Report",

            ]:

                params = [offset]
            else:
                params = [limit, offset]
            # Modify query handling for ORDER BY
            # Modify query handling for ORDER BY
            if col_sort:
                # Remove existing ORDER BY clause
                order_by_pattern = r"\sORDER\s+BY\s+[^)]+(?=\s*LIMIT)"
                query = re.sub(order_by_pattern, "", query, flags=re.IGNORECASE)

                # Extract the single key-value pair
                key, value = list(col_sort.items())[0]
                if key in ("billing_cycle_end_date" "date_activated", "date_of_change"):
                    custom_order_by = f"{key}::TIMESTAMP {value.upper()}"
                else:
                    # Default single-column ORDER BY clause
                    custom_order_by = f"{key} {value.upper()}"

                # Ensure ORDER BY comes before LIMIT and OFFSET
                limit_offset_match = re.search(
                    r"(LIMIT\s+%s\s+OFFSET\s+%s)", query, re.IGNORECASE
                )

                if limit_offset_match:
                    # Replace LIMIT and OFFSET with ORDER BY correctly placed
                    limit_offset_clause = limit_offset_match.group(1)
                    query = query.replace(
                        limit_offset_clause,
                        f"ORDER BY {custom_order_by} {limit_offset_clause}",
                    )
                else:
                    # Append ORDER BY at the end if no LIMIT and OFFSET found
                    query += f" ORDER BY {custom_order_by}"
            logging.info(f"Query to info easily : {query}")
            df = database.execute_query(query, params=params)

        # Adjust dates for specific modules
        if module_name in [
            "Usage By Line Report",
            "Newly Activated Report",
            "Customer Rate Pool Usage Report",
            "Zero Usage Report",
        ]:
            column_name = (
                "billing_cycle_end_date"
                if module_name != "Customer Rate Pool Usage Report"
                else "billing_period_end_date"
            )
            if column_name in df.columns:
                df[column_name] = pd.to_datetime(df[column_name])

                df[column_name] = df[column_name].apply(
                    lambda date: (
                        (date - pd.Timedelta(days=1)).replace(
                            hour=23, minute=59, second=59
                        )
                        if pd.notna(date)
                        and date.time() == pd.Timestamp("00:00:00").time()
                        else date
                    )
                )

        tenant_time_zone = fetch_tenant_timezone(common_utils_database, data)

        # Convert data and map headers
        df_dict = df.to_dict(orient="records")

        try:
            df_dict = convert_timestamp_data(df_dict, tenant_time_zone)
        except Exception as e:
            logging.exception(f"Failed to convert the timezone")
        headers_map = get_headers_mapping(
            tenant_database,
            [module_name],
            role_name,
            "username",
            "main_tenant_id",
            "sub_parent_module",
            "parent_module",
            data,
            common_utils_database,
        )

        # Prepare response data
        return_json_data.update(
            {
                "message": "Successfully generated the report",
                "flag": True,
                "headers_map": headers_map,
                "data": serialize_data(df_dict),
                "pages": pages,
            }
        )

        # End time and audit logging
        end_time = time.time()
        time_consumed = int(end_time - start_time)
        audit_data_user_actions = {
            "service_name": "Module Management",
            "created_date": request_received_at,
            "created_by": username,
            "status": str(return_json_data["flag"]),
            "time_consumed_secs": time_consumed,
            "session_id": session_id,
            "tenant_name": Partner,
            "comments": "Reports data",
            "module_name": "Reports",
            "request_received_at": request_received_at,
        }
        common_utils_database.update_audit(
            audit_data_user_actions, "audit_user_actions"
        )
        return return_json_data

    except Exception as e:
        logging.exception(f"An error occurred: {e}")
        message = "Unable to fetch the reports data"
        headers_map = get_headers_mapping(
            tenant_database,
            [module_name],
            role_name,
            "username",
            "main_tenant_id",
            "sub_parent_module",
            "parent_module",
            data,
            common_utils_database,
        )
        response = {"flag": True, "message": message,"headers_map": headers_map}
        error_type = str(type(e).__name__)
        try:
            error_data = {
                "service_name": "update_superadmin_data",
                "created_date": request_received_at,
                "error_message": message,
                "error_type": error_type,
                "users": username,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": "",
                "module_name": "Module Management",
                "request_received_at": request_received_at,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"Exception while logging error: {e}")
        return response


def convert_booleans(data):
    logging.info(f"Initial data for conversion: {data}")
    for key, value in data.items():
        if isinstance(value, str) and value.lower() == "true":
            data[key] = True
            logging.info(f"Converted '{key}' from string 'true' to boolean True")
        elif isinstance(value, str) and value.lower() == "false":
            data[key] = False
            logging.info(f"Converted '{key}' from string 'false' to boolean False")
        elif isinstance(value, dict):  # Recursively process nested dictionaries
            logging.info(
                f"Found nested dictionary at key '{key}', processing recursively."
            )
            convert_booleans(value)
    return data  # Return the modified dictionary


def get_modules(data):
    """
    Retrieves and formats modules and sub-modules for a tenant and user based on roles, permissions,
    and configurations in the database.

    Args:
        data (dict): Input data containing the following keys:
            - username (str): Username of the user.
            - tenant_name (str): Name of the tenant.
            - session_id (str, optional): Session ID of the user (not used in processing).
            - role_name (str): Role of the user (e.g., "Super Admin").
            - db_name (str, optional): Name of the database (default is empty string).

    Returns:
        dict: A response dictionary containing the following keys:
            - flag (bool): Indicates success of the operation.
            - message (str): Success message.
            - Modules (list): List of formatted module data with parent modules, child modules,
              and sub-children.
            - logo (str): Logo of the tenant.
    """
    # start_time = time.time()
    del db_config['customers']
    del db_config['service_providers']
    del db_config['billing_account_number']
    del db_config['feature_codes']
    del db_config['tenant_ids']
    username = data.get("username", None)
    tenant_name = data.get("tenant_name", None)
    data.get("session_id", None)
    role_name = data.get("role_name", None)
    data.get("db_name", "")
    db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    database = DB("altaworx_central", **db_config)
    tenant_id = db.get_data("tenant", {"tenant_name": tenant_name}, ["id"])[
        "id"
    ].to_list()[0]
    # Step 1: Fetch tenant modules
    tenant_module_query_params = [tenant_name]
    tenant_module_query = """SELECT module_name
                             FROM tenant_module
                             WHERE tenant_name = %s AND is_active = TRUE order by id asc;"""
    tenant_module_dataframe = db.execute_query(
        tenant_module_query, params=tenant_module_query_params
    )

    main_tenant_modules = tenant_module_dataframe["module_name"].to_list()
    logging.info(f"Tenant modules fetched: {main_tenant_modules}")
    user_module_df = db.get_data(
        "user_module_tenant_mapping",
        {"user_name": username, "tenant_id": tenant_id},
        ["module_names", "sub_module"],
    ).to_dict(orient="records")

    # Step 2: Handle modules based on role
    if (role_name.lower() == "super admin") and (
        not user_module_df or not user_module_df[0].get("module_names")
    ):
        # For Super Admin, get all tenant modules
        final_modules = [
            {"module": mod, "sub_module": []} for mod in main_tenant_modules
        ]  # Ensure final_modules is a list of dicts
    else:
        # Fetch role modules for non-super admin
        role_module_data = db.get_data(
            "role_module", {"role": role_name}, ["module", "sub_module"]
        ).to_dict(orient="records")
        # role_module_query=f"select module,sub_module from role_module"
        # role_module_data=db.execute_query(role_module_query,True).to_dict(
        #         orient="records"
        #             )
        # Step 2.1: Deserialize the JSON-like strings if needed
        if role_module_data:
            for item in role_module_data:
                item["module"] = json.loads(
                    item["module"]
                )  # Convert module string to list
                item["sub_module"] = json.loads(
                    item["sub_module"]
                )  # Convert sub_module string to dict

        # Step 3: Filter role modules by tenant modules
        filtered_modules = []
        for module in role_module_data:
            # Iterate over the list of modules
            for mod in module["module"]:
                if mod in main_tenant_modules:
                    filtered_modules.append(
                        {
                            "module": mod,
                            "sub_module": module["sub_module"].get(
                                mod, []
                            ),  # Get sub_modules or empty list if not found
                        }
                    )

        # Step 4: Add filtered modules to final_modules
        final_modules = filtered_modules
        logging.info(f"Final modules after filtering: {final_modules}")

    if not user_module_df or not user_module_df[0].get("module_names"):
        # If no user-specific modules are found, use final_modules as is
        logging.info("No user-specific modules found, using final modules.")
        # Now `final_modules` contains either the filtered data or the entire modules
        # if no filtering was applied.
        logging.info(final_modules, "ghbjklhjgvbjkhvhjlhvbjhb")
        # Transforming the keys
        transformed_data = [
            {"parent_module_name": item["module"], "module_name": item["sub_module"]}
            for item in final_modules  # Use final_modules instead of data
        ]

        # Print the transformed data
        logging.info("transformed_data", transformed_data)
        module_table_df = db.get_data(
            "module",
            {"is_active": True},
            ["module_name", "parent_module_name", "submodule_name"],
            {"id": "asc"},
        ).to_dict(orient="records")

        # Process the data
        formatted_data = format_module_data(
            transformed_data, main_tenant_modules, module_table_df, role_name
        )

        # Output the formatted data
        logging.info(formatted_data)
    else:
        # Convert module_names to a list
        module_names_list = json.loads(user_module_df[0]["module_names"])

        # Convert sub_module JSON string to a dictionary
        sub_module_dict = json.loads(user_module_df[0]["sub_module"])

        # Prepare the output data
        filtered_output = []

        # Iterate through the module names to filter based on the user data
        for module_name in module_names_list:
            # Get the corresponding sub_modules
            valid_sub_modules = []
            for sub_module in sub_module_dict.get(module_name, []):
                # You can apply any further logic if needed for filtering sub_modules
                valid_sub_modules.append(sub_module)

            # Append valid module and sub_modules to the output
            if valid_sub_modules:
                filtered_output.append(
                    {
                        "parent_module_name": module_name,
                        "module_name": valid_sub_modules,
                    }
                )

        # Final output
        filter_data = filtered_output
        modules = []
        module_data = db.get_data(
            "module", {}, ["id", "parent_module_name", "module_name", "submodule_name"]
        ).to_dict(orient="records")

        # Initialize lists to store filtered results
        filtered_results = []

        # Loop through the filter data
        for filter_item in filter_data:
            parent_name = filter_item["parent_module_name"]
            module_names = filter_item["module_name"]

            # Check the module_data for matching parent and module names
            for module_item in module_data:
                # Check if the parent_module_name matches
                if module_item["parent_module_name"] == parent_name:
                    # Now, only add if the module_name or submodule_name exists in filter data
                    if (
                        module_item["module_name"] in module_names
                        or module_item["submodule_name"] in module_names
                    ):
                        filtered_results.append(module_item)
                    elif (
                        not module_item["module_name"]
                        and not module_item["submodule_name"]
                    ):
                        filtered_results.append(module_item)

        # Create structured output for modules with IDs
        modules = []  # Resetting modules to gather results
        for item in filtered_results:
            module_entry = {
                "id": item["id"],  # Use the existing ID from module_data
                "parent_module_name": item["parent_module_name"],
                "module_name": item["module_name"],
                "submodule_name": item["submodule_name"],
            }
            modules.append(module_entry)

        # Print the structured modules list
        my_dict = modules
        # Initialize the output structure
        output_structure = []

        # Group by parent_module_name
        for item in my_dict:
            parent_name = item["parent_module_name"]
            # Check if the parent entry already exists
            parent_entry = next(
                (
                    entry
                    for entry in output_structure
                    if entry["parent_module_name"] == parent_name
                ),
                None,
            )
            if not parent_entry:
                parent_entry = {
                    "parent_module_name": parent_name,
                    "queue_order": item["id"],  # Use id as queue_order for parent
                    "children": [],
                }
                output_structure.append(parent_entry)

            # Only add a child if module_name is not None
            if item["module_name"] is not None:
                # Check if the child module already exists
                child_entry = next(
                    (
                        child
                        for child in parent_entry["children"]
                        if child["child_module_name"] == item["module_name"]
                    ),
                    None,
                )

                if not child_entry:
                    child_entry = {
                        "child_module_name": item["module_name"],
                        "queue_order": len(parent_entry["children"])
                        + 1,  # Position-based queue_order for children
                        "sub_children": [],  # Always include sub_children key
                    }
                    parent_entry["children"].append(child_entry)

                # If there is a submodule, add it to sub_children
                if item["submodule_name"]:
                    sub_child_entry = {
                        "sub_child_module_name": item["submodule_name"],
                        "queue_order": len(child_entry["sub_children"])
                        + 1,  # Position-based queue_order for sub-children
                        "sub_children": [],  # Always include sub_children key for sub-modules
                    }
                    child_entry["sub_children"].append(sub_child_entry)

        formatted_data = output_structure
    # Fetch the data from the database
    result = db.get_data(
        "tenant", {"tenant_name": tenant_name}, ["logo", "id", "db_name"]
    )

    # ordring modules
    parent_module_order_query = (
        f"select parent_module_name,parent_module_order from module"
    )
    parent_module_order = db.execute_query(parent_module_order_query, True).to_dict(
        orient="records"
    )

    module_order = {}
    for mod in parent_module_order:
        module_order[mod["parent_module_name"]] = mod["parent_module_order"]

    new_formated_data = []
    for modules in formatted_data:
        temp = modules
        if modules["parent_module_name"] in module_order:
            temp["queue_order"] = int(module_order[modules["parent_module_name"]])
        new_formated_data.append(temp)

    new_formated_data = sorted(new_formated_data, key=lambda x: x["queue_order"])

    # Extract 'logo' and 'id' separately
    logo = result["logo"].to_list()[0]  # Assuming the result contains a column 'logo'
    tenant_id = result["id"].to_list()[0]  # Assuming the result contains a column 'id'
    db_name = result["db_name"].to_list()[
        0
    ]  # Assuming the result contains a column 'id'
    message = "Module data sent sucessfully"
    response = {
        "flag": True,
        "message": message,
        "Modules": new_formated_data,
        "logo": logo,
        "tenant_id": tenant_id,
        "db_name": db_name,
    }
    logging.info("get_modules function executed successfully")
    try:
        audit_data_user_actions = {
            "service_name": "Module_management",
            "created_date": data.get("request_received_at", ""),
            "created_by": username,
            "status": "Success",
            "session_id": data.get("sessionID", ""),
            "tenant_name": tenant_name,
            "module_name": "Module_management",
            "comments": "get_modules",
            "request_received_at": data.get("request_received_at", ""),
        }

        db.update_audit(audit_data_user_actions, "audit_user_actions")
    except Exception as e:
        logging.warning(f"Exception is {e}")
    return response


def format_module_data(transformed_data, tenant_modules, module_table_df, role_name):
    """
    Formats module data into a structured hierarchy with parent modules, child modules,
    and sub-children, including queue order.
    """
    logging.info("Starting format_module_data function")
    # Step 1: Create a mapping for transformed_data to find parent modules easily
    parent_module_map = {
        item["parent_module_name"]: {
            "parent_module_name": item["parent_module_name"],
            "queue_order": 0,  # Placeholder for queue order
            "children": [],
        }
        for item in transformed_data
    }
    logging.info(
        f"Parent module map initialized with {len(parent_module_map)} entries"
    )

    # Step 2: Populate the parent_module_map with child and sub-child modules
    for module in module_table_df:
        parent_name = module["parent_module_name"]
        module_name = module["module_name"]
        submodule_name = module.get("submodule_name")
        module_access = True
        logging.info(f"Processing module: {module_name} under parent: {parent_name}")
        if not module_name:
            continue
        # Check if the parent module name exists in the transformed_data
        if (
            parent_name in parent_module_map and parent_name in tenant_modules
        ):  # Ensure module_name is not None or empty
            # Check if the child already exists in the parent's children list
            for item in transformed_data:
                if item["parent_module_name"] == parent_name:
                    if submodule_name:
                        if submodule_name not in item["module_name"]:
                            module_access = False
                            break
                    else:
                        if module_name not in item["module_name"]:
                            module_access = False
                            break

            if not module_access and (role_name.lower() != "super admin"):
                continue

            child_module = next(
                (
                    child
                    for child in parent_module_map[parent_name]["children"]
                    if child["child_module_name"] == module_name
                ),
                None,
            )

            if not child_module:
                # If the child module doesn't exist, create a new one
                child_module = {
                    "child_module_name": module_name,
                    "queue_order": len(parent_module_map[parent_name]["children"]) + 1,
                    "sub_children": [],
                }
                # Append the child module to the parent's children
                parent_module_map[parent_name]["children"].append(child_module)
                logging.info(
                    f"""Added child module: {module_name} with
                    queue order {child_module['queue_order']}
                    """
                )

            # If submodule_name exists, add it to sub_children
            if submodule_name:
                sub_child_module = {
                    "sub_child_module_name": submodule_name,
                    "queue_order": len(child_module["sub_children"]) + 1,
                    "sub_children": [],
                }
                child_module["sub_children"].append(sub_child_module)
                logging.info(
                    f"""Added sub-child module: {submodule_name} with
                      queue order {sub_child_module['queue_order']}
                      """
                )
        else:
            if parent_name in parent_module_map:
                parent_module_map.pop(parent_name)
    # Step 3: Convert parent_module_map to a list
    structured_data = []

    for index, (parent_name, parent_data) in enumerate(parent_module_map.items()):
        parent_data["queue_order"] = index + 1  # Set queue_order based on the index
        structured_data.append(parent_data)  # Include even if no children
        logging.info(
            f"Set queue order {parent_data['queue_order']} for parent module: {parent_name}"
        )

    logging.info("Successfully formatted module data")
    return structured_data


def form_modules_dictionary(data, sub_modules, tenant_modules):
    """
    Description: The form_modules_dict function constructs a nested dictionary that maps
      parent modules
    to their respective submodules and child modules. It filters and organizes modules based on the
    user's tenant permissions and specified submodules.
    """
    logging.info("Starting form_modules_dictionary function")
    # Initialize an empty dictionary to store the output
    out = {}

    # Iterate through the list of modules in the data
    for item in data:
        parent_module = item["parent_module_name"]
        logging.info(f"Processing parent module: {parent_module}")

        # Skip modules not assigned to the tenant
        if parent_module not in tenant_modules and parent_module:
            logging.info(
                f"Skipping parent module {parent_module} - not in tenant_modules"
            )
            continue

        # If there's no parent module, initialize an empty dictionary for the module
        if not parent_module:
            logging.info(f"Adding top-level module: {item['module_name']}")
            out[item["module_name"]] = {}
            continue
        else:
            logging.info(
                f"Initializing empty dictionary for parent module {parent_module}"
            )
            out[item["parent_module_name"]] = {}

        # Iterate through the data again to find related modules and submodules
        for module in data:
            temp = {}

            # Skip modules not in the specified submodules
            if (
                module["module_name"] not in sub_modules
                and module["submodule_name"] not in sub_modules
            ):
                logging.info(
                    f"""Skipping module {module['module_name']} or
                    submodule {module['submodule_name']} - not in sub_modules
                    """
                )
                continue

            # Handle modules without submodules and create a list for them
            if (
                module["parent_module_name"] == parent_module
                and module["module_name"]
                and not module["submodule_name"]
            ):
                logging.info(
                    f"Adding module without submodule: {module['module_name']} under {parent_module}"
                )
                temp = {module["module_name"]: []}
            # Handle modules with submodules and map them accordingly
            elif (
                module["parent_module_name"] == parent_module
                and module["module_name"]
                and module["submodule_name"]
            ):
                logging.info(
                    f"""Mapping submodule {module['submodule_name']} to
                      module {module['module_name']} under {parent_module}
                      """
                )
                temp = {module["submodule_name"]: [module["module_name"]]}

            # Update the output dictionary with the constructed module mapping
            if temp:
                for key, value in temp.items():
                    if key in out[item["parent_module_name"]]:
                        out[item["parent_module_name"]][key].append(value[0])
                        logging.info(
                            f"Appending {value[0]} to existing submodule {key} in {parent_module}"
                        )
                    else:
                        out[item["parent_module_name"]].update(temp)
                        logging.info(f"Adding new submodule {key} to {parent_module}")

    logging.info("Module dictionary formed successfully")
    # Return the final dictionary containing the module mappings
    return out


def transform_structure_data_values(input_data):
    """
    Description: The transform_structure function transforms a nested dictionary
    of modules into a list of structured dictionaries, each with queue_order to
    maintain the order of parent modules, child modules, and sub-children.
    """
    logging.info("Starting transform_structure_data_values function")
    # Initialize an empty list to store the transformed data
    transformed_data = []
    # Initialize the queue order for parent modules
    queue_order = 1

    # Iterate over each parent module and its children in the input data
    for parent_module, children in input_data.items():
        logging.info(
            f"Processing parent module: {parent_module} with queue_order {queue_order}"
        )
        transformed_children = []
        child_queue_order = 1
        # Iterate over each child module and its sub-children
        for child_module, sub_children in children.items():
            logging.info(
                f"Processing child module: {child_module} with queue_order {child_queue_order}"
            )
            transformed_sub_children = []
            sub_child_queue_order = 1

            # Iterate over each sub-child module
            for sub_child in sub_children:
                logging.info(
                    f"Adding sub-child module: {sub_child} with queue_order {sub_child_queue_order}"
                )
                transformed_sub_children.append(
                    {
                        "sub_child_module_name": sub_child,
                        "queue_order": sub_child_queue_order,
                        "sub_children": [],
                    }
                )
                sub_child_queue_order += 1
            # Append the transformed child module with its sub-children
            transformed_children.append(
                {
                    "child_module_name": child_module,
                    "queue_order": child_queue_order,
                    "sub_children": transformed_sub_children,
                }
            )
            child_queue_order += 1

        # Append the transformed parent module with its children
        transformed_data.append(
            {
                "parent_module_name": parent_module,
                "queue_order": queue_order,
                "children": transformed_children,
            }
        )
        queue_order += 1
    logging.info("Transformation completed successfully")

    # Return the list of transformed data
    return transformed_data


def convert_timestamp(data):
    """Convert timestamp columns in the provided dictionary list to the
    tenant's timezone."""
    logging.info(f"Converting data: {data}")
    if isinstance(data, pd.Timestamp):
        logging.info(f"Converting pd.Timestamp: {data}")
        return data.strftime("%m-%d-%Y %H:%M:%S")
    elif isinstance(data, dict):
        logging.info("Processing dictionary in convert_timestamp")
        return {k: convert_timestamp(v) for k, v in data.items()}
    elif isinstance(data, list):
        logging.info("Processing list in convert_timestamp")
        return [convert_timestamp(v) for v in data]
    else:
        logging.info(f"No conversion needed for type: {type(data)}")
        return data


def convert_timestamp_data(df_dict, tenant_time_zone):
    """Convert timestamp columns in the provided dictionary list to the
    tenant's timezone."""
    # Create a timezone object
    target_timezone = timezone(tenant_time_zone)

    # List of timestamp columns to convert
    timestamp_columns = [
        "created_date",
        "modified_date",
        "deleted_date",
    ]  # Adjust as needed based on your data

    # Convert specified timestamp columns to the tenant's timezone
    for record in df_dict:
        for col in timestamp_columns:
            if col in record and record[col] is not None:
                # Convert to datetime if it's not already
                timestamp = pd.to_datetime(record[col], errors="coerce")
                if timestamp.tz is None:
                    # If the timestamp is naive, localize it to UTC first
                    timestamp = timestamp.tz_localize("UTC")
                # Now convert to the target timezone
                record[col] = timestamp.tz_convert(target_timezone).strftime(
                    "%m-%d-%Y %H:%M:%S"
                )  # Ensure it's a string
    return df_dict


# import numpy as np

# def serialize_data(data):
#     """Recursively convert pandas objects in the data structure to serializable types."""
#     if isinstance(data, list):
#         return [serialize_data(item) for item in data]
#     elif isinstance(data, dict):
#         return {key: serialize_data(value) for key, value in data.items()}
#     elif isinstance(data, pd.Timestamp):
#         # Handle pd.Timestamp and NaT
#         return data.strftime("%m-%d-%Y %H:%M:%S") if pd.notna(data) else None
#     elif data is pd.NaT:  # Directly check for pd.NaT
#         return None
#     elif isinstance(data, np.datetime64):  # Handle numpy datetime64
#         return str(data) if pd.notna(data) else None
#     elif pd.api.types.is_integer(data):  # Check explicitly for integers
#         return int(data)
#     elif pd.api.types.is_float(data):  # Check explicitly for floats
#         return float(data)
#     elif pd.isna(data):  # Handle NaN or missing values
#         return None
#     else:
#         return data  # Return as is for other types


def service_provider_list_view(data):
    """
    Description:
        Retrieves service provider data in list view format from the database.
        The function validates the access token and logs the request. It fetches the
        service provider data along with related information such as integrations,
        service provider settings, and pagination details. The response is formatted
        with the retrieved data, which includes service provider details, integration
        lists, settings, and headers mapping.

    Args:
        data (dict): A dictionary containing the request data. Expected keys include:
            - 'db_name' (str, optional): The database name to query (default: 'altaworx_central').
            - 'role_name' (str, optional): The role name for data access (default: '').
            - 'tenant_name' (str, optional): The tenant name to fetch the timezone (default: '').
            - 'pages' (dict, optional): Pagination information including 'start' and '
               end' (default: {'start': 0, 'end': 100}).

    Returns:
        dict: A dictionary containing the formatted response data, which includes:
            - 'flag' (bool): Indicates whether the data was fetched successfully.
            - 'message' (str): A message describing the result of the operation.
            - 'data' (list): The list of service provider data.
            - 'integration_list' (list): The list of integration details.
            - 'service_provider_setting_list' (list): The list of service provider settings.
            - 'headers_map' (dict): The mapping of headers for the service provider data.
            - 'pages' (dict): Pagination information with 'start', 'end', and 'total' values.
    """
    logging.info("Request Data Received")

    # database Connection
    database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_db_name = data.get("db_name", "")
    dbs = DB(tenant_db_name, **db_config)

    role_name = data.get("role_name", "")
    tenant_database = data.get("db_name", "")

    try:
        return_json_data = {}
        start_page = data.get("pages", {}).get("start", 0)
        end_page = data.get("pages", {}).get("end", 100)

        # Query to get total number of rows for pagination
        total_count_query = """SELECT COUNT(*) AS total FROM serviceprovider"""
        total_count_result = dbs.execute_query(total_count_query, flag=True)
        total_count = int(total_count_result.iloc[0]["total"])

        # Pagination pages info
        pages = {"start": start_page, "end": end_page, "total": total_count}

        # SQL query to get all columns from the templates table with pagination
        # query = """SELECT SP.*, I.name FROM serviceprovider SP
        #     left join integration I on I.id = SP.integration_id
        #     WHERE SP.is_active = 'true' OR
        #             SP.is_deleted = 'false' ORDER BY SP.modified_date DESC, SP.created_date LIMIT 100 OFFSET %s"""

        # Fetch integrations
        integration_query = f"""
        SELECT id, name FROM integration
        WHERE is_active='true'
        """
        integrations = database.execute_query(integration_query, True)
        integration_map = dict(zip(integrations["id"], integrations["name"]))

        # Fetch service providers
        sp_query = """
        SELECT * FROM serviceprovider SP
        WHERE SP.is_active = 'true' OR SP.is_deleted = 'false'
        ORDER BY SP.modified_date DESC, SP.created_date
        LIMIT 100 OFFSET %s
        """

        params = [start_page]
        result = dbs.execute_query(sp_query, params=[start_page])

        result["integration_name"] = result["integration_id"].map(integration_map)

        integration_query = "SELECT id, name FROM integration WHERE is_active='true'"
        df = dbs.execute_query(integration_query, True)
        df = df.sort_values(by="name", ascending=True)

        # Convert the 'role_name' column to a list
        integration_list = [{row["name"]: row["id"]} for _, row in df.iterrows()]

        service_provider_setting = """SELECT service_provider_id, setting_key, setting_value
                FROM service_provider_setting WHERE is_active='true'
          """
        service_provider_setting = dbs.execute_query(service_provider_setting, True)
        service_provider_setting_list = service_provider_setting.to_dict(
            orient="records"
        )

        # Get tenant's timezone
        tenant_time_zone = fetch_tenant_timezone(database, data)

        # Execute the query using the existing execute_query function
        # result = dbs.execute_query(query, params=params)
        headers_map = get_headers_mapping(
            tenant_database,
            ["Service Provider"],
            role_name,
            "",
            "",
            "",
            "",
            data,
            database,
        )

        if not result.empty:
            df_dict = result.to_dict(orient="records")
            df_dict = convert_timestamp_data(df_dict, tenant_time_zone)
            return_json_data["flag"] = True
            return_json_data["message"] = "Data fetched successfully"
            return_json_data["data"] = serialize_data(df_dict)
            return_json_data["integration_list"] = integration_list
            return_json_data["service_provider_setting_list"] = (
                service_provider_setting_list
            )
            return_json_data["headers_map"] = headers_map
            return_json_data["pages"] = pages
            return return_json_data
        else:
            logging.info("No data found.")
            return_json_data["flag"] = True
            return_json_data["data"] = []
            return_json_data["integration_list"] = integration_list
            return_json_data["message"] = "No data found!"
        try:
            audit_data_user_actions = {
                "service_name": "Module_management",
                "created_date": data.get("request_received_at", ""),
                "created_by": data.get("username", ""),
                "status": "Success",
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "module_name": "Module_management",
                "comments": "service_provider_list_view",
                "request_received_at": data.get("request_received_at", ""),
            }

            database.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Exception is {e}")
            return return_json_data
    except Exception as e:
        logging.exception(f"Error occurred: {str(e)}")
        return_json_data["flag"] = True
        headers_map = get_headers_mapping(
            tenant_database,
            ["Service Provider"],
            role_name,
            "",
            "",
            "",
            "",
            data,
            database,
        )
        return_json_data["message"] = f"Failed to Fetch data! or No data found!"
        return_json_data["integration_list"] = []
        return_json_data["data"] = []
        return_json_data["headers_map"] = headers_map
        message = "Something went wrong while fetching Partner info"
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "Module Management",
                "created_date": data.get("request_received_at", ""),
                "error_message": message,
                "error_type": error_type,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("tenant_name", ""),
                "comments": "",
                "module_name": "service_provider_list_view",
                "request_received_at": data.get("request_received_at", ""),
            }
            database.log_error_to_db(error_data, "error_log_table")
        except Exception as e:
            logging.exception(f"Exception is {e}")
        return return_json_data


def update_tenant_service_provider_data():

    FILE_PATH = f"/opt/python/lib/python3.9/site-packages/common_utils/tenant_service_providers.json"

    """Fetch data from the database and update the JSON file."""
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

        # Fetch all active tenants
        tenants = common_utils_database.execute_query(
            "SELECT id, tenant_name, db_name FROM tenant WHERE is_active = true", True
        ).to_dict(orient="records")
        logging.info(tenants, "tenants are")

        # Load existing data if file exists
        existing_data = {}
        if os.path.exists(FILE_PATH):
            with open(FILE_PATH, "r") as file:
                existing_data = json.load(file)

        # Process each tenant
        for tenant in tenants:
            tenant_id, tenant_name, db_name = (
                int(tenant["id"]),
                tenant["tenant_name"],
                tenant["db_name"],
            )
            logging.info(tenant, "Processing Tenant")

            # Ensure tenant exists in the JSON file
            if tenant_name not in existing_data:
                existing_data[tenant_name] = {}

            # Skip tenants with missing `db_name`
            if not db_name:
                logging.info(
                    f"Skipping tenant '{tenant_name}' due to missing database name."
                )
                continue

            try:
                # Attempt to connect to the tenant's database
                database = DB(db_name, **db_config)

                # Fetch active service providers for the tenant
                service_providers = database.execute_query(
                    f"SELECT id, service_provider_name FROM serviceprovider WHERE is_active = true AND tenant_id = {tenant_id}",
                    True,
                ).to_dict(orient="records")

                # Update JSON structure
                for sp in service_providers:
                    existing_data[tenant_name][sp["service_provider_name"]] = sp["id"]

            except Exception as db_error:
                logging.exception(f"Skipping '{tenant_name}' due to database error: {db_error}")
                continue  # Move to the next tenant

        # Save updated data back to file
        os.makedirs(os.path.dirname(FILE_PATH), exist_ok=True)
        with open(FILE_PATH, "w") as file:
            json.dump(existing_data, file, indent=4)

        logging.info(f"Data successfully updated in {FILE_PATH}")

    except Exception as e:
        logging.addFilter(f"Error updating tenant-service provider data: {e}")


def submit_update_edit_service_provider(data):
    """
    Updates or creates service provider data, manages custom fields, and handles deletion
    operations.
    This function allows for the creation, updating, and deletion of service provider
    records in the database.It processes the incoming data, performs the necessary database
    operations, and logs the user actions for auditing.
    The function also ensures that any changes to custom fields are handled properly,
    preventing duplicates and ensuring data integrity.

    Parameters:
        data (dict): A dictionary containing the following keys:
            - 'changed_data': The data to be updated.
            - 'custom_fields': Custom fields to be added or updated.
            - 'new_data': New data to be inserted.
            - 'delete_data': Data indicating what records need to be deleted.
            - 'action': The action to perform ('create', 'update', or 'delete').
            - 'username': The username of the person performing the action.
            - 'tenant_name': The tenant associated with the service provider.
            - 'request_received_at': Timestamp of when the request was received.
            - 'db_name': The tenant database name.
            - 'table_name': The table name where the data should be updated.

    Returns:
        dict: A dictionary containing the result of the operation:
            - 'flag': A boolean indicating whether the operation was successful.
            - 'message': A message indicating success or failure.
    """

    # Convert boolean values in the input data to their respective types
    data = convert_booleans(data)
    start_time = time.time()  # Start the timer for performance measurement
    changed_data = data.get("changed_data", {})
    custom_fields = data.get("custom_fields", {})
    new_data = {k: v for k, v in data.get("new_data", {}).items() if v}
    delete_data = data.get("delete_data", {})
    unique_id = changed_data.get("id")
    table_name = data.get("table_name", "")
    action = data.get("action", "")
    request_received_at = data.get("request_received_at", "")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")

    # Database connection setup
    tenant_database = data.get("db_name", "altaworx_central")
    dbs = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

    try:
        if action == "create":
            # Prepare new data for insertion by ensuring no empty values are included
            new_data = {k: v for k, v in new_data.items() if v not in [None, "None"]}
            for k, v in new_data.items():
                if isinstance(v, list):
                    if all(isinstance(item, dict) for item in v):
                        new_data[k] = json.dumps(
                            v
                        )  # Convert list of dicts to JSON string
                    else:
                        new_data[k] = ", ".join(
                            str(item) for item in v if item is not None
                        )  # Convert other types to strings
            if new_data:
                # dbs.insert_data(new_data, table_name)
                tenant_id = common_utils_database.get_data(
                    "tenant", {"tenant_name": tenant_name}, ["id"]
                ).to_dict(orient="records")[0]["id"]
                new_data["tenant_id"] = tenant_id
                new_data["is_deleted"] = False
                service_provider_id = dbs.insert_data(new_data, table_name)
                integration_dataframe = common_utils_database.get_data(
                    "integration",
                    {"id": new_data["integration_id"]},
                    ["id", "authentication_type"],
                )
                integration_id = integration_dataframe["id"].to_list()[0]
                authentication_type = integration_dataframe[
                    "authentication_type"
                ].to_list()[0]
                logging.info(tenant_id, "tenant_id")
                service_provider_setting_data = {
                    "integration_id": integration_id,
                    "service_provider_id": service_provider_id,
                    "tenant_id": tenant_id,
                    "authentication_type": authentication_type,
                    "is_active": True,
                    "created_by": username,
                    "is_deleted": False,
                }
                integration_authentication_id = common_utils_database.insert_data(
                    service_provider_setting_data, "integration_authentication"
                )
                # Call function to update JSON file
                update_tenant_service_provider_data()
                logging.info("Data insertion was successful.")
        elif action == "update":
            if unique_id is not None:
                # Prepare the data for update by filtering out None values
                changed_data = {
                    k: v for k, v in changed_data.items() if v not in [None, "None"]
                }
                update_data = {
                    key: value for key, value in changed_data.items() if key != "id"
                }
                # Handle custom fields
                custom_fields = [
                    {k: v for k, v in custom_field.items() if v not in [None, "None"]}
                    for custom_field in custom_fields
                ]
                for k, v in new_data.items():
                    if isinstance(v, list):
                        if all(isinstance(item, dict) for item in v):
                            new_data[k] = json.dumps(
                                v
                            )  # Convert list of dicts to JSON string
                        else:
                            new_data[k] = ", ".join(
                                str(item) for item in v if item is not None
                            )  # Convert other types to strings

                if update_data:
                    dbs.update_dict(table_name, update_data, {"id": unique_id})
                if custom_fields:
                    for custom_field in custom_fields:
                        # Check if the record already exists in the database
                        setting_value = custom_field.get("setting_value")
                        service_provider_id = custom_field.get("service_provider_id")
                        setting_key = custom_field.get("setting_key")

                        # Fetch all active records for the service provider
                        active_records = dbs.get_data(
                            "service_provider_setting",
                            {
                                "service_provider_id": service_provider_id,
                                "is_active": True,
                            },
                            ["setting_key", "setting_value"],
                        ).to_dict(orient="records")

                        # Check if the setting_key and setting_value already exist
                        record_exists = any(
                            record["setting_key"] == setting_key
                            and record["setting_value"] == setting_value
                            for record in active_records
                        )


                        dbs.update_dict("service_provider_setting",
                                                            {"setting_value": setting_value},
                                                {"setting_key": setting_key, "service_provider_id": service_provider_id})

                            # Call function to update JSON file
                        update_tenant_service_provider_data()
        elif action == "delete":
            # Clean up delete data by removing None values
            delete_data = {
                k: v for k, v in delete_data.items() if v not in [None, "None"]
            }
            if delete_data:
                dbs.update_dict(table_name, delete_data, {"id": unique_id})
                logging.info("Data deletion was successful.")
            # Call function to update JSON file
            update_tenant_service_provider_data()

        # Prepare the response data
        response_data = {"flag": True, "message": f"{action} successfully"}

        try:
            # End time calculation
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            # Log the user action in the audit table
            audit_data_user_actions = {
                "service_name": "Module Management",
                "created_date": request_received_at,
                "created_by": username,
                "status": str(response_data["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": "session_id",
                "tenant_name": tenant_name,
                "comments": "Reports data",
                "module_name": "Reports",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
            logging.info("Audit log recorded successfully")
        except Exception as e:
            logging.exception(f"Exception during audit log: {e}")

        return response_data
    except Exception as e:
        logging.exception(f"An error occurred: {e}")
        message = "Unable to save the data"
        response = {"flag": False, "message": message}
        error_type = str(type(e).__name__)

        try:
            # Log error to database
            error_data = {
                "service_name": "update_superadmin_data",
                "created_date": request_received_at,
                "error_message": message,
                "error_type": error_type,
                "users": username,
                "session_id": "session_id",
                "tenant_name": tenant_name,
                "comments": "",
                "module_name": "Module Management",
                "request_received_at": request_received_at,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
            logging.info("Error details logged successfully")
        except Exception as e:
            logging.exception(f"Exception during error log: {e}")

        return response


# AWS S3 client
s3_client = boto3.client("s3")
S3_BUCKET_NAME = os.getenv("S3_BUCKET_NAME", " ")


def format_header(header):
    # Define acronyms to preserve uppercase
    acronyms = {"SMS", "IMEI", "IP", "BAN", "URL", "UID", "MAC", "EID", "MSISDN"}

    # Split by underscores and format each part
    parts = header.split("_")
    formatted_parts = [
        part if part.upper() in acronyms else part.capitalize()  # Preserve acronym case
        for part in parts
    ]

    # Join the parts back together
    return " ".join(formatted_parts)

def convert_timestamp_dataframe(df, tenant_time_zone):
    """Convert specific timestamp columns in a DataFrame to the tenant's timezone."""

    # Define the columns to process
    timestamp_columns = ["created_date", "modified_date", "deleted_date","processed_date"]

    # Create a timezone object
    target_timezone = pytz.timezone(tenant_time_zone)

    # Convert only the specified timestamp columns
    for col in timestamp_columns:
        if col in df.columns:  # Ensure column exists
            try:
                # Convert to datetime, handling invalid values as NaT
                df[col] = pd.to_datetime(df[col], errors="coerce")

                # Localize naive timestamps to UTC
                df[col] = df[col].apply(lambda x: x.tz_localize("UTC") if pd.notna(x) and x.tz is None else x)

                # Convert to tenant's timezone
                df[col] = df[col].apply(lambda x: x.tz_convert(target_timezone) if pd.notna(x) else x)

                # Format as string with AM/PM
                df[col] = df[col].dt.strftime("%m-%d-%Y %I:%M:%S %p")

            except Exception as e:
                print(f"Error processing column {col}: {e}")

    return df

def export_to_s3_bucket(data):
    """
    Export combined query results for all billing periods into a single Excel file
    and upload it to an Amazon S3 bucket.

    Args:
        data (dict): Input data with necessary details.

    Returns:
        dict: Operation result containing flag, message, and optionally download_url.
    """
    S3_BUCKET_NAME = os.getenv("S3_BUCKET_NAME", " ")

    # Extract input parameters
    Partner = data.get("Partner", "")
    tenant_name=data.get('tenant_name','')
    request_received_at = data.get("request_received_at", None)
    module_name = data.get("module_name", "")
    module_name_snake_case = "_".join(module_name.strip().lower().split())
    user_name = data.get("user_name", "")
    session_id = data.get("session_id", "")
    service_provider = data.get("service_provider", "")
    if module_name == "Usage By Line Report":
        billing_cycle_period = data.get("billing_cycle_period", [])
    else:
        billing_cycle_period = data.get("billing_cycle_period", "")
    end_date = data.get("end_date", "")
    killbill_flag = data.get("killbill_flag", "")
    try:
        killbill_db = DB("billing_platform", **db_config)
    except Exception as e:
        logging.exception(f"Exception is {e}")
    start_date = data.get("start_date", "")
    tenant_database = data.get("db_name", "")
    export_base_path = os.getenv("EXPORT_BASE_PATH")
    if module_name == "SimManagement Inventory":
        file_name = (
            f"{export_base_path}/{module_name_snake_case}/SimManagement/Inventory.xlsx"
        )
    else:
        file_name = f"{export_base_path}/{module_name_snake_case}/{module_name}.xlsx"
    download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{file_name}"
    list_view_data_id = data.get("list_view_data_id", "3394")
    database = DB(tenant_database, **db_config)
    db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    if tenant_name == "Altaworx Test":
            tenant_id = 1  # Include the hardcoded ID
            tenant_name='Altaworx'
    else:
        # Default case: fetch only from the database
        tenant_id = db.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id"]
        )["id"].to_list()[0]

    # Update export status to 'Waiting'
    db.update_dict(
        "export_status",
        {"status_flag": "Waiting", "url": ""},
        {"module_name": module_name},
    )

    # Fetch the query for the module
    module_query_df = db.get_data("export_queries", {"module_name": module_name})
    if module_query_df.empty:
        return {
            "flag": False,
            "message": f"No query found for module name: {module_name}",
        }

    query = module_query_df.iloc[0]["module_query"]
    if not query:
        return {"flag": False, "message": f"Unknown module name: {module_name}"}

    try:
        if module_name == "SimManagement Inventory":
            logging.info("Handling SimManagement Inventory module")

            p = database.get_data(
                "optimization_setting",
                {},
                ["optino_cross_providercustomer_optimization"],
            ).iloc[0, 0]
            if p == True:
                insert_position = query.index("sms_count")
                new_columns = 'carrier_cycle_usage_mb AS "carrier_cycle_usage",\n    customer_cycle_usage_mb AS "customer_cycle_usage",\n    '
                query = query[:insert_position] + new_columns + query[insert_position:]
            else:
                insert_position = query.index(
                    "sms_count"
                )  # Find where to insert the new column
                query = (
                    query[:insert_position]
                    + 'carrier_cycle_usage_mb AS "data_usage_mb",\n    '
                    + query[insert_position:]
                )

            result_frames = []
            # for params in params_list:
            df = database.execute_query(query, True)
            if not df.empty:

                def truncate_to_2_decimal(x):
                    if x is None:
                        return None  # Handle None values gracefully
                    return math.floor(x * 100) / 100

                # Check if the columns exist, then apply truncation
                if "data_usage_mb" in df.columns:
                    df["data_usage_mb"] = df["data_usage_mb"].apply(
                        truncate_to_2_decimal
                    )
                    df["data_usage_mb"] = df["data_usage_mb"].apply(
                        lambda x: f"{x:.2f}"
                    )

                if "carrier_cycle_usage" in df.columns:
                    df["carrier_cycle_usage"] = df["carrier_cycle_usage"].apply(
                        truncate_to_2_decimal
                    )
                    # Ensure formatting with 2 decimal places
                    df["carrier_cycle_usage"] = df["carrier_cycle_usage"].apply(
                        lambda x: f"{x:.2f}"
                    )
                result_frames.append(df)

            if result_frames:
                combined_df = pd.concat(result_frames, ignore_index=True)

                # Fetch optimization setting for `p`
                p = database.get_data(
                    "optimization_setting",
                    {},
                    ["optino_cross_providercustomer_optimization"],
                ).iloc[0, 0]

                # Conditionally modify DataFrame based on `p`
                if (
                    not p
                ):  # If `p == False`, drop `customer_cycle_usage_mb` and rename `carrier_cycle_usage_mb` to `data_usage_mB`
                    if "customer_cycle_usage_mb" in combined_df.columns:
                        combined_df = combined_df.drop(
                            columns=["customer_cycle_usage_mb"]
                        )
                    if "carrier_cycle_usage_mb" in combined_df.columns:
                        combined_df = combined_df.rename(
                            columns={"carrier_cycle_usage_mb": "data_usage_mB"}
                        )
                # combined_df.columns = [
                #     # col.replace("_", " ").capitalize() for col in combined_df.columns
                #     " ".join(word.capitalize() for word in col.split("_")) for col in combined_df.columns
                # ]
                acronyms = {
                    "SMS",
                    "IMEI",
                    "IP",
                    "BAN",
                    "URL",
                    "UID",
                    "MAC",
                    "EID",
                    "MSISDN",
                    "MB",
                    "CCID",
                    "ICCID",
                    "MSISDN",
                    "IP",
                    "SIM",
                }

                # Define your special cases for capitalization (e.g., "And" -> "and" and "Att" -> "AT&T")
                special_replacements = {"Att": "AT&T", "And": "and"}
                # Format column names
                combined_df.columns = [
                    " ".join(
                        part.upper() if part.upper() in acronyms else part.capitalize()
                        for part in col.split("_")
                    )
                    for col in combined_df.columns
                ]

                # Apply special replacements (Att -> AT&T, And -> and)
                combined_df.columns = [
                    " ".join(
                        [
                            special_replacements.get(word, word)
                            for word in col.split(" ")
                        ]
                    )
                    for col in combined_df.columns
                ]
                logging.info(f"Data successfully combined. Rows: {len(combined_df)}")
            else:

                column = [
                    "Service provider",
                    "IMEI",
                    "Carrier rate plan name",
                    "Carrier cycle usage MB",
                    "SMS count",
                    "Cost center",
                    "Account number",
                    "Customer name",
                    "Date added",
                    "ICCID",
                    "MSISDN",
                    "EID",
                    "Username",
                    "Carrier cycle usage bytes",
                    "Customer rate pool name",
                    "Customer rate plan name",
                    "SIM status",
                    "Date activated",
                    "IP address",
                    "Carrier rate plan cost",
                    "Communication plan",
                    "Pool ID",
                    "Feature codes",
                    "Carrier data allocation MB",
                    "Customer data allocation MB",
                    "Service zip code",
                    "Device make",
                    "Device model",
                    "Next bill cycle date",
                    "Billing account number",
                    "Foundation account number",
                    "BAN status",
                    "Minutes used",
                    "Modified by",
                    "Modified date",
                ]
                combined_df = pd.DataFrame(columns=column)

            # Create an Excel file using OpenPyXL
            workbook = Workbook()
            sheet = workbook.active
            sheet.title = "Sheet1"

            # Write headers to the Excel sheet
            header_font = Font(bold=True)  # Define a bold font for the headers
            for col_idx, header in enumerate(combined_df.columns, start=1):
                cell = sheet.cell(row=1, column=col_idx, value=header)
                cell.alignment = Alignment(horizontal="center", vertical="center")
                cell.fill = PatternFill(
                    start_color="D3D3D3", end_color="D3D3D3", fill_type="solid"
                )
                cell.font = header_font

            # Write data to the Excel sheet
            for row_idx, row in combined_df.iterrows():
                for col_idx, value in enumerate(row, start=1):
                    sheet.cell(row=row_idx + 2, column=col_idx, value=value)

            # Adjust column widths
            for col_idx, col_cells in enumerate(sheet.columns, start=1):
                max_length = max(len(str(cell.value or "")) for cell in col_cells)
                sheet.column_dimensions[get_column_letter(col_idx)].width = (
                    max_length + 2
                )

            # Save the workbook to a buffer
            excel_buffer = BytesIO()
            workbook.save(excel_buffer)

            excel_buffer.seek(0)

            s3_client = boto3.client("s3")
            logging.info("Uploading file to S3 bucket")
            try:
                s3_client.put_object(
                    Bucket=S3_BUCKET_NAME,
                    Key=file_name,
                    Body=excel_buffer.getvalue(),
                    ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                )
                logging.info(
                    f"File successfully uploaded to {S3_BUCKET_NAME}/{file_name}"
                )
            except Exception as e:
                logging.exception(f"Failed to upload file:")

        elif module_name in (
            "Zero Usage Report Export",
            "Automation rule verification report Export",
            "Status History Report Export",
            "Customer Rate Pool Usage Report Export",
            "Pool Group Summary Report Export",
            "Usage By Line Report",
            "Newly Activated Report Export",
            "Daily usage report Export",
        ):

            if module_name == "Usage By Line Report":
                billing_cycle_period_all = (
                    tuple(map(str, billing_cycle_period))
                    if isinstance(billing_cycle_period, list)
                    else billing_cycle_period
                )
            params = [service_provider, billing_cycle_period]
            if not service_provider and not billing_cycle_period:
                if module_name == "Usage By Line Report":
                    p = database.get_data(
                            "optimization_setting",
                            {},
                            ["optino_cross_providercustomer_optimization"],
                        ).iloc[0, 0]
                    if p == False:
                        # Step 1: Fetch the latest billing cycle end date for each service provider
                        billing_period_query = """
                        SELECT DISTINCT ON (service_provider)
                                service_provider,
                                billing_cycle_end_date
                            FROM billing_period
                            WHERE is_active = 'true'
                            ORDER BY
                                service_provider,
                                id DESC;
                        """

                        billing_dates_df = database.execute_query(
                            billing_period_query, True
                        )

                        # Ensure 'billing_cycle_end_date' is in datetime format
                        billing_dates_df["billing_cycle_end_date"] = pd.to_datetime(
                            billing_dates_df["billing_cycle_end_date"]
                        )

                        # Convert to MM/DD/YYYY HH:MM:SS format
                        billing_dates_df["formatted_date"] = billing_dates_df[
                            "billing_cycle_end_date"
                        ].dt.strftime("%m/%d/%Y %H:%M:%S")

                        # Step 2: Prepare the query for fetching usage data
                        query_main = """
                        SELECT
                                billing_cycle_end_date,
                                service_provider_name as service_provider,
                                iccid,
                                msisdn,
                                foundation_account_number,
                                billing_account_number,
                                customer_rate_pool_name as customer_pool,
                                customer_name,
                                username,
                                carrier_rate_plan,
                                rate_plan_name as customer_rate_plan,
                                data_usage_mb,
                                status_display_name as sim_status,
                                date_activated
                                FROM public.vw_usage_by_line_from_devices
                                WHERE tenant_id = %s and is_active=True
                                AND service_provider_name = %s
                                AND TO_CHAR(billing_cycle_end_date, 'MM/DD/YYYY HH24:MI:SS') = %s
                        """
                        # Step 3: Fetch data for each service provider & billing cycle, then combine
                        final_df = pd.DataFrame()  # Empty DataFrame to store final results

                        for _, row in billing_dates_df.iterrows():
                            service_provider = row["service_provider"]
                            billing_cycle_date = row["formatted_date"]

                            # Execute query for the specific service provider & billing cycle
                            data = database.execute_query(
                                query_main, params=[tenant_id,service_provider, billing_cycle_date]
                            )
                            df = pd.DataFrame(data)

                            if not df.empty:
                                # Convert 'billing_cycle_end_date' to MM/DD/YYYY format for consistency
                                df["billing_cycle_end_date"] = pd.to_datetime(
                                    df["billing_cycle_end_date"]
                                ).dt.strftime("%m/%d/%Y")

                                # Append to final DataFrame
                                final_df = pd.concat([final_df, df], ignore_index=True)
                        count_dict = final_df["service_provider"].value_counts().to_dict()
                        logging.info(f"count_dict for each service provider is {count_dict}")
                        data_frame = final_df
                    else:
                        # billing_period_query = """
                            #         WITH billing_data AS (
                            #                 SELECT
                            #                     c.id AS customer_id,
                            #                     c.customer_name,
                            #                     bp.id AS billing_period_id,
                            #                     bp.bill_month,
                            #                     bp.bill_year,
                            #                     COALESCE(bp.customer_bill_period_end_day, 1) AS customer_bill_period_end_day,
                            #                     COALESCE(bp.customer_bill_period_end_hour, 0) AS customer_bill_period_end_hour,
                            #                     ROW_NUMBER() OVER (PARTITION BY c.id ORDER BY bp.bill_year DESC, bp.bill_month DESC) AS row_num
                            #                 FROM
                            #                     public.customers c
                            #                 JOIN LATERAL
                            #                     usp_get_customer_billing_period_by_siteid(c.id) bp ON true
                            #                 WHERE
                            #                     c.is_active = true
                            #             )
                            #             SELECT
                            #                 customer_name,
                            #                 CONCAT(
                            #                     LPAD(bill_month::TEXT, 2, '0'), '-',
                            #                     LPAD(customer_bill_period_end_day::TEXT, 2, '0'), '-',
                            #                     bill_year::TEXT, ' ',
                            #                     LPAD(customer_bill_period_end_hour::TEXT, 2, '0'), ':00:00'
                            #                 ) AS billing_cycle_end_date
                            #             FROM
                            #                 billing_data
                            #             WHERE
                            #                 row_num = 1
                            #             ORDER BY
                            #                 customer_name;
                            #     """

                            # billing_dates_df = database.execute_query(
                            #     billing_period_query, True
                            # )

                            # # Ensure 'billing_cycle_end_date' is in datetime format
                            # billing_dates_df["billing_cycle_end_date"] = pd.to_datetime(
                            #     billing_dates_df["billing_cycle_end_date"]
                            # )

                            # # Convert to MM/DD/YYYY HH:MM:SS format
                            # billing_dates_df["formatted_date"] = billing_dates_df[
                            #     "billing_cycle_end_date"
                            # ].dt.strftime("%m/%d/%Y %H:%M:%S")


                            query_main = f"""
                            select
                            service_provider_display_name,
                            billing_cycle_end_date,
                            iccid,msisdn,
                            foundation_account_number,
                            billing_account_number,
                            customer_rate_pool_name,
                            customer_name,
                            username,
                            carrier_rate_plan,
                            rate_plan_name,
                            integration_id,
                            data_usage_mb,
                            status_display_name,
                            date_activated,
                            tenant_id
                            from usp_report_customer_usage_by_line
                            WHERE tenant_id = {tenant_id}  and is_active=True

                            """

                            final_df = pd.DataFrame()



                            # Execute query for the specific service provider & billing cycle
                            data = database.execute_query(
                                query_main, True
                            )
                            df = pd.DataFrame(data)

                            if not df.empty:


                                # Append to final DataFrame
                                final_df = pd.concat([final_df, df], ignore_index=True)
                            data_frame = final_df
                else:
                    query = query.split("WHERE")[0].strip()
                    # Add LIMIT 100000 if not already present
                    if "LIMIT" not in query.upper():
                        if module_name == "Automation rule verification report Export":
                            query += ""
                        else:
                            query += f""" WHERE tenant_id = {tenant_id} """
                    data_frame = database.execute_query(query, True)
            else:
                # Add LIMIT 100000 if not already present
                if "LIMIT" not in query.upper():
                    query += ""
                if module_name == "Usage By Line Report":

                    p = database.get_data(
                            "optimization_setting",
                            {},
                            ["optino_cross_providercustomer_optimization"],
                        ).iloc[0, 0]
                    if p == False:

                        # Fetch full data for the first billing cycle
                        primary_billing_period = billing_cycle_period[0]

                        main_data = """
                        SELECT
                                billing_cycle_end_date,
                                service_provider_name as service_provider,
                                iccid,
                                msisdn,
                                foundation_account_number,
                                billing_account_number,
                                customer_rate_pool_name as customer_pool,
                                customer_name,
                                username,
                                carrier_rate_plan,
                                rate_plan_name as customer_rate_plan,
                                data_usage_mb,
                                status_display_name as sim_status,
                                date_activated
                                FROM public.vw_usage_by_line_from_devices
                                WHERE tenant_id = %s and is_active=True
                                AND service_provider_name = %s
                                AND billing_cycle_end_date = %s
                        """

                        # Query for device history data
                        secondary_data = """
                                            SELECT
                                                    billing_cycle_end_date,
                                                    service_provider_display_name as service_provider,
                                                    iccid,
                                                    msisdn,
                                                    foundation_account_number,
                                                    billing_account_number,
                                                    customer_rate_pool_name as customer_pool,
                                                    customer_name,
                                                    username,
                                                    carrier_rate_plan,
                                                    rate_plan_name as customer_rate_plan,
                                                    data_usage_mb,
                                                    status_display_name as sim_status,
                                                    date_activated
                                                    FROM public.vw_usage_by_line_report
                                                    WHERE tenant_id = %s and is_active=True
                                                    AND service_provider_display_name = %s
                                                    AND billing_cycle_end_date IN %s
                                            """

                        # Fetch primary billing cycle data from both sources
                        primary_billing_period = billing_cycle_period_all[0]

                        # Get usage report data
                        main_data = database.execute_query(
                            main_data, params=[tenant_id,service_provider, primary_billing_period]
                        )
                        df_main = pd.DataFrame(main_data)



                        # Get device history data
                        secondary_data = database.execute_query(
                            secondary_data, params=[tenant_id,service_provider, billing_cycle_period_all]
                        )
                        df_secondary = pd.DataFrame(secondary_data)

                        # Instead of grouping and summing duplicates, create a unique identifier
                        if 'duplicate_records' in df_secondary.columns:
                            df_secondary = df_secondary.sort_values('data_usage_mb', ascending=False)
                        else:
                            # Create a sequence number for each iccid+billing_cycle combination
                            df_secondary['record_seq'] = df_secondary.groupby(['iccid', 'billing_cycle_end_date']).cumcount() + 1

                            # Create unique pivot column by combining billing cycle with sequence number
                            df_secondary['pivot_column'] = df_secondary['billing_cycle_end_date'].astype(str) + '_' + df_secondary['record_seq'].astype(str)

                            # Now pivot using the unique pivot column
                            df_pivot = df_secondary.pivot(index='iccid', columns='pivot_column', values='data_usage_mb').reset_index()

                            # Merge pivoted data with main data using 'iccid'
                            df_final = df_main.merge(df_pivot, on='iccid', how='outer')

                            # Rename the columns for readability
                            rename_dict = {}
                            for col in df_pivot.columns:
                                if col != 'iccid':
                                    date_part = col.split('_')[0]
                                    seq_part = col.split('_')[1]
                                    rename_dict[col] = f"{date_part}_record{seq_part}"

                            df_final = df_final.rename(columns=rename_dict)

                            # Clean up temporary columns in the original dataframe
                            if 'record_seq' in df_secondary.columns:
                                df_secondary = df_secondary.drop(columns=['record_seq', 'pivot_column'])

                            # If any other temporary columns were added to the final dataframe that need removal
                            # df_final = df_final.drop(columns=['any_other_temp_column'])

                            data_frame = df_final

                    else:
                        if int(billing_cycle_period) == 0:
                            query_main = """
                                select
                                        service_provider_display_name,
                                        billing_cycle_end_date,
                                        iccid,msisdn,
                                        foundation_account_number,
                                        billing_account_number,
                                        customer_rate_pool_name,
                                        customer_name,
                                        customer_id,
                                        username,
                                        carrier_rate_plan,
                                        rate_plan_name,
                                        data_usage_mb,
                                        status_display_name,
                                        date_activated
                                        from usp_report_customer_usage_by_line
                                        WHERE tenant_id = %s and is_active=True
                                        and customer_id = %s
                                """
                            params = [tenant_id,service_provider]
                            data_frame = database.execute_query(query_main, params=params)
                        else:


                            query_main = """
                            select
                                service_provider_display_name,
                                billing_cycle_end_date,
                                iccid,
                                msisdn,
                                foundation_account_number,
                                billing_account_number,
                                customer_rate_pool_name,
                                customer_name,username,
                                carrier_rate_plan,
                                rate_plan_name,
                                integration_id,
                                data_usage_mb,
                                status_display_name,
                                date_activated,
                                tenant_id
                                from usp_report_customer_historyusagebyline_rmf(%s,%s,%s )
                                """

                            params = [tenant_id, service_provider,billing_cycle_period ]


                            data_frame = database.execute_query(query_main, params=params)


                else:
                    data_frame = database.execute_query(query, params=params)

            if data_frame.empty:
                db.update_dict(
                    "export_status",
                    {"status_flag": "No Data Found for export", "url": ""},
                    {"module_name": module_name},
                )
                return {"flag": False, "message": "No data found for export."}

            # data_frame.columns = [
            #     # col.replace("_", " ").capitalize() for col in data_frame.columns
            #     " ".join(word.capitalize() for word in col.split("_")) for col in data_frame.columns
            # ]
            acronyms = {
                "SMS",
                "IMEI",
                "IP",
                "BAN",
                "URL",
                "UID",
                "MAC",
                "EID",
                "MSISDN",
                "MB",
                "CCID",
                "ICCID",
                "MSISDN",
                "IP",
                "SIM",
            }

            # Define your special cases for capitalization (e.g., "And" -> "and" and "Att" -> "AT&T")
            special_replacements = {"Att": "AT&T", "And": "and"}
            # Format column names
            data_frame.columns = [
                # Handle timestamp or date-like columns separately
                (
                    col
                    if isinstance(col, pd.Timestamp)
                    or bool(re.match(r"\d{2}[-/]\d{2}[-/]\d{4}", str(col)))
                    else
                    # Process string column names
                    " ".join(
                        part.upper() if part.upper() in acronyms else part.capitalize()
                        for part in str(col).split("_")
                    )
                )
                for col in data_frame.columns
            ]

            # Apply special replacements (Att -> AT&T, And -> and)
            data_frame.columns = [
                (
                    " ".join(
                        [
                            special_replacements.get(word, word)
                            for word in str(col).split(" ")
                        ]
                    )
                    if isinstance(col, str)
                    else col
                )  # Only apply replacements to string columns
                for col in data_frame.columns
            ]

            excel_buffer = BytesIO()
            with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
                data_frame.to_excel(writer, index=False, sheet_name="Sheet1")

                # Get the workbook and the sheet
                workbook = writer.book
                sheet = workbook["Sheet1"]

                # Apply styles to the header row
                header_font = Font(bold=True)  # Define a bold font for the headers
                for cell in sheet[1]:
                    cell.alignment = Alignment(
                        horizontal="center", vertical="center"
                    )  # Center align
                    cell.fill = PatternFill(
                        start_color="D3D3D3", end_color="D3D3D3", fill_type="solid"
                    )  # Grey background
                    cell.font = header_font
                # Adjust column widths based on content
                for col_idx, col_cells in enumerate(sheet.columns, 1):
                    max_length = max(len(str(cell.value or "")) for cell in col_cells)
                    sheet.column_dimensions[get_column_letter(col_idx)].width = (
                        max_length + 2
                    )

            excel_buffer.seek(0)

            s3_client = boto3.client("s3")
            s3_client.put_object(
                Bucket=S3_BUCKET_NAME,
                Key=file_name,
                Body=excel_buffer.getvalue(),
                ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )
        elif module_name in ("Automation rule log Export",):
            params = [start_date, end_date]

            data_frame = database.execute_query(query, params=params)

            if data_frame.empty:
                db.update_dict(
                    "export_status",
                    {"status_flag": "No Data Found for export", "url": ""},
                    {"module_name": module_name},
                )
                return {"flag": False, "message": "No data found for export."}

            # data_frame.columns = [
            #     # col.replace("_", " ").capitalize() for col in data_frame.columns
            #     " ".join(word.capitalize() for word in col.split("_")) for col in data_frame.columns
            # ]
            acronyms = {
                "SMS",
                "IMEI",
                "IP",
                "BAN",
                "URL",
                "UID",
                "MAC",
                "EID",
                "MSISDN",
                "MB",
                "CCID",
                "ICCID",
                "MSISDN",
                "IP",
                "SIM",
            }

            # Define your special cases for capitalization (e.g., "And" -> "and" and "Att" -> "AT&T")
            special_replacements = {"Att": "AT&T", "And": "and"}
            # Format column names
            data_frame.columns = [
                " ".join(
                    part.upper() if part.upper() in acronyms else part.capitalize()
                    for part in col.split("_")
                )
                for col in data_frame.columns
            ]

            # Apply special replacements (Att -> AT&T, And -> and)
            data_frame.columns = [
                " ".join(
                    [special_replacements.get(word, word) for word in col.split(" ")]
                )
                for col in data_frame.columns
            ]

            excel_buffer = BytesIO()
            with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
                data_frame.to_excel(writer, index=False, sheet_name="Sheet1")

                # Get the workbook and the sheet
                workbook = writer.book
                sheet = workbook["Sheet1"]

                # Apply styles to the header row
                header_font = Font(bold=True)  # Define a bold font for the headers
                for cell in sheet[1]:
                    cell.alignment = Alignment(
                        horizontal="center", vertical="center"
                    )  # Center align
                    cell.fill = PatternFill(
                        start_color="D3D3D3", end_color="D3D3D3", fill_type="solid"
                    )  # Grey background
                    cell.font = header_font
                # Adjust column widths based on content
                for col_idx, col_cells in enumerate(sheet.columns, 1):
                    max_length = max(len(str(cell.value or "")) for cell in col_cells)
                    sheet.column_dimensions[get_column_letter(col_idx)].width = (
                        max_length + 2
                    )

            excel_buffer.seek(0)

            s3_client = boto3.client("s3")
            s3_client.put_object(
                Bucket=S3_BUCKET_NAME,
                Key=file_name,
                Body=excel_buffer.getvalue(),
                ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )
        elif module_name=='Bulk Change History':
            params = [list_view_data_id]
            data_frame = database.execute_query(query, params=params)
            tenant_time_zone = fetch_tenant_timezone(db, data)
            data_frame = convert_timestamp_dataframe(data_frame, tenant_time_zone)
            if data_frame.empty:
                db.update_dict(
                    "export_status",
                    {"status_flag": "No Data Found for export", "url": ""},
                    {"module_name": module_name},
                )
                return {"flag": False, "message": "No data found for export."}

            # data_frame.columns = [
            #     # col.replace("_", " ").capitalize() for col in data_frame.columns
            #     " ".join(word.capitalize() for word in col.split("_")) for col in data_frame.columns
            # ]
            acronyms = {
                "SMS",
                "IMEI",
                "IP",
                "BAN",
                "URL",
                "UID",
                "MAC",
                "EID",
                "MSISDN",
                "MB",
                "CCID",
                "ICCID",
                "MSISDN",
                "IP",
                "SIM",
            }

            # Define your special cases for capitalization (e.g., "And" -> "and" and "Att" -> "AT&T")
            special_replacements = {"Att": "AT&T", "And": "and"}
            # Format column names
            data_frame.columns = [
                " ".join(
                    part.upper() if part.upper() in acronyms else part.capitalize()
                    for part in col.split("_")
                )
                for col in data_frame.columns
            ]

            # Apply special replacements (Att -> AT&T, And -> and)
            data_frame.columns = [
                " ".join(
                    [special_replacements.get(word, word) for word in col.split(" ")]
                )
                for col in data_frame.columns
            ]

            excel_buffer = BytesIO()
            with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
                data_frame.to_excel(writer, index=False, sheet_name="Sheet1")

                # Get the workbook and the sheet
                workbook = writer.book
                sheet = workbook["Sheet1"]

                # Apply styles to the header row
                header_font = Font(bold=True)  # Define a bold font for the headers
                for cell in sheet[1]:
                    cell.alignment = Alignment(
                        horizontal="center", vertical="center"
                    )  # Center align
                    cell.fill = PatternFill(
                        start_color="D3D3D3", end_color="D3D3D3", fill_type="solid"
                    )  # Grey background
                    cell.font = header_font
                # Adjust column widths based on content
                for col_idx, col_cells in enumerate(sheet.columns, 1):
                    max_length = max(len(str(cell.value or "")) for cell in col_cells)
                    sheet.column_dimensions[get_column_letter(col_idx)].width = (
                        max_length + 2
                    )

            excel_buffer.seek(0)

            s3_client = boto3.client("s3")
            s3_client.put_object(
                Bucket=S3_BUCKET_NAME,
                Key=file_name,
                Body=excel_buffer.getvalue(),
                ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )
        else:


            if killbill_flag == True or killbill_flag == "True":
                logging.info(f"eexecuting the killdb unparmaterid query")
                logging.info(f"query----------{query}")
                data_frame = killbill_db.execute_query(query, True)
            else:
                if module_name == "Users":
                    data_frame = db.execute_query(query, True)
                else:
                    data_frame = database.execute_query(query, True)

            if data_frame.empty:
                db.update_dict(
                    "export_status",
                    {"status_flag": "No Data Found for export", "url": ""},
                    {"module_name": module_name},
                )
                return {"flag": False, "message": "No data found for export."}

            # data_frame.columns = [
            #     # col.replace("_", " ").capitalize() for col in data_frame.columns
            #     # " ".join(word.capitalize() for word in col.split("_")) for col in data_frame.columns
            #     # " ".join(word if word.isupper() else word.capitalize() for word in col.split("_")) for col in data_frame.columns
            #     [format_header(col) for col in data_frame.columns]
            # ]
            acronyms = {
                "SMS",
                "IMEI",
                "IP",
                "BAN",
                "URL",
                "UID",
                "MAC",
                "EID",
                "MSISDN",
                "MB",
                "CCID",
                "ICCID",
                "MSISDN",
                "IP",
                "SIM",
            }

            # Define your special cases for capitalization (e.g., "And" -> "and" and "Att" -> "AT&T")
            special_replacements = {"Att": "AT&T", "And": "and"}
            # Format column names
            data_frame.columns = [
                " ".join(
                    part.upper() if part.upper() in acronyms else part.capitalize()
                    for part in col.split("_")
                )
                for col in data_frame.columns
            ]

            # Apply special replacements (Att -> AT&T, And -> and)
            data_frame.columns = [
                " ".join(
                    [special_replacements.get(word, word) for word in col.split(" ")]
                )
                for col in data_frame.columns
            ]
            # Ensure column order is preserved
            excel_buffer = BytesIO()
            with pd.ExcelWriter(excel_buffer, engine="openpyxl") as writer:
                data_frame.to_excel(writer, index=False, sheet_name="Sheet1")

                # Get the workbook and the sheet
                workbook = writer.book
                sheet = workbook["Sheet1"]

                # Apply styles to the header row
                header_font = Font(bold=True)  # Define a bold font for the headers
                for cell in sheet[1]:
                    cell.alignment = Alignment(
                        horizontal="center", vertical="center"
                    )  # Center align
                    cell.fill = PatternFill(
                        start_color="D3D3D3", end_color="D3D3D3", fill_type="solid"
                    )  # Grey background
                    cell.font = header_font
                # Adjust column widths based on content
                for col_idx, col_cells in enumerate(sheet.columns, 1):
                    max_length = max(len(str(cell.value or "")) for cell in col_cells)
                    sheet.column_dimensions[get_column_letter(col_idx)].width = (
                        max_length + 2
                    )

            excel_buffer.seek(0)

            s3_client = boto3.client("s3")
            s3_client.put_object(
                Bucket=S3_BUCKET_NAME,
                Key=file_name,
                Body=excel_buffer.getvalue(),
                ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            )

        db.update_dict(
            "export_status",
            {"status_flag": "Success", "url": download_url},
            {"module_name": module_name},
        )
        try:
            audit_data_user_actions = {
                "service_name": "Module_management",
                "created_date": data.get("request_received_at", ""),
                "created_by": data.get("username", ""),
                "status": "Success",
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "module_name": "Module_management",
                "comments": "get_user_module_map",
                "request_received_at": data.get("request_received_at", ""),
            }

            db.update_audit(audit_data_user_actions, "audit_user_actions")
        except Exception as e:
            logging.warning(f"Exception is {e}")
        return {"flag": True, "download_url": download_url}
    except Exception as e:
        logging.exception(f"An error occurred: {e}")
        db.update_dict(
            "export_status", {"status_flag": "Failure"}, {"module_name": module_name}
        )
        db.log_error_to_db(
            {
                "service_name": "Module Management",
                "created_date": request_received_at,
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": user_name,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": str(e),
                "module_name": "export",
                "request_received_at": request_received_at,
            },
            "error_log_table",
        )
        return {"flag": False, "message": f"Error: {str(e)}"}


def get_export_status(data):
    try:
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        module_name = data.get("module_name")
        export_status_query = (
            f"select * from export_status where module_name='{module_name}'"
        )
        export_status_data = common_utils_database.execute_query(
            export_status_query, True
        ).to_dict(orient="records")
        try:
            audit_data_user_actions = {
                "service_name": "Module_management",
                "created_date": data.get("request_received_at", ""),
                "created_by": data.get("username", ""),
                "status": "Success",
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "module_name": "Module_management",
                "comments": "get_user_module_map",
                "request_received_at": data.get("request_received_at", ""),
            }

            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"Exception is {e}")
        return {"flag": True, "export_status_data": export_status_data[0]}
    except Exception as e:
        logging.exception(f"Exception is {e}")
        common_utils_database.log_error_to_db(
            {
                "service_name": "Module Management",
                "created_date": data.get("request_received_at", ""),
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": str(e),
                "module_name": "export",
                "request_received_at": data.get("request_received_at", ""),
            },
            "error_log_table",
        )
        return {"flag": False, "export_status_data": []}


def reports_dropdown_data_export(data):
    request_received_at = data.get("request_received_at", "")
    session_id = data.get("session_id", "")
    username = data.get("username", "")
    module_name = data.get("module", "")
    tenant_database = data.get("db_name", "")
    tenant_name = data.get("tenant_name", "")
    # database Connection
    database = DB(database=tenant_database, **db_config)
    dbs = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

    if tenant_name == "Altaworx Test":
        tenant_id = 1  # Include the hardcoded ID

    else:
        # Default case: fetch only from the database
        tenant_id = dbs.get_data(
            "tenant", {"tenant_name": tenant_name}, ["id"]
        )["id"].to_list()[0]

    p = database.get_data("optimization_setting",{},["optino_cross_providercustomer_optimization"],).iloc[0, 0]

    if module_name == 'Usage By Line Report':

        if p == False:

            billing_period_query = """
                        SELECT service_provider, billing_cycle_end_date
                        FROM billing_period
                        WHERE is_active = 'true'
                        ORDER BY
                            CASE
                                WHEN CURRENT_DATE BETWEEN billing_cycle_start_date
                                AND billing_cycle_end_date THEN 0
                                ELSE 1
                            END,
                            billing_cycle_end_date DESC
                    """
            billing_period_dates = database.execute_query(billing_period_query, True)
            billing_period_dates["billing_cycle_end_date"] = pd.to_datetime(
            billing_period_dates["billing_cycle_end_date"], errors="coerce"
                )

            # Remove NaT (null) values before processing
            billing_period_dates = billing_period_dates.dropna(subset=["billing_cycle_end_date"])

            # Format valid dates
            billing_period_dates["billing_cycle_end_date"] = billing_period_dates["billing_cycle_end_date"].dt.strftime("%m-%d-%Y %H:%M:%S")
            billing_period_dates = billing_period_dates.to_dict(orient="records")
            # Extract only the service_provider values
            service_providers = [row["service_provider"] for row in billing_period_dates]

            # Create a dictionary where the key is service_provider and
            # the value is a list of billing_cycle_end_dates
            service_provider_dict = {}

            for row in billing_period_dates:
                if row["service_provider"] in service_provider_dict:
                    service_provider_dict[row["service_provider"]].append(
                        row["billing_cycle_end_date"]
                    )
                else:
                    service_provider_dict[row["service_provider"]] = [
                        row["billing_cycle_end_date"]
                    ]

            # Optionally, remove duplicates
            unique_service_providers = sorted(list(set(service_providers)))

            # Add "All" to the list of unique service providers
            unique_service_providers.insert(0, "All service providers")
        else:
            view_query = f"""
                SELECT customer_id, customer_name, billing_period_ids, billing_cycle_end_date
                FROM vw_cross_provider_usage_by_line_report_for_customer where tenant_id = {tenant_id}
            """
            billing_data = database.execute_query(view_query, True)

            # Convert to your dictionary structure
            service_provider_dict = {}
            unique_service_providers = []

            for _, row in billing_data.iterrows():
                customer_id = str(row['customer_id'])
                customer_name = row['customer_name']
                customer_key = f"{customer_name}-{customer_id}"

                # Get the sets from the row
                billing_period_ids = row['billing_period_ids']  # This is a set
                billing_dates = row['billing_cycle_end_date']   # This is a set

                # Create a dictionary to store the date-to-period mapping
                date_period_map = {}

                # Convert billing_dates to list of (date_obj, date_str) tuples for sorting
                date_objects = []
                for date_str in billing_dates:
                    try:
                        date_obj = datetime.datetime.strptime(date_str, "%m-%d-%Y %H:%M:%S")
                        date_objects.append((date_obj, date_str))
                    except (ValueError, TypeError):
                        # Skip invalid dates
                        continue

                # Sort dates in descending order
                date_objects.sort(reverse=True)
                sorted_dates = [date_str for _, date_str in date_objects]

                # Sort period IDs in ascending order (assuming newer dates get larger IDs)
                sorted_period_ids = sorted(billing_period_ids)

                # Match sorted dates with period IDs
                # Using the business rule you mentioned (04-01-2025 → 80)
                # I'm assuming the most recent date gets the highest period ID
                if sorted_dates and sorted_period_ids and len(sorted_dates) == len(sorted_period_ids):
                    for i in range(len(sorted_dates)):
                        date_period_map[sorted_dates[i]] = sorted_period_ids[len(sorted_period_ids) - i - 1]

                # Store the mapping in the service_provider_dict
                service_provider_dict[customer_key] = date_period_map

                # Add to unique customers list
                unique_service_providers.append(customer_key)

            # Sort unique customer names
            unique_service_providers.sort()

            # Add "All Customers" at the beginning
            unique_service_providers.insert(0, "All Customers")

    else:
        billing_period_query = """
                        SELECT service_provider, billing_cycle_end_date
                        FROM billing_period
                        WHERE is_active = 'true'
                        ORDER BY
                            CASE
                                WHEN CURRENT_DATE BETWEEN billing_cycle_start_date
                                AND billing_cycle_end_date THEN 0
                                ELSE 1
                            END,
                            billing_cycle_end_date DESC
                    """
        billing_period_dates = database.execute_query(billing_period_query, True)
        billing_period_dates["billing_cycle_end_date"] = pd.to_datetime(
        billing_period_dates["billing_cycle_end_date"], errors="coerce"
            )

        # Remove NaT (null) values before processing
        billing_period_dates = billing_period_dates.dropna(subset=["billing_cycle_end_date"])

        # Format valid dates
        billing_period_dates["billing_cycle_end_date"] = billing_period_dates["billing_cycle_end_date"].dt.strftime("%m-%d-%Y %H:%M:%S")
        billing_period_dates = billing_period_dates.to_dict(orient="records")
        # Extract only the service_provider values
        service_providers = [row["service_provider"] for row in billing_period_dates]

        # Create a dictionary where the key is service_provider and
        # the value is a list of billing_cycle_end_dates
        service_provider_dict = {}

        for row in billing_period_dates:
            if row["service_provider"] in service_provider_dict:
                service_provider_dict[row["service_provider"]].append(
                    row["billing_cycle_end_date"]
                )
            else:
                service_provider_dict[row["service_provider"]] = [
                    row["billing_cycle_end_date"]
                ]

        # Optionally, remove duplicates
        unique_service_providers = sorted(list(set(service_providers)))

        # Add "All" to the list of unique service providers
        unique_service_providers.insert(0, "All service providers")
    try:
        audit_data_user_actions = {
            "service_name": "Module_management",
            "created_date": data.get("request_received_at", ""),
            "created_by": data.get("username", ""),
            "status": "Success",
            "session_id": data.get("sessionID", ""),
            "tenant_name": data.get("Partner", ""),
            "module_name": "Module_management",
            "comments": "reports_dropdown_data_export",
            "request_received_at": data.get("request_received_at", ""),
        }

        dbs.update_audit(audit_data_user_actions, "audit_user_actions")
    except Exception as e:
        logging.warning(f"Exception is {e}")

    return {
        "flag": True,
        "unique_service_providers": unique_service_providers,
        "billing_period_dates": service_provider_dict,
        "cross_provider": False if int(p) == 0 else True,
    }

def reports_data_with_date_filter(data):
    """
    This function retrieves report data by executing a query based
    on the provided module name and parameters,
    converting the results into a dictionary format.
    It logs the audit and error details to the database
    and returns the report data along with a success flag.
    """
    # Start time  and date calculation
    start_time = time.time()
    module_name = data.get("module_name", "")
    # logging.info("module_name",module_name)
    request_received_at = data.get("request_received_at", "")
    session_id = data.get("session_id", "")
    username = data.get("username", None)
    Partner = data.get("Partner", "")
    mod_pages = data.get("mod_pages", {})
    logging.info("##mod_pages", mod_pages)
    limit = mod_pages.get("end", 100)
    offset = mod_pages.get("start", 0)
    start_date = data.get("start_date", "")
    end_date = data.get("end_date", "")
    role_name = data.get("role_name", "")
    col_sort = data.get("col_sort", "")
    ##Database connection
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    return_json_data = {}
    logging.info(
        f"Report request for module: {module_name}, Username: {username}, Partner: {Partner}"
    )
    try:
        # Fetch the query from the database based on the module name
        module_query_df = common_utils_database.get_data(
            "export_queries", {"module_name": module_name}
        )
        # logging.info(module_query_df,'module_query_df')
        ##checking the dataframe is empty or not
        if module_query_df.empty:
            return {
                "flag": False,
                "message": f"No query found for module name: {module_name}",
            }
        # Extract the query string from the DataFrame
        query = module_query_df.iloc[0]["module_query"]
        if not query:
            logging.warning(f"No query defined for module name: {module_name}")
            return {"flag": False, "message": f"Unknown  module name: {module_name}"}
        start_date = start_date + " 00:00:00"
        end_date = end_date + " 23:59:59"
        params = [start_date, end_date, limit, offset]
        ##executing the query

        if col_sort:
            # Remove existing ORDER BY clause
            order_by_pattern = r"\sORDER\s+BY\s+[^)]+(?=\s*LIMIT)"
            query = re.sub(order_by_pattern, "", query, flags=re.IGNORECASE)

            # Extract the single key-value pair
            key, value = list(col_sort.items())[0]

            # Ensure ORDER BY comes before LIMIT and OFFSET
            limit_offset_match = re.search(
                r"(LIMIT\s+%s\s+OFFSET\s+%s)", query, re.IGNORECASE
            )

            if limit_offset_match:
                # Replace LIMIT and OFFSET with ORDER BY correctly placed
                limit_offset_clause = limit_offset_match.group(1)
                query = query.replace(
                    limit_offset_clause,
                    f"ORDER BY {key} {value.upper()} {limit_offset_clause}",
                )
            else:
                # Append ORDER BY at the end if no LIMIT and OFFSET found
                query += f" ORDER BY {key} {value.upper()}"

        df = database.execute_query(query, params=params)
        # Convert dataframe to dictionary
        df_dict = df.to_dict(orient="records")
        for record in df_dict:
            for key, value in record.items():
                if isinstance(value, pd.Timestamp):
                    record[key] = value.strftime("%m-%d-%Y %H:%M:%S")
        headers_map = get_headers_mapping(
            tenant_database,
            [module_name],
            role_name,
            "username",
            "main_tenant_id",
            "sub_parent_module",
            "parent_module",
            data,
            common_utils_database,
        )
        logging.info(f"## Report written Successfully")
        return_json_data.update(
            {
                "message": "Successfully generated the report",
                "flag": True,
                "headers_map": headers_map,
                "data": df_dict,
            }
        )
        try:
            # End time calculation
            end_time = time.time()
            time_consumed = f"{end_time - start_time:.4f}"
            time_consumed = int(float(time_consumed))
            audit_data_user_actions = {
                "service_name": "Module Management",
                "created_date": request_received_at,
                "created_by": username,
                "status": str(return_json_data["flag"]),
                "time_consumed_secs": time_consumed,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": "Reports data",
                "module_name": "Reports",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
            logging.info("Audit log recorded successfully")
        except Exception as e:
            logging.exception(f"exception is {e}")
        return return_json_data
    except Exception as e:
        logging.exception(f"An error occurred: {e}")
        message = f"Unable to fetch the reports data"
        response = {"flag": False, "message": message}
        error_type = str(type(e).__name__)
        try:
            # Log error to database
            error_data = {
                "service_name": "update_superadmin_data",
                "created_date": request_received_at,
                "error_message": message,
                "error_type": error_type,
                "users": username,
                "session_id": session_id,
                "tenant_name": Partner,
                "comments": "",
                "module_name": "People Module",
                "request_received_at": request_received_at,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
            logging.info("Error details logged successfully")
        except Exception as e:
            logging.exception(f"exception is {e}")
        return response



def get_optimization_setting_details(data):
    logging.info("Request Recieved")
    # Record the start time for performance measurement
    start_time = time.time()
    session_id = data.get("session_id")
    tenant_database = data.get("db_name", "")
    username = data.get("username", "")
    module_name = data.get("module_name", "")
    partner = data.get("Partner", "")
    request_received_at = data.get("request_received_at", "")
    tenant_name = data.get("tenant_name", "")
    try:
        # database Connection
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    except Exception as db_exception:
        logging.error("Failed to connect to the database: %s", str(db_exception))
    if tenant_name == "Altaworx Test":
        tenant_name = "Altaworx"

    # tenant and sub tenants
    try:
        parent_tenant_id=common_utils_database.get_data("tenant",{"tenant_name":tenant_name},["id"])["id"].to_list()[0]
        if parent_tenant_id:
            sub_tenants=common_utils_database.get_data("tenant",{"parent_tenant_id":parent_tenant_id},["tenant_name"])["tenant_name"].to_list()
            parent_tenant=[tenant_name]
        else:
            sub_tenants=[tenant_name]
            parent_tenant=[]
    except Exception as e:
        parent_tenant=[]
        sub_tenants=[]
    
    tenant_details={
        "parent_tenant":parent_tenant,
        "sub_tenants":sorted(sub_tenants)
    }
    tenant_id = common_utils_database.get_data(
        "tenant", {"tenant_name": tenant_name}, ["id"]
    )["id"].to_list()[0]
    optimization_setting_dataframe = database.get_data(
        "optimization_setting", {"tenant_id": tenant_id}
    )
    optimization_setting_dataframe = optimization_setting_dataframe.astype("str")
    optimization_setting_data = optimization_setting_dataframe.to_dict(orient="records")
    response = {"flag": True, "optimization_setting_data": optimization_setting_data,"tenant_details":tenant_details}
    try:
        audit_data_user_actions = {
            "service_name": "Module_management",
            "created_date": data.get("request_received_at", ""),
            "created_by": data.get("username", ""),
            "status": "Success",
            "session_id": data.get("sessionID", ""),
            "tenant_name": data.get("Partner", ""),
            "module_name": "Module_management",
            "comments": "get_user_module_map",
            "request_received_at": data.get("request_received_at", ""),
        }

        common_utils_database.update_audit(
            audit_data_user_actions, "audit_user_actions"
        )
    except Exception as e:
        logging.warning(f"Exception is {e}")
    return response


def update_optimization_setting_details(data):
    """
    The update_optimization_setting_details function updates the settings  and
    other relevant data for a specific id in the optimization_setting table.
    It takes the changed_data (the data to be updated) and the id for tenant
    (identifier for the SIM) from the request.
    The function attempts to update the record and returns a success message
    if the update is successful. If an exception occurs during the update process,
    it logs the exception and continues.
    """
    logging.info("Request Recieved")
    # Database connection
    # Extract database name and validate
    tenant_database = data.get("db_name", "")
    if not tenant_database:
        logging.warning("Database name is missing in the request data")
    try:
        # Establishing the database connection
        database = DB(tenant_database, **db_config)
        common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        logging.info(f"Connected to the database")
    except Exception as db_exception:
        logging.error(f"Failed to connect to the database")
        return {"flag": False, "message": "Database connection failed."}
    changed_data = data.get("changed_data", "")
    list_view_id = changed_data.get("id")
    logging.info(f"List view Id is :{list_view_id}")
    try:
        # Ensure 'id' is removed, but the rest of the data remains as a dictionary
        if "id" in changed_data:
            changed_data.pop("id")
        changed_data.pop("id_10")
        database.update_dict("optimization_setting", changed_data, {"id": list_view_id})
        try:
            audit_data_user_actions = {
                "service_name": "Module_management",
                "created_date": data.get("request_received_at", ""),
                "created_by": data.get("username", ""),
                "status": "Success",
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "module_name": "Module_management",
                "comments": "get_user_module_map",
                "request_received_at": data.get("request_received_at", ""),
            }

            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"Exception is {e}")
        return {"flag": True, "message": "Updated Successfully"}
    except Exception as e:
        logging.exception(f"Exception is {e}")
        common_utils_database.log_error_to_db(
            {
                "service_name": "Module Management",
                "created_date": data.get("request_received_at", ""),
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": str(e),
                "module_name": "update_optimization_setting_details",
                "request_received_at": data.get("request_received_at", ""),
            },
            "error_log_table",
        )
        return {"flag": False, "message": "Failed to Update!!!"}


def get_integration_data(data):
    """
    Fetch integration data and determine authenticated status.

    Args:
        data: Input data (if required for the query logic).

    Returns:
        List of dictionaries containing label and authenticated status.
    """
    tenant_database = data.get("db_name", "altaworx_central")
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    database = DB(tenant_database, **db_config)
    tenant_name = data.get("tenant_name", "")
    result_dict = {}

    try:

        if tenant_name == "Altaworx Test":
            tenant_id = [1]  # Include the hardcoded ID
            # Fetch the ID from the database as well
            db_tenant_id = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["id"]
            )["id"].to_list()
            tenant_id.extend(db_tenant_id)  # Combine both IDs
        else:
            # Default case: fetch only from the database
            tenant_id = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["id"]
            )["id"].to_list()
        tenant_id = list(tenant_id)

        # Get integration and integration_connection data from common database
        integration_query = """
            SELECT
                IC.id AS ic_id,
                IC.integration_id,
                I.id AS i_id,
                I.name AS i_name,
                I.authentication_type,
                I.has_service_provider
            FROM integration_connection IC
            LEFT JOIN integration I on I.id = IC.integration_id
            WHERE IC.is_deleted = false
        """

        # Get service provider data from altaworx database
        service_provider_query = f"""
            SELECT
                id AS s_id,
                tenant_id AS s_tenant_id,
                integration_id AS s_integration_id,
                service_provider_name AS s_name
            FROM serviceprovider
            WHERE is_deleted = false
            and tenant_id in ({','.join(map(str, tenant_id))})
        """

        # Get data from common database
        integration_data = common_utils_database.execute_query(
            integration_query, True
        ).to_dict(orient="records")

        # Get service provider data from altaworx database
        service_providers = database.execute_query(
            service_provider_query, True
        ).to_dict(orient="records")

        # Create a dictionary of service providers keyed by integration_id
        sp_by_integration = {}
        for sp in service_providers:
            if sp["s_integration_id"] not in sp_by_integration:
                sp_by_integration[sp["s_integration_id"]] = []
            sp_by_integration[sp["s_integration_id"]].append(sp)

        # Combine the data
        all_records = []

        for record in integration_data:
            # Check for service providers related to this integration
            sps = sp_by_integration.get(record["integration_id"], [])

            if sps:
                # If there are service providers, add a record for each one
                for sp in sps:
                    combined_record = {**record}
                    combined_record.update(sp)
                    all_records.append(combined_record)
            else:
                # If no service providers, add the record with has_service_provider = False
                if not record["has_service_provider"]:
                    combined_record = {**record}
                    combined_record.update(
                        {
                            "s_id": None,
                            "s_tenant_id": None,
                            "s_integration_id": None,
                            "s_name": None,
                        }
                    )
                    all_records.append(combined_record)


        result = []

        for record in all_records:
            authentication_type = record.get("authentication_type")
            if record.get("s_id") and record["s_tenant_id"]:
                query_integration_authentication = f"""
                    SELECT * FROM integration_authentication
                    WHERE integration_id = {record['i_id']}
                    AND tenant_id in ({','.join(map(str, tenant_id))})
                    AND is_active = TRUE
                    AND service_provider_id = {record['s_id']}
                """
            else:
                query_integration_authentication = f"""
                    SELECT * FROM integration_authentication
                    WHERE integration_id = {record['i_id']}
                    AND is_active = TRUE
                """

            auth_results = common_utils_database.execute_query(
                query_integration_authentication, True
            )

            if not auth_results.empty:
                auth_results = auth_results.to_dict(orient="records")
                authenticated = bool(auth_results and len(auth_results) > 0)
            else:
                authenticated = False

            label = record["s_name"] if record.get("s_name") else record["i_name"]

            result.append(
                {
                    "label": label,
                    "authenticated": authenticated,  # True if authentication results exist, otherwise False
                    "integration_id": record["integration_id"],
                    "authentication_type": authentication_type,
                }
            )

        intergation_details = """SELECT DISTINCT ON (ia.integration_id, ia.authentication_type)
            ia.integration_id,
            ia.authentication_type,
            ia.*,
            json_agg(
                json_build_object(
                    'setting_key', sps.setting_key,
                    'setting_value', sps.setting_value
                )
            ) AS settings
        FROM
            public.integration_authentication ia
        LEFT JOIN
            public.service_provider_setting sps
        ON
            ia.service_provider_id = sps.service_provider_id
        WHERE
            ia.is_active = TRUE
            AND (ia.service_provider_id IS NOT NULL OR ia.integration_id IS NOT NULL)
        GROUP BY
            ia.integration_id, ia.authentication_type, ia.id
        ORDER BY
            ia.integration_id, ia.authentication_type, ia.id;"""
        intergation_details = database.execute_query(intergation_details, True).to_dict(
            orient="records"
        )

        result_dict["intergation_details"] = intergation_details

        result = sorted(result, key=lambda x: x["label"])

        result_dict["connections"] = result

        try:
            audit_data_user_actions = {
                "service_name": "Module_management",
                "created_date": data.get("request_received_at", ""),
                "created_by": data.get("username", ""),
                "status": "Success",
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "module_name": "Module_management",
                "comments": "get_user_module_map",
                "request_received_at": data.get("request_received_at", ""),
            }

            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"Exception is {e}")

        return serialize_data(result_dict)
    except Exception as e:
        logging.exception(f"An error occurred: {str(e)}")
        common_utils_database.log_error_to_db(
            {
                "service_name": "Module Management",
                "created_date": data.get("request_received_at", ""),
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": str(e),
                "module_name": "export",
                "request_received_at": data.get("request_received_at", ""),
            },
            "error_log_table",
        )
        return {"flag": True, "message": f"Unable to fetch integration data"}


import xml.etree.ElementTree as ET


def save_integration_details(data):
    tenant_name = data.get("tenant_name", "")
    """
    Save integration data filtered by service_provider_id, integration_id, and authentication_type.
    """
    tenant_database = data.get("db_name", "altaworx_test")
    try:

        # Validate input data
        if not isinstance(data, dict):
            return {
                "flag": False,
                "message": "Invalid data format. Expected a dictionary.",
            }
        changed_data = data.get("changed_data", {})
        if not isinstance(changed_data, dict):
            return {
                "flag": False,
                "message": "Invalid or missing 'changed_data'. Expected a dictionary.",
            }
        service_provider_id = changed_data.get("service_provider_id")
        integration_id = changed_data.get("integration_id")
        authentication_type = changed_data.get("authentication_type")
        record_id = changed_data.get(
            "id"
        )  # Use 'id' if service_provider_id is not provided

        if not (
            service_provider_id or (integration_id and authentication_type) or record_id
        ):
            return {
                "flag": False,
                "message": "Missing required fields: service_provider_id, integration_id, authentication_type, or id.",
            }

        # Define base where condition
        where_dict = {}
        if service_provider_id is not None:
            where_dict["service_provider_id"] = service_provider_id
        elif (
            record_id is not None
        ):  # Use 'id' for filtering if service_provider_id is not present
            where_dict["id"] = record_id
        else:
            where_dict.update(
                {
                    "integration_id": integration_id,
                    "authentication_type": authentication_type,
                }
            )

        # Prepare data for insertion based on conditions
        insert_data = {}
        if tenant_name=='Altaworx Test':
            tenant_name='Altaworx'

        json_data = load_json()
        telegence_ids = get_provider_ids(json_data, tenant_name, ["Telegence"])
        bandwidthids = get_provider_ids(json_data, tenant_name, ["Bandwidth"])
        koreids = get_provider_ids(json_data, tenant_name, ["Koremain"])
        pond_iot_ids = get_provider_ids(json_data, tenant_name, ["POND IoT"])
        webbing_ids = get_provider_ids(json_data, tenant_name, ["Webbing"])
        verizon_thingspaceiot_ids = get_provider_ids(json_data, tenant_name, ["Verizon - ThingSpace IoT"])
        ciscojasper_ids = get_provider_ids(json_data, tenant_name, ["Cisco Jasper"])
        condition_ids = get_provider_ids(json_data, tenant_name, ["Teal","POND IoT"])
        condition2_ids = get_provider_ids(json_data, tenant_name, ["T-Mobile - Advantage","AT&T - POD19","T-Mobile","Rogers"])
        # Convert the comma-separated string into a list
        if service_provider_id in telegence_ids:
            insert_data = {
                "oauth2_client_id": changed_data.get("oauth2_client_id"),
                "oauth2_client_secret": changed_data.get("oauth2_client_secret"),
                "username": changed_data.get("username"),
                "password": changed_data.get("password"),
                "modified_by": changed_data.get("modified_by"),
                "modified_date": changed_data.get("modified_date"),
            }
        elif service_provider_id in bandwidthids:
            insert_data = {
                "oauth2_custom1": changed_data.get("oauth2_custom1"),
                "username": changed_data.get("username"),
                "password": changed_data.get("password"),
                "modified_by": changed_data.get("modified_by"),
                "modified_date": changed_data.get("modified_date"),
            }
        elif service_provider_id in koreids:
            insert_data = {
                "oauth2_client_id": changed_data.get("oauth2_client_id"),
                "oauth2_client_secret": changed_data.get("oauth2_client_secret"),
                "token_value": changed_data.get("token_value"),
                "token_variable_name": changed_data.get("token_variable_name"),
            }
        elif service_provider_id in pond_iot_ids:
            insert_data = {
                "username": changed_data.get("username"),
                "password": changed_data.get("password"),
                "oauth2_custom1": changed_data.get("oauth2_custom1"),
                "oauth2_custom2": changed_data.get("oauth2_custom2"),
                "modified_by": changed_data.get("modified_by"),
                "modified_date": changed_data.get("modified_date"),
            }
        elif service_provider_id in verizon_thingspaceiot_ids:
            insert_data = {
                "username": changed_data.get("username"),
                "password": changed_data.get("password"),
                "modified_by": changed_data.get("modified_by"),
                "modified_date": changed_data.get("modified_date"),
            }
        elif authentication_type == 15 and integration_id == 14:
            insert_data = {"oauth2_custom1": changed_data.get("oauth2_custom1")}
        elif authentication_type in {13, 1} and integration_id == 3:
            insert_data = {
                "username": changed_data.get("username"),
                "rev_bill_profile": changed_data.get("rev_bill_profile"),
                "password": changed_data.get("password"),
                "token_value": changed_data.get("token_value"),
                "modified_by": changed_data.get("modified_by"),
                "modified_date": changed_data.get("modified_date"),
            }

        elif service_provider_id in bandwidthids:
            insert_data = {
                "oauth2_client_id": changed_data.get("oauth2_client_id"),
                "oauth2_client_secret": changed_data.get("oauth2_client_secret"),
                "token_value": changed_data.get("token_value"),
                "token_variable_name": changed_data.get("token_variable_name"),
                "modified_by": changed_data.get("modified_by"),
                "modified_date": changed_data.get("modified_date"),
            }
        elif authentication_type == 16 and integration_id == 16:
            insert_data = {
                "realm_id": changed_data.get("realm_id"),
                "password": changed_data.get("password"),
                "modified_by": changed_data.get("modified_by"),
                "modified_date": changed_data.get("modified_date"),
            }
        elif authentication_type == 3 and integration_id == 17:
            insert_data = {
                "oauth2_custom1": changed_data.get("oauth2_custom1"),
                "oauth2_client_secret": changed_data.get("oauth2_client_secret"),
                "oauth2_client_id": changed_data.get("oauth2_client_id"),
                "modified_by": changed_data.get("modified_by"),
                "modified_date": changed_data.get("modified_date"),
            }
        elif authentication_type == 4 and integration_id == 5:
            insert_data = {
                "oauth2_custom2": changed_data.get("oauth2_custom2"),
                "oauth2_client_id": changed_data.get("oauth2_client_id"),
                "oauth2_client_secret": changed_data.get("oauth2_client_secret"),
                "username": changed_data.get("username"),
                "password": changed_data.get("password"),
                "modified_by": changed_data.get("modified_by"),
                "modified_date": changed_data.get("modified_date"),
            }
        elif service_provider_id in condition_ids:
            insert_data = {
                # "oauth2_client_id": changed_data.get("oauth2_client_id"),
                # "oauth2_client_secret": changed_data.get("oauth2_client_secret"),
                "username": changed_data.get("username"),
                "password": changed_data.get("password"),
                "modified_by": changed_data.get("modified_by"),
                "modified_date": changed_data.get("modified_date"),
                "is_active": True
            }
        elif service_provider_id in webbing_ids:
            insert_data = {
                "username": changed_data.get("oauth2_client_id"),
                "password": changed_data.get("oauth2_client_secret"),
                "token_value": changed_data.get("token_value"),
                "oauth2_custom1": changed_data.get("oauth2_custom1"),
                "oauth2_custom2": changed_data.get("oauth2_custom2"),
                "oauth2_custom3": changed_data.get("oauth2_custom3"),
                "oauth2_custom4": changed_data.get("oauth2_custom4")
            }
        elif service_provider_id in ciscojasper_ids:
            settings = changed_data.get("settings", [])
            if not isinstance(settings, list):
                return {"flag": False, "message": "Settings must be a list."}
            for idx, setting in enumerate(settings):
                setting_key = setting.get("setting_key")
                setting_value = setting.get("setting_value")
                if not setting_key or setting_value is None:
                    continue
                response = update_settings(
                    setting_key, setting_value, service_provider_id,tenant_database
                )
            return {
                "flag": True,
                "message": "Updated successfully for service_provider.",
            }

        elif service_provider_id in condition2_ids:
            settings = changed_data.get("settings", [])
            if not isinstance(settings, list):
                return {"flag": False, "message": "Settings must be a list."}
            for idx, setting in enumerate(settings):
                setting_key = setting.get("setting_key")
                setting_value = setting.get("setting_value")
                if not setting_key or setting_value is None:
                    continue
                response = update_settings(
                    setting_key, setting_value, service_provider_id,tenant_database
                )
                if not response["flag"]:
                    return response
            insert_data = {
                "username": changed_data.get("username"),
                "password": changed_data.get("password"),
            }

        # If no valid insert data, skip update
        if not insert_data:
            return {"flag": False, "message": "No valid data found to update."}
        # telegence_integration_ids = get_integration_id_by_unique_name(json_data, tenant_name, "Telegence")
        # kore_integration_ids = get_integration_id_by_unique_name(json_data, tenant_name, "Koremain")
        # testv2_ids = get_integration_id_by_unique_name(json_data, tenant_name, "testv2")
        # verizon_thingspaceiot_integration_ids = get_integration_id_by_unique_name(json_data, tenant_name, "Verizon - ThingSpace IoT")
        # bandwidth_integration_ids = get_integration_id_by_unique_name(json_data, tenant_name, "Bandwidth")
        # qatest_integration_ids = get_integration_id_by_unique_name(json_data, tenant_name, "QA test")
        # teal_integration_ids = get_integration_id_by_unique_name(json_data, tenant_name, "Teal")
        # pond_integration_ids = get_integration_id_by_unique_name(json_data, tenant_name, "POND")
        telegence_integration_ids = [get_integration_id_by_unique_name(json_data, tenant_name, "Telegence")]
        kore_integration_ids = [get_integration_id_by_unique_name(json_data, tenant_name, "Koremain")]
        testv2_ids = [get_integration_id_by_unique_name(json_data, tenant_name, "testv2")]
        verizon_thingspaceiot_integration_ids = [get_integration_id_by_unique_name(json_data, tenant_name, "Verizon - ThingSpace IoT")]
        bandwidth_integration_ids = [get_integration_id_by_unique_name(json_data, tenant_name, "Bandwidth")]
        qatest_integration_ids = [get_integration_id_by_unique_name(json_data, tenant_name, "QA test")]
        teal_integration_ids = [get_integration_id_by_unique_name(json_data, tenant_name, "Teal")]
        pond_integration_ids = [get_integration_id_by_unique_name(json_data, tenant_name, "POND")]
        webbing_integration_ids = [get_integration_id_by_unique_name(json_data, tenant_name, "Webbing")]

        if integration_id  in telegence_integration_ids:
            integration_id = integration_id
            # Dynamically construct the URL and headers
            api_url_base = changed_data.get(
                "oauth2_custom2"
            )  # base URL ( https://apsapi.att.com:8082)

            try:
                dbs = DB(data.get("db_name"), **db_config)
                api_endpoint_url = dbs.get_data(
                    "integration_connection",
                    {"integration_id": integration_id, "is_active": True},
                    ["auth_test_url"],
                )["auth_test_url"].to_list()[0]

            except Exception as e:
                logging.exception(f"Error updating api_endpoint_url: {e}")

            url = api_url_base + api_endpoint_url  # Construct the full URL


            # Extract headers from the changed data
            app_id = changed_data.get("oauth2_client_id")
            app_secret = changed_data.get("oauth2_client_secret")

            # Validate that necessary values are present
            if not app_id or not app_secret:
                return {
                    "flag": False,
                    "message": "Missing app_id or app_secret in changed_data.",
                }

            headers = {"app-id": app_id, "app-secret": app_secret}


            api_response = requests.get(url, headers=headers)

        elif integration_id in kore_integration_ids:
            client_id = changed_data.get("oauth2_client_id")
            client_secret = changed_data.get("oauth2_client_secret")
            api_key = changed_data.get("token_value")
            email = changed_data.get("token_variable_name")
            integration_id = integration_id

            try:
                dbs = DB(data.get("db_name"), **db_config)
                endpoint_data = dbs.get_data(
                    "integration_connection",
                    {"integration_id": integration_id, "is_active": True},
                    ["production_url"],
                )["production_url"].to_list()[0]

            except Exception as e:
                logging.exception(f"Error updating api_endpoint_url: {e}")

            production_url = endpoint_data
            api_endpoint_url = f"{production_url}/v1/accounts?email={email}"
            access_token = get_access_token(client_id, client_secret)
            print(access_token, "12345")

            url = api_endpoint_url

            print(url, "1234567890")

            headers = {
                "Accept": "application/json",
                "Authorization": f"Bearer {access_token}",
            }
            if api_key:
                api_key = api_key[0] if isinstance(api_key, tuple) else api_key
                headers["x-api-key"] = api_key

            api_response = requests.get(url, headers=headers)

        elif integration_id in webbing_integration_ids:
            username = changed_data.get("username")
            password = changed_data.get("password")
            token_value = changed_data.get("token_value")
            integration_id = integration_id

            try:
                dbs = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
                endpoint_data = dbs.get_data(
                    "integration_connection",
                    {"integration_id": integration_id, "is_active": True},
                    ["production_url"],
                )["production_url"].to_list()[0]

            except Exception as e:
                logging.exception(f"Error updating api_endpoint_url: {e}")

            production_url = endpoint_data
            api_endpoint_url = production_url
            print(api_endpoint_url, "0987654321234567890")
            soap_body = f"""<?xml version="1.0" encoding="utf-8"?>
                <soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
                <soap:Header>
                    <Credentials xmlns="http://wws.iamwebbing.com/">
                        <Username>{username}</Username>
                        <Password>{password}</Password>
                        <WSKey>{token_value}</WSKey>
                    </Credentials>
                </soap:Header>
                <soap:Body>
                    <GetAccount xmlns="http://wws.iamwebbing.com/">
                    <GetAccountRequest>
                        <AccountID>{int(1)}</AccountID>
                    </GetAccountRequest>
                    </GetAccount>
                </soap:Body>
                </soap:Envelope>"""

            url = "https://wws.iamwebbing.com/accounts/Accounts.asmx"

            headers = {
                "Content-Type": "text/xml; charset=utf-8",
                "SOAPAction": f"http://wws.iamwebbing.com/GetAccount"
            }




            print(soap_body, "1234")
            print(headers, "mnbvcxzxcvb")
            api_response = requests.post(url, data=soap_body, headers=headers)


        elif integration_id in testv2_ids:
            x_api_key = changed_data.get("oauth2_custom1")
            integration_id = integration_id

            try:
                dbs = DB(data.get("db_name"), **db_config)
                endpoint_data = dbs.get_data(
                    "integration_connection",
                    {"integration_id": integration_id, "is_active": True},
                    ["sandbox_url", "auth_test_url"],
                )["sandbox_url", "auth_test_url"].to_list()[0]
            except Exception as e:
                logging.exception(f"Error updating api_endpoint_url: {e}")

            sandbox_url_template = endpoint_data["sandbox_url"].to_list()[0]
            auth_test_url = endpoint_data["auth_test_url"].to_list()[0]
            sandbox_url = sandbox_url_template.format("calc")
            api_endpoint_url = f"{sandbox_url}{auth_test_url}"

            url = api_endpoint_url

            # Validate that necessary values are present
            if not x_api_key:
                return {
                    "flag": False,
                    "message": "Missing app_id or app_secret in changed_data.",
                }

            headers = {"Accept": "application/json", "x-api-key": x_api_key}

            api_response = requests.get(url, headers=headers)
        elif integration_id in verizon_thingspaceiot_integration_ids:
            integration_id = integration_id
            try:
                # Initialize the database connection
                dbs = DB(data.get("db_name"), **db_config)

                # Fetch production_url from the database
                endpoint_data = dbs.get_data(
                    "integration_connection",
                    {"integration_id": integration_id, "is_active": True},
                    ["production_url"],
                )
            except Exception as e:
                logging.exception(f"Error updating api_endpoint_url: {e}")
                endpoint_data = None
            # Endpoint and credentials for token
            # url = 'https://thingspace.verizon.com/api/ts/v1/oauth2/token?grant_type=client_credentials'
            baseurl = endpoint_data["production_url"].to_list()[0]

            # Define the additional path and query parameters
            auth_test_url = changed_data.get("oauth2_token_url")
            query_params = "?grant_type=client_credentials"

            # Combine base URL, auth URL, and query parameters
            url = f"{baseurl}{auth_test_url}{query_params}"
            clientid = changed_data.get("oauth2_client_id")
            # clientid = "RvxMbfpulNVNBU2FpSnBZ2QSai8a"
            clientsecret = changed_data.get("oauth2_client_secret")
            # clientsecret = "5Con_pshpyYfjZ1PMCuBePGS7fQa"

            username = changed_data.get("username")
            password = changed_data.get("password")

            # Combine client ID and secret
            credentials = f"{clientid}:{clientsecret}"

            # Encode credentials as base64
            encoded_credentials = base64.b64encode(credentials.encode()).decode()

            # Set headers for token request
            headers = {
                "Accept": "application/json",
                "Authorization": f"Basic {encoded_credentials}",
            }

            # Send POST request for token
            api_response_data = requests.post(url, headers=headers)

            logging.info("Status Code:", api_response_data.status_code)
            if api_response_data.status_code == 200:
                # Parse the JSON response
                response_data = api_response_data.json()
                baseurl = baseurl
                try:
                    # Initialize the database connection
                    dbs = DB(data.get("db_name"), **db_config)

                    # Fetch production_url from the database
                    endpoint_data = dbs.get_data(
                        "integration_connection",
                        {"integration_id": integration_id, "is_active": True},
                        ["production_url"],
                    )
                except Exception as e:
                    logging.exception(f"Error updating api_endpoint_url: {e}")
                    endpoint_data = None

                auth_test_url = changed_data.get("oauth2_authorization_url")

                # Extract the access token
                access_token = response_data.get("access_token")

                if access_token:
                    url = f"{baseurl}{auth_test_url}"
                    # Use access token for login request
                    # url = "https://thingspace.verizon.com/api/m2m/v1/session/login"

                    # Set the Authorization header using Bearer token
                    headers = {
                        "Accept": "application/json",
                        "Authorization": f"Bearer {access_token}",  # Corrected authorization scheme
                    }

                    # Login body with username and password
                    body = {"username": username, "password": password}

                    body["password"] = base64.b64decode(body["password"]).decode()

                    # Send POST request to login
                    api_response = requests.post(url, headers=headers, json=body)

                    # Print the login response status and body
                    logging.info("Login Status Code:", api_response.status_code)
                else:
                    logging.info("Access token not found.")
            else:
                logging.info(f"Error: {api_response.status_code}")

        elif integration_id in bandwidth_integration_ids:
            integration_id = integration_id
            account = changed_data.get("oauth2_custom1")

            try:
                # Initialize the database connection
                dbs = DB(data.get("db_name"), **db_config)

                # Fetch production_url from the database
                endpoint_data = dbs.get_data(
                    "integration_connection",
                    {"integration_id": integration_id, "is_active": True},
                    ["production_url", "auth_test_url"],
                )
            except Exception as e:
                logging.exception(f"Error updating api_endpoint_url: {e}")
                endpoint_data = None

            production_url = endpoint_data["production_url"].to_list()[0]
            auth_url = endpoint_data["auth_test_url"].to_list()[0]

            url = f"{production_url}{auth_url}{account}"

            # url = 'https://dashboard.bandwidth.com/api/accounts/5001532'

            username = changed_data.get("username")
            password = changed_data.get("password")
            # username= "fderr"
            # password = "QldAUGkhMjM0"

            password_1 = base64.b64decode(password).decode()
            credentials = f"{username}:{password_1}"

            encoded = base64.b64encode(credentials.encode()).decode()

            # print(encoded)

            # encoded = 'ZmRlcnI6QldAUGkhMjM0'

            headers = {"Authorization": f"Basic {encoded}"}

            api_response = requests.get(url, headers=headers)
        elif integration_id in qatest_integration_ids:
            integration_id = integration_id
            try:
                # Initialize the database connection
                dbs = DB(data.get("db_name"), **db_config)

                # Fetch production_url from the database
                endpoint_data = dbs.get_data(
                    "integration_connection",
                    {"integration_id": integration_id, "is_active": True},
                    ["auth_test_url"],
                )
            except Exception as e:
                logging.exception(f"Error updating api_endpoint_url: {e}")
                endpoint_data = None

            url = endpoint_data["auth_test_url"].to_list()[0]

            # url = 'https://api.revioapi.com/v1/Customers'

            username = changed_data.get("username")
            password = changed_data.get("password")
            token_value = changed_data.get("token_value")

            # username = "AMOPToRevio@altaworx_sandbox"
            # password = "R2VvbG9neTdAU2hvd2luZ0BTdGFuaw=="

            # Combine client ID and secret
            credentials = f"{username}:{password}"

            # Encode credentials as base64
            encoded_credentials = base64.b64encode(credentials.encode()).decode()
            headers = {
                "Accept": "application/json",
                "Ocp-Apim-Subscription-Key": token_value,
                "Authorization": f"Basic {encoded_credentials}",
            }
            api_response = requests.get(url, headers=headers)
        elif integration_id == 17:
            integration_id = integration_id
            client_id = changed_data.get("oauth2_client_id")
            client_secret = changed_data.get("oauth2_custom2")

            try:
                # Initialize the database connection
                dbs = DB(data.get("db_name"), **db_config)

                # Fetch production_url from the database
                endpoint_data = dbs.get_data(
                    "integration_connection",
                    {"integration_id": integration_id, "is_active": True},
                    ["sandbox_url", "auth_test_url"],
                )
            except Exception as e:
                logging.exception(f"Error updating api_endpoint_url: {e}")
                endpoint_data = None

            sandbox_test_url = endpoint_data["sandbox_url"].to_list()[0]
            auth_test1_url = endpoint_data["auth_test_url"].to_list()[0]

            url = f"{sandbox_test_url}{auth_test1_url}"

            # url = 'https://lgw.att.com/aps/service/v3/oauth2/token'
            body = {
                "grant_type": "client_credentials",
                "client_id": client_id,
                "client_secret": client_secret,
            }
            api_response = requests.post(url, json=body)
        elif integration_id == 5:
            url = changed_data.get("oauth2_custom2")
            client_id = changed_data.get("oauth2_client_id")
            client_secret = changed_data.get("oauth2_custom2")
            username = changed_data.get("username")
            password = changed_data.get("password")

            decoded_password = base64.b64decode(password).decode("utf-8")

            # url = "https://api.netsapiens.com/ns-api/apidoc/"
            # url = "https://api.netsapiens.com/ns-api/apidoc/#api-Reseller-Read"
            params = {
                "grant_type": "password",
                "client_id": client_id,
                "client_secret": client_secret,
                "username": username,
                "password": decoded_password,
            }

            # Headers
            headers = {
                "Accept": "application/json",
            }

            # Make the request
            api_response = requests.get(url, headers=headers, params=params)
        elif integration_id in teal_integration_ids:
            username = changed_data.get("username")
            password = changed_data.get("password")
            decoded_password = base64.b64decode(password).decode("utf-8")

            integration_id = integration_id
            try:
                # Initialize the database connection
                dbs = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

                # Fetch production_url from the database
                endpoint_data = dbs.get_data(
                    "integration_connection",
                    {"integration_id": integration_id, "is_active": True},
                    ["sandbox_url", "auth_test_url"],
                )
            except Exception as e:
                logging.exception(f"Error updating api_endpoint_url: {e}")
                endpoint_data = None

            sandbox_test_url = endpoint_data["sandbox_url"].to_list()[0]
            auth_test1_url = endpoint_data["auth_test_url"].to_list()[0]

            base_url = f"{sandbox_test_url}{auth_test1_url}"

            # base_url = "https://integrationapi.teal.global/api/v1/esims"

            # Generate the current datetime in the required format
            current_datetime = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
            request_id = f"GetDevice_{current_datetime}"

            # Construct the full URL with the updated datetime
            url = f"{base_url}?requestId={request_id}"

            # Headers
            headers = {
                "ApiKey": username,
                "ApiSecret": decoded_password,
                "Accept": "application/json",
            }

            # Make the GET request
            api_response = requests.get(url, headers=headers)
        elif integration_id in pond_integration_ids:
            DistributorId = changed_data.get("oauth2_custom2")
            username = changed_data.get("username")
            password = changed_data.get("password")
            oauth2_custom1 = changed_data.get("oauth2_custom1")

            try:
                # Initialize the database connection
                dbs = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)

                if tenant_name=='Altaworx Test':
                    # Fetch production_url from the database
                    endpoint_data = dbs.get_data(
                        "integration_connection",
                        {"integration_id": integration_id, "is_active": True},
                        ["sandbox_url", "auth_test_url"],
                    )
                else:
                    # Fetch production_url from the database
                    endpoint_data = dbs.get_data(
                        "integration_connection",
                        {"integration_id": integration_id, "is_active": True},
                        ["production_url", "auth_test_url"],
                    )
            except Exception as e:
                logging.exception(f"Error updating api_endpoint_url: {e}")
                endpoint_data = None

            if tenant_name =='Altaworx Test':
                sandbox_url_t = endpoint_data["sandbox_url"].to_list()[0]
            else:
                sandbox_url_t = endpoint_data["production_url"].to_list()[0]
            auth_test_url_ = endpoint_data["auth_test_url"].to_list()[0]
            # Construct the URL dynamically

            # base_url = "https://www.mydashboard.pondmobile.com/ds/u/distributorPPUService/v1"
            url = f"{sandbox_url_t}/{DistributorId}{auth_test_url_}"


            # username = "person@altaworx.com"
            # password = "M2YxMjUzNzYtNzljZi00N2VlLTk4NTEtNjQyY2MyZWVjNmU4"

            # Combine username and password with a colon

            # Encode the string in Base64
            decoded_password = base64.b64decode(password).decode("utf-8")

            auth_string = f"{username}:{decoded_password}"

            encoded_auth_string = base64.b64encode(auth_string.encode()).decode("utf-8")
            # Create the Basic Auth header
            basic_auth_header = f"Basic {encoded_auth_string}"

            # Headers
            headers = {
                "ApiKey": oauth2_custom1,
                "Authorization": basic_auth_header,
                "Accept": "application/json",
            }

            # Make the GET request
            api_response = requests.get(url, headers=headers)
        else:

            pass

        if integration_id in [20]:
            if api_response.status_code == 200:
                # Parse XML response
                root = ET.fromstring(api_response.text)
                ns = {"ns0": "http://wws.iamwebbing.com/"}

                # Extract response values
                success = root.find(".//ns0:Success", ns)
                response_code = root.find(".//ns0:ResponseCode", ns)
                response_description = root.find(".//ns0:ResponseDescription", ns)

                result = {
                    "success": success.text.strip().lower() == "true" if success is not None else False,
                    "response_code": response_code.text if response_code is not None else "N/A",
                    "response_description": response_description.text if response_description is not None else "No description"
                }

                return result

            else:
                return {"success": False, "error": f"HTTP Error {api_response.status_code}: {api_response.text}"}


        # If status code is 200, proceed with the database update
        if api_response.status_code == 200:
            try:
                db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
                update_result = db.update_dict(
                    "integration_authentication", insert_data, where_dict
                )
                if update_result:
                    return {
                        "flag": True,
                        "message": "Integration details updated successfully.",
                    }
                else:
                    return {
                        "flag": False,
                        "message": "Failed to update integration details.",
                    }
            except Exception as db_error:
                return {
                    "flag": False,
                    "message": f"Database error occurred: {db_error}",
                }
        elif authentication_type == 16 and integration_id == 16:
            try:
                db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
                update_result = db.update_dict(
                    "integration_authentication", insert_data, where_dict
                )
                if update_result:
                    return {
                        "flag": True,
                        "message": "Integration details updated successfully.",
                    }
                else:
                    return {
                        "flag": False,
                        "message": "Failed to update integration details.",
                    }
            except Exception as db_error:
                return {
                    "flag": False,
                    "message": f"Database error occurred: {db_error}",
                }
        else:
            return {
                "flag": False,
                "message": f"API call failed with status code {api_response.status_code} and {api_response.text}",
            }

    except Exception as e:
        db = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        db.log_error_to_db(
            {
                "service_name": "Module Management",
                "created_date": data.get("request_received_at", ""),
                "error_message": str(e),
                "error_type": type(e).__name__,
                "users": data.get("username", ""),
                "session_id": data.get("sessionID", ""),
                "tenant_name": data.get("Partner", ""),
                "comments": str(e),
                "module_name": "save_integration_details",
                "request_received_at": data.get("request_received_at", ""),
            },
            "error_log_table",
        )
        return {"flag": False, "message": f"An error occurred: {str(e)}"}


def update_settings(setting_key, setting_value, service_provider_id,tenant_database):
    """Helper function to update settings in the database."""
    try:
        db = DB(tenant_database, **db_config)
        insert_data = {"setting_value": setting_value}
        where_dict = {
            "setting_key": setting_key,
            "service_provider_id": service_provider_id,
        }
        db.update_dict("service_provider_setting", insert_data, where_dict)
        logging.info(f"Successfully updated setting: {setting_key}")

    except Exception as e:
        logging.exception(f"Error updating setting {setting_key}: {e}")


def get_cross_provider_optimization_status(data):
    tenant_database=data.get('db_name')
    database = DB(tenant_database, **db_config)
    try:
        # Atgempt to retrieve the value from the 'tenant' table
        cross_carrier_optimization = database.get_data(
            "optimization_setting",
            {},
            ["optino_cross_providercustomer_optimization"],
        )["optino_cross_providercustomer_optimization"].to_list()[0]
    except Exception as e:
        logging.exception(f"Failed to get the cross_carrier_optimization{e}")
        cross_carrier_optimization = False
    response={"flag":True,"cross_carrier_optimization":cross_carrier_optimization}
    return response



# def get_service_provider_config(data):
#     """
#     Fetches service provider configuration for a given tenant.
#     Args:
#         data (dict): Dictionary containing request data including:
#             - db_name: Tenant database name
#             - tenant_name: Name of the tenant
#             - request_received_at: Timestamp of when request was received
#             - username: Username making the request
#     Returns:
#         dict: Dictionary containing service provider configuration and related data
#     """
#     # Extract data from input dictionary with default values
#     tenant_database = data.get("db_name", "")
#     db = DB(tenant_database, **db_config)
#     common_utils_database = DB(os.environ.get("COMMON_UTILS_DATABASE", "common_utils"), **db_config)
#     tenant_name = data.get("tenant_name", "")
#     request_received_at = data.get("request_received_at", "")
#     username = data.get("username", "")
 
#     try:
#         # Initialize result dictionary
#         result = {}
#         # Case-insensitive comparison for Altaworx Test
#         if tenant_name.lower() == "altaworx test":
#             tenant_id = 1  # Hardcoded ID for Altaworx Test
#         else:
#             # Fetch tenant_id from database for other tenants
#             tenant_data = common_utils_database.get_data(
#                 "tenant", {"tenant_name": tenant_name}, ["id"]
#             ).to_list()[0]
#             print(f"\n\nsub_tenants1: {tenant_data}\n\n")
#             # Check if we got any results
#             if tenant_data.empty:
#                 raise ValueError(f"Tenant '{tenant_name}' not found in database")
#             tenant_id = tenant_data["id"].iloc[0]  # Safer way to get first value
#         result["flag"] = True  # Initial success flag
#         result["parent_tenant_name"] = tenant_name
 
#         # Get sub-tenant names for the current tenant
#         sub_tenant_query = f"""
#         SELECT tenant_name FROM public.tenant 
#         WHERE parent_tenant_id = {tenant_id} AND is_active = true
#         """
       
#         print(f"\n\nsub_tenants: {sub_tenant_query}\n\n")

#         sub_tenants = common_utils_database.execute_query(sub_tenant_query, True)
#         #logging.debug(f"Executing Query: {sub_tenants}")
#         print(f"\n\nsub_tenants1: {sub_tenants}\n\n")

#         result["sub_tenant_names"] = sub_tenants["tenant_name"].to_list() if not sub_tenants.empty else []
#         print(f"\n\nsub_tenants2: {result['sub_tenant_names']}\n\n")



 
#         integration_auth_id = os.environ["INTEGRATION_AUTHENTICATION_ID"]
 
#         # If no valid integration_auth_id is found, return empty result
#         if integration_auth_id is None:
#             return []
 
       
#        # Get products and product types
#         # result["rev_products"] = [
#         #     {"description": row["description"], "product_id": row["product_id"]}
#         #     for _, row in db.get_data("rev_product",
#         #                             {"is_active": True, "is_deleted": False, "integration_authentication_id": integration_auth_id},
#         #                             ["description", "product_id"]).iterrows()
#         # ]
#         # products = db.get_data("rev_product",
#         #                      {"is_active": True, "is_deleted": False, "integration_authentication_id": integration_auth_id},
#         #                      ["description", "product_id"])
#        # Define the SQL query correctly
#         query = """
#             SELECT description, product_id 
#             FROM rev_product 
#             WHERE is_active = TRUE 
#             AND is_deleted = FALSE 
#             AND integration_authentication_id = '4';
#         """

#         # Execute query and get a DataFrame
#         products = db.execute_query(query, True)  # Ensure this function returns a DataFrame

#         # Print the query
#         print(f"\n\nQuery executed: {query}\n\n")

#         # Check if 'products' is a valid DataFrame
#         if not products.empty:
#             result["rev_products"] = [
#                 {"description": row["description"], "product_id": row["product_id"]}
#                 for _, row in products.iterrows()
#             ]
#         else:
#             result["rev_products"] = []

#         # Print the processed result
#         print(f"\n\nres_rev_product: {result['rev_products']}\n\n")


#         result["rev_product_types"] = [
#             {"description": row["description"], "product_type_id": row["product_type_id"]}
#             for _, row in db.get_data("rev_product_type",
#                                     {"is_active": True, "is_deleted": False, "integration_authentication_id": integration_auth_id},
#                                     ["description", "product_type_id"]).iterrows()
#         ]

#         print(f"\n\nsub_tenants4: {result['rev_product_types']}\n\n")

 
#         # Get all active integrations
#         integration_query = """
#         SELECT id, name FROM integration
#         WHERE is_active='true'
#         """
#         integrations = common_utils_database.execute_query(integration_query, True)
#         print(f"\n\nsub_tenants5: {integrations}\n\n") 
 
        
#         integration_map = dict(zip(integrations["id"], integrations["name"])) if not integrations.empty else {}
      
#         print(f"\n\nsub_tenants6: {integration_map}\n\n") 
 
 
#         # Fetch service providers data
#         sp_query = """
#         SELECT SP.id, SP.service_provider_name, SP.integration_id FROM serviceprovider SP
#         WHERE SP.is_active = 'true' AND SP.is_deleted = 'false'
#         ORDER BY SP.service_provider_name ASC
#         """
#         service_providers = db.execute_query(sp_query, True)
       
#         print(f"\n\nsub_tenants7: {service_providers}\n\n") 
 
#         if not service_providers.empty:
#             service_providers["integration_name"] = service_providers["integration_id"].map(integration_map)
#             result["service_providers"] = service_providers.to_dict(orient="records")
#             print(f"\n\nsub_tenants7: {service_providers}\n\n")
#         else:
#             result["service_providers"] = []
 
#         # Get service provider tenant configuration
#         sptc_query = f"""
#         SELECT spc.*
#         FROM public.service_provider_tenant_configuration spc
#         JOIN public.serviceprovider sp
#         ON spc.service_provider_id = sp.id
#         WHERE spc.is_active = true 
#         AND sp.is_active = true 
#         AND sp.is_deleted = false
#         AND spc.tenant_id = {tenant_id}
#         ORDER BY spc.service_provider_id ASC
#         """
#         service_provider_tenant_configuration = db.execute_query(sptc_query, True)
#         #logging.debug(f"Service Providers Data: {service_provider_tenant_configuration}")
#         print(f"\n\nsub_tenants8: {service_provider_tenant_configuration}\n\n")
#         if not service_provider_tenant_configuration.empty:
#             tenant_time_zone = fetch_tenant_timezone(common_utils_database, data)
#             service_provider_tenant_configuration = convert_timestamp_data(
#                 service_provider_tenant_configuration.to_dict(orient="records"), 
#                 tenant_time_zone
#             )
#             result["service_provider_tenant_configuration"] = service_provider_tenant_configuration
#         else:
#             result["service_provider_tenant_configuration"] = []
 
#         try:

#             audit_data_user_actions = {
#                 "service_name": "MOdule Management",
#                 "created_date": request_received_at,
#                 "created_by": username,
#                 "status": str(result["flag"]),
#                 "tenant_name": tenant_name,
#                 "comments": "fetching customer plan list view data",
#                 "module_name": "Customer Rate Pool module function:get_customer_rate_plan_list_view_data",
#                 "request_received_at": request_received_at,
#             }
#             common_utils_database.update_audit(
#                 audit_data_user_actions, "audit_user_actions"
#             )
#         except Exception as e:
#             logging.warning(f"Exception is {e}")

#         return result

#         print(f"\n\nsub_tenants9: {result}\n\n")
        
 
#     except Exception as e:
#         # Handle exceptions and provide feedback
#         logging.exception(f"Exception occurred: {e}")
#         message = "Something went wrong while updating data"
#         # Error Management
#         error_data = {
#             "service_name": "Sim Management",
#             "created_date": request_received_at,
#             "error_messag": message,
#             "error_type": e,
#             "user": username,
#             "tenant_name": tenant_name,
#             "comments": message,
#             "module_name": "servie provider confic function:get_service_provider_config",
#             "request_received_at": request_received_at,
#         }
#         common_utils_database.log_error_to_db(error_data, "error_table")
#         result = {"flag": False, "error": str(e)}
#     return result

#     print(f"\n\nsub_tenants10: {result}\n\n")
        

def get_service_provider_config(data):
    tenant_database = data.get("db_name", "")
    db = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    tenant_name = data.get("tenant_name", "")
    request_received_at = data.get("request_received_at", "")
    username = data.get("username", "")

    try:

        if tenant_name == "Altaworx Test":
            tenant_id = 1  # Include the hardcoded ID
            # Fetch the ID from the database as well
        else:
            # Default case: fetch only from the database
            tenant_id = common_utils_database.get_data(
                "tenant", {"tenant_name": tenant_name}, ["id"]
            )["id"].to_list()[0]
            print("tenant_id",tenant_id)
        result = {}

        result["flag"]=  True


        integration_auth_id = os.environ["INTEGRATION_AUTHENTICATION_ID"]

        # If no valid integration_auth_id is found, return empty result
        if integration_auth_id is None:
            return []

        # Get products and product types
        result["rev_products"] = [
            {"description": row["description"], "product_id": row["product_id"]}
            for _, row in db.get_data("rev_product",
                                    {"is_active": True, "is_deleted": False, "integration_authentication_id": integration_auth_id},
                                    ["description", "product_id"]).iterrows()
        ]

        result["rev_product_types"] = [
            {"description": row["description"], "product_type_id": row["product_type_id"]}
            for _, row in db.get_data("rev_product_type",
                                    {"is_active": True, "is_deleted": False, "integration_authentication_id": integration_auth_id},
                                    ["description", "product_type_id"]).iterrows()
        ]


        integration_query = f"""
        SELECT id, name FROM integration
        WHERE is_active='true'
        """
        integrations = common_utils_database.execute_query(integration_query, True)
        integration_map = dict(zip(integrations["id"], integrations["name"]))

        # Fetch service providers
        sp_query = """
        SELECT SP.id, SP.service_provider_name, SP.integration_id FROM serviceprovider SP
        WHERE SP.is_active = 'true' OR SP.is_deleted = 'false'
        ORDER BY SP.service_provider_name ASC
        """

        service_providers = db.execute_query(sp_query, True)

        service_providers["integration_name"] = service_providers["integration_id"].map(integration_map)


        result["service_providers"] = service_providers.to_dict(orient="records")

        sptc_query = f"""
        SELECT spc.*
            FROM public.service_provider_tenant_configuration spc
            JOIN public.serviceprovider sp
            ON spc.service_provider_id = sp.id
            WHERE spc.is_active = true and sp.is_active = true and sp.is_deleted = false

			and spc.tenant_id = {tenant_id}
            ORDER BY spc.service_provider_id ASC

        """

        service_provider_tenant_configuration = db.execute_query(sptc_query, True).to_dict(orient="records")



        tenant_time_zone = fetch_tenant_timezone(common_utils_database, data)
        service_provider_tenant_configuration = convert_timestamp_data(
            service_provider_tenant_configuration, tenant_time_zone
        )
        result["service_provider_tenant_configuration"] = service_provider_tenant_configuration


        try:

            audit_data_user_actions = {
                "service_name": "MOdule Management",
                "created_date": request_received_at,
                "created_by": username,
                "status": str(result["flag"]),
                "tenant_name": tenant_name,
                "comments": "fetching customer plan list view data",
                "module_name": "Customer Rate Pool module function:get_customer_rate_plan_list_view_data",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"Exception is {e}")

        return result


    except Exception as e:
        # Handle exceptions and provide feedback
        logging.exception(f"Exception occurred: {e}")
        message = "Something went wrong while updating data"
        # Error Management
        error_data = {
            "service_name": "Sim Management",
            "created_date": request_received_at,
            "error_messag": message,
            "error_type": e,
            "user": username,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": "servie provider confic function:get_service_provider_config",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_table")
        result = {"flag": False, "error": str(e)}
    return result




def save_service_provider_config(data):
    changed_data_list = data.get("changed_data", [])
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    request_received_at = data.get("request_received_at", "")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")
    table_name = "service_provider_tenant_configuration"
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)


    try:
        # Process each item in the changed_data list
        for changed_data in changed_data_list:
            unique_id = changed_data.get("id", "")

            # Filter out None values
            # changed_data = {
            #     k: v for k, v in changed_data.items() if v not in [None, "None"]
            # }

            # Remove id from update data
            update_data = {
                key: value for key, value in changed_data.items() if key != "id"
            }

            logging.info(f"Updating record with ID {unique_id}. Update data: {update_data}")

            if update_data and unique_id:
                database.update_dict(table_name, update_data, {"id": unique_id})
            else:
                logging.info(f"Skipping update for ID {unique_id}: No valid update data or missing ID")

        response_data = {"flag": True, "message": f"Successfully Updated"}

        try:
            # Log the user action in the audit table
            audit_data_user_actions = {
                "service_name": "Module Management",
                "created_date": request_received_at,
                "created_by": username,
                "status": str(response_data["flag"]),
                "session_id": "session_id",
                "tenant_name": tenant_name,
                "comments": "Reports data",
                "module_name": "Reports",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
            logging.info("Audit log recorded successfully")
        except Exception as e:
            logging.warning(f"Exception during audit log: {e}")

        return response_data

    except Exception as e:
        print(f"An error occurred: {e}")
        message = "Unable to save the data"
        response = {"flag": False, "message": message}
        error_type = str(type(e).__name__)

        try:
            # Log error to database
            error_data = {
                "service_name": "update_superadmin_data",
                "created_date": request_received_at,
                "error_message": message,
                "error_type": error_type,
                "users": username,
                "session_id": "session_id",
                "tenant_name": tenant_name,
                "comments": "",
                "module_name": "Module Management",
                "request_received_at": request_received_at,
            }
            common_utils_database.log_error_to_db(error_data, "error_log_table")
            logging.info("Error details logged successfully")
        except Exception as e:
            logging.warning(f"Exception during error log: {e}")

        return response





def get_cross_carrier_optimization(data):
    tenant_database = data.get("db_name", "")
    database = DB(tenant_database, **db_config)
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    request_received_at = data.get("request_received_at", "")
    username = data.get("username", "")
    tenant_name = data.get("tenant_name", "")

    try:
        p = database.get_data(
                                "optimization_setting",
                                {},
                                ["optino_cross_providercustomer_optimization"],
                            ).iloc[0, 0]







        try:

            audit_data_user_actions = {
                "service_name": "MOdule Management",
                "created_date": request_received_at,
                "created_by": username,
                "status": str(result["flag"]),
                "tenant_name": tenant_name,
                "comments": "fetching customer plan list view data",
                "module_name": "Customer Rate Pool module function:get_customer_rate_plan_list_view_data",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as e:
            logging.warning(f"Exception is {e}")


        return {"flag": True, "cross_carrier_optimization": False if int(p) == 0 else True}

    except Exception as e:
        # Handle exceptions and provide feedback
        logging.exception(f"Exception occurred: {e}")
        message = "Something went wrong while updating data"
        # Error Management
        error_data = {
            "service_name": "MOdule Management",
            "created_date": request_received_at,
            "error_messag": message,
            "error_type": e,
            "user": username,
            "tenant_name": tenant_name,
            "comments": message,
            "module_name": "cross_carrier_optimization function:cross_carrier_optimization",
            "request_received_at": request_received_at,
        }
        common_utils_database.log_error_to_db(error_data, "error_table")
        result = {"flag": False, "error": str(e)}
    return result


def convert_and_filter(data):
    converted_list = []

    for entry in data:
        converted_entry = {
            k: (v.isoformat() if isinstance(v, (date, Timestamp)) else v)
            for k, v in entry.items() if v is not None  # Remove None values
        }
        converted_list.append(converted_entry)

    return converted_list

from datetime import date
from pandas import Timestamp
def get_customer_user_by_line_report_view_data(data):
    """
    Retrieves the status history of a SIM management inventory item based on the provided ID.

    Parameters:
    - data (dict): Dictionary containing the 'list_view_data_params' for querying the status history.

    Returns:
    - dict: A dictionary containing the List view data, header mapping, and a success message or an error message.
    """
    try:
        logging.info(f"Request Data Received {data}")
        Partner = data.get("tenant_name", "")
        role_name = data.get("role_name", "")
        request_received_at = data.get("request_received_at", "")
        username = data.get("username", " ")
        module_name = data.get("module_name", "")
        col_sort = data.get("col_sort", "")

        # Initialize the database connection
        tenant_database = data.get("db_name", "")

        try:
            # database Connection
            database = DB(tenant_database, **db_config)
            common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
        except Exception as db_error:
            logging.error(f"Database connection error: {db_error}")
            return {"flag": False, "error": f"Failed to connect to database: {str(db_error)}"}

        tenant_database = data.get("db_name", "altaworx_test")
        customer_id = data.get("service_provider", "")
        billing_id = data.get("billing_cycle_period", "")

        export_base_path = os.getenv("EXPORT_BASE_PATH")
        module_name_snake_case = "_".join(module_name.strip().lower().split())
        file_name = f"{export_base_path}/{module_name_snake_case}/{module_name}.json"
        download_url = f"https://{S3_BUCKET_NAME}.s3.amazonaws.com/{file_name}"

        # Update export status to 'Waiting'
        try:
            common_utils_database.update_dict(
                "export_status",
                {"status_flag": "Waiting", "url": ""},
                {"module_name": "Usage By Line Report View"},
            )
        except Exception as status_error:
            logging.warning(f"Failed to update export status to 'Waiting': {status_error}")
            # Continue execution despite this error

        # Handle pagination
        pages = {}
        if "mod_pages" in data:
            start = data["mod_pages"].get("start") or 0  # Default to 0 if no value
            end = data["mod_pages"].get("end") or 100  # Default to 100 if no value
            logging.info(f"Starting page is {start} and ending page is {end}")

        # Get service providers for the user
        try:
            query = f"select service_provider from users where username ='{username}'"
            filters = common_utils_database.execute_query(query, True)
            service_providers = None
            if not filters.empty:
                service_providers = filters["service_provider"].to_list()[0]

            if isinstance(service_providers, str):
                # If it's a string, convert it to a list by evaluating it
                import ast
                try:
                    service_providers = ast.literal_eval(service_providers)
                except:
                    # If evaluation fails, wrap it in a list
                    service_providers = [service_providers]
        except Exception as sp_error:
            logging.warning(f"Error retrieving service providers: {sp_error}")
            service_providers = None

        # Build conditions with parameterized query
        conditions = ""
        if service_providers:
            # Dynamically generate conditions for service providers
            conditions = f"""WHERE service_provider_display_name IN ({','.join(f"'{service_provider}'" for service_provider in service_providers)}) """

        # Construct ORDER BY clause
        if col_sort:
            # Extract the single key-value pair
            key, value = list(col_sort.items())[0]  # Get the first and only pair
            order_condition = f"ORDER BY {key} {value.upper()} Limit 100 OFFSET {start}"
        else:
            order_condition = f"LIMIT 100 OFFSET {start}"

        # Get tenant ID
        try:
            tenant_name = data.get("tenant_name", "Altaworx Test")
            tenant_names_str = os.getenv("TENANT_NAMES", "")
            # Convert the comma-separated string into a list
            tenant_names_str = re.sub(r"[^a-zA-Z0-9]", " ", tenant_names_str)
            tenant_names = tenant_names_str.split(",")

            if tenant_name in tenant_names:
                tenant_id = 1
            else:
                tenant_query_result = common_utils_database.get_data(
                    "tenant", {"tenant_name": tenant_name}, ["id"]
                )
                if tenant_query_result.empty:
                    return {"flag": False, "error": f"Tenant not found: {tenant_name}"}
                tenant_id = tenant_query_result["id"].to_list()[0]
        except Exception as tenant_error:
            logging.error(f"Error retrieving tenant ID: {tenant_error}")
            return {"flag": False, "error": f"Failed to retrieve tenant ID: {str(tenant_error)}"}

        # Main query with parameterization
        try:
            if int(billing_id) == 0:
                customer_user_by_line_query = f"""
                    select
                            service_provider_display_name,
                            billing_cycle_end_date,
                            iccid,msisdn,
                            foundation_account_number,
                            billing_account_number,
                            customer_rate_pool_name,
                            customer_name,
                            customer_id,
                            username,
                            carrier_rate_plan,
                            rate_plan_name,
                            integration_id,
                            data_usage_mb,
                            status_display_name,
                            date_activated,
                            tenant_id
                            from usp_report_customer_usage_by_line
                            WHERE tenant_id = {tenant_id} and is_active=True
                            and customer_id = {customer_id}
                    {conditions}
                    {order_condition}"""
            else:
                customer_user_by_line_query = f"""
                    select
                        service_provider_display_name,
                        billing_cycle_end_date,
                        iccid,
                        msisdn,
                        foundation_account_number,
                        billing_account_number,
                        customer_rate_pool_name,
                        customer_name,username,
                        carrier_rate_plan,
                        rate_plan_name,
                        integration_id,
                        data_usage_mb,
                        status_display_name,
                        date_activated,
                        tenant_id
                    from usp_report_customer_historyusagebyline_rmf({int(customer_id)},{int(tenant_id)},{int(billing_id)})
                    {conditions}
                    {order_condition}
                """

            # Execute the query with parameters
            query_result = database.execute_query(customer_user_by_line_query, True)
            if query_result is None or query_result.empty:
                customer_user_by_line_report = []
            else:
                customer_user_by_line_report = query_result.to_dict(orient="records")
                print(customer_user_by_line_report,'burhan testing')

                customer_user_by_line_report = convert_and_filter(customer_user_by_line_report)
        except Exception as query_error:
            logging.error(f"Query execution error: {query_error}")
            return {"flag": False, "error": f"Query execution failed: {str(query_error)}"}

        # Apply timezone conversion if needed
        try:
            tenant_time_zone = fetch_tenant_timezone(common_utils_database, data)
            customer_user_by_line_report = convert_timestamp_data(
                customer_user_by_line_report, tenant_time_zone
            )
            # customer_user_by_line_report = serialize_data(customer_user_by_line_report)
        except Exception as timezone_error:
            logging.warning(f"Error converting timestamps: {timezone_error}")
            # Continue execution despite this error

        # Generate the headers mapping
        try:
            headers_map = get_headers_mapping(
                tenant_database,
                ["Usage By Line Report"],
                role_name,
                "",
                "",
                "",
                "",
                data,
                common_utils_database,
            )
        except Exception as headers_error:
            logging.warning(f"Error generating headers mapping: {headers_error}")
            headers_map = {}  # Use empty dict if headers mapping fails

        # Serialize data for S3 upload
        try:
            import json
            serialized_data = json.dumps(customer_user_by_line_report)

            # Upload JSON to S3
            try:
                import boto3
                s3_client = boto3.client('s3')
                s3_client.put_object(
                    Bucket=S3_BUCKET_NAME,
                    Key=file_name,
                    Body=serialized_data,
                    ContentType="application/json",
                )

                # Update export status to 'Success'
                common_utils_database.update_dict(
                    "export_status",
                    {"status_flag": "Success", "url": download_url},
                    {"module_name": "Usage By Line Report View"},
                )
            except Exception as s3_error:
                logging.error(f"S3 upload error: {s3_error}")
                # Continue execution even if S3 upload fails
        except Exception as serialize_error:
            logging.error(f"Data serialization error: {serialize_error}")
            # Continue execution even if serialization fails



        # Prepare the response
        response = {
            "flag": True,
            "data": serialize_data(customer_user_by_line_report),
            "headers_map": headers_map,
            "pages": pages,
        }

        # Log audit
        try:
            audit_data_user_actions = {
                "service_name": "Module Management",
                "created_date": request_received_at,
                "created_by": username,
                "status": str(response["flag"]),
                "tenant_name": Partner,
                "comments": "fetching customer user by line report view data",
                "module_name": "Usage By Line Report module function:get_customer_user_by_line_report_view_data",
                "request_received_at": request_received_at,
            }
            common_utils_database.update_audit(
                audit_data_user_actions, "audit_user_actions"
            )
        except Exception as audit_error:
            logging.warning(f"Audit logging exception: {audit_error}")
            # Continue execution despite audit logging error

        return response

    except Exception as e:
        # Handle general exceptions and provide feedback
        logging.exception(f"Exception occurred: {e}")
        message = "Something went wrong while retrieving Usage By Line Report data"

        try:
            # Error Management
            error_data = {
                "service_name": "Module Management",
                "created_date": request_received_at,
                "error_message": message,
                "error_type": str(e),
                "user": username,
                "tenant_name": Partner,
                "comments": message,
                "module_name": "Usage By Line Report module function:get_customer_user_by_line_report_view_data",
                "request_received_at": request_received_at,
            }
            common_utils_database.log_error_to_db(error_data, "error_table")
        except Exception as error_log_error:
            logging.error(f"Failed to log error to database: {error_log_error}")

        response = {"flag": False, "error": str(e)}
        return response


def customer_info_details(data):
    
    common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    partner_name=data.get("partner_name",'')

    # get the db_name 
    if partner_name: 
        try:
            db_name=common_utils_database.get_data("tenant",{"tenant_name":partner_name},["db_name"])["db_name"].to_list()[0]
        except Exception as e:
            db_name=''
            logging.info(f"Error:{e}")
    else:
        db_name=''
        

    if db_name: 
        partner_db=DB(db_name, **db_config)

        # get customer from users table
        try:
            customers=partner_db.get_data("customers",None,["customer_name"],{"customer_name":"asc"})["customer_name"].to_list()
            customers=sorted(set(customers))
        except Exception as e:
            customers=[]
            logging.info(f"Error:{e}")

        # get customer from users table
        try:
            serviceprovider=partner_db.get_data("serviceprovider",None,["service_provider_name"],{"service_provider_name":"asc"})["service_provider_name"].to_list()
            serviceprovider=sorted(set(serviceprovider))
        except Exception as e:
            serviceprovider=[]
            logging.info(f"Error:{e}")

        # get customer from users table
        try:
            customergroups=partner_db.get_data("customergroups",None,["name"],{"name":"asc"})["name"].to_list()
            customergroups=sorted(set(customergroups))
        except Exception as e:
            customergroups=[]
            logging.info(f"Error:{e}")

        dropdown={
            "customers":customers,
            "serviceprovider":serviceprovider,
            "customergroups":customergroups
        }


        response = {
            "flag": True,
            "message":"Data Fetched Succesfully",
            "data": {},
            "pages": {},
            "features": {},
            "dropdown": dropdown
        }
        return response
    else:
        response = {
            "flag": False,
            "message":"Not db found"
        }
        return response

data={
  "tenant_name": "Altaworx Test",
  "username": "lohitha.v@algonox.com",
  "firstLastName": "Lohitha V",
  "path": "/get_partner_info",
  "role_name": "Super Admin",
  "parent_module": "Partner",
  "modules_list": [
    "Customer groups"
  ],
  "feature_module_name": "Partner Info",
  "pages": {
    "Customer groups": {
      "start": 0,
      "end": 100
    },
    "Partner users": {
      "start": 0,
      "end": 100
    }
  },
  "Partner": "Altaworx Test",
  "request_received_at": "2025-04-03 16:48:06.841",
  "access_token": "null",
  "db_name": "altaworx_test",
  "sessionID": 'null'
}

get_partner_info(data)