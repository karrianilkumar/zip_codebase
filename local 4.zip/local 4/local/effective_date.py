# from common_utils.email_trigger import send_email

import logging
from datetime import datetime, timezone
import uuid
# Importing the necessary Libraries
import os
import json
import time
import threading
import boto3 # type: ignore
import pandas as pd # type: ignore
import numpy as np
import base64
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
from concurrent.futures import ThreadPoolExecutor, as_completed
# from config.carrier_config_manager import CarrierConfigManager

common_utils_database_config = db_config = {
    'host': "amopuatpostgresoct23.c3qae66ke1lg.us-east-1.rds.amazonaws.com",
    'port': "5432",
    'user':"root",
    'password':"AmopTeam123"
}
# logging = Logging(name="email_trigger")


class ColorFormatter(logging.Formatter):
    COLORS = {
        "DEBUG": "\033[94m",   # Blue
        "INFO": "\033[92m",    # Green
        "WARNING": "\033[93m", # Yellow
        "ERROR": "\033[91m",   # Red
        "CRITICAL": "\033[95m" # Purple
    }
    RESET = "\033[0m"

    def format(self, record):
        color = self.COLORS.get(record.levelname, self.RESET)
        message = super().format(record)
        return f"{color}{message}{self.RESET}"

# Create logger
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

# Remove old handlers (important in Jupyter)
logger.handlers.clear()

# Add new handler
handler = logging.StreamHandler()
handler.setFormatter(ColorFormatter("%(levelname)s: %(message)s"))
logger.addHandler(handler)


def create_schedule(trigger_time_str, payload):
    """
    Creates a one-time AWS EventBridge Scheduler trigger to invoke a target Lambda function.

    Converts the provided trigger time (DD-MM-YYYY HH:MM) into AWS scheduler
    format and schedules the Lambda execution in UTC timezone.

    Args:
        trigger_time_str (str): Execution time in format "DD-MM-YYYY HH:MM" (UTC).
        payload (dict): JSON-serializable payload to pass to the target Lambda.

    Returns:
        dict: Response from AWS scheduler.create_schedule API.
    """
    logging.info(f"### create_schedule trigger_time_str : {trigger_time_str} and payload : {payload}")
    # scheduler = boto3.client("scheduler")
    scheduler = boto3.client("scheduler",region_name="us-east-1")
    # TARGET_LAMBDA_ARN ="bulk_change_processor_beta"
    TARGET_LAMBDA_ARN = "arn:aws:lambda:us-east-1:008971638399:function:bulk_change_processor_beta"
    SCHEDULER_ROLE_ARN = "arn:aws:iam::008971638399:role/Amazon_EventBridge_lambda"

    # Convert from DD-MM-YYYY HH:MM to required format
    dt = datetime.strptime(trigger_time_str, "%d-%m-%Y %H:%M")
    formatted_time = dt.strftime("%Y-%m-%dT%H:%M:%S")
    schedule_name = f"dynamic-trigger-{uuid.uuid4()}"
 
    logging.info(f"### Creating schedule for {schedule_name} at time {formatted_time}")
 
    response = scheduler.create_schedule(
        Name=schedule_name,
        ScheduleExpression=f"at({formatted_time})",
        ScheduleExpressionTimezone="UTC",
        FlexibleTimeWindow={
            "Mode": "FLEXIBLE",
            "MaximumWindowInMinutes": 5
        },
        # ActionAfterCompletion="DELETE",  # auto delete after execution
        Target={
            "Arn": TARGET_LAMBDA_ARN,
            "RoleArn": SCHEDULER_ROLE_ARN,
            "Input": json.dumps(payload)
        }
    )
    return response


def schedule_bulk_change_execution(bulk_change_procesor_payload):
    """
    Handles effective date logic for Bulk Change processing.

    - If effective_date exists and is in the future → schedule execution.
    - If no effective_date → execute immediately.
    - Writes audit only once in success and once in failure.
    """

    logging.info("### Entered schedule_bulk_change_execution function with data :")

    start_time = time.time()

    if not bulk_change_procesor_payload:
        return {"flag": False, "message": "bulk_change_procesor_payload is empty"}

    try:
        changed_data = bulk_change_procesor_payload.get("changed_data", {})
        change_type = bulk_change_procesor_payload.get("change_type")
        effective_date = changed_data.get("effective_date")
        bulk_change_lambda = os.getenv("bulk_change_lambda")
        bulk_change_id = bulk_change_procesor_payload.get("bulk_change_id")
        db_name = bulk_change_procesor_payload.get("db_name")
        username = bulk_change_procesor_payload.get("username")
        tenant_name = bulk_change_procesor_payload.get("tenant_name")
        service_provider = bulk_change_procesor_payload.get("service_provider")
        request_received_at = bulk_change_procesor_payload.get("request_received_at")

        # DB Connections
        tenant_database = DB(db_name, **db_config)
        common_utils_database = DB("common_utils", **common_utils_database_config)

        # ------------------------------------------------------------
        # CASE 1: Effective Date Exists and is Future → Schedule
        # ------------------------------------------------------------
        if effective_date:
            effective_dt = datetime.fromisoformat(
                effective_date.replace("Z", "+00:00")
            )

            if effective_dt > datetime.now(timezone.utc):

                formatted_trigger_time = effective_dt.strftime("%d-%m-%Y %H:%M")

                schedule_response = create_schedule(
                    formatted_trigger_time, bulk_change_procesor_payload
                )

                if schedule_response.get("ResponseMetadata", {}).get("HTTPStatusCode") == 200:

                    if bulk_change_id:
                        tenant_database.update_dict(
                            "sim_management_bulk_change",
                            {"status": "SCHEDULED"},
                            {"id": bulk_change_id},
                        )

                    result_message = f"{change_type} scheduled successfully for {formatted_trigger_time}"
                    status_flag = True

                else:
                    raise Exception("Scheduler creation failed")


        # ------------------------------------------------------------
        # CASE 2: No Effective Date → Immediate Lambda Invocation
        # ------------------------------------------------------------
        else:

            lambda_client = boto3.client("lambda")

            invoke_response = lambda_client.invoke(
                FunctionName=bulk_change_lambda,
                InvocationType="Event",
                Payload=json.dumps(
                    {"data": bulk_change_procesor_payload}
                ).encode("utf-8"),
            )

            if invoke_response.get("StatusCode") == 202:
                result_message = f"{change_type} triggered immediately"
                status_flag = True
            else:
                raise Exception("Immediate Lambda invocation failed")

        # SUCCESS AUDIT (ONLY ONCE)
        end_time = time.time()
        time_consumed = int(end_time - start_time)
        try : 
            audit_data = {
                "service_name": "schedule_bulk_change_execution",
                "created_by": username,
                "time_consumed_secs": time_consumed,
                "status": "Success",
                "tenant_name": tenant_name,
                "module_name": "Bulk Change",
                "comments": f"Bulk change type is scheduled for service provider: {service_provider}, change_type: {change_type}, bulk_change_id: {bulk_change_id} by effective date : {effective_dt}",
                "request_received_at":request_received_at
            }

            common_utils_database.update_audit(audit_data, "audit_user_actions")
        except Exception as audit_error:
            logging.exception(f"### Logging error failed in success case : {audit_error}")
        return {"flag": status_flag,"message": result_message}

    except Exception as e:
        logging.exception("### Error in schedule_bulk_change_execution")
        # FAILURE AUDIT (ONLY ONCE)
        try:
            error_data = {
                "service_name": "schedule_bulk_change_execution",
                "error_message": str(e),
                "error_type": type(e).__name__,
                "tenant_name": bulk_change_procesor_payload.get("tenant_name"),
                "module_name": "Bulk Change",
                "comments": f"Error during bulk change type scheduling for change type : {change_type}",
                "request_received_at":request_received_at
            }

            common_utils_database.log_error_to_db(error_data, "error_log_table")

        except Exception as audit_error:
            logging.exception(f"### Logging error failed: {audit_error} in Error case")

        return {
            "flag": False,
            "message": f"Bulk change type scheduling is failed for change type : {change_type}",
            "details": str(e)
        }




data = {
  "tenant_name": "Altaworx",
  "path": "/bulk_change_processor",
  "role_name": "Super Admin",
  "username": "lohitha.v@algonox.com",
  "request_received_at": "2026-02-23 12:54:54.235",
  "access_token": "eyJhbGciOiJSUzI1NiIsImtpZCI6IjMzNDQ0Mzk5NTgxODE1MzIzMCIsInR5cCI6IkpXVCJ9.eyJhdWQiOlsiMjc4MDg2NzkwODI3NTY1NTIyIiwiMjU2ODkwNjQ5MzM5NTk0NTc2QGF1dGhlbnRpY2F0aW9uYXBpIiwiMjU2ODg5OTc1MzE0ODc2MjQwIl0sImNsaWVudF9pZCI6IjI1Njg5MDY0OTMzOTU5NDU3NkBhdXRoZW50aWNhdGlvbmFwaSIsImVtYWlsIjoibG9oaXRoYS52QGFsZ29ub3guY29tIiwiZW1haWxfdmVyaWZpZWQiOnRydWUsImV4cCI6MTc3MTkxMTk2OSwiZmFtaWx5X25hbWUiOiJWIiwiZ2l2ZW5fbmFtZSI6IkxvaGl0aGEiLCJpYXQiOjE3NzE4MjU1NjksImlzcyI6Imh0dHBzOi8vYW1vcC1kZXZlbG9wbWVudC14Mmttb2Eueml0YWRlbC5jbG91ZCIsImp0aSI6IlYyXzM2MTI2MzA2OTQxNTkxOTk0OC1hdF8zNjEyNjMwNjk0MTU5ODU0ODQiLCJsb2NhbGUiOm51bGwsIm5hbWUiOiJMb2hpdGhhIFYiLCJuYmYiOjE3NzE4MjU1NjksInByZWZlcnJlZF91c2VybmFtZSI6ImxvaGl0aGEudkBhbGdvbm94LmNvbSIsInN1YiI6IjI2NzExNDA4MDMwMzYyOTY2MiIsInVwZGF0ZWRfYXQiOjE3MTU3MDgzOTksInVybjp6aXRhZGVsOmlhbTp1c2VyOm1ldGFkYXRhIjp7InBlcm1pc3Npb24iOiJleUoxYzJWeVVtOXNaWE1pT2x0N0luSnZiR1ZKWkNJNk1Td2ljbTlzWlU1aGJXVWlPaUpUZFhCbGNpQkJaRzFwYmlJc0luTnBkR1ZKWkNJNmJuVnNiQ3dpYzJsMFpVZHliM1Z3U1dRaU9tNTFiR3dzSW5SbGJtRnVkRWxrSWpveExDSjBaVzVoYm5ST1lXMWxJam9pUVd4MFlYZHZjbmdpZlN4N0luSnZiR1ZKWkNJNk1Td2ljbTlzWlU1aGJXVWlPaUpUZFhCbGNpQkJaRzFwYmlJc0luTnBkR1ZKWkNJNmJuVnNiQ3dpYzJsMFpVZHliM1Z3U1dRaU9tNTFiR3dzSW5SbGJtRnVkRWxrSWpveU1USXNJblJsYm1GdWRFNWhiV1VpT2lKQmJIUmhkMjl5ZUNCVVpYTjBJbjFkTENKMWMyVnlWR1Z1WVc1MGN5STZXM3NpYVdRaU9qRXNJbTVoYldVaU9pSkJiSFJoZDI5eWVDSXNJbWx6VTNWd1pYSkJaRzFwYmlJNmRISjFaU3dpYVhOUVlYSmxiblJCWkcxcGJpSTZkSEoxWlN3aWFYTkRhR2xzWkVGa2JXbHVJanBtWVd4elpTd2lhWE5RWVhKbGJuUlBja05vYVd4a1FXUnRhVzRpT25SeWRXVXNJbWx6VlhObGNsSnZiR1VpT21aaGJITmxMQ0pwYzBGblpXNTBJanBtWVd4elpTd2lhWE5SZFdGc2FXWnBZMkYwYVc5dVQyNXNlVlZ6WlhJaU9tWmhiSE5sTENKallXNUJZMk5sYzNOTmIyUjFiR1Z6SWpwYlhYMWRMQ0owWlc1aGJuUk5iMlIxYkdWeklqcGJleUpwWkNJNk1Td2liVzlrZFd4bFNXUnpJanBiTVN3eUxETXNOQ3cxTERZc09Dd3hNQ3d4TVN3eE1pd3hNeXd4TkN3eE5Td3hOeXd4Tml3eE9Td3hPQ3d5TUN3eU1Td3lNaXd5TXl3eU5Td3lOQ3d5Tml3eU55d3lPQ3d5T1N3ek1Dd3pNU3d6TWl3ek15d3pORjE5TEhzaWFXUWlPakV5T1N3aWJXOWtkV3hsU1dSeklqcGJNU3d5TERNc05DdzFMRFlzT0N3eE1Dd3hNU3d4TWl3eE5Dd3hOU3d4Tml3eE9Dd3hPU3d5TUN3eU1pd3lNeXd5TkN3eU5Td3lOaXd5Tnl3eU9Dd3lPU3d6TUN3ek1Td3pNaXd6TkYxOUxIc2lhV1FpT2pJeE1pd2liVzlrZFd4bFNXUnpJanBiTkN3eE1pd3hOaXd4T0N3eU1pd3lOQ3d5TlN3eU5pd3lOeXd5T1N3ek1pd3pNeXd6TkN3ekxEVXNOaXc0TERFd0xERXhMREV6TERFMExERTFMREUzTERFNUxESXdMREl6TERJNExETXdMRE14WFgwc2V5SnBaQ0k2TWpJMkxDSnRiMlIxYkdWSlpITWlPbHN5TERFeExERTBMREV5TERFd0xERTFMRFVzTVN3eE15dzJMRE1zTkN3eU1Dd3hPQ3d5TVN3eU5Dd3lOaXd6TWl3ek5GMTlMSHNpYVdRaU9qRXhOVGtzSW0xdlpIVnNaVWxrY3lJNld6SXNNVEVzTWpJc01UUXNNVEFzTVRVc01USXNNakFzTlN3eExERTJMRFlzT0N3eE9Dd3pMREkxTERJMkxESTNMREk0WFgwc2V5SnBaQ0k2TVRFMk5Td2liVzlrZFd4bFNXUnpJanBiTlN3MkxEZ3NNVFpkZlN4N0ltbGtJam94TVRZMkxDSnRiMlIxYkdWSlpITWlPbHN6TERnc01UTXNNVFFzTVRVc01qQmRmU3g3SW1sa0lqb3hNVFkzTENKdGIyUjFiR1ZKWkhNaU9sc3pMRFFzTVRBc01USXNNVE1zTVRRc01UVXNNVGdzTWpBc01qRXNNalFzTWpZc016SXNNVEZkZlN4N0ltbGtJam94TVRZNExDSnRiMlIxYkdWSlpITWlPbHN6TERRc05TdzJMRGdzTVRBc01URXNNVElzTVRNc01UUXNNVFVzTVRZc01UZ3NNakFzTVRjc016RXNNalFzTWpVc01qWXNNelJkZlN4N0ltbGtJam94TVRjeUxDSnRiMlIxYkdWSlpITWlPbHRkZlN4N0ltbGtJam94TVRjMExDSnRiMlIxYkdWSlpITWlPbHN4TERJc015dzBMRFVzTml3NExERXdMREV4TERFeUxERXpMREUwTERFMVhYMHNleUpwWkNJNk1URTRPQ3dpYlc5a2RXeGxTV1J6SWpwYk1pd3hNU3d5TWl3eE9Td3pNQ3d4TkN3ek15d3lNeXd4TUN3eE5Td3hNaXd5TUN3MUxERXNNVGNzTVRZc01UTXNNekVzTXpRc01qRXNOaXd5T1N3NExETXlMREU0TERNc05GMTlMSHNpYVdRaU9qRXhPRGtzSW0xdlpIVnNaVWxrY3lJNld6SXNNVEVzTWpJc01Ua3NNekFzTVRRc016TXNNalVzTWpRc01qWXNNamNzTWpnc01qTXNNVEFzTVRVc01USXNNakFzTlN3eExERTNMREUyTERFekxETXhMRE0wTERZc01qa3NPQ3d6TWl3eE9Dd3pMRFJkZlN4N0ltbGtJam94TVRrd0xDSnRiMlIxYkdWSlpITWlPbHN5TERFeExESXlMREU1TERNd0xERTBMRE16TERJMUxESTBMREkyTERJM0xESTRMREl6TERFd0xERTFMREV5TERJd0xEVXNNU3d4Tnl3eE5pd3hNeXd6TVN3ek5DdzJMREk1TERnc016SXNNVGdzTXl3MFhYMHNleUpwWkNJNk1URTVNU3dpYlc5a2RXeGxTV1J6SWpwYk1pd3hNU3d5TWl3eE9Td3pNQ3d4TkN3ek15d3lOU3d5TkN3eU5pd3lOeXd5T0N3eU15d3hNQ3d4TlN3eE1pd3lNQ3cxTERFc01UY3NNVFlzTVRNc016RXNNelFzTml3eU9TdzRMRE15TERFNExETXNORjE5TEhzaWFXUWlPakV4T1RNc0ltMXZaSFZzWlVsa2N5STZXMTE5TEhzaWFXUWlPakV4T1RRc0ltMXZaSFZzWlVsa2N5STZXMTE5TEhzaWFXUWlPakV4T1RVc0ltMXZaSFZzWlVsa2N5STZXekVzTWl3ekxEUXNOU3cyTERnc01UQXNNVEVzTVRJc01UTXNNVFFzTVRVc01UWXNNVGNzTVRnc01Ua3NNakFzTWpFc01qSXNNak1zTWpRc01qVXNNallzTWpjc01qZ3NNamtzTXpBc016RXNNeklzTXpNc016UmRmU3g3SW1sa0lqb3hNVGszTENKdGIyUjFiR1ZKWkhNaU9sc3hNaXd4TXl3eU1GMTlMSHNpYVdRaU9qRXhPVGdzSW0xdlpIVnNaVWxrY3lJNlcxMTlMSHNpYVdRaU9qRXhPVGtzSW0xdlpIVnNaVWxrY3lJNlcxMTlYWDAiLCJwZXJtaXNzaW9uLXJlZnJlc2gtcmVxdWlyZWQiOiJXVVZUIiwicGVybWlzc2lvbi12ZXJzaW9uIjoiTVRJMCJ9fQ.hBhJZIX4S2for9O4kgllFRi5o-bvZUxdD4wQpCIwz2mAyOx61yF80Mo4hTGS7VBxkadYqQHLp0yu5QvgSqJ-eUsej1GDIUB7pspNl2F4fGnB80BuEG4fdkrg3mPS2zqilPSxhwTYr9jye9fZMfjIyhX5M9Re36QJdPKfO_pC9hQrUqiPQdjWvVxjJyi7X74MEdUOKj-eKNUIBJPxIflVCSvAh-Lz37JrCPWPn0MpTtl5n0qtIqgKAi5kFSx7kieQhQP6HwmOZn1oLrkeYVBPLdJtK0dihi7bXu3F4fz4KvId4Q6GMqNm9Umq2243jcETonqFw1VJT54FcwVnjFg41Q",
  "db_name": "altaworx_central_beta",
  "db_config_details": "eyJwb3J0IjogIjU0MzIiLCAidXNlciI6ICJyb290IiwgImRiX3R5cGUiOiAicG9zdGdyZXNxbCIsICJkYXRhYmFzZSI6ICJhbHRhd29yeF9jZW50cmFsX2JldGEiLCAiaG9zdG5hbWUiOiAiYW1vcHVhdHBvc3RncmVzb2N0MjMuYzNxYWU2NmtlMWxnLnVzLWVhc3QtMS5yZHMuYW1hem9uYXdzLmNvbSIsICJwYXNzd29yZCI6ICJBbW9wVGVhbTEyMyJ9",
  "sessionID": "4fda9e59-b673-4d6c-b0b2-176af8475b1b",
  "service_provider": "AT&T - POD19",
  "parent_provider_name": "",
  "change_type": "Change Customer Rate Plan",
  "created_by": "Lohitha V",
  "iccids": [
    "89010304300130278849"
  ],
  "use_carrier_activation": False,
  "changed_data": {
    "customer_rate_plan_name": "AT&T POD19 100GB - Pooled",
    "customer_rate_pool_name": None,
    "effective_date": "2026-02-23T17:25:00.000Z"
  },
  "bulk_change_id": 14444
}
res = schedule_bulk_change_execution(data)
logging.info("#### result ===> ",res)






















