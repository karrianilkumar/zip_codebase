"""
Module for sending emails using SendGrid.
This module provides a function to send emails using the SendGrid API.

@Author1 : Phaneendra.Y
@Author2 : Burhan

Created Date: June 06, 2024
"""

import re
import os
import base64
import time
import json
import pandas as pd
import psutil
import boto3
import datetime
from sendgrid import SendGridAPIClient
# from sendgrid.exceptions import SendGridException
from sendgrid.helpers.mail import (
    Mail,
    Content,
    Attachment,
    FileContent,
    FileName,
    FileType,
    Disposition
)
from io import StringIO
# from lxml import etree
import xml.etree.ElementTree as ET
import csv

# Importing the necessary Libraries
import psycopg2
from time import time
from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine, exc
from sqlalchemy.exc import OperationalError
from time import time
import pandas as pd
import re
from sqlalchemy import text
from sqlalchemy import literal
from sqlalchemy.orm import sessionmaker
from sqlalchemy import delete, and_, or_
from sqlalchemy import create_engine, Table, MetaData, select, desc, asc, and_,update,or_,insert,func
from sqlalchemy import Integer, String, Float, DateTime, Boolean, Column, Table, MetaData
from sqlalchemy import insert
#from common_utils.logging_utils import Logging
import numpy as np
import json
import os
from datetime import datetime
# from common_utils.db_utils import DB
#from common_utils.logging_utils import Logging
# Dictionary to store database configuration settings retrieved from environment variables.
# db_config = {
#     'host': 'amopuatpostgresoct23.c3qae66ke1lg.us-east-1.rds.amazonaws.com',
#     'port': '5432',
#     'user': 'root',
#     'password': 'AmopTeam123'
# }
#logging = Logging(name="email_trigger")
class DB(object):
    def __init__(self, database, host='127.0.0.1', user='root', password='', port='3306' ,customers = None ,service_providers = None,service_provider_id=None ,db_type='postgresql'):
        """
        Initialization of databse object.

        Args:
            databse (str): The database to connect to.
            host (str): Host IP address. For dockerized app, it is the name of
                the service set in the compose file.
            user (str): Username of PostgresSQL server. (default = 'root')
            password (str): Password of PostgresSQL server. For dockerized app, the
                password is set in the compose file. (default = '')
            port (str): Port number for PostgresSQL. For dockerized app, the port that
                is mapped in the compose file. (default = '3306')
        """
        # Assigning instance variables with the given arguments or default values
        self.HOST = host
        self.USER = user
        self.PASSWORD = password
        self.PORT = port
        self.DATABASE = f'{database}'
        self.DB_TYPE = db_type
        self.customers = customers
        self.service_providers = service_providers
        self.service_provider_id = service_provider_id
        # Logging the connection details for debugging purposes
        #print(f'Host: {self.HOST}')
        #print(f'User: {self.USER}')
        #print(f'Port: {self.PORT}')
        #print(f'Database: {self.DATABASE}')
        # Calling the connect method to establish a connection to the database
        self.connect()
        self.file_path = f"C:/Users/Admin/Documents/local/common_utils/schemas/{database}.json"

        # Check if the file exists
        if not os.path.exists(self.file_path):
            print(
                f"File for '{database}' not found. Using default 'default_schema' instead."
            )
            # Replace with default database if file is not found
            self.file_path = f"C:/Users/Admin/Documents/local/common_utils/schemas/default_schema.json"
        self.metadata, self.tables = self.load_schema(self.file_path)

    def __del__(self):
        # This method is called when the object is about to be destroyed
        try:
            print("############### DETROYING THE DB CONNECTION")
            # Attempting to close the database connection
            self.engine.close()
            # Disposing of the database engine to free up resources
            # if self.engine:
            #     self.engine.dispose()
            print('connections are closed')

        except Exception as e:
            print('########### Failed to destroy the DB COnenctions', e)


    def connect(self, max_retry=3):
        retry = 1
        try:
            #start = time.time()
            print(f'Making connection to `{self.DATABASE}`...')
            config = f'postgresql://{self.USER}:{self.PASSWORD}@{self.HOST}:{self.PORT}/{self.DATABASE}'
            #print(f"connection : {config}")
            self.engine = create_engine(config, connect_args={'connect_timeout': 10}, pool_recycle=300)
            print(f'Engine created for `{self.DATABASE}`')
            while retry <= max_retry:
                try:
                    self.engine = self.engine.connect()
                    self.session = sessionmaker(bind=self.engine)()
                    #print(f'Connection established successfully to `{self.DATABASE}`! ({round(time() - start, 2)} secs to connect)')
                    break
                except Exception as e:
                    print(f'Connection failed. Retrying... ({retry}) [{e}]')
                    retry += 1
                    self.engine.dispose()
                    if retry > max_retry:
                        raise Exception('Max retry attempts reached. Could not connect to the database.')
        except Exception as e:
            raise Exception(f'Something went wrong while connecting. Check trace. {e}')


    def type_from_string(self,type_str):
        # Map type strings to SQLAlchemy types
        type_map = {
            'Integer': Integer,
            'String': String,
            'Float': Float,
            'DateTime': DateTime,
            'Boolean': Boolean
            # Add other types as needed
        }
        return type_map.get(type_str, String)  # Default to String if type is not found

    def load_schema(self, schema_file):
        metadata = MetaData()
        tables = {}

        with open(schema_file, 'r') as f:
            schema = json.load(f)

        for table_name, columns in schema.items():
            column_objects = []
            for col in columns:
                col_type = self.type_from_string(col['type'])  # Convert type string to actual type
                column_objects.append(Column(col['name'], col_type, nullable=col['nullable'], primary_key=col['primary_key']))

            tables[table_name] = Table(table_name, metadata, *column_objects)

        return metadata, tables


    def combine_records_excluding_columns(self,data, exclude_columns=['id', 'schema_tag']):
        # Create a DataFrame from the input data
        df = pd.DataFrame(data)

        # Determine which columns to include by excluding the specified columns
        include_columns = df.columns.difference(exclude_columns)

        # Group by the include_columns and perform aggregation
        result = (
            df.groupby(include_columns.tolist(), as_index=False)
            .agg(
                id=('id', lambda x: '-'.join(map(str, x))),  # Join original IDs
                schema_tag=('schema_tag', lambda x: '-'.join(set(x)))  # Aggregate schema tags
            )
        )

        return result


    def fetch_schemas(self):
        schema_query = """
        SELECT nspname AS schema_name
        FROM pg_catalog.pg_namespace
        WHERE nspname NOT LIKE 'pg_%'
        AND nspname != 'information_schema';
        """

        with self.engine as connection:
            schemas_result = connection.execute(text(schema_query)).fetchall()

        schemas = [row[0] for row in schemas_result]  # Getting the result returns a list of schema names
        if not schemas:
            print("No schemas found.")
            return []
        return schemas


    def set_shema_path(self,schema):
        # Set the search path to the schema
        set_path=f"SET search_path TO {schema}"
        try:
            if self.engine.closed:
                print('Connection is closed. Attempting to reconnect...')
                self.connect()
            pd.read_sql(set_path, self.engine)
        except exc.ResourceClosedError:
            print('Query executed, but it does not have any result to return.')
            return None


    def execute_query_multi_schemas(self, query, flag=False,insert=[],update=[],schemas=[],attempt=0, **kwargs):
        """
        Executes an SQL query.

        Args:
            query (str): The query that needs to be executed.
            flag (bool): A flag to indicate if the query should proceed without parameters.
            direct_query (bool): If True, executes the query across all available schemas.
            attempt (int): Number of attempts made for retries in case of connection errors.
            kwargs: Additional arguments like 'params' for the query.

        Returns:
            (DataFrame): A pandas DataFrame containing the result of the query, or None if an error occurs.
        """

        try:
            # Initialize data variable
            data = None
            print(f'Executing Query in execute_query_multi_schemas: {query} and insert is {insert} and update is {update} and schemas is {schemas}')

            combined_results = []
            # Handle direct query for executing across schemas
            if insert:
                schemas=insert
            elif update:
                schemas=update

            for schema in schemas:
                try:
                    # Check if the query is parameterized
                    if 'params' not in kwargs and not flag:
                        print('Cannot execute query (Expecting parameterized query).')
                        return None

                    # Extract parameters from kwargs, if available
                    params = tuple(kwargs.get('params', ()))
                    print(f'Params: {params}')

                    print(f"Running query on schema: {schema}")
                    self.set_shema_path(schema)

                    if hasattr(query, 'compile'):
                        query_str = str(query.compile(compile_kwargs={"literal_binds": True}))
                    else:
                        query_str = str(query)

                    print(f'####### Query: {query_str}')
                    print(f'####### Params: {params}')

                    # Execute the query using pandas read_sql method
                    try:
                        query_str=query_str.replace("`","")
                        query_str=query_str.replace('"','')
                    except:
                        pass

                    if self.engine.closed:
                        print('Connection is closed. Attempting to reconnect...')
                        self.connect()

                    # Execute the query using pandas read_sql method
                    schema_data = pd.read_sql(query_str, self.engine, params=params)
                    print(f"Query executed successfully.and data is {schema_data}")

                    if not insert and not update:
                        schema_data['schema_tag']=schema
                        combined_results.append(schema_data)
                except exc.ResourceClosedError:
                    print('Query executed, but it does not have any result to return.')

            # Combine results across schemas and return as one DataFrame
            if combined_results:
                return self.combine_records_excluding_columns(pd.concat(combined_results, ignore_index=True))
            else:
                print("No results obtained across schemas.")
                return True

        except exc.ResourceClosedError:
            print('Query executed, but it does not have any result to return.')
            return None

        except exc.IntegrityError as e:
            print(f'Integrity Error: {e}')
            return None

        except (exc.StatementError, OperationalError) as e:
            # Handle statement and operational errors (e.g., connection issues)
            print(f'Error encountered: {e}. Retrying (attempt #{attempt + 1})...')
            attempt += 1
            if attempt <= 3:
                # Retry the connection and execution
                self.connect()
                return self.execute_query(query, flag=flag,insert=insert,update=update, attempt=attempt, **kwargs)
            else:
                print('Maximum retry attempts reached.')
                return None

        except Exception as e:
            print(f'Error executing query: {e}')
            return None


    def append_conditions(self,query):

        try:
            exception_tables=["users"]
            query = query.replace("\n", " ").replace("\t", " ")
            # Remove extra spaces
            query = " ".join(query.split())
            query=query.replace(";","")
            # tables = re.findall(r'(FROM|JOIN)\s+([a-zA-Z0-9_]+)(?:\s+AS\s+([a-zA-Z0-9_]+))?', query, re.IGNORECASE)
            tables = re.findall(r'(FROM|JOIN)\s+([a-zA-Z0-9_]+\.[a-zA-Z0-9_]+|\S+)(?:\s+AS\s+([a-zA-Z0-9_]+))?', query, re.IGNORECASE)

            # Extract table names and aliases into a list (ignoring 'FROM' and 'JOIN' keywords)
            table_info = [(table[1], table[2] if len(table) > 2 else table[1]) for table in tables]
            print("TABLES AND ALIASES:", table_info)

            # Step 2: Define the additional conditions based on the table(s)
            additional_conditions = ""

            # Loop through the list of tables and append conditions for each
            for table_name, alias in table_info:

                if table_name in exception_tables:
                    continue

                customer_columns = ['customer_name']
                service_provider_column = ['serviceprovider', 'serviceprovidername', 'serviceproviderdisplayname', 'serviceproviders']
                service_provider_id_column=['serviceproviderid']

                if self.customers or self.service_providers:
                    parts=table_name.split('.')
                    if len(parts)>1:
                        cols = self.get_columns(parts[1])
                    else:
                        cols = self.get_columns(parts[0])
                    print('COLUMNS ARE', cols, self.customers, self.service_providers)

                    if self.service_providers and self.service_providers[0]:
                        found=False
                        if 'vw' in table_name.lower():
                            for col_ in cols:
                                col=re.sub(r'[^a-zA-Z]', '', col_).lower()
                                print(self.service_provider_id)
                                if col in service_provider_id_column and (self.service_provider_id and self.service_provider_id[0]) :
                                    found=True
                                    print(self.service_provider_id)
                                    if len(self.service_provider_id) == 1:
                                        if alias:
                                            additional_conditions += f" AND {alias}.{col_} = '{self.service_provider_id[0]}'"
                                        else:
                                            additional_conditions += f" AND {col_} = '{self.service_provider_id[0]}'"
                                    else:
                                        if alias:
                                            additional_conditions += f" AND {alias}.{col_} IN {self.service_provider_id}"
                                        else:
                                            additional_conditions += f" AND {col_} IN {self.service_provider_id}"
                                    break

                        if not found:
                            for col_ in cols:
                                col=re.sub(r'[^a-zA-Z]', '', col_).lower()
                                if col in service_provider_column:
                                    if len(self.service_providers) == 1:
                                        if alias:
                                            additional_conditions += f" AND {alias}.{col_} = '{self.service_providers[0]}'"
                                        else:
                                            additional_conditions += f" AND {col_} = '{self.service_providers[0]}'"
                                    else:
                                        if alias:
                                            additional_conditions += f" AND {alias}.{col_} IN {self.service_providers}"
                                        else:
                                            additional_conditions += f" AND {col_} IN {self.service_providers}"
                                    break

                    if self.customers and self.customers[0]:
                        for col_ in cols:
                            if col_ in customer_columns:
                                col=re.sub(r'[^a-zA-Z]', '', col_).lower()
                                if len(self.customers) == 1:
                                    if alias:
                                        additional_conditions += f" AND {alias}.{col_} = '{self.customers[0]}'"
                                    else:
                                        additional_conditions += f" AND {col_} = '{self.customers[0]}'"
                                else:
                                    if alias:
                                        additional_conditions += f" AND {alias}.{col_} IN {self.customers}"
                                    else:
                                        additional_conditions += f" AND {col_} IN {self.customers}"
                                break

            query_parts = re.split(r"(\sGROUP\sBY\s.+)", query, flags=re.IGNORECASE)
            order_limit_clause = "".join(query_parts[1:])
            if not order_limit_clause:
                query_parts= re.split(r"(\sORDER\sBY\s.+|\sLIMIT\s\d+)", query, flags=re.IGNORECASE)
                order_limit_clause = "".join(query_parts[1:])
                if not order_limit_clause:
                    query_parts = re.split(r"(\sLIMIT\s(?:\d+|\%s)\sOFFSET\s(?:\d+|\%s)|\sLIMIT\s(?:\d+|\%s))", query, flags=re.IGNORECASE)
                    order_limit_clause = "".join(query_parts[1:])
            print(order_limit_clause,'order_limit_clause')
            # Remove any WHERE, ORDER BY, and LIMIT clauses to avoid conflicts
            if order_limit_clause:
                query = base_query = query_parts[0]  # Base query without ORDER BY/LIMIT   # Remove only ORDER BY and LIMIT
                print(query)

            # Step 4: Add the WHERE clause if additional conditions exist
            if additional_conditions:
                if "WHERE" in query.upper():
                    query += additional_conditions
                else:
                    query += " WHERE 1=1" + additional_conditions

            # Step 5: Re-attach any ORDER BY and LIMIT clauses back to the query
            if order_limit_clause:
                query += order_limit_clause # Append ORDER BY / LIMIT
        except Exception as e:
            print(f'Error appending conditions: {e}')

        return query


    def execute_query(self, query,flag=False,no_filter_append=False, insert=[],update=[],attempt=0, **kwargs):
        """
        Executes an SQL query.

        Args:
            query (str): The query that needs to be executed.
            params (list/tuple/dict): List of parameters to pass to in the query.

        Returns:
            (DataFrame) A pandas dataframe containing the data from the executed
            query. (None if an error occurs)
        """
        # Initialize data variable
        data = None
        print(f'Query: {query}')
        schemas=[]
        if not insert and not update:
            schemas=self.fetch_schemas()
        print(f'schemas: {schemas}')

        if len(schemas)>1 or len(update)>0 or len(insert)>1:
            return self.execute_query_multi_schemas(query,flag,insert,update,schemas)
        Session = sessionmaker(bind=self.engine)
        session = Session()  # Create a new session
        try:
            # Check if the query is parameterized
            if 'params' not in kwargs and not flag:
                print('Cannot execute query (Expecting parametarized query).')
                return True
            # Extract parameters from kwargs if available
            params = kwargs['params'] if 'params' in kwargs else None
            if params:
                params=tuple(params)
            else:
                params=()

            if self.engine.closed:
                print('Connection is closed. Attempting to reconnect...')
                self.connect()

            if hasattr(query, 'compile'):
                query_str = str(query.compile(compile_kwargs={"literal_binds": True}))
            else:
                query_str = str(query)

            print(f'####### Query: {query_str}')
            print(f'####### Params: {params}')

            # Execute the query using pandas read_sql method
            try:
                query_str=query_str.replace("`","")
                query_str=query_str.replace('"','')
            except:
                pass

            if self.customers or self.service_providers and "SELECT" in query_str.upper() and not no_filter_append:
                query_str=self.append_conditions(query_str)

            print(f'####### after additional add ons Query: {query_str}')

            data = pd.read_sql(query_str, self.engine, params=params)
            # data =  self.engine.execute(query, params=params)
            print(f"########### Data")
        except exc.ResourceClosedError:
            print('Query does not have any value to return.')
            return True
        except exc.IntegrityError as e:
            print(f'Integrity Error - {e}')
            return None
        except (exc.StatementError, OperationalError) as e:
            # Handle statement errors and operational errors (e.g., connection issues)
            print(f'Creating new connection. Engine/Connection is probably None. [{e}]')
            attempt += 1
            if attempt <= 3:
                # Reconnect to the database
                self.connect()
                print(f'Attempt #{attempt}')
                # Execute the query using execute_query
                return self.execute_query(query, attempt=attempt, **kwargs)
            else:
                print(f'Maximum attempts reached. ({3})')
                return False
        except Exception as e:
            print(f'Something went wrong executing query. Check trace. {e}')
            params = kwargs['params'] if 'params' in kwargs else None
            return False
        finally:
            session.close()
            print('connections are closed')
        # Replace NaN values in the resulting DataFrame with None and return
        return data.replace({np.nan: None})


    def _build_filters(self,table, filters, combine_logic=[]):

        filter_conditions = []
        count=0
        for key, value in filters.items():
            # Check if condition is a tuple (value, logic) e.g., ("not Null", "OR")
            if str(count) in combine_logic:
                logic = "OR"
            else:
                logic = "AND"  # Default logic if not specified

            # Handle NULL and NOT NULL conditions
            if value == "not Null":
                filter_condition = table.c[key].isnot(None)
            elif value == "Null":
                filter_condition = table.c[key].is_(None)
            elif isinstance(value, (list, tuple)):
                # Handle WHERE IN condition
                filter_condition = table.c[key].in_(value)
            else:
                filter_condition = table.c[key] == value
            count=count+1
            filter_conditions.append((filter_condition, logic))

        # Combine conditions based on the specified logic
        and_conditions = [cond for cond, logic in filter_conditions if logic == 'AND']
        or_conditions = [cond for cond, logic in filter_conditions if logic == 'OR']

        combined_condition = "None"
        if and_conditions:
            combined_condition = and_(*and_conditions)
        if or_conditions:
            or_combined = or_(*or_conditions)

            if combined_condition != "None":
                combined_condition = and_(combined_condition, or_combined)
            else:
                combined_condition = or_combined

        return combined_condition


    def get_data(self, table_name=None, condition=None, columns=None, order=None, combine=[], joins=None, mod_pages=None, concat_columns=None,coalesce_columns=None):
        Session = sessionmaker(bind=self.engine)
        session = Session()  # Create a new session

        try:
            print(table_name, condition, columns, order, joins)

            # Reflect the table from the database schema
            # metadata = MetaData()
            # metadata.reflect(bind=self.engine)
            # table = Table(table_name, metadata, autoload_with=self.engine)
            table = self.tables.get(table_name)

            if columns:
                columns = [table.c[col] if isinstance(col, str) else col for col in columns]
            else:
                columns = [table]

            # Handle concatenation if `concat_columns` is provided
            if concat_columns:
                name_column, id_column = concat_columns
                concat_expr = func.concat(
                    table.c[name_column],
                    str(' -- '),
                    table.c[id_column]
                )
                columns.append(concat_expr.label('concat_column'))

            if coalesce_columns:
                coalesce_expr = func.coalesce(
                    *[table.c[col] for col in coalesce_columns]
                )
                columns.append(coalesce_expr.label('coalesce_column'))


            # Create the base query
            query = select(*columns)

            # Handle joins
            if joins:
                for join_table, on_condition in joins.items():
                    join_table = Table(join_table, metadata, autoload_with=self.engine)
                    query = query.join(join_table, on_condition)

            # Apply filters
            if condition:
                where = self._build_filters(table, condition, combine)
                query = query.where(where)

            # Apply ordering
            if order:
                order_by = list(order.keys())[0]
                order_direction = list(order.values())[0]
                order_clause = asc(order_by) if order_direction == 'asc' else desc(order_by)
                query = query.order_by(order_clause)

            # Apply pagination
            if mod_pages:
                start = mod_pages.get('start', 0)
                end = mod_pages.get('end', 500)
                query = query.offset(start).limit(end - start)

            print(f"Final query that is going to get executed is {query}")
            return self.execute_query(query, True)

        except Exception as e:
            # Logging an exception if any error occurs during the update process
            print(f'Error getting data: {e}')
            return False
        finally:
            session.close()  # Ensure the session is closed
    def get_data_bp(self, table_name=None, condition=None, columns=None, order=None, combine=[], joins=None, mod_pages=None, concat_columns=None,coalesce_columns=None):
        Session = sessionmaker(bind=self.engine)
        session = Session()  # Create a new session

        try:
            print(table_name, condition, columns, order, joins)

            # Reflect the table from the database schema
            # metadata = MetaData()
            # metadata.reflect(bind=self.engine)
            # table = Table(table_name, metadata, autoload_with=self.engine)
            table = self.tables.get(table_name)

            if columns:
                columns = [table.c[col] if isinstance(col, str) else col for col in columns]
            else:
                columns = [table]

            # Handle concatenation if `concat_columns` is provided
            if concat_columns:
                name_column, id_column = concat_columns
                concat_expr = func.concat(
                    table.c[name_column],
                    str(' -- '),
                    table.c[id_column]
                )
                columns.append(concat_expr.label('concat_column'))

            if coalesce_columns:
                coalesce_expr = func.coalesce(
                    *[table.c[col] for col in coalesce_columns]
                )
                columns.append(coalesce_expr.label('coalesce_column'))


            # Create the base query
            query = select(*columns)

            # Handle joins
            if joins:
                for join_table, on_condition in joins.items():
                    join_table = Table(join_table, metadata, autoload_with=self.engine)
                    query = query.join(join_table, on_condition)

            # Apply filters
            if condition:
                print(f'condition is {condition}')
                where = self._build_filters_bp(table, condition, combine)
                print(f'where is {where}')
                query = query.where(where)
                print(f'query is {query}')

            # Apply ordering
            if order:
                order_by = list(order.keys())[0]
                order_direction = list(order.values())[0]
                order_clause = asc(order_by) if order_direction == 'asc' else desc(order_by)
                query = query.order_by(order_clause)

            # Apply pagination
            if mod_pages:
                start = mod_pages.get('start', 0)
                end = mod_pages.get('end', 500)
                query = query.offset(start).limit(end - start)

            print(f"Final query that is going to get executed is {query}")
            return self.execute_query(query, True)

        except Exception as e:
            # Logging an exception if any error occurs during the update process
            print(f'Error getting data: {e}')
            return False
        finally:
            session.close()  # Ensure the session is closed
    def _build_filters_bp(self, table, filters, combine_logic=[]):
        filter_conditions = []
        count = 0

        for key, value in filters.items():
            print(f'key is {key} and value is {value}')
            # Determine the logic (AND/OR)
            logic = "OR" if str(count) in combine_logic else "AND"

            col = table.c[key]

            # Handle IS NULL / IS NOT NULL
            if value == "not Null":
                filter_condition = col.isnot(None)
            elif value == "Null":
                filter_condition = col.is_(None)
            elif isinstance(value, (list, tuple)):
                if len(value) == 2 and value[0] in ['>', '<', '>=', '<=', '!=', 'like']:
                    operator, val = value
                    if operator == '>':
                        filter_condition = col > val
                    elif operator == '<':
                        filter_condition = col < val
                    elif operator == '>=':
                        filter_condition = col >= val
                    elif operator == '<=':
                        filter_condition = col <= val
                    elif operator == '!=':
                        filter_condition = col != val
                    elif operator == 'like':
                        filter_condition = col.like(val)
                else:
                    # Handle WHERE IN condition
                    filter_condition = col.in_(value)
            else:
                # Default equality
                filter_condition = col == value

            count += 1
            filter_conditions.append((filter_condition, logic))

        # Combine all conditions
        and_conditions = [cond for cond, logic in filter_conditions if logic == 'AND']
        or_conditions = [cond for cond, logic in filter_conditions if logic == 'OR']

        combined_condition = None
        if and_conditions:
            combined_condition = and_(*and_conditions)
        if or_conditions:
            or_combined = or_(*or_conditions)
            combined_condition = and_(combined_condition, or_combined) if combined_condition else or_combined

        print(f'combined_condition is {combined_condition}')
        return combined_condition
    def update_dict(self, table_name, values, and_conditions=None, or_conditions=None, in_conditions=None):
        """
        Updates a table in the database using SQLAlchemy.

        Parameters:
        - table_name: The name of the table to update.
        - values: A dictionary of column-value pairs to update.
        - and_conditions: A list of `AND` conditions (tuples of column and value).
        - or_conditions: A list of `OR` conditions (tuples of column and value).
        - in_conditions: A list of `IN` conditions (tuples of column and list of values).

        Example:
        update_table('users', {'name': 'New Name'},
                    and_conditions={'age':30},
                    or_conditions={'city':'New York'},
                    in_conditions={'id':[1, 2, 3]})
        """

        try:
            # Create connection string
            # metadata = MetaData()
            # metadata.bind = self.engine  # Bind the metadata to the engine
            # table = Table(table_name, metadata, autoload_with=self.engine)
            table = self.tables.get(table_name)

            # Create the base update statement
            stmt = update(table).values(**values)

            # Apply AND conditions
            if and_conditions:
                and_clause = and_(*[table.c[column] == value for column, value in and_conditions.items()])
                stmt = stmt.where(and_clause)

            # Apply OR conditions
            if or_conditions:
                or_clause = or_(*[table.c[column] == value for column, value in or_conditions.items()])
                stmt = stmt.where(or_clause)

            # Apply IN conditions
            if in_conditions:
                in_clause = and_(*[table.c[column].in_(values) for column, values in in_conditions.items()])
                stmt = stmt.where(in_clause)
            print(stmt)
            result = self.engine.execute(stmt)
            self.engine.commit()

            # print("update successful")
            if result.rowcount > 0:
                print("Update successful")
                return True
            else:
                print("No rows were updated")
                return False

        except Exception as e:
            # Logging an exception if any error occurs during the insertion process
            print(f'Error updating data: {e}')
            return False
        finally:
            # Ensure that the cursor and connection are closed
            if 'conn' in locals() and self.engine:
                self.engine.close()

    def update_dict_back(self, table_name, values, and_conditions=None, or_conditions=None, in_conditions=None):
        """
        Updates a table in the database using SQLAlchemy.

        Parameters:
        - table_name: The name of the table to update.
        - values: A dictionary of column-value pairs to update.
        - and_conditions: A dictionary of `AND` conditions (tuples of column and value).
        - or_conditions: A dictionary of `OR` conditions (tuples of column and value).
        - in_conditions: A dictionary of `IN` conditions (tuples of column and list of values).

        Example:
        update_dict('users', {'name': 'New Name'},
                    and_conditions={'age': 30, 'id': '123-456-789'},
                    or_conditions={'city': 'New York'},
                    in_conditions={'id': ['123-456-789', '987-654-321']})
        """

        try:
            # Extract and split the schema_tag from values or conditions
            schema_tag = values.pop('schema_tag', None) or \
                        (and_conditions and and_conditions.pop('schema_tag', None)) or \
                        (or_conditions and or_conditions.pop('schema_tag', None)) or \
                        (in_conditions and in_conditions.pop('schema_tag', None))

            # Split schema_tag by '-' for index use
            schema_tag = schema_tag.split('-') if schema_tag else []
            for ind,tag in enumerate(schema_tag):
                print(f" schema_tag is {tag} and ind is {ind}")
                # Retrieve the table from the schema specified by schema_tag
                table = self.tables.get(table_name)

                # Function to split the id based on schema_tag index
                def process_id_condition(condition_dict):
                    condition={}
                    for key, values_list in condition_dict.items():
                        condition[key]=values_list
                        if key == 'id' and schema_tag:
                            condition['id'] = condition_dict['id'].split('-')[ind]  # Use schema_tag index
                    return condition

                # Process the `and_conditions`, `or_conditions`, and `in_conditions`
                and_condition_dict={}
                if and_conditions:
                    and_condition_dict = process_id_condition(and_conditions)
                or_condition_dict={}
                if or_conditions:
                    or_condition_dict = process_id_condition(or_conditions)
                in_condition_dict={}
                if in_conditions:
                    for key, values_list in in_conditions.items():
                        in_condition_dict[key]=values_list
                        if key == 'id' and schema_tag:
                            in_condition_dict[key] = [value.split('-')[ind] for value in values_list]

                print(and_condition_dict,or_condition_dict,in_condition_dict)

                # Create the base update statement
                stmt = update(table).values(**values)

                # Apply AND conditions
                if and_condition_dict:
                    and_clause = and_(*[table.c[column] == value for column, value in and_condition_dict.items()])
                    stmt = stmt.where(and_clause)

                # Apply OR conditions
                if or_condition_dict:
                    or_clause = or_(*[table.c[column] == value for column, value in or_condition_dict.items()])
                    stmt = stmt.where(or_clause)

                # Apply IN conditions
                if in_condition_dict:
                    in_clause = and_(*[table.c[column].in_(values) for column, values in in_condition_dict.items()])
                    stmt = stmt.where(in_clause)

                # Print the statement for debugging purposes
                print(stmt)

        #       Execute the query
                result = self.execute_query(stmt,True, update=[tag])
                self.engine.commit()

            print("Update successful")
            return True

        except Exception as e:
            # Logging an exception if any error occurs during the process
            print(f'Error updating data: {e}')
            return False

        finally:
            # Ensure that the connection is closed
            if 'conn' in locals() and self.engine:
                self.engine.close()



    def insert_dict(self, data, table):
        """
        Insert dictionary into a SQL database table.

        Args:
            data (dict): The dictionary containing column names and values to insert.
            table (str): The table in which the records should be inserted.

        Returns:
            (bool) True if successfully inserted, else False.
        """
        print(f'Inserting dictionary data into `{table}`...')
        print('testing')
        print(f'Data:\n{data}')

        try:

            # metadata = MetaData()
            # metadata.bind = self.engine  # Bind the metadata to the engine
            # table = Table(table, metadata, autoload_with=self.engine)
            table = self.tables.get(table)

            if not isinstance(data,list):
                data=[data]

            stmt = insert(table).values(data)

            # Executing the constructed query with the parameters
            result = self.execute_query(stmt,True,insert=self.fetch_schemas())
            self.engine.commit()

            print("Insert successful")
            return True

        except Exception as e:
            # Logging an exception if any error occurs during the insertion process
            print(f'Error inserting data: {e}')
            return False
        finally:
            # Ensure that the cursor and connection are closed
            if 'conn' in locals() and self.engine:
                self.engine.close()


    def update_audit(self, data, table):
        """
        Insert dictionary into a SQL database table.

        Args:
            data (dict): The dictionary containing column names and values to insert.
            table (str): The table in which the records should be inserted.

        Returns:
            (bool) True if successfully inserted, else False.
        """
        print(f'Inserting dictionary data into `{table}`...')
        print('testing')
        print(f'Data:\n{data}')

        try:
            # Create connection string
            connection_string = (
                f"{self.DB_TYPE}://{self.USER}:{self.PASSWORD}@{self.HOST}:{self.PORT}/{self.DATABASE}"
            )

            # Establish database connection
            conn = psycopg2.connect(connection_string)
            cursor = conn.cursor()

            # Extracting column names and values
            column_names = [f'"{column_name}"' for column_name in data.keys()]
            params = list(data.values())

            print(f'Column names: {column_names}')
            print(f'Params: {params}')

            # Constructing the SQL query dynamically
            columns_string = ', '.join(column_names)
            param_placeholders = ', '.join(['%s'] * len(column_names))
            print(f"Columns inserting: {columns_string} and values: {param_placeholders}")

            # Making the Insert query
            query = f'INSERT INTO {table} ({columns_string}) VALUES ({param_placeholders})'

            # Executing the constructed query with the parameters
            cursor.execute(query, params)
            conn.commit()

            print("Insert successful")
            return True
        except Exception as e:
            # Logging an exception if any error occurs during the insertion process
            print(f'Error inserting data: {e}')
            return False
        finally:
            # Ensure that the cursor and connection are closed
            if 'cursor' in locals() and cursor:
                cursor.close()
            if 'conn' in locals() and conn:
                conn.close()


    def log_error_to_db(self, data, table):
        """
        Insert dictionary into a SQL database table.

        Args:
            data (dict): The dictionary containing column names and values to insert.
            table (str): The table in which the records should be inserted.

        Returns:
            (bool) True if successfully inserted, else False.
        """
        print(f'Inserting dictionary data into `{table}`...')
        print('testing')
        print(f'Data:\n{data}')

        try:
            # Create connection string
            connection_string = (
                f"{self.DB_TYPE}://{self.USER}:{self.PASSWORD}@{self.HOST}:{self.PORT}/{self.DATABASE}"
            )

            # Establish database connection
            conn = psycopg2.connect(connection_string)
            cursor = conn.cursor()

            # Extracting column names and values
            column_names = [f'"{column_name}"' for column_name in data.keys()]
            params = list(data.values())

            print(f'Column names: {column_names}')
            print(f'Params: {params}')

            # Constructing the SQL query dynamically
            columns_string = ', '.join(column_names)
            param_placeholders = ', '.join(['%s'] * len(column_names))
            print(f"Columns inserting: {columns_string} and values: {param_placeholders}")

            # Making the Insert query
            query = f'INSERT INTO {table} ({columns_string}) VALUES ({param_placeholders})'

            # Executing the constructed query with the parameters
            cursor.execute(query, params)
            conn.commit()
            # # Send success email
            #     # Create dynamic subject and content for the email
            # service_name = data.get('service_name', '')
            # error_message = data.get('error_message', '')
            # error_type = data.get('error_type', '')
            # timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            #     # Create email subject and content
            # subject = f"Error Notification: {service_name} - {error_type}"
            # content = f"""
            #     <p>Hi,</p>
            #     <p>There was an error reported in the service <strong>{service_name}</strong>:</p>
            #     <p><strong>Error Message:</strong> {error_message}</p>
            #     <p><strong>Error Type:</strong> {error_type}</p>
            #     <p><strong>Timestamp:</strong> {timestamp}</p>
            #     <p>Details:</p>
            #     <pre>{data}</pre>
            #     <p>Please investigate the issue as soon as possible.</p>
            #     """

            #     # Send the email
            # template_name = data.get("template_name", 'Log Errors')
            # to_emails, cc_emails, subject, body, from_email, partner_name = send_email(template_name, content=content, is_html=True)
            # message = "Mail sent successfully"

            print("Insert successful")
            return True
        except Exception as e:
            # Logging an exception if any error occurs during the insertion process
            print(f'Error inserting data: {e}')
            return False
        finally:
            # Ensure that the cursor and connection are closed
            if 'cursor' in locals() and cursor:
                cursor.close()
            if 'conn' in locals() and conn:
                conn.close()


    def insert(self, data, table, database=None, if_exists='replace', index=False, method=None):
        """
        Write records stored in a DataFrame to a SQL database.

        Args:
            data (DataFrame): The DataFrame that needs to be write to SQL database.
            table (str): The table in which the rcords should be written to.
            kwargs: Keyword arguments for pandas to_sql function.
                See https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.DataFrame.to_sql.html
                to know the arguments that can be passed.

        Returns:
            (bool) True is succesfully inserted, else false.
        """
        #print(f'Inserting into `{table}`')

        try:
            data.to_sql(table, self.engine, if_exists=if_exists, index=index, method=method)
            return True
        except:
            print('exception')
            return False

    def insert_data(self, data, table):
        """
        Insert dictionary into a SQL database table and return the inserted ID.

        Args:
            data (dict): The dictionary containing column names and values to insert.
            table (str): The table in which the records should be inserted.

        Returns:
            (int) The ID of the inserted row if successful, else None.
        """
        print(f'Inserting dictionary data into `{table}`...')
        print('testing')
        print(f'Data:\n{data}')

        try:
            # Get the table object from metadata
            table = self.tables.get(table)

            if not isinstance(data, list):
                data = [data]

            # Assuming the table has an 'id' column to return after insert
            stmt = insert(table).values(data).returning(table.c.id)

            # Executing the constructed query
            result = self.engine.execute(stmt)
            inserted_id = result.scalar()

            # Committing the transaction
            self.engine.commit()

            print(f"Insert successful, inserted ID: {inserted_id}")
            return inserted_id

        except Exception as e:
            # Logging any error that occurs during the insertion process
            print(f'Error inserting data: {e}')
            return None

        finally:
            # Ensure that the connection is closed
            if 'conn' in locals() and self.engine:
                self.engine.close()

    def get_table_columns(self, table_name):
        query = f"""
        SELECT column_name
        FROM information_schema.columns
        WHERE table_name = '{table_name}'
        ORDER BY ordinal_position;
        """
        return pd.read_sql(query, self.engine)


    def get_columns(self, table):
        """
        Get all column names from an SQL table.
        """
        try:
            print(f'Getting column names of table `{table}`')

            # Query to fetch column names from the database schema

            with open(self.file_path, "r") as f:
                schema = json.load(f)

            if table not in schema:
                with open(f"/opt/python/lib/python3.9/site-packages/common_utils/schemas/default_schema.json", "r") as f:
                    schema = json.load(f)

            column_names = []
            for cols in schema[table]:
                column_names.append(cols['name'])

            return column_names

        except Exception as e:
            print(f"Something went wrong getting column names. Error: {e}")
            return []


    def execute_default_index(self, query, **kwargs):
        """
        Executes an SQL query.

        Args:
            query (str): The query that needs to be executed.
            database (str): Name of the database to execute the query in. Leave
                it none if you want use database during object creation.
            params (list/tuple/dict): List of parameters to pass to in the query.

        Returns:
            (DataFrame) A pandas dataframe containing the data from the executed
            query. (None if an error occurs)
        """
        data = None

        try:
            # Execute the SQL query using pandas read_sql function
            data = pd.read_sql(query, self.engine, **kwargs).replace({pd.np.nan: None})
        except exc.ResourceClosedError:
            # Handle the case where the query is executed successfully but returns no data
            return True
        except:
            # Log and handle any other exceptions that occur during query execution
            print(f'Something went wrong while executing query. Check trace.')
            params = kwargs['params'] if 'params' in kwargs else None
            return False

        return data.where((pd.notnull(data)), None)



    def delete_data(self, table_name, and_conditions=None, or_conditions=None, in_conditions=None):
        """
        Deletes rows from a table in the database using SQLAlchemy.
        """
        # Fetch the table object
        table = self.tables.get(table_name)
        if table is None:
            raise ValueError(f"Table {table_name} not found.")
        print(f"Table found: {table}")

        # Start with a base delete statement
        stmt = delete(table)

        # Construct AND conditions
        if and_conditions:
            and_clauses = [table.c[column] == value for column, value in and_conditions.items()]
            stmt = stmt.where(and_(*and_clauses))

        # Construct OR conditions
        if or_conditions:
            or_clauses = [table.c[column] == value for column, value in or_conditions.items()]
            stmt = stmt.where(or_(*or_clauses))

        # Construct IN conditions
        if in_conditions:
            in_clauses = [table.c[column].in_(values) for column, values in in_conditions.items()]
            stmt = stmt.where(and_(*in_clauses))

        # Debugging: Print the final delete statement
        print(f"Final delete statement: {stmt}")

        # Execute the delete statement using self.engine.execute() directly
        result = self.engine.execute(stmt)

        # Commit the changes
        self.engine.commit()

        print("Delete operation successful.")
        return True
# db_config = {
# 'host': "amoppostoct19.c3qae66ke1lg.us-east-1.rds.amazonaws.com",
# 'port': "5432",
# 'user':"root",
# 'password':"AmopTeam123"
# }
db_config = {
'host': "amopuatpostgresoct23.c3qae66ke1lg.us-east-1.rds.amazonaws.com",
'port': "5432",
'user':"root",
'password':"AmopTeam123"
}


region = 'us-east-1'  

sns = boto3.client('sns', region_name=region)
cloudwatch = boto3.client('cloudwatch', region_name=region)

def send_sns_email(subject, message):
    """Send an email via SNS when memory are breached."""
    response = sns.publish(
        # TopicArn='arn:aws:sns:us-east-1:008971638399:custom-alert',
        TopicArn=os.environ['ALERT'],
        Message=message,
        Subject=subject)
    return response

def get_memory_usage():
    """Get the current memory usage in MB."""
    process = psutil.Process()
    memory_info = process.memory_info()
    print(memory_info.rss / (1024 * 1024))
    return memory_info.rss / (1024 * 1024)

def memory_sns(memory_limit,memory_used,context):
    if memory_used > 0.8 * memory_limit:
        subject = 'Lambda Memory Usage Alert'
        message = f"Warning: Memory usage has exceeded allocated limit.\n\nDetails:\nMemory Used: {memory_used} MB\nMemory Limit: {memory_limit} MB\nFunction: {context.function_name}\nRequest ID: {context.aws_request_id}"
        template_name="lambda ram exceeded"
        request_received_at=datetime.now()
        send_sns_email(subject, message)
        insert_email_audit( subject,message, request_received_at, template_name)
        print("###mail sent")
        #subject, message, template_name, request_received_at = result


def insert_email_audit(subject, message, template_name, to_emails, comments, partner_name, from_email, email_type):
    common_utils_database = DB('common_utils', **db_config)
    try:
        # Email audit
        email_audit_data = {
        "template_name": template_name,
        "email_type": email_type,
        "partner_name": partner_name,
        "email_status": "success",
        "from_email": from_email,
        "to_email": to_emails,
        "comments": comments,
        "subject": subject,
        "body": message,
        "role": "admin",
        "action": comments

    }
        common_utils_database.update_audit(email_audit_data, 'email_audit')
        print("data inserted into database.")
    except Exception as e:
        print(f"Error inserting email audit data: {e}")


# def replace_placeholders_with_table(
#     text, record_id="", template_type="", username="", data_dict=None, database=""
# ):
#     """
#     Replace placeholders with actual values from the database and include tabular data based on date range.

#     :param text: The text containing placeholders and table details in the list format.
#     :param record_id: The id to use as the WHERE condition.

#     :return: Text with placeholders replaced by actual values.
#     """

#     # Find all placeholders using regex, matches patterns like {"table":"column"}
#     #placeholders = re.findall(r'\{"(.*?)":"(.*?)"\}', text)
#     placeholders = re.findall(r'\{(.*?)\}', text)
#     print(f'placeholders--------{placeholders}')
#     common_utils_database= DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
#     try:
#         database= DB('altaworx_test', **db_config)
#     except Exception as e:
#         database= DB('altaworx_central', **db_config)
#     # Find table structure inside the text: ["users", "username, temp_password", "2024-01-01", "2025-01-01"]
#     try:
#         table_structure = re.findall(r"\[(.*?)\]", text)
#     except Exception as e:
#         print(f'Error: {e}')
#     print(f'table_structure--------------{table_structure}')
#     print("enter here", template_type)
#     # if table_structure:
#     #     print('entered if conditon of table_structure')
#     #     # Extract table name, columns, start date, and end date
#     #     for structure in table_structure:
#     #         table_data = structure.replace('"', "").split(",")
#     #         table_name = table_data[0].strip()
#     #         if table_name in [
#     #             "tenant",
#     #             "roles",
#     #             "users",
#     #             "amop_apis",
#     #             "carrier_apis",
#     #             "mapping_table",
#     #             "master_amop_apis",
#     #             "master_carrier_apis",
#     #             "master_roles",
#     #             "module",
#     #             "tenant_module",
#     #             "module_features","service_accounts"
#     #         ]:
#     #             database = common_utils_database  # Use common_utils connection
#     #         else:
#     #             database = database  # Use tenant-specific connection
#     #         columns = table_data[1].strip().split()  # Multiple columns
#     #         start_date = table_data[2].strip()
#     #         end_date = table_data[3].strip()

#     #         # Query to get data from columns in the date range (assuming there's a date column in the table)
#     #         query = f"SELECT {', '.join(columns)} FROM {table_name} WHERE created_date BETWEEN %s AND %s"
#     #         params = [start_date, end_date]
#     #         result = database.execute_query(query, params=params)

#     #         # If the result is not empty, create a table (DataFrame) from the result
#     #         if result is not None and not result.empty:
#     #             # Convert the result to a pandas DataFrame for tabular display
#     #             df = pd.DataFrame(result, columns=columns)

#     #             # Convert the DataFrame to a string format (this can be HTML or plain text)
#     #             table_string = df.to_string(index=False)

#     #             # Replace the table structure in the text with the tabular data
#     #             text = text.replace(f"[{structure}]", f"\n{table_string}\n")
#     #         else:
#     #             # Replace the table structure with an empty string if no data found
#     #             text = text.replace(f"[{structure}]", "")
#     # if template_type == "Status Template":
#     #     print('entered if conditon of Status Template')
#     #     # Handle regular placeholders like {"table":"column"}
#     #     for table_name, column_name in placeholders:
#     #         if table_name in [
#     #             "tenant",
#     #             "roles",
#     #             "users",
#     #             "amop_apis",
#     #             "carrier_apis",
#     #             "mapping_table",
#     #             "master_amop_apis",
#     #             "master_carrier_apis",
#     #             "master_roles",
#     #             "module",
#     #             "tenant_module",
#     #             "module_features","service_accounts"
#     #         ]:
#     #             database = common_utils_database  # Use common_utils connection
#     #         else:
#     #             database = database  # Use tenant-specific connection
#     #         query = f"SELECT {column_name} FROM {table_name} WHERE id = %s"
#     #         params = [record_id]
#     #         result = database.execute_query(query, params=params)

#     #         if result is not None and not result.empty:
#     #             value = result.iloc[0, 0]
#     #             placeholder = f'{{"{table_name}":"{column_name}"}}'
#     #             text = text.replace(placeholder, str(value))
#     #         else:
#     #             text = text.replace(f'{{"{table_name}":"{column_name}"}}', "")
#     # elif template_type == "User Based":
#     #     # Handle regular placeholders like {"table":"column"}
#     #     for table_name, column_name in placeholders:
#     #         if table_name in [
#     #             "tenant",
#     #             "roles",
#     #             "users",
#     #             "amop_apis",
#     #             "carrier_apis",
#     #             "mapping_table",
#     #             "master_amop_apis",
#     #             "master_carrier_apis",
#     #             "master_roles",
#     #             "module",
#     #             "tenant_module",
#     #             "module_features","service_accounts"
#     #         ]:
#     #             database = common_utils_database  # Use common_utils connection
#     #         else:
#     #             database = database  # Use tenant-specific connection
#     #         query = f"SELECT {column_name} FROM {table_name} WHERE username = %s"
#     #         params = [username]
#     #         result = database.execute_query(query, params=params)

#     #         if result is not None and not result.empty:
#     #             value = result.iloc[0, 0]
#     #             placeholder = f'{{"{table_name}":"{column_name}"}}'
#     #             text = text.replace(placeholder, str(value))
#     #         else:
#     #             text = text.replace(f'{{"{table_name}":"{column_name}"}}', '')
#     if (template_type == 'Payload Based' and data_dict is not None) or template_type == 'Payload Data':
#         print('entered if conditon of Payload Based')
#         # print(placeholders, "333333333333333")
#         for table_name, column_name in placeholders:
#             if table_name in [
#                 "tenant",
#                 "roles",
#                 "users",
#                 "amop_apis",
#                 "carrier_apis",
#                 "mapping_table",
#                 "master_amop_apis",
#                 "master_carrier_apis",
#                 "master_roles",
#                 "module",
#                 "tenant_module",
#                 "module_features","service_accounts"
#             ]:
#                 database = common_utils_database  # Use common_utils connection
#             else:
#                 database = database  # Use tenant-specific connection
#             key = column_name  # In this case, we'll assume column_name matches the keys in `data`
#             # print(key, "eeeeeeeeeeeeeeeeeeeeeee")

#             # If the key exists in data, replace the placeholder
#             if key in data_dict:
#                 value = data_dict[key]
#                 # print(value, "33333344444444444444444444443333333")
#                 # Check if the current key is 'sim_info' to format JSON correctly
#                 # If the key exists in data_dict, replace the placeholder
#                 # Check if the current key is 'sim_info' to format JSON correctly
#                 if key == 'sim_info':
#                     # Convert the JSON string to a Python object (list of dicts)
#                     try:
#                         # sim_info_list = json.loads(value)  # Parse the JSON string
#                         # # Construct the formatted string
#                         # json_string = ', '.join(
#                         #     f'Carrier: {item["carrier"]}, SIM Size: {item["SIM Size"]}, Quantity: {item["Quantity"]}'
#                         #     for item in sim_info_list
#                         # )
#                         # final_value = json_string  # Set final_value to the constructed json_string
#                         sim_info_list = json.loads(value)  # Parse the JSON string

#                         # Construct the HTML table
#                         html_table = '''
#                         <table border="1" style="border-collapse: collapse; width: 100%;">
#                             <tr>
#                                 <th style="padding: 10px; background-color: #f2f2f2;">Carrier</th>
#                                 <th style="padding: 10px; background-color: #f2f2f2;">SIM Size</th>
#                                 <th style="padding: 10px; background-color: #f2f2f2;">Quantity</th>
#                             </tr>
#                         '''

#                         # Add rows to the table
#                         for item in sim_info_list:
#                             html_table += f'''
#                             <tr>
#                                 <td style="padding: 10px;">{item['carrier']}</td>
#                                 <td style="padding: 10px;">{item['SIM Size']}</td>
#                                 <td style="padding: 10px;">{item['Quantity']}</td>
#                             </tr>
#                             '''

#                         html_table += '</table>'  # Close the table
#                         final_value = html_table  # Set final_value to the constructed HTML table
#                         # print(f'Formatted sim_info as HTML table:\n{final_value}///////////////////////')  # Debug print
#                     except json.JSONDecodeError:
#                         final_value = "Invalid JSON"
#                         # print(final_value, "mmmmmmmmmmmmmmmmm")  # Error handling for invalid JSON
#                 else:
#                     final_value = str(value)  # Convert other values to string
#                     # print(f'Final value for {key}: {final_value};;;;;;;;;;;;;;;;;;;;;;;;;')  # Debug print

#                 # Replace the placeholder in the text with the final_value
#                 placeholder = f'{{"{table_name}":"{column_name}"}}'
#                 text = text.replace(placeholder, final_value)  # Use final_value for replacement
#                 # print(text, "text, qaaaaaaaaaaaaaaaaaaaaaaaaa")

#             else:
#                 # If key does not exist, remove the placeholder
#                 text = text.replace(f'{{"{table_name}":"{column_name}"}}', '')
#     else:
#         pass

#     return text

def replace_placeholders_with_values(
    text, record_id="", template_type="", username="", data_dict=None, database="",placeholder_value=None
):
    """
    Replace placeholders with actual values from the database and include tabular data based on date range.
 
    :param text: The text containing placeholders and table details in the list format.
    :param record_id: The id to use as the WHERE condition.
 
    :return: Text with placeholders replaced by actual values.
    """
 
    # Find all placeholders using regex, matches patterns like {"table":"column"}
    # placeholders = re.findall(r'\{"(.*?)":"(.*?)"\}', text)
    placeholders = re.findall(r'\{(.*?)\}', text)
    print(f'placeholders--------{placeholders}')
    print(f'placeholder_value--------{placeholder_value}')
    for item in placeholders:
        print(f'item--------{item}')
        placeholder = f"""{{{item}}}"""
        print(f'placeholder--------{placeholder}')
        text = text.replace(placeholder, str(placeholder_value[item]))
        print(f'text--------{text}')
        if item  not in placeholder_value:
            text = text.replace(f"""{{{item}}}""", '')
    return text

def create_attachment_from_blob(blob_data, filename):
    """
    Create an attachment from blob data.

    Args:
        blob_data (bytes): Binary data of the file to attach.
        filename (str): The name of the file being attached.

    Returns:
        Attachment: The SendGrid attachment object.
    """
    encoded_file = base64.b64encode(blob_data).decode()  # Encode blob data to base64

    return Attachment(
        FileContent(encoded_file),
        FileName(filename),  # Provide the filename for the attachment
        FileType('application/octet-stream'),  # Adjust MIME type if necessary
        Disposition('attachment')  # Marks it as an attachment
    )

def prepare_email_message(from_email, to_emails, **kwargs):
    """
    Prepare the email message object.

    Args:
        from_email (str): The sender's email address.
        to_emails (list): List of recipient email addresses.
        subject (str): Email subject.
        content (str): Email content.
        cc_emails (list): List of CC email addresses.
        is_html (bool): Whether the content is HTML or plain text.

    Returns:
        Mail: The SendGrid Mail object.
    """
    subject = kwargs.get('subject')
    content = kwargs.get('content')
    cc_emails = kwargs.get('cc_emails')
    is_html = kwargs.get('is_html')

    message = Mail(
        from_email=from_email,
        to_emails=to_emails,
        subject=subject
    )
    message.add_content(Content("text/html" if is_html else "text/plain", content))
    for cc_email in cc_emails:
        message.add_cc(cc_email)
    return message

def send_email(template_name, **kwargs):
    """
    Send an email using SendGrid with retry logic.

    Args:
        template_name (str): Name of the email template.
        content (str): Email content.
        is_html (bool): Whether the content is HTML or plain text.

    Returns:
        bool: True if the email was sent successfully, False otherwise.
    """
    max_retries = 3  # Set the number of retries
    retry_delay = 5  # Delay between retries in seconds

    is_html = kwargs.get("is_html", True)
    record_id = kwargs.get("id", "")
    username = kwargs.get("username", "")
    user_mail = kwargs.get("user_mail", "")
    data_dict = kwargs.get("data_dict", None)
    placeholder_value = kwargs.get("placeholder_value", None)
    print(f'placeholder_value--------{placeholder_value}')
    subject_placeholders = kwargs.get("subject_placeholders", None)
    print(f'subject_placeholders--------{subject_placeholders}')
    comments = kwargs.get("comments", "")
    #to_email = kwargs.get("to_email", "")
    tenant_database = kwargs.get("tenant_database", 'altaworx_test')
    try:
        database = DB('altaworx_test', **db_config)
    except:
        database = DB('altaworx_test', **db_config)


    #common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    common_utils_database = DB('common_utils', **db_config)
    # Retrieve template data
    template_data_dataframe = common_utils_database.get_data(
        "email_templates", {"template_name": template_name}
    )
    email_status = template_data_dataframe.iloc[0]["email_status"]
    if email_status == False:
        response = {"flag": True, "message": "the email template status is disabled"}
        return response
    # Extract data from the template
    cc_emails = template_data_dataframe.iloc[0]["cc_mail"] or []
    partner_name = template_data_dataframe.iloc[0]["partner_name"] or ""
    template_type = template_data_dataframe.iloc[0]["template_type"] or ""
    role_based = template_data_dataframe.iloc[0]["role_based"]
    email_type = template_data_dataframe.iloc[0]["email_type"] or ""
    if role_based:
        # Fetch data from the database where tenant_name is the partner and role is the specified role
        email_dataframe = common_utils_database.get_data(
            "users",
            {"tenant_name": partner_name, "role": role_based, "is_active": True},
            ["email"],
        )
        # Extract the 'email' column and convert it to a list (if it's not already)
        email_list = email_dataframe["email"].tolist()
        # Join the list into a comma-separated string (if needed)
        to_emails = ",".join(email_list)
    else:
        if template_name == "Forgot password":
            to_emails = user_mail
        else:
            to_emails = template_data_dataframe.iloc[0]["to_mail"] or []
    if not to_emails:
        to_emails = kwargs.get("to_email", "")
    common_utils_database = DB('common_utils', **db_config)
    email_credientials = common_utils_database.get_data(
                "tenant",
                {"tenant_name": 'Altaworx', "is_active": True},
                ["from_email","sendgrid_api"],
            )
    sendgrid_email = email_credientials.iloc[0]["from_email"]
    sendgrid_api_key = email_credientials.iloc[0]["sendgrid_api"]
    subject = (
        template_data_dataframe.iloc[0]["subject"]
        or kwargs.get("subject", "")
        or "Default Subject"
    )
    # attachments = template_data_dataframe.iloc[0]['attachments'] or []  #this contains blob data
    body = template_data_dataframe.iloc[0]["body"] or kwargs.get("body", "") or ""
    body = body.replace("\n", "<br>")
    attachments = kwargs.get("attachments", None)
    try:
        body = replace_placeholders_with_values(
            text=body,
            record_id=record_id,
            template_type=template_type,
            username=username,
            data_dict=data_dict,
            database=database,
            placeholder_value = placeholder_value
        )
    except Exception as e:
        print("Error: 'Issue with the Body replacing the placeholders.'")

    # Add the external user warning at the bottom in red
    external_warning = (
        '<br><br><p style="color: red;">This message is from an external user. Be cautious when opening attachment files or links.</p>'
    )
    body += external_warning  # Append the warning at the bottom

    # Handle missing 'to_emails' or 'subject'
    if not to_emails:
        print("Error: 'to_emails' is missing.")
        return False

    if not subject:
        print("Error: 'subject' is missing.")
        return False
    
    subject=replace_placeholders_with_values(
        text=subject,
        placeholder_value=subject_placeholders
    )

    # Prepare email content
    from_email = str(sendgrid_email)
    # from_email = "notifications@amop.services"  # Verified email for SendGrid
    message = prepare_email_message(
        from_email=from_email,
        to_emails=to_emails.split(","),  # Handle multiple emails as a list
        subject=subject,
        content=body,
        cc_emails=cc_emails.split(",") if cc_emails else [],
        is_html=is_html,
    )
    # ##adding the attachments
    if isinstance(attachments, list):
        for attachment in attachments:

            if isinstance(attachment, dict) and 'blob_data' in attachment and 'filename' in attachment:
                blob_data = attachment['blob_data']
                filename = attachment['filename']

                if blob_data and filename:
                    try:
                        # Create and add the attachment
                        attachment_part = create_attachment_from_blob(blob_data, filename)
                        message.add_attachment(attachment_part)
                    except Exception as e:
                        print(f"Error adding attachment {filename}: {e}")
                        return {"flag": False, "message": f"Failed to add attachment: {filename}"}
            else:
                print(f"Unexpected attachment format: {attachment}")
    if isinstance(attachments, bytes):
        # Handle single attachment case
        try:
            # Add the attachment (blob data is already base64 encoded)
            attachment_part = Attachment(
                FileContent(attachments.decode()),  # Decode base64 bytes to string
                FileName('report.xlsx'),  # Provide the filename for the attachment
                FileType('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),  # Proper MIME type for Excel
                Disposition('attachment')
            )
            message.add_attachment(attachment_part)
        except Exception as e:
            print(f"Error adding attachment: {e}")
            return {"flag": False, "message": f"Failed to add attachment"}

    # Retry logic
    attempt = 0
    while attempt < max_retries:
        try:
            try:
                # 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   our sendgrid api key
                sendgrid_initialization = SendGridAPIClient(
                    # "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"
                    str(sendgrid_api_key)
                )
                response = sendgrid_initialization.send(message)
                print(f'email is sent successfully')
                print(f'response: {response}')
                print(f'response status code: {response.status_code}')
                print(f'response body: {response.body}')
                print(f'response headers: {response.headers}')
                insert_status = insert_email_audit(subject,body,template_name, to_emails, comments, partner_name, from_email, email_type)
                print(f"insert_status: {insert_status}")
                # print(f"Email sent! Status code: {response.status_code}")
                return to_emails, cc_emails, subject, body, from_email, partner_name
            except Exception as e:
                print(f"SendGrid error: {e}")  # Log SendGrid error message
                return {
                        "flag": False,
                        "message": "Email failed to send after retries",
                        "to_emails": to_emails,
                        "cc_emails": cc_emails,
                        "subject": subject,
                        "body": body,
                        "from_email": from_email,
                        "partner_name": partner_name}
        except Exception as error:
            attempt += 1
            print(f"Attempt {attempt}: An unexpected error occurred: {error}")
            if attempt < max_retries:
                print(f"Retrying in {retry_delay} seconds...")
                time.sleep(retry_delay)
            else:
                print("Max retries reached. Email failed to send.")
                break

    return False


# def send_email_without_template(**kwargs):
#     """
#     Send an email using SendGrid with retry logic.

#     Args:
#         template_name (str): Name of the email template.
#         content (str): Email content.
#         is_html (bool): Whether the content is HTML or plain text.

#     Returns:
#         bool: True if the email was sent successfully, False otherwise.
#     """
#     max_retries = 3  # Set the number of retries
#     retry_delay = 5  # Delay between retries in seconds

#     cc_emails = kwargs.get("cc_emails", "")
#     partner_name = kwargs.get("partner_name", "Altaworx Test")
#     template_type = kwargs.get("template_type", "AWS")
#     to_emails = kwargs.get("to_email", "")
#     subject = kwargs.get("subject", "")
#     body = kwargs.get("body", "")
#     is_html = kwargs.get("is_html", True)
#     record_id = kwargs.get("id", "")
#     username = kwargs.get("username", "")
#     user_mail = kwargs.get("user_mail", "")
#     data_dict = kwargs.get("data_dict", None)
#     attachments = kwargs.get("attachments", None)
#     invoice_links = kwargs.get("invoice_link", None)
#     placeholder_value = kwargs.get("placeholder_value", None)
#     print(f'placeholder_value--------{placeholder_value}')
#     subject_placeholders = kwargs.get("subject_placeholders", None)
#     print(f'subject_placeholders--------{subject_placeholders}')
#     comments = kwargs.get("comments", "")
#     #to_email = kwargs.get("to_email", "")
#     tenant_database = kwargs.get("tenant_database", 'altaworx_test')
#     try:
#         database = DB('altaworx_test', **db_config)
#     except:
#         database = DB('altaworx_test', **db_config)


#     #common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
#     common_utils_database = DB('common_utils', **db_config)
#     email_credientials = common_utils_database.get_data(
#                 "tenant",
#                 {"tenant_name": 'Altaworx', "is_active": True},
#                 ["from_email","sendgrid_api"],
#             )
#     sendgrid_email = email_credientials.iloc[0]["from_email"]
#     sendgrid_api_key = email_credientials.iloc[0]["sendgrid_api"]
#     external_warning = (
#         '<br><br><p style="color: red;">This message is from an external user. Be cautious when opening attachment files or links.</p>'
#     )
#     # invoice_links = ["https://billing-platform-email.s3.us-east-1.amazonaws.com/billing_platform_qa/Bill-693","https://billing-platform-email.s3.us-east-1.amazonaws.com/billing_platform_qa/Bill-651"]
#     if isinstance(invoice_links, list) and invoice_links:
#         view_links_section = "<br><br><b>Bill References:</b><ul>"
#         for link in invoice_links:
#             # Extract bill ID from the link
#             bill_id = link.rstrip("/").split("/")[-1]  # gets 'Bill-693' from the URL
#             view_links_section += f'<li><a href="{link}" target="_blank">{bill_id}</a></li>'
#         view_links_section += "</ul>"
#         body += view_links_section + external_warning
#     elif isinstance(invoice_links, str) and invoice_links:
#         # If a single string was passed
#         view_invoice_line = f'<br><br>To view or download the full invoice, click the link: <a href="{invoice_links}">View Invoice</a>'
#         body += view_invoice_line + external_warning
#     else:
#         body += external_warning

#     # Handle missing 'to_emails' or 'subject'
#     if not to_emails:
#         print("Error: 'to_emails' is missing.")
#         return False

#     if not subject:
#         print("Error: 'subject' is missing.")
#         return False
#     from_email = str(sendgrid_email)
#     # from_email = "notifications@amop.services"  # Verified email for SendGrid
#     message = prepare_email_message(
#         from_email=from_email,
#         to_emails=to_emails.split(","),  # Handle multiple emails as a list
#         subject=subject,
#         content=body,
#         cc_emails=cc_emails.split(",") if cc_emails else [],
#         is_html=is_html,
#     )
#     # ##adding the attachments
#     if isinstance(attachments, list):
#         for attachment in attachments:

#             if isinstance(attachment, dict) and 'blob_data' in attachment and 'filename' in attachment:
#                 blob_data = attachment['blob_data']
#                 filename = attachment['filename']

#                 if blob_data and filename:
#                     try:
#                         # Create and add the attachment
#                         attachment_part = create_attachment_from_blob(blob_data, filename)
#                         message.add_attachment(attachment_part)
#                     except Exception as e:
#                         print(f"Error adding attachment {filename}: {e}")
#                         return {"flag": False, "message": f"Failed to add attachment: {filename}"}
#             else:
#                 print(f"Unexpected attachment format: {attachment}")
#     if isinstance(attachments, bytes):
#         # Handle single attachment case
#         try:
#             # Add the attachment (blob data is already base64 encoded)
#             attachment_part = Attachment(
#                 FileContent(attachments.decode()),  # Decode base64 bytes to string
#                 FileName('report.xlsx'),  # Provide the filename for the attachment
#                 FileType('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),  # Proper MIME type for Excel
#                 Disposition('attachment')
#             )
#             message.add_attachment(attachment_part)
#         except Exception as e:
#             print(f"Error adding attachment: {e}")
#             return {"flag": False, "message": f"Failed to add attachment"}

#     # Retry logic
#     attempt = 0
#     while attempt < max_retries:
#         try:
#             try:
#                 # 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   our sendgrid api key
#                 sendgrid_initialization = SendGridAPIClient(
#                     # "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"
#                     str(sendgrid_api_key)
#                 )
#                 response = sendgrid_initialization.send(message)
#                 print(f'email is sent successfully')
#                 #insert_status = insert_email_audit(subject,body, to_emails, comments, partner_name, from_email, email_type='Billing Platform', template_name="Collection Email trigger")
#                 insert_status = insert_email_audit(subject, body, "Collection Email trigger", to_emails, comments, partner_name, from_email, "Billing Platform")
#                 print(f"insert_status: {insert_status}")
#                 # print(f"Email sent! Status code: {response.status_code}")
#                 return to_emails, cc_emails, subject, body, from_email, partner_name
#             except Exception as e:
#                 print(f"SendGrid error: {e}")  # Log SendGrid error message
#                 return {
#                         "flag": False,
#                         "message": "Email failed to send after retries",
#                         "to_emails": to_emails,
#                         "cc_emails": cc_emails,
#                         "subject": subject,
#                         "body": body,
#                         "from_email": from_email,
#                         "partner_name": partner_name}
#         except Exception as error:
#             attempt += 1
#             print(f"Attempt {attempt}: An unexpected error occurred: {error}")
#             if attempt < max_retries:
#                 print(f"Retrying in {retry_delay} seconds...")
#                 time.sleep(retry_delay)
#             else:
#                 print("Max retries reached. Email failed to send.")
#                 break

#     return False


def send_email_without_template(**kwargs):
    """
    Send an email using SendGrid with retry logic.

    Args:
        template_name (str): Name of the email template.
        content (str): Email content.
        is_html (bool): Whether the content is HTML or plain text.

    Returns:
        bool: True if the email was sent successfully, False otherwise.
    """
    max_retries = 3  # Set the number of retries
    retry_delay = 5  # Delay between retries in seconds

    cc_emails = kwargs.get("cc_emails", "")
    partner_name = kwargs.get("partner_name", "Altaworx Test")
    template_type = kwargs.get("template_type", "AWS")
    to_emails = kwargs.get("to_email", "")
    subject = kwargs.get("subject", "")
    body = kwargs.get("body", "")
    is_html = kwargs.get("is_html", True)
    record_id = kwargs.get("id", "")
    username = kwargs.get("username", "")
    user_mail = kwargs.get("user_mail", "")
    data_dict = kwargs.get("data_dict", None)
    attachments = kwargs.get("attachments", None)
    placeholder_value = kwargs.get("placeholder_value", None)
    print(f'placeholder_value--------{placeholder_value}')
    subject_placeholders = kwargs.get("subject_placeholders", None)
    print(f'subject_placeholders--------{subject_placeholders}')
    comments = kwargs.get("comments", "")
    invoice_links = kwargs.get("invoice_link", '')
    #to_email = kwargs.get("to_email", "")
    tenant_database = kwargs.get("tenant_database", 'altaworx_test')
    try:
        database = DB('altaworx_test', **db_config)
    except:
        database = DB('altaworx_test', **db_config)


    #common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
    common_utils_database = DB('common_utils', **db_config)
    email_credientials = common_utils_database.get_data(
                "tenant",
                {"tenant_name": 'Altaworx', "is_active": True},
                ["from_email","sendgrid_api"],
            )
    sendgrid_email = email_credientials.iloc[0]["from_email"]
    sendgrid_api_key = email_credientials.iloc[0]["sendgrid_api"]
    external_warning = (
        '<br><br><p style="color: red;">This message is from an external user. Be cautious when opening attachment files or links.</p>'
    )
    if isinstance(invoice_links, list) and invoice_links:
        view_links_section = "<br><br><b>Bill References:</b><ul>"
        for link in invoice_links:
            # Extract bill ID from the link
            bill_id = link.rstrip("/").split("/")[-1]  # gets 'Bill-693' from the URL
            view_links_section += f'<li><a href="{link}" target="_blank">{bill_id}</a></li>'
        view_links_section += "</ul>"
        body += view_links_section + external_warning
    elif isinstance(invoice_links, str) and invoice_links:
        # If a single string was passed
        view_invoice_line = f'<br><br>To view or download the full invoice, click the link: <a href="{invoice_links}">View Invoice</a>'
        body += view_invoice_line + external_warning
    else:
        body += external_warning

    # Handle missing 'to_emails' or 'subject'
    if not to_emails:
        print("Error: 'to_emails' is missing.")
        return False

    if not subject:
        print("Error: 'subject' is missing.")
        return False
    from_email = str(sendgrid_email)
    # from_email = "notifications@amop.services"  # Verified email for SendGrid
    message = prepare_email_message(
        from_email=from_email,
        to_emails=to_emails.split(","),  # Handle multiple emails as a list
        subject=subject,
        content=body,
        cc_emails=cc_emails.split(",") if cc_emails else [],
        is_html=is_html,
    )
    # ##adding the attachments
    if isinstance(attachments, list):
        for attachment in attachments:

            if isinstance(attachment, dict) and 'blob_data' in attachment and 'filename' in attachment:
                blob_data = attachment['blob_data']
                filename = attachment['filename']

                if blob_data and filename:
                    try:
                        # Create and add the attachment
                        attachment_part = create_attachment_from_blob(blob_data, filename)
                        message.add_attachment(attachment_part)
                    except Exception as e:
                        print(f"Error adding attachment {filename}: {e}")
                        return {"flag": False, "message": f"Failed to add attachment: {filename}"}
            else:
                print(f"Unexpected attachment format: {attachment}")
    if isinstance(attachments, bytes):
        # Handle single attachment case
        try:
            # Add the attachment (blob data is already base64 encoded)
            attachment_part = Attachment(
                FileContent(attachments.decode()),  # Decode base64 bytes to string
                FileName('report.xlsx'),  # Provide the filename for the attachment
                FileType('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),  # Proper MIME type for Excel
                Disposition('attachment')
            )
            message.add_attachment(attachment_part)
        except Exception as e:
            print(f"Error adding attachment: {e}")
            return {"flag": False, "message": f"Failed to add attachment"}

    # Retry logic
    attempt = 0
    while attempt < max_retries:
        try:
            try:
                # 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   our sendgrid api key
                sendgrid_initialization = SendGridAPIClient(
                    # "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"
                    str(sendgrid_api_key)
                )
                response = sendgrid_initialization.send(message)
                print(f'email is sent successfully')
                #insert_status = insert_email_audit(subject,body, to_emails, comments, partner_name, from_email)
                insert_status = insert_email_audit(subject, body, "Collection Email trigger", to_emails, comments, partner_name, from_email, "Billing Platform")
                print(f"insert_status: {insert_status}")
                # print(f"Email sent! Status code: {response.status_code}")
                return to_emails, cc_emails, subject, body, from_email, partner_name
            except Exception as e:
                print(f"SendGrid error: {e}")  # Log SendGrid error message
                return {
                        "flag": False,
                        "message": "Email failed to send after retries",
                        "to_emails": to_emails,
                        "cc_emails": cc_emails,
                        "subject": subject,
                        "body": body,
                        "from_email": from_email,
                        "partner_name": partner_name}
        except Exception as error:
            attempt += 1
            print(f"Attempt {attempt}: An unexpected error occurred: {error}")
            if attempt < max_retries:
                print(f"Retrying in {retry_delay} seconds...")
                time.sleep(retry_delay)
            else:
                print("Max retries reached. Email failed to send.")
                break

    return False
import ast
from datetime import datetime, timedelta
# def send_email_without_template(**kwargs):
#     """
#     Send an email using SendGrid with retry logic.

#     Args:
#         template_name (str): Name of the email template.
#         content (str): Email content.
#         is_html (bool): Whether the content is HTML or plain text.

#     Returns:
#         bool: True if the email was sent successfully, False otherwise.
#     """
#     max_retries = 3  # Set the number of retries
#     retry_delay = 5  # Delay between retries in seconds

#     cc_emails = kwargs.get("cc_emails", "")
#     partner_name = kwargs.get("partner_name", "Altaworx Test")
#     template_type = kwargs.get("template_type", "AWS")
#     to_emails = kwargs.get("to_email", "")
#     subject = kwargs.get("subject", "")
#     body = kwargs.get("body", "")
#     is_html = kwargs.get("is_html", True)
#     record_id = kwargs.get("id", "")
#     username = kwargs.get("username", "")
#     user_mail = kwargs.get("user_mail", "")
#     data_dict = kwargs.get("data_dict", None)
#     attachments = kwargs.get("attachments", None)
#     placeholder_value = kwargs.get("placeholder_value", None)
#     print(f'placeholder_value--------{placeholder_value}')
#     subject_placeholders = kwargs.get("subject_placeholders", None)
#     print(f'subject_placeholders--------{subject_placeholders}')
#     comments = kwargs.get("comments", "")
#     invoice_links = kwargs.get("invoice_link", '')
#     #to_email = kwargs.get("to_email", "")
#     tenant_database = kwargs.get("tenant_database", 'altaworx_test')
#     try:
#         database = DB('altaworx_test', **db_config)
#     except:
#         database = DB('altaworx_test', **db_config)


#     #common_utils_database = DB(os.environ["COMMON_UTILS_DATABASE"], **db_config)
#     common_utils_database = DB('common_utils', **db_config)
#     email_credientials = common_utils_database.get_data(
#                 "tenant",
#                 {"tenant_name": 'Altaworx', "is_active": True},
#                 ["from_email","sendgrid_api"],
#             )
#     sendgrid_email = email_credientials.iloc[0]["from_email"]
#     sendgrid_api_key = email_credientials.iloc[0]["sendgrid_api"]
#     external_warning = (
#         '<br><br><p style="color: red;">This message is from an external user. Be cautious when opening attachment files or links.</p>'
#     )
#     if isinstance(invoice_links, list) and invoice_links:
#         print('##It is a list')
#         view_links_section = "<br><br><b>Bill References:</b><ul>"
#         for link in invoice_links:
#             # Extract bill ID from the link
#             bill_id = link.rstrip("/").split("/")[-1]  # gets 'Bill-693' from the URL
#             view_links_section += f'<li><a href="{link}" target="_blank">{bill_id}</a></li>'
#         view_links_section += "</ul>"
#         body += view_links_section + external_warning
#     elif isinstance(invoice_links, str) and invoice_links:
#         print('##It is a string')
#         # If a single string was passed
#         view_invoice_line = f'<br><br>To view or download the full invoice, click the link: <a href="{invoice_links}">View Invoice</a>'
#         body += view_invoice_line + external_warning
#     else:
#         print('####Not a list or string')
#         body += external_warning

#     # Handle missing 'to_emails' or 'subject'
#     if not to_emails:
#         print("Error: 'to_emails' is missing.")
#         return False

#     if not subject:
#         print("Error: 'subject' is missing.")
#         return False
#     from_email = str(sendgrid_email)
#     # from_email = "notifications@amop.services"  # Verified email for SendGrid
#     message = prepare_email_message(
#         from_email=from_email,
#         to_emails=to_emails.split(","),  # Handle multiple emails as a list
#         subject=subject,
#         content=body,
#         cc_emails=cc_emails.split(",") if cc_emails else [],
#         is_html=is_html,
#     )
#     # ##adding the attachments
#     if isinstance(attachments, list):
#         for attachment in attachments:

#             if isinstance(attachment, dict) and 'blob_data' in attachment and 'filename' in attachment:
#                 blob_data = attachment['blob_data']
#                 filename = attachment['filename']

#                 if blob_data and filename:
#                     try:
#                         # Create and add the attachment
#                         attachment_part = create_attachment_from_blob(blob_data, filename)
#                         message.add_attachment(attachment_part)
#                     except Exception as e:
#                         print(f"Error adding attachment {filename}: {e}")
#                         return {"flag": False, "message": f"Failed to add attachment: {filename}"}
#             else:
#                 print(f"Unexpected attachment format: {attachment}")
#     if isinstance(attachments, bytes):
#         # Handle single attachment case
#         try:
#             # Add the attachment (blob data is already base64 encoded)
#             attachment_part = Attachment(
#                 FileContent(attachments.decode()),  # Decode base64 bytes to string
#                 FileName('report.xlsx'),  # Provide the filename for the attachment
#                 FileType('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),  # Proper MIME type for Excel
#                 Disposition('attachment')
#             )
#             message.add_attachment(attachment_part)
#         except Exception as e:
#             print(f"Error adding attachment: {e}")
#             return {"flag": False, "message": f"Failed to add attachment"}

#     # Retry logic
#     attempt = 0
#     while attempt < max_retries:
#         try:
#             try:
#                 # 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   our sendgrid api key
#                 sendgrid_initialization = SendGridAPIClient(
#                     # "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"
#                     str(sendgrid_api_key)
#                 )
#                 response = sendgrid_initialization.send(message)
#                 print(f'email is sent successfully')
#                 #insert_status = insert_email_audit(subject,body, to_emails, comments, partner_name, from_email)
#                 insert_status = insert_email_audit(subject, body, "Collection Email trigger", to_emails, comments, partner_name, from_email, "Billing Platform")
#                 print(f"insert_status: {insert_status}")
#                 # print(f"Email sent! Status code: {response.status_code}")
#                 return to_emails, cc_emails, subject, body, from_email, partner_name
#             except Exception as e:
#                 print(f"SendGrid error: {e}")  # Log SendGrid error message
#                 return {
#                         "flag": False,
#                         "message": "Email failed to send after retries",
#                         "to_emails": to_emails,
#                         "cc_emails": cc_emails,
#                         "subject": subject,
#                         "body": body,
#                         "from_email": from_email,
#                         "partner_name": partner_name}
#         except Exception as error:
#             attempt += 1
#             print(f"Attempt {attempt}: An unexpected error occurred: {error}")
#             if attempt < max_retries:
#                 print(f"Retrying in {retry_delay} seconds...")
#                 time.sleep(retry_delay)
#             else:
#                 print("Max retries reached. Email failed to send.")
#                 break

#     return False

# send_email_without_template(
# cc_emails="srikanth.rekkala@algonox.com",
# to_email="srikanth.rekkala@algonox.com",
# subject="Hi",
# body="<p>srikanth<p>",
# is_html=True,
# comments="Collection Email trigger"
# )


def send_email_without_template(**kwargs):
    """
    Send an email using SendGrid with retry logic.
    
    Returns:
        dict: Response containing success flag and message
    """
    import time
    from sendgrid import SendGridAPIClient
    from sendgrid.helpers.mail import Mail
    
    max_retries = 3
    retry_delay = 5

    # Extract parameters
    cc_emails = kwargs.get("cc_emails", "")
    partner_name = kwargs.get("partner_name", "Altaworx Test")
    to_email = kwargs.get("to_email", "")
    subject = kwargs.get("subject", "")
    body = kwargs.get("body", "")
    is_html = kwargs.get("is_html", True)
    comments = kwargs.get("comments", "")
    invoice_links = kwargs.get("invoice_link", '')
    
    # Debug info
    print(f"Debug - to_email: {to_email}")
    print(f"Debug - cc_emails: {cc_emails}")
    print(f"Debug - invoice_links: {invoice_links}")
    
    # Parameter validation
    if not to_email:
        print("Error: 'to_email' is missing.")
        return {"flag": False, "message": "Missing recipient email address"}

    if not subject:
        print("Error: 'subject' is missing.")
        return {"flag": False, "message": "Missing email subject"}
    
    try:
        # Database setup
        database = DB('altaworx_test', **db_config)
        common_utils_database = DB('common_utils', **db_config)
        
        # Get email credentials
        email_credientials = common_utils_database.get_data(
            "tenant",
            {"tenant_name": 'Altaworx', "is_active": True},
            ["from_email","sendgrid_api"],
        )
        
        sendgrid_email = email_credientials.iloc[0]["from_email"]
        sendgrid_api_key = email_credientials.iloc[0]["sendgrid_api"]
        
        # Process email content
        final_body = body
        
        # External warning message
        external_warning = (
            '<br><br><p style="color: red;">This message is from an external user. Be cautious when opening attachment files or links.</p>'
        )
        
        # Handle invoice links
        if isinstance(invoice_links, list) and invoice_links:
            print('##It is a list')
            view_links_section = "<br><br><b>Bill References:</b><ul>"
            for link in invoice_links:
                bill_id = link.rstrip("/").split("/")[-1]
                view_links_section += f'<li><a href="{link}" target="_blank">{bill_id}</a></li>'
            view_links_section += "</ul>"
            final_body += view_links_section + external_warning
        elif isinstance(invoice_links, str) and invoice_links:
            print('##It is a string')
            view_invoice_line = f'<br><br>To view or download the full invoice, click the link: <a href="{invoice_links}">View Invoice</a>'
            final_body += view_invoice_line + external_warning
        else:
            print('####Not a list or string')
            final_body += external_warning
        
        # Create Mail object directly - similar to the successful test
        message = Mail(
            from_email=sendgrid_email,
            to_emails=to_email,
            subject=subject,
            html_content=final_body if is_html else None,
            plain_text_content=None if is_html else final_body
        )
        
        # Add CC recipients if present
        if cc_emails:
            for cc_email in cc_emails.split(','):
                if cc_email.strip():
                    message.add_cc(cc_email.strip())
        
        # Retry logic
        attempt = 0
        while attempt < max_retries:
            try:
                sg = SendGridAPIClient(sendgrid_api_key)
                response = sg.send(message)
                print(f"Email sent successfully! Status code: {response.status_code}")
                
                # Log the successful email
                insert_status = insert_email_audit(
                    subject, final_body, "Collection Email trigger", 
                    to_email, comments, partner_name, sendgrid_email, "Billing Platform"
                )
                
                return {"flag": True, "message": "Email sent successfully"}
                
            except Exception as e:
                attempt += 1
                print(f"Attempt {attempt}: SendGrid error: {str(e)}")
                
                if attempt < max_retries:
                    print(f"Retrying in {retry_delay} seconds...")
                    time.sleep(retry_delay)
                else:
                    error_details = str(e)
                    print(f"Max retries reached. Email failed to send: {error_details}")
                    return {"flag": False, "message": f"Email failed to send: {error_details}"}
    
    except Exception as error:
        print(f"Unexpected error in send_email_without_template: {str(error)}")
        return {"flag": False, "message": f"Email system error: {str(error)}"}