from common_utils.email_trigger import send_email

import logging

class ColorFormatter(logging.Formatter):
    COLORS = {
        "DEBUG": "\033[94m",   # Blue
        "INFO": "\033[92m",    # Green
        "WARNING": "\033[93m", # Yellow
        "ERROR": "\033[91m",   # Red
        "CRITICAL": "\033[95m" # Purple
    }
    RESET = "\033[0m"

    def format(self, record):
        color = self.COLORS.get(record.levelname, self.RESET)
        message = super().format(record)
        return f"{color}{message}{self.RESET}"

# Create logger
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

# Remove old handlers (important in Jupyter)
logger.handlers.clear()

# Add new handler
handler = logging.StreamHandler()
handler.setFormatter(ColorFormatter("%(levelname)s: %(message)s"))
logger.addHandler(handler)

try:
    result = send_email(
        template_name="Carrier Sync",
        username="emil_tester",
        user_mail="kumar.anil@ALGONOX.COM",
        is_html=True,
        tenant_name ='Verizon-Kore Wireless'
    )
    logging.info(f'## bulk_upload_users_for_subtenant Send_mail True')
except Exception as e:
    logging.info(f"### bulk_upload_users_for_subtenant send_email failed for {user_update['username']}: {e}")
    result = {"flag": False, "message": str(e)}

if result:
    print("Email sent successfully.")
else:
    print("Failed to send email.")

    
    
    