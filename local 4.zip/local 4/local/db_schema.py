from sqlalchemy import create_engine, MetaData
import json
def reflect_and_save_schema(engine_url, output_file):
    # Create an engine and metadata object
    engine = create_engine(engine_url)
    metadata = MetaData()
    # Reflect the database schema
    metadata.reflect(bind=engine)
    # Prepare schema definition
    schema = {}
    for table in metadata.sorted_tables:
        columns = []
        for column in table.columns:
            columns.append({
                'name': column.name,
                'type': str(column.type),
                'nullable': column.nullable,
                'primary_key': column.primary_key,
            })
        schema[table.name] = columns
    # Save schema to a file
    with open(output_file, 'w') as f:
        json.dump(schema, f, indent=4)
# Example usage
#UAT # 
#billing platform
# reflect_and_save_schema('postgresql://root:AmopTeam123@amopuatpostgresoct23.c3qae66ke1lg.us-east-1.rds.amazonaws.com:5432/billing_platform', 'billing_platform_UAT.json')

# Beta
# reflect_and_save_schema('postgresql://root:AmopTeam123@amopuatpostgresoct23.c3qae66ke1lg.us-east-1.rds.amazonaws.com:5432/altaworx_central_billing_platform_beta', 'altaworx_central_billing_platform_beta.json')
# reflect_and_save_schema('postgresql://root:AmopTeam123@amopuatpostgresoct23.c3qae66ke1lg.us-east-1.rds.amazonaws.com:5432/altaworx_go_tech_billing_platform_beta', 'altaworx_go_tech_billing_platform_beta.json')
# reflect_and_save_schema('postgresql://root:AmopTeam123@amopuatpostgresoct23.c3qae66ke1lg.us-east-1.rds.amazonaws.com:5432/spectrotel_billing_platform_beta', 'spectrotel_billing_platform_beta.json')
#common_utils
# reflect_and_save_schema('postgresql://root:AmopTeam123@amopuatpostgresoct23.c3qae66ke1lg.us-east-1.rds.amazonaws.com:5432/common_utils', 'common_utils_UAT_new.json')
#QA
# reflect_and_save_schema('postgresql://root:AmopTeam123@amoppostoct19.c3qae66ke1lg.us-east-1.rds.amazonaws.com:5432/billing_platform', 'billing_platform_QA.json')

# Prod
reflect_and_save_schema('postgresql://root:AmopTeam123@amoppostgresdb.c3qae66ke1lg.us-east-1.rds.amazonaws.com:5432/altaworx_central_billing_platform', 'altaworx_central_billing_platform_prod.json')
reflect_and_save_schema('postgresql://root:AmopTeam123@amoppostgresdb.c3qae66ke1lg.us-east-1.rds.amazonaws.com:5432/altaworx_go_tech_billing_platform', 'altaworx_go_tech_billing_platform_prod.json')
reflect_and_save_schema('postgresql://root:AmopTeam123@amoppostgresdb.c3qae66ke1lg.us-east-1.rds.amazonaws.com:5432/spectrotel_billing_platform', 'spectrotel_billing_platform_prod.json')
reflect_and_save_schema('postgresql://root:AmopTeam123@amoppostgresdb.c3qae66ke1lg.us-east-1.rds.amazonaws.com:5432/billing_platform_common_utils', 'billing_platform_common_utils_prod.json')