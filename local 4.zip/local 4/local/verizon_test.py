from common_utils.email_trigger import send_email
"""
@Author1 : Phaneendra.Y
@Author2 :Ajay
@Author3 :Puja
Created Date: 05-09-2025
"""

# Importing the necessary Libraries
import os
import json
import time
import threading
import boto3 # type: ignore
import pandas as pd # type: ignore
from datetime import datetime
import numpy as np
import base64
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
from concurrent.futures import ThreadPoolExecutor, as_completed
# from config.carrier_config_manager import CarrierConfigManager

import logging

class ColorFormatter(logging.Formatter):
    COLORS = {
        "DEBUG": "\033[94m",   # Blue
        "INFO": "\033[92m",    # Green
        "WARNING": "\033[93m", # Yellow
        "ERROR": "\033[91m",   # Red
        "CRITICAL": "\033[95m" # Purple
    }
    RESET = "\033[0m"

    def format(self, record):
        color = self.COLORS.get(record.levelname, self.RESET)
        message = super().format(record)
        return f"{color}{message}{self.RESET}"

# Create logger
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

# Remove old handlers (important in Jupyter)
logger.handlers.clear()

# Add new handler
handler = logging.StreamHandler()
handler.setFormatter(ColorFormatter("%(levelname)s: %(message)s"))
logger.addHandler(handler)

import requests


from common_utils.db_utils import DB
db_config = {
    'host': "amopuatpostgresoct23.c3qae66ke1lg.us-east-1.rds.amazonaws.com",
    'port': "5432",
    'user':"root",
    'password':"AmopTeam123"
}
 
#amop_Central_database = DB('altaworx_central', **db_config)
common_utils_database = DB('common_utils', **db_config)
tenant_database = DB('altaworx_central_beta', **db_config)


# def get_verizon_token_details(app_id,app_secret,username_value,password_value):
#     """
#     Obtain an OAuth access token and session token from Verizon  API.
 
#     Args:
#         app_id (str): The client ID (application ID) for Verizon API.
#         app_secret (str): The client secret associated with the app_id.
 
#     Returns:
#         tuple[str, str]: A tuple containing the access token and the session token.
 
#     Raises:
#         requests.exceptions.HTTPError: If any of the HTTP requests fail.
#         Exception: For unexpected decoding or response format issues.
#     """
#     main_url = "https://thingspace.verizon.com"
#     client_id = app_id
#     client_secret = app_secret
#     username = username_value
#     password_encoded = password_value
#     logging.info(f"### get_verizon_token_details: with credentials {client_id}, {username},")
#     # Decode password from base64
#     password = base64.b64decode(password_encoded).decode('utf-8')
 
#     token_url = f"{main_url}/api/ts/v1/oauth2/token"
#     session_url = f"{main_url}/api/m2m/v1/session/login"
 
#     # Prepare Basic Auth header
#     auth_header = base64.b64encode(f"{client_id}:{client_secret}".encode()).decode()
 
#     # Get OAuth access token
#     token_response = requests.post(
#         token_url,
#         headers={
#             "Authorization": f"Basic {auth_header}",
#             "Accept": "application/json",
#         },
#         data={"grant_type": "client_credentials"},
#     )
#     token_response.raise_for_status()
#     access_token_id = token_response.json().get("access_token")
#     logging.info(f"### get_verizon_token_details Access token: {access_token_id}")
 
#     # Get session token
#     for attempt in range(3):  # retry 3 times
#         try:
#             session_response = requests.post(
#                 session_url,
#                 headers={
#                     "Authorization": f"Bearer {access_token_id}",
#                     "Accept": "application/json",
#                     "Content-Type": "application/json"
#                 },
#                 json={"username": username, "password": password},
#                 timeout=30
#             )

#             if session_response.status_code == 200:
#                 break

#             logger.warning(
#                 f"Session login failed (attempt {attempt+1}): {session_response.status_code}"
#             )

#         except requests.exceptions.RequestException as e:
#             logger.error(f"Session login error (attempt {attempt+1}): {str(e)}")

#         time.sleep(2)

#     if session_response.status_code != 200:
#         logger.error(f"Session login failed after retries: {session_response.text}")
#         session_response.raise_for_status()
        
    
#     session_token = session_response.json().get("sessionToken")
#     logging.info(f"## get_verizon_token_details Session token: {session_token}")
#     # return access_token_id,session_token
#     return {
#             "access_token": access_token_id,
#             "session_token": session_token
#         }

def get_verizon_token_details(app_id, app_secret, username_value, password_value):

    main_url = "https://thingspace.verizon.com"
    client_id = app_id
    client_secret = app_secret
    username = username_value
    password_encoded = password_value

    logging.info(f"### get_verizon_token_details: client_id={client_id}, username={username}")

    # Decode password
    password = base64.b64decode(password_encoded).decode("utf-8")

    token_url = f"{main_url}/api/ts/v1/oauth2/token"
    session_url = f"{main_url}/api/m2m/v1/session/login"

    # Prepare Basic Auth header
    auth_header = base64.b64encode(f"{client_id}:{client_secret}".encode()).decode()

    # Get OAuth token
    token_response = requests.post(
        token_url,
        headers={
            "Authorization": f"Basic {auth_header}",
            "Accept": "application/json",
        },
        data={"grant_type": "client_credentials"},
        timeout=30
    )

    token_response.raise_for_status()

    access_token_id = token_response.json().get("access_token")

    logging.info(f"Access token received for username={username}")

    # Retry session login
    session_response = None

    for attempt in range(3):

        try:

            session_response = requests.post(
                session_url,
                headers={
                    "Authorization": f"Bearer {access_token_id}",
                    "Accept": "application/json",
                    "Content-Type": "application/json"
                },
                json={
                    "username": username,
                    "password": password
                },
                timeout=30
            )

            if session_response.status_code == 200:
                break

            logger.warning(
                f"Session login failed attempt={attempt+1} username={username} status={session_response.status_code}"
            )

        except requests.exceptions.RequestException as e:

            logger.error(
                f"Session login error attempt={attempt+1} username={username} error={str(e)}"
            )

        time.sleep(2)

    if not session_response or session_response.status_code != 200:

        logger.error(
            f"Session login failed after retries username={username}"
        )

        session_response.raise_for_status()

    session_token = session_response.json().get("sessionToken")

    logging.info(f"Session token received for username={username}")

    return {
        "access_token": access_token_id,
        "session_token": session_token
    }

app_id = "RvxMbfpulNVNBU2FpSnBZ2QSai8a"
app_secrete = "5Con_pshpyYfjZ1PMCuBePGS7fQa"
username = "ldaniel80"
password = "OG81a1dnOFhNMDh6SkN0biQq"

# res = get_verizon_token_details(app_id, app_secrete, username, password)
# access_token, session_token = res
# print("Access Token:", res[0])
# print("Session Token:", res[1])








############################################################################################################################################



# -------------------------------------------------
# Fetch Verizon Devices (Logging Version)
# -------------------------------------------------
def fetch_all_verizon_devices(access_token, vz_token, account_number):    

    url = "https://thingspace.verizon.com/api/m2m/v1/devices/actions/list"

    headers = {
        "Accept": "application/json",
        "Content-Type": "application/json",
        "VZ-M2M-Token": vz_token,
        "Authorization": f"Bearer {access_token}"
    }

    largest_device_id_seen = 0
    all_devices = []
    page_number = 0

    logger.info("Starting device fetch")

    while True:
        page_number += 1
        payload = {"largestDeviceIdSeen": largest_device_id_seen , "accountName": account_number}

        logger.info(
            f"Calling devices API | Page={page_number} | "
            f"largestDeviceIdSeen={largest_device_id_seen}"
        )

        max_retries = 3
        attempt = 0

        while attempt < max_retries:
            response = requests.post(url, headers=headers, json=payload)

            if response.status_code == 429:
                wait_time = 2 ** attempt
                logger.warning(
                    f"Rate limit hit on page {page_number}. "
                    f"Retrying in {wait_time}s"
                )
                time.sleep(wait_time)
                attempt += 1
                continue

            break

        if response.status_code != 200:
            logger.error(
                f"Device API failed | Page={page_number} | "
                f"Status={response.status_code} | Response={response.text}"
            )
            break

        data = response.json()
        devices = data.get("devices", [])

        logger.info(
            f"Page {page_number} fetched | Devices received={len(devices)}"
        )

        if not devices:
            break

        for device in devices:

            record = {
                # ---- DB Column Names ----
                "iccid": None,
                "msisdn": None,
                "imsi": None,
                "imei": None,
                "account_name": device.get("accountName"),
                "sim_status": None,
                "plan_name": None,
                "billing_cycle_end_date": device.get("billingCycleEndDate"),
                "ip_address": device.get("ipAddress"),
                "last_activated_date": device.get("lastActivationDate"),
                "service_provider_name": "verizon",
                "service_provider_id": 5,
                "last_activation_by": device.get("lastActivationBy"),
                "created_by" :"verizon_carrier_sync",
                "modified_by" : "verizon_carrier_sync"
            }

            # Extract deviceIds
            for d in device.get("deviceIds", []):
                if d.get("kind") == "iccId":
                    record["iccid"] = d.get("id")
                elif d.get("kind") == "msisdn":
                    record["msisdn"] = d.get("id")
                elif d.get("kind") == "imsi":
                    record["imsi"] = d.get("id")
                elif d.get("kind") == "imei":
                    record["imei"] = d.get("id")

            # Carrier info
            carrier_info = device.get("carrierInformations", [{}])[0]
            record["sim_status"] = carrier_info.get("state")
            record["plan_name"] = carrier_info.get("servicePlan")
            
            # extendedAttributes extraction
            for attr in device.get("extendedAttributes", []):
                if attr.get("key") == "DeviceId":
                    record["device_id"] = attr.get("value")

                elif attr.get("key") == "AccountNumber":
                    record["account_number"] = attr.get("value")

            all_devices.append(record)

        # Pagination logic
        last_device = devices[-1]
        for attr in last_device.get("extendedAttributes", []):
            if attr.get("key") == "DeviceId":
                largest_device_id_seen = int(attr.get("value"))
                break

        if not data.get("hasMoreData", False):
            break

    logger.info(f"Device fetch completed | Total devices={len(all_devices)}")

    return all_devices


import pandas as pd
from concurrent.futures import ThreadPoolExecutor, as_completed
# -------------------------------------------------
# Process One Account
# -------------------------------------------------
def process_single_account(account):
    service_provider_id = account["service_provider_id"]
    service_provider_name = account["service_provider_name"]

    logger.info(
        f"Processing account | "
        f"ID={service_provider_id} | "
        f"Name={service_provider_name}"
    )

    try:

        # Get tokens
        token_data = get_verizon_token_details(
            account["oauth2_client_id"],
            account["oauth2_client_secret"],
            account["username"],
            account["password"]
        )

        access_token = token_data["access_token"]
        session_token = token_data["session_token"]

        account_results = {}

        account_numbers = account.get("account_numbers", [])

        logger.info(
            f"Starting parallel fetch for account numbers | "
            f"Total={len(account_numbers)}"
        )

        # -----------------------------------------
        # Parallel Account Processing
        # -----------------------------------------
        with ThreadPoolExecutor(max_workers=5) as executor:

            future_to_account = {
                executor.submit(
                    fetch_all_verizon_devices,
                    access_token,
                    session_token,
                    account_number
                ): account_number
                for account_number in account_numbers
            }

            for future in as_completed(future_to_account):

                account_number = future_to_account[future]

                try:
                    devices = future.result()

                    logger.info(
                        f"Fetched devices for service provider : {service_provider_name} | AccountNumber={account_number} | "
                        f"Devices={len(devices)}"
                    )

                    # -----------------------------------------
                    # Convert to DataFrame
                    # -----------------------------------------
                    df = pd.DataFrame(devices)

                    # if not df.empty and "iccid" in df.columns:

                    #     # Remove duplicate ICCIDs
                    #     df_distinct = df.drop_duplicates(subset=["iccid"])

                    #     distinct_devices = df_distinct.to_dict(orient="records")

                    #     distinct_iccid_count = df_distinct["iccid"].nunique()

                    #     # INSERT INTO STAGING + AUDIT TABLES
                    #     insert_verizon_batches(
                    #         distinct_devices,
                    #         tenant_database,
                    #         1
                    #     )
                    # df = pd.DataFrame(devices)

                    if not df.empty and "iccid" in df.columns:

                        # -----------------------------
                        # Find duplicate ICCIDs
                        # -----------------------------
                        duplicate_rows = df[df.duplicated(subset=["iccid"], keep=False)]

                        if not duplicate_rows.empty:
                            logger.warning(
                                f"Duplicate ICCIDs found | AccountNumber={account_number} | "
                                f"Count={len(duplicate_rows)}"
                            )

                            # Print full duplicate records
                            logger.warning(f"\nDuplicate Records:\n{duplicate_rows.to_string()}")

                        # -----------------------------
                        # Remove duplicates
                        # -----------------------------
                        df_distinct = df.drop_duplicates(subset=["iccid"])

                        distinct_devices = df_distinct.to_dict(orient="records")

                        distinct_iccid_count = df_distinct["iccid"].nunique()

                        # # INSERT INTO STAGING + AUDIT TABLES
                        # insert_verizon_batches(
                        #     distinct_devices,
                        #     tenant_database,
                        #     1
                        # )

                    else:
                        distinct_devices = []
                        distinct_iccid_count = 0

                    account_results[account_number] = {
                        "device_count": len(devices),
                        "distinct_iccid_count": distinct_iccid_count,
                        "devices": distinct_devices
                    }

                    logger.info(
                        f"Account processed | AccountNumber={account_number} | "
                        f"Devices={len(devices)} | "
                        f"Distinct ICCIDs={distinct_iccid_count}"
                    )

                except Exception as e:
                    logger.exception(
                        f"Account number processing failed | "
                        f"AccountNumber={account_number} | Error={str(e)}"
                    )

        logger.info(
            f"Completed service provider | "
            f"ID={service_provider_id} | "
            f"AccountsProcessed={len(account_results)}"
        )

        return {
            "service_provider_id": service_provider_id,
            "service_provider_name": service_provider_name,
            "accounts": account_results
        }

    except Exception as e:
        logger.exception(
            f"Account failed | ID={service_provider_id} | "
            f"Error={str(e)}"
        )
        return None
    
    
    
from datetime import datetime
import threading

insert_lock = threading.Lock()

def insert_verizon_batches(devices, tenant_database, sync_run_count):

    BATCH_SIZE = 1000
    triggered_by = "verizon"
    now = datetime.utcnow()

    batch_records = []
    audit_batch_records = []

    def insert_batch():
        """Insert current batch into staging and audit tables."""
        if not batch_records:
            return

        try:
            with insert_lock:
                tenant_database.insert_data(
                    batch_records,
                    "verizon_carrier_sync_staging"
                )

                tenant_database.insert_data(
                    audit_batch_records,
                    "verizon_carrier_sync_staging_audit"
                )

            logger.info(f"Inserted batch size = {len(batch_records)}")

        except Exception as e:
            logger.exception(f"Batch insert failed | Error={str(e)}")

        finally:
            batch_records.clear()
            audit_batch_records.clear()

    for record in devices:

        if not record:
            continue

        # staging record
        batch_records.append(record)

        # audit record
        audit_record = record.copy()
        audit_record["sync_run_count"] = sync_run_count
        audit_record["sync_date"] = now
        audit_record["triggered_by"] = triggered_by

        audit_batch_records.append(audit_record)

        # Insert when batch size reached
        if len(batch_records) >= BATCH_SIZE:
            insert_batch()

    # Insert remaining records
    insert_batch()    



# -------------------------------------------------
# Parallel Runner
# -------------------------------------------------
def run_parallel_device_sync(accounts, max_workers=5):
    logger.info(f"Starting parallel Verizon sync | Total accounts={len(accounts)}")

    results = []
    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [
            executor.submit(process_single_account, acc)
            for acc in accounts
        ]

        for future in as_completed(futures):
            result = future.result()
            if result:
                results.append(result)

    logger.info(
        f"Parallel sync completed | "
        f"Successful accounts={len(results)}"
    )

    return results


# -------------------------------------------------
# Execute
# # -------------------------------------------------
SERVICE_PROVIDER_ACCOUNTS = [

{
    "service_provider_id": 34,
    "service_provider_name": "VZWCR 1628-LFW",
    "username": "Creefapi1628",
    "password": "YWx3eDI1JDIwdHVyblE=",
    "oauth2_client_id": "c04009ad-764f-4e49-9e95-0000c50b51e7",
    "oauth2_client_secret": "f7a37c2a-caf0-44c4-bd06-81fd1b91231f",
    "account_numbers": [
        "0842441628-00001",
        "0942836718-00001"
    ]
},

{
    "service_provider_id": 20,
    "service_provider_name": "VZWCR 8280-CRBEAST",
    "username": "creefapi8280",
    "password": "YWx3eDI1JDIwdHVyblE=",
    "oauth2_client_id": "c04009ad-764f-4e49-9e95-0000c50b51e7",
    "oauth2_client_secret": "f7a37c2a-caf0-44c4-bd06-81fd1b91231f",
    "account_numbers": [
        "0942108280-00001",
        "0442837323-00001"
    ]
},

{
    "service_provider_id": 5,
    "service_provider_name": "Verizon - ThingSpace IoT",
    "username": "ldaniel80",
    "password": "OG81a1dnOFhNMDh6SkN0biQq",
    "oauth2_client_id": "RvxMbfpulNVNBU2FpSnBZ2QSai8a",
    "oauth2_client_secret": "5Con_pshpyYfjZ1PMCuBePGS7fQa",
    "account_numbers": [
        "0242838169-00001",
        "0242390116-00001"
    ]
},

{
    "service_provider_id": 12,
    "service_provider_name": "Verizon - ThingSpace PN",
    "username": "AMOPAPI4787",
    "password": "U3FucFE0MmhNYkc5Y0Ih",
    "oauth2_client_id": "RvxMbfpulNVNBU2FpSnBZ2QSai8a",
    "oauth2_client_secret": "5Con_pshpyYfjZ1PMCuBePGS7fQa",
    "account_numbers": [
        "0742509040-00001"
    ]
},

{
    "service_provider_id": 31,
    "service_provider_name": "VZWCR 6242-CRMBBFWA5G",
    "username": "Creefapi6242",
    "password": "YWx3eDI1JDIwdHVyblE=",
    "oauth2_client_id": "c04009ad-764f-4e49-9e95-0000c50b51e7",
    "oauth2_client_secret": "f7a37c2a-caf0-44c4-bd06-81fd1b91231f",
    "account_numbers": [
        "0442656242-00001"
    ]
},

{
    "service_provider_id": 32,
    "service_provider_name": "VZWCR 1256-cyberree",
    "username": "creefapi1256",
    "password": "YWx3eDI1JDIwdHVyblE=",
    "oauth2_client_id": "c04009ad-764f-4e49-9e95-0000c50b51e7",
    "oauth2_client_secret": "f7a37c2a-caf0-44c4-bd06-81fd1b91231f",
    "account_numbers": [
        "0442091256-00001",
        "0742837094-00001"
    ]
},

{
    "service_provider_id": 33,
    "service_provider_name": "VZWCR 2215-SO01",
    "username": "Creefapi2215a",
    "password": "YWx3eDI1JDIwdHVyblE=",
    "oauth2_client_id": "c04009ad-764f-4e49-9e95-0000c50b51e7",
    "oauth2_client_secret": "f7a37c2a-caf0-44c4-bd06-81fd1b91231f",
    "account_numbers": [
        "0442012215-00001",
        "0542837860-00001"
    ]
},

{
    "service_provider_id": 35,
    "service_provider_name": "VZWCR 5488-CRFWAFED5G",
    "username": "Creefapi5488",
    "password": "YWx3eDI1JDIwdHVyblE=",
    "oauth2_client_id": "c04009ad-764f-4e49-9e95-0000c50b51e7",
    "oauth2_client_secret": "f7a37c2a-caf0-44c4-bd06-81fd1b91231f",
    "account_numbers": [
        "0542695488-00001"
    ]
},

{
    "service_provider_id": 36,
    "service_provider_name": "VZWCR 8593-cybersol",
    "username": "creefapi8593",
    "password": "YWx3eDI1JDIwdHVyblE=",
    "oauth2_client_id": "c04009ad-764f-4e49-9e95-0000c50b51e7",
    "oauth2_client_secret": "f7a37c2a-caf0-44c4-bd06-81fd1b91231f",
    "account_numbers": [
        "0442468593-00001"
    ]
},

{
    "service_provider_id": 37,
    "service_provider_name": "VZWCR 1481-CYBEREN",
    "username": "Creefapi1481",
    "password": "YWx3eDI1JDIwdHVyblE=",
    "oauth2_client_id": "c04009ad-764f-4e49-9e95-0000c50b51e7",
    "oauth2_client_secret": "f7a37c2a-caf0-44c4-bd06-81fd1b91231f",
    "account_numbers": [
        "0842111481-00001",
        "0842836989-00001"
    ]
},

{
    "service_provider_id": 38,
    "service_provider_name": "VZWCR 3433-CRSKRAKN",
    "username": "Creefapi3433",
    "password": "YWx3eDI1JDIwdHVyblE=",
    "oauth2_client_id": "c04009ad-764f-4e49-9e95-0000c50b51e7",
    "oauth2_client_secret": "f7a37c2a-caf0-44c4-bd06-81fd1b91231f",
    "account_numbers": [
        "0742213433-00001",
        "0842836985-00001"
    ]
}

]



import json

if __name__ == "__main__":
    final_results = run_parallel_device_sync(SERVICE_PROVIDER_ACCOUNTS)

    logger.info("final_results==============>")

    for provider in final_results:

        total_devices_count = 0
        total_distinct_iccid_count = 0

        for account_number, account_data in provider.get("accounts", {}).items():

            device_count = account_data.get("device_count", 0)
            distinct_iccid_count = account_data.get("distinct_iccid_count", 0)

            total_devices_count += device_count
            total_distinct_iccid_count += distinct_iccid_count

            logger.info(
                f"Account: {account_number} | Devices Count: {device_count} | Distinct ICCID Count: {distinct_iccid_count}"
            )

        logger.info(
            f"Service Provider: {provider.get('service_provider_name')} "
            f"(ID: {provider.get('service_provider_id')}) | "
            f"Total Devices Count: {total_devices_count} | "
            f"Total Distinct ICCID Count: {total_distinct_iccid_count}"
        )

    logger.info("All accounts processing finished")































# #####################################################################################################################################
# import requests
# import json
# import time


# def fetch_all_verizon_devices(authorization_token , vz_token):
#     url = "https://thingspace.verizon.com/api/m2m/v1/devices/actions/list"

#     headers = {
#     "Accept": "application/json",
#     "Content-Type": "application/json",
#     "VZ-M2M-Token": vz_token,
#     "Authorization": f"Bearer {authorization_token}"
# }

#     largest_device_id_seen = 0
#     all_devices = []
#     page_number = 0

#     print("Starting Verizon Device Sync...\n")

#     while True:
#         page_number += 1
#         payload = {"largestDeviceIdSeen": largest_device_id_seen}

#         print(f"\nCalling API → Page {page_number} | largestDeviceIdSeen: {largest_device_id_seen}")

#         # ------------------------------
#         # 429 Retry Logic (3 attempts)
#         # ------------------------------
#         max_retries = 3
#         attempt = 0

#         while attempt <= max_retries:
#             response = requests.post(url, headers=headers, json=payload)

#             if response.status_code == 429:
#                 if attempt == max_retries:
#                     print(f"❌ Page {page_number} failed after 3 retries due to 429.")
#                     return all_devices

#                 wait_time = 2 ** (attempt + 1)
#                 print(f"⚠️ 429 Too Many Requests → Retrying in {wait_time} seconds...")
#                 time.sleep(wait_time)
#                 attempt += 1
#                 continue

#             break  # Exit retry loop if not 429

#         # ------------------------------
#         # Other Error Handling
#         # ------------------------------
#         if response.status_code != 200:
#             print(f"❌ API Error on Page {page_number}: {response.text}")
#             break

#         data = response.json()
#         devices = data.get("devices", [])

#         print(f"Page {page_number} → Devices Received: {len(devices)}")

#         if not devices:
#             print("No devices returned. Stopping.")
#             break

#         # ------------------------------
#         # Process Devices
#         # ------------------------------
#         for device in devices:

#             iccid = msisdn = imsi = mdn = min_value = imei = None

#             for d in device.get("deviceIds", []):
#                 kind = d.get("kind")
#                 if kind == "iccId":
#                     iccid = d.get("id")
#                 elif kind == "msisdn":
#                     msisdn = d.get("id")
#                 elif kind == "imsi":
#                     imsi = d.get("id")
#                 elif kind == "mdn":
#                     mdn = d.get("id")
#                 elif kind == "min":
#                     min_value = d.get("id")
#                 elif kind == "imei":
#                     imei = d.get("id")

#             carrier_info = device.get("carrierInformations", [{}])[0]
#             state = carrier_info.get("state")
#             service_plan = carrier_info.get("servicePlan")

#             account_number = None
#             device_id_value = None

#             for attr in device.get("extendedAttributes", []):
#                 if attr.get("key") == "AccountNumber":
#                     account_number = attr.get("value")
#                 elif attr.get("key") == "DeviceId":
#                     device_id_value = attr.get("value")

#             record = {
#                 "iccId": iccid,
#                 "msisdn": msisdn,
#                 "state": state,
#                 "imsi": imsi,
#                 "mdn": mdn,
#                 "min": min_value,
#                 "AccountNumber": account_number,
#                 "billingCycleEndDate": device.get("billingCycleEndDate"),
#                 "servicePlan": service_plan,
#                 "data_usage": None,
#                 "data_usage_mb": None,
#                 "sms_usage": None,
#                 "voice_usage": None,
#                 "accountName": device.get("accountName"),
#                 "imei": imei,
#                 "DeviceId": device_id_value,
#                 "ipAddress": device.get("ipAddress"),
#                 "lastActivationBy": device.get("lastActivationBy"),
#                 "lastActivationDate": device.get("lastActivationDate"),
#             }

#             all_devices.append(record)

#         # ------------------------------
#         # Pagination
#         # ------------------------------
#         last_device = devices[-1]
#         last_device_id = None

#         for attr in last_device.get("extendedAttributes", []):
#             if attr.get("key") == "DeviceId":
#                 try:
#                     last_device_id = int(attr.get("value"))
#                 except:
#                     last_device_id = None
#                 break

#         if not last_device_id:
#             print("No DeviceId found for pagination. Stopping.")
#             break

#         largest_device_id_seen = last_device_id

#         if not data.get("hasMoreData", False):
#             print(f"\n✅ Last Page Reached → Page {page_number}")
#             print("✅ All pages completed successfully.")
#             break

#         time.sleep(1)  # small delay to reduce rate limit risk

#     # ------------------------------
#     # Final Summary
#     # ------------------------------
#     print("\n================================")
#     print("SYNC SUMMARY")
#     print("================================")
#     print(f"Total Pages Fetched: {page_number}")
#     print(f"Total Devices Collected: {len(all_devices)}")
#     print("================================\n")

#     print("First 5000 characters of data:\n")
#     print(json.dumps(all_devices, indent=2)[:5000])

#     return all_devices


# res = fetch_all_verizon_devices(access_token, session_token) 
# print("all the devices are fetched...")



