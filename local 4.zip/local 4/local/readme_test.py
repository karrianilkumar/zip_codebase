from common_utils.email_trigger import send_email
"""
@Author1 : Phaneendra.Y
@Author2 :Ajay
@Author3 :Puja
Created Date: 05-09-2025
"""

# Importing the necessary Libraries
import os
import json
import time
import threading
import boto3 # type: ignore
import pandas as pd # type: ignore
from datetime import datetime
import numpy as np
import base64
from common_utils.db_utils import DB
from common_utils.logging_utils import Logging
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests
# from config.carrier_config_manager import CarrierConfigManager

import logging

class ColorFormatter(logging.Formatter):
    COLORS = {
        "DEBUG": "\033[94m",   # Blue
        "INFO": "\033[92m",    # Green
        "WARNING": "\033[93m", # Yellow
        "ERROR": "\033[91m",   # Red
        "CRITICAL": "\033[95m" # Purple
    }
    RESET = "\033[0m"

    def format(self, record):
        color = self.COLORS.get(record.levelname, self.RESET)
        message = super().format(record)
        return f"{color}{message}{self.RESET}"

# Create logger
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

# Remove old handlers (important in Jupyter)
logger.handlers.clear()

# Add new handler
handler = logging.StreamHandler()
handler.setFormatter(ColorFormatter("%(levelname)s: %(message)s"))
logger.addHandler(handler)



def get_bundle_codes():
    """
    Fetch bundle (PS) codes from the Ceretax API.

    Returns:
        list | dict: API response containing bundle codes or error message.
    """

    url = "https://data.cert.ceretax.net/psCodes"

    headers = {
        "x-api-key": "9P1I3fkgLE9mLWgsFrS8O9KwDrErmcGytgb7LNhg",
        "Content-Type": "application/json"
    }

    try:
        response = requests.get(url, headers=headers, timeout=30)

        if response.status_code == 200:
            return response.json()   # return response as it is

        logging.error(f"API failed with status code {response.status_code}")
        return {
            "flag": False,
            "message": f"API request failed with status code {response.status_code}"
        }

    except requests.exceptions.RequestException as e:
        logging.error(f"Error calling Ceretax API: {str(e)}")
        return {
            "flag": False,
            "message": str(e)
        }
        
        
# res =get_bundle_codes()   
# print("result ==> ", res)     
import requests


from common_utils.db_utils import DB
db_config = {
    'host': "amopuatpostgresoct23.c3qae66ke1lg.us-east-1.rds.amazonaws.com",
    'port': "5432",
    'user':"root",
    'password':"AmopTeam123"
}
 
#amop_Central_database = DB('altaworx_central', **db_config)
common_utils_database = DB('common_utils', **db_config)
tenant_database = DB('altaworx_central_beta', **db_config)

# Step 1: Fetch staging data
staging_df = tenant_database.get_data(
    table_name="verizon_carrier_sync_staging",
    columns=["id", "iccid", "account_number"]
)
# Step 2: Fetch callback usage data
callback_df = tenant_database.get_data(
    table_name="verizon_carrier_usage_staging",
    columns=["iccid","data_usage", "sms_usage"]
)
print("Staging DataFrame:",staging_df)
print("Callback DataFrame:",callback_df)
if staging_df is None or callback_df is None:
    print({"flag": False, "message": "Failed to fetch tables"})
if staging_df.empty or callback_df.empty:
    print({"flag": False, "message": "No data available to process"})
import pandas as pd

# Step 3: Find common ICCIDs between staging and callback tables
common_iccid_df = pd.merge(
    staging_df,
    callback_df,
    on="iccid",
    how="inner"
)

print("Common ICCID Records:")
print(common_iccid_df)    
    
    
usage_df = common_iccid_df[
    (common_iccid_df["sms_usage"] > 0)
]

print("ICCID with usage > 0:")
print(usage_df)    