"use client";
import React, { useEffect, useState } from "react";
import { Modal } from "antd";
import dayjs, { Dayjs } from "dayjs";
import { PerformanceLogStore } from "./stores/performance_matrix_store";
import { DoubleLeftOutlined } from "@ant-design/icons";

interface PerformanceLogProps {
  performanceMatrix: any;
  latestNavClick: any;
}

export const RenderPerformanceMatrixModal: React.FC<PerformanceLogProps> = ({
  performanceMatrix,
  latestNavClick,
}) => {
  const [logs, setLogs] = useState<{ step: string; time: string }[]>([]);
  const [isLogModalOpen, setIsLogModalOpen] = useState(false);
  const { logStatement } = PerformanceLogStore();

  const addLog = (step: string) => {
    console.log(logs);
    console.log(step);
    const now = dayjs().format("HH:mm:ss.SSS"); // 24-hour format with milliseconds
    setLogs((prevLogs) => [...prevLogs, { step, time: now }]);
  };


  useEffect(() => {
    addLog(logStatement);
  }, [logStatement]);

  const closeLogModal = () => {
    setIsLogModalOpen(false);
  };

  return (
    <>
      <div>
        <DoubleLeftOutlined
          title="Show Logs"
          onClick={() => setIsLogModalOpen(true)}
          className="cursor-pointer text-base"
        />
      </div>
      <Modal
        open={isLogModalOpen}
        onCancel={closeLogModal}
        footer={null}
        title="Performance Details"
        style={{
          position: "fixed",
          bottom: 0,
          right: 0,
          margin: 0,
        }}
        width={600}
      >
        <div style={{ maxHeight: "500px", overflowY: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr>
                <th
                  style={{
                    borderBottom: "2px solid #ddd",
                    padding: "8px",
                    textAlign: "left",
                  }}
                >
                  Step
                </th>
                <th
                  style={{
                    borderBottom: "2px solid #ddd",
                    padding: "8px",
                    textAlign: "left",
                  }}
                >
                  Time
                </th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  Nav Item Clicked
                </td>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  {latestNavClick?.clickTime || "-"}
                </td>
              </tr>
              <tr>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  UI API Call
                </td>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  {logs.find((log) => log.step === "UI API Call")?.time || "-"}
                </td>
              </tr>
              <tr>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  Component Rendered
                </td>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  {logs.find((log) => log.step === "Component rendered")
                    ?.time || "-"}
                </td>
              </tr>
              <tr>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  Backend Start Time
                </td>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  {performanceMatrix.start_time || "-"}
                </td>
              </tr>
              <tr>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  Backend End Time
                </td>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  {performanceMatrix.end_time || "-"}
                </td>
              </tr>
              <tr>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  Lambda Response to UI
                </td>
                <td style={{ borderBottom: "1px solid #ddd", padding: "8px" }}>
                  {logs.find((log) => log.step === "Lambda Response to UI")
                    ?.time || "-"}
                </td>
              </tr>
              {/* Display additional logs for user interactions */}
              {logs
                .filter(
                  (log) =>
                    ![
                      "UI API Call",
                      "Component rendered",
                      "Lambda Response to UI",
                    ].includes(log.step)
                )
                .map((log, index) => (
                  <tr key={index}>
                    <td
                      style={{ borderBottom: "1px solid #ddd", padding: "8px" }}
                    >
                      {log.step}
                    </td>
                    <td
                      style={{ borderBottom: "1px solid #ddd", padding: "8px" }}
                    >
                      {log.time}
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </Modal>
    </>
  );
};
