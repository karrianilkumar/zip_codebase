"use client";
import React, { useEffect, useState, lazy, Suspense, useRef } from 'react';
import { useSidebarStore } from '@/app/stores/navBarStore';
import { useLogoStore } from "@/app/stores/logoStore";
import { Modal, Spin, Switch } from 'antd';
import { useAuth } from '../components/auth_context';
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { getCurrentDateTime } from '../components/header_constants';
import axios from 'axios';
import { useInventoryRedirectStore } from '../stores/inventoryRedirectStore';

// Lazy-loaded dashboard components
const SimsOverview = lazy(() => import('./sims_overview'));
const UsageInsights = lazy(() => import('./usage_insights'));
const RevenueMetrics = lazy(() => import('./revenue_metrics'));
const ZendeskTracking = lazy(() => import('./zendesk_tracking'));
const SyncStatus = lazy(() => import('./sync_status'));         

const Dashboard_2_0: React.FC = () => {
  const title = useLogoStore((state) => state.title);
  const setTitle = useLogoStore((state) => state.setTitle);
  const isExpanded = useSidebarStore((state: any) => state.isExpanded);
  const { username, role, partner, token, selectedDb,metaData, firstLastName, sessionId, modulesVersionMap, setModulesVersionMap } = useAuth();
  const { setTotalFeatures, setSelectedFeatures, selectedFeatures, totalFeatures } = useInventoryRedirectStore();

  const active_tab = localStorage.getItem("activeTab") || "simsOverview";
  const active_tabs_list = ["simsOverview", "usageInsights", "revenueMetrics", "zendeskTracking", "syncStatus"];
  const [activeTab, setActiveTab] = useState(() => {
    return active_tabs_list.includes(active_tab) ? active_tab : "simsOverview";
  });
  const [loading, setLoading] = useState(false);
  const [isBPEnabled, setIsBPEnabled] = useState(false);
  const [switchVersion, setSwitchVersion] = useState(false);
  const [dataLoaded, setDataLoaded] = useState(false);
  const selectedFeaturesRef = useRef(selectedFeatures);

  // Tab mapping for feature checking
  const tabFeatureMapping = {
    "simsOverview": "Sim Overview",
    "usageInsights": "Usage Insights", 
    "revenueMetrics": "Revenue Metrics",
    "zendeskTracking": "Zendesk Tracking",
    "syncStatus": "Sync Status"
  };

  // Function to check if a tab has any available features
  const hasTabFeatures = (tabKey: string) => {
    const tabName = tabFeatureMapping[tabKey as keyof typeof tabFeatureMapping];
    return totalFeatures.some((feature: any) => feature.tab === tabName);
  };

  // Get available tabs based on features
  const getAvailableTabs = () => {
    return active_tabs_list.filter(tab => {
      if (tab === "revenueMetrics") {
        // Revenue Metrics tab requires both BP enabled and has features
        return isBPEnabled && hasTabFeatures(tab);
      }
      return hasTabFeatures(tab);
    });
  };

  // Get the first available tab as default
  const getDefaultTab = () => {
    const availableTabs = getAvailableTabs();
    if (availableTabs.length > 0) {
      // If current active tab is available, keep it
      if (availableTabs.includes(activeTab)) {
        return activeTab;
      }
      // Otherwise return the first available tab
      return availableTabs[0];
    }
    return "simsOverview"; // fallback
  };

  // Update activeTab when totalFeatures changes
 useEffect(() => {
  // Only check tab availability AFTER data is loaded
  if (totalFeatures.length > 0 && dataLoaded) {
    const availableTabs = getAvailableTabs();
    
    // Only reset if the current tab is truly not available
    if (!availableTabs.includes(activeTab)) {
      const defaultTab = availableTabs[0] || "simsOverview";
      setActiveTab(defaultTab);
    }
  }
}, [totalFeatures, isBPEnabled, dataLoaded]); 

  // Update ref when selectedFeatures changes
  useEffect(() => {
    selectedFeaturesRef.current = selectedFeatures;
  }, [selectedFeatures]);

  // Initialize switchVersion based on modulesVersionMap
  useEffect(() => {
    const initial_version_flag = modulesVersionMap?.["Dashboard-None"] || false;
    if (!initial_version_flag || initial_version_flag === "False" || initial_version_flag === "None") {
      setSwitchVersion(false);
    } else {
      setSwitchVersion(true);
    }
    saveVersionFlag();
  }, [modulesVersionMap]);

  // Fetch billing platform flag and features on mount
  useEffect(() => {
    fetchBpFlag();
    fetchFeatures("get", []);
  }, []);

  // Save activeTab to localStorage and update features
  useEffect(() => {
    localStorage.setItem("activeTab", activeTab);
    fetchFeatures("update", selectedFeaturesRef.current);
  }, [activeTab]);

  // Update features on component unmount
  useEffect(() => {
    return () => {
      fetchFeatures("update", selectedFeaturesRef.current);
    };
  }, []);

  // Save version flag to server
  const saveVersionFlag = async () => {
    const url = ENV_ROUTES.MODULE_MANAGEMENT;
    const data = {
      tenant_name: partner || "default_value",
      username,
      path: "/update_version_flag",
      role_name: role,
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
      version_flag: modulesVersionMap,
    };

    try {
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === true) {
        console.log("Successfully saved version flag");
      }
    } catch (error) {
      console.error("Error saving version flag:", error);
    }
  };

  // Handle switch toggle
  const handleVersionChange = (checked: boolean) => {
    setSwitchVersion(checked);
    const value_ = checked ? "True" : "False";
    setModulesVersionMap((prev: any) => {
      const updated = { ...prev, "Dashboard-None": checked };
      localStorage.setItem("switch_user_20_modules_json", JSON.stringify(updated));
      return updated;
    });
  };

  // Fetch billing platform flag
  const fetchBpFlag = async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username,
        firstLastName,
        path: "/get_cross_provider_optimization_status",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Active Customer Rate Plan",
        feature_module_name: "Customer Rate Plans",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        const billing_platform_flag = parsedData?.billing_platform_flag || false;
        setIsBPEnabled(billing_platform_flag);
        setDataLoaded(true); 
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
      setDataLoaded(true);
    } finally {
      setLoading(false);
    }
  };

  // Fetch or update features
  const fetchFeatures = async (action: string, features: any[]) => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.DASHBOARD;
      const data = {
        tenant_name: partner || "default_value",
        username,
        firstLastName,
        path: "/get_update_module_features",
        role_name: role,
        module_name: "Dashboard",
        feature_module_name: "Dashboard",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        action,
        ...(action === "update" ? { selected_features: [...features] } : {}),
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else if (action === "get") {
        const module_features = parsedData?.module_features || [];
        console.log("Fetched features:", module_features);
        setTotalFeatures(module_features);
        const selected_features = parsedData?.selected_features || [];
        console.log("Fetched selected features:", selected_features);
        setSelectedFeatures(selected_features);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  const availableTabs = getAvailableTabs();

  return (
    <div className="">
      <div className={`shadow-md mb-4 gap-4 tabs ${isExpanded ? "left-[250px]" : "lg:left-[70px] left-0"}`}>
        <div className="flex justify-between items-center w-full">
          <div className="flex gap-4">
            {/* Conditionally render tabs based on available features */}
            {availableTabs.includes('simsOverview') && (
              <button
                className={`tab-headings ${activeTab === 'simsOverview' ? 'active-tab-heading' : ''}`}
                onClick={() => setActiveTab('simsOverview')}
              >
                SIMs Overview
              </button>
            )}
            {availableTabs.includes('usageInsights') && (
              <button
                className={`tab-headings ${activeTab === 'usageInsights' ? 'active-tab-heading' : ''}`}
                onClick={() => setActiveTab('usageInsights')}
              >
                Usage Insights
              </button>
            )}
            {availableTabs.includes('revenueMetrics') && (
              <button
                className={`tab-headings ${activeTab === 'revenueMetrics' ? 'active-tab-heading' : ''}`}
                onClick={() => setActiveTab('revenueMetrics')}
              >
                Revenue Metrics
              </button>
            )}
             {availableTabs.includes('zendeskTracking') && (
              <button
                className={`tab-headings ${activeTab === 'zendeskTracking' ? 'active-tab-heading' : ''}`}
                onClick={() => setActiveTab('zendeskTracking')}
              >
                Zendesk Tracking
              </button>
            )}
            {/* {availableTabs.includes('revenueMetrics') && ( */}
              <button
                className={`tab-headings ${activeTab === 'syncStatus' ? 'active-tab-heading' : ''}`}
                onClick={() => setActiveTab('syncStatus')}
              >
                Sync Status
              </button>
            {/* )} */}
          </div>
          {localStorage.getItem("switch_user_2_0") === "True" && (
            <div className="flex items-center switch-container">
              <span className="font-semibold  md:mr-4">1.0</span>
              <Switch
                checked={switchVersion}
                onChange={handleVersionChange}
                className="scale-[0.8] md:scale-[1.3] ml-4 custom-switch"
              />
              <span className="font-semibold m-2 md:ml-4">2.0</span>
            </div>
          )}
        </div>
      </div>
      <div className="h-[calc(100vh-150px)] pt-[70px]">
        <Suspense fallback={<div className="flex justify-center items-center h-screen"><Spin size="large" /></div>}>
          {activeTab === 'simsOverview' && availableTabs.includes('simsOverview') && <SimsOverview />}
          {activeTab === 'usageInsights' && availableTabs.includes('usageInsights') && <UsageInsights />}
          {activeTab === 'revenueMetrics' && availableTabs.includes('revenueMetrics') && <RevenueMetrics />}
          {activeTab === 'zendeskTracking' && availableTabs.includes('zendeskTracking') && <ZendeskTracking />}
          {/* {activeTab === 'syncStatus' && availableTabs.includes('syncStatus') && <SyncStatus />} */}
          {activeTab === 'syncStatus' && <SyncStatus />}
        </Suspense>
      </div>
    </div>
  );
};

export default Dashboard_2_0;