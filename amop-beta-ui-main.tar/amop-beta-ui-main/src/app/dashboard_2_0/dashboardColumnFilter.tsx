import React, { useEffect, useState } from "react";
import { Checkbox, Divider, Popover, Spin } from "antd";
import { AdjustmentsHorizontalIcon } from "@heroicons/react/24/outline";
import { useInventoryRedirectStore } from "../stores/inventoryRedirectStore";

interface ColumnFilterProps {
    tabName: string;
    setFeatures: (graphs: string[]) => void;
     selectedByteUnit?: "KB" | "MB" | "GB";
}

const DashboardColumnFilter: React.FC<ColumnFilterProps> = ({
    tabName,
    setFeatures,
    selectedByteUnit
}) => {
    const { totalFeatures, selectedFeatures, setSelectedFeatures } = useInventoryRedirectStore();
    const [loading, setLoading] = useState(false);
    const [selectedGraphs, setSelectedGraphs] = useState<any[]>([]);
    const [allGraphs, setAllGraphs] = useState<any[]>([]);

    useEffect(() => {
        if (!tabName) return;

        // get all graphs for this tab
        const all_graphs = totalFeatures
            .filter((f) => f.tab === tabName)
            .map((f) => f.name);

        // get selected graphs for this tab
        const selected_graphs = selectedFeatures
            .filter((f) => f.tab === tabName && all_graphs.includes(f.name))
            .map((f) => f.name);

        setAllGraphs(all_graphs);
        setSelectedGraphs(selected_graphs);
        setFeatures(selected_graphs)
    }, [tabName, selectedFeatures, totalFeatures]);


    const handleGraphVisibleChange = (checked: boolean, graph: string) => {
        if (checked) {
            // Add only if not already present
            if (!selectedFeatures.some((f) => f.tab === tabName && f.name === graph)) {
                setSelectedFeatures([
                    ...selectedFeatures,
                    { tab: tabName, name: graph },
                ]);
            }
        } else {
            // Remove if unchecked
            setSelectedFeatures(
                selectedFeatures.filter((f) => !(f.tab === tabName && f.name === graph))
            );
        }
    };


    const handleCheckAllChange = (checked: boolean) => {
        if (checked) {
            // Add all graphs (avoid duplicates)
            const newSelections = allGraphs
                .filter((graph) => !selectedFeatures.some((f) => f.tab === tabName && f.name === graph))
                .map((graph) => ({ tab: tabName, name: graph }));

            setSelectedFeatures([...selectedFeatures, ...newSelections]);
        } else {
            // Remove all graphs of this tab
            setSelectedFeatures(
                selectedFeatures.filter((f) => f.tab !== tabName)
            );
        }
    };


    const columnContent = (
        <Spin spinning={loading}>
            <div
                style={{
                    display: "flex",
                    flexDirection: "column",
                    maxHeight: "300px",
                    overflowY: "auto",
                }}
            >
                <Checkbox
                    onChange={(e) =>
                        handleCheckAllChange(e.target.checked)
                    }
                    checked={selectedGraphs.length === allGraphs.length}
                    style={{ marginBottom: "4px" }}
                >
                    All
                </Checkbox>
                <Divider style={{ margin: "0.5rem 0 0.2rem" }} />
                {allGraphs.map((graph) => {
                const label = graph
                .replace("(GB)", `(${selectedByteUnit})`)
                .replace("(MB)", `(${selectedByteUnit})`)
                .replace("(KB)", `(${selectedByteUnit})`);

                return (
                <Checkbox
                    key={graph}
                    value={graph}
                    checked={selectedGraphs.includes(graph)}
                    onChange={(e) => handleGraphVisibleChange(e.target.checked, graph)}
                    style={{ marginBottom: "4px", whiteSpace: "nowrap" }}
                >
                    {label}
                </Checkbox>
                );
            })}
            </div>
        </Spin>
    );

    return (
        <Popover content={columnContent} trigger="click" placement="bottom">
            <button
                className={`flex items-center save-btn !min-h-[39px]`}
            >
                <AdjustmentsHorizontalIcon className="h-5 w-5 text-black-500" />
                <span className="hidden md:inline">Graphs</span>
            </button>
        </Popover>
    );
};

export default DashboardColumnFilter;