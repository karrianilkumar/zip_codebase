import React, { useEffect, useState } from "react";
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import { Spin } from "antd";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import dayjs from "dayjs";
interface ConfigTypes {
  title: string;
  height: number;
  width: number;
  count: number | string;
}

interface DasboardCardsProps {
  selectedServiceProvider: string;
  startDate: string;
  endDate: string;
  serviceProvider: string;
  selectedTenantId: any;
  billingCyclePeriod:any;
  features: string[]
}

const RevenueMetricCards: React.FC<DasboardCardsProps> = ({ selectedServiceProvider, startDate, endDate, serviceProvider, selectedTenantId, billingCyclePeriod, features }) => {
  const [loading, setLoading] = useState(false);
  const [datalog, setData] = useState<ConfigTypes[]>([]);
  const [rawData, setRawData] = useState<ConfigTypes[]>([]);
  const { token, partner, selectedDb,metaData, sessionId, username, role } = useAuth();
  
   useEffect(() => {
        if (rawData.length > 0) {
          const filteredResults = rawData.filter((item) =>
            features.some((f) => f.trim().toLowerCase() === item.title.trim().toLowerCase())
          );
          setData(filteredResults);
        }
      }, [features, rawData]);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
  let finalStart = startDate;
  let finalEnd = endDate;
 if (!startDate && !endDate) {
   finalStart = dayjs().startOf("month").format("YYYY-MM-DD");
   finalEnd = dayjs().format("YYYY-MM-DD");
 }
      try {
        const url = ENV_ROUTES.DASHBOARD;
        const requestData = {
          partner: partner,
          tenant_name: partner,
          start_date: selectedServiceProvider ==="" || billingCyclePeriod === "None" ? finalStart : startDate,
          end_date: selectedServiceProvider ==="" || billingCyclePeriod === "None" ?  finalEnd  : endDate,
          // service_provider: serviceProvider,
          tenant_id: selectedTenantId,
          role_name: role,
          username: username,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          service_provider: selectedServiceProvider,
          // billing_cycle_end_period: billingCyclePeriod || "", // Use the billing cycle period if provided burhan

          billing_cycle_end_period:
          billingCyclePeriod === "None"
          ? ""
          : billingCyclePeriod || "",
        };

        // Fetch data from the single path
        const response = await axios.post(url, { data: { path: "/get_revenue_metrics_cards", ...requestData } });
        const parsedData = JSON.parse(response.data.body);
        const { data } = parsedData;
        console.log(data, "show that parsed data");
        // Create an array of objects for each key in the response
        const results = [
          {
            title: "Total Revenue",
            count: data.total_payments,
            height: data.height,
            width: data.width,
          },
          {
            title: "Total Charges",
            count: data.total_charges,
            height: data.height,
            width: data.width,
          },
          {
            title: "Total Billed Amount",
            count: data.total_billed_amount,
            height: data.height,
            width: data.width,
          },
          {
            title: " Overdue Payments",
            count: data.overdue_payments,
            height: data.height,
            width: data.width,
          },
        ];

        setRawData(results);
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };
  
    fetchData();
  }, [token, selectedServiceProvider, startDate, endDate]);
  
  if (loading) {
    return (
      <div className="ml-1 py-2 px-6 w-full">
                  <div className="grid grid-cols-2 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                    <div className="col-span-4 flex justify-center items-center py-10">
                      <Spin size="large" />
                    </div>
                  </div>
                </div>
    );
  }
  
  const isSmallScreen = typeof window !== "undefined" && window.innerWidth < 700;

  return (
    <div className="ml-1 py-2 px-6 w-full">
      <div className="grid grid-cols-2 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {datalog.map((item, index) => {
          return (
            <div
              key={index}
              className="chart w-full"
              style={
                isSmallScreen
                  ? { width: "150px", height: "100px" }
                  : {  minHeight: "75px" }
              }
            >
              <div className="p-2 mt-0">
                <div className="flex flex-col sm:text-left text-center">
                  <h2 style={{ fontFamily: "Calibri, sans-serif", fontSize: "18px" }}>
                    {item.title}
                  </h2>
                  <p className="chart-count">
                    <span style={{ fontSize: "18px" }}>{item.count}</span>
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default RevenueMetricCards;
