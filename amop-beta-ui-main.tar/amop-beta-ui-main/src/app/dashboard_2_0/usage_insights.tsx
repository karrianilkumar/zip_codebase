"use client";
import React, { lazy, Suspense, useEffect, useState, ReactElement, useRef} from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "../components/auth_context";
import { useLogoStore } from "../stores/logoStore";
import { useInventoryRedirectStore } from "../stores/inventoryRedirectStore";
import {
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LabelList,
  ComposedChart,
  Line,
  LineChart,
  Area,
  AreaChart,
 ScatterChart, Scatter, ZAxis ,CartesianGrid // Add this
} from "recharts";
import { ENV_ROUTES } from "../components/routes/route_constants";
import axios from "axios";
import { getCurrentDateTime } from "../components/header_constants";
import { Button, DatePicker, Spin, Table, Tooltip as AntdTooltip } from "antd";
import Select from "react-select";
import { ChevronDownIcon, ArrowPathRoundedSquareIcon, ArrowTopRightOnSquareIcon } from "@heroicons/react/24/outline";
import moment from "moment";
import dayjs, { Dayjs } from "dayjs";
import DashboardColumnFilter from "./dashboardColumnFilter";
import DashboardRefresh from "./dashboardRefreshComponent";
import {ResponsiveBar} from '@nivo/bar'
import { DropdownStyles } from "../components/css/dropdown";
import { ResponsiveLine } from "@nivo/line";
import { line as d3Line, curveMonotoneX } from "d3-shape";

const UsageInsightsCards = lazy(() => import("@/app/dashboard_2_0/UsageInsightsCards"));

const { RangePicker } = DatePicker;

interface FilterOption {
  value: string;
  label: string;
  tenant_id: string;
}

interface FilterOptions {
  options: FilterOption[];
}

interface UsageChartData {
  usageTrend: any | null;
  serviceTypeUsage: any | null;
  usageByCarrier: any | null;
  planUtilisation: any | null;
}

interface ProcessedUsageData {
  chartData: Array<{ service_provider: string; usage?: number; percentage?: number; usage_count?: number; plan?: string }>;
  details: { [provider: string]: { [date: string]: number } };
}

interface CustomTooltipProps {
  active?: boolean;
  payload?: Array<{ value: number; name: string; dataKey: string }>;
  label?: string;
  details?: { [provider: string]: { [date: string]: number } };
  coordinate?: { x: number; y: number };
  isStatusChart?: boolean;
  chartType?: 'usageTrend' | 'serviceType' | 'usageByCarrier' | 'planUtilisation';
}

interface EnhancedResponsiveContainerProps {
  dataLength: number;
  height: number;
  children: ReactElement;
}
interface ServiceProviderData {
  unique_service_providers: string[];
  billing_period_dates: { [provider: string]: string[] };
}

// Each row: { time: string, [planName]: number }
type NivoRow = {
  time: string;
  [key: string]: string | number;
};


type UsageChartEntry = {
  service_provider?: string;
  plan?: string;
  usage?: number;
  percentage?: number;
  usage_count?: number;
  constantHeight?: number;
  [key: string]: number | string | undefined;
};
// ============================================================================
// UNIT CONVERSION UTILITIES - Add this at the top of usage_insights.tsx
// ============================================================================

type ByteUnit = "KB" | "MB" | "GB" | "TB" | "PB";

interface ConversionResult {
  value: number;
  unit: ByteUnit;
  formatted: string;
}
// Raw data is in KB, not bytes
const BYTE_UNITS: Record<ByteUnit, number> = {
  KB: 1,
  MB: 1024,
  GB: 1024 * 1024,
  TB: 1024 ** 3,
  PB: 1024 ** 4,
};



/**
 * Detects the appropriate unit based on byte value
 * Returns the largest unit where the value is >= 1
 */
const detectAppropriateUnit = (bytes: number): ByteUnit => {
  const absBytes = Math.abs(bytes);
  
  if (absBytes >= BYTE_UNITS.PB) return 'PB';
  if (absBytes >= BYTE_UNITS.TB) return 'TB';
  if (absBytes >= BYTE_UNITS.GB) return 'GB';
  if (absBytes >= BYTE_UNITS.MB) return 'MB';
  if (absBytes >= BYTE_UNITS.KB) return 'KB';

  // Raw values always KB → smallest unit = KB
  return 'KB';
};


/**
 * Converts bytes to a specific unit with formatting
 * @param bytes - The value in bytes
 * @param targetUnit - The unit to convert to (default: auto-detect)
 * @param decimals - Number of decimal places (default: 2)
 */
const convertBytes = (
  bytes: number,
  targetUnit?: ByteUnit,
  decimals: number = 2
): ConversionResult => {
  if (bytes === 0) {
    return { value: 0, unit: 'KB', formatted: '0 KB' };
  }

  const unit = targetUnit || detectAppropriateUnit(bytes);
  const divisor = BYTE_UNITS[unit];
  const value = bytes / divisor;

  // Round to nearest decimal places
  const roundedValue = Math.round(value * Math.pow(10, decimals)) / Math.pow(10, decimals);

  // Format with proper decimal places and locale-specific formatting
  const formatted = `${roundedValue.toLocaleString(undefined, {
    minimumFractionDigits: 0,
    maximumFractionDigits: decimals,
  })} ${unit}`;

  return { value: roundedValue, unit, formatted };
};

/**
 * Formats bytes for tooltip display
 * Shows value with automatically selected unit
 */
const formatBytesForTooltip = (bytes: number, decimals: number = 2): string => {
  return convertBytes(bytes, undefined, decimals).formatted;
};

/**
 * Formats bytes for Y-axis with abbreviations
 * Uses single letter abbreviations (T, G, M, K, B)
 */
const formatBytesForAxis = (bytes: number): string => {
  if (bytes === 0) return '0';

  const absBytes = Math.abs(bytes);
  
  if (absBytes >= BYTE_UNITS.TB) {
    const value = Math.round((bytes / BYTE_UNITS.TB) * 10) / 10;
    return `${value}T`;
  } else if (absBytes >= BYTE_UNITS.GB) {
    const value = Math.round((bytes / BYTE_UNITS.GB) * 10) / 10;
    return `${value}G`;
  } else if (absBytes >= BYTE_UNITS.MB) {
    const value = Math.round((bytes / BYTE_UNITS.MB) * 10) / 10;
    return `${value}M`;
  } else if (absBytes >= BYTE_UNITS.KB) {
    const value = Math.round((bytes / BYTE_UNITS.KB) * 10) / 10;
    return `${value}K`;
  }

  return Math.round(bytes).toString();
};

/**
 * Rounds value to nearest 0 or 5 for cleaner Y-axis display
 */
const roundToNearest0Or5 = (num: number): number => {
  const remainder = num % 10;
  const base = num - remainder;

  if (remainder <= 2.5) {
    return Math.abs(num - base) < Math.abs(num - (base + 5)) ? base : base + 5;
  } else if (remainder <= 7.5) {
    return Math.abs(num - (base + 5)) < Math.abs(num - (base + 10)) ? base + 5 : base + 10;
  } else {
    return base + 10;
  }
};

// Updated provider colors
const PROVIDER_COLORS =  [
 " #74B9FF","#A29BFE",
//  "#f6a751",//changed color
"#faad14",
 "#81ECEC","#D980FA","#55EFC4","#FABE58","#00B894","#FF9FF3","#00CEC9","#BDC3C7","#FFEAA7"];


// Updated usage trend colors (darker variants for better line visibility)
const USAGE_TREND_BLUE_SHADES = [
 " #74B9FF","#A29BFE","#faad14","#81ECEC","#D980FA","#55EFC4","#FABE58","#00B894","#FF9FF3","#00CEC9","#BDC3C7","#FFEAA7"];


// Updated plan colors for rectangles
const PLAN_COLORS =  [
 " #74B9FF","#A29BFE","#faad14","#81ECEC","#D980FA","#55EFC4","#FABE58","#00B894","#FF9FF3","#00CEC9","#BDC3C7","#FFEAA7"];


// Enhanced ResponsiveContainer
const EnhancedResponsiveContainer: React.FC<EnhancedResponsiveContainerProps> = ({ dataLength, height, children }) => {
  const minWidth = 320;
  const widthPerItem = 80;
  const calculatedWidth = Math.max(minWidth, dataLength * widthPerItem);

  return (
    <div style={{ width: "100%", overflowX: "auto" }}>
      <ResponsiveContainer width="100%" height={height}>
        {children}
      </ResponsiveContainer>
    </div>
  );
};
// Helper function to round to nearest 0 or 5

// const wrapYAxisLabel = (label: string): string => {
//   const maxLength = 15;
//   if (label.length <= maxLength) {
//     return label;
//   }
//   const words = label.split(" ");
//   let currentLine = "";
//   const lines: string[] = [];
//   words.forEach((word) => {
//     if ((currentLine + word).length > maxLength) {
//       lines.push(currentLine.trim());
//       currentLine = word + " ";
//     } else {
//       currentLine += word + " ";
//     }
//   });
//   if (currentLine) {
//     lines.push(currentLine.trim());
//   }
//   return lines.join("\n");
// };

// Fixed date formatting function to handle the specific format you mentioned
const wrapYAxisLabel = (label: string): string => {
  const maxLength = 18; // Reduced for single line with width={100}
  
  if (label.length <= maxLength) return label;
  
  // For single line, truncate and add ellipsis
  return label.substring(0, maxLength - 3) + "...";
};
const formatDateForTooltip = (dateString: string): string => {
  if (!dateString) return "Invalid Date";
  
  try {
    let parsedDate;
    
    // Handle the specific format: 2025-07-18'T'00:00:00'Z'
    if (dateString.includes("'T'") && dateString.includes("'Z'")) {
      // Remove the single quotes around T and Z
      const cleanedDate = dateString.replace(/'/g, "");
      parsedDate = moment(cleanedDate);
    } else if (dateString.includes('T')) {
      // Standard ISO format
      parsedDate = moment(dateString);
    } else if (dateString.includes('-')) {
      // YYYY-MM-DD format
      parsedDate = moment(dateString, 'YYYY-MM-DD');
    } else if (dateString.includes('/')) {
      // MM/DD/YYYY or DD/MM/YYYY format
      parsedDate = moment(dateString, ['MM/DD/YYYY', 'DD/MM/YYYY']);
    } else {
      // Try to parse as is
      parsedDate = moment(dateString);
    }
    
    if (!parsedDate.isValid()) {
      return "Invalid Date";
    }
    
    return parsedDate.format("MMM DD, YYYY");
  } catch (error) {
    console.error("Date parsing error:", error, "for date:", dateString);
    return "Invalid Date";
  }
};

// Add this function near the top of the file, after imports
const getMonthNameFromIndex = (monthIndex: string | number): string => {
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const index = typeof monthIndex === 'string' ? parseInt(monthIndex) : monthIndex;
  return monthNames[index] || monthIndex.toString();
};


const UsageInsights: React.FC = () => {
  const router = useRouter();
  const { username, partner, role, selectedDb, metaData, token, firstLastName, sessionId, setSelectedPartner } = useAuth();
  const setTitle = useLogoStore((state) => state.setTitle);
  // ✅ ADD MISSING STORE METHODS
  const { setFilters, setRedirected, clearFilters } = useInventoryRedirectStore();
  
  const [loading, setLoading] = useState<boolean>(false);
  const [filterOptions, setFilterOptions] = useState<FilterOptions>({ options: [] });
  const [selectedFilter, setSelectedFilter] = useState<string>(partner || "");
  const [selectedTenantId, setSelectedTenantId] = useState<string>("");
  const [selectedButton, setSelectedButton] = useState<string | null>("Current Month");
  const [startDate, setStartDate] = useState<string>(moment().startOf("month").format("YYYY-MM-DD"));
  const [endDate, setEndDate] = useState<string>(moment().format("YYYY-MM-DD"));
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([null, null]);
  const [flippedChart, setFlippedChart] = useState<number | null>(null);
  const [chartData, setChartData] = useState<UsageChartData>({
    usageTrend: null,
    serviceTypeUsage: null,
    usageByCarrier: null,
    planUtilisation: null,
  });
  const [cachedData, setCachedData] = useState<UsageChartData>({
    usageTrend: null,
    serviceTypeUsage: null,
    usageByCarrier: null,
    planUtilisation: null,
  });
  const [loadingUsageTrend, setLoadingUsageTrend] = useState<boolean>(true);
  const [loadingServiceTypeUsage, setLoadingServiceTypeUsage] = useState<boolean>(true);
  const [loadingUsageByCarrier, setLoadingUsageByCarrier] = useState<boolean>(true);
  const [loadingPlanUtilisation, setLoadingPlanUtilisation] = useState<boolean>(true);
  const [useCache, setUseCache] = useState<boolean>(false);
  const [internalFilterUsageTrend, setInternalFilterUsageTrend] = useState<string>("1_month");
  const [internalFilterServiceType, setInternalFilterServiceType] = useState<string>("1_month");
  const [internalFilterUsageByCarrier, setInternalFilterUsageByCarrier] = useState<string>("1_month");
  const [internalFilterPlanUtilisation, setInternalFilterPlanUtilisation] = useState<string>("1_month");
  const [selectedPlanProvider, setSelectedPlanProvider] = useState<string>("");
  const [isSmallMediumScreen, setIsSmallMediumScreen] = useState<boolean>(false);
  const [hoveredBarIndex, setHoveredBarIndex] = useState<number | null>(null);
  const [showRedirectNotification, setShowRedirectNotification] = useState<boolean>(false);
  // NEW: Service Provider and Billing Cycle states
const [serviceProviders, setServiceProviders] = useState<string[]>([]);
const [selectedServiceProvider, setSelectedServiceProvider] = useState<string>("All service providers");
const [billingCyclePeriods, setBillingCyclePeriods] = useState<string[]>([]);
const [selectedBillingCyclePeriod, setSelectedBillingCyclePeriod] = useState<string>("");
const [showBillingCyclePeriod, setShowBillingCyclePeriod] = useState<boolean>(false);
const [serviceProviderData, setServiceProviderData] = useState<ServiceProviderData | null>(null);
// ✅ ADD THIS STATE FOR AUTO-EXPANSION
const [isExpanded, setIsExpanded] = useState<boolean>(false);
const [hoveredBubble, setHoveredBubble] = useState<string | null>(null);
const [hoveredRectangle, setHoveredRectangle] = useState<string | null>(null);

const [features, setFeatures] = useState<any[]>([])
// const [selectedByteUnit, setSelectedByteUnit] = useState<ByteUnit>('GB');
const [selectedByteUnit, setSelectedByteUnit] = useState<"GB" | "MB" | "KB">("GB");

  useEffect(() => {
    const handleResize = () => {
      setIsSmallMediumScreen(window.innerWidth <= 1000);
    };
    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  // ✅ ADD CLEAR FILTERS EFFECT
  useEffect(() => {
    return () => {
      clearFilters();
    };
  }, [clearFilters]);

  // Sync internal filters with global filter selection
useEffect(() => {
  console.log(`=== GLOBAL FILTER SYNC ===`);
  console.log(`Selected Button: ${selectedButton}, Start Date: ${startDate}, End Date: ${endDate}`);

  if (selectedButton) {
    const internalFilter = mapGlobalDateToInternalFilter(selectedButton);
    console.log(`Mapping global filter ${selectedButton} to internal filter ${internalFilter}`);
    
    setInternalFilterUsageTrend(internalFilter);
    setInternalFilterServiceType(internalFilter);
    setInternalFilterUsageByCarrier(internalFilter);
    setInternalFilterPlanUtilisation(internalFilter);
    setUseCache(false);
    clearFilters();
    
    fetchChartData(startDate, endDate, false);
  } else if (startDate && endDate) {
    setUseCache(false);
    fetchChartData(startDate, endDate, false);
  }
}, [selectedButton, startDate, endDate]);

// Effect for service provider/billing cycle changes
useEffect(() => {
  if (
    selectedTenantId &&
    ((selectedServiceProvider !== "All service providers" && selectedBillingCyclePeriod) ||
      selectedServiceProvider === "All service providers")
  ) {
     fetchChartData("", "", true);
  }
}, [selectedServiceProvider, selectedBillingCyclePeriod, selectedTenantId]);

// ✅ AUTO-EXPANSION LOGIC - Add this useEffect
useEffect(() => {
  const filterToUseUsageTrend = getActualFilterFromData(useCache ? cachedData.usageTrend : chartData.usageTrend, internalFilterUsageTrend);
  const filterToUseServiceType = getActualFilterFromData(useCache ? cachedData.serviceTypeUsage : chartData.serviceTypeUsage, internalFilterServiceType);
  const filterToUseUsageByCarrier = getActualFilterFromData(useCache ? cachedData.usageByCarrier : chartData.usageByCarrier, internalFilterUsageByCarrier);
  // FIXED: Include Plan Utilisation in auto-expansion check
  const filterToUsePlanUtilisation = getActualFilterFromData(useCache ? cachedData.planUtilisation : chartData.planUtilisation, internalFilterPlanUtilisation);
  console.log("=== AUTO-EXPANSION EFFECT TRIGGERED ===",filterToUseUsageTrend, filterToUseServiceType, filterToUseUsageByCarrier, filterToUsePlanUtilisation);
  const shouldExpand =
    ["3_month", "6_month", "1_year"].includes(filterToUseUsageTrend) ||
    ["3_month", "6_month", "1_year"].includes(filterToUseServiceType) ||
    ["3_month", "6_month", "1_year"].includes(filterToUseUsageByCarrier) ||
    ["3_month", "6_month", "1_year"].includes(filterToUsePlanUtilisation); // FIXED: Added this line

  console.log("🔄 Auto-expansion check:", {
    filterToUseUsageTrend,
    filterToUseServiceType,
    filterToUseUsageByCarrier,
    filterToUsePlanUtilisation, // FIXED: Added this
    shouldExpand,
    currentIsExpanded: isExpanded
  });

  setIsExpanded(shouldExpand);
}, [
  useCache ? cachedData.usageTrend : chartData.usageTrend,
  useCache ? cachedData.serviceTypeUsage : chartData.serviceTypeUsage,
  useCache ? cachedData.usageByCarrier : chartData.usageByCarrier,
  useCache ? cachedData.planUtilisation : chartData.planUtilisation, // FIXED: Added this dependency
  internalFilterUsageTrend,
  internalFilterServiceType,
  internalFilterUsageByCarrier,
  internalFilterPlanUtilisation, // FIXED: Added this dependency
  useCache
]);


  // Helper function to get date range based on internal filter
const getDateRangeFromFilter = (filter: string): { start_date: string; end_date: string } => {
  const now = moment();
  
  switch (filter) {
    case "1_day":
      return {
        start_date: now.format("YYYY-MM-DD"),
        end_date: now.format("YYYY-MM-DD")
      };
    case "5_day":
      return {
        start_date: now.subtract(4, 'days').format("YYYY-MM-DD"),
        end_date: moment().format("YYYY-MM-DD")
      };
    case "1_month":
      return {
        start_date: now.startOf('month').format("YYYY-MM-DD"),
        end_date: moment().endOf('month').format("YYYY-MM-DD")
      };
    case "3_month": // ✅ ADD THIS
      return {
        start_date: now.subtract(2, 'months').startOf('month').format("YYYY-MM-DD"),
        end_date: moment().endOf('month').format("YYYY-MM-DD")
      };
    case "6_month": // ✅ ADD THIS
      return {
        start_date: now.subtract(5, 'months').startOf('month').format("YYYY-MM-DD"),
        end_date: moment().endOf('month').format("YYYY-MM-DD")
      };
    case "1_year":
      return {
        start_date: now.startOf('year').format("YYYY-MM-DD"),
        end_date: moment().endOf('year').format("YYYY-MM-DD")
      };
    case "5_years":
      return {
        start_date: now.subtract(4, 'years').startOf('year').format("YYYY-MM-DD"),
        end_date: moment().endOf('year').format("YYYY-MM-DD")
      };
    case "max":
      return {
        start_date: "2020-01-01",
        end_date: moment().format("YYYY-MM-DD")
      };
    default:
      return {
        start_date: startDate || moment().startOf('month').format("YYYY-MM-DD"),
        end_date: endDate || moment().endOf('month').format("YYYY-MM-DD")
      };
  }
};


  // ✅ ENHANCED CLICK HANDLER WITH SETREDIRECTED CALLS
  const handleChartClick = (
  data: any,
  chartType: 'usageTrend' | 'serviceType' | 'usageByCarrier' | 'planUtilisation',
  timeData?: any
) => {
  console.log("=== USAGE CHART CLICK HANDLER START ===");
  console.log("Chart type:", chartType);
  console.log("Clicked data:", data);
  console.log("Time data:", timeData);
  console.log("Current partner:", partner);
  console.log("Selected filter:", selectedFilter);

  if (selectedFilter !== partner) {
    console.log("⚠️ Redirection blocked: Selected partner doesn't match current partner");
    setRedirected(false);
    return;
  }

  // For time-based redirection, we need time information
  if (!timeData || !timeData.time) {
    console.log("⚠️ No valid time data to process");
    setRedirected(false);
    return;
  }

  setShowRedirectNotification(true);

  let currentFilter: string;

  switch (chartType) {
    case 'usageTrend':
      currentFilter = internalFilterUsageTrend;
      break;
    case 'serviceType':
      currentFilter = internalFilterServiceType;
      break;
    case 'usageByCarrier':
      currentFilter = internalFilterUsageByCarrier;
      break;
    case 'planUtilisation':
      currentFilter = internalFilterPlanUtilisation;
      break;
    default:
      currentFilter = internalFilterUsageTrend;
  }

  // Convert time-based data to date range for filtering
  const dateRange = convertTimeToDateRange(timeData.time, currentFilter);

  let filtersPayload: any = {};

  // For usage insights, we'll use created_date for all charts
  filtersPayload.created_date = [`${dateRange.start_date}:${dateRange.end_date}`];

  console.log("Filter payload:", filtersPayload);

  sessionStorage.setItem('inventoryRedirected', 'true');

  setFilters(filtersPayload);
  setRedirected(true);

  setTimeout(() => {
    setShowRedirectNotification(false);
    router.push('sim_management/inventory');
  }, 1000);
};

// 2. ADD this new helper function (add after handleChartClick function)
const convertTimeToDateRange = (timeLabel: string, filter: string): { start_date: string; end_date: string } => {
  const now = moment();

  if (filter === "1_day") {
    // timeLabel format: "14:00" or "00:00 - 03:59" (time range)
    if (timeLabel.includes(' - ')) {
      // Handle time range format
      const [startTime] = timeLabel.split(' - ');
      const [hour] = startTime.split(':');
      const targetDate = now.clone().hour(parseInt(hour)).minute(0).second(0);
      return {
        start_date: targetDate.format("YYYY-MM-DD HH:00:00"),
        end_date: targetDate.clone().add(4, 'hours').format("YYYY-MM-DD HH:00:00")
      };
    } else {
      // Handle single hour format
      const [hour] = timeLabel.split(':');
      const targetDate = now.clone().hour(parseInt(hour)).minute(0).second(0);
      return {
        start_date: targetDate.format("YYYY-MM-DD HH:00:00"),
        end_date: targetDate.clone().add(1, 'hour').format("YYYY-MM-DD HH:00:00")
      };
    }
  } else if (filter === "5_day") {
    // timeLabel format: "Dec 15" (month day)
    const targetDate = moment(timeLabel + " " + now.year(), "MMM DD YYYY");
    return {
      start_date: targetDate.format("YYYY-MM-DD"),
      end_date: targetDate.format("YYYY-MM-DD")
    };
  } else if (filter === "1_month") {
    // timeLabel format: "W1", "W2", etc.
    const weekNumber = parseInt(timeLabel.replace('W', ''));
    const monthStart = now.clone().startOf('month');
    const weekStart = monthStart.clone().add((weekNumber - 1) * 7, 'days');
    const weekEnd = weekStart.clone().add(6, 'days').endOf('day');
    
    return {
      start_date: weekStart.format("YYYY-MM-DD"),
      end_date: weekEnd.format("YYYY-MM-DD")
    };
  } else if (["3_month", "6_month", "1_year"].includes(filter)) {
    // timeLabel format: "00-W1" (month-week)
    const [monthIndex, weekPart] = timeLabel.split('-W');
    const weekNumber = parseInt(weekPart);
    const targetMonth = parseInt(monthIndex);
    
    const monthStart = moment().month(targetMonth).startOf('month');
    const weekStart = monthStart.clone().add((weekNumber - 1) * 7, 'days');
    const weekEnd = weekStart.clone().add(6, 'days').endOf('day');
    
    return {
      start_date: weekStart.format("YYYY-MM-DD"),
      end_date: weekEnd.format("YYYY-MM-DD")
    };
  } else if (filter === "5_years" || filter === "max") {
    // timeLabel format: "2024" (year)
    const year = parseInt(timeLabel);
    return {
      start_date: `${year}-01-01`,
      end_date: `${year}-12-31`
    };
  } else {
    // Default fallback
    return {
      start_date: now.clone().subtract(1, 'day').format("YYYY-MM-DD"),
      end_date: now.format("YYYY-MM-DD")
    };
  }
};

  // Enhanced CustomTooltip matching SimsOverview styling with correct total calculation and click functionality
 const CustomTooltip: React.FC<CustomTooltipProps> = ({ active, payload, label, details, isStatusChart, chartType }) => {
  if (!active || !payload || !payload.length || !label || !details) {
    return null;
  }

  const provider = label;
  if (!provider || typeof provider !== 'string') {
    return null;
  }

  const providerDetails = details[provider];
  if (!providerDetails) {
    return null;
  }

  const correctTotal = Object.values(providerDetails).reduce((sum, value) => sum + (value as number), 0);
  const canRedirect = selectedFilter === partner && chartType && chartType !== 'planUtilisation';

  return (
    <div
      style={{
        backgroundColor: 'white',
        border: '1px solid #ccc',
        borderRadius: '4px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
        padding: '6px 8px',
        maxWidth: '250px',
        maxHeight: '300px',
        overflow: 'auto',
        fontSize: '12px',
        zIndex: 1000
      }}
    >
      <div style={{ fontWeight: 'bold', marginBottom: '4px', color: '#333' }}>
        {provider}
      </div>
      {canRedirect && (
        <div style={{ fontSize: '10px', color: '#666', marginBottom: '4px' }}>
          <ArrowTopRightOnSquareIcon style={{ width: '12px', height: '12px', display: 'inline', marginRight: '2px' }} />
        </div>
      )}
      <div style={{ marginBottom: '4px' }}>
        {payload[0].dataKey === 'usage' ? `Total: ${correctTotal.toFixed(2)}` :
        payload[0].dataKey === 'percentage' ? `Total: ${correctTotal.toFixed(1)}%` :
        `Total: ${correctTotal}`}
      </div>
      <div style={{ maxHeight: '150px', overflow: 'auto' }}>
        {Object.entries(providerDetails)
          .sort(([dateA], [dateB]) => dateA.localeCompare(dateB))
          .map(([date, value]) =>
            (value as number) > 0 ? (
              <div key={date} style={{ fontSize: '11px', marginBottom: '2px' }}>
                {date}: {(value as number).toFixed(2)}
              </div>
            ) : null
          )}
      </div>
      {canRedirect && (
        <div style={{ fontSize: '10px', color: '#666', marginTop: '4px' }}>
          Click to view details in Inventory
        </div>
      )}
    </div>
  );
};


  // Add redirect notification components
  const renderRedirectNotification = () => {
    if (!showRedirectNotification) return null;

    return (
      <div 
        style={{
          position: 'fixed',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          backgroundColor: 'white',
          padding: '20px 30px',
          borderRadius: '8px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
          zIndex: 9999,
          display: 'flex',
          alignItems: 'center',
          gap: '12px',
          border: '1px solid #e5e7eb'
        }}
      >
        <Spin size="small" />
        <span style={{ 
          fontFamily: 'Calibri, sans-serif', 
          fontSize: '16px',
          fontWeight: '500',
          color: '#374151'
        }}>
          Redirecting to Inventory...
        </span>
      </div>
    );
  };

  const renderRedirectOverlay = () => {
    if (!showRedirectNotification) return null;

    return (
      <div
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.3)',
          zIndex: 9998
        }}
      />
    );
  };

  const fetchFilterOptions = async () => {
    try {
      const url = ENV_ROUTES.DASHBOARD;
      const data = {
        tenant_name: partner || "default_value",
        username,
        firstLastName,
        path: "/get_all_related_tenants",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Dashboard",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (!parsedData.flag || !parsedData.data) {
        console.warn("Invalid filter options response:", parsedData);
        setFilterOptions({ options: [] });
        setSelectedFilter("");
        setSelectedTenantId("");
        return;
      }

      const serviceProviders: FilterOption[] = Object.entries(parsedData.data)
      .map(([key, value]) => ({
        value: key.trim(),
        label: key.trim(),
        tenant_id: String(value),
      }))
      .sort((a, b) => a.label.localeCompare(b.label));


      setFilterOptions({ options: serviceProviders });

      const partnerOption = serviceProviders.find((option) => option.value === partner);
      console.log("partnerOption..", partnerOption);
      if (partnerOption) {
      setSelectedFilter(partnerOption.value);
      setSelectedTenantId(partnerOption.tenant_id);
        localStorage.setItem("selectedTenantId", partnerOption.tenant_id);
    } else if (serviceProviders.length > 0) {
      setSelectedFilter(serviceProviders[0].value);
      setSelectedTenantId(serviceProviders[0].tenant_id);
       localStorage.setItem(
    "selectedTenantId",
    serviceProviders[0].tenant_id
  );
    }

    } catch (error) {
    console.error("Error fetching filter options:", error);
    // Graceful fallback: empty options
    setFilterOptions({ options: [] });
    setSelectedFilter("");
    setSelectedTenantId("");
  }
  };
  // Function to fetch service providers and billing cycle data
const fetchServiceProviderData = async () => {
  try {
    const url = ENV_ROUTES.DASHBOARD;
    const data = {
      tenant_name: partner || "default_value",
      username,
      firstLastName,
      path: "/get_all_service_providers_and_billing_cycle_dates_dropdown_data",
      role_name: role,
      parent_module: "Sim Management",
      module_name: "Dashboard",
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
        tenant_id: selectedTenantId,
    };

    const response = await axios.post(url, { data });
    const parsedData = JSON.parse(response.data.body);

    if (
  !parsedData.flag ||
  !Array.isArray(parsedData.unique_service_providers) ||
  parsedData.unique_service_providers.length === 0
){
      console.warn("Invalid service provider response:", parsedData);
      setServiceProviders(["All service providers"]);
      setSelectedServiceProvider("All service providers");
      return;
    }

    const providers = parsedData.unique_service_providers;
    setServiceProviders(providers);
    setServiceProviderData(parsedData);
    setSelectedServiceProvider("All service providers");
    setShowBillingCyclePeriod(false);
    setSelectedBillingCyclePeriod("");

  } catch (error) {
    console.error("Error fetching service provider data:", error);
    setServiceProviders(["All service providers"]);
    setSelectedServiceProvider("All service providers");
  }
};

// Handle service provider change
const handleServiceProviderChange = async (value: string) => {
  console.log("=== SERVICE PROVIDER CHANGE ===");
  console.log("Selected service provider:", value);

  setSelectedServiceProvider(value);

  if (value === "All service providers") {
    setShowBillingCyclePeriod(false);
    setSelectedBillingCyclePeriod("");
    setBillingCyclePeriods([]);

    // const defaultStart = moment().startOf("month").format("YYYY-MM-DD");
    // const defaultEnd = moment().format("YYYY-MM-DD");
    // setSelectedButton("Current Month");
    // setStartDate("");
    // setEndDate("");
    // setDateRange([dayjs(defaultStart), dayjs(defaultEnd)]);

  } else {
    setShowBillingCyclePeriod(true);
    
    if (serviceProviderData?.billing_period_dates[value]) {
      const periods = serviceProviderData.billing_period_dates[value];
      setBillingCyclePeriods(["None", ...periods]);
      setSelectedBillingCyclePeriod(periods[0] || "");
    }
    // setStartDate("");
    // setEndDate("");
    // setDateRange([null, null]);
  }
    setSelectedButton(null); // Removes Today/Week/Month selection

  // Reset filters and fetch new data
  setInternalFilterUsageTrend("1_month");
  setInternalFilterServiceType("1_month");
  setInternalFilterUsageByCarrier("1_month");
  setInternalFilterPlanUtilisation("1_month");
  setUseCache(false);
  //  ✅ Clear date filters when billing cycle changed
    setStartDate("");
    setEndDate("");
    setDateRange([null, null]);
  

  // Clear cache
  localStorage.removeItem("usage_trend_cache");
  localStorage.removeItem("service_type_cache");
  localStorage.removeItem("usage_by_carrier_cache");
  localStorage.removeItem("plan_utilisation_cache");

  clearFilters();
};

// Handle billing cycle period change
const handleBillingCyclePeriodChange = async (value: string) => {
  console.log("=== BILLING CYCLE PERIOD CHANGE ===");
  console.log("Selected billing cycle period:", value);

  setSelectedBillingCyclePeriod(value);
   // ✅ Clear date filters when billing cycle changed
    setStartDate("");
    setEndDate("");
    setDateRange([null, null]);
  setUseCache(false);
    if(value === "None"){
      setSelectedButton("Current Month");
    }
    else{
      setSelectedButton(null)
    }


  // Clear cache
  localStorage.removeItem("usage_trend_cache");
  localStorage.removeItem("service_type_cache");
  localStorage.removeItem("usage_by_carrier_cache");
  localStorage.removeItem("plan_utilisation_cache");

  clearFilters();

  if (selectedTenantId) {
    // await fetchChartData("", "", true);
  }
};

// Function to map global date filters to internal filters
const mapGlobalDateToInternalFilter = (globalFilter: string): string => {
  console.log(`Mapping global filter: ${globalFilter}`);
  switch (globalFilter) {
    case "Today":
      return "1_day";
    case "Current Week":
      return "5_day";
    case "Current Month":
      return "1_month";
    default:
      console.warn(`Unknown global filter: ${globalFilter}, defaulting to 1_month`);
      return "1_month";
  }
};
// **KEY FIX: Function to dynamically determine the correct filter from available data**
// 1. FIX: Enhanced getActualFilterFromData function (replace existing one)
const getActualFilterFromData = (data: any, internalFilter: string): string => {
  console.log("=== GET ACTUAL FILTER FROM DATA ===");
  console.log("Internal filter requested:", internalFilter);
  console.log("Available data:", data?.data?.data ? Object.keys(data.data.data) : 'No data');

  // ALWAYS return the requested internal filter for UI consistency
  // This ensures the filter buttons show the correct active state
  // regardless of data availability
  return internalFilter;
};

// 2. FIX: Enhanced sync between global and internal filters (replace existing useEffect)

const fetchChartData = async (startDate: string, endDate: string, cacheData: boolean = false) => {
  if (!selectedTenantId) {
    console.warn("No tenant_id set, skipping chart data fetch");
    return;
  }

  const url = ENV_ROUTES.DASHBOARD;
  const serviceProvidersFilter = selectedFilter === "All Tenants" ? "All" : selectedFilter;

  const baseRequestData = {
    partner,
    tenant_name: partner || "default_value",
    username,
    role_name: role,
    request_received_at: getCurrentDateTime(),
    access_token: token,
    db_name: selectedDb,
    ...metaData,
    sessionID: sessionId,
    start_date: startDate,
    end_date: endDate,
    tenant_id: selectedTenantId,
    service_provider: selectedServiceProvider === "All service providers" ? "" : selectedServiceProvider,
    billing_cycle_end_period: selectedBillingCyclePeriod === "None" || selectedServiceProvider === "All service providers" ? "" : selectedBillingCyclePeriod,
  };

  const fetchDataForPath = async (path: string) => {
    try {
      const response = await axios.post(url, {
        data: { ...baseRequestData, path },
      });
      const parsedResponse = JSON.parse(response.data.body);
      return parsedResponse;
    } catch (error) {
      console.error(`Error fetching data for ${path}:`, error);
      return null;
    }
  };

  try {
    setLoadingUsageTrend(true);
    setLoadingServiceTypeUsage(true);
    setLoadingUsageByCarrier(true);
    setLoadingPlanUtilisation(true);

    const [usageTrend, serviceTypeUsage, usageByCarrier, planUtilisation] = await Promise.all([
      fetchDataForPath("/get_usage_trend_by_provider"),
      fetchDataForPath("/get_service_type_usage_distribution"),
      fetchDataForPath("/get_usage_by_carrier_weekly_distribution"),
      fetchDataForPath("/get_plan_utilisation_summary"),
    ]);

    const newChartData = {
      usageTrend: usageTrend?.flag ? usageTrend : null,
      serviceTypeUsage: serviceTypeUsage?.flag ? serviceTypeUsage : null,
      usageByCarrier: usageByCarrier?.flag ? usageByCarrier : null,
      planUtilisation: planUtilisation?.flag ? planUtilisation : null,
    };

    if (cacheData) {
      setCachedData(newChartData);
      localStorage.setItem("usage_trend_cache", JSON.stringify({
        ...newChartData.usageTrend,
        lastUpdated: new Date().toISOString()
      }));
      localStorage.setItem("service_type_cache", JSON.stringify({
        ...newChartData.serviceTypeUsage,
        lastUpdated: new Date().toISOString()
      }));
      localStorage.setItem("usage_by_carrier_cache", JSON.stringify({
        ...newChartData.usageByCarrier,
        lastUpdated: new Date().toISOString()
      }));
      localStorage.setItem("plan_utilisation_cache", JSON.stringify({
        ...newChartData.planUtilisation,
        lastUpdated: new Date().toISOString()
      }));
      setChartData(newChartData);
    } else {
      setChartData(newChartData);
    }
  } catch (error) {
    console.error("Error fetching chart data:", error);
  } finally {
    setLoadingUsageTrend(false);
    setLoadingServiceTypeUsage(false);
    setLoadingUsageByCarrier(false);
    setLoadingPlanUtilisation(false);
  }
};

  const checkCacheValidity = () => {
    const caches = ["usage_trend_cache", "service_type_cache", "usage_by_carrier_cache", "plan_utilisation_cache"];
    return caches.every(cacheKey => {
      const cached = localStorage.getItem(cacheKey);
      if (!cached) return false;
      const { lastUpdated } = JSON.parse(cached);
      const lastUpdatedDate = new Date(lastUpdated);
      const now = new Date();
      const hoursDiff = (now.getTime() - lastUpdatedDate.getTime()) / (1000 * 60 * 60);
      return hoursDiff < 24;
    });
  };

  const initializeDashboard = async () => {
    setSelectedPartner(true);
    setSelectedButton("Current Month");
    setSelectedByteUnit("GB");
    setDateRange([null, null]);
    setLoading(true);
    try {
      await fetchFilterOptions();
      //  await fetchServiceProviderData(); // NEW: Fetch service provider data
      if (selectedTenantId) {
        const isCacheValid = checkCacheValidity();
        // if (isCacheValid) {
        //   const usageTrend = JSON.parse(localStorage.getItem("usage_trend_cache") || "{}");
        //   const serviceType = JSON.parse(localStorage.getItem("service_type_cache") || "{}");
        //   const usageByCarrier = JSON.parse(localStorage.getItem("usage_by_carrier_cache") || "{}");
        //   const planUtilisation = JSON.parse(localStorage.getItem("plan_utilisation_cache") || "{}");
        //   setCachedData({
        //     usageTrend: usageTrend,
        //     serviceTypeUsage: serviceType,
        //     usageByCarrier: usageByCarrier,
        //     planUtilisation: planUtilisation,
        //   });
        //   setChartData({
        //     usageTrend: usageTrend,
        //     serviceTypeUsage: serviceType,
        //     usageByCarrier: usageByCarrier,
        //     planUtilisation: planUtilisation,
        //   });
        //   setUseCache(true);
        // } else {
          await fetchChartData("", "", true);
        // }
      }
    } catch (error) {
      console.error("Error during initialization:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    initializeDashboard();
  }, [partner]);

  useEffect(() => {
    if (selectedTenantId && !useCache) {
      localStorage.removeItem("usage_trend_cache");
      localStorage.removeItem("service_type_cache");
      localStorage.removeItem("usage_by_carrier_cache");
      localStorage.removeItem("plan_utilisation_cache");
      fetchChartData("", "", true);
    }
  }, [selectedTenantId]);
// Add this useEffect in your main UsageInsights component
useEffect(() => {
  // Only reset if we don't have a valid selection
  if (chartData.planUtilisation || cachedData.planUtilisation) {
    const dataSource = useCache ? cachedData : chartData;
    const filterToUse = getActualFilterFromData(dataSource.planUtilisation, internalFilterPlanUtilisation);
    
    if (filterToUse !== "no_data" && dataSource.planUtilisation) {
      const { providers: availableProviders } = processPlanUtilisationData(
        dataSource.planUtilisation, 
        filterToUse, 
        selectedTenantId, 
        "All" // ✅ Pass "All" to get all providers
      );
      
      // ✅ Only set default if no provider is selected yet
      if (availableProviders.length > 0) {
        setSelectedPlanProvider(availableProviders[0]); // Always update when filter changes
      }

    }
  }
}, [
  chartData.planUtilisation, 
  cachedData.planUtilisation, 
  internalFilterPlanUtilisation, 
  selectedTenantId,
  useCache
]);

useEffect(() => {
  if (!selectedTenantId) return;

  // Reset provider-related UI
  setServiceProviders([]);
  setSelectedServiceProvider("All service providers");
  setBillingCyclePeriods([]);
  setShowBillingCyclePeriod(false);
  setServiceProviderData(null);

  fetchServiceProviderData();
}, [selectedTenantId]);

  // ✅ ENHANCED FILTER CHANGE HANDLER WITH CLEAR FILTERS
  const handleFilterChange = async (value: string) => {
    const selectedOption = filterOptions.options.find((option) => option.value === value);
    
    if (selectedOption) {
      setSelectedFilter(selectedOption.value);
      setSelectedTenantId(selectedOption.tenant_id);
      setInternalFilterUsageTrend("1_month");
      setInternalFilterServiceType("1_month");
      setInternalFilterUsageByCarrier("1_month");
      setInternalFilterPlanUtilisation("1_month");
      setSelectedPlanProvider("");
      setChartData(prev => ({ ...prev, planUtilisation: null }));
      setStartDate("");
      setEndDate("");
      setDateRange([null, null]);
      setSelectedButton("Current Month");
      setUseCache(false);
      localStorage.removeItem("usage_trend_cache");
      localStorage.removeItem("service_type_cache");
      localStorage.removeItem("usage_by_carrier_cache");
      localStorage.removeItem("plan_utilisation_cache");
      
      // ✅ CLEAR ANY PREVIOUS REDIRECT FILTERS WHEN CHANGING DASHBOARD FILTERS
      clearFilters();
      
    // await fetchChartData("", "", true);

    const defaultStart = (moment().startOf("month").format("YYYY-MM-DD"));
    const defaultEnd = (moment().format("YYYY-MM-DD"));
    setStartDate(defaultStart);
    setEndDate(defaultEnd);
    }
  };

  const handleButtonClick = (range: "Today" | "Current Week" | "Current Month") => {
    setSelectedButton(range);
    
    let newStartDate: string;
    let newEndDate: string;

    if (range === "Today") {
      newStartDate = moment().format("YYYY-MM-DD");
      newEndDate = moment().format("YYYY-MM-DD");
    } else if (range === "Current Week") {
      newStartDate = moment().startOf("week").format("YYYY-MM-DD");
      newEndDate = moment().endOf("week").format("YYYY-MM-DD");
    } else {
      newStartDate = moment().subtract(30, "days").format("YYYY-MM-DD");
      newEndDate = moment().format("YYYY-MM-DD");
    }

    setStartDate(newStartDate);
    setEndDate(newEndDate);
    setDateRange([dayjs(newStartDate), dayjs(newEndDate)]);
    setInternalFilterUsageTrend("1_month");
setInternalFilterServiceType("1_month");
setInternalFilterUsageByCarrier("1_month");
setInternalFilterPlanUtilisation("1_month");
    setUseCache(false);
    fetchChartData(newStartDate, newEndDate, false);
  };


// const detectClosestFilter = (startDate: string, endDate: string): string => {
//   const start = moment(startDate);
//   const end = moment(endDate);
//   const oneYearBack = moment().subtract(1, "year");

//     // If selected range goes beyond 1 year back → force 5_years
//     if (start.isBefore(oneYearBack, "day") || end.isBefore(oneYearBack, "day")) {
//       return "5_years";
//     }

//   if (start.isSame(end, "day")) return "1_day";

//   const diffDays = end.diff(start, "days");

//   if (diffDays <= 4) return "5_day";
//   if (diffDays <= 31) return "1_month";    // 👈 NEW LOGIC HERE
//   if (diffDays <= 90) return "3_month";
//   if (diffDays <= 180) return "6_month";
//   if (diffDays <= 365) return "1_year";

//   const diffYears = end.diff(start, "years", true);
//   if (diffYears < 5) return "5_years";

//   return "max";
// };
const detectClosestFilter = (startDate: string, endDate: string): string => {
  const start = moment(startDate);
  const end = moment(endDate);
  const oneYearBack = moment().subtract(1, "year");

  // If selected range goes beyond 1 year back → force 5_years
  // if (start.isBefore(oneYearBack, "day") || end.isBefore(oneYearBack, "day")) {
  //   return "5_years";
  // }

  if (!start.isValid() || !end.isValid()) return "1_month";
  if (end.isBefore(start)) return "1_month";

  const diffDays = end.diff(start, "days");
  const diffYears = end.diff(start, "years", true);

  if (diffDays === 0) return "1_day";
  if (diffDays <= 4) return "5_day";
  if (diffDays <= 31) return "1_month";
  if (diffDays <= 92) return "3_month";
  if (diffDays <= 183) return "6_month";
  if (diffDays <= 366) return "1_year";
  if (diffYears <= 5) return "5_years";

  return "max";
};



//   const handleDateRangeChange = (
//     dates: [Dayjs | null, Dayjs | null] | null,
//     dateStrings: [string, string]
//   ) => {
//     let applied_filter
//     setSelectedButton(null);
//     if (dates && dates[0] && dates[1]) {
//       setDateRange([dates[0], dates[1]]);
//       const newStartDate = dates[0].format("YYYY-MM-DD");
//       const newEndDate = dates[1].format("YYYY-MM-DD");
//       setStartDate(newStartDate);
//       setEndDate(newEndDate);
//        // ⭐ RESET ALL INTERNAL FILTERS BACK TO "1M" ⭐
//  setInternalFilterUsageTrend("1_month");
// setInternalFilterServiceType("1_month");
// setInternalFilterUsageByCarrier("1_month");
// setInternalFilterPlanUtilisation("1_month");

//       setUseCache(false);
//       fetchChartData(newStartDate, newEndDate, false);
//       applied_filter = detectClosestFilter(newStartDate,newEndDate)
//       console.clear()
//       console.error("applied_filter",applied_filter,newStartDate,newEndDate)
//     } else {
//       setDateRange([null, null]);
//       setSelectedButton("Current Month");
//       const newStartDate = moment().subtract(30, "days").format("YYYY-MM-DD");
//       const newEndDate = moment().format("YYYY-MM-DD");
//       setStartDate(newStartDate);
//       setEndDate(newEndDate);
//       setUseCache(false);
//       fetchChartData(newStartDate, newEndDate, false);
//       applied_filter = detectClosestFilter(newStartDate,newEndDate)
//       console.clear()
//       console.error("applied_filter",applied_filter,newStartDate,newEndDate)
//     }
//     setInternalFilterUsageTrend(applied_filter);
//     setInternalFilterServiceType(applied_filter);
//     setInternalFilterUsageByCarrier(applied_filter);
//     setInternalFilterPlanUtilisation(applied_filter);
//   };

//  const handleInternalFilterChange = (chart: string, filter: string) => {
//   console.log(`=== HANDLE INTERNAL FILTER CHANGE ===`);
//   console.log(`Chart: ${chart}, Filter: ${filter}`);

//   // Update filter state
//   if (chart === "usageTrend") {
//     setInternalFilterUsageTrend(filter);
//   } else if (chart === "serviceType") {
//     setInternalFilterServiceType(filter);
//   } else if (chart === "usageByCarrier") {
//     setInternalFilterUsageByCarrier(filter);
//   } else if (chart === "planUtilisation") {
//     setInternalFilterPlanUtilisation(filter);
//   }

//   if (cachedData?.usageTrend || cachedData?.serviceTypeUsage || cachedData?.usageByCarrier || cachedData?.planUtilisation) {
//     console.log(`Using cached data for ${chart}`);
//     setChartData(cachedData);
//     setUseCache(true);
//   } else {
//     console.log(`No cached data available for ${chart}, showing empty state`);
//     // just reset chartData to an empty object (valid type)
//     setChartData({} as UsageChartData);
//     setUseCache(true);
//   }
// };
const handleDateRangeChange = (
  dates: [Dayjs | null, Dayjs | null] | null,
  dateStrings: [string, string]
) => {
  setSelectedButton(null);

  let newStartDate: string;
  let newEndDate: string;

  if (dates && dates[0] && dates[1]) {
    setDateRange([dates[0], dates[1]]);
    newStartDate = dates[0].format("YYYY-MM-DD");
    newEndDate = dates[1].format("YYYY-MM-DD");
  } else {
    setDateRange([null, null]);
    setSelectedButton("Current Month");
    newStartDate = moment().subtract(30, "days").format("YYYY-MM-DD");
    newEndDate = moment().format("YYYY-MM-DD");
  }

  setStartDate(newStartDate);
  setEndDate(newEndDate);

  // 🔑 Detect closest filter ONCE
  const applied_filter = detectClosestFilter(newStartDate, newEndDate);

  // 🔥 Apply detected filter (includes 1_month naturally)
  setInternalFilterUsageTrend(applied_filter);
  setInternalFilterServiceType(applied_filter);
  setInternalFilterUsageByCarrier(applied_filter);
  setInternalFilterPlanUtilisation(applied_filter);

  setUseCache(false);
  fetchChartData(newStartDate, newEndDate, false);

  console.log("applied_filter:", applied_filter);
};

const handleInternalFilterChange = (chart: string, filter: string) => {
  console.log(`=== HANDLE INTERNAL FILTER CHANGE ===`);
  console.log(`Chart: ${chart}, Filter: ${filter}`);

  // Update only the selected chart internal filter
  if (chart === "usageTrend") {
    setInternalFilterUsageTrend(filter);
  } else if (chart === "serviceType") {
    setInternalFilterServiceType(filter);
  } else if (chart === "usageByCarrier") {
    setInternalFilterUsageByCarrier(filter);
  } else if (chart === "planUtilisation") {
    setInternalFilterPlanUtilisation(filter);
  }

  // Mapping to correct key in cachedData
  const chartMap: Record<string, keyof UsageChartData> = {
    usageTrend: "usageTrend",
    serviceType: "serviceTypeUsage",
    usageByCarrier: "usageByCarrier",
    planUtilisation: "planUtilisation",
  };

  const targetKey = chartMap[chart];

  if (!targetKey) {
    console.warn("Unknown chart key: ", chart);
    return;
  }

  // Update only the target chart — keep others as-is
  setChartData((prev) => ({
    ...prev,
    [targetKey]: cachedData?.[targetKey] || null
  }));

  setUseCache(true);
};


  const processUsageData = (data: any, filter: string, tenantId: string): ProcessedUsageData => {
    if (!data?.data?.data?.[filter] || !data?.meta?.providers) {
      return { chartData: [], details: {} };
    }

    const providers = data.meta.providers as { [key: string]: string };
    const serviceProviderMap: { [key: string]: number } = {};
    const details: { [provider: string]: { [date: string]: number } } = {};

    let filteredData = data.data.data[filter];
    
    if (tenantId !== "All") {
      filteredData = filteredData.filter((item: any) => String(item.tenant_id) === tenantId);
    }

    filteredData.forEach((item: any) => {
      const providerId = item.provider_id === null ? "null" : String(item.provider_id);
      const providerName = providers[providerId];
      
      if (!providerName) return;

      item.records?.forEach((record: any) => {
        let date: string, usage: number;
        
        if (Array.isArray(record)) {
          date = record[0];
          usage = Number(record[1]) || 0;
        } else if (typeof record === "object" && record !== null) {
          date = Object.keys(record)[0];
          usage = Number(record[date]) || 0;
        } else {
          return;
        }

        const formattedDate = formatDateForTooltip(date);
        
        serviceProviderMap[providerName] = (serviceProviderMap[providerName] || 0) + usage;
        
        if (!details[providerName]) {
          details[providerName] = {};
        }
        details[providerName][formattedDate] = (details[providerName][formattedDate] || 0) + usage;
      });
    });

    const chartData = Object.entries(serviceProviderMap)
      .map(([provider, usage]) => ({
        service_provider: provider,
        usage: Math.round(usage * 100) / 100,
      }))
      .filter(item => item.usage > 0)
      .sort((a, b) => b.usage - a.usage);

    return { chartData, details };
  };

  const processServiceTypeData = (data: any, filter: string, tenantId: string): ProcessedUsageData => {
    if (!data?.data?.data?.[filter] || !data?.meta?.providers) {
      return { chartData: [], details: {} };
    }

    const providers = data.meta.providers as { [key: string]: string };
    const serviceProviderMap: { [key: string]: number } = {};
    const details: { [provider: string]: { [date: string]: number } } = {};

    let filteredData = data.data.data[filter];
    
    if (tenantId !== "All") {
      filteredData = filteredData.filter((item: any) => String(item.tenant_id) === tenantId);
    }

    filteredData.forEach((item: any) => {
      const providerId = item.provider_id === null ? "null" : String(item.provider_id);
      const providerName = providers[providerId];
      
      if (!providerName) return;

      item.records?.forEach((record: any) => {
        let date: string, percentage: string;
        
        if (Array.isArray(record)) {
          date = record[0];
          percentage = record[1];
        } else {
          return;
        }

        if (percentage && percentage !== "0.0%") {
          let numericValue: number;
          
          if (typeof percentage === 'string') {
            numericValue = parseFloat(percentage.replace("%", ""));
          } else if (typeof percentage === 'number') {
            numericValue = percentage;
          } else {
            return;
          }

          if (!isNaN(numericValue) && numericValue > 0) {
            const formattedDate = formatDateForTooltip(date);
            
            serviceProviderMap[providerName] = (serviceProviderMap[providerName] || 0) + numericValue;
            
            if (!details[providerName]) {
              details[providerName] = {};
            }
            details[providerName][formattedDate] = (details[providerName][formattedDate] || 0) + numericValue;
          }
        }
      });
    });

    const chartData = Object.entries(serviceProviderMap)
      .map(([provider, percentage]) => ({
        service_provider: provider,
        percentage: Math.round(percentage * 100) / 100,
        details: details[provider] || {}
      }))
      .filter((item) => item.percentage > 0)
      .sort((a, b) => b.percentage - a.percentage);

    return { chartData, details };
  };

  const processPlanUtilisationData = (data: any, filter: string, tenantId: string, selectedProvider: string = "All") => {
    if (!data?.data?.data?.[filter] || !data?.meta?.providers) {
      return { chartData: [], tableData: [], providers: [], details: {} };
    }

  const providers = data.meta.providers as { [key: string]: string };
  const planMap: { [key: string]: { plan: string; usage_count: number; service_provider: string } } = {};
  const details: { [provider: string]: { [date: string]: number } } = {};
  
  // ✅ Get ALL available providers from backend (for dropdown)
  const allAvailableProviders = Object.values(providers);
  
  let filteredData = data.data.data[filter];
  
  if (tenantId !== "All") {
    filteredData = filteredData.filter((item: any) => String(item.tenant_id) === tenantId);
  }

  // ✅ Filter by selected provider ONLY for chart data (not for dropdown)
  if (selectedProvider !== "All" && selectedProvider !== "") {
    const selectedProviderId = Object.keys(providers).find(key => providers[key] === selectedProvider);
    if (selectedProviderId) {
      filteredData = filteredData.filter((item: any) => String(item.provider_id) === selectedProviderId);
    }
  }

  filteredData.forEach((item: any) => {
    const providerId = item.provider_id === null ? "null" : String(item.provider_id);
    const providerName = providers[providerId];
    const planName = item.plan || "No Plan";
    
    if (!providerName) return;

    const key = `${planName}-${providerName}`;
    
    if (!planMap[key]) {
      planMap[key] = {
        plan: planName,
        usage_count: 0,
        service_provider: providerName,
      };
    }

    if (!details[planName]) {
      details[planName] = {};
    }

    item.records?.forEach((record: any) => {
      let count: number, date: string;
      
      if (Array.isArray(record)) {
        date = record[0];
        count = Number(record[1]) || 0;
      } else {
        return;
      }

      const formattedDate = formatDateForTooltip(date);
      planMap[key].usage_count += count;
      
      details[planName][formattedDate] = (details[planName][formattedDate] || 0) + count;
    });
  });

  const chartData = Object.values(planMap)
    .filter(item => item.usage_count > 0)
    .sort((a, b) => b.usage_count - a.usage_count);

  const tableData = chartData.map((item, index) => ({
    key: `plan-${index}`,
    plan_name: item.plan,
    service_provider: item.service_provider,
    usage_value: item.usage_count,
  }));

  // ✅ Return ALL providers from backend for dropdown
  return { chartData, tableData, providers: allAvailableProviders, details };
};
  const processTimeBasedLineData = (
  data: any, 
  filter: string, 
  tenantId: string
): { chartData: any[], serviceProviders: string[] } => {
  console.log("=== PROCESSING TIME BASED LINE DATA ===");
  
  if (!data?.data?.data?.[filter] || !data?.meta?.providers) {
    return { chartData: [], serviceProviders: [] };
  }

  const providers = data.meta.providers as { [key: string]: string };
  const serviceProviders = Object.values(providers);
  
  let filteredData = data.data.data[filter];
  
  if (tenantId !== "All") {
    filteredData = filteredData.filter((item: any) => String(item.tenant_id) === tenantId);
  }

  const processedData: { [timeLabel: string]: { [provider: string]: number } } = {};
  
  filteredData?.forEach((item: any) => {
    const providerId = item.provider_id === null ? "null" : String(item.provider_id);
    const providerName = providers[providerId];
    
    if (!providerName) return;
    
    item.records?.forEach((record: any) => {
      let date: string, count: number;
      
      if (Array.isArray(record)) {
        date = record[0];
        count = Number(record[1]) || 0;
      } else if (typeof record === "object" && record !== null) {
        date = Object.keys(record)[0];
        count = Number(record[date]) || 0;
      } else {
        return;
      }
      
      const recordDate = new Date(date);
      let timeLabel: string;
      const monthIndex = recordDate.getMonth() + 1;

      
      switch (filter) {
       case "1_day":
          // Handle the time range format "00:00 - 03:59"
          if (date.includes(' - ')) {
            timeLabel = date; // Use the time range as is
          } else {
            timeLabel = recordDate.toLocaleTimeString('en-US', { 
              hour: '2-digit', 
              hour12: false 
            });
          }
          break;
          
        case "5_day":
          timeLabel = recordDate.toLocaleDateString('en-US', { 
            month: 'short', 
            day: 'numeric' 
          });
          break;
          
      case "1_month": {
  const year = recordDate.getFullYear();
  const monthStart = new Date(year, recordDate.getMonth(), 1);
  const weekNum =
    Math.floor((recordDate.getTime() - monthStart.getTime()) / (1000 * 60 * 60 * 24 * 7)) + 1;

  timeLabel = `${year}-${monthIndex.toString().padStart(2, "0")}-W${Math.min(weekNum, 4)}`;
  break;
}

          
        case "3_month":
        case "6_month":
        case "1_year":
          const year = recordDate.getFullYear();
  const monthStartDate = new Date(year, recordDate.getMonth(), 1);
  const weekNumber =
    Math.floor((recordDate.getTime() - monthStartDate.getTime()) / (1000 * 60 * 60 * 24 * 7)) + 1;

  timeLabel = `${year}-${monthIndex.toString().padStart(2, "0")}-W${Math.min(weekNumber, 5)}`;
  break;
          
        case "5_years":
        case "max":
          timeLabel = recordDate.getFullYear().toString();
          break;
          
        default:
          timeLabel = date;
      }
      
      if (!processedData[timeLabel]) {
        processedData[timeLabel] = {};
        serviceProviders.forEach(provider => {
          processedData[timeLabel][provider] = 0;
        });
      }
      
      processedData[timeLabel][providerName] = 
        (processedData[timeLabel][providerName] || 0) + count;
    });
  });

  // Sort time labels appropriately
  const sortedTimeLabels = Object.keys(processedData).sort((a, b) => {
    if (filter === "1_day") {
      return a.localeCompare(b);
    } else if (filter === "5_day") {
      return new Date(a).getTime() - new Date(b).getTime();
    } else if (["1_month", "3_month", "6_month", "1_year"].includes(filter)) {
  const ma = a.match(/^(\d{4})-(\d{2})-W(\d+)$/);
  const mb = b.match(/^(\d{4})-(\d{2})-W(\d+)$/);

  if (ma && mb) {
    const [, yA, mA, wA] = ma;
    const [, yB, mB, wB] = mb;

    if (yA !== yB) return Number(yA) - Number(yB);
    if (mA !== mB) return Number(mA) - Number(mB);
    return Number(wA) - Number(wB);
  }

  return a.localeCompare(b);
}
 else if (filter === "5_years") {
      return parseInt(a) - parseInt(b);
    } else {
      return a.localeCompare(b);
    }
  });

  const chartData = sortedTimeLabels.map(timeLabel => ({
    time: timeLabel,
    ...processedData[timeLabel]
  }));

  return { chartData, serviceProviders };
};

// -----------------------------------------
// 🔥 Correct Week-of-Month Function
// -----------------------------------------
const getWeekOfMonth = (date: Date) => {
  const day = date.getDate(); 
  return Math.ceil(day / 7);   // 1..5
};

// --------------------------------------------------------
// 🔥 FINAL FIXED processUsageTrendLineData FUNCTION
// --------------------------------------------------------
const processUsageTrendLineData = (
  data: any,
  filter: string,
  tenantId: string
): { chartData: any[]; serviceProviders: string[] } => {

  if (!data?.data?.data?.[filter] || !data?.meta?.providers) {
    return { chartData: [], serviceProviders: [] };
  }

  const providers = data.meta.providers as { [key: string]: string };
  const serviceProviders = Object.values(providers);

  let filteredData = data.data.data[filter];

  if (tenantId !== "All") {
    filteredData = filteredData.filter(
      (item: any) => String(item.tenant_id) === tenantId
    );
  }

  const processedData: {
    [timeLabel: string]: { [provider: string]: number | null };
  } = {};

  // ----------------------------------------------------
  // 🔥 LOOP THROUGH ALL PROVIDERS' RECORDS
  // ----------------------------------------------------
  filteredData.forEach((item: any) => {
    const providerId = String(item.provider_id);
    const providerName = providers[providerId];
    if (!providerName) return;

    item.records?.forEach((record: any) => {
      let date: string;
      let usage: number;

      if (Array.isArray(record)) {
        date = record[0];
        usage = Number(record[1]) || 0;
      } else {
        date = Object.keys(record)[0];
        usage = Number(record[date]) || 0;
      }

      const recordDate = new Date(date);
      let timeLabel = "";
      if (filter === "1_day") {
  timeLabel = date; // "00:00 - 03:59" or "14:00"
} else {
  const recordDate = new Date(date);
  if (isNaN(recordDate.getTime())) return;

      // -----------------------------------
      // 🔥 TIME LABEL CALCULATION (FIXED)
      // -----------------------------------
       switch (filter) {
    case "5_day":
      timeLabel = recordDate.toLocaleDateString("en-US", {
        month: "short",
        day: "2-digit",
      });
      break;

    case "1_month":
    case "3_month":
    case "6_month":
    case "1_year": {
      const year = recordDate.getFullYear();
      const month = recordDate.getMonth() + 1;
      const weekNum = getWeekOfMonth(recordDate);
      timeLabel = `${year}-${String(month).padStart(2, "0")}-W${weekNum}`;
      break;
    }

    case "5_years":
    case "max":
      timeLabel = recordDate.getFullYear().toString();
      break;

    default:
      timeLabel = date;
  }
}

      // ------------------------------------------------
      // 🔥 Initialize row with 0 (NOT null)
      // ------------------------------------------------
      if (!processedData[timeLabel]) {
        processedData[timeLabel] = {};
        serviceProviders.forEach((p) => {
          processedData[timeLabel][p] = 0;
        });
      }

      // ------------------------------------------------
      // 🔥 SUM USAGE PER PROVIDER (FIXED)
      // ------------------------------------------------
      if (usage > 0) {
        processedData[timeLabel][providerName] =
          (processedData[timeLabel][providerName] ?? 0) + usage;
      }
    });
  });

  // ----------------------------------------------------
  // 🔥 Convert 0 → null so Recharts hides empty points
  // ----------------------------------------------------
  Object.keys(processedData).forEach((label) => {
    Object.keys(processedData[label]).forEach((provider) => {
      if (processedData[label][provider] === 0) {
        processedData[label][provider] = null;
      }
    });
  });

  // ----------------------------------------------------
  // 🔥 Sort labels correctly
  // ----------------------------------------------------
  const sortedLabels = Object.keys(processedData).sort((a, b) => {
    if (filter === "1_month") {
      const [mA, wA] = a.split("-W");
      const [mB, wB] = b.split("-W");
      return parseInt(mA) - parseInt(mB) || parseInt(wA) - parseInt(wB);
    }
    if (["3_month", "6_month", "1_year"].includes(filter)) {
       const [yA, mA, wA] = a.split(/-|W/).map(Number);
    const [yB, mB, wB] = b.split(/-|W/).map(Number);

    if (yA !== yB) return yA - yB;   // YEAR
    if (mA !== mB) return mA - mB;   // MONTH
    return wA - wB;    
    }

    return a.localeCompare(b);
  });

  // ----------------------------------------------------
  // 🔥 Handle spacer rows for dual X-axis
  // ----------------------------------------------------
  const shouldShowDual = ["1_month","3_month", "6_month", "1_year"].includes(filter);
  const finalChartData: any[] = [];

  if (shouldShowDual) {
    let lastMonth = "";
    sortedLabels.forEach((label, index) => {
      const currentMonth = label.split("-W")[0];

      if (index > 0 && currentMonth !== lastMonth) {
        finalChartData.push({
          day: `spacer-${index}`,
          isSpacer: true,
          ...serviceProviders.reduce((acc, p) => ({ ...acc, [p]: null }), {}),
        });
      }

      finalChartData.push({
        day: label,
        isSpacer: false,
        ...processedData[label],
      });

      lastMonth = currentMonth;
    });
  } else {
    sortedLabels.forEach((label) => {
      finalChartData.push({
        day: label,
        isSpacer: false,
        ...processedData[label],
      });
    });
  }

  // DONE 🎉
  return { chartData: finalChartData, serviceProviders };
};


// Helper: get number of days in month
const daysInMonth = (year: number, month0Based: number) =>
  new Date(year, month0Based + 1, 0).getDate();

// Helper: calculate weeks in a month given first weekday
const calcWeeksInMonth = (year: number, month0Based: number) => {
  const firstDay = new Date(year, month0Based, 1);
  const firstWeekday = firstDay.getDay(); // 0 = Sunday
  const dim = daysInMonth(year, month0Based);
  return Math.ceil((firstWeekday + dim) / 7);
};

// --- processBubbleChartData (FINAL FIXED VERSION)

const processBubbleChartData = (
  data: any,
  filter: string,
  tenantId: string
): {
  bubbleData: any[];
  serviceProviders: string[];
  monthPositions: Array<{ month: string; first: string; last: string }>;
  primaryMonth: number;
} => {
  if (!data?.data?.data?.[filter] || !data?.meta?.providers) {
    return {
      bubbleData: [],
      serviceProviders: [],
      monthPositions: [],
      primaryMonth: new Date().getMonth()
    };
  }
const filterMap: Record<string, string> = {
  "1_month": "1M",
  "3_month": "3M",
  "6_month": "6M",
  "1_year": "1Y",
  "5_years": "5Y",
};

const normalizedFilter = filterMap[filter] || filter;
  const providers = data.meta.providers as Record<string, string>;
  const serviceProviders = Object.values(providers);

  let filteredData = data.data.data[filter];
  if (tenantId !== "All") {
    filteredData = filteredData.filter(
      (item: any) => String(item.tenant_id) === tenantId
    );
  }

  // --------------------------------------------------
  // ✅ Primary month (ONLY for non-1D)
  // --------------------------------------------------
  let primaryMonth = new Date().getMonth();

  if (filter !== "1_day") {
    const allDates: Date[] = [];

    filteredData.forEach((item: any) => {
      item.records?.forEach((rec: any) => {
        const dateStr = Array.isArray(rec) ? rec[0] : Object.keys(rec)[0];
        const d = new Date(dateStr);
        if (!isNaN(d.getTime())) allDates.push(d);
      });
    });

    if (allDates.length) {
      const count: Record<string, number> = {};
      allDates.forEach(d => {
        const key = `${d.getFullYear()}-${d.getMonth()}`;
        count[key] = (count[key] || 0) + 1;
      });

      const primaryKey = Object.entries(count)
        .sort((a, b) => b[1] - a[1])[0][0];

      primaryMonth = Number(primaryKey.split("-")[1]);
    }
  }

  // --------------------------------------------------
  // ✅ Time label helper (SAFE FOR 1D)
  // --------------------------------------------------
  const getLabel = (dateStr: string): string | null => {
    if (filter === "1_day") {
      return dateStr; // "00:00 - 03:59"
    }

    const d = new Date(dateStr);
    if (isNaN(d.getTime())) return null;

    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const week = Math.ceil(d.getDate() / 7);

    if (filter === "5_day") {
      return d.toLocaleDateString("en-US", { month: "short", day: "numeric" });
    }

    if (filter === "5_years" || filter === "max") {
      return `${year}`;
    }

    return `${year}-${month}-W${week}`;
  };

  // --------------------------------------------------
  // ✅ Build processed map
  // --------------------------------------------------
  const processed: Record<string, Record<string, number>> = {};
  const labels = new Set<string>();

  filteredData.forEach((item: any) => {
    const providerName = providers[String(item.provider_id)];
    if (!providerName) return;

    item.records?.forEach((rec: any) => {
      const dateStr = Array.isArray(rec) ? rec[0] : Object.keys(rec)[0];
      const rawVal = Array.isArray(rec) ? rec[1] : rec[dateStr];

      const lbl = getLabel(dateStr);
      if (!lbl) return;

      if (!processed[lbl]) {
        processed[lbl] = {};
        serviceProviders.forEach(p => (processed[lbl][p] = 0));
      }

      const value =
        typeof rawVal === "string"
          ? parseFloat(rawVal.replace("%", "")) || 0
          : Number(rawVal) || 0;

      processed[lbl][providerName] += value;
      labels.add(lbl);
    });
  });

  // --------------------------------------------------
  // ✅ Build bubble data (DO NOT DROP ZERO FOR 1D)
  // --------------------------------------------------
  const bubbleData: any[] = [];
  Array.from(labels).forEach((lbl, idx) => {
    serviceProviders.forEach((provider, pIdx) => {
      const val = processed[lbl]?.[provider] ?? 0;

      if (filter === "1_day" || val > 0) {
        bubbleData.push({
          id: `${provider}-${lbl}`,
          service_provider: provider,
          time: lbl,
          value: val,
          x: idx,
          y: val,
          z: val,
          color: PROVIDER_COLORS[pIdx % PROVIDER_COLORS.length]
        });
      }
    });
  });
// --------------------------------------------------
// ✅ Build monthPositions for 1M / 3M / 6M / 1Y
// --------------------------------------------------
const monthPositions: Array<{ month: string; first: string; last: string }> = [];

if (["1_month", "3_month", "6_month", "1_year"].includes(filter)){
  const groups: Record<string, string[]> = {};

  Array.from(labels).forEach(lbl => {
    // lbl format: YYYY-MM-Wn
    if (!lbl.includes("-W")) return;

    const [, mm] = lbl.split("-"); // YYYY-[MM]-Wn
    groups[mm] = groups[mm] || [];
    groups[mm].push(lbl);
  });

  Object.keys(groups)
    .sort((a, b) => Number(a) - Number(b))
    .forEach(mm => {
      const arr = groups[mm].sort();
      monthPositions.push({
        month: mm,          // "01", "02"
        first: arr[0],      // first week label
        last: arr[arr.length - 1] // last week label
      });
    });
}

  return {
    bubbleData,
    serviceProviders,
    monthPositions,
    primaryMonth
  };
};






// 4. FIX: Enhanced CustomBubble with proper hover detection (replace existing)

const CustomBubble: React.FC<any> = (props) => {
  const { cx, cy, payload } = props;
  
  if (payload.isGap || payload.isSpacer || payload.value === 0) {
    return <g></g>;
  }
  
  const isHovered = hoveredBubble === payload.id;
  const shouldDim = hoveredBubble && hoveredBubble !== payload.id;
  
  // FIXED: Better radius calculation based on actual data range
  const minRadius = 6;
  const maxRadius = 18;
  
  // Get all valid bubble values for proper scaling
  const allValidBubbles = props.bubbleData?.filter((d:any) => !d.isGap && !d.isSpacer && d.value > 0) || [];
  if (allValidBubbles.length === 0) return <g></g>;
  
  const allValues = allValidBubbles.map((d: any) => d.value);
  const maxValue = Math.max(...allValues);
  const minValue = Math.min(...allValues);
  
  // Calculate radius based on the value's position in the range
  let radius = minRadius;
  if (maxValue > minValue) {
    const normalizedValue = (payload.value - minValue) / (maxValue - minValue);
    radius = minRadius + (normalizedValue * (maxRadius - minRadius));
  }
  
  return (
    <g>
      {/* Invisible hover area */}
      <circle
        cx={cx}
        cy={cy}
        r={radius + 3}
        fill="transparent"
        style={{ cursor: selectedFilter === partner ? "pointer" : "default" }}
        onMouseEnter={() => setHoveredBubble(payload.id)}
        onMouseLeave={() => setHoveredBubble(null)}
        onClick={() => {
          if (selectedFilter === partner && payload && !payload.isGap) {
            handleChartClick({ time: payload.time }, 'serviceType', payload);
          }
        }}
      />
      {/* Visible bubble */}
      
      <circle
      cx={cx}
      cy={cy}
      r={radius}
      fill={payload.color}
      fillOpacity={shouldDim ? 0.3 : 0.8}
      stroke="#fff"
       strokeWidth={isHovered ? 2 : 1}
       style={{
          filter: isHovered ? "drop-shadow(0 2px 4px rgba(0,0,0,0.3))" : "none",
          transition: "all 0.2s ease",
          pointerEvents: "none"
        }}
      // Remove any opacity or filter attributes
      // style={{ cursor: 'pointer' }}
    />
      {/* Optional: Add value text inside larger bubbles */}
      {/* REMOVED: No text inside bubbles as requested */}
    </g>
  );
};

// 3. Enhanced BubbleTooltip with better color contrast


// NEW: Process plan rectangle chart data - time-based like bubble chart// 4. Enhanced processPlanRectangleData with better time handling
// 5. FIX: Enhanced processPlanRectangleData with smaller rectangles (replace existing)
const processPlanRectangleData = (
  data: any, 
  filter: string, 
  tenantId: string,
  selectedProvider: string = "All"
): { rectangleData: any[], planNames: string[] } => {
  console.log("=== PROCESSING PLAN RECTANGLE DATA ===");
  
  if (!data?.data?.data?.[filter] || !data?.meta?.providers) {
    return { rectangleData: [], planNames: [] };
  }

  const providers = data.meta.providers as { [key: string]: string };
  
  let filteredData = data.data.data[filter];
  
  if (tenantId !== "All") {
    filteredData = filteredData.filter((item: any) => String(item.tenant_id) === tenantId);
  }

  if (selectedProvider !== "All") {
    const selectedProviderId = Object.keys(providers).find(key => providers[key] === selectedProvider);
    if (selectedProviderId) {
      filteredData = filteredData.filter((item: any) => String(item.provider_id) === selectedProviderId);
    }
  }

  const processedData: { [timeLabel: string]: { [plan: string]: number } } = {};
  const allPlans = new Set<string>();
  
  filteredData?.forEach((item: any) => {
    const planName = item.plan || "No Plan";
    allPlans.add(planName);
    
    item.records?.forEach((record: any) => {
      let date: string, count: number;
      
      if (Array.isArray(record)) {
        date = record[0];
        count = Number(record[1]) || 0;
        // count = count * 1024; // Convert to KB
      } else {
        return;
      }
      
      const recordDate = new Date(date);
      let timeLabel: string;
      
      switch (filter) {
        case "1_day":
          if (date.includes(' - ')) {
            timeLabel = date;
          } else {
            timeLabel = recordDate.toLocaleTimeString('en-US', { 
              hour: '2-digit', 
              hour12: false 
            });
          }
          break;
          
        case "5_day":
          timeLabel = recordDate.toLocaleDateString('en-US', { 
            month: 'short', 
            day: '2-digit'
          });
          break;
          
        case "1_month":
          const monthIndex = recordDate.getMonth() + 1;
          const monthStart = new Date(recordDate.getFullYear(), recordDate.getMonth(), 1);
          const weekNum = Math.floor((recordDate.getTime() - monthStart.getTime()) / (1000 * 60 * 60 * 24 * 7)) + 1;
          timeLabel = `${monthIndex.toString().padStart(2, '0')}-W${Math.min(weekNum, 4)}`;
          break;
          
        case "3_month":
        case "6_month":
        case "1_year":
          const week = getWeekOfMonth(recordDate);
          const month = recordDate.getMonth() + 1; // 1..12
          timeLabel = `${month}-W${week}`;
          break;
          
        case "5_years":
        case "max":
          timeLabel = recordDate.getFullYear().toString();
          break;
          
        default:
          timeLabel = date;
      }

      if (count > 0) {
        if (!processedData[timeLabel]) {
          processedData[timeLabel] = {};
          allPlans.forEach(plan => {
            processedData[timeLabel][plan] = 0;
          });
        }
        
        processedData[timeLabel][planName] = 
          (processedData[timeLabel][planName] || 0) + count;
      }
    });
  });
// ---- Helper to convert "MM-Wx" into real sortable date ----
const resolveWeekDate = (label: string) => {
  if (!label.includes("-W")) return null;

  const [m, w] = label.split("-W");
  const month = Number(m);
  const week = Number(w);

  // Approximate date: 1st + (week-1)*7
  return new Date(new Date().getFullYear(), month - 1, 1 + (week - 1) * 7);
};

  const sortedTimeLabels = Object.keys(processedData).sort((a, b) => {
    if (filter === "1_day") {
      if (a.includes(' - ') && b.includes(' - ')) {
        return a.split(' - ')[0].localeCompare(b.split(' - ')[0]);
      }
      return a.localeCompare(b);
    } else if (filter === "5_day") {
      return new Date(a).getTime() - new Date(b).getTime();
    } else if (filter === "1_month") {
      const dateA = resolveWeekDate(a);
      const dateB = resolveWeekDate(b);

      if (dateA && dateB) return dateA.getTime() - dateB.getTime();

      // Fallback if resolveWeekDate fails
      const [monthIndexA, weekA] = a.split('-W');
      const [monthIndexB, weekB] = b.split('-W');

      const monthCompare = parseInt(monthIndexA) - parseInt(monthIndexB);
      if (monthCompare !== 0) {
        return monthCompare;
      }
      return parseInt(weekA) - parseInt(weekB);
    }else if (["3_month", "6_month", "1_year"].includes(filter)) {
      const dateA = resolveWeekDate(a);
      const dateB = resolveWeekDate(b);

      if (dateA && dateB) return dateA.getTime() - dateB.getTime();
      return a.localeCompare(b);
    }else if (["1_year"].includes(filter)) {
      // REVERSE ORDER FOR 1 YEAR AND MAX - Show most recent first
      const [monthIndexA, weekA] = (a.includes('-W') ? a.split('-W') : [a, '0']);
      const [monthIndexB, weekB] = (b.includes('-W') ? b.split('-W') : [b, '0']);
     
      // For "max" filter with just years, parse as integers
      if (!a.includes('-W') && !b.includes('-W')) {
        return  parseInt(a)- parseInt(b); // Descending year order
      }
     
      // Calculate months ago from current month
      const now = new Date();
      const currentMonth = now.getMonth();
     
      const monthA = parseInt(monthIndexA);
      const monthB = parseInt(monthIndexB);
     
      // Calculate distance from current month (going backwards)
      let distanceA = (currentMonth - monthA + 12) % 12;
      let distanceB = (currentMonth - monthB + 12) % 12;
     
      // If same month, sort by week (reversed)
      if (distanceA === distanceB) {
        return  parseInt(weekA)-parseInt(weekB);
      }
     
      // Sort by distance (closer to current = earlier in list)
      return distanceA - distanceB;
    } else if (["5_years", "max"].includes(filter)) {
      return parseInt(a) - parseInt(b);
    } else {
      return a.localeCompare(b);
    }
  });

  const validPlans = Array.from(allPlans).filter(plan => 
    sortedTimeLabels.some(time => processedData[time][plan] > 0)
  );

  const shouldShowDualXAxis = ["1_month","3_month", "6_month", "1_year"].includes(filter);
  const finalRectangleData: any[] = [];

  if (shouldShowDualXAxis) {
    let previousMonth = "";
    let currentXIndex = 0;
    
    sortedTimeLabels.forEach((timeLabel, index) => {
      const currentMonth = timeLabel.split('-W')[0];
      
      if (index > 0 && currentMonth !== previousMonth) {
        for (let i = 0; i < 1; i++) {
          finalRectangleData.push({
            id: `spacer-${index}-${i}`,
            time: `spacer-${index}-${i}`,
            isSpacer: true,
            isGap: true,
            x: currentXIndex++,
            y: 0,
            width: 0,
            height: 0,
            value: 0
          });
        }
      }
      
      
      validPlans.forEach((plan, planIndex) => {
        const value = processedData[timeLabel][plan];
        if (value > 0) {
          finalRectangleData.push({
            id: `${plan}-${timeLabel}`,
            plan_name: plan,
            time: timeLabel,
            timeIndex: currentXIndex,
            x: currentXIndex,
            y: value + (planIndex * 8), // Increased spacing
            width: 40, // Reduced width
            height: 25, // Reduced height
            value: value,
            usage_count: value,
            planIndex: planIndex,
            color: PLAN_COLORS[planIndex % PLAN_COLORS.length],
            isSpacer: false,
            isGap: false,
            displayName: plan.length > 6 ? plan.substring(0, 6) + "..." : plan, // Shorter names
            fullName: plan
          });
          console.log("📌 RAW BEFORE CONVERT", {
            provider: plan,
            time: timeLabel,
            unit: selectedByteUnit,
            value: value
          });

        }
      });
      
      currentXIndex++;
      previousMonth = currentMonth;
    });
  } else {
    sortedTimeLabels.forEach((timeLabel, timeIndex) => {
      validPlans.forEach((plan, planIndex) => {
        const value = processedData[timeLabel][plan];
        if (value > 0) {
          finalRectangleData.push({
            id: `${plan}-${timeLabel}`,
            plan_name: plan,
            time: timeLabel,
            timeIndex: timeIndex,
            x: timeIndex,
            y: value + (planIndex * 8), // Increased spacing
            width: 40, // Reduced width
            height: 25, // Reduced height
            value: value,
            usage_count: value,
            planIndex: planIndex,
            color: PLAN_COLORS[planIndex % PLAN_COLORS.length],
            isSpacer: false,
            isGap: false,
            displayName: plan.length > 6 ? plan.substring(0, 6) + "..." : plan,
            fullName: plan
          });
        }
      });
    });
  }

  return { rectangleData: finalRectangleData, planNames: validPlans };
};

// UPDATED: Plan table processing for time-based data
const processPlanTimeBasedTableData = (data: any, filter: string, tenantId: string, selectedProvider: string = "All") => {
  if (!data?.data?.data?.[filter] || !data?.meta?.providers) {
    return { chartData: [], planNames: [] };
  }

  const providers = data.meta.providers as { [key: string]: string };
  
  let filteredData = data.data.data[filter];
  
  if (tenantId !== "All") {
    filteredData = filteredData.filter((item: any) => String(item.tenant_id) === tenantId);
  }

  if (selectedProvider !== "All") {
    const selectedProviderId = Object.keys(providers).find(key => providers[key] === selectedProvider);
    if (selectedProviderId) {
      filteredData = filteredData.filter((item: any) => String(item.provider_id) === selectedProviderId);
    }
  }

  const processedData: { [timeLabel: string]: { [plan: string]: number } } = {};
  const allPlans = new Set<string>();
  
  filteredData?.forEach((item: any) => {
    const planName = item.plan || "No Plan";
    allPlans.add(planName);
    
    item.records?.forEach((record: any) => {
      let date: string, count: number;
      
      if (Array.isArray(record)) {
        date = record[0];
        count = Number(record[1]) || 0;
      } else {
        return;
      }
      
      const recordDate = new Date(date);
      let timeLabel: string;
      
      // Same time labeling logic
      switch (filter) {
        case "1_day":
          // Handle the time range format "00:00 - 03:59"
          if (date.includes(' - ')) {
            timeLabel = date; // Use the time range as is
          } else {
            timeLabel = recordDate.toLocaleTimeString('en-US', { 
              hour: '2-digit', 
              hour12: false 
            });
          }
          break;
        case "5_day":
          timeLabel = recordDate.toLocaleDateString('en-US', { 
            month: 'short', 
            day: 'numeric' 
          });
          break;
        case "1_month":
          const monthStart = new Date(recordDate.getFullYear(), recordDate.getMonth(), 1);
          const weekNum = Math.floor((recordDate.getTime() - monthStart.getTime()) / (1000 * 60 * 60 * 24 * 7)) + 1;
          timeLabel = `W${Math.min(weekNum, 4)}`;
          break;
        case "3_month":
        case "6_month":
        case "1_year":
          const monthIndex = recordDate.getMonth();
          const monthStartDate = new Date(recordDate.getFullYear(), recordDate.getMonth(), 1);
          const weekNumber = Math.floor((recordDate.getTime() - monthStartDate.getTime()) / (1000 * 60 * 60 * 24 * 7)) + 1;
          timeLabel = `${monthIndex.toString().padStart(2, '0')}-W${Math.min(weekNumber, 5)}`;
          break;
        case "5_years":
        case "max":
          timeLabel = recordDate.getFullYear().toString();
          break;
        default:
          timeLabel = date;
      }

      if (count > 0) {
        if (!processedData[timeLabel]) {
          processedData[timeLabel] = {};
          allPlans.forEach(plan => {
            processedData[timeLabel][plan] = 0;
          });
        }
        
        processedData[timeLabel][planName] = 
          (processedData[timeLabel][planName] || 0) + count;
      }
    });
  });

  // Sort time labels
  const sortedTimeLabels = Object.keys(processedData).sort((a, b) => {
    if (filter === "1_day") {
      return a.localeCompare(b);
    } else if (filter === "5_day") {
      return new Date(a).getTime() - new Date(b).getTime();
    } else if (filter === "1_month") {
      const weekA = parseInt(a.replace('W', ''));
      const weekB = parseInt(b.replace('W', ''));
      return weekA - weekB;
    } else if (["3_month", "6_month"].includes(filter)) {
      const [monthIndexA, weekA] = a.split('-W');
      const [monthIndexB, weekB] = b.split('-W');
      
      const monthCompare = parseInt(monthIndexA) - parseInt(monthIndexB);
      if (monthCompare !== 0) {
        return monthCompare;
      }
      return parseInt(weekA) - parseInt(weekB);
    } else if (["1_year"].includes(filter)) {
      // REVERSE ORDER FOR 1 YEAR AND MAX - Show most recent first
      const [monthIndexA, weekA] = (a.includes('-W') ? a.split('-W') : [a, '0']);
      const [monthIndexB, weekB] = (b.includes('-W') ? b.split('-W') : [b, '0']);
     
      // For "max" filter with just years, parse as integers
      if (!a.includes('-W') && !b.includes('-W')) {
        return  parseInt(a)- parseInt(b); // Descending year order
      }
     
      // Calculate months ago from current month
      const now = new Date();
      const currentMonth = now.getMonth();
     
      const monthA = parseInt(monthIndexA);
      const monthB = parseInt(monthIndexB);
     
      // Calculate distance from current month (going backwards)
      let distanceA = (currentMonth - monthA + 12) % 12;
      let distanceB = (currentMonth - monthB + 12) % 12;
     
      // If same month, sort by week (reversed)
      if (distanceA === distanceB) {
        return  parseInt(weekA)-parseInt(weekB);
      }
     
      // Sort by distance (closer to current = earlier in list)
      return distanceA - distanceB;
    } else if (filter === "5_years") {
      return parseInt(a) - parseInt(b);
    } else {
      return a.localeCompare(b);
    }
  });

  const planNames = Array.from(allPlans);
  const timeBasedTableData = sortedTimeLabels
    .filter(time => !time.startsWith('spacer-'))
    .map((time, index) => ({
      time,
      key: index,
      ...processedData[time]
    }));

  return { chartData: timeBasedTableData, planNames };
};

// NEW: Custom Rectangle Component
// 6. FIX: Enhanced CustomRectangle with smaller size (replace existing)
const CustomRectangle: React.FC<any> = (props) => {
  const { cx, cy, payload } = props;
  
  if (payload.isGap || payload.isSpacer || payload.value === 0) {
    return <></>;
  }

  const rectWidth = 40;
  const rectHeight = 25;
  const x = cx - rectWidth / 2;
  const y = cy - rectHeight / 2;
  
  // Check if this rectangle should be highlighted or dimmed
  const isHovered = hoveredRectangle === payload.time;
  const shouldDim = hoveredRectangle && hoveredRectangle !== payload.time;

  return (
    <g>
      <rect
        x={x}
        y={y}
        width={rectWidth}
        height={rectHeight}
        fill={payload.color}
        stroke="#fff"
        strokeWidth={1}
        style={{ 
          // cursor: "pointer",
          opacity: shouldDim ? 0.3 : isHovered ? 1 : 0.8,
          filter: isHovered ? 'brightness(1.1)' : shouldDim ? 'brightness(0.7)' : 'none'
        }}
        onMouseEnter={() => setHoveredRectangle(payload.time)}
        onMouseLeave={() => setHoveredRectangle(null)}
        // onClick={() => {
        //   if (selectedFilter === partner && payload && !payload.isGap) {
        //     handleChartClick({ time: payload.time }, 'planUtilisation', payload);
        //   }
        // }}
      />
      {/* <text
        x={cx}
        y={cy}
        textAnchor="middle"
        dominantBaseline="middle"
        fontSize={9}
        fill="#333"
        fontWeight="bold"
        style={{ 
          pointerEvents: "none",
          opacity: shouldDim ? 0.5 : 1
        }}
      >
        {payload.displayName}
      </text> */}
    </g>
  );
};




const renderFilterButtons = (chart: string) => {
  const filters = [
    { label: "1D", value: "1_day" },
    { label: "5D", value: "5_day" },
    { label: "1M", value: "1_month" },
    { label: "3M", value: "3_month" },
    { label: "6M", value: "6_month" },
    { label: "1Y", value: "1_year" },
    { label: "5Y", value: "5_years" },
    { label: "Max", value: "max" },
  ];

  const currentFilter =
    chart === "usageTrend"
      ? getActualFilterFromData(useCache ? cachedData.usageTrend : chartData.usageTrend, internalFilterUsageTrend)
      : chart === "serviceType"
      ? getActualFilterFromData(useCache ? cachedData.serviceTypeUsage : chartData.serviceTypeUsage, internalFilterServiceType)
      : chart === "usageByCarrier"
      ? getActualFilterFromData(useCache ? cachedData.usageByCarrier : chartData.usageByCarrier, internalFilterUsageByCarrier)
      : getActualFilterFromData(useCache ? cachedData.planUtilisation : chartData.planUtilisation, internalFilterPlanUtilisation);

  return (
    <div className="flex grid grid-cols-8">
      {filters.map((filter) => (
        <button
          key={filter.value}
          data-testid={`filter-${chart}-${filter.value}`} // Add test ID for debugging
          onClick={() => handleInternalFilterChange(chart, filter.value)}
          style={{ fontFamily: "Calibri, sans-serif", fontSize: "14px" }}
          className={`${currentFilter === filter.value ? "new-dashboard-filter-active-btn" : "new-dashboard-filter-btn"} p-2`}
          disabled={loadingUsageTrend || loadingServiceTypeUsage || loadingUsageByCarrier || loadingPlanUtilisation}
        >
          {filter.label}
        </button>
      ))}
    </div>
  );
};

// 6. Enhanced renderTable function with proper scroll handling
const renderTable = (
  chartDataEntries: UsageChartEntry[],
  details: { [provider: string]: { [date: string]: number } },
  chartIndex: number
) => {
  const isPercentageChart = chartIndex === 1;
  const isPlanChart = chartIndex === 3;

  const dataSource = useCache ? cachedData : chartData;
  const shouldShowTimeBasedTable = chartIndex <= 3;

  if (shouldShowTimeBasedTable) {
    const rawData = chartIndex === 0 ? dataSource.usageTrend :
                   chartIndex === 1 ? dataSource.serviceTypeUsage :
                   chartIndex === 2 ? dataSource.usageByCarrier :
                   dataSource.planUtilisation;

    const filter = chartIndex === 0 ? getActualFilterFromData(rawData, internalFilterUsageTrend) :
                  chartIndex === 1 ? getActualFilterFromData(rawData, internalFilterServiceType) :
                  chartIndex === 2 ? getActualFilterFromData(rawData, internalFilterUsageByCarrier) :
                  getActualFilterFromData(rawData, internalFilterPlanUtilisation);

    if (rawData) {
      if (chartIndex === 1) {
        // Bubble chart (service type) processing
        const { bubbleData, serviceProviders } = processBubbleChartData(rawData, filter, selectedTenantId);
        
        const timeBasedData: { [time: string]: { [provider: string]: number } } = {};
        
        bubbleData.forEach(bubble => {
          if (!bubble.isSpacer && !bubble.isGap && bubble.value > 0) {
            if (!timeBasedData[bubble.time]) {
              timeBasedData[bubble.time] = {};
              serviceProviders.forEach(provider => {
                timeBasedData[bubble.time][provider] = 0;
              });
            }
            timeBasedData[bubble.time][bubble.service_provider] = bubble.value ?? 0;
          }
        });

        const timeBasedTableData = Object.keys(timeBasedData)
          .filter(time => !time.startsWith('spacer-'))
          .sort((a, b) => {
            if (filter === "1_day") {
              if (a.includes(' - ') && b.includes(' - ')) {
                const timeA = a.split(' - ')[0];
                const timeB = b.split(' - ')[0];
                return timeA.localeCompare(timeB);
              }
              return a.localeCompare(b);
            } else if (filter === "1_month") {
              const weekA = parseInt(a.replace('W', ''));
              const weekB = parseInt(b.replace('W', ''));
              return weekA - weekB;
            } else if (["3_month", "6_month", "1_year"].includes(filter)) {
              const [monthIndexA, weekA] = a.split('-W');
              const [monthIndexB, weekB] = b.split('-W');
              
              const monthCompare = parseInt(monthIndexA) - parseInt(monthIndexB);
              if (monthCompare !== 0) {
                return monthCompare;
              }
              return parseInt(weekA) - parseInt(weekB);
            } else if (["5_years", "max"].includes(filter)) {
              return parseInt(a) - parseInt(b);
            }
            return a.localeCompare(b);
          })
          .map((time, index) => ({
            time,
            key: index,
            ...timeBasedData[time]
          }));

        return (
          <div style={{ 
            height: '280px', 
            padding: "10px",
            overflow: 'hidden'
          }}>
            <Table
              dataSource={timeBasedTableData}
              columns={[
                {
                   title: (
    <span style={{ fontSize: "14px", fontFamily: "Calibri, sans-serif" }}>
      Time Period
    </span>
  ),
                  dataIndex: "time",
                  key: "time",
                  width: 120,
                  // fixed: 'left',
                  render: (value: string) => {
                    if (filter === "1_day" && value.includes(' - ')) {
                      return value; // Show time range as is
                    } else if (value.includes('-W')) {
                      const [monthIndex, week] = value.split('-W');
                      const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 
                                        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                      const monthName = monthNames[parseInt(monthIndex)] || monthIndex;
                      return `${monthName}-W${week}`;
                    } else if (["5_years", "max"].includes(filter)) {
                      return value; // Show year only
                    }
                    return value;
                  },
                  onHeaderCell: () => ({
                    style: { 
                      fontSize: '14px',
                      padding: '8px 16px',
                      fontFamily: "Calibri, sans-serif"

                    }
                  }),
                  onCell: () => ({
                    style: { 
                      fontSize: '14px',
                      fontFamily: "Calibri, sans-serif",
                      padding: '8px 16px'
                    }
                  })
                },
                ...serviceProviders.map((provider, index) => ({
                  title: provider,
                  dataIndex: provider,
                  key: provider,
                  width: Math.max(80, Math.floor((window.innerWidth - 200) / serviceProviders.length)),
                  render: (value: number) => (value > 0 ? 
                    value.toFixed(2) + '%' : "-"),
                  onHeaderCell: () => ({
                    style: { 
                      fontSize: '12px',
                       fontFamily: "Calibri, sans-serif",
                      padding: '8px 16px',
                      whiteSpace: 'nowrap',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis'
                    }
                  }),
                  onCell: () => ({
                    style: { 
                      fontSize: '12px',
                       fontFamily: "Calibri, sans-serif",
                      padding: '8px 16px'
                    }
                  })
                })),
              ]}
              pagination={false}
              scroll={{ 
                y: 220,
                x: ["3_month", "6_month", "1_year"].includes(filter) ? 'max-content' : undefined
              }}
              size="small"
              style={{ 
                fontSize: '12px',
                width: '100%'
              }}
            />
          </div>
        );
      } else if (chartIndex === 3) {
        // Plan rectangle chart processing
        const { chartData: planTimeBasedData, planNames } = 
          processPlanTimeBasedTableData(rawData, filter, selectedTenantId, selectedPlanProvider);

        // Filter out empty plans
        const validPlanNames = planNames.filter(plan => 
          planTimeBasedData.some((item:any) => item[plan] && item[plan] > 0)
        );

        return (
          <div style={{ 
            height: '280px', 
            padding: "10px",
            overflow: 'hidden'
          }}>
            <Table
              dataSource={planTimeBasedData}
              columns={[
                {
                           title: (
    <span style={{ fontSize: "14px", fontFamily: "Calibri, sans-serif" }}>
      Time Period
    </span>
  ),
                  dataIndex: "time",
                  key: "time",
                  width: 120,
                  fixed: 'left',
                 render: (value: string) => {
  let displayValue = value;

  if (filter === "1_day" && value.includes(' - ')) {
    displayValue = value;
  } else if (value.includes('-W')) {
    const [monthIndex, week] = value.split('-W');
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const monthName = monthNames[parseInt(monthIndex)] || monthIndex;
    displayValue = `${monthName}-W${week}`;
  } else if (["5_years", "max"].includes(filter)) {
    displayValue = value;
  }

  return (
    <span style={{ fontFamily: "Calibri, sans-serif" }}>
      {displayValue}
    </span>
  );
}

                },
                ...validPlanNames.map((plan, index) => ({
                  title: plan.length > 12 ? plan.substring(0, 12) + "..." : plan,
                  dataIndex: plan,
                  key: plan,
                  width: 100,
                  // render: (value: number) => (value > 0 ? value : "-"),
                  render: (value: number) => (value > 0 ? formatValueForTooltip(value) : "-"),
                  onHeaderCell: () => ({
                    style: { 
                      fontSize: '12px',
                      fontFamily: "Calibri, sans-serif",
                      padding: '8px 16px',
                      whiteSpace: 'nowrap',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis'
                    }
                  }),
                  onCell: () => ({
                    style: { 
                      fontSize: '12px',
                      fontFamily: "Calibri, sans-serif",
                      padding: '8px 16px'
                    }
                  })
                })),
              ]}
              pagination={false}
              scroll={{ 
                y: 220,
                x: ["3_month", "6_month", "1_year"].includes(filter) ? 'max-content' : undefined
              }}
              size="small"
              style={{ 
                fontSize: '9px',
                width: '100%'
              }}
            />
          </div>
        );
      } else {
        // Line charts (usage trend and usage by carrier)
        const { chartData: timeBasedData, serviceProviders } = chartIndex === 0 
          ? processUsageTrendLineData(rawData, filter, selectedTenantId)
          : processTimeBasedLineData(rawData, filter, selectedTenantId);

        return (
          <div style={{ 
            height: '280px', 
            padding: "10px",
            overflow: 'hidden'
          }}>
            <Table
              dataSource={timeBasedData.filter(item => !item.isSpacer).map((item, index) => ({ ...item, key: index }))}
              columns={[
                {
                           title: (
    <span style={{ fontSize: "14px", fontFamily: "Calibri, sans-serif" }}>
      Time Period
    </span>
  ),
                  dataIndex: chartIndex === 0 ? "day" : "time",
                  key: chartIndex === 0 ? "day" : "time",
                  width: 120,
                  fixed: 'left',
                  render: (value: string) => {
  let displayValue = value;

  if (filter === "1_day" && value.includes(" - ")) {
    displayValue = value; // Time range
  } else if (value.includes("-W")) {
    const [monthIndex, week] = value.split("-W");
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const monthName = monthNames[parseInt(monthIndex)] || monthIndex;
    displayValue = `${monthName}-W${week}`;
  } else if (["5_years", "max"].includes(filter)) {
    displayValue = value; // year
  }

  return (
    <span style={{ fontFamily: "Calibri, sans-serif", fontSize: "14px" }}>
      {displayValue}
    </span>
  );
},

                },
                ...serviceProviders.map((provider, index) => ({
                  title: provider,
                  dataIndex: provider,
                  key: provider,
                  width: Math.max(80, Math.floor((window.innerWidth - 200) / serviceProviders.length)),
                  render: (value: number) => (value > 0 ? 
                    // (isPercentageChart ? value.toFixed(2) + '%' : value.toLocaleString()) : "-"),
                    (isPercentageChart ? value.toFixed(2) + '%' : formatValueForTooltip(value)) : "-"), 
                  onHeaderCell: () => ({
                    style: { 
                      fontSize: '12px',
                      fontFamily: "Calibri, sans-serif",
                      padding: '8px 16px',
                      whiteSpace: 'nowrap',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis'
                    }
                  }),
                  onCell: () => ({
                    style: { 
                      fontSize: '12px',
                      fontFamily: "Calibri, sans-serif",
                      padding: '8px 16px'
                    }
                  })
                })),
              ]}
              pagination={false}
              scroll={{ 
                y: 220,
                x: ["3_month", "6_month", "1_year"].includes(filter) ? 'max-content' : undefined
              }}
              size="small"
              style={{ 
                fontSize: '9px',
                width: '100%'
              }}
            />
          </div>
        );
      }
    }
  }

  return <div>No data available</div>;
};
  const getAdjustedDomain = (data: any[], field: string): [number, number] => {
    if (!data || data.length === 0) {
      return [0, field === "usage_count" ? 500 : 100];
    }

    const values = data.flatMap((item) =>
      Object.values(item).filter((v): v is number => typeof v === "number")
    );
    const max = Math.max(...values, 0);
    const adjustedMax = max === 0 ? (field === "usage_count" ? 500 : 100) : Math.ceil(max / 100) * 100;

    return [0, adjustedMax];
  };

const formatConvertedValue = (value: number): string => {
  const divisor = BYTE_UNITS[selectedByteUnit];
  const convertedValue = value / divisor;

  // Round to nearest whole number (NO decimals)
  const rounded = Math.round(convertedValue);

  return `${rounded} ${selectedByteUnit}`;
};
const formatAxisValueRounded = (value: number): string => {
  if (value === 0) return "0";
  
  const divisor = BYTE_UNITS[selectedByteUnit];
  const convertedValue = value / divisor;

  let rounded;

  // Small values → round to nearest 10
  if (convertedValue < 50) {
    rounded = Math.round(convertedValue / 5) * 5;
  }
  else if (convertedValue < 100){
    rounded = Math.round(convertedValue / 10) * 10;
  }
  // Larger values → round to nearest 100
  else {
    rounded = Math.round(convertedValue / 100) * 100;
  }

  return `${rounded} ${selectedByteUnit}`;
};



const formatYAxisTickForCharts = (value: number): string => {
  if (value === 0) return "0";
  return formatAxisValueRounded(value);
};

const formatValueForTooltip = (value: number): string => {
  return formatConvertedValue(value);
};



// 7. Enhanced chart rendering with better axis alignment and spacing

const renderNewChartsWithScrolling = () => {
  const cardHeight = 280;
  const dataSourceUsageTrend = useCache ? cachedData : chartData;
  const dataSourceServiceType = useCache ? cachedData : chartData;
  const dataSourceUsageByCarrier = useCache ? cachedData : chartData;
  const dataSourcePlanUtilisation = useCache ? cachedData : chartData;

  const filterToUseUsageTrend = getActualFilterFromData(dataSourceUsageTrend.usageTrend, internalFilterUsageTrend);
  const filterToUseServiceType = getActualFilterFromData(dataSourceServiceType.serviceTypeUsage, internalFilterServiceType);
  const filterToUseUsageByCarrier = getActualFilterFromData(dataSourceUsageByCarrier.usageByCarrier, internalFilterUsageByCarrier);
  const filterToUsePlanUtilisation = getActualFilterFromData(dataSourcePlanUtilisation.planUtilisation, internalFilterPlanUtilisation);

  const shouldShowDualXAxis = 
    ["3_month", "6_month", "1_year"].includes(filterToUseUsageTrend) ||
    ["3_month", "6_month", "1_year"].includes(filterToUseServiceType) ||
    ["3_month", "6_month", "1_year"].includes(filterToUseUsageByCarrier) ||
   ["3_month", "6_month", "1_year"].includes(filterToUsePlanUtilisation);

  console.log("🔧 Render charts with expansion state:", {
    shouldShowDualXAxis,
    isExpanded,
    filterToUseUsageTrend,
    filterToUseServiceType,
    filterToUseUsageByCarrier,
    filterToUsePlanUtilisation
  });

  const { chartData: usageTrendData, details: usageTrendDetails } = dataSourceUsageTrend.usageTrend
    ? processUsageData(dataSourceUsageTrend.usageTrend, filterToUseUsageTrend, selectedTenantId)
    : { chartData: [], details: {} };

  const { chartData: serviceTypeUsageData, details: serviceTypeDetails } = dataSourceServiceType.serviceTypeUsage
    ? processServiceTypeData(dataSourceServiceType.serviceTypeUsage, filterToUseServiceType, selectedTenantId)
    : { chartData: [], details: {} };

  const { chartData: usageByCarrierData, details: usageByCarrierDetails } = dataSourceUsageByCarrier.usageByCarrier
    ? processUsageData(dataSourceUsageByCarrier.usageByCarrier, filterToUseUsageByCarrier, selectedTenantId)
    : { chartData: [], details: {} };

// Inside Chart 4 rendering section in renderNewChartsWithScrolling
const { chartData: planUtilisationData, tableData: planTableData, providers: planProviders, details: planDetails } = 
  dataSourcePlanUtilisation.planUtilisation
    ? processPlanUtilisationData(
        dataSourcePlanUtilisation.planUtilisation, 
        filterToUsePlanUtilisation, 
        selectedTenantId, 
        selectedPlanProvider // ✅ This filters the CHART data only
      )
    : { chartData: [], tableData: [], providers: [], details: {} };

console.log("🛠️ Plan Utilisation Data.......:",planProviders);

// ✅ All providers are available in dropdown
const filteredPlanProviders = (planProviders || []).map((item) => ({
  label: item,
  value: item,
}));

// ✅ Use selected provider or default to first one
// const displayPlanProvider = selectedPlanProvider || 
//   (filteredPlanProviders.length > 0 ? filteredPlanProviders[0] : undefined);
const displayPlanProvider =
  filteredPlanProviders.find(
    (option) => option.value === selectedPlanProvider
  ) || filteredPlanProviders[0] || null;


const TimeBasedTooltip: React.FC<{
  active?: boolean;
  payload?: Array<{ value: number; formatted: string; name: string; dataKey: string; color: string }>;
  label?: string;
  filter?: string;
}> = ({ active, payload, label, filter }) => {

  if (!active || !payload || !payload.length || !label) return null;

  const validEntries = payload.filter(entry => entry.value && entry.value > 0);
  if (validEntries.length === 0) return null;

let timeLabel = label;
 if (label.includes("-W")) {
  // label format: YYYY-MM-Wn
  const [ym, w] = label.split("-W"); // ["2025-11", "3"]
  const [year, month] = ym.split("-").map(Number);
  const week = Number(w);

  const monthNames = [
    "Jan","Feb","Mar","Apr","May","Jun",
    "Jul","Aug","Sep","Oct","Nov","Dec"
  ];

  timeLabel = `${monthNames[month - 1]} - W${week}`;
}


  let labelText = "";
  if (filter === "1_day") labelText = "Time: ";
  else if (filter === "5_day") labelText = " ";

  return (
    <div
    className="nivo-default-tooltip"
      style={{
        background: "white",
        border: "1px solid #ccc",
        borderRadius: "6px",
        boxShadow: "0 2px 6px rgba(0,0,0,0.15)",
        padding: "10px 12px",
        minWidth: "220px",   // 🔥 increased width
        maxWidth: "380px", 
        maxHeight: "400px",
        overflowY: "auto",
        fontFamily: "Calibri, sans-serif",
        zIndex: 1000
      }}
    >
      {/* Header */}
      <div
        style={{
          textAlign: "center",
          fontWeight: 600,
          marginBottom: "10px",
          fontSize: "13px",
          // color: "#000",
          // borderBottom: "1px solid #eee",
          paddingBottom: "6px"
        }}
      >
        {labelText}{timeLabel}
      </div>

      {/* Each Row */}
      {validEntries.map((entry, index) => (
        <div
          key={index}
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            gap: "10px",
            marginBottom: "6px",
            fontSize: "12px",
            // color: "#000"
          }}
        >
          {/* Square icon + Name */}
          <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
            <span
              style={{
                width: "10px",
                height: "10px",
                backgroundColor: entry.color,
                borderRadius: "2px" // 👈 Square shape (slight smooth edges like your charts)
              }}
            ></span>
            <span style={{ maxWidth: "160px", overflow: "hidden", textOverflow: "ellipsis" }}>
              {entry.dataKey}
            </span>
          </div>

          {/* Value right aligned */}
          <span style={{ fontWeight: 400 }}>
            {entry.formatted}
          </span>
        </div>
      ))}
    </div>
  );
};


  // Updated BubbleTooltip to match TimeBasedTooltip format
 // 2. FIXED: Enhanced BubbleTooltip with conditional label display
const BubbleTooltip: React.FC<any> = ({ active, payload, label, coordinate, filter, allBubbleData }) => {
  if (!active || !payload || !payload.length) {
    return null;
  }

  const data = payload[0].payload;
  if (data.isSpacer || data.isGap) {
    return null;
  }

  const canRedirect = selectedFilter === partner;

  // Format time label to show month names
  let timeLabel = data.time;
  if (data.time && data.time.includes('-W')) {
    const [monthIndex, week] = data.time.split('-W');
    const monthName = getMonthNameFromIndex(monthIndex);
    timeLabel = `${monthName}-W${week}`;
  }

  // Conditional label display based on filter
  let labelText = '';
  if (filter === '1_day') {
    labelText = 'Time: ';
  } else if (filter === '5_day') {
    labelText = 'Day: ';
  }

  // FIXED: Find all providers at the same time and position
  const currentTime = data.time;
  const currentValue = data.percentage || data.value;
  
  // Get all bubbles at the same time period with similar values (within tolerance)
  const overlappingBubbles = allBubbleData ? allBubbleData.filter((bubble:any) => 
    !bubble.isSpacer && 
    !bubble.isGap && 
    bubble.time === currentTime && 
    Math.abs((bubble.percentage || bubble.value) - currentValue) < 0.1 // Same value within 0.1% tolerance
  ) : [data];

  console.log("Tooltip Debug:", {
    currentTime,
    currentValue,
    overlappingBubbles: overlappingBubbles.map((b:any) => ({ provider: b.service_provider, value: b.value })),
    totalBubbles: allBubbleData?.length || 0
  });

  return (
    <div
      style={{
        backgroundColor: 'white',
        border: '1px solid #ccc',
        borderRadius: '4px',
        boxShadow: '0 2px 4px rgba(0,0,0,0.1)',
        padding: '8px 12px',
        maxWidth: '280px',
        fontSize: '10px',
        zIndex: 1000,
        position: 'absolute',
        left: coordinate.x + 10, // Adjust position to avoid left-side sticking
        top: coordinate.y - 10,
      }}
    >
      <div style={{ 
        fontWeight: 'bold', 
        marginBottom: '6px', 
        color: '#333',
        borderBottom: '1px solid #eee',
        paddingBottom: '4px'
      }}>
        {labelText}{timeLabel}
      </div>
      
      <div style={{ marginBottom: '6px', fontSize: '10px', color: '#666' }}>
        Usage: {currentValue.toFixed(2)}%
      </div>
      
      {/* Show all overlapping providers */}
      <div style={{ 
        maxHeight: '150px', 
        overflowY: 'auto',
        marginBottom: overlappingBubbles.length > 1 ? '6px' : '0'
      }}>
        <div style={{ fontWeight: '500', marginBottom: '4px', fontSize: '11px' }}>
          {overlappingBubbles.length > 1 ? 'Providers:' : 'Provider:'}
        </div>
        {overlappingBubbles.map((bubble:any, index:any) => (
          <div 
            key={`${bubble.service_provider}-${index}`}
            style={{ 
              display: 'flex', 
              alignItems: 'center', 
              marginBottom: '3px',
              fontSize: '10px'
            }}
          >
            <div 
              style={{ 
                width: '8px', 
                height: '8px', 
                borderRadius: '50%', 
                backgroundColor: bubble.color,
                marginRight: '6px',
                flexShrink: 0
              }}
            />
            <span style={{ 
              overflow: 'hidden', 
              textOverflow: 'ellipsis', 
              whiteSpace: 'nowrap',
              flex: 1
            }}>
              {bubble.service_provider}
            </span>
            <span style={{ 
              marginLeft: '6px',
              fontSize: '10px',
              color: '#666'
            }}>
              {bubble.value.toFixed(2)}%
            </span>
          </div>
        ))}
      </div>
      
      {overlappingBubbles.length > 1 && (
        <div style={{ 
          fontSize: '10px', 
          color: '#888', 
          fontStyle: 'italic',
          borderTop: '1px solid #eee',
          paddingTop: '4px'
        }}>
          {overlappingBubbles.length} providers at this position
        </div>
      )}
      
      {canRedirect && (
        <div style={{ 
          fontSize: '10px', 
          color: '#666', 
          marginTop: '6px',
          borderTop: '1px solid #eee',
          paddingTop: '4px'
        }}>
          Click to view details in Inventory
        </div>
      )}
    </div>
  );
};

const RectangleTooltip: React.FC<any> = ({ active, payload, label, coordinate, filter, allRectangleData }) => {
  if (!active || !payload || !payload.length) {
    return null;
  }

  const data = payload[0].payload;
  if (data.isSpacer || data.isGap) {
    return null;
  }

  const canRedirect = selectedFilter === partner;

  // Format time label to show month names
  let timeLabel = data.time;
  if (data.time && data.time.includes('-W')) {
    const [monthIndex, week] = data.time.split('-W');
    const monthName = getMonthNameFromIndex(monthIndex);
    timeLabel = `${monthName}-W${week}`;
  }

  // Conditional label display based on filter
  let labelText = '';
  if (filter === '1_day') {
    labelText = 'Time: ';
  } else if (filter === '5_day') {
    labelText = 'Day: ';
  }

  // Find all rectangles at the same time period
  const currentTime = data.time;
  const rectanglesAtSameTime = allRectangleData ? allRectangleData.filter((rect: any) =>
    !rect.isSpacer &&
    !rect.isGap &&
    rect.time === currentTime &&
    rect.value > 0
  ) : [data];

  // Sort by usage count (descending)
  rectanglesAtSameTime.sort((a: any, b: any) => b.usage_count - a.usage_count);

  // Calculate total usage for this time period
  const totalUsage = rectanglesAtSameTime.reduce((sum: number, rect: any) => sum + rect.usage_count, 0);

  return (
    <div
      style={{
        backgroundColor: 'rgba(255, 255, 255, 0.95)',
        border: '1px solid #ccc',
        borderRadius: '4px',
        padding: '8px',
        fontSize: '10px',
        boxShadow: '0 2px 8px rgba(0,0,0,0.15)',
        maxWidth: '400px',
        maxHeight: '800px',
        zIndex: 1000
      }}
    >
      <div style={{ fontWeight: 'bold', marginBottom: '4px', color: '#333' }}>
        {labelText}{timeLabel}
      </div>
      
      {/* ✓ UPDATED: Apply unit conversion to total usage */}
      <div style={{ marginBottom: '6px', color: '#666' }}>
        Total Plans: {rectanglesAtSameTime.length} | Total Usage: {formatValueForTooltip(totalUsage)}
      </div>

      {/* Show all plans at this time */}
      <div style={{ 
        maxHeight: '500px', 
        overflowY: 'auto',  // ✓ CHANGED: 'hidden' to 'auto' for better scrolling
        display: 'grid',
        gap: '3px'
      }}>
        {rectanglesAtSameTime.map((rect: any, index: any) => (
          <div
            key={`${rect.plan_name}-${index}`}
            style={{
              display: 'flex',
              alignItems: 'center',
              padding: '2px 4px',
              backgroundColor: rect.plan_name === data.plan_name ? 'rgba(116, 185, 255, 0.1)' : 'transparent',
              borderRadius: '2px',
              border: rect.plan_name === data.plan_name ? '1px solid rgba(116, 185, 255, 0.3)' : 'none'
            }}
          >
            <div
              style={{
                width: '12px',
                height: '12px',
                backgroundColor: rect.color,
                marginRight: '6px',
                borderRadius: '2px',
                flexShrink: 0
              }}
            />
            <div style={{ flex: 1, fontSize: '10px' }}>
              <div style={{ fontWeight: rect.plan_name === data.plan_name ? 'bold' : 'normal' }}>
                {rect.fullName || rect.plan_name}
              </div>
              {/* ✓ UPDATED: Apply unit conversion to individual plan usage */}
              <div style={{ color: '#666', fontSize: '10px' }}>
                Usage: {formatValueForTooltip(rect.usage_count)}
              </div>
            </div>
          </div>
        ))}
      </div>

      {rectanglesAtSameTime.length > 1 && (
        <div style={{ 
          marginTop: '6px', 
          paddingTop: '6px', 
          borderTop: '1px solid #eee',
          fontSize: '10px',
          color: '#666'
        }}>
          {rectanglesAtSameTime.length} plans active in this period
        </div>
      )}

      {canRedirect && (
        <div style={{ 
          marginTop: '6px', 
          paddingTop: '6px', 
          borderTop: '1px solid #eee',
          fontSize: '10px', 
          color: '#0066cc' 
        }}>
          Click to view details in Inventory
        </div>
      )}
    </div>
  );
};


  return (
    <div className="flex flex-col items-start justify-start w-full">
      <div className={
        shouldShowDualXAxis && isExpanded 
          ? "flex flex-col gap-4 w-full p-6"
          : "grid grid-cols-1 md:grid-cols-2 gap-4 w-full p-6"
      }>
        {/* Chart 1 - Usage Trend with enhanced alignment and proper axis handling */}
        {features.includes("Usage Trend") && (
          <div className="bg-white text-gray-900 p-4 rounded-lg shadow-md graph" style={{ height: `400px` }}>
            <div className="bg-gray-100 flex justify-between items-center p-4 chart-title">
              <div className="flex items-center">
                <h2 className="font-semibold">
                  {dataSourceUsageTrend.usageTrend?.data?.title || "Usage Trend"}
                </h2>
              </div>
              <div className="flex items-center">
                {/* <ArrowPathRoundedSquareIcon
          className="cursor-pointer w-6 h-6"
          onClick={() => setFlippedChart(flippedChart === 0 ? null : 0)}
        /> */}
                <button
                  onClick={() => setFlippedChart(flippedChart === 0 ? null : 0)}
                  className="flex items-center justify-center cursor-pointer"
                  style={{
                    width: "24px",
                    height: "24px",
                    border: "none",
                    background: "transparent",
                    padding: 0,
                    marginLeft: "4px",
                  }}
                >
                  <i
                    className="fi fi-rr-flip-horizontal"
                    style={{
                      fontSize: "18px",
                      color: "currentColor",
                      lineHeight: 1,
                    }}
                  />
                </button>

              </div>
            </div>
            {renderFilterButtons("usageTrend")}
            {flippedChart === 0 ? (
              <div style={{ height: `${cardHeight}px`, padding: "10px" }}>
                {renderTable(usageTrendData, usageTrendDetails, 0)}
              </div>
            ) : (
              <div style={{ height: `${cardHeight}px`, padding: "" }}>
                <ResponsiveContainer width="100%" height="100%">
                  {loadingUsageTrend ? (
                    <div className="flex flex-row justify-center items-center h-full">
                      <Spin size="large" />
                    </div>
                  ) : (
                      (() => {
  const { chartData: usageTrendLineData, serviceProviders: usageTrendProviders } =
    processUsageTrendLineData(dataSourceUsageTrend.usageTrend, filterToUseUsageTrend, selectedTenantId);

  // FIXED: Always show "No Data" when filter has no data but allow filter selection
  if (filterToUseUsageTrend === "no_data" ||
    usageTrendLineData.length === 0 ||
    usageTrendLineData.every(d =>
      usageTrendProviders.every(provider => !d[provider] || d[provider] === 0)
    )) {
    return (
      <div className="flex flex-col items-center justify-center h-full w-full">
        <span style={{ fontSize: 16, color: "#aaa" }}>No Data</span>
      </div>
    );
  }

  const shouldShowDualXAxis = ["1_month", "3_month", "6_month", "1_year"].includes(filterToUseUsageTrend);
  const bottomMargin = shouldShowDualXAxis ? 60 : 45;

  const formatYAxisTick = (value: number): string => {
    // Round to nearest 0 or 5
    const roundToNearest0Or5 = (num: number): number => {
      const remainder = num % 10;
      const base = num - remainder;

      if (remainder <= 2.5) {
        return Math.abs(num - base) < Math.abs(num - (base + 5)) ? base : base + 5;
      } else if (remainder <= 7.5) {
        return Math.abs(num - (base + 5)) < Math.abs(num - (base + 10)) ? base + 5 : base + 10;
      } else {
        return base + 10;
      }
    };

    if (value >= 1e12) {
      const rounded = roundToNearest0Or5(value / 1e12);
      return `${rounded}T`;
    } else if (value >= 1e9) {
      const rounded = roundToNearest0Or5(value / 1e9);
      return `${rounded}B`;
    } else if (value >= 1e6) {
      const rounded = roundToNearest0Or5(value / 1e6);
      return `${rounded}M`;
    } else if (value >= 1e3) {
      const rounded = roundToNearest0Or5(value / 1e3);
      return `${rounded}K`;
    }

    return roundToNearest0Or5(value).toString();
  };

  // ✅ Add spacers for visual separation BUT track them
  const withSpacers: any[] = [];
  let prevMonth: string | null = null;
  const spacerKeys = new Set<string>(); // Track spacer keys

  usageTrendLineData.forEach((d: any) => {
    if (!d.isSpacer && d.day.includes("-W")) {
      const [m] = d.day.split("-W");
      if (prevMonth !== null && prevMonth !== m) {
        // Add TWO spacers between months for visual separation
        for (let i = 0; i < 2; i++) {
          const spacerKey = `gap-${m}-${i}`;
          spacerKeys.add(spacerKey);
          withSpacers.push({
            day: spacerKey,
            isSpacer: true,
          });
        }
      }
      prevMonth = m;
    }
    withSpacers.push(d);
  });

  const maxY = Math.ceil(
    Math.max(
      ...usageTrendLineData
        .filter((d) => !d.isSpacer)
        .flatMap((d) =>
          usageTrendProviders.map((p) => Number(d[p]) || 0)
        )
    ) * 1.05 // 5% padding
  );
const lineData = usageTrendProviders.map((prov) => ({
  id: prov,
  color:
    USAGE_TREND_BLUE_SHADES[
      usageTrendProviders.indexOf(prov) % USAGE_TREND_BLUE_SHADES.length
    ],
  data: withSpacers.map((d: any) => {
    // For spacers, still include them but mark them
    if (d.isSpacer || String(d.day).startsWith("gap-")) {
      return { 
        x: d.day,
        y: null,
        isSpacer: true
      };
    }
    
    const value = d[prov];
    return { 
      x: d.day,
      y: value !== undefined && value !== null ? value : null,
      isSpacer: false
    };
  }),
}));

// STEP 2: Custom Line Layer that connects across spacers

const CustomConnectedLineLayer = ({ series, xScale, yScale }: any) => {
  return (
    <g>
      {series.map((serie: any) => {
        const validPoints = serie.data.filter(
          (point: any) =>
            !point.data.isSpacer &&
            point.data.y !== null &&
            point.data.y !== undefined &&
            !isNaN(point.data.y)
        );

        if (validPoints.length < 2) return null;

        const lineGenerator = d3Line<any>()
          .x((p) => xScale(p.data.x))
          .y((p) => yScale(p.data.y))
          .curve(curveMonotoneX);

        const path = lineGenerator(validPoints);

        if (!path) return null;

        return (
          <path
            key={`${serie.id}-line`}
            d={path}
            fill="none"
            stroke={serie.color}
            strokeWidth={2}
          />
        );
      })}
    </g>
  );
};



  // 👇 Build visible month groups (ignore spacers)
  interface MonthGroup {
    [month: string]: string[];
  }

const groups: MonthGroup = withSpacers.reduce((acc: MonthGroup, d: any) => {
  if (!d.isSpacer && d.day.includes("-W")) {
    // day = "2025-11-W3"
    const [year, month] = d.day.split("-"); // ["2025","11"]
    const key = `${year}-${month}`;

    if (!acc[key]) acc[key] = [];
    acc[key].push(d.day);
  }
  return acc;
}, {});


  // 📌 Month Names Array Used for Labels
  const monthNames = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
  ];

  // const getCleanTicks = (max: number) => {
  //   const roughStep = max / 5;
  //   const pow = Math.pow(10, Math.floor(Math.log10(roughStep)));
  //   const normalized = Math.ceil(roughStep / pow) * pow;

  //   let ticks: number[] = [];
  //   for (let v = 0; v <= max; v += normalized) ticks.push(v);

  //   // Always include exact max
  //   if (ticks[ticks.length - 1] !== max) ticks.push(max);

  //   // 🚫 Remove ticks that are very close to max (overlap prevention)
  //   ticks = ticks.filter((t, idx, arr) => {
  //     if (idx === arr.length - 2) {
  //       const diff = arr[arr.length - 1] - t;
  //       return diff > max * 0.1; // must differ ≥ 10% of max
  //     }
  //     return true;
  //   });

  //   return ticks;
  // };
const getCleanTicks = (max: number) => {
    const roughStep = max / 5;
    const pow = Math.pow(10, Math.floor(Math.log10(roughStep)));
    const normalized = Math.ceil(roughStep / pow) * pow;

    let ticks: number[] = [];
    for (let v = 0; v <= max; v += normalized) ticks.push(v);

    // Always include exact max
    if (ticks[ticks.length - 1] !== max) ticks.push(max);

    // 🚫 Remove ticks that are very close to max (overlap prevention)
    ticks = ticks.filter((t, idx, arr) => {
      if (idx === arr.length - 2) {
        const diff = arr[arr.length - 1] - t;
        return diff > max * 0.1; // must differ ≥ 10% of max
      }
      return true;
    });

    // Remove duplicate formatted values and filter out any value that formats to "0 GB"
    const seen = new Set<string>();
    return ticks.filter(tick => {
      // Special handling: keep actual 0, but format it as "0"
      const formatted = tick === 0 ? "0" : formatYAxisTickForCharts(tick);
      
      // Skip any non-zero values that format to "0 GB" or just "0"
      if (tick !== 0 && (formatted === "0 GB" || formatted === "0")) {
        return false;
      }
      
      if (seen.has(formatted)) {
        return false;
      }
      seen.add(formatted);
      return true;
    });
  };
  return (
    <div style={{ position: "relative", height: `${cardHeight}px` }}>
      <ResponsiveContainer width="100%" height="100%">
        <ResponsiveLine
          key={filterToUseUsageTrend}
          data={lineData}
          margin={{
            top: 10,
            right: shouldShowDualXAxis ? 30 : 20,
            bottom: bottomMargin,
            left: selectedByteUnit === "KB" ? 120 : selectedByteUnit === "MB" ? 90 : 70
          }}

          xScale={{ type: "point" }}
          yScale={{
            type: "linear",
            min: 0,
            max: maxY,
            stacked: false
          }}

          curve="monotoneX"
          enablePoints={true}
          enablePointLabel={false}
          enableGridX={false}
          enableGridY={true}
          axisTop={null}
          axisRight={null}
          colors={(d) => d.color}

          pointSize={6}
          pointBorderWidth={2}
          pointBorderColor="#fff"
          useMesh={true}
          enableSlices="x"
          enableCrosshair={false}

          // 🟢 X Bottom Axis (Weeks) - Hide spacer ticks
          axisBottom={{
  tickSize: 0,
  tickPadding: 10,

  format: (value) => {
    const v = String(value);

    if (v.startsWith("gap-") || v.startsWith("spacer-")) return "";

   
    if (filterToUseUsageTrend === "5_day") {
     
      return v.split(" ")[0];
    }

    // Weeks
    if (v.includes("-W")) {
      return `W${v.split("-W")[1]}`;
    }

    return v;
  },

  renderTick: (tick) => {
    const v = String(tick.value);

    if (v.startsWith("gap-") || v.startsWith("spacer-")) {
      return <g />;
    }

    let label = v;

    //5D month-only
      if (filterToUseUsageTrend === "5_day") {
  label = v; 
}

    // Weeks
    else if (v.includes("-W")) {
      label = `W${v.split("-W")[1]}`;
    }

    return (
      <g transform={`translate(${tick.x},${tick.y})`}>
        <text
          y={12}
          textAnchor="middle"
          className="chart-axis-text"
          style={{ fontSize: 10 }}
        >
          {label}
        </text>
      </g>
    );
  }
}}


          theme={{
            axis: {
              legend: {
                text: {
                  fill: "currentColor",
                  fontSize: 16,
                  fontFamily: "Calibri, sans-serif",
                  fontWeight: 400
                }
              },
              ticks: {
                text: {
                  fill: "currentColor",
                  fontSize: 12,
                  fontFamily: "Calibri, sans-serif",
                }
              }
            },
            grid: {
              line: {
                strokeWidth: 1,
                strokeDasharray: "2 2",
              }
            }
          }}

          // 🟡 Y Axis with your custom formatter
          axisLeft={{
            tickSize: 0,
            tickPadding: 10,
            legend: "Usage",
            // legendPosition: "start",
            legendOffset:
              selectedByteUnit === "KB"
                ? -100
                : selectedByteUnit === "MB"
                  ? -80
                  : -60,

            tickValues: getCleanTicks(maxY),
            format: (v) => formatYAxisTickForCharts(v),

            renderTick: (tick) => {
              const yOffset = tick.value === 0 ? -8 : 0;
               const xShift =
    selectedByteUnit === "KB"
      ? -5
      : selectedByteUnit === "MB"
      ? -5
      : -5; // GB

              return (
                <g transform={`translate(${tick.x+ xShift},${tick.y + yOffset})`}>
                  <text
                    textAnchor="end"
                    dominantBaseline="middle"
                     className="chart-axis-text"
                    style={{
                      fontSize: "12px",
                      fontFamily: "Calibri, sans-serif",
                      fontWeight: 400,
                    }}
                  >
                    {formatYAxisTickForCharts(tick.value)}
                  </text>
                </g>
              );
            },
          }}

          sliceTooltip={({ slice }) => {
  const xValue = slice.points[0]?.data.x;

  // 🚫 Ignore gaps / spacers
  if (
    String(xValue).startsWith("gap-") ||
    String(xValue).startsWith("spacer-")
  ) {
    return null;
  }

  const providerColorMap: Record<string, string> = Object.fromEntries(
    lineData.map((serie) => [serie.id, serie.color])
  );

  const validPoints = slice.points.filter(
    (pt) =>
      pt.data.y !== null &&
      pt.data.y !== undefined &&
      !Number.isNaN(pt.data.y)
  );

  if (!validPoints.length) return null;

  // 🧠 Decide tooltip side
  const sliceX = slice.points[0].x;     // X position in chart
  const chartWidth = 800;               // safe fallback
  const showOnRight = sliceX < chartWidth / 2;
  const OFFSET = 10;

  return (
    <div
      style={{
        transform: showOnRight
          ? `translateX(calc(120% - ${OFFSET}px))`               // 👉 left side → show right
          : `translateX(calc(-20% - ${OFFSET}px))`, // 👈 right side → show left
        pointerEvents: "none",
        whiteSpace: "nowrap",
      }}
    >
      <TimeBasedTooltip
        active
        payload={validPoints.map((pt) => ({
          value: pt.data.y as number,
          formatted: formatValueForTooltip(pt.data.y),
          name: pt.seriesId,
          dataKey: pt.seriesId,
          color: providerColorMap[pt.seriesId] ?? "#000",
        }))}
        label={xValue}
        filter={filterToUseUsageTrend}
      />
    </div>
  );
}}


          // 🟣 Add MONTH LABELS under weeks
          layers={[
            "grid",
            "markers",
            "axes",
            "areas",
            "crosshair",
            // "lines",
            CustomConnectedLineLayer,
            "points",
            "slices",
            "mesh",
            (props) => {
              if (!shouldShowDualXAxis) return null;
              const { xScale, innerHeight } = props;
               const bw =
    typeof (xScale as any).bandwidth === "function"
      ? (xScale as any).bandwidth()
      : 0;
              return (
                <g>
                  {Object.entries(groups).map(([m, days]) => {
                    const weekDays = days as string[];
                    if (!weekDays.length) return null;

                  const first = weekDays[0];
        const last = weekDays[weekDays.length - 1];

        const firstX = xScale(first);
        const lastX = xScale(last);

        if (firstX == null || lastX == null) return null;

        // ⭐ TRUE CENTER between bars
        const centerX = firstX + (lastX - firstX + bw) / 2;

                    return (
                      <text
                        key={m}
                        x={centerX}
                        y={innerHeight + 25}
                          className="chart-month-label"
                        textAnchor="middle"
                        style={{ fontSize: 12, fontWeight: 500 }}
                      >
                         {(() => {
      // m = "2025-11"
      const [, month] = m.split("-"); // "11"
      return monthNames[Number(month) - 1];
    })()}
                      </text>
                    );
                  })}
                </g>
              );
            }
          ]}
        />
      </ResponsiveContainer>

      <div
        style={{
          width: "100%",
          textAlign: "center",
          position: "relative",
          marginTop: "-27px"
        }}
        className="group"
      >
        <button className="peer px-3 py-1 text-[16px] service-provider-button rounded-md shadow cursor-pointer">
          Service Providers
        </button>

        {/* Tooltip Panel */}
        <div
          className="absolute left-1/2 -translate-x-1/2 hidden peer-hover:block service-provider-tooltip shadow-lg rounded-md border p-2 w-50 z-50"
          style={{
            bottom: "40px",
            pointerEvents: "auto",
            fontFamily: "Calibri",
            fontSize: "13px",
            lineHeight: "14px",
            overflowY: "auto"
          }}
        >
          {usageTrendProviders.map((provider, idx) => (
            <div key={idx} className="flex items-center gap-2 mb-1">
              <div
                className="w-2 h-2 rounded-sm"
                style={{ background: USAGE_TREND_BLUE_SHADES[idx % USAGE_TREND_BLUE_SHADES.length] }}
              ></div>
              <span style={{ fontSize: "13px", fontFamily: "Calibri" }}>{provider}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
})()
                  )}
                </ResponsiveContainer>
              </div>
            )}
          </div>
        )}

        {/* Chart 2 - Enhanced Bubble Chart with better positioning and tooltips */}
        {/* Chart 2 - Enhanced Bubble Chart with better positioning and tooltips */}
       {features.includes("Service Type Usage Distribution") && (
          <div className="bg-white text-gray-900 p-4 rounded-lg shadow-md graph" style={{ height: `400px` }}>
            <div className="bg-gray-100 flex justify-between items-center p-4 chart-title">
              <div className="flex items-center">
                <h2 className="font-semibold">
                  {dataSourceServiceType.serviceTypeUsage?.data?.title || "Service Type Usage Distribution"}
                </h2>
              </div>
              <div className="flex items-center">
                {/* <ArrowPathRoundedSquareIcon
                  className="cursor-pointer w-6 h-6"
                  onClick={() => setFlippedChart(flippedChart === 1 ? null : 1)}
                /> */}
                <button
                  onClick={() => setFlippedChart(flippedChart === 1 ? null : 1)}
                  className="flex items-center justify-center cursor-pointer"
                  style={{
                    width: "24px",
                    height: "24px",
                    border: "none",
                    background: "transparent",
                    padding: 0,
                    marginLeft: "4px",
                  }}
                >
                  <i
                    className="fi fi-rr-flip-horizontal"
                    style={{
                      fontSize: "18px",
                      color: "currentColor",
                      lineHeight: 1,
                    }}
                  />
                </button>
              </div>
            </div>
            {renderFilterButtons("serviceType")}
            {flippedChart === 1 ? (
              <div style={{ height: `${cardHeight}px`, padding: "10px" }}>
                {renderTable(serviceTypeUsageData, serviceTypeDetails, 1)}
              </div>
            ) : (
              <div style={{ width: "100%", marginBottom: "10px" }}>
              <div style={{ height: `${cardHeight}px`, padding: "8px", position: "relative",  overflow: "visible" }}>
                {loadingServiceTypeUsage ? (
                  <div className="flex flex-row justify-center items-center h-full">
                    <Spin size="large" />
                  </div>
                ) : (
                  <>
                          {(() => {
                            // run the fixed processor
                            const { bubbleData, serviceProviders: bubbleProviders, monthPositions, primaryMonth } =
                              processBubbleChartData(
                                dataSourceServiceType.serviceTypeUsage,
                                filterToUseServiceType,
                                selectedTenantId
                              );

                            if (!bubbleData || bubbleData.length === 0 && (!monthPositions || monthPositions.length === 0)) {
                              return (
                                <div className="flex flex-col items-center justify-center h-full w-full">
                                  <span style={{ fontSize: 16, color: "#aaa" }}>No Data</span>
                                </div>
                              );
                            }

                            const providers = bubbleProviders;

                            // Build timeSet & sorted timeArr (keeps ordering from processor)
                            const timeSet = new Set<string>();
                            // include all labels that processor knows about (monthPositions + bubbleData)
                            bubbleData.forEach((d: any) => { if (d?.time) timeSet.add(d.time); });

                            // also include labels from monthPositions (ensures zero rows appear when provider had no value)
                            monthPositions.forEach(mp => {
                              // add every label between mp.first and mp.last — they exist in processed data keys so just add them
                              // safer: add mp.first and mp.last as anchors
                              if (mp.first) timeSet.add(mp.first);
                              if (mp.last) timeSet.add(mp.last);
                            });

                            // const timeArr = Array.from(timeSet).sort((a: string, b: string) => {
                            //   // Keep MM-Wn groups sorted then Wn
                            //   const ma = a.match(/^(\d{2})-W(\d+)$/);
                            //   const mb = b.match(/^(\d{2})-W(\d+)$/);
                            //   if (ma && mb) {
                            //     const mmA = parseInt(ma[1], 10), wkA = parseInt(ma[2], 10);
                            //     const mmB = parseInt(mb[1], 10), wkB = parseInt(mb[2], 10);
                            //     if (mmA !== mmB) return mmA - mmB;
                            //     return wkA - wkB;
                            //   }
                            //   const wa = a.match(/^W(\d+)$/);
                            //   const wb = b.match(/^W(\d+)$/);
                            //   if (wa && wb) return parseInt(wa[1], 10) - parseInt(wb[1], 10);
                            //   if (ma && !mb) return -1;
                            //   if (!ma && mb) return 1;
                            //   return a.localeCompare(b);
                            // });
                            const timeArr: string[] = [];
const seen = new Set<string>();

// 1️⃣ Use bubbleData order FIRST (this preserves real chronology)
bubbleData.forEach((d: any) => {
  if (d?.time && !seen.has(d.time)) {
    timeArr.push(d.time);
    seen.add(d.time);
  }
});

// 2️⃣ Ensure month boundary anchors exist
monthPositions.forEach(mp => {
  if (mp.first && !seen.has(mp.first)) {
    timeArr.push(mp.first);
    seen.add(mp.first);
  }
  if (mp.last && !seen.has(mp.last)) {
    timeArr.push(mp.last);
    seen.add(mp.last);
  }
});


                            // Build timeMap and populate values (defaults to 0)
                            const timeMap: Record<string, Record<string, number>> = {};
                            timeArr.forEach(t => {
                              timeMap[t] = {};
                              providers.forEach(p => (timeMap[t][p] = 0));
                            });

                            bubbleData.forEach((d: any) => {
                              if (!d || !d.time) return;
                              const t = d.time;
                              const prov = d.service_provider;
                              const value = Number(d.value || 0);
                              if (!timeMap[t]) {
                                timeMap[t] = {};
                                providers.forEach(p => (timeMap[t][p] = 0));
                              }
                              timeMap[t][prov] = (timeMap[t][prov] || 0) + value;
                            });

                            // safeDataForNivo (exclude any spacer/gap tokens if present)
                            const safeDataForNivo = timeArr
                              .filter(t => !String(t).startsWith("spacer-") && !String(t).startsWith("gap-"))
                              .map(t => {
                                const obj: any = { time: t };
                                providers.forEach(p => (obj[p] = Number(timeMap[t]?.[p] ?? 0)));
                                return obj;
                              });

                            //-------------------------------------------------------
                            // INSERT SPACER ROWS BETWEEN MONTHS (CRITICAL FOR GAPS & MONTH LABELS)
                            //-------------------------------------------------------
                            if (["1_month", "3_month", "6_month", "1_year"].includes(filterToUseServiceType)) {
                              const spaced: any[] = [];
                              let prevMonth: string | null = null;

                              safeDataForNivo.forEach((row, idx) => {
                                const t = String(row.time);

                                // extract month MM from "MM-Wn"
                                const currentMonth = t.includes("-W") ? t.split("-W")[0] : null;

                                // add spacer when month changes
                                if (prevMonth !== null && currentMonth !== prevMonth) {
                                  spaced.push({
                                    time: `spacer-${idx}`,
                                    __isSpacer: true,
                                    ...Object.fromEntries(
                                      providers.map(p => [p, 0])
                                    )
                                  });
                                }

                                spaced.push(row);
                                prevMonth = currentMonth;
                              });

                              safeDataForNivo.length = 0;
                              spaced.forEach(r => safeDataForNivo.push(r));
                            }

                            // compute keys sorted by total descending (largest at bottom of stack)
                            const validProviders = providers.filter(p => !!p && p.length > 0);
                            const providerTotals = validProviders.map(p => ({
                              provider: p,
                              total: safeDataForNivo.reduce((s, r) => s + (Number(r[p]) || 0), 0)
                            })).sort((a, b) => b.total - a.total);
                            const keys = providerTotals.map(pt => pt.provider).reverse();

                            const STATUS_COLORS: Record<string, string> = {};
                            providers.forEach((k, i) => {
                              STATUS_COLORS[k] = STATUS_COLORS[k] ?? (PROVIDER_COLORS && PROVIDER_COLORS.length ? PROVIDER_COLORS[i % PROVIDER_COLORS.length] : "#74B9FF");
                            });

                            // computed padding (reuse your logic or use default)
                            const computedPadding = (() => {
                              if (filterToUseServiceType === "1_year") return 0.15;
                              if (filterToUseServiceType === "6_month") return 0.18;
                              if (filterToUseServiceType === "3_month") return 0.20;
                              if (safeDataForNivo.length <= 6) return 0.25;
                              if (safeDataForNivo.length <= 12) return 0.22;
                              return 0.20;
                            })();

                            // helper: translate time label for tooltip (shows month name + Wn)
                            const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                            const getLabelWithMonth = (timeLabel: any) => {
                              if (timeLabel.startsWith("W")) {
                                // 1-month style (we infer month from primaryMonth)
                                const w = timeLabel.replace(/^W/, "");
                                return `${monthNames[primaryMonth]} - W${w}`;
                              }
                              if (timeLabel.includes("-W")) {
                                const [mm, wn] = timeLabel.split("-W");
                                const idx = Math.max(0, Math.min(11, parseInt(mm, 10) - 1));
                                return `${monthNames[idx]} - W${wn}`;
                              }
                              return timeLabel;
                            };

                            // monthPositions is ready from processor and contains {month, first, last} entries

                            return (
                              <div style={{ width: "100%", height: cardHeight, position: "relative" }}>
                                <ResponsiveBar
                                  key={`bar-${filterToUseServiceType}-${safeDataForNivo.length}-${monthPositions.length}`}
                                  data={safeDataForNivo}
                                  keys={keys}
                                  indexBy="time"
                                  groupMode="stacked"
                                  enableLabel={false}
                                  //        barComponent={(props: any) => {
                                  //   const { bar } = props;
                                  //   const { x, y, width, height, color, data } = bar;

                                  //   // ⛔ spacer → draw invisible rect (no hover, no bar)
                                  //   if (data.__isSpacer) {
                                  //     return (
                                  //       <rect
                                  //         x={x}
                                  //         y={y}
                                  //         width={width}
                                  //         height={height}
                                  //         fill="transparent"
                                  //         opacity={0}
                                  //         pointerEvents="none"
                                  //       />
                                  //     );
                                  //   }

                                  //   // ✅ normal bar
                                  //   return (
                                  //     <rect
                                  //       x={x}
                                  //       y={y}
                                  //       width={width}
                                  //       height={height}
                                  //       fill={color}
                                  //       style={{ pointerEvents: "all" }}
                                  //     />
                                  //   );
                                  // }}

                                  labelSkipHeight={9999}
                                  labelSkipWidth={9999}
                                  indexScale={{ type: "band", round: false }}
                                  padding={computedPadding}
                                  valueScale={{ type: "linear", min: 0, max: 100 }}
                                  margin={{ top: 15, right: 20, bottom: (["1_month", "3_month", "6_month", "1_year"].includes(filterToUseServiceType) ? 75 : 65), left: 60 }}
                                  colors={({ id }) => STATUS_COLORS[id as string] ?? "#74B9FF"}
                                  borderRadius={0}
                                  enableGridX={false}
                                  enableGridY
                                  axisLeft={{
                                    tickSize: 5,
                                    tickPadding: 5,
                                    tickRotation: 0,
                                    legend: "Percentage",
                                    legendPosition: "middle",
                                    legendOffset: -50,
                                    renderTick: (tick) => {
                                      const displayValue = `${tick.value}%`;
                                      return (
                                        <g transform={`translate(${tick.x},${tick.y})`}>
                                          <text  className="chart-axis-text" textAnchor="end" dominantBaseline="middle" style={{ fontSize: 10 }} x={-5}>
                                            {displayValue}
                                          </text>
                                        </g>
                                      );
                                    }
                                  }}
                                  axisBottom={{
                                    tickSize: 5,
                                    tickPadding: 8,
                                    tickRotation: 0,
                                    format: (value: any) => {
                                      if (!value) return "";
                                      const s = String(value);
                                      if (s.startsWith("gap-") || s.startsWith("spacer-")) return "";
                                      // If "MM-Wn" -> show "Wn"
                                      if (s.includes("-W")) {
                                        const rawWeek = s.split("-W")[1];
                                        const weekNum = Number(rawWeek); // removes leading zeros
                                        return `W${weekNum}`;
                                      }
                                      // If already "Wn"
                                      const m = s.match(/^W0*(\d+)$/);
                                      if (m) return `W${Number(m[1])}`;
                                      return s;
                                    },
                                    renderTick: (tick) => {
                                      const v = String(tick.value || "");
                                      if (v.startsWith("gap-") || v.startsWith("spacer-")) return <g />;
                                      let label = "";
                                      if (v.includes("-W")) {
                                        label = `W${Number(v.split("-W")[1])}`;
                                      } else {
                                        const m = v.match(/^W0*(\d+)$/);
                                        label = m ? `W${Number(m[1])}` : v;
                                      }
                                      return (
                                        <g transform={`translate(${tick.x},${tick.y})`}>
                                          <line y1={0} y2={5} className="chart-axis-line" strokeWidth={1} />
                                          <text y={16} textAnchor="middle" dominantBaseline="hanging"  className="chart-axis-text" style={{fontSize: 10 }}>
                                            {label}
                                          </text>
                                        </g>
                                      );
                                    }
                                  }}

                                  // onClick={(bar: any) => {
                                  //   if (!bar) return;
                                  //   const indexValue = bar.indexValue;
                                  //   const data = bar.data;
                                  //   if (data && (data as any).__isSpacer) return;
                                  //   handleChartClick({ time: indexValue }, "serviceType", data);
                                  // }}
                                  tooltip={({ indexValue, data }) => {
                                    const label = String(indexValue);

                                    // ⛔ Skip tooltip for spacer rows
                                    if (label.startsWith("spacer-") || label.startsWith("gap-")) {
                                      return null;
                                    }

                                    // Find the real row from full data
                                    const row = safeDataForNivo.find(r => r.time === label);
                                    if (!row) return null;

                                    // Provider keys that have >0 value
                                    const activeProviders = keys.filter(k => Number(row[k] || 0) > 0);
                                    if (activeProviders.length === 0) return null;
 const barX =
    typeof data?.x === "number"
      ? data.x
      : 0;

  // ⭐ Chart width (fallback safe)
  const chartWidth = cardHeight ? cardHeight * 2 : 800;

  // ⭐ Decide side
  const showOnRight = barX < chartWidth / 2;
  const OFFSET = -25;
                                    // Format title: Month - WeekNumber
                                    const getTooltipTitle = (label: string) => {
                                      if (label.startsWith("W")) {
                                        // 1-month filters -> infer primary month
                                        const week = label.replace("W", "");
                                        return `${monthNames[primaryMonth]} - W${week}`;
                                      }

                                     if (label.includes("-W")) {
  // label format: YYYY-MM-Wn
  const parts = label.split("-");
  const year = parts[0];
  const month = parts[1]; // "11"
  const week = parts[2].replace("W", "");

  const monthIndex = Number(month) - 1;
  return `${monthNames[monthIndex]} - W${week}`;
}


                                      return label;
                                    };

                                    return (
                                      <div
                                        className="recharts-default-tooltip"
                                        style={{
                                          background: "white",
                                          border: "1px solid #ccc",
                                          padding: "8px 10px",
                                          borderRadius: 6,
                                          boxShadow: "0 2px 6px rgba(0,0,0,0.15)",
                                          fontSize: 11,
                                          minWidth: 200,
                                            transform: showOnRight
          ? `translateX(${OFFSET}px)`    
          : `translateX(-105%)`,            

                                        }}
                                      >
                                        {/* Title */}
                                        <div style={{ fontWeight: 700, marginBottom: 6, textAlign: "center" }}>
                                          {getTooltipTitle(label)}
                                        </div>

                                        {/* Provider Values */}
                                        {activeProviders.map((p) => {
                                          const value = Number(row[p] || 0);
                                          const color = STATUS_COLORS[p] || "#74B9FF";

                                          return (
                                            <div
                                              key={p}
                                              style={{
                                                display: "flex",
                                                justifyContent: "space-between",
                                                marginBottom: 4
                                              }}
                                            >
                                              <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
                                                <span
                                                  style={{
                                                    width: 10,
                                                    height: 10,
                                                    background: color,
                                                    borderRadius: 0
                                                  }}
                                                />
                                                <span>{p}</span>
                                              </span>
                                              <span style={{ fontFamily: "Calibri" }}>{value}%</span>
                                            </div>
                                          );
                                        })}
                                      </div>
                                    );
                                  }}

                                  theme={{
                                    // background: '#ffffff',
                                    axis: {
                                      domain: { line: { stroke: '#E5E7EB', strokeWidth: 1 } },
                                      ticks: { line: { stroke: '#D1D5DB', strokeWidth: 1 }, text: { fill: '#666', fontSize: 10, fontFamily: "Calibri" } },
                                      legend: { text: {  fill: 'currentColor', fontSize: 16, fontFamily: "Calibri" } },
                                    },
                                    grid: { line: { strokeWidth: 1, strokeDasharray: "2 2" } },
                                    tooltip: { container: { background: '#fff', color: '#333', fontSize: '11px', borderRadius: 6 } }
                                  }}
                                  motionConfig="gentle"

                                  // add custom layers for gaps + month label row
                                  layers={[
                                    
                                    // 1️⃣ Draw spacers at the bottom, BEFORE grid/axes
                                    (layerProps: any) => {
                                      const { xScale, innerHeight } = layerProps;
                                      return (
                                        <g>
                                          {safeDataForNivo
                                            .filter((d: any) => d.__isSpacer)
                                            .map((d: any, i: number) => {
                                              const x = xScale(d.time);
                                              if (x == null) return null;

                                              const barWidth = xScale.bandwidth();
                                              const gapWidth = Math.max(2, barWidth * 0.18);

                                              return (
                                                <rect
                                                  key={`sp-${i}`}
                                                  x={x}
                                                  y={0}
                                                  width={gapWidth}
                                                  height={innerHeight}
                                                  // fill="#ffffff"
                                                  fill="transparent"
                                                  pointerEvents="none"
                                                />
                                              );
                                            })}
                                        </g>
                                      );
                                    },

                                    // 2️⃣ Then grid + axes
                                    "grid",
                                    "axes",

                                    // 3️⃣ Bars after everything else
                                    "bars",

                                    // 4️⃣ Month labels overlay, no pointer events
                                   
// 4️⃣ Month labels overlay (CENTERED BETWEEN BARS)
(layerProps: any) => {
if (!["1_month", "3_month", "6_month", "1_year"].includes(filterToUseServiceType)) {
  return null;
}

  const { xScale, innerHeight } = layerProps;
  const yOffset = innerHeight + 34;

  return (
    <g transform={`translate(0, ${yOffset})`} pointerEvents="none">
      {monthPositions.map((mp, idx) => {
        const firstX = xScale(mp.first);
        const lastX = xScale(mp.last);
        if (firstX == null || lastX == null) return null;

        const barWidth = xScale.bandwidth();

        const firstCenter = firstX + barWidth / 2;
        const lastCenter = lastX + barWidth / 2;
        const centerX = (firstCenter + lastCenter) / 2;

        const monthIndex = Number(mp.month) - 1;

        return (
          <text
            key={idx}
            x={centerX}
            y={0}
            textAnchor="middle"
            fontSize={12}
            // fontWeight={600}
            fill="#000"
          >
            {monthNames[monthIndex]}
          </text>
        );
      })}
    </g>
  );
},
                                    // 5️⃣ Legend last
                                    "legends",
                                    
                                  ]}



                                />

                                {/* Legend button (unchanged) */}
                                <div style={{ width: "100%", textAlign: "center", marginTop: "245px", position: "relative" }} className="group">
                                  <button className="peer px-3 py-1 text-[16px] service-provider-button rounded-md shadow cursor-pointer">
                                    Service Providers
                                  </button>
                                  <div className="absolute left-1/2 -translate-x-1/2 hidden peer-hover:block service-provider-tooltip shadow-lg rounded-md border p-2 w-50 z-50"
                                    style={{ bottom: "40px", pointerEvents: "auto", fontSize: "13px", fontFamily: "Calibri", lineHeight: "14px", overflow: "visible", paddingRight: "6px" }}>
                                    {providers.map((status, idx) => (
                                      <div key={idx} className="flex items-center gap-2 mb-1">
                                        <div className="w-2 h-2" style={{ backgroundColor: STATUS_COLORS[status] }}></div>
                                        <span style={{ fontSize: "13px" }}>{status}</span>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              </div>
                            );
                          })()}
            </>
                )}
              </div>
              </div>
            )}
          </div>
        )}

       
        {/* Chart 3: Usage by Carrier / Provider (Nivo Stacked Bar) */}
        {features.includes("Usage by Carrier / Provider") && (
          <div className="bg-white text-gray-900 p-4 rounded-lg shadow-md graph" style={{ height: `400px` }}>
            <div className="bg-gray-100 flex justify-between items-center p-6  chart-title">
              <div className="flex items-center">
                <h2 className="font-semibold">
                  {dataSourceUsageByCarrier.usageByCarrier?.data?.title || "Usage by Carrier"}
                </h2>
              </div>
              <div className="flex items-center">
                {/* <ArrowPathRoundedSquareIcon
          className="cursor-pointer w-6 h-6"
          onClick={() => setFlippedChart(flippedChart === 2 ? null : 2)}
        /> */}
                <button
                  onClick={() => setFlippedChart(flippedChart === 2 ? null : 2)}
                  className="flex items-center justify-center cursor-pointer"
                  style={{
                    width: "24px",
                    height: "24px",
                    border: "none",
                    background: "transparent",
                    padding: 0,
                    marginRight: "-2px",
                  }}
                >
                  <i
                    className="fi fi-rr-flip-horizontal"
                    style={{
                      fontSize: "18px",
                      color: "currentColor",
                      lineHeight: 1,
                    }}
                  />
                </button>
              </div>
            </div>

            {renderFilterButtons("usageByCarrier")}


            {flippedChart === 2 ? (
              <div style={{ height: `${cardHeight}px`, padding: "10px" }}>
                {renderTable(usageByCarrierData, usageByCarrierDetails, 2)}
              </div>
            ) : (
              <div style={{ width: "100%", height: `${cardHeight}px`, padding: "8px", display: "flex", flexDirection: "column" }}>
                {loadingUsageByCarrier ? (
                  <div className="flex flex-row justify-center items-center h-full w-full">
                    <Spin size="large" />
                  </div>
                ) : (
                      (() => {
                        /* ---------------------
                            STEP 1: PROCESS DATA
                        ---------------------- */
                        const {
                          chartData: rawData,
                          serviceProviders
                        } = processTimeBasedLineData(
                          dataSourceUsageByCarrier.usageByCarrier,
                          filterToUseUsageByCarrier,
                          selectedTenantId
                        );


                        if (!rawData || rawData.length === 0) {
                          return (
                            <div className="flex flex-col items-center justify-center h-full w-full">
                              <span style={{ fontSize: 16, color: "#aaa" }}>No Data</span>
                            </div>
                          );
                        }

                        // ⭐ FIX NEGATIVE VALUES BEFORE ANY PROCESSING
                        rawData.forEach((row: any) => {
                          serviceProviders.forEach((p) => {
                            const v = Number(row[p] ?? 0);
                            if (v < 0) row[p] = 0;
                          });
                        });



                        /* ---------------------
                            STEP 2: TIME SORTING
                        ---------------------- */
                        const timeSet = new Set<string>();
                        rawData.forEach((d: any) => d?.time && timeSet.add(String(d.time)));

                        const sorted = [...timeSet].sort((a, b) => {
                          if (a.includes("-W") && b.includes("-W")) {
                            const [m1, w1] = a.split("-W");
                            const [m2, w2] = b.split("-W");
                            return m1 === m2 ? Number(w1) - Number(w2) : Number(m1) - Number(m2);
                          }
                          return a.localeCompare(b);
                        });



                        /* ---------------------
                            STEP 3: BUILD MAP
                        ---------------------- */
                        const timeMap: Record<string, Record<string, number>> = {};
                        sorted.forEach((t) => {
                          timeMap[t] = {};
                          serviceProviders.forEach((p) => (timeMap[t][p] = 0));
                        });

                        rawData.forEach((row: any) => {
                          if (!row?.time) return;
                          serviceProviders.forEach((p) => {
                            timeMap[row.time][p] = Number(row[p] ?? 0);
                          });
                        });


                        /* ---------------------
                            STEP 4: BUILD NIVO ROWS
                        ---------------------- */
                        let safeDataForNivo: any[] = sorted.map((t) => {
                          const o: any = { time: t, __isSpacer: 0 };
                          serviceProviders.forEach((p) => (o[p] = timeMap[t][p]));
                          return o;
                        });

                        const multiMonth = ["1_month", "3_month", "6_month", "1_year"].includes(filterToUseUsageByCarrier);

                        if (multiMonth) {
                          const newRows: any[] = [];
                          let prevMonth = "";

                          safeDataForNivo.forEach((r, idx) => {
                            const month = r.time.split("-W")[0];
                            if (prevMonth && month !== prevMonth) {
                              // ⭐ Insert TWO spacers to create visible month gap
                              for (let i = 0; i < 2; i++) {
                                const gap: any = { time: `gap-${idx}-${i}`, __isSpacer: 1 };
                                serviceProviders.forEach((p) => (gap[p] = 0));
                                newRows.push(gap);
                              }
                            }

                            newRows.push(r);
                            prevMonth = month;
                          });

                          safeDataForNivo = newRows;
                        }

                        const visibleData = safeDataForNivo.filter((r) => !r.__isSpacer);

                        /* ---------------------
                            STEP 5: COLORS
                        ---------------------- */
                        // Calculate total usage per provider and sort descending
                        const providerTotals = serviceProviders.map((p) => ({
                          provider: p,
                          total: visibleData.reduce((sum, r) => sum + (Number(r[p]) || 0), 0)
                        })).sort((a, b) => b.total - a.total); // Sort descending (largest first)

                        // Use sorted provider order for display (largest at bottom of stack)
                        const sortedProviders = providerTotals.map(pt => pt.provider).reverse(); // Reverse so largest is at bottom

                        const STATUS_COLORS: Record<string, string> = {};
                        serviceProviders.forEach((p, i) => {
                          STATUS_COLORS[p] = PROVIDER_COLORS[i % PROVIDER_COLORS.length];
                        });
                        /* ---------------------
                           STEP 6: MAX VALUE & TICKS (rounded, no 1024, 2048, 3072)
                        ---------------------- */

                        // 1. factor to convert BYTES → selected unit
                        const unitFactor =
                          selectedByteUnit === "KB"
                            ? 1024
                            : selectedByteUnit === "MB"
                              ? 1024 * 1024
                              : selectedByteUnit === "GB"
                                ? 1024 * 1024 * 1024
                                : 1;

                        // 2. helper to choose a “nice” step (1, 2, 5, 10, 20, 50, …)
                        const getNiceStep = (roughStep: number) => {
                          if (!roughStep || !isFinite(roughStep)) return 1;
                          const pow10 = Math.pow(10, Math.floor(Math.log10(roughStep)));
                          const base = roughStep / pow10;
                          let niceBase;
                          if (base <= 1) niceBase = 1;
                          else if (base <= 2) niceBase = 2;
                          else if (base <= 5) niceBase = 5;
                          else niceBase = 10;
                          return niceBase * pow10;
                        };

                        // 3. find max STACKED usage per time (still in BYTES)
                        const allStackSumsBytes = visibleData.map((row) =>
                          serviceProviders.reduce(
                            (sum, p) => sum + (Number(row[p] || 0)),
                            0
                          )
                        );

                        const maxStackBytes = Math.max(0, ...allStackSumsBytes);

                        // 4. work in the SELECTED UNIT to get a nice axis
                        const maxInUnit = maxStackBytes / unitFactor;

                        // aim ~5 ticks
                        const roughStep = maxInUnit / 5 || 1;
                        const stepInUnit = getNiceStep(roughStep);

                        // axis top in unit
                        const maxAxisInUnit = stepInUnit * Math.ceil(maxInUnit / stepInUnit);

                        // back to BYTES for Nivo
                        const maxAxisBytes = maxAxisInUnit * unitFactor;

                        // 5. build tick values (still BYTES!)
                        const tickValues: number[] = [];
                        for (let v = 0; v <= maxAxisInUnit + 1e-9; v += stepInUnit) {
                          tickValues.push(v * unitFactor);
                        }


                        /* ---------------------
                            STEP 7: MONTH LABELS
                        ---------------------- */
const monthPositions: any[] = [];

if (multiMonth) {
  const groups: Record<string, string[]> = {};

  visibleData.forEach((r) => {
    const match = String(r.time).match(/^(\d{4})-(\d{2})-W\d+$/);
    if (!match) return;

    const monthKey = match[2]; // "11", "12"
    groups[monthKey] = groups[monthKey] || [];
    groups[monthKey].push(r.time);
  });

  Object.keys(groups)
    .sort((a, b) => Number(a) - Number(b))
    .forEach((m) => {
      const arr = groups[m];
      monthPositions.push({
        month: Number(m),    
        first: arr[0],       
        last: arr[arr.length - 1]
      });
    });
}

  const formatMonthWeek = (value: string | number) => {
  const str = String(value);

  // If no week format, return as-is
  if (!str.includes("W")) return str;

  const monthNames = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
  ];

  // --------------------------------
  // 1 MONTH → W1, W2, W3...
  // --------------------------------
  if (!str.includes("-W") && filterToUseUsageByCarrier === "1_month") {
    const now = new Date();
    const monthIndex = now.getMonth();
    return `${monthNames[monthIndex]} - ${str}`;
  }

  // --------------------------------
  //  3M / 6M / 1Y → YYYY-MM-Wx
  // --------------------------------
  const match = str.match(/^(\d{4})-(\d{2})-W(\d+)$/);

  if (match) {
    const [, year, month, week] = match;
    const monthName = monthNames[Number(month) - 1];

    return `${monthName} - W${week}`;        
    // return `${monthName} ${year} - W${week}`;
  }

  return str;
};



                        /* ---------------------
                            STEP 8: RETURN NIVO
                        ---------------------- */
                        return (
                          <>
                            <ResponsiveBar
                              key={`bar-${filterToUseUsageByCarrier}-${safeDataForNivo.length}-${monthPositions.length}`}
                              data={safeDataForNivo}
                              keys={sortedProviders}
                              indexBy="time"
                              groupMode="stacked"
                              padding={0.15}
                              enableLabel={false}
                              // animate={false}
                              motionConfig="gentle"
                              margin={{
                                top: 24,
                                right: 20,
                                bottom: multiMonth ? 88 : 60,
                            left: selectedByteUnit === "KB" ? 120 : selectedByteUnit === "MB" ? 115 : 85
                              }}
                              valueScale={{ type: "linear", min: 0, max: maxAxisBytes, stacked: true }}
                              indexScale={{ type: "band", round: false }}
                              colors={({ id }) => STATUS_COLORS[id]}
                              enableGridY
                              axisLeft={{
                                tickSize: 5,
                                tickPadding: 5,
                                tickValues,
                                tickRotation: 0,
                                legend: "Usage",
                                // legendPosition: "start", // ⬅️ helps anchor near bottom, not middle!
                            legendOffset: selectedByteUnit === "KB" ? -110 : selectedByteUnit === "MB" ? -100 : -80,
                                // legendPosition: "middle",
                                // legendOffset: -85,
                                // legendOffset: selectedByteUnit === "KB" ? -85 : selectedByteUnit === "MB" ? -65
                                //   : -55,
                                format: (v) => formatAxisValueRounded(Number(v)),
                                renderTick: (tick) => {
                                  return (
                                    <g transform={`translate(${tick.x},${tick.y})`}>
                                      <text
                                        className="chart-axis-text"
                                        x={-5}
                                        textAnchor="end"
                                        dominantBaseline="middle"
                                        style={{
                                          fontSize: 12,      // ✔ font size 10px
                                          fontFamily: "Calibri, sans-serif",
                                          fontWeight: 400,   // normal (not bold)
                                        }}
                                      >
                                        {formatAxisValueRounded(Number(tick.value))}
                                      </text>
                                    </g>
                                  );
                                },
                              }}

                              axisBottom={{
                                renderTick: (tick) => {
                                  const value = String(tick.value);

                                  // ⭐ Completely remove ticks for spacer rows
                                  if (value.startsWith("gap-")) {
                                    return <g />;  // returns nothing → no tick line, no label
                                  }

                                  const label = value.includes("-W")
                                    ? "W" + value.split("-W")[1]
                                    : value;

                                  return (
                                    <g transform={`translate(${tick.x},${tick.y})`}>
                                      {/* normal tick line */}
                                      <line y1={0} y2={5} stroke="#666" strokeWidth={1} />

                                      {/* label */}
                                      <text
                                        y={16}
                                         className="chart-axis-text"
                                        textAnchor="middle"
                                        style={{ fontSize: filterToUseUsageByCarrier === "1_year" ? 9 : 10, fontWeight: "bond" }}
                                      >
                                        {label}
                                      </text>
                                    </g>
                                  );
                                }
                              }}

                              // onClick={(bar) => {
                              //   const t = bar.data.time;
                              //   if (!String(t).startsWith("gap-")) {
                              //     handleChartClick({ time: t }, "usageByCarrier", bar.data);
                              //   }
                              // }}
                              
                              tooltip={({ indexValue }) => {
                                const row = safeDataForNivo.find((r) => r.time === indexValue);
                                if (!row) return null;

                                const nonZero = serviceProviders.filter((p) => Number(row[p]) > 0);

                                return (
                                  <div
                                  className="recharts-default-tooltip"
                                    style={{
                                      background: "white",
                                      padding: "8px 10px",
                                      border: "1px solid #ccc",
                                      borderRadius: 6,
                                      fontSize: 11,
                                      minWidth: 250,   // ⭐ Required for width increase
                                      maxWidth: 350, 
                                      transform: "translate(-15%, -10%)",     
                                    }}
                                  >

                                    <div style={{
                                      fontWeight: 700, marginBottom: 6, width: "100%",
                                      textAlign: "center",
                                      paddingBottom: 4
                                    }}>
                                      {formatMonthWeek(indexValue)}
                                    </div>

                                    {nonZero.map((p) => (
                                      <div
                                        key={p}
                                        style={{
                                          display: "flex",
                                          justifyContent: "space-between",
                                          marginBottom: 4
                                        }}
                                      >
                                        <span style={{ display: "flex", gap: 6 }}>
                                          <span
                                            style={{
                                              width: 10,
                                              height: 10,
                                              background: STATUS_COLORS[p]
                                            }}
                                          />
                                          {p}
                                        </span>
                                        <span>{formatValueForTooltip(row[p])}</span>
                                      </div>
                                    ))}
                                  </div>
                                );
                              }}

                              layers={[
                                "grid",
                                "axes",

                                // ⭐ MONTH LABELS BELOW WEEKS ⭐
                                (props) => {
                                  if (!multiMonth) return null;

                                  const { xScale, innerHeight } = props;
                                  const bw =
                                    typeof (xScale as any).bandwidth === "function"
                                      ? (xScale as any).bandwidth()
                                      : 0;

                                  const monthNames = [
                                    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
                                    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
                                  ];

                                  return (
                                    <g transform={`translate(0, ${innerHeight + 35})`}>
                                      {monthPositions.map((mp) => {
                                        const firstX = xScale(mp.first);
                                        const lastX = xScale(mp.last);
                                        if (firstX == null || lastX == null) return null;

                                        const originalIndex = Number(mp.month);
                                        const correctedIndex = originalIndex === 0 ? 11 : originalIndex - 1; // Fix mph.month = "00"
                                        let mid = firstX + (lastX - firstX + bw) / 2;

                                        // Shift Dec left
                                        if (originalIndex === 0) {
                                          console.clear()
                                          console.log("Dec label:", { firstX, bw, mid });
                                          mid = 30 // Adjust further if needed
                                        }

                                        return (
                                          <text
                                            key={mp.month}
                                            x={mid}
                                            y={0}
                                            textAnchor="middle"
                                            fontSize={12}
                                            className="chart-month-label"
  fill="currentColor"
                                            fontWeight={500}
                                            fontFamily="Calibri"
                                          >
                                           {monthNames[mp.month - 1]}
                                          </text>
                                        );
                                      })}
                                    </g>
                                  );
                                },


                                (props) => {
                                  const { xScale, innerHeight, bars } = props;

                                  // Safe bandwidth getter (fixes TS error)
                                  const getBandwidth = () =>
                                    (xScale as any).bandwidth ? (xScale as any).bandwidth() : 0;

                                  return (
                                    <g>
                                      {bars.map((bar) => {
                                        const time = bar.data.data.time;

                                        if (String(time).startsWith("gap-")) return null;

                                        const x = xScale(time);
                                        const width = getBandwidth();

                                        return (
                                          <rect
                                            key={`hit-${time}`}
                                            x={x}
                                            y={0}
                                            width={width}
                                            height={innerHeight}
                                            fill="rgba(0,0,0,0)"
                                            pointerEvents="all"
                                          />
                                        );
                                      })}
                                    </g>
                                  );
                                },

                                "bars",
                              ]}
                              theme={{
                                background: "transparent",
                                axis: {
                                  ticks: {
                                    text: {
                                      fill: '#000',              // ✔ Y-axis tick color (black)
                                      fontSize: 10,              // ✔ Font size 10px
                                      fontFamily: 'Calibri, sans-serif',
                                      fontWeight: 400            // ✔ Normal (not bold)
                                    }
                                  },
                                  legend: {
                                    text: {
                                      fill: "currentColor",              // ✔ Legend text color
                                      fontSize: 16,              // Adjust if needed
                                      fontFamily: 'Calibri, sans-serif',
                                      // fontWeight: 400
                                    }
                                  }
                                },
                                grid: {
                                  line: {
                                    strokeWidth: 1,
                                    strokeDasharray: '2 2'      // ✔ Dotted grid
                                  }
                                },
                                legends: {
                                  text: {
                                    fill: '#000',
                                    fontSize: 16,
                                    fontFamily: 'Calibri'
                                  }
                                }
                              }}

                            />

                            {/* ⭐ Custom Legend Button ⭐ */}
                            <div
                              style={{
                                width: "100%",
                                textAlign: "center",
                                marginTop: "225px",
                                position: "relative"
                              }}
                              className="group"
                            >
                              <button className="peer px-3 py-1 text-[16px] service-provider-button  rounded-md shadow cursor-pointer">
                                Service Providers
                              </button>

                              <div
                                className="absolute left-1/2 -translate-x-1/2 hidden peer-hover:block service-provider-tooltip shadow-lg rounded-md border p-2 w-50 z-50"
                                style={{
                                  bottom: "40px",
                                  pointerEvents: "auto",
                                  fontFamily: "Calibri",
                                  fontSize: "13px",
                                  lineHeight: "14px",
                                  // maxHeight: "250px",
                                  overflowY: "auto",
                                  paddingRight: "6px"
                                }}
                              >
                                {serviceProviders.map((provider, idx) => (
                                  <div key={idx} className="flex items-center gap-2 mb-1">
                                    <div
                                      className="w-2 h-2 rounded-sm"
                                      style={{ background: STATUS_COLORS[provider] }}
                                    ></div>
                                    <span style={{ fontSize: "13px", fontFamily: "Calibri" }}>{provider}</span>
                                  </div>
                                ))}
                              </div>
                            </div>
                          </>
                        );


                      })()
                )}
              </div>
            )}
          </div>
        )}

        
        {/* Chart 4: Plan Utilisation - Enhanced Rectangle Chart with consistent X-axis handling */}
        {features.includes("Plan Usage by Service Provider") && (
          <div className="bg-white text-gray-900 p-4 rounded-lg shadow-md graph" style={{ height: `400px` }}>
            <div className="bg-gray-100 flex justify-between items-center p-4 chart-title">
              <div className="flex items-center">
                <h2 className="font-semibold">
                  {dataSourcePlanUtilisation.planUtilisation?.data?.title || "Plan Utilisation Summary"}
                </h2>
              </div>
              <div className="flex items-center">
                <Select
                  styles={DropdownStyles}
                  value={displayPlanProvider}                  
                  onChange={(option) => setSelectedPlanProvider(option?.value ?? "")}
                  options={filteredPlanProviders}
                  placeholder="Select Provider"
                   components={{
                    IndicatorSeparator: () => null
                  }}
                  // suffixIcon={<ChevronDownIcon className="w-4 h-4 text-gray-600" />}
                // disabled={filteredPlanProviders.length === 0}
                />
                {/* <ArrowPathRoundedSquareIcon
                  className="cursor-pointer w-6 h-6 ml-2"
                  onClick={() => setFlippedChart(flippedChart === 3 ? null : 3)}
                /> */}
                <button
                  onClick={() => setFlippedChart(flippedChart === 3 ? null : 3)}
                  className="flex items-center justify-center cursor-pointer"
                  style={{
                    width: "24px",
                    height: "24px",
                    border: "none",
                    background: "transparent",
                    padding: 0,
                    marginLeft: "4px",
                  }}
                >
                  <i
                    className="fi fi-rr-flip-horizontal"
                    style={{
                      fontSize: "18px",
                      color: "currentColor",
                      lineHeight: 1,
                    }}
                  />
                </button>
              </div>
            </div>
  {renderFilterButtons("planUtilisation")}

            {flippedChart === 3 ? (
              <div style={{ height: `${cardHeight}px`, padding: "10px" }}>
                {renderTable(planUtilisationData, planDetails, 3)}
              </div>
            ) : (
      <div style={{ width: "100%", height: `${cardHeight}px`, padding: "8px", display: "flex", flexDirection: "column" }}>
                {loadingPlanUtilisation ? (
                  <div className="flex flex-row justify-center items-center h-full">
                    <Spin size="large" />
                  </div>
                ) : (
                  (() => {
                    const filterToUsePlanUtilisation = getActualFilterFromData(dataSourcePlanUtilisation.planUtilisation, internalFilterPlanUtilisation);
                    
                    if (filterToUsePlanUtilisation === "no_data") {
                      return (
                        <div className="flex flex-col items-center justify-center h-full w-full">
                          <span style={{ fontSize: 16, color: "#aaa" }}>No Data Available</span>
                        </div>
                      );
                    }

                    const { rectangleData, planNames } = 
                      processPlanRectangleData(dataSourcePlanUtilisation.planUtilisation, filterToUsePlanUtilisation, selectedTenantId, selectedPlanProvider);
                      // console.clear();
                      // console.log(
                      //   "%c RAW RECT DATA",
                      //   "color: white; background: blue; padding: 4px"
                      // );

                      // rectangleData.forEach((r: any, i: number) => {
                      //   console.log(
                      //     `#${i}`,
                      //     "original_date =", r?.date || r?.original_date,
                      //     "time =", r?.time,
                      //     "plan =", r?.plan_name,
                      //     "usage =", r?.usage_count
                      //   );
                      // });

                    if (rectangleData.length === 0) {
                      return (
                        <div className="flex flex-col items-center justify-center h-full w-full">
                          <span style={{ fontSize: 16, color: "#aaa" }}>No Data</span>
                        </div>
                      );
                    }

                    const shouldShowDualXAxis = ["1_month","3_month", "6_month", "1_year"].includes(filterToUsePlanUtilisation);
                    const uniqueXPositions = [...new Set(
                      rectangleData
                        .filter(d => !d.isSpacer && !d.isGap)
                        .map(d => d.x)
                    )].sort((a, b) => a - b);

// --- TRANSFORM RECTANGLE DATA INTO NIVO STACKED FORMAT --- //
// ❌ REMOVE: getMonth, normalizeMonthKey and all that
// We trust time from processPlanRectangleData: "MM-Wn"

// ---------- STEP 1: Sort rows by month & week (NO GAPS YET) ----------
let normalizedRows: any[] = rectangleData
  .filter((r) => !r.isSpacer && !r.isGap)
  .map((row: any) => {
    const raw = row.time ?? row.x ?? ""; // "11-W3", "01-W1"
const [mPart, wPart] = String(raw).split("-W");

const monthNum = Number(mPart);      // 1..12
const weekNum = Number(wPart) || 0;

//  DETERMINE YEAR PROPERLY
const now = new Date();
const currentMonth = now.getMonth() + 1; // 1..12

// If month is GREATER than current month → previous year
const year =
  monthNum > currentMonth
    ? now.getFullYear() - 1
    : now.getFullYear();


    return {
      ...row,
      time: String(raw), // keep label exactly as created in processor
      month: monthNum,
      week: weekNum,
      year,
    };
  });

// Sort by month then week
normalizedRows.sort((a, b) => {
 if (a.year !== b.year) return a.year - b.year;
  if (a.month !== b.month) return a.month - b.month;
  return a.week - b.week;
});

// ---------- STEP 2: Insert GAP rows BETWEEN months ----------
let processedRows: any[] = [];
let prevMonth: number | null = null;

normalizedRows.forEach((row, idx) => {

  // ❌ DO NOT add month spacing for 1-month filter
  // if (filterToUsePlanUtilisation !== "1_month") {
    if (prevMonth !== null && row.month !== prevMonth) {
      processedRows.push({ time: `gap-${idx}-0`, isGap: true });
      processedRows.push({ time: `gap-${idx}-1`, isGap: true });
    }
  // }

  processedRows.push(row);
  prevMonth = row.month;
});
// ---------- STEP 3: Build Nivo Stacked Data (INCLUDING gaps) ----------
const nivoRowsMap: Record<string, any> = {};

processedRows.forEach((row: any) => {
  if (row.isGap) {
    // create empty row for gap (so monthPositions still align)
    nivoRowsMap[row.time] = { time: row.time };
    planNames.forEach((p) => (nivoRowsMap[row.time][p] = 0));
    return;
  }

  if (!nivoRowsMap[row.time]) {
    nivoRowsMap[row.time] = { time: row.time };
    planNames.forEach((p) => (nivoRowsMap[row.time][p] = 0));
  }

  nivoRowsMap[row.time][row.plan_name] += row.usage_count || 0;
});

const nivoData = Object.values(nivoRowsMap);

// ---------- STEP 4: Build color map ----------
const PLAN_COLORS_MAP: Record<string, string> = {};
planNames.forEach((p, i) => {
  PLAN_COLORS_MAP[p] = PLAN_COLORS[i % PLAN_COLORS.length];
});

// ---------- STEP 5: Group months for bottom MONTH LABELS ----------
const groups: Record<number, string[]> = {};

processedRows.forEach((r) => {
  if (r.isGap) return;
  if (!r.time || !String(r.time).includes("-W")) return;

  const [m] = String(r.time).split("-W");
  const monthNum = Number(m);
  if (!monthNum) return;

  if (!groups[monthNum]) groups[monthNum] = [];
  groups[monthNum].push(r.time);
});

const monthPositions = Object.keys(groups)
  .map(Number)
  .sort((a, b) => a - b)
  .map((m) => ({
    month: m,
    first: groups[m][0],
    last: groups[m][groups[m].length - 1],
  }));

const monthNames = [
  "Jan", "Feb", "Mar", "Apr", "May", "Jun",
  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
];

// REPLACE your existing formatMonthWeek with this:
const formatMonthWeek = (timeLabel: any) => {
  const str = String(timeLabel || "");

  if (str.includes("-W")) {
    const [mm, wn] = str.split("-W");
    const mmNum = Number(mm);
    const idx = (mmNum >= 1 && mmNum <= 12) ? mmNum - 1 : null;
    if (idx !== null) return `${monthNames[idx]} - W${wn}`;
    // fallback: if mm is zero-based  (rare) treat mm as 0-based
    const maybeZeroBased = Number(mm);
    if (!isNaN(maybeZeroBased) && maybeZeroBased >= 0 && maybeZeroBased <= 11) {
      return `${monthNames[maybeZeroBased]} - W${wn}`;
    }
  }
 
  // else fallback to current month.
  if (/^W\d+$/i.test(str)) {
    // find a monthPositions entry that contains this week (if monthPositions exists)
    if (Array.isArray(monthPositions) && monthPositions.length > 0) {
      for (const mp of monthPositions) {
        // monthPositions entries use 'first'/'last' in "MM-Wn" format
        if (!mp.first || !mp.last) continue;
        // build array of weeks for this month
        const firstW = Number(String(mp.first).split("-W")[1] || "1");
        const lastW = Number(String(mp.last).split("-W")[1] || firstW);
        const thisW = Number(str.replace(/^W/, ""));
        if (thisW >= firstW && thisW <= lastW) {
          const mm = Number(mp.month);
          const idx = (mm >= 1 && mm <= 12) ? mm - 1 : (mm >= 0 && mm <= 11 ? mm : new Date().getMonth());
          return `${monthNames[idx]} - ${str}`;
        }
      }
    }
    // fallback to current month if we couldn't infer
    return `${monthNames[new Date().getMonth()]} - ${str}`;
  }

  // last fallback: return original string
  return str;
};


// ---- COMPUTE REAL STACKED MAX ----
const stackedTotals = nivoData
  .filter(r => !String(r.time).startsWith("gap-"))
  .map(r =>
    planNames.reduce((sum, p) => sum + (Number(r[p]) || 0), 0)
  );

let realMax = Math.max(...stackedTotals);

// fallback safety
if (!isFinite(realMax) || realMax <= 0) {
  realMax = 1;
}

// STEP 3: convert max KB to selected unit (same as tooltip)
const convertFromKB = (valueKB: number) => {
  const divisor =
    selectedByteUnit === "GB"
      ? 1024 * 1024
      : selectedByteUnit === "MB"
      ? 1024
      : 1;

  return valueKB / divisor;
};

const maxInUnit = convertFromKB(realMax);

// STEP 4: dynamic step based on tooltip range
const getDynamicStep = (value: number) => {
  if (value <= 10) return 2;
  if (value <= 50) return 10;
  if (value <= 100) return 20;
  return Math.ceil(value / 5);
};

const stepInUnit = getDynamicStep(maxInUnit);

// STEP 5: final axis max in selected unit
const axisMaxInUnit =
  Math.ceil(maxInUnit / stepInUnit) * stepInUnit;

// convert back to KB for Nivo scale
const unitDivisor =
  selectedByteUnit === "GB"
    ? 1024 * 1024
    : selectedByteUnit === "MB"
    ? 1024
    : 1;

const axisMaxKB = axisMaxInUnit * unitDivisor;
// STEP 6: build tick values (still in KB)
const tickValues: number[] = [];
for (let i = 0; i <= axisMaxInUnit; i += stepInUnit) {
  tickValues.push(i * unitDivisor);
}

/* ---- SMART Y AXIS RANGE + STEP CALCULATION ---- */



const formatFromKB = (
  valueInKB: number,
  unit: "KB" | "MB" | "GB"
) => {
  if (unit === "KB") {
    // round to nearest 10,000 KB
    const roundedKB = Math.round(valueInKB / 10000) * 10000;
    return `${roundedKB} KB`;
  }

  if (unit === "MB") {
    const valueMB = valueInKB / 1024;

    // round to nearest 10,000 MB
    const rounded = Math.round(valueMB / 10000) * 10000;
    return `${rounded} MB`;
  }

  // GB
  return `${Math.round(valueInKB / (1024 * 1024))} GB`;
};





                    return (
                      <div style={{ position: "relative", width: "100%", height: "100%" }}>
                        <ResponsiveBar
                          key={`bar-${filterToUsePlanUtilisation}-${nivoData.length}-${monthPositions.length}`}
                          data={nivoData}
                          keys={planNames}
                          indexBy="time"
                          groupMode="stacked"
                          padding={0.10}
                          innerPadding={0}
                          indexScale={{ type: "band", round: false }}
                          label={() => ""}
                          enableLabel={false}
                          labelSkipWidth={9999}
                          labelSkipHeight={9999}

                          /* -------------- FIXED Y AXIS CALCULATION -------------- */
                          valueScale={{ type: "linear", min: 0, max:axisMaxKB }}
                          margin={{
                            top: 24,
                            right: 20,
                            bottom: shouldShowDualXAxis ? 88 : 60,
                            left: selectedByteUnit === "KB" ? 120 : selectedByteUnit === "MB" ? 115 : 85
                          }}
                          colors={({ id }) => PLAN_COLORS_MAP[id as string]}
                          enableGridY

                          axisLeft={{
                            tickSize: 5,
                            tickPadding: 5,
                            tickRotation: 0,
                            tickValues,
                            legend: "Usage",
                            // legendPosition: "start",
                            legendOffset: selectedByteUnit === "KB" ? -110 : selectedByteUnit === "MB" ? -100 : -80,
                            //  legendOffset: -80, // 
                            format: (v) => formatValueForTooltip(v),
                            renderTick: (tick) => {
                              return (
                                <g transform={`translate(${tick.x},${tick.y})`}>
                                  <text
                                    x={-6}
                                    textAnchor="end"
                                    dominantBaseline="middle"
                                    className="chart-axis-text"
                                    style={{
                                   
                                      fontSize: 12,      // ✔ font size 10px
                                      fontFamily: "Calibri, sans-serif",
                                      fontWeight: 400,   // normal (not bold)
                                    }}
                                  >
                                     {formatFromKB(Number(tick.value), selectedByteUnit)}
                                  </text>
                                </g>
                              );
                            },
                          }}

                          axisBottom={{
                            renderTick: (tick) => {
                              const value = String(tick.value);
                              if (value.startsWith("gap-")) return <g />;
                              const label = value.includes("-W") ? "W" + value.split("-W")[1] : value;

                              return (
                                <g transform={`translate(${tick.x},${tick.y})`}>
                                  <line y1={0} y2={5} stroke="#666" strokeWidth={1} />
                                  <text
                                    y={16}
                                    textAnchor="middle"
                                      className="chart-axis-text"
                                    style={{  fontSize: filterToUsePlanUtilisation === "1_year" ? 9 : 10 }}
                                  >
                                    {label}
                                  </text>
                                </g>
                              );
                            }
                          }}

                          /* ------------------ FIXED TOOLTIP ------------------ */
                          tooltip={({ indexValue }) => {
                            const row = nivoData.find(r => r.time === indexValue);
                            if (!row) return null;
                            const nonZeroPlans = planNames.filter(p => Number(row[p]) > 0);
                             const index = nivoData.findIndex(r => r.time === indexValue);
  const total = nivoData.length;

  const isRightSide = index > total * 0.35;
  const isLeftSide  = index < total * 0.35;

                            return (
                              <div 
                                className="recharts-default-tooltip"
                              style={{
                                background: "white",
                                padding: "8px 10px",
                                border: "1px solid #ccc",
                                borderRadius: 6,
                                fontSize: 11,
                                minWidth: 250,
                                maxWidth: 350,
                                marginLeft: isRightSide ? -100 : isLeftSide ? 20 : 0,
                              }}>
                                <div style={{
                                  width: "100%",
                                  textAlign: "center",
                                  fontWeight: 700,
                                  fontSize: 12,
                                  marginBottom: 6,
                                  paddingBottom: 4
                                }}>
                                  {formatMonthWeek(indexValue)}
                                </div>

                                {nonZeroPlans.map((p) => (
                                  <div key={p} style={{ display: "flex", justifyContent: "space-between", marginBottom: 4 }}>
                                    <span style={{ display: "flex", gap: 6 }}>
                                      <span style={{ width: 10, height: 10, background: PLAN_COLORS_MAP[p] ,borderRadius: "50%",}} />
                                      {p}
                                    </span>
                                    <span>{formatValueForTooltip(row[p])}</span>
                                  </div>
                                ))}
                              </div>
                            );
                          }}

                          layers={[
                            "grid",
                            "axes",

                            /* ---------------- MONTH LABEL LAYER (FIXED) ---------------- */
                            (props) => {
                              const { xScale, innerHeight } = props;
                              const bw =
                                typeof (xScale as any).bandwidth === "function"
                                  ? (xScale as any).bandwidth()
                                  : 0;

                              return (
                                <g transform={`translate(0, ${innerHeight + 35})`}>
                                  {monthPositions.map((mp) => {
                                    const firstX = (xScale as any)(mp.first);
                                    const lastX = (xScale as any)(mp.last);
                                    if (firstX == null || lastX == null) return null;

                                    // Mid between first & last bar of each month
                                    const mid = firstX + (lastX - firstX + bw) / 2;

                                    return (
                                      <text
                                        key={mp.month}
                                        x={mid}
                                        y={0}
                                        textAnchor="middle"
                                          className="chart-month-label"
                                        fontSize={12}
                                        fontFamily="Calibri"
                                        fontWeight={500}
                                     
                                      >
                                        {monthNames[mp.month - 1]}
                                      </text>
                                    );
                                  })}
                                </g>
                              );
                            },

                            /* ---------------- HITBOX FIX (DON'T SHOW TOOLTIP ON GAP) ---------------- */
                            (props) => {
                              const { xScale, innerHeight, bars } = props;
                              const bw =
                                typeof (xScale as any).bandwidth === "function"
                                  ? (xScale as any).bandwidth()
                                  : 0;

                              return (
                                <g>
                                  {bars.map((bar) => {
                                    const time = bar.data.data.time;
                                    if (String(time).startsWith("gap-")) return null;

                                    return (
                                      <rect
                                        key={`hit-${time}`}
                                        x={(xScale as any)(time)}
                                        width={bw}
                                        y={0}
                                        height={innerHeight}
                                        fill="rgba(0,0,0,0)"
                                        pointerEvents="all"
                                      />
                                    );
                                  })}
                                </g>
                              );
                            },

                            "bars",
                          ]}


                          theme={{
                            background:  "transparent",
                            axis: {
                              ticks: {
                                text: { fill:  "currentColor", fontSize: 10, fontFamily: "Calibri", fontWeight: 400 }
                              },
                              legend: { text: { fill:  "currentColor", fontSize: 16, fontFamily: "Calibri" } }
                            },
                            grid: { line: { strokeWidth: 1, strokeDasharray: "2 2" } },
                            legends: { text: { fill:  "currentColor", fontSize: 16, fontFamily: "Calibri" } }
                          }}
                        />


  {/* ⭐ Custom Legend Button ⭐ */}
<div
  style={{
    width: "100%",
    textAlign: "center",
    marginTop: "225px",
    position: "relative"
  }}
  className="group"
>
  <button className="peer px-3 py-1 text-[16px] service-provider-button rounded-md shadow cursor-pointer">
 Rate Plans
  </button>

  <div
    className="absolute left-1/2 -translate-x-1/2 hidden peer-hover:block service-provider-tooltip  shadow-lg rounded-md border p-2 w-50 z-50"
    style={{
      bottom: "40px",
      pointerEvents: "none",
      fontSize: "13px",
      fontFamily: "Calibri",
      lineHeight: "14px",
      // maxHeight: "250px",
      overflowY: "auto",
      paddingRight: "6px"
    }}
  >
    {planNames.map((name, idx) => (
      <div key={idx} className="flex items-center gap-2 mb-1">
        <div
          className="w-2 h-2 rounded-full"
          style={{ background: PLAN_COLORS_MAP[name] }}
        ></div>
        <span style={{ fontSize: "13px",fontFamily: "Calibri" }}>{name}</span>
      </div>
    ))}
  </div>
</div>

                      </div>
                    );
                  })()
                )}
              </div>
            )}
          </div>
        )}

      </div>

      <style jsx global>{`
        div::-webkit-scrollbar {
          width: 6px;
        }
        div::-webkit-scrollbar-track {
          background: #f1f1f1;
          border-radius: 3px;
        }
        div::-webkit-scrollbar-thumb {
          background: #888;
          border-radius: 3px;
        }
        div::-webkit-scrollbar-thumb:hover {
          background: #555;
        }
        
        /* Fix for last data points being unclickable */
        .recharts-wrapper {
          overflow: visible !important;
        }
        
        .recharts-surface {
          overflow: visible !important;
        }
        
        /* Ensure tooltips are properly positioned and visible */
        .recharts-tooltip-wrapper {
          pointer-events: none !important;
          z-index: 1000 !important;
        }
        
        /* Make dots more accessible on chart edges */
        .recharts-dot {
          pointer-events: all !important;
        }
        
        .recharts-active-dot {
          pointer-events: all !important;
        }
      `}</style>
    </div>
  );
};

const renderControls = () => {

  return (
    // <div className="w-full" style={{ paddingLeft: "24px", paddingRight: "24px" }}>
      <div
        className="flex flex-row flex-nowrap items-center justify-between w-full p-2 overflow-x-auto"
        style={{ gap: '8px', whiteSpace: 'nowrap' }}
      >        {/* Left side - All controls in one line */}
      <div className="flex flex-row flex-nowrap items-center" style={{ gap: '6px' }}>
        <Select
          className="min-w-[170px] w-[200px]"
          value={{ label: selectedFilter, value: selectedFilter }}
          onChange={(opt) => handleFilterChange(opt?.value ?? "")}
          options={filterOptions.options}
          placeholder="Tenant"
          isSearchable
          noOptionsMessage={() => "No options"}
          styles={{
            ...DropdownStyles,
            control: (base, state) => ({
              ...DropdownStyles.control(base, state),
              paddingRight: "0px",
            }),
            indicatorsContainer: (base) => ({
              ...base,
              paddingRight: "0px",
            }),
            dropdownIndicator: (base) => ({
              ...base,
              padding: "0 2px",
              paddingRight: "4px", 
              width: "18px",
            }),
            valueContainer: (base) => ({
              ...base,
              paddingRight: "2px",
            }),
            singleValue: (base) => ({
              ...DropdownStyles.singleValue(base),
              marginRight: "0px",
            }),
          }}

          components={{
            IndicatorSeparator: () => null
          }}
          menuPlacement="auto"
          menuPortalTarget={document.body}
        />
        {showBillingCyclePeriod && selectedServiceProvider !== "All service providers" && (
          <Select
            className="min-w-[150px]" 
            value={{ label: selectedBillingCyclePeriod, value: selectedBillingCyclePeriod }}
            onChange={(opt) => handleBillingCyclePeriodChange(opt?.value ?? "")}
            options={billingCyclePeriods.map(period => ({
              value: period,
              label: period
            }))}
            placeholder="Billing Cycle"
            styles={{
              ...DropdownStyles,
              control: (base, state) => ({
                ...DropdownStyles.control(base, state),
                paddingRight: "0px",
              }),
              indicatorsContainer: (base) => ({
                ...base,
                paddingRight: "0px",
              }),
              dropdownIndicator: (base) => ({
                ...base,
                padding: "0 2px",
                width: "18px",
                paddingRight: "4px", 
              }),
              valueContainer: (base) => ({
                ...base,
                paddingRight: "2px",
              }),
              singleValue: (base) => ({
                ...DropdownStyles.singleValue(base),
                marginRight: "0px",
              }),
            }}
            components={{
              IndicatorSeparator: () => null
            }}
            menuPlacement="auto"
            menuPortalTarget={document.body}
          />
        )}

        <Select
          className="min-w-[170x]"
          value={{ label: selectedServiceProvider, value: selectedServiceProvider }}
          onChange={(opt) => handleServiceProviderChange(opt?.value ?? "")}
          options={serviceProviders.map(provider => ({
            value: provider,
            label: provider
          }))}
          placeholder="Service Provider"
          styles={{
            ...DropdownStyles,
            control: (base, state) => ({
              ...DropdownStyles.control(base, state),
              paddingRight: "0px",
            }),
            indicatorsContainer: (base) => ({
              ...base,
              paddingRight: "0px",
            }),
            dropdownIndicator: (base) => ({
              ...base,
              padding: "0 2px",
              paddingRight: "4px", 
              width: "18px",
            }),
            valueContainer: (base) => ({
              ...base,
              paddingRight: "2px",
            }),
            singleValue: (base) => ({
              ...DropdownStyles.singleValue(base),
              marginRight: "0px",
            }),
          }} components={{
            IndicatorSeparator: () => null
          }}
          menuPlacement="auto"
          menuPortalTarget={document.body}
        />
        
        {/* // Add this Select component in the renderControls() function, after the date range picker: */}

        <Select
          className="w-[70px]"
          value={
            selectedByteUnit
              ? { label: selectedByteUnit, value: selectedByteUnit }
              : null
          }
          onChange={(opt) => setSelectedByteUnit(opt?.value as "GB" | "MB" | "KB")}
          options={[
            { value: "KB", label: "KB" },
            { value: "MB", label: "MB" },
            { value: "GB", label: "GB" },
          ]}
          placeholder="Unit"
          styles={{
            ...DropdownStyles,
            control: (base, state) => ({
              ...DropdownStyles.control(base, state),
              paddingRight: "0px",
            }),
            indicatorsContainer: (base) => ({
              ...base,
              paddingRight: "0px",
            }),
            dropdownIndicator: (base) => ({
              ...base,
              padding: "0 2px",
              paddingRight: "4px", 
              width: "18px",
            }),
            valueContainer: (base) => ({
              ...base,
              paddingRight: "2px",
            }),
            singleValue: (base) => ({
              ...DropdownStyles.singleValue(base),
              marginRight: "0px",
            }),
          }}
          components={{
              IndicatorSeparator: () => null
            }}
            menuPlacement="auto"
            menuPortalTarget={document.body}
        />

        {/* "Select:" text - aligned with other elements */}
        <span 
        style={{
          fontFamily: "Calibri, sans-serif",
          fontSize: "14px",
          // color: "currentColor",
          whiteSpace: "nowrap",
          marginLeft: "12px",
          marginRight: "4px",
          height: "38px",
          display: "flex",
          alignItems: "center",
        }} className="dashboard-select-text"
        >
          Select:
        </span>

        {/* Time selection buttons - same height as selects */}
        <button
          className={selectedButton === "Current Month" ? "save-btn  !min-h-[40px]" : "email-dashboard-btns"}
          onClick={() => handleButtonClick("Current Month")}
          style={{
            fontFamily: "Calibri,sans-serif",
            fontSize: 13,
            padding: "0 12px",
            height: 38,
            // borderRadius: 7,
            minWidth: "60px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          Month
        </button>

        <button
          className={selectedButton === "Current Week" ? "save-btn  !min-h-[40px]" : "email-dashboard-btns"}
          onClick={() => handleButtonClick("Current Week")}
          style={{
            fontFamily: "Calibri,sans-serif",
            fontSize: 13,
            padding: "0 12px",
            height: 38,
            // borderRadius: 7,
            minWidth: "55px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          Week
        </button>

        <button
          className={selectedButton === "Today" ? "save-btn  !min-h-[40px]" : "email-dashboard-btns"}
          onClick={() => handleButtonClick("Today")}
          style={{
            fontFamily: "Calibri,sans-serif",
            fontSize: 13,
            padding: "0 12px",
            height: 38,
            // borderRadius: 7,
            minWidth: "55px",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
          }}
        >
          Today
        </button>

        {/* Date Range */}
        <RangePicker
          value={dateRange}
          onChange={handleDateRangeChange}
          style={{
            width: 220,
            height: 38,
            borderRadius: 7,
            fontSize: 12,
            marginLeft: 4,
          }}
          popupClassName="custom-range-popup"
          disabledDate={current => current && current > dayjs().endOf("day")}
          placeholder={["Start", "End"]}
          disabled={(showBillingCyclePeriod && selectedBillingCyclePeriod !== "None")}
        />

      </div>
        
        {/* Right side - Action buttons */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 8,
            flexShrink: 0,
          }}
        >
          <DashboardRefresh tabName={"Usage Insights"} onRefresh={initializeDashboard} tabKey={"usage_insights"}/>
          <DashboardColumnFilter tabName={"Usage Insights"} setFeatures={setFeatures}    selectedByteUnit={selectedByteUnit}
/>
        </div>
      </div>
    // </div>
  );
};


  return (
    <>
      {loading ? (
        <div className="flex justify-center items-center h-screen">
          <Spin size="large" />
        </div>
      ) : (
        <Suspense fallback={<Spin size="large" />}>
          {renderControls()}
          <UsageInsightsCards
          key={`${selectedTenantId}-${selectedServiceProvider}-${selectedBillingCyclePeriod}-${selectedFilter}`}
            selectedTenantId={selectedTenantId}
            // ✅ FIX: Do NOT send start & end date when billing cycle dropdown is used
          startDate={
           startDate
          }
          endDate={
             endDate
          }
            billingCyclePeriod={selectedServiceProvider === "All service providers" ? "" : selectedBillingCyclePeriod}
            selectedServiceProvider={selectedServiceProvider  === "All service providers" ? "" : selectedServiceProvider}
            serviceProvider={selectedFilter === "All Tenants" ? "All" : selectedFilter}
            features={features}
            selectedByteUnit={selectedByteUnit}
          />

          {renderNewChartsWithScrolling()}
        </Suspense>
      )}
      
      {/* Add redirect notification components */}
      {renderRedirectOverlay()}
      {renderRedirectNotification()}
    </>
  );
};

export default UsageInsights;