
"use client";
import React, { lazy, Suspense, useEffect, useState, ReactElement, useRef } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "../components/auth_context";
import { useLogoStore } from "../stores/logoStore";
import { ResponsiveBar } from "@nivo/bar";
import {
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  ResponsiveContainer,
  Label,
  Customized,
  LineChart,
  Line,
  LabelList,
  Cell,
  Scatter,
  CartesianGrid,
  ScatterChart,
  ZAxis,
  ComposedChart,
  ReferenceArea
} from "recharts";
import { ENV_ROUTES } from "../components/routes/route_constants";
import axios from "axios";
import { getCurrentDateTime } from "../components/header_constants";
import { Button, DatePicker, Spin, Table } from "antd";
import Select from "react-select";
import { ChevronDownIcon, ArrowPathRoundedSquareIcon } from "@heroicons/react/24/outline";
import moment from "moment";
import dayjs, { Dayjs } from "dayjs";
import { Sparklines, SparklinesLine } from "react-sparklines";
import { useInventoryRedirectStore } from "../stores/inventoryRedirectStore";
import DashboardColumnFilter from "./dashboardColumnFilter";
import DashboardRefresh from "./dashboardRefreshComponent";
import { DropdownStyles } from "../components/css/dropdown";

const RevenueMetricCards = lazy(() => import("@/app/dashboard_2_0/RevenueMetricCards"));
const { RangePicker } = DatePicker;

// **UPDATED CONSTANTS** - Fixed card heights to match Sims Overview
const FIXED_CARD_HEIGHT = 280; // Base height for all cards (reduced from variable heights)
const FIXED_CONTAINER_HEIGHT = 400; // Total container height including header/controls
const NO_EXPANSION_ON_FLIP = true; // Prevent expansion when flipped

// Type definitions
interface FilterOption {
  value: string;
  label: string;
  tenant_id: string;
}

interface FilterOptions {
  options: FilterOption[];
}

interface RevenueChartData {
  revenueByCarrier: any | null;
  revenueByRatePlan: any | null;
  profitMarginTrend: any | null;
  revenueByUsageTrend: any | null;
}

interface ProcessedRevenueData {
  chartData: Array<{
    carrier?: string;
    plan?: string;
    usage_type?: string;
    month?: string;
    revenue?: number;
    percentage?: number;
    profit_margin?: number;
    total_revenue?: number;
    details?: any;
    time?: string;
    totalRevenue?: number;
  }>;
  details: { [key: string]: { [date: string]: number } };
  timeSeriesData?: any[];
  topPlans?: string[];
  isWeekBasedFilter?: boolean;
  weekLabels?: string[];
}


interface CustomTooltipProps {
  active?: boolean;
  payload?: Array<{
    value: number;
    name: string;
    dataKey: string;
    color?: string;
  }>;
  label?: string;
  details?: { [key: string]: { [date: string]: number } };
  filter?: any;
}

interface TickProps {
  x?: number;
  y?: number;
  payload?: { value: string };
}

interface ProcessedTimeBasedData {
  chartData: Array<{ time: string; profit_margin: number }>;
  details: { [timeLabel: string]: { [date: string]: number } };
  isWeekBasedFilter: boolean;
  weekLabels: string[];
}
interface ServiceProviderData {
  unique_service_providers: string[];
  billing_period_dates: { [provider: string]: string[] };
}
type CarrierTimeData = {
  [timeLabel: string]: number;
} & {
  statistic: number[];
};

interface EnhancedResponsiveContainerProps {
  dataLength: number;
  height: number;
  children: ReactElement;
  width?: string; // Add this line
}
interface PayloadEntry {
  dataKey: string;
  value: number;
}

// Add this helper function at the top of your component
const formatYAxisTicks = (value:any) => {
  if (value === 0) return '$0';
  
  // Round to nearest 5 or 10 based on magnitude
  let roundedValue;
  if (value < 10) {
    roundedValue = Math.ceil(value / 5) * 5;
  } else if (value < 100) {
    roundedValue = Math.ceil(value / 10) * 10;
  } else if (value < 1000) {
    roundedValue = Math.ceil(value / 50) * 50;
  } else {
    roundedValue = Math.ceil(value / 100) * 100;
  }
  
  return `$${roundedValue}`;
};


interface RectangleTooltipProps {
  active: boolean;
  payload: any;
  label: any;
  coordinate: any;
}
const EnhancedResponsiveContainer: React.FC<EnhancedResponsiveContainerProps> = ({ dataLength, height, children }) => {
  return (
    <div style={{
      width: "100%",
      height: `${height}px`,
      overflow: "hidden",
      position: "relative"
    }}>
      <ResponsiveContainer width="100%" height={height}>
        {children}
      </ResponsiveContainer>
    </div>
  );
};


// Color constants - FIXED: Week-based colors for consistency
// 1. Update color constants to match sims overview
const BLUE_SHADES = [
  "#74B9FF", "#A29BFE", "#FF7675", "#81ECEC", "#D980FA", "#55EFC4", 
  "#FABE58", "#00B894", "#FF9FF3", "#00CEC9", "#BDC3C7", "#FFEAA7"
];

// Week-based colors for consistency
const WEEK_COLORS = [
  '#8b5cf6', '#06b6d4', '#10b981', '#f59e0b', '#ef4444'
] as const;
// Updated plan colors for rectangles
const PLAN_COLORS = [
  "#74B9FF", "#A29BFE", "#FF7675", "#81ECEC", "#D980FA", "#55EFC4", 
  "#FABE58", "#00B894", "#FF9FF3", "#00CEC9", "#BDC3C7", "#FFEAA7"
];
// Helper functions for time-based processing
const getWeekNumber = (date: Date, monthStart: Date): number => {
  const dayDiff = Math.floor((date.getTime() - monthStart.getTime()) / (1000 * 60 * 60 * 24));
  return Math.floor(dayDiff / 7) + 1;
};

const getMonthName = (monthIndex: number): string => {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return months[monthIndex] || monthIndex.toString();
};

const formatDateForTooltip = (dateString: string): string => {
  if (!dateString) return "Invalid Date";
  try {
    let parsedDate: moment.Moment;
    if (dateString.includes("'T'") && dateString.includes("'Z'")) {
      const cleanedDate = dateString.replace(/'/g, "");
      parsedDate = moment(cleanedDate);
    } else if (dateString.includes('T')) {
      parsedDate = moment(dateString);
    } else if (dateString.includes('-')) {
      parsedDate = moment(dateString, 'YYYY-MM-DD');
    } else if (dateString.includes('/')) {
      parsedDate = moment(dateString, ['MM/DD/YYYY', 'DD/MM/YYYY']);
    } else {
      parsedDate = moment(dateString);
    }
    if (!parsedDate.isValid()) {
      return "Invalid Date";
    }
    return parsedDate.format("MMM DD, YYYY");
  } catch (error) {
    return "Invalid Date";
  }
};


const generateYAxisTicks = (rectangleData: any[]) => {
  if (!rectangleData || rectangleData.length === 0) return [0];

  const values = rectangleData
    .filter(d => !d.isGap && !d.isSpacer)
    .map(d => Number(d.y) || 0); // IMPORTANT: you use dataKey="y"

  const max = Math.max(...values);

  if (max <= 10) return [0, 5, 10];
  if (max <= 20) return [0, 10, 20];
  if (max <= 50) return [0, 10, 20, 30, 40, 50];
  if (max <= 100) return [0, 20, 40, 60, 80, 100];
  if (max <= 500) return [0, 100, 200, 300, 400, 500];
  if (max <= 1000) return [0, 200, 400, 600, 800, 1000];

  const step = Math.ceil(max / 5 / 100) * 100;
  return Array.from({ length: 6 }, (_, i) => i * step);
};


const RevenueMetrics: React.FC = () => {
  const router = useRouter();
  const { username, partner, role, selectedDb,metaData, token, firstLastName, sessionId, setSelectedPartner } = useAuth();
  const setTitle = useLogoStore((state) => state.setTitle);
    const { setFilters, setRedirected, clearFilters } = useInventoryRedirectStore();
  const [showRedirectNotification, setShowRedirectNotification] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(true);
  const [allApisLoaded, setAllApisLoaded] = useState<boolean>(false);
  const [filterOptions, setFilterOptions] = useState<FilterOptions>({ options: [] });
  const [selectedFilter, setSelectedFilter] = useState<string>(partner || "");
  const [selectedTenantId, setSelectedTenantId] = useState<string>("");
  const [selectedButton, setSelectedButton] = useState<string | null>("Current Month");
  const [startDate, setStartDate] = useState<string>(moment().startOf("month").format("YYYY-MM-DD"))
  const [endDate, setEndDate] = useState<string>(moment().format("YYYY-MM-DD"));
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([null, null]);
  const [flippedChart, setFlippedChart] = useState<number | null>(null);
  const [chartData, setChartData] = useState<RevenueChartData>({
    revenueByCarrier: null,
    revenueByRatePlan: null,
    profitMarginTrend: null,
    revenueByUsageTrend: null,
  });
  const [tickPositions, setTickPositions] = useState<{ coordinate: number }[]>([]);
  const [cachedData, setCachedData] = useState<RevenueChartData>({
    revenueByCarrier: null,
    revenueByRatePlan: null,
    profitMarginTrend: null,
    revenueByUsageTrend: null,
  });
  const [internalFilterRevenueByCarrier, setInternalFilterRevenueByCarrier] = useState<string>("1_month");
  const [internalFilterRevenueByRatePlan, setInternalFilterRevenueByRatePlan] = useState<string>("1_month");
  const [internalFilterProfitMarginTrend, setInternalFilterProfitMarginTrend] = useState<string>("1_month");
  const [internalFilterRevenueByUsageTrend, setInternalFilterRevenueByUsageTrend] = useState<string>("1_month");
  // const [selectedRatePlanProvider, setSelectedRatePlanProvider] = useState<string | undefined>('');
  const [selectedRatePlanProvider, setSelectedRatePlanProvider] =useState<string | undefined>(undefined);

  const [selectedUsageProvider, setSelectedUsageProvider] = useState<string | undefined>('');
  const [isSmallMediumScreen, setIsSmallMediumScreen] = useState<boolean>(false);
  const [useCache, setUseCache] = useState<boolean>(false);
  // NEW: Service Provider and Billing Cycle states
const [serviceProviders, setServiceProviders] = useState<string[]>([]);
const [selectedServiceProvider, setSelectedServiceProvider] = useState<string>("All service providers");
const [billingCyclePeriods, setBillingCyclePeriods] = useState<string[]>([]);
const [selectedBillingCyclePeriod, setSelectedBillingCyclePeriod] = useState<string>("");
const [showBillingCyclePeriod, setShowBillingCyclePeriod] = useState<boolean>(false);
const [serviceProviderData, setServiceProviderData] = useState<ServiceProviderData | null>(null);
// Add this state (you already have it but need to use it correctly)
const [isExpanded, setIsExpanded] = useState<boolean>(false);
const [hoveredWeek, setHoveredWeek] = useState(null);
const [legendVisible, setLegendVisible] = useState(false);

const ratePlanProvidersByMonth = React.useMemo(() => {
  const res = chartData.revenueByRatePlan || cachedData.revenueByRatePlan;

  if (!res?.data?.data?.[internalFilterRevenueByRatePlan] || !res?.meta?.providers) {
    return [];
  }

  const providersMap = res.meta.providers;

  return Array.from(
    new Set(
      res.data.data[internalFilterRevenueByRatePlan]
        .map((item: any) => providersMap[item.provider_id]) 
        .filter(Boolean)
    )
  ).map((provider) => ({
    label: provider,
    value: provider,
  }));
}, [
  chartData.revenueByRatePlan,
  cachedData.revenueByRatePlan,
  internalFilterRevenueByRatePlan,
]);

const usageProvidersByMonth = React.useMemo(() => {
  const res = chartData.revenueByUsageTrend || cachedData.revenueByUsageTrend;

  if (
    !res?.data?.data?.[internalFilterRevenueByUsageTrend] ||
    !res?.meta?.providers
  ) {
    return [];
  }

  const providersMap = res.meta.providers;

  return Array.from(
    new Set(
      res.data.data[internalFilterRevenueByUsageTrend]
        .map((item: any) => providersMap[item.provider_id]) 
        .filter(Boolean)
    )
  ).map((provider) => ({
    label: provider,
    value: provider,
  }));
}, [
  chartData.revenueByUsageTrend,
  cachedData.revenueByUsageTrend,
  internalFilterRevenueByUsageTrend,
]);

// --- Helpers to compute unique provider lists from meta ---

const uniqueRatePlanProviders = React.useMemo(() => {
  const meta = chartData.revenueByRatePlan?.meta?.providers || cachedData.revenueByRatePlan?.meta?.providers || {};
  return Array.from(new Set(Object.values(meta).filter(Boolean))) as string[];
}, [chartData.revenueByRatePlan, cachedData.revenueByRatePlan]);
const ratePlanOptions = React.useMemo(
  () =>
    uniqueRatePlanProviders.map((provider) => ({
      value: provider,
      label: provider,
    })),
  [uniqueRatePlanProviders]
);
const displayRatePlanProvider = React.useMemo(
  () =>
    ratePlanOptions.find((opt) => opt.value === selectedRatePlanProvider) ||
    null,
  [ratePlanOptions, selectedRatePlanProvider]
);
const uniqueUsageProviders = React.useMemo(() => {
  const meta = chartData.revenueByUsageTrend?.meta?.providers || cachedData.revenueByUsageTrend?.meta?.providers || {};
  // drop "All" and duplicates
  return Array.from(new Set(Object.values(meta).filter((p: any) => p && p !== "All"))) as string[];
}, [chartData.revenueByUsageTrend, cachedData.revenueByUsageTrend]);
const usageOptions = React.useMemo(
  () => uniqueUsageProviders.map((p) => ({ value: p, label: p })),
  [uniqueUsageProviders]
);

// Get the selected option object
const displayUsageProvider = React.useMemo(
  () => usageOptions.find((opt) => opt.value === selectedUsageProvider) || null,
  [usageOptions, selectedUsageProvider]
);
// --- Clear selections if they are no longer valid after global changes ---
const suppressEffectFetchRef = useRef(false);

useEffect(() => {
  if (selectedRatePlanProvider && !uniqueRatePlanProviders.includes(selectedRatePlanProvider)) {
    setSelectedRatePlanProvider(undefined);
  }
}, [
  uniqueRatePlanProviders,
  selectedServiceProvider, // global provider
  selectedTenantId,
  startDate,
  endDate,
]);
useEffect(() => {
  if (!selectedRatePlanProvider && ratePlanProvidersByMonth.length > 0) {
    setSelectedRatePlanProvider(
      String(ratePlanProvidersByMonth[0].value)
    );
  }

  if (!selectedUsageProvider && usageProvidersByMonth.length > 0) {
    setSelectedUsageProvider(
      String(usageProvidersByMonth[0].value)
    );
  }
}, [
  ratePlanProvidersByMonth,
  usageProvidersByMonth,
  selectedRatePlanProvider,
  selectedUsageProvider,
]);

useEffect(() => {
  if (
    usageProvidersByMonth.length > 0 &&
    !usageProvidersByMonth.some(
      (o) => o.value === selectedUsageProvider
    )
  ) {
    setSelectedUsageProvider(
      String(usageProvidersByMonth[0].value)
    );
  }
}, [usageProvidersByMonth, selectedUsageProvider]);


useEffect(() => {
  if (selectedUsageProvider && !uniqueUsageProviders.includes(selectedUsageProvider)) {
    setSelectedUsageProvider(undefined);
  }
}, [
  uniqueUsageProviders,
  selectedServiceProvider, // global provider
  selectedTenantId,
  startDate,
  endDate,
]);

// --- Set a safe default (first option) but only when nothing is selected ---

// useEffect(() => {
//   if (!selectedRatePlanProvider && uniqueRatePlanProviders.length > 0) {
//     setSelectedRatePlanProvider(uniqueRatePlanProviders[0]);
//   }
// }, [uniqueRatePlanProviders, selectedRatePlanProvider]);

// useEffect(() => {
//   if (!selectedUsageProvider && uniqueUsageProviders.length > 0) {
//     setSelectedUsageProvider(uniqueUsageProviders[0]);
//   }
// }, [uniqueUsageProviders, selectedUsageProvider]);

// Add this useEffect to trigger auto-expansion (MISSING in your code)
useEffect(() => {
  const shouldExpand =
    ["3_month", "6_month", "1_year"].includes(internalFilterRevenueByCarrier) ||
    ["3_month", "6_month", "1_year"].includes(internalFilterRevenueByRatePlan) ||
    ["3_month", "6_month", "1_year"].includes(internalFilterProfitMarginTrend) ||
    ["3_month", "6_month", "1_year"].includes(internalFilterRevenueByUsageTrend);

  setIsExpanded(shouldExpand);
}, [internalFilterRevenueByCarrier, internalFilterRevenueByRatePlan, internalFilterProfitMarginTrend, internalFilterRevenueByUsageTrend]);

const [features, setFeatures] = useState<any[]>([])

  // Screen size effect
  useEffect(() => {
    const handleResize = () => {
      setIsSmallMediumScreen(window.innerWidth <= 1000);
    };
    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);
  

// Effect for service provider/billing cycle changes
useEffect(() => {
  console.log("selectedbutton triggered>>>>>>>>>>>")
  if(selectedButton == null){
    return;
  }
 
  if (selectedButton) {
   console.log(`Selected Button: ${selectedButton}, Start Date: ${startDate}, End Date: ${endDate}`);

    const internalFilter = mapGlobalDateToInternalFilter(selectedButton);
    
    setInternalFilterRevenueByCarrier(internalFilter);
    setInternalFilterRevenueByRatePlan(internalFilter);
    setInternalFilterProfitMarginTrend(internalFilter);
    setInternalFilterRevenueByUsageTrend(internalFilter);
    setUseCache(false);
     if (!suppressEffectFetchRef.current) {
       fetchChartData(startDate, endDate, false);
     }
  } else if (startDate && endDate) {
    const internalFilter = mapGlobalDateToInternalFilter("", startDate, endDate);
    
    setInternalFilterRevenueByCarrier(internalFilter);
    setInternalFilterRevenueByRatePlan(internalFilter);
    setInternalFilterProfitMarginTrend(internalFilter);
    setInternalFilterRevenueByUsageTrend(internalFilter);
    setUseCache(false);
    
    fetchChartData(startDate, endDate, false);
  }
}, [selectedButton, startDate, endDate, selectedTenantId]);

// Effect for service provider/billing cycle changes (like SimsOverview)
useEffect(() => {
  if (
    selectedTenantId &&
    ((selectedServiceProvider !== "All service providers" && selectedBillingCyclePeriod) ||
      selectedServiceProvider === "All service providers")
  ) {
    fetchChartData("", "", true);
  }
}, [selectedServiceProvider, selectedBillingCyclePeriod, selectedTenantId]);
 
const getActualFilterFromData = (data: any, internalFilter: string): string => {
 
  return internalFilter;
};

  // API Functions
  const fetchFilterOptions = async (): Promise<void> => {
    try {
      const url = ENV_ROUTES.DASHBOARD;
      const data = {
        tenant_name: partner || "default_value",
        username,
        firstLastName,
        path: "/get_all_related_tenants",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Dashboard",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (!parsedData.flag || !parsedData.data) {
        setFilterOptions({ options: [] });
        setSelectedFilter("");
        setSelectedTenantId("");
        return;
      }

      const serviceProviders: FilterOption[] = Object.entries(parsedData.data)
      .map(([key, value]) => ({
        value: key.trim(),
        label: key.trim(),
        tenant_id: String(value),
      }))
      .sort((a, b) => a.label.localeCompare(b.label));

      setFilterOptions({ options: serviceProviders });

      const partnerOption = serviceProviders.find((option) => option.value === partner);
      if (partnerOption) {
        setSelectedFilter(partnerOption.value);
        setSelectedTenantId(partnerOption.tenant_id);
         localStorage.setItem("selectedTenantId", partnerOption.tenant_id);
      } else {
        setSelectedFilter("All Tenants");
        setSelectedTenantId("All");
         localStorage.setItem(
    "selectedTenantId",
    serviceProviders[0].tenant_id
  );
      }
    } catch (error) {
      setFilterOptions({ options: [] });
      setSelectedFilter("");
      setSelectedTenantId("");
    }
  };

  // Function to fetch service providers and billing cycle data
const fetchServiceProviderData = async () => {
  try {
    const tenantId =
      selectedTenantId || localStorage.getItem("selectedTenantId");
    const url = ENV_ROUTES.DASHBOARD;
    const data = {
      tenant_name: partner || "default_value",
      username,
      firstLastName,
      path: "/get_all_service_providers_and_billing_cycle_dates_dropdown_data",
      role_name: role,
      parent_module: "Sim Management",
      module_name: "Dashboard",
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
      tenant_id: tenantId,
    };

    const response = await axios.post(url, { data });
    const parsedData = JSON.parse(response.data.body);

    if (!parsedData.flag || !parsedData.unique_service_providers) {
      setServiceProviders(["All service providers"]);
      setSelectedServiceProvider("All service providers");
      return;
    }

    const providers = parsedData.unique_service_providers;
    setServiceProviders(providers);
    setServiceProviderData(parsedData);
    setSelectedServiceProvider("All service providers");
    setShowBillingCyclePeriod(false);
    setSelectedBillingCyclePeriod("");

  } catch (error) {
    setServiceProviders(["All service providers"]);
    setSelectedServiceProvider("All service providers");
  }
};
// Handle service provider change
const handleServiceProviderChange = async (value: string) => {
 

  setSelectedServiceProvider(value);

  // ✅ RESET graph-specific provider dropdowns - set to undefined instead of empty string
  setSelectedRatePlanProvider(undefined);  // Reset 2nd graph selection
  setSelectedUsageProvider(undefined);     // Reset 4th graph selection

  if (value === "All service providers") {
    setShowBillingCyclePeriod(false);
    setSelectedBillingCyclePeriod("");
    setBillingCyclePeriods([]);
    // const defaultStart = moment().startOf("month").format("YYYY-MM-DD");
    // const defaultEnd = moment().format("YYYY-MM-DD");
    // setSelectedButton("Current Month");
    // setStartDate(defaultStart);
    // setEndDate(defaultEnd);
    // setDateRange([dayjs(defaultStart), dayjs(defaultEnd)]);
  } else {
    setShowBillingCyclePeriod(true);
    
    if (serviceProviderData?.billing_period_dates[value]) {
      const periods = serviceProviderData.billing_period_dates[value];
      setBillingCyclePeriods(["None", ...periods]);
      // FIX: Set default to first period immediately
      setSelectedBillingCyclePeriod(periods[0] || "");
    }
      // setStartDate("");
      // setEndDate("");
      // setDateRange([null, null]);
  }

  // Reset internal filters based on current global selection
  const currentInternalFilter = mapGlobalDateToInternalFilter(selectedButton || "Current Month");
  setInternalFilterRevenueByCarrier(currentInternalFilter);
  setInternalFilterRevenueByRatePlan(currentInternalFilter);
  setInternalFilterProfitMarginTrend(currentInternalFilter);
  setInternalFilterRevenueByUsageTrend(currentInternalFilter);
  setUseCache(false);
  
   // ✅ Clear date filters when billing cycle changed
    setStartDate("");
    setEndDate("");
    setDateRange([null, null]);
    setSelectedButton(null); // Removes Today/Week/Month selection

  // Clear cache
  clearCache();
};


// Handle billing cycle period change
const handleBillingCyclePeriodChange = async (value: string) => {
  setSelectedBillingCyclePeriod(value);
   // ✅ Clear date filters when billing cycle changed
    setStartDate("");
    setEndDate("");
    setDateRange([null, null]);
      if(value === "None"){
      setSelectedButton("Current Month");
    }
    else{
      setSelectedButton(null)
    }

  setUseCache(false);

  // Clear cache
  clearCache();

  // if (selectedTenantId) {
  //   await fetchChartData("", "", true);
  // }
};
// Function to map global date filters to internal filters
const mapGlobalDateToInternalFilter = (globalFilter: string, customStartDate?: string, customEndDate?: string): string => {
  
  // Handle custom date ranges
  if (customStartDate && customEndDate) {
    const start = moment(customStartDate);
    const end = moment(customEndDate);
    const diffDays = end.diff(start, 'days');
    const diffMonths = end.diff(start, 'months');
    
    if (diffDays <= 1) return "1_day";
    if (diffDays <= 7) return "5_day";
    if (diffMonths <= 1) return "1_month";
    if (diffMonths <= 3) return "3_month";
    if (diffMonths <= 6) return "6_month";
    if (diffMonths <= 12) return "1_year";
    return "max";
  }
  
  switch (globalFilter) {
    case "Today":
      return "1_day";
    case "Current Week":
      return "5_day";
    case "Current Month":
      return "1_month";
    default:
      return "1_month";
  }
};


  const fetchChartData = async (startDate: string, endDate: string, cacheData: boolean = false): Promise<void> => {
   
    if (!selectedTenantId) {
    console.warn("No tenant_id set, skipping chart data fetch");
    return;
  }

    const url = ENV_ROUTES.DASHBOARD;
    const serviceProvidersFilter = selectedFilter === "All Tenants" ? "All" : selectedFilter;
    const baseRequestData = {
      partner,
      tenant_name: partner || "default_value",
      username,
      role_name: role,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
      start_date: startDate,
      end_date: endDate,
      tenant_id: selectedTenantId,
      // service_providers: serviceProvidersFilter,
      service_provider: selectedServiceProvider === "All service providers" ? "" : selectedServiceProvider,
      billing_cycle_end_period: selectedBillingCyclePeriod === "None" || selectedServiceProvider === "All service providers" ? "" : selectedBillingCyclePeriod,      
    };


    const fetchDataForPath = async (path: string): Promise<any> => {
      try {
        const response = await axios.post(url, {
          data: { ...baseRequestData, path },
        });
        const parsedResponse = JSON.parse(response.data.body);
        return parsedResponse;
      } catch (error) {
        return null;
      }
    };

    try {
      setLoading(true);
      setAllApisLoaded(false);
      setChartData({
        revenueByCarrier: null,
        revenueByRatePlan: null,
        profitMarginTrend: null,
        revenueByUsageTrend: null,
      });
      

      const [revenueByCarrier, revenueByRatePlan, profitMarginTrend, revenueByUsageTrend] = await Promise.all([
        fetchDataForPath("/get_revenue_by_carrier"),
        fetchDataForPath("/get_revenue_by_rate_plan"),
        fetchDataForPath("/get_profit_margin_trend"),
        fetchDataForPath("/get_revenue_by_usage_trend"),
      ]);


      const newChartData = {
        revenueByCarrier: revenueByCarrier?.flag ? revenueByCarrier : null,
        revenueByRatePlan: revenueByRatePlan?.flag ? revenueByRatePlan : null,
        profitMarginTrend: profitMarginTrend?.flag ? profitMarginTrend : null,
        revenueByUsageTrend: revenueByUsageTrend?.flag ? revenueByUsageTrend : null,
      };

      if (cacheData) {
  setCachedData(newChartData);
  localStorage.setItem("revenue_by_carrier_cache", JSON.stringify({
    ...newChartData.revenueByCarrier,
    lastUpdated: new Date().toISOString()
  }));
  localStorage.setItem("revenue_by_rate_plan_cache", JSON.stringify({
    ...newChartData.revenueByRatePlan,
    lastUpdated: new Date().toISOString()
  }));
  localStorage.setItem("profit_margin_trend_cache", JSON.stringify({
    ...newChartData.profitMarginTrend,
    lastUpdated: new Date().toISOString()
  }));
  localStorage.setItem("revenue_by_usage_trend_cache", JSON.stringify({
    ...newChartData.revenueByUsageTrend,
    lastUpdated: new Date().toISOString()
  }));
  setChartData(newChartData);
} else {
  // **FIXED: Don't override internal filters - they're already set correctly**
  // The internal filters are managed by the useEffect above
  setChartData(newChartData);
}
      setUseCache(cacheData);
    } catch (error) {
      console.error("Error fetching chart data:", error);
    } finally {
      setLoading(false);
      setAllApisLoaded(true);
    }
  };

  // Cache management functions
  const checkCacheValidity = (): boolean => {
    const caches = [
      "revenue_by_carrier_cache",
      "revenue_by_rate_plan_cache",
      "profit_margin_trend_cache",
      "revenue_by_usage_trend_cache"
    ];
    
    return caches.every(cacheKey => {
      const cached = localStorage.getItem(cacheKey);
      if (!cached) return false;
      
      const { lastUpdated } = JSON.parse(cached);
      const lastUpdatedDate = new Date(lastUpdated);
      const now = new Date();
      const hoursDiff = (now.getTime() - lastUpdatedDate.getTime()) / (1000 * 60 * 60);
      return hoursDiff < 24;
    });
  };

  const clearCache = (): void => {
    localStorage.removeItem("revenue_by_carrier_cache");
    localStorage.removeItem("revenue_by_rate_plan_cache");
    localStorage.removeItem("profit_margin_trend_cache");
    localStorage.removeItem("revenue_by_usage_trend_cache");
    setCachedData({
      revenueByCarrier: null,
      revenueByRatePlan: null,
      profitMarginTrend: null,
      revenueByUsageTrend: null,
    });
    setUseCache(false);
  };

  // Initialization function
  const initializeDashboard = async (): Promise<void> => {
    setSelectedPartner(true);

    suppressEffectFetchRef.current = true;

    setSelectedButton("Current Month");
    setDateRange([null, null]);
    setLoading(true);
    
    try {
      await fetchFilterOptions();
      await fetchServiceProviderData(); // NEW: Fetch service provider data

      
      if (selectedTenantId) {
        const isCacheValid = checkCacheValidity();
        
        // if (isCacheValid) {
        //   const revenueByCarrier = JSON.parse(localStorage.getItem("revenue_by_carrier_cache") || "{}");
        //   const revenueByRatePlan = JSON.parse(localStorage.getItem("revenue_by_rate_plan_cache") || "{}");
        //   const profitMarginTrend = JSON.parse(localStorage.getItem("profit_margin_trend_cache") || "{}");
        //   const revenueByUsageTrend = JSON.parse(localStorage.getItem("revenue_by_usage_trend_cache") || "{}");
          
        //   const cachedData = {
        //     revenueByCarrier,
        //     revenueByRatePlan,
        //     profitMarginTrend,
        //     revenueByUsageTrend,
        //   };
          
        //   setCachedData(cachedData);
        //   setChartData(cachedData);
        //   setUseCache(true);
        //   setAllApisLoaded(true);
        // } else {
          clearCache();
          await fetchChartData("", "", true);
        // }
      }
    } catch (error) {
      console.error("Error during initialization:", error);
      setAllApisLoaded(true);
    } finally {
      setLoading(false);
      suppressEffectFetchRef.current = false;
    }
  };

  // Effects
  useEffect(() => {
    console.log("Initialized dashboard");
    console.log("Partner:", partner);
    initializeDashboard();
  }, [partner]);

  useEffect(() => {
    if (selectedTenantId) {
      clearCache();
      fetchChartData("", "", true);
    }
  }, [selectedTenantId]);
 

  // Event handlers
 const handleFilterChange = async (value: string): Promise<void> => {
  
  const selectedOption = filterOptions.options.find((option) => option.value === value);
  
  if (selectedOption) {

    setSelectedFilter(selectedOption.value);
    setSelectedTenantId(selectedOption.tenant_id);
    setInternalFilterRevenueByCarrier("1_month");
    setInternalFilterRevenueByRatePlan("1_month");
    setInternalFilterProfitMarginTrend("1_month");
    setInternalFilterRevenueByUsageTrend("1_month");
    
    setShowBillingCyclePeriod(false);
    setSelectedBillingCyclePeriod("");
    setBillingCyclePeriods([]);
    setStartDate("");
    setEndDate("");
    setDateRange([null, null]);
    setSelectedButton("Current Month");
    setUseCache(false);
    
    clearCache(); // ✅ Only clear cache for actual tenant changes

    setChartData({
      revenueByCarrier: null,
      revenueByRatePlan: null,
      profitMarginTrend: null,
      revenueByUsageTrend: null,
    });
    const defaultStart = (moment().startOf("month").format("YYYY-MM-DD"));
        const defaultEnd = (moment().format("YYYY-MM-DD"));
        setStartDate(defaultStart);
        setEndDate(defaultEnd);
  }

};

  // **FIX: Updated button click handler to properly reset filters and use cache=false**
const handleButtonClick = (range: "Today" | "Current Week" | "Current Month"): void => {

  let newStartDate: string;
  let newEndDate: string;

  if (range === "Today") {
    newStartDate = moment().format("YYYY-MM-DD");
    newEndDate = moment().format("YYYY-MM-DD");
  } else if (range === "Current Week") {
    newStartDate = moment().startOf("week").format("YYYY-MM-DD");
    newEndDate = moment().endOf("week").format("YYYY-MM-DD");
  } else {
    newStartDate = moment().subtract(30, "days").format("YYYY-MM-DD");
    newEndDate = moment().format("YYYY-MM-DD");
  }
  setSelectedButton(range);
  setStartDate(newStartDate);
  setEndDate(newEndDate);
  setDateRange([dayjs(newStartDate), dayjs(newEndDate)]);
   setInternalFilterRevenueByCarrier("1_month");
    setInternalFilterRevenueByRatePlan("1_month");
    setInternalFilterProfitMarginTrend("1_month");
    setInternalFilterRevenueByUsageTrend("1_month");
  setUseCache(false);

  // Don't call fetchChartData here - it will be called by the useEffect
  // when selectedButton changes
};

// const detectClosestFilter = (startDate: string, endDate: string): string => {
//   const start = moment(startDate);
//   const end = moment(endDate);
//   const oneYearBack = moment().subtract(1, "year");

//   // If selected range goes beyond 1 year back → force 5_years
//   if (start.isBefore(oneYearBack, "day") || end.isBefore(oneYearBack, "day")) {
//     return "5_years";
//   }

//   if (start.isSame(end, "day")) return "1_day";

//   const diffDays = end.diff(start, "days");

//   if (diffDays <= 4) return "5_day";
//   if (diffDays <= 31) return "1_month";    // 👈 NEW LOGIC HERE
//   if (diffDays <= 90) return "3_month";
//   if (diffDays <= 180) return "6_month";
//   if (diffDays <= 365) return "1_year";

//   const diffYears = end.diff(start, "years", true);
//   if (diffYears < 5) return "5_years";

//   return "max";
// };

  //  const handleDateRangeChange = (
  //     dates: [Dayjs | null, Dayjs | null] | null,
  //     dateStrings: [string, string]
  //   ) => {
  //     let applied_filter
  //     setSelectedButton(null);
  //     if (dates && dates[0] && dates[1]) {
  //       setDateRange([dates[0], dates[1]]);
  //       const newStartDate = dates[0].format("YYYY-MM-DD");
  //       const newEndDate = dates[1].format("YYYY-MM-DD");
  //       setStartDate(newStartDate);
  //       setEndDate(newEndDate);
  //       setUseCache(false);
  //       fetchChartData(newStartDate, newEndDate, false);
  //       applied_filter = detectClosestFilter(newStartDate,newEndDate)
  //     } else {
  //       setDateRange([null, null]);
  //       setSelectedButton("Current Month");
  //       const newStartDate = moment().subtract(30, "days").format("YYYY-MM-DD");
  //       const newEndDate = moment().format("YYYY-MM-DD");
  //       setStartDate(newStartDate);
  //       setEndDate(newEndDate);
  //       setUseCache(false);
  //       fetchChartData("", "", false);
  //       applied_filter = detectClosestFilter(newStartDate,newEndDate)
        
  //     }
  //      setInternalFilterRevenueByCarrier(applied_filter);
  //     setInternalFilterRevenueByRatePlan(applied_filter);
  //      setInternalFilterProfitMarginTrend(applied_filter);
  //       setInternalFilterRevenueByUsageTrend(applied_filter);
  //   };
const detectClosestFilter = (startDate: string, endDate: string): string => {
  const start = moment(startDate);
  const end = moment(endDate);
  const oneYearBack = moment().subtract(1, "year");

  // If selected range goes beyond 1 year back → force 5_years
  // if (start.isBefore(oneYearBack, "day") || end.isBefore(oneYearBack, "day")) {
  //   return "5_years";
  // }
      
  // Last day of current month
const rangeEnd = moment().endOf("month");

// First day of the month AFTER current month, one year ago
const rangeStart = moment()
  .add(1, "month")
  .subtract(1, "year")
  .startOf("month");

const withinYearRange = {
  start: rangeStart,
  end: rangeEnd,
};

console.log(
  "withinYearRange",
  rangeStart.format("YYYY-MM-DD"),
  "→",
  rangeEnd.format("YYYY-MM-DD")
);

// If selected range is completely outside past 12 months → force 5_years
if (end.isBefore(withinYearRange.start, "day")) {
  return "5_years";
}
  // Safety guards
  if (!start.isValid() || !end.isValid()) return "1_month";
  if (end.isBefore(start)) return "1_month";

  const diffDays = end.diff(start, "days");
  const diffYears = end.diff(start, "years", true);

  if (diffDays === 0) return "1_day";
  if (diffDays <= 4) return "5_day";
  if (diffDays < 31) return "1_month";
  if (diffDays <= 90) return "3_month";
  if (diffDays <= 180) return "6_month";
  if (diffDays <= 365) return "1_year";
  if (diffYears <= 5) return "5_years";

  return "max";
};

const handleDateRangeChange = (
  dates: [Dayjs | null, Dayjs | null] | null,
  dateStrings: [string, string]
) => {
  setSelectedButton(null);

  let newStartDate: string;
  let newEndDate: string;

  if (dates && dates[0] && dates[1]) {
    setDateRange([dates[0], dates[1]]);
    newStartDate = dates[0].format("YYYY-MM-DD");
    newEndDate = dates[1].format("YYYY-MM-DD");
  } else {
    setDateRange([null, null]);
    setSelectedButton("Current Month");
    newStartDate = moment().subtract(30, "days").format("YYYY-MM-DD");
    newEndDate = moment().format("YYYY-MM-DD");
  }

  setStartDate(newStartDate);
  setEndDate(newEndDate);

  // 🔑 Detect filter ONCE
  const applied_filter = detectClosestFilter(newStartDate, newEndDate);

  // 🔥 Apply to all revenue/profit filters
  setInternalFilterRevenueByCarrier(applied_filter);
  setInternalFilterRevenueByRatePlan(applied_filter);
  setInternalFilterProfitMarginTrend(applied_filter);
  setInternalFilterRevenueByUsageTrend(applied_filter);

  setUseCache(false);
  fetchChartData(newStartDate, newEndDate, false);

  console.log("applied_filter:", applied_filter);
};

const handleInternalFilterChange = (chart: string, filter: string): void => {
  
  if (chart === "revenueByCarrier") setInternalFilterRevenueByCarrier(filter);
  else if (chart === "revenueByRatePlan") setInternalFilterRevenueByRatePlan(filter);
  else if (chart === "profitMarginTrend") setInternalFilterProfitMarginTrend(filter);
  else if (chart === "revenueByUsageTrend") setInternalFilterRevenueByUsageTrend(filter);

  // Use cached data when available (like SimsOverview)
  if (cachedData.revenueByCarrier || cachedData.revenueByRatePlan || 
      cachedData.profitMarginTrend || cachedData.revenueByUsageTrend) {
    setChartData(cachedData);
    setUseCache(true);
  }
};


  // **FIX: Updated data processing functions with proper filter handling**
  const processRevenueByCarrierData = (data: any, filter: string, tenantId: string): ProcessedRevenueData => {
    if (!data?.data?.data?.[filter]) {
      console.error(`❌ Filter '${filter}' not found in data. Available filters:`, Object.keys(data?.data?.data || {}));
      
      // **FIX: Try to find any available filter with data**
      const availableFilters = Object.keys(data?.data?.data || {});
      const fallbackFilter = availableFilters.find(f => data.data.data[f]?.length > 0);
      
      if (fallbackFilter) {
        console.log(`🔄 Using fallback filter: ${fallbackFilter}`);
        return processRevenueByCarrierData(data, fallbackFilter, tenantId);
      }
      
      return { chartData: [], details: {} };
    }

    if (!data?.meta?.providers) {
      console.warn("No providers metadata for revenue by carrier");
      return { chartData: [], details: {} };
    }

    const providers = data.meta.providers as { [key: string]: string };
    const carrierMap: { [key: string]: number } = {};
    const details: { [carrier: string]: { [date: string]: number } } = {};

    let filteredData = data.data.data[filter];
    
    if (tenantId !== "All") {
      filteredData = filteredData.filter((item: any) => String(item.tenant_id) === tenantId);
    }

    filteredData.forEach((item: any) => {
      const providerId = item.provider_id === null ? "null" : String(item.provider_id);
      const providerName = providers[providerId];
      
      if (!providerName) return;

      const revenueString = item.Revenue || "$0.00";
      const numericRevenue = parseFloat(revenueString.replace('$', '')) || 0;
      const formattedDate = formatDateForTooltip(new Date().toISOString());

      carrierMap[providerName] = (carrierMap[providerName] || 0) + numericRevenue;

      if (!details[providerName]) {
        details[providerName] = {};
      }
      details[providerName][formattedDate] = (details[providerName][formattedDate] || 0) + numericRevenue;
    });

    const chartData = Object.entries(carrierMap)
      .map(([carrier, revenue]) => ({
        carrier,
        revenue: Math.round(revenue * 100) / 100,
      }))
      .filter(item => item.revenue > 0)
      .sort((a, b) => b.revenue - a.revenue);

    return { chartData, details };
  };

const processRevenueByRatePlanData = (data: any, filter: string, tenantId: string, selectedProvider: string) => {

  
  if (!data?.data?.data?.[filter]) {
    console.error(`Filter '${filter}' not found in data. Available filters:`, Object.keys(data?.data?.data || {}));
    return { chartData: [], providers: [], planDetails: {}, timeSeriesData: [] };
  }

  if (!data?.meta?.providers) {
    console.warn("No providers metadata for revenue by rate plan");
    return { chartData: [], providers: [], planDetails: {}, timeSeriesData: [] };
  }

  const providers = data.meta.providers as { [key: string]: string };
  const availableProviders = Object.values(providers).filter(provider => provider && provider.trim() !== '');
  
  let filteredData = data.data.data[filter];
  
  if (tenantId !== "All") {
    filteredData = filteredData.filter((item: any) => String(item.tenant_id) === tenantId);
  }

  // **FIX: Filter by provider BEFORE processing**
  if (selectedProvider && selectedProvider.trim() !== '' && selectedProvider !== "All") {
    const selectedProviderId = Object.keys(providers).find(key => providers[key] === selectedProvider);
    if (selectedProviderId) {
      filteredData = filteredData.filter((item: any) => String(item.provider_id) === selectedProviderId);
      console.log(`Filtered data for provider ${selectedProvider}:`, filteredData.length, "items");
    } else {
      return { chartData: [], providers: availableProviders, planDetails: {}, timeSeriesData: [] };
    }
  }

  if (!filteredData || filteredData.length === 0) {
    console.log("No data after filtering - returning empty");
    return { chartData: [], providers: availableProviders, planDetails: {}, timeSeriesData: [] };
  }

  // **FIX: Process plan totals correctly from the backend data structure**
  const planTotals: { [plan: string]: number } = {};
  const processedData: { [timeLabel: string]: { [plan: string]: number } } = {};
  const allPlans = new Set<string>();

  // Process each provider's data
  filteredData.forEach((item: any) => {
    // **FIX: Get plans from the 'plans' array in the data structure**
    const plans = item.plans || [];
    
    // Process each record for this provider
    item.records?.forEach((record: any) => {
      if (!Array.isArray(record) || record.length < 3) return;
      
      const [date, revenue, planName] = record;
      const numericRevenue = Number(revenue) || 0;
      
      // **FIX: Use the plan name from the record (3rd element)**
      if (planName && numericRevenue > 0) {
        allPlans.add(planName);
        
        // Add to plan totals for bar chart
        planTotals[planName] = (planTotals[planName] || 0) + numericRevenue;
        
        // Process time-based data for rectangle chart
        const recordDate = new Date(date);
        let timeLabel: string;
        
        switch (filter) {
          case "1_day":
            timeLabel = recordDate.toLocaleTimeString('en-US', {
              hour: '2-digit',
              minute: '2-digit',
              hour12: false
            });
            break;
          case "5_day":
            timeLabel = recordDate.toLocaleDateString('en-US', {
              month: 'short',
              day: 'numeric'
            });
            break;
          case "1_month":
            const monthStart = new Date(recordDate.getFullYear(), recordDate.getMonth(), 1);
            const weekNum = Math.floor((recordDate.getTime() - monthStart.getTime()) / (1000 * 60 * 60 * 24 * 7)) + 1;
            timeLabel = `W${Math.min(weekNum, 4)}`;
            break;
          case "3_month":
          case "6_month":
          case "1_year":
            const monthIndex = recordDate.getMonth();
            const monthStartDate = new Date(recordDate.getFullYear(), recordDate.getMonth(), 1);
            const weekNumber = Math.floor((recordDate.getTime() - monthStartDate.getTime()) / (1000 * 60 * 60 * 24 * 7)) + 1;
            timeLabel = `${monthIndex.toString().padStart(2, '0')}-W${Math.min(weekNumber, 5)}`;
            break;
          case "5_years":
          case "max":
            timeLabel = recordDate.getFullYear().toString();
            break;
          default:
            timeLabel = formatDateForTooltip(date);
        }

        if (!processedData[timeLabel]) {
          processedData[timeLabel] = {};
        }
        
        processedData[timeLabel][planName] = (processedData[timeLabel][planName] || 0) + numericRevenue;
      }
    });
  });

  // Create chart data for bar chart
  const chartData = Object.entries(planTotals)
    .map(([plan, total]) => ({
      plan,
      totalRevenue: total,
    }))
    .filter(item => item.totalRevenue > 0)
    .sort((a, b) => b.totalRevenue - a.totalRevenue);

  return {
    chartData,
    providers: availableProviders,
    planDetails: processedData,
    timeSeriesData: [],
    rectangleData: processedData,
    planNames: Array.from(allPlans)
  };
};


  // **UPDATED: Enhanced Time-based processing for profit margin trend**
 interface ProcessedStackedProfitMargin {
  data: any[];
  keys: string[];
  isWeekBasedFilter: boolean;
}

const processProfitMarginStackedData = (
  data: any,
  filter: string,
  tenantId: string
): ProcessedStackedProfitMargin => {

  if (!data?.data?.data?.[filter]) {
    return { data: [], keys: [], isWeekBasedFilter: false };
  }

  const isWeekBasedFilter = ["1_month", "3_month", "6_month", "1_year"].includes(filter);

  let filteredData = data.data.data[filter];
  if (tenantId !== "All") {
    filteredData = filteredData.filter(
      (item: any) => String(item.tenant_id) === tenantId
    );
  }

  const timeMap: Record<string, Record<string, number>> = {};
  const providers = new Set<string>();

  filteredData.forEach((item: any) => {
    const provider =
      item.service_provider_display_name ||
      item.provider_name ||
      "Unknown";

    const recordDate = new Date(item.time);
    const margin = Number(item.profit_margin) || 0;

    let timeLabel = "";

    switch (filter) {
      case "1_day":
          timeLabel = recordDate.toLocaleTimeString('en-US', {
            hour: '2-digit',
            minute: '2-digit',
            hour12: false
          });
          break;
          
        case "5_day":
          timeLabel = recordDate.toLocaleDateString('en-US', {
            month: 'short',
            day: 'numeric'
          });
          break;
      case "1_month":
      case "3_month":
      case "6_month":
      case "1_year":
        timeLabel = `${recordDate.getMonth()
          .toString()
          .padStart(2, "0")}-W${getWeekNumber(
          recordDate,
          new Date(recordDate.getFullYear(), recordDate.getMonth(), 1)
        )}`;
        break;

      default:
        timeLabel = recordDate.getFullYear().toString();
    }

    if (!timeMap[timeLabel]) timeMap[timeLabel] = {};
    if (!timeMap[timeLabel][provider]) timeMap[timeLabel][provider] = 0;

    timeMap[timeLabel][provider] += margin;
    providers.add(provider);
  });

  const keys = Array.from(providers);

  const stackedData = Object.entries(timeMap).map(([time, values]) => ({
    time,
    ...keys.reduce((acc, key) => {
      acc[key] = values[key] ?? 0;
      return acc;
    }, {} as Record<string, number>)
  }));

  return { data: stackedData, keys, isWeekBasedFilter };
};


  const normalizeStackedToPercent = (data: any[], keys: string[]) => {
    return data.map(row => {
      const negatives = keys.filter(k => (row[k] ?? 0) < 0);
      const positives = keys.filter(k => (row[k] ?? 0) > 0);

      const totalNegative = negatives.reduce(
        (sum, k) => sum + Math.abs(row[k]),
        0
      );

      const totalPositive = positives.reduce(
        (sum, k) => sum + row[k],
        0
      );

      const grandTotal = totalNegative + totalPositive;

      const normalized: any = { time: row.time };

      // Guard: all zero
      if (!grandTotal) {
        keys.forEach(k => (normalized[k] = 0));
        return normalized;
      }

      const negativeShare = (totalNegative / grandTotal) * 100;
      const positiveShare = (totalPositive / grandTotal) * 100;

      // Distribute negatives
      negatives.forEach(k => {
        normalized[k] = Number(
          (-(Math.abs(row[k]) / totalNegative) * negativeShare).toFixed(2)
        );
      });

      // Distribute positives
      positives.forEach(k => {
        normalized[k] = Number(
          ((row[k] / totalPositive) * positiveShare).toFixed(2)
        );
      });

      // Zero values
      keys.forEach(k => {
        if (!normalized.hasOwnProperty(k)) {
          normalized[k] = 0;
        }
      });

      return normalized;
    });
  };
// const normalizeStackedToPercent = (
//   data: any[],
//   keys: string[]
// ) => {
//   return data.map(row => {
//     //  Calculate TOTAL using ABSOLUTE values
//     const total = keys.reduce(
//       (sum, k) => sum + Math.abs(row[k] ?? 0),
//       0
//     );

//     // Guard: avoid divide-by-zero
//     if (!total) return { time: row.time };

//     const normalized: any = { time: row.time };

//     //  Percentage = |value| / |total| * 100
//     keys.forEach(k => {
//       normalized[k] = Number(
//         ((Math.abs(row[k] ?? 0) / total) * 100).toFixed(2)
//       );
//     });

//     return normalized;
//   });
// };

// const normalizeStackedToPercent = (data: any[], keys: string[]) => {
//   return data.map(row => {
//     const total = keys.reduce(
//       (sum, k) => sum + Math.abs(row[k] ?? 0),
//       0
//     );

//     if (!total) return row;

//     const normalized: any = { time: row.time };

//     keys.forEach(k => {
//       normalized[k] = Number(
//         ((Math.abs(row[k]) / total) * 100).toFixed(2)
//       );
//     });

//     return normalized;
//   });
// };


  const processRevenueByUsageTrendData = (data: any, filter: string, tenantId: string, selectedProvider: string) => {
    
    if (!data?.data?.data?.[filter]) {
      console.error(`❌ Filter '${filter}' not found in data. Available filters:`, Object.keys(data?.data?.data || {}));
      
      // **FIX: Try to find any available filter with data**
      const availableFilters = Object.keys(data?.data?.data || {});
      const fallbackFilter = availableFilters.find(f => data.data.data[f]?.length > 0);
      
      if (fallbackFilter) {
        console.log(`🔄 Using fallback filter: ${fallbackFilter}`);
        return processRevenueByUsageTrendData(data, fallbackFilter, tenantId, selectedProvider);
      }
      
      return { chartData: [], providers: [], details: {} };
    }

    if (!data?.data?.xField) {
      console.warn("No xField for revenue by usage trend");
      return { chartData: [], providers: [], details: {} };
    }

    const usageTypes = data.data.xField as string[];
    const providers = data.meta?.providers ? Object.values(data.meta.providers) : [];
    const availableProviders = [ ...providers];
    const usageMap: { [key: string]: number } = {};
    const details: { [usage: string]: { [date: string]: number } } = {};

    let filteredData = data.data.data[filter];
    
    if (tenantId !== "All") {
      filteredData = filteredData.filter((item: any) => String(item.tenant_id) === tenantId);
    }

    if (selectedProvider !== "All") {
      const selectedProviderId = Object.keys(data.meta?.providers || {}).find(key => data.meta.providers[key] === selectedProvider);
      if (selectedProviderId) {
        filteredData = filteredData.filter((item: any) => String(item.provider_id) === selectedProviderId);
      }
    }

    filteredData.forEach((item: any) => {
      item.records?.forEach((record: any) => {
        if (Array.isArray(record) && record.length >= 4) {
          const date = record[0];
          const formattedDate = formatDateForTooltip(date);

          usageTypes.forEach((usageType, index) => {
            const value = Number(record[index + 1]) || 0;
            usageMap[usageType] = (usageMap[usageType] || 0) + value;

            if (!details[usageType]) {
              details[usageType] = {};
            }
            details[usageType][formattedDate] = (details[usageType][formattedDate] || 0) + value;
          });
        }
      });
    });

    const chartData = usageTypes.map(usageType => ({
      usage_type: usageType,
      total_revenue: Math.round((usageMap[usageType] || 0) * 100) / 100,
    })).filter(item => item.total_revenue > 0);


    return { chartData, providers: availableProviders, details };
  };
  // UI Rendering functions
  // 3. Update renderFilterButtons to handle no_data state like sims overview
const renderFilterButtons = (chart: string): JSX.Element => {
  const filters = [
    { label: "1D", value: "1_day" },
    { label: "5D", value: "5_day" },
    { label: "1M", value: "1_month" },
    { label: "3M", value: "3_month" },
    { label: "6M", value: "6_month" },
    { label: "1Y", value: "1_year" },
    { label: "5Y", value: "5_years" },
    { label: "Max", value: "max" },
  ];

  // Always show the current internal filter as active
  const currentFilter = chart === "revenueByCarrier" ? internalFilterRevenueByCarrier :
                       chart === "revenueByRatePlan" ? internalFilterRevenueByRatePlan :
                       chart === "profitMarginTrend" ? internalFilterProfitMarginTrend :
                       internalFilterRevenueByUsageTrend;

  return (
    <div className="flex grid grid-cols-8">
      {filters.map((filter) => (
        <button
          key={filter.value}
          onClick={() => handleInternalFilterChange(chart, filter.value)}
          style={{ fontFamily: "Calibri, sans-serif", fontSize: "14px" }}
          className={`${currentFilter === filter.value ? 
            "new-dashboard-filter-active-btn" : 
            "new-dashboard-filter-btn"} p-2 transition-all duration-300`}
        >
          {filter.label}
        </button>
      ))}
    </div>
  );
};

// Ensure processCarrierTimeBasedData handles 5_day correctly
const processCarrierTimeBasedData = (data: any, filter: string, tenantId: string) => {

  if (!data?.data?.data?.[filter]) {
    console.error(`Filter '${filter}' not found`);
    return { tableData: [], timeColumns: [] };
  }

  if (!data?.meta?.providers) {
    console.warn("No providers metadata");
    return { tableData: [], timeColumns: [] };
  }

  const providers = data.meta.providers as { [key: string]: string };
  let filteredData = data.data.data[filter];
  
  if (tenantId !== "All") {
    filteredData = filteredData.filter((item: any) => String(item.tenant_id) === tenantId);
  }

  const carrierTimeData: Record<string, CarrierTimeData> = {};
  const allTimePeriods = new Set<string>();

  filteredData.forEach((item: any) => {
    const providerId = item.provider_id === null ? "null" : String(item.provider_id);
    const carrierName = providers[providerId];
    
    if (!carrierName) return;

    if (!carrierTimeData[carrierName]) {
      carrierTimeData[carrierName] = { statistic: item.Statistic || [] };
    }

    // FIXED: Add proper validation for records array
    if (!item.records) {
      console.warn("No records found for item:", item);
      return;
    }

    if (!Array.isArray(item.records)) {
      console.warn("Records is not an array for carrier:", carrierName, "Type:", typeof item.records, "Value:", item.records);
      return;
    }

    item.records.forEach((record: any) => {
      if (!Array.isArray(record) || record.length < 2) {
        console.warn("Invalid record format:", record);
        return;
      }
      
      const [date, revenue] = record;
      const numericRevenue = parseFloat(String(revenue).replace('$', '')) || 0;
      
      // Validate date
      if (!date) {
        console.warn("Invalid date in record:", record);
        return;
      }

      const recordDate = new Date(date);
      
      // Check if date is valid
      if (isNaN(recordDate.getTime())) {
        console.warn("Invalid date format:", date);
        return;
      }
      
      let timeLabel: string;
      
      switch (filter) {
        case "1_day":
          timeLabel = recordDate.toLocaleTimeString('en-US', {
            hour: '2-digit',
            minute: '2-digit',
            hour12: false
          });
          break;
          
        case "5_day":
          timeLabel = recordDate.toLocaleDateString('en-US', {
            month: 'short',
            day: 'numeric'
          });
          break;
          
        case "1_month":
          const monthStart = new Date(recordDate.getFullYear(), recordDate.getMonth(), 1);
          const weekNum = getWeekNumber(recordDate, monthStart);
          timeLabel = `W${Math.min(weekNum, 4)}`;
          break;
          
        case "3_month":
        case "6_month":
        case "1_year":
          const monthIndex = recordDate.getMonth();
          const monthStartDate = new Date(recordDate.getFullYear(), recordDate.getMonth(), 1);
          const weekNumber = getWeekNumber(recordDate, monthStartDate);
          timeLabel = `${monthIndex.toString().padStart(2, '0')}-W${Math.min(weekNumber, 5)}`;
          break;
          
        case "5_years":
        case "max":
          timeLabel = recordDate.getFullYear().toString();
          break;
          
        default:
          timeLabel = formatDateForTooltip(date);
      }

      allTimePeriods.add(timeLabel);
      carrierTimeData[carrierName][timeLabel] = (carrierTimeData[carrierName][timeLabel] || 0) + numericRevenue;
    });
  });

  // Sort time periods
  const sortedTimePeriods = Array.from(allTimePeriods).sort((a, b) => {
    if (filter === "1_day") {
      return a.localeCompare(b);
    } else if (filter === "5_day") {
      const dateA = new Date(a);
      const dateB = new Date(b);
      return dateA.getTime() - dateB.getTime();
    } else if (filter === "1_month") {
      const weekA = parseInt(a.replace('W', ''));
      const weekB = parseInt(b.replace('W', ''));
      return weekA - weekB;
    } else if (["3_month", "6_month", "1_year"].includes(filter)) {
      const [monthA, weekA] = a.split('-W');
      const [monthB, weekB] = b.split('-W');
      const monthCompare = parseInt(monthA) - parseInt(monthB);
      if (monthCompare !== 0) return monthCompare;
      return parseInt(weekA) - parseInt(weekB);
    } else if (filter === "5_years") {
      return parseInt(a) - parseInt(b);
    } else {
      return a.localeCompare(b);
    }
  });

  // Create table data
  const tableData = Object.entries(carrierTimeData).map(([carrier, data]) => {
    const row: any = { 
      key: carrier, 
      carrier,
      statistic: data.statistic || []
    };
    
    sortedTimePeriods.forEach(period => {
      row[period] = data[period] || 0;
    });
    
    return row;
  });

  // Generate time columns based on filter
  const generateTimeColumns = () => {
    if (["3_month", "6_month", "1_year"].includes(filter)) {
      const monthGroups: { [month: string]: string[] } = {};
      
      sortedTimePeriods.forEach(period => {
        if (period.includes('-W')) {
          const [monthIndex, week] = period.split('-W');
          const monthName = getMonthName(parseInt(monthIndex));
          if (!monthGroups[monthName]) {
            monthGroups[monthName] = [];
          }
          monthGroups[monthName].push(period);
        }
      });

      const timeColumns: any[] = [];
      
      Object.entries(monthGroups).forEach(([monthName, weeks]) => {
        timeColumns.push({
          title: monthName,
          children: weeks.map(week => {
            const weekNum = week.split('-W')[1];
            return {
              title: `W${weekNum}`,
              dataIndex: week,
              key: week,
              width: 60,
              render: (value: number) => value > 0 ? `$${value.toFixed(2)}` : "-"
            };
          })
        });
      });
      
      return timeColumns;
    } else {
      return sortedTimePeriods.map(period => ({
        title: period,
        dataIndex: period,
        key: period,
        width: filter === "1_day" ? 80 : filter === "5_day" ? 90 : 60,
        render: (value: number) => value > 0 ? `$${value.toFixed(2)}` : "-"
      }));
    }
  };

 
  return { 
    tableData, 
    timeColumns: generateTimeColumns(),
    sortedTimePeriods 
  };
};

// 4. Update renderRevenueByCarrierChart to handle no_data and fix expansion
const renderRevenueByCarrierChart = (): JSX.Element => {
  const dataSource = useCache ? cachedData : chartData;
  const filterToUse = getActualFilterFromData(
    dataSource.revenueByCarrier,
    internalFilterRevenueByCarrier
  );

  // Handle no data case like sims overview
  if (filterToUse === "no_data") {
    return (
      <div
        className="bg-white p-4 rounded-lg shadow-md graph"
        style={{ height: `${FIXED_CONTAINER_HEIGHT}px`, width: "100%" }}
      >
        <div className="bg-gray-100 flex justify-between items-center p-4 chart-title">
          <div className="flex items-center">
            <h2 className="font-semibold">Revenue By Carrier</h2>
          </div>
        </div>
        {renderFilterButtons("revenueByCarrier")}
        <div className="flex justify-center items-center h-full">
          <span
            style={{
              fontSize: "16px",
              color: "#666",
              fontFamily: "Calibri, sans-serif",
            }}
          >
            No Data Available
          </span>
        </div>
      </div>
    );
  }

  const { tableData, timeColumns } = dataSource.revenueByCarrier
    ? processCarrierTimeBasedData(
        dataSource.revenueByCarrier,
        filterToUse,
        selectedTenantId
      )
    : { tableData: [], timeColumns: [] };
    // Ensure each row has a numeric `statistic` array derived from the timeColumns (W1/W2/...)
    if (Array.isArray(tableData) && Array.isArray(timeColumns)) {
      // timeColumns is antd column descriptors — get the dataIndex keys in the
      // same order the table displays them (this is the order you want for the sparkline)
      const weekKeys: string[] = timeColumns
        .map((c: any) => (typeof c.dataIndex === "string" ? c.dataIndex : ""))
        .filter((k: string) => !!k);

      // Fallback: if no timeColumns (or they are formatted differently),
      // try to auto-detect week-like keys from the first row (keys like "08-W1", "10-W3")
      if (weekKeys.length === 0 && tableData.length > 0) {
        const sample = tableData[0];
        weekKeys.push(
          ...Object.keys(sample).filter((k) => /^[0-9]{2}-W\d+$/i.test(k))
        );
        // keep them sorted by month-week for consistent order
        weekKeys.sort((a, b) => {
          const [mA, wA] = a.split("-W").map(Number);
          const [mB, wB] = b.split("-W").map(Number);
          if (mA === mB) return wA - wB;
          return mA - mB;
        });
      }

      // Now populate `row.statistic` from the weekKeys for each row
      tableData.forEach((row: any) => {
        const stat = weekKeys.map((k) => {
          const raw = row[k];
          // handle undefined/null, formatted numbers like "$1,234.56"
          const n = Number(String(raw ?? 0).replace(/[^0-9.-]+/g, ""));
          return Number.isFinite(n) ? n : 0;
        });

        // If you prefer at least 2 points (not required), ensure length >= 2:
        row.statistic = stat.length === 1 ? [0, stat[0]] : stat;
      });
    }
    // console.log('revenue table sample', tableData.slice(0,6));

  const shouldShowDualXAxis = ["3_month", "6_month", "1_year"].includes(
    filterToUse
  );

const columns = [
  {
    title: "Carrier",
    dataIndex: "carrier",
    key: "carrier",
    width: 120,
    fixed: "left" as const,
    render: (text: string) => (
      <span style={{ fontWeight: 500, fontSize: "12px" }}>{text}</span>
    ),
  },
  ...timeColumns, // make sure these dataIndex keys match the row keys (W1, W2, ...)
  {
    title: "Statistic",
    dataIndex: "statistic", // <-- we populate this above from timeColumns
    key: "statistic",
    width: 120,
    fixed: "right" as const,
    render: (data: any, record: any, index: number) => {
      const raw: number[] =
        Array.isArray(data) && data.length > 0
          ? data.map((v: any) => {
              if (v === null || v === undefined) return 0;
              const n = Number(String(v).replace(/[^0-9.-]+/g, ""));
              return Number.isFinite(n) ? n : 0;
            })
          : [0];

      const prepared = raw.length === 1 ? [0, raw[0]] : raw;
      const min = Math.min(...prepared);
      const max = Math.max(...prepared);
      let sparkData: number[];

      if (max - min === 0) {
        sparkData = prepared.map((v, i) => (i % 2 === 0 ? v * 0.995 : v));
      } else {
        sparkData = prepared.map((v) => (v - min) / (max - min));
      }

      const color = BLUE_SHADES[index % BLUE_SHADES.length];

      return (
        <div style={{ width: 100, height: 25 }}>
          <Sparklines data={sparkData} width={100} height={25}>
            <SparklinesLine color={color} style={{ strokeWidth: 2 }} />
          </Sparklines>
        </div>
      );
    },
  },
];



  return (
    <div
      className="bg-white p-4 rounded-lg shadow-md graph"
      style={{
        height: `${FIXED_CONTAINER_HEIGHT}px`, // Fixed height like sims overview
        width: "100%",
        overflow: "hidden",
      }}
    >
      <div className="bg-gray-100 flex justify-between items-center p-4 chart-title">
        <div className="flex items-center">
          <h2 className="font-semibold">
            {dataSource.revenueByCarrier?.data?.title || "Revenue By Carrier"}
          </h2>
        </div>
      </div>

      {renderFilterButtons("revenueByCarrier")}

      <div
        style={{
          height: `${FIXED_CARD_HEIGHT}px`,
          padding: "10px",
          overflow: "hidden",
        }}
      >
        {loading || !allApisLoaded ? (
          <div className="flex flex-row justify-center items-center h-full w-full">
            <Spin size="large" />
          </div>
        ) : tableData.length === 0 && allApisLoaded ? (
          <div
            style={{
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              height: "100%",
              fontSize: "16px",
              color: "#6b7280",
              fontFamily: "Calibri, sans-serif",
            }}
          >
            No Data Available
          </div>
        ) : (
          <Table
            dataSource={tableData}
            columns={columns}
                pagination={false}
                scroll={{
                  x: "max-content", // ✅ KEY FIX
                  ...(tableData.length > 5 ? { y: FIXED_CARD_HEIGHT - 80 } : {}),
                }}
            size="small"
            style={{
              fontSize: "11px",
              width: "100%",
            }}
            bordered={shouldShowDualXAxis}
          />
        )}
      </div>
    </div>
  );
};


// 5. Update profit margin chart with better month positioning like sims overview



const renderProfitMarginTrendChart = (): JSX.Element => {
  const dataSource = useCache ? cachedData : chartData;

  const filterToUseProfitMarginTrend = getActualFilterFromData(
    dataSource.profitMarginTrend,
    internalFilterProfitMarginTrend
  );

  const {
    data: stackedProfitMarginData,
    keys: providerKeys,
  } = processProfitMarginStackedData(
    dataSource.profitMarginTrend,
    filterToUseProfitMarginTrend,
    selectedTenantId
  );
const percentStackedProfitMarginData = normalizeStackedToPercent(
  stackedProfitMarginData,
  providerKeys
);
const colorScheme = [
  "#66c2a5",
  "#fc8d62",
  "#8da0cb",
  "#e78ac3",
  "#a6d854",
  "#ffd92f",
];

const providerColorMap = providerKeys.reduce((acc: any, key, i) => {
  acc[key] = colorScheme[i % colorScheme.length];
  return acc;
}, {});

const MonthLabelsLayer = ({ bars, innerHeight }: any) => {
  if (!bars.length) return null;

  const sortedBars = [...bars].sort((a, b) => a.x - b.x);
  const monthGroups: Record<string, any[]> = {};

  sortedBars.forEach((bar) => {
    const time = bar.data.indexValue; // "10-W1"
    if (!time?.includes("-W")) return;

    const month = time.split("-W")[0];
    monthGroups[month] ??= [];
    monthGroups[month].push(bar);
  });

  const monthNames = [
    "Jan","Feb","Mar","Apr","May","Jun",
    "Jul","Aug","Sep","Oct","Nov","Dec"
  ];

  return (
    <g transform={`translate(0, ${innerHeight + 42})`}>
      {Object.entries(monthGroups).map(([month, bars]) => {
        const first = bars[0];
        const last = bars[bars.length - 1];

        const centerX =
          first.x + (last.x + last.width - first.x) / 2;

        return (
          <text
            key={month}
            x={centerX}
            y={0}
            textAnchor="middle"
            fontSize={11}
            fill="#000"
          >
            {monthNames[Number(month)]}
          </text>
        );
      })}
    </g>
  );
};


const getYScaleBounds = (data: any[], keys: string[]) => {
  let min = 0;
  let max = 0;

  data.forEach(row => {
    let positiveSum = 0;
    let negativeSum = 0;

    keys.forEach(k => {
      const v = row[k] ?? 0;
      if (v > 0) positiveSum += v;
      if (v < 0) negativeSum += v;
    });

    max = Math.max(max, positiveSum);
    min = Math.min(min, negativeSum);
  });

  // Add small padding so bars don’t touch edges
  return {
    min: Math.floor(min),
    max: Math.ceil(max),
  };
};

const { min: yMin, max: yMax } = getYScaleBounds(
  percentStackedProfitMarginData,
  providerKeys
);

  // ---------------- NO DATA STATE ----------------
  if (filterToUseProfitMarginTrend === "no_data") {
    return (
      <div
        className="bg-white p-4 rounded-lg shadow-md graph"
        style={{ height: `${FIXED_CONTAINER_HEIGHT}px` }}
      >
        <div className="bg-gray-100 flex justify-between items-center p-4 chart-title">
          <h2 className="font-semibold">Profit Margin Trend</h2>
        </div>

        {renderFilterButtons("profitMarginTrend")}

        <div className="flex justify-center items-center h-full">
          <span style={{ fontSize: 16, color: "#666" }}>
            No Data Available
          </span>
        </div>
      </div>
    );
  }

  // ---------------- MAIN RENDER ----------------
  return (
    <div
      className="bg-white p-4 rounded-lg shadow-md graph"
      style={{ height: `${FIXED_CONTAINER_HEIGHT}px`, overflow: "hidden" }}
    >
      {/* HEADER */}
      <div className="bg-gray-100 flex justify-between items-center p-4 chart-title">
        <h2 className="font-semibold">
          {dataSource.profitMarginTrend?.data?.title || "Profit Margin Trend"}
        </h2>

        <button
          onClick={() => setFlippedChart(flippedChart === 2 ? null : 2)}
          className="cursor-pointer"
        >
          <i className="fi fi-rr-flip-horizontal text-lg" />
        </button>
      </div>

      {renderFilterButtons("profitMarginTrend")}

      {/* TABLE VIEW */}
      {flippedChart === 2 ? (
        <div style={{ height: FIXED_CARD_HEIGHT, padding: 10 }}>
          <Table
            dataSource={stackedProfitMarginData.map((row, idx) => ({
              key: idx,
              time: row.time,
              ...providerKeys.reduce((acc: any, k) => {
                acc[k] = row[k];
                return acc;
              }, {}),
            }))}
            columns={[
              {
                title: "Time Period",
                dataIndex: "time",
                key: "time",
              },
              ...providerKeys.map((provider) => ({
                title: provider,
                dataIndex: provider,
                key: provider,
                render: (v: number) =>
                  v ? `${v.toFixed(1)}%` : "-",
              })),
            ]}
            pagination={false}
            size="small"
          />
        </div>
      ) : (
        /* CHART VIEW */
        <div style={{ height: FIXED_CARD_HEIGHT }}>
          {loading || !allApisLoaded ? (
            <div className="flex justify-center items-center h-full">
              <Spin size="large" />
            </div>
          ) :  percentStackedProfitMarginData.length === 0 || providerKeys.length === 0 ? (
            <div className="flex justify-center items-center h-full text-gray-500">
              No Data Available
            </div>
          ) : (
            <ResponsiveBar
              data={percentStackedProfitMarginData}
              keys={providerKeys}
              indexBy="time"
              groupMode="stacked"
              padding={0.3}
              margin={{ top: 30, right: 20, bottom: 70, left: 60 }}

              // valueScale={{ type: "linear", min: 0, max: 100 }}
              valueScale={{
                type: "linear",
                min: yMin,
                max: yMax,
              }}
              markers={[
                {
                  axis: "y",
                  value: 0,
                  lineStyle: {
                    stroke: "#818181ff",
                    strokeWidth: 1,
                    strokeDasharray: "0",
                  },
                  textStyle: {
                    fill: "#000",
                    fontSize: 11,
                    fontWeight: 600,
                  },
                },
              ]}
              indexScale={{ type: "band", round: true }}

              colors={{ scheme: "set2" }}

              axisLeft={{
                format: (v) => `${v}%`,
                legend: "Profit Margin",
                legendPosition: "middle",
                legendOffset: -50,
              }}

  axisBottom={{
  tickSize: 0,
  tickPadding: 6,
  format: (value) => {
    if (typeof value === "string" && value.includes("-W")) {
      return `W${value.split("-W")[1]}`;
    }
    return value;
  },
}}



              enableLabel={false}
layers={[
    "grid",
    "axes",
    "bars",
    MonthLabelsLayer, 
    "markers",
    "legends",

  ]}
//    tooltip={({ data, indexValue }) => {
//   let displayTime = String(indexValue);

//   if (displayTime.includes("-W")) {
//     const [monthIndex, week] = displayTime.split("-W");

//     const monthNames = [
//       "Jan","Feb","Mar","Apr","May","Jun",
//       "Jul","Aug","Sep","Oct","Nov","Dec"
//     ];

//     displayTime = `${monthNames[Number(monthIndex)]} - W${week}`;
//   }

//   return (
//     <div className="bg-white border p-2 rounded shadow text-xs"  style={{
//         minWidth: 150,     // ✅ increase tooltip width
//         maxWidth: 260,     // optional
//         lineHeight: 1.4,
//       }}>
      
//       <div className="font-semibold mb-1">{displayTime}</div>

//       {providerKeys.map((provider) => {
//         const v = data[provider];
//         if (v == null || v === 0) return null;

//         return (
//           <div key={provider}>
//             {provider}: {Number(v).toFixed(1)}%
//           </div>
//         );
//       })}
//     </div>
//   );
// }}

tooltip={({ data, indexValue }) => {
  let displayTime = String(indexValue);

  if (displayTime.includes("-W")) {
    const [monthIndex, week] = displayTime.split("-W");
    const monthNames = [
      "Jan","Feb","Mar","Apr","May","Jun",
      "Jul","Aug","Sep","Oct","Nov","Dec"
    ];
    displayTime = `${monthNames[Number(monthIndex)]} - W${week}`;
  }

  return (
    <div
      className="bg-white border p-2 rounded shadow text-xs"
      style={{ minWidth: 170 }}
    >
      <div className="font-semibold mb-2">{displayTime}</div>

      {providerKeys.map((provider) => {
        const v = data[provider];
        if (!v) return null;

        return (
          <div
            key={provider}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 6,
              marginBottom: 4,
            }}
          >
            {/* ■ square icon */}
            <span
              style={{
                width: 10,
                height: 10,
                backgroundColor: providerColorMap[provider],
                display: "inline-block",
              }}
            />

            <span>
              {provider}: {Number(v).toFixed(1)}%
            </span>
          </div>
        );
      })}
    </div>
  );
}}


              legends={[
                {
                  dataFrom: "keys",
                  anchor: "bottom",
                  direction: "row",
                  translateY: 70,
                  itemWidth: 130,
                  itemHeight: 14,
                  symbolSize: 10,
                },
              ]}
            />
          )}
        </div>
      )}
    </div>
  );
};


const processUsageTrendTimeBasedData = (data: any, filter: string, tenantId: string, selectedProvider: string) => {

  
  if (!data?.data?.data?.[filter] || !data?.meta?.providers || !data?.data?.xField) {
    return { chartData: [], usageTypes: [], processedData: [], monthPositions: [] };
  }
  
  const providers = data.meta.providers as { [key: string]: string };
  const usageTypes = data.data.xField as string[]; // Get actual usage types from backend
  const shouldShowDualXAxis = ["3_month", "6_month", "1_year"].includes(filter);
  
  
  let filteredData = data.data.data[filter];
  
  if (tenantId !== "All") {
    filteredData = filteredData.filter((item: any) => String(item.tenant_id) === tenantId);
  }

  if (selectedProvider && selectedProvider !== "All") {
    const selectedProviderId = Object.keys(providers).find(key => providers[key] === selectedProvider);
    if (selectedProviderId) {
      filteredData = filteredData.filter((item: any) => String(item.provider_id) === selectedProviderId);
    }
  }


  const timeUsageData: { 
    [timeLabel: string]: { 
      [usageType: string]: number;
      total: number;
    } 
  } = {};

  // Process each data item
  filteredData?.forEach((item: any) => {
    item.records?.forEach((record: any) => {
      if (!Array.isArray(record) || record.length < (usageTypes.length + 1)) return;

      const date = record[0];
      const recordDate = new Date(date);
      
      let timeLabel: string;
      // Generate time labels based on filter
      switch (filter) {
        case "1_day":
          timeLabel = recordDate.toLocaleTimeString('en-US', { 
            hour: '2-digit', 
            minute: '2-digit', 
            hour12: false 
          });
          break;
        case "5_day":
          timeLabel = recordDate.toLocaleDateString('en-US', { 
            month: 'short', 
            day: 'numeric' 
          });
          break;
        case "1_month": {
          const monthStart = new Date(recordDate.getFullYear(), recordDate.getMonth(), 1);
          const weekNum =
            Math.floor(
              (recordDate.getTime() - monthStart.getTime()) /
              (1000 * 60 * 60 * 24 * 7)
            ) + 1;

          timeLabel = `W${Math.min(weekNum, 4)}`;

          // ✅ STORE MONTH INFO
          if (!timeUsageData[timeLabel]) {
            timeUsageData[timeLabel] = {
              total: 0,
              monthIndex: recordDate.getMonth(), // 🔥 KEY FIX
              year: recordDate.getFullYear()
            };
            usageTypes.forEach(type => {
              timeUsageData[timeLabel][type] = 0;
            });
          }
          break;
        }
        case "3_month":
        case "6_month":
        case "1_year":
          const monthIndex = recordDate.getMonth();
          const monthStartDate = new Date(recordDate.getFullYear(), recordDate.getMonth(), 1);
          const weekNumber = Math.floor((recordDate.getTime() - monthStartDate.getTime()) / (1000 * 60 * 60 * 24 * 7)) + 1;
          timeLabel = `${monthIndex.toString().padStart(2, '0')}-W${Math.min(weekNumber, 4)}`;
          break;
        case "5_years":
        case "max":
          timeLabel = recordDate.getFullYear().toString();
          break;
        default:
          timeLabel = formatDateForTooltip(date);
      }

      // Initialize time period if not exists
      if (!timeUsageData[timeLabel]) {
        timeUsageData[timeLabel] = { total: 0 };
        usageTypes.forEach(type => {
          timeUsageData[timeLabel][type] = 0;
        });
      }

      // Process each usage type value
      usageTypes.forEach((usageType, index) => {
        const value = Number(record[index + 1]) || 0;
        timeUsageData[timeLabel][usageType] += value;
      });

      // Recalculate total
      timeUsageData[timeLabel].total = usageTypes.reduce((sum, type) => 
        sum + timeUsageData[timeLabel][type], 0
      );
    });
  });


  // Sort time labels
  const sortedTimeLabels = Object.keys(timeUsageData).sort((a, b) => {
    if (filter === "1_day") {
      return a.localeCompare(b);
    } else if (filter === "5_day") {
      return new Date(a).getTime() - new Date(b).getTime();
    } else if (filter === "1_month") {
      const weekA = parseInt(a.replace('W', ''));
      const weekB = parseInt(b.replace('W', ''));
      return weekA - weekB;
    } else if (["3_month", "6_month", "1_year"].includes(filter)) {
      const [monthA, weekA] = a.split('-W');
      const [monthB, weekB] = b.split('-W');
      const monthCompare = parseInt(monthA) - parseInt(monthB);
      if (monthCompare !== 0) return monthCompare;
      return parseInt(weekA) - parseInt(weekB);
    } else if (filter === "5_years" || filter === "max") {
      return parseInt(a) - parseInt(b);
    } else {
      return a.localeCompare(b);
    }
  });

  // Create chart data with proper structure
  const chartData = sortedTimeLabels
    .filter(timeLabel => timeUsageData[timeLabel].total > 0)
    .map(timeLabel => {
      const dataEntry: any = {
        time: timeLabel,
        total: timeUsageData[timeLabel].total,
        isGap: false,
        monthIndex: timeUsageData[timeLabel].monthIndex, // ✅
        year: timeUsageData[timeLabel].year               // ✅ (optional)
      };
    
      // Add each usage type as a property
      usageTypes.forEach(usageType => {
        dataEntry[usageType] = timeUsageData[timeLabel][usageType] || 0;
      });
      
      return dataEntry;
    });

  // Process data with month gaps for dual axis display
  const processDataWithMonthGaps = (data: any[]) => {
    if (!shouldShowDualXAxis || data.length === 0) {
      return { processedData: data, monthPositions: [] };
    }

    const processedData: any[] = [];
    const monthPositions: { month: string; startIndex: number; endIndex: number; centerIndex: number; total: number }[] = [];
    
    // Group data by month
    const monthGroups: { [month: string]: any[] } = {};
    
    data.forEach(item => {
      if (item.time.includes('-W')) {
        const [monthIndex] = item.time.split('-W');
        if (!monthGroups[monthIndex]) {
          monthGroups[monthIndex] = [];
        }
        monthGroups[monthIndex].push(item);
      }
    });

    // Process each month group
    Object.keys(monthGroups).sort((a, b) => parseInt(a) - parseInt(b)).forEach((month, monthIdx) => {
      const monthData = monthGroups[month];
      const startIndex = processedData.length;
      
      monthData.forEach(item => {
        processedData.push({
          ...item,
          monthIndex: month
        });
      });
      
      const endIndex = processedData.length - 1;
      const weekCount = monthData.length;
      
      // Calculate month total
      const monthTotal = monthData.reduce((sum, item) => {
        const weekTotal = usageTypes.reduce((weekSum, type) => 
          weekSum + (item[type] || 0), 0
        );
        return sum + weekTotal;
      }, 0);
      
      let centerIndex: number;
      if (weekCount === 1) {
        centerIndex = startIndex;
      } else if (weekCount % 2 === 1) {
        centerIndex = startIndex + Math.floor(weekCount / 2);
      } else {
        centerIndex = startIndex + (weekCount / 2) - 0.5;
      }
      
      monthPositions.push({
        month,
        startIndex,
        endIndex,
        centerIndex: Math.floor(centerIndex),
        total: monthTotal
      });
      
      // Add gaps between months
      if (monthIdx < Object.keys(monthGroups).length - 1) {
        for (let i = 0; i < 2; i++) {
          const gapEntry: any = {
            time: `gap-${month}-${i}`,
            isGap: true,
            total: 0,
            monthIndex: month
          };
          usageTypes.forEach(type => {
            gapEntry[type] = 0;
          });
          processedData.push(gapEntry);
        }
      }
    });

    return { processedData, monthPositions };
  };

  const { processedData, monthPositions } = processDataWithMonthGaps(chartData);

  return {
    chartData,
    usageTypes,
    processedData,
    monthPositions
  };
};
const UsageTypeTimeBasedTooltip: React.FC<{
  active?: boolean;
  payload?: any[];
  label?: string;
  currentFilter?: string;
}> = ({ active, payload, label, currentFilter }) => {
  if (!active || !payload?.length || !label) return null;

  const monthNames = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];

  const item = payload[0].payload;
  let title = label;

  // 1-day → HH:00
  if (currentFilter === "1_day") {
    const h = Number(label);
    title = isNaN(h) ? label : `${String(h).padStart(2, "0")}:00`;
  }

  // ✅ 1-month → Dec-W1 (from recordDate)
  if (currentFilter === "1_month" && label.startsWith("W")) {
    const item = payload[0].payload;
    if (item.monthIndex !== undefined) {
      title = `${monthNames[item.monthIndex]}-${label}`;
    }
  }

  
  if (["3_month", "6_month", "1_year"].includes(currentFilter || "") && label.includes('-W')) {
    const [monthIndex, week] = label.split('-W');
    const monthName = monthNames[parseInt(monthIndex)] || monthIndex;
    title = `${monthName}-W${week}`;
  }

  const validEntries = payload.filter(p => p.value > 0);
  if (!validEntries.length) return null;

  if (title.includes('-W') && !title.match(/[A-Za-z]/)) {
    const [monthIndex, week] = title.split('-W');
    const monthName = monthNames[parseInt(monthIndex)] || monthIndex;
    title = `${monthName}-W${week}`;
  }

  return (
    <div style={{
      background: "#fff",
      border: "1px solid #ccc",
      padding: "8px 10px",
      borderRadius: 4,
      fontSize: 12
    }}>
      <div style={{ fontWeight: 600, marginBottom: 6 }}>{title}</div>

      {validEntries.map((e, i) => (
        <div key={i} style={{ display: "flex", justifyContent: "space-between" }}>
          <span>{e.dataKey}</span>
          <span>${e.value.toFixed(2)}</span>
        </div>
      ))}
    </div>
  );
};



// Add this function after processPlanRectangleData function
const processRatePlanTableData = (rectangleData: any[], planNames: string[]): any[] => {
 
  const timeGroups: { [time: string]: { [plan: string]: number } } = {};
  
  rectangleData.forEach(item => {
    if (item.isSpacer || item.isGap) return;
    
    const timeKey = item.time;
    const planName = item.fullName || item.plan_name;
    const value = item.value || item.usage_count || 0;
    
    if (!timeGroups[timeKey]) {
      timeGroups[timeKey] = {};
      // Initialize all plans to 0 for this time period
      planNames.forEach(plan => {
        timeGroups[timeKey][plan] = 0;
      });
    }
    
    if (planName && planNames.includes(planName)) {
      timeGroups[timeKey][planName] = (timeGroups[timeKey][planName] || 0) + value;
    }
  });

  // Convert to table format
  const tableData = Object.keys(timeGroups).map(timeKey => {
    const row: any = { 
      key: timeKey, 
      time: timeKey 
    };
    
    // Add each plan as a column with its value
    planNames.forEach(plan => {
      row[plan] = timeGroups[timeKey][plan] || 0;
    });
    
    return row;
  });

  return tableData;
};


  // **UPDATED** renderNewChartsWithScrolling with FIXED HEIGHTS for all cards and proper filter detection
  const renderNewChartsWithScrolling = (): JSX.Element => {
   // Fixed card height for all charts
  const cardHeight = FIXED_CONTAINER_HEIGHT;
  
  const dataSourceRevenueByCarrier = useCache ? cachedData : chartData;
  const dataSourceRevenueByRatePlan = useCache ? cachedData : chartData;
  const dataSourceRevenueByUsageTrend = useCache ? cachedData : chartData;

  // Use exact filter matching - no fallbacks
  const filterToUseRevenueByCarrier = getActualFilterFromData(dataSourceRevenueByCarrier.revenueByCarrier, internalFilterRevenueByCarrier);
  const filterToUseRevenueByRatePlan = getActualFilterFromData(dataSourceRevenueByRatePlan.revenueByRatePlan, internalFilterRevenueByRatePlan);
  const filterToUseRevenueByUsageTrend = getActualFilterFromData(dataSourceRevenueByUsageTrend.revenueByUsageTrend, internalFilterRevenueByUsageTrend);


  const { chartData: revenueByCarrierData, details: revenueByCarrierDetails } = dataSourceRevenueByCarrier.revenueByCarrier
    ? processRevenueByCarrierData(dataSourceRevenueByCarrier.revenueByCarrier, filterToUseRevenueByCarrier, selectedTenantId)
    : { chartData: [], details: {} };
  
  const { chartData: revenueByRatePlanData, providers: ratePlanProviders, planDetails } = dataSourceRevenueByRatePlan.revenueByRatePlan
    ? processRevenueByRatePlanData(dataSourceRevenueByRatePlan.revenueByRatePlan, filterToUseRevenueByRatePlan, selectedTenantId, selectedRatePlanProvider ?? '')
    : { chartData: [], providers: [], planDetails: {} };

    const renderBubbleChart = () => {
  const bubbleData = rectangleData.filter(item => !item.isSpacer && !item.isGap).map(item => ({
    x: item.timeIndex,
    y: item.value,
    z: item.value,
    plan: item.fullName,
    time: item.time,
    value: item.value,
    color: item.color
  }));

  const BubbleTooltip: React.FC<any> = ({ active, payload }) => {
    if (!active || !payload || !payload.length) return null;

    const data = payload[0].payload;

    // Check if current filter is multi-month to show table view (NOT 1_month)
    const isMultiMonthFilter = ["3_month", "6_month", "1_year"].includes(filterToUseRevenueByRatePlan);

    // For multi-month filters ONLY, show comprehensive table
    if (isMultiMonthFilter && data.time?.includes('-W')) {
      let monthIndex: string;
      let monthName: string;
      
      [monthIndex] = data.time.split('-W');
      monthName = getMonthName(parseInt(monthIndex));

      // Extract ALL rate plan data for this specific MONTH
      const monthPlanData = rectangleData.filter((item: any) => {
        if (item.isGap || item.isSpacer || item.value <= 0) return false;
        // For multi-month filters
        return item.time.includes(`${monthIndex}-W`);
      });

      if (monthPlanData.length === 0) return null;

      interface WeekData {
        [week: string]: {
          [planName: string]: number;
        };
      }

      const weekData: WeekData = {};
      const allPlans = new Set<string>();

      // Get all weeks in this month
      const weeksInMonth = [...new Set(monthPlanData.map(item => {
        return item.time.split('-W')[1];
      }).filter(Boolean))].sort((a, b) => parseInt(a) - parseInt(b));

      // Initialize all weeks
      weeksInMonth.forEach(week => {
        weekData[week] = {};
      });

      // Populate data
      monthPlanData.forEach(item => {
        const week = item.time.split('-W')[1];
        
        const planName = item.fullName || item.plan_name;
        if (planName && item.value > 0) {
          weekData[week][planName] = item.value;
          allPlans.add(planName);
        }
      });

      const weeks = Object.keys(weekData).sort((a, b) => parseInt(a) - parseInt(b));
      const plansArray = Array.from(allPlans);

      if (weeks.length === 0 || plansArray.length === 0) return null;

      return (
        <div style={{
          backgroundColor: 'white',
          border: '1px solid #ccc',
          borderRadius: '3px',
          boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
          padding: '4px',
          maxWidth: '300px',
          maxHeight: '200px',
          overflow: 'hidden',
          fontSize: '10px',
          fontFamily: 'Calibri, sans-serif',
          zIndex: 1000
        }}>
          <div style={{
            fontWeight: 'bold',
            marginBottom: '3px',
            fontSize: '10px',
            color: '#333',
            textAlign: 'center',
            borderBottom: '1px solid #eee',
            paddingBottom: '2px'
          }}>
            {monthName} - Revenue By Rate Plan Breakdown By Week
          </div>

          <table style={{
            width: '100%',
            borderCollapse: 'collapse',
            fontSize: '10px',
            tableLayout: 'fixed'
          }}>
            <thead>
              <tr style={{ backgroundColor: '#f8f9fa' }}>
                <th style={{
                  padding: '2px 2px 2px 3px',
                  textAlign: 'left',
                  borderBottom: '1px solid #ddd',
                  fontWeight: 'bold',
                  fontSize: '10px',
                  width: '55px'
                }}>
                  Rate Plan
                </th>
                {weeks.map(week => (
                  <th
                    key={week}
                    style={{
                      textAlign: 'center',
                      padding: '2px 1px',
                      borderBottom: '1px solid #ddd',
                      fontWeight: 'bold',
                      fontSize: '10px',
                      width: '40px'
                    }}
                  >
                    W{week}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {plansArray.map((plan, idx) => {
                const planTotal = weeks.reduce((sum, week) => sum + (weekData[week]?.[plan] || 0), 0);
                if (planTotal === 0) return null;

                const planColor = monthPlanData.find(item =>
                  (item.fullName === plan || item.plan_name === plan) && item.color
                )?.color || '#74B9FF';

                return (
                  <tr
                    key={plan}
                    style={{ background: idx % 2 === 0 ? '#ffffff' : '#f9f9f9' }}
                  >
                    <td
                      style={{
                        backgroundColor: "white",
                        padding: '1px 1px 1px 2px',
                        borderBottom: '1px solid #eee',
                        fontWeight: '500',
                        fontSize: '10px',
                        color: '#333',
                        display: 'flex',
                        alignItems: 'center',
                        gap: '2px',
                        overflow: 'hidden',
                        textOverflow: 'ellipsis',
                        whiteSpace: 'nowrap',
                        width: '100px'
                      }}
                    >
                      <div
                        style={{
                          width: '5px',
                          height: '5px',
                          backgroundColor: planColor,
                          borderRadius: '50%',
                          flexShrink: 0
                        }}
                      />
                      {plan}
                    </td>
                    {weeks.map(week => (
                      <td
                        key={week}
                        style={{
                          textAlign: 'center',
                          padding: '1px 1px',
                          borderBottom: '1px solid #eee',
                          color: '#000',
                          fontWeight: '500',
                          width: '20px'
                        }}
                      >
                        {weekData[week]?.[plan] > 0 ? `$${weekData[week][plan].toFixed(0)}` : '-'}
                      </td>
                    ))}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      );
    }

    const shouldShowLabelText = filterToUseRevenueByRatePlan === "1_day" ||
      filterToUseRevenueByRatePlan === "5_day";
    const labelText = filterToUseRevenueByRatePlan === "1_day" ? "Time" :
      filterToUseRevenueByRatePlan === "5_day" ? "Day" : "";

    let timeLabel = data.time;
    if (data.time.includes('-W')) {
      const [monthIndex, week] = data.time.split('-W');
      const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      const monthName = monthNames[parseInt(monthIndex)] || monthIndex;
      timeLabel = `${monthName}-W${week}`;
   } else if (data.time.startsWith("W") && filterToUseRevenueByRatePlan === "1_month") {
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

  const rangeMonthIndex = startDate
    ? new Date(startDate).getMonth()
    : new Date().getMonth(); 

  const monthName = monthNames[rangeMonthIndex];
  const weekNumber = data.time.substring(1);

  timeLabel = `${monthName} - W${weekNumber}`;
}


    const formatHourLabel = (time: string) => {
  // if time is "09" or "9"
  const hour = parseInt(time);
  if (isNaN(hour)) return time;

  const hh = hour.toString().padStart(2, "0");
  return `${hh}:00`;
};


    return (
      <div 
      className="profit-tooltip"
      style={{
        backgroundColor: 'rgba(255, 255, 255, 0.95)',
        border: '1px solid #ccc',
        borderRadius: '3px',
        padding: '4px 6px',
        fontSize: '10px',
        boxShadow: '0 1px 3px rgba(0,0,0,0.1)',
        maxWidth: '200px'
      }}>
        <div style={{ fontWeight: 'bold', marginBottom: '6px', fontSize: '12px' }}>
          {filterToUseRevenueByRatePlan === "1_day"
  ? formatHourLabel(timeLabel)            //  09:00
  : timeLabel
}

        </div>

        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
            <div
              style={{
                width: "10px",
                height: "10px",
                backgroundColor: data.color,
                borderRadius: "50%"
              }}
            />
            <span style={{ fontSize: '11px', fontWeight: '500' }}>
              {data.plan}:
            </span>
          </div>

          <span style={{ fontSize: '11px', fontWeight: 'normal', paddingLeft: '5px' }}>
            ${data.value.toFixed(2)}
          </span>
        </div>
      </div>
    );
  };

  const chartWidth =
    document.querySelector(".recharts-wrapper")?.clientWidth || FIXED_CARD_HEIGHT;

  // Check if dual axis should be shown
  const shouldShowDualXAxis = ["1_month", "3_month", "6_month", "1_year"].includes(filterToUseRevenueByRatePlan);
const formatHourLabel = (time: string): string => {
  const hour = parseInt(time);
  if (isNaN(hour)) return time;
  return `${String(hour).padStart(2, "0")}:00`;
};


  return (
     <div
    style={{
      position: "relative",
      width: "100%",
      height: FIXED_CARD_HEIGHT,
    }}
  >
    <ResponsiveContainer width="100%" height={FIXED_CARD_HEIGHT}>
      <ScatterChart
        data={bubbleData}
        margin={{
          top: 15,
          right: 30,
          left: 10,
          bottom: shouldShowDualXAxis ? 70 : 50,
        }}
      >
        <CartesianGrid strokeDasharray="2 2" vertical={false} />

        <XAxis
          dataKey="x"
          type="number"
          axisLine={false}
          tickLine={false}
          interval={0}
          allowDecimals={false}
          domain={['dataMin - 0.5', 'dataMax + 0.5']}
          ticks={[
            ...new Set(
              rectangleData
                .filter(d => !d.isGap && !d.isSpacer)
                .map(d => d.timeIndex)
            )
          ]}
          tick={({ x, y, payload }: any): React.ReactElement<SVGElement> => {
  const item = rectangleData.find(
    d => d.timeIndex === payload.value && !d.isGap && !d.isSpacer
  );
  if (!item) return <g />;

  let rawTime = item.time;
  let label = rawTime;

  // For 1-day filter → show full hour as HH:00
  if (filterToUseRevenueByRatePlan === "1_day") {
    label = formatHourLabel(rawTime);
  } 
  // For other filters → your original logic stays
  else {
    if (label.includes("-W")) {
      label = `W${label.split("-W")[1]}`;
    } else if (label.startsWith("W")) {
      label = label;
    }
  }

  return (
    <g transform={`translate(${x},${y})`}>
      <text
        y={14}
        textAnchor="middle"
        fill="#000"
        fontSize={10}
        fontFamily="Calibri, sans-serif"
      >
        {label}
      </text>
    </g>
  );
}}

        />

        <YAxis
          dataKey="y"
          type="number"
          axisLine={false}
          tickLine={false}
          tick={{ fontSize: 12, fill: '#000' }}
          width={80}
           ticks={generateYAxisTicks(rectangleData)}   
  domain={[0, 'dataMax']}                    
  tickFormatter={(v) => `$${v}`}    
          label={{
            value: "Revenue",
            angle: -90,
             offset: -5,  
            position: "insideLeft",
            style: {
              fontSize: '16px',
              fill: '#000',
              fontFamily: 'Calibri',
              fontWeight: 'normal',
              textAnchor: 'middle'
            }
          }}
        />

        <ZAxis dataKey="z" range={[50, 400]} />

        <Tooltip content={<BubbleTooltip />} />

 

        {/* Month Labels for Multi-Month Filters AND 1_month */}
        {shouldShowDualXAxis && (
          <Customized
            component={({ xAxisMap }: any) => {
              const axisEntries = Object.values(xAxisMap || {});
              if (!axisEntries.length) return null;

              const xAxis: any = axisEntries[0];
              const scale = xAxis?.scale;
              if (!scale) return null;

              // For 1_month filter, show current month centered
              // For 1_month filter, show current month centered
              if (filterToUseRevenueByRatePlan === "1_month") {
               
                const firstDataPoint = rectangleData.find((item: any) => 
                  item.time.startsWith('W') && !item.isGap && !item.isSpacer
                );
                
                if (!firstDataPoint) return null;
                
                const monthNames = [
                  "Jan", "Feb", "Mar", "Apr", "May", "Jun",
                  "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
                ];
                const monthIndex = firstDataPoint.monthIndex !== undefined 
                  ? firstDataPoint.monthIndex 
                  : new Date().getMonth();
                const monthName = monthNames[monthIndex];

                // Get all week indexes for 1_month
                const weekIndexes = rectangleData
                  .filter((item: any) => item.time.startsWith('W') && !item.isGap && !item.isSpacer)
                  .map((item: any) => item.timeIndex);

                if (weekIndexes.length === 0) return null;

                const min = Math.min(...weekIndexes);
                const max = Math.max(...weekIndexes);
                const centerIndex = min + (max - min) / 2;

                const xPos = scale(centerIndex);
                if (xPos == null) return null;

                return (
                  <text
                    x={xPos}
                    y={FIXED_CARD_HEIGHT - 60}
                    textAnchor="middle"
                    fontSize={12}
                    fontFamily="Calibri, sans-serif"
                    fill="#000"
                    style={{ pointerEvents: "none" }}
                  >
                    {monthName}
                  </text>
                );
              }

              // For multi-month filters (3M, 6M, 1Y)
              const monthGroups: Record<string, number[]> = {};
              rectangleData.forEach((item: any) => {
                if (item.time.includes("-W") && !item.isGap && !item.isSpacer) {
                  const [month] = item.time.split("-W");
                  if (!monthGroups[month]) monthGroups[month] = [];
                  monthGroups[month].push(item.timeIndex);
                }
              });

              const monthNames = [
                "Jan", "Feb", "Mar", "Apr", "May", "Jun",
                "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
              ];

              return (
                <>
                  {Object.entries(monthGroups).map(([month, indexes]) => {
                    const min = Math.min(...indexes);
                    const max = Math.max(...indexes);
                    const centerIndex = min + (max - min) / 2;

                    const xPos = scale(centerIndex);
                    if (xPos == null) return null;

                    return (
                      <text
                        key={month}
                        x={xPos}
                        y={FIXED_CARD_HEIGHT - 60}
                        textAnchor="middle"
                        fontSize={12}
                        fontFamily="Calibri, sans-serif"
                        fill="#000"
                        style={{ pointerEvents: "none" }}
                      >
                        {monthNames[parseInt(month, 10)]}
                      </text>
                    );
                  })}
                </>
              );
            }}
          />
        )}

        {planNames.map((plan, index) => {
          const planBubbles = bubbleData.filter(d => d.plan === plan);
          if (planBubbles.length === 0) return null;
          return (
            <Scatter
              key={plan}
              data={planBubbles}
              name={plan}
              fill={PLAN_COLORS[index % PLAN_COLORS.length]}
            />
          );
        })}
      </ScatterChart>
    </ResponsiveContainer>
        <div
      style={{
        position: "absolute",
        bottom: 20,
        left: "50%",
        transform: "translateX(-50%)",
        zIndex: 100,
      }}
    >
      <button
        className="px-3 py-1 text-[16px] service-provider-button rounded-md shadow cursor-pointer"
        onMouseEnter={() => setLegendVisible(true)}
        onMouseLeave={() => setLegendVisible(false)}
      >
        Rate Plans
      </button>

      {legendVisible && (
        <div
         className="service-provider-tooltip"
          style={{
            position: "absolute",
            left: "50%",
            transform: "translateX(-50%)",
            bottom: "38px",
            borderRadius: 6,
            padding: "10px 12px",
            minWidth: "180px",
            fontFamily: "Calibri, sans-serif",
            fontSize: "12px",
            zIndex: 200,
          }}
        >
          {planNames.map((plan) => (
            <div
              key={plan}
              style={{
                display: "flex",
                alignItems: "center",
                gap: "8px",
                marginBottom: "6px",
              }}
            >
              <span
                style={{
                  width: 10,
                  height: 10,
                  backgroundColor:
                    rectangleData.find(d => d.fullName === plan)?.color || "#74B9FF",
                  borderRadius: "50%",
                }}
              />
              <span>{plan}</span>
            </div>
          ))}
        </div>
      )}
    </div>

</div>
    
  );
};
  // Filter out empty options and set proper default
  const filteredRatePlanProviders = [...new Set(ratePlanProviders.filter(p => p))];
  const effectiveRatePlanProvider = selectedRatePlanProvider && selectedRatePlanProvider.trim() !== '' 
    ? selectedRatePlanProvider 
    : filteredRatePlanProviders[0] || "";
    

  // Update the usage providers processing to remove "All" and set first as default
  const { chartData: revenueByUsageTrendData, providers: usageProviders, details: usageDetails } = dataSourceRevenueByUsageTrend.revenueByUsageTrend
    ? processRevenueByUsageTrendData(dataSourceRevenueByUsageTrend.revenueByUsageTrend, filterToUseRevenueByUsageTrend, selectedTenantId, selectedUsageProvider ?? '')
    : { chartData: [], providers: [], details: {} };

  
  // Smart Month Tick Component for Rate Plan Chart
const processPlanRectangleData = (
  data: any,
  filter: string,
  tenantId: string,
  selectedProvider: string = "All"
): { rectangleData: any[]; planNames: string[] } => {

  if (!data?.data?.data?.[filter] || !data?.meta?.providers) {
    return { rectangleData: [], planNames: [] };
  }

  const providers = data.meta.providers as { [key: string]: string };

  let filteredData = data.data.data[filter];

  if (tenantId !== "All") {
    filteredData = filteredData.filter(
      (item: any) => String(item.tenant_id) === tenantId
    );
  }

  if (selectedProvider !== "All") {
    const selectedProviderId = Object.keys(providers).find(
      (key) => providers[key] === selectedProvider
    );
    if (selectedProviderId) {
      filteredData = filteredData.filter(
        (item: any) => String(item.provider_id) === selectedProviderId
      );
    }
  }

  const processedData: { [timeLabel: string]: { [plan: string]: number } } = {};
  const allPlans = new Set<string>();

  // **FIX: Process the actual backend data structure**
  filteredData?.forEach((item: any) => {
    item.records?.forEach((record: any) => {
      if (!Array.isArray(record) || record.length < 3) return;
      
      const [date, revenue, planName] = record;
      const numericRevenue = Number(revenue) || 0;

      if (!planName || numericRevenue <= 0) return;

      allPlans.add(planName);

      const recordDate = new Date(date);
      let timeLabel: string;

      switch (filter) {
        case "1_day":
          if (date.includes(" - ")) {
            timeLabel = date;
          } else {
            timeLabel = recordDate.toLocaleTimeString("en-US", {
              hour: "2-digit",
              hour12: false,
            });
          }
          break;

        case "5_day":
          timeLabel = recordDate.toLocaleDateString("en-US", {
            month: "short",
            day: "2-digit",
          });
          break;

       case "1_month":
          const monthStart = new Date(
            recordDate.getFullYear(),
            recordDate.getMonth(),
            1
          );
          const weekNum =
            Math.floor(
              (recordDate.getTime() - monthStart.getTime()) /
                (1000 * 60 * 60 * 24 * 7)
            ) + 1;
          timeLabel = `W${Math.min(weekNum, 4)}`;
          
         
          if (!processedData[timeLabel]) {
            processedData[timeLabel] = {
              monthIndex: recordDate.getMonth(),
              year: recordDate.getFullYear()
            };
          }
          break;

        case "3_month":
        case "6_month":
        case "1_year":
          const monthIndex = recordDate.getMonth();
          const monthStartDate = new Date(
            recordDate.getFullYear(),
            recordDate.getMonth(),
            1
          );
          const weekNumber =
            Math.floor(
              (recordDate.getTime() - monthStartDate.getTime()) /
                (1000 * 60 * 60 * 24 * 7)
            ) + 1;
          timeLabel = `${monthIndex.toString().padStart(2, "0")}-W${Math.min(
            weekNumber,
            5
          )}`;
          break;

        case "5_years":
        case "max":
          timeLabel = recordDate.getFullYear().toString();
          break;

        default:
          timeLabel = date;
      }

      if (!processedData[timeLabel]) {
        processedData[timeLabel] = {};
        allPlans.forEach((plan) => {
          processedData[timeLabel][plan] = 0;
        });
      }

      processedData[timeLabel][planName] =
        (processedData[timeLabel][planName] || 0) + numericRevenue;
    });
  });

  const sortedTimeLabels = Object.keys(processedData).sort((a, b) => {
    if (filter === "1_day") {
      if (a.includes(" - ") && b.includes(" - ")) {
        return a.split(" - ")[0].localeCompare(b.split(" - ")[0]);
      }
      return a.localeCompare(b);
    } else if (filter === "5_day") {
      return new Date(a).getTime() - new Date(b).getTime();
    } else if (filter === "1_month") {
      const weekA = parseInt(a.replace("W", ""));
      const weekB = parseInt(b.replace("W", ""));
      return weekA - weekB;
    } else if (["3_month", "6_month", "1_year"].includes(filter)) {
      const [monthIndexA, weekA] = a.split("-W");
      const [monthIndexB, weekB] = b.split("-W");

      const monthCompare = parseInt(monthIndexA) - parseInt(monthIndexB);
      if (monthCompare !== 0) {
        return monthCompare;
      }
      return parseInt(weekA) - parseInt(weekB);
    } else if (["5_years", "max"].includes(filter)) {
      return parseInt(a) - parseInt(b);
    } else {
      return a.localeCompare(b);
    }
  });

  const validPlans = Array.from(allPlans).filter((plan) =>
    sortedTimeLabels.some((time) => processedData[time][plan] > 0)
  );

  const shouldShowDualXAxis = ["3_month", "6_month", "1_year"].includes(filter);
  const finalRectangleData: any[] = [];

  if (shouldShowDualXAxis) {
    let previousMonth = "";
    let currentXIndex = 0;

    sortedTimeLabels.forEach((timeLabel, index) => {
      const currentMonth = timeLabel.split("-W")[0];

      if (index > 0 && currentMonth !== previousMonth) {
        for (let i = 0; i < 1; i++) {
          finalRectangleData.push({
            id: `spacer-${index}-${i}`,
            time: `spacer-${index}-${i}`,
            isSpacer: true,
            isGap: true,
            x: currentXIndex++,
            y: 0,
            width: 0,
            height: 0,
            value: 0,
          });
        }
      }

      validPlans.forEach((plan, planIndex) => {
        const value = processedData[timeLabel][plan];
        if (value > 0) {
          finalRectangleData.push({
            id: `${plan}-${timeLabel}`,
            plan_name: plan,
            time: timeLabel,
            timeIndex: currentXIndex,
            x: currentXIndex,
            y: value + planIndex * 8,
            width: 40,
            height: 25,
            value: value,
            usage_count: value,
            planIndex: planIndex,
            color: PLAN_COLORS[planIndex % PLAN_COLORS.length],
            isSpacer: false,
            isGap: false,
            displayName:
              plan.length > 6 ? plan.substring(0, 6) + "..." : plan,
            fullName: plan,
          });
        }
      });

      currentXIndex++;
      previousMonth = currentMonth;
    });
  } else {
    sortedTimeLabels.forEach((timeLabel, timeIndex) => {
     validPlans.forEach((plan, planIndex) => {
        const value = processedData[timeLabel][plan];
        if (value > 0) {
          finalRectangleData.push({
            id: `${plan}-${timeLabel}`,
            plan_name: plan,
            time: timeLabel,
            timeIndex: timeIndex,
            x: timeIndex,
            y: value + planIndex * 8,
            width: 40,
            height: 25,
            value: value,
            usage_count: value,
            planIndex: planIndex,
            color: PLAN_COLORS[planIndex % PLAN_COLORS.length],
            isSpacer: false,
            isGap: false,
            displayName:
              plan.length > 6 ? plan.substring(0, 6) + "..." : plan,
            fullName: plan,
            monthIndex: processedData[timeLabel].monthIndex, 
            year: processedData[timeLabel].year 
          });
        }
      });
    });
  }

  return { rectangleData: finalRectangleData, planNames: validPlans };
};



  // Get rectangle data for rate plan chart
  const { rectangleData, planNames } = processPlanRectangleData(
    dataSourceRevenueByRatePlan.revenueByRatePlan, 
    filterToUseRevenueByRatePlan, 
    selectedTenantId, 
    selectedRatePlanProvider ?? ''
  );
  // Calculate positioning for charts when one is expanded
const ratePlanTableData = processRatePlanTableData(rectangleData, planNames);
   return (
    <div className="flex flex-col items-start justify-start w-full">
      <div className={
        isExpanded 
          ? "flex flex-col gap-4 w-full p-6"
          : "grid grid-cols-1 md:grid-cols-2 gap-4 w-full p-6"
      }>
        
        {/* Chart 1: Revenue by Carrier */}
        {features.includes("Revenue By Carrier") && (
          <div style={{ height: `${FIXED_CONTAINER_HEIGHT}px`, width: '100%' }}>
            {renderRevenueByCarrierChart()}
          </div>
        )}
         
         
        {/* Chart 2: Revenue by Rate Plan - FIXED */}
        {features.includes("Revenue By Rate Plan") && (
          <div style={{ height: `${FIXED_CONTAINER_HEIGHT}px`, width: '100%' }}>
            <div className="bg-white p-4 rounded-lg shadow-md graph" style={{ height: `${FIXED_CONTAINER_HEIGHT}px` }}>
              <div className="bg-gray-100 flex justify-between items-center p-4 chart-title">
                <div className="flex items-center">
                  <h2 className="font-semibold">
                    {dataSourceRevenueByRatePlan?.revenueByRatePlan?.data?.title || "Revenue By Rate Plan"}
                  </h2>
                </div>
                <div className="flex items-center gap-2">
 <Select
  options={ratePlanProvidersByMonth}
  value={
    ratePlanProvidersByMonth.find(
      (o) => o.value === selectedRatePlanProvider
    ) || null
  }
  onChange={(opt) => {
    const provider = String((opt as any)?.value);
    console.log("Selected Rate Plan Provider:", provider);
    setSelectedRatePlanProvider(provider);
  }}
  styles={DropdownStyles}
/>



                  {/* <ArrowPathRoundedSquareIcon
                    className="cursor-pointer w-6 h-6"
                    onClick={() => setFlippedChart(flippedChart === 1 ? null : 1)}
                  /> */}
                   <div className="flex items-center">
                     <button
                       onClick={() => setFlippedChart(flippedChart === 1 ? null : 1)}
                       className="flex items-center justify-center cursor-pointer"
                       style={{
                         width: "24px",
                         height: "24px",
                         border: "none",
                         background: "transparent",
                         padding: 0,
                         marginLeft: "4px",
                       }}
                     >
                       <i
                         className="fi fi-rr-flip-horizontal"
                         style={{
                           fontSize: "18px",
                           color: "currentColor",
                           lineHeight: 1,
                         }}
                       />
                     </button>
                   </div>
                </div>
              </div>

              {renderFilterButtons("revenueByRatePlan")}

              {/* Handle no data case properly */}
              {filterToUseRevenueByRatePlan === "no_data" ? (
                <div style={{
                  height: `${FIXED_CARD_HEIGHT}px`,
                  display: 'flex',
                  justifyContent: 'center',
                  alignItems: 'center',
                  fontSize: '16px',
                  color: '#6b7280',
                  fontFamily: 'Calibri, sans-serif'
                }}>
                  No Data Available
                </div>
              ) : flippedChart === 1 ? (
                <div style={{
                  height: `${FIXED_CARD_HEIGHT}px`,
                  padding: "10px",
                  overflow: 'hidden'
                }}>
                  {rectangleData.length === 0 ? (
                    <div style={{
                      height: '100%',
                      display: 'flex',
                      justifyContent: 'center',
                      alignItems: 'center',
                      fontSize: '16px',
                      color: '#6b7280',
                      fontFamily: 'Calibri, sans-serif'
                    }}>
                      No Data Available
                    </div>
                  ) : (
                    <Table
  dataSource={ratePlanTableData}
  columns={[
    {
       title: (
    <span style={{ fontSize: "14px", fontFamily: "Calibri, sans-serif" }}>
      Time Period
    </span>
  ),
      dataIndex: "time",
      key: "time",
      width: 150,
       render: (value: string) => {
    let displayValue = value;

    if (value.includes('-W')) {
      const [monthIndex, week] = value.split('-W');
      const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      const monthName = monthNames[parseInt(monthIndex)] || monthIndex;
      displayValue = `${monthName}-W${week}`;
    }

    return (
      <span style={{ fontFamily: "Calibri, sans-serif" }}>
        {displayValue}
      </span>
    );
  },
      // Add these styling properties to match other columns
      onHeaderCell: () => ({
        style: { 
          fontSize: '14px',
          fontFamily: "Calibri, sans-serif",
          padding: '8px 16px',
          whiteSpace: 'nowrap',

        }
      }),
      onCell: () => ({
        style: { 
          fontSize: '14px',
          fontFamily: "Calibri, sans-serif",
          padding: '8px 16px'
        }
      })
    },
    ...planNames.map((plan, index) => ({
      title: plan.length > 12 ? plan.substring(0, 12) + "..." : plan,
      dataIndex: plan,
      key: plan,
      width: Math.max(80, Math.floor((window.innerWidth - 200) / planNames.length)),
      render: (value: number) => {
        return value > 0 ? `$${value.toFixed(2)}` : "-";
      },
      onHeaderCell: () => ({
        style: { 
          fontSize: '14px',
          fontFamily: "Calibri, sans-serif",
          padding: '8px 16px',
          whiteSpace: 'nowrap',
          overflow: 'hidden',
          textOverflow: 'ellipsis'
        }
      }),
      onCell: () => ({
        style: { 
          fontSize: '12px',
          fontFamily: "Calibri, sans-serif",
          padding: '8px 16px'
        }
      })
    })),
  ]}
  pagination={false}
  style={{ 
    fontSize: '14px',
    width: '100%'
  }}
/>
                  )}
                </div>
              ) : (
               <div style={{ height: `${FIXED_CARD_HEIGHT}px`, padding: "8px", position: "relative" }}>
                  {loading || !allApisLoaded ? (
                    <div className="flex flex-row justify-center items-center h-full">
                      <Spin size="large" />
                    </div>
                  ) : rectangleData.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full w-full">
                      <span style={{ fontSize: 16, color: "#6b7280", fontFamily: 'Calibri, sans-serif' }}>No Data Available</span>
                    </div>
                  ) : (
                    <div style={{ position: "relative", width: "100%", height: "100%" }}>
                      {renderBubbleChart()}
                    </div>
                  )}
                </div>
              )
  }
            </div>
          </div>
        )}

        {/* Chart 3: Profit Margin Trend */}
        {features.includes("Profit Margin Trend") && (
          <div style={{ height: `${FIXED_CONTAINER_HEIGHT}px`, width: '100%' }}>
            {renderProfitMarginTrendChart()}
          </div>
        )}

        {/* Chart 4: Revenue by Usage Trend */}
{features.includes("Revenue by Usage Type") && (
  <div style={{ height: `${FIXED_CONTAINER_HEIGHT}px`, width: '100%' }}>
    <div className="bg-white p-4 rounded-lg shadow-md graph" style={{ height: `${FIXED_CONTAINER_HEIGHT}px` }}>
      <div className="bg-gray-100 flex justify-between items-center p-4 chart-title">
        <div className="flex items-center">
          <h2 className="font-semibold">
            {dataSourceRevenueByUsageTrend.revenueByUsageTrend?.data?.title || "Revenue by Usage Type"}
          </h2>
        </div>
                 <div className="flex items-center gap-2">
                  <Select
  options={usageProvidersByMonth}
  value={usageProvidersByMonth.find(o => o.value === selectedUsageProvider) || null}
  onChange={(opt) => {
    const provider = (opt as any)?.value;
    console.log("Selected Usage Provider:", provider);
    setSelectedUsageProvider(provider);
  }}
  styles={DropdownStyles}
/>

                   {/* <ArrowPathRoundedSquareIcon
                     className="cursor-pointer w-6 h-6 ml-2"
                     onClick={() => setFlippedChart(flippedChart === 3 ? null : 3)}
                   /> */}
                   <div className="flex items-center">
                     <button
                       onClick={() => setFlippedChart(flippedChart === 3 ? null : 3)}
                       className="flex items-center justify-center cursor-pointer"
                       style={{
                         width: "24px",
                         height: "24px",
                         border: "none",
                         background: "transparent",
                         padding: 0,
                         marginLeft: "4px",
                       }}
                     >
                       <i
                         className="fi fi-rr-flip-horizontal"
                         style={{
                           fontSize: "18px",
                           color: "currentColor",
                           lineHeight: 1,
                         }}
                       />
                     </button>
                   </div>
                 </div>
      </div>
      
      {renderFilterButtons("revenueByUsageTrend")}
      
               <div style={{ padding: "16px", height: `${FIXED_CARD_HEIGHT}px`, overflow: 'hidden' }}>
                 {loading || !allApisLoaded ? (
                   <div className="flex flex-row justify-center items-center h-full w-full">
                     <Spin size="large" />
                   </div>
                 ) : filterToUseRevenueByUsageTrend === "no_data" ? (
                   <div style={{
                     display: 'flex',
                     justifyContent: 'center',
                     alignItems: 'center',
                     height: '100%',
                     fontSize: '16px',
                     color: '#6b7280',
                     fontFamily: 'Calibri, sans-serif'
                   }}>
                     No Data Available
                   </div>
                 ) : flippedChart === 3 ? (
                   // Table view
                   (() => {
                     const { chartData, usageTypes } = processUsageTrendTimeBasedData(
                       dataSourceRevenueByUsageTrend.revenueByUsageTrend,
                       filterToUseRevenueByUsageTrend,
                       selectedTenantId,
                       selectedUsageProvider ?? ''
                     );

                    

                     const usageTableData = chartData
                       .filter(item => !item.isGap)
                       .map((item, index) => {
                         return { ...item, key: index };
                       });

                     return (
                       <div style={{
                         height: `${FIXED_CARD_HEIGHT}px`,
                         padding: "10px",
                         overflow: 'hidden'
                       }}>
                         <Table
                           dataSource={usageTableData}
                           columns={[
                             {
                               title: "Time Period",
                               dataIndex: "time",
                               key: "time",
                              width: 150,
                               render: (value: string) => {
                                 if (value.includes('-W')) {
                                   const [monthIndex, week] = value.split('-W');
                                   const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                                     'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                                   const monthName = monthNames[parseInt(monthIndex)] || monthIndex;
                                   return `${monthName}-W${week}`;
                                 }
                                 return value;
                               },
                               onHeaderCell: () => ({
                                  style: { 
                                    fontSize: '14px',
                                    fontFamily: "Calibri, sans-serif",
                                    padding: '8px 16px',
                                    whiteSpace: 'nowrap',

                                  }
                                }),
                                onCell: () => ({
                                  style: { 
                                    fontSize: '14px',
                                    fontFamily: "Calibri, sans-serif",
                                    padding: '8px 16px'
                                  }
                                })
                             },
                             // FIXED: Use actual usage types from backend instead of hard-coded
                             ...usageTypes.map((usageType, index) => ({
                               title: usageType.toLowerCase() === "sms" ? "SMS" : usageType,
                               dataIndex: usageType, // This must match the property name in chartData
                               key: usageType,
                               width: Math.max(80, Math.floor((window.innerWidth - 200) / usageTypes.length)),
                               render: (value: number) => {
                                 return value && value > 0 ? `$${value.toFixed(2)}` : "-";
                               },
                               onHeaderCell: () => ({
                                 style: {
                                   fontSize: '14px',
                                   fontFamily: "Calibri, sans-serif",
                                   padding: '8px 16px',
                                   whiteSpace: 'nowrap',
                                   overflow: 'hidden',
                                   textOverflow: 'ellipsis'
                                 }
                               }),
                               onCell: () => ({
                                 style: {
                                   fontSize: '14px',
                                   fontFamily: "Calibri, sans-serif",
                                   padding: '8px 16px'
                                 }
                               })
                             })),
                           ]}
                           pagination={false}
                           // scroll={{
                           //   y: FIXED_CARD_HEIGHT - 120,
                           //   x: usageTypes.length > 6 ? "max-content" : undefined
                           // }}
                           size="small"
                           style={{
                             fontSize: '9px',
                             width: '100%'
                           }}
                         />
                       </div>
                     );
                   })()
                 ) : (
                   // Chart view
                         (() => {
                           const { chartData, usageTypes, processedData, monthPositions } = processUsageTrendTimeBasedData(
                             dataSourceRevenueByUsageTrend.revenueByUsageTrend,
                             filterToUseRevenueByUsageTrend,
                             selectedTenantId,
                             selectedUsageProvider ?? ''
                           );
                           if (chartData.length === 0) {
                             return (
                               <div style={{
                                 display: 'flex',
                                 justifyContent: 'center',
                                 alignItems: 'center',
                                 height: '100%',
                                 fontSize: '16px',
                                 color: '#6b7280',
                                 fontFamily: 'Calibri, sans-serif'
                               }}>
                                 No Data Available
                               </div>
                             );
                           }
                           const shouldShowDualXAxis = ["1_month", "3_month", "6_month", "1_year"].includes(filterToUseRevenueByUsageTrend);
                           const bottomMargin = shouldShowDualXAxis ? 60 : 45;
                           const topMargin = shouldShowDualXAxis ? 30 : 10;
                           const legendHeight = Math.ceil(usageTypes.length / 4) * 20 + 10;
                           const CenteredMonthXAxisTick = (props: any): React.ReactElement<SVGElement> => {
                             const { x, y, payload, index } = props;

                             if (payload?.value?.startsWith('gap-')) {
                               return <g></g>;
                             }

if (filterToUseRevenueByUsageTrend === "1_month") {
  const visibleWeeks = processedData.filter(d => !d.isGap);
  
  if (!visibleWeeks.length) return <g />;

  const firstWeek = visibleWeeks[0].time;
  const lastWeek = visibleWeeks[visibleWeeks.length - 1].time;

  // Only render once - let's use the first week this time
  if (payload.value !== firstWeek) return <g />;

  const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const monthIndex = visibleWeeks[0].monthIndex;
  if (monthIndex === undefined) return <g />;

  const monthName = monthNames[monthIndex];

  // For 2 weeks: we want to position between them
  // x is currently at W1 position
  // We need to move right by approximately half the distance to W2
  
  // Since you have barSize={20}, barGap={1}, and barCategoryGap="5%"
  // For 2 weeks, we need to find the midpoint between them
  // The actual spacing in Recharts with these settings is approximately:
  // barSize(20) + barGap(1) + categoryGap ≈ 45-50 pixels total between bar centers
  
  const numberOfWeeks = visibleWeeks.length;
  
  // For 2 weeks: move halfway = 0.5 of the distance
  // For 3 weeks: move to middle = 1.0 of the distance
  // For 4 weeks: move 1.5 times the distance
  const distanceMultiplier = (numberOfWeeks - 1) / 2;
  
  // Adjust this value based on your chart's actual rendering
  // Start with 45 and tune up or down
  const barCenterDistance = 48;
  const xOffset = barCenterDistance * distanceMultiplier;

  return (
    <g>
      <text
        x={x + xOffset}
        y={y + 28}
        textAnchor="middle"
        fontSize={10}
        fill="#000"
      >
        {monthName}
      </text>
    </g>
  );
}

                             // ✅ Handle multi-month filters (3_month, 6_month, 1_year)
                             // Find current item in processed data
                             const currentIndex = processedData.findIndex(item => item.time === payload.value);
                             if (currentIndex === -1) return <g></g>;

                             // Get month from current item
                             const currentMonth = payload?.value?.split('-W')[0];
                             if (!currentMonth) return <g></g>;

                             const monthInfo = monthPositions.find(m => m.month === currentMonth);
                             if (!monthInfo) return <g></g>;

                             // Calculate if this is the position where we should show the month name
                             const weekCount = monthInfo.endIndex - monthInfo.startIndex + 1;
                             let shouldShowMonth = false;

                             if (weekCount === 1) {
                               shouldShowMonth = currentIndex === monthInfo.startIndex;
                             } else if (weekCount === 2) {
                               shouldShowMonth = currentIndex === monthInfo.startIndex;
                             } else if (weekCount === 3) {
                               shouldShowMonth = currentIndex === monthInfo.startIndex + 1;
                             } else if (weekCount === 4) {
                               shouldShowMonth = currentIndex === monthInfo.startIndex + 1;
                             } else {
                               shouldShowMonth = currentIndex === Math.floor(monthInfo.centerIndex);
                             }

                             if (!shouldShowMonth) return <g></g>;

                             const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                               'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                             const monthIndex = parseInt(currentMonth);
                             const monthName = monthNames[monthIndex] || currentMonth;

                             // Calculate X offset for even number of weeks (to center between weeks)
                             let xOffset = 0;
                             const currentFilter = filterToUseRevenueByUsageTrend;

                             if (weekCount === 2 || weekCount === 4) {
                               if (currentFilter === "3_month") {
                                 xOffset = 60;
                               } else if (currentFilter === "6_month") {
                                 xOffset = 60;
                               } else if (currentFilter === "1_year") {
                                 xOffset = 60;
                               }
                             }

                             return (
                               <g>
                                 <text
                                   x={x + xOffset}
                                   y={y + 5}
                                   textAnchor="middle"
                                   fontSize={10}
                                   fill="#000"
                                 >
                                   {monthName}
                                 </text>
                               </g>
                             );
                           };

                           const transformDataForVisibility = (data: any[], usageTypes: string[]) => {
                             return data.map(item => {
                               if (item.isGap) return item;

                               const transformed: any = { ...item };
                               usageTypes.forEach(type => {
                                 transformed[type] = item[type] || 0;
                               });

                               return transformed;
                             });
                           };

                           const transformedChartData = transformDataForVisibility(processedData, usageTypes);
                           const getDynamicCleanTicks = (data: any[], usageTypes: string[]): number[] => {
                             if (!data || data.length === 0) return [0];

                             const totals = data
                               .filter((d) => !d.isGap)
                               .map((d) => usageTypes.reduce((sum, key) => sum + Number(d[key] || 0), 0));

                             const maxValue = Math.max(...totals);

                             if (maxValue <= 0) return [0];

                             const magnitude = Math.pow(10, Math.floor(Math.log10(maxValue)));

                             const multipliers = [1, 2, 5];

                             let chosenStep = magnitude;

                             // 3️⃣ Choose clean step giving 4–7 ticks
                             for (const m of multipliers) {
                               const step = m * magnitude;
                               if (maxValue / step <= 7) {
                                 chosenStep = step;
                                 break;
                               }
                             }
                             const upperBound = Math.ceil(maxValue / chosenStep) * chosenStep;

                             const ticks: number[] = [];
                             for (let v = 0; v <= upperBound; v += chosenStep) {
                               ticks.push(v);
                             }

                             return ticks;
                           };

                           return (
                             <div style={{ height: `${FIXED_CARD_HEIGHT + 20}px`, overflow: 'hidden', position: 'relative' }}>
                               <ResponsiveContainer width="100%" height={FIXED_CARD_HEIGHT + 20}>
                                 <BarChart
                                   // data={processedData}
                                   data={transformedChartData}  // Use transformed data here
                                   margin={{
                                     top: 10,
                                     right: -10,
                                     left: 20,
                                     bottom: bottomMargin
                                   }}
                                   barGap={1}
                                   barCategoryGap="5%"
                                   barSize={20}

                                 >
                                   <CartesianGrid strokeDasharray="2 2" vertical={false} />
                                   {/* Reference Areas for month borders */}
                                   {/* {shouldShowDualXAxis && monthPositions.map((mp, idx) => {
                      if (mp.total === 0) return null;
                      return (
                        <ReferenceArea
                          key={`ref-${idx}`}
                          x1={processedData[mp.startIndex].time}
                          x2={processedData[mp.endIndex].time}
                          fill="rgba(116, 185, 255, 0.1)"
                          stroke="#74B9FF"
                          strokeWidth={1}
                          // y1={0}
                          // y2="max"
                        />
                      );
                    })} */}

                                   {/* Top X-Axis for month totals */}
                                   {/* {shouldShowDualXAxis && (
                      <XAxis
                        xAxisId="monthTotal"
                        dataKey="time"
                        axisLine={false}
                        tickLine={false}
                        interval={0}
                        tick={CenteredMonthTotalTick}
                        height={15}
                        orientation="top"
                      />
                    )} */}

                                 
                                 {/* Primary X-Axis for weeks */}
                                   <XAxis
                                     dataKey="time"
                                     axisLine={false}
                                     tickLine={false}
                                     interval={0}
                                     tick={({ x, y, payload }) => {
                                       if (!payload?.value || payload.value.startsWith("gap-")) {
                                         return <g />;
                                       }

                                       let displayLabel = payload.value;
                                       
                                       if (payload.value.includes('-W')) {
                                         displayLabel = `W${payload.value.split('-W')[1]}`;
                                       }

                                       return (
                                         <g transform={`translate(${x},${y})`}>
                                           <text
                                             y={14}
                                             textAnchor="middle"
                                             fontSize={10}
                                             fill="#000"
                                           >
                                             {displayLabel}
                                           </text>
                                         </g>
                                       );
                                     }}
                                   />

                                   {/* Secondary X-Axis for months */}
                                   {shouldShowDualXAxis && (
                                     <XAxis
                                       xAxisId="month"
                                       dataKey="time"
                                       axisLine={false}
                                       tickLine={false}
                                       interval={0}
                                       tick={CenteredMonthXAxisTick}
                                       height={35}
                                       orientation="bottom"
                                       dy={20}
                                     />
                                   )}
                                   <YAxis
                                     axisLine={false}
                                     tickLine={false}
                                     tick={{ fontSize: 12, fill: "#000" }}
                                     // tickFormatter={(value) => `${value}`}
                                     ticks={getDynamicCleanTicks(processedData, usageTypes)}
                                     tickFormatter={(v) => `$${v.toLocaleString()}`}
                                     domain={[
                                       0,
                                       () => {
                                         const t = getDynamicCleanTicks(processedData, usageTypes);
                                         return t[t.length - 1];
                                       }
                                     ]}
                                   >
                                     <Label
                                       value="Revenue"
                                       angle={-90}
                                       position="insideLeft"
                                       offset={-15}
                                       style={{
                                         fontSize: 16,
                                         //  fontWeight: 600,
                                         fill: "#000",
                                         fontFamily: "Calibri",
                                         textAnchor: "middle"
                                       }}

                                     />
                                   </YAxis>
                                   <Tooltip
                                     content={(props: any) => {
                                       if (props.payload?.[0]?.payload?.isGap) {
                                         return null;
                                       }
                                       return <UsageTypeTimeBasedTooltip {...props} currentFilter={filterToUseRevenueByUsageTrend} processedData={processedData} />;
                                     }}
                                     cursor={{
                                       fill: 'rgba(0, 0, 0, 0.1)',
                                       stroke: 'none'
                                     }}
                                     allowEscapeViewBox={{ x: false, y: false }}
                                     position={{ x: undefined, y: undefined }}
                                     isAnimationActive={false}
                                   />

                                   <Legend
                                     verticalAlign="bottom"
                                     align="center"
                                     height={legendHeight}
                                     iconType="square"
                                     wrapperStyle={{
                                       fontSize: "16px",
                                       fontWeight: "normal",
                                       position: "absolute",
                                       lineHeight: "1.1",
                                       width: "100%",
                                       left: "0",
                                       bottom: "50px",
                                       maxHeight: "20px",
                                       overflow: "hidden"
                                     }}
                                     layout="horizontal"
                                      formatter={(value: string) => (
    <span style={{ color: "#000" }}>
      {value.toLowerCase() === "sms" ? "SMS" : value}
    </span>
  )}
                                   />
                                   {usageTypes.map((usageType, index) => (
                                     <Bar
                                       key={usageType}
                                       dataKey={usageType}
                                       stackId="usage"
                                       fill={BLUE_SHADES[index % BLUE_SHADES.length]}
                                       isAnimationActive={true}
                                       radius={index === usageTypes.length - 1 ? [2, 2, 0, 0] : [0, 0, 0, 0]}
                                       style={{ cursor: selectedFilter === partner ? "pointer" : "default" }}
                                     // FIXED: Remove connectNulls since we're using 0 values now
                                     />
                                   ))}

                                   {chartData.length === 0 && (
                                     <text x="50%" y="50%" textAnchor="middle" fontSize={14}>
                                       No Data Available
                                     </text>
                                   )}
                                 </BarChart>
                               </ResponsiveContainer>
                             </div>
                           );
                         })()
                 )}
               </div>
    </div>
  </div>
)}
      </div>
    </div>
  );
  };

const renderControls = () => {
  const isSmallScreen = typeof window !== "undefined" && window.innerWidth < 700;

  // Desktop layout with aligned controls
  
  return (
    // <div className="w-full" style={{ paddingLeft: "24px", paddingRight: "24px" }}>
     <div
        className="flex flex-row flex-nowrap items-center justify-between w-full p-2 overflow-x-auto"
        style={{ gap: '8px', whiteSpace: 'nowrap' }}
      >
        {/* ----- LEFT SECTION ----- */}
        <div className="flex flex-row flex-nowrap items-center" style={{ gap: '6px' }}>
          <Select
          value={{ label: selectedFilter, value: selectedFilter }}
          onChange={(opt) => handleFilterChange(opt?.value ?? "")}
          options={filterOptions.options}
          placeholder="Tenant"
          isSearchable
          noOptionsMessage={() => "No options"}
           styles={{...DropdownStyles , 
                       control: (base, state) => ({
                        ...DropdownStyles.control(base, state),
                        paddingRight: "0px", // reduce gap
                      }),
                       indicatorsContainer: (base) => ({
                      ...base,
                      paddingRight: "0px", // reduce arrow space
                    }),
                     singleValue: (base) => ({
                      ...DropdownStyles.singleValue(base),
                      marginRight: "0px", // bring text closer
                    }),
                    }}
                    components={{
                        IndicatorSeparator: () => null
                      }}
                      menuPlacement="auto"
                  menuPortalTarget={document.body}

        />
          {/* NEW: Billing Cycle Period Dropdown */}
          {showBillingCyclePeriod && selectedServiceProvider !== "All service providers" && (
          <Select
            className="min-w-[150px]" 
            value={{ label: selectedBillingCyclePeriod, value: selectedBillingCyclePeriod }}
            onChange={(opt) => handleBillingCyclePeriodChange(opt?.value ?? "")}
            options={billingCyclePeriods.map(period => ({
              value: period,
              label: period
            }))}
            placeholder="Billing Cycle"
            styles={{...DropdownStyles , 
                         control: (base, state) => ({
                          ...DropdownStyles.control(base, state),
                          paddingRight: "0px", // reduce gap
                        }),
                         indicatorsContainer: (base) => ({
                        ...base,
                        paddingRight: "0px", // reduce arrow space
                      }),
                       singleValue: (base) => ({
                        ...DropdownStyles.singleValue(base),
                        marginRight: "0px", // bring text closer
                      }),
                      }}
                        components={{
                          IndicatorSeparator: () => null
                        }}
                        menuPlacement="auto"
                        menuPortalTarget={document.body}
          />
        )}

        <Select
          value={{ label: selectedServiceProvider, value: selectedServiceProvider }}
          onChange={(opt) => handleServiceProviderChange(opt?.value ?? "")}
          options={serviceProviders.map(provider => ({
            value: provider,
            label: provider
          }))}
          placeholder="Service Provider"
           styles={{...DropdownStyles , 
                       control: (base, state) => ({
                        ...DropdownStyles.control(base, state),
                        paddingRight: "0px", // reduce gap
                      }),
                       indicatorsContainer: (base) => ({
                      ...base,
                      paddingRight: "0px", // reduce arrow space
                    }),
                     singleValue: (base) => ({
                      ...DropdownStyles.singleValue(base),
                      marginRight: "0px", // bring text closer
                    }),
    menuPortal: (base) => ({
      ...base,
      zIndex: 9999,
      position: "fixed",
    }),
    menu: (base) => ({
      ...base,
      zIndex: 9999,
    }),
  }}
                      
                            components={{
                        IndicatorSeparator: () => null
                      }}
                      menuPlacement="auto"
                  menuPortalTarget={document.body}
        />

        

          {/* "Select:" text - aligned with other elements */}
          <span 
          style={{ 
            fontFamily: "Calibri, sans-serif", 
            fontSize: "14px",
            // color: "currentColor",
            whiteSpace: "nowrap",
            marginLeft: "12px",
            marginRight: "4px",
            height: "38px",
            display: "flex",
            alignItems: "center",
          }} className="dashboard-select-text"
          >
            Select:
          </span>
          
          {/* Time selection buttons - same height as selects */}
          <button
            className={selectedButton === "Current Month" ? "save-btn !min-h-[40px]" : "email-dashboard-btns"}
            onClick={() => handleButtonClick("Current Month")}
            style={{
              fontFamily: "Calibri,sans-serif",
              fontSize: 12,
              padding: "0 12px",
              height: 38,
              // borderRadius: 7,
              minWidth: "60px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            Month
          </button>
          
          <button
            className={selectedButton === "Current Week" ? "save-btn !min-h-[40px]" : "email-dashboard-btns"}
            onClick={() => handleButtonClick("Current Week")}
            style={{
              fontFamily: "Calibri,sans-serif",
              fontSize: 12,
              padding: "0 12px",
              height: 38,
              // borderRadius: 7,
              minWidth: "55px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            Week
          </button>
          
          <button
            className={selectedButton === "Today" ? "save-btn !min-h-[40px]" : "email-dashboard-btns"}
            onClick={() => handleButtonClick("Today")}
            style={{
              fontFamily: "Calibri,sans-serif",
              fontSize: 12,
              padding: "0 12px",
              height: 38,
              // borderRadius: 7,
              minWidth: "55px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            Today
          </button>

          {/* Date Range */}
          <RangePicker
            value={dateRange}
            onChange={handleDateRangeChange}
            style={{
              width: 220,
              height: 38,
              borderRadius: 7,
              fontSize: 12,
              marginLeft: 4,
            }}
            popupClassName="custom-range-popup"
            disabledDate={current => current && current > dayjs().endOf("day")}
            placeholder={["Start", "End"]}
            disabled={(showBillingCyclePeriod && selectedBillingCyclePeriod !== "None")}
          />
        </div>
        
        {/* Right side - Action buttons */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 8,
            flexShrink: 0,
          }}
        >
          <DashboardRefresh tabName={"Revenue Metrics"} onRefresh={initializeDashboard} tabKey={"revenue_metrics"}/>
          <DashboardColumnFilter tabName={"Revenue Metrics"} setFeatures={setFeatures} />
        </div>
      </div>
    // </div>
  );
};


  // Main render function
  return (
    <>
      {loading ? (
        <div className="flex justify-center items-center h-screen">
          <Spin size="large" />
        </div>
      ) : (
        <Suspense fallback={<Spin size="large" />}>
          {renderControls()}
          <RevenueMetricCards
          selectedServiceProvider={selectedServiceProvider  === "All service providers" ? "" : selectedServiceProvider}
          selectedTenantId={selectedTenantId}
           // ✅ FIX: Do NOT send start & end date when billing cycle dropdown is used
          startDate={
            selectedBillingCyclePeriod && !selectedButton ? "" : startDate
          }
          endDate={
            selectedBillingCyclePeriod && !selectedButton ? "" : endDate
          }
          serviceProvider={selectedFilter === "All Tenants" ? "All" : selectedFilter}
          billingCyclePeriod={selectedServiceProvider === "All service providers" ? "" : selectedBillingCyclePeriod}
          features={features}
        />

          {renderNewChartsWithScrolling()}
        </Suspense>
      )}
    </>
  );
};

export default RevenueMetrics;
