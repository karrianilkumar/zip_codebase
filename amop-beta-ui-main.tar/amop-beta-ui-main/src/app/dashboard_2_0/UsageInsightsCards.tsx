import React, { useEffect, useState } from "react";
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import { Spin } from "antd";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import dayjs from "dayjs";

interface ConfigTypes {
  title: string;
  height: number;
  width: number;
  count: number | string;
}

interface UsageInsightsCardsProps {
  selectedServiceProvider: string;
  startDate: string;
  endDate: string;
  serviceProvider: string;
  selectedTenantId: any;
  billingCyclePeriod?: string; // Optional prop for billing cycle period
  features: string[];
   selectedByteUnit?: "GB" | "MB" | "KB"; 
}

// Define route configurations
const ROUTE_CONFIGS = [
  {
    path: "/total_usage_card",
    title: "Total Usage",
    countKey: "total_usage_gb",
  },
  {
    path: "/total_usage_sims_count",
    title: "No.of Usage SIMs",
    countKey: "usage_sims_count",
  },
  
  {
    path: "/total_usage_cost",
    title: "Total Usage Cost",
    countKey: "total_usage_cost",
  },
  {
    path:"/average_usage_card",
    title:"Average Usage",  
    countKey:"average_usage_gb"
  }
];

const UsageInsightsCards: React.FC<UsageInsightsCardsProps> = ({
  selectedServiceProvider,
  startDate,
  endDate,
  serviceProvider,
  selectedTenantId,
  billingCyclePeriod,
  features,
   selectedByteUnit 
}) => {
  const [loading, setLoading] = useState(false);
  const [datalog, setData] = useState<ConfigTypes[]>([]);
  const [rawData, setRawData] = useState<ConfigTypes[]>([]);
  const { token, partner, selectedDb, metaData, sessionId, username, role } = useAuth();

    // filter whenever features changes
    useEffect(() => {
      if (rawData.length > 0) {
        const filteredResults = rawData.filter((item) =>
          features.some((f) => f.trim().toLowerCase() === item.title.trim().toLowerCase())
        );
        setData(filteredResults);
      }
    }, [features, rawData]);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      
let finalStart = startDate;
let finalEnd = endDate;

// If both are null → use current month range
if (!startDate && !endDate) {
  finalStart = dayjs().startOf("month").format("YYYY-MM-DD");
  finalEnd = dayjs().format("YYYY-MM-DD");
}

      try {
        const url = ENV_ROUTES.DASHBOARD;
        const requestData = {
          partner: partner,
          tenant_name: partner,
          start_date: selectedServiceProvider ==="" || billingCyclePeriod === "None" ? finalStart : startDate,
          end_date: selectedServiceProvider ==="" || billingCyclePeriod === "None" ?  finalEnd  : endDate,
          tenant_id: selectedTenantId,
          role_name: role,
          username: username,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          service_provider: selectedServiceProvider,
          // billing_cycle_end_period: billingCyclePeriod || "", // Use the billing cycle period if provided
          billing_cycle_end_period:
          billingCyclePeriod === "None"
          // ? dayjs().format("YYYY-MM-DD HH:mm:ss") burhan
          ? ""
          : billingCyclePeriod || "",
        };

        // Fetch data for all configured routes
        const results: ConfigTypes[] = [];

        for (const config of ROUTE_CONFIGS) {
          const response = await axios.post(url, { data: { path: config.path, ...requestData } });
          const parsedData = JSON.parse(response.data.body);
          const { data } = parsedData;

          results.push({
            title: data.title || config.title,
            count: data[config.countKey],
            height: 100, // Default height, adjust as needed
            width: 300, // Default width, adjust as needed
          });
        }

        setRawData(results);
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [token, selectedServiceProvider, startDate, endDate, selectedTenantId, partner, role, username, selectedDb, sessionId]);

  if (loading) {
    return (
      <div className="ml-1 py-2 px-6 w-full">
            <div className="grid grid-cols-2 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="col-span-4 flex justify-center items-center py-10">
                <Spin size="large" />
              </div>
            </div>
          </div>
    );
  }

  const isSmallScreen = typeof window !== "undefined" && window.innerWidth < 700;

  return (
    <div className="ml-1 py-2 px-6 w-full">
      <div className="grid grid-cols-2 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
       
        {datalog.map((item, index) => {
          // ---- Unit conversion ONLY for Average Usage card ----
          let titleToShow = item.title;
          let countToShow: number | string = item.count;

if (
  item.title.trim() === "Average Usage per SIM (GB)" ||
  item.title.toLowerCase().includes("average usage per sim")
) {
  const kbValue = Number(String(item.count).replace(/,/g, ""));
  const mbValue = kbValue / 1024;
  const gbValue = mbValue / 1024;

  if (selectedByteUnit === "KB") {
    countToShow = kbValue.toLocaleString(undefined, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
    titleToShow = "Average Usage per SIM (KB)";
  } else if (selectedByteUnit === "MB") {
    countToShow = mbValue.toLocaleString(undefined, {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2
    });
    titleToShow = "Average Usage per SIM (MB)";
  } else {
    countToShow = gbValue.toLocaleString(undefined, {
      minimumFractionDigits: 4, // 🔥 More precision
      maximumFractionDigits: 4
    });
    titleToShow = "Average Usage per SIM (GB)";
  }
}


          // ---- Unit conversion ONLY for Total Usage card ----

if (item.title.trim() === "Total Usage (GB)" || item.title.trim() === "Total Usage") {
  const kbValue = Number(String(item.count).replace(/,/g, ""));

  const gbValue = kbValue / (1024 * 1024); // KB → GB

  if (selectedByteUnit === "MB") {
    countToShow = (kbValue / 1024).toLocaleString(undefined, {
      maximumFractionDigits: 2,
    });
    titleToShow = "Total Usage (MB)";
  } else if (selectedByteUnit === "KB") {
    countToShow = kbValue.toLocaleString(undefined, {
      maximumFractionDigits: 2,
    });
    titleToShow = "Total Usage (KB)";
  } else {
    countToShow = gbValue.toLocaleString(undefined, {
      maximumFractionDigits: 2,
    });
    titleToShow = "Total Usage (GB)";
  }
}



          return (
            <div
              key={index}
              className="chart w-full"
              style={
                isSmallScreen
                  ? { width: "150px", height: "100px" }
                  : { minHeight: "75px" }
              }
            >
              <div className="p-2 mt-0">
                <div className="flex flex-col sm:text-left text-center">
                  <h2
                    style={{
                      fontFamily: "Calibri, sans-serif",
                      fontSize: "18px",
                    }}
                  >
                    {titleToShow}
                  </h2>
                  <p className="chart-count">
                    <span style={{ fontSize: "18px" }}>
                      {countToShow}
                    </span>
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default UsageInsightsCards;