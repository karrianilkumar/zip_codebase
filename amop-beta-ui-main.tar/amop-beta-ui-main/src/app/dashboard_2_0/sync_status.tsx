"use client";
import React, { lazy, Suspense, useEffect, useState } from "react";
import { useAuth } from "../components/auth_context";
import { ENV_ROUTES } from "../components/routes/route_constants";
import axios from "axios";
import { getCurrentDateTime } from "../components/header_constants";
import { Button, DatePicker, Modal, notification, Spin } from "antd";
import Select from "react-select";
import { ChevronDownIcon, ChevronLeftIcon, ChevronRightIcon, InformationCircleIcon } from "@heroicons/react/24/outline";
import moment, { months } from "moment";
import dayjs, { Dayjs } from "dayjs";
import { DropdownStyles } from "../components/css/dropdown";

const DashboardTables = lazy(() => import("@/app/dashboard_1_0/dasboard_table"));

const { RangePicker } = DatePicker;
interface FilterOptions {
  options: any[];
}
interface Message {
  [key: string]: number;
}

interface ChartDataItem {
  provider: string;
  messages: Message;
}


const SyncStatus: React.FC = () => {
  const { username, partner, role, selectedDb,metaData, token, firstLastName, sessionId, setSelectedPartner } = useAuth();
  const [loading, setLoading] = useState(false);
  const [filterOptions, setFilterOptions] = useState<FilterOptions>({
    options: [],
  });
  const [selectedFilter, setSelectedFilter] = useState("All");
  const [selectedButton, setSelectedButton] = useState<string | null>("Today");
  const [startDate, setStartDate] = useState<string>(
    moment().format("YYYY-MM-DD")
  );
  const [endDate, setEndDate] = useState<string>(moment().format("YYYY-MM-DD"));
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([
    null,
    null,
  ]);

  const { RangePicker } = DatePicker;
  const [dashboardFeatures, setDashboardFeatures] = useState<string[]>([]);

  // Inside your component
const [isSmallMediumScreen, setIsSmallMediumScreen] = useState(false);
const [selectedServiceProvider, setSelectedServiceProvider] = useState<string>("All service providers");

const [tenantOptions, setTenantOptions] = useState<any[]>([]);
const [serviceProviderData, setServiceProviderData] = useState<any>({});

useEffect(() => {
  const handleResize = () => {
    setIsSmallMediumScreen(window.innerWidth <= 1000); // Customize breakpoint if needed
  };

  handleResize(); // Set on mount
  window.addEventListener("resize", handleResize);

  return () => window.removeEventListener("resize", handleResize);
}, []);



const fetchDashboardFeatures = async () => {
  try {
    const url = ENV_ROUTES.MODULE_MANAGEMENT;
    const data = {
      tenant_name: partner || "default_value",
      username,
      firstLastName,
      path: "/get_dashboard_features",
      role_name: role,
      Partner: partner,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
    };

    const response = await axios.post(url, { data });
    const parsed = JSON.parse(response.data.body);

  if (parsed.flag && parsed?.module_features) {
  setDashboardFeatures(parsed?.module_features);
  localStorage.setItem(
    "dashboardFeatures",
    JSON.stringify(parsed?.module_features)
  );
  console.log("Dashboard 1.0 features:", parsed?.module_features);
}


  } catch (error) {
    console.error("Error fetching dashboard features:", error);
  }
};



  useEffect(() => {
    const initializeDashboard = async () => {
      setSelectedPartner(true); // Keep this as it is for setting the partner state
      console.log("App mounted, fetching SSM parameters");
      setLoading(true); // Start loading state
  
      try {
        // Fetch SSM Parameters first
        // await fetchSSMParameters();
        console.log("SSM parameters fetched successfully");
        await fetchDashboardFeatures(); // 👈 call the new API

        // Proceed to fetch the filter options and data after SSM parameters are ready
        // await fetchFilterOptions(); // Fetch the filter options
        await fetchTenantProviderOptions();
        // Fetch data with the selected start and end dates, and the selected filter
      } catch (error) {
        console.error("Error during initialization:", error);
      } finally {
        setLoading(false); // Stop loading state
      }
    };
  
    // Call the initialization function
    initializeDashboard();
  }, [startDate, endDate]); // Dependencies to re-run the effect when dates or filters change


 

  const handleButtonClick = (
    range: "Today" | "Current Week" | "Current Month"
  ) => {
    setSelectedButton(range);

  let newStartDate: string;
  let newEndDate: string;
  if (range === "Today") {
    newStartDate = moment().format("YYYY-MM-DD");
    newEndDate = moment().format("YYYY-MM-DD");
  } else if (range === "Current Week") {
    newStartDate = moment().startOf('week').format("YYYY-MM-DD");
    newEndDate = moment().endOf('week').format("YYYY-MM-DD");
  } else if (range === "Current Month") {
    newStartDate = moment().subtract(30, "days").format("YYYY-MM-DD");
    newEndDate = moment().format("YYYY-MM-DD");
  } else if (range === "1 Year") {
    // ✅ NEW: Show from current month to 12 months back
    newStartDate = moment().subtract(12, "months").format("YYYY-MM-DD");
    newEndDate = moment().format("YYYY-MM-DD");
  } else {
    newStartDate = moment().subtract(30, "days").format("YYYY-MM-DD");
    newEndDate = moment().format("YYYY-MM-DD");
  }
 
  setStartDate(newStartDate);
  setEndDate(newEndDate);
  setDateRange([dayjs(newStartDate), dayjs(newEndDate)]);
  };

  const handleDateRangeChange = (
    dates: [Dayjs | null, Dayjs | null] | null,
    dateStrings: [string, string]
  ) => {
    if (dates && dates[0] && dates[1]) {
      setSelectedButton(null);
      setDateRange([dates[0], dates[1]]);
      setStartDate(dates[0].format("YYYY-MM-DD"));
      setEndDate(dates[1].format("YYYY-MM-DD"));
      setSelectedButton("");
    } else {
      const today = moment().format("YYYY-MM-DD");
      setDateRange([null, null]);
      setSelectedButton("Today");
      setSelectedServiceProvider("All service providers");
      setStartDate(today);
      setEndDate(today);
    }
  };

  useEffect(() => {
    let startDate = "";
    let endDate = "";

    if (selectedButton === "Today") {
      startDate = moment().format("YYYY-MM-DD");
      endDate = moment().format("YYYY-MM-DD");
    } else if (selectedButton === "Current Week") {
      startDate = moment().startOf("week").format("YYYY-MM-DD");
      endDate = moment().endOf("week").format("YYYY-MM-DD");
    } else if (selectedButton === "Current Month") {
      startDate = moment().startOf("month").format("YYYY-MM-DD");
      endDate = moment().endOf("month").format("YYYY-MM-DD");
    } else if (dateRange[0] && dateRange[1]) {
      startDate = dateRange[0].format("YYYY-MM-DD");
      endDate = dateRange[1].format("YYYY-MM-DD");
    }

  }, [selectedButton, dateRange, selectedFilter]);

  const fetchFilterOptions = async () => {
    try {
      const url = ENV_ROUTES.DASHBOARD;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_service_providers",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Dashboard",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      const serviceProviders = parsedData.service_providers
        .sort((a: string, b: string) => a.localeCompare(b))
        .map((provider: any) => ({
          value: provider,
          label: provider,
        }));
      setFilterOptions({ options: serviceProviders });
    } catch (error) {
      console.error(error);
    }
  };
  const fetchTenantProviderOptions = async () => {
    try {
      const url = ENV_ROUTES.DASHBOARD;
      const data = {
        partner_name: partner || "default_value",
        tenant_name: selectedFilter,
        username: username,
        firstLastName: firstLastName,
        path: "/get_tenant_and_service_providers_dropdown_data",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Dashboard",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      
      if (parsedData.flag && parsedData.data) {
        // Process tenant dropdown data
        const tenants = parsedData.data.tenant_dropdown_data?.map((tenant: any) => ({
          value: tenant.tenant_name,
          label: tenant.tenant_name,
        })) || [];
        
        // Add "All" option at the beginning
        tenants.unshift({ value: "All", label: "All" });
        setTenantOptions(tenants);
        
        // Store service provider data for filtering
        setServiceProviderData(parsedData.data.service_provider_dropdown_data || {});
        
        // Set default service provider to "All service providers" if All tenant is selected
        if (selectedFilter) {
          setSelectedServiceProvider("All service providers");
        }
      }
    } catch (error) {
      console.error(error);
    }
  };

  // Helper function to get filtered service providers based on selected tenant
  const getFilteredServiceProviders = () => {
    if (selectedFilter === "All") {
      // Return all service providers from all tenants
      const allProviders = new Set<string>();
      Object.values(serviceProviderData).forEach((providerArray: any) => {
        providerArray.forEach((provider: any) => {
          allProviders.add(provider.service_provider_name);
        });
      });
      const providers = Array.from(allProviders).map((name: string) => ({
        value: name,
        label: name,
      }));
      // Add "All service providers" option at the beginning
      providers.unshift({ value: "All service providers", label: "All service providers" });
      return providers;
    } else {
      // Return service providers for the selected tenant
      const providers = serviceProviderData[selectedFilter]?.map((provider: any) => ({
        value: provider.service_provider_name,
        label: provider.service_provider_name,
      })) || [];
      providers.unshift({ value: "All service providers", label: "All service providers" });
      return providers;
    }
  };

  const handleFilterChange = async (value: any) => {
    setSelectedFilter(value);
    // Reset service provider based on selected tenant
    if (value === "All") {
      setSelectedServiceProvider("All service providers");
    } else {
      // Get the providers for the newly selected tenant
      const tenantProviders = serviceProviderData[value] || [];
      // if (tenantProviders.length > 0) {
      //   // Set to the first provider of the selected tenant
      //   setSelectedServiceProvider(tenantProviders[0].service_provider_name);
      // } else {
      //   setSelectedServiceProvider("");
      // }
    }
  };

const handleServiceProviderChange = async (value: string) => {
  setSelectedServiceProvider(value);
}
  const renderControls = () => {
    const availableOptions = filterOptions.options.filter(
      (option: any) => option.value !== selectedFilter
    ); 
    const isSmallScreen = typeof window !== "undefined" && window.innerWidth < 700;

    if (isSmallScreen) {
      return (
        <div className="flex flex-col gap-4 mx-3 my-2">
          {/* First Row: Select and RangePicker */}
          <div className="flex justify-between items-center gap-2">
            {/* <Select
              style={{
                width: "100%",
                maxWidth: 200,
                fontWeight: "450",
                height: "47px",
                fontFamily: "Calibri, sans-serif",
                borderRadius: "8px",
              }}
              value={selectedFilter}
              onChange={handleFilterChange}
              options={availableOptions}
              notFoundContent="No options available"
              showSearch
              suffixIcon={<ChevronDownIcon className="w-4 h-4 text-gray-600" />}
              className="flex-1"
            /> */}
            <RangePicker
              value={dateRange}
              onChange={handleDateRangeChange}
              style={{
                width: "220px",
                // maxWidth: 250,
                height: "47px",
                borderRadius: "8px",
              }}
              disabledDate={(current) =>
                current && current > dayjs().endOf("day")
              }
              popupClassName="custom-range-popup"
              className="flex-1 small-screen-range-picker"
            />
          </div>
          {/* Second Row: Select label and Buttons */}
          <div className="flex flex-wrap items-center gap-2">
            <span
              style={{
                fontFamily: "Calibri, sans-serif",
                fontSize: "16px",
              }}
              className="mr-2 dashboard-select-text"
            >
              Select:
            </span>
            <button
              className={
                selectedButton === "Today"
                  ? "save-btn !min-h-[40px]"
                  : "email-dashboard-btns"
              }
              onClick={() => handleButtonClick("Today")}
              style={{
              fontFamily: "Calibri,sans-serif",
              fontSize: 13,
              padding: "0 12px",
              height: 38, // Same height as selects
              // borderRadius: 7,
              minWidth: "60px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
            >
              Today
            </button>
            <button
              className={
                selectedButton === "Current Week"
                  ? "save-btn !min-h-[40px]"
                  : "email-dashboard-btns"
              }
              onClick={() => handleButtonClick("Current Week")}
              style={{
              fontFamily: "Calibri,sans-serif",
              fontSize: 13,
              padding: "0 12px",
              height: 38, // Same height as selects
              // borderRadius: 7,
              minWidth: "60px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
            >
              Current Week
            </button>
            <button
              className={
                selectedButton === "Current Month"
                  ? "save-btn !min-h-[40px]"
                  : "email-dashboard-btns"
              }
              onClick={() => handleButtonClick("Current Month")}
              style={{
              fontFamily: "Calibri,sans-serif",
              fontSize: 13,
              padding: "0 12px",
              height: 38, // Same height as selects
              // borderRadius: 7,
              minWidth: "60px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
            >
              Current Month
            </button>
          </div>
        </div>
        
      );
    }
 
  
    return (
       <div
        className="flex flex-row flex-nowrap items-center justify-between w-full p-2 overflow-x-auto"
        style={{ gap: '8px', whiteSpace: 'nowrap' }}
      >
       <div className="flex flex-row flex-nowrap items-center" style={{ gap: '6px' }}>
        <Select
          className="min-w-[200px]"
          value={{ label: selectedFilter, value: selectedFilter }}
          onChange={(opt) => handleFilterChange(opt?.value ?? "")}
          options={tenantOptions}
          placeholder="Tenant"
          isSearchable
          noOptionsMessage={() => "No options"}
          styles={{
            ...DropdownStyles,
            control: (base, state) => ({
              ...DropdownStyles.control(base, state),
              paddingRight: "0px", // reduce gap
            }),
            indicatorsContainer: (base) => ({
              ...base,
              paddingRight: "0px", // reduce arrow space
            }),
            singleValue: (base) => ({
              ...DropdownStyles.singleValue(base),
              marginRight: "0px", // bring text closer
            }),
          }}
          components={{
            IndicatorSeparator: () => null
          }}
          menuPlacement="auto"
          menuPortalTarget={document.body}

        />
          <Select
          value={{ label: selectedServiceProvider, value: selectedServiceProvider }}
          onChange={(opt) => handleServiceProviderChange(opt?.value ?? "")}
          options={getFilteredServiceProviders()}
          placeholder="Service Provider"
          styles={{
            ...DropdownStyles,
            control: (base, state) => ({
              ...DropdownStyles.control(base, state),
              paddingRight: "0px", // reduce gap
            }),
            indicatorsContainer: (base) => ({
              ...base,
              paddingRight: "0px", // reduce arrow space
            }),
            singleValue: (base) => ({
              ...DropdownStyles.singleValue(base),
              marginRight: "0px", // bring text closer
            }),
            menuPortal: (base) => ({
              ...base,
              zIndex: 9999,
              position: "fixed",
            }),
            menu: (base) => ({
              ...base,
              zIndex: 9999,
            }),
          }}

          components={{
            IndicatorSeparator: () => null
          }}
          menuPlacement="auto"
          menuPortalTarget={document.body}
        />
       
        
      </div>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "flex-end",
          marginBottom: "10px",
          // marginTop: "10px",
          marginRight: "12px",
        }}
        className="flex flex-wrap gap-2"
      >
        
        {/* <Select
          style={{
            width: 200,
            fontWeight: "450",
            height: "47px",
            fontFamily: "Calibri, sans-serif",
            borderRadius: "8px",
          }}
          value={selectedFilter}
          onChange={handleFilterChange}
          options={availableOptions}
          notFoundContent="No options available"
          showSearch
          suffixIcon={<ChevronDownIcon className="w-4 h-4 text-gray-600" />}
        /> */}
        <span
          style={{
            fontFamily: "Calibri, sans-serif",
            fontSize: "16px",
            marginTop: "-2px",
          }}
          className="dashboard-select-text"
        >
          Select:
        </span>
        <button
          className={
            selectedButton === "Today" ? "save-btn !min-h-[40px]" : "email-dashboard-btns"
          }
          onClick={() => handleButtonClick("Today")}
         style={{
              fontFamily: "Calibri,sans-serif",
              fontSize: 13,
              padding: "0 12px",
              height: 38, // Same height as selects
              // borderRadius: 7,
              minWidth: "60px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
        >
          Today
        </button>
        <button
          className={
            selectedButton === "Current Week"
              ? "save-btn !min-h-[40px]"
              : "email-dashboard-btns"
          }
          onClick={() => handleButtonClick("Current Week")}
          style={{
              fontFamily: "Calibri,sans-serif",
              fontSize: 13,
              padding: "0 12px",
              height: 38, // Same height as selects
              // borderRadius: 7,
              minWidth: "60px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
        >
          Current Week
        </button>
        <button
          className={
            selectedButton === "Current Month"
              ? "save-btn !min-h-[40px]"
              : "email-dashboard-btns"
          }
          onClick={() => handleButtonClick("Current Month")}
          style={{
              fontFamily: "Calibri,sans-serif",
              fontSize: 13,
              padding: "0 12px",
              height: 38, // Same height as selects
              // borderRadius: 7,
              minWidth: "60px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
        >
          Current Month
        </button>
        <RangePicker
          value={dateRange}
          onChange={handleDateRangeChange}
          style={{
            width:"220px",
            height: "47px",
            borderRadius: "8px",
          }}
          popupClassName="custom-range-popup"
          disabledDate={(current) => current && current > dayjs().endOf("day")}
        />
      </div>
      </div>
       
    );
  
  };



  return (
    <>
      {loading ? (
        <div className="flex justify-center items-center h-screen">
          <Spin size="large" />
        </div>
      ) : (
        <>
          <Suspense>
            {renderControls()}
           
            {/* Tables Section */}
            <div className="m-[10px]">
              <DashboardTables
                selectedServiceProvider={selectedFilter}
                startDate={startDate}
                endDate={endDate}
                serviceProvider={selectedServiceProvider.toLowerCase() === "all service providers" ? "All" : selectedServiceProvider}
                dashboardFeatures={dashboardFeatures}
              />

            </div>
          </Suspense>
         
        </>
      )}
    </>
  );
};


export default SyncStatus;