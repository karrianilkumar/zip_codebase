"use client";
import React, { lazy, Suspense, useEffect, useState, ReactElement, useRef } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "../components/auth_context";
import { useLogoStore } from "../stores/logoStore";
import {
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
  LabelList,
  CartesianGrid,
} from "recharts";
import { ENV_ROUTES } from "../components/routes/route_constants";
import axios from "axios";
import { getCurrentDateTime } from "../components/header_constants";
import { Button, DatePicker, Spin, Table } from "antd";
import Select from "react-select";
import { ChevronDownIcon, ArrowPathRoundedSquareIcon } from "@heroicons/react/24/outline";
import moment from "moment";
import dayjs, { Dayjs } from "dayjs";
import { addWeeks, differenceInCalendarWeeks, format, isValid, parse, parseISO, startOfMonth, startOfWeek } from "date-fns";
import { groupBy } from "lodash";
import DashboardColumnFilter from "./dashboardColumnFilter";
import DashboardRefresh from "./dashboardRefreshComponent";
import { Popover } from "antd"; // add if not already imported
import { DropdownStyles } from "../components/css/dropdown";
import { ResponsiveLine } from '@nivo/line';
import { ResponsiveBar } from "@nivo/bar";
const ZendeskTrackingCards = lazy(() => import("@/app/dashboard_2_0/ZendeskTrackingCards"));

const { RangePicker } = DatePicker;

interface FilterOption {
  value: string;
  label: string;
  tenant_id: string;
}

interface FilterOptions {
  options: FilterOption[];
}

interface ChartData {
  ticketStatusDistribution: any | null;
  ticketSeverityOverview: any | null;
  ticketCategoryDistribution: any | null;
  ticketComplianceByModule:any | null;
}

interface ProcessedChartData {
  chartData: Array<{ [key: string]: any }>;
  details: { [key: string]: { [date: string]: number } };
}

interface ProcessedLineChartData {
  chartData: Array<{ day: string; dayName: string;[key: string]: any }>;
  details: { [key: string]: { [date: string]: number } };
}

interface ProcessedBarChartData {
  chartData: Array<{ Category: string; Count: number }>;
  details: { [key: string]: { [date: string]: number } };
}

interface ProcessedTimeBasedData {
  chartData: Array<{ time: string;[category: string]: number | string }>;
  details: { [timeLabel: string]: { [category: string]: number } };
  categories: string[];
}

interface CustomTooltipProps {
  active?: boolean;
  payload?: Array<{ value: number; name: string; dataKey: string; color: string }>;
  label?: string;
  details?: { [key: string]: { [date: string]: number } };
}

interface EnhancedResponsiveContainerProps {
  dataLength: number;
  height: number;
  children: ReactElement;
  expandHorizontally?: boolean;
}
// 1. ADD THESE INTERFACES AFTER YOUR EXISTING INTERFACES (around line 40)
interface TicketComplianceData {
  organization_id: string;
  records: {
    [module: string]: {
      [subcategory: string]: {
        [date: string]: {
          open: number;
          close: number;
          progress: number;
          before_eta: number;
          eta: number;
          after_eta: number;
        };
      };
    };
  };
}

interface ProcessedComplianceData {
  chartData: Array<{
    time: string;
    subcategory: string;
    open: number;
    close: number;
    progress: number;
    before_eta: number;
    eta: number;
    after_eta: number;
  }>;
  subcategories: string[];
  modules: string[];
}

// 2. ADD THESE CONSTANTS AFTER YOUR EXISTING COLOR CONSTANTS (around line 70)

const COMPLIANCE_STATUS_COLORS = {
  open: "#74B9FF",      // Blue
  close: "#55EFC4",     // Green  
  progress: "#A29BFE",  // Purple
  before_eta: "#FABE58", // Yellow
  eta: "#FF7675",       // Red
  after_eta: "#D980FA"  // Pink
};

// Updated color palette to match SimsOverview exactly
const BLUE_SHADE_COLORS = [
  "#00AFF0", // bright sky blue
  "#34E7E4", // turquoise cyan
  "#F7B731", // sunflower yellow
  "#ED4C67", // vibrant pink
  "#9980FA", // medium purple
  "#F6E58D", // pale yellow
  "#303952", // deep blue-grey
  "#B33771", // rich magenta
  "#FD7272", // salmon
  "#BDC581", // muted green
  "#786FA6", // lavender grey
  "#8395A7", // steel blue
  "#222F3E", // dark blue
  "#F8A5C2", // blush pink
  "#576574", // medium slate
  "#9AECDB", // pale teal
  "#FEA47F", // apricot
  "#55EFCB", // mint
  "#C44569",  // mauve-red
  "#74B9FF","#A29BFE","#FF7675","#81ECEC","#D980FA","#55EFC4","#FABE58","#00B894","#FF9FF3","#00CEC9","#BDC3C7","#FFEAA7", "#E17055", // vivid orange-red

];

// Updated severity colors
const SEVERITY_COLORS = ["#FF7675", "#FABE58", "#74B9FF", ]; // Red, green, blue matching SimsOverview

const STATUS_CATEGORIES = ["Open", "To do", "Inprogress", "Closed"];
const SEVERITY_CATEGORIES = ["High", "Medium", "Low"] as const;

type SeverityType = typeof SEVERITY_CATEGORIES[number];

const EnhancedResponsiveContainer: React.FC<EnhancedResponsiveContainerProps> = ({ dataLength, height, children }) => {
  return (
    <div style={{
      width: "100%",
      height: `${height}px`,
      overflow: "hidden",
      position: "relative"
    }}>
      <ResponsiveContainer width="100%" height={height}>
        {children}
      </ResponsiveContainer>
    </div>
  );
};

// Enhanced Custom Tooltip for Line Chart with dynamic labels
const CustomLineTooltip: React.FC<any> = ({ active, payload, label, details, filter }) => {
  if (!active || !payload || !payload.length) {
    return null;
  }

  const getTooltipLabel = (label: string, filter: string) => {
    // Convert month index to month name for 3M, 6M, 1Y filters
    let displayLabel = label;
    if (label.includes('-W')) {
      const [monthIndex, week] = label.split('-W');
      const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      const monthName = monthNames[parseInt(monthIndex)] || monthIndex;
      displayLabel = `${monthName}-W${week}`;
    }

    switch (filter) {
      case "1_day":
        return `Time: ${displayLabel}`;
      case "5_day":
        return `Day: ${displayLabel}`;
      case "1_month":
        return `Week: ${displayLabel}`;
      case "3_month":
      case "6_month":
      case "1_year":
        return ` ${displayLabel}`;
      case "5_years":
      case "max":
        return `${displayLabel}`;
      default:
        return `Period: ${displayLabel}`;
    }
  };

  return (
    <div
      style={{
        border: "1px solid #ccc",
        padding: "10px",
        borderRadius: "4px",
        boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
        backgroundColor: "rgba(255, 255, 255, 0.95)",
        fontSize:"14px",
      }}
      className="new-dashboard-tooltip"
    >
      <p style={{ fontWeight: 500, marginBottom: 5 }}>
        {getTooltipLabel(label, filter)}
      </p>
      {payload.map((entry: any, index: number) => (
        <div
          key={index}
          style={{
            display: "flex",
            alignItems: "center",
            margin: "3px 0",
            width: "100%",
          }}
        >
          {/* Left side: Color + label */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: "6px",
              flex: 1,
            }}
          >
            <div
              style={{
                width: 10,
                height: 10,
                backgroundColor: entry.color,
                borderRadius: "50%",
              }}
            />
            <span style={{ color: "#000", fontSize: "14px" }}>{entry.name}</span>
          </div>

          {/* Right side: Value */}
          <span
            style={{
              color: "black",
              fontSize: "14px",
              fontWeight: "normal",
              paddingLeft: "6px", // ⬅️ YOUR REQUESTED SPACING
              minWidth: "24px", // keeps layout stable
              textAlign: "right",
            }}
          >
            {entry.value}
          </span>
        </div>
      ))}



      {/* {details && details[label] && Object.keys(details[label]).length > 0 && (
        <>
          <hr style={{ margin: "5px 0" }} />
          {Object.entries(details[label])
            .sort(([dateA], [dateB]) => dateA.localeCompare(dateB))
            .map(([date, count]) =>
              (count as number) > 0 ? (
                <p key={date} style={{ margin: 0, fontSize: "10px" }}>
                  {date}: {count as number}
                </p>
              ) : null
            )}
        </>
      )} */}
    </div>
  );
};

// Enhanced Time-based tooltip matching SimsOverview
// Enhanced Time-based tooltip matching SimsOverview with proper hover detection

const TicketCategoryTooltip: React.FC<{
  active?: boolean;
  payload?: any[];
  label?: string;
  filter?: string;
  processedData?: any[];
  categories?: string[];
  colors?: string[]; // BLUE_SHADE_COLORS
}> = ({ active, payload, label, filter, processedData = [], categories = [], colors = [] }) => {
  if (!active || !payload || !payload.length || !label) return null;

const getMonthName = (m: string) => {
  const idx = parseInt(m, 10);   // 0-based month from your dataset
  const names = ["Jan","Feb","Mar","Apr","May","Jun","Jul",
                 "Aug","Sep","Oct","Nov","Dec"];
  return names[idx] ?? m;
};
const isMultiMonth = ["3_month", "6_month", "1_year"].includes(filter || "");

  // -------- Multi-Month TABLE Tooltip --------
  if (isMultiMonth && label.includes("-W")) {
    const [monthKey] = label.split("-W");
const monthName = getMonthName(monthKey);  // → "Dec"

    // Always use full category list
    const allCats = categories;

    // Filter rows of only this month (ignore spacers)
    const monthRows = processedData.filter(
      d => d.time && d.time.startsWith(monthKey + "-W") && !d.isGap
    );
    if (monthRows.length === 0) return null;

    // Unique weeks inside this month
    const weeks = [...new Set(monthRows.map(d => d.time.split("-W")[1]))]
      .sort((a, b) => parseInt(a) - parseInt(b));

    // Prepare matrix: week → category → value
    const weekData: Record<string, Record<string, number>> = {};
    weeks.forEach(w => {
      weekData[w] = {};
      allCats.forEach(cat => (weekData[w][cat] = 0));
    });
    monthRows.forEach(row => {
      const wk = row.time.split("-W")[1];
      allCats.forEach(cat => {
        weekData[wk][cat] = Number(row[cat] || 0);
      });
    });

    // Match same color as bars
    const getColor = (cat: string) => {
      const found = payload.find(p => p.dataKey === cat);
      if (found?.color) return found.color;
      const idx = allCats.indexOf(cat);
      return idx >= 0 ? colors[idx % colors.length] : "#999";
    };

    return (
      <div style={{
        background: "#fff",
        border: "1px solid #ccc",
        borderRadius: 4,
        boxShadow: "0 2px 4px rgba(0,0,0,0.15)",
        padding: "6px 8px",
        width: 240,
        fontSize: 10,
        pointerEvents: "none",     // 🛑 important
    transform: "translate3d(0,0,0)",
        fontFamily: "Calibri",
        zIndex: 9999
      }}>
        
        {/* -------- Tooltip Header (Correct Month) -------- */}
        <div style={{
          fontWeight: 700,
          marginBottom: 4,
          textAlign: "center",
          fontSize: 10,
          borderBottom: "1px solid #eee",
          paddingBottom: 3
        }}>
          {`${monthName} - Category Breakdown by Week`}
        </div>

        {/* -------- Table -------- */}
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 10 }}>
          <thead>
            <tr style={{ background: "#f8f9fa" }}>
              <th style={{ padding: "2px 3px", textAlign: "left", borderBottom: "1px solid #ddd" }}>Category</th>
              {weeks.map(w => (
                <th key={w} style={{ textAlign: "center", borderBottom: "1px solid #ddd" }}>W{w}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {allCats.map((cat, idx) => {
              const total = weeks.reduce((sum, w) => sum + (weekData[w][cat] || 0), 0);
              if (total === 0) return null; // Hide empty rows

              return (
                <tr key={cat} style={{ background: idx % 2 === 0 ? "#fff" : "#f9f9f9" }}>
                  <td style={{
                    padding: "2px 3px",
                    borderBottom: "1px solid #eee",
                    fontWeight: 500,
                    display: "flex",
                    alignItems: "center",
                    gap: 4
                  }}>
                    <div style={{
                      width: 6,
                      height: 6,
                      borderRadius: 2,
                      background: getColor(cat)
                    }} />
                    {cat}
                  </td>
                  {weeks.map(w => (
                    <td key={w} style={{
                      textAlign: "center",
                      padding: 2,
                      borderBottom: "1px solid #eee",
                      fontWeight: 600,
                      color: weekData[w][cat] > 0 ? "#000" : "#000"
                    }}>
                      {weekData[w][cat] || "-"}
                    </td>
                  ))}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    );
  }

  // -------- Normal Tooltip (1D/5D etc.) --------
  const validEntries = payload.filter(e => e.value > 0);
  if (validEntries.length === 0) return null;

 let title = label;
if (label.includes("-W")) {
  const [m, w] = label.split("-W");
  title = `${getMonthName(m)}-W${w}`;
}

  return (
    <div style={{
      background: "#fff",
      border: "1px solid #ccc",
      borderRadius: 4,
      boxShadow: "0 2px 4px rgba(0,0,0,0.15)",
      padding: "6px 8px",
      fontSize: 10,
      fontFamily: "Calibri"
    }}>
      <div style={{ fontWeight: 700, marginBottom: 4 }}>{title}</div>
      {validEntries.map(e => (
        <div key={e.dataKey} style={{ display: "flex", justifyContent: "space-between", marginBottom: 2 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 4 }}>
            <div style={{ width: 8, height: 8, borderRadius: 2, background: e.color }} />
            <span>{e.dataKey}</span>
          </div>
          <span style={{ fontWeight: 600 }}>{e.value}</span>
        </div>
      ))}
    </div>
  );
};




// Helper functions for time-based processing
const getWeekNumber = (date: Date, monthStart: Date): number => {
  const dayDiff = Math.floor((date.getTime() - monthStart.getTime()) / (1000 * 60 * 60 * 24));
  return Math.floor(dayDiff / 7) + 1;
};

const getMonthName = (monthIndex: number): string => {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return months[monthIndex];
};

// Add TriangleDot component after the helper functions
const TriangleDot = (props: any) => {
  const { cx, cy, stroke } = props;
  if (typeof cx !== "number" || typeof cy !== "number") return null;
  const size = 4;
  return (
    <polygon
      points={`${cx},${cy - size} ${cx - size},${cy + size} ${cx + size},${cy + size}`}
      fill={stroke}
      stroke={stroke}
    />
  );
};

// Add these two functions after your existing helper functions (around line 150)

// Helper function for smart month positioning
// Add this helper function near the top of your component (around line 300)
const formatYAxisTick = (value: number): string => {
  if (value === 0) return "0";
  
  // Round to nearest value ending in 0 or 5
  const rounded = Math.round(value);
  const lastDigit = rounded % 10;
  
  let formattedValue: number;
  if (lastDigit <= 2) {
    formattedValue = rounded - lastDigit; // Round down to nearest 0
  } else if (lastDigit <= 7) {
    formattedValue = rounded - lastDigit + 5; // Round to nearest 5
  } else {
    formattedValue = rounded - lastDigit + 10; // Round up to nearest 10 (ends in 0)
  }
  
  return formattedValue.toString();
};

// Update the getAdjustedDomain function to work with the new formatting
const getAdjustedDomain = (data: any[], field: string) => {
  if (!data || data.length === 0) return [0, 10];
  const values = data.map((item) => Number(item[field])).filter((v) => !isNaN(v));
  if (values.length === 0) return [0, 10];
  const max = Math.max(...values);
  
  // Adjust max to nearest value ending in 0 or 5
  const lastDigit = max % 10;
  let adjustedMax: number;
  if (lastDigit <= 2) {
    adjustedMax = max - lastDigit + 5; // Round up to nearest 5
  } else if (lastDigit <= 7) {
    adjustedMax = max - lastDigit + 10; // Round up to nearest 10
  } else {
    adjustedMax = max - lastDigit + 15; // Round up to next 5
  }
  
  return [0, Math.max(adjustedMax, 10)];
};

const ZendeskTracking: React.FC = () => {
  const router = useRouter();
  const { username, partner, role, selectedDb, metaData, token, firstLastName, sessionId, setSelectedPartner } = useAuth();
  const setTitle = useLogoStore((state) => state.setTitle);
  const [loading, setLoading] = useState<boolean>(false);
  const [filterOptions, setFilterOptions] = useState<FilterOptions>({ options: [] });
  const [selectedFilter, setSelectedFilter] = useState<string>(partner || "");
  const [selectedTenantId, setSelectedTenantId] = useState<string>("");
  const [selectedButton, setSelectedButton] = useState<string | null>("Current Month");
  const [startDate, setStartDate] = useState<string>(moment().startOf("month").format("YYYY-MM-DD"));
  const [endDate, setEndDate] = useState<string>(moment().format("YYYY-MM-DD"));
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([null, null]);
  const [chartData, setChartData] = useState<ChartData>({
    ticketStatusDistribution: null,
    ticketSeverityOverview: null,
    ticketCategoryDistribution: null,
    ticketComplianceByModule:null,
  });
  const [cachedData, setCachedData] = useState<ChartData>({
    ticketStatusDistribution: null,
    ticketSeverityOverview: null,
    ticketCategoryDistribution: null,
    ticketComplianceByModule:null,
  });
  const [loadingTicketStatus, setLoadingTicketStatus] = useState<boolean>(true);
  const [loadingTicketSeverity, setLoadingTicketSeverity] = useState<boolean>(true);
  const [loadingTicketCategory, setLoadingTicketCategory] = useState<boolean>(true);
  const [useCache, setUseCache] = useState<boolean>(false);
  const [internalFilterTicketStatus, setInternalFilterTicketStatus] = useState<string>("1_month");
  const [internalFilterTicketSeverity, setInternalFilterTicketSeverity] = useState<string>("1_month");
  const [internalFilterTicketCategory, setInternalFilterTicketCategory] = useState<string>("1_month");
  const [isSmallMediumScreen, setIsSmallMediumScreen] = useState<boolean>(false);
  const [features, setFeatures] = useState<any[]>([]);
  const [flippedChart, setFlippedChart] = useState<number | null>(null);
  const [showTicketStatusTooltip, setShowTicketStatusTooltip] = useState(false);
const [showTicketSeverityTooltip, setShowTicketSeverityTooltip] = useState(false);
const [ticketComplianceData, setTicketComplianceData] = useState<any>(null);
const [loadingTicketCompliance, setLoadingTicketCompliance] = useState<boolean>(true);
const [internalFilterTicketCompliance, setInternalFilterTicketCompliance] = useState<string>("1_month");
const [selectedComplianceModule, setSelectedComplianceModule] = useState("");
const [svgWidth, setSvgWidth] = useState(800);
const wrapperRef = useRef<HTMLDivElement>(null);

useEffect(() => {
  const update = () => {
    if (wrapperRef.current) {
      setSvgWidth(wrapperRef.current.offsetWidth);
    }
  };
  update();
  window.addEventListener("resize", update);
  return () => window.removeEventListener("resize", update);
}, []);
// Add this useEffect to set default module when modules are loaded
useEffect(() => {
  if (ticketComplianceData && !selectedComplianceModule) {
    const { modules } = processComplianceData(ticketComplianceData, internalFilterTicketCompliance, selectedTenantId, "");
    if (modules.length > 0) {
      setSelectedComplianceModule(modules[0]);
    }
  }
}, [ticketComplianceData, selectedTenantId, internalFilterTicketCompliance]);


  // NEW: Function to map global date filters to internal filters (matching SimsOverview)
const mapGlobalDateToInternalFilter = (globalFilter: string): string => {
  switch (globalFilter) {
    case "Today":
      return "1_day";
    case "Current Week":
      return "5_day";
    case "Current Month":
      return "1_month";
    default:
      console.warn(`Unknown global filter: ${globalFilter}, defaulting to 1_month`);
      return "1_month";
  }
};


    // Sync internal filters with global filter selection
  useEffect(() => {
  
    if (selectedButton) {
      const internalFilter = mapGlobalDateToInternalFilter(selectedButton);
 
      setInternalFilterTicketStatus(internalFilter);
      setInternalFilterTicketSeverity(internalFilter);
      setInternalFilterTicketCategory(internalFilter);
      setInternalFilterTicketCompliance(internalFilter);
      setUseCache(false);
      
      fetchChartData(startDate, endDate, false);
    } else if (startDate && endDate) {
      setUseCache(false);
      fetchChartData(startDate, endDate, false);
    }
  }, [selectedButton, startDate, endDate]);
  

  useEffect(() => {
    const handleResize = () => {
      setIsSmallMediumScreen(window.innerWidth <= 1000);
    };
    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);


// **KEY FIX: Function to dynamically determine the correct filter from available data**
  const getActualFilterFromData = (data: any, internalFilter: string): string => {

  // ALWAYS return the requested internal filter for UI consistency
  // This ensures the filter buttons show the correct active state
  // regardless of data availability
  return internalFilter;
};
  const fetchFilterOptions = async () => {
    try {
      const url = ENV_ROUTES.DASHBOARD;
      const data = {
        tenant_name: partner || "default_value",
        username,
        firstLastName,
        path: "/get_organization_dropdown_data",
        role_name: role,
        parent_module: "Zendesk Tracking",
        module_name: "Dashboard",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (!parsedData.flag || !parsedData.data) {
        setFilterOptions({ options: [{ value: "All Tenants", label: "All Tenants", tenant_id: "All" }] });
        setSelectedFilter("All Tenants");
        setSelectedTenantId("All");
        return;
      }

      const serviceProviders: FilterOption[] = [
        { value: "All Tenants", label: "All Tenants", tenant_id: "All" },
        ...Object.entries(parsedData.data)
          .filter(([key]) => key !== "All Tenants")
          .map(([key, value]) => ({
            value: key.trim(),
            label: key.trim(),
            tenant_id: String(value),
          }))
          .sort((a, b) => a.label.localeCompare(b.label)),
      ];

      setFilterOptions({ options: serviceProviders });

      const partnerOption = serviceProviders.find((option) => option.value === partner);
      if (partnerOption) {
        setSelectedFilter(partnerOption.value);
        setSelectedTenantId(partnerOption.tenant_id);
      } else {
        setSelectedFilter("All Tenants");
        setSelectedTenantId("All");
      }
    } catch (error) {
      console.error("Error fetching filter options:", error);
      setFilterOptions({ options: [{ value: "All Tenants", label: "All Tenants", tenant_id: "All" }] });
      setSelectedFilter("All Tenants");
      setSelectedTenantId("All");
    }
  };

// 6. UPDATE YOUR fetchChartData FUNCTION - REPLACE THE EXISTING ONE

const fetchChartData = async (startDate: string, endDate: string, cacheData: boolean = false) => {

  if (!selectedTenantId) {
    console.warn("No tenant_id set, skipping chart data fetch");
    return;
  }

  const url = ENV_ROUTES.DASHBOARD;
  const serviceProvidersFilter = selectedFilter === "All Tenants" ? "All" : selectedFilter;

  const baseRequestData = {
    partner,
    tenant_name: partner || "default_value",
    username,
    role_name: role,
    request_received_at: getCurrentDateTime(),
    access_token: token,
    db_name: selectedDb,
    ...metaData,
    sessionID: sessionId,
    start_date: startDate,
    end_date: endDate,
    tenant_id: selectedTenantId,
    service_providers: serviceProvidersFilter,
  };

  const fetchDataForPath = async (path: string) => {
    try {
      const response = await axios.post(url, {
        data: { ...baseRequestData, path },
      });
      const parsedResponse = JSON.parse(response.data.body);
      console.log(`Data for ${path}:`, parsedResponse);
      return parsedResponse;
    } catch (error) {
      console.error(`Error fetching data for ${path}:`, error);
      return null;
    }
  };

  try {
    console.log("Making API calls...");
    setLoadingTicketStatus(true);
    setLoadingTicketSeverity(true);
    setLoadingTicketCategory(true);
    setLoadingTicketCompliance(true);

    const [ticketStatusDistribution, ticketSeverityOverview, ticketCategoryDistribution, ticketComplianceByModule] = await Promise.all([
      fetchDataForPath("/get_ticket_status_distribution"),
      fetchDataForPath("/get_ticket_severity_overview"),
      fetchDataForPath("/get_ticket_category_distribution"),
      fetchDataForPath("/get_ticket_compilance_by_module"),
    ]);

    const newChartData = {
      ticketStatusDistribution: ticketStatusDistribution?.flag ? ticketStatusDistribution : null,
      ticketSeverityOverview: ticketSeverityOverview?.flag ? ticketSeverityOverview : null,
      ticketCategoryDistribution: ticketCategoryDistribution?.flag ? ticketCategoryDistribution : null,
      ticketComplianceByModule: ticketComplianceByModule?.flag ? ticketComplianceByModule : null,
    };

    // Set compliance data separately
    setTicketComplianceData(ticketComplianceByModule?.flag ? ticketComplianceByModule : null);

    if (cacheData) {
      setCachedData(newChartData);
      localStorage.setItem("zendesk_status_cache", JSON.stringify({
        ...newChartData.ticketStatusDistribution,
        lastUpdated: new Date().toISOString()
      }));
      localStorage.setItem("zendesk_severity_cache", JSON.stringify({
        ...newChartData.ticketSeverityOverview,
        lastUpdated: new Date().toISOString()
      }));
      localStorage.setItem("zendesk_category_cache", JSON.stringify({
        ...newChartData.ticketCategoryDistribution,
        lastUpdated: new Date().toISOString()
      }));
      localStorage.setItem("zendesk_compliance_cache", JSON.stringify({
        ...ticketComplianceByModule,
        lastUpdated: new Date().toISOString()
      }));
      setChartData(newChartData);
    } else {
      setChartData(newChartData);
    }
  } catch (error) {
    console.error("Error fetching chart data:", error);
  } finally {
    setLoadingTicketStatus(false);
    setLoadingTicketSeverity(false);
    setLoadingTicketCategory(false);
    setLoadingTicketCompliance(false);
  }
};

 // 4. UPDATE YOUR checkCacheValidity FUNCTION TO INCLUDE COMPLIANCE CACHE

const checkCacheValidity = () => {
  const caches = ["zendesk_status_cache", "zendesk_severity_cache", "zendesk_category_cache", "zendesk_compliance_cache"];
  return caches.every(cacheKey => {
    const cached = localStorage.getItem(cacheKey);
    if (!cached) return false;
    const { lastUpdated } = JSON.parse(cached);
    const lastUpdatedDate = new Date(lastUpdated);
    const now = new Date();
    const hoursDiff = (now.getTime() - lastUpdatedDate.getTime()) / (1000 * 60 * 60);
    return hoursDiff < 24;
  });
};


// 5. UPDATE YOUR initializeDashboard FUNCTION TO INCLUDE COMPLIANCE CACHE

const initializeDashboard = async () => {
  setSelectedPartner(true);
  setSelectedButton("Current Month");
  setDateRange([null, null]);
  setLoading(true);
  try {
    await fetchFilterOptions();
    if (selectedTenantId) {
      const isCacheValid = checkCacheValidity();
      // if (isCacheValid) {
      //   const statusCache = JSON.parse(localStorage.getItem("zendesk_status_cache") || "{}");
      //   const severityCache = JSON.parse(localStorage.getItem("zendesk_severity_cache") || "{}");
      //   const categoryCache = JSON.parse(localStorage.getItem("zendesk_category_cache") || "{}");
      //   const complianceCache = JSON.parse(localStorage.getItem("zendesk_compliance_cache") || "{}");
        
      //   setCachedData({
      //     ticketStatusDistribution: statusCache,
      //     ticketSeverityOverview: severityCache,
      //     ticketCategoryDistribution: categoryCache,
      //     ticketComplianceByModule: complianceCache,
      //   });
      //   setChartData({
      //     ticketStatusDistribution: statusCache,
      //     ticketSeverityOverview: severityCache,
      //     ticketCategoryDistribution: categoryCache,
      //     ticketComplianceByModule: complianceCache,
      //   });
        
      //   // SET COMPLIANCE DATA SEPARATELY
      //   setTicketComplianceData(complianceCache);
      //   setUseCache(true);
      // } else {
        await fetchChartData("", "", true);
      // }
    }
  } catch (error) {
    console.error("Error during initialization:", error);
  } finally {
    setLoading(false);
  }
};


  useEffect(() => {
    initializeDashboard();
  }, [partner]);

  useEffect(() => {
    if (selectedTenantId && !useCache) {
      localStorage.removeItem("zendesk_status_cache");
      localStorage.removeItem("zendesk_severity_cache");
      localStorage.removeItem("zendesk_category_cache");
      localStorage.removeItem("zendesk_compliance_cache");
      fetchChartData("", "", true);
    }
  }, [selectedTenantId]);

  const handleFilterChange = async (value: string) => {
   

    const selectedOption = filterOptions.options.find((option) => option.value === value);
    console.log("📋 Selected option:", selectedOption);

    if (selectedOption) {
      setSelectedFilter(selectedOption.value);
      setSelectedTenantId(selectedOption.tenant_id);
      setInternalFilterTicketStatus("1_month");
      setInternalFilterTicketSeverity("1_month");
      setInternalFilterTicketCategory("1_month");
      setStartDate("");
      setEndDate("");
      setDateRange([null, null]);
      setSelectedButton("Current Month");
      setUseCache(false);

      localStorage.removeItem("zendesk_status_cache");
      localStorage.removeItem("zendesk_severity_cache");
      localStorage.removeItem("zendesk_category_cache");
      localStorage.removeItem("zendesk_compliance_cache");

      const defaultStart = (moment().startOf("month").format("YYYY-MM-DD"));
      const defaultEnd = (moment().format("YYYY-MM-DD"));
      setStartDate(defaultStart);
      setEndDate(defaultEnd);
    } else {
      console.error("❌ Selected option not found for value:", value);
    }
  };

 const handleButtonClick = (range: "Today" | "Current Week" | "Current Month") => {
    setSelectedButton(range);
    let newStartDate: string;
    let newEndDate: string;

    if (range === "Today") {
      newStartDate = moment().format("YYYY-MM-DD");
      newEndDate = moment().format("YYYY-MM-DD");
    } else if (range === "Current Week") {
      newStartDate = moment().startOf("week").format("YYYY-MM-DD");
      newEndDate = moment().endOf("week").format("YYYY-MM-DD");
    } else {
      newStartDate = moment().subtract(30, "days").format("YYYY-MM-DD");
      newEndDate = moment().format("YYYY-MM-DD");
    }

    setStartDate(newStartDate);
    setEndDate(newEndDate);
    setDateRange([dayjs(newStartDate), dayjs(newEndDate)]);

  // ⭐ RESET ALL INTERNAL FILTERS BACK TO "1M" ⭐
  setInternalFilterTicketStatus("1_month");
  setInternalFilterTicketSeverity("1_month");
  setInternalFilterTicketCategory("1_month");
  setInternalFilterTicketCompliance("1_month");

    setUseCache(false);
    fetchChartData(newStartDate, newEndDate, false);
  };



// const detectClosestFilter = (startDate: string, endDate: string): string => {
//   const start = moment(startDate);
//   const end = moment(endDate);
//   const oneYearBack = moment().subtract(1, "year");

//     // If selected range goes beyond 1 year back → force 5_years
//     if (start.isBefore(oneYearBack, "day") || end.isBefore(oneYearBack, "day")) {
//       return "5_years";
//     }

//   if (start.isSame(end, "day")) return "1_day";

//   const diffDays = end.diff(start, "days");

//   if (diffDays <= 4) return "5_day";
//   if (diffDays <= 31) return "1_month";    // 👈 NEW LOGIC HERE
//   if (diffDays <= 90) return "3_month";
//   if (diffDays <= 180) return "6_month";
//   if (diffDays <= 365) return "1_year";

//   const diffYears = end.diff(start, "years", true);
//   if (diffYears < 5) return "5_years";

//   return "max";
// };



//   const handleDateRangeChange = (
//     dates: [Dayjs | null, Dayjs | null] | null,
//     dateStrings: [string, string]
//   ) => {
//     let applied_filter
//     setSelectedButton(null);
//     if (dates && dates[0] && dates[1]) {
//       setDateRange([dates[0], dates[1]]);
//       const newStartDate = dates[0].format("YYYY-MM-DD");
//       const newEndDate = dates[1].format("YYYY-MM-DD");
//       setStartDate(newStartDate);
//       setEndDate(newEndDate);
//       setUseCache(false);
//       fetchChartData(newStartDate, newEndDate, false);
//       applied_filter = detectClosestFilter(newStartDate,newEndDate)
//       console.clear()
//       console.error("applied_filter",applied_filter,newStartDate,newEndDate)
//     } else {
//       setDateRange([null, null]);
//       setSelectedButton("Current Month");
//       const newStartDate = moment().subtract(30, "days").format("YYYY-MM-DD");
//       const newEndDate = moment().format("YYYY-MM-DD");
//       setStartDate(newStartDate);
//       setEndDate(newEndDate);

//         // ⭐ RESET INTERNAL FILTERS ON DATE CHANGE ⭐
//   setInternalFilterTicketStatus("1_month");
//   setInternalFilterTicketSeverity("1_month");
//   setInternalFilterTicketCategory("1_month");
//   setInternalFilterTicketCompliance("1_month");
  
//       setUseCache(false);
//       fetchChartData(newStartDate, newEndDate, false);
//       applied_filter = detectClosestFilter(newStartDate,newEndDate)
      
//     }
//       setInternalFilterTicketStatus(applied_filter);
//       setInternalFilterTicketSeverity(applied_filter);
//       setInternalFilterTicketCategory(applied_filter);
//       setInternalFilterTicketCompliance(applied_filter);
//   };

const detectClosestFilter = (startDate: string, endDate: string): string => {
  const start = moment(startDate);
  const end = moment(endDate);
  const oneYearBack = moment().subtract(1, "year");

  // If selected range goes beyond 1 year back → force 5_years
  // if (start.isBefore(oneYearBack, "day") || end.isBefore(oneYearBack, "day")) {
  //   return "5_years";
  // }

  // Last day of current month
const rangeEnd = moment().endOf("month");

// First day of the month AFTER current month, one year ago
const rangeStart = moment()
  .add(1, "month")
  .subtract(1, "year")
  .startOf("month");

const withinYearRange = {
  start: rangeStart,
  end: rangeEnd,
};

console.log(
  "withinYearRange",
  rangeStart.format("YYYY-MM-DD"),
  "→",
  rangeEnd.format("YYYY-MM-DD")
);

// If selected range is completely outside past 12 months → force 5_years
if (end.isBefore(withinYearRange.start, "day")) {
  return "5_years";
}

  // Check if dates are the same day
  if (start.isSame(end, "day")) return "1_day";

  // Calculate the difference in days
  const diffDays = end.diff(start, "days");
  const diffMonths = end.diff(start, "months", true);
  const diffYears = end.diff(start, "years", true);

  // Map day differences to appropriate filters based on duration
  if (diffDays <= 4) return "5_day";
  if (diffDays <= 31) return "1_month";
  if (diffDays <= 92) return "3_month";   // ~3 months
  if (diffDays <= 183) return "6_month";  // ~6 months
  if (diffDays <= 366) return "1_year";   // ~1 year
  if (diffYears <= 5) return "5_years";

  return "max";
};

const handleDateRangeChange = (
  dates: [Dayjs | null, Dayjs | null] | null,
  dateStrings: [string, string]
) => {
  let applied_filter: string;
  setSelectedButton(null);
  
  if (dates && dates[0] && dates[1]) {
    setDateRange([dates[0], dates[1]]);
    const newStartDate = dates[0].format("YYYY-MM-DD");
    const newEndDate = dates[1].format("YYYY-MM-DD");
    
    // 1️⃣ FIRST: Detect the appropriate filter
    applied_filter = detectClosestFilter(newStartDate, newEndDate);
    
    console.log("📅 Date Range Selected:", { 
      start: newStartDate, 
      end: newEndDate, 
      filter: applied_filter,
      daysDiff: moment(newEndDate).diff(moment(newStartDate), "days")
    });
    
    // 2️⃣ SECOND: Set all internal filters to the detected filter
    setInternalFilterTicketStatus(applied_filter);
    setInternalFilterTicketSeverity(applied_filter);
    setInternalFilterTicketCategory(applied_filter);
    setInternalFilterTicketCompliance(applied_filter);
    
    // 3️⃣ THIRD: Update date state
    setStartDate(newStartDate);
    setEndDate(newEndDate);
    setUseCache(false);
    
    // 4️⃣ FOURTH: Fetch data with the new date range
    fetchChartData(newStartDate, newEndDate, false);
    
  } else {
    // Reset to default (Current Month)
    setDateRange([null, null]);
    setSelectedButton("Current Month");
    const newStartDate = moment().subtract(30, "days").format("YYYY-MM-DD");
    const newEndDate = moment().format("YYYY-MM-DD");
    
    // Detect filter for default range
    applied_filter = detectClosestFilter(newStartDate, newEndDate);
    
    console.log("🔄 Date Range Reset:", { 
      start: newStartDate, 
      end: newEndDate, 
      filter: applied_filter 
    });
    
    // Set all internal filters
    setInternalFilterTicketStatus(applied_filter);
    setInternalFilterTicketSeverity(applied_filter);
    setInternalFilterTicketCategory(applied_filter);
    setInternalFilterTicketCompliance(applied_filter);
    
    // Update date state
    setStartDate(newStartDate);
    setEndDate(newEndDate);
    setUseCache(false);
    
    // Fetch data
    fetchChartData(newStartDate, newEndDate, false);
  }
};
const chartMap: Record<string, keyof ChartData> = {
  ticketStatus: "ticketStatusDistribution",
  ticketSeverity: "ticketSeverityOverview",
  ticketCategory: "ticketCategoryDistribution",
  ticketCompliance: "ticketComplianceByModule",
};

const handleInternalFilterChange = (chart: string, filter: string) => {
  console.log(`Internal Filter Change → Chart: ${chart}, Filter: ${filter}`);

  // update filter state
  if (chart === "ticketStatus") setInternalFilterTicketStatus(filter);
  if (chart === "ticketSeverity") setInternalFilterTicketSeverity(filter);
  if (chart === "ticketCategory") setInternalFilterTicketCategory(filter);
  if (chart === "ticketCompliance") setInternalFilterTicketCompliance(filter);

  const keyToUpdate = chartMap[chart];
  if (!keyToUpdate) return;

  setChartData(prev => {
    const updated = { ...prev };

    // only update selected chart's data using cached data
    updated[keyToUpdate] = cachedData?.[keyToUpdate] || null;

    return updated;
  });

  if (keyToUpdate === "ticketComplianceByModule") {
    setTicketComplianceData(cachedData?.ticketComplianceByModule || null);
  }
};


  const formatDateForTooltip = (date: string): string => {
    if (!date) return "";
    return date.includes("T") ? date.split("T")[0] : date;
  };

  // Helper function to extract dynamic categories from data
  const extractCategoriesFromData = (data: any): string[] => {
    const categories = new Set<string>();

    if (!data?.data?.data) return [];

    // Check all time ranges for categories
    Object.values(data.data.data).forEach((timeRangeData: any) => {
      if (Array.isArray(timeRangeData)) {
        timeRangeData.forEach((orgData: any) => {
          orgData.records?.forEach((record: any) => {
            if (record.category_counts) {
              Object.keys(record.category_counts).forEach(category => {
                categories.add(category);
              });
            }
          });
        });
      }
    });

    return Array.from(categories).sort();
  };

  // Enhanced Time-based chart data processing function for ticket categories
  const processTimeBasedCategoryData = (
    data: any,
    filter: string,
    tenantId: string
  ): ProcessedTimeBasedData => {

    if (!data?.data?.data?.[filter]) {
      return { chartData: [], details: {}, categories: [] };
    }

    const rawData = data.data.data[filter];
    const organizationNames = data.meta?.organization_names || {};

    // Extract dynamic categories from the data
    const dynamicCategories = extractCategoriesFromData(data);

    let filteredData = rawData;

    if (tenantId !== "All") {
      filteredData = rawData.filter((item: any) => String(item.organization_id) === tenantId);
    }

    const processedData: { [timeLabel: string]: { [category: string]: number } } = {};

    filteredData?.forEach((orgData: any) => {
      orgData.records?.forEach((record: any) => {
        const categoryCounts = record.category_counts || {};
        const date = formatDateForTooltip(record.date || "");

        let timeLabel: string;
        const recordDate = new Date(date);
 const year = recordDate.getFullYear();
const month = String(recordDate.getMonth() + 1).padStart(2, "0");

        switch (filter) {
          case "1_day":
            timeLabel = recordDate.toLocaleTimeString('en-US', {
              hour: '2-digit',
              minute: '2-digit',
              hour12: false
            });
            break;

          case "5_day":
            timeLabel = recordDate.toLocaleDateString('en-US', {
              month: 'short',
              day: 'numeric'
            });
            break;         
        case "1_month":
          const monthStart = new Date(recordDate.getFullYear(), recordDate.getMonth(), 1);
          const weekNum = getWeekNumber(recordDate, monthStart);
          // ✅ Use actual month index (0-11), not adjusted
          timeLabel = `${year}-${month}-W${Math.min(weekNum, 4)}`;
          break;

        case "3_month":
        case "6_month":
        case "1_year":
          const monthStartDate = new Date(recordDate.getFullYear(), recordDate.getMonth(), 1);
          const week = getWeekNumber(recordDate, monthStartDate);
          // ✅ Use actual month index (0-11), not adjusted
          
           timeLabel = `${year}-${month}-W${Math.min(week, 4)}`;
          break;

          case "5_years":
          case "max":
            timeLabel = recordDate.getFullYear().toString();
            break;

          default:
            timeLabel = date;
        }

        if (!processedData[timeLabel]) {
          processedData[timeLabel] = {};
          dynamicCategories.forEach(category => {
            processedData[timeLabel][category] = 0;
          });
        }

        Object.entries(categoryCounts).forEach(([category, count]) => {
          if (dynamicCategories.includes(category)) {
            processedData[timeLabel][category] =
              (processedData[timeLabel][category] || 0) + (Number(count) || 0);
          }
        });
      });
    });

    // Sort time labels properly

const sortedTimeLabels = Object.keys(processedData).sort((a, b) => {
  if (filter === "1_day") {
    return a.localeCompare(b);
  }

  if (filter === "5_day") {
    return new Date(a).getTime() - new Date(b).getTime();
  }

  if (["1_month", "3_month", "6_month", "1_year"].includes(filter)) {
    // YYYY-MM-Wx
    const [ymA, wA] = a.split("-W");
    const [ymB, wB] = b.split("-W");

    const [yA, mA] = ymA.split("-").map(Number);
    const [yB, mB] = ymB.split("-").map(Number);

    if (yA !== yB) return yA - yB;
    if (mA !== mB) return mA - mB;
    return Number(wA) - Number(wB);
  }

  if (filter === "5_years" || filter === "max") {
    return parseInt(a) - parseInt(b);
  }

  return a.localeCompare(b);
});


    const chartData = sortedTimeLabels.map(timeLabel => ({
      time: timeLabel,
      ...processedData[timeLabel]
    }));

    return { chartData, details: processedData, categories: dynamicCategories };
  };

  // Updated Custom Tick Components matching SimsOverview
const CustomGroupedXAxisTick = (props: any): React.ReactElement<SVGElement> => {
  const { x, y, payload } = props;

  // Skip gap bars
  if (payload?.value?.startsWith("gap-")) {
    return <g></g>;
  }

  let label = payload?.value || "";

  // 🟢 If it's "MM-WN" → convert to "Wn"
  if (label.includes("-W")) {
    label = "W" + label.split("-W")[1];
  }

  // 🟢 If it is "YYYY" (5Y/Max mode), show as-is (no week)
  if (/^\d{4}$/.test(label)) {
    // Year-only
    return (
      <g transform={`translate(${x},${y})`}>
        <text x={0} y={16} textAnchor="middle" fill="#000" fontSize="12">
          {label}
        </text>
      </g>
    );
  }

  return (
    <g transform={`translate(${x},${y})`}>
      <text x={0} y={16} textAnchor="middle" fill="#000" fontSize="12">
        {label}
      </text>
    </g>
  );
};

// Add these properly typed functions after your existing helper functions

// Helper function for smart month positioning



// Smart Month Tick Component for Line Charts
// REPLACE your existing SmartMonthXAxisTick function

const SmartMonthXAxisTick = (chartData: any[], filter: string) => {
  const TickComponent = (props: any): React.ReactElement<SVGElement> => {
    const { x, y, payload } = props;

    if (!payload?.value || typeof payload.value !== 'string') return <g />;
    if (payload.value.startsWith('spacer-') || !payload.value.includes('-W')) return <g />;

    const currentMonth = payload.value.split('-W')[0];
    
    // Use the same logic as CenteredMonthXAxisTick
    const monthWeeks = chartData
      .filter((item: any) =>
        !item.isSpacer &&
        item.day &&
        typeof item.day === 'string' &&
        item.day.startsWith(`${currentMonth}-W`)
      )
      .sort((a: any, b: any) => {
        const weekA = parseInt(a.day.split('-W')[1]);
        const weekB = parseInt(b.day.split('-W')[1]);
        return weekA - weekB;
      });

    const weekCount = monthWeeks.length;
    if (weekCount === 0) return <g />;

    // Find current item index in chart data
    const currentIndex = chartData.findIndex(item => item.day === payload.value);
    if (currentIndex === -1) return <g />;

    // Find the start index of this month in the chart data
    const monthStartIndex = chartData.findIndex(item => 
      item.day && item.day.startsWith(`${currentMonth}-W`)
    );
    if (monthStartIndex === -1) return <g />;

    let shouldShowMonth = false;
    let xOffset = 0;

    if (weekCount === 1) {
      // Single week: show on that week
      shouldShowMonth = currentIndex === monthStartIndex;
    } else if (weekCount === 2) {
      // Two weeks: show on first week with offset
      shouldShowMonth = currentIndex === monthStartIndex;
      // For 3M filter, use offset 27, otherwise 15
      xOffset = filter === "3_month" ? 27 : 15;
    } else if (weekCount === 3) {
      // Three weeks: show on middle week (W2)
      shouldShowMonth = currentIndex === monthStartIndex + 1;
    } else if (weekCount === 4) {
      // Four weeks: show on second week with offset
      shouldShowMonth = currentIndex === monthStartIndex + 1;
      // For 3M filter, use offset 27, otherwise 15
      xOffset = filter === "3_month" ? 27 : 15;
    } else {
      // More than 4 weeks: show on middle week
      const middleIndex = monthStartIndex + Math.floor(weekCount / 2);
      shouldShowMonth = currentIndex === middleIndex;
    }

    if (!shouldShowMonth) return <g />;

    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const monthIndex = parseInt(currentMonth);
    const monthName = monthNames[monthIndex] || currentMonth;

    return (
      <g>
        <text
          x={x + xOffset}
          y={y + 5}
          textAnchor="middle"
          fontSize="10"
          fontWeight="normal"
          fill="#000"
        >
          {monthName}
        </text>
      </g>
    );
  };

  TickComponent.displayName = 'SmartMonthXAxisTick';
  return TickComponent;
};

// REPLACE your existing getSmartMonthPosition function

const getSmartMonthPosition = (
  chartData: any[],
  currentMonth: string,
  filter: string
): { shouldShow: boolean; targetDay: string; xOffset: number } => {
  const monthWeeks = chartData
    .filter((item: any) =>
      !item.isSpacer &&
      item.day &&
      typeof item.day === 'string' &&
      item.day.startsWith(`${currentMonth}-W`)
    )
    .sort((a: any, b: any) => {
      const weekA = parseInt(a.day.split('-W')[1]);
      const weekB = parseInt(b.day.split('-W')[1]);
      return weekA - weekB;
    });

  const totalWeeks = monthWeeks.length;

  if (totalWeeks === 0) return { shouldShow: false, targetDay: '', xOffset: 0 };

  let targetIndex: number;
  let xOffset = 0;

  if (totalWeeks === 1) {
    targetIndex = 0;
  } else if (totalWeeks === 2) {
    targetIndex = 0;
    // For 3M filter, use offset 27, otherwise 15
    xOffset = filter === "3_month" ? 27 : 15;
  } else if (totalWeeks === 3) {
    targetIndex = 1; // W2 (middle week)
  } else if (totalWeeks === 4) {
    targetIndex = 1; // W2 with offset
    // For 3M filter, use offset 27, otherwise 15
    xOffset = filter === "3_month" ? 27 : 15;
  } else {
    targetIndex = Math.floor(totalWeeks / 2);
  }

  const targetDay = monthWeeks[targetIndex]?.day ?? '';
  return { shouldShow: true, targetDay, xOffset };
};


  // Process Status Distribution Data (Updated)
const processStatusChartData = (
  data: any,
  filter: string,
  tenantId: string
): { chartData: any[]; details: any } => {
  if (!data?.data?.data?.[filter]) {
    return { chartData: [], details: {} };
  }

  const rawData = data.data.data[filter];
  const organizationNames = data.meta?.organization_names || {};

  let filteredData = rawData;
  if (tenantId !== "All") {
    filteredData = rawData.filter(
      (item: any) => String(item.organization_id) === tenantId
    );
  }

  const statusDetails: { [status: string]: { [date: string]: number } } = {};
  STATUS_CATEGORIES.forEach((s) => (statusDetails[s] = {}));

  let chartData: Array<{ day: string; dayName: string; [key: string]: any }> = [];

  if (filter === "1_day") {
    // FIXED: Process hourly data correctly
    const hourlyData: { [hour: string]: Record<string, number> } = {};
    
    // Initialize all 24 hours with 0 values
    for (let hour = 0; hour < 24; hour++) {
      const hourLabel = `${hour.toString().padStart(2, '0')}:00`;
      hourlyData[hourLabel] = { Open: 0, "To do": 0, Inprogress: 0, Closed: 0 };
    }

    // Process each organization's records
    filteredData.forEach((orgData: any) => {
      orgData.records?.forEach((record: any) => {
        const timestamp = record.date;
        const statusCounts = record.status_counts || {};
        
        // Extract hour from timestamp (e.g., "2025-09-08 15:59:59" -> "15:00")
        const recordDate = new Date(timestamp);
        const hour = recordDate.getHours();
        const hourLabel = `${hour.toString().padStart(2, '0')}:00`;
        
        // Add counts to the specific hour
        STATUS_CATEGORIES.forEach((status) => {
          const count = Number(statusCounts[status]) || 0;
          hourlyData[hourLabel][status] += count;
          
          // Update details for tooltip
          const dateKey = formatDateForTooltip(timestamp);
          statusDetails[status][dateKey] = (statusDetails[status][dateKey] || 0) + count;
        });
      });
    });

    // Convert hourly data to chart format
    chartData = Object.entries(hourlyData)
      .map(([hourLabel, counts]) => ({
        day: hourLabel,
        dayName: hourLabel,
        ...counts
      }))
      .filter(item => 
        // Only show hours that have data
       STATUS_CATEGORIES.some((status) => (item as Record<string, any>)[status] > 0)
      )
      .sort((a, b) => a.day.localeCompare(b.day));

  } else if (filter === "5_day") {
  // Show days of the week
  const dayGroups: {
    [dayName: string]: { rawDates: string[], counts: Record<string, number> }
  } = {
    'Mon': { rawDates: [], counts: { Open: 0, "To do": 0, Inprogress: 0, Closed: 0 } },
    'Tue': { rawDates: [], counts: { Open: 0, "To do": 0, Inprogress: 0, Closed: 0 } },
    'Wed': { rawDates: [], counts: { Open: 0, "To do": 0, Inprogress: 0, Closed: 0 } },
    'Thu': { rawDates: [], counts: { Open: 0, "To do": 0, Inprogress: 0, Closed: 0 } },
    'Fri': { rawDates: [], counts: { Open: 0, "To do": 0, Inprogress: 0, Closed: 0 } },
    'Sat': { rawDates: [], counts: { Open: 0, "To do": 0, Inprogress: 0, Closed: 0 } },
    'Sun': { rawDates: [], counts: { Open: 0, "To do": 0, Inprogress: 0, Closed: 0 } }
  };

  filteredData.forEach((orgData: any) => {
    orgData.records?.forEach((record: any) => {
      const rawDate = formatDateForTooltip(record.date); // yyy-mm-dd
      const statusCounts = record.status_counts || {};
      const dayName = moment(rawDate).format('ddd'); // Mon, Tue, ...

      if (dayGroups[dayName]) {
        dayGroups[dayName].rawDates.push(rawDate); // 🆕 store real date

        STATUS_CATEGORIES.forEach((status) => {
          const count = Number(statusCounts[status]) || 0;
          dayGroups[dayName].counts[status] += count;
          statusDetails[status][rawDate] = (statusDetails[status][rawDate] || 0) + count;
        });
      }
    });
  });

  // Convert to chart data
  chartData = Object.entries(dayGroups)
    .map(([dayName, obj]) => {
      const dayData: any = {
        day: dayName,           // still show Mon, Tue on axis
        dayName: dayName,
        rawDate: obj.rawDates[0] || null  // 🟢 store real date for tooltip
      };

      STATUS_CATEGORIES.forEach((status) => {
        dayData[status] = obj.counts[status];
      });

      return dayData;
    })
    .filter(item => STATUS_CATEGORIES.some((status) => item[status] > 0))
    .sort((a, b) => {
      const dayOrder = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
      return dayOrder.indexOf(a.day) - dayOrder.indexOf(b.day);
    });
}
 
  else if (["1_month", "3_month", "6_month", "1_year"].includes(filter)) {
  // Group weeks by months for proper spacing
  const dateData: { [date: string]: Record<string, number> } = {};

  // Process each organization's data
  filteredData.forEach((orgData: any) => {
    orgData.records?.forEach((record: any) => {
      const date = formatDateForTooltip(record.date);
      const statusCounts = record.status_counts || {};

      if (!dateData[date]) {
        dateData[date] = { Open: 0, "To do": 0, Inprogress: 0, Closed: 0 };
      }

      STATUS_CATEGORIES.forEach((status) => {
        const count = Number(statusCounts[status]) || 0;
        dateData[date][status] += count;
        statusDetails[status][date] = (statusDetails[status][date] || 0) + count;
      });
    });
  });

  const sortedDates = Object.keys(dateData).sort((a, b) => a.localeCompare(b));
  const monthlyGroupedWeeks: {
    [monthKey: string]: { label: string; data: Record<string, number> }[];
  } = {};
  const weeklyDetails: { [weekLabel: string]: { [date: string]: number } } = {};

  sortedDates.forEach((date) => {
    const recordDate = new Date(date);
    let weekLabel: string;
    let monthKey: string;

    if (filter === "1_month") {
      // For 1 month: show MM-W1, MM-W2, MM-W3, MM-W4
      const monthIndex = recordDate.getMonth();
      const monthStart = new Date(recordDate.getFullYear(), recordDate.getMonth(), 1);
      const week = getWeekNumber(recordDate, monthStart);
      const year = recordDate.getFullYear();
      weekLabel = `W${Math.min(week, 4)}`;
      monthKey = `${year}-${(monthIndex + 1).toString().padStart(2, "0")}`;
    } else {
      // For 3M, 6M, 1Y: group by actual month
      const monthIndex = recordDate.getMonth();
      const monthStart = new Date(recordDate.getFullYear(), recordDate.getMonth(), 1);
      const week = getWeekNumber(recordDate, monthStart);
      const year = recordDate.getFullYear();
      weekLabel = `W${Math.min(week, 4)}`;
      monthKey = `${year}-${(monthIndex + 1).toString().padStart(2, "0")}`;
    }

    if (!monthlyGroupedWeeks[monthKey]) {
      monthlyGroupedWeeks[monthKey] = [];
    }

    // Find existing week in this month or create new
    let weekEntry = monthlyGroupedWeeks[monthKey].find((w) => w.label === weekLabel);
    if (!weekEntry) {
      weekEntry = {
        label: weekLabel,
        data: { Open: 0, "To do": 0, Inprogress: 0, Closed: 0 },
      };
      monthlyGroupedWeeks[monthKey].push(weekEntry);
    }

    // Aggregate status data
    STATUS_CATEGORIES.forEach((status) => {
      weekEntry.data[status] += dateData[date][status];
    });

    // Store details
    const fullWeekLabel = `${monthKey}-${weekLabel}`;
    if (!weeklyDetails[fullWeekLabel]) {
      weeklyDetails[fullWeekLabel] = {};
    }
    const totalForDate = STATUS_CATEGORIES.reduce(
      (sum, status) => sum + dateData[date][status],
      0
    );
    weeklyDetails[fullWeekLabel][date] =
      (weeklyDetails[fullWeekLabel][date] || 0) + totalForDate;
  });

  // Build chart data with tight weeks + month spacing
  const chartDataWithSpacing: any[] = [];
  const sortedMonths = Object.keys(monthlyGroupedWeeks);

  // ✅ Apply different sort orders based on filter
  if (filter === "1_year") {
    // Reverse chronological sort (most recent month first)
    const now = new Date();
    const currentMonth = now.getMonth();

    sortedMonths.sort((a, b) => {
      const monthA = parseInt(a);
      const monthB = parseInt(b);
      const distanceA = (currentMonth - monthA + 12) % 12;
      const distanceB = (currentMonth - monthB + 12) % 12;
      return distanceB - distanceA;
    });
  } else {
    // Chronological sort for 1M, 3M, 6M
    sortedMonths.sort((a, b) => {
  const [yA, mA] = a.split("-").map(Number);
  const [yB, mB] = b.split("-").map(Number);

  if (yA !== yB) return yA - yB;
  return mA - mB;
});

  }

  // 🧩 Generate chart data
  sortedMonths.forEach((monthKey, monthIndex) => {
    const monthWeeks = monthlyGroupedWeeks[monthKey];

    // Sort weeks within each month (W1 → W4)
    monthWeeks.sort((a, b) => {
      const aNum = parseInt(a.label.replace("W", ""));
      const bNum = parseInt(b.label.replace("W", ""));
      return aNum - bNum;
    });

    // Add weekly data
   // Add weekly data
      monthWeeks.forEach((weekEntry) => {
        const fullWeekLabel =`${monthKey}-${weekEntry.label}`;

        // 🟢 Pick the first real date for this week (used in tooltip)
       const rawWeekDate = sortedDates.find(d => {
          const recordDate = new Date(d);
          const y = recordDate.getFullYear();
const m = (recordDate.getMonth() + 1).toString().padStart(2,"0");


          const monthStart = new Date(recordDate.getFullYear(), recordDate.getMonth(), 1);
          const wk = `W${Math.min(getWeekNumber(recordDate, monthStart),4)}`;
          const checkLabel = `${y}-${m}-${wk}`;
          return checkLabel === fullWeekLabel;
        }) || null;

        const weekData: any = {
          day: fullWeekLabel,
          dayName: fullWeekLabel,
          monthKey: monthKey,
          rawDate: rawWeekDate // 🟢 REAL DATE FIX
        };

        STATUS_CATEGORIES.forEach((status) => {
          weekData[status] = weekEntry.data[status];
        });

        chartDataWithSpacing.push(weekData);
      });


    // Add spacing BETWEEN months (not after last)
    if (monthIndex < sortedMonths.length - 1) {
      for (let i = 0; i < 3; i++) {
        chartDataWithSpacing.push({
          day: `spacer-${monthKey}-${i}`,
          dayName: `spacer-${monthKey}-${i}`,
          isSpacer: true,
          Open: null,
          "To do": null,
          Inprogress: null,
          Closed: null,
        });
      }
    }
  });

  chartData = chartDataWithSpacing;
  Object.assign(statusDetails, weeklyDetails);
  }else if (filter === "5_years" || filter === "max") {
    // Group by years
    const dateData: { [date: string]: Record<string, number> } = {};

    // Process each organization's data
    filteredData.forEach((orgData: any) => {
      orgData.records?.forEach((record: any) => {
        const date = formatDateForTooltip(record.date);
        const statusCounts = record.status_counts || {};

        if (!dateData[date]) {
          dateData[date] = { Open: 0, "To do": 0, Inprogress: 0, Closed: 0 };
        }

        STATUS_CATEGORIES.forEach((status) => {
          const count = Number(statusCounts[status]) || 0;
          dateData[date][status] += count;
          statusDetails[status][date] = (statusDetails[status][date] || 0) + count;
        });
      });
    });

    const sortedDates = Object.keys(dateData).sort((a, b) => a.localeCompare(b));
    const yearGroups: { [year: string]: Record<string, number> } = {};

    sortedDates.forEach(date => {
      const year = moment(date).format('YYYY');
      if (!yearGroups[year]) {
        yearGroups[year] = { Open: 0, "To do": 0, Inprogress: 0, Closed: 0 };
      }

      STATUS_CATEGORIES.forEach((status) => {
        yearGroups[year][status] += dateData[date][status];
      });
    });

    chartData = Object.entries(yearGroups)
      .sort(([a], [b]) => parseInt(a) - parseInt(b))
      .map(([year, counts]) => {
        const yearData: any = { day: year, dayName: year };
        STATUS_CATEGORIES.forEach((status) => {
          yearData[status] = counts[status];
        });
        return yearData;
      });
  }

  return { chartData, details: statusDetails };
};

  // Updated processSeverityChartData with tight week spacing
const processSeverityChartData = (data: any, filter: string, tenantId: string): ProcessedLineChartData => {

  if (!data?.data?.data?.[filter]) {
    console.error("❌ Invalid chart data structure");
    return { chartData: [], details: {} };
  }

  const rawData = data.data.data[filter];
  let filteredData = rawData;

  if (tenantId !== "All") {
    filteredData = rawData.filter((item: any) => String(item.organization_id) === tenantId);
  }

  const dayDetails: { [key: string]: { [date: string]: number } } = {};
  let chartData: Array<{ day: string; dayName: string;[key: string]: any }> = [];

  if (filter === "1_day") {
    // FIXED: Process hourly data correctly
    const hourlyData: { [hour: string]: Record<SeverityType, number> } = {};
    
    // Initialize all 24 hours with 0 values
    for (let hour = 0; hour < 24; hour++) {
      const hourLabel = `${hour.toString().padStart(2, '0')}:00`;
      hourlyData[hourLabel] = { High: 0 , Medium: 0, Low: 0};
    }

    // Process each organization's records
    filteredData.forEach((orgData: any) => {
      orgData.records?.forEach((record: any) => {
        const timestamp = record.date;
        const severityCounts = record.severity_counts || {};
        
        // Extract hour from timestamp
        const recordDate = new Date(timestamp);
        const hour = recordDate.getHours();
        const hourLabel = `${hour.toString().padStart(2, '0')}:00`;
        
        // Add counts to the specific hour
        SEVERITY_CATEGORIES.forEach((severity: SeverityType) => {
          const count = Number(severityCounts[severity]) || 0;
          hourlyData[hourLabel][severity] += count;
        });

        // Update details for tooltip
        const dateKey = formatDateForTooltip(timestamp);
        const totalForDate = SEVERITY_CATEGORIES.reduce((sum, severity: SeverityType) =>
          sum + (Number(severityCounts[severity]) || 0), 0);
        dayDetails[dateKey] = { [dateKey]: totalForDate };
      });
    });

    // Convert hourly data to chart format
    chartData = Object.entries(hourlyData)
      .map(([hourLabel, counts]) => ({
        day: hourLabel,
        dayName: hourLabel,
        ...counts
      }))
      .filter(item => 
        // Only show hours that have data
        SEVERITY_CATEGORIES.some((severity: SeverityType) => item[severity] > 0)
      )
      .sort((a, b) => a.day.localeCompare(b.day));

  } else if (filter === "5_day") {
    const dayGroups: {
      [dayName: string]: { rawDates: string[], counts: Record<SeverityType, number> }
    } = {
      'Mon': { rawDates: [], counts: { High: 0, Medium: 0, Low: 0 } },
      'Tue': { rawDates: [], counts: { High: 0, Medium: 0, Low: 0 } },
      'Wed': { rawDates: [], counts: { High: 0, Medium: 0, Low: 0 } },
      'Thu': { rawDates: [], counts: { High: 0, Medium: 0, Low: 0 } },
      'Fri': { rawDates: [], counts: { High: 0, Medium: 0, Low: 0 } },
      'Sat': { rawDates: [], counts: { High: 0, Medium: 0, Low: 0 } },
      'Sun': { rawDates: [], counts: { High: 0, Medium: 0, Low: 0 } }
    };

    filteredData.forEach((orgData: any) => {
      orgData.records?.forEach((record: any) => {
        const date = formatDateForTooltip(record.date); // yyyy-mm-dd
        const severityCounts = record.severity_counts || {};
        const dayName = moment(date).format('ddd'); // Mon, Tue, ...
        
        if (dayGroups[dayName]) {
          dayGroups[dayName].rawDates.push(date); // 🆕 store real date
          
          SEVERITY_CATEGORIES.forEach((severity: SeverityType) => {
            const count = Number(severityCounts[severity]) || 0;
            dayGroups[dayName].counts[severity] += count;
          });
        }

        const totalForDate = SEVERITY_CATEGORIES.reduce((sum, severity: SeverityType) =>
          sum + (Number(severityCounts[severity]) || 0), 0);
        dayDetails[date] = { [date]: totalForDate };
      });
    });

    chartData = Object.entries(dayGroups)
      .map(([dayName, obj]) => {
        const dayData: any = {
          day: dayName,           // still show Mon, Tue on axis
          dayName: dayName,
          rawDate: obj.rawDates[0] || null  // 🟢 store real date for tooltip
        };

        SEVERITY_CATEGORIES.forEach((severity: SeverityType) => {
          dayData[severity] = obj.counts[severity];
        });

        return dayData;
      })
      .filter(item => SEVERITY_CATEGORIES.some((severity: SeverityType) => item[severity] > 0))
      .sort((a, b) => {
        const dayOrder = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
        return dayOrder.indexOf(a.day) - dayOrder.indexOf(b.day);
      });
    }
  else if (["1_month", "3_month", "6_month", "1_year"].includes(filter)) {
  const dateData: { [date: string]: Record<SeverityType, number> } = {};

  // Step 1: Aggregate daily data by severity
  filteredData.forEach((orgData: any) => {
    orgData.records?.forEach((record: any) => {
      const date = formatDateForTooltip(record.date);
      const severityCounts = record.severity_counts || {};

      if (!dateData[date]) {
        dateData[date] = { High: 0 ,Medium: 0,Low: 0 };
      }

      SEVERITY_CATEGORIES.forEach((severity: SeverityType) => {
        dateData[date][severity] += Number(severityCounts[severity]) || 0;
      });

      const totalForDate = SEVERITY_CATEGORIES.reduce(
        (sum, severity: SeverityType) =>
          sum + (Number(severityCounts[severity]) || 0),
        0
      );

      dayDetails[date] = { [date]: totalForDate };
    });
  });

  // Step 2: Group by month and week
  const sortedDates = Object.keys(dateData).sort((a, b) => a.localeCompare(b));
  const groupedWeeks: {
    [monthKey: string]: { label: string; data: Record<SeverityType, number> }[];
  } = {};
  const weeklyDetails: { [weekLabel: string]: { [date: string]: number } } = {};

  sortedDates.forEach((date) => {
    const recordDate = new Date(date);
    let weekLabel: string;
    let monthKey: string;

    if (filter === "1_month") {
    // Single month view - use actual month index
    // const monthIndex = recordDate.getMonth();
    const monthStart = new Date(recordDate.getFullYear(), recordDate.getMonth(), 1);
    const week = getWeekNumber(recordDate, monthStart);
    const year = recordDate.getFullYear();
const monthIndex = recordDate.getMonth();
    weekLabel = `W${Math.min(week, 4)}`;
    // monthKey = monthIndex.toString().padStart(2, "0"); // Use actual month
    monthKey = `${year}-${monthIndex.toString().padStart(2, "0")}`;
     }else {
      // 3M, 6M, 1Y views
      // const monthIndex = recordDate.getMonth();
      const monthStart = new Date(recordDate.getFullYear(), recordDate.getMonth(), 1);
      const week = getWeekNumber(recordDate, monthStart);
      const year = recordDate.getFullYear();
const monthIndex = recordDate.getMonth();
      weekLabel = `W${Math.min(week, 4)}`;
      // monthKey = monthIndex.toString().padStart(2, "0");
      monthKey = `${year}-${monthIndex.toString().padStart(2, "0")}`;
    }

    if (!groupedWeeks[monthKey]) groupedWeeks[monthKey] = [];

    let weekEntry = groupedWeeks[monthKey].find((w) => w.label === weekLabel);
    if (!weekEntry) {
      weekEntry = { label: weekLabel, data: { High: 0, Medium: 0, Low: 0} };
      groupedWeeks[monthKey].push(weekEntry);
    }

    SEVERITY_CATEGORIES.forEach((severity: SeverityType) => {
      weekEntry.data[severity] += dateData[date][severity];
    });

    const fullWeekLabel =`${monthKey}-${weekLabel}`;
    if (!weeklyDetails[fullWeekLabel]) {
      weeklyDetails[fullWeekLabel] = {};
    }

    const totalForDate = SEVERITY_CATEGORIES.reduce(
      (sum, severity: SeverityType) => sum + dateData[date][severity],
      0
    );
    weeklyDetails[fullWeekLabel][date] =
      (weeklyDetails[fullWeekLabel][date] || 0) + totalForDate;
  });

  // Step 3: Sort months
  const monthKeys = Object.keys(groupedWeeks);
  if (filter === "1_year") {
    // Reverse chronological (most recent first)
    const now = new Date();
    const currentMonth = now.getMonth();
    monthKeys.sort((a, b) => {
      const monthA = parseInt(a);
      const monthB = parseInt(b);
      const distanceA = (currentMonth - monthA + 12) % 12;
      const distanceB = (currentMonth - monthB + 12) % 12;
      return distanceB - distanceA;
    });
  } else {
    // Normal chronological order
    monthKeys.sort((a, b) => parseInt(a) - parseInt(b));
  }

  // Step 4: Build chart data with spacing between months
  const chartDataWithSpacing: any[] = [];

  monthKeys.forEach((monthKey, monthIndex) => {
    const monthWeeks = groupedWeeks[monthKey];

    // Sort by week order (W1–W4)
    monthWeeks.sort((a, b) => {
      const aNum = parseInt(a.label.replace("W", ""));
      const bNum = parseInt(b.label.replace("W", ""));
      return aNum - bNum;
    });

    // Add each week's data
    monthWeeks.forEach((weekEntry) => {
      const fullWeekLabel = `${monthKey}-${weekEntry.label}`;
      const weekData: any = {
        day: fullWeekLabel,
        dayName: fullWeekLabel,
        monthKey: monthKey,
      };

      SEVERITY_CATEGORIES.forEach((severity: SeverityType) => {
        weekData[severity] = weekEntry.data[severity];
      });

      chartDataWithSpacing.push(weekData);
    });

    // Add spacing between months (not after last one)
    if (monthIndex < monthKeys.length - 1) {
      for (let i = 0; i < 2; i++) {
        chartDataWithSpacing.push({
          day: `spacer-${monthKey}-${i}`,
          dayName: `spacer-${monthKey}-${i}`,
          isSpacer: true,
          High: null,
          Medium: null,
          Low: null,
        });
      }
    }
  });

  chartData = chartDataWithSpacing;
  Object.assign(dayDetails, weeklyDetails);
}
else if (filter === "5_years" || filter === "max") {
    const dateData: { [date: string]: Record<SeverityType, number> } = {};

    filteredData.forEach((orgData: any) => {
      orgData.records?.forEach((record: any) => {
        const date = formatDateForTooltip(record.date);
        const severityCounts = record.severity_counts || {};

        if (!dateData[date]) {
          dateData[date] = { High: 0,Medium: 0,Low: 0 };
        }

        SEVERITY_CATEGORIES.forEach((severity: SeverityType) => {
          dateData[date][severity] += Number(severityCounts[severity]) || 0;
        });

        const totalForDate = SEVERITY_CATEGORIES.reduce((sum, severity: SeverityType) =>
          sum + (Number(severityCounts[severity]) || 0), 0);

        dayDetails[date] = { [date]: totalForDate };
      });
    });

    const sortedDates = Object.keys(dateData).sort((a, b) => a.localeCompare(b));
    const yearGroups: { [year: string]: Record<SeverityType, number> } = {};

    sortedDates.forEach(date => {
      const year = moment(date).format('YYYY');
      if (!yearGroups[year]) {
        yearGroups[year] = {  High: 0 , Medium: 0,Low: 0};
      }

      SEVERITY_CATEGORIES.forEach((severity: SeverityType) => {
        yearGroups[year][severity] += dateData[date][severity];
      });
    });

    chartData = Object.entries(yearGroups)
      .sort(([a], [b]) => parseInt(a) - parseInt(b))
      .map(([year, counts]) => {
        const yearData: any = { day: year, dayName: year };
        SEVERITY_CATEGORIES.forEach((severity: SeverityType) => {
          yearData[severity] = counts[severity];
        });
        return yearData;
      });
  }

  return { chartData, details: dayDetails };
};
  // Updated renderTimeBasedCategoryChart matching SimsOverview
const renderTimeBasedCategoryChart = () => {
  const cardHeight = 280;
  const dataSource = useCache ? cachedData : chartData;
  const filter =
    startDate && endDate && !useCache
      ? getActualFilterFromData(dataSource.ticketCategoryDistribution, internalFilterTicketCategory)
      : internalFilterTicketCategory;

  // 👉 Get processed stacked data
  const { chartData: timeBasedData, categories }: { chartData: any[]; categories: string[] } =
    dataSource.ticketCategoryDistribution
      ? processTimeBasedCategoryData(
          dataSource.ticketCategoryDistribution,
          filter,
          selectedTenantId
        )
      : { chartData: [], categories: [] };
  const isDualAxis = ["1_month", "3_month", "6_month", "1_year"].includes(filter);
const buildMonthGaps = (data: any[]) => {
  if (!isDualAxis || data.length === 0) return { processed: data, monthPos: [] };


  const groups: Record<string, any[]> = {};

  data.forEach((r) => {
    if (!r.time || !r.time.includes("-W")) return;
    // group by YYYY-MM
const ym = r.time.split("-W")[0]; // "2025-12"
if (!groups[ym]) groups[ym] = [];
groups[ym].push(r);

  });
const sortedMonths = Object.keys(groups).sort((a, b) => {
  const [ya, ma] = a.split("-").map(Number);
  const [yb, mb] = b.split("-").map(Number);

  if (ya !== yb) return ya - yb;
  return ma - mb;
});

  const processed: any[] = [];
  const monthPos: any[] = [];

  sortedMonths.forEach((m, i) => {
    const w = groups[m];
    if (!w || w.length === 0) {
      console.log(`⚠️ Month ${m} has no data!`);
      return;
    }
    w.sort((a, b) => {
      const wa = parseInt(a.time.split("-W")[1] || "0");
      const wb = parseInt(b.time.split("-W")[1] || "0");
      return wa - wb;
    });

    const start = processed.length;
    processed.push(...w);
    const end = processed.length - 1;
    const mid = Math.floor((start + end) / 2);

    monthPos.push({ month: m, center: mid });

    if (i < sortedMonths.length - 1) {
      processed.push(
        ...[0, 1].map((gapIdx) => ({
          time: `gap-${m}-${gapIdx}`,
          isGap: true,
          ...categories.reduce((acc, c) => ({ ...acc, [c]: 0 }), {}),
        }))
      );
    }
  });

  return { processed, monthPos };
};

  const { processed: processedData, monthPos } = buildMonthGaps(timeBasedData);

  // 👉 Month rendering for dual axis
  const monthNames = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  return (
    <div className="w-full">
      <div className="bg-white p-4 rounded-lg shadow-md graph" style={{ height: 420 }}>
        <div className="bg-gray-100 flex justify-between items-center p-4 chart-title">
          <div className="flex items-center">
            <BarChart className="cursor-pointer mr-2" />
            <h2 className="font-semibold">Ticket Category Distribution</h2>
          </div>
        </div>

        {renderFilterButtons("ticketCategory")}
{processedData.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full w-full">
            <span style={{ fontSize: 16, color: "#aaa" }}>No Data Available</span>
          </div>
        ) : (
          <>
              <div style={{ height: cardHeight + 20, position: "relative", width: "100%" }}>
                <ResponsiveBar
                  data={processedData}
                  keys={categories}
                  labelSkipHeight={9999}
                  enableLabel={false}
                  borderRadius={0}
                  indexBy="time"
                  margin={{
                    top: 20,
                    right: 50,  // ✅ Increased from 15 to ensure bars aren't cut off
                    left: 50,
                    bottom: isDualAxis ? 75 : 55,
                  }}
                  padding={0.5}
                  groupMode="stacked"
                  enableGridY={true}
                  enableGridX={false}

                  colors={(d: { id: string | number }) => {
                    const name = String(d.id);
                    const i = categories.indexOf(name);
                    return BLUE_SHADE_COLORS[i >= 0 ? i % BLUE_SHADE_COLORS.length : 0];
                  }}

                  theme={{
                    grid: {
                      line: {
                        stroke: "#ccc",          // line color
                        strokeWidth: 1,
                        strokeDasharray: "2 2",  // ⭐ dotted line (3px dash, 3px gap)
                      }
                    },
                    axis: {
                      legend: {
                        text: {
                          fontFamily: "Calibri, sans-serif",
                          fontSize: 16,
                          fill: "currentColor",
                        },
                      },
                      ticks: {
                        text: {
                          fontFamily: "Calibri, sans-serif",
                          fontSize: 10,
                          fill: "currentColor",
                        },
                      },

                    },
                  }}
                  tooltip={(props: any) => {
                    const { index } = props;

                    // 1️⃣ Invalid or missing index
                    if (index == null || !processedData[index]) return null;

                    const row = processedData[index];

                    // 2️⃣ Skip gaps
                    if (row.isGap) return null;

                    // 3️⃣ Now safe to use row.time
                    let label = row.time;

                    if (row.time.includes("-W")) {
                      const [ym, weekStr] = row.time.split("-W");
                      const [year, month] = ym.split("-");

                      const monthIdx = parseInt(month, 10) - 1;

                      label = `${monthNames[monthIdx]} - W${weekStr}`;
                    } else if (/^\d{4}$/.test(row.time)) {
                      label = row.time;
                    }

                    const list = categories
                      .map((c, i) => ({
                        name: c,
                        value: row[c] || 0,
                        color: BLUE_SHADE_COLORS[i % BLUE_SHADE_COLORS.length],
                      }))
                      .filter(item => item.value > 0);

                    return (
                      <div
                        className="recharts-default-tooltip"
                        style={{
                          background: "white",
                          padding: "8px 10px",
                          borderRadius: "6px",
                          boxShadow: "0px 2px 6px rgba(0,0,0,0.15)",
                          fontFamily: "Calibri",
                          fontSize: "13px",
                          minWidth: "200px",   // ⭐ Increase tooltip width
                          maxWidth: "350px",   // optional
                          // width: "fit-content" // auto-expand
                        }}
                      >
                        <div style={{ fontWeight: 600, marginBottom: 6 }}>{label}</div>
                        {list.map((item, i) => (
                          <div key={i} style={{ display: "flex", justifyContent: "space-between", marginBottom: 2 }}>
                            <div style={{ display: "flex", alignItems: "center", gap: 5 }}>
                              <div style={{ width: 10, height: 10, borderRadius: 2, background: item.color }} />
                              {item.name}
                            </div>
                            <span>{item.value}</span>
                          </div>
                        ))}
                      </div>
                    );
                  }}


                  axisBottom={{
                    tickSize: 0,
                    tickPadding: 10,
                    format: (value: string) => {
                      // ✅ Match the new gap format: gap-{month}-{index}
                      if (String(value).startsWith("gap-")) return "";
                      if (String(value).includes("-W")) return "W" + value.split("-W")[1];
                      return value;
                    },
                  }}

                  axisLeft={{
                    legend: "Ticket Count",
                    legendPosition: "middle",
                    legendOffset: -45,
                    tickSize: 0,
                    tickPadding: 4,
                  }}
                  layers={[
                    "grid",
                    "axes",
                    (p: any) => {
                      if (!isDualAxis) return null;

                      const { xScale, innerHeight } = p;

                      return (
                        <g>
                          {monthPos.map((m: { month: string }) => {
                            const visibleWeeks = processedData.filter(
                              (d) => !d.isGap && d.time.startsWith(`${m.month}-W`)
                            );

                            if (!visibleWeeks.length) return null;

                            const first = visibleWeeks[0];
                            const last = visibleWeeks[visibleWeeks.length - 1];

                            const x1 = xScale(first.time);
                            const x2 = xScale(last.time);

                            if (x1 == null || x2 == null) return null;

                            const step = (xScale.step ? xScale.step() : 0) || 0;
                            const bandwidth = (xScale.bandwidth ? xScale.bandwidth() : 0) || step;
                            const centerX = (x1 + x2 + bandwidth) / 2;

                            const [year, month] = m.month.split("-");
                            const monthIdx = parseInt(month, 10) - 1;

                            return (
                              <text
                                key={m.month}
                                x={centerX}
                                y={innerHeight + 30}
                                textAnchor="middle"
                                fontSize={12}
                                fontWeight="500"
                                className="chart-month-label"
                              >
                                {`${monthNames[monthIdx]}`}
                              </text>
                            );
                          })}
                        </g>
                      );
                    },
                    "bars",
                    "markers",
                  ]}

                />

              </div>
              {/* 🎨 Hover Legend Below Chart */}

              <div className="w-full text-center relative bottom-[25px]">

                <button
                  className="peer px-3 py-1 text-[15px] service-provider-button rounded-md shadow cursor-pointer relative"
                >
                  Category
                </button>

                {/* TOOLTIP - appears ONLY when button is hovered */}
                <div
                  className="
      absolute left-1/2 -translate-x-1/2 
      service-provider-tooltip shadow-lg rounded-md border z-50 
      p-3
      
      w-[350px]
      grid grid-cols-2 gap-x-5 gap-y-2
      font-[Calibri] text-[13px]

      opacity-0 invisible pointer-events-none
      transition-opacity duration-200 ease-in-out

      peer-hover:opacity-100 peer-hover:visible peer-hover:pointer-events-auto

      bottom-[45px]
    "
                >
                  {categories.map((c, i) => (
                    <div key={i} className="flex items-center gap-2">
                      <div
                        className="w-2 h-2 rounded-sm"
                        style={{ background: BLUE_SHADE_COLORS[i % BLUE_SHADE_COLORS.length] }}
                      />
                      <span>{c}</span>
                    </div>
                  ))}
                </div>

              </div>
          </>
        )}

      </div>
    </div>
  );
};


    const processComplianceData = (
      data: any,
      filter: string,
      tenantId: string,
      selectedModule: string
    ): ProcessedComplianceData => {
      if (!data?.data?.data?.[filter]) {
        return { chartData: [], subcategories: [], modules: [] };
      }

      const rawData = data.data.data[filter];
      let filteredData = rawData;
      if (tenantId !== "All") {
        filteredData = rawData.filter((item: any) => String(item.organization_id) === tenantId);
      }

      // Extract all available modules from the actual data structure (first level: "Uncategorized", etc.)
      const allModules = new Set<string>();
      const allSubcategories = new Set<string>();
      
      filteredData.forEach((orgData: any) => {
        Object.keys(orgData.records || {}).forEach(module => {
          allModules.add(module);
          
          // Extract subcategories from each module (second level: "Unknown Subcategory", etc.)
          const moduleRecords = orgData.records[module] || {};
          Object.keys(moduleRecords).forEach(subcategory => {
            allSubcategories.add(subcategory);
          });
        });
      });
      
      const modules = Array.from(allModules);
      const moduleToUse = selectedModule || modules[0] || '';

      const processedData: Array<{
        time: string;
        subcategory: string;
        open: number;
        close: number;
        progress: number;
        before_eta: number;
        eta: number;
        after_eta: number;
      }> = [];

      const subcategoriesSet = new Set<string>();

      filteredData.forEach((orgData: any) => {
        const records = orgData.records || {};
        
        // Process each module in the records (first level: "Uncategorized", etc.)
        Object.entries(records).forEach(([module, moduleRecords]: [string, any]) => {
          // Skip if module filter is applied and doesn't match
          if (moduleToUse && moduleToUse !== module) {
            return;
          }

          // Process each subcategory within the module (second level: "Unknown Subcategory", etc.)
          Object.entries(moduleRecords).forEach(([subcategory, subcategoryData]: [string, any]) => {
            subcategoriesSet.add(subcategory);

            // Process each date entry within the subcategory
            Object.entries(subcategoryData).forEach(([date, counts]: [string, any]) => {
              const recordDate = new Date(date);
              let timeLabel: string;
              const monthIndex = recordDate.getMonth();

              // Handle different time filters - same logic as other charts
             const year = recordDate.getFullYear();
const month = recordDate.getMonth() + 1; // 1–12

switch (filter) {
  case "1_day":
    timeLabel = recordDate.toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: false,
    });
    break;

  case "5_day":
    timeLabel = recordDate.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
    });
    break;

  case "1_month": {
    const monthStart = new Date(year, recordDate.getMonth(), 1);
    const weekNum = getWeekNumber(recordDate, monthStart);

    timeLabel = `${year}-${month.toString().padStart(2, "0")}-W${Math.min(weekNum, 4)}`;
    break;
  }

  case "3_month":
  case "6_month":
  case "1_year": {
    const monthStartDate = new Date(year, recordDate.getMonth(), 1);
    const weekNumber = getWeekNumber(recordDate, monthStartDate);

    timeLabel = `${year}-${month.toString().padStart(2, "0")}-W${Math.min(weekNumber, 4)}`;
    break;
  }

  case "5_years":
  case "max":
    timeLabel = year.toString();
    break;

  default:
    timeLabel = formatDateForTooltip(date);
}


              // Create data point for this subcategory and time
              processedData.push({
                time: timeLabel,
                subcategory,
                open: counts.open || 0,
                close: counts.close || 0,
                progress: counts.progress || 0,
                before_eta: counts.before_eta || 0,
                eta: counts.eta || 0,
                after_eta: counts.after_eta || 0
              });
            });
          });
        });
      });

      // subcategories (like "Unknown Subcategory") will be used for y-axis labels
      const subcategories = Array.from(subcategoriesSet).sort();
      return { chartData: processedData, subcategories, modules };
    };
    const processComplianceDataForTable = (
      data: any,
      filter: string,
      tenantId: string,
      selectedModule: string
    ): any[] => {
      if (!data?.data?.data?.[filter]) {
        return [];
      }

      const rawData = data.data.data[filter];
      let filteredData = rawData;
      if (tenantId !== "All") {
        filteredData = rawData.filter((item: any) => String(item.organization_id) === tenantId);
      }

      // Use a Map to aggregate data by Month-Week-Category combination
      const aggregatedData = new Map<string, {
        month: string;
        week: string;
        category: string;
        pending: number;
        open: number;
        closed: number;
        inEta: number;
        beforeEta: number;
        afterEta: number;
        total: number;
      }>();

      filteredData.forEach((orgData: any) => {
        const records = orgData.records || {};
        
        // Process each module in the records
        Object.entries(records).forEach(([module, moduleRecords]: [string, any]) => {
          // Skip if module filter is applied and doesn't match
          if (selectedModule && selectedModule !== module) {
            return;
          }

          // Process each subcategory within the module (these are the categories like "incident", "problem", etc.)
          Object.entries(moduleRecords).forEach(([subcategory, subcategoryData]: [string, any]) => {
            // Process each date entry within the subcategory
            Object.entries(subcategoryData).forEach(([date, counts]: [string, any]) => {
              const recordDate = new Date(date);
              let month: string;
              let week: string;

              // Handle different time filters
              switch (filter) {
                case "1_day":
                  month = recordDate.toLocaleDateString('en-US', { month: 'short' });
                  week = recordDate.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
                  break;
                case "5_day":
                  month = recordDate.toLocaleDateString('en-US', { month: 'short' });
                  week = recordDate.toLocaleDateString('en-US', { day: 'numeric' });
                  break;
                case "1_month":
                  month = recordDate.toLocaleDateString('en-US', { month: 'short' });
                  const monthStart = new Date(recordDate.getFullYear(), recordDate.getMonth(), 1);
                  const weekNum = getWeekNumber(recordDate, monthStart);
                  week = `W${Math.min(weekNum, 4)}`;
                  break;
                case "3_month":
                case "6_month":
                case "1_year":
                  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                  month = monthNames[recordDate.getMonth()];
                  const monthStartDate = new Date(recordDate.getFullYear(), recordDate.getMonth(), 1);
                  const weekNumber = getWeekNumber(recordDate, monthStartDate);
                  week = `W${Math.min(weekNumber, 4)}`;
                  break;
                case "5_years":
                case "max":
                  month = recordDate.toLocaleDateString("en-US", { month: "short" }); // Month name
                  week = recordDate.getFullYear().toString(); // Year string
                  break;
                default:
                  month = recordDate.toLocaleDateString('en-US', { month: 'short' });
                  week = date;
              }

              // Create unique key for aggregation
              const aggregationKey = `${month}-${week}-${subcategory}`;

              // Get existing aggregated data or create new entry
              const existingData = aggregatedData.get(aggregationKey) || {
                month,
                week,
                category: subcategory,
                pending: 0,
                open: 0,
                closed: 0,
                inEta: 0,
                beforeEta: 0,
                afterEta: 0,
                total: 0
              };

              // Add current counts to existing data
              existingData.pending += counts.progress || 0;
              existingData.open += counts.open || 0;
              existingData.closed += counts.close || 0;
              existingData.inEta += counts.eta || 0;
              existingData.beforeEta += counts.before_eta || 0;
              existingData.afterEta += counts.after_eta || 0;
              
              // Recalculate total
              existingData.total = existingData.pending + existingData.open + existingData.closed + 
                                  existingData.inEta + existingData.beforeEta + existingData.afterEta;

              // Update the map
              aggregatedData.set(aggregationKey, existingData);
            });
          });
        });
      });

      // Convert Map to Array and add keys
      const tableData = Array.from(aggregatedData.values()).map((item, index) => ({
        ...item,
        key: `${item.month}-${item.week}-${item.category}-${index}`
      }));

      // Sort the data by month, then by week, then by category
      tableData.sort((a, b) => {
        // First sort by month
        if (filter === "5_years" || filter === "max") {
          const yearCompare = parseInt(a.month) - parseInt(b.month);
          if (yearCompare !== 0) return yearCompare;
        } else {
          const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
            'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
          const monthCompare = monthNames.indexOf(a.month) - monthNames.indexOf(b.month);
          if (monthCompare !== 0) return monthCompare;
        }

        // Then sort by week
        if (a.week.startsWith('W') && b.week.startsWith('W')) {
          const weekA = parseInt(a.week.replace('W', ''));
          const weekB = parseInt(b.week.replace('W', ''));
          const weekCompare = weekA - weekB;
          if (weekCompare !== 0) return weekCompare;
        } else {
          const weekCompare = a.week.localeCompare(b.week);
          if (weekCompare !== 0) return weekCompare;
        }

        // Finally sort by category
        return a.category.localeCompare(b.category);
      });

      return tableData;
    };

// Update your renderTicketComplianceChart function with the table view
const renderTicketComplianceChart = () => {
  const cardHeight = 350;
  const filter = startDate && endDate && !useCache 
    ? getActualFilterFromData(ticketComplianceData, internalFilterTicketCompliance)
    : internalFilterTicketCompliance;

  const { chartData: complianceData, subcategories, modules } = ticketComplianceData
    ? processComplianceData(ticketComplianceData, filter, selectedTenantId, selectedComplianceModule)
    : { chartData: [], subcategories: [], modules: [] };

  // Process data for table view
  const tableData = ticketComplianceData
    ? processComplianceDataForTable(ticketComplianceData, filter, selectedTenantId, selectedComplianceModule)
    : [];

    const getMonthColumnTitle = (filter: string) => {
  if (["5_years", "max"].includes(filter)) {
    return "Month";
  }
  return "Month";
};

const getWeekColumnTitle = (filter: string) => {
  if (filter === "1_day") return "Time";
  if (filter === "5_day") return "Date";
  if (["1_month", "3_month", "6_month", "1_year"].includes(filter)) return "Week";
  if (["5_years", "max"].includes(filter)) return "Year";
  return "Week";
};

  // Define table columns
 const tableColumns = [
  {
    title: (
      <span style={{ fontSize: "14px", fontFamily: "Calibri, sans-serif" }}>
        {getMonthColumnTitle(filter)}
      </span>
    ),
    dataIndex: "month",
    key: "month",
    width: 70,
    fixed: 'left' as const,
    render: (value: string) => (
      <span style={{ fontSize: "14px", fontFamily: "Calibri, sans-serif" }}>
        {value}
      </span>
    )
  },
  {
    title: (
      <span style={{ fontSize: "14px", fontFamily: "Calibri, sans-serif" }}>
        {getWeekColumnTitle(filter)}
      </span>
    ),
    dataIndex: "week",
    key: "week",
    width: 60,
    fixed: 'left' as const,
    render: (value: string) => (
      <span style={{ fontSize: "14px", fontFamily: "Calibri, sans-serif" }}>
        {value}
      </span>
    )
  },
  {
    title: (
      <span style={{ fontSize: "14px", fontFamily: "Calibri, sans-serif" }}>
        Category
      </span>
    ),
    dataIndex: "category",
    key: "category",
    width: 120,
    fixed: 'left' as const,
    render: (text: string) => (
      <span
        title={text}
        style={{
          fontSize: "14px",
          fontFamily: "Calibri, sans-serif",
          display: "block",
          whiteSpace: "nowrap",
          overflow: "hidden",
          textOverflow: "ellipsis",
          maxWidth: "110px"
        }}
      >
        {text}
      </span>
    )
  },
  ...["pending", "open", "closed", "inEta", "beforeEta", "afterEta", "total"].map((key) => ({
    title: (
      <span style={{ fontSize: "14px", fontFamily: "Calibri, sans-serif" }}>
        {key === "inEta"
          ? "In ETA"
          : key === "beforeEta"
          ? "Before ETA"
          : key === "afterEta"
          ? "After ETA"
          : key.charAt(0).toUpperCase() + key.slice(1)}
      </span>
    ),
    dataIndex: key,
    key,
    width: 90,
    render: (value: number) => (
      <span style={{ fontSize: "14px", fontFamily: "Calibri, sans-serif" }}>
        {value > 0 ? value.toLocaleString() : "-"}
      </span>
    )
  }))
];


  // Process data similar to other charts for dual axis support
  const shouldShowDualXAxis = ["1_month","3_month", "6_month", "1_year"].includes(filter);
  
  // Group and aggregate data by time periods and subcategories
  const timeGroups: { [time: string]: { [subcategory: string]: any } } = {};
  
  complianceData.forEach(item => {
    if (!timeGroups[item.time]) {
      timeGroups[item.time] = {};
    }
    
    if (!timeGroups[item.time][item.subcategory]) {
      timeGroups[item.time][item.subcategory] = {
        open: 0,
        close: 0,
        progress: 0,
        before_eta: 0,
        eta: 0,
        after_eta: 0
      };
    }
    
    // Aggregate data for this time-subcategory combination
    timeGroups[item.time][item.subcategory].open += item.open || 0;
    timeGroups[item.time][item.subcategory].close += item.close || 0;
    timeGroups[item.time][item.subcategory].progress += item.progress || 0;
    timeGroups[item.time][item.subcategory].before_eta += item.before_eta || 0;
    timeGroups[item.time][item.subcategory].eta += item.eta || 0;
    timeGroups[item.time][item.subcategory].after_eta += item.after_eta || 0;
  });

  // Process time periods with proper spacing like other charts
  const processTimePeriodsWithSpacing = () => {
    const rawTimePeriods = Object.keys(timeGroups).sort((a, b) => {
      if (filter === "1_day") return a.localeCompare(b);
      if (filter === "5_day") return new Date(a).getTime() - new Date(b).getTime();
      if (filter === "1_month") {
        const [monthIndexA, weekA] = a.split('-W');
        const [monthIndexB, weekB] = b.split('-W');
        
        const monthCompare = parseInt(monthIndexA) - parseInt(monthIndexB);
        if (monthCompare !== 0) return monthCompare;
        return parseInt(weekA) - parseInt(weekB);
      }
       if (["3_month", "6_month", "1_year"].includes(filter)) {
      // a = "2026-01-W2"
      const [yA, mA, wA] = a.split(/-|W/).map(Number);
      const [yB, mB, wB] = b.split(/-|W/).map(Number);

      if (yA !== yB) return yA - yB;   // YEAR first
      if (mA !== mB) return mA - mB;   // MONTH next
      return wA - wB;                  // WEEK last
    }
      if (filter === "5_years" || filter === "max") {
        return parseInt(a) - parseInt(b);
      }
      return a.localeCompare(b);
    });

    return rawTimePeriods;
  };
//showing values greater than zero in graph
  for (const time of Object.keys(timeGroups)) {
  const subcats = timeGroups[time];

  const hasRealValue = Object.values(subcats).some(s =>
    Object.values(s).some(v => typeof v === "number" && v > 0)
  );

  if (!hasRealValue) {
    delete timeGroups[time];
  }
}

  const timePeriods = processTimePeriodsWithSpacing();


  // Helper function to truncate text with tooltip
interface TruncatedTextProps {
  text: string;
  x: number;
  y: number;
  maxLength?: number;
  maxLines?: number;
  lineGap?: number;
}

const TruncatedText: React.FC<TruncatedTextProps> = ({
  text,
  x,
  y,
  maxLength = 25,
  maxLines = 2,
  lineGap
}) => {
  const words: string[] = text.split(" ");
  const lines: string[] = [];
  let currentLine = "";

  words.forEach((word: string) => {
    if ((currentLine + " " + word).trim().length <= maxLength) {
      currentLine += (currentLine ? " " : "") + word;
    } else if (lines.length < maxLines) {
      lines.push(currentLine);
      currentLine = word;
    }
  });

  if (currentLine && lines.length < maxLines) lines.push(currentLine);

  if (lines.length > maxLines) {
    lines[maxLines - 1] = lines[maxLines - 1] + "…";
  }

  return (
    <text x={x} y={y} fontSize="16"   className="chart-axis-text" textAnchor="start">
      {lines.map((line: string, i: number) => (
        <tspan key={i} x={x}   dy={i === 0 ? 0 : 14 + (lineGap || 0)} >
          {line}
        </tspan>
      ))}
    </text>
  );
};




  // Updated Custom Tooltip Component (fixed glittering)
//  const ComplianceTooltip = ({ active, payload, label, filter }: any) => {
//   if (!active || !payload || !payload.length) return null;

//   const validEntries = payload.filter((entry: any) => entry.value && entry.value > 0);
//   if (validEntries.length === 0) return null;

//   const getTooltipLabel = (label: string, filter: string) => {
//     let displayLabel = label;
//     if (label.includes('-W')) {
//       const [monthIndex, week] = label.split('-W');
//       const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
//         'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
//       const monthName = monthNames[parseInt(monthIndex)] || monthIndex;
//       displayLabel = `${monthName}-W${week}`;
//     }

//     switch (filter) {
//       case "1_day":
//         return `Time: ${displayLabel}`;
//       case "5_day":
//         return `Day: ${displayLabel}`;
//       case "1_month":
//         return `Week: ${displayLabel}`;
//       case "3_month":
//       case "6_month":
//       case "1_year":
//         return `Time: ${displayLabel}`;
//       case "5_years":
//       case "max":
//         return `Year: ${displayLabel}`;
//       default:
//         return `Period: ${displayLabel}`;
//     }
//   };

//   return (
//     <div 
//       className="bg-white p-2 border border-gray-300 rounded shadow-lg text-xs"
//       style={{
//         maxWidth: '200px',
//         fontSize: '10px',
//         zIndex: 1001,
//         pointerEvents: 'none'
//       }}
//     >
//       <div className="font-semibold mb-1" style={{ fontSize: '11px' }}>
//         {getTooltipLabel(label, filter)}
//       </div>
//       <div style={{ 
//         display: 'grid', 
//         gridTemplateColumns: validEntries.length > 4 ? '1fr 1fr' : '1fr',
//         gap: '2px',
//         fontSize: '9px'
//       }}>
//         {validEntries.map((entry: any, index: number) => (
//           <div key={index} style={{ color: entry.color, fontWeight: 'bold' }}>
//             {`${entry.dataKey.replace('_', ' ')}: ${entry.value}`}
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// };
 // 🍀 Status label mapping
  const COMPLIANCE_STATUS_LABELS: Record<keyof typeof COMPLIANCE_STATUS_COLORS, string> = {
    open: "Open",
    close: "Closed",
    progress: "Progress",
    before_eta: "Before ETA",
    eta: "ETA",
    after_eta: "After ETA",
  }
// ✅ Enhanced Tooltip with Triangle Icons + Full Category Data
const ComplianceTooltip = ({ active, payload, label, filter }: any) => {
  if (!active || !payload || !payload.length) return null;

  const pointData = payload[0];
  const category = pointData?.category || pointData?.payload?.subcategory || "N/A";

 ;

  // 🎯 Smart week/month/year label logic
  const getTooltipLabel = (label: string, filter: string) => {
    let displayLabel = label;
 if (label.includes("-W")) {
  // label = "2025-11-W2"
  const parts = label.split("-");

  const month = parts[1];                 // "11"
  const week = parts[2].replace("W", ""); // "2"

  const monthNames = [
    'Jan','Feb','Mar','Apr','May','Jun',
    'Jul','Aug','Sep','Oct','Nov','Dec'
  ];

  displayLabel = `${monthNames[Number(month) - 1]} - W${week}`;
}

    switch (filter) {
      case "1_day": return `${displayLabel}`;
      case "5_day": return `${displayLabel}`;
      case "1_month": return `${displayLabel}`;
      case "3_month":
      case "6_month":
      case "1_year": return `${displayLabel}`;
      case "5_years":
      case "max": return `${displayLabel}`;
      default: return `Period: ${displayLabel}`;
    }
  };

  return (
    <div
      className="recharts-default-tooltip"
      style={{
        backgroundColor: 'white',
        border: '1px solid #ddd',
        borderRadius: '6px',
        padding: '12px 14px',
        fontSize: '12px',
        boxShadow: '0 4px 12px rgba(0,0,0,0.2)',
        pointerEvents: 'none',
        maxWidth: '280px',
        minWidth: '200px',
      }}
    >
      {/* 🗓️ Week/Time label */}
      <div style={{ fontWeight: 'normal', marginBottom: '6px', fontSize: '14px' }}>
        {getTooltipLabel(label, filter)}
      </div>

      {/* 📂 Subcategory */}
      <div style={{ marginBottom: '8px', fontSize: '13px' }}>
        <p>Category:</p> {category}
      </div>

      {/* 📊 Status + Triangle icon + value */}
      <div style={{ borderTop: '1px solid #eee', paddingTop: '8px' }}>
        {Object.entries(COMPLIANCE_STATUS_COLORS)
          .filter(([key]) => (pointData?.payload?.[key] ?? 0) > 0)
          .map(([key, color], index) => (
            <div
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                width: '100%',
                fontSize: '13px',
                marginBottom: '4px',
              }}
            >
              {/* Left: Icon + Label */}
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <svg width="10" height="10" viewBox="0 0 10 10">
                  <polygon points="5,0 10,10 0,10" fill={color} />
                </svg>
                <span>
                  {COMPLIANCE_STATUS_LABELS[key as keyof typeof COMPLIANCE_STATUS_LABELS]}
                </span>
              </div>

              {/* Right: Value */}
              <span style={{ fontWeight: 'normal'}}>
                {pointData?.payload?.[key] ?? 0}
              </span>
            </div>

          ))}
      </div>
    </div>
  );
};




  // Smart Month Position Function (like other charts)
  const getSmartMonthPosition = (
    timePeriods: string[],
    currentMonthKey: string,
    xPositions: number[]
  ): { shouldShow: boolean; targetIndex: number; xOffset: number } => {
    const monthWeekIndices = timePeriods
      .map((time, index) => ({ time, index }))
      .filter(({ time }) => {
  if (!time.includes("-W")) return false;

  // time = "2025-11-W2"
   const monthKey = time.split("-W")[0]; // "2025-11"
  return monthKey === currentMonthKey;
})

      .sort((a, b) => {
        const weekA = parseInt(a.time.split('-W')[1]);
        const weekB = parseInt(b.time.split('-W')[1]);
        return weekA - weekB;
      });

    const totalWeeks = monthWeekIndices.length;
    if (totalWeeks === 0) return { shouldShow: false, targetIndex: -1, xOffset: 0 };

    let targetIndex: number;
    let xOffset = 0;

    if (totalWeeks === 1) {
      targetIndex = monthWeekIndices[0].index;
    } else if (totalWeeks === 2) {
      targetIndex = monthWeekIndices[0].index;
      // Calculate offset to center between first and second week
      const firstX = xPositions[monthWeekIndices[0].index];
      const secondX = xPositions[monthWeekIndices[1].index];
      xOffset = (secondX - firstX) / 2;
    } else if (totalWeeks === 3) {
      targetIndex = monthWeekIndices[1].index; // Middle week
    } else if (totalWeeks === 4) {
      targetIndex = monthWeekIndices[1].index;
      // Calculate offset to center between 2nd and 3rd week
      const secondX = xPositions[monthWeekIndices[1].index];
      const thirdX = xPositions[monthWeekIndices[2].index];
      xOffset = (thirdX - secondX) / 2;
    } else {
      targetIndex = monthWeekIndices[Math.floor(totalWeeks / 2)].index;
    }

    return { shouldShow: true, targetIndex, xOffset };
  };

  // Enhanced Scatter Chart Component
  const ComplianceScatterChart = () => {
    const [tooltip, setTooltip] = useState<any>(null);
    // Initialize with actual container width or fallback to window width
  const [containerWidth, setContainerWidth] = useState(() => {
    if (typeof window !== 'undefined') {
      return window.innerWidth - 100; // Approximate container width
    }
    return svgWidth;
  });
  
  // Update container width on mount and resize
  useEffect(() => {
    const updateWidth = () => {
      if (wrapperRef.current) {
        setContainerWidth(wrapperRef.current.offsetWidth);
      }
    };
    
    // Call immediately on mount
    updateWidth();
    
    // Small delay to ensure DOM is ready
    const timeoutId = setTimeout(updateWidth, 0);
    
    window.addEventListener('resize', updateWidth);
    
    return () => {
      clearTimeout(timeoutId);
      window.removeEventListener('resize', updateWidth);
    };
  }, []);
    const marginLeft = 200; 
    const ADD_EXTRA_SPACE_FOR_LONG_TERM = 0;
    const isMultiFilter = ["1_month","1_year","3_month","6_month"].includes(filter);
    
      // FIXED: Calculate proper X positions with month spacing and better spacing for 5y/max
 const calculateXPositions = () => {
  const marginRight = 40; // ✅ ADD margin right
  const plotWidth = containerWidth - marginLeft - marginRight; // ✅ USE containerWidth instead of svgWidth
  
  if (!shouldShowDualXAxis) {
    const positions: number[] = [];
    const spacing = plotWidth / (timePeriods.length || 1);
    
    for (let i = 0; i < timePeriods.length; i++) {
      const x = marginLeft + i * spacing + spacing / 2;
      positions.push(x);
    }
    return positions;
  }

  // For dual axis, group by months with proper spacing
  const monthlyGrouped: { [monthKey: string]: string[] } = {};
  timePeriods.forEach(time => {
    if (time.includes("-W")) {
  const [year, month] = time.split("-W")[0].split("-");
  const monthKey = `${year}-${month}`;

  if (!monthlyGrouped[monthKey]) {
    monthlyGrouped[monthKey] = [];
  }
  monthlyGrouped[monthKey].push(time);
}
 else {
      monthlyGrouped['0'] = monthlyGrouped['0'] || [];
      monthlyGrouped['0'].push(time);
    }
  });

  let monthKeys = Object.keys(monthlyGrouped);
  if (filter === "1_year") {
    const now = new Date();
    const currentMonth = now.getMonth();
    monthKeys.sort((a, b) => {
      const monthA = parseInt(a);
      const monthB = parseInt(b);
      const distanceA = (currentMonth - monthA + 12) % 12;
      const distanceB = (currentMonth - monthB + 12) % 12;
      return distanceB - distanceA;
    });
  } else {
    monthKeys.sort((a, b) => parseInt(a) - parseInt(b));
  }
  
  const totalWeeks = timePeriods.length;
  const numberOfMonths = monthKeys.length;
  const gapBetweenMonths = Math.min(25, plotWidth * 0.03); // ✅ CHANGE: Dynamic gap (max 25px or 3% of width)
  
  // ✅ CHANGE: Calculate available width considering gaps
  const availableWeekWidth = plotWidth - (gapBetweenMonths * Math.max(0, numberOfMonths - 1));
  const weekSlotWidth = availableWeekWidth / totalWeeks;
  
  const positions: number[] = [];
  let currentX = marginLeft;
  
  monthKeys.forEach((month, monthIndex) => {
    const monthWeeks = monthlyGrouped[month].sort((a, b) => {
      if (a.includes('-W') && b.includes('-W')) {
        const weekA = parseInt(a.split('-W')[1]);
        const weekB = parseInt(b.split('-W')[1]);
        return weekA - weekB;
      }
      return a.localeCompare(b);
    });

    monthWeeks.forEach(() => {
      positions.push(currentX + weekSlotWidth / 2);
      currentX += weekSlotWidth;
    });

    if (monthIndex < monthKeys.length - 1) {
      currentX += gapBetweenMonths;
    }
  });

  return positions;
};

  const xPositions = calculateXPositions();
    return (
      <ResponsiveContainer width="100%" height="100%">
        <div ref={wrapperRef} style={{ position: 'relative', width: '100%', height: '100%' }}>
          <svg 
            width="100%" 
            height="100%" 
            viewBox={`0 0 ${containerWidth} ${cardHeight}`}
            preserveAspectRatio="xMidYMid meet"
            style={{ overflow: "visible" }}
            onMouseLeave={() => setTooltip(null)}
          >
            {/* Y-axis labels (subcategories) with truncation */}
            {subcategories.map((subcategory, yIndex) => (
              <TruncatedText
                key={`y-label-${yIndex}`}
                text={subcategory}
                x={10} 
                y={
                  30 +
                  (yIndex * ((cardHeight - 100) / subcategories.length)) +
                  ((cardHeight - 100) / subcategories.length / 2)
                }
                maxLength={isMultiFilter ? 15 : 20}
                maxLines={2}
                lineGap={6}
              />
            ))}

            {/* X-axis labels with proper dual axis spacing and improved visibility for 5y/max */}
            {timePeriods.map((time, timeIndex) => {
              const baseX = xPositions[timeIndex];
              if (!baseX) return null;
              
              // For 5y/max, show every nth label to avoid crowding
              const isLongTerm = filter === "5_years" || filter === "max";
              const shouldShowLabel = !isLongTerm || timeIndex % Math.max(1, Math.floor(timePeriods.length / 8)) === 0;
              
              if (!shouldShowLabel && isLongTerm) return null;
              
              return (
                <g key={`x-label-${timeIndex}`}>
                  {/* Primary X-axis label (weeks/years) */}
                  <text
                    x={baseX}
                    y={shouldShowDualXAxis ? cardHeight - 60 : cardHeight - 35}
                    textAnchor="middle"
                    fontWeight="normal"
                    fontSize={"10"}
                    className="chart-axis-text"
                  >
                    {shouldShowDualXAxis && time.includes('-W') ? 
                      `W${time.split('-W')[1]}` : time}
                  </text>
                  
                  {/* Secondary X-axis label (months) with smart positioning */}
                  {shouldShowDualXAxis && time.includes('-W') && (() => {
                    const [, monthStr] = time.split('-W')[0].split('-');
                    const monthIndex = parseInt(monthStr, 10) - 1;
                    const monthKey = time.split("-W")[0];
                    const { shouldShow, targetIndex, xOffset } = getSmartMonthPosition(
                      timePeriods, 
                      monthKey,
                      xPositions
                    );
                    
                    if (!shouldShow || timeIndex !== targetIndex) return null;
                    
                    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                    const monthName = monthNames[monthIndex] || monthIndex;
                    
                    return (
                      <text
                        key={`month-${monthIndex}`}
                        x={baseX + xOffset + ADD_EXTRA_SPACE_FOR_LONG_TERM}
                        y={cardHeight - 35}
                        textAnchor="middle"
                       fontSize="12"         // Number, not "10px"
                      className="chart-month-label"
                      fontWeight="normal"
                      >
                        {monthName}
                      </text>
                    );
                  })()}
                </g>
              );
            })}

            {/* Horizontal full grid line (for each category) */}
            {subcategories.map((_, yIndex) => {
              const centerY =
                20 +
                yIndex * ((cardHeight - 100) / subcategories.length) +
                ((cardHeight - 100) / subcategories.length) / 2;

              return (
                <line
                  key={`h-grid-${yIndex}`}
                 x1={xPositions[0]}
                  y1={centerY}
                 x2={xPositions[xPositions.length - 1]}
                  y2={centerY}
                  // stroke="#e0e0e0"
                 className="chart-grid-line"
                  strokeDasharray="2 2"
                />
              );
            })}

            {/* Vertical dotted lines for each week/period - CENTERED */}
            {timePeriods.map((time, timeIndex) => {
              const baseX = xPositions[timeIndex];
              if (!baseX) return null;
              
              return (
                <line
                  key={`v-grid-${timeIndex}`}
                  x1={baseX + ADD_EXTRA_SPACE_FOR_LONG_TERM}
                  y1={20}
                  x2={baseX + ADD_EXTRA_SPACE_FOR_LONG_TERM}
                  y2={cardHeight - 80}
                  // stroke="#e0e0e0"
                  className="chart-grid-line"
                  strokeDasharray="2 2"
                  strokeWidth="1"
                />
              );
            })}

            {/* FIXED: Data points as triangles positioned EXACTLY on the vertical dotted lines */}
            {timePeriods.map((time, timeIndex) => 
              subcategories.map((subcategory, yIndex) => {
                const dataPoint = timeGroups[time]?.[subcategory];
                if (!dataPoint) return null;

                const statusTypes = ['open', 'close', 'progress', 'before_eta', 'eta', 'after_eta'];
                const baseX = xPositions[timeIndex];
                if (!baseX) return null;
                
                // Center on the horizontal grid line
                const centerY = 20 + yIndex * ((cardHeight - 100) / subcategories.length) + ((cardHeight - 100) / subcategories.length)/2;
                
                // Count how many statuses have data for better vertical spacing
                const activeStatuses = statusTypes.filter(status => dataPoint[status] && dataPoint[status] > 0);
                const totalActiveStatuses = activeStatuses.length;
                
                return statusTypes.map((status, statusIndex) => {
                  const count = dataPoint[status];
                  if (!count || count === 0) return null; // Ignore 0 values

                  // Find the active index for vertical positioning
                  const activeIndex = activeStatuses.indexOf(status);
                  if (activeIndex === -1) return null;

                  // FIXED: Position triangles EXACTLY on the vertical dotted line with vertical stacking
                  const x = baseX; // Exactly on the vertical line
                  const verticalSpacing = Math.min(8, 24 / Math.max(totalActiveStatuses, 1)); // Adaptive spacing based on count
                  const startY = centerY - ((totalActiveStatuses - 1) * verticalSpacing) / 2;
                  const y = startY + (activeIndex * verticalSpacing);
                  
                  const color = COMPLIANCE_STATUS_COLORS[status as keyof typeof COMPLIANCE_STATUS_COLORS];
                  const size = filter === "5_years" || filter === "max" ? 6 : 8; // Smaller for long-term views

                  return (
                    <g key={`${time}-${subcategory}-${status}`}>
                      {/* Triangle positioned as arrow on the line */}
                      <polygon
                        points={`${x},${y-size} ${x-size},${y+size} ${x+size},${y+size}`}
                        fill={color}
                        stroke={color}
                        strokeWidth="1"
                        style={{ cursor: 'pointer' }}
                        onMouseEnter={(e) => {
                          e.stopPropagation();
                          setTooltip({
                            active: true,
                            coordinate: { x: x, y: y },
                            label: time,
                            payload: [{
                              dataKey: status,
                              value: count,
                              color: color,
                              category: subcategory,   // ✅ Add this
                              payload: dataPoint       // ✅ Add this to get full values later
                            }]
                          });
                        }}
                        onMouseLeave={(e) => {
                          e.stopPropagation();
                          setTooltip(null);
                        }}
                      />
                      
                      {/* FIXED: Count label in BLACK color positioned to the right of the triangle */}
                      {/* <text
                        x={x + size + 2}
                        y={y + 1}
                        fontSize="5"          // Number, smaller than axis
                        fill="#000000"
                        textAnchor="start"
                        dominantBaseline="middle"
                        style={{ 
                          fontWeight: 'bold',
                          pointerEvents: 'none' // Prevent text from interfering with hover
                        }}
                      >
                        {count}
                      </text> */}
                    </g>
                  );
                });
              })
            )}
          </svg>
          
          {/* Render tooltip with improved stability */}
        {tooltip && tooltip.active && (
            <div
              style={{
                position: "absolute",
                top: tooltip.coordinate.y - 10,
                transform: "translateY(-50%)",
                zIndex: 1000,
                pointerEvents: "none",
                 // Dynamic positioning of tooltip
      left:
        tooltip.coordinate.x + 240 > containerWidth 
          ? tooltip.coordinate.x - 260  
          : tooltip.coordinate.x + 20,
              }}
            >
          <ComplianceTooltip {...tooltip} filter={internalFilterTicketCompliance} />
        </div>
      )}
        </div>
      </ResponsiveContainer>
    );
  };

  return (
    <div
      className="bg-white p-4 rounded-lg shadow-md graph"
      style={{
        height: `450px`,
        width: "100%",
        overflow: 'hidden',
        position: 'relative'
      }}
    >
      <div className="bg-gray-100 flex justify-between items-center p-4 chart-title">
        <div className="flex items-center">
          <LineChart className="cursor-pointer mr-2" />
          <h2 className="font-semibold">Ticket Compliance by Module</h2>
        </div>
        <div className="flex items-center gap-2">
        <Select
        className="min-w-[150px]"
          value={modules
            .map(module => ({ value: module, label: module }))
            .find(option => option.value === selectedComplianceModule) || null
          }
          onChange={(selectedOption) => setSelectedComplianceModule(selectedOption?.value || "")}
          options={modules.map(module => ({ value: module, label: module }))}
          placeholder="Select Module"
          styles={DropdownStyles}
          components={{
            DropdownIndicator: () => (
              <ChevronDownIcon className="w-4 h-4 text-gray-600" />
            ),
          }}
        />

           <button
                  onClick={() => setFlippedChart(flippedChart === 3 ? null : 3)}
                  className="flex items-center justify-center cursor-pointer"
                  style={{
                    width: "24px",
                    height: "24px",
                    border: "none",
                    background: "transparent",
                    padding: 0,
                    marginLeft: "4px",
                  }}
                >
                  <i
                    className="fi fi-rr-flip-horizontal"
                    style={{
                      fontSize: "18px",
                      color: "#000",
                      lineHeight: 1,
                    }}
                  />
                </button>
        </div>
      </div>

      {renderFilterButtons("ticketCompliance")}

      {loadingTicketCompliance ? (
        <div className="flex flex-row justify-center items-center h-full">
          <Spin size="large" />
        </div>

      ) : (
        <div style={{ height: `${cardHeight - 10}px`, padding: "10px", width: "100%" }}>
          {getActualFilterFromData(ticketComplianceData, internalFilterTicketCompliance) === "no_data" ? (
            <div className="flex justify-center items-center h-full">
              <span style={{ fontSize: '16px', color: '#666' }}>No Data Available</span>
            </div>) : (
            flippedChart === 3 ? (
              // Table View
              <div style={{
                height: `${cardHeight - 20}px`,
                padding: "10px",
                overflow: 'hidden'
              }}>
                <Table
                  dataSource={tableData}
                  columns={tableColumns}
                  pagination={false}
                  scroll={{
                    y: cardHeight - 120,
                    x: 800
                  }}
                  size="small"
                  style={{
                    fontSize: '9px',
                    width: '100%'
                  }}
                  rowClassName={(record, index) => {
                    // Alternate row colors for better readability
                    return index % 2 === 0 ? 'table-row-even' : 'table-row-odd';
                  }}
                />
              </div>
                ) : (
                  // Chart View
                  complianceData.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full w-full">
                      <span style={{ fontSize: 16, color: "#aaa" }}>No Data Available</span>
                    </div>
                  ) : (
                    <div style={{ width: '100%', height: '100%', position: 'relative' }}>
                      <ComplianceScatterChart />

                      {/* Legend positioned INSIDE the chart container at bottom */}
                      <div
                        style={{
                          position: 'absolute',
                          left: '50%',
                          bottom: "5px",
                          transform: 'translateX(-50%)',
                          display: 'flex',
                          flexWrap: 'wrap',
                          justifyContent: 'center',
                          gap: '8px',
                          fontSize: '10px',
                          maxHeight: "45px",
                        }}
                      >
                        {Object.entries(COMPLIANCE_STATUS_COLORS).map(([status, color]) => (
                          <div key={status} className="flex items-center gap-1">
                            {/* Triangle icon */}
                            <div
                              style={{
                                width: 0,
                                height: 0,
                                borderLeft: '5px solid transparent',
                                borderRight: '5px solid transparent',
                                borderBottom: `8px solid ${color}`
                              }}
                            />

                            {/* Proper Label from LABELS mapping */}
                            <span className="chart-legend-text" style={{ fontSize: '12px', fontWeight: 'bold' }}>
                              {COMPLIANCE_STATUS_LABELS[status as keyof typeof COMPLIANCE_STATUS_LABELS]}
                            </span>
                          </div>
                        ))}
                      </div>

                    </div>
                  )
                )
          )}
        </div>
      )}

      {/* Add custom CSS for table styling */}
      <style jsx>{`
        .table-row-even {
          background-color: #f9f9f9;
        }
        .table-row-odd {
          background-color: #ffffff;
        }
        .ant-table-thead > tr > th {
          background-color: #f0f0f0 !important;
          font-weight: bold !important;
          font-size: 10px !important;
          padding: 4px 8px !important;
        }
        .ant-table-tbody > tr > td {
          padding: 4px 8px !important;
          font-size: 9px !important;
        }
      `}</style>
    </div>
  );
};
// 2. UPDATE THE renderFilterButtons FUNCTION TO INCLUDE ticketCompliance (replace your existing function)
const renderFilterButtons = (chart: string) => {
  const filters = [
    { label: "1D", value: "1_day" },
    { label: "5D", value: "5_day" },
    { label: "1M", value: "1_month" },
    { label: "3M", value: "3_month" },
    { label: "6M", value: "6_month" },
    { label: "1Y", value: "1_year" },
    { label: "5Y", value: "5_years" },
    { label: "Max", value: "max" },
  ];

  let currentFilter: string;
  let dataSource = useCache ? cachedData : chartData;
  
  if (chart === "ticketStatus") {
    currentFilter = startDate && endDate && !useCache 
      ? getActualFilterFromData(dataSource.ticketStatusDistribution, internalFilterTicketStatus)
      : internalFilterTicketStatus;
  } else if (chart === "ticketSeverity") {
    currentFilter = startDate && endDate && !useCache
      ? getActualFilterFromData(dataSource.ticketSeverityOverview, internalFilterTicketSeverity)  
      : internalFilterTicketSeverity;
  } else if (chart === "ticketCategory") {
    currentFilter = startDate && endDate && !useCache
      ? getActualFilterFromData(dataSource.ticketCategoryDistribution, internalFilterTicketCategory)
      : internalFilterTicketCategory;
  } else if (chart === "ticketCompliance") {
    currentFilter = startDate && endDate && !useCache
      ? getActualFilterFromData(ticketComplianceData, internalFilterTicketCompliance)
      : internalFilterTicketCompliance;
  } else {
    currentFilter = "1_month"; // fallback
  }

  return (
    <div className="flex grid grid-cols-8">
      {filters.map((filter) => (
        <button
          key={filter.value}
          onClick={() => handleInternalFilterChange(chart, filter.value)}
          style={{ fontFamily: "Calibri, sans-serif", fontSize: "14px" }}
          className={`${currentFilter === filter.value || (currentFilter === "no_data" && filter.value === internalFilterTicketStatus) ? "new-dashboard-filter-active-btn" : "new-dashboard-filter-btn"} p-2 transition-all duration-300`}
        >
          {filter.label}
        </button>
      ))}
    </div>
  );
};

  const getAdjustedDomain = (data: any[], field: string) => {
    if (!data || data.length === 0) return [0, 10];
    const values = data.map((item) => Number(item[field])).filter((v) => !isNaN(v));
    if (values.length === 0) return [0, 10];
    const max = Math.max(...values);
    const adjustedMax = Math.ceil(max * 1.2);
    return [0, adjustedMax];
  };


// STEP 3: Replace your entire renderNewChartsWithScrolling function with this:

const renderNewChartsWithScrolling = () => {
  const cardHeight = 280;
  const dataSource = useCache ? cachedData : chartData;
  
  const filterTicketStatus = startDate && endDate && !useCache 
    ? getActualFilterFromData(dataSource.ticketStatusDistribution, internalFilterTicketStatus)
    : internalFilterTicketStatus;
    
  const filterTicketSeverity = startDate && endDate && !useCache
    ? getActualFilterFromData(dataSource.ticketSeverityOverview, internalFilterTicketSeverity)  
    : internalFilterTicketSeverity;

  // FIX: Update these lines to use getActualFilterFromData
  const filterTicketCategory = startDate && endDate && !useCache
    ? getActualFilterFromData(dataSource.ticketCategoryDistribution, internalFilterTicketCategory)
    : internalFilterTicketCategory;

  const filterTicketCompliance = startDate && endDate && !useCache
    ? getActualFilterFromData(ticketComplianceData, internalFilterTicketCompliance)
    : internalFilterTicketCompliance;
  // Auto-expand for 3M, 6M, and 1Y
  const shouldExpand = 
    ["3_month", "6_month", "1_year"].includes(filterTicketStatus) ||
    ["3_month", "6_month", "1_year"].includes(filterTicketSeverity) ||
    ["3_month", "6_month", "1_year"].includes(filterTicketCategory) ||
    ["3_month", "6_month", "1_year"].includes(filterTicketCompliance);


  // Process chart data
  const { chartData: ticketStatusChartData, details: ticketStatusDetails } = dataSource.ticketStatusDistribution
    ? processStatusChartData(dataSource.ticketStatusDistribution, filterTicketStatus, selectedTenantId)
    : { chartData: [], details: {} };

  const { chartData: ticketSeverityChartData, details: ticketSeverityDetails } = dataSource.ticketSeverityOverview
    ? processSeverityChartData(dataSource.ticketSeverityOverview, filterTicketSeverity, selectedTenantId)
    : { chartData: [], details: {} };

const buildLineDataForStatus = (chartData: any[], statusKeys: string[], colorMap: any) => {
  return statusKeys.map((key) => ({
    id: key,
    color: colorMap[key],
    data: chartData.map((item) => ({
      x: item.day,
      rawDate: item.rawDate ?? null,   // 🟢 KEEP REAL DATE
      y: item[key] ?? 0,
    })),
  }));
};

const addMonthGaps = (data: any[], filter: string) => {
  const result: any[] = [];
  let prevMonth: string | null = null;
  
  data.forEach((item) => {
    if (item.day && item.day.includes('-W')) {
      const currentMonth = item.day.split('-W')[0];
      
      // Add spacer when month changes (skip for 1_month since there's only one month)
      if (filter !== "1_month" && prevMonth !== null && prevMonth !== currentMonth) {
        result.push({
          day: `spacer-${prevMonth}-${currentMonth}`,
          isSpacer: true,
          Open: 0,
          "To do": 0,
          Inprogress: 0,
          Closed: 0
        });
      }
      
      prevMonth = currentMonth;
    }
    
    result.push(item);
  });
  
  return result;
};
// Add color mapping for status
const STATUS_COLORS_MAP = {
  "Closed": "#EF4444", // or your red color
  "Inprogress": "#F59E0B", // or your orange color
  "To do": "#10B981", // or your teal color
  "Open": "#3B82F6" // or your blue color
};

  return (
    <div className="flex flex-col items-start justify-start w-full">
      <div className={
        shouldExpand
          ? "flex flex-col gap-4 w-full p-6"
          : "grid grid-cols-1 md:grid-cols-2 gap-4 w-full p-6"
      }>

        {/* Ticket Status Distribution Chart - NIVO VERSION */}
        {features.includes("Ticket Status Distribution") && (
          <div
            className="bg-white p-4 rounded-lg shadow-md graph"
            style={{
              height: `400px`,
              width: "100%",
              overflow: 'hidden',
            }}
          >
            <div className="bg-gray-100 flex justify-between items-center p-4 chart-title">
              <div className="flex items-center">
                <LineChart className="cursor-pointer mr-2" />
                <h2 className="font-semibold">
                  {dataSource.ticketStatusDistribution?.data?.title || "Ticket Status Distribution"}
                </h2>
              </div>
            </div>
        
            {renderFilterButtons("ticketStatus")}
        
            {loadingTicketStatus ? (
              <div className="flex flex-row justify-center items-center h-full">
                <Spin size="large" />
              </div>
            ) : (
              <div style={{ height: `${cardHeight + 20}px`, padding: "10px" }}>
                {filterTicketStatus === "no_data" ? (
                  <div className="flex justify-center items-center h-full">
                    <span style={{ fontSize: '16px', color: '#666' }}>No Data Available</span>
                  </div>
                ) : (
                  ticketStatusChartData.length === 0 ||
                  ticketStatusChartData.every(x =>
                    (x.Open ?? 0) === 0 &&
                    (x["To do"] ?? 0) === 0 &&
                    (x.Inprogress ?? 0) === 0 &&
                    (x.Closed ?? 0) === 0
                  ) ? (
                    <div className="flex flex-col items-center justify-center h-full w-full">
                      <span style={{ fontSize: 16, color: "#aaa" }}>No Data Available</span>
                    </div>
                  ) : (
                      (() => {
                        const shouldShowDualXAxis = ["1_month", "3_month", "6_month", "1_year"].includes(filterTicketStatus);
                        const bottomMargin = 60;
                        const sortByYearMonth = (data: any[]) => {
                          return [...data].sort((a, b) => {
                            if (!a.rawDate || !b.rawDate) return 0;

                            const dateA = new Date(a.rawDate);
                            const dateB = new Date(b.rawDate);

                            return dateA.getTime() - dateB.getTime(); // YEAR → MONTH → DAY
                          });
                        };

                        // Fix 5D: Ensure ascending date order
                        // ✅ Fix: Always sort by YEAR → MONTH → DAY
                        const sortedTicketStatusData =
                          filterTicketStatus === "5_day"
                            ? [...ticketStatusChartData].sort(
                              (a, b) => new Date(a.rawDate).getTime() - new Date(b.rawDate).getTime()
                            )
                            : sortByYearMonth(ticketStatusChartData);



                        const dataWithGaps = addMonthGaps(sortedTicketStatusData, filterTicketStatus);
                        // Build line data for Nivo
                        const lineData = buildLineDataForStatus(
                          dataWithGaps,
                          STATUS_CATEGORIES,
                          STATUS_COLORS_MAP
                        );
                        // console.log("FINAL NIVO DATA =>", JSON.stringify(lineData, null, 2));
                        // lineData.forEach((serie, index) => {
                        //   console.log(`Serie ${index}:`, {
                        //     id: serie.id,
                        //     color: serie.color,
                        //     dataPoints: serie.data.length
                        //   });
                        // });
                        // Get unique months for dual axis
                        const uniqueMonths = shouldShowDualXAxis
                          ? Array.from(
                            new Set(
                              dataWithGaps
                                .filter(d => !d.isSpacer && d.rawDate)
                                .map(d => {
                                  const date = new Date(d.rawDate);
                                  return `${date.getFullYear()}-${date.getMonth()}`; // YEAR-MONTH KEY
                                })
                            )
                          )
                          : [];

                        const allY = lineData.flatMap(s => s.data.map(p => p.y || 0));
                        let maxValue = Math.max(...allY);

                        function getDynamicTicks(maxValue: number, filter: string) {
                          if (maxValue <= 0) return { max: 10, ticks: [0, 5, 10] };

                          let step: number = 1;

                          // ⭐ CASE 1: 1D / 5D small charts
                          if (["1_day", "5_day"].includes(filter)) {
                            if (maxValue <= 5) step = 1;
                            else if (maxValue <= 10) step = 2;
                            else if (maxValue <= 25) step = 5;
                            else if (maxValue <= 50) step = 10;
                            else step = 20;

                            const niceMax = Math.ceil(maxValue / step) * step;

                            return {
                              max: niceMax,
                              ticks: Array.from({ length: niceMax / step + 1 }, (_, i) => i * step)
                            };
                          }

                          // ⭐ CASE 2: 5Y / Max – large values
                          if (["5_year", "max"].includes(filter)) {
                            const magnitude = Math.pow(10, Math.floor(Math.log10(maxValue)));

                            // Dynamic step (larger ranges → bigger step)
                            if (maxValue < magnitude * 2) step = magnitude / 5;
                            else step = magnitude / 2;

                            step = Math.max(10, Math.round(step / 10) * 10);

                            const niceMax = Math.ceil(maxValue / step) * step;

                            return {
                              max: niceMax,
                              ticks: Array.from({ length: niceMax / step + 1 }, (_, i) => i * step)
                            };
                          }

                          // ⭐ CASE 3: 1M / 3M / 6M / 1Y → medium ranges
                          const magnitude = Math.pow(10, Math.floor(Math.log10(maxValue)));
                          step = magnitude / 4;

                          if (maxValue <= magnitude * 0.5) step = magnitude / 6;
                          if (maxValue <= magnitude * 0.2) step = magnitude / 10;

                          step = Math.max(5, Math.round(step / 5) * 5);

                          const niceMax = Math.ceil(maxValue / step) * step;

                          return {
                            max: niceMax,
                            ticks: Array.from({ length: niceMax / step + 1 }, (_, i) => i * step)
                          };
                        }


                        // ⬇️ APPLY THE FUNCTION HERE
                        const { max: niceMax, ticks: tickValueList } = getDynamicTicks(maxValue, filterTicketStatus);



                        return (
                          <ResponsiveLine
                            data={lineData}
                            margin={{ top: 10, right: 30, bottom: bottomMargin, left: 55 }}
                            xScale={{ type: "point" }}
                            yScale={{
                              type: "linear",
                              min: 0,
                              max: niceMax,   // <-- MUST MATCH tickValues
                              stacked: false,
                            }}


                            curve="monotoneX"
                            axisTop={null}
                            axisRight={null}
                            enableGridX={false}
                            enableGridY={true}
                            // COLOR CONFIGURATION - THIS IS THE FIX
                            colors={(serie) => serie.color}
                            pointSize={8}
                            useMesh={true}
                            enableCrosshair={false}
                            enableSlices="x"

                            axisBottom={{
                              tickSize: 0,
                              tickPadding: 4,
                              format: (value: string): string => {
                                if (value.startsWith("spacer-")) return ""; // hide spacers completely

                                // 🟦 5D: Show "Dec 01"
                                if (filterTicketStatus === "5_day") {
                                  const pt = ticketStatusChartData.find(d => d.day === value);
                                  if (!pt?.rawDate) return value;
                                  const d = new Date(pt.rawDate);
                                  if (isNaN(d.getTime())) return value;
                                  const month = d.toLocaleDateString("en-US", { month: "short" });
                                  const day = d.getDate()
                                  return `${month} ${day}`;
                                }

                                // 🟨 Weeks for multi-month filters
                                if (value.includes("-W")) return `W${value.split("-W")[1]}`;

                                return value;
                              }
                            }}


                            axisLeft={{
                              tickSize: 0,
                              tickPadding: 10,
                              tickRotation: 0,
                              legend: 'Ticket Count',
                              legendOffset: -45,
                              legendPosition: 'middle',
                              tickValues: tickValueList
                            }}



                            sliceTooltip={({ slice }) => {
                              const validPoints = slice.points.filter(pt => !pt.data.x.toString().startsWith("spacer-"));
                              if (!validPoints.length) return null;
                              const first = validPoints[0].data;
                              const firstSeriesPoint = validPoints[0];
                              if (String(first.x).startsWith("spacer-")) return null;
                              // Determine Left vs Right Shift Dynamically
                              const totalSlices = dataWithGaps.filter(d => !d.isSpacer).length;
                              const currentIndex = dataWithGaps.findIndex(d => d.day === first.x);
                              const isLeftSide = currentIndex < totalSlices * 0.5;

                              // Tooltip Label Formatting
                              const raw = first.rawDate ?? null;
                              let label = first.x.toString();
                              if (raw) {
                                const d = new Date(raw);
                                if (!isNaN(d.getTime())) {
                                  const month = d.toLocaleDateString("en-US", { month: "short" });
                                  const day = d.getDate();

                                  if (filterTicketStatus === "5_day") {
                                    label = `${month} ${day}`;
                                  } else {
                                    const weekLabel = first.x.toString().split("-").slice(-1)[0];
                                    label = `${month}-${weekLabel}`;
                                  }
                                }
                              }

                              return (
                                <div
                                  style={{
                                    position: "relative",
                                    transform: isLeftSide ? "translateX(200px)" : "translateX(-10%)",
                                    pointerEvents: "none",
                                  }}
                                >
                                  <div
                                    className="recharts-default-tooltip"
                                    style={{
                                      background: "white",
                                      padding: "10px",
                                      border: "1px solid #ccc",
                                      borderRadius: "4px",
                                      fontSize: "14px",
                                      boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
                                      fontFamily: "Calibri, sans-serif",
                                      width: "160px"
                                    }}
                                  >
                                    <p style={{ fontWeight: 500, marginBottom: 6 }}>{label}</p>

                                    {validPoints.map((pt) => (
                                      <div
                                        key={pt.id}
                                        style={{ display: "flex", justifyContent: "space-between", gap: 12 }}
                                      >
                                        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                                          <div
                                            style={{
                                              width: 10,
                                              height: 10,
                                              borderRadius: "50%",
                                              backgroundColor: pt.seriesColor,
                                            }}
                                          />
                                          <span>{pt.seriesId}</span>
                                        </div>

                                        <span style={{ minWidth: 20, textAlign: "right" }}>
                                          {pt.data.y}
                                        </span>
                                      </div>
                                    ))}
                                  </div>
                                </div>
                              );
                            }}


                            legends={[
                              {
                                anchor: "bottom",
                                direction: "row",
                                justify: false,
                                translateX: 0,
                                translateY: shouldShowDualXAxis ? 60 : 50,
                                itemsSpacing: 10,
                                itemDirection: "left-to-right",
                                itemWidth: 80,
                                itemHeight: 20,
                                itemOpacity: 1,
                                symbolSize: 12,
                                symbolShape: "circle",
                                symbolBorderColor: "rgba(0, 0, 0, .5)",
                                effects: [
                                  {
                                    on: "hover",
                                    style: {
                                      itemBackground: "rgba(0, 0, 0, .03)",
                                      itemOpacity: 1,
                                    },
                                  },
                                ],
                              },
                            ]}

                            layers={[
                              "grid",
                              "markers",
                              "axes",
                              "areas",
                              "crosshair",
                              "lines",
                              "points",
                              "slices",
                              "mesh",
                              "legends",
                              (props: any) => {
                                if (!shouldShowDualXAxis) return null;

                                const { xScale, innerHeight } = props;
                                const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                                  'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

                                return (
                                  <g>
                                    {uniqueMonths.map((ym: string) => {
                                      const [year, monthIndex] = ym.split("-");

                                      const monthPoints = dataWithGaps.filter(d => {
                                        if (!d.rawDate || d.isSpacer) return false;
                                        const dt = new Date(d.rawDate);
                                        return (
                                          dt.getFullYear() === Number(year) &&
                                          dt.getMonth() === Number(monthIndex)
                                        );
                                      });


                                      if (monthPoints.length === 0) return null;

                                      // ⭐ Get first + last X positions for this month
                                      const firstDay = monthPoints[0].day;
                                      const lastDay = monthPoints[monthPoints.length - 1].day;

                                      const firstX = xScale(firstDay);
                                      const lastX = xScale(lastDay);

                                      if (firstX == null || lastX == null) return null;

                                      // ⭐ Center position
                                      const centerX = (firstX + lastX) / 2;
                                      return (
                                        <text
                                          key={`month-${monthIndex}`}
                                          x={centerX}
                                          y={innerHeight + 25}
                                          textAnchor="middle"
                                          className="chart-month-label"
                                          style={{
                                            fontSize: '12px',
                                            fontWeight: 'normal'
                                          }}
                                        >
                                          {monthNames[parseInt(monthIndex)]}
                                        </text>
                                      );
                                    })}
                                  </g>
                                );
                              },
                            ]}

                            theme={{
                              axis: {
                                ticks: {
                                  text: {
                                    fontSize:
                                      filterTicketStatus === "1_year" ? 9 :        // ⬇️ smaller for 1Y
                                        filterTicketStatus === "6_month" ? 10 :       // medium for 6M
                                          10,
                                    fill: "currentColor",
                                    fontFamily: "Calibri"
                                  }
                                },
                                legend: {
                                  text: {
                                    fontSize: 16,
                                    fill: "currentColor",
                                    fontWeight: 'normal',
                                    fontFamily: "Calibri"
                                  }
                                }
                              },
                              legends: {
                                text: {
                                  fontSize: 14,
                                  fill: "currentColor",
                                }
                              },
                              grid: {
                                line: {
                                  // stroke: '#e0e0e0',
                                  strokeWidth: 1,
                                  strokeDasharray: '2 2'
                                }
                              },

                            }}
                          />
                        );
                      })()
                  )
                )}
              </div>
            )}
          </div>
        )}
        {/* Ticket Severity Overview Chart  - NIVO VERSION*/}

        {features.includes("Ticket Severity Overview") && (
          <div
            className="bg-white p-4 rounded-lg shadow-md graph"
            style={{
              height: `400px`,
              width: "100%",
              overflow: 'visible',
            }}
          >
            <div className="bg-gray-100 flex justify-between items-center p-4 chart-title">
              <div className="flex items-center">
                <LineChart className="cursor-pointer mr-2" />
                <h2 className="font-semibold">{dataSource.ticketSeverityOverview?.data?.title || "Ticket Severity Overview"}</h2>
              </div>
            </div>

            {renderFilterButtons("ticketSeverity")}

            {loadingTicketSeverity ? (
              <div className="flex flex-row justify-center items-center h-full">
                <Spin size="large" />
              </div>
            ) : (
              <div style={{ height: `${cardHeight + 20}px`, padding: "10px" }}>
                {filterTicketSeverity === "no_data" ? (
                  <div className="flex justify-center items-center h-full">
                    <span style={{ fontSize: '16px', color: '#666' }}>No Data Available</span>
                  </div>
                ) : (
                  ticketSeverityChartData.length === 0 ||
                  ticketSeverityChartData.every(
                    d => (!d.Low || d.Low === 0) && (!d.Medium || d.Medium === 0) && (!d.High || d.High === 0)
                  ) ? (
                    <div className="flex flex-col items-center justify-center h-full w-full">
                      <span style={{ fontSize: 16, color: "#aaa", fontFamily: "Calibri, sans-serif" }}>
                        No Data Available
                      </span>
                    </div>
                  ) : (
                    (() => {
                      const shouldShowDualXAxis = ["1_month", "3_month", "6_month", "1_year"].includes(filterTicketSeverity);
                      const bottomMargin = shouldShowDualXAxis ? 60 : 45;

                      if (filterTicketSeverity === "5_day") {
                        ticketSeverityChartData.sort((a, b) => {
                          const dateA = new Date(a.rawDate);
                          const dateB = new Date(b.rawDate);
                          return dateA.getTime() - dateB.getTime(); // oldest → newest
                        });
                      }
                      const sortByYearMonth = (data: any[]) => {
                        return [...data].sort((a, b) => {
                          if (!a.rawDate || !b.rawDate) return 0;

                          const dateA = new Date(a.rawDate);
                          const dateB = new Date(b.rawDate);

                          return dateA.getTime() - dateB.getTime(); // oldest → newest
                        });
                      };

                      const sortedTicketSeverityData = sortByYearMonth(ticketSeverityChartData);

                      const dataWithGaps = addMonthGaps(
                        sortedTicketSeverityData,
                        filterTicketSeverity
                      );
                      // Color mapping for severity levels
                      const SEVERITY_COLORS_MAP = {
                        "High": "#FF7675",    // Red
                        "Medium": "#FABE58",  // Yellow
                        "Low": "#74B9FF"      // Blue
                      };

                      // Build line data for Nivo
                      const lineData = buildLineDataForStatus(
                        dataWithGaps,
                        [...SEVERITY_CATEGORIES],
                        SEVERITY_COLORS_MAP
                      );

                      // Get unique months for dual axis
                      // Get unique months for dual axis
                      const uniqueMonths = shouldShowDualXAxis
                        ? Array.from(
                          new Set(
                            dataWithGaps  // ✅ Use dataWithGaps instead of ticketSeverityChartData
                              .filter((d) => d.day && d.day.includes("-W") && !d.isSpacer)
                              .map((d) => {
                                // Extract "2025-11" from "2025-11-W1"
                                const parts = d.day.split("-W");
                                return parts[0]; // Returns "2025-11"
                              })
                          )
                        ).sort()  // Sort chronologically
                        : [];

                      // Add debug
                      console.log('uniqueMonths:', uniqueMonths);
                      console.log('dataWithGaps sample:', dataWithGaps.slice(0, 3));
                      // ======== Compute Max for Severity Chart ========
                      let computedMax = Math.max(
                        ...dataWithGaps
                          .filter(d => !d.isSpacer)
                          .map(d => Math.max(d.High || 0, d.Medium || 0, d.Low || 0))
                      );

                      // Avoid only 0 or flat line
                      if (computedMax === 0) computedMax = 10;

                      // Round nicely (to nearest 5 or 10)
                      let roundedMax = Math.ceil(computedMax / 5) * 5;
                      if (roundedMax <= computedMax) roundedMax += 5;

                      return (
                        <ResponsiveLine
                          data={lineData}
                          margin={{ top: 10, right: 30, bottom: bottomMargin, left: 55 }}
                          xScale={{ type: "point" }}
                          yScale={{
                            type: "linear",
                            min: 0,
                            max: roundedMax,
                            stacked: false,
                          }}
                          curve="monotoneX"
                          axisTop={null}
                          axisRight={null}
                          enableGridX={false}
                          enableGridY={true}
                          colors={(serie) => serie.color}
                          pointSize={8}
                          useMesh={true}
                          enableCrosshair={false}
                          enableSlices="x"

                          axisBottom={{
                            tickSize: 0,
                            tickPadding: 4,
                            format: (value: string): string => {
                              if (value.startsWith("spacer-")) return "";

                              // 5D: Show "Dec 01" format
                              // 5D: Show "Dec-W2" format (Month-Week)
                              if (filterTicketSeverity === "5_day") {
                                const pt = ticketSeverityChartData.find(d => d.day === value);
                                if (!pt?.rawDate) return value;
                                const d = new Date(pt.rawDate);
                                if (isNaN(d.getTime())) return value;
                                const month = d.toLocaleDateString("en-US", { month: "short" });
                                const day = d.getDate()
                                return `${month} ${day}`;
                              }

                              // Weeks for multi-month filters
                              if (value.includes("-W")) return `W${value.split("-W")[1]}`;

                              return value;
                            }
                          }}

                          axisLeft={{
                            tickSize: 0,
                            tickPadding: 10,
                            tickRotation: 0,
                            legend: 'Ticket Count',
                            legendOffset: -45,
                            legendPosition: 'middle',
                            tickValues: (() => {
                              let step = 5;
                              let maxValue = roundedMax;

                              if (["5_years", "max"].includes(filterTicketSeverity)) {
                                // Increase step for large ranges
                                step = Math.ceil(roundedMax / 4);
                                step = Math.ceil(step / 50) * 50; // round to nearest 50 for clean steps
                              }

                              const ticks = [];
                              for (let i = 0; i <= maxValue; i += step) {
                                ticks.push(i);
                              }

                              return ticks;
                            })(),
                          }}


                          sliceTooltip={({ slice }) => {
                            const points = slice.points.filter(pt => !pt.data.x.toString().startsWith("spacer-"));
                            if (!points.length) return null;

                            const xValue = points[0].data.x.toString();
                            let label = xValue;

                            // Same formatting logic you already have
                            if (filterTicketSeverity === "5_day") {
                              const pt = ticketSeverityChartData.find(d => d.day === xValue);
                              if (pt?.rawDate) {
                                const d = new Date(pt.rawDate);
                                if (!isNaN(d.getTime())) {
                                  const month = d.toLocaleDateString("en-US", { month: "short" });
                                  const day = d.getDate();

                                  // Tooltip should match x-axis → "Dec 8"
                                  label = `${month} ${day}`;
                                }
                              }
                            }
                            else if (["1_month", "3_month", "6_month", "1_year"].includes(filterTicketSeverity) && xValue.includes("-W")) {
                              const [year, monthIndex, weekPart] = xValue.split("-");
                              const week = weekPart.replace("W", "");

                              const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                                'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

                              label = `${monthNames[parseInt(monthIndex)]} - W${week}`;
                            }

                            // Detect if near left or right side
                            const totalSlices = dataWithGaps.length;
                            const currentIndex = dataWithGaps.findIndex(d => d.day === xValue);
                            const isLeftSide = currentIndex < totalSlices * 0.5;

                            // Tooltip always stays **INSIDE** chart
                            const offsetX = isLeftSide ? 200 : -50;

                            return (
                              <div
                                style={{
                                  position: "relative",
                                  pointerEvents: "none",
                                  transform: `translateX(${offsetX}px)`
                                }}
                              >
                                <div
                                  className="recharts-default-tooltip"
                                  style={{
                                    background: "white",
                                    padding: "10px",
                                    border: "1px solid #ccc",
                                    borderRadius: "6px",
                                    fontSize: "14px",
                                    boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
                                    fontFamily: "Calibri, sans-serif",
                                    minWidth: "150px"
                                  }}>
                                  <p style={{ fontWeight: 600, marginBottom: 6, textAlign: "center" }}>{label}</p>

                                  {/* Build sortable items */}
                                  {(() => {
                                    // Convert SEVERITY_CATEGORIES → lowercase for consistent matching
                                    const order = SEVERITY_CATEGORIES.map(s => s.toLowerCase());


                                    const items = points.map((pt: any) => ({
                                      id: pt.id,
                                      seriesId: pt.seriesId,
                                      value: Number(pt.data.y || 0),
                                      color: pt.seriesColor
                                    }));

                                    items.sort((a, b) => {
                                      const ai = order.indexOf(a.seriesId.toLowerCase());
                                      const bi = order.indexOf(b.seriesId.toLowerCase());

                                      if (ai !== bi) return ai - bi;
                                      return b.value - a.value;
                                    });

                                    return items.map(it => (
                                      <div
                                        key={it.id}
                                        style={{
                                          display: "flex",
                                          justifyContent: "space-between",
                                          marginBottom: 6,
                                          alignItems: "center",
                                          gap: 12
                                        }}
                                      >
                                        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                                          <div
                                            style={{
                                              width: 10,
                                              height: 10,
                                              borderRadius: "50%",
                                              backgroundColor: it.color
                                            }}
                                          />
                                          <span style={{ fontSize: 13 }}>{it.seriesId}</span>
                                        </div>

                                        <span style={{ minWidth: 35, textAlign: "right", fontWeight: 500 }}>
                                          {it.value}
                                        </span>
                                      </div>
                                    ));
                                  })()}


                                </div>
                              </div>
                            );
                          }}


                          legends={[
                            {
                              anchor: "bottom",
                              direction: "row",
                              justify: false,
                              translateX: 0,
                              translateY: shouldShowDualXAxis ? 60 : 50,
                              itemsSpacing: 10,
                              itemDirection: "left-to-right",
                              itemWidth: 80,
                              itemHeight: 20,
                              itemOpacity: 1,
                              symbolSize: 12,
                              symbolShape: "circle",
                              symbolBorderColor: "rgba(0, 0, 0, .5)",

                              // ⭐ Force legend order using SEVERITY_CATEGORIES
                              data: SEVERITY_CATEGORIES.map((severity) => ({
                                id: severity,
                                label: severity,
                                color:
                                  severity === "High"
                                    ? "#FF7675"
                                    : severity === "Medium"
                                      ? "#FABE58"
                                      : "#74B9FF",
                              })),

                              effects: [
                                {
                                  on: "hover",
                                  style: {
                                    itemBackground: "rgba(0, 0, 0, .03)",
                                    itemOpacity: 1,
                                  },
                                },
                              ],
                            },
                          ]}


                          layers={[
                            "grid",
                            "markers",
                            "axes",
                            "areas",
                            "crosshair",
                            "lines",
                            "points",
                            "slices",
                            "mesh",
                            "legends",
                            (props: any) => {
                              if (!shouldShowDualXAxis) return null;

                              const { xScale, innerHeight } = props;
                              const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                                'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

                              return (
                                <g>
                                  {uniqueMonths.map((yearMonth: string) => {
                                    // Find all points that match this year-month
                                    const monthPoints = dataWithGaps.filter(d => {
                                      if (!d.day || d.isSpacer) return false;
                                      return d.day.startsWith(yearMonth + "-W");
                                    });

                                    if (!monthPoints.length) return null;

                                    const firstDay = monthPoints[0].day;
                                    const lastDay = monthPoints[monthPoints.length - 1].day;

                                    const firstX = xScale(firstDay);
                                    const lastX = xScale(lastDay);

                                    if (firstX == null || lastX == null) return null;

                                    const centerX = (firstX + lastX) / 2;

                                    // Parse year-month for label
                                    const [year, monthStr] = yearMonth.split("-");
                                    const monthIndex = parseInt(monthStr); // ✅ DON'T subtract 1!

                                    // Handle invalid month
                                    let label;
                                    if (monthIndex < 0 || monthIndex > 11) {
                                      label = `${year}`;
                                    } else {
                                      label = `${monthNames[monthIndex]}`;
                                    }

                                    return (
                                      <text
                                        key={yearMonth}
                                        x={centerX}
                                        y={innerHeight + 28}
                                        textAnchor="middle"
                                        style={{ fontSize: 12, fontFamily: "Calibri", fill: "currentColor" }}
                                      >
                                        {label}
                                      </text>
                                    );
                                  })}
                                </g>
                              );
                            }

                          ]}

                          theme={{
                            axis: {
                              ticks: {
                                text: {
                                  fontSize:
                                    filterTicketSeverity === "1_year" ? 9 :
                                      filterTicketSeverity === "6_month" ? 10 : 10,
                                  fontFamily: "Calibri",
                                  fill: "currentColor",
                                }
                              },
                              legend: {
                                text: {
                                  fontSize: 16,
                                  fill: "currentColor",
                                  fontWeight: 'normal',
                                  fontFamily: "Calibri"
                                }
                              }
                            },
                            legends: {
                              text: {
                                fill: "currentColor",
                                fontSize: 14,
                              }
                            },
                            grid: {
                              line: {
                                strokeWidth: 1,
                                strokeDasharray: '2 2'
                              }
                            },
                          }}
                        />
                      );
                    })()
                  )
                )}
              </div>
            )}
          </div>
        )}

      </div>

      {/* Ticket Category Distribution - Full width */}
     {/* Second Row: Charts 3 and 4 */}
      <div className={ 
          "flex flex-col gap-4 w-full p-6"
      }>

        {/* Ticket Category Distribution - YOUR EXISTING CHART 3 */}
        {features.includes("Ticket Category Distribution") && (
          // filterTicketCategory === "no_data" ? (
          //    <div className="flex justify-center items-center h-full">
          //       <span style={{ fontSize: '16px', color: '#666' }}>No Data Available</span>
          //     </div>
          // ) : (
            renderTimeBasedCategoryChart()
          // )
        )}

        {/* NEW: Ticket Compliance by Module Chart */}
        {features.includes("Ticket Compilance by Module") && (
          renderTicketComplianceChart()
        )}

      </div>

      <style jsx global>{`
        div::-webkit-scrollbar {
          width: 8px;
        }
        div::-webkit-scrollbar-track {
          background: #f1f1f1;
          border-radius: 4px;
        }
        div::-webkit-scrollbar-thumb {
          background: #888;
          border-radius: 4px;
        }
        div::-webkit-scrollbar-thumb:hover {
          background: #555;
        }
      `}</style>
    </div>
  );
};
  // Updated renderControls to match SimsOverview alignment
  const renderControls = () => {

    return (
      <div className="flex justify-between items-center p-2 flex-wrap space-y-4 md:space-y-0">
        <div className="flex items-center gap-3 flex-wrap py-[10px]">
        <Select
          className="w-[200px]"
          styles={DropdownStyles}
          value={
            filterOptions.options.find(
              (option) => option.value === selectedFilter
            ) || null
          }
          onChange={(selectedOption) =>
            handleFilterChange(selectedOption?.value ?? "")
          }
          options={filterOptions.options}
          placeholder="Select Filter"
          isSearchable
          noOptionsMessage={() => "No options available"}
          components={{
              IndicatorSeparator: () => null
            }}
        />
          <span style={{ 
            fontFamily: "Calibri, sans-serif", 
            fontSize: "16px",
            whiteSpace: "nowrap" 
          }} className="dashboard-select-text">
            Select:
          </span>
          
          <div className="flex items-center gap-2">
            <button
              className={selectedButton === "Current Month" ? "save-btn !min-h-[40px]" : "email-dashboard-btns"}
              onClick={() => handleButtonClick("Current Month")}
              style={{
                fontFamily: "Calibri,sans-serif",
                fontSize: 12,
                padding: "0 12px",
                height: 38,
                // borderRadius: 7,
                minWidth: "60px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              Month
            </button>
            
            <button
              className={selectedButton === "Current Week" ? "save-btn !min-h-[40px]" : "email-dashboard-btns"}
              onClick={() => handleButtonClick("Current Week")}
              style={{
              fontFamily: "Calibri,sans-serif",
              fontSize: 12,
              padding: "0 12px",
              height: 38,
              // borderRadius: 7,
              minWidth: "60px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
            >
              Week
            </button>
            
            <button
              className={selectedButton === "Today" ? "save-btn !min-h-[40px]" : "email-dashboard-btns"}
              onClick={() => handleButtonClick("Today")}
              style={{
                fontFamily: "Calibri,sans-serif",
                fontSize: 12,
                padding: "0 12px",
                height: 38,
                // borderRadius: 7,
                minWidth: "60px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              Today
            </button>
          </div>
          
          <RangePicker
            value={dateRange}
            onChange={handleDateRangeChange}
            style={{ 
              height: "40px",
              width: "220px",
              fontFamily: "Calibri, sans-serif", 
            }}
            popupClassName="custom-range-popup"
            disabledDate={(current) => current && current > dayjs().endOf("day")}
          />
        </div>
        
        <div className="flex items-center gap-2">
          <DashboardRefresh tabName={"Zendesk Tracking"} onRefresh={initializeDashboard} tabKey={"zendesk"} />
          <DashboardColumnFilter tabName={"Zendesk Tracking"} setFeatures={setFeatures} />
        </div>
      </div>
    );
  };

  return (
    <>
      {loading ? (
        <div className="flex justify-center items-center h-screen">
          <Spin size="large" />
        </div>
      ) : (
        <Suspense fallback={<Spin size="large" />}>
          {renderControls()}
          <ZendeskTrackingCards
            selectedServiceProvider={selectedFilter}
            selectedTenantId={selectedTenantId}
            startDate={startDate}
            endDate={endDate}
            serviceProvider={selectedFilter === "All Tenants" ? "All" : selectedFilter}
            features={features}
          />
          {renderNewChartsWithScrolling()}
        </Suspense>
      )}
    </>
  );
};

export default ZendeskTracking;
