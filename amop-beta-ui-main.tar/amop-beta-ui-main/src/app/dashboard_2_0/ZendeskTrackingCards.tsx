import React, { useEffect, useState } from "react";
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import { Spin } from "antd";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";

interface ConfigTypes {
  title: string;
  height: number;
  width: number;
  count: number | string;
}

interface ZendeskTrackingCardsProps {
  selectedServiceProvider: string;
  startDate: string;
  endDate: string;
  serviceProvider: string;
  selectedTenantId: any;
  features: string[]
}

const ZendeskTrackingCards: React.FC<ZendeskTrackingCardsProps> = ({
  selectedServiceProvider,
  startDate,
  endDate,
  serviceProvider,
  selectedTenantId,
  features
}) => {
  const [loading, setLoading] = useState(false);
  const [datalog, setData] = useState<ConfigTypes[]>([]);
  const [rawData, setRawData] = useState<ConfigTypes[]>([]);
  const { token, partner, selectedDb, metaData, sessionId, username, role } = useAuth();

  // filter whenever features changes
      useEffect(() => {
        if (rawData.length > 0) {
          const filteredResults = rawData.filter((item) =>
            features.some((f) => f.trim().toLowerCase() === item.title.trim().toLowerCase())
          );
          setData(filteredResults);
        }
      }, [features, rawData]);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);

      try {
        const url = ENV_ROUTES.DASHBOARD;
        const requestData = {
          partner: partner,
          tenant_name: partner,
          start_date: startDate,
          end_date: endDate,
          tenant_id: selectedTenantId,
          role_name: role,
          username: username,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
        };

        const response = await axios.post(url, {
          data: { path: "/get_status_count_of_tickets", ...requestData },
        });

        const parsedData = JSON.parse(response.data.body);
        const { rows, height, width } = parsedData.data;

        const titleMap: Record<string, string> = {
          Volume: "Ticket Volume",
          Active: "Active Tasks",
          Inprogress: "In Progress Tickets",
          Closed: "Close Tickets",
        };

        const results = rows.map((row: any) => ({
          title: titleMap[row.Status] || row.Status,
          count: row.Count,
          height,
          width,
        }));

        setRawData(results);
      } catch (error) {
        console.error("Error fetching ticket status data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [token, selectedServiceProvider, startDate, endDate]);

  if (loading) {
    return (
       <div className="ml-1 py-2 px-6 w-full">
                       <div className="grid grid-cols-2 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                         <div className="col-span-4 flex justify-center items-center py-10">
                           <Spin size="large" />
                         </div>
                       </div>
                     </div>
    );
  }

  const isSmallScreen = typeof window !== "undefined" && window.innerWidth < 700;

  return (
    <div className="ml-1 py-2 px-6 w-full">
      <div className="grid grid-cols-2 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {datalog.map((item, index) => (
          <div
            key={index}
            className="chart w-full"
            style={
              isSmallScreen
                ? { width: "150px", height: "100px" }
                : { minHeight: "75px" }
            }
          >
            <div className="p-2 mt-0">
              <div className="flex flex-col sm:text-left text-center">
                <h2 style={{ fontFamily: "Calibri, sans-serif", fontSize: "18px" }}>
                  {item.title}
                </h2>
                <p className="chart-count">
                  <span style={{ fontSize: "18px" }}>{item.count}</span>
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ZendeskTrackingCards;
