import React, { useEffect, useState } from "react";
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import { Modal, Spin, Tooltip } from "antd";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { getCurrentDateTime } from "../components/header_constants";
import { ArrowPathIcon } from "@heroicons/react/24/outline";
import { useInventoryRedirectStore } from "../stores/inventoryRedirectStore";


interface DashboardRefreshProps {
    tabKey: string;
    tabName: string;
    onRefresh: () => void;
}

const DashboardRefresh: React.FC<DashboardRefreshProps> = ({
    tabName,
    tabKey,
    onRefresh,
}) => {
    const [loading, setLoading] = useState(false);
    const [lastSync, setLastSync] = useState<any>({});
    const { token, partner, selectedDb, metaData, sessionId, username, role, firstLastName } = useAuth();
    const { addTab, removeTab, tabNames } = useInventoryRedirectStore()

    // useEffect(() => {
    //     refreshPolling("initial")
    // }, [tabKey]);

    const refreshCache = async () => {
        setLoading(true)
        addTab(tabKey, tabName);
        try {
            const url = ENV_ROUTES.DASHBOARD;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/refresh_dashboard_all_caches",
                role_name: role,
                module_name: "Dashboard",
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                tab_name: tabKey || ""
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === false) {
                console.error("Error refreshing Cache:", parsedData.message ||
                    "An error occurred while refreshing dashboard. Please try again.");
            } else {
                const statusFlag = parsedData?.last_sync_date || "None";

                if (statusFlag && statusFlag !== "None") {
                    removeTab(tabKey)
                    setLastSync((prev: any) => ({
                        ...prev,
                        [tabKey]: statusFlag,
                    }));
                    onRefresh()
                    setLoading(false)
                }
                else {
                    refreshPolling("refresh")
                }
            }
        } catch (error) {
            console.error("Error fetching refresh data:", error);
            refreshPolling("refresh")
        } finally {
        }
    };
    const refreshCacheForUsageInsights = async () => {
        setLoading(true)
        addTab(tabKey, tabName);
        try {
            const url = ENV_ROUTES.DASHBOARD;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/sync_usage_insight",
                role_name: role,
                module_name: "Dashboard",
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                tab_name: tabKey || ""
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === false) {
                console.error("Error refreshing Cache:", parsedData.message ||
                    "An error occurred while refreshing dashboard. Please try again.");
            } else {
                const statusFlag = parsedData?.last_sync_date || "None";

                if (statusFlag && statusFlag !== "None") {
                    removeTab(tabKey)
                    setLastSync((prev: any) => ({
                        ...prev,
                        [tabKey]: statusFlag,
                    }));
                    onRefresh()
                    setLoading(false)
                }
                else {
                    refreshPolling("refresh")
                }
            }
        } catch (error) {
            console.error("Error fetching refresh data:", error);
            refreshPolling("refresh")
        } finally {
        }
    };

    const fetchLastSyncStatus = async (mode: string) => {
        // console.clear()
        // console.error("modeee", mode)
        try {
            // if (!tabNames.some((item) => item.key === tabKey)) {
            //     setLoading(true)
            //     addTab(tabKey, tabName)
            // }
            const url = ENV_ROUTES.DASHBOARD;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_dashboard_last_sync_time",
                role_name: role,
                module_name: "Dashboard",
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                tab_name: tabKey || ""
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === false) {
                console.error("Error refreshing Cache:", parsedData.message ||
                    "An error occurred while refreshing dashboard. Please try again.");
                return false
            } else {
                let statusFlag = "None"
                if (mode === "initial") {
                    statusFlag = parsedData?.last_sync_date || "None";
                }
                else {
                    statusFlag = parsedData?.recent_sync_date || "None";
                }

                if (statusFlag && statusFlag !== "None") {
                    setLastSync((prev: any) => ({
                        ...prev,
                        [tabKey]: statusFlag,
                    }));
                    onRefresh()
                    return true

                }
                else {
                    return false
                }
            }
        } catch (error) {
            console.error("Error fetching refresh data:", error);
            return false
        } finally {
        }
    };
    const refreshPolling = async (mode: string) => {
        const result = await fetchLastSyncStatus(mode);
        if (!result) {
            setTimeout(() => refreshPolling(mode), 30000); // Try again after 10 seconds
        } else {
            console.log("Refresh complete.");
            removeTab(tabKey)
            setLoading(false)

        }
    };

    const handleRefresh = () => {
        if (tabKey === "usage_insights") {
            refreshCacheForUsageInsights()
        }
        else {
            refreshCache()
        }
    }
    return (
        <div className="">
            {loading ? (
                <div className="flex items-center gap-2">
                    <ArrowPathIcon
                        className="w-6 h-6  animate-spin "
                    />
                </div>
            ) : (
                <div className="flex items-center gap-2">
                    <Tooltip title={lastSync[tabKey] ? lastSync[tabKey] : ""}>
                        <ArrowPathIcon
                            className="cursor-pointer w-6 h-6 dashboard-refresh-icon"
                            onClick={() => handleRefresh()}
                        />
                    </Tooltip>

                </div>
            )}
        </div>
    );
};

export default DashboardRefresh;
