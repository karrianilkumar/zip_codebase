"use client";
import React, { lazy, Suspense, useEffect, useState, ReactElement, useMemo } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "../components/auth_context";
import { useLogoStore } from "../stores/logoStore";
import { useInventoryRedirectStore } from "../stores/inventoryRedirectStore";
import {
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  ResponsiveContainer,
  AreaChart,
  Area,
  LabelList,
  CartesianGrid,
  Line,
  LineChart,
  ReferenceArea,
  ReferenceLine,
} from "recharts";
import { ResponsiveBar } from '@nivo/bar';
import { ResponsiveLine } from '@nivo/line';
import  { components, SingleValue } from "react-select";
// import { ParentSize } from '@visx/responsive';
// import {
//   XYChart,
//   Axis,
//   Grid,
//   LineSeries,
//   GlyphSeries,
// } from '@visx/xychart';
// import { curveMonotoneX } from 'd3-shape';
// import { useTooltip, TooltipWithBounds } from '@visx/tooltip';
// import { GlyphCircle } from '@visx/glyph';
// import { Group } from '@visx/group';
import { ENV_ROUTES } from "../components/routes/route_constants";
import axios from "axios";
import { getCurrentDateTime } from "../components/header_constants";
import { Button, DatePicker, Spin, Table, Tooltip as AntdTooltip } from "antd";
import Select from "react-select";
import { ChevronDownIcon, ArrowPathRoundedSquareIcon, ArrowTopRightOnSquareIcon } from "@heroicons/react/24/outline";
import moment from "moment";
import dayjs, { Dayjs } from "dayjs";
import DashboardColumnFilter from "./dashboardColumnFilter";
import DashboardRefresh from "./dashboardRefreshComponent";
import { DropdownStyles } from "../components/css/dropdown";

const SimOverviewCards = lazy(() => import("@/app/dashboard_2_0/SIMsOverviewCards"));

const { RangePicker } = DatePicker;

interface FilterOption {
  value: string;
  label: string;
  tenant_id: string;
}

interface FilterOptions {
  options: FilterOption[];
}

// NEW: Interface for service provider data
interface ServiceProviderData {
  unique_service_providers: string[];
  billing_period_dates: { [provider: string]: string[] };
}

interface ChartData {
  simVsServiceProvider: any | null;
  simActivationTrend: any | null;
  serviceProviderVsStatus: any | null;
}

interface ProcessedChartData {
  chartData: Array<{ service_provider: string; total: number }>;
  details: { [provider: string]: { [date: string]: number } };
}

interface ProcessedStackedBarData {
  chartData: Array<{ service_provider: string;[key: string]: number | string }>;
  details: { [provider: string]: { [date: string]: { [status: string]: number } } };
  categories: string[];
}

interface ProcessedTimeBasedData {
  chartData: Array<{ time: string;[provider: string]: number | string }>;
  details: { [timeLabel: string]: { [provider: string]: number } };
  serviceProviders: string[];
}

interface CustomTooltipProps {
  active?: boolean;
  payload?: Array<{ value: number; name: string; dataKey: string; color: string }>;
  label?: string;
  details?: { [provider: string]: { [date: string]: number | { [status: string]: number } } };
  isStatusChart?: boolean;
  chartType?: 'simVsService' | 'simActivation' | 'serviceVsStatus';
}

interface EnhancedResponsiveContainerProps {
  dataLength: number;
  height: number;
  children: ReactElement;
}

type ChartEntry = {
  service_provider: string;
  total?: number;
  [key: string]: number | string | undefined;
};

const STATUS_CATEGORIES = ["Activated", "Active", "Deactivated", "Suspended", "Retired"] as const;
type Status = typeof STATUS_CATEGORIES[number];

type ProviderStatusData = {
  details: {
    [date: string]: {
      [status in Status]: number;
    };
  };
} & {
  [status in Status]: number;
};

// Blue shades color palette for service providers in time-based chart
const BLUE_SHADE_COLORS = [
 "#74B9FF","#A29BFE","#FF7675","#81ECEC","#D980FA","#55EFC4","#FABE58","#00B894","#a16469","#00CEC9","#BDC3C7","#FFEAA7", "#6C5CE7", "#FD79A8",  "#1ABC9C" ];

// 🔹 Global persistent color map for service providers
const SERVICE_PROVIDER_COLORS: Record<string, string> =
  (window as any).SERVICE_PROVIDER_COLORS ||
  ((window as any).SERVICE_PROVIDER_COLORS = {});

const EnhancedResponsiveContainer: React.FC<EnhancedResponsiveContainerProps> = ({ dataLength, height, children }) => {
  return (
    <div style={{
      width: "100%",
      height: `${height}px`,
      overflow: "hidden",
      position: "relative"
    }}>
      <ResponsiveContainer width="100%" height={height}>
        {children}
      </ResponsiveContainer>
    </div>
  );
};

const wrapYAxisLabel = (label: string): string => {
  const maxLength = 18;
  if (label.length <= maxLength) return label;
  return label.substring(0, maxLength - 3) + "...";
};

// Helper functions for time-based processing
const getWeekNumber = (date: Date, monthStart: Date): number => {
  const dayDiff = Math.floor((date.getTime() - monthStart.getTime()) / (1000 * 60 * 60 * 24));
  return Math.floor(dayDiff / 7) + 1;
};

const getMonthName = (monthIndex: number): string => {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  return months[monthIndex];
};

// 1. First, add a utility function to convert month index to month name at the top of the file
const getMonthNameFromIndex = (monthIndex: string | number): string => {
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const index = typeof monthIndex === 'string' ? parseInt(monthIndex) : monthIndex;
  return monthNames[index] || monthIndex.toString();
};
const ALL_PROVIDERS: string[] = [];
const calculateNiceTicks = (min: number, max: number, forceZeroStart: boolean = true, tickCount: number = 6): number[] => {
  // For bar charts, always start from 0
  const actualMin = forceZeroStart ? 0 : min;
  
  if (actualMin === max) {
    if (max === 0) return [0, 5, 10, 15, 20, 25];
    return [0, Math.ceil(max / 4), Math.ceil(max / 2), Math.ceil(max * 0.75), max, Math.ceil(max * 1.2)];
  }

  // Add 10% padding above max
  const paddedMax = max + (max * 0.1);
  const range = paddedMax - actualMin;
  const roughStep = range / (tickCount - 1);
  
  // Calculate step size based on data magnitude
  let stepSize: number;
  if (paddedMax <= 50) {
    stepSize = 5;
  } else if (paddedMax <= 100) {
    stepSize = 10;
  } else if (paddedMax <= 500) {
    stepSize = 50;
  } else if (paddedMax <= 1000) {
    stepSize = 100;
  } else if (paddedMax <= 5000) {
    stepSize = 500;
  } else if (paddedMax <= 10000) {
    stepSize = 1000;
  } else if (paddedMax <= 50000) {
    stepSize = 5000;
  } else {
    stepSize = 10000;
  }
  
  const niceMax = Math.ceil(paddedMax / stepSize) * stepSize;
  
  const ticks: number[] = [];
  for (let tick = 0; tick <= niceMax; tick += stepSize) {
    ticks.push(tick);
  }
  
  return ticks;
};
// 3. FIX FOR MAX FILTER - Update your getDataMinMax function:
const getDataMinMax = (data: any[], dataKeys: string[]): { min: number; max: number } => {
  let min = Infinity;
  let max = -Infinity;
  
  data.forEach(item => {
    if (item.isGap) return; // Skip gap items
    
    dataKeys.forEach(key => {
      if (item[key] !== undefined && item[key] !== null && typeof item[key] === 'number') {
        min = Math.min(min, item[key]);
        max = Math.max(max, item[key]);
      }
    });
  });
  
  if (min === Infinity) min = 0;
  if (max === -Infinity) max = 100;
  
  // For max filter with very small values (like 1), ensure visible bars
  if (max <= 5) {
    max = 10; // Ensure minimum scale of 10 for visibility
  }
  
  if (min === max) {
    min = Math.max(0, min - 10);
    max = max + 10;
  }
  
  return { min, max };
};


const SimsOverview: React.FC = () => {
  const router = useRouter();
  const { username, partner, role, selectedDb,metaData, token, firstLastName, sessionId, setSelectedPartner } = useAuth();
  const setTitle = useLogoStore((state) => state.setTitle);
  const { setFilters, setRedirected, clearFilters } = useInventoryRedirectStore();
  const isDarkMode = document.documentElement.classList.contains("dark");
//  const [isDarkMode, setIsDarkMode] = useState(true);
  const [loading, setLoading] = useState<boolean>(false);
  const [filterOptions, setFilterOptions] = useState<FilterOptions>({ options: [] });
  const [selectedFilter, setSelectedFilter] = useState<string>(partner || "");
  const [selectedTenantId, setSelectedTenantId] = useState<string>("");
  // NEW: Service Provider and Billing Cycle states
  const [serviceProviders, setServiceProviders] = useState<string[]>([]);
  const [selectedServiceProvider, setSelectedServiceProvider] = useState<string>("All service providers");
  const [billingCyclePeriods, setBillingCyclePeriods] = useState<string[]>([]);
  const [selectedBillingCyclePeriod, setSelectedBillingCyclePeriod] = useState<string>("");
  const [showBillingCyclePeriod, setShowBillingCyclePeriod] = useState<boolean>(false);
  const [serviceProviderData, setServiceProviderData] = useState<ServiceProviderData | null>(null);
  const [selectedServiceProvider2, setSelectedServiceProvider2] =  useState("");
  const [selectedButton, setSelectedButton] = useState<string | null>("Current Month");
  const [startDate, setStartDate] = useState<string>(moment().startOf("month").format("YYYY-MM-DD"));
  const [endDate, setEndDate] = useState<string>(moment().format("YYYY-MM-DD"));
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([null, null]);
  const [flippedChart, setFlippedChart] = useState<number | null>(null);
  const [chartData, setChartData] = useState<ChartData>({
    simVsServiceProvider: null,
    simActivationTrend: null,
    serviceProviderVsStatus: null,
  });
  const [cachedData, setCachedData] = useState<ChartData>({
    simVsServiceProvider: null,
    simActivationTrend: null,
    serviceProviderVsStatus: null,
  });
  const [loadingSimVsServiceProvider, setLoadingSimVsServiceProvider] = useState<boolean>(true);
  const [loadingSimActivationTrend, setLoadingSimActivationTrend] = useState<boolean>(true);
  const [loadingServiceProviderVsStatus, setLoadingServiceProviderVsStatus] = useState<boolean>(true);
  const [useCache, setUseCache] = useState<boolean>(false);
  const [internalFilterSimVsService, setInternalFilterSimVsService] = useState<string>("1_month");
  const [internalFilterSimActivation, setInternalFilterSimActivation] = useState<string>("1_month");
  const [internalFilterServiceVsStatus, setInternalFilterServiceVsStatus] = useState<string>("1_month");
  const [isSmallMediumScreen, setIsSmallMediumScreen] = useState<boolean>(false);
  const [showRedirectNotification, setShowRedirectNotification] = useState<boolean>(false);
  const { totalFeatures, selectedFeatures } = useInventoryRedirectStore();
  const [features, setFeatures] = useState<any[]>([])
  // New state for horizontal expansion and animations
  const [isExpanded, setIsExpanded] = useState<boolean>(false);
  const [maxExpand, setMaxExpand] = useState<boolean>(false);
  const [isAnimating, setIsAnimating] = useState<boolean>(false);
const [legendVisible, setLegendVisible] = useState(false);
  const [showSIMVsProviderTooltip, setShowSIMVsProviderTooltip] = useState(false);
// Status multi-select dropdown state for status
const [selectedStatuses, setSelectedStatuses] = useState<string[]>([]);
const [uniqueStatuses, setUniqueStatuses] = useState<string[]>([]);
// useEffect(() => {
//   console.log("uniqueStatuses",uniqueStatuses)
//   if (uniqueStatuses.length > 0) {
//     // Only set if we haven't initialized yet or if uniqueStatuses changed
//     setSelectedStatuses(prev => {
//       if (prev.length === 0 || !prev.every(s => uniqueStatuses.includes(s))) {
//         return [...uniqueStatuses];
//       }
//       return prev;
//     });
//   }
// }, [uniqueStatuses]);

const [weekLabelFont, setWeekLabelFont] = useState(12);

useEffect(() => {
  const updateFontSize = () => {
    const width = window.innerWidth;
    const zoom = window.devicePixelRatio;

    if (width < 1366) {
      if (zoom > 1 && zoom <= 1.10) {
        setWeekLabelFont(6.5);   // 👈 slightly smaller for 110%
      }
      else if (zoom >= 1.10 && zoom <= 1.25) {
        setWeekLabelFont(5.8);   // 👈 even smaller for 125%
      }
      else {
        setWeekLabelFont(7);     // 👈 normal 100%
      }
    }
    else if (width < 1600) {
      setWeekLabelFont(9);
    } 
    else {
      setWeekLabelFont(10);
    }
  };

  updateFontSize();
  window.addEventListener("resize", updateFontSize);
  return () => window.removeEventListener("resize", updateFontSize);
}, []);


    const serviceProviderOptions = serviceProviders
    .filter(Boolean)
  .filter(provider => provider !== "All service providers")
  .map(provider => ({
    value: provider,
    label: provider,
  }));
  useEffect(() => {
    const handleResize = () => {
      setIsSmallMediumScreen(window.innerWidth <= 1000);
    };
    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  useEffect(() => {
    if (serviceProviders2.length > 0) {
    setSelectedServiceProvider2(serviceProviders2[0]);
  } else {
    setSelectedServiceProvider2("");
  }   // 🔥 THIS IS THE KEY FIX
  if (selectedTenantId) {
    fetchServiceProviderData();
  }
}, [selectedTenantId]);

  // NEW: Function to fetch service providers and billing cycle data
  const fetchServiceProviderData = async () => {
  if (!selectedTenantId) return;

  try {
    const url = ENV_ROUTES.DASHBOARD;
    const data = {
      tenant_name: partner || "default_value",
      username,
      firstLastName,
      path: "/get_all_service_providers_and_billing_cycle_dates_dropdown_data",
      role_name: role,
      parent_module: "Sim Management",
      module_name: "Dashboard",
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
      tenant_id: selectedTenantId,
    };

    const response = await axios.post(url, { data });
    const parsedData = JSON.parse(response.data.body);

    if (
      !parsedData.flag ||
      !Array.isArray(parsedData.unique_service_providers) ||
      parsedData.unique_service_providers.length === 0
    ) {
      setServiceProviders(["All service providers"]);
      return;
    }

    setServiceProviders(parsedData.unique_service_providers);
    setServiceProviderData(parsedData);
    setSelectedServiceProvider("All service providers");
    setShowBillingCyclePeriod(false);
    setSelectedBillingCyclePeriod("");

  } catch (err) {
    console.error("Service provider fetch failed:", err);
    setServiceProviders(["All service providers"]);
  }
};


  // NEW: Handle service provider change
  const handleServiceProviderChange = async (value?: string) => {
    // console.log("=== SERVICE PROVIDER CHANGE ===");
    // console.log("Selected service provider:", value);
    // console.log("Current serviceProviders2:", serviceProviders2);

    setSelectedServiceProvider(value || "");

    if (value !== "All service providers") {
   setSelectedServiceProvider2(value || "");
 } else {
   if (serviceProviders2.length > 0) {
     setSelectedServiceProvider2(serviceProviders2[0]);
   }
 }

    if (value === "All service providers") {
      setShowBillingCyclePeriod(false);
      setSelectedBillingCyclePeriod("");
      setBillingCyclePeriods([]);

      // const defaultStart = moment().startOf("month").format("YYYY-MM-DD");
      // const defaultEnd = moment().format("YYYY-MM-DD");
      // setSelectedButton("Current Month");
      // setStartDate(defaultStart);
      // setEndDate(defaultEnd);
      // setDateRange([dayjs(defaultStart), dayjs(defaultEnd)]);
    } else {
      setSelectedButton(null); // Removes Today/Week/Month selection
      setShowBillingCyclePeriod(true);
      if (!value) return; 
      if (serviceProviderData?.billing_period_dates[value]) {
        const periods = serviceProviderData.billing_period_dates[value];
        setBillingCyclePeriods(["None", ...periods]);
        // Set default to first period
        setSelectedBillingCyclePeriod(periods[0] || "");
      }
      // setStartDate("");
      // setEndDate("");
      // setDateRange([null, null]);
    }

    // Reset internal filters and fetch new data
    setInternalFilterSimVsService("1_month");
    setInternalFilterSimActivation("1_month");
    setInternalFilterServiceVsStatus("1_month");
    setUseCache(false);

    //  ✅ Clear date filters when billing cycle changed
    setStartDate("");
    setEndDate("");
    setDateRange([null, null]);

    // Clear cache
    localStorage.removeItem("simCounts_cache");
    localStorage.removeItem("activations_cache");
    localStorage.removeItem("status_cache");

    clearFilters();

  };

  // NEW: Handle billing cycle period change
  const handleBillingCyclePeriodChange = async (value: string) => {
    // console.log("=== BILLING CYCLE PERIOD CHANGE ===");
    // console.log("Selected billing cycle period:", value);

    setSelectedBillingCyclePeriod(value);
    // ✅ Clear date filters when billing cycle changed
    setStartDate("");
    setEndDate("");
    setDateRange([null, null]);
     if(value === "None"){
      setSelectedButton("Current Month");
    }
    else{
      setSelectedButton(null)
    }

    setUseCache(false);

    // Clear cache
    localStorage.removeItem("simCounts_cache");
    localStorage.removeItem("activations_cache");
    localStorage.removeItem("status_cache");

    clearFilters();

    // Fetch new data with billing cycle selection
    // if (selectedTenantId) {
    //   await fetchChartData("", "", true);
    // }
  };

  // NEW: Function to map global date filters to internal filters
  const mapGlobalDateToInternalFilter = (globalFilter: string): string => {
    switch (globalFilter) {
      case "Today":
        return "1_day";
      case "Current Week":
        return "5_day";
      case "Current Month":
        return "1_month";
      default:
        return "1_month";
    }
  };

  // **KEY FIX: Function to dynamically determine the correct filter from available data**
const getActualFilterFromData = (data: any, internalFilter: string): string => {
  // console.log("=== GET ACTUAL FILTER FROM DATA ===");
  // console.log("Internal filter requested:", internalFilter);
  // console.log("Available data:", data?.data?.data ? Object.keys(data.data.data) : 'No data');

  // ALWAYS return the requested internal filter for UI consistency
  // This ensures the filter buttons show the correct active state
  // regardless of data availability
  return internalFilter;
};





const getWeekOfMonth = (d: dayjs.Dayjs) => {
  return Math.ceil(d.date() / 7); // simple week of month
};

const processTimeBasedChartData = (
  data: any,
  filter: string,
  tenantId: string,
  chartType: "simVsService" | "simActivation" | "serviceVsStatus"
): ProcessedTimeBasedData => {

  if (!data?.data?.data?.[filter] || !data?.meta?.providers) {
    return { chartData: [], details: {}, serviceProviders: [] };
  }

  const providers = data.meta.providers as Record<string, string>;
  const serviceProviders = Object.values(providers);

  let filtered = data.data.data[filter];
  if (tenantId !== "All") {
    filtered = filtered.filter((d: any) => String(d.tenant_id) === tenantId);
  }

  const details: Record<string, Record<string, number>> = {};
  const bucketDate: Record<string, string | null> = {};

  // ---------------------------------------------------
  // LOOP through all providers + their records
  // ---------------------------------------------------
  filtered.forEach((item: any) => {
    const providerName = providers[String(item.provider_id)];
    if (!providerName) return;

    item.records?.forEach((rec: any) => {
      const raw = Array.isArray(rec) ? rec[0] : Object.keys(rec)[0];
      const value = Array.isArray(rec) ? Number(rec[1]) : Number(rec[raw]);

      // ---------------------------------------------------
      // CASE 1: YEAR-ONLY VALUE (e.g. "2021", "2024")
      // ---------------------------------------------------
      const isYearOnly = /^\d{4}$/.test(raw);

      if (isYearOnly) {
        const label = raw; // Use YEAR directly

        if (!details[label]) {
          details[label] = {};
          serviceProviders.forEach((sp) => (details[label][sp] = 0));
        }

        details[label][providerName] = value;
        bucketDate[label] = raw;

        return; // IMPORTANT → do NOT process week logic
      }

      // ---------------------------------------------------
      // CASE 2: DAILY/MONTHLY DATA → WEEK BUCKET
      // ---------------------------------------------------
     
// ---------------------------------------------------
// CASE 2: DAILY/MONTHLY DATA →
//   IF 1_day → KEEP EXACT TIME
//   ELSE → WEEK BUCKET
// ---------------------------------------------------
const d = dayjs(raw);

let label = raw; // default keep original timestamp
let normalized = raw;

// 5_day & beyond use weekly grouping
// FIX for 5D: Keep each day separate (NO WEEK BUCKET)
if (filter === "5_day") {
  label = d.format("YYYY-MM-DD");  // Unique day
  normalized = label;
}
//  For all filters except 1D & 5D → Use weekly grouping
else if (filter !== "1_day") {
  const week = getWeekOfMonth(d);
  const monthIndex = d.month().toString().padStart(2, "0");
  label = `${monthIndex}-W${week}`;
  normalized = d.format("YYYY-MM-DD");
}


if (!details[label]) {
  details[label] = {};
  serviceProviders.forEach((sp) => (details[label][sp] = 0));
}

details[label][providerName] = value;

// Save original date (for 1D tooltip + axis)
bucketDate[label] = raw;


      details[label][providerName] = value;

      if (!bucketDate[label]) bucketDate[label] = normalized;
      else if (dayjs(normalized).isBefore(bucketDate[label]!)) {
        bucketDate[label] = normalized;
      }
    });
  });

  // ---------------------------------------------------
  // SORTING: YEAR labels first, week labels correctly
  // ---------------------------------------------------
  const sortedLabels = Object.keys(details).sort((a, b) => {

    const yearPattern = /^\d{4}$/;

    const isYearA = yearPattern.test(a);
    const isYearB = yearPattern.test(b);

    // Sort pure years numerically
    if (isYearA && isYearB) {
      return Number(a) - Number(b);
    }

    // Sort week-based labels
    if (a.includes("-W") && b.includes("-W")) {
      const [mA, wA] = a.split("-W").map(Number);
      const [mB, wB] = b.split("-W").map(Number);

      if (mA !== mB) return mA - mB;
      return wA - wB;
    }

    // Keep different types as-is
    return 0;
  });

  // ---------------------------------------------------
  // FINAL chartData format
  // ---------------------------------------------------
  const chartData = sortedLabels.map((label) => {
    const row: any = {
      time: label,
      firstDate: bucketDate[label] || null,
    };

     serviceProviders.forEach((sp) => {
      row[sp] = details[label][sp] ?? 0;
  });

    return row;
  });

  return { chartData, details, serviceProviders };
};

const processTimeBasedBarChartData = (
  data: any,
  filter: string,
  tenantId: string,
  chartType: "simVsService" | "simActivation" | "serviceVsStatus"
): ProcessedTimeBasedData => {

  if (!data?.data?.data?.[filter] || !data?.meta?.providers) {
    return { chartData: [], details: {}, serviceProviders: [] };
  }

  const providers = data.meta.providers as Record<string, string>;
  const serviceProviders = Object.values(providers);

  // Filter tenant
  let filtered = data.data.data[filter];
  if (tenantId !== "All") {
    filtered = filtered.filter((d: any) => String(d.tenant_id) === tenantId);
  }

  const details: Record<string, Record<string, number>> = {};
  const bucketDate: Record<string, Date> = {}; // IMPORTANT → real dates stored here

  const getWeekOfMonth = (d: dayjs.Dayjs) => {
    const day = d.date();
    if (day <= 7) return 1;
    if (day <= 14) return 2;
    if (day <= 21) return 3;
    return 4;
  };

  // ---------------------------------------------------
  // MAIN PARSING LOOP
  // ---------------------------------------------------
  filtered.forEach((item: any) => {
    const providerName = providers[String(item.provider_id)];
    if (!providerName) return;

    item.records?.forEach((rec: any) => {
      const raw = Array.isArray(rec) ? rec[0] : Object.keys(rec)[0];
      const value = Array.isArray(rec) ? Number(rec[1]) : Number(rec[raw]);

      const isYear = /^\d{4}$/.test(raw);

      // ---------- CASE 1: YEAR level data ----------
      if (isYear) {
        const label = raw;

        if (!details[label]) {
          details[label] = {};
          serviceProviders.forEach(sp => (details[label][sp] = 0));
        }

        details[label][providerName] = value;
        bucketDate[label] = new Date(`${raw}-01-01`); // REAL sortable date

        return;
      }

      // ---------- CASE 2: DAY-LEVEL data ----------
      const d = dayjs(raw);
      let label = raw;
      let realDate = d.toDate(); // ALWAYS store real date

      // 1D → keep exact time
      if (filter === "1_day") {
        label = raw;
      }
      // 5D → keep each day
      else if (filter === "5_day") {
        label = d.format("YYYY-MM-DD");
      }
      // Weekly buckets for 1M, 3M, 6M, 1Y
      else {
        const week = getWeekOfMonth(d);
        const year = d.year();
        const monthIndex = String(d.month() + 1).padStart(2, "0");
        label = `${year}-${monthIndex}-W${week}`;
      }

      if (!details[label]) {
        details[label] = {};
        serviceProviders.forEach(sp => (details[label][sp] = 0));
      }

      details[label][providerName] = value;

      // Store earliest date for correct sorting
      if (!bucketDate[label] || realDate < bucketDate[label]) {
        bucketDate[label] = realDate;
      }
    });
  });

  // ---------------------------------------------------
  // 🔥 PERFECT SORTING using REAL DATES
  // ---------------------------------------------------
  const sortedLabels = Object.keys(details).sort((a, b) => {
    return bucketDate[a].getTime() - bucketDate[b].getTime();
  });

  // ---------------------------------------------------
  // Build final usable chart data
  // ---------------------------------------------------
  const chartData = sortedLabels.map(label => {
    const row: any = { time: label, firstDate: bucketDate[label] };

    serviceProviders.forEach(sp => {
      row[sp] = details[label][sp] ?? 0;
    });

    return row;
  });

  return { chartData, details, serviceProviders };
};

 

  // Updated click handler for chart interactions
const handleChartClick = (
  data: any,
  chartType: "simVsService" | "simActivation" | "serviceVsStatus",
  timeData?: any
) => {
  // console.log("=== CHART CLICK HANDLER START ===");
  // console.log("Chart type:", chartType);
  // console.log("Clicked data:", data);
  // console.log("Time data:", timeData);
  // console.log("Current partner:", partner);
  // console.log("Selected filter:", selectedFilter);

  if (selectedFilter !== partner) {
    console.log("⚠️ Redirection blocked: Partner mismatch");
    setRedirected(false);
    return;
  }

  if (!timeData?.time) {
    console.log("⚠️ No valid time data");
    setRedirected(false);
    return;
  }

  setShowRedirectNotification(true);

  // Determine current internal filter
  let currentFilter = internalFilterSimVsService;
  if (chartType === "simActivation") currentFilter = internalFilterSimActivation;
  if (chartType === "serviceVsStatus") currentFilter = internalFilterServiceVsStatus;
  if (chartType === "simVsService") currentFilter = internalFilterSimVsService

  const rawTime = timeData.time; // "09-W3" or "W2"
  let dateRange: any = null;

  try {
    if (currentFilter === "1_month") {
      // Extract only week (W1, W2...) for 1 month filter
      const weekOnly = rawTime.includes("-W")
        ? "W" + rawTime.split("-W")[1]
        : rawTime;

      console.log("Converting using weekOnly:", weekOnly);
      dateRange = convertTimeToDateRange(weekOnly, currentFilter);

    } else {
      // Extract month-week for 3M/6M/1Y filters
      const [monthStr, weekStr] = rawTime.split("-W");
      const month = parseInt(monthStr);
      const week = parseInt(weekStr);

      console.log(`Converting using month=${month}, week=${week}`);
      dateRange = convertTimeToDateRange({ month, week }, currentFilter);
    }
  } catch (err) {
    console.log("❌ Error converting time:", err);
    setRedirected(false);
    setShowRedirectNotification(false);
    return;
  }

  if (!dateRange) {
    console.log("❌ Invalid date range conversion");
    setRedirected(false);
    setShowRedirectNotification(false);
    return;
  }

  let filtersPayload: any = {};

  if (chartType === "simActivation") {
    filtersPayload.date_activated = [
      `${dateRange.start_date}:${dateRange.end_date}`,
    ];
  } else {
    filtersPayload.created_date = [
      `${dateRange.start_date}:${dateRange.end_date}`,
    ];
  }

  // console.log("📌 Final Filter Payload:", filtersPayload);

  sessionStorage.setItem("inventoryRedirected", "true");
  setFilters(filtersPayload);
  setRedirected(true);

  setTimeout(() => {
    setShowRedirectNotification(false);
    router.push("sim_management/inventory");
  }, 1000);
};


// 2. ADD this new helper function (add after handleChartClick function)
const convertTimeToDateRange = (
  timeData: string | { month?: number; week: number },
  filter: string
) => {
  const year = new Date().getFullYear();

  // Case: string input for 1-month "W3" format
  if (typeof timeData === "string" && timeData.startsWith("W")) {
    const week = parseInt(timeData.replace("W", ""), 10);

    return calculateRange({
      year,
      month: new Date().getMonth() + 1, // CURRENT month
      week,
    });
  }

  // Case: month-week object → { month: X, week: Y }
  if (typeof timeData === "object" && timeData.month) {
    return calculateRange({
      year,
      month: timeData.month + 1, // correct month from chart data
      week: timeData.week,
    });
  }

  console.error("❌ Unsupported timeData format:", timeData);
  return null;
};


// Core logic — this is the main correct logic now!!!
const calculateRange = ({
  year,
  month, // 1-12 EXACTLY from raw data
  week,  // 1-5
}: {
  year: number;
  month: number;
  week: number;
}) => {
  // Your exact week split logic:
  let startDay = 1 + (week - 1) * 7;
  let endDay = startDay + 6;

  const daysInMonth = new Date(year, month, 0).getDate();
  if (endDay > daysInMonth) endDay = daysInMonth;

  const pad = (n: number) => n.toString().padStart(2, "0");

  return {
    start_date: `${year}-${pad(month)}-${pad(startDay)}`,
    end_date: `${year}-${pad(month)}-${pad(endDay)}`,
  };
};


const getDateRangeFromMonthWeek = (month: number, week: number, year: number) => {
  // month is 1-based from backend (1 = Jan, 9 = Sep)
  const monthIndex = month - 1;

  // Last day of that month (28, 29, 30 or 31)
  const lastDayOfMonth = new Date(year, monthIndex + 1, 0).getDate();

  let startDay: number;
  let endDay: number;

  switch (week) {
    case 1:
      startDay = 1;
      endDay = 7;
      break;
    case 2:
      startDay = 8;
      endDay = 14;
      break;
    case 3:
      startDay = 15;
      endDay = 20;
      break;
    case 4:
      startDay = 21;
      endDay = 27;
      break;
    case 5:
      startDay = 28;
      endDay = lastDayOfMonth; // 28–30 or 28–31 depending on month
      break;
    default:
      // Fallback to full month if week is invalid
      startDay = 1;
      endDay = lastDayOfMonth;
  }

  // Ensure we don't go beyond the real last day of the month
  if (endDay > lastDayOfMonth) {
    endDay = lastDayOfMonth;
  }

  // ⚠️ IMPORTANT: Build YYYY-MM-DD manually to avoid timezone / ISO shifting (14 vs 15 issue)
  const pad = (n: number) => n.toString().padStart(2, "0");

  const start_date = `${year}-${pad(month)}-${pad(startDay)}`;
  const end_date = `${year}-${pad(month)}-${pad(endDay)}`;

  return { start_date, end_date };
};

const getWeekRangeOfCurrentMonth = (week: number, year: number) => {
  const now = new Date();
  const monthIndex = now.getMonth(); // current month index (0–11)
  const month = monthIndex + 1;

  let startDay: number;
  let endDay: number;

  switch (week) {
    case 1:
      startDay = 1;
      endDay = 7;
      break;
    case 2:
      startDay = 8;
      endDay = 14;
      break;
    case 3:
      startDay = 15;
      endDay = 20;
      break;
    case 4:
      startDay = 21;
      endDay = 27;
      break;
    case 5:
      startDay = 28;
      // compute real last day for current month
      endDay = new Date(year, monthIndex + 1, 0).getDate();
      break;
    default:
      startDay = 1;
      endDay = new Date(year, monthIndex + 1, 0).getDate();
  }

  const pad = (n: number) => n.toString().padStart(2, "0");

  return {
    start_date: `${year}-${pad(month)}-${pad(startDay)}`,
    end_date: `${year}-${pad(month)}-${pad(endDay)}`
  };
};



  // Custom Tick Components for Proper Month-Week Grouping
  const CustomGroupedXAxisTick = (props: any) => {
    const { x, y, payload, index } = props;
    const filter = startDate && endDate && !useCache ?
      getActualFilterFromData(useCache ? cachedData.simVsServiceProvider : chartData.simVsServiceProvider, internalFilterSimVsService)
      : internalFilterSimVsService;
    const shouldShowDualXAxis = ["3_month", "6_month", "1_year"].includes(filter);

    if (!shouldShowDualXAxis) {
      return (
        <g transform={`translate(${x},${y})`}>
          <text x={0} y={0} dy={16} textAnchor="middle" fill="#666" fontSize="12">
            {payload.value}
          </text>
        </g>
      );
    }

    // For dual axis, show only week numbers (W1, W2, etc.)
    const [monthIndex, weekPart] = payload.value.split('-W');
    return (
      <g transform={`translate(${x},${y})`}>
        <text x={0} y={0} dy={16} textAnchor="middle" fill="#666" fontSize="10">
          W{weekPart}
        </text>
      </g>
    );
  };

  const CustomMonthXAxisTick = (props: any) => {
    const { x, y, payload, index, visibleTicksCount } = props;
    const filter = startDate && endDate && !useCache ?
      getActualFilterFromData(useCache ? cachedData.simVsServiceProvider : chartData.simVsServiceProvider, internalFilterSimVsService)
      : internalFilterSimVsService;
    const shouldShowDualXAxis = ["3_month", "6_month", "1_year"].includes(filter);

    if (!shouldShowDualXAxis || !payload.value.includes('-W')) return null;

    const [monthIndex, week] = payload.value.split('-W');

    // Only show month name for W1 of each month
    if (week !== '1') return null;

    const monthName = getMonthName(parseInt(monthIndex));

    return (
      <g transform={`translate(${x},${y})`}>
        <text x={0} y={0} dy={30} textAnchor="middle" fill="#333" fontSize="12" fontWeight="bold" >
          {monthName}
        </text>
      </g>
    );
  };


  // Enhanced Time-based tooltip with smaller size and all providers
const TimeBasedTooltip = ({ active, payload, label, filter, fullData }: any) => {
  if (!active || !payload || payload.length === 0) return null;

  // Check if this is a gap
  if (payload[0]?.payload?.isGap) return null;

  let displayLabel = label;

  // Format the label based on filter type
  if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(label)) {
    // 1_day filter: "YYYY-MM-DDTHH:MM:SS"
    const timePart = label.split("T")[1].slice(0, 5);
    displayLabel = timePart;
  } else if (/^\d{4}-\d{2}-\d{2}$/.test(label)) {
    // 5_day filter: "YYYY-MM-DD"
    const [year, month, day] = label.split("-");
    const dateObj = new Date(Number(year), Number(month) - 1, Number(day));
    const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
                        "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
    displayLabel = `${monthNames[dateObj.getMonth()]} ${day}`;
  } else if (label.includes("-W")) {
    // Weekly format: "MM-Wxx"
    const [monthIndex, week] = label.split("-W");
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const monthName = monthNames[parseInt(monthIndex)] || monthIndex;
    displayLabel = `${monthName}-W${week}`;
  }

  return (
    <div
      style={{
        backgroundColor: "white",
        border: "1px solid #ccc",
        borderRadius: "8px",
        padding: "10px",
        boxShadow: "0 2px 8px rgba(0,0,0,0.15)",
        minWidth:"180px",
        maxWidth:"240px"
      }}
    >
      <p
        style={{
          margin: 0,
          marginBottom: "8px",
          fontWeight: "normal",
          fontSize: "14px",
          borderBottom: "1px solid #eee",
          paddingBottom: "5px",
        }}
      >
        {displayLabel}
      </p>
     {payload
  .filter((entry: any) => {
    const value = entry.value;
    return value !== 0 && value !== null && value !== undefined;
  })
  .map((entry: any, index: number) => (
    <div
      key={`item-${index}`}
      style={{
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        marginBottom: "6px",
        width: "180px", // increased width for alignment
        whiteSpace: "nowrap",
      }}
    >
      {/* Left: dot + provider name */}
      <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
        <div
          style={{
            width: "12px",
            height: "12px",
            backgroundColor: entry.color,
            borderRadius: "2px",
            flexShrink: 0,
          }}
        />
        <span style={{ fontSize: "12px", fontFamily: "Calibri, sans-serif" }}>
          {entry.name}
        </span>
      </div>

      {/* Right: number aligned cleanly */}
      <span
        style={{
          fontSize: "12px",
          // fontWeight: 600,
          textAlign: "right",
          minWidth: "40px",
          paddingLeft: "10px",
        }}
      >
        {Number(entry.value).toLocaleString()}
      </span>
    </div>
  ))}

    </div>
  );
};
const CustomLegendWithTooltip = ({ 
  serviceProviders, 
  colorMap 
}: { 
  serviceProviders: string[]; 
  colorMap: Record<string, string> 
}) => {
  const [hoveredProvider, setHoveredProvider] = useState<string | null>(null);

  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        // justifyContent: 'flex-end',
        // flexDirection: 'row-reverse',
        flexWrap: 'wrap',
        gap: '12px',
        padding: '10px',
        fontSize: '12px',
        fontFamily: 'Calibri, sans-serif',
        position: 'relative',
        zIndex: 9999
      }}
    >
      {serviceProviders.map((provider) => (
        <div
          key={provider}
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '6px',
            cursor: 'pointer',
            position: 'relative',
          }}
          // onMouseEnter={() => setHoveredProvider(provider)}
          // onMouseLeave={() => setHoveredProvider(null)}
        >
          <div
            style={{
              width: '10px',
              height: '10px',
              borderRadius: '2px',
              backgroundColor: colorMap[provider] || '#74B9FF',
            }}
          />
          <span>{provider}</span>

          {/* {hoveredProvider === provider && (
            <div
              style={{
                position: 'absolute',
                bottom: '100%',
                left: '0',
                marginBottom: '8px',
                backgroundColor: 'white',
                border: '1px solid #ccc',
                borderRadius: '4px',
                padding: '6px 10px',
                whiteSpace: 'nowrap',
                fontSize: '11px',
                boxShadow: '0 2px 8px rgba(0, 0, 0, 0.15)',
                zIndex: 9999,
              }}
            >
              <div style={{ fontWeight: 'bold', marginBottom: '2px' }}>
                {provider}
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <div
                  style={{
                    width: '8px',
                    height: '8px',
                    borderRadius: '50%',
                    backgroundColor: colorMap[provider] || '#74B9FF',
                  }}
                />
                <span>{provider}</span>
              </div>
            </div>
          )} */}
        </div>
      ))}
    </div>
  );
};


  const renderRedirectNotification = () => {
    if (!showRedirectNotification) return null;

    return (
      <div
        style={{
          position: 'fixed',
          top: '50%',
          left: '50%',
          transform: 'translate(-50%, -50%)',
          backgroundColor: 'white',
          padding: '20px 30px',
          borderRadius: '8px',
          boxShadow: '0 4px 12px rgba(0, 0, 0, 0.15)',
          zIndex: 9999,
          display: 'flex',
          alignItems: 'center',
          gap: '12px',
          border: '1px solid #e5e7eb'
        }}
      >
        <Spin size="small" />
        <span style={{
          fontFamily: 'Calibri, sans-serif',
          fontSize: '16px',
          fontWeight: '500',
          color: '#374151'
        }}>
          Redirecting to Inventory...
        </span>
      </div>
    );
  };

  const renderRedirectOverlay = () => {
    if (!showRedirectNotification) return null;

    return (
      <div
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          backgroundColor: 'rgba(0, 0, 0, 0.3)',
          zIndex: 9998
        }}
      />
    );
  };

  const fetchFilterOptions = async () => {
    try {
      const url = ENV_ROUTES.DASHBOARD;
      const data = {
        tenant_name: partner || "default_value",
        username,
        firstLastName,
        path: "/get_all_related_tenants",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Dashboard",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (!parsedData.flag || !parsedData.data) {
        console.warn("Invalid filter options response:", parsedData);
         setFilterOptions({ options: [] });
        setSelectedFilter("");
        setSelectedTenantId("");
        return;
      }

      const serviceProviders: FilterOption[] = Object.entries(parsedData.data)
  .map(([key, value]) => ({
    value: key.trim(),
    label: key.trim(),
    tenant_id: String(value),
  }))
  .sort((a, b) => a.label.localeCompare(b.label));

      setFilterOptions({ options: serviceProviders });

      const partnerOption = serviceProviders.find((option) => option.value === partner);
      if (partnerOption) {
        setSelectedFilter(partnerOption.value);
        setSelectedTenantId(partnerOption.tenant_id);
        localStorage.setItem("selectedTenantId", partnerOption.tenant_id);
      } else if (serviceProviders.length > 0) {
        setSelectedFilter(serviceProviders[0].value);
        setSelectedTenantId(serviceProviders[0].tenant_id);
         localStorage.setItem(
    "selectedTenantId",
    serviceProviders[0].tenant_id
  );
      }

    } catch (error) {
      console.error("Error fetching filter options:", error);
      setFilterOptions({ options: [] });
    setSelectedFilter("");
    setSelectedTenantId("");
    }
  };

  const fetchChartData = async (startDate: string, endDate: string, cacheData: boolean = false) => {
    // console.log("=== FETCH CHART DATA START ===");
    // console.log("Fetch parameters:", { startDate, endDate, cacheData, selectedTenantId });

    if (!selectedTenantId) {
      console.warn("No tenant_id set, skipping chart data fetch");
      return;
    }

    const url = ENV_ROUTES.DASHBOARD;
    const serviceProvidersFilter = selectedFilter === "All Tenants" ? "All" : selectedFilter;
    // console.log("Request configuration:", {
    //   url,
    //   serviceProvidersFilter,
    //   selectedFilter,
    //   selectedTenantId
    // });

    const baseRequestData = {
      partner,
      tenant_name: partner || "default_value",
      username,
      role_name: role,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
      start_date: startDate,
      end_date: endDate,
      tenant_id: selectedTenantId,
      service_provider: selectedServiceProvider === "All service providers" ? "" : selectedServiceProvider,
      billing_cycle_end_period: selectedBillingCyclePeriod === "None" || selectedServiceProvider === "All service providers" ? "" : selectedBillingCyclePeriod,
    };

    const fetchDataForPath = async (path: string) => {
      try {
        const response = await axios.post(url, {
          data: { ...baseRequestData, path },
        });
        const parsedResponse = JSON.parse(response.data.body);
        // console.log(`Data for ${path}:`, parsedResponse);
        return parsedResponse;
      } catch (error) {
        console.error(`Error fetching data for ${path}:`, error);
        return null;
      }
    };

    try {
      console.log("Making API calls...");
      setLoadingSimVsServiceProvider(true);
      setLoadingSimActivationTrend(true);
      setLoadingServiceProviderVsStatus(true);

      const [simVsServiceProvider, simActivationTrend, serviceProviderVsStatus] = await Promise.all([
        fetchDataForPath("/get_sim_count_by_service_provider"),
        fetchDataForPath("/get_sim_activations_by_service_provider"),
        fetchDataForPath("/get_service_provider_vs_status"),
      ]);

      // console.log("API Response flags:", {
      //   simVsServiceProvider: simVsServiceProvider?.flag,
      //   simActivationTrend: simActivationTrend?.flag,
      //   serviceProviderVsStatus: serviceProviderVsStatus?.flag
      // });

      const newChartData = {
        simVsServiceProvider: simVsServiceProvider?.flag ? simVsServiceProvider : null,
        simActivationTrend: simActivationTrend?.flag ? simActivationTrend : null,
        serviceProviderVsStatus: serviceProviderVsStatus?.flag ? serviceProviderVsStatus : null,
      };

      if (cacheData) {
        setCachedData(newChartData);
        localStorage.setItem("simCounts_cache", JSON.stringify({
          ...newChartData.simVsServiceProvider,
          lastUpdated: new Date().toISOString()
        }));
        localStorage.setItem("activations_cache", JSON.stringify({
          ...newChartData.simActivationTrend,
          lastUpdated: new Date().toISOString()
        }));
        localStorage.setItem("status_cache", JSON.stringify({
          ...newChartData.serviceProviderVsStatus,
          lastUpdated: new Date().toISOString()
        }));
        setChartData(newChartData);
        
      } else {
        setChartData(newChartData);
       
      }
    } catch (error) {
      console.error("Error fetching chart data:", error);
    } finally {
      setLoadingSimVsServiceProvider(false);
      setLoadingSimActivationTrend(false);
      setLoadingServiceProviderVsStatus(false);
    }
  };

  const checkCacheValidity = () => {
    const caches = ["simCounts_cache", "activations_cache", "status_cache"];
    return caches.every(cacheKey => {
      const cached = localStorage.getItem(cacheKey);
      if (!cached) return false;
      const { lastUpdated } = JSON.parse(cached);
      const lastUpdatedDate = new Date(lastUpdated);
      const now = new Date();
      const hoursDiff = (now.getTime() - lastUpdatedDate.getTime()) / (1000 * 60 * 60);
      return hoursDiff < 24;
    });
  };

  const initializeDashboard = async () => {
    setSelectedPartner(true);
    setSelectedButton("Current Month");
    setDateRange([null, null]);
    setLoading(true);
    try {
      await fetchFilterOptions();
      // await fetchServiceProviderData(); // NEW: Fetch service provider data
      if (selectedTenantId) {
        const isCacheValid = checkCacheValidity();
        // if (isCacheValid) {
        //   const simCounts = JSON.parse(localStorage.getItem("simCounts_cache") || "{}");
        //   const activations = JSON.parse(localStorage.getItem("activations_cache") || "{}");
        //   const status = JSON.parse(localStorage.getItem("status_cache") || "{}");
        //   setCachedData({
        //     simVsServiceProvider: simCounts,
        //     simActivationTrend: activations,
        //     serviceProviderVsStatus: status,
        //   });
        //   setChartData({
        //     simVsServiceProvider: simCounts,
        //     simActivationTrend: activations,
        //     serviceProviderVsStatus: status,
        //   });
        //   setUseCache(true);
        // } else {
          await fetchChartData("", "", true);
        // }
      }
    } catch (error) {
      console.error("Error during initialization:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    initializeDashboard();
  }, [partner]);

  useEffect(() => {
    if (selectedTenantId && !useCache) {
      localStorage.removeItem("simCounts_cache");
      localStorage.removeItem("activations_cache");
      localStorage.removeItem("status_cache");
      fetchChartData("", "", true);
    }
  }, [selectedTenantId]);
  // Whenever selectedButton changes, update ALL internal filters.
    // Sync internal filters with global filter selection
 useEffect(() => {
   console.log(`=== GLOBAL FILTER SYNC ===`);
   console.log(`Selected Button: ${selectedButton}, Start Date: ${startDate}, End Date: ${endDate}`);
 
   if (selectedButton) {
     const internal = mapGlobalDateToInternalFilter(selectedButton);
      
    setInternalFilterSimVsService(internal);
      setInternalFilterSimActivation(internal);
      setInternalFilterServiceVsStatus(internal);
     setUseCache(false);
     clearFilters();
     
     fetchChartData(startDate, endDate, false);
   } else if (startDate && endDate) {
     setUseCache(false);
     fetchChartData(startDate, endDate, false);
   }
 }, [selectedButton, startDate, endDate]);
  // Add:
  useEffect(() => {
    // Only fetch if you have a valid period for the currently selected provider
    if (
      selectedTenantId &&
      ((selectedServiceProvider !== "All service providers" && selectedBillingCyclePeriod) ||
        selectedServiceProvider === "All service providers")
    ) {
      fetchChartData("", "", true);
    }
  }, [selectedServiceProvider, selectedBillingCyclePeriod, selectedTenantId]);


  // For simVsServiceProvider
  const filterSimVsService = startDate && endDate && !useCache
    ? getActualFilterFromData(
      useCache ? cachedData.simVsServiceProvider : chartData.simVsServiceProvider,
      internalFilterSimVsService
    )
    : internalFilterSimVsService;

  // For simActivationTrend
  const filterSimActivation = startDate && endDate && !useCache
    ? getActualFilterFromData(
      useCache ? cachedData.simActivationTrend : chartData.simActivationTrend,
      internalFilterSimActivation
    )
    : internalFilterSimActivation;
  // For simVsServiceProvider
  const filterSimVsServiceProvider = startDate && endDate && !useCache
    ? getActualFilterFromData(
      useCache ? cachedData.simVsServiceProvider : chartData.simVsServiceProvider,
      internalFilterServiceVsStatus
    )
    : internalFilterServiceVsStatus;
  // Auto-expand for 3M, 6M, and 1Y
  useEffect(() => {
    const shouldExpand =
      ["3_month", "6_month", "1_year", "max"].includes(filterSimVsService) ||
      ["3_month", "6_month", "1_year", "max"].includes(filterSimActivation)

    const maxExpand = ["max"].includes(filterSimVsServiceProvider) || ["max"].includes(filterSimActivation);

    setMaxExpand(maxExpand);
    setIsExpanded(shouldExpand);
  }, [filterSimVsService, filterSimActivation, filterSimVsServiceProvider]);

  const handleFilterChange = async (value: string) => {
    // console.log("=== HANDLE FILTER CHANGE START ===");
    // console.log("Changing filter to:", value);

    const selectedOption = filterOptions.options.find((option) => option.value === value);
    // console.log(" Selected option:", selectedOption);

    if (selectedOption) {
      setSelectedFilter(selectedOption.value);
      setSelectedTenantId(selectedOption.tenant_id);
      setServiceProviders([]);
setSelectedServiceProvider("All service providers");
setServiceProviderData(null);
setBillingCyclePeriods([]);
setShowBillingCyclePeriod(false);

      setInternalFilterSimVsService("1_month");
      setInternalFilterSimActivation("1_month");
      setInternalFilterServiceVsStatus("1_month");
      setStartDate("");
      setEndDate("");
      setDateRange([null, null]);
      setSelectedButton("Current Month");
      setUseCache(false);

      localStorage.removeItem("simCounts_cache");
      localStorage.removeItem("activations_cache");
      localStorage.removeItem("status_cache");

      clearFilters();

    const defaultStart = (moment().startOf("month").format("YYYY-MM-DD"));
    const defaultEnd = (moment().format("YYYY-MM-DD"));
    setStartDate(defaultStart);
    setEndDate(defaultEnd);
      // Fetch with current service provider selections
      // await fetchChartData("", "", true);
    }
  };

const handleButtonClick = (range: "Today" | "Current Week" | "Current Month" | "1 Year") => {
  setSelectedButton(range);
 
  // Map global filter to internal filter
  const internalFilter = mapGlobalDateToInternalFilter(range);
  setInternalFilterSimVsService(internalFilter);
  setInternalFilterSimActivation(internalFilter);
  setInternalFilterServiceVsStatus(internalFilter);
 
  let newStartDate: string;
  let newEndDate: string;
 
  if (range === "Today") {
    newStartDate = moment().format("YYYY-MM-DD");
    newEndDate = moment().format("YYYY-MM-DD");
  } else if (range === "Current Week") {
    newStartDate = moment().startOf('week').format("YYYY-MM-DD");
    newEndDate = moment().endOf('week').format("YYYY-MM-DD");
  } else if (range === "Current Month") {
    newStartDate = moment().subtract(30, "days").format("YYYY-MM-DD");
    newEndDate = moment().format("YYYY-MM-DD");
  } else if (range === "1 Year") {
    // ✅ NEW: Show from current month to 12 months back
    newStartDate = moment().subtract(12, "months").format("YYYY-MM-DD");
    newEndDate = moment().format("YYYY-MM-DD");
  } else {
    newStartDate = moment().subtract(30, "days").format("YYYY-MM-DD");
    newEndDate = moment().format("YYYY-MM-DD");
  }
 
  setStartDate(newStartDate);
  setEndDate(newEndDate);
  setDateRange([dayjs(newStartDate), dayjs(newEndDate)]);
  setUseCache(false);
 
  fetchChartData(newStartDate, newEndDate, false);
};

  // const detectClosestFilter = (startDate: string, endDate: string): string => {
  //   const start = moment(startDate);
  //   const end = moment(endDate);
  //    const oneYearBack = moment().subtract(1, "year");

  //   // If selected range goes beyond 1 year back → force 5_years
  //   if (start.isBefore(oneYearBack, "day") || end.isBefore(oneYearBack, "day")) {
  //     return "5_years";
  //   }

  //   // Check if dates are exactly the same (for 1_day)
  //   if (start.isSame(end, 'day')) return "1_day";
    
  //   const diffDays = end.diff(start, "days");
  //   const diffMonths = end.diff(start, "months", true);
  //   const diffYears = end.diff(start, "years", true);
    
  //   // Match backend logic more precisely
  //   // if (diffDays <= 4) return "5_day";
  //   // if (diffMonths < 1) return "1_month";
  //   // if (diffMonths < 3) return "3_month";
  //   // if (diffMonths < 6) return "6_month";
  //   // if (diffMonths < 12) return "1_year";
  //   // if (diffYears < 5) return "5_years";
  //    if (diffDays <= 4) return "5_day";
  // if (diffDays <= 31) return "1_month";   // 
  // if (diffDays <= 92) return "3_month";   // ~3 months
  // if (diffDays <= 183) return "6_month";  // ~6 months
  // if (diffDays <= 366) return "1_year";   // ~1 year
  // if (diffDays <= 1826) return "5_years";
  
    
  //   return "max";
  // };
//    const detectClosestFilter = (startDate: string, endDate: string): string => {
//     const start = moment(startDate);
//     const end = moment(endDate);
//      const oneYearBack = moment().subtract(1, "year");

//     // If selected range goes beyond 1 year back → force 5_years
//     if (start.isBefore(oneYearBack, "day") || end.isBefore(oneYearBack, "day")) {
//       return "5_years";
//     }

//     // Check if dates are exactly the same (for 1_day)
//     if (start.isSame(end, 'day')) return "1_day";
    
//     const diffDays = end.diff(start, "days");
//     const diffMonths = end.diff(start, "months", true);
//     const diffYears = end.diff(start, "years", true);
    
//     // Match backend logic more precisely
//     // if (diffDays <= 4) return "5_day";
//     // if (diffMonths < 1) return "1_month";
//     // if (diffMonths < 3) return "3_month";
//     // if (diffMonths < 6) return "6_month";
//     // if (diffMonths < 12) return "1_year";
//     // if (diffYears < 5) return "5_years";
//      if (diffDays <= 4) return "5_day";
//   if (diffDays <= 31) return "1_month";   // 
//   if (diffDays <= 92) return "3_month";   // ~3 months
//   if (diffDays <= 183) return "6_month";  // ~6 months
//   if (diffDays <= 366) return "1_year";   // ~1 year
//   if (diffDays <= 1826) return "5_years";
  
    
//     return "max";
// };
   const detectClosestFilter = (startDate: string, endDate: string): string => {
    const start = moment(startDate);
    const end = moment(endDate);
    const oneYearBack = moment().subtract(1, "year");

    // If selected range goes beyond 1 year back → force 5_years
    // if (start.isBefore(oneYearBack, "day") || end.isBefore(oneYearBack, "day")) {
    //   return "5_years";
    // }

    // Last day of current month
const rangeEnd = moment().endOf("month");

// First day of the month AFTER current month, one year ago
const rangeStart = moment()
  .add(1, "month")
  .subtract(1, "year")
  .startOf("month");

const withinYearRange = {
  start: rangeStart,
  end: rangeEnd,
};

console.log(
  "withinYearRange",
  rangeStart.format("YYYY-MM-DD"),
  "→",
  rangeEnd.format("YYYY-MM-DD")
);

// If selected range is completely outside past 12 months → force 5_years
if (end.isBefore(withinYearRange.start, "day")) {
  return "5_years";
}
    // Calculate the difference
    const diffDays = end.diff(start, "days");
    const diffMonths = end.diff(start, "months", true);
    const diffYears = end.diff(start, "years", true);
    
    // Map day differences to appropriate filters
    if (diffDays === 0) return "1_day";
    if (diffDays <= 4) return "5_day";
    if (diffDays <= 31) return "1_month";
    if (diffDays <= 92) return "3_month";
    if (diffDays <= 183) return "6_month";
    if (diffDays <= 366) return "1_year";
    if (diffYears <= 5) return "5_years";
    
    return "max";
};
// const handleDateRangeChange = (
//       dates: [Dayjs | null, Dayjs | null] | null,
//       dateStrings: [string, string]
//     ) => {
//       let applied_filter
//       setSelectedButton(null);
//       if (dates && dates[0] && dates[1]) {
//         setDateRange([dates[0], dates[1]]);
//         const newStartDate = dates[0].format("YYYY-MM-DD");
//         const newEndDate = dates[1].format("YYYY-MM-DD");
//         setStartDate(newStartDate);
//         setEndDate(newEndDate);
//         setUseCache(false);
//         fetchChartData(newStartDate, newEndDate, false);
//         applied_filter = detectClosestFilter(newStartDate,newEndDate)
//         console.clear()
//         console.error("applied_filter",applied_filter,newStartDate,newEndDate)
//       } else {
//         setDateRange([null, null]);
//         setSelectedButton("Current Month");
//         const newStartDate = moment().subtract(30, "days").format("YYYY-MM-DD");
//         const newEndDate = moment().format("YYYY-MM-DD");
//         setStartDate(newStartDate);
//         setEndDate(newEndDate);
//         setUseCache(false);
//         fetchChartData(newStartDate, newEndDate, false);
//         applied_filter = detectClosestFilter(newStartDate,newEndDate)
//         console.clear()
//         console.error("applied_filter",applied_filter,newStartDate,newEndDate)
//       }
//        setInternalFilterSimVsService(applied_filter);
//       setInternalFilterSimActivation(applied_filter);
//     setInternalFilterServiceVsStatus(applied_filter);
//     };
const handleDateRangeChange = (
    dates: [Dayjs | null, Dayjs | null] | null,
    dateStrings: [string, string]
) => {
    let applied_filter;
    setSelectedButton(null);
    
    if (dates && dates[0] && dates[1]) {
        setDateRange([dates[0], dates[1]]);
        const newStartDate = dates[0].format("YYYY-MM-DD");
        const newEndDate = dates[1].format("YYYY-MM-DD");
        setStartDate(newStartDate);
        setEndDate(newEndDate);
        
        // Detect the appropriate filter BEFORE fetching data
        applied_filter = detectClosestFilter(newStartDate, newEndDate);
        
        // Set all internal filters to the detected filter
        setInternalFilterSimVsService(applied_filter);
        setInternalFilterSimActivation(applied_filter);
        setInternalFilterServiceVsStatus(applied_filter);
        
        setUseCache(false);
        fetchChartData(newStartDate, newEndDate, false);
        
    } else {
        setDateRange([null, null]);
        setSelectedButton("Current Month");
        const newStartDate = moment().subtract(30, "days").format("YYYY-MM-DD");
        const newEndDate = moment().format("YYYY-MM-DD");
        setStartDate(newStartDate);
        setEndDate(newEndDate);
        
        applied_filter = detectClosestFilter(newStartDate, newEndDate);
        setInternalFilterSimVsService(applied_filter);
        setInternalFilterSimActivation(applied_filter);
        setInternalFilterServiceVsStatus(applied_filter);
        
        setUseCache(false);
        fetchChartData(newStartDate, newEndDate, false);
    }
};
  const handleInternalFilterChange = (chart: string, filter: string) => {
  setIsAnimating(true);

  if (chart === "simVsService") setInternalFilterSimVsService(filter);
  else if (chart === "simActivation") setInternalFilterSimActivation(filter);
  else if (chart === "serviceVsStatus") setInternalFilterServiceVsStatus(filter);

  if (cachedData.simVsServiceProvider || cachedData.simActivationTrend || cachedData.serviceProviderVsStatus) {
    setChartData(cachedData);
    setUseCache(true);
  }

  // Reset animation state after duration
  setTimeout(() => setIsAnimating(false), 500);
};

  const formatDateForTooltip = (date: string): string => {
    if (!date) return "";
    return date.includes("'T'") ? date.split("'T'")[0] : date;
  };

  // **FIX: Updated processChartData function with proper filter handling**
  const processChartData = (data: any, filter: string, tenantId: string, chartType?: 'simVsService' | 'simActivation' | 'serviceVsStatus'): ProcessedChartData => {
    // console.log("=== PROCESS CHART DATA START ===");
    // console.log("Input parameters:", { filter, tenantId, chartType });
    // console.log("Available data filters:", Object.keys(data?.data?.data || {}));

    if (!data?.data?.data?.[filter]) {
      console.error(`âŒ Filter '${filter}' not found in data. Available filters:`, Object.keys(data?.data?.data || {}));

      // **FIX: Try to find any available filter with data**
      const availableFilters = Object.keys(data?.data?.data || {});
      const fallbackFilter = availableFilters.find(f => data.data.data[f]?.length > 0);

      if (fallbackFilter) {
        console.log(`ðŸ”„ Using fallback filter: ${fallbackFilter}`);
        return processChartData(data, fallbackFilter, tenantId, chartType);
      }

      return { chartData: [], details: {} };
    }

    if (!data?.meta?.providers) {
      console.error("âŒ No providers metadata found");
      return { chartData: [], details: {} };
    }

    const providers = data.meta.providers as { [key: string]: string };
    console.log("ðŸ“‹ Available providers:", providers);

    const providerData: { [provider: string]: { total: number; details: { [date: string]: number } } } = {};

    // Initialize provider data
    Object.values(providers).forEach((provider: string) => {
      providerData[provider] = { total: 0, details: {} };
    });
    console.log("ðŸ”§ Initialized provider data:", providerData);

    let filteredData = data.data.data[filter];
    // console.log(`ðŸ“Š Raw filtered data for ${filter}:`, filteredData);
    // console.log(`ðŸ“Š Number of records in ${filter}:`, filteredData?.length || 0);

    // For specific tenant, filter by tenant_id
    // For "All Tenants", use all data (no filtering)
    if (tenantId !== "All") {
      const beforeFilter = filteredData?.length || 0;
      filteredData = filteredData.filter((item: any) => String(item.tenant_id) === tenantId);
      console.log(`ðŸ” Filtered for tenant ${tenantId}: ${beforeFilter} -> ${filteredData?.length || 0} records`);
    } else {
      console.log("ðŸŒ ALL TENANTS mode - processing all records without tenant filter");
    }

    // console.log("ðŸ“Š Final filtered data:", filteredData);

    // Process each item
    filteredData?.forEach((item: any, index: number) => {
      // console.log(`\n--- Processing item ${index + 1} ---`);
      // console.log("Item details:", item);

      // Handle null provider_id by converting to string
      const providerId = item.provider_id === null ? "null" : String(item.provider_id);
      const providerName = providers[providerId];

      // console.log(`ðŸ¢ Provider ID: ${providerId} -> Provider Name: ${providerName}`);

      if (!providerName) {
        console.warn(`âš ï¸ Provider ID ${providerId} not found in meta.providers`);
        console.log("Available provider IDs:", Object.keys(providers));
        return;
      }

      // console.log(`ðŸ“± Processing ${item.records?.length || 0} records for ${providerName}`);

      item.records?.forEach((record: any, recordIndex: number) => {
        console.log(`  Record ${recordIndex + 1}:`, record);

        let date: string, count: number;
        if (Array.isArray(record)) {
          date = record[0];
          count = Number(record[1]) || 0;
          console.log(`    Array format: date=${date}, count=${count}`);
        } else if (typeof record === "object" && record !== null) {
          date = Object.keys(record)[0];
          count = Number(record[date]) || 0;
          console.log(`    Object format: date=${date}, count=${count}`);
        } else {
          console.warn("    âŒ Invalid record format:", record);
          return;
        }

        const formattedDate = formatDateForTooltip(date);
        // console.log(`    Formatted date: ${formattedDate}`);

        // Sum across all tenants for each provider
        const previousTotal = providerData[providerName].total;
        const previousDateTotal = providerData[providerName].details[formattedDate] || 0;

        providerData[providerName].total += count;
        providerData[providerName].details[formattedDate] =
          (providerData[providerName].details[formattedDate] || 0) + count;

        // console.log(`    ðŸ“ˆ Updated ${providerName}: total ${previousTotal} -> ${providerData[providerName].total}`);
        // console.log(`    ðŸ“ˆ Updated ${providerName}[${formattedDate}]: ${previousDateTotal} -> ${providerData[providerName].details[formattedDate]}`);
      });
    });

    // console.log("\nðŸ”„ Final provider data before processing:", providerData);

    // Fix: Different logic based on chart type
    const chartData = Object.entries(providerData)
      .map(([provider, data]) => {
        if (chartType === 'simActivation') {
          // For SIM Activation Trend: show total count across all dates
          return {
            service_provider: provider,
            total: data.total, // Total count across all dates
          };
        } else {
          // For other charts: show latest date count only
          const allDates = Object.keys(data.details);
          if (!allDates.length) return { service_provider: provider, total: 0 };
          // Find the latest date (assuming ISO strings)
          const latestDate = allDates.sort().reverse()[0];
          return {
            service_provider: provider,
            total: data.details[latestDate], // latest date count only!
            latest_date: latestDate,
          };
        }
      })
      .filter((entry) => entry.total > 0)
      .sort((a, b) => b.total - a.total);

    // console.log("\nâœ… Final chart data:", chartData);
    // console.log("ðŸ“‹ Chart data summary:", chartData.map(item => `${item.service_provider}: ${item.total}`));

    const details = Object.fromEntries(
      Object.entries(providerData).map(([provider, data]) => [provider, data.details])
    );

    // console.log("ðŸ“Š Final details:", details);
    // console.log("=== PROCESS CHART DATA END ===\n");

    return { chartData, details };
  };

  // Enhanced processTableData function with status chart support
  const processTableData = (data: any, filter: string, tenantId: string): ProcessedChartData => {
    if (!data?.data?.data?.[filter] || !data?.meta?.providers) {
      // console.warn("Invalid table data structure:", data);
      return { chartData: [], details: {} };
    }

    const providers = data.meta.providers as { [key: string]: string };
    const tenants = data.meta.tenants as { [key: string]: string };
    const tenantProviderData: { [key: string]: { total: number; details: { [date: string]: number } } } = {};

    let filteredData = data.data.data[filter];

    // For specific tenant, filter by tenant_id
    if (tenantId !== "All") {
      filteredData = filteredData.filter((item: any) => String(item.tenant_id) === tenantId);
    }

    // Process each item - for tables, keep tenant separation
    filteredData.forEach((item: any) => {
      const providerId = item.provider_id === null ? "null" : String(item.provider_id);
      const providerName = providers[providerId];
      const currentTenantId = String(item.tenant_id);

      if (!providerName) {
        console.warn(`Provider ID ${providerId} not found in meta.providers`);
        return;
      }

      // Create unique key for tenant-provider combination
      const key = `${currentTenantId}-${providerName}`;

      if (!tenantProviderData[key]) {
        tenantProviderData[key] = { total: 0, details: {} };
      }

      item.records?.forEach((record: any) => {
        let date: string, count: number;

        // Handle different record formats
        if (Array.isArray(record)) {
          date = record[0];
          count = Number(record[1]) || 0;
        } else if (typeof record === "object" && record !== null) {
          // Handle status chart records
          if (record.status_counts) {
            date = record.date;
            count = Object.values(record.status_counts).reduce((sum: number, val: any) => sum + (Number(val) || 0), 0);
          } else {
            date = Object.keys(record)[0];
            count = Number(record[date]) || 0;
          }
        } else {
          console.warn("Invalid record format:", record);
          return;
        }

        const formattedDate = formatDateForTooltip(date);

        tenantProviderData[key].total += count;
        tenantProviderData[key].details[formattedDate] =
          (tenantProviderData[key].details[formattedDate] || 0) + count;
      });
    });

    const chartData = Object.entries(tenantProviderData)
      .map(([key, data]) => {
        const [tenantId, providerName] = key.split('-');
        const tenantName = tenantId === "All" ? "All Tenants" :
          tenants[tenantId] || filterOptions.options.find(option => option.tenant_id === tenantId)?.label || tenantId;

        return {
          service_provider: providerName,
          tenant_name: tenantName,
          tenant_id: tenantId,
          total: data.total,
          key: key
        };
      })
      .filter((entry) => entry.total > 0)
      .sort((a, b) => b.total - a.total);

    const details = Object.fromEntries(
      Object.entries(tenantProviderData).map(([key, data]) => [key, data.details])
    );

    return { chartData, details };
  };


// 1. Replace your renderFilterButtons function with this:
const renderFilterButtons = (chart: string) => {
  const filters = [
    { label: "1D", value: "1_day" },
    { label: "5D", value: "5_day" },
    { label: "1M", value: "1_month" },
    { label: "3M", value: "3_month" },
    { label: "6M", value: "6_month" },
    { label: "1Y", value: "1_year" },
    { label: "5Y", value: "5_years" },
    { label: "Max", value: "max" },
  ];

  const currentFilter =
    chart === "simVsService"
      ? getActualFilterFromData(useCache ? cachedData.simVsServiceProvider : chartData.simVsServiceProvider, internalFilterSimVsService)
      : chart === "simActivation"
        ? internalFilterSimActivation
        : internalFilterServiceVsStatus;

  return (
    <div className="flex grid grid-cols-8">
      {filters.map((filter) => (
        <button
          key={filter.value}
          onClick={() => handleInternalFilterChange(chart, filter.value)}
          style={{ fontFamily: "Calibri, sans-serif", fontSize: "14px" }}
          className={`${currentFilter === filter.value || (currentFilter === "no_data" && filter.value === internalFilterSimVsService) ? "new-dashboard-filter-active-btn" : "new-dashboard-filter-btn"} p-2 transition-all duration-300`}
        >
          {filter.label}
        </button>
      ))}
    </div>
  );
};

const SERVICE_PROVIDER_COLORS: Record<string, string> = {};

  // Enhanced Time-based chart rendering with proper month grouping and auto-expansion

  const renderTimeBasedChart = () => {
    const cardHeight = 280; // Reduced from 350 to accommodate legends
    const dataSource = useCache ? cachedData : chartData;
    
    // Show loading spinner while data is being fetched
  if (loadingSimVsServiceProvider) {
    return (
      <div className="bg-white p-4 rounded-lg shadow-md graph" style={{ height: '400px', width: '100%' }}>
        <div className="bg-gray-100 flex justify-between items-center p-4 chart-title">
          <div className="flex items-center">
            <BarChart className="cursor-pointer mr-2" />
            <h2 className="font-semibold">SIM Vs Service Provider</h2>
          </div>
          <div className="flex items-center">
           <button
                  onClick={() => setFlippedChart(flippedChart === 0 ? null : 0)}
                  className="flex items-center justify-center cursor-pointer"
                  style={{
                    width: "24px",
                    height: "24px",
                    border: "none",
                    background: "transparent",
                    padding: 0,
                    marginLeft: "4px",
                  }}
                >
                  <i
                    className="fi fi-rr-flip-horizontal"
                    style={{
                      fontSize: "18px",
                      color: "currentColor",
                      lineHeight: 1,
                    }}
                  />
                </button>
          </div>
        </div>
        {renderFilterButtons("simVsService")}
        <div className="flex justify-center items-center" style={{ height: 'calc(100% - 100px)' }}>
          <Spin size="large" />
        </div>
      </div>
    );
  }
    const filter = getActualFilterFromData(dataSource.simVsServiceProvider, internalFilterSimVsService);
  
  if (filter === "no_data") {
    return (
      <div className="bg-white p-4 rounded-lg shadow-md graph" style={{ height: '400px', width: '100%' }}>
        <div className="bg-gray-100 flex justify-between items-center p-4 chart-title">
          <div className="flex items-center">
            <BarChart className="cursor-pointer mr-2" />
            <h2 className="font-semibold">SIM Vs Service Provider</h2>
          </div>
          <div className="flex items-center">
           <button
                  onClick={() => setFlippedChart(flippedChart === 0 ? null : 0)}
                  className="flex items-center justify-center cursor-pointer"
                  style={{
                    width: "24px",
                    height: "24px",
                    border: "none",
                    background: "transparent",
                    padding: 0,
                    marginLeft: "4px",
                  }}
                >
                  <i
                    className="fi fi-rr-flip-horizontal"
                    style={{
                      fontSize: "18px",
                      color: "currentColor",
                      lineHeight: 1,
                    }}
                  />
                </button>
          </div>
        </div>
        {renderFilterButtons("simVsService")}
        <div className="flex justify-center items-center" style={{ height: 'calc(100% - 100px)' }}>
          <span style={{ fontSize: '16px', color: '#666' }}>No Data Available</span>
        </div>
      </div>
    );
  }


    const { chartData: timeBasedData, serviceProviders } = dataSource.simVsServiceProvider
      ? processTimeBasedChartData(dataSource.simVsServiceProvider, filter, selectedTenantId, 'simVsService')
      : { chartData: [], serviceProviders: [] };


    // Calculate legend height based on number of providers

    const barWidth = 20;

    const shouldShowDualXAxis = ["1_month","3_month", "6_month", "1_year"].includes(filter);
  const bottomMargin = shouldShowDualXAxis ? 60 : 45;
  const legendHeight = 50; // Fixed legend height
  const baseWidth = "100%";





    // Enhanced month positioning logic for proper center alignment
const processDataWithMonthGaps = (data: any[]) => {
  if (!shouldShowDualXAxis || data.length === 0) {
    return { processedData: data, monthPositions: [] };
  }

  const processedData: any[] = [];
  const monthPositions: {
    month: string;
    startIndex: number;
    endIndex: number;
    centerIndex: number;
    monthLabel?: string;
  }[] = [];

  // --------------------------------------------------
  // 1️⃣ GROUP DATA BY YEAR + MONTH (YYYY-MM)
  // --------------------------------------------------
  const monthGroups: { [month: string]: any[] } = {};

  data.forEach((item) => {
    if (!item.time || item.isGap) return;

    // get real date (weekly/monthly data)
    const d = dayjs(item.rawDate || item.firstDate || item.time);
    if (!d.isValid()) return;

    const monthKey = d.format("YYYY-MM");     // ✅ FIX
    const monthLabel = d.format("MMM");  // for UI

    if (!monthGroups[monthKey]) {
      monthGroups[monthKey] = [];
    }

    monthGroups[monthKey].push({
      ...item,
      __date: d,
      __monthLabel: monthLabel,
    });
  });

  // --------------------------------------------------
  // 2️⃣ SORT MONTHS CHRONOLOGICALLY (OLD → NEW)
  // --------------------------------------------------
  const monthKeys = Object.keys(monthGroups).sort(
    (a, b) => dayjs(a).valueOf() - dayjs(b).valueOf()
  );

  // --------------------------------------------------
  // 3️⃣ PROCESS EACH MONTH
  // --------------------------------------------------
  monthKeys.forEach((month, monthIdx) => {
    const monthData = monthGroups[month];

    // sort weeks inside month
    monthData.sort(
      (a, b) => a.__date.valueOf() - b.__date.valueOf()
    );

    const startIndex = processedData.length;

    monthData.forEach((item) => {
      processedData.push(item);
    });

    const endIndex = processedData.length - 1;
    const weekCount = monthData.length;

    // --------------------------------------------------
    // 4️⃣ CENTER INDEX LOGIC (UNCHANGED)
    // --------------------------------------------------
    let centerIndex: number;

    if (weekCount === 1) {
      centerIndex = startIndex;
    } else if (weekCount % 2 === 1) {
      centerIndex = startIndex + Math.floor(weekCount / 2);
    } else {
      centerIndex = startIndex + weekCount / 2 - 0.5;
    }

    monthPositions.push({
      month, // stays same variable name
      startIndex,
      endIndex,
      centerIndex: Math.floor(centerIndex),
      monthLabel: monthData[0].__monthLabel, // ✅ year-aware label
    });

    // --------------------------------------------------
    // 5️⃣ ADD GAPS BETWEEN MONTHS
    // --------------------------------------------------
    if (monthIdx < monthKeys.length - 1) {
      for (let i = 0; i < 2; i++) {
        processedData.push({
          time: `gap-${month}-${i}`,
          isGap: true,
          ...serviceProviders.reduce(
            (acc: any, provider: string) => {
              acc[provider] = 0;
              return acc;
            },
            {}
          ),
        });
      }
    }
  });

  return { processedData, monthPositions };
};


    const { processedData: processedTimeBasedData, monthPositions } = processDataWithMonthGaps(timeBasedData);
// const getStackedDataMinMax = (data: any[], stackedKeys: string[]): { min: number; max: number } => {
//   let min = Infinity;
//   let max = -Infinity;
  
//   data.forEach(item => {
//     // Calculate the total stacked value for this time period
//     let stackedTotal = 0;
//     stackedKeys.forEach(key => {
//       if (item[key] !== undefined && item[key] !== null && typeof item[key] === 'number') {
//         stackedTotal += item[key];
//       }
//     });
    
//     min = Math.min(min, stackedTotal);
//     max = Math.max(max, stackedTotal);
//   });
  
//   // Handle edge cases
//   if (min === Infinity) min = 0;
//   if (max === -Infinity) max = 100;
//   if (min === max) {
//     min = Math.max(0, min - 10);
//     max = max + 10;
//   }
  
//   return { min, max };
// };
// 1️⃣ Calculate total usage per provide

const providerTotals = serviceProviders.map((p) => ({
  provider: p,
  total: processedTimeBasedData
   .filter((r) => !r.isGap).reduce((sum, r) => sum + (Number(r[p]) || 0), 0)
})).sort((a, b) => b.total - a.total);

 const sortedProviders = providerTotals.map(pt => pt.provider).reverse();

// Assign color only once per provider for lifetime stability
// Maintain a stable order of providers (first appearance = fixed order)
// Assign a unique stable color to each service provider
serviceProviders.forEach((provider) => {
  if (!SERVICE_PROVIDER_COLORS[provider]) {
    const nextIndex = Object.keys(SERVICE_PROVIDER_COLORS).length;
    SERVICE_PROVIDER_COLORS[provider] =
      BLUE_SHADE_COLORS[nextIndex % BLUE_SHADE_COLORS.length];
  }
});




const getLocalWeekNumber = (value: string): string => {
  if (filter !== "1_month") return value;

  if (!value.includes("-W")) return value;

  const [month] = value.split("-W");

  const sameMonthWeeks = processedTimeBasedData.filter(
    (item: any) =>
      item.time &&
      item.time.startsWith(`${month}-W`) &&
      !item.isGap
  );

  const weekIndex =
    sameMonthWeeks.findIndex((item: any) => item.time === value) + 1;

  return `W${weekIndex}`;
};

    return (
      <div
        className="bg-white p-4 rounded-lg shadow-md graph"
        style={{
          height: `400px`,// Adjusted height calculation
          width: baseWidth,
          overflow: 'visible', // Prevent any overflow
        }}
      >
        <div className="bg-gray-100 flex justify-between items-center p-4 chart-title">
          <div className="flex items-center">
            <BarChart className="cursor-pointer mr-2" />
            <h2 className="font-semibold">SIM Vs Service Provider</h2>
          </div>
          <div className="flex items-center">
           <button
                  onClick={() => setFlippedChart(flippedChart === 0 ? null : 0)}
                  className="flex items-center justify-center cursor-pointer"
                  style={{
                    width: "24px",
                    height: "24px",
                    border: "none",
                    background: "transparent",
                    padding: 0,
                    marginLeft: "4px",
                  }}
                >
                  <i
                    className="fi fi-rr-flip-horizontal"
                    style={{
                      fontSize: "18px",
                      color: "currentColor",
                      lineHeight: 1,
                    }}
                  />
                </button>
          </div>
        </div>

        {renderFilterButtons("simVsService")}

        {flippedChart === 0 ? (
          <div style={{
            height: `${cardHeight + legendHeight - 20}px`,
            padding: "10px",
            overflow: 'hidden' // Prevent table overflow
          }}>
            <Table
              dataSource={timeBasedData.map((item, index) => ({ ...item, key: index }))}
              columns={[
                {
                   title: (
    <span style={{ fontSize: "14px", fontFamily: "Calibri, sans-serif" }}>
      Time Period
    </span>
  ),
                  dataIndex: "time",
                  key: "time",
                  width: 120, // Reduced width
                  fixed: 'left',
                   onCell: () => ({
    style: {
      fontSize: "14px",
      fontFamily: "Calibri, sans-serif",
    },
  }),
                  render: (value: string) => {
                    // Convert 00-W1 format to Jan-W1 format
                    if (value.includes('-W')) {
                      const [monthIndex, week] = value.split('-W');
                      const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                      const monthName = monthNames[parseInt(monthIndex)] || monthIndex;
                      return `${monthName}-W${week}`;
                    }
                    return value;
                  }
                },
                ...serviceProviders.map((provider, index) => ({
                  title: provider,
                  dataIndex: provider,
                  key: provider,
                  width: Math.max(80, Math.floor((window.innerWidth - 200) / serviceProviders.length)), // Dynamic width
                  render: (value: number) => (value > 0 ? value.toLocaleString() : "-"),
                  onHeaderCell: () => ({
                    style: {
                      fontSize: '12px', // Further reduced font size
                      padding: '2px 4px', // Minimal padding
                      whiteSpace: 'nowrap',
                      overflow: 'hidden',
                      fontFamily: "Calibri, sans-serif",
                      textOverflow: 'ellipsis'
                    }
                  }),
                  onCell: () => ({
                    style: {
                      fontSize: '12px', // Smaller font for data
                      fontFamily: "Calibri, sans-serif",
                      padding: '2px 4px'
                    }
                  })
                })),
              ]}
              pagination={false}
              scroll={{
                y: cardHeight + legendHeight - 120, // Fit within container
                x: undefined // Remove horizontal scroll
              }}
              size="small"
              style={{
                fontSize: '9px',
                width: '100%'
              }}
            />
          </div>
        ) : (
         
          <div style={{
            width: baseWidth,
            // height: `${cardHeight + legendHeight}px`,
            height:'280px',
            overflow: 'visible',
            position: 'relative'
          }}>
            
              <ResponsiveBar
                data={processedTimeBasedData.map((item) => {
                  if (item.isGap) {
                    // Convert gap records → all values = 0 for Nivo
                    const gapEntry: any = { time: item.time };
                    sortedProviders.forEach((sp) => (gapEntry[sp] = 0));
                    gapEntry.isGap = true;
                    return gapEntry;
                  }
                  return item;
                })}
                key={filter}
                keys={sortedProviders}
                onClick={(bar) => {
                  if (!bar.data || bar.data.isGap) return;

                  const timeLabel = bar.data.time.includes("-W")
                    ? getLocalWeekNumber(bar.data.time)
                    : bar.data.time;

                  handleChartClick({ time: timeLabel }, "simVsService", bar.data);
                }}

                indexBy="time"
                groupMode="stacked"
                padding={filter === "1_year" ? 0.12 : 0.35}
                valueScale={{ type: "linear" }}
                margin={{ top: 20, right: 40, bottom: shouldShowDualXAxis ? 80:60, left: 80}}
                colors={(d) => SERVICE_PROVIDER_COLORS[String(d.id)]}



                borderRadius={0}
                enableLabel={false}
                enableGridX={false}
                enableGridY={true}
                axisLeft={{
                  tickSize: 5,
                  tickPadding: 5,
                  tickRotation: 0,
                  legend: "SIM Count",
                  legendPosition: "middle",
                  legendOffset: -70,   // moved LEFT
                  format: value => value,
                }}
                theme={{
                  grid: {
                    line: {
                      strokeWidth: 1,
                      strokeDasharray: "2 2",    // dotted style (use "4 2" if you want slightly larger dots)
                    },
                  },
                  axis: {
                    domain: {
                      line: {
                        stroke: "#e6e6e6",
                        strokeWidth: 1,
                      }
                    },
                    ticks: {
                      line: {
                        stroke: "#e6e6e6",
                        strokeWidth: 1
                      },
                      text: {
                        //  fontSize: filter === "1_year" ? 7  : 12,
                        fontSize: 12,
                        fill:  "currentColor",
                        fontWeight: 500,
                        fontFamily: "Calibri, sans-serif",
                      }
                    },
                    legend: {
                      text: {
                        fontSize: 16,
                        
        // fontWeight: 600,
        fill:  "currentColor",
        fontFamily: "Calibri",
                      }
                    }
                  },
                  tooltip: {
                    container: {
                      fontSize: 11
                    }
                  }
                }}
                axisTop={null}
                axisRight={null}

                axisBottom={{
                  tickSize: 5,
                  tickPadding: 6,
                  tickRotation: 0,
                  legendOffset: 50,

                  format: (value) => {
                    const v = String(value);

                    if (v.startsWith("gap-")) return "";

                    // 1-day filter: show only time (HH:mm)
                    if (filter === "1_day") {
                      const parsed = dayjs(v);
                      return parsed.format("HH:mm");
                    }

                    // 5-day filter: show Month-Date (e.g., Dec-01)
                    if (filter === "5_day") {
                      const parsed = dayjs(v);
                      return parsed.format("MMM-DD");
                    }

                    // Weekly format: show week number
                    if (v.includes("-W")) return "W" + v.split("-W")[1];

                    return v;
                  },

                  renderTick: (tick) => {
                    const v = String(tick.value);

                    if (v.startsWith("gap-")) return <g />;

                    const isWeekFormat = v.includes("-W");
                    const isSmall = filter === "1_year" && isWeekFormat;

                    // Format display based on filter
                    let displayText = tick.value;

                    if (filter === "1_day") {
                      displayText = dayjs(v).format("HH:mm");
                    } else if (filter === "5_day") {
                      displayText = dayjs(v).format("MMM-DD");
                    } else if (isWeekFormat) {
                      displayText = "W" + v.split("-W")[1];
                    }

                    return (
                      <g transform={`translate(${tick.x},${tick.y})`}>
                        <line y1={0} y2={5} stroke="#666" strokeWidth={1}   className="chart-axis-line" />
                        <text
  x={0}
  y={14}
  textAnchor="middle"
  dominantBaseline="hanging"
    className="chart-axis-text"
  style={{
    // fill: "#000",
    fontFamily: "Calibri, sans-serif",
    fontWeight: 500,
    fontSize: weekLabelFont,  // 👈 use responsive value
  }}
>
  {displayText}
</text>

                      </g>
                    );
                  },
                }}
                // ------------------------------
                //  CUSTOM MONTH NAME LAYER
                // ------------------------------
                layers={[
                  "grid",
                  "axes",
                  "bars",
                  "markers",
                  "legends",
                  (layerProps) => {
                    const { xScale, innerWidth, innerHeight } = layerProps;
                    const band = xScale as any;
                    const bandwidth =
                      typeof band.bandwidth === "function" ? band.bandwidth() : 0;

                    return (
                      <g transform={`translate(0, ${innerHeight + 25})`}>
                        {monthPositions.map((m) => {
                          const startItem = processedTimeBasedData[m.startIndex];
                          const endItem = processedTimeBasedData[m.endIndex];

                          if (!startItem || !endItem) return null;
                          if (startItem.isGap || endItem.isGap) return null;

                          const xStart = xScale(startItem.time);
                          const xEnd = xScale(endItem.time);
                          if (xStart == null || xEnd == null) return null;

                          // center between first and last week’s bars
                          const centerX = (xStart + xEnd + bandwidth) / 2;

                          const safeX = Math.max(0, Math.min(centerX, innerWidth));

                          const monthNames = [
                            "Jan", "Feb", "Mar", "Apr", "May", "Jun",
                            "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
                          ];

                          return (
                            <text
                              key={`${m.month}_${m.startIndex}_${m.endIndex}`}
                              x={safeX}
                              y={20}
                              textAnchor="middle"
                              fontSize={12}
                              fontWeight={500}
                               className="chart-month-label"
                            >
                              {m.monthLabel}
                            </text>
                          );
                        })}
                      </g>
                    );
                  },
                ]}


                // ------------------------------
                //  TOOLTIP (same UI as Status chart)
                // ------------------------------
                tooltip={(bar) => {
                  const is1Day = filter === "1_day";
                  const is5Day = filter === "5_day";
                  
                  // For 1D we use exact time
                  const raw = is1Day ? bar.data.time : bar.data.firstDate;
                  if (!raw) return null;

                  const d = dayjs(raw);

                  // Title formatting
                  let title;

                const isYearBucket = /^\d{4}$/.test(bar.data.time);

                if (is1Day) {
                  title = d.format("HH:mm");  // Time only for 1D
                }
                else if (is5Day) {
                  title = d.format("MMM DD"); // FIX: date only
                }  
                else if (isYearBucket) {
                  // 5Y → Show YEAR only
                  title = bar.data.time;
                } else {
                  // title = `${d.format("MMM")} - W${getWeekOfMonth(d)}`;
                  title = `${d.format("MMM")} - W${getWeekOfMonth(d)}`;

                }


                  return (
                    <div
                     className="recharts-default-tooltip"
                      style={{
                        background: "#fff",
                        padding: "10px 12px",
                        border: "1px solid #ccc",
                        borderRadius: 8,
                        fontSize: 12,
                        whiteSpace: "nowrap",
                        color: "#000",
                        boxShadow: "0 2px 6px rgba(0,0,0,0.2)",
                        minWidth: "192px", // ⬅️ Increased width
    maxWidth: "240px", // ⬅️ Optional limit
                      }}
                    >
                      <div style={{ fontWeight: 700, marginBottom: 6, textAlign: "center" }}>
                        {title}
                      </div>

                      {serviceProviders
                      .filter((sp) => Number(bar.data[sp]) > 0) 
                      .map((sp) => (
                        <div
                          key={sp}
                          style={{
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "center",
                            marginBottom: 6,
                            whiteSpace: "nowrap",
                          }}
                        >
                          <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                            <span
                              style={{
                                width: 10,
                                height: 10,
                                backgroundColor: SERVICE_PROVIDER_COLORS[sp],
                                borderRadius: 2,
                              }}
                            ></span>
                            {sp}
                          </div>
                          <span>{Number(bar.data[sp] ?? 0).toLocaleString()}</span>
                        </div>
                      ))}
                    </div>
                  );
                }}


                // Smooth animation
                motionConfig="gentle"
              />
{/*legend button*/}
{/* <div
  style={{
    width: "100%",
    textAlign: "center",
    marginTop: "250px",
    marginBottom: "5px",
    position: "relative",
  }}
  className="group"
>
  <button className="px-3 py-1 text-[16px] bg-gray-200 rounded-md shadow cursor-pointer">
    Service Providers
  </button>

  <div
    className="
      absolute left-1/2 -translate-x-1/2 bottom-5
      hidden group-hover:block
      bg-white shadow-lg rounded-md border
      p-3 w-56 z-50
    "
    style={{
       width: "180px",  
      maxHeight: "none",
      overflow: "visible",
      fontFamily: "Calibri, sans-serif",
      fontSize: "12px",
      color: "#000",
    }}
  >
   {sortedProviders.map((sp, idx) => (
  <div
    key={idx}
    className="flex items-center gap-2 mb-2"
    style={{ fontWeight: 400 }}
  >
    <span
      style={{
        width: "10px",
        height: "10px",
        backgroundColor: BLUE_SHADE_COLORS[idx % BLUE_SHADE_COLORS.length],
        borderRadius: "2px",
        display: "inline-block",
      }}
    />
    
    <span style={{ fontWeight: 400 }}>
      {sp}
    </span>
  </div>
))}

  </div>
</div> */}

<div
  style={{
    width: "100%",
    textAlign: "center",
    marginTop: "250px",
    marginBottom: "5px",
    position: "relative",
  }}
>
  {/* Hover only button triggers tooltip */}
  <button
    className="px-3 py-1 text-[16px] service-provider-button rounded-md shadow cursor-pointer"
    onMouseEnter={() => setLegendVisible(true)}
    onMouseLeave={() => setLegendVisible(false)}
  >
    Service Providers
  </button>

  {/* Tooltip renders only when legendVisible is true */}
  {legendVisible && (
    <div
      className="service-provider-tooltip shadow-lg rounded-md border p-3 z-50"
      style={{
        position: "absolute",
        left: "50%",
        transform: "translateX(-50%)",
        bottom: "35px",
        minWidth: "180px",
        fontFamily: "Calibri, sans-serif",
        fontSize: "12px",
        color: "#000",
      }}
    >
      {sortedProviders.map((sp, idx) => (
        <div
          key={sp}
          style={{
            display: "flex",
            alignItems: "center",
            gap: "6px",
            marginBottom: "6px",
          }}
        >
          <span
            style={{
              width: 10,
              height: 10,
              backgroundColor: SERVICE_PROVIDER_COLORS[sp],
              borderRadius: 2,
            }}
          />
          <span>{sp}</span>
        </div>
      ))}
    </div>
  )}
</div>

{/* Custom Legend Below Chart */}
{/* <div className="flex justify-center ">  */}
          {/* <CustomLegendWithTooltip  
            serviceProviders={serviceProviders} 
            colorMap={serviceProviderColorMap}
          /> */}
          </div>
          
          
        )}
        

      </div>
    );
  };

  const renderTimeBasedLineChart = () => {
    const cardHeight = 265;
    const dataSource = useCache ? cachedData : chartData;

    if (loadingSimActivationTrend) {
      return (
        <div className="bg-white p-4 rounded-lg shadow-md graph" style={{ height: '400px', width: '100%' }}>
          <div className="bg-gray-100 flex justify-between items-center p-4 chart-title">
            <div className="flex items-center">
              <BarChart className="cursor-pointer mr-2" />
              <h2 className="font-semibold">SIMs Active</h2>
            </div>
            <div className="flex items-center">
              <button
                onClick={() => setFlippedChart(flippedChart === 0 ? null : 0)}
                className="flex items-center justify-center cursor-pointer"
                style={{
                  width: "24px",
                  height: "24px",
                  border: "none",
                  background: "transparent",
                  padding: 0,
                  marginLeft: "4px",
                }}
              >
                <i
                  className="fi fi-rr-flip-horizontal"
                  style={{
                    fontSize: "18px",
                    color: "currentColor",
                    lineHeight: 1,
                  }}
                />
              </button>
            </div>
          </div>
          {renderFilterButtons("simVsService")}
          <div className="flex justify-center items-center" style={{ height: 'calc(100% - 100px)' }}>
            <Spin size="large" />
          </div>
        </div>
      );
    }

    const filter = getActualFilterFromData(
      dataSource.simActivationTrend,
      internalFilterSimActivation
    );

    if (filter === "no_data") {
      return (
        <div className="bg-white p-4 rounded-lg shadow-md graph" style={{ height: '400px', width: '100%' }}>
          <div className="bg-gray-100 flex justify-between items-center p-4 chart-title">
            <div className="flex items-center">
              <BarChart className="cursor-pointer mr-2" />
              <h2 className="font-semibold">SIMs Active</h2>
            </div>
            <div className="flex items-center">
              <button
                onClick={() => setFlippedChart(flippedChart === 1 ? null : 1)}
                className="flex items-center justify-center cursor-pointer"
                style={{
                  width: "24px",
                  height: "24px",
                  border: "none",
                  background: "transparent",
                  padding: 0,
                  marginLeft: "4px",
                }}
              >
                <i
                  className="fi fi-rr-flip-horizontal"
                  style={{
                    fontSize: "18px",
                    color: "currentColor",
                    lineHeight: 1,
                  }}
                />
              </button>
            </div>
          </div>
          {renderFilterButtons("simActivation")}
          <div className="flex justify-center items-center h-full">
            <span style={{ fontSize: '16px', color: '#666' }}>No Data Available</span>
          </div>
        </div>
      );
    }

    const { chartData: timeBasedData, serviceProviders } = dataSource.simActivationTrend
      ? processTimeBasedBarChartData(dataSource.simActivationTrend, filter, selectedTenantId, 'simActivation')
      : { chartData: [], serviceProviders: [] };

// 🔥 Extract dynamic providers from all data records
const dynamicProvidersSet = new Set<string>();

timeBasedData.forEach(item => {
  Object.keys(item).forEach(key => {
    // Exclude non-provider keys
    if (
      key !== "time" &&
      key !== "firstDate" &&
      key !== "isGap"
    ) {
      dynamicProvidersSet.add(key);
    }
  });
});

// Convert to array
const dynamicProviders = Array.from(dynamicProvidersSet);

    // Assign colors to service providers
    dynamicProviders.forEach((provider) => {
      if (!SERVICE_PROVIDER_COLORS[provider]) {
        let hash = 5381;
        for (let i = 0; i < provider.length; i++) {
          hash = (hash * 33) ^ provider.charCodeAt(i);
        }
        const colorIndex = Math.abs(hash) % BLUE_SHADE_COLORS.length;
        SERVICE_PROVIDER_COLORS[provider] = BLUE_SHADE_COLORS[colorIndex];
      }
    });

const isWeeklyFilter = ["1_month", "3_month", "6_month", "1_year"].includes(filter);
const shouldShowDualXAxis = isWeeklyFilter;

    const legendRows = Math.ceil(dynamicProviders.length / 4);
    const legendHeight = Math.min(legendRows * 20 + 10, 50);

    // Process data with month gaps (keeping your existing logic)
    const processDataWithMonthGaps = (data: any[]) => {
      if (!shouldShowDualXAxis || data.length === 0) return { processedData: data, monthPositions: [] };

      const processedData: any[] = [];
      const monthPositions: { month: string; startIndex: number; endIndex: number; centerIndex: number }[] = [];

      // const monthGroups: { [month: string]: any[] } = {};
  const monthGroups: { [key: string]: any[] } = {};
      data.forEach(item => {
        if (item.time.includes('-W')) {
          const [year, month] = item.time.split("-W")[0].split("-");
      const monthKey = `${year}-${month}`;
           if (!monthGroups[monthKey]) {
        monthGroups[monthKey] = [];
      }
      monthGroups[monthKey].push(item);
    }
      });

      const monthKeys = Object.keys(monthGroups);

    // Always sort month keys in natural calendar order for all weekly filters
if (["1_month", "3_month", "6_month", "1_year"].includes(filter)) {
    monthKeys.sort((a, b) => {
      const [ya, ma] = a.split("-").map(Number);
      const [yb, mb] = b.split("-").map(Number);

      if (ya !== yb) return ya - yb; // year first
      return ma - mb;               // then month
    });
}


      monthKeys.forEach((month, monthIdx) => {
        const monthData = monthGroups[month];

        monthData.sort((a, b) => {
          const getWeekNum = (item: any) => {
            if (item.time.includes('-W')) {
              return parseInt(item.time.split('-W')[1]);
            } else if (item.time.startsWith('W')) {
              return parseInt(item.time.substring(1));
            }
            return 0;
          };
          return getWeekNum(a) - getWeekNum(b);
        });

        const startIndex = processedData.length;

        monthData.forEach(item => {
          processedData.push(item);
        });

        const endIndex = processedData.length - 1;
        const weekCount = monthData.length;

        let centerIndex: number;
        if (weekCount === 1) {
          centerIndex = startIndex;
        } else if (weekCount % 2 === 1) {
          centerIndex = startIndex + Math.floor(weekCount / 2);
        } else {
          centerIndex = startIndex + (weekCount / 2) - 0.5;
        }

        monthPositions.push({
          month,
          startIndex,
          endIndex,
          centerIndex: Math.floor(centerIndex)
        });

        if (monthIdx < monthKeys.length - 1) {
          for (let i = 0; i < 2; i++) {
            processedData.push({
              time: `gap-${month}-${i}`,
              isGap: true,
              ...dynamicProviders.reduce((acc, provider) => ({ ...acc, [provider]: 0 }), {})
            });

          }
        }
      });

      return { processedData, monthPositions };
    };
const getFixedWeekOfMonth = (date: Date) => {
  const day = date.getDate();
  if (day <= 7) return 1;
  if (day <= 14) return 2;
  if (day <= 21) return 3;
  return 4; // last week
};

interface MonthPosition {
  month: string;
  startIndex: number;
  endIndex: number;
  centerIndex: number;
}


let monthPositions: MonthPosition[] = [];

let processedTimeBasedData = timeBasedData; 

if (isWeeklyFilter) {
  // Step 1 → Normalize YYYY-MM-DD → MM-Wx
  const normalized = timeBasedData.map(item => {
    const raw = item.time;

    // 1Y = monthly
    if (filter === "1_year") {
      if (/^\d{4}-\d{2}$/.test(raw)) {
        return { ...item, time: raw.split("-")[1], firstDate: raw };
      }
      return item;
    }

    // weekly buckets for 1M/3M/6M
    if (/^\d{4}-\d{2}-\d{2}$/.test(raw)) {
      const [y, m, d] = raw.split("-");
      const dateObj = new Date(+y, +m - 1, +d);
      const week = getFixedWeekOfMonth(dateObj);
      return {
        ...item,
        time: `${y}-${m}-W${week}`,
        firstDate: raw,
      };
    }

    return item;
  });

  // Step 2 → Insert month gaps + find month centers
  const result = processDataWithMonthGaps(normalized);
  processedTimeBasedData = result.processedData;
  monthPositions = result.monthPositions;

} else {

 
  if (filter === "1_day") {
    processedTimeBasedData = timeBasedData.map(item => {
      const raw = item.time;

    
      let hhmm = raw;
      if (raw.includes("T")) {
        hhmm = raw.split("T")[1].slice(0, 5);
      } else if (raw.includes(" ")) {
        hhmm = raw.split(" ")[1].slice(0, 5);
      }

      return {
        ...item,
        time: hhmm,     
        firstDate: raw,   
      };
    });

  }else {
  processedTimeBasedData = timeBasedData;
}
}


const nivoData = dynamicProviders.map(provider => ({
  id: provider,
  color: SERVICE_PROVIDER_COLORS[provider],
  data: processedTimeBasedData.map(d => ({
    x: d.time,
    y: d[provider] ?? 0,   
    originalData: d,
    isGap: d.isGap     
  }))
}));



    // Format X-axis labels
    const formatXAxis = (value: string) => {
      if (!value) return '';

      // 1-day filter: "YYYY-MM-DDTHH:MM:SS"
      if (/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/.test(value)) {
        return value.split("T")[1].slice(0, 5);
      }

      // 5-day filter: "YYYY-MM-DD"
      if (/^\d{4}-\d{2}-\d{2}$/.test(value)) {
        const [year, month, day] = value.split("-");
        const dateObj = new Date(Number(year), Number(month) - 1, Number(day));
        const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
        return `${monthNames[dateObj.getMonth()]} ${day}`;
      }

      // Weekly format: "MM-Wxx" or "Wxx"
      if (value.includes("-W")) {
        return "W" + value.split("-W")[1];
      } else if (value.startsWith("W")) {
        return value;
      }

      return value;
    };

    // Calculate Y-axis domain and ticks
    const getYAxisConfig = () => {
      if (processedTimeBasedData.length === 0) {
        return { min: 0, max: 100, ticks: [0, 25, 50, 75, 100] };
      }
     const { min, max } = getDataMinMax(processedTimeBasedData, dynamicProviders);

      const ticks = calculateNiceTicks(min, max);
      return { min: ticks[0], max: ticks[ticks.length - 1], ticks };
    };

    const yAxisConfig = getYAxisConfig();

    // Custom tooltip for Nivo
    const CustomTooltip = ({ slice }: any) => {
      if (!slice || !slice.points || slice.points.length === 0) return null;

      // Get the first point to extract the time/x value
      const firstPoint = slice.points[0];
      const timeValue = firstPoint.data.x;

      // Find the original data object
      const originalData = processedTimeBasedData.find(d => d.time === timeValue);
      if (!originalData || originalData.isGap) return null;

      const payload = slice.points.map((pt: any) => ({
        name: pt.seriesId,           
        dataKey: pt.seriesId,       
        value: pt.data.y,         
        formatted: pt.data.y?.toLocaleString() ?? "0",
        color: pt.color || pt.seriesColor || "#000", 
      }));





      return (
        <TimeBasedTooltip
          active={true}
          payload={payload}
          label={timeValue}
          filter={filter}
          fullData={timeBasedData}
        />
      );
    };

    // Render month labels for dual axis
const renderMonthLayer = ({ xScale, innerHeight }: any) => {
  if (!shouldShowDualXAxis || monthPositions.length === 0) return null;

  const monthNames = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

  return (
    <g>
      {monthPositions.map((m, idx) => {
        // Get the actual time values from the processed data
        const startValue = processedTimeBasedData[m.startIndex]?.time;
        const endValue = processedTimeBasedData[m.endIndex]?.time;

        if (!startValue || !endValue) return null;

        // Get X positions using the time values (not indices!)
        const startX = xScale(startValue);
        const endX = xScale(endValue);
        const barWidth = xScale.bandwidth();
        
        // Calculate center position
        const centerX = (startX + endX + barWidth) / 2;

        // month is "12" for December, so we need index 11 (12-1)
        const [, month] = m.month.split("-");
const monthIndex = parseInt(month) - 1;


        return (
          <text
            key={idx}
            x={centerX}
            y={innerHeight + 30}
            textAnchor="middle"
            fontSize={12}
            fill= "currentColor"
            fontFamily="Calibri"  
          >
            {monthNames[monthIndex]}
          </text>
        );
      })}
    </g>
  );
};


    const MonthlyTick = ({ x, y, value }: any) => {
  const monthNames = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
  return (
    <g transform={`translate(${x}, ${y + 12})`}>
      <text textAnchor="middle" style={{ fontSize: 11, fill: "#000" }}>
        {monthNames[parseInt(value)]}
      </text>
    </g>
  );
};

const CustomWeekXAxisTick = (tick: any): JSX.Element => {
  const { value, x, y } = tick;

  if (!value) return <g />;

  if (String(value).startsWith("gap-")) return <g />;

  let display = value;

  if (/^\d{4}-\d{2}-\d{2}T/.test(value)) {
    display = value.split("T")[1].substring(0, 5); // HH:mm
  }

  else if (/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    const [year, month, day] = value.split("-");
    const dateObj = new Date(+year, +month - 1, +day);
    const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    display = `${months[dateObj.getMonth()]} ${day}`;
  }

  else if (value.includes("-W")) {
    display = "W" + value.split("-W")[1];
  }

  return (
    <g transform={`translate(${x}, ${y + 12})`}>
      <text
        textAnchor="middle"
        style={{
          fontSize: 9,
          fill: "currentColor",
          fontFamily: "Calibri, sans-serif",
          fontWeight: 500,
        }}
      >
        {display}
      </text>
    </g>
  );
};



const nivoBarData = processedTimeBasedData.map(d => {
  const row: any = { time: d.time };
  dynamicProviders.forEach(provider => {
    row[provider] = Number(d[provider] ?? 0);
  });
  return row;
});


const sortedProviders = [...dynamicProviders].sort((a, b) => {
  const sumA = processedTimeBasedData.reduce(
    (t, row) => t + Number(row[a] ?? 0),
    0
  );

  const sumB = processedTimeBasedData.reduce(
    (t, row) => t + Number(row[b] ?? 0),
    0
  );

  return sumA - sumB; // low → high
});

const formatTooltipLabel = (
  timeValue: string,
  filter: string,
  originalData: any
) => {
  const actualDate = originalData?.firstDate || timeValue;

  if (filter === "5_day") {
    return dayjs(actualDate).format("MMM DD");
  }

  if (filter === "1_day") {
    return actualDate.split("T")[1]?.slice(0, 5);
  }

  if (timeValue.includes("-W")) {
     const [ym, week] = timeValue.split("-W"); // "2026-01"
  const [year, month] = ym.split("-");


    const monthNames = ["Jan","Feb","Mar","Apr","May","Jun",
                        "Jul","Aug","Sep","Oct","Nov","Dec"];

    const monthIndex = parseInt(month, 10) - 1;

  return `${monthNames[monthIndex]} - W${week}`;
}


  return actualDate;
};
   return (
      <div
        className="bg-white p-4 rounded-lg shadow-md graph"
        style={{
          height: `400px`,
          width: "100%",
          overflow: 'visible',
        }}
      >
        <div className="bg-gray-100 flex justify-between items-center p-4 chart-title">
          <div className="flex items-center">
            <h2 className="font-semibold">{dataSource?.simActivationTrend?.data?.title || "SIM Activation Trend"}</h2>
          </div>
          <div className="flex items-center">
            <button
              onClick={() => setFlippedChart(flippedChart === 1 ? null : 1)}
              className="flex items-center justify-center cursor-pointer"
              style={{
                width: "24px",
                height: "24px",
                border: "none",
                background: "transparent",
                padding: 0,
                marginLeft: "4px",
              }}
            >
              <i
                className="fi fi-rr-flip-horizontal"
                style={{
                  fontSize: "18px",
                  color: "currentColor",
                  lineHeight: 1,
                }}
              />
            </button>
          </div>
        </div>

        {renderFilterButtons("simActivation")}

        {flippedChart === 1 ? (
          <div style={{
            height: `${cardHeight + legendHeight - 20}px`,
            padding: "10px",
            overflow: 'hidden'
          }}>
            <Table
              dataSource={timeBasedData.map((item, index) => ({ ...item, key: index }))}
              columns={[
                {
                  title: (
                    <span style={{ fontSize: "14px", fontFamily: "Calibri, sans-serif" }}>
                      Time Period
                    </span>
                  ),
                  dataIndex: "time",
                  key: "time",
                  width: 120,
                  fixed: 'left',
                 render: (value: string) => {
  let displayValue = value;
  if (value.includes('-W')) {
    const [monthIndex, week] = value.split('-W');
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
      'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    // monthIndex is "12" for December, array needs index 11
    const monthName = monthNames[parseInt(monthIndex) - 1] || monthIndex;
    displayValue = `${monthName}-W${week}`;
  }
  return (
    <span style={{ fontSize: "14px", fontFamily: "Calibri, sans-serif" }}>
      {displayValue}
    </span>
  );
},
                },
                ...dynamicProviders.map((provider, index) => ({
                  title: provider,
                  dataIndex: provider,
                  key: provider,
                 width: Math.max(80, Math.floor((window.innerWidth - 200) / dynamicProviders.length)),

                  render: (value: number) => (value > 0 ? value.toLocaleString() : "-"),
                  onHeaderCell: () => ({
                    style: {
                      fontSize: '12px',
                      fontFamily: "Calibri, sans-serif",
                      padding: '2px 4px',
                      whiteSpace: 'nowrap',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis'
                    }
                  }),
                  onCell: () => ({
                    style: {
                      fontSize: '12px',
                      fontFamily: "Calibri, sans-serif",
                      padding: '2px 4px'
                    }
                  })
                })),
              ]}
              pagination={false}
              scroll={{
                y: cardHeight + legendHeight - 120,
                x: undefined
              }}
              size="small"
              style={{
                fontSize: '9px',
                width: '100%'
              }}
            />
          </div>
        ) : (
          <div style={{
            height: `${cardHeight + legendHeight}px`,
            overflow: 'visible',
            position: 'relative',
            paddingBottom: '60px' // Add space for button
          }}>
            <div style={{ height: `${cardHeight + legendHeight - 60}px` }}>
              <ResponsiveBar
    data={nivoBarData}
    key={filter}
keys={sortedProviders}

  indexBy="time"
  groupMode="stacked" 
  innerPadding={0}              
  margin={{ top: 20, right: 40, bottom: shouldShowDualXAxis ? 35 : 20, left: 80 }}
  padding={0.25}
  colors={(bar) => SERVICE_PROVIDER_COLORS[bar.id]}
  enableLabel={false}
  axisTop={null}
  axisRight={null}
  axisLeft={{
    tickSize: 0,
    tickPadding: 10,
    tickRotation: 0,
    legend: "SIM Count",
    legendPosition: "middle",
    legendOffset: -70
  }}
  axisBottom={{
    tickSize: 0,
    tickPadding: 10,
    tickRotation: 0,
  renderTick: CustomWeekXAxisTick

  }}
  layers={[
    "grid",
    "axes",
    renderMonthLayer, 
    "bars",
    "markers",
    "legends"
  ]}
 tooltip={({ id, value, color, data }) => {
  if (data.isGap) return null;

  return (
    <div
      className="recharts-default-tooltip"
      style={{
        background: "#fff",
        padding: "10px 12px",
        border: "1px solid #ccc",
        borderRadius: 8,
        fontSize: 12,
        whiteSpace: "nowrap",
        color: "#000",
        boxShadow: "0 2px 6px rgba(0,0,0,0.2)",
        minWidth: "180px"
      }}
    >
      {/* TIME */}
      <div style={{ fontWeight: 700, marginBottom: 8, textAlign: "center" }}>
      {filter === "1_day"
    ? String(data.time)  
    : formatTooltipLabel(
        data.originalData?.firstDate ?? data.time,
        filter,
        data.originalData
      )}
      </div>

      {/* ONLY PROVIDERS WITH VALUE > 0 */}
      {sortedProviders
        .filter(sp => Number(data[sp] ?? 0) > 0)
        .map(sp => (
          <div
            key={sp}
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: 6
            }}
          >
            <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
              <span
                style={{
                  width: 10,
                  height: 10,
                  backgroundColor: SERVICE_PROVIDER_COLORS[sp],
                  borderRadius: 2
                }}
              />
              {sp}
            </div>

            <span>{Number(data[sp]).toLocaleString()}</span>
          </div>
        ))}
    </div>
  );
}}


    theme={{
                  grid: {
                    line: {
                      strokeWidth: 1,
                      strokeDasharray: "2 2",   
                    },
                  },
                  axis: {
                    domain: {
                      line: {
                        stroke: "#e6e6e6",
                        strokeWidth: 1,
                      }
                    },
                    ticks: {
                      line: {
                        stroke: "#e6e6e6",
                        strokeWidth: 1
                      },
                      text: {
                        //  fontSize: filter === "1_year" ? 10  : 12,
                        fontSize: 12,
                        fill: "currentColor",
                        fontWeight: 500,
                        fontFamily: "Calibri, sans-serif",
                      }
                    },
                    legend: {
                      text: {
                        fontSize: 16,
        // fontWeight: 600,
        fill: "currentColor",
        fontFamily: "Calibri",
                      }
                    }
                  },
                  tooltip: {
                    container: {
                      fontSize: 11
                    }
                  }
                }}

/>

            </div>
            <div
              style={{
                width: "100%",
                textAlign: "center",
                position: "absolute",
                left: 0,
                right: 0,
              }}
              className="group"
            >
              <button className="peer px-3 py-1 text-[16px] service-provider-button rounded-md shadow cursor-pointer">
                Service Providers
              </button>

              <div
                className="absolute left-1/2 -translate-x-1/2 bottom-full mb-2 hidden peer-hover:block service-provider-tooltip  shadow-lg rounded-md border p-3 w-48 z-50"
                style={{
                  pointerEvents: "none",
                  maxHeight: "none",
                  overflow: "visible"
                }}
              >
                {dynamicProviders.map((sp, idx) => (
                  <div key={idx} className="flex items-center gap-2 mb-2">
                    <div
                      className="w-3 h-3 rounded-full"
                      style={{
                        backgroundColor: SERVICE_PROVIDER_COLORS[sp],
                        borderRadius: "2px"
                      }}
                    ></div>
                    <span className="text-xs">{sp}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    );
  };
// Safe: hooks at top-level of component
const dataSource = useCache ? cachedData : chartData;

const serviceProviders2: string[] = useMemo(() => {
  // Use fresh data source, not cached
  const currentData = useCache ? cachedData : chartData;
  const metaProviders = currentData?.serviceProviderVsStatus?.meta?.providers;
  
  // console.log("Meta Providers:", metaProviders);
  // console.log("useCache:", useCache);
  // console.log("Current Data Source:", currentData?.serviceProviderVsStatus);
  
  if (!metaProviders) return [];
  return Object.values(metaProviders).map(String);
}, [chartData, cachedData, useCache]);

// Build dropdown items
const serviceProviderOptions2 = useMemo(
  () => serviceProviders2.map((p) => ({ value: p, label: p })),
  [serviceProviders2]
);

// Auto-set default selected provider ONLY when empty
useEffect(() => {
  // console.log("Service Providers 2:", serviceProviders2);
  
  if (serviceProviders2.length > 0) {
    // If current selection is not in the new list, reset to first
    // if (!selectedServiceProvider2 || !serviceProviders2.includes(selectedServiceProvider2)) {
      setSelectedServiceProvider2(serviceProviders2[0]);
    // }
  } else {
    setSelectedServiceProvider2("");
  }
}, [serviceProviders2]);
useEffect(() => {
  const dataSource = useCache ? cachedData : chartData;
  const filter = getActualFilterFromData(
    dataSource.serviceProviderVsStatus,
    internalFilterServiceVsStatus
  );
  
  if (dataSource.serviceProviderVsStatus && filter !== "no_data") {
    const statuses = getUniqueStatusesFromData(
      dataSource.serviceProviderVsStatus,
      filter
    );
    setUniqueStatuses(statuses);
  }
}, [useCache, cachedData, chartData, internalFilterServiceVsStatus]);

// Keep your existing useEffect for selectedStatuses:
useEffect(() => {
  if (uniqueStatuses.length > 0) {
    setSelectedStatuses(prev => {
      if (prev.length === 0 || !prev.every(s => uniqueStatuses.includes(s))) {
        return [...uniqueStatuses];
      }
      return prev;
    });
  }
}, [uniqueStatuses]);

const getUniqueStatusesFromData = (data: any, filter: string): string[] => {
    if (!data?.data?.data?.[filter]) return [];

    const statusSet = new Set<string>();

    data.data.data[filter].forEach((item: any) => {
      if (item.records && Array.isArray(item.records)) {
        item.records.forEach((record: any) => {
          if (record.status_counts) {
            Object.keys(record.status_counts).forEach((status) => {
              statusSet.add(status);
            });
          }
        });
      }
    });

    return Array.from(statusSet).sort();
  };
const renderTimeBasedBubbleLineChart = () => {
  const cardHeight = 280;
  const dataSource = useCache ? cachedData : chartData;

  if (loadingServiceProviderVsStatus) {
    return (
      <div className="bg-white p-4 rounded-lg shadow-md graph" style={{ height: "400px", width: "100%" }}>
        <div className="bg-gray-100 flex justify-between items-center p-4 chart-title">
          <div className="flex items-center gap-4">
            <h2 className="font-semibold">Service Providers vs Status</h2>
          </div>
          <div className="flex items-center gap-2">
            <Select
              options={serviceProviderOptions2}
              value={
                selectedServiceProvider2 && serviceProviderOptions2.length > 0
                  ? { value: selectedServiceProvider2, label: selectedServiceProvider2 }
                  : null
              }
              onChange={(selected) => {
                setSelectedServiceProvider2(selected?.value || "");
              }}
              styles={DropdownStyles}
            />
            <i
              className="fi fi-rr-flip-horizontal cursor-pointer text-black-600"
              style={{ fontSize: "24px", marginTop: "5px" }}
              onClick={() => setFlippedChart(flippedChart === 2 ? null : 2)}
            ></i>
          </div>
        </div>
        {renderFilterButtons("serviceVsStatus")}
        <div className="flex justify-center items-center" style={{ height: "calc(100% - 100px)" }}>
          <Spin size="large" />
        </div>
      </div>
    );
  }

  const filter = getActualFilterFromData(
    dataSource.serviceProviderVsStatus,
    internalFilterServiceVsStatus
  );

  if (filter === "no_data") {
    return (
      <div className="bg-white p-4 rounded-lg shadow-md graph" style={{ height: "400px", width: "100%" }}>
        <div className="bg-gray-100 flex justify-between items-center p-4 chart-title">
          <div className="flex items-center gap-4">
            <h2 className="font-semibold">Service Providers vs Status</h2>
          </div>
          <div className="flex items-center gap-2">
            <Select
              options={serviceProviderOptions2}
              value={
                selectedServiceProvider2 && serviceProviderOptions2.length > 0
                  ? { value: selectedServiceProvider2, label: selectedServiceProvider2 }
                  : null
              }
              onChange={(selected) => {
                setSelectedServiceProvider2(selected?.value || "");
              }}
              styles={DropdownStyles}
            />
            <i
              className="fi fi-rr-flip-horizontal cursor-pointer text-black-600"
              style={{ fontSize: "24px", marginTop: "5px" }}
              onClick={() => setFlippedChart(flippedChart === 2 ? null : 2)}
            ></i>
          </div>
        </div>
        {renderFilterButtons("serviceVsStatus")}
        <div className="flex justify-center items-center" style={{ height: "calc(100% - 100px)" }}>
          <span style={{ fontSize: "16px", color: "#666" }}>No Data Available</span>
        </div>
      </div>
    );
  }

  // ---------- helpers / types ----------

  const generateStatusColors = (statuses: string[]): Record<string, string> => {
    const baseColors = [
      "#00B894",
      "#FF7675",
      "#FABE58",
      "#74B9FF",
      "#A29BFE",
      "#81ECEC",
      "#D980FA",
      "#55EFC4",
      "#FF9FF3",
      "#00CEC9",
      "#BDC3C7",
      "#FFEAA7",
    ];

    const colorMap: Record<string, string> = {};
    statuses.forEach((status, index) => {
      colorMap[status] = baseColors[index % baseColors.length];
    });

    return colorMap;
  };

  interface StatusData {
    time: string;
    isGap?: boolean;
    [key: string]: string | number | boolean | null | undefined;
  }

  

  const processTimeBasedStatusData = (
    data: any[],
    selectedProvider: string,
    filter: string
  ): StatusData[] => {
    if (!Array.isArray(data)) return [];

    const uniqueStatusesLocal = getUniqueStatusesFromData(
      { data: { data: { [filter]: data } } },
      filter
    );

    let providersToProcess: any[] = [];

    if (selectedProvider === "All service providers") {
      providersToProcess = data.filter(
        (provider) =>
          provider.records &&
          Array.isArray(provider.records) &&
          provider.records.length > 0
      );
    } else {
      const providerData = data.find(
        (item: any) => item.service_provider === selectedProvider
      );
      if (!providerData) return [];
      providersToProcess = [providerData];
    }

    const timeGroups: Record<string, StatusData> = {};

    providersToProcess.forEach((provider) => {
      if (!provider.records || !Array.isArray(provider.records)) return;

     provider.records.forEach((record: any) => {
  if (!record.date || !record.status_counts) return;

  const timestamp = record.date;
  let timeKey: string;
  let date: Date | null = null;
  let monthIndex: string | null = null;

  if (filter === "1_day") {
    date = new Date(timestamp);
    timeKey = `${date.getHours().toString().padStart(2, "0")}:00`;
  } 
  else if (filter === "5_day") {
    date = new Date(timestamp);
    timeKey = date.toLocaleDateString("en-US", {
      month: "short",
      day: "numeric",
    });
  } 
  else if (filter === "1_month") {
    date = new Date(timestamp);
    monthIndex = date.getMonth().toString().padStart(2, "0");
    const week = Math.ceil(date.getDate() / 7);
    timeKey = `${monthIndex}-W${week}`;
  } 
  else if (["3_month", "6_month", "1_year"].includes(filter)) {
    date = new Date(timestamp);
    monthIndex = date.getMonth().toString().padStart(2, "0");
    const week = Math.ceil(date.getDate() / 7);
    timeKey = `${monthIndex}-W${week}`;
  } 
  else if (["5_years", "max"].includes(filter)) {
    if (/^\d{4}$/.test(timestamp)) {
      timeKey = timestamp;
    } else {
      date = new Date(timestamp);
      timeKey = date.getFullYear().toString();
    }
  } 
  else {
    date = new Date(timestamp);
    timeKey = date.toLocaleDateString();
  }

  // ✅ 1️⃣ CREATE OBJECT FIRST
  if (!timeGroups[timeKey]) {
    timeGroups[timeKey] = {
      time: timeKey,
      ...Object.fromEntries(uniqueStatusesLocal.map((s) => [s, 0])),
    } as StatusData;
  }

  // ✅ 2️⃣ ATTACH METADATA SAFELY
  if (date && monthIndex !== null) {
    (timeGroups[timeKey] as any).__date = date;
    (timeGroups[timeKey] as any).__monthKey =
      `${date.getFullYear()}-${monthIndex}`; // YYYY-MM
    (timeGroups[timeKey] as any).__monthLabel =
      `${date.toLocaleString("en-US", { month: "short" })}`;
  }

  // ✅ 3️⃣ ADD STATUS COUNTS
  Object.entries(record.status_counts).forEach(([status, count]) => {
    if (uniqueStatusesLocal.includes(status)) {
      (timeGroups[timeKey] as any)[status] += Number(count || 0);
    }
  });
});

    });

    const result = Object.values(timeGroups).sort((a: StatusData, b: StatusData) => {
      if (filter === "1_day") {
        return parseInt(a.time.split(":")[0]) - parseInt(b.time.split(":")[0]);
      } else if (["1_month", "3_month", "6_month", "1_year"].includes(filter)) {
         const aDate = (a as any).__date;
  const bDate = (b as any).__date;

  return new Date(aDate).getTime() - new Date(bDate).getTime();
      } else if (["5_years", "max"].includes(filter)) {
        return parseInt(a.time) - parseInt(b.time);
      } else {
        return new Date(a.time).getTime() - new Date(b.time).getTime();
      }
    });

    return result;
  };

//  useEffect(() => {
//   const statuses = getUniqueStatusesFromData(
//     dataSource.serviceProviderVsStatus,
//     filter
//   );
//   setUniqueStatuses(statuses);
// }, [dataSource.serviceProviderVsStatus, filter]);
// useEffect(() => {
//   if (uniqueStatuses.length > 0) {
//     setSelectedStatuses(prev => {
//       if (prev.length === 0 || !prev.every(s => uniqueStatuses.includes(s))) {
//         return [...uniqueStatuses];
//       }
//       return prev;
//     });
//   }
// }, [uniqueStatuses]);

  const statusOptions = uniqueStatuses.map((s) => ({
    value: s,
    label: s,
  }));

  const processDataWithMonthGapsForStatus = (data: StatusData[]) => {
    const shouldShowDualXAxis = ["1_month","3_month", "6_month", "1_year"].includes(filter);
    if (!shouldShowDualXAxis || data.length === 0) {
      return { processedData: data, monthPositions: [] as any[] };
    }

    const processedData: StatusData[] = [];
    const monthPositions: Array<{
      month: string;
      monthLabel: string;
      startIndex: number;
      endIndex: number;
      centerIndex: number;
      weekCount: number;
    }> = [];

    const monthGroups: { [month: string]: StatusData[] } = {};
    data.forEach((item) => {
      if (item.time.includes("-W")) {
        const monthKey = (item as any).__monthKey;
        if (!monthGroups[monthKey]) monthGroups[monthKey] = [];
        monthGroups[monthKey].push(item);
      }
    });

    let sortedMonths = Object.keys(monthGroups);

    if (filter === "1_year") {
      const now = new Date();
      const currentMonth = now.getMonth();
      sortedMonths.sort((a, b) => {
        const monthA = parseInt(a);
        const monthB = parseInt(b);
        const distanceA = (currentMonth - monthA + 12) % 12;
        const distanceB = (currentMonth - monthB + 12) % 12;
        return distanceB - distanceA;
      });
    } else {
     sortedMonths.sort(
  (a, b) =>
    new Date(a + "-01").getTime() -
    new Date(b + "-01").getTime()
);

    }

    sortedMonths.forEach((month, idx, arr) => {
      const monthData = monthGroups[month];
      const startIndex = processedData.length;

      monthData.sort((a, b) => {
        const weekA = parseInt(a.time.split("-W")[1]);
        const weekB = parseInt(b.time.split("-W")[1]);
        return weekA - weekB;
      });

      monthData.forEach((item) => processedData.push(item));

      const endIndex = processedData.length - 1;
      const weekCount = monthData.length;

     const monthLabel =
  (monthData[0] as any).__monthLabel || month;

monthPositions.push({
  month,                 // YYYY-MM
  monthLabel,            // "Jan 2026"
  startIndex,
  endIndex,
  centerIndex: startIndex + Math.floor(weekCount / 2),
  weekCount,
});


      if (idx < arr.length - 1) {
        for (let i = 0; i < 2; i++) {
          const gap: StatusData = { time: `spacer-${month}-${i}`, isGap: true };
          uniqueStatuses.forEach((status) => {
            gap[status] = null;
          });
          processedData.push(gap);
        }
      }
    });

    return { processedData, monthPositions };
  };

  const STATUS_COLORS = generateStatusColors(uniqueStatuses);

  const rawTimeBasedData = processTimeBasedStatusData(
    dataSource.serviceProviderVsStatus?.data?.data?.[filter] ?? [],
    selectedServiceProvider2 || serviceProviders[0],
    filter
  );

  const { processedData, monthPositions } =
    processDataWithMonthGapsForStatus(rawTimeBasedData);

  const legendRows = Math.ceil(uniqueStatuses.length / 4);
  const legendHeight = Math.min(legendRows * 20 + 10, 50);
  const baseWidth = "100%";

  // ----- data for Nivo -----

  const gapMap = new Map<string, boolean>();

  const safeDataForNivo: Record<string, string | number>[] = processedData.map(
    (item) => {
      const cleanItem: Record<string, string | number> = { time: item.time };

      Object.entries(item).forEach(([key, value]) => {
        if (key === "isGap") return;
        if (item.isGap && key !== "time") {
          cleanItem[key] = 0;
        } else if (typeof value === "number" || typeof value === "string") {
          cleanItem[key] = value;
        } else {
          cleanItem[key] = 0;
        }
      });

      gapMap.set(item.time, !!item.isGap);

      return cleanItem;
    }
  );

  // effective selected statuses (empty = all)
  const effectiveSelectedStatuses =
    selectedStatuses.length > 0 ? selectedStatuses : [];

  const maxValue =
    processedData.length === 0 || effectiveSelectedStatuses.length === 0
      ? 0
      : Math.max(
          ...processedData.flatMap((d) =>
            effectiveSelectedStatuses.map((status) =>
              Number(d[status] || 0)
            )
          )
        );
       
  const paddedMax = maxValue > 0 ? maxValue * 1.3 : 10;

  const formatMonthWeek = (value: string | number) => {
    const v = String(value);
    if (!v.includes("-W")) return v;

    const [monthNum, week] = v.split("-W");
    const monthIndex = parseInt(monthNum, 10);
    const monthNames = [
      "Jan",
      "Feb",
      "Mar",
      "Apr",
      "May",
      "Jun",
      "Jul",
      "Aug",
      "Sep",
      "Oct",
      "Nov",
      "Dec",
    ];
    return `${monthNames[monthIndex]}-W${week}`;
  };

const CheckboxOption = (props: any) => {
  const { data, isFocused } = props;
  const isSelectAll = data.value === "ALL";

  const allSelected =
    selectedStatuses.length === uniqueStatuses.length &&
    selectedStatuses.length > 0;

  const isChecked = isSelectAll
    ? allSelected
    : selectedStatuses.includes(data.value);

  const handleClick = () => {
    if (isSelectAll) {
      if (allSelected) {
        setSelectedStatuses([]);
      } else {
        setSelectedStatuses([...uniqueStatuses]);
      }
    } else {
      setSelectedStatuses((prev) =>
        prev.includes(data.value)
          ? prev.filter((v) => v !== data.value)
          : [...prev, data.value]
      );
    }
  };

  return (
    <div
      onClick={(e) => {
        e.preventDefault();
        e.stopPropagation();
        handleClick();
      }}
      style={{
        display: "flex",
        alignItems: "center",
        padding: "6px 10px",
        cursor: "pointer",
        backgroundColor: isFocused
          ? isDarkMode
            ? "#0b2a52"
            : "#f3f4f6"
          : isDarkMode
          ? "#031731"
          : "#ffffff",
        color: isDarkMode ? "#ffffff" : "#000000",
        position: "relative",
      }}
    >
      {/* ✅ CUSTOM CHECKBOX */}
      <div
        style={{
          width: "14px",
          height: "14px",
          borderRadius: "3px",
          border: `1px solid ${
            isDarkMode ? "#64748b" : "#cbd5e1"
          }`,
          backgroundColor: isChecked
            ? "#1E90FF"
            : isDarkMode
            ? "#031731"
            : "#ffffff",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          marginRight: "8px",
        }}
      >
        {isChecked && (
          <span
            style={{
              fontSize: "10px",
              color: "#ffffff",
              lineHeight: 1,
            }}
          >
            ✓
          </span>
        )}
      </div>

      {/* LABEL */}
     <span
  style={{
    fontSize: "14px",
    fontFamily: "Calibri, sans-serif",
    color: isDarkMode ? "#ffffff" : "#000000", // 🔥 FIX
  }}
>
  {props.label}
</span>

    </div>
  );
};



  const CustomMultiValue = ({ index, getValue, ...props }: any) => {
    const maxVisible = 1;
    const selected = getValue();

    if (index >= maxVisible) return null;

    const extraCount = selected.length - maxVisible;

    return (
      <>
        <components.MultiValue {...props} />
        {extraCount > 0 && index === maxVisible - 1 && (
          <span
            style={{
              marginLeft: "4px",
              fontSize: "14px",
              color: "#555",
              fontFamily: "Calibri, sans-serif",
            }}
          >
            +{extraCount}
          </span>
        )}
      </>
    );
  };

const statusOptionsWithAll = statusOptions.length > 0
    ? [{ value: "ALL", label: "Select All" }, ...statusOptions]
    : statusOptions;
  const handleStatusChange = (selected: any) => {
    if (!selected || selected.length === 0) {
      // no manual selection → treat as ALL
      setSelectedStatuses([]);
      return;
    }

    const clickedSelectAll = selected.some((s: any) => s.value === "ALL");

    if (clickedSelectAll) {
      // toggle ALL ↔ NONE(=ALL)
          const allAlreadySelected = selectedStatuses.length === uniqueStatuses.length && selectedStatuses.length > 0;
      if (allAlreadySelected) {
        setSelectedStatuses([]); // none explicitly = all
      } else {
        setSelectedStatuses([...uniqueStatuses]);
      }
    } else {
      setSelectedStatuses(selected.map((s: any) => s.value));
    }
  };
  const stackedMax = Math.max(
  10,
  ...processedData.map((d) =>
    effectiveSelectedStatuses.reduce(
      (sum, status) => sum + Number(d[status] ?? 0),
      0
    )
  )
);
 const sortedSelectedStatuses = effectiveSelectedStatuses.sort(
  (a, b) => uniqueStatuses.indexOf(a) - uniqueStatuses.indexOf(b)
);
  return (
    <div
      className="bg-white p-4 rounded-lg shadow-md graph"
      style={{
        height: `${cardHeight + legendHeight + 80}px`,
        width: baseWidth,
        overflow: "visible",
        position: "relative",
        zIndex: 1,
      }}
    >
      <div className="bg-gray-100 flex justify-between items-center p-4 chart-title">
        <div className="flex items-center gap-4">
          <h2 className="font-semibold">Service Providers vs Status</h2>
        </div>
        <div className="flex items-center gap-2">
          <Select
            options={serviceProviderOptions2}
            value={
              selectedServiceProvider2
                ? { value: selectedServiceProvider2, label: selectedServiceProvider2 }
                : null
            }
            onChange={(selected) => {
              setSelectedServiceProvider2(selected?.value || "");
            }}
            styles={DropdownStyles}
          />

          <div
              className={`status-select-tooltip-wrapper ${isDarkMode ? "dark-mode" : ""}`}
            title={
              selectedStatuses.length > 0
                ? selectedStatuses.join(", ")
                : uniqueStatuses.join(", ")
            }
          >
 
<Select
  // classNamePrefix="status-select"
  isMulti
  closeMenuOnSelect={false}
  hideSelectedOptions={false}
  options={statusOptionsWithAll}
  components={{ Option: CheckboxOption, MultiValue: CustomMultiValue }}
  value={
    selectedStatuses.length === uniqueStatuses.length && selectedStatuses.length > 0
      ? [{ value: "ALL", label: "Select All" }]
      : statusOptions.filter(o => selectedStatuses.includes(o.value))
  }
  onChange={handleStatusChange}
  placeholder="Status"
  menuPortalTarget={document.body}
 styles={DropdownStyles}
/>

          </div>

          <i
            className="fi fi-rr-flip-horizontal cursor-pointer text-black-600"
            style={{ fontSize: "24px", marginTop: "5px" }}
            onClick={() => setFlippedChart(flippedChart === 2 ? null : 2)}
          ></i>
        </div>
      </div>

      {renderFilterButtons("serviceVsStatus")}

      {flippedChart === 2 ? (
        // ----- TABLE VIEW -----
        <div
          style={{
            height: `${cardHeight + legendHeight - 20}px`,
            padding: "10px",
            overflow: "hidden",
          }}
        >
          <Table
            dataSource={processedData
              .filter((item) => !item.isGap)
              .map((item, index) => ({ ...item, key: index }))}
            columns={[
              {
                title: (
                  <span style={{ fontSize: "14px", fontFamily: "Calibri, sans-serif" }}>
                    Time Period
                  </span>
                ),
                dataIndex: "time",
                key: "time",
                width: 120,
                fixed: "left" as const,
                render: (value: string) => {
                  let displayValue = value;

                  if (value.includes("-W")) {
                    const [monthIndex, week] = value.split("-W");
                    const monthNames = [
                      "Jan",
                      "Feb",
                      "Mar",
                      "Apr",
                      "May",
                      "Jun",
                      "Jul",
                      "Aug",
                      "Sep",
                      "Oct",
                      "Nov",
                      "Dec",
                    ];
                    const monthName = monthNames[parseInt(monthIndex)] || monthIndex;
                    displayValue = `${monthName}-W${week}`;
                  }

                  if (value.includes("-") && !value.includes("-W")) {
                    displayValue = value.split("-")[0];
                  }

                  return (
                    <span style={{ fontSize: "14px", fontFamily: "Calibri, sans-serif" }}>
                      {displayValue}
                    </span>
                  );
                },
              },
              ...uniqueStatuses.map((status) => ({
                title: status,
                dataIndex: status,
                key: status,
                width: 100,
                render: (value: number) =>
                  value !== null && value !== undefined
                    ? value.toLocaleString()
                    : "0",
                onHeaderCell: () => ({
                  style: {
                    fontSize: "12px",
                    padding: "2px 4px",
                    whiteSpace: "nowrap",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    fontFamily: "Calibri, sans-serif",
                  },
                }),
                onCell: () => ({
                  style: {
                    fontSize: "12px",
                    fontFamily: "Calibri, sans-serif",
                    padding: "2px 4px",
                  },
                }),
              })),
            ]}
            pagination={false}
            scroll={{
              y: cardHeight + legendHeight - 120,
            }}
            size="small"
            style={{
              fontSize: "10px",
              width: "100%",
            }}
            tableLayout="fixed"
          />
        </div>
      ) : (
        // ----- CHART VIEW -----
        <div
          style={{
            height: `${cardHeight + legendHeight - 40}px`,
            padding: "10px",
            overflow: "visible",
          }}
        >
          
          <ResponsiveBar
            key={`${filter}-${effectiveSelectedStatuses.join("|") || "all"}`}
            data={safeDataForNivo}
            keys={sortedSelectedStatuses}
            indexBy="time"
            groupMode="stacked"
            animate={false}
              onClick={(bar) => {
                if (!bar?.data || bar.data.isGap) return;

                const rawTime = String(bar.data.time);  // 👈 Convert to string always

                const timeLabel = rawTime.includes("-W")
                  ? "W" + rawTime.split("-W")[1]
                  : rawTime;

                handleChartClick({ time: timeLabel }, "serviceVsStatus", bar.data);
              }}

            valueScale={{
              type: "linear",
              min: 0,
              max: stackedMax * 1.0 
            }}
            margin={{ top: 15, right: 20, bottom: 60, left: 80 }}
            padding={filter === "1_year" ? 0.12 : 0.35}
            colors={({ id }) => STATUS_COLORS[id] || "#74B9FF"}
            borderColor={{ from: "color", modifiers: [["darker", 0.6]] }}
            borderRadius={0}
            enableGridY
            enableGridX={false}
            enableLabel={false}
            axisTop={null}
            axisRight={null}
            axisBottom={{
              tickSize: 5,
              tickPadding: 8,
              tickRotation: 0,
              legendPosition: "middle",
              legendOffset: 50,
              format: (value) => {
                if (String(value).startsWith("spacer-")) return "";
                const isWeeklyFilter =
                  filter === "1_month" ||
                  filter === "3_month" ||
                  filter === "6_month" ||
                  filter === "1_year";
                if (isWeeklyFilter && String(value).includes("-W")) {
                  return "W" + String(value).split("-W")[1];
                }
                return value;
              },
              renderTick: (tick) => {
                const raw = String(tick.value);
                if (raw.startsWith("spacer-")) return <g />;

                const isWeekly =
                  ["1_month", "3_month", "6_month", "1_year"].includes(filter) &&
                  raw.includes("-W");

                const week = isWeekly ? "W" + raw.split("-W")[1] : raw;

                return (
                  <g transform={`translate(${tick.x},${tick.y})`}>
                    <line y1={0} y2={5} stroke="#666" strokeWidth={1} />
                    <text
                      y={14}
                      textAnchor="middle"
                      dominantBaseline="hanging"
                      style={{
                          fill:  "currentColor",
                        fontFamily: "Calibri, sans-serif",
                        fontWeight: 500,
                        fontSize: weekLabelFont, 
                      }}
                    >
                      {week}
                    </text>
                  </g>
                );
              },
            }}
            axisLeft={{
              tickSize: 5,
              tickPadding: 5,
              tickRotation: 0,
              legend: "SIM Count",
              legendPosition: "middle",
              legendOffset: -70,
            }}
            theme={{
              grid: {
                line: {
                  strokeWidth: 1,
                  strokeDasharray: "2 2",
                },
              },
              axis: {
                domain: {
                  line: {
                    stroke: "#e6e6e6",
                    strokeWidth: 1,
                  },
                },
                ticks: {
                  line: {
                    stroke: "#e6e6e6",
                    strokeWidth: 1,
                  },
                  text: {
                    fontSize: 12,
                    fill: "currentColor",
                    fontWeight: 500,
                    fontFamily: "Calibri, sans-serif",
                  },
                },
                legend: {
                  text: {
                    fontSize: 16,
                    fill:  "currentColor",
                    fontFamily: "Calibri",
                  },
                },
              },
              tooltip: {
                container: {
                  fontSize: 11,
                },
              },
              legends: {
                text: {
                  fontSize: 16,
                  fill:  "currentColor",
                  fontFamily: "Calibri, sans-serif",
                  fontWeight: 500,
                },
              },
            }}
            tooltip={(bar) => {
              const weekData = safeDataForNivo.find(
                (d) => d.time === bar.indexValue
              );
              if (!weekData) return null;

              const tooltipStyle = {
                background: "white",
                border: "1px solid #ccc",
                padding: "8px 10px",
                borderRadius: "6px",
                boxShadow: "0 2px 6px rgba(0,0,0,0.15)",
                fontSize: 11,
                lineHeight: "16px",
                minWidth: 140,
              };

              return (
                <div 
                 className="recharts-default-tooltip"
                 style={tooltipStyle}>
                  <div
                    style={{
                      fontWeight: 700,
                      marginBottom: 6,
                      textAlign: "center",
                    }}
                  >
                    {formatMonthWeek(bar.indexValue)}
                  </div>

                  {effectiveSelectedStatuses.map((status) => {
                    const value = (weekData as any)[status] ?? 0;
                    const color = STATUS_COLORS[status];
                    return (
                      <div
                        key={status}
                        style={{
                          display: "flex",
                          justifyContent: "space-between",
                          marginBottom: 4,
                        }}
                      >
                        <span
                          style={{
                            display: "flex",
                            alignItems: "center",
                            gap: 8,
                          }}
                        >
                          <span
                            style={{
                              width: 10,
                              height: 10,
                              borderRadius: 10,
                              background: color,
                            }}
                          />
                          {status}
                        </span>
                        <span style={{ fontWeight: 600 }}>{value}</span>
                      </div>
                    );
                  })}
                </div>
              );
            }}
            legends={[
              {
                dataFrom: "keys",
                anchor: "bottom",
                direction: "row",
                justify: false,
                translateY: 55,
                itemsSpacing: 10,
                itemWidth: 90,
                itemHeight: 14,
                itemDirection: "left-to-right",
                symbolSize: 10,
                symbolShape: "circle",
                effects: [
                  {
                    on: "hover",
                    style: { itemTextColor: "#000" },
                  },
                ],
              },
            ]}
            layers={[
  "grid",
  "axes",
  "bars",
  "markers",
  "legends",
  (layerProps) => {
    const { xScale, innerWidth, innerHeight } = layerProps;
    const band = xScale as any;
    const bandwidth =
      typeof band.bandwidth === "function" ? band.bandwidth() : 0;

    return (
      <g transform={`translate(0, ${innerHeight + 18})`}>
        {monthPositions.map((m) => {
          const first = processedData[m.startIndex];
          const last = processedData[m.endIndex];

          if (!first || !last) return null;
          if (first.isGap || last.isGap) return null;

          const x1 = band(first.time);
          const x2 = band(last.time);
          if (x1 == null || x2 == null) return null;

          // 👉 TRUE CENTER between start & end bars
          const centerX = (x1 + x2 + bandwidth) / 2;
          const safeCenter = Math.max(10, Math.min(centerX, innerWidth - 10));

          const monthNames = [
            "Jan","Feb","Mar","Apr","May","Jun",
            "Jul","Aug","Sep","Oct","Nov","Dec"
          ];

          return (
            <text
              key={`${m.month}-${m.startIndex}-${m.endIndex}`}
              x={safeCenter}
              y={15}
              textAnchor="middle"
              fontSize={12}
              fontWeight={500}
              fill= "currentColor"
            >
             {m.monthLabel}
            </text>
          );
        })}
      </g>
    );
  },
]}

          />
        </div>
      )}
    </div>
  );
};


const renderNewChartsWithScrolling = () => {
    const shouldShowDualXAxis =
      ["3_month", "6_month", "1_year", "max"].includes(filterSimVsService) ||
      ["3_month", "6_month", "1_year", "max"].includes(filterSimActivation);

    return (
      <div className="flex flex-col items-start justify-start w-full">
        <div className={
          shouldShowDualXAxis && isExpanded || maxExpand
            ? "flex flex-col gap-4 w-full p-6"
            : "grid grid-cols-1 md:grid-cols-2 gap-4 w-full p-6"
        }>
          {features.includes("SIM Vs Service Provider") && (
            renderTimeBasedChart()
          )}

          {features.includes("SIMs Active") && (
            renderTimeBasedLineChart()
          )}
        </div>
        <div className="w-full p-6">
          {features.includes("Service Provider Vs SIM Status") && (
            renderTimeBasedBubbleLineChart()
          )}
        </div>

        <style jsx global>{`
          div::-webkit-scrollbar {
            width: 8px;
          }
          div::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 4px;
          }
          div::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 4px;
          }
          div::-webkit-scrollbar-thumb:hover {
            background: #555;
          }
        `}</style>
      </div>
    );
  };

  const renderControls = () => (
    // <div className="w-full" style={{ paddingLeft: "24px", paddingRight: "24px" }}>
      <div
  className="flex flex-row flex-nowrap items-center justify-between w-full p-2 overflow-x-auto"
  style={{ gap: '8px', whiteSpace: 'nowrap' }}
>
  {/* ----- LEFT SECTION ----- */}
  <div className="flex flex-row flex-nowrap items-center" style={{ gap: '6px' }}>
        <Select
          className="min-w-[170px] w-[200px]" 
          value={{ label: selectedFilter, value: selectedFilter }}
          onChange={(opt) => handleFilterChange(opt?.value ?? "")}
          options={filterOptions.options}
          placeholder="Tenant"
          isSearchable
          noOptionsMessage={() => "No options"}
          styles={{...DropdownStyles , 
             control: (base, state) => ({
              ...DropdownStyles.control(base, state),
              paddingRight: "0px", // reduce gap
            }),
             indicatorsContainer: (base) => ({
            ...base,
            paddingRight: "0px", // reduce arrow space
          }),
           singleValue: (base) => ({
            ...DropdownStyles.singleValue(base),
            marginRight: "0px", // bring text closer
          }),
          }}
          components={{
              IndicatorSeparator: () => null
            }}
            menuPlacement="auto"
        menuPortalTarget={document.body}
        />
        {showBillingCyclePeriod && selectedServiceProvider !== "All service providers" && (
          <Select
            className="min-w-[150px]" 
            value={{ label: selectedBillingCyclePeriod, value: selectedBillingCyclePeriod }}
            onChange={(opt) => handleBillingCyclePeriodChange(opt?.value ?? "")}
            options={billingCyclePeriods.map(period => ({
              value: period,
              label: period
            }))}
            placeholder="Billing Cycle"
            styles={{...DropdownStyles , 
             control: (base, state) => ({
              ...DropdownStyles.control(base, state),
              paddingRight: "0px", // reduce gap
            }),
             indicatorsContainer: (base) => ({
            ...base,
            paddingRight: "0px", // reduce arrow space
          }),
           singleValue: (base) => ({
            ...DropdownStyles.singleValue(base),
            marginRight: "0px", // bring text closer
          }),
          }}
            components={{
              IndicatorSeparator: () => null
            }}
            menuPlacement="auto"
            menuPortalTarget={document.body}
          />
        )}

        <Select
          className="min-w-[170x]" 
          value={{ label: selectedServiceProvider, value: selectedServiceProvider }}
          onChange={(opt) => handleServiceProviderChange(opt?.value ?? "")}
          options={serviceProviders.map(provider => ({
            value: provider,
            label: provider
          }))}
          placeholder="Service Provider"
          styles={{...DropdownStyles , 
             control: (base, state) => ({
              ...DropdownStyles.control(base, state),
              paddingRight: "0px", // reduce gap
            }),
             indicatorsContainer: (base) => ({
            ...base,
            paddingRight: "0px", // reduce arrow space
          }),
           singleValue: (base) => ({
            ...DropdownStyles.singleValue(base),
            marginRight: "0px", // bring text closer
          }),
          }}          components={{
              IndicatorSeparator: () => null
            }}
            menuPlacement="auto"
        menuPortalTarget={document.body}
        />

        


          {/* "Select:" text - aligned with other elements */}
          <span style={{
            fontFamily: "Calibri, sans-serif",
            fontSize: "14px",
            // color: "currentColor",
            whiteSpace: "nowrap",
            marginLeft: "12px",
            marginRight: "4px",
            height: "38px", // Same height as selects
            display: "flex",
            alignItems: "center", // Center the text vertically
          }} className="dashboard-select-text">
            Select:
          </span>

          {/* Time selection buttons - same height as selects */}
          <button
            className={selectedButton === "Current Month" ? "save-btn !min-h-[40px]" : "email-dashboard-btns"}
            onClick={() => handleButtonClick("Current Month")}
            style={{
              fontFamily: "Calibri,sans-serif",
              fontSize: 13,
              padding: "0 12px",
              height: 38, // Same height as selects
              // borderRadius: 7,
              minWidth: "60px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            Month
          </button>

          <button
            className={selectedButton === "Current Week" ? "save-btn  !min-h-[40px]" : "email-dashboard-btns"}
            onClick={() => handleButtonClick("Current Week")}
            style={{
              fontFamily: "Calibri,sans-serif",
              fontSize: 13,
              padding: "0 12px",
              height: 38, // Same height as selects
              // borderRadius: 7,
              minWidth: "55px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            Week
          </button>

          <button
            className={selectedButton === "Today" ? "save-btn  !min-h-[40px]" : "email-dashboard-btns"}
            onClick={() => handleButtonClick("Today")}
            style={{
              fontFamily: "Calibri,sans-serif",
              fontSize: 13,
              padding: "0 12px",
              height: 38, // Same height as selects
              // borderRadius: 7,
              minWidth: "55px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            Today
          </button>

          <RangePicker
            value={dateRange}
            onChange={handleDateRangeChange}
            style={{
              width: 220,
              height: 38,
              borderRadius: 7,
              fontSize: 12,
            }}
            popupClassName="custom-range-popup"
            disabledDate={current => current && current > dayjs().endOf("day")}
            placeholder={["Start", "End"]}
            disabled={(showBillingCyclePeriod && selectedBillingCyclePeriod !== "None")}
          />
        </div>

        {/* Right side - Action buttons */}
         <div className="flex items-center flex-nowrap" style={{ gap: '8px' }}>
          <DashboardRefresh tabName={"SIMs Overview"} onRefresh={initializeDashboard} tabKey={"sim_overiew"} />
          <DashboardColumnFilter tabName={"Sim Overview"} setFeatures={setFeatures} />
        </div>
      </div>
    // </div>
  );


  return (
    <>
      {loading ? (
        <div className="flex justify-center items-center h-screen">
          <Spin size="large" />
        </div>
      ) : (
        <Suspense fallback={<Spin size="large" />}>
          {renderControls()}
         <SimOverviewCards
          key={`${selectedTenantId}-${selectedServiceProvider}-${selectedBillingCyclePeriod}-${selectedFilter}`}
          selectedTenantId={selectedTenantId}
          selectedServiceProvider={selectedServiceProvider === "All service providers" ? "" : selectedServiceProvider}
          billingCyclePeriod={selectedServiceProvider === "All service providers" ? "" : selectedBillingCyclePeriod}
          // ✅ FIX: Do NOT send start & end date when billing cycle dropdown is used
          startDate={
            selectedBillingCyclePeriod && !selectedButton ? "" : startDate
          }
          endDate={
            selectedBillingCyclePeriod && !selectedButton ? "" : endDate
          }
          serviceProvider={selectedFilter === "All Tenants" ? "All" : selectedFilter}
          features={features}
        />



          {renderNewChartsWithScrolling()}
        </Suspense>
      )}

      {renderRedirectOverlay()}
      {renderRedirectNotification()}
    </>
  );
};

export default SimsOverview;