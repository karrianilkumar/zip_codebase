// app/page.tsx
"use client"
import React,{useEffect} from 'react';
import HomePage from './dashboard/page';
import { useRouter } from 'next/navigation';
import { useAuth } from './components/auth_context';

const Page: React.FC = () => {
  const router = useRouter();
  const { firstModuleRoute } = useAuth();
  const firstModuleUrl = firstModuleRoute ?? '/'; // Default value if firstModuleRoute is null
  console.log(firstModuleUrl,"Show url")
  useEffect(() => {
    if (firstModuleRoute) {
      router.push(firstModuleUrl); // Redirect to the first module URL
    }
  }, [firstModuleRoute, firstModuleUrl, router]);

  // Return null or some loading indicator while handling the redirect
  return null;
};

export default Page;
