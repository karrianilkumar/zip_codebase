import React, { useEffect, useState } from "react";
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import { Spin } from "antd";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { getCurrentDateTime } from "@/app/components/header_constants";

interface ConfigTypes {
  title: string;
  height: number;
  width: number;
  count: number | string;
}

interface EmailsChartsPageProps {
  selectedEmailType: string;
  startDate: string;
  endDate: string;
}

const EmailsChartsPage: React.FC<EmailsChartsPageProps> = ({ selectedEmailType, startDate, endDate }) => {
  const [loading, setLoading] = useState(true);
  const [datalog, setData] = useState<ConfigTypes[]>([]);
  const { token, partner ,selectedDb,metaData, sessionId, username , firstLastName} = useAuth();

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const url =ENV_ROUTES.NOTIFICATION_SERVICES;
        const requestPaths = [
          { path: "/total_emails_count" },
          { path: "/failed_emails_count" },
          { path: "/successful_emails_count"},
          { path: "/email_templates_count" }
        ];

        const promises = requestPaths.map(({ path }) => {
          const requestData = {
            partner: partner,
            start_date: startDate,
            end_date: endDate,
            email_type: selectedEmailType,
            path: path,
            access_token: token,
            db_name:selectedDb,
            ...metaData,
            sessionID: sessionId,
            username:username,
            first_last_name:firstLastName
          };
          console.log(getCurrentDateTime(),"Show the log time request sent from ui to lambda");
          return axios.post(url, { data: requestData }).then(response => {
            // Log the full response for debugging
            console.log(getCurrentDateTime(),"Show the log time response sent from lambda to ui");
            const parsedData = JSON.parse(response.data.body);
            const { data } = parsedData;
            return {
              title: data.title,
              count: parsedData.data.data, // Adjust if necessary
              height: parsedData.data.height, // Adjust this based on actual response
              width: parsedData.data.width   // Adjust this based on actual response
            };
          });
        });

        const results = await Promise.all(promises);
        setData(results);
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, [token, selectedEmailType, startDate, endDate]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  const isSmallScreen = typeof window !== "undefined" && window.innerWidth < 700;
  return (
    <div className="ml-1 py-2 px-6 w-full">
      <div className="grid grid-cols-2 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {datalog.map((item, index) => {
          return (
            <div
              key={index}
              className="chart w-full"
              style={
                isSmallScreen
                  ? { width: "150px", height: "100px" }
                  : { width: `${item.width}px`, height: `${item.height}px` }
              }
            >
              <div className="p-2 mt-0">
                <div className="flex flex-col sm:text-left text-center">
                  <h2 style={{ fontFamily: "Calibri, sans-serif", fontSize: "18px" }}>
                    {item.title}
                  </h2>
                  <p className="chart-count">
                    <span style={{ fontSize: "18px" }}>{item.count}</span>
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
  
};

export default EmailsChartsPage;
