import React, { lazy, useCallback, useEffect, useMemo, useState } from "react";
import { components, GroupBase, MenuListProps, MultiValue } from "react-select";
import { Modal, notification, Spin, Switch, Tooltip } from "antd";
import Select from "react-select";
import VirtualList from 'rc-virtual-list';
import {
  PlusCircleIcon,
  MinusCircleIcon,
  InformationCircleIcon,
  ArrowsRightLeftIcon,
} from "@heroicons/react/24/outline";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { FaUndo } from "react-icons/fa";
import { DropdownStyles } from "@/app/components/css/dropdown";
const VersionModal = lazy(() => import('./versions'));
import { NonEditableDropdownStyles } from "@/app/components/css/dropdown";
import { fireSideCannons } from "@/app/components/confetti";
interface SelectOption {
  label: string;
  value: string;
  group?: string;
}
// Define interfaces for the expected structure
interface ExpressionObject {
  const_one?: { [key: string]: string };
  cond?: { [key: string]: string };
  const_two?: { [key: string]: string };
}

interface ConditionObject {
  [key: string]: string;
}
const ITEM_HEIGHT = 35;
const VirtualizedMenuList = ({
  options,
  children,
  maxHeight,
  getValue,
  ...props
}: MenuListProps<SelectOption, boolean, GroupBase<SelectOption>>) => {
  // Extract the selected values from getValue
  const selectedValues = getValue();
  const selectedIds = new Set(
    Array.isArray(selectedValues) ? selectedValues.map((val) => val.value) : []
  );

  // Flatten grouped options for virtualization
  const flattenedChildren = useMemo(() => {
    const flattened: any[] = [];
    
    React.Children.forEach(children, (child: any) => {
      if (child.type === components.Group) {
        flattened.push({
          type: 'group',
          label: child.props.label,
          data: child.props.data,
          id: `group-${child.props.label}`,
        });
        React.Children.forEach(child.props.children, (option) => {
          flattened.push({
            type: 'option',
            data: option.props.data,
            isSelected: selectedIds.has(option?.props?.data?.value),
            component: option,
            id: option.props.data.value,
          });
        });
      } else if (child) {
        flattened.push({
          type: 'option',
          data: child.props.data,
          isSelected: selectedIds.has(child?.props?.data?.value),
          component: child,
          id: child?.props?.data?.value,
        });
      }
    });
    return flattened;
  }, [children, selectedIds]);

  const renderItem = (item : any) => {
    if (item.type === 'group') {
      return (
        <div
          key={item.id}
          className="group-header"
          style={{
            padding: '8px 12px',
            fontWeight: 'bold',
            backgroundColor: '#f5f5f5',
            position: 'sticky',
            top: 0,
            zIndex: 1,
          }}
        >
          {item.label}
        </div>
      );
    }
    return item.component;
  };
  return (
    <div {...props.innerProps} ref={props.innerRef}>
      <VirtualList
        data={flattenedChildren}
        height={maxHeight}
        itemHeight={ITEM_HEIGHT}
        itemKey="id"
      >
        {(item) => renderItem(item)}
      </VirtualList>
    </div>
  );
};
const EditNotificationsModal: React.FC<{
  visible: boolean;
  onClose: () => void;
  rowData: any;
  isOpen: boolean;
  action: string;
}> = ({ visible, onClose, rowData, action }) => {
  const PERCENTAGE_FIELDS = [
    "Total Mobility Customer Pool Usage(Mobility Customer Pool Usage)",
     "Total M2M Customer Pool Usage(M2M Customer Pool Usage)",
     "Total Cross Provider Customer Pool Usage (Percentage)(Cross Provider Customer Pool Usage)"  
   ];
   
  const [expressionBuilderFields, setExpressionBuilderFields] = useState<
    any[]
  >([
    {
      id: 1,
      field: "",
      fieldId: null,
      condition: "",
      conditionId: null,
      constant: "",
      constantId: null,
      isConditionVisible: false,
      isLabel: false,
      isLabelConstant: false,
      unit:"",
    },
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const [validationErrors, setValidationErrors] = useState<{
    [key: string]: string;
  }>({});
  const [formData, setFormData] = useState({ is_active: false });
  const [showCondition, setShowCondition] = useState<boolean>(false);
  const [isAllCustomers, setIsAllCustomers] = useState<boolean>(false);

  const [operationTypeOptions, setOperationTypeOptions] = useState<
    SelectOption[]
  >([]);
  const [fieldTypeOptions, setFieldTypeOptions] = useState<
    GroupBase<SelectOption>[]
  >([]);
  const [customerOptions, setCustomerOptions] = useState<
    GroupBase<SelectOption>[]
  >([]);

  const [selectedServiceProvider, setSelectedServiceProvider] = useState<{
    label: string;
    value: string;
  } | null>(null);
  const [provider, setProvider] = useState<{ label: string; value: string }[]>([]);

  //states for selected dropdown options
  const [selectedFieldTypeOption, setSelectedOption] =
    useState<SelectOption | null>(null);
  const [selectedOperationOption, setSelectedOperationOption] =
    useState<SelectOption | null>(null);
  const [selectedCustomerOption, setSelectedCustomerOption] =
    useState<MultiValue<SelectOption> | null>(null);
  const [selectedConditions, setSelectedConditions] = useState<string[]>(
    expressionBuilderFields.length > 1
      ? Array(expressionBuilderFields.length - 1).fill("")
      : []
  );

  const [ruleIdField, setRuleIdField] = useState("");
  const [nameField, setNameField] = useState("");
  const [executionOrderField, setExecutionOrderField] = useState<
    number | undefined
  >();
  const [subjectLineField, setSubjectLineField] = useState("");
  const [messageField, setMessageField] = useState("");
  const [descriptionField, setDescriptionField] = useState("");
  const [sendToSystem, setSendToSystem] = useState(false);
  const [showProjected, setShowProjected] = useState(false);
  const [isLabel, setIsLabel] = useState<boolean>(false);
  const [isLabelConstant, setIsLabelConstant] = useState<boolean>(false);
  const [changeToField, setChangeToField] = useState("");
  const [changeToConstant, setChangeToConstant] = useState("");
  const [ruleDefId, setRuleDefId] = useState<number | null>(null);
  const {
    username,
    role,
    token,
    partner,
    selectedDb,
    metaData,
    firstLastName,
    settabledata,
    sessionId,
  } = useAuth();
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [notificationType, setNotificationType] = useState("");
  const [notificationTypeOptions, setNotificationTypeOptions] = useState<any>([]);
  const [notifyCustomerGroup, setNotifyCustomerGroup] = useState(false)
  const [showExcludedPooledDevices, setShowExcludedPooledDevices] = useState(false)
  const [sendAllCutomerNotificationsToEmail, setSendAllCutomerNotificationsToEmail] = useState("");
  const [emailError, setEmailError] = useState("");
     const CROSS_PROVIDER_NOTIFICATION_TYPE_OPTIONS = [
      { value: "m2m_device_notifications", label: "M2M Device Notifications" },
      { value: "m2m_pool_notifications", label: "M2M Pool Notifications" },
      { value: "mobility_device_notifications", label: "Mobility Device Notifications" },
      { value: "mobility_pool_notifications", label: "Mobility Pool Notifications" },
      { value: "cross_provider_device_notifications", label: "Cross Provider Device Notifications" },
      { value: "cross_provider_pool_notifications", label: "Cross Provider Pool Notifications" }
  
    ];
  
   const NOT_CROSS_PROVIDER_NOTIFICATION_TYPE_OPTIONS = [
      { value: "m2m_device_notifications", label: "M2M Device Notifications" },
      { value: "m2m_pool_notifications", label: "M2M Pool Notifications" },
      { value: "mobility_device_notifications", label: "Mobility Device Notifications" },
      { value: "mobility_pool_notifications", label: "Mobility Pool Notifications" },
    ];
const [isCrossProvider, setIsCrossProvider] = useState<boolean>(false);

  const openModal = () => setIsModalOpen(true);

  const closeModal = () => setIsModalOpen(false);
  // Update the transformedExpressions logic to match the exact structure you're receiving
  useEffect(() => {
    setExpressionBuilderFields((prevFields) =>
      prevFields.map((field) => {
        const dropdownTriggers = ['CtdDataUsage', 'Total Carrier Cycle Data Usage', 'Total Customer Cycle Data Usage'];
        const showUnitDropdown = dropdownTriggers.some(value => field.field?.startsWith(value));
        // const showUnitDropdown = field.field?.startsWith('CtdDataUsage');
        return {
          ...field,
          showUnitDropdown, // Set this flag when the field is rendered or updated
        };
      })
    );
  }, []); // Runs whenever the expression fields change
  

  const transformedExpressions = expressionBuilderFields.reduce(
    (acc, expression, index) => {
      // console.log("expressionBuilderFields",expressionBuilderFields)
      // console.log("acc",acc)

      // Determine keys dynamically based on `isLabel` and `isLabelConstant`
      const fieldKey =  expression.isLabel ? "field_one" : "const_one";
      const constantKey = expression.isLabelConstant ? "field_two" : "const_two";

      // Create transformed expression object
      const transformedExpression = {
        [fieldKey]: expression.fieldId
          ? { [expression.field]: expression.fieldId }
          : expression.field,
        cond: expression.conditionId
          ? { [expression.condition]: expression.conditionId }
          : {},
        [constantKey]: expression.constantId
          ? { [expression.constant]: expression.constantId }
          :  expression.constant,
      };
      // console.log("transformedExpression",transformedExpression)
      if(expression.conditionId){
        acc.push(transformedExpression);
        if (expression.showUnitDropdown && expression.unit) {
          transformedExpression.unit = expression.unit;
        }
        if (index < expressionBuilderFields.length - 1 && selectedConditions[index]) {
          acc.push({
            [`expression_condition_${index + 1}`]: selectedConditions[index] || "AND",
          });
        }
      }

      // Insert selected condition between expressions if it's not the last one
      // if (
      //   index < expressionBuilderFields.length - 1 &&
      //   selectedConditions[index]
      // ) {
      //   acc.push({
      //     [`expression_condition_${index + 1}`]: selectedConditions[index] || 'AND',
      //   });
      // }
      
    //  console.log("expression account  returned",acc)
      
      return acc;
    },
    [] as any[]
  );

  useEffect(() => {
    if (rowData) {
      setNotificationType(rowData?.notification_type || ""); // Add this line
      setRuleIdField(rowData?.rule_id || "");
      setNameField(rowData?.name || "");
      setExecutionOrderField(rowData?.order_of_execution || 0);
      setSubjectLineField(rowData?.subject_line || "");
      setMessageField(rowData?.display_message || "");
      setDescriptionField(rowData?.notes || "");
      setSendToSystem(!!rowData?.send_to_carrier);
      setShowProjected(!!rowData?.should_show_projected_usage_cost);
      setNotifyCustomerGroup(!!rowData?.should_send_single_email_to_customer_group);
      setShowExcludedPooledDevices(!!rowData?.should_exclude_pooled_device);
      setSendAllCutomerNotificationsToEmail(rowData?.aggregated_customer_email_recipient || "")
      setIsAllCustomers(!!rowData?.send_to_customer);
        // console.log("rowdata data",rowData.rule_def_id)
      setRuleDefId(rowData?.rule_def_id || "");

      if (rowData?.send_to_customer === true) {
        setCustomerOptions([]);
        setSelectedCustomerOption([]);
      }
      // const transformedProvider = rowData.service_provider
      //   ? [{ label: rowData.service_provider, value: rowData.service_provider }]
      //   : [];
      // setProvider(transformedProvider);

      // Set the selected value (if available)
      if (rowData.service_provider) {
        setSelectedServiceProvider({
          label: rowData.service_provider,
          value: rowData.service_provider,
        });
      }

      const transformCustomersList = (customersList: any) => {
        const customerNamesOptions =
          customersList.customer_names?.map((entry: any) => {
            const [label, value] = Object.entries(entry)[0];
            return {
              label: String(label),
              value: String(value),
              group: "Customer Names", // Ensure group is set
            };
          }) || [];

        const customerGroupsOptions =
          customersList.customer_groups?.map((entry: any) => {
            const [label, value] = Object.entries(entry)[0];
            return {
              label: String(label),
              value: String(value),
              group: "Customer Groups", // Ensure group is set
            };
          }) || [];

        return [...customerNamesOptions, ...customerGroupsOptions];
      };

      // Parse expression_names with robust error handling

      const parseExpressionNames = (expressionNames: any[]) => {
        console.log("expressionNames",expressionNames)
        const parsedExpressions: any[] = [];
        let currentExpressionId = 1;
      
        expressionNames.forEach((item) => {
          // Skip entries that only contain condition (e.g. "expression_condition_1": "OR")
          if (item[`expression_condition_1`] || item[`expression_condition_2`]) {
            // Check if there is a previous valid expression to associate the condition with
            const lastExpression = parsedExpressions[parsedExpressions.length - 1];
            if (lastExpression && lastExpression.field && lastExpression.constant!=="") {
              // Add the condition after a valid expression
              parsedExpressions.push({
                id: currentExpressionId++,
                // field: "",
                // fieldId: null,
                condition: item[`expression_condition_1`] || item[`expression_condition_2`],
                conditionId: null,
                // constant: "",
                // constantId: null,
                // isLabel: true,
                // isLabelConstant: true,
                // isConditionVisible: true,
              });
            }
            return; // Skip adding a new expression for conditions alone
          }
      
          // Parse const_one
          const fieldKey = item.const_one ? "const_one" : null;
          const field = fieldKey ? Object.keys(item[fieldKey])[0] : "";
          const fieldId = fieldKey ? Object.values(item[fieldKey])[0] : null;
      
          // Parse condition
          const condition = item.cond ? Object.keys(item.cond)[0] : "";
          const conditionId = item.cond ? Object.values(item.cond)[0] : null;
      
          // Parse const_two or field_two
          let constant, constantId, isLabelConstant;
          if (item.const_two) {
            constant = Object.keys(item.const_two)[0];
            constantId = Object.values(item.const_two)[0];
            isLabelConstant = false; // Dropdown for const_two
          } else if (item.field_two) {
            constant = item.field_two; // Primitive value
            constantId = null;
            isLabelConstant = true; // Input field for primitive
          } else {
            constant = "";
            constantId = null;
            isLabelConstant = true; // Default to input field
          }
          
          // Handle specific conditions like HAS VALUE and HAS NO VALUE
          if (["HAS VALUE", "HAS NO VALUE"].includes(condition) && constant === "") {
            constant = ""; // Don't set to empty unless it's explicitly disabled
            constantId = null; // Ensure constantId remains null if disabled
          }
          const unit = item.unit || "";
          // Add valid expressions
          const dropdownTriggers = ['CtdDataUsage', 'Total Carrier Cycle Data Usage', 'Total Customer Cycle Data Usage'];
          if (field && condition && constant !== undefined) {
            parsedExpressions.push({
              id: currentExpressionId++,
              field,
              fieldId,
              condition,
              conditionId,
              constant,
              constantId,
              isLabel: false, // Assuming const_one is always a dropdown
              isLabelConstant,
              isConditionVisible: parsedExpressions.length > 0,
              unit: item.unit || "", // Ensure unit is included
              showUnitDropdown:  dropdownTriggers.some(value => field?.startsWith(value)) && unit, 
            });
          }
        });
        console.log("parsedExpressions",parsedExpressions)
      
        // Return parsed expressions or a default entry
        return parsedExpressions.length > 0
          ? parsedExpressions
          : [
              {
                id: 1,
                field: "",
                fieldId: null,
                condition: "",
                conditionId: null,
                constant: "",
                constantId: null,
                isLabel: true,
                isLabelConstant: true,
                isConditionVisible: false,
                unit: "", // Default unit
                showUnitDropdown: false
              },
            ];
      };
      


      // Process customers list
      try {
        const customersList = JSON.parse(rowData.customers_list || "{}");

        const selectedCustomerOptions = transformCustomersList(customersList);

        if (rowData?.send_to_customer) {
          setSelectedCustomerOption(null);
        } else {
          setSelectedCustomerOption(selectedCustomerOptions);
        }
      } catch (error) {
        setSelectedCustomerOption(null);
      }

      try {
        const expressionNames = JSON.parse(rowData.expression_names || "[]");
        console.log("expression names",expressionNames)
        const parsedExpressions = parseExpressionNames(expressionNames);
        setExpressionBuilderFields(parsedExpressions);
        console.log("parsedexpression",expressionNames)

        // Set conditions between expressions
        const conditions = expressionNames.flatMap((item: any) => {
          // Create an array to hold the conditions for the current item
          const itemConditions = [];

          // Loop through the keys of the item
          for (const key in item) {
            // Check if the key matches the pattern for expression conditions
            if (key.startsWith("expression_condition_")) {
              const conditionValue = item[key];
              if (conditionValue) {
                itemConditions.push(conditionValue);
              }
            }
          }

          return itemConditions; // Return the conditions found in this item
        });
        console.log("conditions",conditions)
        setSelectedConditions(conditions);
      } catch (error) {
        console.error("Error parsing expression_names:", error);
        setExpressionBuilderFields([
          {
            id: 1,
            field: "",
            fieldId: null,
            condition: "",
            conditionId: null,
            constant: "",
            constantId: null,
            isConditionVisible: false,
            isLabel: false,
            isLabelConstant: false,
          },
        ]);
      }
    }
  }, [rowData]);
  let displayNameMatched = false;

  const validateForm = () => {
    const errors: Record<string, string> = {};

    // Validate Name
    if (!nameField.trim()) {
      errors.name = "Name is required!";
    }

    // Validate Message
    if (!messageField.trim()) {
      errors.message = "Message is required!";
    }

    // Validate Description
    if (!descriptionField.trim()) {
      errors.description = "Description is required!";
    }

    // Validate Service Provider
    // if (!selectedServiceProvider || !selectedServiceProvider.value) {
    //   errors.service_provider = "Service Provider is required!";
    // }
    expressionBuilderFields.forEach((expression, index) => {
      if(expression.conditionId){

        if (!expression.field) {
          errors[`expression_field_${index}`] = "This Field is required!";
        }
        else{
          displayNameMatched = false;
        }
        if (!expression.condition) {
          errors[`expression_condition_${index}`] = "Condition is required!";
        }
        if (!expression.constant && (!["HAS VALUE", "HAS NO VALUE"].includes(expression.condition))) {
          errors[`expression_constant_${index}`] = "This Field is required!";
        }
      }
    });
    // const hasDisplayName = checkForServiceProviderExpression();
    // if (!hasDisplayName) {
    //   errors['expression_service_provider_field'] = "Service Provider expression is not available!";
    // } else {
    //   // If we have the required expression, clear the error
    //   delete errors['expression_service_provider_field'];
    // }

    return errors;

  };

  const checkForServiceProviderExpression = () => {
    let matched = false;
    expressionBuilderFields.forEach((expression) => {
      if (expression.field === "DisplayName(Service Provider)" || expression.constant === "DisplayName(Service Provider)") {
        matched = true;
      }
    });
    return matched;
  };
  const handleCustomerChange = (selectedOptions: MultiValue<SelectOption>) => {
    setSelectedCustomerOption(selectedOptions);
  };  

  const refetchTableData = async () => {
    setIsLoading(true);
    settabledata([])

    try {
      // setIsLoading(true);
      // settabledata([]);
      // addLog("UI API call");
      const url = ENV_ROUTES.NOTIFICATION_SERVICES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_notification_rules",
        role_name: role,
        parent_module: "Partner",
        module_name: "Usage Notification",
        feature_module_name: "Usage Notification",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      } else {
        const tableData_ = parsedData?.rule_data || [];
        settabledata(tableData_);
        const serviceProviderOptions = parsedData.service_providers.map(
          (provider: any) => ({
            label: provider, // What the user sees in the dropdown
            value: provider, // What gets stored as the selected value
          })
        );
        setProvider(serviceProviderOptions);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Update the transformSelectedCustomersForPayload function
  const transformSelectedCustomersForPayload = (
    selectedOptions: MultiValue<SelectOption>
  ) => {
    const customerNames: Record<string, string>[] = [];
    const customerGroups: Record<string, string>[] = [];
    selectedOptions.forEach((option) => {
      if (option.group === "Customer Names") {
        customerNames.push({ [option.label]: option.value });
      } else if (option.group === "Customer Groups") {
        customerGroups.push({ [option.label]: option.value });
      }
    });

    return {
      customer_names: customerNames.length > 0 ? customerNames : null,
      customer_groups: customerGroups.length > 0 ? customerGroups : null,
    };
  };


  // const handleToggle = (id: number) => {
  //   setExpressionBuilderFields((prevFields) =>
  //     prevFields.map((field) =>
  //       field.id === id ? { ...field, isLabel: !field.isLabel } : field
  //     )
  //   );
  // };

  // const handleToggleChange = () => {
  //   setIsLabelConstant((previous) => !previous);
  // };

  const handleToggle = (id: number) => {
    setIsLabel(!isLabel)
    setExpressionBuilderFields((prevFields) =>
      prevFields.map((field) =>
        field.id === id
          ? {
            ...field,
            isLabel: !field.isLabel, // Toggle isLabel
            // isLabelConstant: false // Reset isLabelConstant when toggling between Field and Constant
          }
          : {...field,
            isLabel: field.isLabel, // Toggle isLabel
          }
      )
    );
  };

  // const handleToggleChange = (id: number) => {
  //   setExpressionBuilderFields((prevFields) =>
  //     prevFields.map((field) =>
  //       field.id === id
  //         ? { ...field, isLabelConstant: !field.isLabelConstant }
  //         : field
  //     )
  //   );
  // };

  const handleToggleChange = (id: number) => {
    setIsLabelConstant(!isLabelConstant)
    setExpressionBuilderFields((prevFields) =>
      prevFields.map((field) =>
        field.id === id
          ? {
            ...field,
            isLabelConstant: !field.isLabelConstant, // Toggle isLabelConstant
            // isLabel: false // Reset isLabel when toggling between Constant and Field
          }
          : field
      )
    );
  };

  const handleAdminCheckbox = () => {
    setSendToSystem(!sendToSystem);
  };

  const handleProjectedCheckbox = () => {
    setShowProjected(!showProjected);
  };

  const addExpressionField = () => {
    setShowCondition(true);
    setExpressionBuilderFields((prevFields) => [
      ...prevFields,
      {
        id: prevFields.length + 1,
        field: "",
        fieldId: null, // Initialize as null
        condition: "",
        conditionId: prevFields.length + 1, // Initialize as null
        constant: "",
        constantId: null, // Initialize as null
        isConditionVisible: true,
        isLabel: false,
        isLabelConstant: false,
      },
    ]);
    setSelectedConditions((prev) => [...prev, "AND"]);
  };

  // Function to handle the toggle change
  const handleSwitchChange = (checked: boolean) => {
    setIsAllCustomers(checked);
    if (checked) {
      setSelectedCustomerOption([]); // Clear selected options when switch is toggled
    }
  };

  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const name = e.target.value;
    setNameField(name);
    setRuleIdField(name.trim().replace(/\s+/g, "-"));
  };
 const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
  const value = e.target.value;
  setSendAllCutomerNotificationsToEmail(value);

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (value && !emailRegex.test(value)) {
    setEmailError("Please enter a valid email address");
  } else {
    setEmailError("");
  }
  };
  const removeExpressionField = (id: number) => {
    const updatedFields = expressionBuilderFields.filter(
      (field) => field.id !== id
    );
    const filteredUpdatedFields = updatedFields.filter(
      (field) =>
        !(field?.conditionId === null)
    );
    setExpressionBuilderFields(filteredUpdatedFields);

    // If the first ExpressionField is removed, hide the condition field
    if (updatedFields.length === 1) {
      setShowCondition(false);
    }
  };
  const handleChangeExpressionField = (
    fieldId: number,
    key: "field" | "condition" | "constant",
    selectedOption: any
  ) => {
    setExpressionBuilderFields((prevFields) =>
      prevFields?.map((field) =>
        field.id === fieldId
          ? {
            ...field,
            [key]: selectedOption?.label,
            [`${key}Id`]: selectedOption?.value,
          }
          : field
      )
    );
  };
  const transformFieldTypesToGroupedOptions = (fieldTypes: any) => {
    return Object.keys(fieldTypes)?.map((key) => ({
      label: key,
      options: fieldTypes[key]?.map((item: any) => {
        const fieldLabel = Object.keys(item)[0];
        const fieldValue = Object.values(item)[0];
        return {
          label: fieldLabel,
          value: fieldValue, // Use the full ID value
          fullKeyValuePair: { [fieldLabel]: fieldValue },
        };
      }),
    }));
  };

  const transformOperationTypes = (operationTypes: any[]): SelectOption[] => {
    return operationTypes.flatMap((op) =>
      Object.entries(op)?.map(([key, value]) => ({
        label: key,
        value: value as string, // Use the ID value
        group: "",
        fullKeyValuePair: { [key]: value },
      }))
    );
  };

  const transformCustomersToGroupedOptions = (
    customers: any
  ): GroupBase<SelectOption>[] => {
    const { customer_names, customer_groups } = customers;

    // Transform customer names into a SelectOption array
    const customerNamesOptions = customer_names
      ?.map((entry: any) => {
        // Ensure entry is an object and extract the first key-value pair
        if (typeof entry === "object" && entry !== null) {
          const [label, value] = Object.entries(entry)[0];
          return {
            label: String(label), // Ensure label is a string
            value: String(value), // Ensure value is a string
            group: "Customer Names", // Ensure consistent group name
          };
        }
        return null; // Return null for invalid entries
      })
      .filter(Boolean); // Filter out any null values

    // Transform customer groups into a SelectOption array
    const customerGroupsOptions = customer_groups
      ?.map((entry: any) => {
        // Ensure entry is an object and extract the first key-value pair
        if (typeof entry === "object" && entry !== null) {
          const [label, value] = Object.entries(entry)[0];
          return {
            label: String(label), // Ensure label is a string
            value: String(value), // Ensure value is a string
            group: "Customer Groups", // Ensure consistent group name
          };
        }
        return null; // Return null for invalid entries
      })
      .filter(Boolean); // Filter out any null values

    return [
      {
        label: "Customer Names",
        options: customerNamesOptions,
      },
      {
        label: "Customer Groups",
        options: customerGroupsOptions,
      },
    ];
  };
  const fetchDropdownOptions = async () => {
    try {
      setIsLoading(true);
      const url = ENV_ROUTES.NOTIFICATION_SERVICES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_notification_rules",
        role_name: role,
        parent_module: "Partner",
        module_name: "Usage Notification",
        feature_module_name: "Usage Notification",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      const operationOptions = transformOperationTypes(
        parsedData.operation_types
      );
      setOperationTypeOptions(operationOptions);

      const fieldTypeOptions = transformFieldTypesToGroupedOptions(
        parsedData.field_types
      );
      setFieldTypeOptions(fieldTypeOptions);

      // const customers = transformCustomersToGroupedOptions(
      //   parsedData.customer_drop_down
      // );
      // setCustomerOptions(customers);

      const serviceProviderOptions = parsedData.service_providers.map(
        (provider: any) => ({
          label: provider, // What the user sees in the dropdown
          value: provider, // What gets stored as the selected value
        })
      );
      setProvider(serviceProviderOptions);

    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };
  const CustomerDropdownOptions = async (offset = 0, limit = 100) => {
    try {
      setIsLoading(true);
      const url = ENV_ROUTES.NOTIFICATION_SERVICES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_notification_rules",
        role_name: role,
        parent_module: "Partner",
        module_name: "Usage Notification",
        feature_module_name: "Usage Notification",
        fetch:"customer_dropdown",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      // const operationOptions = transformOperationTypes(
      //   parsedData.operation_types
      // );
      // setOperationTypeOptions(operationOptions);

      // const fieldTypeOptions = transformFieldTypesToGroupedOptions(
      //   parsedData.field_types
      // );
      // setFieldTypeOptions(fieldTypeOptions);

      const customers = transformCustomersToGroupedOptions(
        parsedData.customer_drop_down
      );
      setCustomerOptions(customers);

      // const serviceProviderOptions = parsedData.service_providers.map(
      //   (provider: any) => ({
      //     label: provider, // What the user sees in the dropdown
      //     value: provider, // What gets stored as the selected value
      //   })
      // );
      // setProvider(serviceProviderOptions);

    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };
  const fetchData = async () => {
      setLoading(true);
      try {
        const url = ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/get_cross_carrier_optimization",
          role_name: role,
          parent_module: "Partner",
          module_name: "Usage Notification",
          feature_module_name: "Usage Notification",
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
        };
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
  
        if (parsedData.flag === false) {
          Modal.error({
            title: 'Data Fetch Error',
            content: parsedData.message || 'An error occurred while fetching data. Please try again.',
            centered: true,
          });
        } else {
          const crossProvider_ = parsedData?.cross_carrier_optimization || false
          setIsCrossProvider(crossProvider_)
          const notification_options = crossProvider_ ? CROSS_PROVIDER_NOTIFICATION_TYPE_OPTIONS : NOT_CROSS_PROVIDER_NOTIFICATION_TYPE_OPTIONS || NOT_CROSS_PROVIDER_NOTIFICATION_TYPE_OPTIONS

          setNotificationTypeOptions(notification_options)
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        Modal.error({
          title: 'Data Fetch Error',
          content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
          centered: true,
        });
      } finally {
        setLoading(false);
  
      }
    };

    // Function to call Notification_sync API
const callNotificationSync = async (ruleDefId: string, actionType: string) => {
  setLoading(true)
  const syncUrl = ENV_ROUTES.NOTIFICATION_SERVICES; 

  const syncData = {
    tenant_name: partner || "default_value",
    username: username,
    path: "/Notification_sync",
    action: actionType, 
    rule_def_id: ruleDefId, 
    parent_module: "Partner",
    module_name: "Usage Notification",
    feature_module_name: "Usage Notification",
    request_received_at: getCurrentDateTime(),
    access_token: token,
    db_name: selectedDb,
    ...metaData,
    sessionID: sessionId,
    is_all_customers_flag:isAllCustomers || false
  };

  try {
    await axios.post(syncUrl, { data: syncData });
  } catch (error) {
    console.error("Error in Notification Sync:", error);
  }
  finally{
    setLoading(false)
  }
};

const messageStyle = {
  fontSize: '14px',
  fontWeight: 'bold',
  padding: '16px',
};

 // Add these transformation functions before your handleSave function in EditNotificationsModal
// Add these transformation functions before your handleSave function in EditNotificationsModal

// Add these transformation functions before your handleSave function in EditNotificationsModal

const transformFieldsBasedOnProvider = (
  expressions: any[],
  ruleObjectTypeMap: any,
  isCrossProvider: boolean,
  notificationType: string
) => {
  // Only transform for Customer Pool Usage Notification or Device Notification when isCrossProvider is true
  // const shouldTransform =
  //   (notificationType === "mobility_pool_notifications") ||
  //   (notificationType === "m2m_pool_notifications");

  // if (!shouldTransform) {
  //   return expressions;
  // }

  return expressions.map((expression) => {
    // Skip non-expression objects (like condition separators)
    if (!expression.const_one && !expression.field_one) {
      return expression;
    }

    const transformedExpression = { ...expression };

    // Transform const_one or field_one
    if (expression.const_one && typeof expression.const_one === "object") {
      transformedExpression.const_one = transformFieldObject(
        expression.const_one,
        ruleObjectTypeMap,
        isCrossProvider,
        notificationType
      );
    } else if (expression.field_one && typeof expression.field_one === "object") {
      transformedExpression.field_one = transformFieldObject(
        expression.field_one,
        ruleObjectTypeMap,
        isCrossProvider,
        notificationType
      );
    }

    // Transform const_two or field_two
    if (expression.const_two && typeof expression.const_two === "object") {
      transformedExpression.const_two = transformFieldObject(
        expression.const_two,
        ruleObjectTypeMap,
        isCrossProvider,
        notificationType
      );
    } else if (expression.field_two && typeof expression.field_two === "object") {
      transformedExpression.field_two = transformFieldObject(
        expression.field_two,
        ruleObjectTypeMap,
        isCrossProvider,
        notificationType
      );
    }

    return transformedExpression;
  });
};

const transformFieldObject = (
  fieldObj: any,
  ruleObjectTypeMap: any,
  isCrossProvider: boolean,
  notificationType: string
) => {
  const transformedObj: any = {};

  console.log(
    "Transforming fieldObj:",
    fieldObj,
    "notificationType:",
    notificationType,
    "isCrossProvider:",
    isCrossProvider
  );

  Object.keys(fieldObj).forEach((fieldName) => {
    const fieldValue = fieldObj[fieldName];
    const fieldName_ = fieldName.toLowerCase();
    console.log("Processing fieldName:", fieldName, "fieldValue:", fieldValue);

    // Extract base value (before underscore)
    const baseValue = fieldValue?.split("_")[0];

    // Default: keep field name same, change only value
    let newObjectTypeId: string | undefined;

    if (notificationType === "mobility_pool_notifications") {
      newObjectTypeId = ruleObjectTypeMap["Mobility Customer Pool Usage"];
    } else if (notificationType === "m2m_pool_notifications") {
      newObjectTypeId = ruleObjectTypeMap["M2M Customer Pool Usage"];
    } else if (notificationType === "m2m_device_notifications") {
      newObjectTypeId = ruleObjectTypeMap["Device"];
    } else if (notificationType === "mobility_device_notifications") {
      newObjectTypeId = ruleObjectTypeMap["Mobility Device"];
    } else if (notificationType === "cross_provider_device_notifications") {
      newObjectTypeId = ruleObjectTypeMap["Cross Provider Device"];
    } else if (notificationType === "cross_provider_pool_notifications") {
      newObjectTypeId = ruleObjectTypeMap["Cross Provider Customer Pool Usage"];
    }

    // Only modify value; keep field name unchanged
    if (newObjectTypeId) {
      transformedObj[fieldName] = `${baseValue}_${newObjectTypeId}`;
    } else {
      transformedObj[fieldName] = fieldValue;
    }
  });

  console.log("Transformed fieldObj:", transformedObj);
  return transformedObj;
};

// Update your handleSave function to use the transformation
const handleSave = async () => {
  const errors = validateForm();
  setValidationErrors(errors);
  // If errors exist, abort the save process
  if (Object.keys(errors).length > 0 || emailError) {
    return;
  }
  setIsLoading(true);
  const url = ENV_ROUTES.NOTIFICATION_SERVICES;
  const transformedCustomerList = isAllCustomers
    ? "All"
    : transformSelectedCustomersForPayload(selectedCustomerOption || []);

  // Get the rule object type map from your backend data
  const ruleObjectTypeMap = {
    "Mobility Device": "47d3aaae-f912-4f50-8e7a-6a0e0495f504",
    "M2M Customer Pool Usage": "a601dd51-ea87-4f2b-a190-937ab968b4af", 
    "Mobility Customer Pool Usage": "c3d1870a-6783-4a9b-a2a2-be7ebdac279b",
    "Device": "1834c245-33b2-4342-8a39-eda996ea0ae8",
    "Cross Provider Device": "21916a87-02b2-4524-9c0e-49649e942fe4",
    "Cross Provider Customer Pool Usage": "612f223f-3c09-4141-aac1-8c433124fc98"
  };

  // Apply transformation to expressions
  const originalTransformedExpressions = expressionBuilderFields.reduce(
    (acc, expression, index) => {
      // Determine keys dynamically based on `isLabel` and `isLabelConstant`
      const fieldKey = expression.isLabel ? "field_one" : "const_one";
      const constantKey = expression.isLabelConstant ? "field_two" : "const_two";

      // Create transformed expression object
      const transformedExpression = {
        [fieldKey]: expression.fieldId
          ? { [expression.field]: expression.fieldId }
          : expression.field,
        cond: expression.conditionId
          ? { [expression.condition]: expression.conditionId }
          : {},
        [constantKey]: expression.constantId
          ? { [expression.constant]: expression.constantId }
          : expression.constant,
      };

      if (expression.conditionId) {
        acc.push(transformedExpression);
        if (expression.showUnitDropdown && expression.unit) {
          transformedExpression.unit = expression.unit;
        }
        if (index < expressionBuilderFields.length - 1) {
          acc.push({
            [`expression_condition_${index + 1}`]: selectedConditions[index] || "AND",
          });
        }
      }
      
      return acc;
    },
    [] as any[]
  );

  // Apply the transformation based on provider type
  const finalTransformedExpressions = transformFieldsBasedOnProvider(
    originalTransformedExpressions,
    ruleObjectTypeMap,
    isCrossProvider, // Pass the isCrossProvider flag
    notificationType // Pass the notification type
  );

  const formData = {
    id: rowData.id,
    notification_type: notificationType,
    rule_id: ruleIdField,
    name: nameField,
    order_of_execution: executionOrderField,
    subject_line: subjectLineField,
    display_message: messageField,
    notes: descriptionField,
    send_to_system_admin: sendToSystem,
    show_projected_usage_cost: showProjected,
    expression_names: finalTransformedExpressions, // Use transformed expressions
    created_by: firstLastName,
    modified_by: firstLastName,
    customer_list: isAllCustomers ? "All" : transformedCustomerList,
    rule_def_id: rowData.rule_def_id,
    version_no: rowData.version_no,
    service_provider: selectedServiceProvider?.value,
    should_send_single_email_to_customer_group: notifyCustomerGroup,
    should_exclude_pooled_device: showExcludedPooledDevices,
    aggregated_customer_email_recipient: sendAllCutomerNotificationsToEmail 
  };

  const data = {
    tenant_name: partner || "default_value",
    username: username,
    path: "/process_notification_rules",
    role_based: role,
    parent_module: "Partner",
    module_name: "Usage Notification",
    feature_module_name: "Usage Notification",
    partner: partner,
    action: "edit",
    changed_data: formData,
    request_received_at: getCurrentDateTime(),
    access_token: token,
    db_name: selectedDb,
    ...metaData,
    sessionID: sessionId,
  };

  try {
    const response = await axios.post(url, { data });
    const parsedData = JSON.parse(response.data.body);

    if (parsedData.flag === false) {
      onClose();
      Modal.error({
        title: "Data Fetch Error",
        content:
          parsedData.message || "An error occurred while saving the data.",
        centered: true,
      });
    } else {
      await callNotificationSync(parsedData.rule_def_id, "edit");
      notification.success({
        message: 'Success',
        description: 'Data updated successfully!',
        style: messageStyle,
        placement: 'top',
      });
      fireSideCannons();
      onClose();
    }
  } catch (error) {
    onClose();
    Modal.error({
      title: "Error",
      content: "There was an error submitting the data.",
    });
  } finally {
    refetchTableData();
    setIsLoading(false);
  }
};

  useEffect(() => {
    fetchDropdownOptions();
    CustomerDropdownOptions();
    fetchData();
  }, [visible]);
  const handleScroll = useCallback(() => {
    if (isLoading) return; // Prevent triggering when already loading
    const menuElement = document.querySelector('.react-select__menu'); // Get the dropdown menu

    if (!menuElement) return;

    const isBottom = menuElement.scrollHeight === menuElement.scrollTop + menuElement.clientHeight;
    if (isBottom) {
      // Calculate the total options currently rendered
      const currentTotal = customerOptions.reduce(
        (acc, group) => acc + group.options.length,
        0
      );
      CustomerDropdownOptions(currentTotal, 100); // Load more options
    }
  }, [isLoading, customerOptions]);

  const modalHeight =
    typeof window !== "undefined" ? (window.innerHeight * 2.5) / 4 : 0;
    const generatePercentageOptions = () => {
      const options = [];
      for (let i = 0; i <= 100; i += 5) {
        options.push({
          value: i.toString(),
          label: `${i}%`
        });
      }
      return options;
    };
    const CustomersSelectComponent = () => (
      <div >
        <label className="block text-sm" style={{ fontFamily: "Calibri" }}>
          Customers & Customer Groups
        </label>
        <Select
          isMulti
          isSearchable
          options={customerOptions}
          menuPlacement="top"
          closeMenuOnSelect={false}
          isDisabled={isAllCustomers}
          value={isAllCustomers ? [] : selectedCustomerOption}
          onChange={(selectedOptions: any) => setSelectedCustomerOption(selectedOptions)}
          components={{
            MenuList:VirtualizedMenuList ,
          }}
          onMenuScrollToBottom={handleScroll}
          styles={{
            menuList: (base) => ({
              ...base,
              height: '200px',
            }),
            menu: (base) => ({
              ...base,
              marginTop: 0,
            }),
          }}
        />
      </div>
    );

    const getFilteredFieldTypeOptions = () => {
  // If notification type is not selected, return all options
  if (!notificationType) {
    return fieldTypeOptions;
  }

  // Define which object types are allowed for each scenario (in lowercase for comparison)
  const allowedTypes: { [key: string]: string[] } = {
    'm2m_device_notifications': [
      'rev.io customer',
      'service provider',
      'device status',
      'device'
    ],
    'm2m_pool_notifications': [
      'rev.io customer',
      'service provider',
      'device status',
      'm2m customer pool usage',
      'device'
    ],
    'mobility_device_notifications': [
      'rev.io customer',
      'service provider',
      'device status',
      'mobility device',
    ],
    'mobility_pool_notifications': [
      'rev.io customer',
      'service provider',
      'device status',
      'mobility device',
      'mobility customer pool usage'
    ],
    "cross_provider_device_notifications": [
      'rev.io customer',
      'service provider',
      'device status',
      'cross provider device',
    ],
    "cross_provider_pool_notifications": [
      'rev.io customer',
      'service provider',
      'device status',
      'cross provider customer pool usage',
    ]
  };

  // Determine which scenario we're in
  let scenarioKey = '';
  // if (isCrossProvider) {
  //   scenarioKey = notificationType === 'customer_pool_usage_notification' 
  //     ? 'crossprovider_on_customer_pool_usage' 
  //     : 'crossprovider_on_device';
  // } else {
  //   scenarioKey = notificationType === 'customer_pool_usage_notification'
  //     ? 'crossprovider_off_customer_pool_usage'
  //     : 'crossprovider_off_device';
  // }

  const allowedTypesForScenario = allowedTypes[notificationType] || [];

  // Filter the options based on what's in the parentheses
  return fieldTypeOptions
    .map(group => ({
      ...group,
      options: group.options.filter(option => {
        // Extract the text within parentheses from the label
        const match = option.label.match(/\(([^()]*)\)(?!.*\([^()]*\))/);
        if (!match) return false;
        
        // Get the object type and convert to lowercase for comparison
        const objectType = match[1].toLowerCase().trim();
        
        // Check if this object type is in the allowed list
        return allowedTypesForScenario.includes(objectType);
      })
    }))
    .filter(group => group.options.length > 0); // Remove empty groups
};
    const renderSecondField = (expression: any, index:number) => {
    const isPercentageField = PERCENTAGE_FIELDS.includes(expression.field);
  
    // Helper function to format constant
    const formatConstant = (constant:any) => {
      if (typeof constant === 'object' && constant !== null) {
        const key = Object.keys(constant)[0];
        return {
          value: key,
          label: `${key}%`,
        };
      } else if (typeof constant === 'number' || typeof constant === 'string') {
        return {
          value: String(constant), // Ensure it's always a string
          label: `${constant}%`,
        };
      }
      return null;
    };
  console.log(expression,"expression")
    // return (
    //   <div className="w-1/2">
    //     {/* Label with toggle functionality */}
    //     <label
    //       className="text-sm cursor-pointer flex items-center"
    //       style={{ fontFamily: "Calibri" }}
    //       onClick={() => handleToggleChange(expression.id)}
    //     >
    //       <ArrowsRightLeftIcon className="w-5 h-5 mr-2 text-blue-500" />
    //       {expression.isLabelConstant
    //         ? "Change to Field"
    //         : "Change to Constant"}
    //       <span className="text-red-500">*</span>
    //     </label>
  
    //     {expression.isLabelConstant ? (
    //       <>
    //         {isPercentageField ? (
    //           <Select
    //             options={generatePercentageOptions()}
    //             value={formatConstant(expression.constant)}
    //             onChange={(selectedOption) => {
    //               if (!selectedOption) return;
  
    //               const selectedValue = String(selectedOption.value); // Ensure value is a string
    //               let newConstant;
  
    //               if (typeof expression.constant === 'object' && expression.constant !== null) {
    //                 const currentKey = Object.keys(expression.constant)[0];
    //                 newConstant = { [selectedValue]: expression.constant[currentKey] || null };
    //               } else {
    //                 newConstant = selectedValue; // Direct assignment for string/number
    //               }
  
    //               setExpressionBuilderFields((prevFields) =>
    //                 prevFields.map((field) =>
    //                   field.id === expression.id ? { ...field, constant: newConstant } : field
    //                 )
    //               );
    //             }}
    //             className="flex-1 mt-2"
    //             placeholder="Select percentage"
    //             menuPlacement="top"
    //             isClearable
    //             isDisabled={["HAS VALUE", "HAS NO VALUE"].includes(expression.condition)}
    //           />
    //         ) : (
    //                       // Show regular text input for non-percentage fields
    //                       <div className="flex items-center space-x-2 mt-2">
    //                         <input
    //                           type="text"
    //                           className={`p-2 border border-gray-300 rounded ${
    //                             expression.showUnitDropdown ? "w-3/4" : "w-full"
    //                           }`}
    //                           placeholder="Enter value"
    //                           value={expression.constant}
    //                           onChange={(e) => {
    //                             const value = e.target.value;
    //                             setChangeToConstant(value);
    //                             setExpressionBuilderFields((prevFields) =>
    //                               prevFields.map((field) =>
    //                                 field.id === expression.id
    //                                   ? { ...field, constant: value }
    //                                   : field
    //                               )
    //                             );
    //                           }}
    //                           disabled={["HAS VALUE", "HAS NO VALUE"].includes(expression.condition)}
    //                         />
                          
    //                         {expression.showUnitDropdown && (
    //                           <Select
    //                             options={[
    //                               { value: "MB", label: "MB" },
    //                               { value: "GB", label: "GB" },
    //                             ]}
    //                             value={expression.unit ? { value: expression.unit, label: expression.unit } : null} // Set the selected value to the unit
    //                             className="w-24"
    //                             onChange={(selectedOption) => {
    //                               setExpressionBuilderFields((prevFields) =>
    //                                 prevFields.map((field) =>
    //                                   field.id === expression.id
    //                                     ? { ...field, unit: selectedOption?.value || "MB" }
    //                                     : field
    //                                 )
    //                               );
    //                             }}
    //                             menuPlacement="top"
    //                           />
    //                         )}
    //                       </div>
    //                     )}
    //                   </>
    //                 ) : (
    //       <Select
    //         options={fieldTypeOptions}
    //         placeholder="Field"
    //         className="flex-1 mt-2"
    //         menuPlacement="top"
    //         value={
    //           expression.constantId
    //             ? { value: expression.constantId, label: expression.constant }
    //             : null
    //         }
    //         onChange={(selectedOption) =>
    //           handleChangeExpressionField(expression.id, "constant", selectedOption || null)
    //         }
    //         isClearable
    //         isDisabled={["HAS VALUE", "HAS NO VALUE"].includes(expression.condition)}
    //       />
    //     )}
    //   </div>
    // );
    return (
      <div className="w-full sm:w-1/2">
        {/* Label with toggle functionality */}
        <label
          className="text-sm cursor-pointer flex items-center mb-2"
          style={{ fontFamily: "Calibri" }}
          onClick={() => handleToggleChange(expression.id)}
        >
          <ArrowsRightLeftIcon className="w-5 h-5 mr-2 text-blue-500" />
          {expression.isLabelConstant
            ? "Change to Field"
            : "Change to Constant"}
          <span className="text-red-500">*</span>
        </label>
    
        {expression.isLabelConstant ? (
          <>
            {isPercentageField ? (
              <Select
                options={generatePercentageOptions()}
                value={formatConstant(expression.constant)}
                onChange={(selectedOption) => {
                  if (!selectedOption) return;
    
                  const selectedValue = String(selectedOption.value); // Ensure value is a string
                  let newConstant;
    
                  if (typeof expression.constant === 'object' && expression.constant !== null) {
                    const currentKey = Object.keys(expression.constant)[0];
                    newConstant = { [selectedValue]: expression.constant[currentKey] || null };
                  } else {
                    newConstant = selectedValue; // Direct assignment for string/number
                  }
    
                  setExpressionBuilderFields((prevFields) =>
                    prevFields.map((field) =>
                      field.id === expression.id ? { ...field, constant: newConstant } : field
                    )
                  );
                }}
                className="w-full"
                placeholder="Select percentage"
                menuPlacement="top"
                isClearable
                isDisabled={["HAS VALUE", "HAS NO VALUE"].includes(expression.condition)}
              />
            ) : (
              // Show regular text input for non-percentage fields
              <div className="flex flex-col sm:flex-row sm:items-center gap-2">
                <input
                  type="text"
                  className={`p-2 border border-gray-300 rounded ${
                    expression.showUnitDropdown 
                      ? "w-full sm:flex-1" 
                      : "w-full"
                  }`}
                  placeholder="Enter value"
                  value={expression.constant}
                  onChange={(e) => {
                    const value = e.target.value;
                    setChangeToConstant(value);
                    setExpressionBuilderFields((prevFields) =>
                      prevFields.map((field) =>
                        field.id === expression.id
                          ? { ...field, constant: value }
                          : field
                      )
                    );
                  }}
                  disabled={["HAS VALUE", "HAS NO VALUE"].includes(expression.condition)}
                />
              
                {expression.showUnitDropdown && (
                  <Select
                    options={[
                      { value: "MB", label: "MB" },
                      { value: "GB", label: "GB" },
                    ]}
                    value={expression.unit ? { value: expression.unit, label: expression.unit } : null}
                    className="w-full sm:w-24"
                    onChange={(selectedOption) => {
                      setExpressionBuilderFields((prevFields) =>
                        prevFields.map((field) =>
                          field.id === expression.id
                            ? { ...field, unit: selectedOption?.value || "MB" }
                            : field
                        )
                      );
                    }}
                    menuPlacement="top"
                  />
                )}
              </div>
            )}
          </>
        ) : (
          <Select
            // options={fieldTypeOptions}
            options={getFilteredFieldTypeOptions()} // Use filtered options
            placeholder="Field"
            className="w-full"
            menuPlacement="top"
            value={
              expression.constantId
                ? { value: expression.constantId, label: expression.constant }
                : null
            }
            onChange={(selectedOption) =>
              handleChangeExpressionField(expression.id, "constant", selectedOption || null)
            }
            isClearable
            isDisabled={["HAS VALUE", "HAS NO VALUE"].includes(expression.condition)}
          />
        )}
      </div>
    );
  };
  

  // return (
  //   <>
  //     <Modal
  //       title={
  //         <div className="flex items-center gap-4">
  //           <span
  //             className="text-xl texfont-semibold"
  //             style={{ fontFamily: "Calibri", top: 40}}
  //           >
  //             Notification Editor
  //           </span>
  //           <button className="save-btn gap-2 ml-auto mr-6"  onClick={openModal} >
  //           <FaUndo />
  //               Versions
  //             </button>
  //             {isModalOpen &&  <VersionModal
  //       isOpen={isModalOpen}
  //       onClose={closeModal}
  //       onSave={handleSave}
  //       ruleDefId={ruleDefId} 
  //       title="Version History"
  //     />}
  //         </div>
  //       }
  //       visible={visible}
  //       centered
  //       onCancel={onClose}
  //       footer={null}
  //       width={900}
  //       // className="p-5 overflow-y-auto max-h-[65vh]"
  //       bodyStyle={{
  //         paddingRight: "10px",
  //         overflowY: "auto",
  //         maxHeight: "75vh",
  //         // height:modalHeight
  //       }}
  //     >
  //       {isLoading ? (
  //         <div
  //           className="flex justify-center items-center"
  //           style={{
  //             height: modalHeight,
  //             overflowY: "auto",
  //             overflowX: "hidden",
  //           }}
  //         >
  //           <Spin size="large" />
  //         </div>
  //       ) : (
  //         <div className="space-y-6">
  //           <div className="flex items-center gap-4">
  //             <div className="w-1/3">
  //               <label
  //                 className="block text-sm "
  //                 style={{ fontFamily: "Calibri" }}
  //               >
  //                 Rule ID
  //               </label>
  //               <input
  //                 value={ruleIdField}
  //                 onChange={(e) => setRuleIdField(e.target.value)}
  //                 type="text"
  //                 disabled
  //                 placeholder="Auto-generated"
  //                 className="w-full p-2 border border-gray-300 rounded-md bg-gray-100 text-gray-700"
  //               />
  //             </div>
  //             <div className="w-1/3">
  //               <label
  //                 className="block text-sm"
  //                 style={{ fontFamily: "Calibri" }}
  //               >
  //                 Name<span className="text-red-500">*</span>
  //               </label>
  //               <input
  //                 type="text"
  //                 value={nameField}
  //                 onChange={handleNameChange}
  //                 placeholder="Rule name"
  //                 className="w-full p-2 border border-gray-300 rounded-md"
  //               />
  //               {validationErrors.name && (
  //                 <span className="text-red-500 text-sm">
  //                   {validationErrors.name}
  //                 </span>
  //               )}
  //             </div>
  //             <div className="w-1/3">
  //               <label
  //                 className="text-sm flex items-center justify-between"
  //                 style={{ fontFamily: "Calibri" }}
  //               >
  //                 Execution Order
  //                 <Tooltip title="Controls the Delivery Orders of Notifications">
  //                   <InformationCircleIcon className="w-4 h-4 text-gray-500 cursor-pointer" />
  //                 </Tooltip>
  //               </label>
  //               <input
  //                 type="number"
  //                 value={executionOrderField}
  //                 onChange={(e) => {
  //                   const value = Number(e.target.value);
  //                   if (value >= 0) {
  //                     setExecutionOrderField(value); // Allow only positive values
  //                   }
  //                 }}
  //                 min="0"
  //                 placeholder="Numeric value"
  //                 className="w-full p-2 border border-gray-300 rounded-md"
  //                 disabled
  //               />
  //             </div>
  //           </div>

  //           {/* Subject Line */}
  //           <div>
  //             <label
  //               className="text-sm flex items-center justify-between"
  //               style={{ fontFamily: "Calibri" }}
  //             >
  //               Subject Line
  //               <Tooltip title="Message for Notification Email Subject Line">
  //                 <InformationCircleIcon className="w-4 h-4 text-gray-500 cursor-pointer" />
  //               </Tooltip>
  //             </label>
  //             <input
  //               type="text"
  //               onChange={(e) => setSubjectLineField(e.target.value)}
  //               placeholder="Email subject"
  //               value={subjectLineField}
  //               className="w-full p-2 border border-gray-300 rounded-md"
  //             />
  //           </div>

  //           {/* Message */}
  //           <div>
  //             <label
  //               className="text-sm flex items-center justify-between"
  //               style={{ fontFamily: "Calibri" }}
  //             >
  //               <div className="flex items-center gap-1">
  //                 <span>Message</span>
  //                 <span className="text-red-500">*</span>
  //               </div>
  //               <Tooltip title="Message for Notification Email Body">
  //                 <InformationCircleIcon className="w-4 h-4 text-gray-500 cursor-pointer" />
  //               </Tooltip>
  //             </label>
  //             <textarea
  //               value={messageField}
  //               onChange={(e) => setMessageField(e.target.value)}
  //               placeholder="Email content"
  //               className="w-full p-2 border border-gray-300 rounded-md h-24 resize-none"
  //             ></textarea>
  //             {validationErrors.message && (
  //               <span className="text-red-500 text-sm">
  //                 {validationErrors.message}
  //               </span>
  //             )}
  //           </div>

  //           {/* Description */}
  //           <div>
  //             <label
  //               className="text-sm flex items-center justify-between"
  //               style={{ fontFamily: "Calibri" }}
  //             >
  //               <div className="flex items-center gap-1">
  //                 <span>Description</span>
  //                 <span className="text-red-500">*</span>
  //               </div>
  //               <Tooltip title="An Informational field for Internal and Historical Documentation is not Customer-Facing">
  //                 <InformationCircleIcon className="w-4 h-4 text-gray-500 cursor-pointer" />
  //               </Tooltip>
  //             </label>
  //             <textarea
  //               value={descriptionField}
  //               onChange={(e) => setDescriptionField(e.target.value)}
  //               placeholder="Rule description"
  //               className="w-full p-2 border border-gray-300 rounded-md h-24 resize-none"
  //             ></textarea>
  //             {validationErrors.description && (
  //               <span className="text-red-500 text-sm">
  //                 {validationErrors.description}
  //               </span>
  //             )}
  //           </div>

  //           <div className="flex gap-3">
  //             {/* Checkbox for System Admin */}
  //             <div className="flex items-center space-x-2">
  //               <input
  //                 type="checkbox"
  //                 id="sendToAdmin"
  //                 className="h-4 w-4"
  //                 checked={sendToSystem}
  //                 onChange={handleAdminCheckbox}
  //               />
  //               <label
  //                 htmlFor="sendToAdmin"
  //                 className="text-sm"
  //                 style={{ fontFamily: "Calibri" }}
  //               >
  //                 Send to System Admin
  //               </label>
  //             </div>
  //             {/* Checkbox for Projected Usage */}
  //             <div className="flex items-center space-x-2">
  //               <input
  //                 checked={showProjected}
  //                 onChange={handleProjectedCheckbox}
  //                 type="checkbox"
  //                 id="showProjectedUsage"
  //                 className="h-4 w-4"
  //               />
  //               <label
  //                 htmlFor="showProjectedUsage"
  //                 className="text-sm"
  //                 style={{ fontFamily: "Calibri" }}
  //               >
  //                 Show Projected Usage Cost
  //               </label>
  //             </div>
  //           </div>

  //           {/* Customers & Customer Groups */}
  //           <div className="flex items-start gap-4 w-full">
  //             {/* <div className="w-1/3">
  //               <label
  //                 className="block text-sm"
  //                 style={{ fontFamily: "Calibri" }}
  //               >
  //                 Service Provider<span className="text-red-500">*</span>
  //               </label>

  //               <Select
  //                 isSearchable
  //                 options={provider}
  //                 menuPlacement="top"
  //                 closeMenuOnSelect={true}
  //                 value={selectedServiceProvider}
  //                 onChange={(value: any) => setSelectedServiceProvider(value)}
  //               />
  //               {validationErrors.service_provider && (
  //                 <span className="text-red-500 text-sm">
  //                   {validationErrors.service_provider}
  //                 </span>
  //               )}
  //             </div> */}
  //             {/* Customers & Customer Groups */}
  //             <div className="w-1/3">
  //               {/* <label
  //                 className="block text-sm"
  //                 style={{ fontFamily: "Calibri" }}
  //               >
  //                 Customers & Customer Groups
  //               </label>
  //               <Select
  //                 isMulti
  //                 isSearchable
  //                 options={customerOptions}
  //                 value={selectedCustomerOption}
  //                 menuPlacement="top"
  //                 closeMenuOnSelect={false}
  //                 isDisabled={isAllCustomers}
  //                 onChange={handleCustomerChange}
  //               /> */}
  //                <CustomersSelectComponent />
  //             </div>

  //             {/* All Customers? */}
  //             <div className="w-1/4 flex items-center space-x-3 mt-8">
  //               <label
  //                 htmlFor="allCustomers"
  //                 className="flex items-center gap-3"
  //                 style={{ fontFamily: "Calibri" }}
  //               >
  //                 <span>All Customers</span>
  //                 <Switch
  //                   checked={isAllCustomers}
  //                   onChange={handleSwitchChange}
  //                 />
  //               </label>
  //             </div>
  //           </div>

  //           <div className="mb-2">
  //             <h2
  //               className="text-lg font-semibold mb-2"
  //               style={{ fontFamily: "Calibri" }}
  //             >
  //               Expression Builder
  //             </h2>

  //             {expressionBuilderFields.map((expression, index) => (
  //               <div key={expression.id}>
  //                 {expression.conditionId && (
  //                   <div className="flex items-center space-x-4 rounded-md">
  //                   <div className="w-1/2">
  //                     {/* Label with toggle functionality */}
  //                     <label
  //                       className="text-sm cursor-pointer flex items-center"
  //                       style={{ fontFamily: "Calibri " }}
  //                       onClick={() => handleToggle(expression.id)} // Pass the unique id
  //                     >
  //                       <ArrowsRightLeftIcon className="w-5 h-5 mr-2 text-blue-500" />
  //                       {expression.isLabel
  //                         ? "Change to Field"
  //                         : "Change to Constant"}
  //                         <span className="text-red-500">*</span>
  //                     </label>

  //                     {/* Toggle between input field and dropdown */}
  //                     {expression.isLabel ? (
  //                       <input
  //                         type="text"
  //                         className="flex-1 mt-3 p-2 border border-gray-300 rounded w-full"
  //                         placeholder="Enter value"
  //                         value={expression.field} // Use row-specific value
  //                         onChange={(e) => {
  //                           const value = e.target.value;
  //                           setChangeToField(value)
  //                           setExpressionBuilderFields((prevFields) =>
  //                             prevFields.map((field) =>
  //                               field.id === expression.id
  //                                 ? { ...field, field: value } // Update the specific row's field value
  //                                 : field
  //                             )
  //                           );
  //                         }}
  //                       />
  //                     ) : (
  //                       <Select
  //                         options={fieldTypeOptions}
  //                         placeholder="Field"
  //                         className="flex-1 mt-2"
  //                         menuPlacement="top"
  //                         value={
  //                           expression.field
  //                             ? {
  //                               value: expression.fieldId,
  //                               label: expression.field
  //                             }
  //                             : null
  //                         }
  //                         // onChange={(selectedOption) =>
  //                         //   handleChangeExpressionField(
  //                         //     expression.id,
  //                         //     "field",
  //                         //     selectedOption || null
  //                         //   )
  //                         // }
  //                         onChange={(selectedOption) => {
  //                           handleChangeExpressionField(
  //                             expression.id,
  //                             "field",
  //                             selectedOption || null
  //                           )
  //                           const selectedValue = selectedOption?.label || '';
  //                           const dropdownTriggers = ['CtdDataUsage', 'Total Carrier Cycle Data Usage', 'Total Customer Cycle Data Usage'];
  //                           const showUnitDropdown = dropdownTriggers.some(value => selectedValue.startsWith(value));
  //                           // const showUnitDropdown = selectedValue.startsWith('CtdDataUsage'); 
  //                           setExpressionBuilderFields((prevFields) =>
  //                             prevFields.map((field, idx) =>
  //                               idx === index
  //                                 ? {
  //                                   ...field,
  //                                   field: selectedValue,
  //                                   unit: showUnitDropdown ? field.unit || "MB" : "",
  //                                   showUnitDropdown,
  //                                 }
  //                                 : field
  //                             )
  //                           );

  //                         }}
  //                         isClearable
  //                       />
  //                     )}
  //                   {validationErrors[`expression_field_${index}`] && (
  //                       <span className="text-red-500 text-sm">
  //                         {validationErrors[`expression_field_${index}`]}
  //                       </span>
  //                     )}                                   
  //                   </div>

  //                   <div className="w-1/4">
  //                   <label
  //                       className="text-sm flex items-center"
  //                       style={{ fontFamily: "Calibri " }}
  //                     >
  //                         Condition
  //                         <span className="text-red-500">*</span>
  //                     </label>
  //                     <Select
  //                       isSearchable
  //                       options={operationTypeOptions}
  //                       value={
  //                         expression.condition
  //                           ? {
  //                             value: expression.condition,
  //                             label: expression.condition,
  //                           }
  //                           : null
  //                       }
  //                       placeholder="Condition"
  //                       menuPlacement="top"
  //                       className="flex-1 mt-2"
  //                       onChange={(selectedOption) =>
  //                         handleChangeExpressionField(
  //                           expression.id,
  //                           "condition",
  //                           selectedOption || null
  //                         )
  //                       }
  //                       isClearable
  //                     />
  //                     {validationErrors[`expression_condition_${index}`] && (
  //                       <span className="text-red-500 text-sm">
  //                         {validationErrors[`expression_condition_${index}`]}
  //                       </span>
  //                     )}
  //                   </div>

                    
  //                   {renderSecondField(expression, index)}
  //                   {/* Add and Remove Icons */}
  //                   <PlusCircleIcon
  //                     className="w-8 h-8 text-green-500 cursor-pointer mt-4"
  //                     onClick={addExpressionField}
  //                   />
  //                   {expressionBuilderFields.length > 1 && (
  //                     <MinusCircleIcon
  //                       className="w-8 h-8 text-red-500 cursor-pointer mt-4"
  //                       onClick={() => removeExpressionField(expression.id)} // Pass the specific field's ID
  //                     />
  //                   )}
  //                 </div>
  //                 )}
                  
  //                 {/* Condition Dropdown - Display once for each pair of fields */}
  //                 {expression.conditionId && index < expressionBuilderFields.length - 1 && (
  //                   <div className="rounded-md w-1/4 mb-3 mt-4">
  //                     <Select
  //                       options={[
  //                         { value: "AND", label: "AND" },
  //                         { value: "OR", label: "OR" },
  //                       ]}
  //                       placeholder="Select Condition"
  //                       className="w-full"
  //                       value={
  //                         selectedConditions[index]
  //                           ? {
  //                             value: selectedConditions[index],
  //                             label: selectedConditions[index],
  //                           }
  //                           : { value: "AND", label: "AND" }
  //                       } // Pass the whole object, not just the string
  //                       onChange={(selectedOption) =>
  //                         setSelectedConditions((prev) => {
  //                           const newConditions = [...prev];
  //                           newConditions[index] = selectedOption?.value || ""; // Default to an empty string if null
  //                           return newConditions;
  //                         })
  //                       }
  //                     />
  //                   </div>
  //                 )}
  //                 {/* {validationErrors[`expression_service_provider_field_${index}`] && (
  //                       <span className="text-red-500 text-sm">
  //                         {validationErrors[`expression_service_provider_field_${index}`]}
  //                       </span>
  //                     )} */}
  //               </div>
                
  //             ))}
  //           </div>
  //           {/* Only show this error once after the loop */}
  //           {validationErrors['expression_service_provider_field'] && (
  //       <span className="text-red-500 text-sm">
  //         {validationErrors['expression_service_provider_field']}
  //       </span>
  //     )}

  //           {/* Footer Buttons */}
  //           <div className="flex justify-center gap-4 mt-6">
  //             <button onClick={onClose} className="cancel-btn">
  //               Cancel
  //             </button>
  //             <button className="save-btn" onClick={handleSave}>
  //               Save
  //             </button>
  //           </div>
  //         </div>
  //       )}
  //     </Modal>
  //   </>
  // );
  return (
    <>
      <Modal
        title={
          <div className="flex items-center gap-4">
            <span
              className="text-lg sm:text-xl font-semibold"
              style={{ fontFamily: "Calibri",top:40 }}
            >
              Notification Editor
            </span>
            <button className="save-btn gap-2 ml-auto mr-6"  onClick={openModal} >
            <FaUndo />
                Versions
              </button>
              {isModalOpen &&  <VersionModal
        isOpen={isModalOpen}
        onClose={closeModal}
        onSave={handleSave}
        ruleDefId={ruleDefId} 
        title="Version History"
      />}
          </div>
        }
        visible={visible}
        centered
        onCancel={onClose}
        footer={null}
        width={window.innerWidth < 768 ? '95%' : 900}
        bodyStyle={{
          paddingRight: "10px",
          overflowY: "auto",
          maxHeight: "75vh",
        }}
      >
        {isLoading ? (
          <div
            className="flex justify-center items-center"
            style={{
              height: modalHeight,
              overflowY: "auto",
              overflowX: "hidden",
            }}
          >
            <Spin size="large" />
          </div>
        ) : (
          <div className="space-y-4 sm:space-y-6">
            {/* Top Form Fields - Responsive Grid */}
            <div className="flex flex-col sm:flex-row sm:items-center gap-4">
              <div className="w-full sm:w-1/4">
              <label
    className="block text-sm "
    style={{ fontFamily: "Calibri" }}
  >
    Notification Type
  </label>
  <Select
    options={notificationTypeOptions}
    value={
      notificationType
        ? notificationTypeOptions.find((opt:any) => opt.value === notificationType)
        : null
    }
    placeholder="Select..."
    // className="w-full"
    styles={NonEditableDropdownStyles}
    isDisabled={true} // This makes it non-editable
    isClearable={false}
  />
              </div>
              <div className="w-full sm:w-1/4">
                <label
                  className="block text-sm mb-1"
                  style={{ fontFamily: "Calibri" }}
                >
                  Rule ID
                </label>
                <input
                  value={ruleIdField}
                  onChange={(e) => setRuleIdField(e.target.value)}
                  type="text"
                  disabled
                  placeholder="Auto-generated"
                  className="w-full p-2 border border-gray-300 rounded-md bg-gray-100 text-gray-700"
                />
              </div>
              <div className="w-full sm:w-1/4">
                <label
                  className="block text-sm mb-1"
                  style={{ fontFamily: "Calibri" }}
                >
                  Name<span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={nameField}
                  onChange={handleNameChange}
                  placeholder="Rule name"
                  className="w-full p-2 border border-gray-300 rounded-md"
                />
                {validationErrors.name && (
                  <span className="text-red-500 text-sm mt-1 block">
                    {validationErrors.name}
                  </span>
                )}
              </div>
              <div className="w-full sm:w-1/4">
                <label
                  className="text-sm flex items-center justify-between mb-1"
                  style={{ fontFamily: "Calibri" }}
                >
                  Execution Order
                  <Tooltip title="Controls the Delivery Orders of Notifications">
                    <InformationCircleIcon className="w-4 h-4 text-gray-500 cursor-pointer" />
                  </Tooltip>
                </label>
                <input
                  type="number"
                  value={executionOrderField}
                  onChange={(e) => {
                    const value = Number(e.target.value);
                    if (value >= 0) {
                      setExecutionOrderField(value);
                    }
                  }}
                  min="0"
                  placeholder="Numeric value"
                  className="w-full p-2 border border-gray-300 rounded-md"
                  disabled
                />
              </div>
            </div>

            {/* Subject Line */}
            <div>
              <label
                className="text-sm flex items-center justify-between mb-1"
                style={{ fontFamily: "Calibri" }}
              >
                Subject Line
                <Tooltip title="Message for Notification Email Subject Line">
                  <InformationCircleIcon className="w-4 h-4 text-gray-500 cursor-pointer" />
                </Tooltip>
              </label>
              <input
                type="text"
                onChange={(e) => setSubjectLineField(e.target.value)}
                placeholder="Email subject"
                value={subjectLineField}
                className="w-full p-2 border border-gray-300 rounded-md"
              />
            </div>

            {/* Message */}
            <div>
              <label
                className="text-sm flex items-center justify-between mb-1"
                style={{ fontFamily: "Calibri" }}
              >
                <div className="flex items-center gap-1">
                  <span>Message</span>
                  <span className="text-red-500">*</span>
                </div>
                <Tooltip title="Message for Notification Email Body">
                  <InformationCircleIcon className="w-4 h-4 text-gray-500 cursor-pointer" />
                </Tooltip>
              </label>
              <textarea
                value={messageField}
                onChange={(e) => setMessageField(e.target.value)}
                placeholder="Email content"
                className="w-full p-2 border border-gray-300 rounded-md h-20 sm:h-24 resize-none"
              ></textarea>
              {validationErrors.message && (
                <span className="text-red-500 text-sm mt-1 block">
                  {validationErrors.message}
                </span>
              )}
            </div>

            {/* Description */}
            <div>
              <label
                className="text-sm flex items-center justify-between mb-1"
                style={{ fontFamily: "Calibri" }}
              >
                <div className="flex items-center gap-1">
                  <span>Description</span>
                  <span className="text-red-500">*</span>
                </div>
                <Tooltip title="An Informational field for Internal and Historical Documentation is not Customer-Facing">
                  <InformationCircleIcon className="w-4 h-4 text-gray-500 cursor-pointer" />
                </Tooltip>
              </label>
              <textarea
                value={descriptionField}
                onChange={(e) => setDescriptionField(e.target.value)}
                placeholder="Rule description"
                className="w-full p-2 border border-gray-300 rounded-md h-20 sm:h-24 resize-none"
              ></textarea>
              {validationErrors.description && (
                <span className="text-red-500 text-sm mt-1 block">
                  {validationErrors.description}
                </span>
              )}
            </div>

            {/* Checkboxes - Responsive Layout */}
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-6">
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="sendToAdmin"
                  className="h-4 w-4"
                  checked={sendToSystem}
                  onChange={handleAdminCheckbox}
                />
                <label
                  htmlFor="sendToAdmin"
                  className="text-sm"
                  style={{ fontFamily: "Calibri" }}
                >
                  Send to System Admin
                </label>
              </div>
              <div className="flex items-center space-x-2">
                <input
                  checked={showProjected}
                  onChange={handleProjectedCheckbox}
                  type="checkbox"
                  id="showProjectedUsage"
                  className="h-4 w-4"
                />
                <label
                  htmlFor="showProjectedUsage"
                  className="text-sm"
                  style={{ fontFamily: "Calibri" }}
                >
                  Show Projected Usage Cost
                </label>
              </div>
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="notifyCustomerGroup"
                  className="h-4 w-4"
                  checked={notifyCustomerGroup}
                  onChange={(e) => setNotifyCustomerGroup(e.target.checked)}
                />
                <label
                  htmlFor="notifyCustomerGroup"
                  className="text-sm"
                  style={{ fontFamily: "Calibri " }}
                >
                  Notify Customer Group
                </label>
              </div>
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="excludePooledDevices"
                  className="h-4 w-4"
                  checked={showExcludedPooledDevices}
                  onChange={(e) => setShowExcludedPooledDevices(e.target.checked)}
                />
                <label
                  htmlFor="excludePooledDevices"
                  className="text-sm"
                  style={{ fontFamily: "Calibri " }}
                >
                  Show Exclude pooled devices?
                </label>
              </div>
            </div>
              <div className="w-1/3">
                <label
                  className="block text-sm"
                  style={{ fontFamily: "Calibri " }}
                >
                  Send All Customer Notifications To Email
                </label>
                <input
                  type="text"
                  placeholder="Enter Email"
                  className="w-full p-2 border border-gray-300 rounded-md input"
                  value={sendAllCutomerNotificationsToEmail}
                  onChange={handleEmailChange}
                />
                {emailError && (
                  <p className="text-red-500 text-sm mt-1">{emailError}</p>
                )}
              </div>
            {/* Customers & Customer Groups - Responsive Layout */}
            <div className="flex flex-col sm:flex-row sm:items-start gap-4 w-full">
              <div className="w-full sm:w-1/3">
                <CustomersSelectComponent />
              </div>

              {/* All Customers Switch */}
              <div className="w-full sm:w-1/4 flex items-center space-x-3 sm:mt-8">
                <label
                  htmlFor="allCustomers"
                  className="flex items-center gap-3"
                  style={{ fontFamily: "Calibri" }}
                >
                  <span>All Customers</span>
                  <Switch
                    checked={isAllCustomers}
                    onChange={handleSwitchChange}
                  />
                </label>
              </div>
            </div>

            {/* Expression Builder - Enhanced Responsive Design */}
            <div className="mb-2">
              <h2
                className="text-lg font-semibold mb-2"
                style={{ fontFamily: "Calibri" }}
              >
                Expression Builder
              </h2>

              {expressionBuilderFields.map((expression, index) => (
                <div key={expression.id}>
                  {expression.conditionId && (
                    <div className="space-y-4 sm:space-y-0 sm:flex sm:items-center sm:space-x-4 rounded-md mb-4">
                      {/* Field Section */}
                      <div className="w-full sm:w-1/2">
                        <label
                          className="text-sm cursor-pointer flex items-center mb-2"
                          style={{ fontFamily: "Calibri" }}
                          onClick={() => handleToggle(expression.id)}
                        >
                          <ArrowsRightLeftIcon className="w-5 h-5 mr-2 text-blue-500" />
                          {expression.isLabel
                            ? "Change to Field"
                            : "Change to Constant"}
                          <span className="text-red-500">*</span>
                        </label>

                        {expression.isLabel ? (
                          <input
                            type="text"
                            className="w-full p-2 border border-gray-300 rounded"
                            placeholder="Enter value"
                            value={expression.field}
                            onChange={(e) => {
                              const value = e.target.value;
                              setChangeToField(value)
                              setExpressionBuilderFields((prevFields) =>
                                prevFields.map((field) =>
                                  field.id === expression.id
                                    ? { ...field, field: value }
                                    : field
                                )
                              );
                            }}
                          />
                        ) : (
                          <Select
                            // options={fieldTypeOptions}
                            options={getFilteredFieldTypeOptions()} // Use filtered options
                            placeholder="Field"
                            className="w-full"
                            menuPlacement="top"
                            value={
                              expression.field
                                ? {
                                  value: expression.fieldId,
                                  label: expression.field
                                }
                                : null
                            }
                            onChange={(selectedOption) => {
                              handleChangeExpressionField(
                                expression.id,
                                "field",
                                selectedOption || null
                              )
                              const selectedValue = selectedOption?.label || '';
                              const dropdownTriggers = ['CtdDataUsage', 'Total Carrier Cycle Data Usage', 'Total Customer Cycle Data Usage'];
                              const showUnitDropdown = dropdownTriggers.some(value => selectedValue.startsWith(value));
                              setExpressionBuilderFields((prevFields) =>
                                prevFields.map((field, idx) =>
                                  idx === index
                                    ? {
                                      ...field,
                                      field: selectedValue,
                                      unit: showUnitDropdown ? field.unit || "MB" : "",
                                      showUnitDropdown,
                                    }
                                    : field
                                )
                              );
                            }}
                            isClearable
                          />
                        )}
                        {validationErrors[`expression_field_${index}`] && (
                          <span className="text-red-500 text-sm mt-1 block">
                            {validationErrors[`expression_field_${index}`]}
                          </span>
                        )}                                   
                      </div>

                      {/* Condition Section */}
                      <div className="w-full sm:w-1/4">
                        <label
                          className="text-sm flex items-center mb-2"
                          style={{ fontFamily: "Calibri" }}
                        >
                          Condition
                          <span className="text-red-500">*</span>
                        </label>
                        <Select
                          isSearchable
                          options={operationTypeOptions}
                          value={
                            expression.condition
                              ? {
                                value: expression.condition,
                                label: expression.condition,
                              }
                              : null
                          }
                          placeholder="Condition"
                          menuPlacement="top"
                          className="w-full"
                          onChange={(selectedOption) =>
                            handleChangeExpressionField(
                              expression.id,
                              "condition",
                              selectedOption || null
                            )
                          }
                          isClearable
                        />
                        {validationErrors[`expression_condition_${index}`] && (
                          <span className="text-red-500 text-sm mt-1 block">
                            {validationErrors[`expression_condition_${index}`]}
                          </span>
                        )}
                      </div>

                      {/* Second Field (render function call) */}
                      {renderSecondField(expression, index)}

                      {/* Action Icons - Responsive positioning */}
                      <div className="flex sm:flex-col items-center gap-2 sm:gap-1 sm:mt-4 justify-center sm:justify-start">
                        <PlusCircleIcon
                          className="w-7 h-7 sm:w-8 sm:h-8 text-green-500 cursor-pointer"
                          onClick={addExpressionField}
                        />
                        {expressionBuilderFields.length > 1 && (
                          <MinusCircleIcon
                            className="w-7 h-7 sm:w-8 sm:h-8 text-red-500 cursor-pointer"
                            onClick={() => removeExpressionField(expression.id)}
                          />
                        )}
                      </div>
                    </div>
                  )}
                  
                  {/* Condition Dropdown - Responsive */}
                  {expression.conditionId && index < expressionBuilderFields.length - 1 && (
                    <div className="w-full sm:w-1/4 mb-3 mt-2 sm:mt-4">
                      <Select
                        options={[
                          { value: "AND", label: "AND" },
                          { value: "OR", label: "OR" },
                        ]}
                        placeholder="Select Condition"
                        className="w-full"
                        value={
                          selectedConditions[index]
                            ? {
                              value: selectedConditions[index],
                              label: selectedConditions[index],
                            }
                            : { value: "AND", label: "AND" }
                        }
                        onChange={(selectedOption) =>
                          setSelectedConditions((prev) => {
                            const newConditions = [...prev];
                            newConditions[index] = selectedOption?.value || "";
                            return newConditions;
                          })
                        }
                      />
                    </div>
                  )}
                </div>
              ))}
            </div>
            
            {/* Expression validation error */}
            {validationErrors['expression_service_provider_field'] && (
              <span className="text-red-500 text-sm">
                {validationErrors['expression_service_provider_field']}
              </span>
            )}

            {/* Footer Buttons */}
            <div className="flex justify-center gap-4 mt-6">
              <button onClick={onClose} className="cancel-btn">
                Cancel
              </button>
              <button className="save-btn" onClick={handleSave}>
                Save
              </button>
            </div>
          </div>
        )}
      </Modal>
    </>
  );
};

export default EditNotificationsModal;
