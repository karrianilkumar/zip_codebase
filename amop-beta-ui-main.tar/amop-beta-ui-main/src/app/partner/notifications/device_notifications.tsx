"use client";
import React, {
  Suspense,
  useCallback,
  useEffect,
  useRef,
  useState,
} from "react";
import TableComponent from "@/app/components/TableComponent/page";
import ColumnFilter from "@/app/components/columnfilter";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { useAuth } from "@/app/components/auth_context";

import TableSearch from "@/app/components/entire_table_search";
import axios from "axios";
import { Modal, notification, Spin } from "antd";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { PlusIcon } from "@heroicons/react/24/outline";
import { DownloadOutlined } from "@ant-design/icons";
import AddNotificationsModal from "./add_notifications";
import AdvancedMultiFilter from "@/app/components/advanced_search";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { useCustomerRatePlanStore } from "@/app/stores/customerRateplanStore";
import { fireSideCannons } from "@/app/components/confetti";

interface ExcelData {
  [key: string]: any;
}

const DeviceNotifications: React.FC = () => {
  const [data, setData] = useState<ExcelData[]>([]);
  const [isAddNotifications, setAddNotifications] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  // const {showAdvanced, setShowAdvanced} = useCustomerRatePlanStore();
  const {
    username,
    partner,
    role,
    settabledata,
    token,
    selectedDb,
    metaData,
    firstLastName,
    advancedStoredpagination,
    tenantId,
    storedpagination,
    sessionId,
    combineAdnvaceStoredpagination,
    setCombineAdnvaceStoredpagination,
    dynamicColumns,
    setDynamicColumns
  } = useAuth();
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState<any>({});
  const [features, setFeatures] = useState<string[]>([]);
  const [popupData, setPopupData] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
  const [isUploadModalVisible, setIsUploadModalVisible] = useState(false);
  const [uploadKey, setUploadKey] = useState(Date.now());
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  // const [exportLoading, setExportLoading] = useState(false);/
  const { addExport, removeExport,exports } = exportLoadingStore();
    const exportKey ="Device Notifications";
    const [executionOrderField, setExecutionOrderField] = useState<
    number | undefined
  >();

  type HeaderMap = Record<string, [string, number]>;
  const hasFetchedData = useRef(false);

  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);

  useEffect(() => {
        setDynamicColumns((prev:any)=>({...prev,"Usage Notification":visibleColumns}))
      }, [visibleColumns]);

  const fetchData = async () => {
    setCombineAdnvaceStoredpagination(null)
    setLoading(true);
    settabledata([])
    setShowAdvanced(false)
    try {
      // settabledata([]);
      // addLog("UI API call");
      const url = ENV_ROUTES.NOTIFICATION_SERVICES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_notification_rules",
        role_name: role,
        parent_module: "Partner",
        module_name: "Usage Notification",
        feature_module_name: "Usage Notification",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };
      console.log(
        getCurrentDateTime(),
        "Show the log time request sent from ui to lambda"
      );
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      console.log(
        getCurrentDateTime(),
        "Show the log time response sent from lambda to ui"
      );
      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      } else {
        const headersMap_ =
          parsedData?.headers_map?.["Usage Notification"]?.header_map || {};
        const sortedheaderMap = sortHeaderMap(headersMap_);
        setHeaderMap(sortedheaderMap);
        const headers_ =
          Object.keys(sortedheaderMap).length > 0
            ? Object.keys(sortedheaderMap)
            : [];
        setHeaders(headers_);
          const dynamic_cols=dynamicColumns?.["Usage Notification"] && dynamicColumns["Usage Notification"].length>0 ?dynamicColumns["Usage Notification"] :headers_ || headers_
          setVisibleColumns(dynamic_cols)
        const tableData_ = parsedData?.rule_data || [];
        setData(tableData_);
        setExecutionOrderField(parsedData?.order_of_execution)
        
        const features_ =
          parsedData?.headers_map?.["Usage Notification"]?.module_features ||
          [];
        setFeatures(features_);
        const allowedActions_: any = [];
        if (features_.includes("Edit-Notification")) {
          allowedActions_.push("editNotification");
        }
        if (features_.includes("Delete-Notification")) {
          allowedActions_.push("delete");
        }
        setAllowedActions(allowedActions_);
        const pagination_ = parsedData?.pages || {};
        setPagination(pagination_);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    // if (!hasFetchedData.current) {
      fetchData();
    //   hasFetchedData.current = true;
    // }
  }, [partner]);

  const handleFilter = (advancedFilters: any) => {
    setAdvancedFilters(advancedFilters)
  };

  const handleReset = (EmptyFilters: any) => {
    setFilteredData(EmptyFilters);
  };

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "bold",
    padding: "16px",
  };

  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(
      firstDay.getMonth() + 1
    ).padStart(2, "0")}-${String(firstDay.getDate()).padStart(
      2,
      "0"
    )} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(
      2,
      "0"
    )}-${String(lastDay.getDate()).padStart(2, "0")} 23:59:59`;
  }

  const ExportWithoutSearch = async () => {
    // setExportLoading(true);
    const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
      return new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          reject(new Error("Request timed out"));
        }, timeout);

        promise
          .then((res) => {
            clearTimeout(timer);
            resolve(res);
          })
          .catch((err) => {
            clearTimeout(timer);
            reject(err);
          });
      });
    };
    try {
      // setExportLoading(true);
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/export_to_s3_bucket",
        role_name: role,
        parent_module: "Partner",
        module_name: "Usage Notification",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        feature_module_name: "Usage Notification",
        start_date: getFirstDayOfCurrentMonth(),
        end_date: getLastDayOfCurrentMonth(),
      };
      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000); // Timeout of 10 seconds
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }

      // Wait for 20 seconds before polling
      await new Promise((resolve) => setTimeout(resolve, 20000));
      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      // setExportLoading(false);
    }
  };

  const pollExportStatus = async () => {
    // Polling for the second API
  const export_url = ENV_ROUTES.MODULE_MANAGEMENT;
  const export_data = {
    tenant_name: partner || "default_value",
    username,
    path: "/get_export_status",
    role_name: role,
    parent_module: "Partner",
    module_name: "Usage Notification",
    request_received_at: getCurrentDateTime(),
    Partner: partner,
    access_token: token,
    db_name: selectedDb,
    ...metaData,
    sessionID: sessionId,
  };

    try {
      const export_response = await axios.post(export_url, {
        data: export_data,
      });
      const export_parsedData = JSON.parse(export_response.data.body);

      if (
        export_parsedData.flag &&
        export_parsedData?.export_status_data?.status_flag === "Success"
      ) {
        const s3Url = export_parsedData?.export_status_data?.url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
                          .then(response => response.blob())
                          .then(blob => {
                            const url = window.URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = 'Device Notifications.xlsx';
                            a.click();
                            a.remove();
                            window.URL.revokeObjectURL(url);
                            notification.success({
                              message: "Success",
                              description: "Successfully exported the record!",
                              style: messageStyle,
                              placement: "top",
                            });
                            fireSideCannons();
                          })
                        .catch((err) => {
                          console.log("error",err)
                          Modal.error({
                            title: "Export Error",
                            content: "An error occurred while exporting data. Please try again.",
                            centered: true,
                          });
                        });
        } else {
          Modal.error({
            title: "Export Error",
            content:
              export_parsedData.message ||
              "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
        return true; // Stop polling
      }

      if (
        export_parsedData?.export_status_data?.status_flag === "Failure"
      ) {
        Modal.error({
          title: "Export Error",
          content:
            export_parsedData.message ||
            "An error occurred while exporting data. Please try again.",
          centered: true,
        });
        return true; // Stop polling
      }
      if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
                Modal.info({
                  title: "Export Error",
                  content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
                  centered: true,
                });
                return true; // Stop polling
              }

      return false; // Continue polling
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred. Please try again.",
        centered: true,
      });
      return true; // Stop polling
    }
  };
  const startPolling = async () => {
    let isPollingComplete = false;

    while (!isPollingComplete) {
      isPollingComplete = await pollExportStatus();
      if (!isPollingComplete) {
        await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
      }
    }
  };

  const handleExport = async (key: string, heading: string) => {
    try {
      // setExportLoading(true);
      addExport(key, heading);
      let parsedData;
      let url;
      let data: any;
      let response;
      if(combineAdnvaceStoredpagination){
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          index_name: "rule_rule_defination",
          module_name: "Usage Notification",
        }
        console.log("combineAdnvaceStoredpagination",data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
      else if (advancedStoredpagination && !storedpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name: "rule_rule_defination",
          module_name: "Usage Notification",
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          tenant_id: tenantId,
          // }
        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } else if (storedpagination && !advancedStoredpagination){
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "rule_rule_defination",
          module_name: "Usage Notification",
          search: "whole",
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          tenant_id: tenantId,
        };
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      } else {
        await ExportWithoutSearch();
        return;
      }

      if (advancedStoredpagination || storedpagination || combineAdnvaceStoredpagination) {
        if (parsedData.flag === true) {
          const s3Url = parsedData?.download_url || null;
          if (s3Url) {
            // window.location.href = s3Url;
            // // setExportLoading(false);
            // notification.success({
            //   message: "Success",
            //   description: "Successfully exported the record!",
            //   style: messageStyle,
            //   placement: "top",
            // });
            fetch(s3Url)
                            .then(response => response.blob())
                            .then(blob => {
                              const url = window.URL.createObjectURL(blob);
                              const a = document.createElement('a');
                              a.href = url;
                              a.download = 'Device Notifications.xlsx';
                              a.click();
                              a.remove();
                              window.URL.revokeObjectURL(url);
                              notification.success({
                                message: "Success",
                                description: "Successfully exported the record!",
                                style: messageStyle,
                                placement: "top",
                              });
                              fireSideCannons();
                            })
                          .catch((err) => {
                            console.log("error",err)
                            Modal.error({
                              title: "Export Error",
                              content: "An error occurred while exporting data. Please try again.",
                              centered: true,
                            });
                          });
          } else {
            // setExportLoading(false);
            Modal.error({
              title: "Export Error",
              content:
                parsedData.message ||
                "An error occurred while exporting data. Please try again.",
              centered: true,
            });
          }

      // if (parsedData.flag) {
      //   const s3Url = parsedData?.download_url || null;
      //   if (s3Url) {
      //     window.location.href = s3Url;
      //     notification.success({
      //       message: "Success",
      //       description: "Successfully Exported the Record!",
      //       style: messageStyle,
      //       placement: "top",
      //     });
        
      //   } else {
      //     // setExportLoading(false);
      //     Modal.error({
      //       title: "Export Error",
      //       content:
      //         parsedData.message ||
      //         "An error occurred while exporting data. Please try again.",
      //       centered: true,
      //     });
        }
      }

      
    } catch (error) {
      console.log("catch")
      await startPolling()
      // Modal.error({
      //   title: "Export Error",
      //   content:
      //     error instanceof Error
      //       ? error.message
      //       : "An unexpected error occurred while fetching data. Please try again.",
      //   centered: true,
      // });
    } finally {
      // setExportLoading(false)
      removeExport(key);
    }
  };

  const handleAddNotificationClick = () => {
    setAddNotifications(true);
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  return (
    <Suspense
      fallback={
        <div className="flex justify-center items-center h-screen">
          <Spin size="large" />
        </div>
      }
    >
      <div className="relative">
      <div className="pr-4 pl-4  pt-2 flex md:flex-row md:items-center md:justify-between mt-1 mb-4 space-y-4">
          {/* Search and Advanced Filter Container */}
          <div className="flex  space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last ">
            {features.includes("Search-Notification") && (
              <TableSearch
                searchTerm={searchTerm}
                setSearchTerm={setSearchTerm}
                tableName={"rule_rule_defination"}
                headerMap={headerMap}
              />
            )}
            {features.includes("Advance-Search-Notification") && (
          <AdvancedMultiFilter
            showAdvanced={showAdvanced}
            setShowAdvanced={setShowAdvanced}
            onFilter={handleFilter}
            onReset={handleReset}
            headers={headers}
            headerMap={headerMap}
            tableName={"rule_rule_defination"}
          />
          )}
          </div>

           
           {/* Export and ColumnFilter Container */}
           <div className="hidden md:flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2  md:order-none order-first pb-2 md:pb-4">
            {features.includes("Create-Notification") && (
              <button
                className="save-btn text-black-500"
                onClick={handleAddNotificationClick}
              >
                <PlusIcon className="h-5 w-5 text-black-500 mr-1 " />
                Add Notification
              </button>
            )}
            {/* {features.includes("Upload-Email Templates") && ( */}
            <button className="save-btn"
            onClick={() => {
              if (!exports.some((exportItem) => exportItem.popupHeading === "Device Notifications")) {
                handleExport("DeviceNotifications", "Device Notifications");
              }
            }}>
              <DownloadOutlined className="h-5 w-5 text-black-500 mr-2" />
              <span>Export</span>
            </button>
            {/* )} */}
            <div className="flex space-x-2">
              <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
              />
            </div>
          </div>
        </div>
        <div className=" mb-4 space-x-2"></div>

        <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
          <TableComponent
            headers={headers}
            initialData={data}
            searchQuery={searchTerm}
            visibleColumns={visibleColumns}
            itemsPerPage={100}
            allowedActions={allowedActions}
            popupHeading="Device notifications"
            pagination={pagination}
            headerMap={headerMap}
            advancedFilters={filteredData}
            height = {showAdvanced?360:300}
          />
        </div>
         {/* Sticky Footer for Small Screens */}
       <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
       {features.includes("Create-Notification") && (
              <button
                className="save-btn text-black-500"
                onClick={handleAddNotificationClick}
              >
                <PlusIcon className="h-5 w-5 text-black-500" />
              </button>
            )}
            {/* {features.includes("Upload-Email Templates") && ( */}
            <button className="save-btn"
            onClick={() => {
              if (!exports.some((exportItem) => exportItem.popupHeading === "Device Notifications")) {
                handleExport("DeviceNotifications", "Device Notifications");
              }
            }}>
              <DownloadOutlined className="h-5 w-5 text-black-500" />
            </button>
            {/* )} */}
             <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
            />                                      
        </div>   

        <AddNotificationsModal
          isVisible={isAddNotifications}
          onClose={() => {setAddNotifications(false);
            // fetchData();
          }}
          executionOrder={executionOrderField}
        />
        {/* {exportLoading && (
            <div className="export-processing-div">
              Export Processing...
            </div>
        )} */}
      </div>
    </Suspense>
  );
};

export default DeviceNotifications;
