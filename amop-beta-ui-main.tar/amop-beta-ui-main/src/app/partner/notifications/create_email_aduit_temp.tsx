import React, { useCallback, useEffect, useState } from "react";
import {
  Upload,
  message,
  Modal,
  Button,
  Input,
  Row,
  Col,
  Form,
  Tag,
  notification,
  Select,
  Table,
  Spin,
  InputNumber,
} from "antd";
import {
  ChevronDownIcon,
  PaperClipIcon,
  PlusIcon,
} from "@heroicons/react/24/outline";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { fireSideCannons } from "@/app/components/confetti";

interface SubChild {
  sub_child_module_name: string | null;
  template_names: string | null;
  sub_children: any;
  table_column_mapping: any;
}

interface ChildModule {
  child_module_name: string;
  table_column_mapping: any;
  template_names: any;
  sub_children: any;
}
interface InitialValues {
  email_type?: string;
  template_name?: string;
  partner_name?: string;
  to_mail?: string;
  cc_mail?: string;
  subject?: string;
  body?: string;
  role_based?: string;
  module?: string;
  parents_module_name?: string;
  sub_module_name?: string;
  child_module_name?: string;
  template_type?: string;
  email_frequency?: string;
}


interface ParentModule {
  parent_module_name: string;
  children: ChildModule[];
}

interface TemplateData {
  template_names: string[];
}

const CreateEmailAuditTemplateModal: React.FC<{
  visible: boolean;
  onClose: () => void;
  rowData: any;
  isOpen: boolean;
  action: string;
  onsave?:any;
}> = ({ visible, onClose, rowData, action ,onsave}) => {
  const [form] = Form.useForm();
  const [isLoading, setIsLoading] = useState(false);
  const [uploadKey, setUploadKey] = useState(Date.now());
  const [isFileSelected, setIsFileSelected] = useState(false);
  const [toEmailInput, setToEmailInput] = useState("");
  const [toEmailList, setToEmailList] = useState<string[]>([]);
  const [ccEmailInput, setCcEmailInput] = useState("");
  const [ccEmailList, setCcEmailList] = useState<string[]>([]);
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const [roleOptions, setRoleOptions] = useState<any[]>([]);
  const [partnerOptions, setPartnerOptions] = useState<any[]>([]);
  const [emailTemplateMapping, setEmailTemplateMapping] = useState<any>({});
  const [parentModOptions, setParentModOptions] = useState<string[]>([]);
  const [childModOptions, setChildModOptions] = useState<string[]>([]);
  const [subModOptions, setSubModOptions] = useState<string[]>([]);
  const [templateOptions, setTemplateOptions] = useState<string[]>([]);
  const [placeholderOptions, setPlaceHolderOptions] = useState<string[]>([]);
  const [modulesMapping, setModulesMapping] = useState<ParentModule[]>([]);
  const [selectedParentModule, setSelectedParentModule] = useState<
    string | null
  >(null);
  const [selectedChildModule, setSelectedChildModule] = useState<string | null>(
    null
  );
  const [selectedSubModule, setSelectedSubModule] = useState<string | null>(
    null
  );
  const [selectedTemplateType, setSelectedTemplateType] = useState<
    string | null
  >(null);
  const [selectedPlaceholder, setSelectedPlaceholder] = useState<string | null>(
    null
  );
  const [selectedPlaceholdersList, setSelectedPlaceholdersList] = useState<
    string[]
  >([]);
  const [uploadedFileData, setUploadedFileData] = useState({
    blobData: null,
    filename: "",
  });
  const [selectedPartnerName, setSelectedPartnerName] = useState<string | null>(
    null
  );

  const {
    username,
    tenantNames,
    role,
    settabledata,
    setStoredPagination,
    token,
    partner,
    selectedDb,
    metaData,
    sessionId,
  } = useAuth();

  // Form input states
  const [emailType, setEmailType] = useState("");
  const [templateName, setTemplateName] = useState("");
  const [roleBased, setRoleBased] = useState("");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [parentModule, setParentModule] = useState("");
  const [subModule, setSubModule] = useState("");
  const [childModule, setChildModule] = useState("");
  const [templates, setTemplates] = useState("");
  const [emailFrequency, setEmailFrequency] = useState("");
  const [toMailDisabled, setToMailDisabled] = useState(false);
  const [initialValues, setInitialValues] = useState<InitialValues>({});

  const [isShowTable, setIsShowTable] = useState(false);
  const [tableNames, setTableNames] = useState<string[]>([]);
  const [tableKeys, setTableKeys] = useState<string[]>([]);
  const [selectedTable, setSelectedTable] = useState(null);
  const [selectedColumns, setSelectedColumns] = useState([]);
  const [tableData, setTableData] = useState([]);
  const [templateType, setTemplateType] = useState<string | null>(null);
  const [isReportDropdownVisible, setIsReportDropdownVisible] = useState(false);
  const [selectedReport, setSelectedReport] = useState<string | null>(null);
  const [isConfirmationVisible, setIsConfirmationVisible] = useState(false);
  const [selectedFrequency, setSelectedFrequency] = useState(null);
  const [cycleDay, setCycleDay] = useState(null);
  const messageStyle = {
    fontSize: "14px",
    fontWeight: "normal",
    padding: "16px",
  };
  const fetchData = async () => {
    try {
      setIsLoading(true)
      const url = ENV_ROUTES.NOTIFICATION_SERVICES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        path: "/email_template_list_view",
        role_name: role,
        parent_module: "Partner",
        module_name: "notification services",
        feature_module_name:"Partner",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };
      console.log(getCurrentDateTime(),"Show the log time request sent from ui to lambda");
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      console.log(getCurrentDateTime(),"Show the log time response sent from lambda to ui");
      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching Inventory data. Please try again.",
          centered: true,
        });
      } else {
        const tableData_ = parsedData?.data || [];
        const modulesMapping_ =
          parsedData.email_template_table_mapping_dict.Modules_mapping;
        setEmailTemplateMapping(parsedData.email_template_table_mapping_dict);
        const parentModuleNames = modulesMapping_.map(
          (module: any) => module.parent_module_name
        );

        const displayNamesForParentModule = extractDisplayNamesForParentModule(
        selectedParentModule,
        modulesMapping_
      );

      setPlaceHolderOptions(displayNamesForParentModule);

        const displayNames = extractDisplayNamesForChildModule(
          selectedParentModule,
          selectedChildModule,
          modulesMapping_
        );

        const displayNamesForSubModule = extractDisplayNamesForSubModule(
          selectedSubModule,
          modulesMapping_
        );
        setPlaceHolderOptions(displayNamesForSubModule);
        const sortedPlaceholderOptions = displayNames.sort();
        setPlaceHolderOptions(sortedPlaceholderOptions);
        setTableNames(displayNames);
        // settabledata(tableData_);
        const sortedRoleOptions = (parsedData.role_list || []).sort();
        const sortedPartnerOptions = (parsedData.partners || []).sort();
        setRoleOptions(sortedRoleOptions);
        setPartnerOptions(sortedPartnerOptions);
        setParentModOptions(parentModuleNames);
        setModulesMapping(modulesMapping_);
        if(rowData){
          let displayNames;
          
          if(rowData?.parents_module_name){
            setSelectedParentModule(rowData?.parents_module_name)
            displayNames = extractDisplayNamesForParentModule(
              rowData?.parents_module_name,
              modulesMapping_
            );
          }
          if(rowData?.child_module_name){
            displayNames = extractDisplayNamesForChildModule(
              rowData?.parents_module_name,
              rowData?.child_module_name,
              modulesMapping_
            );
          }
          if(rowData?.sub_child_module_name){
            displayNames = extractDisplayNamesForSubModule(
              rowData?.sub_child_module_name,
              modulesMapping_
            );
          }
          
          setPlaceHolderOptions(displayNames);
          const body_=convertBody(rowData?.body,rowData?.child_module_name,rowData?.sub_module_name,modulesMapping_,displayNames)
          setBody(body_);
          setRowDataValues(rowData,modulesMapping_)
        }
  
      }
    } catch (error) {
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setIsLoading(false);
    }
  };

  //To convert from dictionary format to string format
  const convertBody=(
    body: string,
    selectedChildModule: any,
    selectedSubModule: any,
    modulesMapping_: any,
    PlaceholderOptionsptions:string[])=>{
      let formattedPayload = body;
      
      PlaceholderOptionsptions?.forEach((option) => {
        // Extract table and column info for the current placeholder option
        const tableInfo = extractTableNames(
          selectedChildModule,
          selectedSubModule,
          modulesMapping_,
          option
        );

        if (tableInfo) {
          const tableKey = tableInfo.table;
          const columnName = tableInfo.column;
          const displayName = tableInfo.display_name;
    
          // Construct the JSON-like placeholder to search for
          const placeholder = `{"${tableKey}":"${columnName}"}`;

          // Check if the body contains this placeholder and replace it with the display_name
      const regex = new RegExp(escapeRegExp(placeholder), "g");
      formattedPayload = formattedPayload.replace(regex, displayName);
    }
  });
  return formattedPayload;
}

const setRowDataValues=(rowData:any,modulesMapping_:any)=>{
  form.setFieldsValue({
    emailType: rowData?.email_type,
    templateName: rowData?.template_name,
    partnerName: rowData?.partner_name,
    toMail: rowData?.to_mail,
    ccMail: rowData?.cc_mail,
    subject: rowData?.subject,
    body: rowData?.body,
    roleBased: rowData?.role_based,
    module: rowData?.module_name,
    actionPerformed: rowData?.action_performed,
    parentModule: rowData?.parents_module_name,
    subModule: rowData?.child_module_name,
    childModule: rowData?.sub_module_name,
    template_type: rowData?.template_type,
    frequency: rowData?.email_frequency,
  });
  setTemplateName(rowData?.template_name)
  setRoleBased(rowData?.role_based);
  setToEmailInput(rowData?.to_mail || "");
  setCcEmailInput(rowData?.cc_mail || "");
  setSubject(rowData?.subject || "");
  setParentModule(rowData?.parents_module_name || "");
  setSelectedParentModule(rowData?.parents_module_name || "")
  setSelectedChildModule(rowData?.sub_child_module_name || "")
  setSelectedSubModule(rowData?.child_module_name || "" )
  setSubModule(rowData?.child_module_name || "");
  setChildModule(rowData?.sub_module_name || "");
  setTemplates(rowData?.template_names || "");
  setTemplateType(rowData?.template_type || "");
  setEmailFrequency(rowData?.email_frequency || "");
  setEmailType(rowData?.email_type || "")

  const parentModule = modulesMapping_.find(
    (module:any) => module.parent_module_name === rowData?.parents_module_name
  );

  if (parentModule) {
    if (parentModule.children) {
      const childModuleNames: any = parentModule.children
        .map((child:any) => child.child_module_name)
        .filter(Boolean)
        .sort();
      setChildModOptions(childModuleNames);

      if (
        rowData?.child_module_name &&
        childModuleNames.includes(rowData?.child_module_name)
      ) {
        form.setFieldsValue({
          childModule: rowData?.sub_child_module_name,
        });
        const parentModule = modulesMapping.find(
          (module) => module.parent_module_name === selectedParentModule
        );
    
        if (parentModule) {
          const child = parentModule.children.find(
            (child) => child.child_module_name === rowData?.child_module_name
          );
    
          if (child && child.sub_children) {
            const subModuleNames: any = child.sub_children
              .map((subChild: any) => subChild.sub_child_module_name)
              .filter(Boolean)
              .sort();
            setSubModOptions(subModuleNames);
    
            const templateNames: string[] = Array.from(
              new Set(
                child.sub_children
                  .flatMap((subChild: any) => subChild.template_names || [])
                  .filter(Boolean)
                  .map((name: string) => name.replace(/[[\]"']/g, "").trim())
                  .sort()
              )
            );
    
            setTemplateOptions(templateNames);
          }
        }
        // handleChildChange(rowData?.child_module_name);
      }
    }
    const templateNames:any= Array.from(
      new Set(
        parentModule.children
          .flatMap((child:any) =>
            child.sub_children
              ? child.sub_children.flatMap(
                  (subChild: any) => subChild.template_names || []
                )
              : []
          )
          .filter(Boolean)
          .map((name: string) => name.replace(/[[\]"']/g, "").trim())
      )
    ).sort();

    // Set template options based on the parent module
    setTemplateOptions(templateNames);
  }
}
  useEffect(() => {
    if(visible){
      fetchData();
    }
  }, [visible]);

  const resetForm = () => {
    setEmailType("");
    setTemplateName("");
    setRoleBased("");
    setToEmailList([]);
    setCcEmailList([]);
    setToEmailInput("");
    setCcEmailInput("");
    setSubject("");
    setBody("");
    setIsFileSelected(false);
    setUploadKey(Date.now());
    form.resetFields();
    setSelectedParentModule(null);
    setSelectedChildModule(null);
    setSelectedSubModule(null);
    setSelectedTemplateType(null);
    setSelectedPartnerName(null);
    setChildModOptions([]);
    setSubModOptions([]);
    setTemplateOptions([]);
    setSelectedColumns([]);
    setIsShowTable(false);
    setPlaceHolderOptions([]);
    setSelectedPlaceholder(null);
    setIsReportDropdownVisible(false);
    setSelectedFrequency(null);
  };

  const extractDisplayNamesForParentModule = (
    selectedParentModule: any,
    modulesMapping: any
  ) => {
    const displayData: any = [];
  
    modulesMapping.forEach((module: any) => {
      if (module.parent_module_name === selectedParentModule) {
        module.children.forEach((child: any) => {
          child.sub_children.forEach((subChild: any) => {
            if (subChild.table_column_mapping) {
              const tableColumnMappings = JSON.parse(
                subChild.table_column_mapping
              );
  
              Object.keys(tableColumnMappings).forEach((key) => {
                const mappingArray = tableColumnMappings[key];
                if (Array.isArray(mappingArray)) {
                  mappingArray.forEach((column: any) => {
                    if (column.displayName) {
                      displayData.push(column.displayName);
                    }
                  });
                }
              });
            }
          });
        });
      }
    });
  
    return displayData.sort((a: string, b: string) => a.localeCompare(b));
  };

  const extractDisplayNamesForChildModule = (
    selectedParentModule:any,
    selectedChildModule: any,
    modulesMapping: any
  ) => {
    const displayData: any = [];
    const displayDataMap: any = [];
  
    modulesMapping.forEach((module: any) => {
      if (module.parent_module_name === selectedParentModule) { // Check if the parent module matches
        module.children.forEach((child: any) => {
          if (child.child_module_name === selectedChildModule) {
            child.sub_children.forEach((subChild: any) => {
              if (subChild.table_column_mapping) {
                const tableColumnMappings = JSON.parse(
                  subChild.table_column_mapping
                );
  
                // Iterate over all keys in the tableColumnMappings object
                Object.keys(tableColumnMappings).forEach((key) => {
                  const mappingArray = tableColumnMappings[key];
                  if (Array.isArray(mappingArray)) {
                    // Store the key and corresponding displayNames
                    mappingArray.forEach((column: any) => {
                      if (column.displayName && column.columnName) {
                        displayDataMap.push({
                          tableKey: key,
                          displayName: column.displayName,
                          columnName: column.columnName,
                        });
                        displayData.push(
                          column.displayName // The displayName value
                        );
                      }
                    });
                  }
                });
              }
            });
          }
        });
      }
    });
  
    displayData.sort((a: string, b: string) => a.localeCompare(b));
    return displayData; 
  };
   

  const extractTableNames = (
    selectedChildModule: any,
    selectedSubModule: any,
    modulesMapping_: any,
    option: string,
  ) => {
    const selectedParentModule_=rowData?rowData?.parents_module_name:selectedParentModule

    const displayDataMap: any = {};
    modulesMapping_.forEach((module: any) => {
      module.children.forEach((child: any) => {
        if (child.child_module_name === selectedChildModule && module.parent_module_name === selectedParentModule_) {
          // If sub-module is selected, iterate through sub-children

          let tableMapping = child.sub_children[0]?.table_column_mapping
          if (typeof tableMapping === 'string') {
            const tableMapping_ = JSON.parse(tableMapping)
            tableMapping = tableMapping_

          }
          const tableKeys = Object.keys(tableMapping)
          let selected_table = tableKeys[0]
          let selected_column;
          let selected_display_name;
          tableMapping[selected_table].forEach((columnMap: any) => {
            if (columnMap.displayName === option) {
              selected_column = columnMap.columnName
              selected_display_name = columnMap.displayName

            }
          })
          displayDataMap["column"] = selected_column
          displayDataMap["table"] = selected_table
          displayDataMap["display_name"] = selected_display_name

        }
      });
    });
    return displayDataMap; // Return array of objects with tableKey and displayName
  };


  const extractDisplayNamesForSubModule = (
    selectedSubModule: any,
    modulesMapping: any
  ) => {
    const displayData: any = [];

    modulesMapping.forEach((module: any) => {
      module.children.forEach((child: any) => {
        child.sub_children.forEach((subChild: any) => {
          if (
            subChild.sub_child_module_name === selectedSubModule &&
            subChild.table_column_mapping
          ) {
            const tableColumnMappings = JSON.parse(
              subChild.table_column_mapping
            );

            // Iterate over all keys in the tableColumnMappings object
            Object.keys(tableColumnMappings).forEach((key) => {
              const mappingArray = tableColumnMappings[key];
              if (Array.isArray(mappingArray)) {
                mappingArray.forEach((column: any) => {
                  if (column.displayName) {
                    displayData.push(column.displayName); // Store the displayName value
                  }
                });
              }
            });
          }
        });
      });
    });

    return displayData.sort((a: string, b: string) => a.localeCompare(b)); // Return sorted display names
  };

  const handleParentChange = (value: any) => {
    setSelectedParentModule(value);
    setSelectedChildModule(null);
    setSelectedSubModule(null);
    setSelectedTemplateType(null);
    setChildModOptions([]);
    setSubModOptions([]);
    setTemplateOptions([]);

    form.setFieldsValue({
      subModule: undefined,
      childModule: undefined,
      templates: undefined,
    });

    if (value === "User authentication") {
      setToMailDisabled(true);
    } else {
      setToMailDisabled(false);
    }

    const parentModule = modulesMapping.find(
      (module) => module.parent_module_name === value
    );

    if (parentModule) {
      // Get child module names
      if (parentModule.children) {
        const childModuleNames: any = parentModule.children
          .map((child) => child.child_module_name)
          .filter(Boolean)
          .sort();
        setChildModOptions(childModuleNames);
      }

      // Get unique template names from the parent module (if applicable)
      const templateNames: string[] = Array.from(
        new Set(
          parentModule.children
            .flatMap((child) =>
              child.sub_children
                ? child.sub_children.flatMap(
                    (subChild: any) => subChild.template_names || []
                  )
                : []
            )
            .filter(Boolean)
            .map((name: string) => name.replace(/[[\]"']/g, "").trim())
        )
      ).sort();

      // Set template options based on the parent module
      setTemplateOptions(templateNames);
      const displayNames = extractDisplayNamesForParentModule(
        value,
        modulesMapping
      );
      setPlaceHolderOptions(displayNames);
    }
  };

  const handleChildChange = (value: any) => {
    setSelectedChildModule(value);
    setSelectedSubModule(null);
    setSelectedTemplateType(null);
    setSubModOptions([]);
    setTemplateOptions([]);
    setTemplateName("");
    let formattedPayload = body;
    placeholderOptions.sort((a, b) => b.length - a.length);
    placeholderOptions.forEach((option) => {
      // Escape the option for regex and allow for flexible spacing around it
      const escapedOption = escapeRegExp(option.trim());
      const regex = new RegExp(`\\b${escapedOption}\\b`, "gi"); // \b ensures whole word matching
      formattedPayload = formattedPayload.replace(regex,"");
    });

    setBody(formattedPayload)

    form.setFieldsValue({
      childModule: undefined,
      templates: undefined,
    });

    const parentModule = modulesMapping.find(
      (module) => module.parent_module_name === selectedParentModule
    );

    if (parentModule) {
      const child = parentModule.children.find(
        (child) => child.child_module_name === value
      );

      if (child && child.sub_children) {
        const subModuleNames: any = child.sub_children
          .map((subChild: any) => subChild.sub_child_module_name)
          .filter(Boolean)
          .sort();
        setSubModOptions(subModuleNames);

        const templateNames: string[] = Array.from(
          new Set(
            child.sub_children
              .flatMap((subChild: any) => subChild.template_names || [])
              .filter(Boolean)
              .map((name: string) => name.replace(/[[\]"']/g, "").trim())
              .sort()
          )
        );

        setTemplateOptions(templateNames);

        const displayNames = extractDisplayNamesForChildModule(
          selectedParentModule,
          value,
          modulesMapping
        );
        setPlaceHolderOptions(displayNames);
      }
    }
  };

  // Handle changes in sub-module dropdown
  const handleSubModuleChange = (value: any) => {
    setSelectedSubModule(value);
    form.setFieldsValue({
      templates: undefined,
    });
    const displayNames = extractDisplayNamesForSubModule(value, modulesMapping);
    setPlaceHolderOptions(displayNames);
  };

  const handleAddTableClick = () => {
    setIsShowTable(true);
  };

  const handleSelectPlaceholder = (value: any) => {
      
    setBody((prevBody) => `${prevBody} ${value} `);

    setSelectedPlaceholdersList((prev) => [...prev, value]);
  };

  const handleTemplateTypeChange = (value: string) => {
    setTemplateType(value);
    if (
      value === "Reports Template" ||
      ((action === "edit" || action === "copy") &&
        rowData?.template_type === "Reports Template")
    ) {
      setIsReportDropdownVisible(true);
      setBody("");
      setSelectedReport(null);
    } else {
      setIsReportDropdownVisible(false);
      // setBody("");
      setSelectedReport(null);
    }
  };

  const handleFrequencyChange = (value: any) => {
    setSelectedFrequency(value);
  };

  const handleCycleDayChange = (value: any) => {
    setCycleDay(value);
  };

  const handleBody = (value: any) => {
    setBody(value);
  };

  const getHighlightedText = (text: string | null, highlights: string[]) => {
    if (!text) {
      return "";
    }
    // Create a regex pattern that matches only the exact case
    const regex = new RegExp(`\\b(${highlights.map(escapeRegExp).join("|")})\\b`, "g");
    return text.replace(
      regex,
      (match) => `<span style="background-color: yellow;">${match}</span>`
    );
  };
  
  
 
 
  const escapeRegExp = (string: string) => {
    return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); // Escape special characters
  };
  const replacePlaceholders = (body: string, placeholderOptions: string[]) => {
    let formattedPayload = body;
    placeholderOptions.sort((a, b) => b.length - a.length);
  
    placeholderOptions.forEach((option) => {
      // Escape the option for regex and allow for flexible spacing around it
      const escapedOption = escapeRegExp(option.trim());
      
      // Regex that matches the exact placeholder (case-insensitive)
      const regex = new RegExp(`\\b${escapedOption}\\b`, "gi"); // \b ensures whole word matching
  
      // Find the corresponding table and column name
      const selectedChildModule_ = rowData ? rowData?.child_module_name : selectedChildModule;
      const tableInfo = extractTableNames(selectedChildModule_, selectedSubModule, modulesMapping, option);
  
      // Perform replacement only if the matched text is exactly the same as the placeholder
      if (tableInfo) {
        const tableKey = tableInfo.table;
        const columnName = tableInfo.column;
        
        // Create a function to check the match case
        formattedPayload = formattedPayload.replace(regex, (match) => {
          // Check if the match is exactly the same as the option (case-sensitive)
          if (match === option) {
            return `{"${tableKey}":"${columnName}"}`;
          }
          // Return the original match if it does not match the case
          return match;
        });
      }
    });
  
    return formattedPayload;
  };
  

  
  const createSave = async () => {
    const formattedPayload_ = replacePlaceholders(body, placeholderOptions)

    // Log the final formatted payload for debugging

    await form.validateFields();
    setIsLoading(true);
    const url = ENV_ROUTES.NOTIFICATION_SERVICES;
    const toEmailString = toEmailList.join(", ");
    const ccEmailString = ccEmailList.join(", ");

    const formData = {
      parents_module_name: selectedParentModule,
      sub_module_name: selectedSubModule,
      child_module_name: selectedChildModule,
      template_type: templateType || null,
      email_type: emailType,
      template_name: templateName,
      partner_name: selectedPartnerName,
      role_based: roleBased,
      email_frequency:
        selectedFrequency === "Cycle"
          ? `Custom date(${cycleDay})`
          : selectedFrequency,
      to_mail: toEmailString,
      cc_mail: ccEmailString,
      subject,
      body: formattedPayload_,
      reports_name: `${selectedReport} Export`,
      created_by: username,
      modified_by: username,
    };

    const data = {
      tenant_name: partner || "default_value",
      username: username,
      path: "/submit_update_copy_status_email_template",
      role_based: role,
      parent_module: "Partner",
      module: "Notifications",
      partner: partner,
      action: "create",
      table_name: "email_templates",
      new_data: formData,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
    };

    try {
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        if (parsedData.error_type && parsedData.error_type == "Warning") {
          console.log("parsedData.error_type", parsedData.error_type)
          Modal.warning({
            title: 'Warning',
            content: parsedData.message || 'An error occurred while submitting data. Please try again.',
            centered: true,
          });
        }
        else {
          Modal.error({
            title: "Submit Error",
            content:
              parsedData.message ||
              "An error occurred while submitting data. Please try again.",
            centered: true,
          });
        }
      } else {
        notification.success({
          message: "Success",
          description: "Data submitted successfully!",
          style: messageStyle,
          placement: "top",
        });
        fireSideCannons();
        onsave()
      }
      onClose();
      resetForm();
    } catch (error) {
      Modal.error({
        title: "Error",
        content: "There was an error submitting the data.",
      });
    } finally {
      setIsLoading(false);
    }
  };
  const editSave = async () => {
    let displayNames
    if(rowData){
      displayNames = extractDisplayNamesForParentModule(
        rowData?.parents_module_name,
        modulesMapping
      );
      setPlaceHolderOptions(displayNames);
    }
    const formattedPayload_ = replacePlaceholders(body, displayNames)
    await form.validateFields();
    setIsLoading(true);
    const url = ENV_ROUTES.NOTIFICATION_SERVICES;
    const toEmailString = toEmailList.join(", ");
    const ccEmailString = ccEmailList.join(", ");
    
    const changedData = {
      parents_module_name: selectedParentModule,
      sub_module_name: selectedSubModule,
      child_module_name: selectedChildModule,
      template_type: templateType || null,
      email_type: emailType,
      template_name: templateName,
      partner_name: selectedPartnerName,
      role_based: roleBased,
      email_frequency:
        selectedFrequency === "Cycle"
          ? `Custom date(${cycleDay})`
          : selectedFrequency,
      to_mail: toEmailString,
      cc_mail: ccEmailString,
      subject,
      body: formattedPayload_,
      reports_name: `${selectedReport} Export`,
      created_by: username,
      modified_by: username,
    };
    const data = {
      tenant_name: partner || "default_value",
      username: username,
      path: "/submit_update_copy_status_email_template",
      role_name: role,
      parent_module: "Partner",
      module: "Notifications",
      partner: partner,
      action: "update",
      table_name: "email_templates",
      changed_data: {
        id: rowData.id,
        ...changedData
      },
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
    };

    try {
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        if (parsedData.error_type && parsedData.error_type == "Warning") {
          console.log("parsedData.error_type", parsedData.error_type)
          Modal.warning({
            title: 'Warning',
            content: parsedData.message || 'An error occurred while submitting data. Please try again.',
            centered: true,
          });
        }
        else {
          Modal.error({
            title: "Submit Error",
            content:
              parsedData.message ||
              "An error occurred while submitting data. Please try again.",
            centered: true,
          });
        }
      } else {
        notification.success({
          message: "Success",
          description: "Data submitted successfully!",
          style: messageStyle,
          placement: "top",
        });
        fireSideCannons();
        // fetchData();
        onsave()
      }
      onClose();
      resetForm();
    } catch (error) {
      notification.error({
        message: "Error",
        description: "There was an error submitting the data.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const copySave = async () => {
    const formattedPayload_ = replacePlaceholders(body, placeholderOptions)
    placeholderOptions.sort((a, b) => b.length - a.length);
    let formattedPayload = body;

    const findTableName = (option: any) => {
      const foundOption: any = tableKeys.find((entry: any) => entry.displayName.toLowerCase() === option.toLowerCase());
      return foundOption ? { tableKey: foundOption.tableKey, columnName: foundOption.columnName } : null;
    };

    // Validation: Check if the template name has been changed
    if (action === "copy" && rowData?.template_name === templateName) {
      Modal.error({
        title: "Validation Error",
        content: "You must change the Template name before saving.",
      });
      return; 
    }
    await form.validateFields();
    setIsLoading(true);
    const url = ENV_ROUTES.NOTIFICATION_SERVICES;
 
    const currentValues = form.getFieldsValue() as InitialValues;
    const keyMapping: { [key: string]: string } = {
      templateName: "template_name",
      roleBased: "role_based",
      frequency: "email_frequency",
      emailType: "email_type",
      partnerName: "partner_name",
      parentModule: "parents_module_name",
      subModule:"sub_module_name",
      childModule: "child_module_name",
      template_type: "template_type",
      toMail:"to_mail",
      ccMail:"cc_mail",
      body: "body",
      reports_name: rowData?.reports_name ? `${selectedReport} Export` : "",
      subject: "subject"
    };
    const changedData: { [key: string]: any } = {};
  
    Object.keys(currentValues).forEach((key) => {
      const typedKey = key as keyof InitialValues;
      
      if (
        currentValues[typedKey] !== initialValues[typedKey] &&
        currentValues[typedKey]?.trim() !== initialValues[typedKey]?.trim()
      ) {
        const apiKey = keyMapping[key] || key; 
        changedData[apiKey] = currentValues[typedKey];
      }
    });
    const data = {
      tenant_name: partner || "default_value",
      username: username,
      path: "/submit_update_copy_status_email_template",
      role_name: role,
      parent_module: "Partner",
      module: "Notifications",
      partner: partner,
      action: "copy",
      table_name: "email_templates",
      copy_data: {
        created_by: username,
        modified_by: username,
        ...changedData
      },
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
    };

    try {
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        if (parsedData.error_type && parsedData.error_type == "Warning") {
          console.log("parsedData.error_type", parsedData.error_type)
          Modal.warning({
            title: 'Warning',
            content: parsedData.message || 'An error occurred while submitting data. Please try again.',
            centered: true,
          });
        }
        else {
          Modal.error({
            title: "Submit Error",
            content:
              parsedData.message ||
              "An error occurred while submitting data. Please try again.",
            centered: true,
          });
        }
      } else {
        notification.success({
          message: "Success",
          description: "Data submitted successfully!",
          style: messageStyle,
          placement: "top",
        });
        fireSideCannons();
        // fetchData();
        onsave()
      }
      onClose();
      resetForm();
    } catch (error) {
      notification.error({
        message: "Error",
        description: "There was an error submitting the data.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSave = async () => {
    const { blobData, filename } = uploadedFileData;

    if (emailType === "AWS") {
      setIsConfirmationVisible(true); // Show the confirmation modal
      
    } else {
      handleConfirm();
    }
  };

  const handleConfirm = () => {
    if (action === "create") {
      createSave();
    } else if (action === "edit") {
      editSave();
    } else if (action === "copy") {
      copySave();
    }
  };

  const validateEmail = (email: string) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleEmailKeyPress = (
    event: React.KeyboardEvent<HTMLInputElement>,
    type: "to" | "cc"
  ) => {
    if (event.key === "Enter") {
      event.preventDefault();

      const inputValue = type === "to" ? toEmailInput : ccEmailInput;

      if (inputValue.trim() === "") return; // If no input, do nothing

      const emailArray = inputValue
        .split(/[\s,]+/)
        .filter((email) => email !== "");

      const validEmails: string[] = [];
      emailArray.forEach((email) => {
        if (validateEmail(email)) {
          validEmails.push(email);
        } else {
          message.error(`${email} is an invalid email address`);
        }
      });

      if (validEmails.length > 0) {
        if (type === "to") {
          setToEmailList([...toEmailList, ...validEmails]);
          setToEmailInput(inputValue); // Keep the input value
        } else if (type === "cc") {
          setCcEmailList([...ccEmailList, ...validEmails]);
          setCcEmailInput(inputValue); // Keep the input value
        }
      }
    }
  };

  const handleEmailBlur = (type: "to" | "cc") => {
    const inputValue = type === "to" ? toEmailInput : ccEmailInput;
    if (inputValue.trim() === "") return;
    const emailArray = inputValue
      .split(/[\s,]+/)
      .filter((email) => email !== "");
    const validEmails: string[] = [];
    emailArray.forEach((email) => {
      if (validateEmail(email)) {
        validEmails.push(email);
      } else {
        message.error(`${email} is an invalid email address`);
      }
    });
    if (validEmails.length > 0) {
      if (type === "to") {
        setToEmailList([...toEmailList, ...validEmails]);
      } else if (type === "cc") {
        setCcEmailList([...ccEmailList, ...validEmails]);
      }
    }
  };

  const renderLabel = (label: string, required: boolean) => (
    <span className="field-label">
      {label}{" "}
      {required && (
        <span className="required-indicator" style={{ color: "red" }}>
          *
        </span>
      )}
    </span>
  );

  const reportOptions = [
    "Customer Rate Pool Usage Report",
    "Newly Activated Report",
    "Pool Group Summary Report",
    "Status History Report",
    "Usage By Line Report",
    "Zero Usage Report",
  ];

  const modalHeight =
  typeof window !== "undefined" ? (window.innerHeight * 2.7) / 4 : 0;

  // if (isLoading) {
  //   return (
  //     <div className="flex justify-center items-center h-screen">
  //       <Spin size="large" />
  //     </div>
  //   );
  // }

//   return (
//     <>
//       <Modal
//         title={
//           <div className="mt-[-10px]">
//             <span className="text-[23px]">
//               {action === "edit"
//                 ? "Edit Email Template"
//                 : action === "copy"
//                 ? "Copy Email Template"
//                 : "Create Email Template"}
//             </span>
//           </div>
//         }
//         visible={visible}
//         onCancel={() => {
//           resetForm();
//           onClose();
//         }}
//         footer={null}
//         closable={true}
//         width={800}
//       >
//         <>
//         {isLoading?(
//           <div className="flex justify-center items-center" style={{
//             height: modalHeight,
//             overflowY: "auto",
//             overflowX: "hidden",
//           }}>
//           <Spin size="large" />
//         </div>
//         ):(
//         <div style={{
//           height: modalHeight,
//           overflowY: "auto",
//           overflowX: "hidden",
//         }}>
          
//         <div>
//           <h2 className="text-[19px] font-medium">Email Template</h2>
//           <Form form={form} layout="vertical" requiredMark={false}>
//             <Row gutter={16}>
//               <Col span={8}>
//                 <Form.Item
//                   label={renderLabel("Parent Module", true)}
//                   name="parentModule"
//                   rules={[
//                     { required: true, message: "Please Select Parent Module" },
//                   ]}
//                 >
//                   <Select
//                     allowClear
//                     placeholder="Select a Module"
//                     suffixIcon={
//                       <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
//                     }
//                     style={{ height: "43px" }}
//                     onChange={handleParentChange}
//                     value={rowData?.parents_module_name}
//                     notFoundContent="No Options Available"
//                     showSearch
//                     filterOption={(input: any, option: any) =>
//                       option.children
//                         .toLowerCase()
//                         .indexOf(input.toLowerCase()) >= 0
//                     }
//                   >
//                     {parentModOptions.map((parentOpt) => (
//                       <Select.Option key={parentOpt} value={parentOpt}>
//                         {parentOpt}
//                       </Select.Option>
//                     ))}
//                   </Select>
//                 </Form.Item>
//               </Col>
//               <Col span={8}>
//                 <Form.Item label="Sub Module" name="subModule">
//                   <Select
//                     allowClear
//                     placeholder="Select a Module"
//                     suffixIcon={
//                       <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
//                     }
//                     style={{ height: "43px", marginTop: "4px" }}
//                     onChange={handleChildChange}
//                     value={rowData?rowData.sub_module_name:selectedChildModule}
//                     notFoundContent="No options available"
//                     showSearch
//                     filterOption={(input: any, option: any) =>
//                       option.children
//                         .toLowerCase()
//                         .indexOf(input.toLowerCase()) >= 0
//                     }
//                   >
//                     {childModOptions.map((childOpt) => (
//                       <Select.Option key={childOpt} value={childOpt}>
//                         {childOpt}
//                       </Select.Option>
//                     ))}
//                   </Select>
//                 </Form.Item>
//               </Col>
//               <Col span={8}>
//                 <Form.Item label={"Child Module"} name="childModule">
//                   <Select
//                     allowClear
//                     placeholder="Select a Module"
//                     suffixIcon={
//                       <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
//                     }
//                     value={rowData?rowData?.sub_module_name:selectedSubModule}
//                     style={{ height: "43px", marginTop: "4px" }}
//                     onChange={handleSubModuleChange}
//                     notFoundContent="No Options Available"
//                     showSearch
//                     filterOption={(input: any, option: any) =>
//                       option.children
//                         .toLowerCase()
//                         .indexOf(input.toLowerCase()) >= 0
//                     }
//                   >
//                     {subModOptions.map((subOpt) => (
//                       <Select.Option key={subOpt} value={subOpt}>
//                         {subOpt}
//                       </Select.Option>
//                     ))}
//                   </Select>
//                 </Form.Item>
//               </Col>
//             </Row>
//             <Row gutter={16}>
//               <Col span={8}>
//                 <Form.Item
//                   label={renderLabel("Template Type", true)}
//                   name="template_type"
//                   rules={[
//                     { required: true, message: "Please Select a Template" },
//                   ]}
//                 >
//                   <Select
//                     allowClear
//                     placeholder="Select a Template"
//                     suffixIcon={
//                       <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
//                     }
//                     value={templateType}
//                     onChange={handleTemplateTypeChange}
//                     style={{ height: "43px" }}
//                     notFoundContent="No Options Available"
//                     showSearch
//                     filterOption={(input: any, option: any) =>
//                       option.children
//                         .toLowerCase()
//                         .indexOf(input.toLowerCase()) >= 0
//                     }
//                   >
//                     {templateOptions.map((temp) => (
//                       <Select.Option key={temp} value={temp}>
//                         {temp}{" "}
//                         {/* This will display the template name directly */}
//                       </Select.Option>
//                     ))}
//                   </Select>
//                 </Form.Item>
//               </Col>
//               <Col span={8}>
//                 <Form.Item label={"Role Based"} name="roleBased">
//                   <Select
//                     allowClear
//                     value={rowData?.role}
//                     onChange={(value) => setRoleBased(value)}
//                     placeholder="Select a Role"
//                     suffixIcon={
//                       <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
//                     }
//                     style={{ height: "43px", marginTop: "4px" }}
//                     showSearch
//                     filterOption={(input: any, option: any) =>
//                       option.children
//                         .toLowerCase()
//                         .indexOf(input.toLowerCase()) >= 0
//                     }
//                   >
//                     {roleOptions.map((role) => (
//                       <Select.Option key={role} value={role}>
//                         {role}
//                       </Select.Option>
//                     ))}
//                   </Select>
//                 </Form.Item>
//               </Col>
//               <Col span={8}>
//                 <Form.Item label="Frequency" name="frequency">
//                   <Select
//                     allowClear
//                     placeholder="Select Frequency"
//                     suffixIcon={
//                       <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
//                     }
//                     style={{ height: "43px", marginTop: "4px" }}
//                     onChange={handleFrequencyChange}
//                   >
//                     <Select.Option value="Daily">Daily</Select.Option>
//                     <Select.Option value="Weekly">Weekly</Select.Option>
//                     <Select.Option value="Monthly">Monthly</Select.Option>
//                     <Select.Option value="Cycle">Cycle Date</Select.Option>
//                   </Select>
//                 </Form.Item>
//               </Col>
//               {selectedFrequency === "Cycle" && (
//                 <Col span={8}>
//                   {/* <Form.Item
//                 label={renderLabel("Select day", true)}
//                 name="cycleDay"
//                 rules={[
//                   {
//                     required: true,
//                     message: "Please select a valid day between 1 and 31",
//                     type: "number",
//                     min: 1,
//                     max: 31,
//                   },
//                 ]}
//               >
//                 <InputNumber
//                   min={1}
//                   max={31}
//                   placeholder="Select day"
//                   style={{ width: "100%", height:"43px" }}
//                   onChange={handleCycleDayChange}
//                 />
//               </Form.Item> */}
//                   <Form.Item
//                     label={renderLabel("Select Day", true)}
//                     rules={[
//                       { required: true, message: "Please input the Quantity!" },
//                       {
//                         validator: (_, value) =>
//                           value >= 0
//                             ? Promise.resolve()
//                             : Promise.reject(
//                                 new Error("Quantity cannot be Negative")
//                               ),
//                       },
//                     ]}
//                   >
//                     <Input
//                       className="input"
//                       placeholder="Input Date"
//                       type="number"
//                       min={0}
//                       max={31}
//                       onChange={handleCycleDayChange}
//                     />
//                   </Form.Item>
//                 </Col>
//               )}
//             </Row>
//           </Form>
//         </div>

//         <h2 className="text-[19px] font-medium">Basic Information</h2>
//         <div
//           className="p-4 rounded-lg"
//           style={{
//             marginTop: "10px",
//             boxShadow:
//               "0px -2px 4px rgba(0, 0, 0, 0.05), 0px 4px 6px rgba(0, 0, 0, 0.1)",
//           }}
//         >
//           <Form form={form} layout="vertical" requiredMark={false}>
//             <Row gutter={16}>
//               <Col span={8}>
//                 <Form.Item
//                   label={renderLabel("Email Type", true)}
//                   name="emailType"
//                   rules={[
//                     { required: true, message: "Please Enter Email Type" },
//                   ]}
//                 >
//                   <Select
//                     allowClear
//                     value={rowData?.email_type}
//                     placeholder="Select Email Type"
//                     onChange={(value) => setEmailType(value)}
//                     suffixIcon={
//                       <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
//                     }
//                     style={{ height: "43px" }}
//                   >
//                     <Select.Option value="Application">
//                       Application
//                     </Select.Option>
//                     <Select.Option value="AWS">AWS</Select.Option>
//                     <Select.Option value="Billing">Billing</Select.Option>
//                   </Select>
//                 </Form.Item>
//               </Col>
//               <Col span={8}>
//                 <Form.Item
//                   label={renderLabel("Template Name", true)}
//                   name="templateName"
//                   rules={[
//                     { required: true, message: "Please Enter Template Name" },
//                   ]}
//                 >
//                   <Input
//                     className="input"
//                     value={templateName}
//                     onChange={(e) => setTemplateName(e.target.value)}
//                   />
//                 </Form.Item>
//               </Col>
//               <Col span={8}>
//                 <Form.Item
//                   label={renderLabel("Partner Name", true)}
//                   name="partnerName"
//                   rules={[
//                     { required: true, message: "Please Select Partner Name" },
//                   ]}
//                 >
//                   <Select
//                     allowClear
//                     value={rowData?.partner_name}
//                     onChange={(value) => setSelectedPartnerName(value)}
//                     placeholder="Select a Partner"
//                     suffixIcon={
//                       <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
//                     }
//                     style={{ height: "43px" }}
//                     showSearch
//                     filterOption={(input: any, option: any) =>
//                       option.children
//                         .toLowerCase()
//                         .indexOf(input.toLowerCase()) >= 0
//                     }
//                   >
//                     {partnerOptions.map((partner) => (
//                       <Select.Option key={partner} value={partner}>
//                         {partner}
//                       </Select.Option>
//                     ))}
//                   </Select>
//                 </Form.Item>
//               </Col>
//             </Row>
//             <div
//               style={{
//                 display: "flex",
//                 alignItems: "center",
//                 marginBottom: "16px",
//               }}
//             >
//               <label
//                 style={{
//                   fontWeight: "bold",
//                   marginRight: "10px",
//                   width: "62px",
//                 }}
//               >
//                 To
//               </label>
//               <div
//                 style={{
//                   display: "flex",
//                   flexWrap: "wrap",
//                   padding: "5px",
//                   alignItems: "center",
//                   width: "100%",
//                 }}
//               >
//                  <Form.Item name="toMail" noStyle>
//       <Input
//         className={`input ${toMailDisabled ? 'non-editable-input' : 'input'}`}
//         value={toEmailInput}
//         onChange={(e) => setToEmailInput(e.target.value)}
//         onKeyPress={(e) => handleEmailKeyPress(e, "to")}
//         onBlur={() => handleEmailBlur("to")}
//         disabled={toMailDisabled}
//       />
//     </Form.Item>
//               </div>
//             </div>

//             <div
//               style={{
//                 display: "flex",
//                 alignItems: "center",
//                 marginBottom: "16px",
//               }}
//             >
//               <label
//                 style={{
//                   fontWeight: "bold",
//                   marginRight: "10px",
//                   width: "62px",
//                 }}
//               >
//                 CC
//               </label>
//               <div
//                 style={{
//                   display: "flex",
//                   flexWrap: "wrap",
//                   padding: "5px",
//                   alignItems: "center",
//                   width: "100%",
//                 }}
//               >
//                 <Form.Item name="ccMail" noStyle>
//   <Input
//     className="input"
//     value={ccEmailInput}
//     onChange={(e) => setCcEmailInput(e.target.value)}
//     onKeyPress={(e) => handleEmailKeyPress(e, "cc")}
//     onBlur={() => handleEmailBlur("cc")}
//   />
// </Form.Item>

//               </div>
//             </div>

//             <div
//               style={{
//                 display: "flex",
//                 alignItems: "center",
//                 marginBottom: "16px",
//                 width: "100%",
//               }}
//             >
//               <label
//                 style={{
//                   fontWeight: "bold",
//                   marginRight: "26px",
//                   width: "49px",
//                   backgroundColor: "transparent",
//                 }}
//               >
//                 Subject
//               </label>
//               <Form.Item name="subject" noStyle>
//               <Input
//                 // disabled={!templateType}
//                 name="subject"
//                 className="input"
//                 value={subject}
//                 onChange={(e) => setSubject(e.target.value)}
//               />
//               </Form.Item>
//             </div>
//             {isReportDropdownVisible ? (
//               <>
//                 <Form.Item
//                   label={renderLabel("Report type", true)}
//                   rules={[{ required: true, message: "Please select report" }]}
//                 >
//                   <Select
//                     allowClear
//                     value={selectedReport}
//                     onChange={(value) => setSelectedReport(value)}
//                     placeholder="Select a report"
//                     style={{ width: "100%" }}
//                     suffixIcon={
//                       <ChevronDownIcon className="w-4 h-4 mt-2 text-gray-600" />
//                     }
//                     showSearch
//                     filterOption={(input: any, option: any) =>
//                       option.children
//                         .toLowerCase()
//                         .indexOf(input.toLowerCase()) >= 0
//                     }
//                   >
//                     {reportOptions.map((report) => (
//                       <Select.Option key={report} value={report}>
//                         {report}
//                       </Select.Option>
//                     ))}
//                   </Select>
//                 </Form.Item>
//                 <Form.Item>
//                   <Input.TextArea
//                     rows={6}
//                     style={{ resize: "none" }}
//                     // value={rowData?.body}
//                   />
//                 </Form.Item>
//               </>
//             ) : (
//               <>
//                 {/* Body and Placeholder Dropdown */}
//                 <div
//                   style={{
//                     display: "flex",
//                     alignItems: "center",
//                     marginBottom: "16px",
//                     justifyContent: "space-between",
//                   }}
//                 >
//                   <label
//                     style={{
//                       fontWeight: "bold",
//                       marginRight: "26px",
//                       width: "49px",
//                     }}
//                   >
//                     Body
//                   </label>

//                   <Form.Item style={{ flex: 1, marginBottom: 0 }}>
//                     <Select
//                       allowClear
//                       value={selectedPlaceholder}
//                       onChange={handleSelectPlaceholder}
//                       placeholder="Select a Placeholder"
//                       suffixIcon={
//                         <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
//                       }
//                       style={{ width: "200px", height: "40px" }}
//                       notFoundContent="No options available"
//                       showSearch
//                       filterOption={(input: any, option: any) =>
//                         option.children
//                           .toLowerCase()
//                           .indexOf(input.toLowerCase()) >= 0
//                       }
//                     >
//                       {placeholderOptions?.map((placeholder) => (
//                         <Select.Option key={placeholder} value={placeholder}>
//                           {placeholder}
//                         </Select.Option>
//                       ))}
//                     </Select>
//                   </Form.Item>
//                   <Button className="save-btn" onClick={handleAddTableClick}>
//                     <PlusIcon className="h-4 w-4 text-black-600 ml-1" />
//                     Add Table
//                   </Button>
//                 </div>

//                 {/* Body Text Area with Highlighted Text */}
//                 <Form.Item
//                   style={{ marginBottom: "10px", position: "relative" }}
//                   name="body"
//                 >
//                   <Input.TextArea
//                     rows={20}
//                     style={{
//                       resize: "none",
//                       backgroundColor: "transparent",
//                       position: "absolute",
//                       top: 0,
//                       left: 0,
//                       zIndex: 2,
//                       width: "100%",
//                       height: "100%",
//                       color: "black",
//                       padding: "8px",
//                       border: "1px solid #d9d9d9",
//                       borderRadius: "4px",
//                     }}
//                     name="body"
//                     placeholder="Insert Text Here..."
//                     value={body}
//                     onChange={(e) => handleBody(e.target.value)}
//                   />
//                   <div
//                     dangerouslySetInnerHTML={{
//                       __html: getHighlightedText(
//                         body,
//                         selectedPlaceholdersList
//                       ),
//                     }}
//                     style={{
//                       whiteSpace: "pre-wrap",
//                       padding: "8px",
//                       border: "1px solid #d9d9d9",
//                       borderRadius: "4px",
//                       minHeight: "120px",
//                       backgroundColor: "#fff",
//                       color: "transparent",
//                       zIndex: 1,
//                       pointerEvents: "none",
//                     }}
//                   />
//                 </Form.Item>

//                 {/* Table Section */}
//                 {isShowTable && (
//                   <div>
//                     <Form layout="vertical">
//                       <Row gutter={16} align="middle">
//                         <Col span={6}>
//                           <Form.Item style={{ marginBottom: 0 }}>
//                             <Select
//                               mode="multiple"
//                               placeholder="Select Columns"
//                               value={selectedColumns}
//                               onChange={(value) => setSelectedColumns(value)}
//                               maxTagCount={1}
//                               suffixIcon={
//                                 <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
//                               }
//                               style={{ width: "200px", height: "40px" }}
//                             >
//                               {placeholderOptions.map((column: any) => (
//                                 <Select.Option key={column} value={column}>
//                                   {column}
//                                 </Select.Option>
//                               ))}
//                             </Select>
//                           </Form.Item>
//                         </Col>
//                       </Row>
//                     </Form>
//                   </div>
//                 )}

//                 {selectedColumns.length > 0 && (
//                   <Table
//                     dataSource={tableData}
//                     columns={selectedColumns.map((col) => ({
//                       title: col, // Set the column title
//                       dataIndex: col, // Set the data field for the column
//                       key: col,
//                     }))}
//                     rowKey={(record: any) => record.id || record.key}
//                     style={{ marginTop: "20px" }}
//                   />
//                 )}
//               </>
//             )}

//             {/* <div
//               style={{
//                 display: "flex",
//                 gap: "10px",
//                 marginBottom: "10px",
//                 marginTop: "10px",
//               }}
//             >
//               <Upload {...uploadProps}>
//                 <Button
//                   icon={
//                     <PaperClipIcon className="h-4 w-4 text-black-600 ml-1" />
//                   }
//                   onClick={handleUploadClick}
//                   className="save-btn"
//                 >
//                   Attach file
//                 </Button>
//               </Upload>
//             </div> */}
//           </Form>
//         </div>
//         <div className="flex justify-center space-x-2 mt-4">
//           <Button
//             onClick={() => {
//               resetForm();
//               onClose();
//             }}
//             style={{ marginRight: "8px", fontFamily: "Calibri" }}
//             className="cancel-btn text-base border-none"
//           >
//             Cancel
//           </Button>
//           <button
//             onClick={handleSave}
//             className="save-btn "
            
//           >
//             Save
//           </button>
//           {rowData?.email_type === "Infra" && (
//             <Button
//               className="save-btn"
//               style={{ fontFamily: "Calibri" }}
//             >
//               Send
//             </Button>
//           )}
//         </div>
//         </div>
//         )}
//         </>
//       </Modal>

//       <Modal
//         title={
//           <div className="mt-[-9px]">
//             <span className="confirm-popup-heading ">Confirm Save</span>
//           </div>
//         }
//         visible={isConfirmationVisible}
//         onCancel={() => setIsConfirmationVisible(false)}
//         styles={{ body: { top:"10px", padding: "4px" } }}
//         footer={null}
//         closable={true}
//         centered
//       >
//         <div className="text-left">
//           <p style={{ fontFamily: "Calibri" }}>
//             Are the Related Settings Activated in your AWS Account from AWS
//             Admin?
//           </p>
//           <div className="flex justify-center space-x-2 mt-4">
//             <Button
//               className="cancel-btn text-base border-none"
//               style={{ fontFamily: "Calibri" }}
//               onClick={() => setIsConfirmationVisible(false)}
//             >
//               Cancel
//             </Button>
//             <Button
//               className="save-btn text-base border-none"
//               style={{ fontFamily: "Calibri" }}
//               onClick={() => {
//                 setIsConfirmationVisible(false);
//                 handleConfirm();
//               }}
              
//             >
//               Confirm
//             </Button>
//           </div>
//         </div>
        
//       </Modal>
//     </>
//   );
// return (
//   <>
//     <Modal
//       title={
//         <div className="mt-[-10px]">
//           <span className="text-[23px]">
//             {action === "edit"
//               ? "Edit Email Template"
//               : action === "copy"
//               ? "Copy Email Template"
//               : "Create Email Template"}
//           </span>
//         </div>
//       }
//       visible={visible}
//       onCancel={() => {
//         resetForm();
//         onClose();
//       }}
//       footer={null}
//       closable={true}
//       width="90%"
//       style={{ maxWidth: "800px" }}
//       centered
//     >
//       <>
//       {isLoading?(
//         <div className="flex justify-center items-center" style={{
//           height: modalHeight,
//           overflowY: "auto",
//           overflowX: "hidden",
//         }}>
//         <Spin size="large" />
//       </div>
//       ):(
//       <div style={{
//         height: modalHeight,
//         overflowY: "auto",
//         overflowX: "hidden",
//       }}>
        
//       <div>
//         <h2 className="text-[19px] font-medium mb-4">Email Template</h2>
//         <Form form={form} layout="vertical" requiredMark={false}>
//           <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
//             <Col xs={24} sm={12} md={8}>
//               <Form.Item
//                 label={renderLabel("Parent Module", true)}
//                 name="parentModule"
//                 rules={[
//                   { required: true, message: "Please Select Parent Module" },
//                 ]}
//               >
//                 <Select
//                   allowClear
//                   placeholder="Select a Module"
//                   suffixIcon={
//                     <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
//                   }
//                   style={{ height: "43px" }}
//                   onChange={handleParentChange}
//                   value={rowData?.parents_module_name}
//                   notFoundContent="No Options Available"
//                   showSearch
//                   filterOption={(input: any, option: any) =>
//                     option.children
//                       .toLowerCase()
//                       .indexOf(input.toLowerCase()) >= 0
//                   }
//                 >
//                   {parentModOptions.map((parentOpt) => (
//                     <Select.Option key={parentOpt} value={parentOpt}>
//                       {parentOpt}
//                     </Select.Option>
//                   ))}
//                 </Select>
//               </Form.Item>
//             </Col>
//             <Col xs={24} sm={12} md={8}>
//               <Form.Item label="Sub Module" name="subModule">
//                 <Select
//                   allowClear
//                   placeholder="Select a Module"
//                   suffixIcon={
//                     <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
//                   }
//                   style={{ height: "43px" }}
//                   onChange={handleChildChange}
//                   value={rowData?rowData.sub_module_name:selectedChildModule}
//                   notFoundContent="No options available"
//                   showSearch
//                   filterOption={(input: any, option: any) =>
//                     option.children
//                       .toLowerCase()
//                       .indexOf(input.toLowerCase()) >= 0
//                   }
//                 >
//                   {childModOptions.map((childOpt) => (
//                     <Select.Option key={childOpt} value={childOpt}>
//                       {childOpt}
//                     </Select.Option>
//                   ))}
//                 </Select>
//               </Form.Item>
//             </Col>
//             <Col xs={24} sm={24} md={8}>
//               <Form.Item label={"Child Module"} name="childModule">
//                 <Select
//                   allowClear
//                   placeholder="Select a Module"
//                   suffixIcon={
//                     <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
//                   }
//                   value={rowData?rowData?.sub_module_name:selectedSubModule}
//                   style={{ height: "43px" }}
//                   onChange={handleSubModuleChange}
//                   notFoundContent="No Options Available"
//                   showSearch
//                   filterOption={(input: any, option: any) =>
//                     option.children
//                       .toLowerCase()
//                       .indexOf(input.toLowerCase()) >= 0
//                   }
//                 >
//                   {subModOptions.map((subOpt) => (
//                     <Select.Option key={subOpt} value={subOpt}>
//                       {subOpt}
//                     </Select.Option>
//                   ))}
//                 </Select>
//               </Form.Item>
//             </Col>
//           </Row>
//           <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
//             <Col xs={24} sm={12} md={8}>
//               <Form.Item
//                 label={renderLabel("Template Type", true)}
//                 name="template_type"
//                 rules={[
//                   { required: true, message: "Please Select a Template" },
//                 ]}
//               >
//                 <Select
//                   allowClear
//                   placeholder="Select a Template"
//                   suffixIcon={
//                     <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
//                   }
//                   value={templateType}
//                   onChange={handleTemplateTypeChange}
//                   style={{ height: "43px" }}
//                   notFoundContent="No Options Available"
//                   showSearch
//                   filterOption={(input: any, option: any) =>
//                     option.children
//                       .toLowerCase()
//                       .indexOf(input.toLowerCase()) >= 0
//                   }
//                 >
//                   {templateOptions.map((temp) => (
//                     <Select.Option key={temp} value={temp}>
//                       {temp}{" "}
//                       {/* This will display the template name directly */}
//                     </Select.Option>
//                   ))}
//                 </Select>
//               </Form.Item>
//             </Col>
//             <Col xs={24} sm={12} md={8}>
//               <Form.Item label={"Role Based"} name="roleBased">
//                 <Select
//                   allowClear
//                   value={rowData?.role}
//                   onChange={(value) => setRoleBased(value)}
//                   placeholder="Select a Role"
//                   suffixIcon={
//                     <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
//                   }
//                   style={{ height: "43px" }}
//                   showSearch
//                   filterOption={(input: any, option: any) =>
//                     option.children
//                       .toLowerCase()
//                       .indexOf(input.toLowerCase()) >= 0
//                   }
//                 >
//                   {roleOptions.map((role) => (
//                     <Select.Option key={role} value={role}>
//                       {role}
//                     </Select.Option>
//                   ))}
//                 </Select>
//               </Form.Item>
//             </Col>
//             <Col xs={24} sm={24} md={8}>
//               <Form.Item label="Frequency" name="frequency">
//                 <Select
//                   allowClear
//                   placeholder="Select Frequency"
//                   suffixIcon={
//                     <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
//                   }
//                   style={{ height: "43px" }}
//                   onChange={handleFrequencyChange}
//                 >
//                   <Select.Option value="Daily">Daily</Select.Option>
//                   <Select.Option value="Weekly">Weekly</Select.Option>
//                   <Select.Option value="Monthly">Monthly</Select.Option>
//                   <Select.Option value="Cycle">Cycle Date</Select.Option>
//                 </Select>
//               </Form.Item>
//             </Col>
//             {selectedFrequency === "Cycle" && (
//               <Col xs={24} sm={12} md={8}>
//                 <Form.Item
//                   label={renderLabel("Select Day", true)}
//                   rules={[
//                     { required: true, message: "Please input the Quantity!" },
//                     {
//                       validator: (_, value) =>
//                         value >= 0
//                           ? Promise.resolve()
//                           : Promise.reject(
//                               new Error("Quantity cannot be Negative")
//                             ),
//                     },
//                   ]}
//                 >
//                   <Input
//                     className="input"
//                     placeholder="Input Date"
//                     type="number"
//                     min={0}
//                     max={31}
//                     onChange={handleCycleDayChange}
//                   />
//                 </Form.Item>
//               </Col>
//             )}
//           </Row>
//         </Form>
//       </div>

//       <h2 className="text-[19px] font-medium mb-4 mt-6">Basic Information</h2>
//       <div
//         className="p-4 rounded-lg"
//         style={{
//           boxShadow:
//             "0px -2px 4px rgba(0, 0, 0, 0.05), 0px 4px 6px rgba(0, 0, 0, 0.1)",
//         }}
//       >
//         <Form form={form} layout="vertical" requiredMark={false}>
//           <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
//             <Col xs={24} sm={12} md={8}>
//               <Form.Item
//                 label={renderLabel("Email Type", true)}
//                 name="emailType"
//                 rules={[
//                   { required: true, message: "Please Enter Email Type" },
//                 ]}
//               >
//                 <Select
//                   allowClear
//                   value={rowData?.email_type}
//                   placeholder="Select Email Type"
//                   onChange={(value) => setEmailType(value)}
//                   suffixIcon={
//                     <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
//                   }
//                   style={{ height: "43px" }}
//                 >
//                   <Select.Option value="Application">
//                     Application
//                   </Select.Option>
//                   <Select.Option value="AWS">AWS</Select.Option>
//                   <Select.Option value="Billing">Billing</Select.Option>
//                 </Select>
//               </Form.Item>
//             </Col>
//             <Col xs={24} sm={12} md={8}>
//               <Form.Item
//                 label={renderLabel("Template Name", true)}
//                 name="templateName"
//                 rules={[
//                   { required: true, message: "Please Enter Template Name" },
//                 ]}
//               >
//                 <Input
//                   className="input"
//                   value={templateName}
//                   onChange={(e) => setTemplateName(e.target.value)}
//                 />
//               </Form.Item>
//             </Col>
//             <Col xs={24} sm={24} md={8}>
//               <Form.Item
//                 label={renderLabel("Partner Name", true)}
//                 name="partnerName"
//                 rules={[
//                   { required: true, message: "Please Select Partner Name" },
//                 ]}
//               >
//                 <Select
//                   allowClear
//                   value={rowData?.partner_name}
//                   onChange={(value) => setSelectedPartnerName(value)}
//                   placeholder="Select a Partner"
//                   suffixIcon={
//                     <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
//                   }
//                   style={{ height: "43px" }}
//                   showSearch
//                   filterOption={(input: any, option: any) =>
//                     option.children
//                       .toLowerCase()
//                       .indexOf(input.toLowerCase()) >= 0
//                   }
//                 >
//                   {partnerOptions.map((partner) => (
//                     <Select.Option key={partner} value={partner}>
//                       {partner}
//                     </Select.Option>
//                   ))}
//                 </Select>
//               </Form.Item>
//             </Col>
//           </Row>

//           {/* Email Fields - Responsive Layout */}
//           <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
//             <Col span={24}>
//               <Form.Item
//                 label={<span style={{ fontWeight: 'bold' }}>To</span>}
//                 name="toMail"
//                 style={{ fontFamily: "Calibri, sans-serif" }}
//               >
//                 <Input
//                   className={`input ${toMailDisabled ? 'non-editable-input' : 'input'}`}
//                   value={toEmailInput}
//                   onChange={(e) => setToEmailInput(e.target.value)}
//                   onKeyPress={(e) => handleEmailKeyPress(e, "to")}
//                   onBlur={() => handleEmailBlur("to")}
//                   disabled={toMailDisabled}
//                 />
//               </Form.Item>
//             </Col>
//           </Row>

//           <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
//             <Col span={24}>
//               <Form.Item
//                 label={<span style={{ fontWeight: 'bold' }}>CC</span>}
//                 name="ccMail"
//                 style={{ fontFamily: "Calibri, sans-serif" }}
//               >
//                 <Input
//                   className="input"
//                   value={ccEmailInput}
//                   onChange={(e) => setCcEmailInput(e.target.value)}
//                   onKeyPress={(e) => handleEmailKeyPress(e, "cc")}
//                   onBlur={() => handleEmailBlur("cc")}
//                 />
//               </Form.Item>
//             </Col>
//           </Row>

//           <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
//             <Col span={24}>
//               <Form.Item
//                 label={<span style={{ fontWeight: 'bold' }}>Subject</span>}
//                 name="subject"
//                 style={{ fontFamily: "Calibri, sans-serif" }}
//               >
//                 <Input
//                   name="subject"
//                   className="input"
//                   value={subject}
//                   onChange={(e) => setSubject(e.target.value)}
//                 />
//               </Form.Item>
//             </Col>
//           </Row>

//           {isReportDropdownVisible ? (
//             <>
//               <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
//                 <Col span={24}>
//                   <Form.Item
//                     label={renderLabel("Report type", true)}
//                     rules={[{ required: true, message: "Please select report" }]}
//                   >
//                     <Select
//                       allowClear
//                       value={selectedReport}
//                       onChange={(value) => setSelectedReport(value)}
//                       placeholder="Select a report"
//                       style={{ width: "100%" }}
//                       suffixIcon={
//                         <ChevronDownIcon className="w-4 h-4 mt-2 text-gray-600" />
//                       }
//                       showSearch
//                       filterOption={(input: any, option: any) =>
//                         option.children
//                           .toLowerCase()
//                           .indexOf(input.toLowerCase()) >= 0
//                       }
//                     >
//                       {reportOptions.map((report) => (
//                         <Select.Option key={report} value={report}>
//                           {report}
//                         </Select.Option>
//                       ))}
//                     </Select>
//                   </Form.Item>
//                 </Col>
//               </Row>
//               <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
//                 <Col span={24}>
//                   <Form.Item>
//                     <Input.TextArea
//                       rows={6}
//                       style={{ resize: "none" }}
//                     />
//                   </Form.Item>
//                 </Col>
//               </Row>
//             </>
//           ) : (
//             <>
//               {/* Body and Placeholder Dropdown */}
//               <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
//                 <Col span={24}>
//                   <div
//                     style={{
//                       display: "flex",
//                       alignItems: "center",
//                       marginBottom: "16px",
//                       justifyContent: "space-between",
//                       flexWrap: "wrap",
//                       gap: "8px"
//                     }}
//                   >
//                     <label
//                       style={{
//                         fontWeight: "bold",
//                         minWidth: "49px",
//                       }}
//                     >
//                       Body
//                     </label>

//                     <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
//                       <Select
//                         allowClear
//                         value={selectedPlaceholder}
//                         onChange={handleSelectPlaceholder}
//                         placeholder="Select a Placeholder"
//                         suffixIcon={
//                           <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
//                         }
//                         style={{ width: "200px", height: "40px" }}
//                         notFoundContent="No options available"
//                         showSearch
//                         filterOption={(input: any, option: any) =>
//                           option.children
//                             .toLowerCase()
//                             .indexOf(input.toLowerCase()) >= 0
//                         }
//                       >
//                         {placeholderOptions?.map((placeholder) => (
//                           <Select.Option key={placeholder} value={placeholder}>
//                             {placeholder}
//                           </Select.Option>
//                         ))}
//                       </Select>
//                       <Button className="save-btn" onClick={handleAddTableClick}>
//                         <PlusIcon className="h-4 w-4 text-black-600 ml-1" />
//                         Add Table
//                       </Button>
//                     </div>
//                   </div>
//                 </Col>
//               </Row>

//               {/* Body Text Area with Highlighted Text */}
//               <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
//                 <Col span={24}>
//                   <Form.Item
//                     style={{ marginBottom: "10px", position: "relative" }}
//                     name="body"
//                   >
//                     <Input.TextArea
//                       rows={20}
//                       style={{
//                         resize: "none",
//                         backgroundColor: "transparent",
//                         position: "absolute",
//                         top: 0,
//                         left: 0,
//                         zIndex: 2,
//                         width: "100%",
//                         height: "100%",
//                         color: "black",
//                         padding: "8px",
//                         border: "1px solid #d9d9d9",
//                         borderRadius: "4px",
//                       }}
//                       name="body"
//                       placeholder="Insert Text Here..."
//                       value={body}
//                       onChange={(e) => handleBody(e.target.value)}
//                     />
//                     <div
//                       dangerouslySetInnerHTML={{
//                         __html: getHighlightedText(
//                           body,
//                           selectedPlaceholdersList
//                         ),
//                       }}
//                       style={{
//                         whiteSpace: "pre-wrap",
//                         padding: "8px",
//                         border: "1px solid #d9d9d9",
//                         borderRadius: "4px",
//                         minHeight: "120px",
//                         backgroundColor: "#fff",
//                         color: "transparent",
//                         zIndex: 1,
//                         pointerEvents: "none",
//                       }}
//                     />
//                   </Form.Item>
//                 </Col>
//               </Row>

//               {/* Table Section */}
//               {isShowTable && (
//                 <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
//                   <Col xs={24} sm={12} md={6}>
//                     <Form layout="vertical">
//                       <Form.Item style={{ marginBottom: 0 }}>
//                         <Select
//                           mode="multiple"
//                           placeholder="Select Columns"
//                           value={selectedColumns}
//                           onChange={(value) => setSelectedColumns(value)}
//                           maxTagCount={1}
//                           suffixIcon={
//                             <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
//                           }
//                           style={{ width: "100%", height: "40px" }}
//                         >
//                           {placeholderOptions.map((column: any) => (
//                             <Select.Option key={column} value={column}>
//                               {column}
//                             </Select.Option>
//                           ))}
//                         </Select>
//                       </Form.Item>
//                     </Form>
//                   </Col>
//                 </Row>
//               )}

//               {selectedColumns.length > 0 && (
//                 <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
//                   <Col span={24}>
//                     <Table
//                       dataSource={tableData}
//                       columns={selectedColumns.map((col) => ({
//                         title: col,
//                         dataIndex: col,
//                         key: col,
//                       }))}
//                       rowKey={(record: any) => record.id || record.key}
//                       style={{ marginTop: "20px" }}
//                       scroll={{ x: true }}
//                     />
//                   </Col>
//                 </Row>
//               )}
//             </>
//           )}
//         </Form>
//       </div>
      
//       {/* Action Buttons - Responsive */}
//       <div className="flex justify-center flex-wrap gap-2 mt-6 mb-4">
//         <Button
//           onClick={() => {
//             resetForm();
//             onClose();
//           }}
//           style={{ fontFamily: "Calibri" }}
//           className="cancel-btn text-base border-none"
//         >
//           Cancel
//         </Button>
//         <button
//           onClick={handleSave}
//           className="save-btn"
//         >
//           Save
//         </button>
//         {rowData?.email_type === "Infra" && (
//           <Button
//             className="save-btn"
//             style={{ fontFamily: "Calibri" }}
//           >
//             Send
//           </Button>
//         )}
//       </div>
//       </div>
//       )}
//       </>
//     </Modal>

//     <Modal
//       title={
//         <div className="mt-[-9px]">
//           <span className="confirm-popup-heading ">Confirm Save</span>
//         </div>
//       }
//       visible={isConfirmationVisible}
//       onCancel={() => setIsConfirmationVisible(false)}
//       styles={{ body: { top:"10px", padding: "4px" } }}
//       footer={null}
//       closable={true}
//       centered
//     >
//       <div className="text-left">
//         <p style={{ fontFamily: "Calibri" }}>
//           Are the Related Settings Activated in your AWS Account from AWS
//           Admin?
//         </p>
//         <div className="flex justify-center space-x-2 mt-4">
//           <Button
//             className="cancel-btn text-base border-none"
//             style={{ fontFamily: "Calibri" }}
//             onClick={() => setIsConfirmationVisible(false)}
//           >
//             Cancel
//           </Button>
//           <Button
//             className="save-btn text-base border-none"
//             style={{ fontFamily: "Calibri" }}
//             onClick={() => {
//               setIsConfirmationVisible(false);
//               handleConfirm();
//             }}
//           >
//             Confirm
//           </Button>
//         </div>
//       </div>
//     </Modal>
//   </>
// );
return (
  <>
    <Modal
      title={
        <div className="mt-[-10px]">
          <span className="text-[23px]">
            {action === "edit"
              ? "Edit Email Template"
              : action === "copy"
              ? "Copy Email Template"
              : "Create Email Template"}
          </span>
        </div>
      }
      visible={visible}
      onCancel={() => {
        resetForm();
        onClose();
      }}
      footer={null}
      closable={true}
      width="90%"
      style={{ maxWidth: "800px" }}
      centered
    >
      <>
      {isLoading?(
        <div className="flex justify-center items-center" style={{
          height: modalHeight,
          overflowY: "auto",
          overflowX: "hidden",
        }}>
        <Spin size="large" />
      </div>
      ):(
      <div style={{
        height: modalHeight,
        overflowY: "auto",
        overflowX: "hidden",
      }}>
        
      <div>
        <h2 className="text-[19px] font-medium mb-4">Email Template</h2>
        <Form form={form} layout="vertical" requiredMark={false}>
          <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
            <Col xs={24} sm={12} md={8}>
              <Form.Item
                label={renderLabel("Parent Module", true)}
                name="parentModule"
                rules={[
                  { required: true, message: "Please Select Parent Module" },
                ]}
              >
                <Select
                  allowClear
                  placeholder="Select a Module"
                  suffixIcon={
                    <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
                  }
                  style={{ height: "43px" }}
                  onChange={handleParentChange}
                  value={rowData?.parents_module_name}
                  notFoundContent="No Options Available"
                  showSearch
                  filterOption={(input: any, option: any) =>
                    option.children
                      .toLowerCase()
                      .indexOf(input.toLowerCase()) >= 0
                  }
                >
                  {parentModOptions.map((parentOpt) => (
                    <Select.Option key={parentOpt} value={parentOpt}>
                      {parentOpt}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col xs={24} sm={12} md={8}>
              <Form.Item label="Sub Module" name="subModule">
                <Select
                  allowClear
                  placeholder="Select a Module"
                  suffixIcon={
                    <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
                  }
                  style={{ height: "43px" }}
                  onChange={handleChildChange}
                  value={rowData?rowData.sub_module_name:selectedChildModule}
                  notFoundContent="No options available"
                  showSearch
                  filterOption={(input: any, option: any) =>
                    option.children
                      .toLowerCase()
                      .indexOf(input.toLowerCase()) >= 0
                  }
                >
                  {childModOptions.map((childOpt) => (
                    <Select.Option key={childOpt} value={childOpt}>
                      {childOpt}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col xs={24} sm={24} md={8}>
              <Form.Item label={"Child Module"} name="childModule">
                <Select
                  allowClear
                  placeholder="Select a Module"
                  suffixIcon={
                    <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
                  }
                  value={rowData?rowData?.sub_module_name:selectedSubModule}
                  style={{ height: "43px" }}
                  onChange={handleSubModuleChange}
                  notFoundContent="No Options Available"
                  showSearch
                  filterOption={(input: any, option: any) =>
                    option.children
                      .toLowerCase()
                      .indexOf(input.toLowerCase()) >= 0
                  }
                >
                  {subModOptions.map((subOpt) => (
                    <Select.Option key={subOpt} value={subOpt}>
                      {subOpt}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
            <Col xs={24} sm={12} md={8}>
              <Form.Item
                label={renderLabel("Template Type", true)}
                name="template_type"
                rules={[
                  { required: true, message: "Please Select a Template" },
                ]}
              >
                <Select
                  allowClear
                  placeholder="Select a Template"
                  suffixIcon={
                    <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
                  }
                  value={templateType}
                  onChange={handleTemplateTypeChange}
                  style={{ height: "43px" }}
                  notFoundContent="No Options Available"
                  showSearch
                  filterOption={(input: any, option: any) =>
                    option.children
                      .toLowerCase()
                      .indexOf(input.toLowerCase()) >= 0
                  }
                >
                  {templateOptions.map((temp) => (
                    <Select.Option key={temp} value={temp}>
                      {temp}{" "}
                      {/* This will display the template name directly */}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col xs={24} sm={12} md={8}>
              <Form.Item label={"Role Based"} name="roleBased">
                <Select
                  allowClear
                  value={rowData?.role}
                  onChange={(value) => setRoleBased(value)}
                  placeholder="Select a Role"
                  suffixIcon={
                    <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
                  }
                  style={{ height: "43px" }}
                  showSearch
                  filterOption={(input: any, option: any) =>
                    option.children
                      .toLowerCase()
                      .indexOf(input.toLowerCase()) >= 0
                  }
                >
                  {roleOptions.map((role) => (
                    <Select.Option key={role} value={role}>
                      {role}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
            <Col xs={24} sm={24} md={8}>
              <Form.Item label="Frequency" name="frequency">
                <Select
                  allowClear
                  placeholder="Select Frequency"
                  suffixIcon={
                    <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
                  }
                  style={{ height: "43px" }}
                  onChange={handleFrequencyChange}
                >
                  <Select.Option value="Daily">Daily</Select.Option>
                  <Select.Option value="Weekly">Weekly</Select.Option>
                  <Select.Option value="Monthly">Monthly</Select.Option>
                  <Select.Option value="Cycle">Cycle Date</Select.Option>
                </Select>
              </Form.Item>
            </Col>
            {selectedFrequency === "Cycle" && (
              <Col xs={24} sm={12} md={8}>
                <Form.Item
                  label={renderLabel("Select Day", true)}
                  rules={[
                    { required: true, message: "Please input the Quantity!" },
                    {
                      validator: (_, value) =>
                        value >= 0
                          ? Promise.resolve()
                          : Promise.reject(
                              new Error("Quantity cannot be Negative")
                            ),
                    },
                  ]}
                >
                  <Input
                    className="input"
                    placeholder="Input Date"
                    type="number"
                    min={0}
                    max={31}
                    onChange={handleCycleDayChange}
                  />
                </Form.Item>
              </Col>
            )}
          </Row>
        </Form>
      </div>

      <h2 className="text-[19px] font-medium mb-4 mt-6">Basic Information</h2>
      <div
        className="p-4 rounded-lg"
        style={{
          boxShadow:
            "0px -2px 4px rgba(0, 0, 0, 0.05), 0px 4px 6px rgba(0, 0, 0, 0.1)",
        }}
      >
        <Form form={form} layout="vertical" requiredMark={false}>
          <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
            <Col xs={24} sm={12} md={8}>
              <Form.Item
                label={renderLabel("Email Type", true)}
                name="emailType"
                rules={[
                  { required: true, message: "Please Enter Email Type" },
                ]}
              >
                <Select
                  allowClear
                  value={rowData?.email_type}
                  placeholder="Select Email Type"
                  onChange={(value) => setEmailType(value)}
                  suffixIcon={
                    <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
                  }
                  style={{ height: "43px" }}
                >
                  <Select.Option value="Application">
                    Application
                  </Select.Option>
                  <Select.Option value="AWS">AWS</Select.Option>
                  <Select.Option value="Billing">Billing</Select.Option>
                </Select>
              </Form.Item>
            </Col>
            <Col xs={24} sm={12} md={8}>
              <Form.Item
                label={renderLabel("Template Name", true)}
                name="templateName"
                rules={[
                  { required: true, message: "Please Enter Template Name" },
                ]}
              >
                <Input
                  className="input"
                  value={templateName}
                  onChange={(e) => setTemplateName(e.target.value)}
                />
              </Form.Item>
            </Col>
            <Col xs={24} sm={24} md={8}>
              <Form.Item
                label={renderLabel("Partner Name", true)}
                name="partnerName"
                rules={[
                  { required: true, message: "Please Select Partner Name" },
                ]}
              >
                <Select
                  allowClear
                  value={rowData?.partner_name}
                  onChange={(value) => setSelectedPartnerName(value)}
                  placeholder="Select a Partner"
                  suffixIcon={
                    <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
                  }
                  style={{ height: "43px" }}
                  showSearch
                  filterOption={(input: any, option: any) =>
                    option.children
                      .toLowerCase()
                      .indexOf(input.toLowerCase()) >= 0
                  }
                >
                  {partnerOptions.map((partner) => (
                    <Select.Option key={partner} value={partner}>
                      {partner}
                    </Select.Option>
                  ))}
                </Select>
              </Form.Item>
            </Col>
          </Row>

          {/* Email Fields - Inline Layout */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              marginBottom: "16px",
            }}
          >
            <label
              style={{
                fontWeight: "bold",
                marginRight: "10px",
                width: "62px",
              }}
            >
              To
            </label>
            <div
              style={{
                display: "flex",
                flexWrap: "wrap",
                padding: "5px",
                alignItems: "center",
                width: "100%",
              }}
            >
              <Form.Item name="toMail" noStyle>
                <Input
                  className={`input ${toMailDisabled ? 'non-editable-input' : 'input'}`}
                  value={toEmailInput}
                  onChange={(e) => setToEmailInput(e.target.value)}
                  onKeyPress={(e) => handleEmailKeyPress(e, "to")}
                  onBlur={() => handleEmailBlur("to")}
                  disabled={toMailDisabled}
                />
              </Form.Item>
            </div>
          </div>

          <div
            style={{
              display: "flex",
              alignItems: "center",
              marginBottom: "16px",
            }}
          >
            <label
              style={{
                fontWeight: "bold",
                marginRight: "10px",
                width: "62px",
              }}
            >
              CC
            </label>
            <div
              style={{
                display: "flex",
                flexWrap: "wrap",
                padding: "5px",
                alignItems: "center",
                width: "100%",
              }}
            >
              <Form.Item name="ccMail" noStyle>
                <Input
                  className="input"
                  value={ccEmailInput}
                  onChange={(e) => setCcEmailInput(e.target.value)}
                  onKeyPress={(e) => handleEmailKeyPress(e, "cc")}
                  onBlur={() => handleEmailBlur("cc")}
                />
              </Form.Item>
            </div>
          </div>

          <div
            style={{
              display: "flex",
              alignItems: "center",
              marginBottom: "16px",
              width: "100%",
            }}
          >
            <label
              style={{
                fontWeight: "bold",
                marginRight: "26px",
                width: "49px",
                backgroundColor: "transparent",
              }}
            >
              Subject
            </label>
            <Form.Item name="subject" noStyle>
              <Input
                name="subject"
                className="input"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
              />
            </Form.Item>
          </div>

          {isReportDropdownVisible ? (
            <>
              <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
                <Col span={24}>
                  <Form.Item
                    label={renderLabel("Report type", true)}
                    rules={[{ required: true, message: "Please select report" }]}
                  >
                    <Select
                      allowClear
                      value={selectedReport}
                      onChange={(value) => setSelectedReport(value)}
                      placeholder="Select a report"
                      style={{ width: "100%" }}
                      suffixIcon={
                        <ChevronDownIcon className="w-4 h-4 mt-2 text-gray-600" />
                      }
                      showSearch
                      filterOption={(input: any, option: any) =>
                        option.children
                          .toLowerCase()
                          .indexOf(input.toLowerCase()) >= 0
                      }
                    >
                      {reportOptions.map((report) => (
                        <Select.Option key={report} value={report}>
                          {report}
                        </Select.Option>
                      ))}
                    </Select>
                  </Form.Item>
                </Col>
              </Row>
              <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
                <Col span={24}>
                  <Form.Item>
                    <Input.TextArea
                      rows={6}
                      style={{ resize: "none" }}
                    />
                  </Form.Item>
                </Col>
              </Row>
            </>
          ) : (
            <>
              {/* Body and Placeholder Dropdown */}
              <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
                <Col span={24}>
                  <div
                    style={{
                      display: "flex",
                      alignItems: "center",
                      marginBottom: "16px",
                      justifyContent: "space-between",
                      flexWrap: "wrap",
                      gap: "8px"
                    }}
                  >
                    <label
                      style={{
                        fontWeight: "bold",
                        minWidth: "49px",
                      }}
                    >
                      Body
                    </label>

                    <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>
                      <Select
                        allowClear
                        value={selectedPlaceholder}
                        onChange={handleSelectPlaceholder}
                        placeholder="Select a Placeholder"
                        suffixIcon={
                          <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
                        }
                        style={{ width: "200px", height: "40px" }}
                        notFoundContent="No options available"
                        showSearch
                        filterOption={(input: any, option: any) =>
                          option.children
                            .toLowerCase()
                            .indexOf(input.toLowerCase()) >= 0
                        }
                      >
                        {placeholderOptions?.map((placeholder) => (
                          <Select.Option key={placeholder} value={placeholder}>
                            {placeholder}
                          </Select.Option>
                        ))}
                      </Select>
                      <Button className="save-btn w-auto p-5" onClick={handleAddTableClick}>
                        <PlusIcon className="h-4 w-4 text-black-600" />
                        Add Table
                      </Button>
                    </div>
                  </div>
                </Col>
              </Row>

              {/* Body Text Area with Highlighted Text */}
              <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
                <Col span={24}>
                  <Form.Item
                    style={{ marginBottom: "10px", position: "relative" }}
                    name="body"
                  >
                    <Input.TextArea
                      rows={20}
                      style={{
                        resize: "none",
                        backgroundColor: "transparent",
                        position: "absolute",
                        top: 0,
                        left: 0,
                        zIndex: 2,
                        width: "100%",
                        height: "100%",
                        color: "black",
                        padding: "8px",
                        border: "1px solid #d9d9d9",
                        borderRadius: "4px",
                      }}
                      name="body"
                      placeholder="Insert Text Here..."
                      value={body}
                      onChange={(e) => handleBody(e.target.value)}
                    />
                    <div
                      dangerouslySetInnerHTML={{
                        __html: getHighlightedText(
                          body,
                          selectedPlaceholdersList
                        ),
                      }}
                      style={{
                        whiteSpace: "pre-wrap",
                        padding: "8px",
                        border: "1px solid #d9d9d9",
                        borderRadius: "4px",
                        minHeight: "120px",
                        backgroundColor: "#fff",
                        color: "transparent",
                        zIndex: 1,
                        pointerEvents: "none",
                      }}
                    />
                  </Form.Item>
                </Col>
              </Row>

              {/* Table Section */}
              {isShowTable && (
                <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
                  <Col xs={24} sm={12} md={6}>
                    <Form layout="vertical">
                      <Form.Item style={{ marginBottom: 0 }}>
                        <Select
                          mode="multiple"
                          placeholder="Select Columns"
                          value={selectedColumns}
                          onChange={(value) => setSelectedColumns(value)}
                          maxTagCount={1}
                          suffixIcon={
                            <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
                          }
                          style={{ width: "100%", height: "40px" }}
                        >
                          {placeholderOptions.map((column: any) => (
                            <Select.Option key={column} value={column}>
                              {column}
                            </Select.Option>
                          ))}
                        </Select>
                      </Form.Item>
                    </Form>
                  </Col>
                </Row>
              )}

              {selectedColumns.length > 0 && (
                <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
                  <Col span={24}>
                    <Table
                      dataSource={tableData}
                      columns={selectedColumns.map((col) => ({
                        title: col,
                        dataIndex: col,
                        key: col,
                      }))}
                      rowKey={(record: any) => record.id || record.key}
                      style={{ marginTop: "20px" }}
                      scroll={{ x: true }}
                    />
                  </Col>
                </Row>
              )}
            </>
          )}
        </Form>
      </div>
      
      {/* Action Buttons - Responsive */}
      <div className="flex justify-center flex-wrap gap-2 mt-6 mb-4">
        <Button
          onClick={() => {
            resetForm();
            onClose();
          }}
          style={{ fontFamily: "Calibri" }}
          className="cancel-btn text-base border-none"
        >
          Cancel
        </Button>
        <button
          onClick={handleSave}
          className="save-btn"
        >
          Save
        </button>
        {rowData?.email_type === "Infra" && (
          <Button
            className="save-btn"
            style={{ fontFamily: "Calibri" }}
          >
            Send
          </Button>
        )}
      </div>
      </div>
      )}
      </>
    </Modal>

    <Modal
      title={
        <div className="mt-[-9px]">
          <span className="confirm-popup-heading ">Confirm Save</span>
        </div>
      }
      visible={isConfirmationVisible}
      onCancel={() => setIsConfirmationVisible(false)}
      styles={{ body: { top:"10px", padding: "4px" } }}
      footer={null}
      closable={true}
      centered
    >
      <div className="text-left">
        <p style={{ fontFamily: "Calibri" }}>
          Are the Related Settings Activated in your AWS Account from AWS
          Admin?
        </p>
        <div className="flex justify-center space-x-2 mt-4">
          <Button
            className="cancel-btn text-base border-none"
            style={{ fontFamily: "Calibri" }}
            onClick={() => setIsConfirmationVisible(false)}
          >
            Cancel
          </Button>
          <Button
            className="save-btn text-base border-none"
            style={{ fontFamily: "Calibri" }}
            onClick={() => {
              setIsConfirmationVisible(false);
              handleConfirm();
            }}
          >
            Confirm
          </Button>
        </div>
      </div>
    </Modal>
  </>
);
};

export default CreateEmailAuditTemplateModal;
