import React, { useCallback, useEffect, useMemo, useState } from "react";
import { Modal, notification, Spin, Switch, Tooltip } from "antd";
import Select, { MenuListProps, MultiValue, SingleValue } from "react-select";
import {
  PlusCircleIcon,
  MinusCircleIcon,
  InformationCircleIcon,
  ArrowsRightLeftIcon,
} from "@heroicons/react/24/outline";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { GroupBase, components } from "react-select";
import VirtualList from 'rc-virtual-list';
import { DropdownStyles } from "@/app/components/css/dropdown";
import { fireSideCannons } from "@/app/components/confetti";
interface SelectOption {
  value: string;
  label: string;
  group?: string;
}
const ITEM_HEIGHT = 35; // Height of each option in pixels

// Define proper types for the VirtualizedMenuList component
const VirtualizedMenuList = ({
  options,
  children,
  maxHeight,
  getValue,
  ...props
}: MenuListProps<SelectOption, boolean, GroupBase<SelectOption>>) => {
  // Extract the selected values from getValue
  const selectedValues = getValue();
  const selectedIds = new Set(
    Array.isArray(selectedValues) ? selectedValues.map((val) => val.value) : []
  );

  // Flatten grouped options for virtualization
  const flattenedChildren = useMemo(() => {
    const flattened: any[] = [];

    React.Children.forEach(children, (child: any) => {
      if (child.type === components.Group) {
        flattened.push({
          type: 'group',
          label: child.props.label,
          data: child.props.data,
          id: `group-${child.props.label}`,
        });
        React.Children.forEach(child.props.children, (option) => {
          flattened.push({
            type: 'option',
            data: option.props.data,
            isSelected: selectedIds.has(option?.props?.data?.value),
            component: option,
            id: option?.props?.data?.value,
          });
        });
      } else if (child) {
        flattened.push({
          type: 'option',
          data: child.props.data,
          isSelected: selectedIds.has(child?.props?.data?.value),
          component: child,
          id: child?.props?.data?.value,
        });
      }
    });
    return flattened;
  }, [children, selectedIds]);

  const renderItem = (item: any) => {
    if (item.type === 'group') {
      return (
        <div
          key={item.id}
          className="group-header"
          style={{
            padding: '8px 12px',
            fontWeight: 'bold',
            backgroundColor: '#f5f5f5',
            position: 'sticky',
            top: 0,
            zIndex: 1,
          }}
        >
          {item.label}
        </div>
      );
    }
    return item.component;
  };
  return (
    <div {...props.innerProps} ref={props.innerRef}>
      <VirtualList
        data={flattenedChildren}
        height={maxHeight}
        itemHeight={ITEM_HEIGHT}
        itemKey="id"
      >
        {(item) => renderItem(item)}
      </VirtualList>
    </div>
  );
};

const AddNotificationsModal: React.FC<{
  isVisible: boolean;
  executionOrder?:any
  onClose: () => void;
}> = ({ isVisible, onClose,executionOrder }) => {
  // Add these new constants at the top level of your component
  const PERCENTAGE_FIELDS = [
    "Total Mobility Customer Pool Usage(Mobility Customer Pool Usage)",
     "Total M2M Customer Pool Usage(M2M Customer Pool Usage)",
     "Total Cross Provider Customer Pool Usage (Percentage)(Cross Provider Customer Pool Usage)"  
   ];
  const [expressionBuilderFields, setExpressionBuilderFields] = useState<
    {
      id: number;
      field: string;
      fieldId: string | null;
      condition: string;
      conditionId: string | null;
      constant: string;
      constantId: string | null;
      isConditionVisible: boolean;
      isLabel: boolean;
      isLabelConstant: boolean;
      showUnitDropdown?: boolean;
      unit?: string;
    }[]
  >([
    {
      id: 1,
      field: "",
      fieldId: null,
      condition: "",
      conditionId: null,
      constant: "",
      constantId: null,
      isConditionVisible: false,
      isLabel: false,
      isLabelConstant: false,
      
    },
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const {
    username,
    tenantNames,
    role,
    token,
    partner,
    selectedDb,
    metaData,
    firstLastName,
    settabledata,
    sessionId,
  } = useAuth();

  const [validationErrors, setValidationErrors] = useState<{
    [key: string]: string;
  }>({});
  // const [isLabel, setIsLabel] = useState<boolean>(false)
  // const [isLabelConstant, setIsLabelConstant] = useState<boolean>(false)
  const [formData, setFormData] = useState({ is_active: false });
  const [showCondition, setShowCondition] = useState<boolean>(false);
  const [isAllCustomers, setIsAllCustomers] = useState<boolean>(false);
  const [isCrossProvider, setIsCrossProvider] = useState<boolean>(false);
  const [ruleIdField, setRuleIdField] = useState("");
  const [nameField, setNameField] = useState("");
  const [executionOrderField, setExecutionOrderField] = useState<
    any | undefined
  >(executionOrder);
  const [subjectLineField, setSubjectLineField] = useState("");
  const [messageField, setMessageField] = useState("");
  const [descriptionField, setDescriptionField] = useState("");
  const [sendToSystem, setSendToSystem] = useState(false);
  const [showProjected, setShowProjected] = useState(false);
  const [notifyCustomerGroup , setNotifyCustomerGroup] = useState(false)
  const [showExcludedPooledDevices,setShowExcludedPooledDevices] = useState(false)
  const [sendAllCutomerNotificationsToEmail, setSendAllCutomerNotificationsToEmail] = useState("");
  const [emailError, setEmailError] = useState("");

  const [customergroup, setCustomerGroup] = useState([]);
  const [selectedCondition, setSelectedCondition] = useState({
    value: "AND",
    label: "AND",
  });
  const [changeToField, setChangeToField] = useState("");
  const [changeToConstant, setChangeToConstant] = useState("");
  const [changeToFieldDropdown, setChangeToFieldDropDown] = useState([]);
  const [conditions, setConditions] = useState<{ [key: string]: string }>({});
  const [idCounter, setIdCounter] = React.useState(2); // Counter to generate unique IDs

  const [isLabel, setIsLabel] = useState<boolean>(false);
  const [loading, setLoading] = useState(false);
  const [isLabelConstant, setIsLabelConstant] = useState<boolean>(false);
  const [selectedServiceProvider, setSelectedServiceProvider] =
    useState<string>(""); // For selected value as string
  const [provider, setProvider] = useState<
    Array<{ label: string; value: string }>
  >([]); // For options array

  const [operationTypeOptions, setOperationTypeOptions] = useState<
    SelectOption[]
  >([]);
  const [fieldTypeOptions, setFieldTypeOptions] = useState<
    GroupBase<SelectOption>[]
  >([]);
  const [customerOptions, setCustomerOptions] = useState<
    GroupBase<SelectOption>[]
  >([]);
  const [selectedConditions, setSelectedConditions] = useState<string[]>(
    expressionBuilderFields.length > 1
      ? Array(expressionBuilderFields.length - 1).fill("")
      : []
  );

  //states for selected dropdown options
  const [selectedFieldTypeOption, setSelectedOption] =
    useState<SelectOption | null>(null);
  const [selectedOperationOption, setSelectedOperationOption] =
    useState<SelectOption | null>(null);
  const [selectedCustomerOption, setSelectedCustomerOption] =
    useState<MultiValue<SelectOption> | null>(null);
  
  const [notificationType, setNotificationType] = useState("");
  const [notificationTypeOptions, setNotificationTypeOptions] = useState<any>([]);

   const CROSS_PROVIDER_NOTIFICATION_TYPE_OPTIONS = [
    { value: "m2m_device_notifications", label: "M2M Device Notifications" },
    { value: "m2m_pool_notifications", label: "M2M Pool Notifications" },
    { value: "mobility_device_notifications", label: "Mobility Device Notifications" },
    { value: "mobility_pool_notifications", label: "Mobility Pool Notifications" },
    { value: "cross_provider_device_notifications", label: "Cross Provider Device Notifications" },
    { value: "cross_provider_pool_notifications", label: "Cross Provider Pool Notifications" }

  ];

 const NOT_CROSS_PROVIDER_NOTIFICATION_TYPE_OPTIONS = [
    { value: "m2m_device_notifications", label: "M2M Device Notifications" },
    { value: "m2m_pool_notifications", label: "M2M Pool Notifications" },
    { value: "mobility_device_notifications", label: "Mobility Device Notifications" },
    { value: "mobility_pool_notifications", label: "Mobility Pool Notifications" },
  ];


    const [theme, setTheme] = useState('normal');
    useEffect(() => {
      if (typeof window !== 'undefined') {
        try {
          const storedTheme = localStorage.getItem('app_theme');
          if (storedTheme) setTheme(storedTheme);
        } catch (e) {
          console.warn("Error reading theme from localStorage:", e);
        }
      }
    }, []);

  const addExpressionField = () => {
    setExpressionBuilderFields((prevFields) => [
      ...prevFields,
      {
        id: prevFields.length + 1,
        field: "",
        fieldId: null,
        condition: "",
        conditionId: null,
        constant: "",
        constantId: null,
        isConditionVisible: true,
        isLabel: false,
        isLabelConstant: false,
        showUnitDropdown: false,

      },
    ]);
    setSelectedConditions((prev) => [...prev, "AND"]);
  };


  const removeExpressionField = (id: number) => {
    const updatedFields = expressionBuilderFields.filter(
      (field) => field.id !== id
    );
    setExpressionBuilderFields(updatedFields);

    // If only one field remains after removal, hide the condition field
    if (updatedFields.length === 1) {
      setShowCondition(false);
    }
  };

  

  // Add this new function to generate percentage options
  const generatePercentageOptions = () => {
    const options = [];
    for (let i = 0; i <= 100; i += 5) {
      options.push({
        value: i.toString(),
        label: `${i}%`
      });
    }
    return options;
  };

  // Function to handle the toggle change
  const handleSwitchChange = (checked: boolean) => {
    setSelectedCustomerOption([]);
    setIsAllCustomers(checked);
  };
  const handleNameChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const name = e.target.value; // Get the typed name
    setNameField(name); // Update the name field
    // Replace spaces with hyphens and update the Rule ID
    setRuleIdField(name.trim().replace(/\s+/g, "-"));
  };
  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
  const value = e.target.value;
  setSendAllCutomerNotificationsToEmail(value);

  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (value && !emailRegex.test(value)) {
    setEmailError("Please enter a valid email address");
  } else {
    setEmailError("");
  }
};

  const resetForm = () => {
    setValidationErrors({});
    setNotificationType(""); // Add this line
    setRuleIdField("");
    setNameField("");
    // setExecutionOrderField(undefined);
    setSubjectLineField("");
    setMessageField("");
    setDescriptionField("");
    setSelectedCustomerOption([]);
    setSendToSystem(false);
    setShowProjected(false);
    setSelectedCustomerOption([]);
    setSelectedConditions([]);
    setSelectedServiceProvider("");
    setIsAllCustomers(false);
    setSelectedServiceProvider("");
    setNotifyCustomerGroup(false);
    setShowExcludedPooledDevices(false);
    setSendAllCutomerNotificationsToEmail('');
    setEmailError("")

    // Reset Expression Builder Fields
    setExpressionBuilderFields([
      {
        id: 1,
        isLabel: false,
        isLabelConstant: false,
        field: '',
        fieldId: '',
        condition: '',
        conditionId: '',
        isConditionVisible: false,
        constant: '',
        constantId: ''
      }
    ]);

    // Reset Conditions
    setSelectedConditions([]);

    // Reset toggle-related states
    setChangeToConstant("");
    setChangeToField("");
  };
  
    const fetchData = async () => {
      setLoading(true);
      try {
        const url = ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/get_cross_carrier_optimization",
          role_name: role,
          parent_module: "Partner",
          module_name: "Usage Notification",
          feature_module_name: "Usage Notification",
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
        };
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
  
        if (parsedData.flag === false) {
          Modal.error({
            title: 'Data Fetch Error',
            content: parsedData.message || 'An error occurred while fetching data. Please try again.',
            centered: true,
          });
        } else {
          const crossProvider_ = parsedData?.cross_carrier_optimization || false
          setIsCrossProvider(crossProvider_)
          const notification_options = crossProvider_ ? CROSS_PROVIDER_NOTIFICATION_TYPE_OPTIONS : NOT_CROSS_PROVIDER_NOTIFICATION_TYPE_OPTIONS || NOT_CROSS_PROVIDER_NOTIFICATION_TYPE_OPTIONS

          setNotificationTypeOptions(notification_options)
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        Modal.error({
          title: 'Data Fetch Error',
          content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
          centered: true,
        });
      } finally {
        setLoading(false);
  
      }
    };

  const validateForm = () => {
    const errors: Record<string, string> = {};

    // Validate Notification Type
  if (!notificationType.trim()) {
    errors.notificationType = "Notification Type is required!";
  }

    // Validate Name
    if (!nameField.trim()) {
      errors.name = "Name is required!";
    }

    // Validate Message
    if (!messageField.trim()) {
      errors.message = "Message is required!";
    }

    // Validate Description
    if (!descriptionField.trim()) {
      errors.description = "Description is required!";
    }
    // if (executionOrderField === undefined || executionOrderField < 0) {
    //   errors.executionOrderField = "Execution order is required";
    // }
    // Validate Service Provider
    // if (!selectedServiceProvider || !selectedServiceProvider) {
    //   errors.service_provider = "Service Provider is required!";
    // }

    expressionBuilderFields.forEach((expression, index) => {
      if (!expression.field) {
        errors[`expression_field_${index}`] = "This Field is required!";
      }
      if (!expression.condition) {
        errors[`expression_condition_${index}`] = "Condition is required!";
      }
      if (!expression.constant && (!["HAS VALUE", "HAS NO VALUE"].includes(expression.condition))) {
        errors[`expression_constant_${index}`] = "This Field is required!";
      }
    });
    // const hasDisplayName = checkForServiceProviderExpression();
    // if (!hasDisplayName) {
    //   errors['expression_service_provider_field'] = "Service Provider expression is not available!";
    // } else {
    //   // If we have the required expression, clear the error
    //   delete errors['expression_service_provider_field'];
    // }
    return errors;
  };
  const checkForServiceProviderExpression = () => {
    let matched = false;
    expressionBuilderFields.forEach((expression) => {
      if (expression.field === "DisplayName(Service Provider)" || expression.constant === "DisplayName(Service Provider)") {
        matched = true;
      }
    });
    return matched;
  };

  const transformFieldTypesToGroupedOptions = (fieldTypes: any) => {
    return Object.keys(fieldTypes).map((key) => ({
      label: key,
      options: fieldTypes[key].map((item: any) => {
        const fieldLabel = Object.keys(item)[0];
        const fieldValue = Object.values(item)[0];
        return {
          label: fieldLabel,
          value: fieldValue,
        };
      }),
    }));
  };

  const transformOperationTypes = (operationTypes: any[]): SelectOption[] => {
    return operationTypes.flatMap((op) =>
      Object.entries(op).map(([key, value]) => ({
        label: key,
        value: String(value),
      }))
    );
  };

  const transformCustomersToGroupedOptions = (
    customers: any
  ): GroupBase<SelectOption>[] => {
    const { customer_names, customer_groups } = customers;

    const customerNamesOptions = customer_names.map((entry: any) => {
      const [label, value] = Object.entries(entry)[0];
      return {
        label,
        value: String(value),
        group: "Customer Names", // Ensure consistent group name
      };
    });

    const customerGroupsOptions = customer_groups.map((entry: any) => {
      const [label, value] = Object.entries(entry)[0];
      return {
        label,
        value: String(value),
        group: "Customer Groups", // Ensure consistent group name
      };
    });

    return [
      {
        label: "Customer Names",
        options: customerNamesOptions,
      },
      {
        label: "Customer Groups",
        options: customerGroupsOptions,
      },
    ];
  };

  const fetchDropdownOptions = async () => {
    try {
      setIsLoading(true);
      const url = ENV_ROUTES.NOTIFICATION_SERVICES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_notification_rules",
        role_name: role,
        parent_module: "Partner",
        module_name: "Usage Notification",
        feature_module_name: "Usage Notification",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      const operationOptions = transformOperationTypes(
        parsedData.operation_types
      );
      setOperationTypeOptions(operationOptions);

      const fieldTypeOptions = transformFieldTypesToGroupedOptions(
        parsedData.field_types
      );
      setFieldTypeOptions(fieldTypeOptions);

      // const customers = transformCustomersToGroupedOptions(
      //   parsedData.customer_drop_down
      // );
      // setCustomerOptions(customers);

      const serviceProviderOptions = parsedData.service_providers.map(
        (provider: any) => ({
          label: provider, // What the user sees in the dropdown
          value: provider, // What gets stored as the selected value
        })
      );
      console.log("serviceProviderOptions", serviceProviderOptions);
      setProvider(serviceProviderOptions);
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };
  const CustomerDropdownOptions = async (offset = 0, limit = 100) => {
    console.log("loaded 12345678")
    try {
      setIsLoading(true);
      const url = ENV_ROUTES.NOTIFICATION_SERVICES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_notification_rules",
        role_name: role,
        parent_module: "Partner",
        module_name: "Usage Notification",
        feature_module_name: "Usage Notification",
        fetch: "customer_dropdown",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };
      const response = await axios.post(url, { data });
      if (response.status === 200 && response.data?.body) {
        const parsedData = JSON.parse(response.data.body);

        // const operationOptions = transformOperationTypes(
        //   parsedData.operation_types
        // );
        // setOperationTypeOptions(operationOptions);

        // const fieldTypeOptions = transformFieldTypesToGroupedOptions(
        //   parsedData.field_types
        // );
        // setFieldTypeOptions(fieldTypeOptions);

        const customers = transformCustomersToGroupedOptions(
          parsedData.customer_drop_down
        );
        console.log("customers@@@@@@@@@@@@@@@", customers)
        // setCustomerOptions(customers);

        setCustomerOptions((prevOptions) => {
          if (offset === 0) return customers; // Reset options on the first load
          return prevOptions.map((group, index) => ({
            ...group,
            options: [...group.options, ...(customers[index]?.options || [])],
          }));
        });
      } else {
        console.log('Response was not successful, no customer data available.');

      }

      // const serviceProviderOptions = parsedData.service_providers.map(
      //   (provider: any) => ({
      //     label: provider, // What the user sees in the dropdown
      //     value: provider, // What gets stored as the selected value
      //   })
      // );
      // setProvider(serviceProviderOptions);

    } catch (error) {
      console.error('An error occurred while fetching customer data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const handleToggle = (id: number) => {
    setIsLabel(true)
    setExpressionBuilderFields((prevFields) =>
      prevFields.map((field) =>
        field.id === id ? { ...field, isLabel: !field.isLabel } : field
      )
    );
  };
  const handleToggleChange = (id: number) => {
    setIsLabelConstant(true)
    setExpressionBuilderFields((prevFields) =>
      prevFields.map((field) =>
        field.id === id
          ? { ...field, isLabelConstant: !field.isLabelConstant }
          : field
      )
    );
  };

  const handleClose = () => {
    resetForm(); // Reset form state
    onClose(); // Notify parent to close the modal
  };

  const handleChangeExpressionField = (
    fieldId: number,
    key: "field" | "condition" | "constant",
    selectedOption: any
  ) => {
    setExpressionBuilderFields((prevFields) =>
      prevFields.map((field) =>
        field.id === fieldId
          ? {
            ...field,
            [key]: selectedOption?.label,
            [`${key}Id`]: selectedOption?.value,
          }
          : field
      )
    );
  };

  const transformSelectedCustomersForPayload = (
    selectedOptions: MultiValue<SelectOption>
  ) => {
    const customerNames: Record<string, string>[] = [];
    const customerGroups: Record<string, string>[] = [];

    selectedOptions.forEach((option) => {
      if (option.group === "Customer Names") {
        customerNames.push({ [option.label]: option.value });
      } else if (option.group === "Customer Groups") {
        customerGroups.push({ [option.label]: option.value });
      }
    });

    return {
      customer_names: customerNames.length > 0 ? customerNames : null,
      customer_groups: customerGroups.length > 0 ? customerGroups : null,
    };
  };
  

  // Transform expressionBuilderFields to expected payload structure
  const transformedExpressions = expressionBuilderFields.reduce(
    (acc, expression, index) => {
      if (!expression.field && !expression.constant && !expression.condition) {
        return acc; // Skip this row if all relevant fields are empty
      }
      // Determine keys dynamically based on `isLabel` and `isLabelConstant`
      const fieldKey = expression.isLabel ? "field_one" : "const_one";
      const constantKey = expression.isLabelConstant ? "field_two" : "const_two";

      // Create transformed expression object
      const transformedExpression = {
        [fieldKey]: expression.fieldId
          ? { [expression.field]: expression.fieldId }
          : expression.field,
        cond: expression.conditionId
          ? { [expression.condition]: expression.conditionId }
          : {},
        [constantKey]: expression.constantId
          ? { [expression.constant]: expression.constantId }
          : expression.constant,
      };
      if (expression.showUnitDropdown && expression.unit) {
        transformedExpression.unit = expression.unit;
      }
      // if (index < expressionBuilderFields.length - 1) {
      //   transformedExpression.condition = selectedConditions[index] || "AND"; // Default to "AND" if no condition is set
      // }

      // acc.push(transformedExpression);

      if (index < expressionBuilderFields.length - 1) {
        acc.push(transformedExpression);
        acc.push({
          [`expression_condition_${index + 1}`]: selectedConditions[index] || "AND", // Use the condition for this expression
        });
      } else {
        acc.push(transformedExpression); // Last expression does not need condition
      }

      return acc;
    },
    [] as any[]
  );


  const refetchTableData = async () => {
    try {
      setIsLoading(true);
    settabledata([])

      // addLog("UI API call");
      const url = ENV_ROUTES.NOTIFICATION_SERVICES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_notification_rules",
        role_name: role,
        parent_module: "Partner",
        module_name: "Usage Notification",
        feature_module_name: "Usage Notification",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      } else {
        const tableData_ = parsedData?.rule_data || [];
        settabledata(tableData_);
        console.log("parded data",parsedData)
        setExecutionOrderField(parsedData?.order_of_execution)
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setIsLoading(false);
    }
  };

  // Function to call Notification_sync API
  const callNotificationSync = async (ruleDefId: string, actionType: string) => {
    const syncUrl = ENV_ROUTES.NOTIFICATION_SERVICES;

    const syncData = {
      tenant_name: partner || "default_value",
      username: username,
      path: "/Notification_sync",
      action: actionType,
      rule_def_id: ruleDefId,
      parent_module: "Partner",
      module_name: "Usage Notification",
      feature_module_name: "Usage Notification",
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
      is_all_customers_flag:isAllCustomers || false
    };

    try {
      await axios.post(syncUrl, { data: syncData });
    } catch (error) {
      console.error("Error in Notification Sync:", error);
    }
  };

  const messageStyle = {
    fontSize: '14px',
    fontWeight: 'bold',
    padding: '16px',
  };

// Add this function before your handleSave function in AddNotificationsModal

// Add this function before your handleSave function in AddNotificationsModal

const transformFieldsBasedOnProvider = (
  expressions: any[],
  ruleObjectTypeMap: any,
  isCrossProvider: boolean,
  notificationType: string
) => {
  // Only transform for Customer Pool Usage Notification or Device Notification when isCrossProvider is true
  // const shouldTransform =
  //   (notificationType === "mobility_pool_notifications") ||
  //   (notificationType === "m2m_pool_notifications");

  // if (!shouldTransform) {
  //   return expressions;
  // }

  return expressions.map((expression) => {
    // Skip non-expression objects (like condition separators)
    if (!expression.const_one && !expression.field_one) {
      return expression;
    }

    const transformedExpression = { ...expression };

    // Transform const_one or field_one
    if (expression.const_one && typeof expression.const_one === "object") {
      transformedExpression.const_one = transformFieldObject(
        expression.const_one,
        ruleObjectTypeMap,
        isCrossProvider,
        notificationType
      );
    } else if (expression.field_one && typeof expression.field_one === "object") {
      transformedExpression.field_one = transformFieldObject(
        expression.field_one,
        ruleObjectTypeMap,
        isCrossProvider,
        notificationType
      );
    }

    // Transform const_two or field_two
    if (expression.const_two && typeof expression.const_two === "object") {
      transformedExpression.const_two = transformFieldObject(
        expression.const_two,
        ruleObjectTypeMap,
        isCrossProvider,
        notificationType
      );
    } else if (expression.field_two && typeof expression.field_two === "object") {
      transformedExpression.field_two = transformFieldObject(
        expression.field_two,
        ruleObjectTypeMap,
        isCrossProvider,
        notificationType
      );
    }

    return transformedExpression;
  });
};

 const transformFieldObject = (
  fieldObj: any,
  ruleObjectTypeMap: any,
  isCrossProvider: boolean,
  notificationType: string
) => {
  const transformedObj: any = {};

  console.log(
    "Transforming fieldObj:",
    fieldObj,
    "notificationType:",
    notificationType,
    "isCrossProvider:",
    isCrossProvider
  );

  Object.keys(fieldObj).forEach((fieldName) => {
    const fieldValue = fieldObj[fieldName];
    const fieldName_ = fieldName.toLowerCase();
    console.log("Processing fieldName:", fieldName, "fieldValue:", fieldValue);

    // Extract base value before "_"
    const baseValue = fieldValue?.split("_")[0];

    // Default — keep the same
    let newFieldName = fieldName;
    let newObjectTypeId = "";

    if (notificationType === "mobility_pool_notifications") {
      newObjectTypeId = ruleObjectTypeMap["Mobility Customer Pool Usage"];
    } else if (notificationType === "m2m_pool_notifications") {
      newObjectTypeId = ruleObjectTypeMap["M2M Customer Pool Usage"];
    } else if (notificationType === "m2m_device_notifications") {
      newObjectTypeId = ruleObjectTypeMap["Device"];
    } else if (notificationType === "mobility_device_notifications") {
      newObjectTypeId = ruleObjectTypeMap["Mobility Device"];
    } else if (notificationType === "cross_provider_device_notifications") {
      newObjectTypeId = ruleObjectTypeMap["Cross Provider Device"];
    } else if (notificationType === "cross_provider_pool_notifications") {
      newObjectTypeId = ruleObjectTypeMap["Cross Provider Customer Pool Usage"];
    }

    // If we found an objectTypeId, modify only the value, not the name in brackets
    if (newObjectTypeId) {
      transformedObj[newFieldName] = `${baseValue}_${newObjectTypeId}`;
    } else {
      transformedObj[newFieldName] = fieldValue;
    }
  });

  console.log("Transformed fieldObj:", transformedObj);
  return transformedObj;
};

// Update your handleSave function to use the transformation
const handleSave = async () => {
  const errors = validateForm();
  setValidationErrors(errors);

  // If errors exist, abort the save process
  if (Object.keys(errors).length > 0 || emailError) {
    return;
  }
  
  const transformedCustomerList = isAllCustomers
    ? "All"
    : transformSelectedCustomersForPayload(selectedCustomerOption || []);
    
  setIsLoading(true);
  const url = ENV_ROUTES.NOTIFICATION_SERVICES;

  // Get the rule object type map from your backend data
  const ruleObjectTypeMap = {
    "Mobility Device": "47d3aaae-f912-4f50-8e7a-6a0e0495f504",
    "M2M Customer Pool Usage": "a601dd51-ea87-4f2b-a190-937ab968b4af", 
    "Mobility Customer Pool Usage": "c3d1870a-6783-4a9b-a2a2-be7ebdac279b",
    "Device": "1834c245-33b2-4342-8a39-eda996ea0ae8",
    "Cross Provider Device": "21916a87-02b2-4524-9c0e-49649e942fe4",
    "Cross Provider Customer Pool Usage": "612f223f-3c09-4141-aac1-8c433124fc98"
  };

  // Apply transformation to expressions
  const transformedExpressions = transformFieldsBasedOnProvider(
    expressionBuilderFields.reduce((acc, expression, index) => {
      if (!expression.field && !expression.constant && !expression.condition) {
        return acc;
      }
      
      const fieldKey = expression.isLabel ? "field_one" : "const_one";
      const constantKey = expression.isLabelConstant ? "field_two" : "const_two";

      const transformedExpression = {
        [fieldKey]: expression.fieldId
          ? { [expression.field]: expression.fieldId }
          : expression.field,
        cond: expression.conditionId
          ? { [expression.condition]: expression.conditionId }
          : {},
        [constantKey]: expression.constantId
          ? { [expression.constant]: expression.constantId }
          : expression.constant,
      };
      
      if (expression.showUnitDropdown && expression.unit) {
        transformedExpression.unit = expression.unit;
      }

      if (index < expressionBuilderFields.length - 1) {
        acc.push(transformedExpression);
        acc.push({
          [`expression_condition_${index + 1}`]: selectedConditions[index] || "AND",
        });
      } else {
        acc.push(transformedExpression);
      }

      return acc;
    }, [] as any[]),
    ruleObjectTypeMap,
    isCrossProvider, // Pass the isCrossProvider flag
    notificationType // Pass the notification type
  );

  const formData = {
    notification_type: notificationType,
    rule_id: ruleIdField,
    name: nameField,
    order_of_execution: executionOrderField + 1 === ""||0||undefined?"0":executionOrderField + 1,
    subject_line: subjectLineField,
    display_message: messageField,
    notes: descriptionField,
    send_to_system_admin: sendToSystem,
    show_projected_usage_cost: showProjected,
    created_by: firstLastName,
    modified_by: firstLastName,
    customer_list: transformedCustomerList,
    expression_names: transformedExpressions,
    should_send_single_email_to_customer_group: notifyCustomerGroup,
    should_exclude_pooled_device: showExcludedPooledDevices,
    aggregated_customer_email_recipient: sendAllCutomerNotificationsToEmail 
  };

  const data = {
    tenant_name: partner || "default_value",
    username: username,
    path: "/process_notification_rules",
    role_based: role,
    parent_module: "Partner",
    module_name: "Usage Notification",
    feature_module_name: "Usage Notification",
    partner: partner,
    action: "create",
    table_name: "email_templates",
    changed_data: formData,
    request_received_at: getCurrentDateTime(),
    access_token: token,
    db_name: selectedDb,
    ...metaData,
    sessionID: sessionId,
  };

  try {
    const response = await axios.post(url, { data });
    const parsedData = JSON.parse(response.data.body);
    if (parsedData.flag === false) {
      handleClose();
      Modal.error({
        title: "Data Fetch Error",
        content:
          parsedData.message || "An error occurred while saving the data.",
        centered: true,
      });
    } else {
      await callNotificationSync(parsedData.rule_def_id, "create" );
      notification.success({
        message: 'Success',
        description: 'Data submitted successfully!',
        style: messageStyle,
        placement: 'top',
      });
      fireSideCannons();
      handleClose();
      refetchTableData();
    }
  } catch (error) {
    handleClose();
    Modal.error({
      title: "Error",
      content: "There was an error submitting the data.",
    });
  } finally {
    setIsLoading(false);
    handleClose();
  }
};
  useEffect(() => {
    fetchDropdownOptions();
    CustomerDropdownOptions();
    fetchData();
  }, [isVisible]);
  const handleScroll = useCallback(() => {
    if (isLoading) return; // Prevent triggering when already loading
    const menuElement = document.querySelector('.react-select__menu'); // Get the dropdown menu

    if (!menuElement) return;

    const isBottom = menuElement.scrollHeight === menuElement.scrollTop + menuElement.clientHeight;
    if (isBottom) {
      // Calculate the total options currently rendered
      const currentTotal = customerOptions.reduce(
        (acc, group) => acc + group.options.length,
        0
      );
      CustomerDropdownOptions(currentTotal, 100); // Load more options
    }
  }, [isLoading, customerOptions]);
  const modalHeight =
    typeof window !== "undefined" ? (window.innerHeight * 2.5) / 4 : 0;


    const getSelectStyles = (theme: string) => {
  let bgColor = 'white';
  let optionBg = '#F9FAFB';
  let selectedOptionBg = '#BFDBFE';
  let textColor = 'black';

  if (theme === 'dark') {
    bgColor = '#2d2f52';
    optionBg = '#031731';
    selectedOptionBg = '#5e5bb3';
    textColor = 'white';
  } else if (theme === 'red') {
    selectedOptionBg = '#FCA5A5';
  } else if (theme === 'green') {
    selectedOptionBg = '#6EE7B7';
  } else if (theme === 'blue') {
    selectedOptionBg = '#BFDBFE';
  }

  return {
    menu: (base: any) => ({
      ...base,
      maxHeight: 400,
      zIndex: 9999,
      backgroundColor: optionBg,
      marginTop: 0,
    }),
    menuPortal: (base: any) => ({
      ...base,
      zIndex: 9999,
    }),
    container: (base: any) => ({
      ...base,
      zIndex: 1000,
    }),
    control: (base: any) => ({
      ...base,
      height: "40px",
      backgroundColor: bgColor,
      color: textColor,
      border: "1px solid #d1d5db",
      fontSize: "16px",
    }),
    singleValue: (provided: any) => ({
      ...provided,
      color: textColor,
    }),
    option: (base: any, state: any) => ({
      ...base,
      whiteSpace: "nowrap",
      textOverflow: "ellipsis",
      padding: "8px 10px",
      fontSize: "16px",
      color: textColor,
      backgroundColor: state.isSelected ? selectedOptionBg : optionBg,
      ":hover": {
        backgroundColor: selectedOptionBg,
      },
    }),
    input: (base: any) => ({
      ...base,
      color: textColor,
    }),
  };
};
  const CustomersSelectComponent = () => (
    <div >
      <label className="block text-sm" style={{ fontFamily: "Calibri" }}>
        Customers & Customer Groups
      </label>
      <Select
        isMulti
        isSearchable
        options={customerOptions}
        menuPlacement="top"
        closeMenuOnSelect={false}
        isDisabled={isAllCustomers}
        value={isAllCustomers ? [] : selectedCustomerOption}
        onChange={(selectedOptions: any) => setSelectedCustomerOption(selectedOptions)}
        components={{
          MenuList: VirtualizedMenuList,
        }}
        onMenuScrollToBottom={handleScroll}
        styles={DropdownStyles}
      />
    </div>
  );

 const getFilteredFieldTypeOptions = () => {
  // If notification type is not selected, return all options
  if (!notificationType) {
    return fieldTypeOptions;
  }

  // Define which object types are allowed for each scenario (in lowercase for comparison)
  const allowedTypes: { [key: string]: string[] } = {
    'm2m_device_notifications': [
      'rev.io customer',
      'service provider',
      'device status',
      'device'
    ],
    'm2m_pool_notifications': [
      'rev.io customer',
      'service provider',
      'device status',
      'm2m customer pool usage',
      'device'
    ],
    'mobility_device_notifications': [
      'rev.io customer',
      'service provider',
      'device status',
      'mobility device',
    ],
    'mobility_pool_notifications': [
      'rev.io customer',
      'service provider',
      'device status',
      'mobility device',
      'mobility customer pool usage'
    ],
    "cross_provider_device_notifications": [
      'rev.io customer',
      'service provider',
      'device status',
      'cross provider device',
    ],
    "cross_provider_pool_notifications": [
      'rev.io customer',
      'service provider',
      'device status',
      'cross provider customer pool usage',
    ]
  };

  // Determine which scenario we're in
  let scenarioKey = '';
  // if (isCrossProvider) {
  //   scenarioKey = notificationType === 'customer_pool_usage_notification' 
  //     ? 'crossprovider_on_customer_pool_usage' 
  //     : 'crossprovider_on_device';
  // } else {
  //   scenarioKey = notificationType === 'customer_pool_usage_notification'
  //     ? 'crossprovider_off_customer_pool_usage'
  //     : 'crossprovider_off_device';
  // }

  const allowedTypesForScenario = allowedTypes[notificationType] || [];

  // Filter the options based on what's in the parentheses
  return fieldTypeOptions
    .map(group => ({
      ...group,
      options: group.options.filter(option => {
        // Extract the text within parentheses from the label
        const match = option.label.match(/\(([^()]*)\)(?!.*\([^()]*\))/);
        if (!match) return false;
        
        // Get the object type and convert to lowercase for comparison
        const objectType = match[1].toLowerCase().trim();
        
        // Check if this object type is in the allowed list
        return allowedTypesForScenario.includes(objectType);
      })
    }))
    .filter(group => group.options.length > 0); // Remove empty groups
};
 const renderSecondField = (expression: any, index: number) => {
    const isPercentageField = PERCENTAGE_FIELDS.includes(expression.field);
  
    return (
      <div className="w-full sm:w-1/2">
        {/* Label with toggle functionality */}
        <label
          className="text-sm cursor-pointer flex items-center"
          style={{ fontFamily: "Calibri " }}
          onClick={() => handleToggleChange(expression.id)}
        >
          <ArrowsRightLeftIcon className="w-5 h-5 mr-2 text-blue-500" />
          {expression.isLabelConstant
            ? "Change to Field"
            : "Change to Constant"}
          <span className="text-red-500">*</span>
        </label>
    
        {/* Toggle between input field and dropdown */}
        {expression.isLabelConstant ? (
          // When toggled to "Change to Constant"
          <>
            {isPercentageField ? (
              // Show percentage dropdown for percentage-related fields
              <Select
                options={generatePercentageOptions()}
                value={
                  expression.constant
                    ? {
                        value: expression.constant,
                        label: `${expression.constant}%`,
                      }
                    : null
                }
                onChange={(selectedOption) => {
                  setExpressionBuilderFields((prevFields) =>
                    prevFields.map((field) =>
                      field.id === expression.id
                        ? { ...field, constant: selectedOption?.value || "" }
                        : field
                    )
                  );
                }}
                className="flex-1 mt-2"
                styles={DropdownStyles}
                placeholder="Select percentage"
                menuPlacement="top"
                isClearable
                isDisabled={["HAS VALUE", "HAS NO VALUE"].includes(expression.condition)}
              />
            ) : (
              // Show regular text input for non-percentage fields
              <div className="flex flex-col sm:flex-row sm:items-center space-y-2 sm:space-y-0 sm:space-x-2 mt-2">
                <input
                  type="text"
                  className={`p-2 border border-gray-300 rounded ${
                    expression.showUnitDropdown 
                      ? "w-full sm:w-3/4" 
                      : "w-full"
                  }`}
                  placeholder="Enter value"
                  value={expression.constant}
                  onChange={(e) => {
                    const value = e.target.value;
                    setChangeToConstant(value);
                    setExpressionBuilderFields((prevFields) =>
                      prevFields.map((field) =>
                        field.id === expression.id
                          ? { ...field, constant: value }
                          : field
                      )
                    );
                  }}
                  disabled={["HAS VALUE", "HAS NO VALUE"].includes(expression.condition)}
                />
    
                {expression.showUnitDropdown && (
                  <Select
                    options={[
                      { value: "MB", label: "MB" },
                      { value: "GB", label: "GB" },
                    ]}
                    className="w-full sm:w-24"
                    styles={DropdownStyles}
                    onChange={(selectedOption) => {
                      setExpressionBuilderFields((prevFields) =>
                        prevFields.map((field) =>
                          field.id === expression.id
                            ? { ...field, unit: selectedOption?.value || "MB" }
                            : field
                        )
                      );
                    }}
                    menuPlacement="top"
                  />
                )}
              </div>
            )}
          </>
        ) : (
          // When toggled to "Change to Field"
          <Select
            // options={fieldTypeOptions}
            options={getFilteredFieldTypeOptions()} // Use filtered options
            placeholder="Field"
            className="flex-1 mt-2"
            styles={DropdownStyles}
            menuPlacement="top"
            value={
              expression.constant
                ? {
                    value: expression.constantId,
                    label: expression.constant,
                  }
                : null
            }
            onChange={(selectedOption) =>
              handleChangeExpressionField(
                expression.id,
                "constant",
                selectedOption || null
              )
            }
            isClearable
            isDisabled={["HAS VALUE", "HAS NO VALUE"].includes(expression.condition)}
          />
        )}
    
        {validationErrors[`expression_constant_${index}`] && (
          <span className="text-red-500 text-sm">
            {validationErrors[`expression_constant_${index}`]}
          </span>
        )}
      </div>
    );
  };
 

  return (
    <>
      <Modal
        title={
          <div className="mt-[-10px]">
            <span
              className="text-lg sm:text-xl font-semibold"
              style={{ fontFamily: "Calibri " }}
            >
              Notification Editor
            </span>
          </div>
        }
        visible={isVisible}
        centered
        onCancel={handleClose}
        footer={null}
        width={window.innerWidth < 640 ? '95%' : 900}
        bodyStyle={{
          paddingRight: "10px",
          overflowY: "auto",
          maxHeight: "75vh",
          padding: window.innerWidth < 640 ? "16px 12px" : "24px",
        }}
      >
        {isLoading ? (
          <div
            className="flex justify-center items-center"
            style={{
              height: modalHeight,
              overflowY: "auto",
              overflowX: "hidden",
            }}
          >
            <Spin size="large" />
          </div>
        ) : (
          
          <div className="space-y-4 sm:space-y-6">
           
            {/* Top Row - Rule ID, Name, Execution Order */}
            <div className="flex flex-col sm:flex-row sm:items-center gap-4">
              <div className="w-full sm:w-1/4">
               <label
    className="block text-sm"
    style={{ fontFamily: "Calibri" }}
  >
    Notification Type<span className="text-red-500">*</span>
  </label>
  <Select
    options={notificationTypeOptions}
    value={
      notificationType
        ? notificationTypeOptions.find((opt:any) => opt.value === notificationType)
        : null
    }
    onChange={(selectedOption) => setNotificationType(selectedOption?.value || "")}
    placeholder="Select..."
    // className="w-full mt-2"
    styles={DropdownStyles}
    menuPlacement="bottom"
    isClearable
  />
  {validationErrors.notificationType && (
    <span className="text-red-500 text-sm">
      {validationErrors.notificationType}
    </span>
  )}
              </div>
              <div className="w-full sm:w-1/4">
                <label
                  className="block text-sm "
                  style={{ fontFamily: "Calibri " }}
                >
                  Rule ID
                </label>
                <input
                  type="text"
                  disabled
                  placeholder="Auto-generated"
                  className="w-full p-2 border border-gray-300 rounded-md bg-gray-100 text-gray-700 non-editable-input"
                  value={ruleIdField}
                />
              </div>
              <div className="w-full sm:w-1/4">
                <label
                  className="block text-sm"
                  style={{ fontFamily: "Calibri " }}
                >
                  Name<span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  placeholder="Rule name"
                  className="w-full p-2 border border-gray-300 rounded-md input"
                  value={nameField}
                  onChange={handleNameChange}
                />
                {validationErrors.name && (
                  <span className="text-red-500 text-sm">
                    {validationErrors.name}
                  </span>
                )}
              </div>
              <div className="w-full sm:w-1/4">
                <label
                  className="text-sm flex items-center justify-between w-full"
                  style={{ fontFamily: "Calibri" }}
                >
                  <span className="flex items-center">
                    Execution Order<span className="text-red-500 ml-1">*</span>
                  </span>
                  <Tooltip title="Controls the Delivery Orders of Notifications">
                    <InformationCircleIcon className="w-4 h-4 text-gray-500 cursor-pointer" />
                  </Tooltip>
                </label>
                <input
                  type="number"
                  placeholder="Numeric value"
                  className="w-full p-2 border border-gray-300 rounded-md"
                  value={executionOrderField+1}
                  onChange={(e) => {
                    const value = Number(e.target.value);
                    if (value >= 0) {
                      setExecutionOrderField(value);
                    }
                  }}
                  min="0"
                  disabled
                />
              </div>
            </div>
  
            {/* Subject Line */}
            <div>
              <label
                className="text-sm flex items-center justify-between"
                style={{ fontFamily: "Calibri " }}
              >
                Subject Line
                <Tooltip title="Message for Notification Email Subject Line">
                  <InformationCircleIcon className="w-4 h-4 text-gray-500 cursor-pointer" />
                </Tooltip>
              </label>
              <input
                type="text"
                placeholder="Email subject"
                className="w-full p-2 border border-gray-300 rounded-md input"
                value={subjectLineField}
                onChange={(e) => setSubjectLineField(e.target.value)}
              />
            </div>
  
            {/* Message */}
            <div>
              <label
                className="text-sm flex items-center justify-between"
                style={{ fontFamily: "Calibri " }}
              >
                <div className="flex items-center gap-1">
                  <span>Message</span>
                  <span className="text-red-500">*</span>
                </div>
                <Tooltip title="Message for Notification Email Body">
                  <InformationCircleIcon className="w-4 h-4 text-gray-500 cursor-pointer" />
                </Tooltip>
              </label>
              <textarea
                placeholder="Email content"
                className="w-full p-2 border border-gray-300 rounded-md h-20 sm:h-24 resize-none"
                value={messageField}
                onChange={(e) => setMessageField(e.target.value)}
              ></textarea>
              {validationErrors.message && (
                <span className="text-red-500 text-sm">
                  {validationErrors.message}
                </span>
              )}
            </div>
  
            {/* Description */}
            <div>
              <label
                className="text-sm flex items-center justify-between"
                style={{ fontFamily: "Calibri " }}
              >
                <div className="flex items-center gap-1">
                  <span>Description</span>
                  <span className="text-red-500">*</span>
                </div>
                <Tooltip title="An Informational field for Internal and Historical Documentation is not Customer-Facing">
                  <InformationCircleIcon className="w-4 h-4 text-gray-500 cursor-pointer" />
                </Tooltip>
              </label>
              <textarea
                placeholder="Rule description"
                className="w-full p-2 border border-gray-300 rounded-md h-20 sm:h-24 resize-none"
                onChange={(e) => setDescriptionField(e.target.value)}
                value={descriptionField}
              ></textarea>
              {validationErrors.description && (
                <span className="text-red-500 text-sm">
                  {validationErrors.description}
                </span>
              )}
            </div>
  
            {/* Checkboxes */}
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-6">
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="sendToAdmin"
                  className="h-4 w-4"
                  checked={sendToSystem}
                  onChange={(e) => setSendToSystem(e.target.checked)}
                />
                <label
                  htmlFor="sendToAdmin"
                  className="text-sm"
                  style={{ fontFamily: "Calibri " }}
                >
                  Send to System Admin
                </label>
              </div>
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="showProjectedUsage"
                  className="h-4 w-4"
                  checked={showProjected}
                  onChange={(e) => setShowProjected(e.target.checked)}
                />
                <label
                  htmlFor="showProjectedUsage"
                  className="text-sm"
                  style={{ fontFamily: "Calibri " }}
                >
                  Show Projected Usage Cost
                </label>
              </div>
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="notifyCustomerGroup"
                  className="h-4 w-4"
                  checked={notifyCustomerGroup}
                  onChange={(e) => setNotifyCustomerGroup(e.target.checked)}
                />
                <label
                  htmlFor="notifyCustomerGroup"
                  className="text-sm"
                  style={{ fontFamily: "Calibri " }}
                >
                  Notify Customer Group
                </label>
              </div>
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="excludePooledDevices"
                  className="h-4 w-4"
                  checked={showExcludedPooledDevices}
                  onChange={(e) => setShowExcludedPooledDevices(e.target.checked)}
                />
                <label
                  htmlFor="excludePooledDevices"
                  className="text-sm"
                  style={{ fontFamily: "Calibri " }}
                >
                  Show Exclude pooled devices?
                </label>
              </div>
            </div>
              <div className="w-1/3">
                <label
                  className="block text-sm"
                  style={{ fontFamily: "Calibri " }}
                >
                  Send All Customer Notifications To Email
                </label>
                <input
                  type="text"
                  placeholder="Enter Email"
                  className="w-full p-2 border border-gray-300 rounded-md input"
                  value={sendAllCutomerNotificationsToEmail}
                  onChange={handleEmailChange}
                />
                {emailError && (
                  <p className="text-red-500 text-sm mt-1">{emailError}</p>
                )}
              </div>
  
            {/* Customers & Customer Groups */}
            <div className="flex flex-col sm:flex-row sm:items-start gap-4 w-full">
              <div className="w-full sm:w-1/3">
                <CustomersSelectComponent />
              </div>
  
              {/* All Customers Switch */}
              <div className="w-full sm:w-1/4 flex items-center space-x-3 sm:mt-8">
                <label
                  htmlFor="allCustomers"
                  className="flex items-center gap-3"
                  style={{ fontFamily: "Calibri " }}
                >
                  <span>All Customers</span>
                  <Switch
                    checked={isAllCustomers}
                    onChange={handleSwitchChange}
                  />
                </label>
              </div>
            </div>
  
            {/* Expression Builder */}
            <div>
              <h2
                className="text-base sm:text-lg font-semibold mb-3"
                style={{ fontFamily: "Calibri " }}
              >
                Expression Builder
              </h2>
  
              {expressionBuilderFields.map((expression, index) => (
                <div key={expression.id} className="mb-4">
                  <div className="flex flex-col sm:flex-row sm:items-center space-y-4 sm:space-y-0 sm:space-x-4 rounded-md">
                    {/* Field/Constant Toggle and Input */}
                    <div className="w-full sm:w-1/2">
                      <label
                        className="text-sm cursor-pointer flex items-center"
                        style={{ fontFamily: "Calibri " }}
                        onClick={() => handleToggle(expression.id)}
                      >
                        <ArrowsRightLeftIcon className="w-5 h-5 mr-2 text-blue-500" />
                        {expression.isLabel
                          ? "Change to Field"
                          : "Change to Constant"}
                        <span className="text-red-500">*</span>
                      </label>
  
                      {expression.isLabel ? (
                        <input
                          type="text"
                          className="flex-1 mt-3 p-2 border border-gray-300 rounded w-full"
                          placeholder="Enter value"
                          value={expression.field}
                          onChange={(e) => {
                            const value = e.target.value;
                            setChangeToField(value)
                            setExpressionBuilderFields((prevFields) =>
                              prevFields.map((field) =>
                                field.id === expression.id
                                  ? { ...field, field: value }
                                  : field
                              )
                            );
                          }}
                        />
                      ) : (
                        <Select
                          // options={fieldTypeOptions}
                          options={getFilteredFieldTypeOptions()} // Use filtered options
                          placeholder="Field"
                          className="flex-1 mt-2"
                          styles={DropdownStyles}
                          menuPlacement="top"
                          value={
                            expression.field
                              ? {
                                value: expression.fieldId,
                                label: expression.field
                              }
                              : null
                          }
                          onChange={(selectedOption) => {
                            handleChangeExpressionField(
                              expression.id,
                              "field",
                              selectedOption || null
                            )
                            const selectedValue = selectedOption?.label || '';
                            const dropdownTriggers = ['CtdDataUsage', 'Total Carrier Cycle Data Usage', 'Total Customer Cycle Data Usage'];
                            const showUnitDropdown = dropdownTriggers.some(value => selectedValue.startsWith(value));
                            setExpressionBuilderFields((prevFields) =>
                              prevFields.map((field, idx) =>
                                idx === index
                                  ? {
                                    ...field,
                                    field: selectedValue,
                                    unit: showUnitDropdown ? selectedOption?.label || "" : "", 
                                    showUnitDropdown,
                                  }
                                  : field
                              )
                            );
                          }}
                          isClearable
                        />
                      )}
                      {validationErrors[`expression_field_${index}`] && (
                        <span className="text-red-500 text-sm">
                          {validationErrors[`expression_field_${index}`]}
                        </span>
                      )}
                    </div>
  
                    {/* Condition Dropdown */}
                    <div className="w-full sm:w-1/4">
                      <label
                        className="text-sm flex items-center"
                        style={{ fontFamily: "Calibri " }}
                      >
                        Condition
                        <span className="text-red-500">*</span>
                      </label>
                      <Select
                        isSearchable
                        options={operationTypeOptions}
                        styles={DropdownStyles}
                        value={
                          expression.condition
                            ? {
                              value: expression.condition,
                              label: expression.condition,
                            }
                            : null
                        }
                        placeholder="Condition"
                        menuPlacement="top"
                        className="flex-1 mt-2"
                        onChange={(selectedOption) =>
                          handleChangeExpressionField(
                            expression.id,
                            "condition",
                            selectedOption || null
                          )
                        }
                        isClearable
                      />
                      {validationErrors[`expression_condition_${index}`] && (
                        <span className="text-red-500 text-sm">
                          {validationErrors[`expression_condition_${index}`]}
                        </span>
                      )}
                    </div>
  
                    {/* Second Field (renderSecondField equivalent) */}
                    {renderSecondField(expression, index)}
  
                 {/* Action Icons - Responsive positioning */}
                    <div className="flex sm:flex-col items-center gap-2 sm:gap-1 sm:mt-4 justify-center sm:justify-start">
                    <PlusCircleIcon
                      className="w-7 h-7 sm:w-8 sm:h-8 text-green-500 cursor-pointer"
                      onClick={addExpressionField}
                   />
                 {expressionBuilderFields.length > 1 && (
                    <MinusCircleIcon
                     className="w-7 h-7 sm:w-8 sm:h-8 text-red-500 cursor-pointer"
                     onClick={() => removeExpressionField(expression.id)}
                     />
                )}
                    </div>
                  </div>
  
                  {/* AND/OR Condition Dropdown */}
                  {index < expressionBuilderFields.length - 1 && (
                    <div className="rounded-md w-full sm:w-1/4 mb-3 mt-4">
                      <Select
                        options={[
                          { value: "AND", label: "AND" },
                          { value: "OR", label: "OR" },
                        ]}
                        placeholder="Select Condition"
                        className="w-full"
                        styles={DropdownStyles}
                        value={
                          selectedConditions[index]
                            ? {
                              value: selectedConditions[index],
                              label: selectedConditions[index],
                            }
                            : { value: "AND", label: "AND" }
                        } // Pass the whole object, not just the string
                        onChange={(selectedOption) =>
                          setSelectedConditions((prev) => {
                            const newConditions = [...prev];
                            newConditions[index] = selectedOption?.value || ""; // Default to an empty string if null
                            return newConditions;
                          })
                        }
                      />
                    </div>
                  )}
                  {/* {validationErrors[`expression_service_provider_field_${index}`] && (
                        <span className="text-red-500 text-sm">
                          {validationErrors[`expression_service_provider_field_${index}`]}
                        </span>
                      )} */}
                </div>
              ))}
            </div>
            {validationErrors['expression_service_provider_field'] && (
              <span className="text-red-500 text-sm">
                {validationErrors['expression_service_provider_field']}
              </span>
            )}

            {/* Footer Buttons */}
            <div className="flex justify-center gap-4 mt-6">
              <button onClick={onClose} className="cancel-btn">
                Cancel
              </button>
              <button className="save-btn" onClick={handleSave}>
                Save
              </button>
            </div>
          </div>
        )}
      </Modal>
    </>
  );
};

export default AddNotificationsModal;
