import React, { useEffect, useState } from "react";
import { Modal, Button, Input, Row, Col, Form, Spin } from "antd";

const EditEmailAuditTemplateModal: React.FC<{
  visible: boolean;
  onClose: () => void;
  rowData: any;
  isOpen: boolean;
  createModalData: any;
}> = ({ visible, onClose, rowData }) => {
  const [isLoading, setIsLoading] = useState(false);

  const modalHeight =
    typeof window !== "undefined" ? (window.innerHeight * 3) / 4 : 0;

  return (
    <Modal
      title={
        <div className="mt-[-10px]">
          <span className="text-[23px]">Email Audit Info</span>
        </div>
      }
      visible={visible}
      onCancel={onClose}
      footer={null}
      closable={true}
      width="90%"
      style={{ maxWidth: "800px" }}
      centered
    >
      {isLoading ? (
        <div className="flex justify-center items-center h-screen">
          <Spin size="large" />
        </div>
      ) : (
        <div
          style={{
            height: modalHeight,
            overflowY: "auto",
            overflowX: "hidden",
          }}
        >
          <div>
            <h2 className="text-[19px] font-medium ml-1 mb-4">Email Template</h2>
            <Form layout="vertical">
              <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
                <Col xs={24} sm={12} md={8}>
                  <Form.Item
                    label="Parent Module"
                    style={{ fontFamily: "Calibri, sans-serif" }}
                  >
                    <Input
                      style={{
                        resize: "none",
                      }}
                      className="non-editable-input"
                      value={rowData?.parents_module_name}
                      readOnly
                    />
                  </Form.Item>
                </Col>
                <Col xs={24} sm={12} md={8}>
                  <Form.Item
                    label="Sub Module"
                    style={{ fontFamily: "Calibri, sans-serif" }}
                  >
                    <Input
                      style={{
                        resize: "none",
                      }}
                      className="non-editable-input"
                      value={rowData?.sub_module_name}
                      readOnly
                    />
                  </Form.Item>
                </Col>
                <Col xs={24} sm={24} md={8}>
                  <Form.Item
                    label="Child Module"
                    style={{ fontFamily: "Calibri, sans-serif" }}
                  >
                    <Input
                      style={{
                        resize: "none",
                      }}
                      className="non-editable-input"
                      value={rowData?.child_module_name}
                      readOnly
                    />
                  </Form.Item>
                </Col>
              </Row>
              <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
                <Col xs={24} sm={12} md={8}>
                  <Form.Item
                    label="Template Types"
                    style={{ fontFamily: "Calibri, sans-serif" }}
                  >
                    <Input
                      style={{
                        resize: "none",
                      }}
                      value={rowData?.template_type}
                      className="non-editable-input"
                      readOnly
                    />
                  </Form.Item>
                </Col>
                <Col xs={24} sm={12} md={8}>
                  <Form.Item
                    label="Roles Based"
                    style={{ fontFamily: "Calibri, sans-serif" }}
                  >
                    <Input
                      style={{
                        resize: "none",
                      }}
                      value={rowData?.role}
                      className="non-editable-input"
                      readOnly
                    />
                  </Form.Item>
                </Col>
                <Col xs={24} sm={24} md={8}>
                  <Form.Item
                    label="Frequency"
                    style={{ fontFamily: "Calibri, sans-serif" }}
                  >
                    <Input
                      style={{
                        resize: "none",
                      }}
                      value={rowData?.email_frequency}
                      className="non-editable-input"
                      readOnly
                    />
                  </Form.Item>
                </Col>
              </Row>
            </Form>
          </div>

          <h2 className="text-[19px] font-medium mb-4 mt-6">Basic Information</h2>
          <div
            className="p-4 rounded-lg"
            style={{
              boxShadow:
                "0px -2px 4px rgba(0, 0, 0, 0.05), 0px 4px 6px rgba(0, 0, 0, 0.1)",
            }}
          >
            <Form layout="vertical" requiredMark={false}>
              <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
                <Col xs={24} sm={12} md={8}>
                  <Form.Item
                    label="Email Type"
                    style={{ fontFamily: "Calibri, sans-serif" }}
                  >
                    <Input
                      style={{
                        resize: "none",
                      }}
                      className="non-editable-input"
                      value={rowData?.email_type}
                      readOnly
                    />
                  </Form.Item>
                </Col>
                <Col xs={24} sm={12} md={8}>
                  <Form.Item
                    label="Template Name"
                    style={{ fontFamily: "Calibri, sans-serif" }}
                  >
                    <Input
                      style={{
                        resize: "none",
                      }}
                      className="non-editable-input"
                      value={rowData?.template_name}
                      readOnly
                    />
                  </Form.Item>
                </Col>
                <Col xs={24} sm={24} md={8}>
                  <Form.Item
                    label="Partner Name"
                    style={{ fontFamily: "Calibri, sans-serif" }}
                  >
                    <Input
                      style={{
                        resize: "none",
                      }}
                      className="non-editable-input"
                      value={rowData?.partner_name}
                      readOnly
                    />
                  </Form.Item>
                </Col>
              </Row>

              {/* Email Fields - Responsive Layout */}
              <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
                <Col span={24}>
                  <Form.Item
                    label={<span style={{ fontWeight: 'bold' }}>From</span>}
                    style={{ fontFamily: "Calibri, sans-serif" }}
                  >
                    <Input
                      readOnly
                      className="input non-editable-input"
                      value={rowData?.from_email}
                    />
                  </Form.Item>
                </Col>
              </Row>

              <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
                <Col span={24}>
                  <Form.Item
                    label={<span style={{ fontWeight: 'bold' }}>To</span>}
                    style={{ fontFamily: "Calibri, sans-serif" }}
                  >
                    <Input
                      readOnly
                      className="input non-editable-input"
                      value={rowData?.to_email}
                    />
                  </Form.Item>
                </Col>
              </Row>

              <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
                <Col span={24}>
                  <Form.Item
                    label={<span style={{ fontWeight: 'bold' }}>CC</span>}
                    style={{ fontFamily: "Calibri, sans-serif" }}
                  >
                    <Input
                      readOnly
                      className="input non-editable-input"
                      value={rowData?.cc_email}
                    />
                  </Form.Item>
                </Col>
              </Row>

              <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
                <Col span={24}>
                  <Form.Item
                    label={<span style={{ fontWeight: 'bold' }}>Subject</span>}
                    style={{ fontFamily: "Calibri, sans-serif" }}
                  >
                    <Input
                      readOnly
                      name="subject"
                      className="input non-editable-input"
                      value={rowData?.subject}
                    />
                  </Form.Item>
                </Col>
              </Row>

              {/* Body Section */}
              <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
                <Col span={24}>
                  <Form.Item
                    label={<span style={{ fontWeight: 'bold' }}>Body</span>}
                    style={{ fontFamily: "Calibri, sans-serif" }}
                  >
                    <Input.TextArea
                      rows={6}
                      style={{ resize: "none" }}
                      value={rowData?.body}
                      className="non-editable-input"
                      readOnly
                    />
                  </Form.Item>
                </Col>
              </Row>

              {/* Conditional Report Section */}
              {rowData?.reports_name && (
                <>
                  <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
                    <Col span={24}>
                      <Form.Item
                        label="Report Type"
                        style={{ fontFamily: "Calibri, sans-serif" }}
                      >
                        <Input
                          style={{
                            resize: "none",
                          }}
                          value={rowData?.reports_name}
                          className="non-editable-input"
                          readOnly
                        />
                      </Form.Item>
                    </Col>
                  </Row>
                  <Row gutter={[16, { xs: 8, sm: 16, md: 16 }]}>
                    <Col span={24}>
                      <Form.Item>
                        <Input.TextArea
                          rows={6}
                          style={{ resize: "none" }}
                          value={rowData?.body}
                          className="non-editable-input"
                          readOnly
                        />
                      </Form.Item>
                    </Col>
                  </Row>
                </>
              )}
            </Form>
          </div>

          {/* Action Buttons - Responsive */}
          <div className="flex justify-center mt-6 mb-4">
            <Button
              onClick={onClose}
              style={{ fontFamily: "Calibri, sans-serif" }}
              className="cancel-btn text-base border-none px-6"
            >
              Cancel
            </Button>
          </div>
        </div>
      )}
    </Modal>
  );
};

export default EditEmailAuditTemplateModal;