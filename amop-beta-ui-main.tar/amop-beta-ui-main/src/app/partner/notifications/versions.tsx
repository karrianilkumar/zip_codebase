import React, { lazy, Suspense, useCallback, useEffect, useRef, useState } from "react";
import { Modal, Input, Spin, notification } from 'antd';
import Select from 'react-select';
import { DropdownStyles } from '@/app/components/css/dropdown';
import { DatePicker } from 'antd';
import TableComponent from "@/app/components/TableComponent/page";
import { useAuth } from "@/app/components/auth_context";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { fireSideCannons } from "@/app/components/confetti";

const { RangePicker } = DatePicker;

interface VersionProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (formData: any) => void;
  ruleDefId: number | null;
  title: string;
}


const Versions: React.FC<VersionProps> = ({
  isOpen,
  onClose,
  onSave,
  ruleDefId,
  title,
}) => {
  const [isLoading, setIsLoading] = useState(false);

  const [data, setData] = useState<[]>([]);
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("General");
  const [generalFields, setGeneralFields] = useState();
  const [fieldsData, setFieldsData] = useState<any[]>([]);
  const [isExpanded, setIsExpanded] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, token, selectedDb,metaData, sessionId, settabledata, advancedStoredpagination, storedpagination, tenantName, tenantId, firstLastName , setStoredPagination , setAdvancedStoredPagination} = useAuth();
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [parsedData, setParsedData] = useState<any>(null);


 
  const hasFetchedData = useRef(false);
    const {
      iccid,
      bulkRow,
      features: moduleFeatures,
      setFeatures: setModuleFeatures,
      setICCID,
      setBulkRow
    } = useFeatureStore();

    type HeaderMap = Record<string, [string, number]>;

 const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);


  const handleSave = (event: React.FormEvent) => {
    event.preventDefault();
    const formData = new FormData(event.target as HTMLFormElement);
    const data = Array.from(formData.entries()).reduce(
      (acc, [key, value]) => ({ ...acc, [key]: value }),
      {}
    );
    onSave(data);
  };

  const handleCancelConfirmation = () => {
    setIsConfirmationOpen(false);
  };

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    
    console.log("fetchdata opened")
    let parsedData: any;
    try {
      setIsLoading(true);
      const url = ENV_ROUTES.NOTIFICATION_SERVICES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        rule_def_id: ruleDefId, 
        path: "/fetch_rule_versions",
        role_name: role,
        parent_module: "Partner",
        module_name: "Usage Notification",
        feature_module_name: "Usage Notification",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };
  
      const response = await axios.post(url, { data });
      console.log("API Response:", response.data); 
      parsedData = JSON.parse(response.data.body);
  
     if (parsedData.flag === true) {
             // Log data and set loading to false immediately to stop the loader
             console.log("table response:", parsedData);
             setParsedData(parsedData)
             if (parsedData && Array.isArray(parsedData.rule_version_data)) {
              // Format the data if rule_version_data is an array
              const formattedData = parsedData.rule_version_data.map((item:any) => ({
                date: item.created_date,  // Extracting date field
                createdBy: item.created_by,  // Extracting created_by field
                notes: item.notes,
                isActive:item.is_active ,
                fullRow: item,  
              }));
              setTableData(formattedData); 
            } else {
              console.error("parsedData.rule_version_data is not an array", parsedData);  // Error handling
            }
           } else {
            //  setLoading(false);
             Modal.error({
               title: "Data Fetch Error",
               content: parsedData.message || "An error occurred while fetching data. Please try again.",
               centered: true,
             });
           }
         } catch (error) {
          //  setLoading(false);
           Modal.error({
             title: "Data Fetch Error",
             content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
             centered: true,
           });
         } finally {
           setIsLoading(false);
         }
       
  };


  const handleRestore = async (row: any) => {
    console.log("tableData, row:", tableData, row);
    console.log("Accessing parsedData in handleRestore:", parsedData); // Access parsedData here
  
    if (!parsedData || !parsedData.rule_version_data) {
      console.error("No parsedData or records found");
      return;
    }
  
    // Find the record where `is_active` is true
    const activeRecord = parsedData.rule_version_data.find(
      (record: any) => record.is_active === true
    );
  
    if (!activeRecord) {
      console.error("No active record found in parsedData");
      return;
    }
  
    // Extract `id` and `version_no` for the active record
    const { current_id, current_version_no } = activeRecord;
    console.log("Active Record Found:", { activeRecord, current_version_no });
  
    const url = ENV_ROUTES.NOTIFICATION_SERVICES;

    const formData = {
      current_id:activeRecord.id,
      current_version:activeRecord.version_no,
      restore_id:row.id,
      restore_version:row.version_no,
      rule_def_id:activeRecord.rule_def_id

    };

    const data = {
      tenant_name: partner || "default_value",
      username: username,
      path: "/process_notification_rules",
      role_based: role,
      parent_module: "Partner",
      module_name: "Usage Notification",
      feature_module_name: "Usage Notification",
      partner: partner,
      action: "restore",
      changed_data: formData,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
    };

    try {
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      // setRuleDefId(parsedData.rule_def_id);

      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message || "An error occurred while saving the data.",
          centered: true,
        });
      } else {
        notification.success({
          message: 'Success',
          description: 'Restored successfully!',
          // style: messageStyle,
          placement: 'top',
        });
        fireSideCannons();
      }
      onClose();
    } catch (error) {
      Modal.error({
        title: "Error",
        content: "There was an error submitting the data.",
      });
    } finally {
      setIsLoading(false);
    }
  };


  const dropdownOptions = [
    { value: "option1", label: "Option 1" },
    { value: "option2", label: "Option 2" },
  ];

  const modalWidth =
    typeof window !== 'undefined' ? (window.innerWidth * 2.5) / 4 : 0;
  const modalHeight =
    typeof window !== 'undefined' ? (window.innerHeight * 2.5) / 4 : 0;

  if (!isOpen) return null;

 
  // if (loading) {
  //   return (
  //     <div className="flex justify-center items-center h-screen">
  //       <Spin size="large" />
  //     </div>
  //   );
  // }
  return (
    <div>
      <Modal
        open={isOpen}
        onCancel={onClose}
        title={
          <h3 className="popup-heading">
           Rule Version History
          </h3>
        }
        centered
        footer={
          <div className="justify-center flex space-x-2">
            <button onClick={onClose} className="cancel-btn">
              Cancel
            </button>
            {/* <button className="save-btn">Create</button> */}
          </div>
        }
        width={'800px'}
        styles={{ body: { height:  "400px " , padding: '2px' } }}
      >
       {isLoading ? (
          <div
            className="flex justify-center items-center"
            style={{
              height: modalHeight,
              overflowY: "auto",
              overflowX: "hidden",
            }}
          >
            <Spin size="large" />
          </div>):(

       <div className="table-container"
       style={{
        maxHeight: "400px", // Set the maximum height for the table container
        overflowY: "auto",  // Add vertical scrolling when content exceeds height
        padding: "4px", // Optional padding
      }}>
      <table className="table-auto w-full border-collapse border border-gray-300">
        <thead>
          <tr>
            <th className="px-4 py-2 border border-gray-300">Date</th>
            <th className="px-4 py-2 border border-gray-300">Created By</th>
            <th className="px-4 py-2 border border-gray-300">Notes</th>
            <th className="px-4 py-2 border border-gray-300">Actions</th>
          </tr>
        </thead>
        <tbody>
          {tableData.length === 0 ? (
            <tr>
              <td colSpan={3} className="px-4 py-2 text-center">
                No Data Available
              </td>
            </tr>
          ) : (
            tableData.map((row:any, index:any) => (
              <tr key={index}>
                <td className="px-4 py-2 border border-gray-300 text-center">{row.date}</td>
                <td className="px-4 py-2 border border-gray-300 text-center">{row.createdBy}</td>
                <td className="px-4 py-2 border border-gray-300 text-center">{row.notes}</td>
                <td className="px-4 py-2 border border-gray-300 text-center">
                {row.isActive  ? (
                 ""
                ) : (
                  
                  <button className="save-btn" onClick={() => handleRestore(row.fullRow)}>
                  Restore
                </button>
                )}
              </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  )}
      </Modal>

      
    </div>
  );
};

export default Versions;




