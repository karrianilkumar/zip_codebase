"use client";

import React, { useEffect, useState } from "react";
import { usePartnerStore } from "../partnerStore";
import { EyeIcon, EyeSlashIcon } from "@heroicons/react/24/outline";
import { Button, Modal, notification, Spin } from "antd";
import Select from "react-select";
import { useAuth } from "@/app/components/auth_context";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { DropdownStyles } from "@/app/components/css/dropdown";
import { fireSideCannons } from "@/app/components/confetti";

// Settings definition with type
const settings = [
  { label: 'Auto Update Rateplans', key: "auto_update_rateplans", type: 'True/False' },
  { label: 'Carrier Optimization Email Subject', key: "carrier_optimization_email_subject", type: 'Text Field' },
  { label: 'Carrier Optimization From Email Address', key: "carrier_optimization_from_email_address", type: 'Text Field' },
  { label: 'Carrier Optimization OU', key: "carrier_optimization_ou", type: 'Text Field' },
  { label: 'Carrier Optimization To Email Address', key: "carrier_optimization_to_email_address", type: 'Text Field' },
  { label: 'Customer Optimization Email Subject', key: "customer_optimization_email_subject", type: 'Text Field' },
  { label: 'Customer Optimization From Email Address', key: "customer_optimization_from_email_address", type: 'Text Field' },
  { label: 'Customer Optimization To Email Address', key: "customer_optimization_to_email_address", type: 'Text Field' },
  { label: 'Go For RatePlan Update Email Subject', key: "go_for_rateplan_update_email_subject", type: 'Text Field' },
  { label: 'Linux TimeZone', key: "linux_timezone", type: 'Text Field' },
  { label: 'No Go For RatePlan Update Email Subject', key: "no_go_for_rate_plan_update_email_subject", type: 'Text Field' },
  { label: 'Optimization BCC Email Addresses', key: "optimization_bcc_email_address", type: 'Text Field' },
  { label: 'Optimization Per Revio Dates', key: "optimization_per_revio_dates", type: 'True/False' },
  { label: 'Optimization Sync Device Error Email Subject', key: "optimization_sync_device_error_email_subject", type: 'Text Field' },
  { label: 'Optinto Continuous Last Day Optimization', key: "optino_continous_last_day_optimization", type: 'True/False' },
  { label: 'Optinto Cross Provider Customer Optimization', key: "optino_cross_providercustomer_optimization", type: 'True/False' },
  { label: 'Using New Process In Customer Charge', key: "using_new_process_in_customer_charge", type: 'True/False' },
  { label: 'Windows TimeZone', key: "windows_timezone", type: 'Text Field' },
  { label: 'Billing Push Customer Charge Type', key: "rev_io_push_customer_charge_type", type: 'Dropdown' },
  { label: 'Billing FTP Host', key: "revio_ftp_host", type: 'Text Field' },
  { label: 'Billing FTP Password', key: "revio_ftp_password", type: 'password' },
  { label: 'Billing FTP Path', key: "rev_io_ftp_path", type: 'Text Field' },
  { label: 'Billing FTP Username', key: "revio_ftp_username", type: 'Text Field' },
  { label: 'Pushing Pooled SIM Charges', key: "pushed_pooled_sim_charges", type: 'True/False' },

];


const messageStyle = {
  fontSize: '14px',
  fontWeight: 'bold',
  padding: '16px',
};

// Define the type of the form values
const OptimizationSettings: React.FC = () => {

  const [loading, setLoading] = useState(false);
  const { username, role, partner, token, selectedDb, metaData,firstLastName, sessionId, isSubTenant } = useAuth();
  const [subTenantOptions, setSubTenantOptions] = useState<any>([])
  const [subTenant, setSubTenant] = useState<any | null>(null)
  const isAdmin = role?.toLowerCase() === "super admin" || role?.toLowerCase() === "partner admin"

  const filteredSettings = isSubTenant
  ? settings.filter(setting =>
      setting.label === 'Optinto Cross Provider Customer Optimization' ||
      setting.label === 'Optimization Per Revio Dates'
  )
  : isAdmin
    ? settings
    : settings.filter(setting =>
        !setting.label.toLowerCase().includes("carrier")
      );


  // Initialize state with an object that matches the `FormValues` type
  // const [formValues, setFormValues] = useState<any>(
  //   settings.reduce((acc, setting) => {
  //     if (setting.type === 'True/False') {
  //       acc[setting.key] = false; // Default is false (unchecked)
  //     } else {
  //       acc[setting.key] = ""; // Initialize Text Fields with empty string
  //     }
  //     return acc;
  //   }, {} as FormValues)
  // );
  const [formValues, setFormValues] = useState<any>([])
  const [initialFormValues, setInitialFormValues] = useState<any>([])
  
  const fetchData = async () => {
    try {
      setLoading(true);
      const url = ENV_ROUTES.MODULE_MANAGEMENT
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_optimization_setting_details",
        role_name: role,
        parent_module: "Partner",
        modules_list: ["Optimization settings"],
        feature_module_name: "Partner Info",
        pages: {
          "Customer groups": { start: 0, end: 100 },
          "Partner users": { start: 0, end: 100 },
        },
        access_token: token,
        db_name: selectedDb,
          ...metaData,
        sessionID: sessionId,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        setLoading(false);
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      } else {
        setLoading(false);
        const optimization_setting_data =
          parsedData?.optimization_setting_data.length > 0 ? parsedData?.optimization_setting_data[0] : [];
        setFormValues(optimization_setting_data)
        setInitialFormValues(optimization_setting_data)

        const sub_tenant_options = parsedData?.tenant_details?.sub_tenants || []
        setSubTenantOptions(sub_tenant_options)

      }
    } catch (error) {
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    }
  };
  const fetchSubTenantData = async () => {
    try {
      setLoading(true);
      const url = ENV_ROUTES.MODULE_MANAGEMENT
      const data = {
        tenant_name:subTenant?subTenant: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_optimization_setting_details",
        role_name: role,
        parent_module: "Partner",
        modules_list: ["Optimization settings"],
        feature_module_name: "Partner Info",
        pages: {
          "Customer groups": { start: 0, end: 100 },
          "Partner users": { start: 0, end: 100 },
        },
        access_token: token,
        db_name: selectedDb,
          ...metaData,
        sessionID: sessionId,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        setLoading(false);
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      } else {
        setLoading(false);
        const optimization_setting_data =
          parsedData?.optimization_setting_data.length > 0 ? parsedData?.optimization_setting_data[0] : [];
        setFormValues(optimization_setting_data)
      }
    } catch (error) {
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    }
  };

  useEffect(() => {
    fetchSubTenantData();
  }, [subTenant]);

  useEffect(() => {
    fetchData();
  }, []);

  const handleChange = (key: string, value: string | boolean) => {
    setFormValues((prevValues: any) => ({
      ...prevValues,
      [key]: value,
    }));
  };

  const callRunDBScript = async (formData: any) => {
    const url = ENV_ROUTES.SIM_MANAGEMENT;
    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/run_db_script",
      role_name: role,
      module_name: "Optimization Settings",
      access_token: token,
      db_name: selectedDb,
          ...metaData,
      sessionID: sessionId,
      update_flag: true,
      delete_flag: false,
      transfer_name: "optimization_setting",
      request_received_at: getCurrentDateTime(),
      Partner: partner || "default_value",
      data: {
        optimization_setting: [{
          ...formData,
          salt: "",
        }]
      },
    };

    try {
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
    } catch (error) {
    }

  }

  const getChangedFormValues = (
    initialValues: Record<string, any>,
    currentValues: Record<string, any>
  ) => {
    const changedValues: Record<
      string,
      { old_value: any; new_value: any }
    > = {};

    Object.keys(currentValues).forEach((key) => {
      const oldValue = initialValues[key];
      const newValue = currentValues[key];

      // Skip if key does not exist in initial values
      if (oldValue === undefined) return;

      // Compare values (string-safe)
      if (oldValue !== newValue) {
        changedValues[key] = {
          old_value: oldValue,
          new_value: newValue,
        };
      }
    });

    return changedValues;
  };


  const submitData = async () => {
    const changed_form_values = getChangedFormValues(
      initialFormValues,
      formValues
    );
    try {
      const changedData = { ...formValues }
      changedData["modified_by"] = username
      changedData["created_by"] = username
      changedData["created_date"] = getCurrentDateTime
      changedData["modified_date"] = getCurrentDateTime

      setLoading(true);
      const url = ENV_ROUTES.MODULE_MANAGEMENT
      const data = {
        tenant_name:subTenant?subTenant: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/update_optimization_setting_details",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
          ...metaData,
        sessionID: sessionId,
        changed_data: { ...changedData },
        updated_fields: {... changed_form_values}
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        setLoading(false);
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while submitting data. Please try again.",
          centered: true,
        });
      } else {
        callRunDBScript(changedData)
        setLoading(false);
        fetchData();
        notification.success({
          message: 'Success',
          description: 'Successfully saved.',
          style: messageStyle,
          placement: 'top',
        });
        fireSideCannons()
      }
    } catch (error) {
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while submitting data. Please try again.",
        centered: true,
      });
    }
    finally {
      setLoading(false)
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  const handleSubTenantChange = (selectedOption: any) => {
    if (selectedOption) {
      const value=selectedOption?.value
      setSubTenant(value)
    }
    else {
      setSubTenant(null)
    }
  }
  return (
    <><div className="optimization-settings-form  p-6">
      {/* <div className="grid grid-cols-2 gap-x-4 mb-4">

      <div className="mr-4">
          <label className="field-label"> Partner </label>
          <input
            className="non-editable-input"
            type="text"
            value={partner || ""}
            disabled
          />
        </div>
        <div className="ml-[-10px]">
          <label className="field-label"> Sub Partner </label>
          <Select
            styles={DropdownStyles}
            className="w-full"
            options={subTenantOptions.map((option: any) => ({ label: option, value: option }))}
            value={{ label: subTenant, value: subTenant }}
            onChange={handleSubTenantChange}
            placeholder="Select Sub Partner"
            isClearable
            isSearchable

          />
        </div>
      </div>  //Manideep */}  
      
      <form className="grid grid-cols-2  gap-y-2">
        {/* Header for Setting Key */}
        <div className="font-bold text-lg">Setting Key</div>
        <div className="font-bold text-lg">Setting Value</div>

        {filteredSettings.map(({ key, type, label }) => (
          <React.Fragment key={key}>
            {/* Setting Key (Left Column) */}
            <div className="field-label">{label}</div>

            {/* Setting Value (Right Column) */}
            <div className="flex items-center space-x-4 mt-1">
              {type === 'True/False' ? (
                <div className="flex items-center">
                  {/* False Label and Checkbox */}
                  <label className="field-label mr-2">False</label>
                  <input
                    type="checkbox"
                    checked={formValues[key] === "False"}
                    onChange={(e) => handleChange(key, e.target.checked ? "False" : formValues[key])}
                    className="custom-checkbox mr-4"
                  />

                  {/* True Label and Checkbox */}
                  <label className="field-label mr-4">True</label>
                  <input
                    type="checkbox"
                    checked={formValues[key] === "True"}
                    onChange={(e) => handleChange(key, e.target.checked ? "True" : formValues[key])}
                    className="custom-checkbox"
                  />
                </div>

              ) : type === "Dropdown" ? (
                <Select
                  styles={DropdownStyles}
                  value={
                    formValues[key]
                      ? { label: formValues[key], value: formValues[key] }
                      : null
                  } onChange={(selectedOption) =>
                    handleChange(key, selectedOption ? selectedOption.value : formValues[key])
                  }
                  className="w-full"
                  options={[
                    { label: "CDR", value: "CDR" },
                    { label: "Non-Recurring Charge", value: "Non-Recurring Charge" },
                  ]}
                />

              ) : type === "password" ? (
                <input
                  type="password"
                  value={formValues[key] !== "None" ? (formValues[key] as string) : ""}
                  onChange={(e) => handleChange(key, e.target.value)}
                  className="input" />

              )
                : (
                  <input
                    type="text"
                    value={formValues[key] !== "None" ? (formValues[key] as string) : ""}
                    onChange={(e) => handleChange(key, e.target.value)}
                    className="input" />
                )}
            </div>
          </React.Fragment>
        ))}
      </form>
    </div><div className="flex justify-end space-x-2  p-4" key="buttons">

        <button
          key="update"
          onClick={submitData}
          className="save-btn  text-base border-none"
          style={{ fontFamily: "Calibri, sans-serif" }}
        >
          Save
        </button>
      </div></>
  );
};

export default OptimizationSettings;
