import React, { useEffect, useState } from "react";
import { Modal, DatePicker, Select, Checkbox, Spin } from "antd";
import { ChevronDownIcon } from "@heroicons/react/24/outline";
import { useAuth } from "@/app/components/auth_context";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { fireSideCannons } from "@/app/components/confetti";

interface AddServiceProviderProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: () => void;

  // onSubmit: (values: any) => void;
}

// Define options interfaces
interface SelectOption {
  value: string;
  label: string;
}

interface FilterOptions {
  options: any[];
}

const AddServiceProvider: React.FC<AddServiceProviderProps> = ({
  isOpen,
  onClose,
  onSave
  // onSubmit,
}) => {
  const [isOptimizationEnabled, setIsOptimizationEnabled] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [validationErrors, setValidationErrors] = useState<{
    [key: string]: string;
  }>({});

  // State for form fields
  const [integrationOptions, setIntegrationOptions] = useState<SelectOption[]>(
    []
  );
  const [integration, setIntegration] = useState<string>();
  const [serviceProviderName, setServiceProviderName] = useState("");
  const [billPeriodEndDay, setBillPeriodEndDay] = useState<
    number | undefined
  >();
  const [billPeriodEndHour, setBillPeriodEndHour] = useState<
    number | undefined
  >();
  const [optimizationStartHour, setOptimizationStartHour] = useState<
    number | undefined
  >();

  const {
    username,
    tenantNames,
    role,
    settabledata,
    setStoredPagination,
    token,
    partner,
    selectedDb,
    metaData,
    firstLastName,
    sessionId,
    tenantId
  } = useAuth();

  const handleCheckboxChange = () => {
    setIsOptimizationEnabled(!isOptimizationEnabled);
  };

  useEffect(() => {
    fetchFilterOptions();
  }, []);

  const resetForm = () => {
    console.log("reset")
    setValidationErrors({}); 
    setIntegration("");
    setServiceProviderName("");
    setBillPeriodEndDay(undefined);
    setBillPeriodEndHour(undefined);
    setOptimizationStartHour(undefined);
    setIsOptimizationEnabled(false);
  };

  const validateForm = () => {
    const errors: Record<string, string> = {};

    // Validate service provider name
    if (!serviceProviderName.trim()) {
      errors.service_provider_name = "Service provider name is required.";
    }

    // // Validate integration selection
    if (!integration) {
      errors.integration = "Integration is required.";
    }

    // Validate bill period end day
    if (!billPeriodEndDay) {
      errors.bill_period_end_day = "Bill period end day is required!";
    } else if (billPeriodEndDay < 1 || billPeriodEndDay > 28) {
      errors.bill_period_end_day =
        "Bill period end day must be between 1 and 28";
    }

    // Validate bill period end hour
    if (billPeriodEndHour=== null || 
      billPeriodEndHour=== undefined) {
      errors.bill_period_end_hour = "Bill period end hour is required!";
    } else if (billPeriodEndHour < 0 || billPeriodEndHour > 23) {
      errors.bill_period_end_hour =
        "Bill period end hour must be between 0 and 23";
    }

    // Validate optimization start hour
    // if (!optimizationStartHour) {
    //   errors.optimization_start_hour = "Optimization start hour is required!";
    // }
    if (optimizationStartHour && (optimizationStartHour < 0 || optimizationStartHour > 23)) {
      errors.optimization_start_hour =
        "Optimization start hour must be between 0 and 23";
    }

    return errors;
  };

  const fetchFilterOptions = async () => {
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/service_provider_list_view",
        role_name: role,
        parent_module: "Partner",
        feature_module_name: "Partner Info",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      const integrationList = parsedData.integration_list;

      // Transform integration list into Select options
      const serviceProviders = integrationList.map((provider: any) => {
        const [key, value] = Object.entries(provider)[0];
        return { value, label: key };
      });
      setIntegrationOptions(serviceProviders);
    } catch (error) {
      console.error(error);
    }
  };

  const handleClose = () => {
    resetForm(); // Reset form state
    onClose(); // Notify parent to close the modal
  };
  const callRunDBScript = async (formData: any) => {
    const tenant_id_ = localStorage.getItem("tenant_id") || "0";
    const url = ENV_ROUTES.SIM_MANAGEMENT;
    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/run_db_script",
      role_name: role,
      module_name: "Service Provider",
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
      update_flag: false,
      delete_flag: false,
      request_received_at: getCurrentDateTime(),
      Partner: partner || "default_value",
      data: {
        serviceprovider: [{

          ...(formData.id && { id: formData.id }),
          ...(formData.service_provider_name && { service_provider_name: formData.service_provider_name }),
          ...(formData.integration_id && { integration_id: formData.integration_id }),
          ...(formData.bill_period_end_day && { bill_period_end_day: formData.bill_period_end_day }),
          ...(formData.bill_period_end_hour && { bill_period_end_hour: formData.bill_period_end_hour }),
          ...(formData.optimization_start_hour_local_time && { optimization_start_hour_local_time: formData.optimization_start_hour_local_time }),
          ...(formData.service_provider_name && { display_name: formData.service_provider_name }),
          modified_by: firstLastName,
          modified_date: getCurrentDateTime(),
          created_by:firstLastName,
          created_date: getCurrentDateTime(),
          is_active:true,
          ...(formData.id && { id: formData.id }),
          is_deleted: false,
          ...(formData.write_is_enabled && { write_is_enabled: formData.write_is_enabled }),
          tenant_id: typeof tenantId === "string" ? Number(tenantId) : tenantId || Number(tenant_id_) ,
        }]
      },
    };

    try {
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
    } catch (error) {
    }

  }


  const handleSave = async () => {
    const errors = validateForm();
    setValidationErrors(errors);
    // If errors exist, abort the save process
    if (Object.keys(errors).length > 0) {
      return;
    }
    setIsLoading(true);
    const url = ENV_ROUTES.MODULE_MANAGEMENT;
    const formData = {
      integration_id: integration,
      service_provider_name: serviceProviderName,
      bill_period_end_day: billPeriodEndDay,
      bill_period_end_hour: billPeriodEndHour,
      optimization_start_hour_local_time: optimizationStartHour,
      write_is_enabled: isOptimizationEnabled,
      is_active: true,
      is_deleted: false,
      created_by:firstLastName || username,
    };

    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName : firstLastName,
      path: "/submit_update_edit_service_provider",
      role_based: role,
      parent_module: "Partner",
      module_name: "Partner info",
      partner: partner,
      action: "create",
      table_name: "serviceprovider",
      new_data: formData,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
    };
    console.log(formData, "Show formData")
    try {
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      callRunDBScript(formData)
      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message || "An error occurred while saving the data.",
          centered: true,
        });
      } else {
        fetchData()
        Modal.success({
          title: "Success",
          content: "Data submitted successfully!",
        });
        fireSideCannons()
      }
      handleClose();
      onSave()
    } catch (error) {
      Modal.error({
        title: "Error",
        content: "There was an error submitting the data.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const fetchData = async () => {
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/service_provider_list_view",
        role_name: role,
        parent_module: "Partner",
        feature_module_name: "Partner Info",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name:selectedDb,
        ...metaData,
        sessionID: sessionId,
      };
      console.log(getCurrentDateTime(),"Show the log time request sent from ui to lambda");
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      console.log(getCurrentDateTime(),"Show the log time response sent from lambda to ui");
      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching Inventory data. Please try again.",
          centered: true,
        });
      } else {
        const tableData_ = parsedData?.data || [];
        settabledata(tableData_)

      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
    }
  };
  const modalHeight =
    typeof window !== "undefined" ? (window.innerHeight * 4.5) / 4 : 0;

  return (
    <Modal
      title={
        <div className="mt-[-10px]">
          <span
            className="text-[23px]"
            style={{ fontFamily: "Calibri, sans-serif" }}
          >
            Add Service Provider
          </span>
        </div>
      }
      open={isOpen}
      onCancel={handleClose}
      footer={null}
      centered
      width={800}
    >
      <>
        {isLoading ? (
          <>
            <div
              className="flex justify-center items-center"
              style={{
                height: "295px",
              }}
            >
              <Spin size="large" />
            </div>
          </>
        ) : (
          <>
            {" "}
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label
                    className="field-label"
                    style={{ fontFamily: "Calibri, sans-serif" }}
                  >
                    Integration
                    <span className="text-red-500">*</span>
                  </label>
                  <Select
                    showSearch
                    filterOption={(input:any, option:any) =>
                      option?.label.toLowerCase().includes(input.toLowerCase())
                    }
                    notFoundContent="no options avilable"
                    placeholder="Select integration"
                    suffixIcon={
                      <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
                    }
                    className=" w-full"
                    style={{ height: "43px" }}
                    value={integration}
                    onChange={(value) => setIntegration(value)}
                    options={integrationOptions}
                    
                  ></Select>
                  {validationErrors.integration && (
                    <span className="text-red-500 mt-2">
                      {validationErrors.integration}
                    </span>
                  )}
                </div>

                <div>
                  <label
                    className="field-label "
                    style={{ fontFamily: "Calibri, sans-serif" }}
                  >
                    Service Provider Name
                    <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    className="input w-full"
                    placeholder="Enter service provider name"
                    value={serviceProviderName}
                    onChange={(e) => setServiceProviderName(e.target.value)}
                  />
                  {validationErrors.service_provider_name && (
                    <span className="text-red-500 mt-2">
                      {validationErrors.service_provider_name}
                    </span>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label
                    className="field-label"
                    style={{ fontFamily: "Calibri, sans-serif" }}
                  >
                    Bill Perid End Day(1-28)
                    <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    className="input w-full"
                    placeholder="Enter bill period end day"
                    min={1}
                    max={28}
                    onInput={(e) => {
                      const value = parseInt(e.currentTarget.value);
                      if (value < 1) e.currentTarget.value = "";
                    }}
                    value={billPeriodEndDay ?? ""}
                    onChange={(e) =>
                      setBillPeriodEndDay(Number(e.target.value))
                    }
                  />
                  {validationErrors.bill_period_end_day && (
                    <span className="text-red-500 mt-2">
                      {validationErrors.bill_period_end_day}
                    </span>
                  )}
                </div>

                <div>
                  <label
                    className="field-label"
                    style={{ fontFamily: "Calibri, sans-serif" }}
                  >
                    Bill Period End Hour(0-23)
                    <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    className="input w-full"
                    placeholder="Enter bill period end hour"
                    min={0}
                    max={23}
                    onInput={(e) => {
                      const value = parseInt(e.currentTarget.value);
                      if (value < 0) e.currentTarget.value = "";
                    }}
                    value={billPeriodEndHour ?? ""}
                    onChange={(e) =>
                      setBillPeriodEndHour(Number(e.target.value))
                    }
                  />
                  {validationErrors.bill_period_end_hour && (
                    <span className="text-red-500 mt-2">
                      {validationErrors.bill_period_end_hour}
                    </span>
                  )}
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label
                    className="field-label"
                    style={{ fontFamily: "Calibri, sans-serif" }}
                  >
                    Optimization Start Hour(0-23)
                    {/* <span className="text-red-500">*</span> */}
                  </label>
                  <input
                    type="number"
                    className="input"
                    placeholder="Enter optimization start hour"
                    min={0}
                    max={23}
                    onInput={(e) => {
                      const value = parseInt(e.currentTarget.value);
                      if (value < 0) e.currentTarget.value = "";
                    }}
                    value={optimizationStartHour ?? ""}
                    onChange={(e) =>
                      setOptimizationStartHour(Number(e.target.value))
                    }
                  />
                  {validationErrors.optimization_start_hour && (
                    <span className="text-red-500 mt-2">
                      {validationErrors.optimization_start_hour}
                    </span>
                  )}
                </div>
                {/* <div className="flex m-8">
            <input
                type="checkbox"
                className="ml-3 mt-2 w-3.5 h-3.5"
                id="optimization-checkbox"
                checked={isOptimizationEnabled}
                onChange={handleCheckboxChange}
              />  
            <label className="field-label">Write enabled</label>
            
            </div> */}
                <div className="mt-8">
                  <Checkbox
                    checked={isOptimizationEnabled}
                    onChange={handleCheckboxChange}
                    className="checkbox"
                  >
                    Write Enabled
                  </Checkbox>
                </div>
              </div>

              <div className="flex justify-center gap-2 mt-6">
                <button
                  onClick={handleClose}
                  className="cancel-btn"
                  style={{ fontFamily: "Calibri, sans-serif" }}
                >
                  Cancel
                </button>
                <button
                  onClick={handleSave}
                  className="save-btn"
                  style={{ fontFamily: "Calibri, sans-serif" }}
                >
                  Save
                </button>
              </div>
            </div>
          </>
        )}
      </>
    </Modal>
  );
};
export default AddServiceProvider;
