import React, { useState } from 'react';
import { Modal, Spin } from 'antd';
import { useAuth } from '@/app/components/auth_context';
import { ENV_ROUTES } from '@/app/components/routes/route_constants';
import axios from 'axios';
import { getCurrentDateTime } from '@/app/components/header_constants';
import { dataTagSymbol } from '@tanstack/react-query';
import { fireSideCannons } from '@/app/components/confetti';

interface QualificationAuthenticateModalProps {
    isOpen: boolean;
    onCancel: () => void;
    connection: string;
    details: any;
    onSave: () => void;
    callSync: () => void;
}

const QualificationAuthenticateModal: React.FC<QualificationAuthenticateModalProps> = ({
    isOpen,
    onCancel,
    connection,
    details,
    onSave,
    callSync
}) => {
    const [isLoading, setIsLoading] = useState(false);
    const [clientId, setClientId] = useState('');
    const [clientSecret, setClientSecret] = useState('');
    const [isConfirmOpen, setIsConfirmOpen] = useState(false);
    const [errors, setErrors] = useState<Record<string, string>>({});
    const {
        username: user_name,
        tenantNames,
        role,
        settabledata,
        setStoredPagination,
        token,
        partner,
        selectedDb,
        metaData,
        firstLastName,
        sessionId,
    } = useAuth();

    const handleValidation = () => {
        const newErrors: Record<string, string> = {};
        if (!clientId.trim()) newErrors.clientId = 'Client ID is mandatory';
        if (!clientSecret.trim()) newErrors.clientSecret = 'Client Secret is mandatory';
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = () => {
        if (handleValidation()) {
            setIsConfirmOpen(true);
        }
    };

    const handleConfirmSubmit = async () => {
        setIsConfirmOpen(false);
        if (Object.keys(errors).length > 0) return;

        setIsLoading(true);
        if (details) {
            details["oauth2_client_id"] = clientId;
            details["oauth2_client_secret"] = clientSecret;
            details["modified_by"] = user_name
            details['modified_date'] = getCurrentDateTime()
        }

        const data = {
            tenant_name: partner || "default_value",
            username: user_name,
            firstLastName: firstLastName,
            path: "/save_integration_details",
            role_based: role,
            parent_module: "Partner",
            module_name: "Partner info",
            partner: partner,
            action: "create",
            table_name: "serviceprovider",
            changed_data: details,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
            ...metaData,
            sessionID: sessionId,
            service_provider_name:connection || ""
        };

        try {
            let url = ENV_ROUTES.MODULE_MANAGEMENT;
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                Modal.error({
                    title: "Submit Error",
                    content: parsedData.message || "An error occurred while saving the data.",
                    centered: true,
                });
            } else {
                callSync()
                Modal.success({
                    title: "Success",
                    content: "Data submitted successfully!",
                });
                fireSideCannons()
            }
            handleCancel();
        } catch (error) {
            Modal.error({
                title: "Error",
                content: "There was an error submitting the data.",
            });
        } finally {
            setIsLoading(false);
            onSave()
        }
    };

    const handleCancel = () => {
        onCancel();
        setIsConfirmOpen(false);
    };

    const handleCancelConfirm = () => {
        setIsConfirmOpen(false);
    };

    return (
        <>
            <Modal
                title="Authentication"
                visible={isOpen}
                onCancel={onCancel}
                width={500}
                centered
                footer={
                    <div className="flex justify-center space-x-4">
                        <button onClick={onCancel} className="cancel-btn">
                            Cancel
                        </button>
                        <button className="save-btn" onClick={handleSubmit}>
                            Save
                        </button>
                    </div>
                }
            >
                {isLoading ? (
                    <div className="flex justify-center items-center" style={{ height: "195px" }}>
                        <Spin size="large" />
                    </div>
                ) : (
                    <div className="space-y-4">
                        <div className="flex items-center mb-4">
                            <label className="w-1/4 text-sm font-medium">
                                Client ID <span className="text-red-500">*</span>
                            </label>
                            <div className="inline w-3/4">
                                <input
                                    type="text"
                                    value={clientId}
                                    onChange={(e) => setClientId(e.target.value)}
                                    className="input"
                                    placeholder="Enter Client ID"
                                />
                                {errors.clientId && (
                                    <div className="text-red-500 text-xs mt-1">{errors.clientId}</div>
                                )}
                            </div>
                        </div>

                        <div className="flex items-center mb-4">
                            <label className="w-1/4 text-sm font-medium">
                                Client Secret <span className="text-red-500">*</span>
                            </label>
                            <div className="inline w-3/4">
                                <input
                                    type="password"
                                    value={clientSecret}
                                    onChange={(e) => setClientSecret(e.target.value)}
                                    className="input"
                                    placeholder="Enter Client Secret"
                                />
                                {errors.clientSecret && (
                                    <div className="text-red-500 text-xs mt-1">{errors.clientSecret}</div>
                                )}
                            </div>
                        </div>
                    </div>
                )}
            </Modal>

            <Modal
                title="Confirm Submission"
                visible={isConfirmOpen}
                centered
                onCancel={handleCancelConfirm}
                footer={
                    <div className="flex justify-center space-x-4">
                        <button onClick={handleCancelConfirm} className="cancel-btn">
                            Cancel
                        </button>
                        <button className="save-btn" onClick={handleConfirmSubmit}>
                            Confirm
                        </button>
                    </div>
                }
            >
                <p>Are you sure you want to submit the form?</p>
            </Modal>
        </>
    );
};

export default QualificationAuthenticateModal;
