"use client";
import React, { useState, useEffect, useRef, useCallback } from "react";
import { useLogoStore } from "@/app/stores/logoStore";
import EmailModal from "../EmailModal";
import { Checkbox, Modal, notification, Spin, Switch } from "antd";
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import { usePartnerStore } from "../partnerStore";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { useUserStore } from "../users/createUser/createUserStore";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import Select, { components, SingleValue } from "react-select";
import {
  NonEditableDropdownStyles,
  DropdownStyles,
} from "@/app/components/css/dropdown";
import moment from "moment-timezone";
import TableComponent from "@/app/components/TableComponent/page";
import { CheckCircleIcon, ChevronDownIcon, ChevronUpIcon, PlusCircleIcon, PlusIcon, XCircleIcon } from "@heroicons/react/24/outline";
import AddServiceProvider from "./addServiceProviderPopup";
import AuthenticateModal from "./authenticateModal";
import TelegenceAuthenticateModal from "./telegenceAuthenticateModal";
import DefaultAuthenticateModal from "./defaultAuthenticateModal";
import BandwidthAuthenticateModal from "./bandwidthAuthenticateModal";
import CereTaxAuthenticateModal from "./cereTaxModal";
import CyberReefAuthenticateModal from "./cyberReefAuthenticateModal";
import PondIotAuthenticateModal from "./pondIotAuthenticateModal";
import QualificationAuthenticateModal from "./qualificationAuthenticateModal";
import RevIotAuthenticateModal from "./revIoAuthenticateModal";
import KoreAuthenticateModal from "./koreAuthenticateModal";
import WebbingAuthenticateModal from "./webbingAuthenticateModal";
import { CustomerGroup2Options } from "@/app/constants/partnercarrier";
import EditableTableComponent from "../editableTableComponent/page";
import { PerformanceLogStore } from "@/app/stores/performance_matrix_store";
import ProgressBar from "@/app/components/optimizationTableComponent/cell-renderers/progressBar";
import { fireSideCannons } from "@/app/components/confetti";

interface PartnerInfo {
  onSubmit: () => void;
}

const apiConnections = [
  { label: "AT&T - Cisco Jasper", authenticated: true },
  { label: "AT&T - POD19", authenticated: true },
  { label: "AT&T - Telegence - UAT ONLY", authenticated: true },
  { label: "Bandwidth.com", authenticated: false },
  { label: "CereTax", authenticated: true },
  { label: "CyberReef", authenticated: false },
  { label: "Intrado E911", authenticated: true },
  { label: "NetSapiens", authenticated: false },
  { label: "T-Mobile - Advantage", authenticated: false },
  { label: "T-Mobile Jasper", authenticated: true },
  { label: "Rogers Sandbox", authenticated: true },
  { label: "POND IoT", authenticated: false },
  { label: "Qualification", authenticated: true },
  { label: "Rev.IO", authenticated: true },
  { label: "Teal", authenticated: true },
  { label: "Verizon - ThingSpace IoT", authenticated: true },
  { label: "Verizon - ThingSpace PN", authenticated: true },

];

const PartnerInfo: React.FC<PartnerInfo> = ({ onSubmit }) => {
  // const timezoneOptions = moment.tz.names().map((timezone) => {
  //   const abbreviation = moment().tz(timezone).format('zz');
  //   const currentTime = moment().tz(timezone).format('HH:mm:ss');
  //   const [countryName, cityName] = timezone.split('/');
  //   const formattedCountryName = cityName ? `${countryName} / ${cityName}` : countryName;
  //   return {
  //     value: `(${abbreviation} +${currentTime}) ${formattedCountryName}`,
  //     label: `(${abbreviation} +${currentTime}) ${formattedCountryName}`,
  //   };
  // });
  const [logoError, setLogoError] = useState<string | null>(null);
  const [collapsedLogoError, setCollapsedLogoError] = useState<string | null>(null);
  const [darkModeCollapsedLogoError, setDarkModeCollapsedLogoError] = useState<string | null>(null);
  const [darkModeLogoError, setDarkModeLogoError] = useState<string | null>(null);
  const [emailError, setEmailError] = useState<string | null>(null);
  const [submitModalOpen, setSubmitModalOpen] = useState(false);
  const [logoModalOpen, setLogoModalOpen] = useState(false);
  const [isLogoUpdated, setIsLogoUpdated] = useState(false);
  const [emailList, setEmailList] = useState<string[]>([]);
  const [emailInput, setEmailInput] = useState<string>("");
  const [isEmailModalOpen, setIsEmailModalOpen] = useState<boolean>(false);
  const { username, partner, role, token, selectedDb, metaData, settabledata, firstLastName, sessionId, setLogoUrl, setCollapsedLogoUrl, setDarkModeLogoUrl, setDarkModeCollapsedLogoUrl, isSubTenant, tenantProviderMap } = useAuth();
  const { partnerData, setPartnerInfo, setPartnerUsers, setCustomerGroups } = usePartnerStore.getState();
  const [emails, setEmails] = useState<string | null>("");
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
  const partnerInfo =
    partnerData?.["Partner info"]?.data?.["Partner info"] || {};
  const {
    tenant,
    role_name,
    sub_tenant,
    user_name,
    setTenant,
    setRoleName,
    setSubTenant,
    emailsList,
    setEmailsList,
  } = useUserStore();
  const provider_options = ["Yes", "No"];
  const [serviceProvider, setServiceProvider] = useState<string | null>(null);
  const [serviceProviderError, setServiceProviderError] = useState<string>("");
  let logoUrl_: string;
  let collapsedLogoUrl_: string;
  let darkModeCollapsedLogoUrl_: string;
  let darkModeLogoUrl_: string;
  // const { setLogoUrl, logoUrl } = useLogoStore();
  const logoFileRef = useRef<HTMLInputElement>(null);
  const collapsedLogoFileRef = useRef<HTMLInputElement>(null);
  const darkModeCollapsedLogoFileRef = useRef<HTMLInputElement>(null);
  const darkModeLogoFileRef = useRef<HTMLInputElement>(null);
  const [providerToError, setProviderToError] = useState<string>("");
  const [tenantOptions, setTenantOptions] = useState<any[]>([]);
  const [providerTo, setProviderTo] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [fromEmail, setFromEmail] = useState(partnerInfo.from_email || "");
  const [billingEmail, setBillingEmail] = useState(partnerInfo.billing_email || "");
  const [sendgridApi, setSendgridApi] = useState(partnerInfo.sendgrid_api || "");
  const [billingApi, setBillingApi] = useState(partnerInfo.billing_api || "");
  const [fromEmailError, setFromEmailError] = useState("");
  const [billingEmailError, setBillingEmailError] = useState("");
  const status = localStorage.getItem("bp_flag");
  const bp_status = status === "true" ? true : false
  // state for add service provider table
  const [addServiceVisibleColumns, setAddServiceVisibleColumns] = useState<
    string[]
  >([]);
  const [addServicePagination, setAddServicePagination] = useState<any>({});
  const [addServiceTableData, setAddServiceTableData] = useState<any>([]);
  const [addServiceHeaders, setAddServiceHeaders] = useState<any[]>([]);
  const [addServiceHeaderMap, setAddServiceHeaderMap] = useState<any>({});
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<string[]>([]);

  // State for billing address fields
  const [billingAddress1, setBillingAddress1] = useState("");
  const [billingAddress2, setBillingAddress2] = useState("");
  const [billingCity, setBillingCity] = useState("");
  const [billingState, setBillingState] = useState("");
  const [billingZip, setBillingZip] = useState("");
  const [billingZipError, setBillingZipError] = useState<string>("");
  const [billingNotes, setBillingNotes] = useState("");
  // const [
  //   crossProviderCustomerOptimization,
  //   setCrossProviderCustomerOptimization,
  // ] = useState(false);

  // State for physical address fields
  const [physicalAddress1, setPhysicalAddress1] = useState("");
  const [physicalAddress2, setPhysicalAddress2] = useState("");
  const [physicalApt, setPhysicalApt] = useState("");
  const [physicalCity, setPhysicalCity] = useState("");
  const [physicalState, setPhysicalState] = useState("");
  const [physicalZip, setPhysicalZip] = useState("");
  const [physicalZipError, setphysicalZipError] = useState<string>("");
  const [physicalCounty, setPhysicalCounty] = useState("");
  const [physicalCountry, setPhysicalCountry] = useState("");
  const [selectedTimezone, setSelectedTimezone] = useState("");
  const [timezoneOptions, setTimezoneOptions] = useState<
    { value: string; label: string }[]
  >([]);
  const [isPopupVisible, setIspopupVisible] = useState(false);

  //Authenticate popup variables
  const [isAuthenticateVisible, setIsAuthenticateVisible] = useState(false);
  const [isTelegenceAuthenticate, setIsTelegenceAuthenticate] = useState(false);
  const [isKoreAuthenticate, setIsKoreAuthenticate] = useState(false);
  const [isWebbingAuthenticate, setIsWebbingAuthenticate] = useState(false);
  const [isBandwidthAuthenticate, setIsBandwidthAuthenticate] = useState(false);
  const [isCereTaxAuthenticate, setIsCereTaxAuthenticate] = useState(false);
  const [isCyberReefAuthenticate, setIsCyberReefAuthenticate] = useState(false);
  const [isPondIOTAuthenticate, setIsPondIOTAuthenticate] = useState(false);
  const [isQualificationAuthenticate, setIsQualificationAuthenticate] = useState(false);
  const [isRevIOAuthenticate, setIsRevIOAuthenticate] = useState(false);
  const [isDefaultAuthenticate, setIsDefaultAuthenticate] = useState(false);
  const [selectedConncetion, setSelectedConnection] = useState<string>("");
  const [apiConnections, setApiConnections] = useState<any[]>([]);
  const [integrationDetails, setIntegrationDetails] = useState<any[]>([]);
  const [selectedIntegrationDetail, setSelectedIntegrationDetail] = useState<any>({});

  const isAgentPartnerAdmin = role?.toLowerCase() === "agent partner admin"
  const [phoneNumberFrequency, setphoneNumberFrequency] = useState<number>(3);

  const storedLogo: any = localStorage.getItem('logo');
  const storedCollapsedLogo: any = localStorage.getItem('collapsed_logo');
  const storedDarkModeCollapsedLogo: any = localStorage.getItem('dark_mode_collapsed_logo');
  const storedDarkModeLogo: any = localStorage.getItem('dark_mode_logo');


  //Partners being Service Provider States
  const [sourceTenantOptions, setSourceTenantOptions] = useState<any[]>([])
  const [sourceTenant, setSourceTenant] = useState<string | null>(null)
  const [targetTenantOptions, setTargetTenantOptions] = useState<any[]>([])
  const [submittedTargetTenants, setSubmittedTargetTenants] = useState<any[]>([])
  const [tenantOptionsMapping, setTenantOptionsMapping] = useState<any[]>([])
  const [targetTenant, setTargetTenant] = useState<string | null>(null)
  const [filteredTargetTenant, setFilteredTargetTenant] = useState<any[]>([])
  const [customerGroupOptions, setCustomerGroupOptions] = useState<any[]>([])
  const [customerGroup, setCustomerGroup] = useState<string | null>(null)
  const [FANBANMapping, setFANBANMapping] = useState<any[]>([])
  const [FANOptions, setFANOptions] = useState<any[]>([])
  const [selectedFAN, setSelectedFAN] = useState<any[]>([])
  const [BANOptions, setBANOptions] = useState<any[]>([])
  const [selectedBAN, setSelectedBAN] = useState<any[]>([])
  const [isCGBAN, setISCGBAN] = useState<boolean>(false)
  const [serviceProviderOptions, setServiceProviderOptions] = useState<any[]>([])
  const [SPOptionsMapping, setSPOptionsMapping] = useState<any[]>([])
  const [sourceTenantMapping, setSourceTenantMapping] = useState<any[]>([])
  const [targetTenantMapping, setTargetTenantMapping] = useState<any[]>([])
  const [sourceTenantError, setSourceTenantError] = useState<string | null>(null);
  const [targetTenantError, setTargetTenantError] = useState<string | null>(null);
  const [partnerProviderError, setPartnerProviderError] = useState<string | null>(null);
  const [progressValue, setProgressValue] = useState<any>(null);


  const [isPartnerProviderTableEditable, setIsPartnerProviderTableEditable] = useState(true);
  const [isPartnerProviderFieldsEditable, setIsPartnerProviderFieldsEditable] = useState(true);
  const [isPartnerProviderSectionEnabled, setIsPartnerProviderSectionEnabled] = useState(false);


  const [partnerProviderVisibleColumns, setPartnerProviderVisibleColumns] = useState<
    string[]
  >([]);
  const [partnerProviderPagination, setPartnerProviderPagination] = useState<any>({});
  const [partnerProviderTableData, setPartnerProviderTableData] = useState<any>([]);
  const [partnerProviderHeaders, setPartnerProviderHeaders] = useState<any[]>([]);
  const [partnerProviderHeaderMap, setPartnerProviderHeaderMap] = useState<any>({});
  const [partnerProviderEditedTable, setPartnerProviderEditedTable] = useState<any>([]);
  const [hasDuplicateDisplayNames, setHasDuplicateDisplayNames] = useState<boolean>(false);

  const targetPartnerProviders = tenantProviderMap ? Object.keys(tenantProviderMap) : []

  const [openSections, setOpenSections] = useState<{
    [key: string]: boolean;
  }>({});

  const toggleSections = (key: string) => {
    setOpenSections((prev) => ({
      ...prev,
      [key]: !openSections[key]
    }));
  }
  const { getTargetTenantProvider, IsTargetTenantProvider } = PerformanceLogStore();


  useEffect(() => {
    console.log("isSubTenant", isSubTenant)
    console.log("sourceTenant", sourceTenant)
    console.log("partner", partner)

    if ((sourceTenant !== partner) || isSubTenant) {
      console.log("if called")

      setIsPartnerProviderTableEditable(false)
      setIsPartnerProviderFieldsEditable(false)
    }
    else {
      setIsPartnerProviderTableEditable(true)
      setIsPartnerProviderFieldsEditable(true)
    }
  }, [sourceTenant, partner, isSubTenant])

  useEffect(() => {
    let email_list = Array.isArray(partnerInfo?.email_id)
      ? partnerInfo.email_id
      : [];
    if (JSON.stringify(emailList) !== JSON.stringify(email_list)) {
      setEmailList(email_list);
      setEmailsList(email_list);
    }
    const service_provider_to = partnerInfo?.service_provider_to || "";
    setProviderTo(service_provider_to);
    const service_provider_status = partnerInfo?.service_provider_status
      ? "Yes"
      : "No";
    setServiceProvider(service_provider_status);

    const tenant_names = partnerInfo?.tenant_names || [];
    setTenantOptions(tenant_names);

    const billing_address_1 = partnerInfo?.billing_address_1 || "";
    setBillingAddress1(billing_address_1);
    const billing_address_2 = partnerInfo?.billing_address_2 || "";
    setBillingAddress2(billing_address_2);
    const billing_city = partnerInfo?.billing_city || "";
    setBillingCity(billing_city);
    const billing_state = partnerInfo?.billing_state || "";
    setBillingState(billing_state);
    const billing_zip_code = partnerInfo?.billing_zip_code || "";
    setBillingZip(billing_zip_code);
    const billing_notes = partnerInfo?.billing_notes || "";
    setBillingNotes(billing_notes);
    const cross_provider_customer_optimization =
      partnerInfo?.cross_provider_customer_optimization || "";
    // setCrossProviderCustomerOptimization(cross_provider_customer_optimization);
    const physical_address_1 = partnerInfo?.physical_address_1 || "";
    setPhysicalAddress1(physical_address_1);
    const physical_addresss_2 = partnerInfo?.physical_addresss_2 || "";
    setPhysicalAddress2(physical_addresss_2);
    const physical_apt_or_suite = partnerInfo?.physical_apt_or_suite || "";
    setPhysicalApt(physical_apt_or_suite);
    const physical_city = partnerInfo?.physical_city || "";
    setPhysicalCity(physical_city);
    const physical_state = partnerInfo?.physical_state || "";
    setPhysicalState(physical_state);
    const physical_zip_code = partnerInfo?.physical_zip_code || "";
    setPhysicalZip(physical_zip_code);
    const physical_country = partnerInfo?.physical_country || "";
    setPhysicalCountry(physical_country);
    const physical_county = partnerInfo?.physical_county || "";
    setPhysicalCounty(physical_county);
    const time_zone = partnerInfo?.time_zone || "";
    setSelectedTimezone(time_zone);
    const initial_ph_no_frequency = partnerInfo?.change_phone_number_frequency_setting
    console.log("initial_ph_no_frequency", initial_ph_no_frequency)
    setphoneNumberFrequency(
      initial_ph_no_frequency && initial_ph_no_frequency !== "None"
        ? Number(initial_ph_no_frequency)
        : 3
    );
  }, []);

  //Time zone
  useEffect(() => {
    const timezoneNames = moment.tz.names();
    const options = timezoneNames.map((timezone) => {
      const abbreviation = moment().tz(timezone).format("zz");
      const currentTime = moment().tz(timezone).format("HH:mm:ss");
      const [countryName, cityName] = timezone.split("/");
      const formattedCountryName = cityName
        ? `${countryName} / ${cityName}`
        : countryName;
      return {
        value: timezone,
        label: `(${abbreviation} +${currentTime}) ${formattedCountryName}`,
      };
    });
    setTimezoneOptions(options);
  }, []);

  useEffect(() => {
    const email_ids = Array.isArray(partnerInfo?.email_id || [])? partnerInfo?.email_id || [] : []
    setEmailList(email_ids)
    const timeZoneFromResponse = partnerInfo?.time_zone || "";
    setSelectedTimezone(timeZoneFromResponse);
    const from_email = partnerInfo.from_email || ""
    setFromEmail(from_email)
    // if (bp_status) {
    //   const billing_email = partnerInfo.billing_email || ""
    //   setBillingEmail(billing_email)
    // }
    const sendgrid_api = partnerInfo.sendgrid_api || ""
    setSendgridApi(sendgrid_api)
    const billing_api = partnerInfo.billing_api || ""
    setBillingApi(billing_api)
    const selected_partners = partnerInfo?.selected_partners || []

    let parsedPartners;
    try {
      parsedPartners = Array.isArray(selected_partners) ? selected_partners : JSON.parse(selected_partners);
    } catch (error) {
      if (selected_partners && selected_partners !== 'None') {
        parsedPartners = [selected_partners];
      }
    }
    const filtered_tenants = parsedPartners.map((tenant: any) => ({ label: tenant, value: tenant }))
    if (filtered_tenants && filtered_tenants.length > 0) {
      setFilteredTargetTenant(filtered_tenants)
      setSubmittedTargetTenants(filtered_tenants)
      setIsPartnerProviderSectionEnabled(true)
    }
    else {
      setFilteredTargetTenant([])
      setSubmittedTargetTenants([])
      setIsPartnerProviderSectionEnabled(false)
    }
  }, [partnerInfo]);
  useEffect(() => {
    const intervalId = setInterval(() => {
      setTimezoneOptions((prevOptions) =>
        prevOptions.map((option) => {
          const abbreviation = moment().tz(option.value).format("zz");
          const currentTime = moment().tz(option.value).format("HH:mm:ss");
          return {
            ...option,
            label: `(${abbreviation} +${currentTime}) ${option.label.split(") ")[1]
              }`,
          };
        })
      );
    }, 1000);

    return () => clearInterval(intervalId);
  }, []);

  type HeaderMap = Record<string, [string, number]>;
  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);

  // Effect to handle rowData changes (if required)
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        settabledata([])
        const url = ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/service_provider_list_view",
          role_name: role,
          parent_module: "Partner",
          feature_module_name: "Partner Info",
          mod_pages: {
            start: 0,
            end: 100,
          },
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
        };
        console.log(getCurrentDateTime(), "Show the log time request sent from ui to lambda");
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        console.log(getCurrentDateTime(), "Show the log time response sent from lambda to ui");
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const headersMap_ =
            parsedData?.headers_map?.["Service Provider"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setAddServiceHeaderMap(sortedheaderMap);
          const headers_ =
            Object.keys(sortedheaderMap).length > 0
              ? Object.keys(sortedheaderMap)
              : [];
          setAddServiceHeaders(headers_)
          setAddServiceVisibleColumns(headers_);
          const tableData_ = parsedData?.data || [];
          setAddServiceTableData(tableData_);
          const features_ =
            parsedData?.headers_map?.["Service Provider"]?.module_features ||
            [];
          setFeatures(features_);
          const allowedActions_: any = []
          if (features_.includes("Edit-Partner info")) {
            allowedActions_.push("editServiceProvider")
          }
          if (features_.includes("Delete-Partner info")) {
            allowedActions_.push("delete")
          }
          setAllowedActions(allowedActions_)

          const pagination_ = parsedData?.pages || {};
          setAddServicePagination(pagination_);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        Modal.error({
          title: "Data Fetch Error",
          content:
            error instanceof Error
              ? error.message
              : "An unexpected error occurred while fetching data. Please try again.",
          centered: true,
        });
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  const fetchAuthenticateData = async () => {
    setLoading(true);
    try {
      settabledata([])
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_integration_data",
        role_name: role,
        parent_module: "Partner",
        feature_module_name: "Partner Info",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching API Connections data. Please try again.",
          centered: true,
        });
      } else {
        const connections = parsedData?.connections || [];
        setApiConnections(connections);
        const intergation_details = parsedData?.intergation_details || [];
        setIntegrationDetails(intergation_details);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchPartnerToProviderData = async () => {
    setLoading(true);
    if (!isSubTenant) {
      setSourceTenant(partner || null)
    }
    else {
      setTargetTenant(partner || null)
    }
    try {
      settabledata([])
      const url = ENV_ROUTES.PARTNER_BECOMING_PROVIDER;
      const data = {
        tenant_name: sourceTenant || partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_partner_to_provider_list_view_data",
        role_name: role,
        parent_module: "Partner",
        feature_module_name: "Partner Info",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        target_tenant_name: targetTenant || ""
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching Partners bieng Providers data. Please try again.",
          centered: true,
        });
      } else {
        if (targetTenant) {
          const tableData_ = parsedData?.data || [];
          setPartnerProviderTableData(tableData_);
          const pagination_ = parsedData?.pages || {};
          setPartnerProviderPagination(pagination_);
          const headersMap_ =
            parsedData?.headers_map?.["Partners Becoming Provider"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setPartnerProviderHeaderMap(sortedheaderMap);
        }
        else {
          const headersMap_ =
            parsedData?.headers_map?.["Partners Becoming Provider"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setPartnerProviderHeaderMap(sortedheaderMap);
          const headers_ =
            Object.keys(sortedheaderMap).length > 0
              ? Object.keys(sortedheaderMap)
              : [];
          setPartnerProviderHeaders(headers_)
          setPartnerProviderVisibleColumns(headers_);
          const tenant_options_mapping = parsedData?.tenant_details || [];
          setTenantOptionsMapping(tenant_options_mapping);
          const tenant_options = tenant_options_mapping
            .filter((tenant: any) => tenant?.tenant_name !== partner)
            .map((tenant: any) => tenant?.tenant_name);
          setTargetTenantOptions(tenant_options)
          const source_tenant_mapping = parsedData?.source_tenant_mapping || [];
          setSourceTenantMapping(source_tenant_mapping);
          const source_tenant_options = source_tenant_mapping.map((tenant: any) => (tenant?.partner_name))
          const target_tenant_mapping = parsedData?.target_tenant_mapping || [];
          setTargetTenantMapping(target_tenant_mapping);
          if (isSubTenant) {
            setSourceTenantOptions([...source_tenant_options])
          }
          else {
            setSourceTenantOptions([partner, ...source_tenant_options])
          }
          const sp_options_mapping = parsedData?.service_provider_details || [];
          setSPOptionsMapping(sp_options_mapping);
          const sp_options = sp_options_mapping.map((sp: any) => (sp?.service_provider_name))
          setServiceProviderOptions(sp_options)
          const customerGroupOptions_ = parsedData?.customer_groups || [];
          setCustomerGroupOptions(customerGroupOptions_);
          const fan_ban_mapping = parsedData?.foundation_account_billing_account_mapping || {};
          setFANBANMapping(fan_ban_mapping);
          const fanOptions_ = Object.keys(fan_ban_mapping) || []
          setFANOptions(fanOptions_)
        }

      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAuthenticateData()
    fetchPartnerToProviderData()
  }, []);


  const handleLogoUpdate = () => {
    let isValid = true;
    const file = logoFileRef.current?.files?.[0];
    if (file) {
      console.log("file", file);
      const validTypes = ["image/png", "image/jpeg"];
      if (!validTypes.includes(file.type)) {
        setLogoError("Only .png and .jpg files are allowed.");
        isValid = false;
      } else if (file.size > 50000000) {
        setLogoError("File size must be less than 50 MB.");
        isValid = false;
      } else {
        setLogoError("");
      }
    }
    const collapsed_file = collapsedLogoFileRef.current?.files?.[0];
    if (collapsed_file) {
      console.log("file", collapsed_file);
      const validTypes = ["image/png", "image/jpeg"];
      if (!validTypes.includes(collapsed_file.type)) {
        setCollapsedLogoError("Only .png and .jpg files are allowed.");
        isValid = false;
      } else if (collapsed_file.size > 50000000) {
        setCollapsedLogoError("File size must be less than 50 MB.");
        isValid = false;
      } else {
        setCollapsedLogoError("");
      }
    }

    const dark_mode_collapsed_file = darkModeCollapsedLogoFileRef.current?.files?.[0];
    if (dark_mode_collapsed_file) {
      console.log("file", dark_mode_collapsed_file);
      const validTypes = ["image/png", "image/jpeg"];
      if (!validTypes.includes(dark_mode_collapsed_file.type)) {
        setDarkModeCollapsedLogoError("Only .png and .jpg files are allowed.");
        isValid = false;
      } else if (dark_mode_collapsed_file.size > 50000000) {
        setDarkModeCollapsedLogoError("File size must be less than 50 MB.");
        isValid = false;
      } else {
        setDarkModeCollapsedLogoError("");
      }
    }
    const darkmode_logo_file = darkModeLogoFileRef.current?.files?.[0];
    if (darkmode_logo_file) {
      console.log("file", darkmode_logo_file);
      const validTypes = ["image/png", "image/jpeg"];
      if (!validTypes.includes(darkmode_logo_file.type)) {
        setDarkModeLogoError("Only .png and .jpg files are allowed.");
        isValid = false;
      } else if (darkmode_logo_file.size > 50000000) {
        setDarkModeLogoError("File size must be less than 50 MB.");
        isValid = false;
      } else {
        setDarkModeLogoError("");
      }
    }
    if (isValid) {
      if (file || collapsed_file || darkmode_logo_file || dark_mode_collapsed_file) {
        setIsLogoUpdated(true)
      }
      setLogoModalOpen(false);
    }
  }

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    let isValid = true;
    // if (billingZip) {
    //   const regex = /^\d{5}$/; // Only 5 numerical values

    //   if (!regex.test(billingZip)) {
    //     setBillingZipError("Zip code must be exactly 5 digits");
    //     isValid = false;
    //   } else {
    //     setBillingZipError("");
    //   }
    // }
    // if (physicalZip) {
    //   const regex = /^\d{5}$/; // Only 5 numerical values

    //   if (!regex.test(physicalZip)) {
    //     setphysicalZipError("Zip code must be exactly 5 digits");
    //     isValid = false;
    //   } else {
    //     setphysicalZipError("");
    //   }
    // }
    if (!serviceProvider) {
      setServiceProviderError("Service provider is required");
      isValid = false;
    } else {
      setServiceProviderError("");
    }

    // if (!providerTo && serviceProvider === "Yes") {
    //   setProviderToError("Service provider to is required");
    //   isValid = false;
    // } else {
    //   setProviderToError("");
    // }

    if (emailList.length === 0) {
      setEmailError("A valid email ID is required");
      isValid = false;
    } else {
      setEmailError("");
    }

    if (isValid) {
      setSubmitModalOpen(true);
    }
  };
  const messageStyle = {
    fontSize: "14px",
    fontWeight: "bold",
    padding: "16px",
  };

  const handleServiceProviderToChange = (selectedOption: any) => {
    setProviderTo(selectedOption.value);
  };

  const handleServiceProvider = (selectedOption: any) => {
    setServiceProvider(selectedOption.value);
    setProviderTo(null);
  };

  const handleEmailBlur = () => {
    if (isEmailValid && !emailList.includes(emailInput)) {
      setEmailList([...emailList, emailInput]);
    }
  };
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+(\.[^\s@]+)*$/;

  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    console.log("value", value);
    // Allow input only until .com, prevent typing anything beyond .com
    if (
      (!value.includes(".com") || value.endsWith(".com")) &&
      emailList.length === 0
    ) {
      setEmailInput(value);
    }
  };
  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    console.log("emailList", emailList);
    // Check if backspace was pressed
    if (e.key === "Backspace" && emailList.length > 0) {
      // Prevent default behavior if there are emails in the list
      e.preventDefault();
    }
  };

  // Check if the email is valid and ends with ".com"
  const isEmailValid = emailRegex.test(emailInput);

  const handleAddEmail = (email: string) => {
    if (!emailList.includes(email)) {
      setEmailList([...emailList, email]);
    }
  };
  const handleModalAddEmail = () => {
    // Add the current email to the emailList if it's valid and clear the input
    // if (isEmailValid) {
    //   setEmailList([...emailList, emailInput]);
    // }
    setEmailInput("");
    setIsEmailModalOpen(true);
  };

  const handleServiceModal = () => {
    setIspopupVisible(true);
  };
  const handleCloseModal = () => {
    setIspopupVisible(false); // Close the modal
  };

  // Open the authenticate modals
  const handleAuthenticateModal = (connection: string) => {
    const value = connection.toLowerCase()
    setSelectedConnection(connection)

    //find the integration details to pass to authenticate modals for mapping
    // Find the matching apiConnection
    const matchingApiConnection = apiConnections.find(apiConn =>
      apiConn.label.toLowerCase() === value
    );

    if (matchingApiConnection) {
      const { integration_id, authentication_type } = matchingApiConnection;

      // Find the matching integrationDetail
      const matchingIntegrationDetail = integrationDetails.find(integrationDetail => {
        // Check if both values are provided, and if so, check both conditions
        if (authentication_type !== null && integration_id !== null) {
          return integrationDetail.integration_id === integration_id &&
            integrationDetail.authentication_type === authentication_type;
        }
        // If authentication_type is null, check only integration_id
        return integrationDetail.integration_id === integration_id;
      });

      if (matchingIntegrationDetail) {
        setSelectedIntegrationDetail(matchingIntegrationDetail)
        console.log("matchingIntegrationDetail", matchingIntegrationDetail)
        // Perform any action using matchingIntegrationDetail
      } else {
        console.warn('No matching integration detail found for this connection.');
      }
    } else {
      console.warn('No matching apiConnection found for this connection.');
    }
    const providerName = (getTargetTenantProvider(connection) || "").toLowerCase();
    const primaryConnections = ['at&t - cisco jasper', 'at&t - pod19']
    if (primaryConnections.includes(value) || providerName.includes('t-mobile') || value.includes('rogers')) {
      setIsAuthenticateVisible(true);
    }
    else if (providerName.includes('at&t - telegence') || value === 'netsapiens') {
      setIsTelegenceAuthenticate(true);
    }
    else if (providerName.includes('kore')) {
      setIsKoreAuthenticate(true);
    }
    else if (providerName === 'webbing' || providerName === "multi-carrier sim") {
      setIsWebbingAuthenticate(true);
    }
    else if (value === 'bandwidth.com') {
      setIsBandwidthAuthenticate(true);
    }
    else if (value === 'ceretax') {
      setIsCereTaxAuthenticate(true);
    }
    else if (value === 'cyberreef') {
      setIsCyberReefAuthenticate(true);
    }
    else if (value === 'pond mobile') {
      setIsPondIOTAuthenticate(true);
    }
    else if (value === 'qualification') {
      setIsQualificationAuthenticate(true);
    }
    else if (value === 'rev.io') {
      setIsRevIOAuthenticate(true);
    }
    else {
      setIsDefaultAuthenticate(true)
    }
  };
  // Close the authenticate modals
  const closeAuthenticateModals = () => {
    setIsAuthenticateVisible(false);
    setIsTelegenceAuthenticate(false);
    setIsKoreAuthenticate(false);
    setIsWebbingAuthenticate(false);
    setIsDefaultAuthenticate(false);
    setIsBandwidthAuthenticate(false);
    setIsCereTaxAuthenticate(false);
    setIsCyberReefAuthenticate(false);
    setIsPondIOTAuthenticate(false);
    setIsQualificationAuthenticate(false);
    setIsRevIOAuthenticate(false);

  };

  const handleRemoveEmail = (index: number) => {
    const newEmailList = emailList.filter((_, i) => i !== index);
    setEmailList(newEmailList);
    setEmailsList(newEmailList);
  };

  const handleFormSubmit = () => {
    const file = logoFileRef.current?.files?.[0];
    const collapsedFile = collapsedLogoFileRef.current?.files?.[0];
    const darkModeFile = darkModeLogoFileRef.current?.files?.[0];
    const darkModeCollapsedFile = darkModeCollapsedLogoFileRef.current?.files?.[0];

    const validTypes = ["image/png", "image/jpeg"];

    // Reset previous errors
    setLogoError(null);
    setCollapsedLogoError(null);
    setDarkModeLogoError(null);
    setDarkModeCollapsedLogoError(null);

    // Validation flags
    let hasError = false;

    // Validate main logo
    if (file) {
      if (!validTypes.includes(file.type)) {
        setLogoError("Only .png and .jpg files are allowed.");
        hasError = true;
      } else if (file.size > 50 * 1024 * 1024) {
        setLogoError("File size must be less than 50 MB.");
        hasError = true;
      }
    }

    // Validate collapsed logo
    if (collapsedFile) {
      if (!validTypes.includes(collapsedFile.type)) {
        setCollapsedLogoError("Only .png and .jpg files are allowed.");
        hasError = true;
      } else if (collapsedFile.size > 50 * 1024 * 1024) {
        setCollapsedLogoError("File size must be less than 50 MB.");
        hasError = true;
      }
    }

    // Validate dark mode collapsed logo
    if (darkModeCollapsedFile) {
      if (!validTypes.includes(darkModeCollapsedFile.type)) {
        setDarkModeCollapsedLogoError("Only .png and .jpg files are allowed.");
        hasError = true;
      } else if (darkModeCollapsedFile.size > 50 * 1024 * 1024) {
        setDarkModeCollapsedLogoError("File size must be less than 50 MB.");
        hasError = true;
      }
    }

    // Validate dark mode logo
    if (darkModeFile) {
      if (!validTypes.includes(darkModeFile.type)) {
        setDarkModeLogoError("Only .png and .jpg files are allowed.");
        hasError = true;
      } else if (darkModeFile.size > 50 * 1024 * 1024) {
        setDarkModeLogoError("File size must be less than 50 MB.");
        hasError = true;
      }
    }

    if (hasError) return;

    // Helper to read file as base64
    const readFileAsBase64 = (file: File): Promise<string> => {
      return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result as string);
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });
    };

    // Read and submit both logos
    const processLogos = async () => {
      try {
        if (file) {
          logoUrl_ = await readFileAsBase64(file);
          setLogoUrl(logoUrl_);
        }
        if (collapsedFile) {
          collapsedLogoUrl_ = await readFileAsBase64(collapsedFile);
          setCollapsedLogoUrl(collapsedLogoUrl_);
        }
        if (darkModeCollapsedFile) {
          darkModeCollapsedLogoUrl_ = await readFileAsBase64(darkModeCollapsedFile);
          setDarkModeCollapsedLogoUrl(darkModeCollapsedLogoUrl_);
        }
        if (darkModeFile) {
          darkModeLogoUrl_ = await readFileAsBase64(darkModeFile);
          setDarkModeLogoUrl(darkModeLogoUrl_);
        }

        setSubmitModalOpen(false);
        confirmSubmit();
      } catch (err) {
        console.error("Error reading file:", err);
      }
    };

    processLogos();
  };


  //Refetching data

  const fetchTabData = async (tab: {
    module: string;
    setter: (data: any) => void;
    setLoaded: (loaded: boolean) => void;
  }) => {
    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/get_partner_info",
      role_name: role,
      parent_module: "Partner",
      modules_list: [tab.module],
      feature_module_name: "Partner Info",
      pages: {
        "Customer groups": { start: 0, end: 100 },
        "Partner users": { start: 0, end: 100 },
      },
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
    };

    try {
      const response = await axios.post(
        ENV_ROUTES.MODULE_MANAGEMENT,
        { data }
      );
      if (response && response.status === 200) {
        const parseddata = JSON.parse(response.data.body);
        if (parseddata.flag) {
          tab.setter(parseddata);
          tab.setLoaded(true);
        } else {
          tab.setter(parseddata.message);
          Modal.error({
            title: "Error",
            content: parseddata.message,
            centered: true,
          });
        }
      }
    } catch (error) {
      console.error("Error fetching", tab.module, ":", error);
      // Modal.error({
      //   title: "Error",
      //   content: "An error occurred during submitting data.",
      //   centered: true,
      // });
    }
  };

  const fetchData = async () => {
    const tabs = [
      {
        module: "Partner info",
        setter: setPartnerInfo,
      },
      {
        module: "Customer groups",
        setter: setCustomerGroups,
      },
      {
        module: "Partner users",
        setter: setPartnerUsers,
      },
      // { module: "Notifications", setter: setNotifications, setLoaded: setNotificationsLoaded }
    ];
    const activeTabData: any = tabs[0]
    const activeTab = "Partner info"

    try {
      if (activeTabData) {
        // Fetch active tab data first
        await fetchTabData(activeTabData);
      } else {
        console.error("Active tab data not found");
      }

      // Fetch remaining tabs data in parallel
      const remainingTabs = tabs.filter(
        (tab) => tab.module.replace(/\s+/g, "").toLowerCase() !== activeTab
      );

      await Promise.all(
        remainingTabs.map((tab: any) => fetchTabData(tab))
      );
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setLoading(false); // Set loading to false after fetching all data
    }
  };
  const SubmitUpdatePartnerInfo = async () => {
    const partner_address_ = {
      billing_address_1: billingAddress1,
      billing_address_2: billingAddress2,
      billing_city: billingCity,
      billing_state: billingState,
      billing_zip_code: billingZip,
      billing_notes: billingNotes,
      // cross_provider_customer_optimization: crossProviderCustomerOptimization,
      physical_address_1: physicalAddress1,
      physical_addresss_2: physicalAddress2,
      physical_apt_or_suite: physicalApt,
      physical_city: physicalCity,
      physical_state: physicalState,
      physical_zip_code: physicalZip,
      physical_country: physicalCountry,
      physical_county: physicalCounty,
      time_zone: selectedTimezone,
    };
    console.log(fromEmail, sendgridApi, "show the apis")
    try {
      setLoading(true);
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/update_partner_info",
        role_name: role,
        parent_module: "Partner",
        module_name: "Partner info",
        action: "update",
        changed_data: {
          change_phone_number_frequency_setting: phoneNumberFrequency || 3,
          email_ids: emailList,
          logo: logoUrl_ || storedLogo || null,
          collapsed_logo: collapsedLogoUrl_ || storedCollapsedLogo || null,
          dark_mode_collapsed_logo: darkModeCollapsedLogoUrl_ || storedDarkModeCollapsedLogo || null,
          dark_mode_logo: darkModeLogoUrl_ || storedDarkModeLogo || null,
          from_email: fromEmail,
          // ...bp_status ? { billing_email: billingEmail, billing_api: billingApi || "" } : {},
          sendgrid_api: sendgridApi,
          selected_partners: filteredTargetTenant && filteredTargetTenant.length > 0 ? filteredTargetTenant.map((opt: any) => (opt?.value || "")) : [],
          ...partner_address_,

        },

        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        sessionID: sessionId,
        ...metaData
      };
      console.log(data, "show the data")
      console.log(
        getCurrentDateTime(),
        "Show the log time request sent from ui to lambda"
      );

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      console.log(
        getCurrentDateTime(),
        "Show the log time response sent from lambda to ui"
      );
      if (parsedData.flag === false) {
        setLoading(false);
        // Modal.error({
        //   title: "Submit Error",
        //   content:
        //     parsedData.message ||
        //     "An error occurred while submitting data. Please try again.",
        //   centered: true,
        // });
      } else {
        setSubmittedTargetTenants(filteredTargetTenant || [])
        localStorage.setItem("logo", logoUrl_ || storedLogo || null)
        localStorage.setItem("collapsed_logo", collapsedLogoUrl_ || storedCollapsedLogo || null)
        localStorage.setItem("dark_mode_collapsed_logo", darkModeCollapsedLogoUrl_ || storedDarkModeCollapsedLogo || null)
        localStorage.setItem("dark_mode_logo", darkModeLogoUrl_ || storedDarkModeLogo || null)
        notification.success({
          message: "Success",
          description: "Successfully saved the form",
          style: messageStyle,
          placement: "top", // Apply custom styles here
        });
        setLoading(false);
        fireSideCannons()
        fetchData()
        // if (response && response.data.statusCode === 200) {
        //   try {
        //     const updatedUrl = ENV_ROUTES.MODULE_MANAGEMENT;
        //     const data = {
        //       tenant_name: partner || "default_value",
        //       username: username,
        //       firstLastName: firstLastName,
        //       path: "/get_partner_info",
        //       feature_module_name: "Partner Info",
        //       role_name: role,
        //       parent_module: "Partner",
        //       modules_list: ["Partner info"],
        //       pages: {
        //         "Customer groups": { start: 0, end: 100 },
        //         "Partner users": { start: 0, end: 100 },
        //       },
        //       access_token: token,
        //       db_name: selectedDb,
        //       sessionID: sessionId,
        //     };
        //     const updatedResponse = await axios.post(updatedUrl, { data });
        //     const updatedPparsedData = JSON.parse(updatedResponse.data.body);
        //     if (updatedResponse && updatedResponse.data.statusCode === 200) {
        //       setPartnerInfo(updatedPparsedData);
        //       // notification.success({
        //       //   message: "Success",
        //       //   description: "Successfully saved the form",
        //       //   style: messageStyle,
        //       //   placement: "top", // Apply custom styles here
        //       // });
        //     } else {
        //       // Modal.error({
        //       //   title: "Submit Error",
        //       //   content:
        //       //     updatedPparsedData.message ||
        //       //     "An error occurred while submitting the form. Please try again.",
        //       //   centered: true,
        //       // });
        //     }
        //   } catch (error) {
        //     console.log(error);
        //     // Modal.error({
        //     //   title: "Submit Error",
        //     //   content:
        //     //     error instanceof Error
        //     //       ? error.message
        //     //       : "An unexpected error occurred while submitting data. Please try again.",
        //     //   centered: true,
        //     // });
        //   } finally {
        //     setLoading(false);
        //   }
        // } else {
        //   const parsedData = JSON.parse(response?.data.body);
        //   // Modal.error({
        //   //   title: "Submit Error",
        //   //   content:
        //   //     parsedData?.message ||
        //   //     "An error occurred while submitting the form. Please try again.",
        //   //   centered: true,
        //   // });
        // }
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Submit Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while submitting data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
  const handlePartnerAddressSubmit = () => {
    let isValid = true;
    if (billingZip) {
      const regex = /^\d{5}$/; // Only 5 numerical values

      if (!regex.test(billingZip)) {
        setBillingZipError("Zip code must be exactly 5 digits");
        isValid = false;
      } else {
        setBillingZipError("");
      }
    }
    if (physicalZip) {
      const regex = /^\d{5}$/; // Only 5 numerical values

      if (!regex.test(physicalZip)) {
        setphysicalZipError("Zip code must be exactly 5 digits");
        isValid = false;
      } else {
        setphysicalZipError("");
      }
    }
    if (isValid) {
      SubmitUpdatePartnerAddress()
    }
  }
  const SubmitUpdatePartnerAddress = async () => {
    const partner_address_ = {
      billing_address_1: billingAddress1,
      billing_address_2: billingAddress2,
      billing_city: billingCity,
      billing_state: billingState,
      billing_zip_code: billingZip,
      billing_notes: billingNotes,
      // cross_provider_customer_optimization: crossProviderCustomerOptimization,
      physical_address_1: physicalAddress1,
      physical_addresss_2: physicalAddress2,
      physical_apt_or_suite: physicalApt,
      physical_city: physicalCity,
      physical_state: physicalState,
      physical_zip_code: physicalZip,
      physical_country: physicalCountry,
      physical_county: physicalCounty,
      time_zone: selectedTimezone,
    };
    console.log(fromEmail, sendgridApi, "show the apis")
    try {
      setLoading(true);
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/update_partner_info",
        role_name: role,
        parent_module: "Partner",
        module_name: "Partner info",
        action: "update",
        changed_data: {
          ...partner_address_,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };
      console.log(data, "show the data")
      console.log(
        getCurrentDateTime(),
        "Show the log time request sent from ui to lambda"
      );

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      console.log(
        getCurrentDateTime(),
        "Show the log time response sent from lambda to ui"
      );
      if (parsedData.flag === false) {
        setLoading(false);
        // Modal.error({
        //   title: "Submit Error",
        //   content:
        //     parsedData.message ||
        //     "An error occurred while submitting data. Please try again.",
        //   centered: true,
        // });
      } else {
        notification.success({
          message: "Success",
          description: "Successfully saved the addrress",
          style: messageStyle,
          placement: "top", // Apply custom styles here
        });
        setLoading(false);
        fireSideCannons()
        fetchData()
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Submit Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while submitting data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const SubmitCreateProviderMain = async () => {
    try {
      setLoading(true);
      const url = ENV_ROUTES.TENANT_ONBOARDING;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/create_provider_main",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        partner_name: partnerInfo.partner,
        sub_partner_name: partnerInfo.sub_partner,
        email_id: emailList,
        logo: logoUrl_ || storedLogo || null,
        collapsed_logo: collapsedLogoUrl_ || storedCollapsedLogo || null,
        dark_mode_collapsed_logo: darkModeCollapsedLogoUrl_ || storedDarkModeCollapsedLogo || null,
        dark_mode_logo: darkModeLogoUrl_ || storedDarkModeLogo || null,
        service_provider: serviceProvider,
        service_provider_to: providerTo,

      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        setLoading(false);
        // Modal.error({
        //   title: "Submit Error",
        //   content:
        //     parsedData.message ||
        //     "An error occurred while submitting data. Please try again.",
        //   centered: true,
        // });
      } else {
        setLoading(false);
        // notification.success({
        //   message: "Success",
        //   description: "Successfully saved.",
        //   style: messageStyle,
        //   placement: "top",
        // });
      }
    } catch (error) {
      setLoading(false);
      // Modal.error({
      //   title: "Submit Error",
      //   content:
      //     error instanceof Error
      //       ? error.message
      //       : "An unexpected error occurred while submitting data. Please try again.",
      //   centered: true,
      // });
    } finally {
      setLoading(false);
    }
  };
  const SubmitRemoveProvider = async () => {
    try {
      setLoading(true);
      const url = ENV_ROUTES.TENANT_ONBOARDING;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/remove_provider",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        partner_name: partnerInfo.partner,
        sub_partner_name: partnerInfo.sub_partner,
        email_id: emailList,
        logo: logoUrl_ || storedLogo || null,
        collapsed_logo: collapsedLogoUrl_ || storedCollapsedLogo || null,
        dark_mode_collapsed_logo: darkModeCollapsedLogoUrl_ || storedDarkModeCollapsedLogo || null,
        dark_mode_logo: darkModeLogoUrl_ || storedDarkModeLogo || null,
        service_provider: serviceProvider,
        service_provider_to: providerTo,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        setLoading(false);
        Modal.error({
          title: "Submit Error",
          content:
            parsedData.message ||
            "An error occurred while submitting data. Please try again.",
          centered: true,
        });
      } else {
        setLoading(false);
        notification.success({
          message: "Success",
          description: "Successfully saved.",
          style: messageStyle,
          placement: "top",
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Submit Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while submitting data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleTimezoneChange = (
    selectedOption: SingleValue<{ label: string; value: string }>
  ) => {
    setSelectedTimezone(selectedOption?.value ?? "");
  };

  const confirmSubmit = async () => {
    //Check if the service provider is changed from yes to no
    if (partnerInfo?.service_provider_status && serviceProvider === "No") {
      // SubmitRemoveProvider();
      SubmitUpdatePartnerInfo();
    }

    //Check if the service provider is changed from no to yes
    else if (
      !partnerInfo?.service_provider_status &&
      serviceProvider === "Yes"
    ) {
      // SubmitCreateProviderMain();
      SubmitUpdatePartnerInfo();
    }
    //if there is no change in service provider
    else {
      //check if the service provider to option is changed
      if (partnerInfo?.service_provider_to !== providerTo) {
        // SubmitCreateProviderMain();
        SubmitUpdatePartnerInfo();
      }
      //if the service provider to option is not changed
      else {
        SubmitUpdatePartnerInfo();
      }
    }
    setSubmitModalOpen(false);
  };

  const normalizeEmail = (value: string) => {
    return value
      .trim()
      // Remove zero-width spaces, word joiners, BOM, etc.
      .replace(/[\u200B-\u200D\u2060\uFEFF]/g, "")
      // Remove non-breaking spaces (char code 160)
      .replace(/\u00A0/g, "")
      // Normalize accents (é → e) if needed
      .normalize("NFKC");
  };

  const handleInputChange = (field: any, value: any) => {
    if (field === "from_email") {
      const value_ = normalizeEmail(value) || value
      setFromEmail(value_);
      if (value_ && !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(value_)) {
        setFromEmailError("Invalid email address");
      } else {
        setFromEmailError("");
      }
    }
    if (field === "billing_email") {
      const value_ = normalizeEmail(value) || value
      setBillingEmail(value_);
      if (value_ && !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(value_)) {
        setBillingEmailError("Invalid email address");
      } else {
        setBillingEmailError("");
      }
    } else if (field === "sendgrid_api") {
      setSendgridApi(value);
      // Add validation for Sendgrid API key if needed
    }
    else if (field === "billing_api") {
      setBillingApi(value);
      // Add validation for Sendgrid API key if needed
    }
  };
  const resetForm = () => {
    setEmailList([]);
    setLogoError(null);
    setEmailError(null);
    if (logoFileRef.current) {
      logoFileRef.current.value = "";
    }
    setBillingAddress1("");
    setBillingAddress2("");
    setBillingCity("");
    setBillingState("");
    setBillingZip("");
    setBillingNotes("");
    setBillingZipError("");
    // setCrossProviderCustomerOptimization(false);

    setphysicalZipError("");
    setPhysicalAddress1("");
    setPhysicalAddress2("");
    setPhysicalApt("");
    setPhysicalCity("");
    setPhysicalCountry("");
    setPhysicalCounty("");
    setPhysicalState("");
    setPhysicalZip("");
    setSelectedTimezone("");
  };

  const convertArray = (value: any) => {
    try {
      let converted_array;

      if (Array.isArray(value)) {
        converted_array = value
      }
      else {
        converted_array = JSON.parse(value)
      }
      return converted_array
    }
    catch (err) {
      console.log("error while parsing FAN BAN", err)
      return []
    }
  }

  const fetchTargetPartnerDetails = async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.PARTNER_BECOMING_PROVIDER;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_target_partner_details",
        role_name: role,
        parent_module: "Partner",
        feature_module_name: "Partner Info",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        source_tenant_name: sourceTenant || "",
        target_tenant_name: targetTenant || "",
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching Partners bieng Providers data. Please try again.",
          centered: true,
        });
      } else {
        const progress_value = parsedData?.data?.progress || null;
        setProgressValue(progress_value);
        const customer_group = parsedData?.data?.customer_group || null;
        setCustomerGroup(customer_group);
        const tagged_fan = parsedData?.data?.tagged_fan || [];
        const selected_fan = convertArray(tagged_fan)
        setSelectedFAN(selected_fan);
        const cg_tagged_ban = parsedData?.data?.cg_tagged_ban || false;
        setISCGBAN(cg_tagged_ban)
        const tagged_ban = parsedData?.data?.tagged_ban || [];
        const selected_ban = convertArray(tagged_ban)
        setSelectedBAN(selected_ban);
        if (customer_group || tagged_fan.length !== 0 || tagged_ban.length !== 0) {
          setIsPartnerProviderFieldsEditable(false)
        }
        else {
          setIsPartnerProviderFieldsEditable(true)
        }
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
  const updatePartnerProviderDetails = async () => {
    setLoading(true);
    let editedData: any[] = []
    let newData: any[] = []
    console.log("partnerProviderEditedTable", partnerProviderEditedTable)
    const partnerProviderEditedTable_Copy = [...partnerProviderEditedTable]
    const tenantObject = targetTenant ? tenantOptionsMapping.find((item: any) => item.tenant_name === targetTenant) : {}

    if (partnerProviderEditedTable_Copy.length !== partnerProviderTableData.length) {
      // How many rows are extra
      const extraCount = partnerProviderEditedTable_Copy.length - partnerProviderTableData.length;

      // Last N rows
      newData = partnerProviderEditedTable_Copy.slice(-extraCount);

      // First rows equal to original table length
      editedData = partnerProviderEditedTable_Copy.slice(0, partnerProviderTableData.length);
    }
    else {
      newData = []
      editedData = [...partnerProviderEditedTable_Copy]
    }
    //Remove modified_date from editedData
    editedData = editedData.map(({ modified_date, ...rest }) => rest);
    //Remove modified_date from newData and add source_tenant_name
    newData = newData.map(({ modified_date, ...rest }) => ({
      ...rest,
      source_tenant_name: sourceTenant || partner,
      created_by: username || firstLastName,

    }));

    let updated_service_provider_object: any = {}
    let initial_service_provider_object: any = {}
    serviceProviderOptions.forEach((provider: string) => {
      const matchedRow = partnerProviderEditedTable.find(
        (row: any) => row.service_provider_name === provider
      );

      updated_service_provider_object[provider] = matchedRow
        ? matchedRow.service_provider_display_name
        : `${sourceTenant}-${provider}`;
    });

    serviceProviderOptions.forEach((provider: string) => {
      const matchedRow = partnerProviderTableData.find(
        (row: any) => row.service_provider_name === provider
      );

      initial_service_provider_object[provider] = matchedRow
        ? matchedRow.service_provider_display_name
        : `${sourceTenant}-${provider}`;
    });

    try {
      const url = ENV_ROUTES.PARTNER_BECOMING_PROVIDER;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/partner_to_provider_actions",
        role_name: role,
        parent_module: "Partner",
        feature_module_name: "Partner Info",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        source_tenant_name: sourceTenant || "",
        target_tenant_name: targetTenant || "",
        action: isPartnerProviderFieldsEditable ? "create" : "edit",
        changed_data: editedData,
        new_data: newData,
        target_db_name: tenantObject?.db_name || "",
        tagged_service_providers: { ...updated_service_provider_object }

      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        if (parsedData.error_type && parsedData.error_type == "Warning") {
          console.log("parsedData.error_type", parsedData.error_type)
          Modal.warning({
            title: 'Warning',
            content: parsedData.message || 'An error occurred while submitting data. Please try again.',
            centered: true,
          });
        }
        else {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while submitting Partners bieng Providers data. Please try again.",
            centered: true,
          });
        }
        return false;
      } else {
        notification.success({
          message: "Success",
          description: "Successfully saved.",
          style: messageStyle,
          placement: "top",
        });
        fireSideCannons()
      }
      return true;
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while submitting data. Please try again.",
        centered: true,
      });
      return true;
    } finally {
      setLoading(false);
    }
  };
  const getChangedData = (
    initialObj: Record<string, string>,
    updatedObj: Record<string, string>
  ) => {
    const changed: Record<string, string> = {};

    Object.keys(updatedObj).forEach((key) => {
      if (updatedObj[key] !== initialObj[key]) {
        changed[key] = updatedObj[key];
      }
    });

    return changed;
  };

  const assignPartnerToProvider = async () => {
    setLoading(true);
    try {
      let partner_to_provider_data_: any = {};
      let action;
      let updated_service_provider_object: any = {}
      let initial_service_provider_object: any = {}

      serviceProviderOptions.forEach((provider: string) => {
        const matchedRow = partnerProviderEditedTable.find(
          (row: any) => row.service_provider_name === provider
        );

        updated_service_provider_object[provider] = matchedRow
          ? matchedRow.service_provider_display_name
          : `${sourceTenant}-${provider}`;
      });

      serviceProviderOptions.forEach((provider: string) => {
        const matchedRow = partnerProviderTableData.find(
          (row: any) => row.service_provider_name === provider
        );

        initial_service_provider_object[provider] = matchedRow
          ? matchedRow.service_provider_display_name
          : `${sourceTenant}-${provider}`;
      });

      const changed_service_provider_object = getChangedData(initial_service_provider_object, updated_service_provider_object)

      const tenantObject = targetTenant ? tenantOptionsMapping.find((item: any) => item.tenant_name === targetTenant) : {}
      const tenant_id = localStorage.getItem("tenant_id") || "0";

      if (isPartnerProviderFieldsEditable) {
        action = "create";

        partner_to_provider_data_ = {
          partner_name: partner || sourceTenant,
          partner_db: selectedDb,
          partner_db_tenant_id: parseInt(tenant_id) || 0,
          target_name: targetTenant || "",
          target_db: tenantObject?.db_name || "",
          target_db_tenant_id: tenantObject?.id || 0,
          customer_group: customerGroup || "",
          tagged_fan: selectedFAN || [],
          tagged_ban: selectedBAN || [],
          created_by: firstLastName || username,
          modified_by: firstLastName || username,
          is_active: true,
          tagged_service_providers: { ...updated_service_provider_object }
        }
      }
      else {
        action = "update";
        partner_to_provider_data_ = {
          tagged_service_providers: { ...updated_service_provider_object }
        }
      }



      const url = ENV_ROUTES.PARTNER_BECOMING_PROVIDER;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/assign_partner_to_provider",
        role_name: role,
        parent_module: "Partner",
        feature_module_name: "Partner Info",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        partner_to_provider_data: { ...partner_to_provider_data_ },
        action: action,
        ...action === "update" ?
          {
            partner_name: partner || sourceTenant,
            target_name: targetTenant || "",
            updated_provider_display_names: { ...changed_service_provider_object },
            target_db: tenantObject?.db_name || "",
            target_db_tenant_id: tenantObject?.id || 0,

          }
          : {}

      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        if (action === "create" && (parsedData.error_type && parsedData.error_type == "Warning"))
          Modal.info({
            title: "Validation Error",
            content:
              parsedData.message ||
              "An error occurred while submitting Partners bieng Providers data. Please try again.",
            centered: true,
          });
      } else {
        //  notification.success({
        //     message: "Success",
        //     description: "Successfully saved.",
        //     style: messageStyle,
        //     placement: "top",
        //   });
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      // Modal.error({
      //   title: "Submit Error",
      //   content:
      //     error instanceof Error
      //       ? error.message
      //       : "An unexpected error occurred while submitting data. Please try again.",
      //   centered: true,
      // });
    } finally {
      setLoading(false);
    }
  };
  const handleTargetPartnersChange = (selectedOptions: any) => {
    // Ensure submittedTargetTenants stay selected
    const protectedOptions = submittedTargetTenants.map((opt: any) => ({
      label: opt.label || opt, // adjust if stored differently
      value: opt.value || opt,
    }));

    // Merge back submittedTargetTenants with whatever is selected
    const mergedOptions = [
      ...protectedOptions,
      ...(selectedOptions || []).filter(
        (opt: any) => !submittedTargetTenants.some((sub: any) => sub.value === opt.value)
      ),
    ];

    setFilteredTargetTenant(mergedOptions);
  };

  const CustomMultiValueRemove = (props: any) => {
    const { data } = props;
    const isSubmitted = submittedTargetTenants.some(
      (opt: any) => opt.value === data.value
    );

    if (isSubmitted) {
      return null; // disable remove button
    }
    return <components.MultiValueRemove {...props} />;
  };
  const handlePartnerSearch = () => {
    fetchPartnerToProviderData()
    fetchTargetPartnerDetails()
  }

  const validatePartnerToProviderFields = () => {
    let isValid = true
    if (!sourceTenant) {
      setSourceTenantError("Source Partner is Required")
      isValid = false
    }
    else {
      setSourceTenantError("")
    }
    if (!targetTenant) {
      setTargetTenantError("Target Partner is Required")
      isValid = false
    }
    else {
      setTargetTenantError("")
    }
    if (!customerGroup && selectedFAN.length === 0 && selectedBAN.length === 0) {
      setPartnerProviderError("Either Customer group or FAN/BAN required ")
      isValid = false
    }
    else {
      setPartnerProviderError("")
    }
    if (isValid) {
      handlePartnerProviderSave()
    }
    else {
      return
    }
  }

  const hasDuplicateProviders = (data: any[]) => {
    const seen = new Set<string>();

    for (const row of data) {
      const provider = row.service_provider_display_name?.trim();
      if (seen.has(provider)) {
        return true; // duplicate found
      }
      seen.add(provider);
    }

    return false; // no duplicates
  }
  const hasEmptyProviders = (data: any[]) => {
    return data.some(
      (row) =>
        !row.service_provider_name ||
        row.service_provider_name.trim() === "" ||
        !row.service_provider_display_name ||
        row.service_provider_display_name.trim() === ""
    );
  };
  const handlePartnerProviderSave = async () => {
    console.log("partnerProviderEditedTable", partnerProviderEditedTable)
    const hasDuplicates = hasDuplicateProviders(partnerProviderEditedTable || [])
    const hasEmptyValues = hasEmptyProviders(partnerProviderEditedTable || [])
    console.log("isvalid", hasDuplicates)
    if (!hasDuplicates && !hasEmptyValues) {
      setHasDuplicateDisplayNames(false)
      const isUpdated = await updatePartnerProviderDetails();

      // 🚫 If API returned Warning / Error, stop here
      if (!isUpdated) {
        return;
      }
      // await updatePartnerProviderDetails()
      // if (isPartnerProviderFieldsEditable) {
      await assignPartnerToProvider()
      // }
      await fetchPartnerToProviderData()
      await fetchTargetPartnerDetails()
    }
    else {
      if (hasDuplicates) {
        setHasDuplicateDisplayNames(true)
        Modal.warning({
          title: "Duplicate Warning",
          content:
            "The Display Name is already available. Please choose a different Display Name",
          centered: true,
        });
      }
      else {
        Modal.warning({
          title: "Validation Warning",
          content:
            "The Display Name and Provider Name  are required.",
          centered: true,
        });
      }

    }

  }
  const handleSourceTenantChange = (selectedOption: any) => {
    const value = selectedOption?.value || null
    if (value) {
      setSourceTenant(value);
      const target_tenant = value !== partner ? partner : null
      setTargetTenant(target_tenant)
    }
    else {
      setSourceTenant(null)
      setTargetTenant(null)
      setFilteredTargetTenant([...filteredTargetTenant])

    }
  };

  const authenticateSync = async () => {
    try {
      const url = ENV_ROUTES.OPTIMIZATION_SYNC_LAMBDA;
      const data = {
        key_name: "integration_authentication_sync",
        path: "/lambda_sync_jobs_",
        tenant_name: partner || "default_value",
      };

      const response = await axios.post(url, { data });
      const responseData = JSON.parse(response.data.body);

      if (responseData.flag === false) {
        console.error("Data Fetch Error: " + responseData.message);
      } else {
        console.log("Success: authenticate lambda sync successful.");
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  }

  const handleFANChange = (selectedOptions: any) => {
    const values = selectedOptions.map((opt: any) => opt?.value || "");
    setSelectedFAN(values);

    // Build the new BAN options from selected FANs
    const ban_options = values.flatMap((fan: any) => FANBANMapping[fan] || []);
    setBANOptions(ban_options);

    // Remove BANs that are no longer linked to selected FANs
    setSelectedBAN((prevBANs) =>
      prevBANs.filter((ban: any) => ban_options.includes(ban))
    );
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  const customDropdownStyles = {
    ...DropdownStyles,
    menu: (provided: any) => ({
      ...provided,
      zIndex: 11, // Ensure dropdown is above all other elements
    }),
    menuPortal: (provided: any) => ({
      ...provided,
      zIndex: 11, // Ensure portal renders above other elements
    }),
  };


  return (
    <div className="p-2">
      <div className="">

        <form onSubmit={handleSubmit}>
          <div className="tabs-sub-headings flex justify-between">
            <h3>Partner Info</h3>
            {(typeof window !== "undefined" && window.innerWidth < 700) && (
              <button
                type="button"
                onClick={() => toggleSections("partner_info")}
              >
                {openSections["partner_info"] ? (
                  <>
                    <ChevronUpIcon className="ml-2 w-4 h-4" />
                  </>
                ) : (
                  <>
                    <ChevronDownIcon className="ml-2 w-4 h-4" />
                  </>
                )}
              </button>
            )}

          </div>
          {(openSections?.["partner_info"] || (typeof window !== "undefined" && window.innerWidth > 700)) && (
            <div className="grid grid-cols-2 gap-4 mb-6">
              <div>
                <label className="field-label">Partner Name</label>
                <input
                  type="text"
                  className="non-editable-input"
                  value={partnerInfo.partner || "NA"}
                  readOnly
                />
              </div>

              <div>
                <label className="field-label">Sub Partner Name</label>
                <input
                  type="text"
                  className="non-editable-input"
                  value={partnerInfo.sub_partner || "NA"}
                  readOnly
                />
              </div>

              <div>
                <label className="field-label">
                  Email IDs<span className="text-red-500">*</span>
                </label>
                <div className="flex items-center">
                  <input
                    type="text"
                    placeholder="Click on + to add Email"
                    className="input"
                    onBlur={handleEmailBlur}
                    value={`${emailInput ? `${emailInput}` : `${emailList.join("; ")}`
                      }`}
                    onChange={handleEmailChange}
                    onKeyDown={handleKeyDown} // Add onKeyDown event
                  />
                  <button
                    type="button"
                    className="save-btn email-plus"
                    onClick={handleModalAddEmail}
                    disabled={emailList.length === 0 && !isEmailValid}
                  >
                    +
                  </button>
                </div>
                <span className="text-red-500 mt-2">{emailError}</span>
              </div>

              <div>
                <label className="field-label">Logo</label>
                <button
                  type="button"
                  className="input mt-1"
                  onClick={() => setLogoModalOpen(true)}
                >
                  Update Logo
                </button>
                {isLogoUpdated && (<span className="text-sm">Logo Uploaded</span>)}
              </div>

              <div>
                <label className="field-label">From Email</label>
                <input
                  type="text"
                  className="input"
                  value={fromEmail}
                  onChange={(e) => handleInputChange("from_email", e.target.value)}
                  placeholder="Enter From Email"
                />
                {fromEmailError && (
                  <p className="text-red-500 text-sm">{fromEmailError}</p>
                )
                  //  : fromEmail ? (
                  //   <p className="text-sm">Please enter a valid email address.</p>
                  // ) : null
                }
              </div>

              <div>
                <label className="field-label">Sendgrid API</label>
                <input
                  type="password"
                  className="input"
                  value={sendgridApi}
                  onChange={(e) => handleInputChange("sendgrid_api", e.target.value)}
                  placeholder="Enter Sendgrid API"
                />

              </div>
              <div>
                <label className="field-label">
                  Service Provider<span className="text-red-500">*</span>
                </label>
                <Select
                  options={provider_options.map((option) => ({
                    label: option,
                    value: option,
                  }))}
                  value={{ label: serviceProvider, value: serviceProvider }}
                  onChange={handleServiceProvider}
                  className=""
                  styles={DropdownStyles}
                  placeholder="Select Service Provider"
                />
                {serviceProviderError && (
                  <p className="text-red-500 text-sm">{serviceProviderError}</p>
                )}
              </div>
              {/* <div>
                <label className="field-label">Service Provider to</label>
                <Select
                  options={tenantOptions.map((option) => ({
                    label: option,
                    value: option,
                  }))}
                  value={{ label: providerTo, value: providerTo }}
                  onChange={handleServiceProviderToChange}
                  className="disabled:cursor-not-allowed"
                  styles={
                    serviceProvider === "No" || !serviceProvider
                      ? NonEditableDropdownStyles
                      : DropdownStyles
                  }
                  placeholder="Select Service Provider"
                  isDisabled={serviceProvider === "No" || !serviceProvider}
                />
                {providerToError && (
                  <p className="text-red-500 text-sm">{providerToError}</p>
                )}
              </div> */}
              <div>
                <label className="field-label">Change Phone Number Frequency Setting</label>
                <input
                  type="number"
                  value={phoneNumberFrequency}
                  min="0"
                  step="1"
                  className="input"
                  onChange={(e) => {
                    const newFrequency = e.target.value === "" ? 0 : Number(e.target.value);
                    console.log("newTime", newFrequency, typeof newFrequency);
                    setphoneNumberFrequency(newFrequency);
                  }}
                />
              </div>
              {/* Parners being Providers */}
              <div>
                <label className="field-label">Source Partner</label>
                <input
                  type="text"
                  className="non-editable-input"
                  value={partner || "NA"}
                  readOnly
                />
              </div>
              <div>
                <label className="field-label">
                  Target Partners
                </label>
                <Select
                  isMulti
                  options={targetTenantOptions.map(opt => ({ label: opt, value: opt }))}
                  value={filteredTargetTenant}
                  onChange={handleTargetPartnersChange}
                  styles={
                    serviceProvider === "No" || !serviceProvider
                      ? NonEditableDropdownStyles
                      : DropdownStyles
                  }
                  className="disabled:cursor-not-allowed"
                  isDisabled={serviceProvider === "No" || !serviceProvider}
                  components={{ MultiValueRemove: CustomMultiValueRemove }}
                />
                {serviceProviderError && (
                  <p className="text-red-500 text-sm">{serviceProviderError}</p>
                )}
              </div>

              {/* <div className="grid grid-cols-2 gap-4 mb-6"> */}
              <div>
                <label className="field-label">Time Zone</label>
                <Select
                  id="timezone-select"
                  value={timezoneOptions.find(
                    (option) => option.value === selectedTimezone
                  )}
                  onChange={handleTimezoneChange}
                  options={timezoneOptions}
                  isSearchable
                  placeholder="Select a Time Zone"
                  styles={customDropdownStyles}
                  menuPortalTarget={document.body}
                  menuPosition="fixed"
                />
              </div>
              {/* <div className="flex items-center mt-4">
              <label className="field-label">
                Cross Provider Customer Optimization
              </label>
              <Switch
                checked={crossProviderCustomerOptimization}
                onChange={(checked) =>
                  setCrossProviderCustomerOptimization(checked)
                }
                className="ml-4"
              />
            </div> */}
              {/* </div> */}
              {/* {bp_status && (
                <>
                  <div>
                    <label className="field-label">Billing Email</label>
                    <input
                      type="text"
                      className="input"
                      value={billingEmail}
                      onChange={(e) => handleInputChange("billing_email", e.target.value)}
                      placeholder="Enter Billing Email"
                    />
                    {billingEmailError && (
                      <p className="text-red-500 text-sm">{billingEmailError}</p>
                    )
                      //  : fromEmail ? (
                      //   <p className="text-sm">Please enter a valid email address.</p>
                      // ) : null
                    }
                  </div>
                  <div>
                    <label className="field-label">Billing API</label>
                    <input
                      type="password"
                      className="input"
                      value={billingApi}
                      onChange={(e) => handleInputChange("billing_api", e.target.value)}
                      placeholder="Enter Billing API"
                    />

                  </div>
                </>
              )} */}


            </div>
          )}

          {(openSections?.["partner_info"] || !(typeof window !== "undefined" && window.innerWidth < 700)) && (
            <div className="flex justify-end space-x-4">
              <button className="save-btn mb-4" type="submit">
                Submit
              </button>
            </div>
          )}

        </form>

      </div>
      {((isPartnerProviderSectionEnabled || sourceTenantOptions.length === 1) && serviceProvider !== "No") && (
        <>
          <div className="tabs-sub-headings flex justify-between">
            <h3>Partners being Providers</h3>
            {(typeof window !== "undefined" && window.innerWidth < 700) && (
              <button
                type="button"
                onClick={() => toggleSections("partners-providers")}
              >
                {openSections["partners-providers"] ? (
                  <>
                    <ChevronUpIcon className="ml-2 w-4 h-4" />
                  </>
                ) : (
                  <>
                    <ChevronDownIcon className="ml-2 w-4 h-4" />
                  </>
                )}
              </button>
            )}

          </div>
          {(openSections?.["partners-providers"] || (typeof window !== "undefined" && window.innerWidth > 700)) && (
            <>
              <div className="grid grid-cols-3 gap-2 md:gap-4 mb-4">
                <div>
                  <label className="field-label">
                    Source Partner<span className="text-red-500">*</span>
                  </label>
                  <Select
                    options={sourceTenantOptions.map((option) => ({
                      label: option,
                      value: option,
                    }))}
                    value={{ label: sourceTenant, value: sourceTenant }}
                    onChange={handleSourceTenantChange}
                    className=""
                    styles={DropdownStyles}
                    isClearable
                  />
                  {sourceTenantError && (
                    <p className="text-red-500 text-sm">{sourceTenantError}</p>
                  )}
                </div>
                <div>
                  <label className="field-label">
                    Target Partner<span className="text-red-500">*</span>
                  </label>
                  <Select
                    options={sourceTenant && sourceTenant !== partner
                      ? [{ label: partner, value: partner }]
                      : submittedTargetTenants.map((option) => ({
                        label: option?.value || "",
                        value: option?.value || "",
                      }))}
                    value={{ label: targetTenant, value: targetTenant }}
                    onChange={(selectedOption: any) => {
                      setTargetTenant(selectedOption?.value || "");
                      setCustomerGroup("");
                      setSelectedFAN([])
                      setSelectedBAN([])
                      // setCustomerGroupOptions([])
                      // setFANOptions([])
                      setBANOptions([])
                      if (!selectedOption) {
                        setIsPartnerProviderFieldsEditable(true)
                      }
                    }}
                    className=""
                    styles={DropdownStyles}
                    isClearable={!isSubTenant}
                  />
                  {targetTenantError && (
                    <p className="text-red-500 text-sm">{targetTenantError}</p>
                  )}
                </div>
                <div>
                  <div className="flex gap-4 items-center">
                    <button
                      className={`${targetTenant ? "save-btn" : "cancel-btn cursor-not-allowed"} mt-6`}
                      onClick={handlePartnerSearch}
                      disabled={!targetTenant}
                    >
                      Search
                    </button>
                    {progressValue && (
                      <div className="mt-6">
                        <label className="field-label">
                          Progress
                        </label>
                        <ProgressBar value={progressValue} />

                      </div>
                    )}

                  </div>

                </div>
                <div>
                  <label className="field-label">
                    Customer Group (CG)
                  </label>
                  <Select
                    options={customerGroupOptions.map((option) => ({
                      label: option,
                      value: option,
                    }))}
                    value={{ label: customerGroup, value: customerGroup }}
                    onChange={(selectedOption: any) => {
                      setCustomerGroup(selectedOption?.value || "");
                    }}
                    className=""
                    styles={(isPartnerProviderTableEditable && isPartnerProviderFieldsEditable) ? DropdownStyles : NonEditableDropdownStyles}
                    isClearable
                    isDisabled={(!isPartnerProviderTableEditable || !isPartnerProviderFieldsEditable)}
                  />
                  {partnerProviderError && (
                    <p className="text-red-500 text-sm">{partnerProviderError}</p>
                  )}
                </div>
                <div>
                  <label className="field-label">
                    FAN
                  </label>
                  <Select
                    isMulti
                    options={FANOptions
                      .slice()
                      .sort((a, b) => a.localeCompare(b, undefined, { numeric: true }))
                      .map(opt => ({ label: opt, value: opt }))}
                    value={selectedFAN.map((opt: any) => ({ label: opt, value: opt }))}
                    onChange={handleFANChange}
                    styles={(isPartnerProviderTableEditable && isPartnerProviderFieldsEditable) ? DropdownStyles : NonEditableDropdownStyles}
                    className=""
                    isDisabled={(!isPartnerProviderTableEditable || !isPartnerProviderFieldsEditable)}

                  />
                </div>
                <div>
                  <label className="field-label">
                    BAN
                  </label>
                  <Select
                    isMulti
                    options={BANOptions.map(opt => ({ label: opt, value: opt }))}
                    value={selectedBAN.map((opt: any) => ({ label: isCGBAN ? `${opt} - CG` : opt, value: opt }))}
                    onChange={(selectedOptions: any) => {
                      const values = selectedOptions.map((val: any) => (val?.value || ""))
                      setSelectedBAN(values)
                    }
                    }
                    styles={(isPartnerProviderTableEditable && isPartnerProviderFieldsEditable) ? DropdownStyles : NonEditableDropdownStyles}
                    className=""
                    isDisabled={(!isPartnerProviderTableEditable || !isPartnerProviderFieldsEditable)}

                  />
                </div>
              </div>

              {/* Partners to Providers List View */}

              <>
                <div style={{ marginBottom: "1rem" }}>
                  <EditableTableComponent
                    headers={partnerProviderHeaders}
                    initialData={partnerProviderTableData}
                    searchQuery={""}
                    visibleColumns={partnerProviderVisibleColumns}
                    itemsPerPage={100}
                    popupHeading="Partners being Providers"
                    pagination={partnerProviderPagination}
                    headerMap={partnerProviderHeaderMap}
                    serviceProviderOptions={serviceProviderOptions}
                    isEditable={isPartnerProviderTableEditable}
                    targetTenant={targetTenant}
                    setEditedData={setPartnerProviderEditedTable}
                    hasDuplicateDisplayNames={hasDuplicateDisplayNames}
                    setHasDuplicateDisplayNames={setHasDuplicateDisplayNames}
                  />
                </div>

                <div className="flex justify-end">
                  <button
                    className="save-btn my-6"
                    onClick={validatePartnerToProviderFields}
                  >
                    Submit
                  </button>
                </div>
              </>

            </>
          )}
        </>
      )}

      {/* Partner Address Section */}

      <div className="tabs-sub-headings flex justify-between">
        <h3>Partner Address</h3>
        {(typeof window !== "undefined" && window.innerWidth < 700) && (
          <button
            type="button"
            onClick={() => toggleSections("partner_address")}
          >
            {openSections["partner_address"] ? (
              <>
                <ChevronUpIcon className="ml-2 w-4 h-4" />
              </>
            ) : (
              <>
                <ChevronDownIcon className="ml-2 w-4 h-4" />
              </>
            )}
          </button>
        )}


      </div>
      {(openSections?.["partner_address"] || (typeof window !== "undefined" && window.innerWidth > 700)) && (
        <>
          <div className="grid grid-cols-2 gap-4 mb-6">
            {/* Billing Address */}
            <div>
              <h3 className="tabs-sub-sub-headings">Billing Address</h3>
              <div>
                <label className="field-label">Address 1</label>
                <input
                  type="text"
                  className="input mb-2"
                  value={billingAddress1}
                  onChange={(e) => setBillingAddress1(e.target.value)}
                />
              </div>
              <div>
                <label className="field-label">Address 2</label>
                <input
                  type="text"
                  className="input mb-2"
                  value={billingAddress2}
                  onChange={(e) => setBillingAddress2(e.target.value)}
                />
              </div>
              <div>
                <label className="field-label">City</label>
                <input
                  type="text"
                  className="input mb-2"
                  value={billingCity}
                  onChange={(e) => setBillingCity(e.target.value)}
                />
              </div>
              <div>
                <label className="field-label">State</label>
                <input
                  type="text"
                  className="input mb-2"
                  value={billingState}
                  onChange={(e) => setBillingState(e.target.value)}
                />
              </div>
              <div>
                <label className="field-label">Zip Code</label>
                <input
                  type="text"
                  className="input mb-2"
                  value={billingZip}
                  onChange={(e) => setBillingZip(e.target.value)}
                />
                {billingZipError && (
                  <p className="text-red-500 text-sm">{billingZipError}</p>
                )}
              </div>
              <div>
                <label className="field-label">Notes</label>
                <textarea
                  id="comments"
                  value={billingNotes} // Use the comments state
                  onChange={(e) => setBillingNotes(e.target.value)} // Update comments state
                  rows={3} // Adjust the number of rows as needed
                  className="w-full border border-gray-300 rounded-md p-2 focus:outline-none focus:border-[#0ea5e9] focus:shadow-[0_0_0_1px_#1640ff]"
                />
              </div>
            </div>

            {/* Physical Address */}
            <div>
              <h3 className="tabs-sub-sub-headings">Physical Address</h3>
              <div>
                <label className="field-label">Address Line 1</label>
                <input
                  type="text"
                  className="input mb-2"
                  value={physicalAddress1}
                  onChange={(e) => setPhysicalAddress1(e.target.value)}
                />
              </div>
              <div>
                <label className="field-label">Address Line 2</label>
                <input
                  type="text"
                  className="input mb-2"
                  value={physicalAddress2}
                  onChange={(e) => setPhysicalAddress2(e.target.value)}
                />
              </div>
              <div>
                <label className="field-label">Apt or Suite</label>
                <input
                  type="text"
                  className="input mb-2"
                  value={physicalApt}
                  onChange={(e) => setPhysicalApt(e.target.value)}
                />
              </div>
              <div>
                <label className="field-label">City</label>
                <input
                  type="text"
                  className="input mb-2"
                  value={physicalCity}
                  onChange={(e) => setPhysicalCity(e.target.value)}
                />
              </div>
              <div>
                <label className="field-label">State</label>
                <input
                  type="text"
                  className="input mb-2"
                  value={physicalState}
                  onChange={(e) => setPhysicalState(e.target.value)}
                />
              </div>
              <div>
                <label className="field-label">Zip Code</label>
                <input
                  type="text"
                  className="input mb-2"
                  value={physicalZip}
                  onChange={(e) => setPhysicalZip(e.target.value)}
                />
                {physicalZipError && (
                  <p className="text-red-500 text-sm">{physicalZipError}</p>
                )}
              </div>
              <div>
                <label className="field-label">County</label>
                <input
                  type="text"
                  className="input mb-2"
                  value={physicalCounty}
                  onChange={(e) => setPhysicalCounty(e.target.value)}
                />
              </div>
              <div>
                <label className="field-label">Country</label>
                <input
                  type="text"
                  className="input mb-2"
                  value={physicalCountry}
                  onChange={(e) => setPhysicalCountry(e.target.value)}
                />
              </div>

            </div>


          </div>
          <div className="flex justify-end space-x-4">
            <button className="save-btn mb-4" onClick={handlePartnerAddressSubmit}>
              Submit
            </button>
          </div>
        </>
      )}


      {!isAgentPartnerAdmin && (
        <>
          <div className="tabs-sub-headings flex justify-between">
            <h3>Service Providers</h3>
            {(typeof window !== "undefined" && window.innerWidth < 700) && (
              <button
                type="button"
                onClick={() => toggleSections("service_providers")}
              >
                {openSections["service_providers"] ? (
                  <>
                    <ChevronUpIcon className="ml-2 w-4 h-4" />
                  </>
                ) : (
                  <>
                    <ChevronDownIcon className="ml-2 w-4 h-4" />
                  </>
                )}
              </button>
            )}

          </div>
          {(openSections?.["service_providers"] || (typeof window !== "undefined" && window.innerWidth > 700)) && (
            <>
              <div
                style={{
                  display: "flex",
                  justifyContent: "flex-end",
                  marginBottom: "1rem",
                  marginTop: "1rem",
                }}
              >
                <button className="save-btn" type="submit" onClick={handleServiceModal}>
                  <PlusIcon className="h-5 w-5 text-black-500 mr-1" />
                  Add Service Provider
                </button>
              </div>
              <div style={{ marginBottom: "1rem" }}>
                <TableComponent
                  headers={addServiceHeaders}
                  initialData={addServiceTableData}
                  searchQuery={""}
                  visibleColumns={addServiceVisibleColumns}
                  itemsPerPage={100}
                  allowedActions={allowedActions}
                  popupHeading="service providers"
                  pagination={{}}
                  headerMap={addServiceHeaderMap}
                />
              </div>
            </>
          )}
        </>
      )}
      {!isAgentPartnerAdmin && (
        <>
          <div className="tabs-sub-headings flex justify-between">
            <h3>API Connections</h3>
            {(typeof window !== "undefined" && window.innerWidth < 700) && (
              <button
                type="button"
                onClick={() => toggleSections("api_connections")}
              >
                {openSections["api_connections"] ? (
                  <>
                    <ChevronUpIcon className="ml-2 w-4 h-4" />
                  </>
                ) : (
                  <>
                    <ChevronDownIcon className="ml-2 w-4 h-4" />
                  </>
                )}
              </button>
            )}

          </div>
          {(openSections?.["api_connections"] || (typeof window !== "undefined" && window.innerWidth > 700)) && (
            <div className="flex items-center p-4 md:p-8">
              {apiConnections.length > 0 && (
                <div className="grid grid-cols-2 gap-2 md:gap-4">
                  {apiConnections.map((connection: any, index) => (
                    <React.Fragment key={index}>
                      {/* Left Column: Label */}
                      <div className="text-left md:pr-4 text-[16px] md:text-[18px] font-semibold">{connection.label}</div>

                      {/* Right Column: Input Field */}
                      <div>
                        <button
                          className={`px-4 py-2 rounded-lg font-semibold flex items-center gap-2 w-[150px] md:w-[200px] ${targetPartnerProviders.includes(connection.label)
                            ? 'cursor-not-allowed bg-[#7b7c82] text-white'
                            : connection.authenticated
                              ? 'bg-[#1a81c3] text-white'
                              : 'bg-[#ed4859] text-white'
                            }`}
                          onClick={() => { handleAuthenticateModal(connection.label) }}
                          disabled={targetPartnerProviders.includes(connection.label)}
                        >
                          {connection.authenticated ? (
                            <>
                              <CheckCircleIcon className=" h-5 w-5" />
                              Authenticated
                            </>
                          ) : (
                            <>
                              <PlusCircleIcon className=" h-5 w-5" />
                              Authenticate
                            </>
                          )}
                        </button>
                      </div>
                    </React.Fragment>
                  ))}
                </div>
              )}
            </div>
          )}
        </>
      )}

      <EmailModal
        isOpen={isEmailModalOpen}
        emailList={emailList}
        onClose={() => setIsEmailModalOpen(false)}
        onAddEmail={handleAddEmail}
        onRemoveEmail={handleRemoveEmail}
      />

      <AddServiceProvider isOpen={isPopupVisible} onClose={handleCloseModal} onSave={fetchAuthenticateData} />

      <Modal
        title={"Update Logos"}
        open={logoModalOpen}
        onOk={handleLogoUpdate}
        onCancel={() => {
          // resetForm();
          setLogoModalOpen(false)
        }}
        centered
      >
        <>
          <div className="grid grid-cols-1 gap-4 mb-6">
            <div>
              <label className="field-label">Partner Logo</label>
              <input
                type="file"
                className="input"
                accept=".png, .jpg"
                ref={logoFileRef}
              />
              {logoError && (
                <p className="text-red-500 text-sm">{logoError}</p>
                // ) : (
                //   <p className="text-sm">Only .png and .jpg Files are Allowed.</p>
              )}
            </div>
            <div>
              <label className="field-label">Dark Mode Logo</label>
              <input
                type="file"
                className="input"
                accept=".png, .jpg"
                ref={darkModeLogoFileRef}
              />
              {darkModeLogoError && (
                <p className="text-red-500 text-sm">{darkModeLogoError}</p>
                // ) : (
                //   <p className="text-sm">Only .png and .jpg Files are Allowed.</p>
              )}
            </div>
            <div>
              <label className="field-label">Collapsed Logo</label>
              <input
                type="file"
                className="input"
                accept=".png, .jpg"
                ref={collapsedLogoFileRef}
              />
              {collapsedLogoError && (
                <p className="text-red-500 text-sm">{collapsedLogoError}</p>
                // ) : (
                //   <p className="text-sm">Only .png and .jpg Files are Allowed.</p>
              )}
            </div>
            <div>
              <label className="field-label">Dark Mode Collapsed Logo</label>
              <input
                type="file"
                className="input"
                accept=".png, .jpg"
                ref={darkModeCollapsedLogoFileRef}
              />
              {darkModeCollapsedLogoError && (
                <p className="text-red-500 text-sm">{darkModeCollapsedLogoError}</p>
                // ) : (
                //   <p className="text-sm">Only .png and .jpg Files are Allowed.</p>
              )}
            </div>
          </div>
          <p className="text-sm">Only .png and .jpg Files are Allowed.</p>
        </>
      </Modal>
      <Modal
        title={<span className="font-semibold">Confirm Submission</span>}
        open={submitModalOpen}
        onOk={handleFormSubmit}
        onCancel={() => {
          // resetForm();
          setSubmitModalOpen(false);
        }}
        centered
      >
        <p>Do you want to Submit this form</p>
      </Modal>
      {/* Authenticate Modals */}
      {isAuthenticateVisible &&
        <AuthenticateModal
          isOpen={isAuthenticateVisible}
          onCancel={closeAuthenticateModals}
          connection={selectedConncetion}
          details={selectedIntegrationDetail}
          onSave={fetchAuthenticateData}
          callSync={authenticateSync}
        />
      }
      {isTelegenceAuthenticate &&
        <TelegenceAuthenticateModal
          isOpen={isTelegenceAuthenticate}
          onCancel={closeAuthenticateModals}
          connection={selectedConncetion}
          details={selectedIntegrationDetail}
          onSave={fetchAuthenticateData}
          callSync={authenticateSync}
        />
      }
      {isKoreAuthenticate &&
        <KoreAuthenticateModal
          isOpen={isKoreAuthenticate}
          onCancel={closeAuthenticateModals}
          connection={selectedConncetion}
          details={selectedIntegrationDetail}
          onSave={fetchAuthenticateData}
          callSync={authenticateSync}
        />
      }
      {isWebbingAuthenticate &&
        <WebbingAuthenticateModal
          isOpen={isWebbingAuthenticate}
          onCancel={closeAuthenticateModals}
          connection={selectedConncetion}
          details={selectedIntegrationDetail}
          onSave={fetchAuthenticateData}
          callSync={authenticateSync}
        />
      }
      {isBandwidthAuthenticate &&
        <BandwidthAuthenticateModal
          isOpen={isBandwidthAuthenticate}
          onCancel={closeAuthenticateModals}
          connection={selectedConncetion}
          details={selectedIntegrationDetail}
          onSave={fetchAuthenticateData}
          callSync={authenticateSync}
        />
      }
      {isCereTaxAuthenticate &&
        <CereTaxAuthenticateModal
          isOpen={isCereTaxAuthenticate}
          onCancel={closeAuthenticateModals}
          connection={selectedConncetion}
          details={selectedIntegrationDetail}
          onSave={fetchAuthenticateData}
          callSync={authenticateSync}
        />
      }
      {isCyberReefAuthenticate &&
        <CyberReefAuthenticateModal
          isOpen={isCyberReefAuthenticate}
          onCancel={closeAuthenticateModals}
          connection={selectedConncetion}
          details={selectedIntegrationDetail}
          onSave={fetchAuthenticateData}
          callSync={authenticateSync}
        />
      }
      {isPondIOTAuthenticate &&
        <PondIotAuthenticateModal
          isOpen={isPondIOTAuthenticate}
          onCancel={closeAuthenticateModals}
          connection={selectedConncetion}
          details={selectedIntegrationDetail}
          onSave={fetchAuthenticateData}
          callSync={authenticateSync}
        />
      }
      {isQualificationAuthenticate &&
        <QualificationAuthenticateModal
          isOpen={isQualificationAuthenticate}
          onCancel={closeAuthenticateModals}
          connection={selectedConncetion}
          details={selectedIntegrationDetail}
          onSave={fetchAuthenticateData}
          callSync={authenticateSync}
        />
      }
      {isRevIOAuthenticate &&
        <RevIotAuthenticateModal
          isOpen={isRevIOAuthenticate}
          onCancel={closeAuthenticateModals}
          connection={selectedConncetion}
          details={selectedIntegrationDetail}
          onSave={fetchAuthenticateData}
          callSync={authenticateSync}
        />
      }
      {isDefaultAuthenticate &&
        <DefaultAuthenticateModal
          isOpen={isDefaultAuthenticate}
          onCancel={closeAuthenticateModals}
          connection={selectedConncetion}
          details={selectedIntegrationDetail}
          onSave={fetchAuthenticateData}
          callSync={authenticateSync}
        />}

    </div>
  );
};

export default PartnerInfo;
