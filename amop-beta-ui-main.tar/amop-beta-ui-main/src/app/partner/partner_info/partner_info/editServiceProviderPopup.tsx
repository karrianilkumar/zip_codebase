import React, { useEffect, useState } from "react";
import { Modal, DatePicker, Select, Checkbox, Spin, Switch } from "antd";
import { ChevronDownIcon, PlusIcon } from "@heroicons/react/24/outline";
import { useAuth } from "@/app/components/auth_context";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { fireSideCannons } from "@/app/components/confetti";

interface EditServiceProviderProps {
  isOpen: boolean;
  onClose: () => void;
  // onSubmit: (values: any) => void;
}

interface CustomField {
  field: any;
  value: any;
  isNew?: any;
  isEdited?: any;
}

// Define options interfaces
interface SelectOption {
  value: string;
  label: string;
}

const EditServiceProvider: React.FC<{
  visible: boolean;
  onClose: () => void;
  rowData: any;
  isOpen: boolean;
  action: string;
}> = ({ visible, onClose, rowData, action, isOpen }) => {
  const [isOptimizationEnabled, setIsOptimizationEnabled] = useState(rowData?.write_is_enabled ?? false);
  const [isLoading, setIsLoading] = useState(false);
  const [customFieldsEnabled, setCustomFieldsEnabled] = useState(false);
  const [optIntoCarrier, setOptIntoCarrier] = useState(rowData?.opt_into_carrier_optimization ?? false);
  const [customFields, setCustomFields] = useState<
    { field: string; value: string }[]
  >([]);

  const [serviceProviderSettingList, setServiceProviderSettingList] = useState<
    any[]
  >([]);
  const [validationErrors, setValidationErrors] = useState<{
    [key: string]: string;
  }>({});
  // State for form fields
  const [integrationOptions, setIntegrationOptions] = useState<SelectOption[]>(
    []
  );
  const [integration, setIntegration] = useState<string>();
  const [serviceProviderName, setServiceProviderName] = useState("");
  const [billPeriodEndDay, setBillPeriodEndDay] = useState<
    number | undefined
  >();
  const [billPeriodEndHour, setBillPeriodEndHour] = useState<
    number | undefined
  >();
  const [optimizationStartHour, setOptimizationStartHour] = useState<
    number | undefined
  >();
  const [newValues, setNewValues] = useState<{ [key: number]: string }>({});
  const [focusedIndex, setFocusedIndex] = useState<number | null>(null);
  const [highlightIndex, setHighlightIndex] = useState<string | null>(null);

  // let isReadOnly = rowData?.write_is_enabled;
  const {
    username,
    tenantNames,
    role,
    settabledata,
    setStoredPagination,
    token,
    partner,
    selectedDb,
    metaData,
    firstLastName,
    sessionId,
  } = useAuth();
  const handleCheckboxChange = (e: any) => {
    const newIsOptimizationEnabled = e.target.checked;
    setIsOptimizationEnabled(newIsOptimizationEnabled);
  };

  const handleSwitchChange = () => {
    setCustomFieldsEnabled(!customFieldsEnabled);
  };

  const handleOptChange = () => {
    setOptIntoCarrier(!optIntoCarrier);
  };

  const handleCustomFieldChange = (index: any, key: "field" | "value", value: any) => {
    setCustomFields((prev: CustomField[]) =>
      prev.map((field, i) =>
        i === index
          ? {
            ...field,
            [key]: value, // TypeScript now knows that key is either "field" or "value"
            isEdited: key === "value" && field.value !== value, // Track only "value" changes
          }
          : field
      )
    );
  };

  // Handle input change for adding new values
  const handleNewValueChange = (index: number, value: string) => {
    setNewValues((prev) => ({ ...prev, [index]: value }));
  };

  // Handle adding a new value to the list
  const handleAddCustomFieldValue = (index: number) => {
    setCustomFields((prev) =>
      prev.map((field, i) => {
        if (i !== index) return field;

        const existingValues = field.value.split(";").map((v) => v.trim());
        const newValue = (newValues[index] || "").trim();

        if (!newValue) return field; // Ignore empty input

        const existingIndex = existingValues.indexOf(newValue);
        if (existingIndex !== -1) {
          // If value exists, highlight it instead of adding
          setHighlightIndex(`${index}-${existingIndex}`);
          setTimeout(() => setHighlightIndex(null), 2000);
          return field;
        }

        return {
          ...field,
          value: [...existingValues, newValue].join(";"),
          isEdited: true,
        };
      })
    );

    setNewValues((prev) => ({ ...prev, [index]: "" })); // Clear input after adding
  };
  // Handle removing an existing value
  const handleRemoveCustomFieldValue = (index: number, subIndex: number) => {
    setCustomFields((prev: CustomField[]) =>
      prev.map((field, i) => {
        if (i === index && ["PDPName", "StaticIPAPN"].includes(field.field)) {
          const currentValues = field.value.split(";").filter(Boolean);
          currentValues.splice(subIndex, 1);
          return {
            ...field,
            value: currentValues.join(";"),
            isEdited: true,
          };
        }
        return field;
      })
    );
  };

  const handleCustomFieldValueChange = (index: number, subIndex: number, newValue: string) => {
    setCustomFields((prev: CustomField[]) =>
      prev.map((field, i) => {
        if (i === index && ["PDPName", "StaticIPAPN"].includes(field.field)) {
          const splitValues = field.value.split(";").map((item: any) => item.trim()); // Split existing value
          splitValues[subIndex] = newValue; // Update the specific edited value
          return {
            ...field,
            value: splitValues.join(";"), // Reconstruct value with updated parts
            isEdited: field.value !== splitValues.join(";"), // Track change
          };
        }
        return field;
      })
    );
  };


  const addCustomField = () => {
    setCustomFields((prevFields) => [...prevFields, { field: "", value: "", isNew: true, }]);
  };

  const removeCustomField = (index: number) => {
    const updatedFields = customFields.filter((_, i) => i !== index);
    setCustomFields(updatedFields);
  };

  useEffect(() => {
    fetchFilterOptions();
  }, []);
  const fetchData = async () => {
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/service_provider_list_view",
        role_name: role,
        parent_module: "Partner",
        feature_module_name: "Partner Info",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };
      console.log(getCurrentDateTime(), "Show the log time request sent from ui to lambda");
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      console.log(getCurrentDateTime(), "Show the log time response sent from lambda to ui");
      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching Inventory data. Please try again.",
          centered: true,
        });
      } else {
        const tableData_ = parsedData?.data || [];
        settabledata(tableData_)

      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
    }
  };
  useEffect(() => {
    if (rowData) {
      setServiceProviderName(rowData.service_provider_name || "");
      setBillPeriodEndDay(rowData.bill_period_end_day || undefined);
      setBillPeriodEndHour(rowData?.bill_period_end_hour || 0);
      setOptimizationStartHour(
        rowData.optimization_start_hour_local_time || undefined
      );
      setIsOptimizationEnabled(!!rowData.write_is_enabled);
      setIntegration(rowData?.integration_id || "");
    }
  }, [rowData]);

  useEffect(() => {
    if (serviceProviderSettingList && rowData?.id) {
      console.log("Entered useEffect");
      console.log("rowData.id:", rowData?.id);

      const filteredSettings = serviceProviderSettingList.filter(
        (setting) => setting.service_provider_id === rowData.id
      );

      console.log(filteredSettings, "Filtered settings...");

      const mappedFields = filteredSettings.map((setting) => ({
        field: setting.setting_key,
        value: setting.setting_value,
        isNew: false,
      }));

      console.log(mappedFields, "Mapped fields...");

      setCustomFields(mappedFields);
    }
  }, [serviceProviderSettingList, rowData?.id]);

  const validateForm = () => {
    const errors: Record<string, string> = {};

    // Validate service provider name
    if (!serviceProviderName.trim()) {
      errors.service_provider_name = "Service provider name is required.";
    }

    // // Validate integration selection
    if (!integration) {
      errors.integration = "Integration is required.";
    }

    // Validate bill period end day
    if (!billPeriodEndDay) {
      errors.bill_period_end_day = "Bill period end day is required!";
    } else if (billPeriodEndDay < 1 || billPeriodEndDay > 28) {
      errors.bill_period_end_day =
        "Bill period end day must be between 1 and 28";
    }

    // Validate bill period end hour
    if (billPeriodEndHour=== null || 
      billPeriodEndHour=== undefined ) {
      errors.bill_period_end_hour = "Bill period end hour is required!";
    } else if (billPeriodEndHour < 0 || billPeriodEndHour > 23) {
      errors.bill_period_end_hour =
        "Bill period end hour must be between 1 and 23";
    }

    // Validate optimization start hour
    // if (!optimizationStartHour) {
    //   errors.optimization_start_hour = "Optimization start hour is required!";
    // }
    if (optimizationStartHour && (optimizationStartHour < 0 || optimizationStartHour > 23)) {
      errors.optimization_start_hour =
        "Optimization start hour must be between 0 and 23";
    }


    return errors;
  };

  const fetchFilterOptions = async () => {
    setIsLoading(true);
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/service_provider_list_view",
        role_name: role,
        parent_module: "Partner",
        feature_module_name: "Partner Info",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      const integrationList = parsedData.integration_list;

      // Transform integration list into Select options
      const serviceProviders = integrationList.map((provider: any) => {
        const [key, value] = Object.entries(provider)[0];
        return { value, label: key };
      });
      setIntegrationOptions(serviceProviders);

      // Save the service_provider_setting_list
      setServiceProviderSettingList(
        parsedData.service_provider_setting_list
      );
      console.log(parsedData, "parsedData...")
      console.log(serviceProviderSettingList, "serviceProviderSettingList...");
    } catch (error) {
      console.error(error);
    } finally {
      setIsLoading(false);
    }
  };

  const callRunDBScript = async (formData: any) => {
    const url = ENV_ROUTES.SIM_MANAGEMENT;
    const transformedCustomFields = customFieldsEnabled
    ? customFields
      .filter((field: any) => field.isEdited) // Only include fields where value was edited
      .map((field) => ({
        service_provider_id: rowData.id,
        is_active: true,
        setting_key: field.field, // Unchanged key
        setting_value: field.value, // Updated value
      }))
    : [];
    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/run_db_script",
      role_name: role,
      module_name: "Service Provider",
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
      update_flag: true,
      delete_flag: false,
      custom_fields: transformedCustomFields,
      request_received_at: getCurrentDateTime(),
      Partner: partner || "default_value",
      data: {
        serviceprovider: [{

          ...(formData.id && { id: formData.id }),
          ...(formData.bill_period_end_day && { bill_period_end_day: formData.bill_period_end_day }),
          ...(formData.bill_period_end_hour && { bill_period_end_hour: formData.bill_period_end_hour }),
          ...(formData.optimization_start_hour_local_time && { optimization_start_hour_local_time: formData.optimization_start_hour_local_time }),
          ...(formData.service_provider_name && { display_name: formData.service_provider_name }),
          ...(formData.service_provider_name && { service_provider_name: formData.service_provider_name }),
          ...(formData.integration_id && { integration_id: formData.integration_id }),
          modified_by: firstLastName,
          modified_date: getCurrentDateTime(),
          created_by: firstLastName,
          created_date: getCurrentDateTime(),
          is_active: true,
          ...(formData.id && { id: formData.id }),
          is_deleted: false,
          write_is_enabled: formData.write_is_enabled,
          ...(rowData.register_carrier_service_callback && { register_carrier_service_callback: rowData.register_carrier_service_callback }),
          tenant_id: rowData?.tenant_id || 1,


        }]
      },
    };

    try {
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
    } catch (error) {
    }

  }
  const handleSave = async () => {
    const errors = validateForm();
    setValidationErrors(errors);
    // If errors exist, abort the save process
    if (Object.keys(errors).length > 0) {
      return;
    }
    setIsLoading(true);
    const url = ENV_ROUTES.MODULE_MANAGEMENT;
    const transformedCustomFields = customFieldsEnabled
      ? customFields
        .filter((field: any) => field.isEdited) // Only include fields where value was edited
        .map((field) => ({
          service_provider_id: rowData.id,
          is_active: true,
          setting_key: field.field, // Unchanged key
          setting_value: field.value, // Updated value
        }))
      : [];
    const formData = {
      id: rowData.id,
      integration_id: integration,
      service_provider_name: serviceProviderName,
      bill_period_end_day: billPeriodEndDay,
      bill_period_end_hour: billPeriodEndHour,
      optimization_start_hour_local_time: optimizationStartHour,
      write_is_enabled: isOptimizationEnabled,
      opt_into_carrier_optimization: optIntoCarrier,
      modified_by:firstLastName || username,
    };

    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/submit_update_edit_service_provider",
      role_based: role,
      parent_module: "Partner",
      module_name: "Partner info",
      partner: partner,
      action: "update",
      table_name: "serviceprovider",
      changed_data: formData,
      custom_fields: transformedCustomFields,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
    };

    try {
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      callRunDBScript(formData)
      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message || "An error occurred while saving the data.",
          centered: true,
        });
      } else {
        Modal.success({
          title: "Success",
          content: "Data submitted successfully!",
        });
        fireSideCannons()
        fetchData()
      }
      onClose();
    } catch (error) {
      Modal.error({
        title: "Error",
        content: "There was an error submitting the data.",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const modalHeight =
    typeof window !== "undefined" ? (window.innerHeight * 2.0) / 4 : 0;

  return (
    <Modal
      title={
        <div className="mt-[-10px]">
          <span
            className="text-[23px]"
            style={{ fontFamily: "Calibri, sans-serif" }}
          >
            Edit Service Provider
          </span>
        </div>
      }
      open={isOpen}
      onCancel={onClose}
      footer={null}
      centered
      width={800}
    // style={{maxHeight: modalHeight}}
    >
      <>
        {isLoading ? (
          <>
            <div
              className="flex justify-center items-center"
              style={{
                height: modalHeight,
                overflowY: "auto",
                overflowX: "hidden",
              }}
            >
              <Spin size="large" />
            </div>
          </>
        ) : (
          <>
            {" "}
            <div
              className="space-y-4"
              style={{
                height: modalHeight,
                overflowY: "auto",
                overflowX: "hidden",
              }}
            >
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label
                    className="field-label"
                    style={{ fontFamily: "Calibri, sans-serif" }}
                  >
                    Integration
                    <span className="text-red-500">*</span>
                  </label>
                  <Select
                    showSearch
                    filterOption={(input: any, option: any) =>
                      option?.label.toLowerCase().includes(input.toLowerCase())
                    }
                    notFoundContent="no options avilable"
                    placeholder="Select integration"
                    suffixIcon={
                      <ChevronDownIcon className="w-4 h-4 mt-1 text-gray-600" />
                    }
                    className=" w-full"
                    style={{ height: "43px" }}
                    value={integration}
                    onChange={(value) => {
                      const selectedOption = integrationOptions.find(
                        (option) => option.label === value
                      );
                      setIntegration(value); // Set the label (key)
                      if (selectedOption) {
                      }
                    }}
                    options={integrationOptions}
                  // disabled={!isOptimizationEnabled}
                  ></Select>
                  {validationErrors.integration && (
                    <span className="text-red-500 mt-2">
                      {validationErrors.integration}
                    </span>
                  )}
                </div>

                <div>
                  <label
                    className="field-label "
                    style={{ fontFamily: "Calibri, sans-serif" }}
                  >
                    Service Provider Name
                    <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    className={`input w-full`}
                    placeholder="Enter service provider name"
                    value={serviceProviderName}
                    onChange={(e) => setServiceProviderName(e.target.value)}
                  // disabled={!isOptimizationEnabled}
                  />
                  {validationErrors.service_provider_name && (
                    <span className="text-red-500 mt-2">
                      {validationErrors.service_provider_name}
                    </span>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label
                    className="field-label"
                    style={{ fontFamily: "Calibri, sans-serif" }}
                  >
                    Bill Perid End Day(1-28)
                    <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    className={`input w-full`}
                    placeholder="Enter bill period end day"
                    min={1}
                    max={28}
                    onInput={(e) => {
                      const value = parseInt(e.currentTarget.value);
                      if (value < 1) e.currentTarget.value = "";
                    }}
                    value={billPeriodEndDay}
                    onChange={(e) =>
                      setBillPeriodEndDay(Number(e.target.value))
                    }
                  // disabled={!isOptimizationEnabled}
                  />
                  {validationErrors.bill_period_end_day && (
                    <span className="text-red-500 mt-2">
                      {validationErrors.bill_period_end_day}
                    </span>
                  )}
                </div>

                <div>
                  <label
                    className="field-label"
                    style={{ fontFamily: "Calibri, sans-serif" }}
                  >
                    Bill Period End Hour(0-23)
                    <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="number"
                    className={`input w-full`}
                    placeholder="Enter bill period end hour"
                    min={0}
                    max={23}
                    onInput={(e) => {
                      const value = parseInt(e.currentTarget.value);
                      if (value < 0) e.currentTarget.value = "";
                    }}
                    value={billPeriodEndHour}
                    onChange={(e) =>
                      setBillPeriodEndHour(Number(e.target.value))
                    }
                  // disabled={!isOptimizationEnabled}
                  />
                  {validationErrors.bill_period_end_hour && (
                    <span className="text-red-500 mt-2">
                      {validationErrors.bill_period_end_hour}
                    </span>
                  )}
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label
                    className="field-label"
                    style={{ fontFamily: "Calibri, sans-serif" }}
                  >
                    Optimization Start Hour(0-23)
                    {/* <span className="text-red-500">*</span> */}
                  </label>
                  <input
                    type="number"
                    className={`input w-full`}
                    placeholder="Enter optimization start hour"
                    min={0}
                    max={23}
                    onInput={(e) => {
                      const value = parseInt(e.currentTarget.value);
                      if (value < 0) e.currentTarget.value = "";
                    }}
                    value={optimizationStartHour}
                    onChange={(e) =>
                      setOptimizationStartHour(Number(e.target.value))
                    }
                  // disabled={!isOptimizationEnabled}
                  // style={{ cursor: isOptimizationEnabled ? "default" : "not-allowed" }}
                  />
                  {validationErrors.optimization_start_hour && (
                    <span className="text-red-500 mt-2">
                      {validationErrors.optimization_start_hour}
                    </span>
                  )}
                </div>
                <div className="flex items-center mt-4 md:mt-8">
                  <div>
                    <Checkbox
                      checked={isOptimizationEnabled}
                      onChange={handleCheckboxChange}
                      className="checkbox"

                    >
                      Write Enabled
                    </Checkbox>
                  </div>
                  <div>
                    <Checkbox
                      checked={customFieldsEnabled}
                      onChange={handleSwitchChange}
                      className="checkbox"
                    >
                      Custom Fields
                    </Checkbox>
                  </div>
                    {serviceProviderName.toLowerCase().includes("telegence") && (
                      <div>
                        <Checkbox
                          checked={optIntoCarrier}
                          onChange={handleOptChange}
                          className="checkbox"
                        >
                          Opt Into Carrier Optimization
                        </Checkbox>
                      </div>
                    )}
                </div>
                {customFieldsEnabled && (
                  <div className="space-y-2 md:space-y-4 mt-2 md:mt-4">
                    <h2
                      className="text-[18px] md:text-[23px] font-semibold"
                      style={{ fontFamily: "Calibri, sans-serif" }}
                    >
                      Custom Settings
                    </h2>
                    {customFields.map((field, index) => (
                      <div
                        key={index}
                        className="grid grid-cols-1 md:grid-cols-2 gap-4 md:w-[500px]"
                      >
                        <span className="p-2 text-md mt-2">{field.field}: </span>
                        {/* <input
                          placeholder="Custom field name"
                          value={field.field}
                          onChange={(e) =>
                            handleCustomFieldChange(
                              index,
                              "field",
                              e.target.value
                            )
                          }
                          className="input flex-1 min-w-[200px] p-2 border rounded"
                        /> */}
                        {["PDPName", "StaticIPAPN"].includes(field.field) ? (
                          <div
                            className={`flex gap-2 flex-wrap border rounded p-2 min-w-[250px] md:min-w-[400px] ${focusedIndex === index ? "border-blue-500" : ""}`}
                            onFocus={() => setFocusedIndex(index)}
                            onBlur={(e) => {
                              if (!e.currentTarget.contains(e.relatedTarget)) {
                                setFocusedIndex(null);
                              }
                            }}
                            tabIndex={0} // Makes div focusable
                          >
                            {/* Display existing values as buttons with a cross icon */}
                            {field.value.split(";").filter(Boolean).map((item, subIndex) => (
                              <div
                                key={subIndex}
                                className={`flex items-center bg-[#bfdbfe] rounded px-3 py-1 transition duration-200 ${highlightIndex === `${index}-${subIndex}` ? "bg-blue-400" : ""
                                  }`}
                              >
                                <span>{item.trim()}</span>
                                <button onClick={() => handleRemoveCustomFieldValue(index, subIndex)} className="ml-2">
                                  x
                                </button>
                              </div>
                            ))}


                            {/* Input field only appears when div is focused */}
                            {focusedIndex === index && (
                              <input
                                className="p-2 outline-none bg-transparent"
                                placeholder="Add value..."
                                value={newValues[index] || ""}
                                onChange={(e) => handleNewValueChange(index, e.target.value)}
                                onKeyDown={(e) => e.key === "Enter" && handleAddCustomFieldValue(index)}
                                onBlur={() => handleAddCustomFieldValue(index)}
                              />
                            )}
                          </div>

                        ) : (
                          <input
                            placeholder="Value"
                            value={field.value}
                            onChange={(e) => handleCustomFieldChange(index, "value", e.target.value)}
                            className="input border rounded min-w-[250px] md:min-w-[400px]"
                          />
                        )}


                        <div>
                          {/* <button
                            onClick={() => removeCustomField(index)}
                            className="cancel-btn"
                          >
                            Remove
                          </button> */}
                        </div>
                      </div>
                    ))}
                    {/* <button onClick={addCustomField} className="save-btn">
                      <PlusIcon className="h-4 w-4 text-black-600 mr-1" />
                      Add Field
                    </button> */}
                  </div>
                )}
              </div>

              <div className="flex justify-center gap-2 mt-6">
                <button
                  onClick={onClose}
                  className="cancel-btn"
                  style={{ fontFamily: "Calibri, sans-serif" }}
                >
                  Cancel
                </button>
                <button
                  onClick={handleSave}
                  className="save-btn"
                  style={{ fontFamily: "Calibri, sans-serif" }}
                >
                  Save
                </button>
              </div>
            </div>
          </>
        )}
      </>
    </Modal>
  );
};
export default EditServiceProvider;
