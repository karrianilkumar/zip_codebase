import React, { useEffect, useState } from 'react';
import { Modal, Button, Spin } from 'antd';
import axios from 'axios';
import { ENV_ROUTES } from '@/app/components/routes/route_constants';
import { getCurrentDateTime } from '@/app/components/header_constants';
import { useAuth } from '@/app/components/auth_context';
import { fireSideCannons } from '@/app/components/confetti';

interface WebbingAuthenticateModalProps {
  isOpen: boolean;
  onCancel: () => void;
  connection: string;
  details: any
  onSave: () => void;
  callSync: () => void;
}

const WebbingAuthenticateModal: React.FC<WebbingAuthenticateModalProps> = ({
  isOpen,
  onCancel,
  connection,
  details,
  onSave,
  callSync
}) => {
  const [isLoading, setIsLoading] = useState(false);
  const [apiUsername, setApiUsername] = useState('');
  const [apiKey, setApiKey] = useState('');
  const [apiUrl, setApiUrl] = useState('');
  const [uiUrl, setUiUrl] = useState('');
  const [apiPassword, setApiPassword] = useState('');
  const [verifyApiPassword, setVerifyApiPassword] = useState('');
  const [uiUsername, setUiUsername] = useState('');
  const [uiPassword, setUiPassword] = useState('');
  const [verifyUiPassword, setVerifyUiPassword] = useState('');
  const [emailAddress, setEmailAddress] = useState('');
  const [emailAlias, setEmailAlias] = useState('');
  const [emailPassword, setEmailPassword] = useState('');
  const [verifyEmailPassword, setVerifyEmailPassword] = useState('');
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [showConfirmation, setShowConfirmation] = useState(false);
  const {
    username,
    tenantNames,
    role,
    settabledata,
    setStoredPagination,
    token,
    partner,
    selectedDb,
    metaData,
    firstLastName,
    sessionId,
  } = useAuth();

  const validateFields = () => {
    const newErrors: Record<string, string> = {};

    if (!apiUsername.trim()) newErrors.apiUsername = 'API Username is required';
    if (!apiKey.trim()) newErrors.apiKey = 'API Key is required';
    if (!apiUrl.trim()) newErrors.apiUrl = 'API Url is required';
    if (!uiUrl.trim()) newErrors.uiUrl = 'UI Url is required';
    if (!apiPassword.trim()) newErrors.apiPassword = 'API Password is required';
    if (apiPassword !== verifyApiPassword)
      newErrors.verifyApiPassword = 'Password does not match';
    if (!uiUsername.trim()) newErrors.uiUsername = 'UI Username is required';
    if (!uiPassword.trim()) newErrors.uiPassword = 'UI Password is required';
    if (uiPassword !== verifyUiPassword)
      newErrors.verifyUiPassword = 'Password does not match';
    // if (!emailAddress.trim()) newErrors.emailAddress = 'Email Address is required';
    // if (!emailAlias.trim()) newErrors.emailAlias = 'Email Alias is required';
    // if (!emailPassword.trim()) newErrors.emailPassword = 'Email Password is required';
    // if (emailPassword !== verifyEmailPassword)
    //   newErrors.verifyEmailPassword = 'Password does not match';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = () => {
    if (validateFields()) {
      setShowConfirmation(true);
    }
  };

  const confirmSubmit = async () => {
    console.log('Submitted with:', {
      apiUsername,
      apiUrl,
      uiUrl,
      apiKey,
      uiUsername,
      emailAddress,
      emailAlias,
    });
    setShowConfirmation(false);
    // const errors = validateFields();
    // setErrors(errors);
    // If errors exist, abort the save process
    if (Object.keys(errors).length > 0) {
      return;
    }
    setIsLoading(true);
    const url = ENV_ROUTES.MODULE_MANAGEMENT;

    if (details) {

      details["username"] = apiUsername
      details["password"] = apiPassword
      details["token_value"] = apiKey
      details["modified_by"] = firstLastName
      details["is_active"] = true
      details["is_deleted"] = false
      details["oauth2_custom1"] = apiUrl
      details["oauth2_custom2"] = uiUrl
      details["oauth2_custom3"] = uiUsername
      details["oauth2_custom4"] = uiPassword

      // details['modified_date'] = getCurrentDateTime()
    }



    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/save_integration_details",
      role_based: role,
      parent_module: "Partner",
      module_name: "Partner info",
      partner: partner,
      action: "create",
      table_name: "serviceprovider",
      changed_data: details,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
      service_provider_name:connection || ""
    };

    try {
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: "Submit Error",
          content:
            parsedData.message || "An error occurred while saving the data.",
          centered: true,
        });
      } else {
        callSync()
        Modal.success({
          title: "Success",
          content: "Data submitted successfully!",
        });
        fireSideCannons()
      }
      handlecancel();
    } catch (error) {
      Modal.error({
        title: "Error",
        content: "There was an error submitting the data.",
      });
    } finally {
      setIsLoading(false);
      onSave()
    }
  };
  const handlecancel = () => {
    resetform()
    onCancel();

  }
  const resetform = () => {
    setUiUrl("")
    setApiUrl("")
    setApiKey("")
    setApiUsername("")
    setApiPassword("")
    setVerifyApiPassword("")
    setUiUsername("")
    setUiPassword("")
    setEmailAddress("")
    setEmailAlias("")
    setEmailPassword("")
    setVerifyEmailPassword("")
  }

  return (
    <>
      <Modal
        title="Authentication"
        visible={isOpen}
        onCancel={onCancel}
        centered
        footer={
          <div className="flex justify-center">
            <button onClick={handlecancel} className="mr-2 cancel-btn">
              Cancel
            </button>
            <button className="save-btn" onClick={handleSubmit}>
              Save
            </button>
          </div>
        }
        width={600}
        bodyStyle={{
          maxHeight: '60vh',
          overflowY: 'auto',
          marginTop: '20px',
          marginBottom: '20px',
          paddingRight: '5px'
        }}
      >
        {isLoading ? (
          <>
            <div
              className="flex justify-center items-center"
              style={{
                height: "295px",
              }}
            >
              <Spin size="large" />
            </div>
          </>
        ) : (
          <>
            <div className='p-2'>
              <h3 className="font-semibold text-lg mb-4">API Credentials</h3>

              {/* API Url */}
              <div className="grid grid-cols-12 items-center gap-4 mb-4">
                <label className="col-span-4 text-sm font-medium">
                  API URL <span className="text-red-500">*</span>
                </label>
                <div className="col-span-8">
                  <input
                    type="text"
                    value={apiUrl}
                    onChange={(e) => setApiUrl(e.target.value)}
                    className="w-full border rounded px-3 py-2 input"
                    placeholder="Enter API URL"
                  />
                  {errors.apiUrl && (
                    <div className="text-red-500 text-xs mt-1">{errors.apiUrl}</div>
                  )}
                </div>
              </div>

              {/* API Username */}
              <div className="grid grid-cols-12 items-center gap-4 mb-4">
                <label className="col-span-4 text-sm font-medium">
                  API Username <span className="text-red-500">*</span>
                </label>
                <div className="col-span-8">
                  <input
                    type="text"
                    value={apiUsername}
                    onChange={(e) => setApiUsername(e.target.value)}
                    className="w-full border rounded px-3 py-2 input"
                    placeholder="Enter API Username"
                  />
                  {errors.apiUsername && (
                    <div className="text-red-500 text-xs mt-1">{errors.apiUsername}</div>
                  )}
                </div>
              </div>

              {/* API Password */}
              <div className="grid grid-cols-12 items-center gap-4 mb-4">
                <label className="col-span-4 text-sm font-medium">
                  API Password <span className="text-red-500">*</span>
                </label>
                <div className="col-span-8">
                  <input
                    type="password"
                    value={apiPassword}
                    onChange={(e) => setApiPassword(e.target.value)}
                    className="w-full border rounded px-3 py-2 input"
                    placeholder="Enter API Password"
                  />
                  {errors.apiPassword && (
                    <div className="text-red-500 text-xs mt-1">{errors.apiPassword}</div>
                  )}
                </div>
              </div>

              {/* Verify API Password */}
              <div className="grid grid-cols-12 items-center gap-4 mb-4">
                <label className="col-span-4 text-sm font-medium">
                  Verify API Password <span className="text-red-500">*</span>
                </label>
                <div className="col-span-8">
                  <input
                    type="password"
                    value={verifyApiPassword}
                    onChange={(e) => setVerifyApiPassword(e.target.value)}
                    className="w-full border rounded px-3 py-2 input"
                    placeholder="Re-enter API Password"
                  />
                  {errors.verifyApiPassword && (
                    <div className="text-red-500 text-xs mt-1">{errors.verifyApiPassword}</div>
                  )}
                </div>
              </div>

              {/* API Key */}
              <div className="grid grid-cols-12 items-center gap-4 mb-4">
                <label className="col-span-4 text-sm font-medium">
                  API Key <span className="text-red-500">*</span>
                </label>
                <div className="col-span-8">
                  <input
                    type="text"
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    className="w-full border rounded px-3 py-2 input"
                    placeholder="Enter API Key"
                  />
                  {errors.apiKey && (
                    <div className="text-red-500 text-xs mt-1">{errors.apiKey}</div>
                  )}
                </div>
              </div>

              <h3 className="font-semibold text-lg mt-6 mb-4">UI Credentials</h3>

              {/* API Url */}
              <div className="grid grid-cols-12 items-center gap-4 mb-4">
                <label className="col-span-4 text-sm font-medium">
                  UI URL <span className="text-red-500">*</span>
                </label>
                <div className="col-span-8">
                  <input
                    type="text"
                    value={uiUrl}
                    onChange={(e) => setUiUrl(e.target.value)}
                    className="w-full border rounded px-3 py-2 input"
                    placeholder="Enter UI URL"
                  />
                  {errors.uiUrl && (
                    <div className="text-red-500 text-xs mt-1">{errors.uiUrl}</div>
                  )}
                </div>
              </div>

              {/* UI Username */}
              <div className="grid grid-cols-12 items-center gap-4 mb-4">
                <label className="col-span-4 text-sm font-medium">
                  UI Username <span className="text-red-500">*</span>
                </label>
                <div className="col-span-8">
                  <input
                    type="text"
                    value={uiUsername}
                    onChange={(e) => setUiUsername(e.target.value)}
                    className="w-full border rounded px-3 py-2 input"
                    placeholder="Enter UI Username"
                  />
                  {errors.uiUsername && (
                    <div className="text-red-500 text-xs mt-1">{errors.uiUsername}</div>
                  )}
                </div>
              </div>

              {/* UI Password */}
              <div className="grid grid-cols-12 items-center gap-4 mb-4">
                <label className="col-span-4 text-sm font-medium">
                  UI Password <span className="text-red-500">*</span>
                </label>
                <div className="col-span-8">
                  <input
                    type="password"
                    value={uiPassword}
                    onChange={(e) => setUiPassword(e.target.value)}
                    className="w-full border rounded px-3 py-2 input"
                    placeholder="Enter UI Password"
                  />
                  {errors.uiPassword && (
                    <div className="text-red-500 text-xs mt-1">{errors.uiPassword}</div>
                  )}
                </div>
              </div>

              {/* Verify UI Password */}
              <div className="grid grid-cols-12 items-center gap-4 mb-4">
                <label className="col-span-4 text-sm font-medium">
                  Verify UI Password <span className="text-red-500">*</span>
                </label>
                <div className="col-span-8">
                  <input
                    type="password"
                    value={verifyUiPassword}
                    onChange={(e) => setVerifyUiPassword(e.target.value)}
                    className="w-full border rounded px-3 py-2 input"
                    placeholder="Re-enter UI Password"
                  />
                  {errors.verifyUiPassword && (
                    <div className="text-red-500 text-xs mt-1">{errors.verifyUiPassword}</div>
                  )}
                </div>
              </div>

              <h3 className="font-semibold text-lg mt-6 mb-4">Email Credentials</h3>

              {/* Email Address */}
              <div className="grid grid-cols-12 items-center gap-4 mb-4">
                <label className="col-span-4 text-sm font-medium">
                  Email Address 
                  {/* <span className="text-red-500">*</span> */}
                </label>
                <div className="col-span-8">
                  <input
                    type="email"
                    value={emailAddress}
                    onChange={(e) => setEmailAddress(e.target.value)}
                    className="w-full border rounded px-3 py-2 input"
                    placeholder="Enter Email Address"
                  />
                  {errors.emailAddress && (
                    <div className="text-red-500 text-xs mt-1">{errors.emailAddress}</div>
                  )}
                </div>
              </div>

              {/* Email Alias */}
              <div className="grid grid-cols-12 items-center gap-4 mb-4">
                <label className="col-span-4 text-sm font-medium">
                  Email Alias 
                  {/* <span className="text-red-500">*</span> */}
                </label>
                <div className="col-span-8">
                  <input
                    type="text"
                    value={emailAlias}
                    onChange={(e) => setEmailAlias(e.target.value)}
                    className="w-full border rounded px-3 py-2 input"
                    placeholder="Enter Email Alias"
                  />
                  {errors.emailAlias && (
                    <div className="text-red-500 text-xs mt-1">{errors.emailAlias}</div>
                  )}
                </div>
              </div>

              {/* Email Password */}
              <div className="grid grid-cols-12 items-center gap-4 mb-4">
                <label className="col-span-4 text-sm font-medium">
                  Email Password 
                  {/* <span className="text-red-500">*</span> */}
                </label>
                <div className="col-span-8">
                  <input
                    type="password"
                    value={emailPassword}
                    onChange={(e) => setEmailPassword(e.target.value)}
                    className="w-full border rounded px-3 py-2 input"
                    placeholder="Enter Email Password"
                  />
                  {errors.emailPassword && (
                    <div className="text-red-500 text-xs mt-1">{errors.emailPassword}</div>
                  )}
                </div>
              </div>

              {/* Verify Email Password */}
              <div className="grid grid-cols-12 items-center gap-4 mb-4">
                <label className="col-span-4 text-sm font-medium">
                  Verify Email Password 
                  {/* <span className="text-red-500">*</span> */}
                </label>
                <div className="col-span-8">
                  <input
                    type="password"
                    value={verifyEmailPassword}
                    onChange={(e) => setVerifyEmailPassword(e.target.value)}
                    className="w-full border rounded px-3 py-2 input"
                    placeholder="Re-enter Email Password"
                  />
                  {errors.verifyEmailPassword && (
                    <div className="text-red-500 text-xs mt-1">{errors.verifyEmailPassword}</div>
                  )}
                </div>
              </div>
            </div>
          </>
        )}
      </Modal>

      <Modal
        title="Confirm Submission"
        visible={showConfirmation}
        centered
        onCancel={() => setShowConfirmation(false)}
        footer={
          <div className="flex justify-center">
            <button onClick={() => setShowConfirmation(false)} className="mr-2 cancel-btn">
              Cancel
            </button>
            <button className="save-btn" onClick={confirmSubmit}>
              Confirm
            </button>
          </div>
        }
      >
        <p>Are you sure you want to submit the form?</p>
      </Modal>
    </>
  );
};

export default WebbingAuthenticateModal;
