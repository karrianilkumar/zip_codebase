import React, { useState } from 'react';
import { Modal, Spin } from 'antd';
import { useAuth } from '@/app/components/auth_context';
import { ENV_ROUTES } from '@/app/components/routes/route_constants';
import { getCurrentDateTime } from '@/app/components/header_constants';
import axios from 'axios';
import { fireSideCannons } from '@/app/components/confetti';

interface TelegenceAuthenticateModalProps {
    isOpen: boolean;
    onCancel: () => void;
    connection: string;
    details: any;
    onSave: () => void;
    callSync: () => void;
}

const TelegenceAuthenticateModal: React.FC<TelegenceAuthenticateModalProps> = ({
    isOpen,
    onCancel,
    connection,
    details,
    onSave,
    callSync
}) => {
    const [isLoading, setIsLoading] = useState(false);
    const [baseUrl, setBaseUrl] = useState('');
    const [clientId, setClientId] = useState('');
    const [clientSecret, setClientSecret] = useState('');
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [verifyPassword, setVerifyPassword] = useState('');
    const {
        username: user_name,
        tenantNames,
        role,
        settabledata,
        setStoredPagination,
        token,
        partner,
        selectedDb,
        metaData,
        firstLastName,
        sessionId,
    } = useAuth();
    const [errors, setErrors] = useState<Record<string, string>>({});
    const [isConfirmOpen, setIsConfirmOpen] = useState(false); // Confirmation modal state

    const handleValidation = () => {
        const newErrors: Record<string, string> = {};
        if (!baseUrl.trim()) newErrors.baseUrl = 'Base URL is mandatory';
        if (!clientId.trim()) newErrors.clientId = 'Client ID is mandatory';
        if (!clientSecret.trim()) newErrors.clientSecret = 'Client Secret is mandatory';
        if (!username.trim()) newErrors.username = 'Username is mandatory';
        if (!password.trim()) newErrors.password = 'Password is mandatory';
        if (!verifyPassword.trim()) newErrors.verifyPassword = 'Verify Password is mandatory';
        if (password && verifyPassword && password !== verifyPassword) {
            newErrors.verifyPassword = 'Passwords do not match';
        }
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = () => {
        if (handleValidation()) {
            setIsConfirmOpen(true); // Open the confirmation modal
        }
    };

    const handleConfirmSubmit = async () => {
        // Proceed with form submission
        console.log('Form Submitted:', {
            baseUrl,
            clientId,
            clientSecret,
            username,
            password,
        });
        setIsConfirmOpen(false);
        // const errors = validateFields();
        // setErrors(errors);
        // If errors exist, abort the save process
        if (Object.keys(errors).length > 0) {
            return;
        }
        setIsLoading(true);
        if(details){

            details["oauth2_custom2"]=baseUrl
            details["oauth2_client_id"] =clientId
            details["oauth2_client_secret"] =clientSecret
            details["username"] =username
            details["password"] =password
            details["modified_by"] = user_name
            details['modified_date'] = getCurrentDateTime()
        }

        const data = {
            tenant_name: partner || "default_value",
            username: user_name,
            firstLastName: firstLastName,
            path: "/save_integration_details",
            role_based: role,
            parent_module: "Partner",
            module_name: "Partner info",
            partner: partner,
            action: "create",
            table_name: "serviceprovider",
            changed_data: details,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
            ...metaData,
            sessionID: sessionId,
            service_provider_name:connection || ""
        };

        try {
            let url = ENV_ROUTES.MODULE_MANAGEMENT;
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                Modal.error({
                    title: "Submit Error",
                    content:
                        parsedData.message || "An error occurred while saving the data.",
                    centered: true,
                });
            } else {
                callSync()
                Modal.success({
                    title: "Success",
                    content: "Data submitted successfully!",
                });
                fireSideCannons()
            }
            handleCancel();
        } catch (error) {
            Modal.error({
                title: "Error",
                content: "There was an error submitting the data.",
            });
        } finally {
            setIsLoading(false);
            onSave()
        }

    };
    const handleCancel = () => {
        resetform()
        onCancel();
        setIsConfirmOpen(false);

    }
    const handleCancelConfirm =()=>{
        setIsConfirmOpen(false);
    }
   
    const resetform = () => {

    }

    return (
        <>
            <Modal
                title="Authentication"
                visible={isOpen}
                onCancel={onCancel}
                width={500}
                footer={
                    <div className="flex justify-center space-x-4">
                        <button onClick={handleCancel} className="cancel-btn">
                            Cancel
                        </button>
                        <button className="save-btn" onClick={handleSubmit}>
                            Save
                        </button>
                    </div>
                }
            >
                {isLoading ? (
                    <>
                        <div
                            className="flex justify-center items-center"
                            style={{
                                height: "295px",
                            }}
                        >
                            <Spin size="large" />
                        </div>
                    </>
                ) : (
                    <>
                <div className="space-y-4">
                    {/* Base URL */}
                    <div className="grid grid-cols-12 items-center gap-4 mb-4">
                        <label className="col-span-4 text-sm font-medium">
                            Base URL <span className="text-red-500">*</span>
                        </label>
                        <div className="col-span-8">
                        <input
                            type="text"
                            value={baseUrl}
                            onChange={(e) => setBaseUrl(e.target.value)}
                            className="w-full border rounded px-3 py-2 input"
                            placeholder="Enter Base URL"
                        />
                        {errors.baseUrl && (
                        <div className="text-red-500 text-xs mt-1">{errors.baseUrl}</div>
                    )}

                        </div>
                        
                    </div>
                    
                    {/* Client ID */}
                    <div className="grid grid-cols-12 items-center gap-4 mb-4">
                        <label className="col-span-4 text-sm font-medium">
                            Client ID <span className="text-red-500">*</span>
                        </label>
                        <div className="col-span-8">
                        <input
                            type="text"
                            value={clientId}
                            onChange={(e) => setClientId(e.target.value)}
                            className="w-full border rounded px-3 py-2 input"
                            placeholder="Enter Client ID"
                        />
                        {errors.clientId && (
                        <div className="text-red-500 text-xs mt-1">{errors.clientId}</div>
                    )}
                        </div>
                        
                    </div>
                    

                    {/* Client Secret */}
                    <div className="grid grid-cols-12 items-center gap-4 mb-4" >
                        <label className="col-span-4 text-sm font-medium">
                            Client Secret <span className="text-red-500">*</span>
                        </label>
                        <div className="col-span-8">
                        <input
                            type="password"
                            value={clientSecret}
                            onChange={(e) => setClientSecret(e.target.value)}
                            className="w-full border rounded px-3 py-2 input"
                            placeholder="Enter Client Secret"
                        />
                         {errors.clientSecret && (
                        <div className="text-red-500 text-xs mt-1">{errors.clientSecret}</div>
                         )}
                        </div>
                        
                    </div>
                   

                    {/* Username */}
                    <div className="grid grid-cols-12 items-center gap-4 mb-4">
                        <label className="col-span-4 text-sm font-medium">
                            Username <span className="text-red-500">*</span>
                        </label>
                        <div  className="col-span-8">
                        <input
                            type="text"
                            value={username}
                            onChange={(e) => setUsername(e.target.value)}
                             className="w-full border rounded px-3 py-2 input"
                            placeholder="Enter Username"
                        />
                        {errors.username && (
                        <div className="text-red-500 text-xs mt-1">{errors.username}</div>
                    )}
                        </div>
                        
                    </div>
                    

                    {/* Password */}
                    <div className="grid grid-cols-12 items-center gap-4 mb-4">
                        <label className="col-span-4 text-sm font-medium">
                            Password <span className="text-red-500">*</span>
                        </label>
                        <div  className="col-span-8">
                        <input
                            type="password"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className="w-full border rounded px-3 py-2 input"
                            placeholder="Enter Password"
                        />
                        {errors.password && (
                        <div className="text-red-500 text-xs mt-1">{errors.password}</div>
                    )}
                    </div>
                    </div>
                    

                    {/* Verify Password */}
                    <div className="grid grid-cols-12 items-center gap-4 mb-4">
                        <label className="col-span-4 text-sm font-medium">
                            Verify Password <span className="text-red-500">*</span>
                        </label>
                        <div  className="col-span-8">
                        <input
                            type="password"
                            value={verifyPassword}
                            onChange={(e) => setVerifyPassword(e.target.value)}
                             className="w-full border rounded px-3 py-2 input"
                            placeholder="Re-enter Password"
                        />
                         {errors.verifyPassword && (
                        <div className="text-red-500 text-xs mt-1">{errors.verifyPassword}</div>
                    )}
                    </div>
                    </div>
                   
                </div>
                </>
            )}
            </Modal>

            {/* Confirmation Modal */}
            <Modal
                title="Confirm Submission"
                visible={isConfirmOpen}
                centered
                onCancel={handleCancelConfirm}
                footer={
                    <div className="flex justify-center space-x-4">
                        <button onClick={handleCancelConfirm} className="cancel-btn">
                            Cancel
                        </button>
                        <button className="save-btn" onClick={handleConfirmSubmit}>
                            Confirm
                        </button>
                    </div>
                }
            >
                <p>Are you sure you want to submit</p>
            </Modal>
        </>
    );
};

export default TelegenceAuthenticateModal;
