"use client";

import React, { useEffect, useState } from "react";
import { usePartnerStore } from "../partnerStore";
import { EyeIcon, EyeSlashIcon } from "@heroicons/react/24/outline";
import { Button, Modal, notification, Spin, Tooltip } from "antd";
import Select, { components } from "react-select";
import { useAuth } from "@/app/components/auth_context";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { DropdownStyles } from "@/app/components/css/dropdown";
import { fireSideCannons } from "@/app/components/confetti";

const messageStyle = {
    fontSize: '14px',
    fontWeight: 'bold',
    padding: '16px',
};

// Define the type of the form values
const ProviderChargeMapping: React.FC = () => {

    const [loading, setLoading] = useState(true);
    const { username, role, partner, token, selectedDb, metaData, selectedBillingDb, firstLastName, sessionId } = useAuth();
    const { partnerData } = usePartnerStore.getState();
    const [initialValues, setInitialValues] = useState<any>([])
    const [changedValues, setChangedValues] = useState<any>([])

    const [formattedData, setFormattedData] = useState<any>([])
    const [providers, setProviders] = useState<any>([])
    const [productOptions, setProductOptions] = useState<any>([])
    const [productTypeOptions, setProductTypeOptions] = useState<any>([])
    const [tooltipVisible, setTooltipVisible] = useState<{ [key: string]: boolean }>({});
    const [serviceProvidersList, setServiceProvidersList] = useState<any[]>([]);
    const [serviceTypeOptions, setServiceTypeOptions] = useState<any[]>([]);
    const [selectedM2MTypes, setSelectedM2MTypes] = useState<any[]>([]);
    const [selectedMobilityTypes, setSelectedMobilityTypes] = useState<any[]>([]);
    const partnerFeaures = partnerData["Customer groups"]?.headers_map?.["Customer groups"]?.module_features || [];

    // Filter out already selected values for each Select
    const getAvailableOptions = (allOptions: any[], selectedOptions: any[]) => {
        const selectedValues = selectedOptions.map((opt) => JSON.stringify(opt.value));
        return allOptions.filter(
            (opt) => !selectedValues.includes(JSON.stringify(opt.value))
        );
    };

    const handleServiceTypeMapping = (selectedOptions: any, type: string) => {
        // const selectedOptions_ = selectedOptions.map((option: any) => option.value);
        console.log("selectedOptions", selectedOptions)
        if (type === "m2m") {
            setSelectedM2MTypes(selectedOptions);
        }
        else {
            setSelectedMobilityTypes(selectedOptions);
        }
    };
    const fetchServiceTypeData = async (action: string) => {
        setLoading(true);
        try {
            let changedData: any = {}
            if (action === "update") {
                const selectedM2MTypes_ = selectedM2MTypes.length > 0 ? selectedM2MTypes.map((option: any) => option.value) : []
                const selectedMobilityTypes_ = selectedMobilityTypes.length > 0 ? selectedMobilityTypes.map((option: any) => option.value) : []

                changedData["m2m"] = selectedM2MTypes_
                changedData["mobility"] = selectedMobilityTypes_
            }
            else {
                setSelectedM2MTypes([])
                setSelectedMobilityTypes([])
            }
            const url = ENV_ROUTES.MODULE_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_update_service_type_mapping",
                role_name: role,
                parent_module: "Partner",
                feature_module_name: "Partner Info",
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                action: action,
                ...(action === "update" ? { changed_data: { ...changedData } } : {})
            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                Modal.error({
                    title: "Data Fetch Error",
                    content:
                        parsedData.message ||
                        `An error occurred while ${action === "get" ? "fetching" : "submitting"} Service Type Mapping data. Please try again.`,
                    centered: true,
                });
            } else {
                if (action === "update") {
                    notification.success({
                        message: "Success",
                        description: "Successfully Updated",
                        style: messageStyle,
                        placement: "top",
                    });
                    fireSideCannons()
                }
                else {
                    const serviceProviders_ = parsedData?.service_providers || [];
                    setServiceProvidersList(serviceProviders_);
                    const service_type_mapping_ = parsedData?.service_type_mapping || [];
                    const service_type_options_ = service_type_mapping_.map((opt: any) => ({ value: opt, label: `${opt?.description || ""} - ${opt?.service_type_id || ""}` }))
                    setServiceTypeOptions(service_type_options_);
                    const selected_data_ = parsedData?.selected_data || {}
                    const m2m_ = selected_data_?.m2m || []
                    const mobility_ = selected_data_?.mobility || []

                    console.log("selected_data_", selected_data_)
                    console.log("m2m_", m2m_)
                    console.log("mobility_", mobility_)

                    const selected_m2m_options = m2m_.map((opt: any) => ({ value: opt, label: `${opt?.description || ""} - ${opt?.service_type_id || ""}` }))
                    console.log("selected_m2m_options", selected_m2m_options)

                    setSelectedM2MTypes(selected_m2m_options)
                    const selected_mobility_options = mobility_.map((opt: any) => ({ value: opt, label: `${opt?.description || ""} - ${opt?.service_type_id || ""}` }))
                    setSelectedMobilityTypes(selected_mobility_options)
                    console.log("selected_mobility_options", selected_mobility_options)


                }

            }
        } catch (error) {
            console.error("Error fetching data:", error);
            Modal.error({
                title: "Data Fetch Error",
                content:
                    error instanceof Error
                        ? error.message
                        : "An unexpected error occurred while fetching data. Please try again.",
                centered: true,
            });
        } finally {
            setLoading(false);
        }
    };
    const fetchData = async () => {
        try {
            setLoading(true);
            const url = ENV_ROUTES.MODULE_MANAGEMENT
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_service_provider_config",
                role_name: role,
                parent_module: "Partner",
                modules_list: ["Provider Charge Mapping"],
                feature_module_name: "Partner Info",
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                billing_db_name: selectedBillingDb,
                sessionID: sessionId,
            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                setLoading(false);
                Modal.error({
                    title: "Data Fetch Error",
                    content:
                        parsedData.message ||
                        "An error occurred while fetching data. Please try again.",
                    centered: true,
                });
            } else {
                setLoading(false);
                const rev_products = parsedData?.rev_products || [];
                setProductOptions(rev_products)

                const rev_product_types = parsedData?.rev_product_types || [];
                setProductTypeOptions(rev_product_types)

                const service_provider_tenant_configuration = parsedData?.service_provider_tenant_configuration || []
                setInitialValues(service_provider_tenant_configuration)

                const service_providers = parsedData?.service_providers || []
                setProviders(service_providers)


                const formattedData = service_providers.map((provider: any) => {
                    // Find matching configurations
                    const matchingConfigs = service_provider_tenant_configuration.filter(
                        (config: any) =>
                            config.service_provider_id === provider.id
                        // && config.service_provider_name === provider.service_provider_name
                    );

                    // Create objects for each match
                    return matchingConfigs.map((config: any) => ({
                        provider: provider.service_provider_name,
                        data_charge_product_value: config.rev_product_id ?? config.rev_product_type_id ?? null,
                        billing_data_charge_product_value: config.bill_product_id ?? null,
                        overage_charge_product_value: config.overage_rev_product_id ?? config.overage_rev_product_type_id ?? null,
                        billing_overage_charge_product_value: config.overage_bill_product_id ?? null,
                        sms_charge_product_value: config.sms_rev_product_id ?? config.sms_rev_product_type_id ?? null,
                        billing_sms_charge_product_value: config.sms_bill_product_id ?? null,
                        service_provider_id: provider.id,
                        data_type: config.rev_product_id
                            ? "product"
                            : config.rev_product_type_id
                                ? "productType"
                                : "No Selection",
                        overage_type: config.overage_rev_product_id
                            ? "product"
                            : config.overage_rev_product_type_id
                                ? "productType"
                                : "No Selection",
                        sms_type: config.sms_rev_product_id
                            ? "product"
                            : config.sms_rev_product_type_id
                                ? "productType"
                                : "No Selection",
                    }));
                });

                // Flatten the array and update state
                setFormattedData((prevValues: any) => [...prevValues, ...formattedData.flat()]);

            }
        } catch (error) {
            Modal.error({
                title: "Data Fetch Error",
                content:
                    error instanceof Error
                        ? error.message
                        : "An unexpected error occurred while fetching data. Please try again.",
                centered: true,
            });
        }
    };

    useEffect(() => {
        fetchData();
        fetchServiceTypeData("get")
        setInitialValues([])
        setChangedValues([])
        setFormattedData([])
    }, []);

    const callRunDBScript = async (formData: any) => {
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/run_db_script",
            role_name: role,
            module_name: "Provider Charge Settings",
            access_token: token,
            db_name: selectedDb,
            ...metaData,
            sessionID: sessionId,
            update_flag: true,
            delete_flag: false,
            transfer_name: "service_provider_tenant_configuration_sync",
            request_received_at: getCurrentDateTime(),
            Partner: partner || "default_value",
            data: {
                service_provider_tenant_configuration: [...formData.flat()]
            },
        };

        try {
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
        } catch (error) {
        }

    }

    const submitData = async () => {
        try {
            // const changedData = { ...changedValues }
            // changedData["modified_by"] = username
            // changedData["created_by"] = username
            // changedData["created_date"] = getCurrentDateTime
            // changedData["modified_date"] = getCurrentDateTime

            setLoading(true);
            const url = ENV_ROUTES.MODULE_MANAGEMENT
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/save_service_provider_config",
                role_name: role,
                Partner: partner,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                changed_data: [...changedValues.flat()],
                modified_by: username,
                created_by: username
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                setLoading(false);
                Modal.error({
                    title: "Data Fetch Error",
                    content:
                        parsedData.message ||
                        "An error occurred while submitting data. Please try again.",
                    centered: true,
                });
            } else {
                callRunDBScript(changedValues)
                setLoading(false);
                notification.success({
                    message: 'Success',
                    description: 'Successfully saved.',
                    style: messageStyle,
                    placement: 'top',
                });
                fireSideCannons()
            }
        } catch (error) {
            Modal.error({
                title: "Data Fetch Error",
                content:
                    error instanceof Error
                        ? error.message
                        : "An unexpected error occurred while submitting data. Please try again.",
                centered: true,
            });
        }
        finally {
            setLoading(false)
        }
    };

    // Format the options with grouped structure
    const productOptionsFormatted = productOptions.map((product: any) => ({
        label: product.description ? `${product.description} - ${product.product_id}${product?.billing_flag ? " - BP" : ""}` : `Product - ${product.product_id}`,
        value: product.product_id,
        type: "product",
        searchableText: `${product.description || ""} ${product.product_id}${product?.billing_flag ? " - BP" : ""} product`.trim(),
        billing_flag: product?.billing_flag ? true : false
    }));

    const productTypeOptionsFormatted = productTypeOptions.map((type: any) => ({
        label: type.description ? `${type.description} - ${type.product_type_id}` : `Product Type - ${type.product_type_id}`,
        value: type.product_type_id,
        type: "productType",
        searchableText: `${type.description || ""} ${type.product_type_id} product type`.trim(),
    }));

    const noSelectionOption = {
        label: "No Selection",
        value: "No Selection",
        type: "none",
        searchableText: "No Selection",
    };

    // Add non-selectable, searchable headers
    const groupedOptions = [
        {
            label: "",
            options: [noSelectionOption], // Adding "No Selection" as the first option
        },
        {
            label: "Products",
            options: [...productOptionsFormatted],
        },
        {
            label: "Product Types",
            options: [...productTypeOptionsFormatted],
        },
    ];

    // Custom component to style group labels
    const CustomGroupHeading = (props: any) => (
        <components.GroupHeading {...props} />
    );

    // Custom search filter function
    const filterOption = (option: any, inputValue: string) => {
        if (!inputValue) return true;

        const searchTerm = inputValue.toLowerCase().trim();
        const isProductSearch = searchTerm.includes("product") && !searchTerm.includes("type");
        const isProductTypeSearch = searchTerm.includes("product type");

        // Ensure individual options are searchable
        if (option.data) {
            return option.data.searchableText?.toLowerCase().includes(searchTerm);
        }

        return false;
    };

    // Function to handle selection
    const findSelectedLabel = (selectedValues:any) => {
        const selectedLabels = selectedValues.map((opt:any)=>opt?.label || "")
        return selectedLabels?.join(",")
    };

    const findSelectedOption = (option_type: string, selectedID: any, item: any) => {
        let selectedValue

        if (option_type === "product") {
            selectedValue =
                [...productOptionsFormatted].find(
                    (option) => option.value === selectedID
                ) || {};
        }
        else if (option_type === "productType") {
            selectedValue =
                [...productTypeOptionsFormatted].find(
                    (option) => option.value === selectedID
                ) || {};
        }
        else {
            selectedValue =
                [...productOptionsFormatted, ...productTypeOptionsFormatted].find(
                    (option) => option.value === selectedID
                ) || {};
        }


        return selectedID === "No Selection" ? null : selectedValue || {}
    };

    // Function to handle selection
    const handleSelection = (selectedOption: any, row: any, key: string) => {

        console.log("selectedOption", selectedOption)
        console.log("row", row)
        console.log("key", key)

        if (!selectedOption) return;
        // if (selectedOption && Array.isArray(selectedOption) && selectedOption.length===0) return;
        if (Array.isArray(selectedOption) && selectedOption.length > 2) {
            Modal.warning({
                title: "Validation Error",
                content: "Cannot select more than 2 Products/Product Types",
                centered: true,
            });
            return
        }

        const isBillingFlag = selectedOption.some((opt: any) => (opt?.billing_flag))
        const billingOption = selectedOption.find((opt: any) => (opt?.billing_flag)) ?? null
        const revOption = selectedOption.find((opt: any) => (!opt?.billing_flag)) ?? null

        if (Array.isArray(selectedOption) && selectedOption.length === 2 && (!billingOption || !revOption)) {
            Modal.warning({
                title: "Validation Error",
                content: "Only one Rev.io customer and one Billing Platform customer can be selected. Selecting two customers from the same system is not allowed.",
                centered: true,
            });
            return
        }

        setFormattedData((prevValues: any) =>
            prevValues.map((item: any) =>
                item.service_provider_id === row.service_provider_id &&
                    item.provider === row.provider
                    ? {
                        ...item,
                        ...(key === "data" && {
                            data_charge_product_value: revOption ? revOption.value : null,
                            billing_data_charge_product_value:billingOption ? billingOption.value : null,
                            data_billing_flag: isBillingFlag,
                            data_type: revOption && revOption?.type ? revOption?.type : "product"
                        }),

                        ...(key === "overage" && {
                            overage_charge_product_value: revOption ? revOption.value : null,
                            billing_overage_charge_product_value: billingOption ? billingOption.value : null,
                            overage_billing_flag: isBillingFlag,
                            overage_type: revOption && revOption?.type ? revOption?.type : "product"
                        }),

                        ...(key === "sms" && {
                            sms_charge_product_value: revOption ? revOption.value : null,
                            billing_sms_charge_product_value: billingOption ? billingOption.value : null,
                            sms_billing_flag: isBillingFlag,
                            sms_type: revOption && revOption?.type ? revOption?.type : "product"
                        }),
                    }
                    : item
            )
        );
        setChangedValues((prevValues: any) => {
            // Check if the item already exists in changedValues
            const existingIndex = prevValues.findIndex(
                (item: any) =>
                    item.service_provider_id === row.service_provider_id
                // && item.service_provider_name === row.provider
            );

            // Define key-value mappings based on selectedOption.type
            const updateFields =
                selectedOption.value === "No Selection"
                    ? {
                        ...(key === "data" && { rev_product_id: null, rev_product_type_id: null, bill_product_id: null }),
                        ...(key === "overage" && { overage_rev_product_id: null, overage_rev_product_type_id: null, overage_bill_product_id: null }),
                        ...(key === "sms" && { sms_rev_product_id: null, sms_rev_product_type_id: null, sms_bill_product_id: null }),
                    }
                    : (billingOption && revOption)
                        ? {
                            ...(key === "data" && {
                                rev_product_id: revOption.type === "product" ? revOption.value : null,
                                rev_product_type_id: revOption.type !== "product" ? revOption.value : null,
                                data_billing_flag: isBillingFlag,
                                bill_product_id: billingOption?.value ?? null
                            }),
                            ...(key === "overage" && {
                                overage_rev_product_id: revOption.type === "product" ? revOption.value : null,
                                overage_rev_product_type_id: revOption.type !== "product" ? revOption.value : null,
                                overage_billing_flag: isBillingFlag,
                                overage_bill_product_id: billingOption?.value ?? null
                            }),

                            ...(key === "sms" && {
                                sms_rev_product_id: revOption.type === "product" ? revOption.value : null,
                                sms_rev_product_type_id: revOption.type !== "product" ? revOption.value : null,
                                sms_billing_flag: isBillingFlag,
                                sms_bill_product_id: billingOption?.value ?? null
                            }),
                        }
                        : (billingOption && !revOption)
                            ? {
                                ...(key === "data" && {
                                    rev_product_id: null,
                                    rev_product_type_id: null,
                                    data_billing_flag: isBillingFlag,
                                    bill_product_id: billingOption?.value ?? null
                                }),
                                ...(key === "overage" && {
                                    overage_rev_product_id: null,
                                    overage_rev_product_type_id: null,
                                    overage_billing_flag: isBillingFlag,
                                    overage_bill_product_id: billingOption?.value ?? null
                                }),

                                ...(key === "sms" && {
                                    sms_rev_product_id: null,
                                    sms_rev_product_type_id: null,
                                    sms_billing_flag: isBillingFlag,
                                    sms_bill_product_id: billingOption?.value ?? null
                                }),
                            }
                            : (!billingOption && revOption)
                                ? {
                                    ...(key === "data" && {
                                        rev_product_id: revOption.type === "product" ? revOption.value : null,
                                        rev_product_type_id: revOption.type !== "product" ? revOption.value : null,
                                        data_billing_flag: isBillingFlag,
                                        bill_product_id: null
                                    }),
                                    ...(key === "overage" && {
                                        overage_rev_product_id: revOption.type === "product" ? revOption.value : null,
                                        overage_rev_product_type_id: revOption.type !== "product" ? revOption.value : null,
                                        overage_billing_flag: isBillingFlag,
                                        overage_bill_product_id: null
                                    }),

                                    ...(key === "sms" && {
                                        sms_rev_product_id: null,
                                        sms_rev_product_type_id: null,
                                        sms_billing_flag: false,
                                        sms_bill_product_id: null
                                    }),
                                }
                                : {
                                    ...(key === "data" && {
                                        rev_product_id: null,
                                        rev_product_type_id: null,
                                        data_billing_flag: false,
                                        bill_product_id: null
                                    }),
                                    ...(key === "overage" && {
                                        overage_rev_product_id: null,
                                        overage_rev_product_type_id: null,
                                        overage_billing_flag: false,
                                        overage_bill_product_id: null
                                    }),

                                    ...(key === "sms" && {
                                        sms_rev_product_id: null,
                                        sms_rev_product_type_id: null,
                                        sms_billing_flag: false,
                                        sms_bill_product_id: null
                                    }),
                                };

            if (existingIndex !== -1) {
                // If found in prevValues, update the existing item
                return prevValues.map((item: any, index: number) =>
                    index === existingIndex ? { ...item, ...updateFields } : item
                );
            }

            // If not found in prevValues, check in initialValues
            const matchedItem = initialValues.find(
                (item: any) =>
                    item.service_provider_id === row.service_provider_id
                //  && item.service_provider_name === row.provider
            );

            if (!matchedItem) return prevValues; // If no match, return previous values

            // Create a new updated item
            const updatedItem = { ...matchedItem, ...updateFields };

            // Add the updated item to changedValues
            return [...prevValues, updatedItem];
        });
    };

    const handleVisibility = (index: number, type: string, visible: boolean, isMobile: boolean = false) => {
        const tooltipKey = isMobile ? `mobile_${index}_${type}` : `${index}_${type}`;
        setTooltipVisible((prev) => ({
            ...prev,
            [tooltipKey]: visible,
        }));
    };

    const renderSelectField = (item: any, index: number, type: string, value: any, billingValue: any, label: string, isMobile: boolean = false, option_type: string) => {
        const tooltipKey = isMobile ? `mobile_${index}_${type}` : `${index}_${type}`;

        const selectedRevOption = value ?  findSelectedOption(option_type, value, item) : null
        const selectedBillingOption = billingValue ? findSelectedOption("product", billingValue, item) : null

        let selectedValues: any

        if (selectedRevOption && selectedBillingOption) {
            selectedValues = [
                selectedRevOption, selectedBillingOption
            ]
        }
        else if (!selectedRevOption && selectedBillingOption) {
            selectedValues = [selectedBillingOption]
        }
        else if (selectedRevOption && !selectedBillingOption) {
            selectedValues = [selectedRevOption]
        }
        else {
            selectedValues = []

        }

        return (
            <div className="mb-4 sm:mb-0">
                <label className="block text-sm font-medium text-gray-700 mb-2 sm:hidden">
                    {label}
                </label>
                <Tooltip
                    title={selectedValues.length !== 0 ? findSelectedLabel(selectedValues) : "No selection"}
                    visible={tooltipVisible[tooltipKey]}
                    onVisibleChange={(visible) => handleVisibility(index, type, visible, isMobile)}
                >
                    <div
                        style={{ width: '100%' }}
                        onMouseEnter={() => handleVisibility(index, type, true, isMobile)}
                        onMouseLeave={() => handleVisibility(index, type, false, isMobile)}
                    >
                        <Select
                            isMulti
                            styles={{
                                ...DropdownStyles,
                                groupHeading: (provided) => ({
                                    ...provided,
                                    fontWeight: "bold",
                                    fontSize: "14px",
                                    color: "#333",
                                    backgroundColor: "#f5f5f5",
                                    padding: "5px",
                                }),
                            }}
                            value={selectedValues}
                            className="w-full"
                            onChange={(selectedOption) => {
                                handleVisibility(index, type, false, isMobile);
                                handleSelection(selectedOption, item, type);
                            }}
                            options={groupedOptions}
                            isSearchable
                            filterOption={filterOption}
                            // getOptionLabel={(e) => e.label}
                            components={{ GroupHeading: CustomGroupHeading }}
                        />
                    </div>
                </Tooltip>
            </div>
        );
    };

    return (
        <>
            {loading ? (
                <div className="flex justify-center items-center h-screen">
                    <Spin size="large" />
                </div>
            ) : (
                <>
                    {partnerFeaures.includes("Display Service Type Mapping") && (
                        <div className="p-6">
                            <div className="tabs-sub-headings flex justify-between">
                                <h3>Service Type Mapping</h3>
                            </div>
                            <div className="items-center p-4 md:p-8 space-y-4">
                                <div className="flex space-x-4">
                                    <span className="text-left md:pr-4 text-[16px] md:text-[18px] font-semibold w-[10%] mt-2 toggle-span">M2M</span>
                                    <div className="w-[30%]">
                                        <Select
                                            options={getAvailableOptions(serviceTypeOptions, selectedM2MTypes)}
                                            value={selectedM2MTypes}
                                            onChange={(selectedOptions: any) =>
                                                handleServiceTypeMapping(selectedOptions, "m2m")
                                            }
                                            className=""
                                            styles={DropdownStyles}
                                            // placeholder="Select Service Provider"
                                            isMulti
                                        />
                                    </div>
                                </div>
                                <div className="flex space-x-4">
                                    <span className="text-left md:pr-4 text-[16px] md:text-[18px] font-semibold w-[10%] mt-2 toggle-span">Mobility</span>
                                    <div className="w-[30%]">
                                        <Select
                                            options={getAvailableOptions(serviceTypeOptions, selectedMobilityTypes)}
                                            value={selectedMobilityTypes}
                                            onChange={(selectedOptions: any) =>
                                                handleServiceTypeMapping(selectedOptions, "mobility")
                                            }
                                            className=""
                                            styles={DropdownStyles}
                                            // placeholder="Select Service Provider"
                                            isMulti
                                        />
                                    </div>
                                </div>

                            </div>
                            <div className="flex justify-end space-x-4">
                                <button className="save-btn" onClick={() => { fetchServiceTypeData("update") }}>
                                    Submit
                                </button>
                            </div>
                        </div>

                    )}
                    <div className="optimization-settings-form px-4 sm:px-6 py-4">
                        <div className="tabs-sub-headings flex justify-between">
                            <h3>Charge Mapping</h3>
                        </div>
                        {/* Desktop View - Hidden on mobile */}
                        <div className="hidden sm:block">
                            <form className="grid grid-cols-4 gap-y-2 gap-x-4">
                                {/* Headers */}
                                <div className="font-bold text-md toggle-span">Service Provider</div>
                                <div className="font-bold text-md toggle-span">Billing Data Charge Product/Product Type</div>
                                <div className="font-bold text-md toggle-span">Billing Overage Charge Product/Product Type</div>
                                <div className="font-bold text-md toggle-span">Billing SMS Charge Product/Product Type</div>

                                {formattedData.map((item: any, index: number) => (
                                    <React.Fragment key={`${item.provider}-${index}`}>
                                        {/* Provider */}
                                        <div className="field-label">{item.provider}</div>

                                        {/* Data Charge */}
                                        {renderSelectField(
                                            item,
                                            index,
                                            'data',
                                            item?.data_charge_product_value,
                                            item?.billing_data_charge_product_value,
                                            'Data Charge Product/Product Type',
                                            false,
                                            item?.data_type

                                        )}

                                        {/* Overage Charge */}
                                        {renderSelectField(
                                            item,
                                            index,
                                            'overage',
                                            item?.overage_charge_product_value,
                                            item?.billing_overage_charge_product_value,
                                            'Overage Charge Product/Product Type',
                                            false,
                                            item?.overage_type
                                        )}

                                        {/* SMS Charge */}
                                        {renderSelectField(
                                            item,
                                            index,
                                            'sms',
                                            item?.sms_charge_product_value,
                                            item?.billing_sms_charge_product_value,
                                            'SMS Charge Product/Product Type',
                                            false,
                                            item?.sms_type
                                        )}
                                    </React.Fragment>
                                ))}
                            </form>
                        </div>

                        {/* Mobile View - Hidden on desktop */}
                        <div className="block sm:hidden">
                            <div className="space-y-6">
                                {formattedData.map((item: any, index: number) => (
                                    <div key={`mobile-${item.provider}-${index}`} className="bg-white border border-gray-200 rounded-lg p-4 shadow-sm">
                                        {/* Provider Header */}
                                        <div className="mb-4 pb-3 border-b border-gray-100">
                                            <h3 className="font-bold text-lg text-gray-800">{item.provider}</h3>
                                        </div>

                                        {/* Form Fields */}
                                        <div className="space-y-4">
                                            {/* Data Charge */}
                                            <div>
                                                {/* <label className="block text-sm font-medium text-gray-700 mb-2">
                                                    Billing Data Charge Product/Product Type
                                                </label> */}
                                                {renderSelectField(
                                                    item,
                                                    index,
                                                    'data',
                                                    item?.data_charge_product_value,
                                                    item?.billing_data_charge_product_value,
                                                    'Billing Data Charge Product/Product Type',
                                                    true,
                                                    item?.data_type
                                                )}
                                            </div>

                                            {/* Overage Charge */}
                                            <div>
                                                {/* <label className="block text-sm font-medium text-gray-700 mb-2">
                                                    Billing Overage Charge Product/Product Type
                                                </label> */}
                                                {renderSelectField(
                                                    item,
                                                    index,
                                                    'overage',
                                                    item?.overage_charge_product_value,
                                                    item?.billing_overage_charge_product_value,
                                                    'Billing Overage Charge Product/Product Type',
                                                    true,
                                                    item?.overage_type
                                                )}
                                            </div>

                                            {/* SMS Charge */}
                                            <div>
                                                {/* <label className="block text-sm font-medium text-gray-700 mb-2">
                                                    Billing SMS Charge Product/Product Type
                                                </label> */}
                                                {renderSelectField(
                                                    item,
                                                    index,
                                                    'sms',
                                                    item?.sms_charge_product_value,
                                                    item?.billing_sms_charge_product_value,
                                                    'Billing SMS Charge Product/Product Type',
                                                    true,
                                                    item?.sms_type
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>

                    {/* Save Button */}
                    <div className="flex justify-end space-x-2 px-4 sm:px-6 pb-4" key="buttons">
                        <button
                            key="update"
                            onClick={submitData}
                            className="save-btn"
                            style={{ fontFamily: "Calibri, sans-serif" }}
                        >
                            Save
                        </button>
                    </div>
                </>
            )}
        </>
    );
};

export default ProviderChargeMapping;