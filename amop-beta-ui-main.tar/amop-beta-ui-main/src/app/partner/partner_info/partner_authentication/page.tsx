// app/partner-onboarding-form/partner-info.tsx
"use client";

import React, { useState, useEffect } from "react";
import { usePartnerStore } from "../partnerStore";
import { EyeIcon, EyeSlashIcon } from "@heroicons/react/24/outline";

interface PartnerAuthentication {
  onSubmit: () => void;
}

const PartnerAuthentication: React.FC<PartnerAuthentication> = () => {
  const { partnerData } = usePartnerStore.getState();
  const partnerAuthentication =
    partnerData["Partner authentication"]?.data?.["Partner authentication"] ||
    {};
  const [isSecretVisible, setIsSecretVisible] = useState(false);

  // Function to toggle secret visibility
  const toggleSecretVisibility = () => {
    setIsSecretVisible(!isSecretVisible);
  };
  return (
    <div className="p-2">
      <form>
        <h3 className="tabs-sub-headings">Partner Authentication</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <div>
            <label className="field-label">Client ID</label>
            <input
              type="text"
              className="non-editable-input "
              value={partnerAuthentication?.client_id || "NA"}
              readOnly
            />
          </div>
          <div>
            <label className="field-label">Client Secret</label>
            <div className="relative flex justify-center space-x-2">
              <input
                type={isSecretVisible ? 'text' : 'password'}
                className="non-editable-input pr-10" // Add padding to make space for the icon inside the input
                value={partnerAuthentication?.client_key || ""}
                readOnly
              />

              {/* Eye icon positioned inside the input */}
              <span
                onClick={toggleSecretVisibility}
                className="absolute inset-y-0 right-0 pr-3 flex items-center cursor-pointer"
              >
                {isSecretVisible ? (
                  <EyeSlashIcon className="h-5 w-5 text-gray-500" />
                ) : (
                  <EyeIcon className="h-5 w-5 text-gray-500" />
                )}
              </span>
            </div>


          </div>
        </div>
      </form>
    </div>
  );
};

export default PartnerAuthentication;
