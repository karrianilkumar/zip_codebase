"use client";
import React, { useEffect, useRef, useState } from "react";
import Pagination from "@/app/components/pagination";
import { Modal, Checkbox, notification, Spin, Tooltip, Button, Radio, Select, Input } from "antd";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import ActionItems from "@/app/components/Table-feautures/action-items";
import {
    ArrowUpOutlined,
    ArrowDownOutlined,
    ExclamationCircleOutlined,
    PlusOutlined,
    CloseOutlined,
} from "@ant-design/icons";
import axios from "axios";
import { usePartnerStore } from "@/app/partner/partner_info/partnerStore";
import { useSearchStore } from "@/app/stores/searchStore";
import { useOptimizationStore } from "@/app/stores/optimizationStore";
import { useCustomerRatePlanStore } from "@/app/stores/customerRateplanStore";
import { useAuth } from "@/app/components/auth_context";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { PlusIcon } from "@heroicons/react/24/outline";

interface EditableTableComponentProps {
    headers: string[];
    initialData: { [key: string]: any }[];
    searchQuery: string;
    visibleColumns: string[];
    itemsPerPage: number;
    popupHeading: string;
    advancedFilters?: any;
    generalFields?: any;
    isSelectRowVisible?: boolean;
    headerMap?: any;
    pagination: any;
    height?: any;
    serviceProviderOptions: any[]
    isEditable: boolean;
    hasDuplicateDisplayNames: boolean;
    targetTenant: string | null;
    setEditedData: (value: { [key: string]: any }[]) => void;
    setHasDuplicateDisplayNames: (value: boolean) => void;
}

const EditableTableComponent: React.FC<EditableTableComponentProps> = ({
    headers,
    initialData,
    searchQuery,
    visibleColumns,
    itemsPerPage,
    popupHeading,
    advancedFilters,
    headerMap,
    pagination,
    height,
    serviceProviderOptions,
    isEditable,
    targetTenant,
    setEditedData,
    hasDuplicateDisplayNames,
    setHasDuplicateDisplayNames
}) => {
    const { Option } = Select;

    const [rowData, setRowData] = useState<{ [key: string]: any }[]>(initialData);
    const [currentPage, setCurrentPage] = useState(1);
    const isFirstRender = useRef(true);
    const isFirstSearchRender = useRef(true);
    const isFirstTableDataRender = useRef(true);
    const isFirstAdvancedSearchRender = useRef(true);
    const [sortConfig, setSortConfig] = useState<{ key: string; direction: "ascending" | "descending"; } | null>(null);
    const {
        username,
        role,
        partner,
        tabledata,
        storedpagination,
        advancedStoredpagination,
        combineAdnvaceStoredpagination,
        token,
        selectedDb, metaData,
        sessionId,
        setAdvancedStoredPagination,
        setStoredPagination,
        setCombineAdnvaceStoredpagination,
        firstLastName
    } = useAuth();
    const [totalPages, setTotalPages] = useState(1);
    const [loading, setLoading] = useState(false);
    const { searchData,
        advancedSearchData,
        combineAdnvaceSearchData,
        setOptimizationErrorsData,
        setOptimizationErrorsPagination,
        optimizationErrorsData,
        optimizationErrorsPagination,
        isSearchComponentCall,
        setIsSearchComponentCall
    } = useSearchStore();
    //Viewport height
    const [viewportHeight, setViewportHeight] = useState(window.innerHeight);
    // Add state to track screen width
    const [isSmallScreen, setIsSmallScreen] = useState(false);
    const [addedRowIndex, setAddedRowIndex] = useState<number | null>(null);

    const [filteredSPOptions, setFilteredSPOptions] = useState<any[]>(serviceProviderOptions)

    // Check for small screen on component mount and window resize
    useEffect(() => {
        const checkScreenSize = () => {
            setIsSmallScreen(window.innerWidth < 700);
        };

        // Initial check
        checkScreenSize();

        // Add event listener for window resize
        window.addEventListener('resize', checkScreenSize);

        // Clean up
        return () => window.removeEventListener('resize', checkScreenSize);
    }, []);

    useEffect(() => {
        // setAdvancedStoredPagination(null)
        setStoredPagination(null)
        setCombineAdnvaceStoredpagination(null)
        setIsSearchComponentCall(false)
        const handleResize = () => {
            setViewportHeight(window.innerHeight);
        };

        // Add event listener for window resize
        window.addEventListener("resize", handleResize);

        // Cleanup event listener on component unmount
        return () => {
            window.removeEventListener("resize", handleResize);
        };
    }, []);

    //To display the initial data
    useEffect(() => {
        const newRowData = tabledata.length > 0 ? tabledata : initialData;
        setRowData(initialData);
        setFilteredSPOptions(serviceProviderOptions)
    }, [initialData, tabledata, serviceProviderOptions]);

    useEffect(() => {
        setEditedData(rowData)
    }, [rowData]);

    useEffect(() => {
        if (!rowData || !Array.isArray(rowData)) return;

        // Step 1: Extract selected providers from rowData
        const selectedProviders = rowData.map(
            (row) => row.service_provider_name?.trim()
        );

        // Step 2: Filter out selected ones from available options
        const updatedOptions = serviceProviderOptions.filter(
            (option) => !selectedProviders.includes(option.trim())
        );

        // Step 3: Update state
        setFilteredSPOptions(updatedOptions);
    }, [rowData]);


    useEffect(() => {
        setCurrentPage(1);
        setIsSearchComponentCall(false)
    }, [tabledata, optimizationErrorsData, sortConfig]);

    useEffect(() => {
        setCurrentPage(1);
    }, [totalPages]);

    useEffect(() => {
        let pagination_;
        // let pagination_;
        if (combineAdnvaceStoredpagination) {
            pagination_ = combineAdnvaceStoredpagination
        }
        else if (advancedStoredpagination && !storedpagination) {
            pagination_ = advancedStoredpagination
        }
        else if (storedpagination && !advancedStoredpagination) {
            pagination_ = storedpagination
        }
        else {
            pagination_ = pagination
        }


        const start = pagination_?.start || 1;
        const total = pagination_?.total || 1;
        const end = pagination_?.end || 1;
        const totalPages_ = Math.ceil(total / itemsPerPage);
        setTotalPages(totalPages_);
    }, [tabledata, initialData, pagination, itemsPerPage, currentPage, storedpagination, advancedStoredpagination, optimizationErrorsPagination, combineAdnvaceStoredpagination, sortConfig]);

    //To manage the pagination routes

    const updatePaginator = async () => {
        let start_ = Math.floor((currentPage - 1) * itemsPerPage);
        let end_ = Math.floor((currentPage - 1) * itemsPerPage + 100);
        try {
            const colSortKey = sortConfig ? sortConfig.key : ""
            const colSortDirection = sortConfig ? sortConfig.direction : ""
            const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";
            // if (currentPage !== 1) {
            setLoading(true);
            // }
            if (popupHeading === "Inventory") {
                const url = ENV_ROUTES.SIM_MANAGEMENT;
                const data = {
                    tenant_name: partner || "default_value",
                    username: username,
                    firstLastName: firstLastName,
                    path: "/get_inventory_data",
                    role_name: role,
                    parent_module: "Sim Management",
                    module_name: "SimManagement Inventory",
                    feature_module_name: "Inventory",
                    mod_pages: {
                        start: start_,
                        end: end_,
                    },
                    request_received_at: getCurrentDateTime(),
                    Partner: partner,
                    access_token: token,
                    db_name: selectedDb,
                    ...metaData,
                    sessionID: sessionId,
                    ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
                        : {}),
                };

                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);
                if (parsedData.flag === false) {
                    Modal.error({
                        title: "Data Fetch Error",
                        content:
                            parsedData.message ||
                            "An error occurred while fetching Inventory data. Please try again.",
                        centered: true,
                    });
                } else {
                    const inventoryData =
                        parsedData?.inventory_data || [];
                    setRowData(inventoryData);
                    pagination = parsedData?.pages || pagination
                }
            }
        } catch (err) {
            console.error("Error fetching data:", err);
        } finally {
            setLoading(false);
        }
        // }
    };
    const updateSearchPaginator = async () => {
        let start_ = Math.floor((currentPage - 1) * itemsPerPage);
        let end_ = Math.floor((currentPage - 1) * itemsPerPage + 100);
        const colSortKey = sortConfig ? sortConfig.key : ""
        const colSortDirection = sortConfig ? sortConfig.direction : ""
        const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";
        try {
            setLoading(true);
            const url = ENV_ROUTES.OPEN_SEARCH;
            let data = { ...searchData, username: username, }
            data.data.pages = {
                start: start_,
                end: end_,
            }
            data.data.col_sort = { [colSortKey]: colSortValue }
            const response = await axios.post(url, data);
            const parsedData = JSON.parse(response.data.body);
            console.log("parsed", parsedData);
            if (parsedData?.flag) {
                const tableData = parsedData?.data?.table || [];
                const pagination_ = parsedData?.pages || {};
                if (popupHeading === "Optimization errors" || popupHeading === "Audit Logs") {
                    setRowData(tableData)
                    setOptimizationErrorsPagination(pagination_)
                }
                else {
                    setRowData(tableData);
                    setStoredPagination(pagination_);
                }

                setAdvancedStoredPagination(null)
                setCombineAdnvaceStoredpagination(null)
                if (tableData.length === 0) {
                    Modal.error({
                        title: "No Records found",
                    });
                }
            } else {
                Modal.error({
                    title: "Search error",
                    content:
                        parsedData.error ||
                        "An error occurred while searching. Please try again.",
                });
            }
            console.log(response);
        } catch (error) {
            console.log(error);
        } finally {
            setLoading(false); // Stop loader
        }
    }
    const updateAdvancedSearchPaginator = async () => {
        let start_ = Math.floor((currentPage - 1) * itemsPerPage);
        let end_ = Math.floor((currentPage - 1) * itemsPerPage + 100);
        const colSortKey = sortConfig ? sortConfig.key : ""
        const colSortDirection = sortConfig ? sortConfig.direction : ""
        const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";
        try {
            setLoading(true);
            const url = ENV_ROUTES.OPEN_SEARCH;
            let data = { ...advancedSearchData, username: username, }
            data.data.pages = {
                start: start_,
                end: end_,
            }
            data.data.col_sort = { [colSortKey]: colSortValue }
            const response = await axios.post(url, data);
            const parsedData = JSON.parse(response.data.body);
            console.log("parsed", parsedData);
            if (parsedData?.flag) {
                const tableData = parsedData?.data?.table;
                setRowData(tableData);
                const pagination_ = parsedData?.pages || {}
                setStoredPagination(null)
                setAdvancedStoredPagination(pagination_)
                setCombineAdnvaceStoredpagination(null)
                if (tableData.length === 0) {
                    Modal.error({
                        title: "No Records found",
                    });
                }
            } else {
                Modal.error({
                    title: "Search error",
                    content:
                        parsedData.error ||
                        "An error occurred while searching. Please try again.",
                });
            }
            console.log(response);
        } catch (error) {
            console.log(error);
        } finally {
            setLoading(false); // Stop loader
        }
    }
    const updateCombinedSearchPaginator = async () => {
        const colSortKey = sortConfig ? sortConfig.key : ""
        const colSortDirection = sortConfig ? sortConfig.direction : ""
        const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";
        let start_ = Math.floor((currentPage - 1) * itemsPerPage);
        let end_ = Math.floor((currentPage - 1) * itemsPerPage + 100);
        try {
            setLoading(true);
            const url = ENV_ROUTES.OPEN_SEARCH;
            let data = { ...combineAdnvaceSearchData, username: username, }
            data.data.pages = {
                start: start_,
                end: end_,
            }
            data.data.col_sort = { [colSortKey]: colSortValue }
            const response = await axios.post(url, data);
            const parsedData = JSON.parse(response.data.body);
            console.log("parsed", parsedData);
            if (parsedData?.flag) {
                const tableData = parsedData?.data?.table;
                setRowData(tableData);
                const pagination_ = parsedData?.pages || {}
                setStoredPagination(null)
                setAdvancedStoredPagination(null)
                setCombineAdnvaceStoredpagination(pagination_)
                if (tableData.length === 0) {
                    Modal.error({
                        title: "No Records found",
                    });
                }
            } else {
                Modal.error({
                    title: "Search error",
                    content:
                        parsedData.error ||
                        "An error occurred while searching. Please try again.",
                });
            }
            console.log(response);
        } catch (error) {
            console.log(error);
        } finally {
            setLoading(false); // Stop loader
        }
    }

    useEffect(() => {
        if (!isFirstRender.current) {
            if (combineAdnvaceStoredpagination) {
                updateCombinedSearchPaginator()
            }
            else if (storedpagination && !advancedStoredpagination) {
                updateSearchPaginator()
            }
            else if (advancedStoredpagination && !storedpagination) {
                updateAdvancedSearchPaginator()
            }
            else {
                updatePaginator();
            }

        } else { isFirstRender.current = false }
    }, [currentPage, sortConfig]);

    useEffect(() => {
        if (!isFirstTableDataRender.current && !isSearchComponentCall) {

            if (tabledata !== rowData && currentPage === 1) {
                if (combineAdnvaceStoredpagination) {
                    updateCombinedSearchPaginator()
                }
                else if (storedpagination && !advancedStoredpagination) {
                    updateSearchPaginator()
                }
                else if (advancedStoredpagination && !storedpagination) {
                    updateAdvancedSearchPaginator()
                }
                else {
                    updatePaginator();
                }
            }

        } else { isFirstTableDataRender.current = false }
    }, [tabledata]);

    useEffect(() => {
        // console.log("searchQuery",searchQuery)
        if (!isFirstSearchRender.current) {
            if (searchQuery === "") {
                console.log("searchQuery", isFirstRender)
                if (storedpagination) {
                    updateSearchPaginator()
                }
                else if (advancedStoredpagination) {
                    updateAdvancedSearchPaginator()
                }
                else {
                    updatePaginator();
                }
            }
        } else { isFirstSearchRender.current = false }
    }, [searchQuery]);

    useEffect(() => {
        // console.log("advancedFilters",advancedFilters)
        if (!isFirstAdvancedSearchRender.current) {
            if (advancedFilters) {
                const allEmpty = Object.values(advancedFilters).every(
                    (value) => Array.isArray(value) && value.length === 0
                );

                if (allEmpty) {
                    console.log("advancedFilters", advancedFilters)
                    if (storedpagination) {
                        updateSearchPaginator()
                    }
                    else if (advancedStoredpagination) {
                        updateAdvancedSearchPaginator()
                    }
                    else {
                        updatePaginator();
                    }
                }
            }
        } else { isFirstAdvancedSearchRender.current = false }

    }, [advancedFilters]);
    //For sorting the table
    const handleSort = (key: string) => {
        let direction: "ascending" | "descending" = "ascending";
        if (
            sortConfig &&
            sortConfig.key === key &&
            sortConfig.direction === "ascending"
        ) {
            direction = "descending";
        }
        setCurrentPage(1)
        setSortConfig({ key, direction });
    };

    // Add new row
    const handleAddRow = () => {
        setAddedRowIndex(rowData.length)
        const newRow: any = {};
        headers.forEach((header) => {
            if (visibleColumns.includes(header)) {
                if (header === "target_tenant_name") {
                    newRow[header] = targetTenant
                }
                else if (header === "modified_by") {
                    newRow[header] = firstLastName || username
                }
                else {
                    newRow[header] = "";
                }
            }
        });

        setRowData((prev) => [...prev, newRow]);
    };

    // for Service Provider Name (dropdown)
    const handleServiceProviderChange = (value: string, rowIndex: number, header: any) => {
        setRowData((prevData) => {
            const newData = [...prevData];
            newData[rowIndex] = {
                ...newData[rowIndex],
                [header]: value,
                service_provider_display_name: `${partner}-${value}`
            };
            return newData;
        });
    };

    // for Integration Name (input field)
    const handleDisplayNameChange = (value: string, rowIndex: number, header: any) => {
        setHasDuplicateDisplayNames(false)
        setRowData((prevData) => {
            const newData = [...prevData];
            newData[rowIndex] = {
                ...newData[rowIndex],
                [header]: value,
            };
            return newData;
        });
    };

    const getDuplicateProviders = (data: any[]): string[] => {
        const seen = new Set<string>();
        const duplicates = new Set<string>();

        for (const row of data) {
            const provider = row.service_provider_display_name?.trim();
            if (provider) {
                if (seen.has(provider)) {
                    duplicates.add(provider);
                }
                seen.add(provider);
            }
        }

        return Array.from(duplicates);
    };


    const getRowClass = (row: any): string => {
        const duplicateProviders = getDuplicateProviders(rowData);
        const provider = row.service_provider_display_name?.trim();
        return duplicateProviders.includes(provider) ? "bg-[#ffffcd]" : "";
    };

    //For custom cell rendering
    const renderCell = (cellData: any, column: string, rowIndex: number) => {
        // Service Provider dropdown
        if (
            popupHeading === "Partners being Providers" &&
            headerMap?.[column]?.[0] === "Service Provider" && isEditable && !(rowData[rowIndex].id)
        ) {
            return (
                <Select
                    value={cellData}
                    placeholder="Select Provider"
                    style={{ width: "100%", font: "16px" }}
                    className="table-drp"
                    onChange={(value) => handleServiceProviderChange(value, rowIndex, column)}
                    showSearch
                    allowClear
                >
                    {filteredSPOptions.map((provider: string) => (
                        <Option key={provider} value={provider}>
                            {provider}
                        </Option>
                    ))}
                </Select>
            );
        }

        // Integration Name input
        if (
            popupHeading === "Partners being Providers" &&
            headerMap?.[column]?.[0] === "Display Name" && isEditable
        ) {
            return (
                <Input
                    value={cellData}
                    placeholder="Display Name"
                    className="h-[35px]"
                    onChange={(e) => handleDisplayNameChange(e.target.value, rowIndex, column)}
                />
            );
        }

        // Default: Tooltip with value
        return (
            <Tooltip
                title={`${cellData}`}
                placement="topLeft"
                overlayStyle={{
                    whiteSpace: "normal",
                    maxWidth: "60vw",
                    wordWrap: "break-word",
                    zIndex: 50,
                }}
                getPopupContainer={() => document.body}
            >
                <span>{cellData}</span>
            </Tooltip>
        );
    };
    const handleDeleteRow = (rowIndex: any) => {
        setRowData((prevRows) => prevRows.filter((_, index) => index !== rowIndex));
    }

    if (loading) {
        return (
            <div className="flex justify-center items-center h-screen">
                <Spin size="large" />
            </div>
        );
    }

    // Pagination component to be used in both places
    const paginationComponent = (
        <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
            moduleName={popupHeading}
        />
    );

    return (
        <div>
            {/* Show pagination at top right for small screens */}
            {isSmallScreen && visibleColumns.length > 0 && (
                <div className="flex justify-end mb-2 mr-2">
                    {paginationComponent}
                </div>
            )}

            {/* Add button */}
            {isEditable &&
                <div className="mb-2 flex justify-end">
                    <button
                        onClick={handleAddRow}
                        className={`${((filteredSPOptions.length === 0) || !targetTenant || (rowData.length === serviceProviderOptions.length)) ? "cancel-btn cursor-not-allowed" : "save-btn"}`}
                        disabled={(filteredSPOptions.length === 0) || !targetTenant || (rowData.length === serviceProviderOptions.length)}
                    >
                        <PlusIcon className="h-5 w-5 text-black-500 mr-1" />
                        Add
                    </button>
                </div>
            }


            {/* Table */}
            <div className="overflow-x-auto">
                <div
                    className="overflow-y-auto"
                    style={{
                        height: `${viewportHeight - height}px`
                    }}
                >
                    <table className="table-auto w-full">
                        <thead className="sticky top-0 bg-gray-200 z-10 table-header-row">
                            <tr>
                                {headers.map((header) => (
                                    headerMap && headerMap[header] && visibleColumns.includes(header) && (
                                        <th
                                            key={header}
                                            className={`px-6 py-3 border-b border-gray-300 text-left font-semibold table-header sticky top-0 ${sortConfig && sortConfig.key === header ? "text-blue-600  active-table-header" : ""
                                                }`}
                                            onClick={() => {
                                                handleSort(header);
                                            }}
                                        >
                                            {headerMap?.[header]?.[0] || header}

                                            {
                                                sortConfig && sortConfig.key === header ? (
                                                    sortConfig.direction === "ascending" ? (
                                                        <ArrowUpOutlined className="sorting-arrow" style={{ marginLeft: 8, color: "#2563EB" }} />
                                                    ) : (
                                                        <ArrowDownOutlined className="sorting-arrow" style={{ marginLeft: 8, color: "#2563EB" }} />
                                                    )
                                                ) : (
                                                    <ArrowUpOutlined style={{ marginLeft: 8, opacity: 0.5 }} />
                                                )
                                            }
                                        </th>
                                    )
                                ))}
                                <th
                                    key={"delete"}
                                    className={`px-6 py-3 border-b border-gray-300 !text-center font-semibold table-header sticky top-0`}
                                >
                                </th>

                            </tr>
                        </thead>
                        <tbody>
                            {visibleColumns.length > 0 ? (
                                rowData.length > 0 ? (
                                    rowData.map((row, index) => (
                                        <tr
                                            key={index}
                                            className={hasDuplicateDisplayNames ? getRowClass(row) : index % 2 === 0 ? "bg-gray-50 even-table-row" : ""}
                                        >

                                            {headers.map((header, columnIndex) =>
                                                visibleColumns.includes(header) && headerMap[header] && (
                                                    <td
                                                        key={columnIndex}
                                                        className={`border-b border-gray-300 table-cell`}
                                                    >
                                                        {header && headerMap?.[header]?.[0] && renderCell(row[header], header, index) || ""}
                                                    </td>
                                                )
                                            )}
                                            <td key={index} className="!text-center border-b border-gray-300 table-cell">
                                                {(isEditable && !(row?.id)) ? (

                                                    <button onClick={() => handleDeleteRow(index)}>
                                                        <span className="text-red-500">
                                                            <CloseOutlined />
                                                        </span>
                                                    </button>
                                                ) : (<></>)
                                                }
                                            </td>
                                        </tr>
                                    ))
                                ) : (
                                    <tr>
                                        <td
                                            colSpan={
                                                headers.filter((header) =>
                                                    visibleColumns.includes(header)
                                                ).length + 1
                                            }
                                            className="px-6 py-3 border-b border-gray-300 text-center text-gray-500"
                                        >
                                            No Records Found
                                        </td>
                                    </tr>
                                )
                            ) : null
                            }
                        </tbody>
                    </table>
                </div>
            </div>
            {/* Show pagination at bottom for larger screens */}
            {(!isSmallScreen && visibleColumns.length > 0) && (
                <div className="flex justify-center mt-5">
                    {paginationComponent}
                </div>
            )}

        </div>
    );
};

export default EditableTableComponent;
