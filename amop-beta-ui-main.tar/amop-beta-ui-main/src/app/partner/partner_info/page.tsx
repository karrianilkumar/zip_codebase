"use client";

import React, { useEffect, useRef, useState, Suspense } from "react";
import dynamic from "next/dynamic";
import { useSidebarStore } from "@/app/stores/navBarStore";
import { useRouter } from "next/navigation";
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import { Modal, Spin } from "antd";
import { usePartnerStore } from "./partnerStore";
import { useLogoStore } from "@/app/stores/logoStore";
import { useUserStore } from "./users/createUser/createUserStore";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { usePrivateNetworkStore } from "@/app/stores/privateNetworksStore";
import { useCustomerRatePlanStore } from "@/app/stores/customerRateplanStore";

// Dynamic imports with fallback loading indicators
const PartnerInfo = dynamic(() => import("./partner_info/page"), {
  loading: () => (
    <div className="flex justify-center items-center h-screen">
      <Spin size="large" />
    </div>
  ),
});

const PartnerAuthentication = dynamic(
  () => import("./partner_authentication/page"),
  {
    loading: () => (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    ),
  }
);

const PartnerModuleAccess = dynamic(
  () => import("./partner_module_access/page"),
  {
    loading: () => (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    ),
  }
);

const CustomerGroups = dynamic(() => import("./customer_groups/page"), {
  loading: () => (
    <div className="flex justify-center items-center h-screen">
      <Spin size="large" />
    </div>
  ),
});

const PartnerUsers = dynamic(() => import("./users/page"), {
  loading: () => (
    <div className="flex justify-center items-center h-screen">
      <Spin size="large" />
    </div>
  ),
});
const OptimizationSettings = dynamic(() => import("./optimization_settings/page"), {
  loading: () => (
    <div className="flex justify-center items-center h-screen">
      <Spin size="large" />
    </div>
  ),
});

const ProviderChargeMapping = dynamic(() => import("./provider_charge_mapping/page"), {
  loading: () => (
    <div className="flex justify-center items-center h-screen">
      <Spin size="large" />
    </div>
  ),
});
const BillingPlatformSettings = dynamic(() => import("./billing_platform_settings/page"), {
  loading: () => (
    <div className="flex justify-center items-center h-screen">
      <Spin size="large" />
    </div>
  ),
});

const Partner: React.FC = () => {
  const router = useRouter();
  const setTitle = useLogoStore((state) => state.setTitle);
  const { username, partner, role, token ,selectedDb, metaData,firstLastName,sessionId,setLogoUrl} = useAuth();
  const [loading, setLoading] = useState(true);
  const active_tab = localStorage.getItem("activeTab") || "partnerInfo"
    const active_tabs_list = ["partnerInfo", "partnerRegistration", "partnermoduleaccess", "customergroups","partnerusers","OptimizationSettings","providerChargeMapping" , "billingPlatformSettings"]
    const [activeTab, setActiveTab] = useState(() => {
      // Check if active_tab is in active_tabs_list; default to 'customer' if not
      return active_tabs_list.includes(active_tab) ? active_tab : "partnerInfo";
    });
  const [partnerInfoLoaded, setPartnerInfoLoaded] = useState(false);
  const [partnerAuthenticationLoaded, setPartnerAuthenticationLoaded] =
    useState(false);
  const [partnerModuleAccessLoaded, setPartnerModuleAccessLoaded] =
    useState(false);
  const [customerGroupsLoaded, setCustomerGroupsLoaded] = useState(false);
  const [partnerUsersLoaded, setPartnerUsersLoaded] = useState(false);
  const [optimizationsettingsLoaded, setOptimizationSettingsLoaded] = useState(false);
  const [billingModuleFeatures, setBillingModuleFeatures] = useState(false);
  const title = useLogoStore((state) => state.title);
  const isExpanded = useSidebarStore((state: any) => state.isExpanded);
  const setPartnerInfo = usePartnerStore((state) => state.setPartnerInfo);
  const setPartnerAuthentication = usePartnerStore(
    (state) => state.setPartnerAuthentication
  );
  const {partnerUsersShowActive} = useCustomerRatePlanStore();
  
  const setPartnerModuleAccess = usePartnerStore(
    (state) => state.setPartnerModuleAccess
  );
  const setCustomerGroups = usePartnerStore((state) => state.setCustomerGroups);
  const setPartnerUsers = usePartnerStore((state) => state.setPartnerUsers);
  // const { setLogoUrl, logoUrl } = useLogoStore();
  const {
    tenant,
    role_name,
    sub_tenant,
    setTenant,
    setRoleName,
    setSubTenant,
    setUser_Name,
    emailsList,
    setEmailsList,
  } = useUserStore();

  const { setEditedTableData } = usePrivateNetworkStore();

  const isAgentPartnerAdmin = role?.toLowerCase() === "agent partner admin"
  const isSuperAdmin = role?.toLowerCase() === "super admin"
  useEffect(() => {
    setEditedTableData([])
      // Save activeTab state to localStorage on change
      localStorage.setItem("activeTab", activeTab);
    }, [activeTab]);
  const is_bp_flag = localStorage.getItem("bp_flag");
  const fetchTabData = async (tab: {
    module: string;
    setter: (data: any) => void;
    setLoaded: (loaded: boolean) => void;
  }) => {
    const data = {
      Partner: partner,
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/get_partner_info",
      role_name: role,
      parent_module: "Partner",
      modules_list: [tab.module],
      feature_module_name:"Partner Info",
      pages: {
        "Customer groups": { start: 0, end: 100 },
        "Partner users": { start: 0, end: 100 },
      },
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name:selectedDb,
      ...metaData,
      sessionID: sessionId,
      ...(tab?.module === "Partner users"? {
        active_toggle:partnerUsersShowActive ?? false
      } :{})
    };

    try {
      console.log(getCurrentDateTime(),"Show the log time request sent from ui to lambda");
      
      const response = await axios.post(
        ENV_ROUTES.MODULE_MANAGEMENT,
        { data }
      );
      console.log(getCurrentDateTime(),"Show the log time response sent from lambda to ui");
      if (response && response.status === 200) {
        const parseddata = JSON.parse(response.data.body);
        if (parseddata.flag) {
          tab.setter(parseddata);
          tab.setLoaded(true);
        } else {
          tab.setter(parseddata.message);
          Modal.error({
            title: "Error",
            content: parseddata.message,
            centered: true,
          });
        }
      } else {
        Modal.error({
          title: "Error",
          content: "An error occurred during fetching data.",
          centered: true,
        });
      }
    } catch (error) {
      console.error("Error fetching", tab.module, ":", error);
      Modal.error({
        title: "Error",
        content: "An error occurred during fetching data.",
        centered: true,
      });
    }
  };
  const fetchModuleFeatures = async () => {
    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/get_billing_module_feature",
      role_name: role,
      parent_module: "Partner",
      feature_module_name:"Partner Info",
      access_token: token,
      db_name:selectedDb,
      ...metaData,
      sessionID: sessionId,
    };

    try {
      console.log(getCurrentDateTime(),"Show the log time request sent from ui to lambda");
      
      const response = await axios.post(
        ENV_ROUTES.MODULE_MANAGEMENT,
        { data }
      );
      console.log(getCurrentDateTime(),"Show the log time response sent from lambda to ui");
      if (response && response.status === 200) {
        const parseddata = JSON.parse(response.data.body);
        if (parseddata.flag) {
          console.log("parseddata.billing_settings",parseddata.billing_settings);
          console.log("typeof:", typeof billingModuleFeatures);
          setBillingModuleFeatures(parseddata?.billing_settings);
          // tab.setter(parseddata);
          // tab.setLoaded(true);
        } else {
          // tab.setter(parseddata.message);
          
          Modal.error({
            title: "Error",
            content: parseddata.message,
            centered: true,
          });
        }
      } else {
        Modal.error({
          title: "Error",
          content: "An error occurred during fetching data.",
          centered: true,
        });
      }
    } catch (error) {
      // console.error("Error fetching", tab.module, ":", error);
      Modal.error({
        title: "Error",
        content: "An error occurred during fetching data.",
        centered: true,
      });
    }
  };
  useEffect(() => {
    setEmailsList([]);
  }, [title]);

  const hasFetchedData = useRef(false); // Ref to track if data has been fetched
  useEffect(() => {
    const fetchData = async () => {
      await fetchModuleFeatures();
      const tabs = [
        {
          module: "Partner info",
          setter: setPartnerInfo,
          setLoaded: setPartnerInfoLoaded,
        },
        {
          module: "Partner authentication",
          setter: setPartnerAuthentication,
          setLoaded: setPartnerAuthenticationLoaded,
        },
        {
          module: "Partner module access",
          setter: setPartnerModuleAccess,
          setLoaded: setPartnerModuleAccessLoaded,
        },
        {
          module: "Customer groups",
          setter: setCustomerGroups,
          setLoaded: setCustomerGroupsLoaded,
        },
        {
          module: "Partner users",
          setter: setPartnerUsers,
          setLoaded: setPartnerUsersLoaded,
        },
        
        // { module: "Notifications", setter: setNotifications, setLoaded: setNotificationsLoaded }
      ];

      // Fetch active tab data first
      const activeTabData = tabs.find(
        (tab) => tab.module.replace(/\s+/g, "").toLowerCase() === activeTab
      );
      // await fetchTabData(activeTabData);
      if (activeTabData) {
        await fetchTabData(activeTabData);
      } else {
        console.error("Active tab data not found");
      }

      // Fetch remaining tabs data in the background
      const remainingTabs = tabs.filter(
        (tab) => tab.module.replace(/\s+/g, "").toLowerCase() !== activeTab
      );
      remainingTabs.forEach((tab) => fetchTabData(tab));

      setLoading(false); // Set loading to false after initialization
    };

    if (!hasFetchedData.current) {
      // Check if data has already been fetched
      fetchData();
      hasFetchedData.current = true; // Set to true after fetching
    }
  }, [activeTab]);
 

  const switchToCarrierInfoTab = () => {
    setActiveTab("carrierInfo");
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }



  return (
    <div className="">
      <div
        className={`bg-white shadow-md tabs !h-[70px] ${
          isExpanded
            ? "left-[250px]"
            : "lg:left-[70px] left-0"
        }`}
      >
        <button
          className={`tab-headings ${
            activeTab === "partnerInfo" ? "active-tab-heading" : ""
          }`}
          onClick={() => setActiveTab("partnerInfo")}
        >
          Partner Info
        </button>
        {!isAgentPartnerAdmin && (
          <button
          className={`tab-headings ${
            activeTab === "partnerRegistration" ? "active-tab-heading" : ""
          }`}
          onClick={() => setActiveTab("partnerRegistration")}
        >
          Partner Authentication
        </button>
        )}
        
        <button
          className={`tab-headings ${
            activeTab === "partnermoduleaccess" ? "active-tab-heading" : ""
          }`}
          onClick={() => setActiveTab("partnermoduleaccess")}
        >
          Partner Module Access
        </button>
        <button
        className={`tab-headings ${
          activeTab === "customergroups" ? "active-tab-heading" : ""
        }`}
        onClick={() => setActiveTab("customergroups")}
      >
        Customer Groups
      </button>
        <button
          className={`tab-headings ${
            activeTab === "partnerusers" ? "active-tab-heading" : ""
          }`}
          onClick={() => setActiveTab("partnerusers")}
        >
          Partner Users
        </button>
        {!isAgentPartnerAdmin && (
          <button
          className={`tab-headings ${
            activeTab === "OptimizationSettings" ? "active-tab-heading" : ""
          }`}
          onClick={() => setActiveTab("OptimizationSettings")}
        >
          Optimization Settings
        </button>

        )}
        {!isAgentPartnerAdmin && (
          <button
          className={`tab-headings ${
            activeTab === "providerChargeMapping" ? "active-tab-heading" : ""
          }`}
          onClick={() => setActiveTab("providerChargeMapping")}
        >
          Service and Charge Mapping
        </button>
        )}
        {!isAgentPartnerAdmin && (isSuperAdmin || (billingModuleFeatures)) && (
          <button
          className={`tab-headings ${
            activeTab === "billingPlatformSettings" ? "active-tab-heading" : ""
          }`}
          onClick={() => setActiveTab("billingPlatformSettings")}
        >
          Billing Settings
        </button>
        )}
      </div>
      <Suspense
        fallback={
          <div className="flex justify-center items-center h-screen">
            <Spin size="large" />
          </div>
        }
      >
        <div className="pt-[70px]">
          {activeTab === "partnerInfo" && (
            <PartnerInfo onSubmit={switchToCarrierInfoTab} />
          )}
          {activeTab === "partnerRegistration" && (
            <PartnerAuthentication onSubmit={switchToCarrierInfoTab} />
          )}
          {activeTab === "partnermoduleaccess" && <PartnerModuleAccess />}
          {activeTab === "customergroups" && <CustomerGroups />}
          {activeTab === "partnerusers" && <PartnerUsers />}
          {activeTab === "OptimizationSettings" && <OptimizationSettings />}
          {activeTab === "providerChargeMapping" && <ProviderChargeMapping />}
          {activeTab === "billingPlatformSettings" && <BillingPlatformSettings/>}

          {/* {activeTab === 'notification' && <Notification />} */}
        </div>
      </Suspense>
    </div>
  );
};

export default Partner;
