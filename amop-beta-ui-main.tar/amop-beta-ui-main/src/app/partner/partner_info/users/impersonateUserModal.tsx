'use client'
import React, { useEffect, useState } from "react";
import { Button, Modal, Table, Tooltip, message } from "antd";
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useRouter } from 'next/navigation';
import { useLogoStore } from "@/app/stores/logoStore";
import Select, { SingleValue, StylesConfig } from "react-select";
import { DropdownStyles } from "@/app/components/css/dropdown";
import { fireSideCannons } from "@/app/components/confetti";

type OptionType = {
  value: string;
  label: string;
};
interface ImpersonateUserProps {
  isOpen: boolean;
  onClose: () => void;
  rowData: any;
}

const ImpersonateUserModal: React.FC<ImpersonateUserProps> = ({
  isOpen,
  onClose,
  rowData,
}) => {
  const [loading, setLoading] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const { username, partner, role, token, selectedDb, metaData,setRole, setEmail, setUsername, setSessionId, LogoutChooseTenant, setFirstLastName, firstLastName,sessionId,setTenantNames,setModulesVersionMap, setDynamicColumns} = useAuth();
  const router = useRouter();
  const [selectedPartner, setSelectedPartner] = useState<SingleValue<OptionType>>(null);
  const [roleName, setRoleName] = useState<string>("");
  const [partnerOptions, setPartnerOptions] = useState<any[]>([])
  const [tableData, setTableData] = useState<any>([]);
  
  const setSwiched20User = useLogoStore((state) => state.setSwiched20User);
  const handleImpersonate = () => {
    setShowConfirm(true);
  };
  const handleChoosePartner = () => {
    LogoutChooseTenant();
  };

  const handleConfirmYes = async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.USER_AUTHENTICATION;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/impersonate_login_using_database",
        role_name: role,
        impersonate_data: {
          id: rowData.id,
          first_name: rowData.first_name,
          last_name: rowData.last_name,
          email: rowData.email,
          role: rowData.role,
          phone: rowData.phone,
          address: rowData.address,
          city: rowData.city,
          state: rowData.state,
          zip: rowData.zip,
        },
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
          ...metaData,
        sessionID: sessionId,
        ... (role?.toLowerCase() !== "super admin" ? { login_tenant_name: partner } : {})
      };
      console.log(getCurrentDateTime(),"Show the log time request sent from ui to lambda");
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      console.log(getCurrentDateTime(),"Show the log time response sent from lambda to ui");
      if (parsedData.flag === false) {
        Modal.error({
          title: "Impersonation Error",
          content: parsedData.message || "Error impersonating user. Please try again.",
          centered: true,
        });
      } else {
        // if (parsedData.user_impersonate === true) {
        //   // Redirect user if impersonation is successful
        //   const redirectUrl = `https://sandbox.amop.services/User/Impersonate/0?username=${parsedData.user_name}&returnUrl=https://qa.amop.services/auth/callback`;
        //   router.push(redirectUrl);
        // } else {
          // Update auth context with impersonated user's details
          // setRole(parsedData?.role || "");
          setEmail(parsedData?.email || "");
          setUsername(parsedData?.user_name || "");
          setFirstLastName(parsedData?.first_last_name || "");
          setSessionId(parsedData?.session_id || "");
          const tenant_names = parsedData?.["tenant_names"];
          setTenantNames(tenant_names);
          setSwiched20User(parsedData?.switch_user_2_0 || "False")
          localStorage.setItem('switch_user_2_0',parsedData?.switch_user_2_0 || "False");
          localStorage.setItem('username', parsedData?.user_name || "");
          localStorage.setItem('first_last_name',parsedData?.first_last_name || "");
          const tenant_role_mapping = parsedData["tenant_role_mapping"] || [];
          const role = parsedData["role"] || "";
          if(!tenant_role_mapping || tenant_role_mapping.length===0){
            setRole(role);
            localStorage.setItem('role_name', role);
          }
          // localStorage.setItem('role_name', parsedData?.role || "");
          localStorage.setItem('tenant_role_mapping', JSON.stringify(parsedData?.tenant_role_mapping || []));
          localStorage.setItem('tenant_names', JSON.stringify(tenant_names || []));
          localStorage.setItem('switch_user_20_modules_json',(parsedData?.switch_user_20_modules_json || '{}'));
          localStorage.setItem('session_id',parsedData?.session_id || "")
          setModulesVersionMap(parsedData?.switch_user_20_modules_json || {});
          setDynamicColumns(parsedData?.dynamic_cols || {})
          localStorage.setItem('dynamic_cols',JSON.stringify(parsedData?.dynamic_cols || {}));
          message.success("User impersonated successfully!");
          fireSideCannons()
          onClose();
          handleChoosePartner();
        // }
      }
    } catch (error) {
      Modal.error({
        title: "Impersonation Error",
        content: "Error impersonating user. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleConfirmNo = () => {
    setShowConfirm(false);
  };

  // useEffect(() => {
  //   const rawData = rowData?.tenant_role_mapping || "[]";

  //   // 🛠 Fix invalid JSON by replacing single quotes with double quotes
  //   const safeJSON = rawData.replace(/'/g, '"');

  //   let parsedData = [];
  //   try {
  //     parsedData = JSON.parse(safeJSON);
  //   } catch (error) {
  //     console.error("Error parsing tenant_role_mapping:", error);
  //   }

  //   const updatedData = parsedData.length > 0 ? parsedData : rowData;
  //   console.log("updatedData", updatedData);
  //   const partner_options = updatedData ? updatedData.map((row:any)=>row?.tenant ||"") : []
  //     setPartnerOptions(partner_options)
  //     const defaultPartner = partner_options.length > 0 && partner_options[0] ? { value: partner_options[0], label: partner_options[0] } : null;
  //     setSelectedPartner(defaultPartner);
      
  //   }, [rowData])

  useEffect(() => {
    const rawData = rowData?.tenant_role_mapping || "[]";

    // 🛠 Fix invalid JSON by replacing single quotes with double quotes
    const safeJSON = rawData.replace(/'/g, '"');

    let parsedData = [];
    try {
      parsedData = JSON.parse(safeJSON);
    } catch (error) {
      console.error("Error parsing tenant_role_mapping:", error);
    }

    const updatedData = parsedData.length > 0 ? parsedData : [];
    console.log("updatedData", updatedData);
    const updatedDataWithRoles = updatedData.filter((row: any) => (row.role && row.role !== "none" ))
    let filtered_row_data = [...updatedDataWithRoles]
    if (role?.toLowerCase() !== "super admin") {
      filtered_row_data = updatedDataWithRoles.filter((row: any) => (row.tenant === partner))
    }
    setTableData(filtered_row_data || updatedData || [])
    if (selectedPartner && selectedPartner?.value) { }
    const selected_tenant = selectedPartner?.value || ""
    console.log("selected_tenant", selected_tenant)
    const selected_object = updatedData.find((obj: any) => obj.tenant === selected_tenant)
    console.log("selected_object", selected_object)
    if (selected_object) {
      const role_name = selected_object.role || ""
      setRoleName(role_name)
    }
  }, [selectedPartner])

  const handleSetPartner = async (selectedOption: SingleValue<OptionType>) => {
    setSelectedPartner(selectedOption);
  };

  const columns = [
    {
      title: "Partner",
      dataIndex: "tenant",
      key: "tenant",
      width: 210,
      onCell: () => ({
        style: {
          height: 40,
          paddingTop: 0,
          paddingBottom: 0,
        },
      }),
      render: (text: any) => (
        <Tooltip title={text}>
          <div className="cell-ellipsis" style={{ lineHeight: "40px" }}>
            {text}
          </div>
        </Tooltip>
      ),
    },
    {
      title: "Role",
      dataIndex: "role",
      key: "role",
      width: 210,
      onCell: () => ({
        style: {
          height: 40,
          paddingTop: 0,
          paddingBottom: 0,
        },
      }),
      render: (text: any) => (
        <Tooltip title={text}>
          <div className="cell-ellipsis" style={{ lineHeight: "40px" }}>
            {text}
          </div>
        </Tooltip>
      ),
    },
  ];
  const getScrollConfig = () => {
    // choose your threshold, e.g. more than 4 rows
    if (tableData && tableData.length > 4) {
      return { y: 300 };
    }
    return undefined; // no scroll prop → normal table
  };

  return (
    <Modal
      title={<div style={{ fontSize: 24, fontWeight: 600 }}>Impersonate User</div>}
      visible={isOpen}
      onCancel={onClose}
      footer={[
        <div key="footer" style={{ display: 'flex', justifyContent: 'center' }}>
          <Button key="back" className="cancel-btn" onClick={onClose} style={{ marginRight: 8 }}>
            Cancel
          </Button>
          <Button key="impersonate" className="save-btn" onClick={handleImpersonate}>
            Impersonate
          </Button>
        </div>
      ]}
    >
      {/* ... (rest of the modal content remains the same) */}
      <div className="flex flex-col">
          <div className="flex justify-between mb-4">
          <span className="text-lg font-bold">{rowData.first_name !== "None" ? rowData.first_name : ""} {rowData.last_name !== "None" ? rowData.last_name : ""}</span>
          </div>
          <div className="flex flex-col">
            <div className="flex mb-2">
              <span className="text-sm font-bold" style={{ width: 120, flexShrink: 0 }}>First Name:</span>
              <span className="text-sm"  >{rowData.first_name}</span>
            </div>
            <div className="flex  mb-2">
              <span className="text-sm font-bold" style={{ width: 120, flexShrink: 0 }}>Last Name:</span>
              <span className="text-sm"  >{rowData.last_name}</span>
            </div>
            <div className="flex mb-2">
              <span className="text-sm font-bold" style={{ width: 120, flexShrink: 0 }}>Email:</span>
              <span className="text-sm" >{rowData.email}</span>
            </div>
          {/* <div className="flex mb-2">
            <span className="text-sm font-bold" style={{ width: 120, flexShrink: 0 }}>Partner:</span>
            <Select
              value={selectedPartner}
              onChange={handleSetPartner}
              options={partnerOptions.map((value) => ({ value, label: value }))}
              styles={DropdownStyles}
              className="w-[200px]"
            />
          </div>
            <div className="flex mb-2">
              <span className="text-sm font-bold" style={{ width: 120, flexShrink: 0 }}>Role:</span>
              <span className="text-sm"  >{roleName || rowData.role}</span>
            </div> */}
            {/* <div className="flex  mb-2">
              <span className="text-sm font-bold" style={{ width: 120, flexShrink: 0 }}>Phone:</span>
              <span className="text-sm" >{rowData.phone}</span>
            </div>
            <div className="flex mb-2">
              <span className="text-sm font-bold" style={{ width: 120, flexShrink: 0 }}>Address:</span>
              <span className="text-sm">{rowData.address}</span>
            </div>
            <div className="flex mb-2">
              <span className="text-sm font-bold" style={{ width: 120, flexShrink: 0 }}>City:</span>
              <span className="text-sm">{rowData.city}</span>
            </div>
            <div className="flex mb-2">
              <span className="text-sm font-bold" style={{ width: 120, flexShrink: 0 }}>State:</span>
              <span className="text-sm" >{rowData.state}</span>
            </div>
            <div className="flex mb-2">
              <span className="text-sm font-bold" style={{ width: 120, flexShrink: 0 }}>Postal Code:</span>
              <span className="text-sm" >{rowData.zip}</span>
            </div> */}
            {tableData && tableData.length>0 ? (
              <div style={{ maxHeight: "fit-content" }} className="">
            <Table
              columns={columns || []}
              dataSource={tableData}
              loading={loading}
              size="middle"
              pagination={false}
              className="custom-table"
              scroll={getScrollConfig()}
            />
          </div>
            ):(
              <div className="flex mb-2">
              <span className="text-sm font-bold" style={{ width: 120, flexShrink: 0 }}>Role:</span>
              <span className="text-sm"  >{roleName || rowData.role}</span>
            </div>
            )
            }
          
          </div>
        </div>
      {showConfirm && (
        <Modal
          title="Confirm Impersonation"
          visible={showConfirm}
          onCancel={handleConfirmNo}
          centered
          footer={[
            <div key="confirm-footer" style={{ display: 'flex', justifyContent: 'center' }}>
              <Button className="cancel-btn" onClick={handleConfirmNo} style={{ marginRight: 8 }}>
                No
              </Button>
              <Button className="save-btn" onClick={handleConfirmYes} loading={loading}>
                Yes
              </Button>
            </div>
          ]}
        >
          <p>Are you sure you want to impersonate this User</p>
        </Modal>
      )}
    </Modal>
  );
};

export default ImpersonateUserModal;