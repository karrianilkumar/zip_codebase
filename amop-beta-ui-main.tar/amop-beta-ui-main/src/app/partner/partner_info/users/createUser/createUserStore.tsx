import create from 'zustand';

interface UserState {
    tenant: any[];
    role_name: any;
    sub_tenant: any[];
    user_name:any;
    emailsList:any[];
    user_role_data:any;
    mobileNumber:any;
    isUserInfoSubmitted:boolean;
    isUserRoleSubmitted:boolean;   
    setTenant: (tenant: any[]) => void;
    setRoleName: (role_name: any) => void;
    setSubTenant: (subPartners: any[]) => void;
    setUser_Name:(user_name: any) => void;
    setMobileNumber:(mobileNumber: any) => void;
    setEmailsList: (emailsList: any[]) => void;
    setUserRoleData:(emailsList: any) => void;
    setIsUserInfoSubmitted:(isUserInfoSubmitted:boolean) => void;
    setIsUserRoleSubmitted:(isUserRoleSubmitted:boolean) => void;

}

export const useUserStore = create<UserState>((set) => ({
    user_name:'',
    tenant: [],
    role_name: '',
    mobileNumber:'',
    sub_tenant: [],
    emailsList:[],
    user_role_data:{},
    isUserInfoSubmitted:false,
    isUserRoleSubmitted:false,
    setEmailsList: (emailsList) => set({ emailsList }),
    setTenant: (tenant) => set({ tenant }),
    setRoleName: (role_name) => set({ role_name }),
    setSubTenant: (sub_tenant) => set({ sub_tenant }),
    setUser_Name: (user_name) => set({ user_name }),
    setMobileNumber: (mobileNumber) => set({ mobileNumber }),
    setUserRoleData:(user_role_data) =>set({user_role_data}),
    setIsUserInfoSubmitted:(isUserInfoSubmitted) =>set({isUserInfoSubmitted}),
    setIsUserRoleSubmitted:(isUserRoleSubmitted) =>set({isUserRoleSubmitted}),
    
}));
