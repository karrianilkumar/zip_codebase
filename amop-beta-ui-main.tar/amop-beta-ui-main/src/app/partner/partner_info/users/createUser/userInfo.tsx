import React, { useState, useEffect } from 'react';
import { XMarkIcon, CheckIcon } from '@heroicons/react/24/outline';
import Select, { MultiValue, SingleValue } from 'react-select';
import { NonEditableDropdownStyles, DropdownStyles } from '@/app/components/css/dropdown';
import { useUserStore } from './createUserStore';
import { usePartnerStore } from '../../partnerStore';
import { getCurrentDateTime } from '@/app/components/header_constants';
import axios from 'axios';
import { useAuth } from '@/app/components/auth_context';
import { Checkbox, Modal, notification, Spin, Switch } from 'antd';
import Button, { isString } from 'antd/es/button';
import { ENV_ROUTES } from '@/app/components/routes/route_constants';
import moment from "moment-timezone";
import { generateRandomSecret } from '@/common/utils';
import { CopyOutlined, SyncOutlined } from '@ant-design/icons';
import VirtualizedSelect from '@/app/components/virtualized_dropdown';
import TenantRoleMappingTable from './tenantRoleMappingTable';
import { usePrivateNetworkStore } from '@/app/stores/privateNetworksStore';
import { useCustomerRatePlanStore } from '@/app/stores/customerRateplanStore';
import { fireSideCannons } from '@/app/components/confetti';

type OptionType = {
  value: string;
  label: string;
};
const { partnerData, setPartnerUsers } = usePartnerStore.getState();
const editableDrp = DropdownStyles;
const nonEditableDrp = NonEditableDropdownStyles;
const Notificationoptions = [
  { value: 'Yes', label: 'Yes' },
  { value: 'No', label: 'No' }
];

interface UserInfoProps {
  rowData?: any;
  isPopup?: any;
  editable?: boolean;
  setRowData: (row: any) => void;
}

const UserInfo: React.FC<UserInfoProps> = ({ rowData, isPopup, editable, setRowData }) => {
  const {
    username: user,
    tenantNames: tenants,
    role: userRole,
    partner: userPartner,
    settabledata,
    token,
    selectedDb,metaData, firstLastName, sessionId, } = useAuth();
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [username, setUsername] = useState('');
  const [emailId, setEmailId] = useState('');
  const [mobileNo, setMobileNo] = useState('');
  // const [password, setPassword] = useState('');
  const [phone, setPhone] = useState('');
  const [timeOutFrequency, setTimeOutFrequency] = useState<number>(15);
  const [businessName, setBusinessName] = useState('');
  const [locale, setLocale] = useState('');
  const [aptSuite, setAptSuite] = useState('');
  const [addressLine1, setAddressLine1] = useState('');
  const [addressLine2, setAddressLine2] = useState('');
  const [country, setCountry] = useState('');
  const [state, setState] = useState('');
  const [city, setCity] = useState('');
  const [timeZone, setTimeZone] = useState('');
  const [zip, setZip] = useState('');
  const [partner, setPartner] = useState<string[]>([]);
  const [changedTenant, setChangedTenant] = useState<string[]>([]);
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<SingleValue<OptionType>>(null);
  const [Notification, setNotification] = useState<SingleValue<OptionType>>(null);
  const [errorMessages, setErrorMessages] = useState<string[]>([]);
  const [selectedSubPartner, setSelectedSubPartner] = useState<string[]>([]);
  const [subPartners, setSubPartners] = useState<string[]>([]);
  const [Partneroptions, setPartneroptions] = useState<any[]>([]);
  const [Roleoptions, setRoleoptions] = useState<any[]>([]);
  const [generalFields, setGeneralFields] = useState<any[]>([]);
  const [subPartnersData, setsubPartnersData] = useState<any>({});
  const [rolePartnersData, setRolePartnersData] = useState<any>({});
  const [subPartnersoptions, setsubPartnersoptions] = useState<any[]>([]);
  const [formData, setFormData] = useState<any>(rowData || {});
  const [loading, setLoading] = useState(false);
  const [isSaveDisable, setIsSaveDisable] = useState(false);
  const [switchUser, setSwitchUser] = useState(false);


  //Service Account States
  const [isServiceAccount, setIsServiceAcount] = useState(false);
  const [clientId, setClientId] = useState<string>(() => {
    const id = rowData?.client_id || '';
    return id.endsWith('_api') ? id.slice(0, -4) : id;
  });

  const [clientIdAPI, setClientIdAPI] = useState<string>();
  const [userId, setUserId] = useState<string>('');
  const [clientSecret, setClientSecret] = useState<string>(rowData?.clientSecret || "");
  const [disabledClientSecret, setDisabledClientSecret] = useState<boolean>(!!rowData);
  const [serviceSubPartner, setServiceSubPartner] = useState<string | null>(null);
  const [serviceSubPartnerOptions, setServiceSubPartnerOptions] = useState<string[]>([]);
  const [servicePartner, setServicePartner] = useState<string | null>(null);
  const [SAerrorMessages, setSAErrorMessages] = useState<{ [key: string]: string }>({
    clientId: '',
    // clientSecret: '',
    email: '',
    phone: '',
  });
  const [taxProfile, setTaxProfile] = useState<SingleValue<OptionType>>(
    rowData?.tax_profile ? { value: rowData.tax_profile, label: rowData.tax_profile } : null
  );
  const [taxProfileOptions, setTaxProfileOptions] = useState<OptionType[]>([]);
  const [isSAFetched, setISSAFetched] = useState(false);
  
  //Show Modal
  const [showModal, setShowModal] = useState(false);
  // console.log("row", rowData)
  const {
    tenant,
    role_name,
    sub_tenant,
    setTenant,
    setRoleName,
    setSubTenant,
    setUser_Name,
    setMobileNumber,
    setUserRoleData,
    setIsUserInfoSubmitted,
    setEmailsList,
    isUserInfoSubmitted
  } = useUserStore();


  const { editedTableData } = usePrivateNetworkStore();
  const {  partnerUsersShowActive } = useCustomerRatePlanStore();
  console.log("rowData",rowData)
  const isSuperAdmin = userRole?.toLocaleLowerCase() === "super admin"
  const timezoneOptions = moment.tz.names().map((timezone) => {
    const abbreviation = moment().tz(timezone).format('zz');
    const currentTime = moment().tz(timezone).format('HH:mm:ss');
    const [countryName, cityName] = timezone.split('/');
    const formattedCountryName = cityName ? `${countryName} / ${cityName}` : countryName;
    return {
      value: `(${abbreviation} +${currentTime}) ${formattedCountryName}`,
      label: `(${abbreviation} +${currentTime}) ${formattedCountryName}`,
    };
  });

  const subPartnersnoOptions = [{ value: '', label: 'No sub-partners available' }];
  const usersData = partnerData["Partner users"]?.data?.["Partner users"] || {};
  const usersFeaures = partnerData["Partner users"]?.headers_map?.["Partner users"]?.module_features || [];

  const getFieldValue = (label: any) => {
    if (rowData) {
      const general_fields = partnerData["Partner users"]?.headers_map?.["Partner users"]?.general_fields || {}
      const field = general_fields ? general_fields.find((f: any) => f.display_name === label) : null;
      return field ? formData[field.db_column_name] || '' : '';
    }
    else {
      return ""
    }
  };

  // useEffect(() => {
  //   if (rowData) {
  //     fetchData();
  //   }
  // }, [rowData]);
  const fetchData = async () => {

    setLoading(true);
    // Set loading to true before the request
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        path: "/user_data",
        user_name: rowData?.username || "",
        Partner: userPartner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
          ...metaData,
        sessionID: sessionId,
        role_name: rowData?.role || ""
      };
      console.log(getCurrentDateTime(), "Show the log time request sent from ui to lambda");

      const response = await axios.post(url, { data: data });
      const parsedData = JSON.parse(response.data.body);
      console.log(getCurrentDateTime(), "Show the log time response sent from lambda to ui");
      if (response.data.statusCode === 200 && parsedData.flag === true) {
        // setUserRoleData(parsedData)
        setLoading(false)
      }
      else {
        setLoading(false)
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      }



    } catch (err) {
      console.error("Error fetching data:", err);
      Modal.error({
        title: 'Data Fetch Error',
        content: err instanceof Error ? err.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };



  useEffect(() => {
    const initializeData = () => {
      const general_fields = partnerData["Partner users"]?.headers_map?.["Partner users"]?.general_fields || {}
      const partner_options: any[] = usersData?.tenant ? Object.keys(usersData.tenant) : []
      const subPartners_Data = usersData?.tenant || {}
      // if (!isSuperAdmin) {
      //   setTenant([userPartner])
      //   // setPartner([userPartner]);
      // }
      const tenant_ =  tenant && tenant.length > 0
          ? tenant 
          : [userPartner]
      const sub_partners = tenant_.flatMap((partner: any) => subPartners_Data[partner] || []);
      // const role_options: any[] = usersData?.role_name || []
      const subPartners_options = sub_partners.map((subPartner: any) => ({ value: subPartner, label: subPartner }));
      setsubPartnersData(subPartners_Data)
      setSubPartners(sub_partners);
      setsubPartnersoptions(subPartners_options)

      //tenant based roles
      const roles_Data = usersData?.role_name || {}
      setRolePartnersData(roles_Data)
      const role_partners = tenant_.flatMap((partner: any) => roles_Data[partner] || []);

      // const role_options: any[] = usersData?.role_name || []
      const role_options = role_partners.map((role: any) => ({ value: role, label: role }));
      const roleHierarchy = [
        "Super Admin",
        "Partner Admin",
        "Agent Partner Admin",
        "Agent",
        "User",
        "Qualification Only User",
        "Notification Only User"
      ];

      // Get the index of the current user's role in the hierarchy
      const currentRoleIndex = roleHierarchy.findIndex(
        role_name => role_name.toLowerCase() === (userRole || "").toLowerCase()
      );

      // Only allow roles **below or equal to** the current role in the hierarchy
      const allowedRoles = roleHierarchy.slice(currentRoleIndex);

      // Map to options (based on the roles actually available in the PartnerModuleData)
      const Roleoptions = role_partners
        ?.filter((role: string) =>
          allowedRoles.includes(role)
        )
        .map((role: string) => ({
          value: role,
          label: role,
        }));
      setRoleoptions(Roleoptions)
      const partner_options_ = partner_options.map((Partner: any) => ({ value: Partner, label: Partner }))
      setPartneroptions(partner_options_)
      setGeneralFields(general_fields)

    };

    initializeData();
  }, [usersData]);

  useEffect(() => {
    if (rowData) {
      setFormData(rowData)
    }
  }, [rowData]);

  // useEffect(() => {
  //   setSubTenant(selectedSubPartner)
  // }, [selectedSubPartner]);

  useEffect(() => {
    if (userRole && userRole.toLowerCase() === "super admin" ){
      const isRolePresent = Roleoptions.some(
        (role) => role.value.toLowerCase() === userRole.toLowerCase()
      );

      if (!isRolePresent && tenant.length < 2 && sub_tenant.length=== 0) {
        const role_options = [...Roleoptions, { label: userRole, value: userRole }];
        const uniqueRoleOptions = Array.from(
        new Set(role_options.map(role => role.value))
      ).map(value => ({
        value,
        label: value
      }));

      setRoleoptions(uniqueRoleOptions);
      }
    }

    if(!isUserInfoSubmitted){
    const subPartners_Data = usersData?.tenant || {}
    const sub_partners = tenant.flatMap((partner: any) => subPartners_Data[partner] || []);
    // const role_options: any[] = usersData?.role_name || []
    const subPartners_options = sub_partners.map((subPartner: any) => ({ value: subPartner, label: subPartner }));
    setsubPartnersoptions(subPartners_options)
    const filtered_sub_tenants = sub_tenant.filter((tenant:any)=>(sub_partners.includes(tenant)))
    setSubTenant(filtered_sub_tenants || [])
    setSelectedSubPartner(filtered_sub_tenants || [])

    if(tenant.length > 1 || sub_tenant.length > 0){
      setRoleName("")
    }
    }
    
  }, [tenant]);

  useEffect(() => {
    if (sub_tenant && sub_tenant.length!==0) {
      setSelectedSubPartner([... sub_tenant])
    }
  }, [sub_tenant]);


  useEffect(() => {
    if (clientId) {
      const client_id_with_api = `${clientId}_api`
      setClientIdAPI(client_id_with_api)
    }
  }, [clientId]);

  useEffect(() => {
    const initializeData = () => {
      if (rowData) {
        const initial_switch_user_flag = rowData?.switch_user_2_0
        if (!initial_switch_user_flag || initial_switch_user_flag === "False" || initial_switch_user_flag === "None") {
          setSwitchUser(false)
        }
        else {
          setSwitchUser(true)
        }
        const initial_timeout_frequency = rowData?.ui_timeout
        console.log("initial_timeout_frequency", initial_timeout_frequency)
        setTimeOutFrequency(
          initial_timeout_frequency && initial_timeout_frequency !== "None"
            ? Number(initial_timeout_frequency)
            : 15
        );
        setFormData(rowData)
        const tenant_name = tenant && tenant.length !== 0 ? tenant : getFieldValue('Partner');
        let parsedPartners: string[] = [];
        const rawData = rowData && rowData?.tenant_role_mapping && rowData?.tenant_role_mapping !== "None" ? rowData?.tenant_role_mapping : "[]";
        const safeJSON = rawData.replace(/'/g, '"');

      let parsedData = [];
        try {
          parsedPartners = Array.isArray(tenant_name) ? tenant_name : JSON.parse(tenant_name);
          parsedData = JSON.parse(safeJSON);

          // Create a Set for fast lookup
          const partnerSet = new Set(parsedPartners);

          // Loop through parsedData & add missing tenants
          parsedData.forEach((row: any) => {
            const t = row?.tenant;
            if (t && !partnerSet.has(t)) {
              partnerSet.add(t);
              parsedPartners.push(t);
            }
          });


        } catch (error) {
          console.log("parse error",error)
          if (tenant_name && tenant_name !== 'None') {
            parsedPartners = [tenant_name];
          }
        }
        const partner_options: any[] = usersData?.tenant ? Object.keys(usersData.tenant) : []
        const validPartners = parsedPartners.filter((partner) =>
          partner_options.some((option: any) => option === partner )
        );

        setPartner(validPartners);
        setChangedTenant(validPartners);
        setTenant(validPartners)
        const role_name = getFieldValue('Role') || ""
        setRole(role_name)
        setRoleName(role_name)
        const subPartnerFieldValue = getFieldValue('Sub Partner');
        const subPartners_Data = usersData?.tenant || {}
        let parsedSubPartners: string[] = [];

        try {
          parsedSubPartners = JSON.parse(subPartnerFieldValue);
        } catch (error) {
          if (subPartnerFieldValue && subPartnerFieldValue !== 'None') {
            parsedSubPartners = [subPartnerFieldValue];
          }
        }
        const allSubPartners = parsedPartners.flatMap((partner: any) => subPartners_Data[partner || ""] || []);

      // Map to { value, label } for dropdown
      const subPartnersOptions = allSubPartners.map((subPartner: any) => ({
        value: subPartner,
        label: subPartner,
      }));
      console.log("subPartners_Data",subPartners_Data)

      console.log("allSubPartners",allSubPartners)
      console.log("subPartnersOptions",subPartnersOptions)
      console.log("parsedPartners",parsedPartners)
        // const sub_partners = subPartners_Data[tenant_name] || []
        // const subpartner_options = sub_partners.map((subPartner: any) => ({ value: subPartner, label: subPartner }))
        setSelectedSubPartner(parsedSubPartners)
        setSubTenant(parsedSubPartners)
        setSubPartners(allSubPartners)
        setsubPartnersoptions(subPartnersOptions)
        setPartner(getFieldValue('Sub Partner'));

        //tenant based roles
        const roles_Data = usersData?.role_name || {}
        setRolePartnersData(roles_Data)
        const role_partners = parsedPartners.flatMap((partner: any) => roles_Data[partner || ""] || []);
        // const role_options: any[] = usersData?.role_name || []
        const unique_role_partners = Array.from(
          new Set(role_partners.map(role => role))
        ).map(value => (
          value));
        const role_options = role_partners.map((role: any) => ({ value: role, label: role }));
        const roleHierarchy = [
          "Super Admin",
          "Partner Admin",
          "Agent Partner Admin",
          "Agent",
          "User",
          "Qualification Only User",
          "Notification Only User"
        ];

        // Get the index of the current user's role in the hierarchy
        const currentRoleIndex = roleHierarchy.findIndex(
          role_name => role_name.toLowerCase() === (userRole || "").toLowerCase()
        );

        // Only allow roles **below or equal to** the current role in the hierarchy
        const allowedRoles = roleHierarchy.slice(currentRoleIndex);

        // Map to options (based on the roles actually available in the PartnerModuleData)
        const Roleoptions = unique_role_partners
          ?.filter((role: string) =>
            allowedRoles.includes(role)
          )
          .map((role: string) => ({
            value: role,
            label: role,
          }));
        setRoleoptions(Roleoptions)
        const notication_value = getFieldValue("Notification Enable") === "True" ? "Yes" : "No"
        setNotification({ value: notication_value, label: notication_value })
        const fields = [
          { stateSetter: setFirstName, fieldName: 'First Name' },
          { stateSetter: setLastName, fieldName: 'Last Name' },
          { stateSetter: setUsername, fieldName: 'Username' },
          { stateSetter: setUser_Name, fieldName: 'Username' },
          { stateSetter: setEmailId, fieldName: 'Email ID' },
          { stateSetter: setMobileNo, fieldName: 'Mobile No' },
          // { stateSetter: setPassword, fieldName: 'Password' },
          { stateSetter: setPhone, fieldName: 'Phone' },
          { stateSetter: setBusinessName, fieldName: 'Business Name' },
          { stateSetter: setLocale, fieldName: 'Locale' },
          { stateSetter: setAptSuite, fieldName: 'Apt/Suite' },
          { stateSetter: setAddressLine1, fieldName: 'Address Line-1' },
          { stateSetter: setAddressLine2, fieldName: 'Address Line-2' },
          // { stateSetter: setNotification, fieldName: 'Notification enable' },
          { stateSetter: setCountry, fieldName: 'Country' },
          { stateSetter: setState, fieldName: 'State' },
          { stateSetter: setCity, fieldName: 'City' },
          { stateSetter: setTimeZone, fieldName: 'Time Zone' },
          { stateSetter: setZip, fieldName: 'Zip' },
        ];

        // Iterate over the fields array to set each state
        fields.forEach(({ stateSetter, fieldName }) => {
          stateSetter(getFieldValue(fieldName));
        });
      }
    };

    initializeData();
  }, [rowData]);

  let sub_partners;
  const handlePartnerChange = (selectedOptions: MultiValue<OptionType>) => {
    console.log("partner data", partnerData)
    const selectedPartners = selectedOptions.map(option => option.value);
    setPartner(selectedPartners);
    setTenant(selectedPartners)
    if (rowData) {
      setFormData((prevState: any) => ({ ...prevState, [getFieldKey('Partner')]: selectedPartners }));
    }
    if (selectedOptions && selectedOptions.length > 0) {
      // Flatten all sub-partners for the selected partners
      
      const allSubPartners = selectedOptions.flatMap((partner: any) => subPartnersData[partner?.value || ""] || []);

      // Map to { value, label } for dropdown
      const subPartnersOptions = allSubPartners.map((subPartner: any) => ({
        value: subPartner,
        label: subPartner,
      }));
      setSubPartners(allSubPartners);
      setsubPartnersoptions(subPartnersOptions);
      // setSelectedSubPartner([]);
      // setSubTenant([]);

      //set tenant based role
      const role_partners = selectedOptions.flatMap((partner: any) => rolePartnersData[partner?.value || ""] || []);

      const role_options = role_partners.map((role: any) => ({ value: role, label: role }));
      const roleHierarchy = [
      "Super Admin",
      "Partner Admin",
      "Agent Partner Admin",
      "Agent",
      "User",
      "Qualification Only User",
      "Notification Only User"
    ];

    // Get index of current user's role
    const currentRoleIndex = roleHierarchy.findIndex(
      role => role.toLowerCase() === (userRole || "").toLowerCase()
    );

    // Roles equal or below current role
    const allowedRoles = roleHierarchy.slice(currentRoleIndex);

    let filteredRoles = role_partners?.filter((role: string) => {
      // Must be in allowedRoles
      if (!allowedRoles.includes(role)) return false;

      // ❌ If multiple partners selected, remove Super Admin
      if (selectedOptions.length > 1 && role === "Super Admin") return false;

      return true;
    }) || [];

    // 🔹 Deduplicate
    const uniqueRoles = [...new Set(filteredRoles)];

    // 🔹 Map to options
    const Roleoptions = uniqueRoles.map(role => ({
      value: role,
      label: role,
    }));

    setRoleoptions(Roleoptions);

      // setRoleName(null)
      // setRole(null);
      if (rowData) {
        // rowData[getFieldKey('Partner')]=partner || ""
        setFormData((prevState: any) => ({ ...prevState, [getFieldKey('Partner')]: partner }));

      }
      setErrorMessages(prevErrors => prevErrors.filter(error => error !== 'Partner is Required.'));
    } else {
      setTenant([]);
      setSubPartners([]);
      setSelectedSubPartner([]);
      setsubPartnersoptions([])
    }
  };

  const handleSetSubPartner = (selectedOptions: MultiValue<OptionType>) => {
    const selectedSubPartners = selectedOptions.map(option => option.value);
    setSelectedSubPartner(selectedSubPartners);
    setSubTenant(selectedSubPartners)
    if (rowData) {
      setFormData((prevState: any) => ({ ...prevState, [getFieldKey('Sub Partner')]: selectedSubPartners }));
      // rowData[getFieldKey('Sub Partner')]=selectedSubPartners || []
    }
  };
  const handlesetRole = (selectedOption: SingleValue<OptionType>) => {
    if (selectedOption) {
      const role = selectedOption.value
      setRole(selectedOption);
      setRoleName(role)
      if (rowData) {
        // formData[getFieldKey('Partner')]=partner
        setFormData((prevState: any) => ({ ...prevState, [getFieldKey('Role')]: role }));
      }
      if (role) {
        setErrorMessages(prevErrors => prevErrors.filter(error => error !== 'Role is Required.'));
      }
    }
  };
  const handleNotification = (selectedOption: SingleValue<OptionType>) => {
    setNotification(selectedOption);
    // if (rowData) {
    //   setFormData((prevState: any) => ({ ...prevState, [getFieldKey('Notification enable')]: selectedOption?.value }));
    // }
    if (selectedOption) {
      setErrorMessages(prevErrors => prevErrors.filter(error => error !== 'Notification is Required.'));
    }
  };
  const messageStyle = {
    fontSize: '14px',  // Adjust font size
    fontWeight: 'bold', // Make the text bold
    padding: '16px',
    // Add padding
  };

  //Clearing fields after the form submission
  const handleClearFields = () => {
    setFirstName('');
    setLastName('');
    setUsername('');
    setEmailId('');
    setMobileNo('');
    // setPassword('');
    setPhone('');
    setBusinessName('');
    setLocale('');
    setAptSuite('');
    setAddressLine1('');
    setAddressLine2('');
    setCountry('');
    setState('');
    setCity('');
    setTimeZone('');
    setZip('');
    setPartner([]);
    setRole(null);
    setNotification(null);
    setSelectedSubPartner([]);
    setSubPartners([]);
    setFormData({});
    setTenant([])
    setRoleName('')
    setSubTenant([])
    setIsSaveDisable(false)
  };

  const callRunDBScript = async (formData: any) => {
    const url = ENV_ROUTES.SIM_MANAGEMENT;
    const data = {
      tenant_name: userPartner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/run_db_script",
      role_name: userRole,
      module_name: "Partner Users",
      access_token: token,
      db_name: selectedDb,
          ...metaData,
      sessionID: sessionId,
      update_flag: isPopup ? true : false,
      delete_flag: false,
      transfer_name: "users_sync_beta",
      request_received_at: getCurrentDateTime(),
      Partner: userPartner || "default_value",
      data: {
        users: [{
          ...formData,
          salt: "",
          tenant_id: 1,
          ...(isPopup && { id: rowData.id }),
        }]
      },
    };

    try {
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
    } catch (error) {
    }

  }

  const generatePassword = () => {
    const getRandom = (chars: string) => chars[Math.floor(Math.random() * chars.length)];

    const lowercase = 'abcdefghijklmnopqrstuvwxyz';
    const uppercase = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const digits = '0123456789';

    const passwordParts = [
      getRandom(lowercase),
      getRandom(lowercase),
      getRandom(uppercase),
      getRandom(uppercase),
      getRandom(digits),
      getRandom(digits),
    ];

    // Shuffle the array to mix character positions
    const shuffled = passwordParts.sort(() => Math.random() - 0.5);

    return shuffled.join('');
  };


  const handleSave = async () => {
    setShowModal(false);
    setIsSaveDisable(true)
    setUser_Name(username)
    setMobileNumber(mobileNo)
    setEmailsList([emailId])
    try {
      setLoading(true)
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      let changedData: any = {};
      const temp_pswd = generatePassword()
      const tenant_name = selectedSubPartner ? selectedSubPartner : partner || []
      const editedTableDataCopy = [... editedTableData]
      const tenantsWithRole = editedTableDataCopy
        .filter((row: any) => row.role && row.role.trim() !== "" && row.role.trim() !== "none" && tenant.includes(row.tenant))
        .map((row: any) => row.tenant);
      const subTenantsWithRole = editedTableDataCopy
        .filter((row: any) => row.role && row.role.trim() !== "" && sub_tenant.includes(row.tenant))
        .map((row: any) => row.tenant);

      const allTenants = [...(tenant || []), ...(sub_tenant || [])];   // combine both
        const existingTenants = editedTableData.map((row: any) => row?.tenant);

        const rowsToAdd = allTenants
          .filter((t) => t && !existingTenants.includes(t))
          .map((t) => ({ tenant: t, role: "none" }));

        const updatedRows = editedTableData.filter((row: any) =>
          allTenants.includes(row?.tenant)
        );
      const mainTenatRolesList = tenant && (tenant.length > 1 || sub_tenant.length > 0)
          ? editedTableData
            .filter(row =>
              Partneroptions.some(opt => opt.value === row?.tenant)
            )
            .map(row => row?.role || "")
            .filter(role => role && role.toLowerCase() !== "none") : []

      const subTenatRolesList = tenant && (tenant.length > 1 || sub_tenant.length > 0)
          ? editedTableData
            .filter(row =>
              subPartnersoptions.some(opt => opt.value === row?.tenant)
            )
            .map(row => row?.role || "")
            .filter(role => role && role.toLowerCase() !== "none") : []
      changedData[getFieldKey('Partner')] = (tenant.length>1 || sub_tenant.length!==0 ) ?tenantsWithRole : tenant;
      changedData[getFieldKey('Sub Partner')] = subTenantsWithRole || sub_tenant;
      changedData[getFieldKey('First Name')] = firstName;
      changedData[getFieldKey('Last Name')] = lastName;
      changedData[getFieldKey('Username')] = username;
      changedData[getFieldKey('Email ID')] = emailId;
      changedData[getFieldKey('Mobile No')] = mobileNo;
      console.log("mainTenatRolesList",mainTenatRolesList)
      console.log("subTenatRolesList",subTenatRolesList)

      changedData[getFieldKey("Role")] =
        tenant && (tenant.length > 1 || sub_tenant.length > 0)
          ?mainTenatRolesList[0] || subTenatRolesList[0] || ""
          : (role?.value?.toLowerCase() === "none" ? "" : role?.value || role || role_name || "");

      changedData[getFieldKey('Password')] = temp_pswd;
      changedData[getFieldKey('Phone')] = phone;
      changedData[getFieldKey('Business Name')] = businessName;
      changedData[getFieldKey('Locale')] = locale;
      changedData[getFieldKey('Apt/Suite')] = aptSuite;
      changedData[getFieldKey('Address Line-1')] = addressLine1;
      changedData[getFieldKey('Address Line-2')] = addressLine2;
      changedData[getFieldKey('Notification Enable')] = Notification?.value === "Yes" ? true : false;
      changedData[getFieldKey('Country')] = country;
      changedData[getFieldKey('State')] = state;
      changedData[getFieldKey('City')] = city;
      changedData[getFieldKey('Time Zone')] = timeZone;
      changedData[getFieldKey('Zip')] = zip;
      changedData['switch_user_2_0'] = switchUser;
      changedData['tenant_role_mapping'] = tenant.length>1 || sub_tenant.length!==0 ? [...updatedRows, ...rowsToAdd] : [];
      changedData['ui_timeout'] = timeOutFrequency || 15;
      changedData["is_active"] = true;
      changedData["is_deleted"] = false;
      if(!rowData){
        changedData["created_by"] = user;
      }
      // changedData["modified_date"] = getCurrentDateTime();
      delete changedData["modified_date"]
      changedData["modified_by"] = user;


      const data = {
        tenant_name: userPartner || "default_value",
        username: user,
        path: "/update_partner_info",
        role_name: userRole,
        template_name: "create_user",
        module_name: "Partner users",
        action: rowData ? "update" : "create",
        request_received_at: getCurrentDateTime(),
        "sub_partner_names": sub_tenant || [],
        changed_data: {
          "user_info": changedData,
        },
        "changed_tenant": changedTenant,
        template: `<html>
<body>
<p>Dear User,</p><p>Your account has been successfully created.</p><p><b>Username:</b>{"users":"username"}</p><p><b>Default Password:</b>${temp_pswd}</p><p>Please log in using the link below:</p><p><a href="https://beta.amop.services/" style="color: #0066cc; font-weight: bold;">https://beta.amop.services/</a></p><p>Please make sure to change your password after your first login for security purposes.</p>
</body>
</html>`,
        Partner: userPartner,
        access_token: token,
        db_name: selectedDb,
          ...metaData,
        sessionID: sessionId,
        ...(rowData ? { list_view_id: formData?.id || "" } : {}),
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (response && response.data.statusCode === 200) {
        if (isServiceAccount) {
          handleSeviceAccountSave()
        }

        callRunDBScript(changedData)

        try {
          const url = ENV_ROUTES.MODULE_MANAGEMENT;
          const data = {
            tenant_name: userPartner || "default_value",
            username: user,
            path: "/get_partner_info",
            role_name: userRole,
            parent_module: "Partner",
            modules_list: ["Partner users"],
            feature_module_name: "Partner Info",
            pages: {
              "Customer groups": { start: 0, end: 100 },
              "Partner users": { start: 0, end: 100 }
            },
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
          ...metaData,
            sessionID: sessionId,
            active_toggle:partnerUsersShowActive ?? false
          };
          const response = await axios.post(url, { data });
          const parsedData = JSON.parse(response.data.body);
          if (parsedData.flag === false) {
            console.log("parsedData.error_type", parsedData.error_type)
            Modal.error({
              title: 'Submit Error',
              content: parsedData.message || 'An error occurred while submitting data. Please try again.',
              centered: true,
            });
            // setLoading(false)

          } else {
            if (!rowData) {
              setIsUserInfoSubmitted(true)
            }
            setPartnerUsers(parsedData)
            const tableData = parsedData?.data?.["Partner users"]?.users || [];
            if (rowData) {
              const foundRow = tableData.find((user: any) => user.id === rowData.id);
              // Step 4: Set the found row to form data
              if (foundRow) {
                setFormData(foundRow);
                setRowData(foundRow)
              }
            }

            settabledata(tableData);
            notification.success({
              message: 'Success',
              description: `Successfully ${isPopup ? 'edited' : 'created'} the User`,
              style: messageStyle,
              placement: 'top', // Apply custom styles here
            });
            fireSideCannons()
            // setLoading(false)

          }
        }
        catch (error) {
          Modal.error({
            title: 'Submit Error',
            content: parsedData.message || 'An error occurred while submitting the form. Please try again.',
            centered: true,
          });
        }
        finally {
          // setLoading(false)
          // handleClearFields();
        }
      }
      else {
        if (parsedData.error_type && parsedData.error_type == "Warning") {
          console.log("parsedData.error_type", parsedData.error_type)
          Modal.warning({
            title: 'Validation Warning',
            content: parsedData.message || 'An error occurred while submitting data. Please try again.',
            centered: true,
          });
        }
        else {
          Modal.error({
            title: 'Submit Error',
            content: parsedData.message || 'An error occurred while submitting the form. Please try again.',
            centered: true,
          });
        }

      }
    }
    catch (error) {
      console.log(
        error
      )
    }
    finally {
      setLoading(false)
      // handleClearFields();
    }




  };

  //Handling Service Account Save
  const handleSeviceAccountSave = async (client_secret?: any) => {
    setShowModal(false);
    setLoading(true);
    let selected_role = role_name
        if (tenant && (tenant.length > 1 || sub_tenant.length > 0)) {
          const selected_tenant = serviceSubPartner ? serviceSubPartner : servicePartner || tenant || [userPartner] || ""
          console.log("selected_tenant", selected_tenant)
          const selected_object = editedTableData.find((obj: any) => obj.tenant === selected_tenant)
          console.log("selected_object", selected_object)
          if (selected_object) {
            selected_role = selected_object.role || ""
          }
        }
    try {
      const url = ENV_ROUTES.USER_AUTHENTICATION;
      const url2 = ENV_ROUTES.MODULE_MANAGEMENT;
      let response;
      let parsedData;

      if (rowData && isSAFetched) {
        // Update existing service account
        const payload = {
          path: "/process_service_account",
          username: username,
          firstLastName: firstLastName,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          request_received_at: getCurrentDateTime(),
          access_token: token,
          "1.0": true,
          client_id: clientIdAPI,
          client_secret: client_secret || clientSecret,
          tenant_name: userPartner || "default_tenant",
          tenant: serviceSubPartner ? serviceSubPartner : servicePartner || tenant || [userPartner],
          role: selected_role,
          email: emailId || null,
          phone: phone || null,
          tax_profile: taxProfile?.value || null,
          flag: "update"
        };

        response = await axios.post(url, { data: payload });
        parsedData = JSON.parse(response.data.body);

        // Additional API call for update_service_account_info_tenant_based
        const updatePayload = {
          path: "/update_service_account_info_tenant_based",

          firstLastName: firstLastName,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          request_received_at: getCurrentDateTime(),
          access_token: token,
          partner_name: tenant,
          tenant_name: userPartner || "default_tenant",
          changed_data: {
            service_account_info: {
              client_id: clientIdAPI,
              client_secret: clientSecret,
              tax_profile: taxProfile?.value || null,
              username: username,
              // email: selectedEmail?.value || null,
              // phone: phone || null,
              // sub_partner: selectedSubPartner?.value || null,
            },
          },
        };

        const updateResponse = await axios.post(url2, { data: updatePayload });
        const updateParsedData = JSON.parse(updateResponse.data.body);

        if (!(updateResponse.data.statusCode === 200 && updateParsedData.flag === true)) {
          throw new Error(updateParsedData.message || 'Failed to update service account info');
        }
      } else {
        let client_secret_ = ""
        let user_id_ = ""
        try {
          const url = ENV_ROUTES.USER_AUTHENTICATION;
          const data = {
            tenant_name: userPartner || "default_value",
            username: user,
            path: "/create_machine_user",
            role_name: userRole,
            parent_module: "Partner",
            modules_list: ["Partner users"],
            feature_module_name: "Partner Info",
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
          ...metaData,
            sessionID: sessionId,
            client_id: clientIdAPI || null,
            
          };

          const response = await axios.post(url, { data });
          const parsedData = JSON.parse(response?.data?.body);

          if (response.data.statusCode === 200 && parsedData.flag === true) {
            client_secret_ = parsedData?.data?.clientSecret || ""
            setClientSecret(client_secret_);

            user_id_ = parsedData?.data?.userId || ""
            setUserId(user_id_);
            console.log("Success while fetching client secret")
          } else {
            console.log("Error while fetching client secret")
          }
        } catch (err) {
          console.error("Error fetching client secret", err);
        }
        finally {
          setLoading(false);
        }

        
        // Create new service account
        const payload = {
          path: "/create_service_account",
          username: username,
          firstLastName: firstLastName,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          request_received_at: getCurrentDateTime(),
          access_token: token,
          "1.0": true,
          client_id: clientIdAPI,
          client_secret: client_secret_ || clientSecret || "",
          user_id: user_id_ || "",
          tenant_name: userPartner || "default_tenant",
          tenant: serviceSubPartner ? serviceSubPartner : servicePartner || tenant || [userPartner],
          role: selected_role,
          email: emailId || null,
          phone: phone || null,
          tax_profile: taxProfile?.value || null,
        };

        response = await axios.post(url, { data: payload });
        parsedData = JSON.parse(response.data.body);

        // Additional API call for update_service_account_info_tenant_based after creation
        const updatePayload = {
          path: "/update_service_account_info_tenant_based",
          username: username,
          firstLastName: firstLastName,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          request_received_at: getCurrentDateTime(),
          access_token: token,
          tenant_name: userPartner || "default_tenant",
          partner_name: tenant,
          changed_data: {
            service_account_info: {
              client_id: clientIdAPI,
              client_secret: client_secret_ || clientSecret || "",
              tax_profile: taxProfile?.value || null,
              username: username,
              // email: selectedEmail?.value || null,
              // phone: phone || null,
              // sub_partner: selectedSubPartner?.value || null,
            },
          },
        };

        const updateResponse = await axios.post(url2, { data: updatePayload });
        const updateParsedData = JSON.parse(updateResponse.data.body);

        if (!(updateResponse.data.statusCode === 200 && updateParsedData.flag === true)) {
          throw new Error(updateParsedData.message || 'Failed to update service account info after creation');
        }
      }

      if (response.data.statusCode === 200 && parsedData.flag === true) {
        // Fetch updated service accounts list
        const fetchPayload = {
          username: username,
          firstLastName: firstLastName,
          role_name: selected_role,
          tenant_name: userPartner || "default_value",
          path: "/get_service_account",
          request_received_at: getCurrentDateTime(),
          access_token: token,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          offset: 0,
        };

        const fetchResponse = await axios.post(url, { data: fetchPayload });
        const fetchParsedData = JSON.parse(fetchResponse.data.body);

        if (fetchResponse.data.statusCode === 200 && fetchParsedData.flag === true) {
          const tableData = fetchParsedData.results || [];
          if (rowData) {
            const foundRow = tableData.find((item: any) => item.id === rowData.id);
            if (foundRow) {
              setRowData(foundRow);
            }
          }
          if (client_secret) {
            notification.success({
              message: 'Success',
              description: 'Client Secret updated successfully',
              style: messageStyle,
              placement: 'top',
            });
            fireSideCannons()
          }
          // else{
          //   notification.success({
          //   message: 'Success',
          //   description: `Service Account ${rowData ? 'updated' : 'created'} successfully`,
          //   style: messageStyle,
          //   placement: 'top',
          // });
          // }

        } else {
          Modal.error({
            title: 'Data Fetch Error',
            content: fetchParsedData.message || 'An error occurred while fetching updated data.',
            centered: true,
          });
        }
      } else {
        Modal.error({
          title: 'Submit Error',
          content: parsedData.message || 'An error occurred while submitting the form.',
          centered: true,
        });
      }
    } catch (error) {
      console.error('Error saving service account:', error);
      Modal.error({
        title: 'Submit Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred.',
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
  //Handling modal save
  const handleConfirmSave = () => {
    const hasIncompleteRow = editedTableData.some((row: any) =>
      Object.keys(row).some((key) => {
        const value = row[key];
        return value === "" || value === null || value === undefined;
      })
    );

    if (hasIncompleteRow && editedTableData.length > 1 && (tenant.length>1 || sub_tenant.length>0)) {
      Modal.info({
        title: "Incomplete",
        content: "Please fill all the fields in User Role Access rows before creating.",
        centered: true,
      });
      return; //
    }
    const errors: string[] = [];
    if (!tenant || tenant.length===0) errors.push('Partner is Required.');
    if (!firstName) errors.push('First Name is Required.');
    if (!lastName) errors.push('Last Name is Required.');
    if (!username) errors.push('Username is Required.');
    if (!emailId) errors.push('Email ID is Required.');
    if (!role_name && tenant.length <2 && sub_tenant.length=== 0 ) errors.push('Role is Required.');
    // if (!password) errors.push('Password is required.');
    if (!Notification) errors.push('Notification is Required.')
    if (zip && zip !== "" && zip !== "None") {
      const regex = /^\d{5}$/; // Only 5 numerical values
      if (!regex.test(zip)) {
        errors.push('Zip Code must be Exactly 5 Digits.')
      }
    }
    if (emailId) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+(\.[^\s@]+)*$/;
      if (!emailRegex.test(emailId)) {
        errors.push('Please Enter a valid Email ID.')
      }
    }
    // if (!phone) errors.push('Please Enter a valid phone Number.');
    if (phone && phone !== "" && phone !== "None") {
      const phoneRegex = /^[\d\s\-+()]+$/;
      if (!phoneRegex.test(phone)) {
        errors.push('Please Enter a valid phone Number.')
      }
    }
    // if (!mobileNo) errors.push('Please Enter a valid Mobile Number.');
    if (mobileNo && mobileNo !== "" && mobileNo !== "None") {
      const phoneRegex = /^[\d\s\-+()]+$/;
      if (!phoneRegex.test(mobileNo)) {
        errors.push('Please Enter a valid Mobile Number.')
      }
    }
    const SAerrors: { [key: string]: string } = {};
    if (isServiceAccount) {
      if (!clientId) SAerrors.clientId = 'Client ID is required.';
      // if (!clientSecret && rowData && !isSAFetched) SAerrors.clientSecret = 'Client Secret is required.';
      // if (selectedSubPartner.length > 0 && !serviceSubPartner) SAerrors.subPartner = 'Sub Partner is required.';
      if (tenant.length > 0 && !servicePartner) SAerrors.partner = 'Partner is required.';

    }
    console.log("errors", errors)
    console.log("SAerrors", SAerrors)

    setErrorMessages(errors);
    setSAErrorMessages(SAerrors);

    if (errors.length === 0 && Object.keys(SAerrors).length === 0) {
      setShowModal(true);
    }
    else {
      scrollToTop()
    }

  };
  //Handling modal cancel
  const handleCancelSave = () => {
    setShowModal(false);
  };


  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'auto'  // Optional: Smooth scroll animation
    });
  };
  const getFieldKey = (label: any) => {
    if (formData) {
      const field = generalFields ? generalFields.find((f: any) => f.display_name === label) : null;
      return field ? field.db_column_name : ''
    }
    else {
      return ""
    }
  };

  const handleTimezoneChange = (selectedOption: SingleValue<{ label: string, value: string }>) => {
    setTimeZone(selectedOption?.value ?? '');
  };
  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  //Service Account functions

  const handleCopy = () => {
    navigator.clipboard.writeText(clientSecret).then(() => {
      notification.success({
        message: 'Success',
        description: 'Client Secret copied to clipboard',
        style: messageStyle,
        placement: 'top',
      });
      fireSideCannons()
    });
  };
  const fetchClientSecret = async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.USER_AUTHENTICATION;
      const data = {
        tenant_name: userPartner || "default_value",
        username: user,
        path: "/regenarate_client_secret",
        role_name: userRole,
        parent_module: "Partner",
        modules_list: ["Partner users"],
        feature_module_name: "Partner Info",
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
          ...metaData,
        sessionID: sessionId,
        client_id: clientIdAPI || null
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response?.data?.body);

      if (response.data.statusCode === 200 && parsedData.flag === true) {
        const client_secret_ = parsedData?.data?.clientSecret || ""
        setClientSecret(client_secret_);

        const user_id = parsedData?.data?.userId || ""
        setUserId(user_id);
        // setSAErrorMessages(prev => ({
        //   ...prev,
        //   clientSecret: clien_secret ? '' : 'Client Secret is required.',
        // }));
        if (rowData) {
          // notification.success({
          //   message: 'Success',
          //   description: 'Client Secret generated successfully',
          //   style: messageStyle,
          //   placement: 'top',
          // });
          await handleSeviceAccountSave(client_secret_)
        }

      } else {
        if (rowData) {
          // setSAErrorMessages(prev => ({
          //   ...prev,
          //   clientSecret: 'Client Secret is required.'
          // }));
          Modal.error({
            title: 'Generate Error',
            content: parsedData.message || 'An error occurred while fetching tax profiles.',
            centered: true,
          });
        }

        console.log("Error while fetching client secret")
      }
    } catch (err) {
      if (rowData) {
        // setSAErrorMessages(prev => ({
        //   ...prev,
        //   clientSecret: 'Client Secret is required.'
        // }));
        console.error("Error fetching client secret", err);
        Modal.error({
          title: 'Data Fetch Error',
          content: err instanceof Error ? err.message : 'An unexpected error occurred.',
          centered: true,
        });
      }

      console.log("Error while fetching client secret")
    } finally {
      setLoading(false);
    }
  };
  const fetchInitialValues = async (tenantName: any) => {
    setLoading(true);
    console.log("tenantName",tenantName)
    let selected_role = role_name
    const propTenant = tenantName?.value || tenantName
        if (tenant && (tenant.length > 1 || sub_tenant.length > 0)) {
          const selected_tenant = tenant.includes(propTenant)?propTenant:servicePartner || ""
          console.log("selected_tenant", selected_tenant)
          const selected_object = editedTableData.find((obj: any) => obj.tenant === selected_tenant)
          console.log("selected_object", selected_object)
          if (selected_object) {
            selected_role = selected_object.role || ""
          }
        }
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        path: "/get_service_account_info_details",
        partner_name: tenantName?.value || tenantName,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
          ...metaData,
        sessionID: sessionId,
        role_name: selected_role || role?.value || role,
        username: username,
        tenant_name: tenantName?.value || tenantName,
      };

      const response = await axios.post(url, { data: data });
      const parsedData = JSON.parse(response?.data?.body);

      if (response.data.statusCode === 200 && parsedData.flag === true) {
        const fetchedData = parsedData.data || {};
        setClientId(fetchedData?.client_id || "");
        setClientSecret(fetchedData?.client_secret || "");
        setTaxProfile(fetchedData.tax_profile ? { value: fetchedData.tax_profile, label: fetchedData.tax_profile } : null);
        if (fetchedData?.client_id && fetchedData?.client_secret) {
          setISSAFetched(true)
        }
        setTaxProfileOptions(parsedData?.tax_profiles?.map((profile: string) => ({
          value: profile,
          label: profile,
        })) || []);
      } else {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data.',
          centered: true,
        });
      }
    } catch (err) {
      console.error("Error fetching data:", err);
      Modal.error({
        title: 'Data Fetch Error',
        content: err instanceof Error ? err.message : 'An unexpected error occurred.',
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
  const handleServiceSubPartner = async (selectedOption: any) => {
    console.log("selectedOption", selectedOption)
    console.log("selectedSubPartner", sub_tenant)
    const value = selectedOption?.value || null
    setServiceSubPartner(value);
    if (selectedOption && isPopup) {
      await fetchInitialValues(value);
    }
  };

  const handleServicePartner = async (selectedOption: any) => {
    setServiceSubPartner(null)
    setServiceSubPartnerOptions([]);
    const value = selectedOption?.value || null
    setServicePartner(value);
    if (value && subPartnersData[value]) {
    console.log("value", value,subPartnersData[value])

    const filteredSubPartners = subPartnersData[value]
      ?.filter((item: any) => sub_tenant?.includes(item))
      ?.map((item: any) => (item));
    console.log("selectedSubPartner", sub_tenant)

    console.log("filteredSubPartners", filteredSubPartners)

    setServiceSubPartnerOptions(filteredSubPartners || []);
  } else {
    setServiceSubPartnerOptions([]);
  }
    if (selectedOption && isPopup) {
      await fetchInitialValues(value);
    }
  };

  const handleTaxProfileChange = (selectedOption: SingleValue<OptionType>) => {
    setTaxProfile(selectedOption);
  };

  const handleServiceAccountCheck = () => {
    const hasIncompleteRow = editedTableData.some((row: any) =>
      Object.keys(row).some((key) => {
        const value = row[key];
        return value === "" || value === null || value === undefined;
      })
    );

    if (hasIncompleteRow && editedTableData.length > 1 && (tenant.length>1 || sub_tenant.length>0)) {
      Modal.info({
        title: "Incomplete",
        content: "Please fill all the fields in User Role Access rows before creating.",
        centered: true,
      });
      return; //
    }
    const errors: string[] = [];
    if (!tenant || tenant.length===0) errors.push('Partner is Required.');
    if (!firstName) errors.push('First Name is Required.');
    if (!lastName) errors.push('Last Name is Required.');
    if (!username) errors.push('Username is Required.');
    if (!emailId) errors.push('Email ID is Required.');
    if ((tenant && tenant.length<2) && !role_name) errors.push('Role is Required.');
    // if (!password) errors.push('Password is required.');
    if (!Notification) errors.push('Notification is Required.')
    if (zip && zip !== "" && zip !== "None") {
      const regex = /^\d{5}$/; // Only 5 numerical values
      if (!regex.test(zip)) {
        errors.push('Zip Code must be Exactly 5 Digits.')
      }
    }
    if (emailId) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+(\.[^\s@]+)*$/;
      if (!emailRegex.test(emailId)) {
        errors.push('Please Enter a valid Email ID.')
      }
    }
    // if (!phone) errors.push('Please Enter a valid phone Number.');
    if (phone && phone !== "" && phone !== "None") {
      const phoneRegex = /^[\d\s\-+()]+$/;
      if (!phoneRegex.test(phone)) {
        errors.push('Please Enter a valid phone Number.')
      }
    }
    // if (!mobileNo) errors.push('Please Enter a valid Mobile Number.');
    if (mobileNo && mobileNo !== "" && mobileNo !== "None") {
      const phoneRegex = /^[\d\s\-+()]+$/;
      if (!phoneRegex.test(mobileNo)) {
        errors.push('Please Enter a valid Mobile Number.')
      }
    }
    console.log("errors", errors)
    setErrorMessages(errors);
    if (errors.length === 0) {
      return true
    }
    else {
      scrollToTop()
      return false
    }
  }
  const confirmServiceAccountCheck = (value: boolean) => {
    const validationCheck = handleServiceAccountCheck()
    if (value && validationCheck) {
      setIsServiceAcount(true)
      if (isPopup) {
        const sub_partner = sub_tenant.length > 0 ? sub_tenant[0] : null
        const tenant_name = sub_partner ? sub_partner : tenant
        // setServiceSubPartner(sub_partner)
        // fetchInitialValues(tenant_name)
      }
    }
    else {
      setIsServiceAcount(false)
    }
  }
  const handleGenerate = () => {
    fetchClientSecret()
  };
  return (
    <div className='bg-gray-50 user-info-div'>
      <h3 className="text-lg font-semibold mb-2 tabs-sub-headings pl-2 py-2">Basic Information</h3>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
        <div>
          <label className="field-label">Partner<span className="text-red-500">*</span></label>
          <Select
            isMulti
            isDisabled={!editable}
            value={Partneroptions.filter(option => tenant.includes(option.value))}
            onChange={handlePartnerChange}
            options={Partneroptions?.length > 0 ? Partneroptions : []}
            styles={editable ? editableDrp : nonEditableDrp}
          />
          {errorMessages.includes('Partner is Required.') && (
            <span className="text-red-600 ml-1">Partner is Required.</span>
          )}
        </div>

        <div>
          <label className="field-label">Sub Partner</label>
          <Select
            isMulti
            isDisabled={!editable}
            // value={subPartnersoptions.filter(option => selectedSubPartner.includes(option.value))}
            value={sub_tenant.map(val => ({ label: val, value: val }))}
            onChange={handleSetSubPartner}
            options={subPartnersoptions?.length > 0 ? subPartnersoptions : []}
            styles={editable ? editableDrp : nonEditableDrp}
          />

        </div>
        <div>
          <label className="field-label">First Name<span className="text-red-500">*</span></label>
          <input
            type="text"
            className={`${editable ? 'input' : 'non-editable-input'}`}
            value={firstName !== "None" ? firstName : ""}
            onChange={(e) => setFirstName(e.target.value)}
            disabled={!editable} />
          {errorMessages.includes('First Name is Required.') && (
            <span className="text-red-600 ml-1">First Name is Required.</span>
          )}
        </div>
        <div>
          <label className="field-label">Last Name<span className="text-red-500">*</span></label>
          <input
            type="text"
            className={`${editable ? 'input' : 'non-editable-input'}`}
            value={lastName !== "None" ? lastName : ""}
            onChange={(e) => setLastName(e.target.value)}
            disabled={!editable} />
          {errorMessages.includes('Last Name is Required.') && (
            <span className="text-red-600 ml-1">Last Name is Required.</span>
          )}
        </div>
        <div>
          <label className="field-label">Username<span className="text-red-500">*</span></label>
          <input
            type="text"
            value={username !== "None" ? username : ""}
            onChange={(e) => setUsername(e.target.value)}
            className={`${editable && !isPopup? 'input' : 'non-editable-input'}`}
            disabled={!editable || isPopup}
          />
          {errorMessages.includes('Username is Required.') && (
            <span className="text-red-600 ml-1">Username is Required.</span>
          )}
        </div>
        <div>
          <label className="field-label">Email ID<span className="text-red-500">*</span></label>
          <input
            type="email"
            value={emailId !== "None" ? emailId : ""}
            onChange={(e) => setEmailId(e.target.value)}
            className={`${editable ? 'input' : 'non-editable-input'}`}
            disabled={!editable}
          />
          {errorMessages.includes('Email ID is Required.') && (
            <span className="text-red-600 ml-1">Email ID is Required.</span>
          )}
          {errorMessages.includes('Please Enter a valid Email ID.') && (
            <span className="text-red-600 ml-1">Please Enter a valid Email ID.</span>
          )}
        </div>
        <div>

          <label className="field-label">Mobile No</label>
          <input type="text"
            className={`${editable ? 'input' : 'non-editable-input'}`}
            value={mobileNo !== "None" ? mobileNo : ""}
            onChange={(e) => setMobileNo(e.target.value)}
            disabled={!editable} />
          {errorMessages.includes('Please Enter a valid Mobile Number.') && (
            <span className="text-red-600 ml-1">Please Enter a valid Mobile Number.</span>
          )}
        </div>
        <div>
          <label className="field-label">Role<span className="text-red-500">*</span></label>
          <Select
            isDisabled={!editable || tenant.length>1 || sub_tenant.length > 0}
            value={role && Roleoptions.filter(option => role_name === option.value)}
            options={tenant ? Roleoptions.length > 0 ? Roleoptions : [{ value: null, label: "Roles are not enabled" }] : []}
            // value={{ value: role_name, label: role_name }}
            onChange={handlesetRole}
            // options={Roleoptions.map((option: string) => ({
            //   label: option,
            //   value: option,
            // }))}
            styles={(editable && tenant.length===1 && sub_tenant.length===0) ? editableDrp : nonEditableDrp}
          />
          {errorMessages.includes('Role is Required.') && (
            <span className="text-red-600 ml-1">Role is Required.</span>
          )}
        </div>
        {/* <div>
          <label className="field-label">Password<span className="text-red-500">*</span></label>
          <input
            type="password"
            value={password!=="None"?password:""}
            onChange={(e) => setPassword(e.target.value)}
            className={`${editable ? 'input' : 'non-editable-input'}`}
            disabled={!editable}
          />
          {errorMessages.includes('Password is required.') && (
            <span className="text-red-600 ml-1">Password is Required.</span>
          )}
        </div> */}
        <div>
          <label className="field-label">Phone</label>
          <input type="text"
            className={`${editable ? 'input' : 'non-editable-input'}`}
            value={phone !== "None" ? phone : ""}
            onChange={(e) => setPhone(e.target.value)}
            disabled={!editable} />
          {errorMessages.includes('Please Enter a valid phone Number.') && (
            <span className="text-red-600 ml-1">Please Enter a valid phone Number.</span>
          )}
        </div>
        <div>
          <label className="field-label">TimeOut Frequency</label>
          <input
            type="number"
            value={timeOutFrequency}
            min="0"
            step="1"
            className="input"
            onChange={(e) => {
              const newTime = e.target.value === "" ? 0 : Number(e.target.value);
              console.log("newTime", newTime, typeof newTime);
              setTimeOutFrequency(newTime);
            }}
          />
        </div>
        {usersFeaures.includes("Enable 2.0 Flow for User Switch-Partner users") && (
          <div className='mt-8'>
            {/* <label className="field-label">Enable 2.0 Flow for User</label> */}
            <Switch
              checked={switchUser}
              onChange={(checked) => setSwitchUser(checked)}
              className="scale-[0.8] md:scale-[1.3] ml-4"
              disabled={!editable}
            />
            <span className="font-semibold ml:2 md:ml-4 toggle-span">Enable 2.0 Flow for User</span>
          </div>
        )}
      </div>

      <div>
        <h3 className="tabs-sub-headings">Additional Information</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <div>
            <label className="field-label">Notification Enable<span className="text-red-500">*</span></label>
            <Select
              isDisabled={!editable}
              styles={editable ? editableDrp : nonEditableDrp}
              // value={rowData ? { value: getFieldValue('Notification enable'), label: getFieldValue('Notification enable') } : Notification}
              value={Notification}
              options={Notificationoptions}
              onChange={handleNotification}
            />
            {errorMessages.includes('Notification is Required.') && (
              <span className="text-red-600 ml-1">Notification is Required.</span>
            )}
          </div>
          <div>
            <label className="field-label">Business Name</label>
            <input type="text"
              className={`${editable ? 'input' : 'non-editable-input'}`}
              value={businessName !== "None" ? businessName : ""}
              onChange={(e) => setBusinessName(e.target.value)}
              disabled={!editable}
            />
          </div>
          <div>
            <label className="field-label">Locale</label>
            <input type="text"
              className={`${editable ? 'input' : 'non-editable-input'}`}
              value={locale !== "None" ? locale : ""}
              onChange={(e) => setLocale(e.target.value)}
              disabled={!editable}
            />
          </div>
          <div>
            <label className="field-label">Apt/Suite</label>
            <input type="text"
              className={`${editable ? 'input' : 'non-editable-input'}`}
              value={aptSuite !== "None" ? aptSuite : ""}
              onChange={(e) => setAptSuite(e.target.value)}
              disabled={!editable}
            />
          </div>
          <div>
            <label className="field-label">Address Line-1</label>
            <input type="text"
              className={`${editable ? 'input' : 'non-editable-input'}`}
              value={addressLine1 !== "None" ? addressLine1 : ""}
              onChange={(e) => setAddressLine1(e.target.value)}
              disabled={!editable}
            />
          </div>
          <div>
            <label className="field-label">Address Line-2</label>
            <input type="text"
              className={`${editable ? 'input' : 'non-editable-input'}`}
              value={addressLine2 !== "None" ? addressLine2 : ""}
              onChange={(e) => setAddressLine2(e.target.value)}
              disabled={!editable}
            />
          </div>
          <div>
            <label className="field-label">Country</label>
            <input type="text"
              className={`${editable ? 'input' : 'non-editable-input'}`}
              value={country !== "None" ? country : ""}
              onChange={(e) => setCountry(e.target.value)}
              disabled={!editable}
            />
          </div>
          <div>
            <label className="field-label">State</label>
            <input type="text"
              className={`${editable ? 'input' : 'non-editable-input'}`}
              value={state !== "None" ? state : ""}
              onChange={(e) => setState(e.target.value)}
              disabled={!editable}
            />
          </div>
          <div>
            <label className="field-label">City</label>
            <input type="text"
              className={`${editable ? 'input' : 'non-editable-input'}`}
              value={city !== "None" ? city : ""}
              onChange={(e) => setCity(e.target.value)}
              disabled={!editable}
            />
          </div>
          {/* <div>
            <label className="field-label">Time Zone</label>
            <Select
                id="timezone-select"
                value={timezoneOptions.find(option => option.value === timeZone)}
                onChange={handleTimezoneChange}
                options={timezoneOptions}
                isSearchable
                placeholder="Select a time zone"
                styles={editable ? editableDrp : nonEditableDrp}
                menuPortalTarget={document.body} // This will append the dropdown to the body
                menuPosition="fixed" // Ensures dropdown is fixed and doesn't affect the form layout
              /> */}
          {/* <input type="text"
              className={`${editable ? 'input' : 'non-editable-input'}`}
              value={timeZone}
              onChange={(e) => setTimeZone(e.target.value)}
              disabled={!editable}
            /> */}
          {/* </div> */}

          <div>
            <label className="field-label">Zip</label>
            <input type="text"
              className={`${editable ? 'input' : 'non-editable-input'}`}
              value={zip !== "None" ? zip : ""}
              onChange={(e) => setZip(e.target.value)}
              disabled={!editable}
            />
            {errorMessages.includes('Zip Code must be Exactly 5 Digits.') && (
              <span className="text-red-600 ml-1">Zip Code must be Exactly 5 Digits.</span>
            )}
          </div>
        </div>
      </div>
      <>
        <Checkbox
          checked={isServiceAccount}
          onChange={(e) => (confirmServiceAccountCheck(e.target.checked || false))}
        />
        <span className='ml-2 toggle-span'>{`${isPopup ? "Edit" : "Create"} Service Account`}</span>

        {isServiceAccount && (
          <div className='mt-4'>
            <h3 className="text-lg font-semibold mb-2 text-blue-500 bg-gray-200 pl-2 py-2">Service Account</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div>
                <label className="field-label">Partner{tenant.length > 0 && <span className='text-red-500'>*</span>}</label>
                <Select
                  isDisabled={!editable}
                  value={servicePartner ? { label: servicePartner, value: servicePartner } : null}
                  onChange={handleServicePartner}
                  options={tenant.map((sp) => ({
                    label: sp,
                    value: sp,
                  }))}
                  styles={editable ? editableDrp : nonEditableDrp}
                  isClearable
                />
                {SAerrorMessages.subPartner && (
                  <span className="text-red-600 mt-1 block">{SAerrorMessages.subPartner}</span>
                )}
              </div>
              <div>
                <label className="field-label">Sub Partner
                  {/* {selectedSubPartner.length > 0 && <span className='text-red-500'>*</span>} */}
                  </label>
                <Select
                  isDisabled={!editable}
                  value={serviceSubPartner ? { label: serviceSubPartner, value: serviceSubPartner } : null}
                  onChange={handleServiceSubPartner}
                  options={serviceSubPartnerOptions.map((sp) => ({
                    label: sp,
                    value: sp,
                  }))}
                  styles={editable ? editableDrp : nonEditableDrp}
                  isClearable
                />
                {SAerrorMessages.subPartner && (
                  <span className="text-red-600 mt-1 block">{SAerrorMessages.subPartner}</span>
                )}
              </div>
              <div>
                <label className="field-label">Tax Profile</label>
                <VirtualizedSelect
                  value={taxProfile}
                  onChange={handleTaxProfileChange}
                  options={taxProfileOptions}
                  styles={editable ? editableDrp : nonEditableDrp}
                  isClearable
                  placeholder="Select..."
                  maxHeight={300}
                  isDisabled={!editable}
                />
              </div>
              <div>
                <label className="field-label">Client ID<span className="text-red-500">*</span></label>
                <input
                  type="text"
                  className={`${(editable && !isSAFetched) ? 'input' : 'non-editable-input'}`}
                  value={
                    clientId.endsWith('_api') ? clientId.slice(0, -4) : clientId
                  }
                  onChange={(e) => {
                    setClientId(e.target.value);
                    setSAErrorMessages(prev => ({
                      ...prev,
                      clientId: e.target.value ? '' : 'Client ID is required.',
                    }));
                  }}
                  disabled={(!editable || isSAFetched)}
                />
                {SAerrorMessages.clientId && (
                  <span className="text-red-600 mt-1 block">{SAerrorMessages.clientId}</span>
                )}
              </div>
              {/* {(rowData && isSAFetched) && ( */}
              <div>
                <label className="field-label">Client Secret</label>
                <div className="relative w-full">
                  <input
                    type="password"
                    value={clientSecret}
                    // className={`w-full pr-10 ${disabledClientSecret ? 'non-editable-input' : 'input'}`}
                    className={`!w-[90%] pr-10 non-editable-input`}
                    // disabled={disabledClientSecret || !editable}
                    disabled
                    onChange={(e) => {
                      setClientSecret(e.target.value);
                    }}
                  />
                  <button
                    type="button"
                    onClick={handleCopy}
                    // disabled={disabledClientSecret || !editable}
                    className="absolute border border-gray-400 rounded-[5px] py-[7px] top-1/2 text-xl -translate-y-1/2 disabled:opacity-50 cursor-pointer w-[10%]"
                  >
                    <CopyOutlined className='text-black' />
                  </button>
                </div>

                {/* {SAerrorMessages.clientSecret && (
                    <span className="text-red-600 mt-1 block">{SAerrorMessages.clientSecret}</span>
                  )} */}
                <div className="text-gray-600 mt-1">
                  <span>Client Secret will be auto generated by zitadel.</span>
                </div>
              </div>
              {/* )} */}

            </div>
          </div>
        )}
      </>

      {/* Tenant Role Mapping List View */}
                  {(tenant.length > 1 || sub_tenant.length > 0 ) && (
                    <>
                      <div style={{ marginBottom: "1rem" }} className='mt-2'>
                        <h3 className="tabs-sub-headings">User Role Access</h3>
                        <TenantRoleMappingTable
                          initialData={editedTableData.length>0 ? [... editedTableData] : []}
                          itemsPerPage={10}
                          popupHeading="User role access"
                          pagination={{ start: 0, end: 0, total: 0 }}
                          tenantOptions={Partneroptions}
                          subPartnerOptions={subPartnersoptions}
                          isEditable={editable || false}
                          rolePartnersData={rolePartnersData}
                          subPartnersData={subPartnersData}
                          row={rowData}
                        />
                      </div>
                    </>
                  )}
      {editable && (
        <div className="flex justify-end space-x-4 mt-3">
          {/* <button className="cancel-btn">
    <XMarkIcon className="h-5 w-5 text-black-500 mr-2" />
    <span>Cancel</span>
  </button> */}
          {(editable && isServiceAccount && isSAFetched) && (
            <div className="flex justify-end space-x-4">
              <Button
                className="save-btn"
                onClick={handleGenerate}
                icon={<SyncOutlined />}
              // disabled={!editable}
              >
                {'Regenerate Client Secret'}
              </Button>
            </div>
          )}
          <button
            className={`${isUserInfoSubmitted ? "cancel-btn" : "save-btn "} disabled:cursor-not-allowed`}
            onClick={() => handleConfirmSave()}
            disabled={isUserInfoSubmitted}
          >
            {/* <CheckIcon className="h-5 w-5 text-black-500 mr-2" /> */}
            <span>Save</span>

          </button>
        </div>
      )}

      {showModal && (
        <Modal
          title="Confirmation"
          open={showModal}
          onOk={handleSave}
          onCancel={handleCancelSave}
          centered
        >
          <p>{`Are you sure you want to ${isPopup ? 'edit' : 'create'} this user`}</p>
        </Modal>
      )}
    </div>
  );
};

export default UserInfo;
