"use client";
import { CheckIcon, XMarkIcon } from '@heroicons/react/16/solid';
import React, { useState, useEffect } from 'react';
import Select, { ActionMeta, MultiValue, SingleValue } from 'react-select';
import { NonEditableDropdownStyles, DropdownStyles } from '@/app/components/css/dropdown';
import { useUserStore } from './createUserStore';
import { usePartnerStore } from '../../partnerStore';
import { useAuth } from '@/app/components/auth_context';
import { getCurrentDateTime } from '@/app/components/header_constants';
import axios from 'axios';
import { Modal, notification, Spin } from 'antd';
import { ENV_ROUTES } from '@/app/components/routes/route_constants';
import VirtualizedSelect from '@/app/components/virtualized_dropdown';
import UserRole from './userrole';
import { usePrivateNetworkStore } from '@/app/stores/privateNetworksStore';
type OptionType = {
    value: string;
    label: string;
};
const editableDrp = DropdownStyles;
const nonEditableDrp = NonEditableDropdownStyles;
interface TenantInfoProps {
    rowData?: any;
    editable?: boolean;
    setRowData: (row: any) => void;
    onClose: () => void;
    action?: any;
}

const TenantInfo: React.FC<TenantInfoProps> = ({ rowData, editable = false, setRowData, action, onClose }) => {
    const { username, tenantNames, role, partner: userPartner, settabledata, token, selectedDb, metaData, firstLastName, sessionId } = useAuth();
    const [carriers, setCarriers] = useState<string[]>([]);
    const [errorMessages, setErrorMessages] = useState<string[]>([]);
    const [CarrierNotification, setCarrierNotification] = useState<any[]>([]);
    const [ServiceProvider, setServiceProvider] = useState<any[]>([]);
    const [customerGroup, setCustomerGroup] = useState<SingleValue<OptionType>>(null);
    const [customer, setCustomer] = useState<any[]>([]);

    const [CustomerGroupOptions, setCustomerGroupOptions] = useState<any[]>([])
    const [ServiceProviderOptions, setServiceProviderOptions] = useState<any[]>([])
    const [customerOptions, setcustomerOptions] = useState<any[]>([])
    const [generalFields, setGeneralFields] = useState<any[]>([]);

    const Carrieroptions = carriers.map(carrier => ({ value: carrier, label: carrier }));
    const { partnerData, setPartnerUsers } = usePartnerStore.getState();
    const usersData = partnerData["Partner users"]?.data?.["Partner users"] || {};
    //Show Modal
    const [showModal, setShowModal] = useState(false);
    const [loading, setLoading] = useState(false);
    const [subPartnerOptions, setSubPartnerOptions] = useState<any[]>([])
    const [selectedSubPartnerOptions, setSelectedSubPartnerOptions] = useState<any[]>([])
    const [selectedSubPartner, setSelectedSubPartner] = useState<SingleValue<OptionType>>(null);
    const [partnerOptions, setPartnerOptions] = useState<any[]>([])
    const [selectedPartner, setSelectedPartner] = useState<SingleValue<OptionType>>(null);
    const [isAlreadyCreated, setIsAlreadyCreated] = useState(false);

    const subPartners_Data = usersData?.tenant || {}
    const { editedTableData } = usePrivateNetworkStore();

    const {
        tenant,
        role_name,
        sub_tenant,
        user_name,
        setTenant,
        setRoleName,
        setSubTenant
    } = useUserStore();

    const initialfetchData = async (tenantName: any) => {
        setLoading(true);
        try {
            const url = ENV_ROUTES.MODULE_MANAGEMENT;
            const data = {
                path: "/customer_info_details",
                partner_name: tenantName,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                role_name: role
            };
            console.log(getCurrentDateTime(), "Show the log time request sent from ui to lambda");

            const response = await axios.post(url, { data: data });
            const parsedData = JSON.parse(response?.data?.body);
            console.log(parsedData?.dropdown, "Show the log time response received from lambda");
            console.log(getCurrentDateTime(), "Show the log time response sent from lambda to ui");

            if (response.data.statusCode === 200 && parsedData.flag === true) {
                const dropdown = parsedData.dropdown || {};
                setcustomerOptions(dropdown.customers?.map((customer: any) => ({ value: customer, label: customer })) || []);
                setCustomerGroupOptions(dropdown.customergroups?.map((group: any) => ({ value: group, label: group })) || []);
                setServiceProviderOptions(dropdown.serviceprovider?.map((provider: any) => ({ value: provider, label: provider })) || []);
            } else {
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            }
        } catch (err) {
            console.error("Error fetching data:", err);
            Modal.error({
                title: 'Data Fetch Error',
                content: err instanceof Error ? err.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        } finally {
            setLoading(false);
        }
    };

    const callPartnerAdminSync = async () => {
        // setLoading(true);
        try {
            const url = ENV_ROUTES.MODULE_MANAGEMENT;
            const data = {
                path: "/update_tenant_based_partner_admin_filters",
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                role_name: role || role_name,
                username: user_name,
                main_tenant_name: selectedPartner && selectedPartner?.value
                    ? selectedPartner?.value : userPartner || userPartner,
                tenant_name: selectedSubPartner && selectedSubPartner?.value
                    ? selectedSubPartner?.value
                    : selectedPartner && selectedPartner?.value
                        ? selectedPartner?.value : userPartner || userPartner,
                action: rowData && !isAlreadyCreated ? "edit" : "create",
                customers_data: {
                    customer_group: customerGroup ? customerGroup.value : null,
                    service_provider: ServiceProvider.length > 0 ? ServiceProvider : null,
                    customers: customer.length > 0 ? customer : null,
                }
            };
            console.log(getCurrentDateTime(), "Show the log time request sent from ui to lambda");

            const response = await axios.post(url, { data: data });
            const parsedData = JSON.parse(response?.data?.body);
            if (response.data.statusCode === 200 && parsedData.flag === true) {
                console.log("partner admin sync success")
            } else {
                console.log("partner admin sync failed")
            }
        } catch (err) {
            console.log("partner admin sync failed")
        } finally {
            // setLoading(false);
        }
    };

    const fetchInitialValues = async (tenantName: any) => {
        setLoading(true);
        try {
            const url = ENV_ROUTES.MODULE_MANAGEMENT;
            const data = {
                path: "/get_user_info_details",
                partner_name: tenantName,
                // sub_partner_name:tenant===tenantName?null:tenantName || tenant,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                role_name: role,
                username: user_name,
                tenant_name: userPartner
            };

            const response = await axios.post(url, { data: data });
            const parsedData = JSON.parse(response?.data?.body);

            if (response.data.statusCode === 200 && parsedData.flag === true) {
                const dropdown = parsedData.dropdown || {};
                // const selected_provider=dropdown?.service_provider || []
                const serviceProviderFieldValue = dropdown?.service_provider || ""
                let selected_provider: string[] = [];
                try {
                    selected_provider = JSON.parse(serviceProviderFieldValue);
                } catch (error) {
                    if (serviceProviderFieldValue && serviceProviderFieldValue !== 'None') {
                        selected_provider = [serviceProviderFieldValue];
                    }
                }
                setServiceProvider(selected_provider)
                // const selected_customer=dropdown?.customers || []
                const customersFieldValue = dropdown?.customers || ""
                let selected_customer: string[] = [];
                try {
                    selected_customer = JSON.parse(customersFieldValue);
                } catch (error) {
                    if (customersFieldValue && customersFieldValue !== 'None') {
                        selected_customer = [customersFieldValue];
                    }
                }
                setCustomer(selected_customer)
                const customersGroupFieldValue = dropdown?.customer_group || null
                const selected_group = { label: customersGroupFieldValue, value: customersGroupFieldValue }
                setCustomerGroup(selected_group)
                if (selected_provider.length === 0 && selected_customer.length === 0 && (customersGroupFieldValue === "None" || customersGroupFieldValue === "" || customersGroupFieldValue === null)) {
                    setIsAlreadyCreated(true)
                }
                else {
                    setIsAlreadyCreated(false)
                }
            } else {
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            }
        } catch (err) {
            console.error("Error fetching data:", err);
            Modal.error({
                title: 'Data Fetch Error',
                content: err instanceof Error ? err.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        } finally {
            setLoading(false);
        }
    };
    const fetchCustomerOptions = async (tenantName: any) => {
        // setLoading(true);
        try {
            const url = ENV_ROUTES.MODULE_MANAGEMENT;
            const data = {
                path: "/customer_info_dropdown",
                partner_name: tenantName,
                // sub_partner_name:tenant===tenantName?null:tenantName || tenant,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                role_name: role,
                username: user_name,
                tenant_name: userPartner
            };
            console.log(getCurrentDateTime(), "Show the log time request sent from ui to lambda");

            const response = await axios.post(url, { data: data });
            const parsedData = JSON.parse(response?.data?.body);
            console.log(parsedData?.dropdown, "Show the log time response received from lambda");
            console.log(getCurrentDateTime(), "Show the log time response sent from lambda to ui");

            if (response.data.statusCode === 200 && parsedData.flag === true) {
                const dropdown = parsedData.dropdown || {};
                setcustomerOptions(dropdown.customers?.map((customer: any) => ({ value: customer, label: customer })) || []);
            } else {
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            }
        } catch (err) {
            console.error("Error fetching data:", err);
            Modal.error({
                title: 'Data Fetch Error',
                content: err instanceof Error ? err.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        } finally {
            // setLoading(false);
        }
    };
    const fetchCustomerGroupOptions = async (tenantName: any) => {
        // setLoading(true);
        try {
            const url = ENV_ROUTES.MODULE_MANAGEMENT;
            const data = {
                path: "/customer_group_info_dropdown",
                partner_name: tenantName,
                // sub_partner_name:tenant===tenantName?null:tenantName || tenant,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                role_name: role,
                username: user_name,
                tenant_name: userPartner
            };
            console.log(getCurrentDateTime(), "Show the log time request sent from ui to lambda");

            const response = await axios.post(url, { data: data });
            const parsedData = JSON.parse(response?.data?.body);
            console.log(parsedData?.dropdown, "Show the log time response received from lambda");
            console.log(getCurrentDateTime(), "Show the log time response sent from lambda to ui");

            if (response.data.statusCode === 200 && parsedData.flag === true) {
                const dropdown = parsedData.dropdown || {};
                setCustomerGroupOptions(dropdown.customergroups?.map((group: any) => ({ value: group, label: group })) || []);
            } else {
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            }
        } catch (err) {
            console.error("Error fetching data:", err);
            Modal.error({
                title: 'Data Fetch Error',
                content: err instanceof Error ? err.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        } finally {
            // setLoading(false);
        }
    };
    const fetchServiceProviderOptions = async (tenantName: any) => {
        try {
            if (rowData) {
                setLoading(true);
            }

            const url = ENV_ROUTES.MODULE_MANAGEMENT;
            const data = {
                path: "/serviceprovider_info_dropdown",
                partner_name: tenantName,
                // sub_partner_name:tenant===tenantName?null:tenantName || tenant,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                role_name: role,
                username: user_name,
                tenant_name: userPartner
            };
            console.log(getCurrentDateTime(), "Show the log time request sent from ui to lambda");

            const response = await axios.post(url, { data: data });
            const parsedData = JSON.parse(response?.data?.body);
            console.log(parsedData?.dropdown, "Show the log time response received from lambda");
            console.log(getCurrentDateTime(), "Show the log time response sent from lambda to ui");

            if (response.data.statusCode === 200 && parsedData.flag === true) {
                const dropdown = parsedData.dropdown || {};
                setServiceProviderOptions(dropdown.serviceprovider?.map((provider: any) => ({ value: provider, label: provider })) || []);
            } else {
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            }
        } catch (err) {
            console.error("Error fetching data:", err);
            Modal.error({
                title: 'Data Fetch Error',
                content: err instanceof Error ? err.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        } finally {
            // setLoading(false);
        }
    };

    useEffect(() => {
        const partner_options = tenant ? tenant : []
        setPartnerOptions(partner_options)
        const initializeData = () => {
            const general_fields = partnerData["Partner users"]?.headers_map?.["Partner users"]?.general_fields || {}
            const CustomerGroupOptions: any[] = usersData?.name || []
            const CustomerGroupOptions_ = CustomerGroupOptions.map((group: any) => ({ value: group, label: group }))
            const ServiceProviderOptions: any[] = usersData?.service_provider_name || []
            const ServiceProviderOptions_ = ServiceProviderOptions.map((service: any) => ({ value: service, label: service }))
            const customerOptions: any[] = usersData?.customer_name || []
            const customerOptions_ = customerOptions.map((customer: any) => ({ value: customer, label: customer }))
            // setcustomerOptions(customerOptions_)
            // setCustomerGroupOptions(CustomerGroupOptions_)
            // setServiceProviderOptions(ServiceProviderOptions_)
            setGeneralFields(general_fields)


        };

        initializeData();
        // initialfetchData(tenant);
        if (rowData) {
            console.log("rowdata", rowData)

            try {
                // setLoading(true)
                const parseNames = (raw: any, fallbackSingle?: string | null) => {
                    if (!raw || raw === "None") {
                        return fallbackSingle ? [fallbackSingle] : [];
                    }

                    if (Array.isArray(raw)) return raw;

                    const s = String(raw).trim();
                    if (!s) return fallbackSingle ? [fallbackSingle] : [];

                    // If it looks like a JSON array, try to parse it
                    if (s.startsWith("[")) {
                        try {
                            const parsed = JSON.parse(s);
                            if (Array.isArray(parsed)) return parsed;
                        } catch {
                            // fall through to non-JSON parsing
                        }
                    }

                    // If it contains commas, treat as comma-separated list
                    if (s.includes(",")) {
                        return s
                            .split(",")
                            .map((x) => x.trim())
                            .filter(Boolean);
                    }

                    // Otherwise treat as a single value
                    return [s];
                };
                const tenantValue = rowData?.["tenant_name"] || "None";
                // const parsedTenants =
                //     tenantValue && tenantValue !== "None"
                //         ? JSON.parse(tenantValue)
                //         : [];
                const subtenantValue = rowData?.["subtenant_name"] || "None";
                // const parsedSubtenants =
                //     subtenantValue && subtenantValue !== "None"
                //         ? JSON.parse(subtenantValue)
                //         : [];

                const parsedTenants = parseNames(tenantValue, userPartner);
                const parsedSubtenants = parseNames(subtenantValue);
                // const parsedSubtenants = JSON.parse(rowData["subtenant_name"]);
                setSubPartnerOptions(parsedSubtenants); // Set available sub-partners
                const sub_partner = parsedSubtenants.length > 0 ? { label: parsedSubtenants[0], value: parsedSubtenants[0] } : null
                const selected_partner = parsedTenants.length > 0 ? { label: parsedTenants[0], value: parsedTenants[0] } : null
                console.log("selected_partner", selected_partner)
                console.log("parsedTenants", parsedTenants)


                if (selected_partner && selected_partner?.value) {

                    setSelectedPartner(selected_partner)
                    fetchInitialValues(selected_partner?.value)
                    fetchCustomerGroupOptions(selected_partner?.value)
                    fetchCustomerOptions(selected_partner?.value)
                    fetchServiceProviderOptions(selected_partner?.value)
                    const sub_partners = subPartners_Data[selected_partner?.value || ""] || []
                    console.log("parsedSubtenants", parsedSubtenants)
                    const selected_options = parsedSubtenants.filter((option: any) => sub_partners.includes(option))
                    console.log("selected_options", selected_options)
                    setSelectedSubPartnerOptions(selected_options)
                    const selected_sub_partner = selected_options.find((option: any) =>
                        option === sub_partner?.value
                    );
                    setSelectedSubPartner(selected_sub_partner); // Set default selected sub-partners

                    const value = selected_sub_partner && selected_partner
                        ? selected_sub_partner?.value
                        : selected_partner
                            ? selected_partner?.value : null
                    console.log("selected_sub_partner", selected_sub_partner)
                    console.log("selected_partner", selected_partner)


                    console.log("value", value)
                    if (value) {
                        fetchInitialValues(value)
                        fetchCustomerGroupOptions(value)
                        fetchCustomerOptions(value)
                        fetchServiceProviderOptions(value)
                        fetchInitialValues(value)
                    }

                }

            } catch (error) {
                console.error("Error parsing subtenant_name:", error);
                setSubPartnerOptions([]); // Reset to empty if parsing fails
            }
            finally {
                // setLoading(false)
            }
        }
        else {
            const parsedSubtenants: any = sub_tenant && sub_tenant.length > 0 ? sub_tenant : []
            setSubPartnerOptions(parsedSubtenants); // Set available sub-partners
            const sub_partner = parsedSubtenants.length > 0 ? { label: parsedSubtenants[0], value: parsedSubtenants[0] } : null
            const selected_partner = tenant.length > 0 ? { label: tenant[0], value: tenant[0] } : null
            console.log("selected_partner", selected_partner)
            if (selected_partner && selected_partner?.value) {

                setSelectedPartner(selected_partner)
                const sub_partners = subPartners_Data[selected_partner?.value || ""] || []
                console.log("parsedSubtenants", parsedSubtenants)
                const selected_options = parsedSubtenants.filter((option: any) => sub_partners.includes(option))
                console.log("selected_options", selected_options)
                setSelectedSubPartnerOptions(selected_options)
                const selected_sub_partner = selected_options.find((option: any) =>
                    option === sub_partner?.value
                );
                setSelectedSubPartner(selected_sub_partner); // Set default selected sub-partners

                const value = selected_sub_partner && selected_partner
                    ? selected_sub_partner?.value
                    : selected_partner
                        ? selected_partner?.value : null
                console.log("selected_sub_partner", selected_sub_partner)
                console.log("selected_partner", selected_partner)


                console.log("value", value)
                if (value) {
                    fetchInitialValues(value)
                    fetchCustomerGroupOptions(value)
                    fetchCustomerOptions(value)
                    fetchServiceProviderOptions(value)
                    fetchInitialValues(value)
                }

            }
        }

    }, [usersData, rowData]);

    // useEffect(() => {
    //     if (rowData) {
    //         console.log("rowdata", rowData)
    //         const serviceProviderFieldValue = rowData?.["service_provider"] || ""
    //         let selected_provider: string[] = [];
    //         try {
    //             selected_provider = JSON.parse(serviceProviderFieldValue);
    //         } catch (error) {
    //             if (serviceProviderFieldValue && serviceProviderFieldValue !== 'None') {
    //                 selected_provider = [serviceProviderFieldValue];
    //             }
    //         }
    //         setServiceProvider(selected_provider)
    //         const customersFieldValue = rowData?.["customers"] || ""
    //         let selected_customer: string[] = [];
    //         try {
    //             selected_customer = JSON.parse(customersFieldValue);
    //         } catch (error) {
    //             if (customersFieldValue && customersFieldValue !== 'None') {
    //                 selected_customer = [customersFieldValue];
    //             }
    //         }
    //         setCustomer(selected_customer)
    //         const customersGroupFieldValue = rowData?.["customer_group"] || ""
    //         const selected_group = { label: customersGroupFieldValue, value: customersGroupFieldValue }
    //         setCustomerGroup(selected_group)

    //     }
    // }, [rowData]);

    const messageStyle = {
        fontSize: '14px',  // Adjust font size
        fontWeight: 'bold', // Make the text bold
        padding: '16px',
    };

    const handleClearFields = () => {
        setCarrierNotification([]);
        setServiceProvider([]);
        setCustomerGroup(null);
        setCustomer([]);
        setErrorMessages([]);
        setTenant([]);
        setSubTenant([]);
    };

    const callRunDBScript = async () => {
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
            tenant_name: userPartner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/run_db_script",
            role_name: role,
            module_name: "Partner Users",
            access_token: token,
            db_name: selectedDb,
            ...metaData,
            sessionID: sessionId,
            update_flag: rowData ? true : false,
            delete_flag: false,
            transfer_name: "users_sync_beta",
            request_received_at: getCurrentDateTime(),
            Partner: userPartner || "default_value",
            data: {
                users: [{
                    username: user_name || username || "",
                    tenant_name: selectedSubPartner && selectedSubPartner?.value
                        ? selectedSubPartner?.value
                        : selectedPartner && selectedPartner?.value
                            ? selectedPartner?.value : userPartner || userPartner,
                    customer_sync: true,
                    ...(rowData && { id: rowData.id }),
                }]
            },
        };

        try {
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
        } catch (error) {
            console.log("run db script customer info error", error)
        }

    }

    const handlePrevSubmit = async () => {
        try {
            setLoading(true)
            const url = ENV_ROUTES.MODULE_MANAGEMENT;

            let changedData: any = {}; // Initialize changedData as an object

            // Ensure getFieldValue returns a valid field name or provide a default value
            const serviceProviderFieldName = getFieldValue("Service provider") || "service_provider";
            const customerGroupFieldName = getFieldValue("Customer group") || "customer_group";
            const customersFieldName = getFieldValue("Customers") || "customers";

            changedData[serviceProviderFieldName] = ServiceProvider.length > 0 ? ServiceProvider : null;
            changedData[customerGroupFieldName] = customerGroup ? customerGroup.value : '';
            changedData[customersFieldName] = customer.length > 0 ? customer : null;
            changedData["username"] = user_name;
            changedData["is_active"] = true;
            changedData["is_deleted"] = false;
            changedData["modified_by"] = firstLastName || username;


            const data = {
                tenant_name: userPartner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/update_partner_info",
                template_name: "create_user",
                role_name: role,
                module_name: "Partner users",
                action: "update",
                request_received_at: getCurrentDateTime(),
                changed_data: {
                    "customer_info": changedData
                },

                Partner: userPartner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                ...(rowData ? { list_view_id: rowData?.id || "" } : {}),
            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
        }
        catch (error) {
            setLoading(false)
            console.log(
                error
            )
        }
    }

    const handleSubmit = async () => {
        const selectedPartner_ = selectedSubPartner && selectedSubPartner?.value
            ? selectedSubPartner?.value
            : selectedPartner && selectedPartner?.value
                ? selectedPartner?.value : userPartner || userPartner
        const selected_object = editedTableData.find((obj: any) => obj.tenant === selectedPartner_)
        console.log("selected_object", selected_object)
        let selectedRole = rowData ? rowData?.role || "" : role_name || ""
        if (selected_object && tenant && (tenant.length > 1 || sub_tenant.length !== 0)) {
            console.log("selected_object.role", selected_object.role)
            selectedRole = selected_object.role || ""
        }
        handlePrevSubmit()
        const mainRoleCheck = role?.toLowerCase() === "super admin" || role?.toLowerCase() === "partner admin" || role?.toLowerCase() === "agent partner admin"
        const createRoleCheck = selectedRole?.toLowerCase() === "partner admin" || selectedRole?.toLowerCase() === "agent partner admin"
        if (mainRoleCheck && createRoleCheck) {
            callPartnerAdminSync()
        }
        const errors: string[] = [];
        // if (CarrierNotification.length === 0) errors.push('Carrier is required.');
        if (!editable && ServiceProvider.length === 0) {
            errors.push('Service Provider is required.');
        }

        setErrorMessages(errors);

        if (errors.length === 0) {
            try {
                setLoading(true)
                const url = ENV_ROUTES.MODULE_MANAGEMENT;

                let changedData: any = {}; // Initialize changedData as an object

                // Ensure getFieldValue returns a valid field name or provide a default value
                const serviceProviderFieldName = getFieldValue("Service provider") || "service_provider";
                const customerGroupFieldName = getFieldValue("Customer group") || "customer_group";
                const customersFieldName = getFieldValue("Customers") || "customers";

                changedData[serviceProviderFieldName] = ServiceProvider.length > 0 ? ServiceProvider : null;
                changedData[customerGroupFieldName] = customerGroup ? customerGroup.value : null;
                changedData[customersFieldName] = customer.length > 0 ? customer : null;
                changedData["username"] = user_name;
                // changedData["is_active"] = true;
                // changedData["is_deleted"] = false;


                const data = {
                    tenant_name: userPartner || "default_value",
                    partner_name: selectedSubPartner && selectedSubPartner?.value
                        ? selectedSubPartner?.value
                        : selectedPartner && selectedPartner?.value
                            ? selectedPartner?.value : userPartner || userPartner,
                    username: username,
                    firstLastName: firstLastName,
                    path: "/update_customer_info_tenant_based",
                    template_name: "create_user",
                    role_name: role,
                    module_name: "Partner users",
                    action: "update",
                    request_received_at: getCurrentDateTime(),
                    changed_data: {
                        "customer_info": changedData
                    },

                    Partner: userPartner,
                    access_token: token,
                    db_name: selectedDb,
                    ...metaData,
                    sessionID: sessionId,
                    ...(rowData ? { list_view_id: rowData?.id || "" } : {}),
                };
                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);
                if (response && response.data.statusCode === 200) {
                    callRunDBScript()
                    try {
                        const url = ENV_ROUTES.MODULE_MANAGEMENT;
                        const data = {
                            tenant_name: userPartner || "default_value",
                            username: username,
                            firstLastName: firstLastName,
                            path: "/get_partner_info",
                            role_name: role,
                            parent_module: "Partner",
                            modules_list: ["Partner users"],
                            feature_module_name: "Partner Info",
                            pages: {
                                "Customer groups": { start: 0, end: 100 },
                                "Partner users": { start: 0, end: 100 }
                            },
                            request_received_at: getCurrentDateTime(),
                            access_token: token,
                            db_name: selectedDb,
                            ...metaData,
                            sessionID: sessionId,

                        };
                        console.log(getCurrentDateTime(), "Show the log time request sent from ui to lambda");

                        const response = await axios.post(url, { data });
                        const parsedData = JSON.parse(response.data.body);
                        console.log(getCurrentDateTime(), "Show the log time response sent from lambda to ui");
                        if (parsedData.flag === false) {
                            Modal.error({
                                title: 'Data Fetch Error',
                                content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                                centered: true,
                            });
                        } else {
                            setPartnerUsers(parsedData)
                            const tableData = parsedData?.data?.["Partner users"]?.users || [];
                            if (rowData) {
                                const foundRow = tableData.find((user: any) => user.id === rowData.id);
                                // Step 4: Set the found row to form data
                                if (foundRow) {
                                    setRowData(foundRow)
                                }
                            }
                            settabledata(tableData);
                            notification.success({
                                message: 'Success',
                                description: 'Successfully saved the form',
                                style: messageStyle,
                                placement: 'top', // Apply custom styles here
                            });
                        }
                        setLoading(false)
                    }
                    catch (error) {
                        setLoading(false)
                        Modal.error({
                            title: 'Submit Error',
                            content: parsedData.message || 'An error occurred while submitting the form. Please try again.',
                            centered: true,
                        });
                    }
                    // handleClearFields(); 
                }
                else {
                    Modal.error({
                        title: 'Submit Error',
                        content: parsedData.message || 'An error occurred while submitting the form. Please try again.',
                        centered: true,
                    });
                    setLoading(false)
                }
            }
            catch (error) {
                setLoading(false)
                console.log(
                    error
                )
            }
            finally {
                onClose()
            }
        } else {
            scrollToTop();
        }


    };
    //Handling modal save
    const handleConfirmSave = () => {
        handleSubmit();
        onClose()
        setShowModal(false);
    };
    //Handling modal cancel
    const handleCancelSave = () => {
        setShowModal(false);
    };

    const scrollToTop = () => {
        window.scrollTo({
            top: 0,
            behavior: 'auto'  // Optional: Smooth scroll animation
        });
    };
    const handleCarrier = (selectedOptions: MultiValue<OptionType>) => {
        const selectedCarriers = selectedOptions.map(option => option.value);

        setCarrierNotification(selectedCarriers);
        // if (selectedCarriers.length > 0) {
        //     setErrorMessages(prevErrors => prevErrors.filter(error => error !== 'Carrier is required.'));
        // }
    };
    const serviceProviderChange = (selectedOptions: MultiValue<OptionType>) => {
        let selectedProviders: any = []
        if (Array.isArray(selectedOptions)) {
            selectedProviders = selectedOptions.map((option: any) => option.value);
            console.log("selectedProviders", selectedProviders);
            setServiceProvider(selectedProviders);
        } else if (selectedOptions === null) {
            // When all options are cleared
            setServiceProvider([]);
        } else {
            // Fallback for single option object just in case
            // setCustomer([selectedOptions.value]);
            console.log("selectedOptions", selectedOptions);

        }
        if (!editable && selectedProviders.length > 0) {
            setErrorMessages(prevErrors =>
                prevErrors.filter(error => error !== 'Service Provider is required.')
            );
        }
    };


    const customerGroupChange = (selectedOption: SingleValue<OptionType>) => {

        if (selectedOption) {
            setCustomerGroup(selectedOption);
        }
        else {
            setCustomerGroup(null);
        }
    }
    const customerChange = (selectedOptions: any) => {
        if (!selectedOptions) {
            setCustomer([]);
            return;
        }
        if (Array.isArray(selectedOptions)) {
            const selectedCustomers = selectedOptions.map((option: any) => option.value);
            console.log("selectedCustomers", selectedCustomers);
            setCustomer(selectedCustomers);
        } else {
            console.log("selectedOption", selectedOptions);
            setCustomer([selectedOptions.value]);
        }
    };

    const getFieldValue = (label: any) => {
        if (rowData) {
            console.log("label", label)
            const field = generalFields ? generalFields.find((f: any) => f.display_name === label) : null;
            return field ? rowData[field.db_column_name] || '' : '';
        }
        else {
            return ""
        }
    };

    const handleChange = async (value: string) => {
        console.log("valuee")
        if (value) {
            setLoading(true);
            try {
                await Promise.all([
                    fetchCustomerGroupOptions(value),
                    fetchCustomerOptions(value),
                    fetchServiceProviderOptions(value),
                ]);
            } catch (error) {
                console.error("Error fetching data:", error);
            } finally {
                setLoading(false);
                handleClearFields()
            }
        }
    };

    const handleSetSubPartner = async (selectedOption: SingleValue<OptionType>) => {
        setSelectedSubPartner(selectedOption);
        // if (selectedOption) {
        //     await fetchData(selectedOption);
        // }
        const value = selectedOption?.value || selectedPartner?.value || ""
        // initialfetchData(value)
        if (rowData) {
            fetchInitialValues(value)
            fetchCustomerGroupOptions(value)
            fetchCustomerOptions(value)
            fetchServiceProviderOptions(value)
        }
        else {
            handleChange(value)
        }

    };

    const handleSetPartner = async (selectedOption: SingleValue<OptionType>) => {
        setSelectedPartner(selectedOption);
        let value = selectedOption?.value || ""

        if (selectedOption) {
            const sub_partners = subPartners_Data[value] || []
            console.log("sub_partners", sub_partners)
            console.log("subPartnerOptions", subPartnerOptions)
            const selected_options = subPartnerOptions.filter(option => sub_partners.includes(option))
            console.log("selected_options", selected_options)

            setSelectedSubPartner(null);
            setSelectedSubPartnerOptions(selected_options)
            // initialfetchData(value)
            if (rowData) {
                fetchInitialValues(value)
                fetchCustomerGroupOptions(value)
                fetchCustomerOptions(value)
                fetchServiceProviderOptions(value)
            }
            else {
                handleChange(value)
            }

        }

    };

    if (loading) {
        return (
            <div className="flex justify-center items-center h-screen">
                <Spin size="large" />
            </div>
        );
    }
    // const customerValues = Array.isArray(customer) ? customer : [];
    // console.log(customerValues, ">>>")
    // console.log("action", editable)
    return (
        <div className=''>
            <div>
                <h3 className="tabs-sub-headings">Customer Info</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    {/* <div>
                        <label className="field-label">Partner</label>
                        <input
                            type="text"
                            value={tenant}
                            className="non-editable-input"
                        />
                    </div> */}
                    <div>
                        <label className="field-label">Partner</label>
                        <Select
                            // isDisabled={!editable}
                            value={selectedPartner}
                            onChange={handleSetPartner}
                            options={partnerOptions.map((value) => ({ value, label: value }))}
                            // styles={editable ? editableDrp : nonEditableDrp}
                            styles={editableDrp}
                            isClearable
                        />
                    </div>

                    <div>
                        <label className="field-label">Sub Partner</label>
                        <Select
                            // isDisabled={!editable}
                            value={selectedSubPartner}
                            onChange={handleSetSubPartner}
                            options={selectedSubPartnerOptions.map((value) => ({ value, label: value }))}
                            // value={selectedSubPartnerOptions.filter(option => selectedSubPartner === (option.value))}
                            // styles={editable ? editableDrp : nonEditableDrp}
                            styles={editableDrp}
                            isClearable
                        />
                    </div>
                    {/* <div>
                        <label className="field-label">Carrier</label>
                        <Select
                            isMulti
                            value={CarrierNotification}
                            options={Carrieroptions}
                            styles={!tenant || !editable ? nonEditableDrp : editableDrp}
                            onChange={handleCarrier}
                            isDisabled={!tenant || !editable}

                        /> */}
                    {/* {errorMessages.includes('Carrier is required.') && (
                            <span className="text-red-600 ml-1">Carrier is required.</span>
                        )} */}
                    {/* </div> */}
                    <div>
                        <label className="field-label">Service Provider
                            {!editable && <span className="text-red-500">*</span>}
                        </label>

                        {/* <Select
                            isMulti
                            options={ServiceProviderOptions}
                            styles={editable ? editableDrp : nonEditableDrp}
                            value={ServiceProviderOptions.filter(option => ServiceProvider.includes(option.value))}
                            onChange={serviceProviderChange}
                            isDisabled={!editable}
                        /> */}
                        <VirtualizedSelect
                            value={ServiceProviderOptions.filter(option => ServiceProvider.includes(option.value))}
                            styles={editable ? editableDrp : nonEditableDrp}
                            onChange={serviceProviderChange}
                            options={ServiceProviderOptions}
                            isMulti
                            placeholder="Select.."
                            maxHeight={300} // Define the max height for the dropdown
                            isDisabled={!editable}
                        />
                        {!editable && errorMessages.includes('Service Provider is required.') && (
                            <span className="text-red-600 ml-1">Service Provider is Required.</span>
                        )}
                    </div>
                    <div>
                        <label className="field-label">Customer Group</label>

                        {/* <Select
                            value={customerGroup}
                            styles={!editable || customer.length > 0 ? nonEditableDrp : editableDrp}
                            options={CustomerGroupOptions}
                            onChange={customerGroupChange}
                            isDisabled={!editable || customer.length > 0}
                            isClearable
                        /> */}

                        <VirtualizedSelect
                            value={customerGroup}
                            styles={!editable || customer.length > 0 ? nonEditableDrp : editableDrp}
                            onChange={customerGroupChange}
                            options={CustomerGroupOptions}
                            isMulti={false}
                            isDisabled={!editable || customer.length > 0}
                            placeholder="Select..."
                            isClearable
                            maxHeight={300} // Define the max height for the dropdown
                        />


                    </div>
                    <div>
                        <label className="field-label">Customers</label>
                        {/* <Select
                            isMulti
                            options={customerOptions}
                            styles={!editable || (customerGroup?.value !== null && customerGroup?.value !== "" && customerGroup !== null) ? nonEditableDrp : editableDrp}
                            value={customerValues.map(customerValue => {
                                const option = customerOptions.find(opt => opt.value === customerValue);
                                return option || { value: customerValue, label: customerValue };  // Return custom value if not found
                            })}
                            onChange={customerChange}
                            isDisabled={!editable || (customerGroup?.value !== null && customerGroup?.value !== "" && customerGroup !== null)}
                        /> */}
                        <VirtualizedSelect
                            value={customer.map(customerValue => {
                                const option = customerOptions.find(opt => opt.value === customerValue);
                                return option || { value: customerValue, label: customerValue };  // Return custom value if not found
                            })}
                            styles={!editable || (customerGroup?.value !== null && customerGroup?.value !== "" && customerGroup !== null) ? nonEditableDrp : editableDrp}
                            onChange={customerChange}
                            options={customerOptions}
                            // isMulti
                            placeholder="Select..."
                            maxHeight={300} // Define the max height for the dropdown
                            isDisabled={!editable || (customerGroup?.value !== null && customerGroup?.value !== "" && customerGroup !== null)}
                        />
                    </div>
                </div>
            </div>
            {editable && (
                <div className="flex justify-end space-x-4">
                    {/* <button className="cancel-btn">
                    <XMarkIcon className="h-5 w-5 text-black-500 mr-2" />
                    <span>Cancel</span>
                </button> */}
                    <button className="save-btn" onClick={handleSubmit}
                    >
                        {/* <CheckIcon className="h-5 w-5 text-black-500 mr-2" /> */}
                        <span>Submit</span>
                    </button>
                </div>)}
            {showModal && (
                <Modal
                    title="Confirmation"
                    open={showModal}
                    onOk={handleConfirmSave}
                    onCancel={handleCancelSave}
                    centered
                >
                    <p>Are you Sure you Want to Submit the Data</p>
                </Modal>
            )}
        </div>
    );
};

export default TenantInfo;
