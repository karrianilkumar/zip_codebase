"use client";
import React, { useEffect, useRef, useState } from "react";
import Pagination from "@/app/components/pagination";
import {
  Modal,
  Spin,
  Tooltip,
  Select,
  Input,
  InputNumber,
  Upload,
  notification,
  message,
} from "antd";
import {
  ArrowUpOutlined,
  ArrowDownOutlined,
  UploadOutlined,
  DownloadOutlined,
  LoadingOutlined,
  CloseOutlined,
} from "@ant-design/icons";
import axios from "axios";
import { useSearchStore } from "@/app/stores/searchStore";
import { useAuth } from "@/app/components/auth_context";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { ArrowUpTrayIcon, PlusIcon } from "@heroicons/react/24/outline";
import { usePrivateNetworkStore } from "@/app/stores/privateNetworksStore";
import { useUserStore } from "./createUserStore";
import EditableFeatureCode from "@/app/components/featureCodeEditPopup";

const headerMap: any = {
  tenant: ["Partner", "1"],
  role: ["Role", "2"],
};

const headers: string[] = ["tenant", "role"];

interface TenantRoleMappingTableProps {
  initialData: { [key: string]: any }[];
  itemsPerPage: number;
  popupHeading: string;
  pagination: any;
  height?: any;
  tenantOptions: any[];
  subPartnerOptions: any[];
  isEditable: boolean;
  row?: any;
  rolePartnersData: any;
  subPartnersData: any;
}

const TenantRoleMappingTable: React.FC<TenantRoleMappingTableProps> = ({
  initialData,
  itemsPerPage,
  popupHeading,
  pagination,
  height,
  tenantOptions,
  isEditable,
  rolePartnersData,
  subPartnersData,
  row,
  subPartnerOptions
}) => {
  const { Option } = Select;

  const [rowData, setRowData] = useState<{ [key: string]: any }[]>(initialData);
  const [currentPage, setCurrentPage] = useState(1);
  const isFirstRender = useRef(true);
  const [mainTenantOptions, setMainTenantOptions] = useState<any>([]);
  const [subTenantOptions, setSubTenantOptions] = useState<any>([]);
  const [filteredTenantOptions, setFilteredTenantOptions] = useState<any>([]);
  const [filteredRoleOptions, setFilteredRoleOptions] = useState<any>({});

  const [sortConfig, setSortConfig] = useState<{
    key: string;
    direction: "ascending" | "descending";
  } | null>(null);
  const {
    username,
    role,
    partner,
    tabledata,
    storedpagination,
    advancedStoredpagination,
    combineAdnvaceStoredpagination,
    token,
    selectedDb,
    metaData,
    sessionId,
    setAdvancedStoredPagination,
    setStoredPagination,
    setCombineAdnvaceStoredpagination,
    firstLastName,
  } = useAuth();
  const {
    tenant,
    role_name,
    sub_tenant,
    setTenant,
    setRoleName,
    setSubTenant,
    setUser_Name,
    setMobileNumber,
    setUserRoleData,
    setIsUserInfoSubmitted,
    setEmailsList,
    isUserInfoSubmitted,
  } = useUserStore();
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(false);
  const [modalloading, setModalLoading] = useState(false);

  //Viewport height
  const [viewportHeight, setViewportHeight] = useState(window.innerHeight);
  // Add state to track screen width
  const [isSmallScreen, setIsSmallScreen] = useState(false);

  const { setEditedTableData, editedTableData } = usePrivateNetworkStore();

  // Check for small screen on component mount and window resize
  useEffect(() => {
    const checkScreenSize = () => {
      setIsSmallScreen(window.innerWidth < 700);
    };

    // Initial check
    checkScreenSize();

    // Add event listener for window resize
    window.addEventListener("resize", checkScreenSize);

    // Clean up
    return () => window.removeEventListener("resize", checkScreenSize);
  }, []);

  useEffect(() => {
    // setAdvancedStoredPagination(null)
    setStoredPagination(null);
    setCombineAdnvaceStoredpagination(null);
    const handleResize = () => {
      setViewportHeight(window.innerHeight);
    };

    // Add event listener for window resize
    window.addEventListener("resize", handleResize);

    // Cleanup event listener on component unmount
    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  useEffect(() => {
    if (row) {
      console.log("row", row);

      const rawData = row?.tenant_role_mapping || "[]";

      // 🛠 Fix invalid JSON by replacing single quotes with double quotes
      const safeJSON = rawData.replace(/'/g, '"');

      let parsedData = [];
      try {
        parsedData = JSON.parse(safeJSON);
      } catch (error) {
        console.error("Error parsing tenant_role_mapping:", error);
      }

      const updatedData = parsedData.length > 0 && parsedData.length === [...tenant, ...sub_tenant].length ? parsedData : rowData;
      setRowData([...updatedData]);
    }
  }, [row,tenant,sub_tenant]);


  useEffect(() => {
    setEditedTableData([...rowData]);
  }, [rowData]);

  useEffect(() => {
    const tenant_options = tenantOptions.map(
      (tenant: any) => tenant?.value || ""
    );

    const sub_tenant_options = subPartnerOptions.map(
      (tenant: any) => tenant?.value || ""
    );

    setMainTenantOptions(tenant_options || [])
    setSubTenantOptions(sub_tenant_options || [])

    setFilteredTenantOptions([...tenant_options, ...sub_tenant_options]);
    const roleHierarchy = [
      "Super Admin",
      "Partner Admin",
      "Agent Partner Admin",
      "Agent",
      "User",
      "Qualification Only User",
      "Notification Only User"
    ];
    const currentRoleIndex = roleHierarchy.findIndex(
      roleName => roleName.toLowerCase() === role?.toLowerCase() || ""
    );

    const allowedRoles = roleHierarchy.slice(currentRoleIndex);

    const result: any = {};
    tenant_options.forEach(tenant => {
      const partnerRoles = rolePartnersData[tenant] || [];
      const eligibleRoles = partnerRoles.filter((role: any) =>
        allowedRoles.includes(role)
      );
      result[tenant] = eligibleRoles.map((role: any) => (role
      ));
    });

    sub_tenant_options.forEach(sub_tenant => {
      const main_tenant = Object.keys(subPartnersData).find(main =>
        (subPartnersData[main] || []).includes(sub_tenant)
      ) || sub_tenant;
      const partnerRoles = rolePartnersData[main_tenant] || [];
      const eligibleRoles = partnerRoles.filter((role: any) =>
        allowedRoles.includes(role)
      );
      result[sub_tenant] = eligibleRoles.map((role: any) => (role
      ));
    });


    setFilteredRoleOptions(result);

  }, [tenantOptions, subPartnerOptions, rolePartnersData, subPartnersData]);

  useEffect(() => {
    // if row exists or rowData is already set, do nothing
    if (row || rowData.length > 0) return;

    // if there are no tenants/sub_tenants, do nothing
    if (!(tenant.length > 1 || sub_tenant.length > 0)) return;

    let updatedData: any[] = [];

    if (editedTableData && editedTableData.length > 0) {
      updatedData = [...editedTableData];
    } else {
      updatedData = [
        ...tenant.map((val: any) => ({ tenant: val, role: "" })),
        ...sub_tenant.map((val: any) => ({ tenant: val, role: "" })),
      ];
    }

    // only update if we actually have something to set
    if (updatedData.length > 0) {
      setRowData(updatedData);
    }
  }, [row, rowData.length, tenant, sub_tenant, editedTableData]);


  useEffect(() => {
    if (rowData.length !== editedTableData.length && rowData.length !== 0 && editedTableData.length !== 0) {
      setRowData([...editedTableData]);
    }
  }, []);

  useEffect(() => {
    return () => {
      // cleanup before unmount
      setRowData([]);
    };
  }, []);
  useEffect(() => {
    if (!tenant && !sub_tenant) return;

    if (!isUserInfoSubmitted) {
      setRowData((prevRows) => {
        const allTenants = [...(tenant || []), ...(sub_tenant || [])];   // combine both
        const existingTenants = prevRows.map((row: any) => row?.tenant);
        // 1️⃣ Add rows for tenants (from both tenant + sub_tenant) missing in rowData
        const rowsToAdd = allTenants
          .filter((t) => t && !existingTenants.includes(t))
          .map((t) => ({ tenant: t, role: "" }));
        // 2️⃣ Remove rows where tenant is no longer in the combined tenant/sub_tenant list
        const updatedRows = prevRows.filter((row: any) =>
          allTenants.includes(row?.tenant)
        );

        // 3️⃣ Combine valid existing rows + newly added rows

        if((JSON.stringify(allTenants) !== JSON.stringify(existingTenants)) || row){
          if(allTenants.length === 2 && existingTenants.length ===2 && !row){
            const newUpdatedRows = updatedRows.map((row:any)=>({...row , role:""}))
            return [...newUpdatedRows, ...rowsToAdd];
          }
        return [...updatedRows, ...rowsToAdd];
        }
        else{
          return [ ...rowsToAdd]
        }
      });
    }
  }, [tenant, sub_tenant]);





  useEffect(() => {
    setCurrentPage(1);
  }, [totalPages]);

  useEffect(() => {
    let pagination_;
    // let pagination_;
    if (combineAdnvaceStoredpagination) {
      pagination_ = combineAdnvaceStoredpagination;
    } else if (advancedStoredpagination && !storedpagination) {
      pagination_ = advancedStoredpagination;
    } else if (storedpagination && !advancedStoredpagination) {
      pagination_ = storedpagination;
    } else {
      pagination_ = pagination;
    }

    const start = pagination_?.start || 1;
    const total = pagination_?.total || 1;
    const end = pagination_?.end || 1;
    const totalPages_ = Math.ceil(total / itemsPerPage);
    setTotalPages(totalPages_);
  }, [
    initialData,
    pagination,
    itemsPerPage,
    currentPage,
    storedpagination,
    advancedStoredpagination,
    combineAdnvaceStoredpagination,
    sortConfig,
  ]);

  const updatePaginator = async () => {
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    try {
      const updatedData = rowData.slice(startIndex, endIndex);
      setRowData(updatedData);
      console.log("updatedData paginator", updatedData);
    } catch (err) {
      console.error("Error fetching data:", err);
    } finally {
    }
    // }
  };

  //For sorting the table
  const handleSort = (key: string) => {
    let direction: "ascending" | "descending" = "ascending";
    if (
      sortConfig &&
      sortConfig.key === key &&
      sortConfig.direction === "ascending"
    ) {
      direction = "descending";
    }

    const sortedData = [...rowData].sort((a, b) => {
      let aValue = a[key];
      let bValue = b[key];

      // Special handling for the "Assigned rate plans" or "Assigned rate plan count" columns
      if (key === "carrier_rate_plans") {
        aValue = Array.isArray(aValue)
          ? aValue.length
          : JSON.parse(aValue)?.length || 0;
        bValue = Array.isArray(bValue)
          ? bValue.length
          : JSON.parse(bValue)?.length || 0;
      }

      // Convert 'None' to null for easier comparison
      const normalizeValue = (value: any) => {
        if (value === "None") return null;
        return value;
      };

      aValue = normalizeValue(aValue);
      bValue = normalizeValue(bValue);

      // Function to split a string into alphabetical and numeric segments
      const splitIntoSegments = (str: string) => {
        return str.toLowerCase().match(/([a-z]+|\d+)/g) || [];
      };

      // Split values into segments
      const aSegments =
        typeof aValue === "string" ? splitIntoSegments(aValue) : [aValue];
      const bSegments =
        typeof bValue === "string" ? splitIntoSegments(bValue) : [bValue];

      // Compare each segment one by one
      for (let i = 0; i < Math.max(aSegments.length, bSegments.length); i++) {
        const aSegment = aSegments[i];
        const bSegment = bSegments[i];

        // If one segment is undefined, consider it smaller
        if (aSegment === undefined) return direction === "ascending" ? -1 : 1;
        if (bSegment === undefined) return direction === "ascending" ? 1 : -1;

        // Compare numeric segments numerically, and character segments lexicographically
        const isANumber = !isNaN(Number(aSegment));
        const isBNumber = !isNaN(Number(bSegment));

        if (isANumber && isBNumber) {
          // Both segments are numbers; compare them numerically
          const numA = Number(aSegment);
          const numB = Number(bSegment);
          if (numA < numB) return direction === "ascending" ? -1 : 1;
          if (numA > numB) return direction === "ascending" ? 1 : -1;
        } else {
          // At least one segment is not a number; compare them as strings
          if (aSegment < bSegment) return direction === "ascending" ? -1 : 1;
          if (aSegment > bSegment) return direction === "ascending" ? 1 : -1;
        }
      }

      return 0;
    });

    setSortConfig({ key, direction });
    setRowData(sortedData);
  };

  const handleDeleteRow = (rowIndex: number) => {
    setRowData((prevRows) => {
      // Remove the row
      const updatedRows = prevRows.filter((_, index) => index !== rowIndex);

      // Extract remaining tenants and remove duplicates
      const remainingMainTenants = [
        ...new Set(
          updatedRows
            .map((row: any) => row?.tenant)
            .filter((tenant) => tenant !== undefined && tenant !== null && tenant !== "" && mainTenantOptions.includes(tenant))
        ),
      ];

      const remainingSubTenants = [
        ...new Set(
          updatedRows
            .map((row: any) => row?.tenant)
            .filter((tenant) => tenant !== undefined && tenant !== null && tenant !== "" && subTenantOptions.includes(tenant))
        ),
      ];

      // Update tenant state
      setTenant(remainingMainTenants || []);
      setSubTenant(remainingSubTenants || []);


      return updatedRows;
    });
  };


  // Add new row
  const handleAddRow = () => {
    // Validate every row
    const hasIncompleteRow = rowData.some((row) =>
      headers.some((header) => {
        const value = row[header];
        return value === "" || value === null || value === undefined;
      })
    );

    if (hasIncompleteRow) {
      Modal.info({
        title: "Incomplete Rows",
        content: "Please fill all fields in every row before adding a new row.",
        centered: true,
      });
      return;
    }

    // Create new empty row
    const newRow: any = {};

    headers.forEach((header) => {
      newRow[header] = "";
    });

    setRowData((prev) => [...prev, newRow]);
  };

  // for dropdown change
  const handleDropdownChange = (
    value: string,
    rowIndex: number,
    header: any
  ) => {
    if (header === "tenant") {
      // Get all existing tenant values except the current row
      const existingTenants = rowData
        .map((row: any, index: number) => (index !== rowIndex ? row?.tenant : null))
        .filter((tenant) => tenant !== null);

      // Check if the selected tenant already exists
      if (existingTenants.includes(value)) {
        Modal.warning({
          title: "Duplicate Tenant",
          content: "Cannot add a row with the same Partner!",
        });
        return; // ⛔ Stop execution — do not update row
      }

      // Else update tenant state (add both old and new if needed)
      const allTenants = [...new Set([...existingTenants, value])];

      const selected_main_tenants = mainTenantOptions.filter((tenant: any) => (allTenants.includes(tenant)))
      setTenant(selected_main_tenants || []);


      const selected_sub_tenants = subTenantOptions.filter((tenant: any) => (allTenants.includes(tenant)))
      setSubTenant(selected_sub_tenants || [])
    }

    // Proceed with updating row data
    setRowData((prevData) => {
      const newData = [...prevData];
      newData[rowIndex] = {
        ...newData[rowIndex],
        [header]: value,
      };
      return newData;
    });
  };


  //For custom cell 
  const renderCell = (cellData: any, column: string, rowIndex: number) => {
    const currentRow = rowData[rowIndex] || {};

    // Tenant dropdown
    if (headerMap?.[column]?.[0] === "Partner" && isEditable) {
      return (
        <Select
          value={cellData}
          placeholder="Select Partner"
          style={{ width: "100%", font: "16px" }}
          className="table-drp"
          onChange={(value) => handleDropdownChange(value, rowIndex, column)}
          showSearch
          allowClear
        >
          {filteredTenantOptions.map((tenant: string) => (
            <Option key={tenant} value={tenant}>
              {tenant}
            </Option>
          ))}
        </Select>
      );
    }

    // Role Dropdown
    if (headerMap?.[column]?.[0] === "Role" && isEditable) {
      const isSubTenant = subTenantOptions.includes(currentRow?.tenant);

      return (
        <Select
          value={cellData}
          placeholder="Select Role"
          style={{ width: "100%", font: "16px" }}
          className="table-drp"
          onChange={(value) => handleDropdownChange(value, rowIndex, column)}
          showSearch
          allowClear
        >
          {/* ✅ Show "None" only for MAIN tenants */}
          {!isSubTenant &&
            (filteredRoleOptions[currentRow?.tenant || ""] || []).length > 0 && (
              <Option value="none" key="none">
                None
              </Option>
            )}

          {(filteredRoleOptions[currentRow?.tenant || ""] || []).map(
            (role: string) => (
              <Option key={role} value={role}>
                {role}
              </Option>
            )
          )}
        </Select>
      );
    }


    // Default: Tooltip with value
    return (
      <Tooltip
        title={`${cellData}`}
        placement="topLeft"
        overlayStyle={{
          whiteSpace: "normal",
          maxWidth: "60vw",
          wordWrap: "break-word",
          zIndex: 50,
        }}
        getPopupContainer={() => document.body}
      >
        <span>{cellData}</span>
      </Tooltip>
    );
  };

  if (loading) {
    return (
      <div className="flex justify-center items-start h-auto pt-10">
        <Spin size="large" />
      </div>
    );
  }

  // Pagination component to be used in both places
  const paginationComponent = (
    <Pagination
      currentPage={currentPage}
      totalPages={totalPages}
      onPageChange={setCurrentPage}
      moduleName={popupHeading}
    />
  );

  return (
    <div>
      {/* Show pagination at top right for small screens */}
      {isSmallScreen && headers.length > 0 && (
        <div className="flex justify-end mb-2 mr-2">{paginationComponent}</div>
      )}

      {/* Add button */}
      {isEditable && (
        <div className="mb-2 flex justify-end gap-2">
          <button
            onClick={handleAddRow}
            // className={`${((serviceProviderOptions.length === 0) || (rowData.length === serviceProviderOptions.length)) ? "cancel-btn cursor-not-allowed" : "save-btn"}`}
            className="save-btn"
          // disabled={(serviceProviderOptions.length === 0) || (rowData.length === serviceProviderOptions.length)}
          >
            <PlusIcon className="h-5 w-5 text-black-500 mr-1" />
            Add
          </button>
        </div>
      )

      }

      {/* Table */}
      <div className="overflow-x-auto">
        <div
          className="overflow-y-auto p-2"
          style={{
            height: `${viewportHeight - height}px`,
          }}
        >
          <table className="table-auto w-full">
            <thead className="sticky top-0 bg-gray-200 z-10 table-header-row">
              <tr>
                {headers.map(
                  (header) =>
                    headerMap &&
                    headerMap[header] &&
                    headers.includes(header) && (
                      <th
                        key={header}
                        className={`px-6 py-3 border-b border-gray-300 !text-center font-semibold table-header sticky top-0 !min-w-[200px] ${sortConfig && sortConfig.key === header
                          ? "text-blue-600  active-table-header"
                          : ""
                          }`}
                        onClick={() => {
                          handleSort(header);
                        }}
                      >
                        {headerMap?.[header]?.[0] || header}

                        {sortConfig && sortConfig.key === header ? (
                          sortConfig.direction === "ascending" ? (
                            <ArrowUpOutlined
                              className="sorting-arrow"
                              style={{ marginLeft: 8, color: "#2563EB" }}
                            />
                          ) : (
                            <ArrowDownOutlined
                              className="sorting-arrow"
                              style={{ marginLeft: 8, color: "#2563EB" }}
                            />
                          )
                        ) : (
                          <ArrowUpOutlined
                            style={{ marginLeft: 8, opacity: 0.5 }}
                          />
                        )}
                      </th>
                    )
                )}
                {isEditable && (
                  <th
                    key={"delete"}
                    className={`px-6 py-3 border-b border-gray-300 !text-center font-semibold table-header sticky top-0`}
                  ></th>
                )}

              </tr>
            </thead>
            <tbody>
              {headers.length > 0 ? (
                rowData.length > 0 ? (
                  rowData.map((row, index) => (
                    <tr
                      key={index}
                      className={
                        index % 2 === 0 ? "bg-gray-50 even-table-row" : ""
                      }
                    >
                      {headers.map(
                        (header, columnIndex) =>
                          headers.includes(header) &&
                          headerMap[header] && (
                            <td
                              key={columnIndex}
                              className={`border-b border-gray-300 table-cell !min-w-[200px] ${header !== "ip_text"
                                ? "!max-w-[290px]"
                                : "!max-w-none"
                                }`}
                            >
                              {(header &&
                                headerMap?.[header]?.[0] &&
                                renderCell(row[header], header, index)) ||
                                ""}
                            </td>
                          )
                      )}
                      {row && isEditable && (
                        <td
                          key={index}
                          className="!text-center border-b border-gray-300 table-cell"
                        >
                          <button onClick={() => handleDeleteRow(index)}>
                            <span className="text-red-500">
                              <CloseOutlined />
                            </span>
                          </button>
                        </td>
                      )}
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td
                      colSpan={
                        headers.filter((header) => headers.includes(header))
                          .length + 1
                      }
                      className="px-6 py-3 border-b border-gray-300 text-center text-gray-500"
                    >
                      No Records Found
                    </td>
                  </tr>
                )
              ) : null}
            </tbody>
          </table>
        </div>
      </div>
      {/* Show pagination at bottom for larger screens */}
      {!isSmallScreen && headers.length > 0 && (
        <div className="flex justify-center mt-5">{paginationComponent}</div>
      )}
    </div>
  );
};

export default TenantRoleMappingTable;
