"use client";
import React, { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
  PencilIcon,
  TrashIcon,
  InformationCircleIcon,
  UserIcon,
  CheckCircleIcon,
  XCircleIcon,
} from "@heroicons/react/24/outline";
import dayjs, { Dayjs } from "dayjs";
import { CopyOutlined } from "@ant-design/icons";
import EditModal from "../../../components/editPopup";
import Pagination from "@/app/components/pagination";
import EditUsernameCellRenderer from "../../../components/TableComponent/data-grid-cell-renderers/edit-username-cell-renderer";

import { StatusCellRenderer } from "../../../components/TableComponent/data-grid-cell-renderers/status-cell-renderer";
import { Modal, Checkbox, notification, Spin, Tooltip, Button, Radio } from "antd";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import ActionItems from "@/app/components/Table-feautures/action-items";
import {
  ArrowUpOutlined,
  ArrowDownOutlined,
  ExclamationCircleOutlined,
} from "@ant-design/icons";


import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { usePartnerStore } from "@/app/partner/partner_info/partnerStore";
import EditCustomerModal from "@/app/sim_management/carrier_rate_plans_socs/optimization_groups/edit_optimization_type_group";
import EditEmailAuditTemplateModal from "@/app/partner/notifications/email_audit_info_popup";
import CreateEmailAuditTemplateModal from "@/app/partner/notifications/create_email_aduit_temp";
// import { useStateManager } from "react-select";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import InfoRevIoPopup from "@/app/people/billing_customers/info_rev_io_customer";
import EditAutomation from "@/app/automation/edit_automation";
import AutomationInfo from "@/app/automation/automation_log_info/page";
import ImpersonateUserModal from "@/app/partner/partner_info/users/impersonateUserModal";
import { useSearchStore } from "@/app/stores/searchStore";
// import { useDateRangeStore } from "@/app/stores/dateStoreDailyUsageReport";
import { useDateRangeStore } from "@/app/billing/killbill_stores/dateStoreReports";

import { usePartnerAPIStore } from "@/app/stores/partnerAPIStore";
import EditCustomerRatePlan from "@/app/sim_management/customer_rate_plans/editCustomerRatePlan";
import InfoCustomerRatePlan from "@/app/sim_management/customer_rate_plans/infoCustomerRatePlan";
import CopyCustomerRatePlan from "@/app/sim_management/customer_rate_plans/copyCustomerRatePlan";
import { useCustomerRatePlanStore } from "@/app/stores/customerRateplanStore";
import EditServiceProvider from "@/app/partner/partner_info/partner_info/editServiceProviderPopup";
import EditNotificationsModal from "@/app/partner/notifications/edit_notification";
import useCrossProviderStore from "@/app/stores/useCrossProviderStore";
import EditBanner from "@/app/super_admin/deployment_notifier/editTenantBanner";
import Select from "react-select"; 
import {
  DropdownStyles,
  NonEditableDropdownStyles,
} from "@/app/components/css/dropdown";
import RowDetailsModal from "@/app/components/rowDetailsModal";
import NewPagination from "@/app/components/newPagination";
import { useCustomerProfileStore } from "../../../../app/billing/killbill_stores/customer_profile_store";
import { useLogoStore } from "@/app/stores/logoStore";
const editableDrp = DropdownStyles;

interface TableComponentProps {
  headers: string[];
  initialData: { [key: string]: any }[];
  searchQuery: string;
  visibleColumns: string[];
  itemsPerPage: number;
  allowedActions?: (
    | "edit"
    | "delete"
    | "info"
    | "Actions"
    | "SingleClick"
    | "tabsEdit"
    | "tabsInfo"
    | "form"
    | "commPlan"
    | "formEditFeatureModal"
    | "editCustomerModal"
    | "infoCustomerModal"
    | "emailAuditing"
    | "copy"
    | "editEmail"
    | "editRev.ioCustomer"
    | "editCustomerRatePlan"
    | "copyCustomerRatePlan"
    | "infoCustomerRatePlan"
    | "infoRev.ioCustomer"
    | "copyFeature"
    | "automationEdit"
    | "automationInfo"
    | "impersonateUser"
    | "editServiceProvider"
    | "editBanner"
    | "copyBanner"
    | "editNotification"
  )[];
  popupHeading: string;
  advancedFilters?: any;
  createModalData?: any[];
  generalFields?: any;
  isSelectRowVisible?: boolean;
  headerMap?: any;
  pagination: any;
  height?: any;
  onsave?: any;
  onRowDataChange?: (updatedData: any[]) => void;
  selectedSubPartner?: any;
  selectedPartnerBP?: any;
  tableData?: any[];
}

export default function BillingTableComponent({
  headers,
  initialData,
  searchQuery,
  visibleColumns,
  itemsPerPage,
  allowedActions,
  popupHeading,
  createModalData,
  generalFields,
  advancedFilters,
  isSelectRowVisible = true,
  headerMap,
  pagination,
  height, onsave, onRowDataChange,
  selectedSubPartner,
  selectedPartnerBP, tableData
}: TableComponentProps) {
  const router = useRouter();
  const {startDateDailyReport,endDateDailyReport,setCustomRange} = useDateRangeStore();
  const { customerShowActive, setCustomerShowActive, emailConditionModal } = useCustomerRatePlanStore();
  const { setIsCustomerProfilesNav } = useCustomerProfileStore();

  const [rowData, setRowData] = useState<{ [key: string]: any }[]>(initialData);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [editRowIndex, setEditRowIndex] = useState<number | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const isFirstRender = useRef(true);
  const isFirstTableDataRender = useRef(true);
  const isFirstSearchRender = useRef(true);
  const isFirstAdvancedSearchRender = useRef(true);
  const [selectAll, setSelectAll] = useState(false);
  const [selectedRows, setSelectedRows] = useState<number[]>([]);
  const [sortConfig, setSortConfig] = useState<{ key: string; direction: "ascending" | "descending"; } | null>(null);
  const {
    username,
    role,
    partner,
    selectedPartnerModule,
    Environment,
    tabledata,
    settabledata,
    storedpagination,
    advancedStoredpagination,
    combineAdnvaceStoredpagination,
    token,
    selectedDb,
    metaData,
    selectedBillingDb,
    setAdvancedStoredPagination,
    setStoredPagination,
    setCombineAdnvaceStoredpagination,
    firstLastName,
    sessionId,
  } = useAuth();
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(false);
  const {isSearchComponentCall, setIsSearchComponentCall, optimizationErrorsData, } = useSearchStore();
  const accountNumber = useCustomerProfileStore((state) => state.accountNumber);
  const setAccountNumber = useCustomerProfileStore((state) => state.setAccountNumber);
  const title = useLogoStore((state) => state.title);
  const setTitle = useLogoStore((state) => state.setTitle);
  const [viewportHeight, setViewportHeight] = useState(window.innerHeight);
  // Add state to track screen width
  const [isSmallScreen, setIsSmallScreen] = useState(false);
  const [showRowModal, setShowRowModal] = useState<boolean>(false);
  const [showRowModalData, setShowRowModalData] = useState<any>(null);
  const billingStatusOptions = [
    { label: "Active", value: "Active" },
    { label: "Suspended", value: "Suspended" },
    { label: "Pending", value: "Pending" },
    { label: "Deactivated", value: "Deactivated" },
  ];
  useEffect(() => {
    if (popupHeading === "Carrier Status Mapping" || popupHeading === "Chargebacks & Returns") {
      const newRowData = optimizationErrorsData.length > 0 ? optimizationErrorsData : initialData;
      if (newRowData.length > itemsPerPage) {
        const slicedData = newRowData.slice(0, itemsPerPage);
        setRowData(slicedData);
      }
      else {
        setRowData(newRowData);
      }
    }
    else {
      const newRowData = tabledata.length > 0 ? tabledata : initialData;
      setRowData(newRowData);
    }

  }, [initialData, tabledata, optimizationErrorsData]);
  // Check for small screen on component mount and window resize
  useEffect(() => {
    const checkScreenSize = () => {
      setIsSmallScreen(window.innerWidth < 700);
    };

    // Initial check
    checkScreenSize();

    // Add event listener for window resize
    window.addEventListener('resize', checkScreenSize);

    // Clean up
    return () => window.removeEventListener('resize', checkScreenSize);
  }, []);

  // console.log("rowda",rowData,initialData,tabledata)
  useEffect(() => {
    setAdvancedStoredPagination(null)
    setStoredPagination(null)
    setCombineAdnvaceStoredpagination(null)
    // setIsSearchComponentCall(false)
    const handleResize = () => {
      setViewportHeight(window.innerHeight);
    };

    // Add event listener for window resize
    window.addEventListener("resize", handleResize);

    // Cleanup event listener on component unmount
    return () => {
      window.removeEventListener("resize", handleResize);
    };

  }, []);


  useEffect(() => {
    if (!router) {
      console.error("NextRouter is not available.");
    }
  }, [router]);


  useEffect(() => {
    console.log("tabledata,sortConfig useeffect", isSearchComponentCall)
    setCurrentPage(1);
    // setIsSearchComponentCall(false)
    updatePaginator()
  }, [tabledata, sortConfig]);
  
const formatDateMMDDYY = (date: any) => {
  if (!date) return null;   // explicitly return null, don't create Date()
  const d = new Date(date);
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  const year = String(d.getFullYear());
  return `${month}/${day}/${year}`;
};

  const updatePaginator = async () => {
    setLoading(true)
    console.log(customerShowActive, "customerShowActive")
    let start_ = Math.floor((currentPage - 1) * itemsPerPage);
    let end_ = Math.floor((currentPage - 1) * itemsPerPage + 100);
    let end2 = Math.floor((currentPage - 1) * itemsPerPage + 6);
    try {
      const colSortKey = sortConfig ? sortConfig.key : ""
      const colSortDirection = sortConfig ? sortConfig.direction : ""
      const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";

      if (popupHeading === "Carrier Status Mapping") {
        console.log("Popup heading")
        const url = ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/bp_settings_list_view",
          role_name: role,
          parent_module: "Partner Info",
          module_name: "Carrier Mapping Data",
          sub_partner: selectedSubPartner || "",
          Selected_Partner: selectedPartnerBP,
          mod_pages: {
            start: 0,
            end: itemsPerPage,
          },
          flag: 'withparameters',
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
          billing_db_name:selectedBillingDb,
          sessionID: sessionId,
          col_sort: {
            "service_provider_name": "asc",
          },
          ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
            : {}),
        };
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
          setLoading(false)
        } else {
          const tableData_ = parsedData?.data?.billing_platform_status || []
          const slicedData = tableData_.slice(0, itemsPerPage);
          setRowData(slicedData);
          pagination = parsedData?.pages || pagination
          setLoading(false)
        }
      }
      if (popupHeading === "Chargebacks & Returns") {
        console.log("Popup heading")
        const url = ENV_ROUTES.BP_PAYMENT_INTEGRATION;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/charge_back_exceptions_list_view",
          role_name: role,
          parent_module: "Billing Platform",
          module_name: "Chargeback Exceptions",
          mod_pages: {
            start: 0,
            end: itemsPerPage,
          },
           start_date: formatDateMMDDYY(startDateDailyReport),
           end_date: formatDateMMDDYY(endDateDailyReport),
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
          billing_db_name:selectedBillingDb,
          sessionID: sessionId,
          // col_sort: {
          //   "service_provider_name": "asc",
          // },
          ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
            : {}),
        };
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
          setLoading(false)
        } else {
          const tableData_ = parsedData?.data?.exceptions || []
          const slicedData = tableData_.slice(0, itemsPerPage);
          setRowData(slicedData);
          pagination = parsedData?.pages || pagination
          setLoading(false)
        }
      }
    } catch (err) {
      console.error("Error fetching data:", err);
      setLoading(false)

    } finally {
      setLoading(false);
    }
    // }
  };

  const handleSelectAllChange = (e: {
    target: { checked: boolean | ((prevState: boolean) => boolean) };
  }) => {
    setSelectAll(e.target.checked);
    if (e.target.checked) {
      const allRowIndices = paginatedData.map((_, index) => index);
      setSelectedRows(allRowIndices);
    } else {
      setSelectedRows([]);
    }
  };

  // Function to call Notification_sync API
  const callNotificationSync = async (ruleDefId: string, actionType: string) => {
    const syncUrl = ENV_ROUTES.NOTIFICATION_SERVICES;

    const syncData = {
      tenant_name: partner || "default_value",
      username: username,
      path: "/Notification_sync",
      action: actionType,
      rule_def_id: ruleDefId,
      parent_module: "Partner",
      module_name: "Usage Notification",
      feature_module_name: "Usage Notification",
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
          ...metaData,
          billing_db_name: selectedBillingDb,
      sessionID: sessionId,
    };

    try {
      await axios.post(syncUrl, { data: syncData });
    } catch (error) {
      console.error("Error in Notification Sync:", error);
    }
  };

  const callCustomersLambdaSync = async () => {
    const url = ENV_ROUTES.OPTIMIZATION_SYNC_LAMBDA;
    const data = {
      path: "/lambda_sync_jobs_",
      key_name: "customers_sub_tenant_insert",
      tenant_name: partner
    };

    try {
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
    } catch (error) {
    }

  }

  const handleCellChange = (rowIndex: number, header: string, value: any) => {
    setRowData((prevData: any[]) => {
      const updatedRows = [...prevData];
      updatedRows[rowIndex] = {
        ...updatedRows[rowIndex],
        [header]: value,
        // isEdited: true, // ✅ this flag is important
      };
      if (onRowDataChange) {
        onRowDataChange(updatedRows);
      }
      return updatedRows;
    });
  };
  const handleSort = (key: string) => {
    let direction: "ascending" | "descending" = "ascending";
    if (
      sortConfig &&
      sortConfig.key === key &&
      sortConfig.direction === "ascending"
    ) {
      direction = "descending";
    }

    // const sortedData = [...rowData].sort((a, b) => {
    //     let aValue = a[key];
    //     let bValue = b[key];

    //     // Special handling for the "Assigned rate plans" or "Assigned rate plan count" columns
    //     if (key === "carrier_rate_plans") {
    //         aValue = Array.isArray(aValue) ? aValue.length : JSON.parse(aValue)?.length || 0;
    //         bValue = Array.isArray(bValue) ? bValue.length : JSON.parse(bValue)?.length || 0;
    //     }

    //     // Convert 'None' to null for easier comparison
    //     const normalizeValue = (value: any) => {
    //         if (value === 'None') return null;
    //         return value;
    //     };

    //     aValue = normalizeValue(aValue);
    //     bValue = normalizeValue(bValue);

    //     // Function to split a string into alphabetical and numeric segments
    //     const splitIntoSegments = (str: string) => {
    //         return str.toLowerCase().match(/([a-z]+|\d+)/g) || [];
    //     };

    //     // Split values into segments
    //     const aSegments = typeof aValue === "string" ? splitIntoSegments(aValue) : [aValue];
    //     const bSegments = typeof bValue === "string" ? splitIntoSegments(bValue) : [bValue];

    //     // Compare each segment one by one
    //     for (let i = 0; i < Math.max(aSegments.length, bSegments.length); i++) {
    //         const aSegment = aSegments[i];
    //         const bSegment = bSegments[i];

    //         // If one segment is undefined, consider it smaller
    //         if (aSegment === undefined) return direction === "ascending" ? -1 : 1;
    //         if (bSegment === undefined) return direction === "ascending" ? 1 : -1;

    //         // Compare numeric segments numerically, and character segments lexicographically
    //         const isANumber = !isNaN(Number(aSegment));
    //         const isBNumber = !isNaN(Number(bSegment));

    //         if (isANumber && isBNumber) {
    //             // Both segments are numbers; compare them numerically
    //             const numA = Number(aSegment);
    //             const numB = Number(bSegment);
    //             if (numA < numB) return direction === "ascending" ? -1 : 1;
    //             if (numA > numB) return direction === "ascending" ? 1 : -1;
    //         } else {
    //             // At least one segment is not a number; compare them as strings
    //             if (aSegment < bSegment) return direction === "ascending" ? -1 : 1;
    //             if (aSegment > bSegment) return direction === "ascending" ? 1 : -1;
    //         }
    //     }

    //     return 0;
    // });
    setSortConfig({ key, direction });
    // setRowData(sortedData);
  };

  const formatColumnName = (name: string) => {
    return name
      .replace(/_/g, " ") // Replace underscores with spaces
      .split(" ") // Split the string into words
      .map(
        (
          word // Capitalize each word
        ) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
      )
      .join(" "); // Join the words back into a single string
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }
  // Pagination component to be used in both places
  const paginationComponent = (
    <NewPagination
      moduleName={popupHeading}
      initialData={tableData}
      itemsPerPage={itemsPerPage}

    />
  );

  let paginatedData = rowData?.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "bold",
    padding: "16px",
  };

  const freezeColumn = (header: string) => {
    if (
      (popupHeading === "Customer Rate Plan" && header === "rate_plan_name") ||
      (popupHeading === "Automation rule" && header === "automation_rule_name") ||
      (popupHeading === "Automation rule log" && header === "automation_rule_name") ||
      (popupHeading === "Zero usage report" && header === "iccid") ||
      (popupHeading === "Newly actvated report" && header === "iccid") ||
      (popupHeading === "Usage by line report" && header === "iccid") ||
      (popupHeading === "Pool group summary report" && header === "pool_id") ||
      (popupHeading === "Customer rate pool usage report" && header === "iccid") ||
      (popupHeading === "Status history report" && header === "iccid") ||
      (popupHeading === "Daily usage report" && header === "iccid") ||
      (popupHeading === "Automation rule verification report" && header === "rule_name") ||
      (popupHeading === "User" && header === "username")
    ) {
      return true
    }
    else {
      return false
    }
  }

  const report = ["Zero usage report", "Usage by line report", "Status history report", "Pool group summary report", "Newly actvated report", "Customer rate pool usage report", "Automation rule verification report", "Daily usage report"]
  const filteredHeaders = headers.filter(header => {
    if (header === "S.no" && report.includes(popupHeading)) {
      return false;
    }
    return true;
  });
  const handleRowClick = (row: any, header: string) => {

    if (headerMap[header][0] === "Customer ID" && popupHeading === 'Chargebacks & Returns') {
      const accountNumber = row.account_number;
      const accountName = row.customer_name;
      sessionStorage.setItem("accountNumber", accountNumber);
      setAccountNumber(accountNumber);
      router.push("/billing/customer_profiles");
      setIsCustomerProfilesNav(false)
      
      // setSelectedRow(row.id); // Set the clicked row
      // setShowNewPage(true)
      // setAdvancedPage?.(true)
      // setReverseRowData(row)
      // console.log("row", row)

      sessionStorage.setItem("is_redirected", "true");
      // // setPrevTitle(title);

      // Set new title
      // const newTitle = accountName
      //   ? `${"Customer Profiles"} - ${accountName} (${accountNumber})`
      //   : `${"Customer Profiles"} - ${accountNumber}`;

      // console.log("title", newTitle);
      // setTitle(newTitle);
      // localStorage.setItem("title", newTitle);
    }
    
  };
  return (
    <div>
      {/* Show pagination at top right for small screens */}
      {isSmallScreen && visibleColumns.length > 0 && (
        <div className="flex justify-end mb-2 mr-2">
          {paginationComponent}
        </div>
      )}
      <div className="overflow-x-auto overflow-y-auto"
       style={{
          height: (popupHeading === "Billing" || popupHeading === "Chargebacks & Returns")
            ? `${viewportHeight - height}px`  // Let height be auto
            : 'auto',
        }}>
        <table className="table-auto w-full">
          <thead className="sticky top-0 bg-gray-200 z-10 table-header-row">
            <tr>
              {(typeof window !== "undefined" && window.innerWidth < 700) && (
                <th
                  className={`px-6 py-3 border-b border-gray-300 text-left font-semibold table-header sticky top-0`}
                  style={{
                    cursor: "pointer", position: "sticky", left: 0, zIndex: 11, backgroundColor: "#E5E7EB", minWidth: "40px"
                  }}>

                </th>
              )}
              {headers.map(
                (header, index) =>
                  visibleColumns.includes(header) ? (
                    <th
                      key={index}
                      className={`px-6 py-3 border-b border-gray-300 text-left font-semibold table-header sticky top-0 
                        ${sortConfig && sortConfig.key === header ? "text-blue-600 active-table-header" : ""
                        } ${freezeColumn(header) ? 'freeze-header' : ''}`}
                      onClick={() => {
                        headerMap && headerMap[header][0] !== 'Change Details' && handleSort(header);
                      }}
                       style={{
                        cursor: "pointer",
                        ...(freezeColumn(header)
                          ? { position: "sticky", left: (typeof window !== "undefined" && window.innerWidth < 700) ? "40px" : 0, zIndex: 11, cursor: "pointer" }
                          : {})
                      }}
                    >
                      {headerMap && headerMap[header]
                        ? headerMap[header][0]
                        : formatColumnName(header)}
                      {headerMap && headerMap[header][0] &&
                        (sortConfig && sortConfig.key === header ? (
                          sortConfig.direction === "ascending" ? (
                            <ArrowUpOutlined className="sorting-arrow" style={{ marginLeft: 8, color: "#2563EB" }} />
                          ) : (
                            <ArrowDownOutlined style={{ marginLeft: 8, color: "#2563EB" }} />
                          )
                        ) : (
                          <ArrowUpOutlined className="sorting-arrow" style={{ marginLeft: 8, opacity: 0.5 }} />
                        )
                        )}
                    </th>
                  ) : null // Ensure non-visible columns return null
              )}
            </tr>
          </thead>
          <tbody>
            {visibleColumns.length > 0 ? (
              rowData.length > 0 ? (
                rowData?.map((row, index) => (
                  <tr key={index}                     
                  className={index % 2 === 0 ? "bg-gray-50 even-table-row" : ""}                  >
                    {/* Render actions column if allowedActions is true */}
                    {/* {visibleColumns.length > 0 && !report.includes(popupHeading) && (
                <td className="px-6 border-b border-gray-300 table-cell">
                {(currentPage - 1) * itemsPerPage + index + 1}
                </td>
                )} */}
                    {(typeof window !== "undefined" && window.innerWidth < 700) && (
                      <td
                        className="border-b border-gray-300 table-cell"
                        style={
                          { position: "sticky", left: 0, backgroundColor: "white", zIndex: 5 }
                        }>
                        <Radio
                          checked={true}
                          onClick={() => {
                            setShowRowModal(true);
                            setShowRowModalData(row);
                          }}
                          className="custom-gray-radio"
                        />
                      </td>
                    )}
                    {headers.map((header, columnIndex) =>
                      visibleColumns.includes(header) ? (
                        <td
                          key={columnIndex}
                          className={`
                          border-b border-gray-300 
                          ${popupHeading === "Bulk Change History status log"
                              ? "custom-table-cell"
                              : headerMap?.[header]?.[0] === "Billing Status"
                                ? "table-cell !px-[24px] !py-[3px]"
                                : "table-cell"
                            } 
                          ${freezeColumn(header)
                              ? index % 2 === 0
                                ? "even-freeze-cell"
                                : "freeze-cell"
                              : ""
                            }
                        `}
                          style={{
                            ...(freezeColumn(header)
                              ? { position: "sticky", left: (typeof window !== "undefined" && window.innerWidth < 700) ? "40px" : 0, zIndex: 5, cursor: "pointer" }
                              : {})
                          }}
                        >
                          {/* Check if the header is the selection column */}
                          {header === "S.no" ? (
                            (currentPage - 1) * itemsPerPage + index + 1
                          ) : headerMap?.[header]?.[0] === "Billing Status" ? (
                            <Select
                              options={billingStatusOptions}
                              value={billingStatusOptions.find(opt => opt.value === row["billing_platform_status"])}
                              onChange={(selectedOption) => {
                                // You can call your change handler here
                                handleCellChange(index, "billing_platform_status", selectedOption?.value || "");

                              }}
                                styles={{
                                  ...editableDrp,
                                  menuPortal: (base) => ({
                                    ...base,
                                    zIndex: 9999,  // high enough to appear on top
                                  }),
                                  menu: (base) => ({
                                    ...base,
                                    pointerEvents: 'auto',
                                  }),
                              }}
                              className="w-[250px]"
                              menuPortalTarget={document.body}
                            />
                          ) : headerMap?.[header]?.[0] === "Suspended" ? (
                            <div className="flex gap-4">
                              <label className="flex items-center gap-1">
                                <input
                                  type="checkbox"
                                  checked={row["suspension_status"] === true}
                                  onChange={() => handleCellChange(index, "suspension_status", true)}
                                />

                                True
                              </label>
                              <label className="flex items-center gap-1">
                                <input
                                  type="checkbox"
                                  checked={row["suspension_status"] === false}
                                  onChange={() => handleCellChange(index, "suspension_status", false)}
                                />
                                False
                              </label>
                                </div>
                              ) : headerMap[header][0] === "Customer ID" ? (
                                <>
                                  <a
                                    onClick={() => handleRowClick(row, header)} // Attach click only to the "Account ID" value
                                    className="text-blue-500 cursor-pointer underline"

                                  >
                                    <Tooltip title={row[header]}>
                                      <span>{row[header]}</span>
                                    </Tooltip>
                                  </a>

                                </>
                              )
                                : row[header] != "None" ? (
                              popupHeading === "Bulk Change History status log" ?
                                (
                                  <span>{row[header]}</span>
                                ) : (
                                  <Tooltip
                                    title={`${row[header]}`}
                                    placement="topLeft"
                                    overlayStyle={{ whiteSpace: 'normal', maxWidth: '60vw', wordWrap: 'break-word', zIndex: 50 }}
                                    // getPopupContainer={(triggerNode) => (triggerNode.parentNode as HTMLElement) || document.body} // Fallback to document.body
                                    getPopupContainer={() => document.body} // Render tooltip directly on the body to avoid stacking issues
                                  >
                                    <span>{row[header]}</span>
                                  </Tooltip>
                                )
                            ) : (
                              ""
                            )}
                        </td>
                      ) : null
                    )}
                  </tr>
                ))
              ) : (
                <tr>
                  <td
                    colSpan={
                      headers.filter((header) =>
                        visibleColumns.includes(header)
                      ).length + 1
                    }
                    className="px-6 py-3 border-b border-gray-300 text-center text-gray-500"
                  >
                    No Records Found
                  </td>
                </tr>
              )
            ) : null}
          </tbody>
        </table>
      </div>
      {(!isSmallScreen && visibleColumns.length > 0 && popupHeading !== "Roles" && popupHeading !== "Module Access") && (
        <div className="flex justify-center mt-5">
          {paginationComponent}
        </div>
      )}

      {showRowModal &&
        <RowDetailsModal
          row={showRowModalData}
          headerMap={headerMap}
          onClose={() => {
            setShowRowModal(false)
            setShowRowModalData(null)
          }}
          isOpen={showRowModal}
        />
      }
    </div>
  );
};

// export default TableComponent;
