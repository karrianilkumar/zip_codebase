"use client";

import AdvancedMultiFilter from "@/app/components/advanced_search";
import ColumnFilter from "@/app/components/columnfilter";
import TableSearch from "@/app/components/entire_table_search";
import TableComponent from "@/app/components/TableComponent/page";
import BillingTableComponent from "@/app/partner/partner_info/billing_platform_settings/billing_table_component";
import React, { useEffect, useState,useCallback, useRef } from "react";
import { ArrowDownTrayIcon, PlusIcon } from '@heroicons/react/24/outline';
import { InputRef, Modal, notification, Spin } from "antd";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useAuth } from '@/app/components/auth_context';
import WholeSearchWithoutAPI from "@/app/components/wholeSearchWithoutAPI";
import { useSearchStore } from "@/app/stores/searchStore";
import AdvancedMultiFilterWithoutAPI from "@/app/components/advSearchWithoutAPI";
import Select, { SingleValue } from 'react-select';
import { DropdownStyles,NonEditableDropdownStyles } from "@/app/components/css/dropdown";
import KillbillTableComponent from "@/app/billing/killbill_components/table__component";
import CreateModal from "@/app/billing/killbill_components/createpopup";
import AdvancedMultiFilter2 from "@/app/billing/killbill_components/advanced__search";
import WholeTableSearch from "@/app/billing/killbill_components/whole__search";
import BillingPlatformTableComponent2 from "@/app/billing/killbill_components/table__component_2";
import { Input } from "antd";
import { useSidebarStore } from "@/app/stores/navBarStore";
import { fireSideCannons } from "@/app/components/confetti";
interface ExcelDataRow {
  [key: string]: any;
}
interface RowDataType {
  [key: string]: any;
  isEdited?: boolean;
}

interface BillingStatusSettingsProps {
  suspensionSettingsData: any; // Replace `any` with the actual type if known
  carrierMappingData: any;
  rolesHeaders: any;
  moduleHeaders: any;
  rolesHeadersMap: any;
  moduleHeadersMap: any;
  popupHeading?: any;
  suspensionPagination?: any;
  statusPagination?: any;
  selectedSubPartner?: any;
  selectedPartner?: any;
  fetchData?: (selectedPartner: any,selectedSubPartner: any) => void; 
  billingPlatformStatusData?: any;
  service_line_description?:any;
  handleCancel?: () => void; // Optional prop for handling cancel action
}

const BillingStatusSettings: React.FC<BillingStatusSettingsProps> = ({
  suspensionSettingsData = null,
  carrierMappingData = null,
  rolesHeaders,
  moduleHeaders,
  rolesHeadersMap,
  moduleHeadersMap,
  popupHeading,
  suspensionPagination = {},
  statusPagination = {},
  selectedSubPartner = null,
  selectedPartner = null,
  fetchData = (selectedPartner,selectedSubPartner) => {}, 
  billingPlatformStatusData = null,
  service_line_description = null,
  handleCancel = () => {}, 
}) => {
type FeeInputKey =
  | "network_access_fee"
  | "cost_recovery_fee"
  | "credit_card_fee"
  | "lead_days"
  | "late_fees"
  | "minimum_amount"
  | "charge_back_fee"
  | "billing_email"
  | "billing_api";

const inputRefs: Record<FeeInputKey, React.RefObject<InputRef>> = {
  network_access_fee: React.createRef<InputRef>(),
  cost_recovery_fee: React.createRef<InputRef>(),
  credit_card_fee: React.createRef<InputRef>(),
  lead_days: React.createRef<InputRef>(),
  late_fees: React.createRef<InputRef>(),
  minimum_amount: React.createRef<InputRef>(),
  charge_back_fee: React.createRef<InputRef>(),
   billing_email:React.createRef<InputRef>(),
  billing_api: React.createRef<InputRef>()
}

const selectRefs = {
  late_fee_type: useRef<any>(null),
  enable_credit_card_fee_type: useRef<any>(null), 
};




  const [data, setData] = useState<ExcelDataRow[]>([]);
  const [data2, setData2] = useState<ExcelDataRow[]>([]);
  const [tableData, setTableData] = useState<ExcelDataRow[]>([]);
  const [tableData2, setTableData2] = useState<ExcelDataRow[]>([]);
  const [wholeData, setWholeData] = useState<ExcelDataRow[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const [visibleColumns2, setVisibleColumns2] = useState<string[]>([]);
  const [pagination1, setpagination1] = useState<any>({ suspensionPagination });
  const [pagination2, setpagination2] = useState<any>({ statusPagination });
  const [isChecked, setIsChecked] = useState<boolean | null>(true);
  const { addExport, removeExport, exports } = exportLoadingStore();
  const { username, partner, role, settabledata, token,setModules, selectedDb, metaData,selectedBillingDb,advancedStoredpagination, storedpagination, tenantId, tenantName, firstLastName, sessionId, combineAdnvaceStoredpagination, setCombineAdnvaceStoredpagination, dynamicColumns, setDynamicColumns } = useAuth();
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  const [advancedMultiFilters2, setAdvancedFilters2] = useState<any>({});
  const [filteredData, setFilteredData] = useState([]);
  const [targetRowIndex, setTargetRowIndex] = useState<number | null>(null);
  const { setOptimizationErrorsData , setGLCodeTableData , setserviceProviderData , setbillableOnSuspensionData } = useSearchStore();
  const isExpanded = useSidebarStore((state: any) => state.isExpanded);
  const serviceLineDescriptionOptions = [
    { label: "Username", value: "Username" },
    { label: "Cost Center", value: "Cost Center" },
    { label: "Leave Blank", value: "Leave Blank" },
  ];
  const [serviceLineDescription, setServiceLineDescription] = useState<any>(
    service_line_description
      ? serviceLineDescriptionOptions.find(
        (opt) => opt.value === service_line_description
      )
      : serviceLineDescriptionOptions.find((opt) => opt.value === "Leave Blank")
  );
 type Fees = {
  network_access_fee: number | "";
  cost_recovery_fee: number | "";
  credit_card_fee: number | "";
  lead_days: number | "";
  late_fee_type: string;
  minimum_amount: number | "";
  late_fees: number | "";
  charge_back_fee: number | "";
  enable_credit_card_fee_type: string;
};
type CreditCardFeeOption = {
  label: string;
  value: string;
};

const creditCardFeeOptions: CreditCardFeeOption[] = [
  { label: "All CC payments (manual + auto debit)", value: "All CC payments" },
  { label: "Only manual payments", value:"Only manual payments" },
  { label: "Only auto-debit payments", value:"Only auto-debit payments" },
];
const [fees, setFees] = useState<Fees>({
  network_access_fee: "",
  cost_recovery_fee: "",
  credit_card_fee: "",
  lead_days: "",
  late_fee_type: "",
  late_fees: "",
  minimum_amount: "",
  charge_back_fee: "",
  enable_credit_card_fee_type: "",
});
 
  const lateFeeOptions = [
    { value: "Percentage", label: "Percentage" },
    { value: "Flat Rate", label: "Flat Rate" },
    // { value: "minimum", label: "Minimum Amount" },
  ];
  const [formData, setFormData] = useState({
  billing_email: "",
  billing_api: "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const headers1 = rolesHeaders;
  const headers2 = moduleHeaders;
  
const [glTableData, setGLTableData] = useState<any[]>([]);
const [glHeaders, setGLHeaders] = useState<string[]>([]);
const [glVisibleColumns, setGLVisibleColumns] = useState<string[]>([]);
const [glHeaderMap, setGLHeaderMap] = useState<any>({});
const [glFeatures, setGLFeatures] = useState<string[]>([]);
const [glAllowedActions, setGLAllowedActions] =useState<any[]>([]);
const [glCreateModalData, setGLCreateModalData] = useState<any[]>([]);
const [glPagination, setGLPagination] = useState<any>({});
const [glSearchTerm, setGLSearchTerm] = useState<string>("");
const [glShowAdvanced, setGLShowAdvanced] = useState<boolean>(false);
const [glFilteredData, setGLFilteredData] = useState<any[]>([]);
const [glGeneralFields, setGLGeneralFields] = useState<any>({});
const [isCreateModalOpen, setCreateModalOpen] = useState(false);
const [isSPCreateModalOpen, setSPCreateModalOpen] = useState(false);
const [spTableData, setSPTableData] = useState<any[]>([]);
const [spfeatures, setSPFeatures] = useState<string[]>([]);
const [spHeaders, setSPHeaders] = useState<any[]>([]);
const [spVisibleColumns, setSPVisibleColumns] = useState<string[]>([]);
const [spHeaderMap, setSPHeaderMap] = useState<any>({});
const [spAllowedActions, setSPAllowedActions] =useState<any[]>([]);
const [spCreateModalData, setSPCreateModalData] = useState<any[]>([]);
const [spPagination, setSPPagination] = useState<any>({});
const [spSearchTerm, setSPSearchTerm] = useState<string>("");
const [spShowAdvanced, setSPShowAdvanced] = useState<boolean>(false);
const [spFilteredData, setSPFilteredData] = useState<any[]>([]);
const [spGeneralFields, setSPGeneralFields] = useState<any>({});
 type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);
//  useEffect(() => {
//   const firstErrorKey = Object.keys(errors).find((key) => errors[key]);
//   if (firstErrorKey) {
//     scrollToFirstError(errors);
//   }
// }, [errors]);

  // console.log("Suspension Settings Data:", pagination1, "Carrier Mapping Data:", pagination2);
  useEffect(() => {
    if (billingPlatformStatusData !== undefined) {
      setIsChecked(billingPlatformStatusData);
    }
  }, [billingPlatformStatusData]);

  useEffect(() => {
    setErrors({
    network_access_fee: "",
    cost_recovery_fee: "",
    credit_card_fee: "",
    lead_days: "",
    late_fee_type: "",
    late_fees: "",
    charge_back_fee: ""
  });
    setData(suspensionSettingsData);
    setbillableOnSuspensionData(suspensionSettingsData);
    setTableData(suspensionSettingsData);
    const slicedCarrierData = carrierMappingData.slice(0, 10);
    console.log("slicedCarrierData",slicedCarrierData)
    setOptimizationErrorsData(slicedCarrierData);
    setTableData2(slicedCarrierData);
    setWholeData(carrierMappingData);
    // setTableData2(carrierMappingData)
    setData2(carrierMappingData);
    fetchGLCodeManagementData();
    fetchServiceProviderData();
    handleDefaultClick();
  }, [suspensionSettingsData, carrierMappingData]);
//   const scrollToFirstError = (errors: Record<string, string>) => {
//   const firstErrorKey = Object.keys(errors).find((key) => errors[key]);
//   if (!firstErrorKey) return;

//   const inputRef = inputRefs[firstErrorKey as keyof typeof inputRefs]?.current;

//   if (inputRef?.input) {
//     // ✅ Use .input for scroll
//     inputRef.input.scrollIntoView({ behavior: "smooth", block: "center" });
//     inputRef.focus();
//   } else if (firstErrorKey === "late_fee_type" && selectRefs.late_fee_type.current) {
//     // react-select
//     selectRefs.late_fee_type.current.scrollIntoView?.({
//       behavior: "smooth",
//       block: "center",
//     });
//     selectRefs.late_fee_type.current.focus();
//   }
// };

  const fetchGLCodeManagementData = async () => {
     setLoading(true);
  settabledata([]);
  setGLSearchTerm("");
  try {
    console.log("fetchGLCodeManagementData entered")
    const url = ENV_ROUTES.MODULE_MANAGEMENT;

    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/glcode_list_view",
      role_name: role,
      parent_module: "Partner Info",
      module_name: "Billing GL Code",
      Selected_Partner: selectedPartner,
      sub_partner: selectedSubPartner,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
          ...metaData,
      billing_db_name:selectedBillingDb,
      sessionID: sessionId,
      mod_pages: {
        start: 0,
        end: 100,
      },
    };

    const response = await axios.post(url, { data });
    const parsedData = JSON.parse(response.data.body);
    console.log("GL Code Response:", parsedData);

    if (parsedData.flag === true) {
      setLoading(false);
       setTimeout(() => {
        const headersMap_ = parsedData?.headers_map?.["Billing GL Code"]?.header_map || {};
      const sortedheaderMap = sortHeaderMap(headersMap_);
      setGLHeaderMap(sortedheaderMap);

      setGLGeneralFields(parsedData || {});
      const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : []; 
      setGLHeaders(headers_);
      setGLVisibleColumns(headers_);
      console.log("GL Headers:", headers_);
      const features_ = parsedData?.headers_map?.["Billing GL Code"]?.module_features || [];
      setGLFeatures(features_);
      setGLAllowedActions(["edit", "deactivate"]);
      setGLCreateModalData(parsedData?.headers_map?.["Billing GL Code"]?.pop_up || []);
      console.log("GL Create Modal Data:", parsedData?.headers_map?.["Billing GL Code"]?.pop_up || []);
      setGLPagination(parsedData.pages || {});
      setGLTableData(parsedData?.data?.billing_gl_code || []);
      setGLCodeTableData(parsedData?.data?.billing_gl_code || []);
      console.log("GL Code Data:", parsedData?.data?.billing_gl_code);
       },0);
      
    } else {
      setLoading(false);
        console.log("flag set to false")
      Modal.error({
        title: "Data Fetch Error",
        content: parsedData.message || "An error occurred while fetching GL Code data. Please try again.",
        centered: true,
      });
    }
  } catch (error: any) {
    Modal.error({
      title: "Data Fetch Error",
      content: error instanceof Error ? error.message : "An unexpected error occurred while fetching GL Code data. Please try again.",
      centered: true,
    });
  } finally {
      setLoading(false);
    }
  }
  const fetchServiceProviderData = async () => {
    setLoading(true);
    settabledata([]);
    setSPSearchTerm("");
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;

      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/bp_service_providers_list_view",
        role_name: role,
        parent_module: "Partner Info",
        module_name: "Billing Service Providers",
        Selected_Partner: selectedPartner,
        sub_partner: selectedSubPartner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
          ...metaData,
        billing_db_name:selectedBillingDb,
        sessionID: sessionId,
        mod_pages: {
          start: 0,
          end: 100,
        },
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      
      console.log("Service Provider Response:", parsedData);
      if (parsedData.flag === true) {
        setLoading(false);
        setTimeout(() => {
          const headersMap_ = parsedData?.header_map?.["Service Provider BP"]?.header_map || {};
          const sortedheaderMap = sortHeaderMap(headersMap_);
          setSPHeaderMap(sortedheaderMap);

          setSPGeneralFields(parsedData || {});
          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
          setSPHeaders(headers_);
          setSPVisibleColumns(headers_);
          // console.log("GL Headers:", headers_);
          const features_ = parsedData?.header_map?.["Service Provider BP"]?.module_features || [];
          setSPFeatures(features_);
          setSPAllowedActions(["edit", "deactivate"]);
          setSPCreateModalData(parsedData?.header_map?.["Service Provider BP"]?.pop_up || []);
          setserviceProviderData(parsedData?.data?.billing_service_providers || []);
          // console.log("GL Create Modal Data:", parsedData?.headers_map?.["Billing GL Code"]?.pop_up || []);
          setSPPagination(parsedData.pages || {});
          setSPTableData(parsedData?.data?.billing_service_providers || []);
          // console.log("GL Code Data:", parsedData?.data?.billing_service_providers);
        }, 0);

      } else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching GL Code data. Please try again.",
          centered: true,
        });
      }
    } catch (error: any) {
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching GL Code data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  }
  
  const handleDefaultClick = async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username,
        firstLastName,
        path: "/fetch_default_settings",
        role_name: role,
        table_name: "default_settings",
        request_received_at: getCurrentDateTime(),
        Selected_Partner: selectedPartner,
        sub_partner: selectedSubPartner,
        Partner: partner,
        db_name: selectedDb,
        ...metaData,
        billing_db_name: selectedBillingDb,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      // console.log(response.data.data.default_settings);
      console.log("Default Settings Response:", response);
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === true) {
      const settings = parsedData.data.default_settings[0];
        setFormData({
          billing_api:settings.billing_api,
          billing_email:settings.billing_email
        })
        const {
          network_access_fee,
          cost_recovery_fee,
          late_fee_type,
          late_fees,
          minimum_amount, // ✅ ADD THIS
          credit_card_fee,
          lead_days,
          charge_back_fee,
          enable_credit_card_fee_type
        } = settings;

        setFees({
          network_access_fee: network_access_fee || "",
          cost_recovery_fee: cost_recovery_fee || "",
          // late_fee_type: late_fee_type || "",
          late_fee_type: (() => {
            const type = (late_fee_type || "").toLowerCase().replace(/_/g, " ").trim();
            if (type.includes("percent")) return "Percentage";
            if (type.includes("flat")) return "Flat Rate";
            return "";
          })(),

          late_fees: late_fees === 0 ? 0 : late_fees || "",

          // ✅ Only show minimum_amount if late_fee_type is percentage
          minimum_amount:
            (late_fee_type || "").toLowerCase() === "percentage"
              ? minimum_amount === 0 ? 0 : minimum_amount || ""
              : "",
          credit_card_fee: credit_card_fee || "",
          // lead_days: lead_days || "",
          // lead_days: (lead_days === 0 ? 0 : lead_days || ""),
          lead_days: (lead_days === 0 ? 0 : lead_days || ""),
          charge_back_fee: charge_back_fee || "",
          enable_credit_card_fee_type: enable_credit_card_fee_type || "",
        });
      } else {
        Modal.error({
          title: "Error",
          content: "Failed to fetch default settings. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      console.error("Error fetching default settings:", error);
      Modal.error({
        title: "Error",
        content: "An error occurred while fetching default settings. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
    const handleFeeConfigurationConfirmSave = async () => {
  setLoading(true);
  try {
    const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;

     // 🧠 Clean + normalize the fee data before saving
    const normalizedFees = {
       ...fees,
  late_fee_type:
    fees.late_fee_type?.toLowerCase().includes("flat") ? "Flat Rate" :
    fees.late_fee_type?.toLowerCase().includes("percent") ? "Percentage" : "",
    // ✅ Send minimum_amount always as a number (or 0), avoid ""
  minimum_amount:
    fees.minimum_amount !== "" && fees.minimum_amount !== null
      ? Number(fees.minimum_amount)
      : 0,
  // minimum_amount:
  //   fees.late_fee_type?.toLowerCase().includes("percent")
  //     ? fees.minimum_amount || ""
  //     : "",
    };

    const data = {
      tenant_name: partner||"default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/update_default_settings",
      role_name: role,
      table_name: "default_settings",
      request_received_at: getCurrentDateTime(),
      Selected_Partner: selectedPartner,
      sub_partner: selectedSubPartner,
      Partner: partner,
      db_name: selectedDb,
      billing_db_name: selectedBillingDb,
      sessionID: sessionId,
      changed_data: { ...normalizedFees, ...formData }
    };

    const response = await axios.post(url, data);
    console.log(response);
    const parsedData = JSON.parse(response.data.body);
    if (parsedData.flag === true) {
          // ✅ Wait for backend to update
  await new Promise((resolve) => setTimeout(resolve, 500));

  // ✅ Re-fetch latest saved data from backend
  await handleDefaultClick();

  // // ✅ Fix: Keep UI consistent with selected type
  // setFees((prev) => ({
  //   ...prev,
  //   late_fee_type: fees.late_fee_type,
  //   minimum_amount:
  //     fees.late_fee_type?.toLowerCase() === "percentage"
  //       ? fees.minimum_amount
  //       : "",
  // }));
      notification.success({
        message: "Success",
        description: parsedData.message || "Successfully submitted the data!", // ✅ Extract message string
        style: messageStyle,
        placement: "top",
      });
      fireSideCannons()
    } else {
      Modal.error({
        title: "Error",
        content: parsedData.message || "Failed to save fees.",
        centered: true,
      });
    }
  } catch (error) {
    Modal.error({
      title: "Error",
      content: "Failed to save fees. Please try again.",
      centered: true,
    });
  } finally {
    setLoading(false);
  }
};


   const handleCreateModalOpen = () => {
    setCreateModalOpen(true);
  };

  const handleCreateModalClose = () => {
    setCreateModalOpen(false);
    setSPCreateModalOpen(false);
  };
   const handleCreateRow = () => {
    handleCreateModalClose();
    fetchGLCodeManagementData();
  };
  const handleGLFilter = (advancedFilters: any) => {
    console.log(advancedFilters)
    setAdvancedFilters(advancedFilters)
  };
  const handleGLReset = (EmptyFilters: any) => {
    console.log(EmptyFilters)
    setGLFilteredData(EmptyFilters);
  };
   const handleSPFilter = (advancedFilters: any) => {
    console.log(advancedFilters)
    setAdvancedFilters2(advancedFilters)
  };
  const handleSPReset = (EmptyFilters: any) => {
    console.log(EmptyFilters)
    setSPFilteredData(EmptyFilters);
  };
  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }

  const ExportWithoutSearch = async () => {
    // setExportLoading(true)
    // const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
    //   return new Promise((resolve, reject) => {
    //     const timer = setTimeout(() => {
    //       reject(new Error("Request timed out"));
    //     }, timeout);

    //     promise
    //       .then((res) => {
    //         clearTimeout(timer);
    //         resolve(res);
    //       })
    //       .catch((err) => {
    //         clearTimeout(timer);
    //         reject(err);
    //       });
    //   });
    // };
    try {
      // setExportLoading(true)
      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Request timed out"));
          }, timeout);

          promise
            .then((res) => {
              clearTimeout(timer);
              resolve(res);
            })
            .catch((err) => {
              clearTimeout(timer);
              reject(err);
            });
        });
      };
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/export_to_s3_bucket",
        role_name: role,
        parent_module: "Partner Info",
        module_name: "Billing Settings",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
          ...metaData,
          billing_db_name:selectedBillingDb,
        sessionID: sessionId,
        start_date: getFirstDayOfCurrentMonth(),
        end_date: getLastDayOfCurrentMonth(),
      };
      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000); // Timeout of 10 seconds
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }

      // Wait for 20 seconds before polling
      await new Promise((resolve) => setTimeout(resolve, 20000));
      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      // setExportLoading(false);
      // removeExport(exportKey); // Remove the export from the store
    }
  }
  const pollExportStatus = async () => {
    // Polling for the second API
    const export_url = ENV_ROUTES.MODULE_MANAGEMENT;
    const export_data = {
      tenant_name: partner || "default_value",
      username,
      path: "/get_export_status",
      role_name: role,
      parent_module: "Partner Info",
      module_name: "Billing Settings",
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
          ...metaData,
          billing_db_name:selectedBillingDb,
      sessionID: sessionId,
    };
    try {
      const export_response = await axios.post(export_url, { data: export_data });
      const export_parsedData = JSON.parse(export_response.data.body);

      if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
        const s3Url = export_parsedData?.export_status_data?.url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
            .then(response => response.blob())
            .then(blob => {
              const url = window.URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = 'Users.xlsx';
              a.click();
              a.remove();
              window.URL.revokeObjectURL(url);
              notification.success({
                message: "Success",
                description: "Successfully exported the record!",
                style: messageStyle,
                placement: "top",
              });
              fireSideCannons()
            })
            .catch((err) => {
              console.log("error", err)
              Modal.error({
                title: "Export Error",
                content: "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            });
        } else {
          Modal.error({
            title: "Export Error",
            content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
        return true; // Stop polling
      }

      if (export_parsedData?.export_status_data?.status_flag === "Failure") {
        Modal.error({
          title: "Export Error",
          content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
        return true; // Stop polling
      }
      if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
        Modal.info({
          title: "Export Error",
          content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
        return true; // Stop polling
      }

      return false; // Continue polling
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
      return true; // Stop polling
    }
  };
  const startPolling = async () => {
    let isPollingComplete = false;

    while (!isPollingComplete) {
      isPollingComplete = await pollExportStatus();
      if (!isPollingComplete) {
        await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
      }
    }
  };
  const handleExport = async (key: string, heading: string) => {
    try {
       let index_name = "Carrier Status Mapping";
      if (popupHeading === "Carrier Status Mapping") {
        index_name = "Carrier Status Mapping";
      } else if (popupHeading === "Billable on Suspension") {
        index_name = "Suspension Settings";
      }
      // setExportLoading(true)
      addExport(key, heading);
      let parsedData
      let url
      let data: any
      let response
      if (combineAdnvaceStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedBillingDb,
          ...metaData,
          // billing_db_name:selectedBillingDb,
          sessionID: sessionId,
          module_name: "Billing Settings",
          index_name,
          sub_partner: selectedSubPartner || "",
          Selected_Partner: selectedPartner,
        }
        console.log("combineAdnvaceStoredpagination", data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
      else if (advancedStoredpagination && !storedpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          module_name: "Billing Settings",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name,
          pages: {
            start: 0,
            end: 100
          },
          partner: partner,
          username: username,
          db_name: selectedBillingDb,
          ...metaData,
          // billing_db_name:selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
          sub_partner: selectedSubPartner || "",
          Selected_Partner: selectedPartner,
          // }
        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

      }
      else if (storedpagination && !advancedStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          module_name: "Billing Settings",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name,    
          search: "whole",
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedBillingDb,
          ...metaData,
          // billing_db_name:selectedBillingDb,
          sessionID: sessionId,
          tenant_id: tenantId,
          sub_partner: selectedSubPartner || "",
          Selected_Partner: selectedPartner,

        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

      }
      else {
        // ExportWithoutSearch()
        await ExportWithoutSearch();
        return;
      }

      if (advancedStoredpagination || storedpagination || combineAdnvaceStoredpagination) {
        // if (parsedData.flag === true) {
        //   const s3Url = parsedData?.download_url || null;
        //   if (s3Url) {
        //     window.location.href = s3Url;
        //     setExportLoading(false)
        //     notification.success({
        //       message: 'Success',
        //       description: 'Successfully exported the record!',
        //       style: messageStyle,
        //       placement: 'top',
        //     });
        //   }
        //   else {
        //     setExportLoading(false)
        //     Modal.error({
        //       title: "Export Error",
        //       content: parsedData.message || "An error occurred while exporting data. Please try again.",
        //       centered: true,
        //     });
        //   }


        if (parsedData.flag) {
          const s3Url = parsedData?.download_url || null;
          if (s3Url) {
            // window.location.href = s3Url;
            // notification.success({
            //   message: "Success",
            //   description: "Successfully exported the  record!",
            //   style: messageStyle,
            //   placement: "top",
            // });
            fetch(s3Url)
              .then(response => response.blob())
              .then(blob => {
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'Users.xlsx';
                a.click();
                a.remove();
                window.URL.revokeObjectURL(url);
                notification.success({
                  message: "Success",
                  description: "Successfully exported the record!",
                  style: messageStyle,
                  placement: "top",
                });
              })
              .catch((err) => {
                console.log("error", err)
                Modal.error({
                  title: "Export Error",
                  content: "An error occurred while exporting data. Please try again.",
                  centered: true,
                });
              });
          }


        } else {
          // setExportLoading(false)
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      } else {
        Modal.error({
          title: "Export Error",
          content: parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
      }

    } catch (error) {
      console.log("catch")
      await startPolling()
      // Modal.error({
      //   title: "Export Error",
      //   content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
      //   centered: true,
      // });
    } finally {
      // setExportLoading(false)
      removeExport(key);
    }
  };
  const messageStyle = {
    fontSize: '14px',  // Adjust font size
    fontWeight: 'bold', // Make the text bold
    padding: '16px',
    // Add padding
  };
    if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }
  const handleInputChange = (field: keyof typeof formData, value: string) => {
  setFormData((prev) => ({
    ...prev,
    [field]: value,
  }));

  // ✅ clear error for this field if user is typing
  setErrors((prev) => {
    const newErrors = { ...prev };
    delete newErrors[field];
    return newErrors;
  });
};
const handleFeeChange = (key: keyof Fees, value: string) => {
  setFees((prev) => {
    // If switching away from percentage, clear minimum_amount
    if (key === "late_fee_type") {
       const lowerValue = value.toLowerCase();
      return {
        ...prev,
        [key]: value,
        minimum_amount: value === "percentage" ? prev.minimum_amount : "", // clear it if not percentage
      };
    }

    return {
      ...prev,
      [key]:
        value === ""
          ? ""
          : value === "0"
          ? 0
          : Number(value),
    };
  });

  setErrors((prev) => ({
    ...prev,
    [key]: value.trim() !== "" ? "" : prev[key],
    ...(key === "late_fee_type" && value.toLowerCase() !== "percentage"
      ? { minimum_amount: "" } // also clear error for minimum_amount
      : {}),
  }));
};



 const validate = () => {
  const newErrors: Record<string, string> = {};
  console.log(fees.minimum_amount, "minimum_amount")
  if (!fees.network_access_fee) newErrors.network_access_fee = "Network Access Fee is required";
  else if (Number(fees.network_access_fee) < 0) newErrors.network_access_fee = "Network Access Fee cannot be negative";
  
  if (!fees.cost_recovery_fee) newErrors.cost_recovery_fee = "Cost Recovery Fee is required";
  else if (Number(fees.cost_recovery_fee) < 0) newErrors.cost_recovery_fee = "Cost Recovery Fee cannot be negative";
  
  if (!fees.credit_card_fee) newErrors.credit_card_fee = "Credit Card Fee is required";
  else if (Number(fees.credit_card_fee) < 0) newErrors.credit_card_fee = "Credit Card Fee cannot be negative";
  
  if (!fees.charge_back_fee) newErrors.charge_back_fee = "Charge Back Fee is required";
  else if (Number(fees.charge_back_fee) < 0) newErrors.charge_back_fee = "Charge Back Fee cannot be negative";
  
  if (fees.lead_days === undefined || fees.lead_days === null || fees.lead_days === "") {
    newErrors.lead_days = "Grace Period is required";
  } else if (Number(fees.lead_days) < 0) {
    newErrors.lead_days = "Late Fee Grace Period cannot be negative";
  }
  
  if (fees.lead_days && !fees.late_fee_type) newErrors.late_fee_type = "Late Fee Type is required";

   // 🔹 ✅ Late Fee Value (New Required Validation)
  if (fees.late_fee_type) {
    if (!fees.late_fees && fees.late_fees !== 0) {
      newErrors.late_fees = "Late Fee Value is required";
    } else if (Number(fees.late_fees) < 0) {
      newErrors.late_fees = "Late Fee Value cannot be negative";
    }
  }
  
  if (fees.lead_days && fees.late_fee_type === "percentage" && !fees.late_fees) newErrors.late_fees = "Late Fee Value is required";
  else if (fees.late_fees && Number(fees.late_fees) < 0) newErrors.late_fees = "Late Fee Value cannot be negative";
  
// ✅ FIXED: enforce Minimum Amount only if Percentage type
  if (fees.late_fee_type?.toLowerCase() === "percentage") {
    if (!fees.minimum_amount && fees.minimum_amount !== 0) {
      newErrors.minimum_amount = "Minimum Amount is required when Late Fee Type is Percentage";
    } else if (Number(fees.minimum_amount) < 0) {
      newErrors.minimum_amount = "Minimum Amount cannot be negative";
    }
  }
  
  if (!formData.billing_email) newErrors.billing_email = "Billing Email is required";
  else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.billing_email)) newErrors.billing_email = "Enter a valid email";
  if (!formData.billing_api) newErrors.billing_api = "Billing API is required";
  
  setErrors(newErrors);
  return newErrors;
};


  const handleSave = async (isChecked:boolean) => {
  const newErrors = validate(); // returns an object like { fieldKey: "Error message", ... }
    if (isChecked && Object.keys(newErrors).length > 0) {
      setErrors(newErrors);   // triggers useEffect to scroll to first error
      return;
    }
 


  // Reset errors if valid
  setErrors({
    network_access_fee: "",
    cost_recovery_fee: "",
    credit_card_fee: "",
    lead_days: "",
    late_fee_type: "",
    late_fees: "",
    charge_back_fee: ""
  });

  if(!isChecked) {
    await handleBillingPlatformDisable();
  }
  else{
    await handleBillingPlatformDisable();
    await handleSuspensionSave();
    await handleCarrierMappingSave();
    if(service_line_description !== serviceLineDescription.label)
    await handleServiceLineChange();
    await handleFeeConfigurationConfirmSave();
    
  }
  };
  const handleSuspensionSave = async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";
      const changedData: RowDataType[] = tableData.filter((row: RowDataType) => row.isEdited);
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/update_carrier_suspend_status",
        role_name: role,
        parent_module: "Partner Info",
        module_name: "Suspension Settings Data",
        table_name: "carrier_suspension_settings",
        sub_partner: selectedSubPartner || "",
        Selected_Partner: selectedPartner,
        // flag: "withoutparameters",
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
          ...metaData,
          billing_db_name:selectedBillingDb,
        tenant_id: tenant_id_,
        sessionID: sessionId,
        changed_data: tableData,
      };
      console.log(getCurrentDateTime(), "Show the log time request sent from ui to lambda");
      const response = await axios.post(url, { data });
      const resp = JSON.parse(response.data.body);
      console.log(getCurrentDateTime(), "Show the log time response sent from lambda to ui");
      console.log(resp);
      // Check if the flag is false
      if (resp.flag === false) {
        Modal.warning({
          title: "Permission Denied",
          content:
            resp.message ||
            "An error occurred while fetching initial data. Please try again.",
          centered: true,
        });
        return; // Exit early if there's an error
      }
      else {
        // if(action !== 'whole') {
        //   notification.success({
        //     message: "Success",
        //     description: resp.message || "Successfully updated the record!",
        //     style: messageStyle,
        //     placement: "top",
        //   });
        //   // fetchData(selectedPartner, selectedSubPartner || "");
        // }
      }

    } catch (err) {
      console.error("Error fetching initial data:", err);
      Modal.error({
        title: "Data Fetch Error",
        content:
          err instanceof Error
            ? err.message
            : "An unexpected error occurred while fetching initial data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
   const handleCarrierMappingSave = async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";
      const changedData: RowDataType[] = tableData.filter((row: RowDataType) => row.isEdited);
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/update_carrier_suspend_status",
        role_name: role,
        parent_module: "Partner Info",
        module_name: "Carrier Mapping Data",
        table_name: "carrier_status_settings",
        sub_partner: selectedSubPartner || "",
        Selected_Partner: selectedPartner,
        // flag: "withoutparameters",
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
          ...metaData,
          billing_db_name:selectedBillingDb,
        tenant_id: tenant_id_,
        sessionID: sessionId,
        changed_data: tableData2,
      };
      console.log(getCurrentDateTime(), "Show the log time request sent from ui to lambda");
      const response = await axios.post(url, { data });
      const resp = JSON.parse(response.data.body);
      console.log(getCurrentDateTime(), "Show the log time response sent from lambda to ui");
      console.log(resp);
      // Check if the flag is false
      if (resp.flag === false) {
        Modal.warning({
          title: "Permission Denied",
          content:
            resp.message ||
            "An error occurred while fetching initial data. Please try again.",
          centered: true,
        });
        return; // Exit early if there's an error
      }
      else {
        
          fetchData(selectedPartner, selectedSubPartner || "");
        
      }
    } catch (err) {
      console.error("Error fetching initial data:", err);
      Modal.error({
        title: "Data Fetch Error",
        content:
          err instanceof Error
            ? err.message
            : "An unexpected error occurred while fetching initial data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
  const handleBillingPlatformDisable = async () => {
     setLoading(true);
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";
      const changedData: RowDataType[] = tableData.filter((row: RowDataType) => row.isEdited);
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/enabling_billing_platform",
        role_name: role,
        parent_module: "Partner Info",
        module_name: "Billing Settings",
        table_name: "carrier_suspension_settings",
        sub_partner: selectedSubPartner || "",
        Selected_Partner: selectedPartner,
        // flag: "withoutparameters",
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
          ...metaData,
          billing_db_name:selectedBillingDb,
        tenant_id: tenant_id_,
        sessionID: sessionId,
        changed_data: {
          "is_active": isChecked,
          "is_deleted": !isChecked,
        },
      };
      console.log(getCurrentDateTime(), "Show the log time request sent from ui to lambda");
      const response = await axios.post(url, { data });
      const resp = JSON.parse(response.data.body);
      console.log(getCurrentDateTime(), "Show the log time response sent from lambda to ui");
      console.log(resp);
      // Check if the flag is false
      if (resp.flag === false) {
        Modal.warning({
          title: "Permission Denied",
          content:
            resp.message ||
            "An error occurred while fetching initial data. Please try again.",
          centered: true,
        });
        return; // Exit early if there's an error
      }
      else {
        if(resp.flag === true) {
          if(resp.get_module_check){
            await handleModuleChanges();
          }
          notification.success({
            message: "Success",
            description: resp.message || "Successfully updated the record!",
            style: messageStyle,
            placement: "top",
          });
          fireSideCannons()
          // fetchData(selectedPartner, selectedSubPartner || "");
        }
      }

    } catch (err) {
      console.error("Error fetching initial data:", err);
      Modal.error({
        title: "Data Fetch Error",
        content:
          err instanceof Error
            ? err.message
            : "An unexpected error occurred while fetching initial data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
      }
  const handleModuleChanges = async () => {
    const data = {
          path: "/get_modules",
          role_name: role,
          username: username,
          firstLastName: firstLastName,
          sessionID: sessionId,
          tenant_name: partner,
          Partner: partner,
          request_received_at: getCurrentDateTime(),
          access_token: token,
        };
    
        setLoading(true);
    
        try {
          const url = ENV_ROUTES.MODULE_MANAGEMENT;
          const response = await axios.post(url, { data: data }, {
            headers: {
              'Content-Type': 'application/json',
            },
          });
    
          if (response.status === 200) {
            const parsedData = JSON.parse(response.data.body);
    
            if (parsedData.error) {
              setLoading(false);
              Modal.error({
                title: 'Module Fetch Error',
                content: parsedData.error || 'An error occurred while fetching modules. Please try again.',
              });
            } else if (parsedData.flag === false) {
              setLoading(false);
              Modal.error({
                title: 'Module Fetch Error',
                content: parsedData.message || 'An error occurred while fetching modules. Please try again.',
              });
            } else {
              const modules = parsedData?.Modules || [];
              const billingFlag = parsedData?.billing_platform_flag ?? false;
              const filteredModules = billingFlag
                ? modules
                : modules.filter(
                    (module: any) => module.parent_module_name !== "Billing"
                  );

              setModules(filteredModules);
              localStorage.setItem("modules", JSON.stringify(filteredModules || []));
              localStorage.setItem('bp_flag', parsedData?.billing_platform_flag || false);
              
            }
          } else {
            setLoading(false);
            Modal.error({
              title: 'Module Fetch Error',
              content: response.data.message || 'Fetching modules failed. Please try again.',
            });
          }
        } catch (error) {
          setLoading(false);
          Modal.error({
            title: 'Module Fetch Error',
            content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching modules. Please try again.',
          });
        } finally {
          // setLoading(false);
        }
  }
  const handleServiceLineChange = async () => {
     setLoading(true);
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const tenant_id_ = localStorage.getItem("tenant_id") || "0";
      // const changedData: RowDataType[] = tableData.filter((row: RowDataType) => row.isEdited);
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/update_service_line_description",
        role_name: role,
        parent_module: "Partner Info",
        module_name: "Billing Settings",
        table_name: "service_line_description",
        sub_partner: selectedSubPartner || "",
        Selected_Partner: selectedPartner,
        // flag: "withoutparameters",
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
          ...metaData,
          billing_db_name:selectedBillingDb,
        tenant_id: tenant_id_,
        sessionID: sessionId,
        changed_data: {service_line_description:serviceLineDescription.label},
      };
      console.log(getCurrentDateTime(), "Show the log time request sent from ui to lambda");
      const response = await axios.post(url, { data });
      const resp = JSON.parse(response.data.body);
      console.log(getCurrentDateTime(), "Show the log time response sent from lambda to ui");
      console.log(resp);
      // Check if the flag is false
      if (resp.flag === false) {
        Modal.warning({
          title: "Permission Denied",
          content:
            resp.message ||
            "An error occurred while fetching initial data. Please try again.",
          centered: true,
        });
        return; // Exit early if there's an error
      }
      else {
        if(resp.flag === true) {
          if(resp.get_module_check){
            await handleModuleChanges();
          }
          notification.success({
            message: "Success",
            description: resp.message || "Successfully updated the record!",
            style: messageStyle,
            placement: "top",
          });
          fireSideCannons()
          // fetchData(selectedPartner, selectedSubPartner || "");
        }
      }

    } catch (err) {
      console.error("Error fetching initial data:", err);
      Modal.error({
        title: "Data Fetch Error",
        content:
          err instanceof Error
            ? err.message
            : "An unexpected error occurred while fetching initial data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
      }
  const updateRowData = (value: boolean) => {
    setData((prevData) =>
      prevData.map((row, index) =>
        index === targetRowIndex // replace with dynamic logic if needed
          ? { ...row, suspend: value }
          : row
      )
    );
  };
  return (
    <div className="">
      <div>
        {popupHeading === "Billing Settings" && (
          <>
            <div className="flex mt-2 ml-4 gap-4">
              <label className="field-label mr-2">Billing</label>

              <div className="flex items-center gap-2">
                <label className="flex items-center gap-1">
                  <input type="checkbox" checked={isChecked === true}
                    onChange={() => {
                      setIsChecked(true);
                      updateRowData(true);
                    }}
                  />
                  <span>True</span>
                </label>

                <label className="flex items-center gap-1">
                  <input type="checkbox" checked={isChecked === false}
                    onChange={() => {
                      setIsChecked(false);
                      updateRowData(false);
                    }}
                  />
                  <span>False</span>
                </label>
              </div>

            </div>
            <div className="flex mt-2 ml-4 gap-4">
              <label className="field-label mr-2 mt-2">
                Service Line Description
              </label>

              <div className="lex flex-col md:flex-row items-center md:items-end gap-4 flex-wrap w-[320px]">
                <Select
                  options={serviceLineDescriptionOptions}
                  value={serviceLineDescription}
                  onChange={(selected: any) => setServiceLineDescription(selected)}
                  // placeholder="Select Service Line"
                  styles={DropdownStyles}
                // classNamePrefix="react-select"
                />
              </div>

            </div>
             {isChecked && (
              <>

              <div className="p-2 mt-2">
            <h3 className="tabs-sub-headings !mb-0 mt-2">Billing Notifications from email</h3>
            </div>
            <div className="flex flex-wrap">
           <div className="flex flex-col mt-2 ml-4 w-[350px]">
              <label className="field-label">Billing Email<span className="text-red-500 ml-1">*</span></label>
              <Input
                ref={inputRefs.billing_email}
                type="text"
                className="input"
                value={formData.billing_email}
                onChange={(e) => handleInputChange("billing_email", e.target.value)}
                placeholder="Enter Billing Email"
              />
              {errors.billing_email && (
                <p className="text-red-500 text-sm">{errors.billing_email}</p>
              )}
            </div>
            <div className="flex flex-col mt-2 ml-4 w-[350px]">
              <label className="field-label">Billing API<span className="text-red-500 ml-1">*</span></label>
              <Input
                ref={inputRefs.billing_api}
                type="password"
                className="input"
                value={formData.billing_api}
                onChange={(e) => handleInputChange("billing_api", e.target.value)}
                placeholder="Enter Billing API"
              />
              {errors.billing_api && (
                <p className="text-red-500 text-sm">{errors.billing_api}</p>
              )}

            </div>
            </div>
            <div className="p-2 mt-2">
            <h3 className="tabs-sub-headings !mb-0 mt-2">Fee Configurations</h3>
            </div>
            <div className="flex flex-wrap">
              {/* Network Access Fee */}
              <div className="flex flex-col mt-2 ml-4 w-[250px]">
                <label className="field-label mb-1">
                  Network Access Fee <span className="text-red-500 ml-1">*</span>
                </label>
                <div className="flex gap-2">
                  <Input
                    ref={inputRefs["network_access_fee"]}
                    type="number"
                    min={0}
                    suffix="%"
                    className="input w-[120px]"
                    value={fees["network_access_fee"]}
                    onChange={(e) => {
                      const value = e.target.value;
                      if (value === "" || (!isNaN(Number(value)) && Number(value) >= 0)) {
                        handleFeeChange("network_access_fee", value);
                      }
                    }}
                    onKeyDown={(e) => {
                      if (e.key === "-" || e.key === "e" || e.key === "E") {
                        e.preventDefault();
                      }
                    }}
                    onWheel={(e) => {
                        (e.target as HTMLInputElement).blur();
                      }} 
                  />
                </div>
                {errors["network_access_fee"] && (
                  <p className="text-red-500 text-sm">{errors["network_access_fee"]}</p>
                )}
              </div>

              {/* Cost Recovery Fee */}
              <div className="flex flex-col mt-2 ml-4 w-[250px]">
                <label className="field-label mb-1">
                  Cost Recovery Fee <span className="text-red-500 ml-1">*</span>
                </label>
                <div className="flex gap-2">
                  <Input
                    ref={inputRefs["cost_recovery_fee"]}
                    type="number"
                    min={0}
                    suffix="%"
                    className="input w-[120px]"
                    value={fees["cost_recovery_fee"]}
                    onChange={(e) => {
                      const value = e.target.value;
                      if (value === "" || (!isNaN(Number(value)) && Number(value) >= 0)) {
                        handleFeeChange("cost_recovery_fee", value);
                      }
                    }}
                    onKeyDown={(e) => {
                      if (e.key === "-" || e.key === "e" || e.key === "E") {
                        e.preventDefault();
                      }
                    }}
                    onWheel={(e) => {
                        (e.target as HTMLInputElement).blur();
                      }}                  
                      />
                </div>
                {errors["cost_recovery_fee"] && (
                  <p className="text-red-500 text-sm">{errors["cost_recovery_fee"]}</p>
                )}
              </div>

              {/* Charge Back Fee */}
              <div className="flex flex-col mt-2 ml-4 w-[250px]">
                <label className="field-label mb-1">
                  Charge Back Fee <span className="text-red-500 ml-1">*</span>
                </label>
                <div className="flex gap-2">
                  <Input
                    ref={inputRefs["charge_back_fee"]}
                    type="number"
                    min={0}
                    // suffix="%"
                    prefix="$"
                    className="input w-[120px]"
                    value={fees["charge_back_fee"]}
                    onChange={(e) => {
                      const value = e.target.value;
                      if (value === "" || (!isNaN(Number(value)) && Number(value) >= 0)) {
                        handleFeeChange("charge_back_fee", value);
                      }
                    }}
                    onKeyDown={(e) => {
                      if (e.key === "-" || e.key === "e" || e.key === "E") {
                        e.preventDefault();
                      }
                    }}
                    onWheel={(e) => {
                        (e.target as HTMLInputElement).blur();
                      }} 
                  />
                </div>
                {errors["charge_back_fee"] && (
                  <p className="text-red-500 text-sm">{errors["charge_back_fee"]}</p>
                )}
              </div>

              {/* Credit Card Fee + Type together */}
              <div className="flex flex-col mt-2 ml-4 w-[250px]">
                <label className="field-label mb-1">
                  Credit Card Fee <span className="text-red-500 ml-1">*</span>
                </label>
                <div className="flex gap-2">
                  <Input
                    ref={inputRefs["credit_card_fee"]}
                    type="number"
                    min={0}
                    suffix="%"
                    className="input w-[80px]"
                    value={fees["credit_card_fee"]}
                    onChange={(e) => {
                      const value = e.target.value;
                      if (value === "" || (!isNaN(Number(value)) && Number(value) >= 0)) {
                        handleFeeChange("credit_card_fee", value);
                      }
                    }}
                    onKeyDown={(e) => {
                      if (e.key === "-" || e.key === "e" || e.key === "E") {
                        e.preventDefault();
                      }
                    }}
                    onWheel={(e) => {
                        (e.target as HTMLInputElement).blur();
                      }} 
                  />
                </div>
                {errors["credit_card_fee"] && (
                  <p className="text-red-500 text-sm">{errors["credit_card_fee"]}</p>
                )}
              </div>
               <div className="flex flex-col mt-2 ml-4 w-[250px]">
                <label className="field-label mb-1">
                  Credit Card Fee Type<span className="text-red-500 ml-1">*</span>
                </label>
                <div className="flex gap-2">
                  <Select
                    className="w-full"
                    styles={DropdownStyles}
                    placeholder="Select"
                    value={
                      creditCardFeeOptions.find(
                        (option) => option.value === fees.enable_credit_card_fee_type
                      ) || null
                    }
                    onChange={(option) =>
                      setFees((prev) => ({
                        ...prev,
                        enable_credit_card_fee_type: option?.value || "",
                      }))
                    }
                    options={creditCardFeeOptions}
                  />
                </div>
                {/* {errors["credit_card_fee"] && (
                  <p className="text-red-500 text-sm">{errors["credit_card_fee"]}</p>
                )} */}
              </div>
              
            </div>
             {/* Row 2 */}
            <div className="flex flex-wrap">
              {/* Grace Period */}
              <div className="flex flex-col mt-2 ml-4 w-[250px]">
                <label className="field-label mb-1">
                 Late Fee Grace Period <span className="text-red-500 ml-1">*</span>
                </label>
                <Input
                  ref={inputRefs.lead_days}
                  type="number"
                  className="input"
                  min={0}
                  value={fees.lead_days}
                  onChange={(e) => {
                    const value = e.target.value;
                    // Allow empty string or non-negative numbers
                    if (value === '' || (!isNaN(Number(value)) && Number(value) >= 0)) {
                      handleFeeChange("lead_days", value);
                    }
                  }}
                  onKeyDown={(e) => {
                    // Prevent typing minus sign
                    if (e.key === '-' || e.key === 'e' || e.key === 'E') {
                      e.preventDefault();
                    }
                  }}
                  onWheel={(e) => {
                        (e.target as HTMLInputElement).blur();
                      }} 
                />
                {errors.lead_days && (
  <p className="text-red-500 text-sm">{errors.lead_days}</p>
)}

              </div>

              {/* Late Fee Type (dropdown) */}
              <div className="flex flex-col mt-2 ml-4 w-[250px]">
              <label className="field-label mb-1">
                Late Fee Type<span className="text-red-500 ml-1">*</span>
              </label>

              <Select
                inputId="late_fee_type"
                ref={selectRefs.late_fee_type as React.Ref<any>} // ✅ TS safe
                className="w-full"
                styles={fees.lead_days == null || fees.lead_days === "" || fees.lead_days < 0 ? NonEditableDropdownStyles : DropdownStyles}
                isDisabled={fees.lead_days == null || fees.lead_days === "" || fees.lead_days < 0}
                value={lateFeeOptions.find((opt) => opt.value === fees.late_fee_type) || null}
                onChange={(option) => handleFeeChange("late_fee_type", option?.value || "")}
                options={lateFeeOptions}
                placeholder="Select Fee Type"
              />

              {errors.late_fee_type && (
                <p className="text-red-500 text-sm">{errors.late_fee_type}</p>
              )}
            </div>

              {/* Late Fee Value */}
              
                <div className="flex flex-col mt-2 ml-4 w-[250px]">
                  <label className="field-label mb-1">
                    Late Fee Value <span className="text-red-500 ml-1">*</span>
                  </label>
                  <Input
                    ref={inputRefs.late_fees}
                    type="number"
                    className="input"
                    prefix={fees.late_fee_type?.toLowerCase() !== "percentage" ? "$" : undefined}
                    suffix={fees.late_fee_type?.toLowerCase() === "percentage" ? "%" : undefined}
                    value={fees.late_fees}
                    onChange={(e) => {
                      const value = e.target.value;
                      // Allow empty string or non-negative numbers
                      if (value === '' || (!isNaN(Number(value)) && Number(value) >= 0)) {
                        handleFeeChange("late_fees", value);
                      }
                    }}
                    onKeyDown={(e) => {
                      // Prevent typing minus sign
                      if (e.key === '-' || e.key === 'e' || e.key === 'E') {
                        e.preventDefault();
                      }
                    }}
                    onWheel={(e) => {
                        (e.target as HTMLInputElement).blur();
                      }} 
                    min={0}
                  />
                  {errors.late_fees && (
                    <p className="text-red-500 text-sm">{errors.late_fees}</p>
                  )}
                </div>
              {/* ✅ Show Minimum Amount only if Percentage is selected */}
              {fees.late_fee_type === "Percentage" && (
                <div className="flex flex-col mt-2 ml-4 w-[250px]">
                  <label className="field-label mb-1">
                    Minimum Amount <span className="text-red-500 ml-1">*</span>
                  </label>
                  <Input
                    ref={inputRefs.minimum_amount}
                    type="number"
                    className="input"
                    min={0}
                    prefix= "$"
                    value={fees.minimum_amount}
                    onChange={(e) => {
                      const value = e.target.value;
                      // Allow empty string or non-negative numbers
                      if (value === '' || (!isNaN(Number(value)) && Number(value) >= 0)) {
                        handleFeeChange("minimum_amount", value);
                      }
                    }}
                    onWheel={(e) => {
                        (e.target as HTMLInputElement).blur();
                      }} 
                    onKeyDown={(e) => {
                      // Prevent typing minus sign
                      if (e.key === '-' || e.key === 'e' || e.key === 'E') {
                        e.preventDefault();
                      }
                    }}
                  />
                  {errors.minimum_amount && (
                    <p className="text-red-500 text-sm">{errors.minimum_amount}</p>
                  )}
                </div>
              )}
               
              
            </div>
            </>)}


           
          </>
        )}
        {(popupHeading !== "Billing Settings" || isChecked) && (
          <>
            <div className="p-2 mt-2">
              {/* <h3 className="tabs-sub-headings">Module Access</h3> */}
              <h3 className="tabs-sub-headings !mb-0">Billable on Suspension – Carrier Settings</h3>

            </div>
            <div className="relative">
              
              {/* <div className={`${showAdvanced ? "mt-[70px]" : ""}`}> */}
                <TableComponent
                  isSelectRowVisible={false}
                  headers={headers1}
                  initialData={data}
                  visibleColumns={headers1}
                  itemsPerPage={10}
                  searchQuery={''}
                  popupHeading={"Billable on Suspension"}
                  createModalData={[]}
                  pagination={pagination1.suspensionPagination || {}}
                  headerMap={rolesHeadersMap}
                  height={popupHeading === "Billing Settings" ? 300 : ''}
                  onRowDataChange={(updatedData) => setTableData(updatedData)}
                  selectedSubPartner={selectedSubPartner}
                  selectedPartnerBP={selectedPartner}
                />
              {/* </div> */}
            </div>
            <div>
              <div className="p-2">
                {/* <h3 className="tabs-sub-headings">Module Access</h3> */}
                <h3 className="tabs-sub-headings  !mb-0">Carrier Status Mapping</h3>

              </div>
              <div className="relative">
                <div className="pr-4 pl-4 flex md:flex-row md:items-center md:justify-between space-y-2">
                  <div className="flex  space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last ">
                    {(
                      <>
                       {/* <TableSearch
                        searchTerm={searchTerm}
                        setSearchTerm={setSearchTerm}
                        tableName={"Carrier Status Mapping"}
                        headerMap={moduleHeadersMap}
                      /> */}
                      <WholeSearchWithoutAPI
                        headers={headers2}
                        initialData={data2}
                        modulename={"Carrier Status Mapping"}
                        headerMap={moduleHeadersMap}
                        itemsPerPage={5}
                      /></>
                     
                    )}
                    {(
                      <AdvancedMultiFilterWithoutAPI
                        showAdvanced={showAdvanced}
                        setShowAdvanced={setShowAdvanced}
                        headers={headers2}
                        headerMap={moduleHeadersMap}
                        tableName={"Carrier Status Mapping"}
                        initialData = {data2} />
                    )}
                  </div>

                  <div className="hidden md:flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2  md:order-none order-first pb-2 md:pb-4">
{/* 
                    {(
                      <button
                        className="save-btn"
                        onClick={handleCarrierMappingSave} // Show create user form on click
                      >
                        Save
                      </button>
                    )} */}
                    {/* {(
                      <button className="save-btn"
                        onClick={() => {
                          if (!exports.some((exportItem: { popupHeading: string; }) => exportItem.popupHeading === "Partner Users")) {
                            handleExport("PrtnerUsers", "Partner Users");
                          }
                        }}>
                        <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                        <span>Export</span>
                      </button>
                    )} */}
                    {/* <ColumnFilter headers={headers2} visibleColumns={visibleColumns} setVisibleColumns={setVisibleColumns} headerMap={moduleHeadersMap} /> */}
                  </div>
                </div>
                <div className={`${showAdvanced ? "mt-[70px]" : "mt-[10px]"}`}>
                  <BillingTableComponent
                    isSelectRowVisible={false}
                    headers={headers2}
                    initialData={data2}
                    tableData = {wholeData}
                    searchQuery={searchTerm}
                    visibleColumns={headers2}
                    itemsPerPage={10}
                    popupHeading={'Carrier Status Mapping'}
                    createModalData={[]}
                    pagination={pagination2.statusPagination ||{}}
                    headerMap={moduleHeadersMap}
                    height={ showAdvanced? 370: 290 }
                    onRowDataChange={(updatedData) => setTableData2(updatedData)}
                    selectedSubPartner={selectedSubPartner}
                    selectedPartnerBP={selectedPartner}
                    advancedFilters={filteredData}

                  />
                </div>
              </div>
            </div>
          
          </>
        )}
          {/* Fixed Bottom Buttons */}
          {/* Fixed Bottom Buttons */}
          <div 
            className={`fixed bottom-0 right-0 bg-white border-t border-gray-200 shadow-lg z-50 transition-all duration-300 ${
              isExpanded ? 'left-[250px]' : 'left-[70px]'
            }`}
          >
            <div className="flex justify-center p-2 gap-4">
              <button
                className="cancel-btn"
                onClick={handleCancel}
              >
                Cancel
              </button>
              <button
                className="save-btn"
                onClick={() => handleSave(isChecked || false)}
              >
                Save
              </button>
            </div>
          </div>
          
        {/* GL Code Management section */}
        <div>
          <div className="p-2">
            {/* <h3 className="tabs-sub-headings">Module Access</h3> */}
            <h3 className="tabs-sub-headings  !mb-0">GL Code Management section</h3>

          </div>
          <div className="relative">
            <div className="pr-4 pl-4 flex md:flex-row md:items-center md:justify-between space-y-2">
              <div className="flex  space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last ">
                {(
                  <WholeTableSearch
                    searchTerm={glSearchTerm}
                    setSearchTerm={setGLSearchTerm}
                    tableName={"GL Code Settings"}
                    headerMap={glHeaders}
                    selectedSubPartner={selectedSubPartner}
                    selectedPartner={selectedPartner}
                  />
                )}
                {(
                  <AdvancedMultiFilter2
                    showAdvanced={glShowAdvanced}
                    setShowAdvanced={setGLShowAdvanced}
                    onFilter={handleGLFilter}
                    onReset={handleGLReset}
                    headers={glHeaders}
                    headerMap={glHeaderMap}
                    tableName={"GL Code Settings"}
                    selectedSubPartner={selectedSubPartner}
                    selectedPartner={selectedPartner}
                  />
                )}
              </div>

              <div className="hidden md:flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2  md:order-none order-first pb-2 md:pb-4">
                {(
                  <button className="save-btn" onClick={handleCreateModalOpen}>
                    <PlusIcon className="h-5 w-5 text-black-500 mr-1" />
                    Create
                  </button>
                )}
                {/* 
                    {(
                      <button
                        className="save-btn"
                        onClick={handleCarrierMappingSave} // Show create user form on click
                      >
                        Save
                      </button>
                    )} */}
                {/* {(
                      <button className="save-btn"
                        onClick={() => {
                          if (!exports.some((exportItem: { popupHeading: string; }) => exportItem.popupHeading === "Partner Users")) {
                            handleExport("PrtnerUsers", "Partner Users");
                          }
                        }}>
                        <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                        <span>Export</span>
                      </button>
                    )} */}
                {/* <ColumnFilter headers={headers2} visibleColumns={visibleColumns} setVisibleColumns={setVisibleColumns} headerMap={moduleHeadersMap} /> */}
              </div>
            </div>
            <div className={`${glShowAdvanced ? "mt-[70px]" : ""}`}>
              <KillbillTableComponent
                headers={glHeaders}
                headerMap={glHeaderMap}
                initialData={glTableData}
                searchQuery={glSearchTerm}
                visibleColumns={glVisibleColumns}
                itemsPerPage={100}
                allowedActions={glAllowedActions}
                popupHeading="GL Code"
                pagination={glPagination}
                advancedFilters={glFilteredData}
                createModalData={glCreateModalData}
                generalFields={glGeneralFields}
                height={glShowAdvanced ? 380 : 320}
                selectedSubPartner={selectedSubPartner}
                selectedPartner={selectedPartner}
              />

              <CreateModal
                isOpen={isCreateModalOpen}
                onClose={handleCreateModalClose}
                onSave={handleCreateRow}
                modalData={glCreateModalData}
                title="GL Code"
                visible={isCreateModalOpen}
                action="create"
                generalFields={glGeneralFields}
                selectedSubPartner={selectedSubPartner}
                selectedPartner={selectedPartner}
              />
            </div>
          </div>
        </div>
        {/* Service Provider Settings section */}
        <div>
          <div className="p-2">
            <h3 className="tabs-sub-headings  !mb-0">Service Providers</h3>
          </div>
           <div className="relative">
            <div className="pr-4 pl-4 flex md:flex-row md:items-center md:justify-between space-y-2">
               <div className="flex  space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last ">
                {(
                  <TableSearch
                    searchTerm={spSearchTerm}
                    setSearchTerm={setSPSearchTerm}
                    tableName={"Billing Service Providers"}
                    headerMap={spHeaders}
                    selectedSubPartner={selectedSubPartner}
                    selectedPartner={selectedPartner}
                  />
                )}
                {(
                  <AdvancedMultiFilter
                    showAdvanced={spShowAdvanced}
                    setShowAdvanced={setSPShowAdvanced}
                    onFilter={handleSPFilter}
                    onReset={handleSPReset}
                    headers={spHeaders}
                    headerMap={spHeaderMap}
                    tableName={"Billing Service Providers"}
                    selectedSubPartner={selectedSubPartner}
                    selectedPartner={selectedPartner}
                  />
                )}
              </div>
              <div className="hidden md:flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2  md:order-none order-first pb-2 md:pb-4">
                {(
                  <button className="save-btn" onClick={() => setSPCreateModalOpen(true)}>
                    <PlusIcon className="h-5 w-5 text-black-500 mr-1" />
                    Create
                  </button>
                )}
              </div>
            </div>
            <div className={`${spShowAdvanced ? "mt-[70px]" : ""}`}>
              <BillingPlatformTableComponent2
                headers={spHeaders}
                headerMap={spHeaderMap}
                initialData={spTableData}
                searchQuery={spSearchTerm}
                visibleColumns={spVisibleColumns}
                itemsPerPage={100}
                allowedActions={spAllowedActions}
                popupHeading="Service Provider"
                pagination={spPagination}
                advancedFilters={spFilteredData}
                createModalData={spCreateModalData}
                generalFields={spGeneralFields}
                height={spShowAdvanced ? 380 : 320}
                selectedSubPartner={selectedSubPartner}
                selectedPartner={selectedPartner}
              />

              <CreateModal
                isOpen={isSPCreateModalOpen}
                onClose={handleCreateModalClose}
                onSave={handleCreateRow}
                modalData={spCreateModalData}
                title="Service Provider"
                visible={isSPCreateModalOpen}
                action="create"
                generalFields={spGeneralFields}
                selectedSubPartner={selectedSubPartner}
                selectedPartner={selectedPartner}
              />
            </div>
          </div>
        </div>
        <div style={{ height: "64px" }}>
 
        </div>
      </div>
    </div>
  );
};

export default BillingStatusSettings;
