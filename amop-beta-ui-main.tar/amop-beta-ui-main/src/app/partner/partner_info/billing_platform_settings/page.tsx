"use client";
import React, { Suspense, useEffect, useState } from "react";
import {
  DropdownStyles,
  NonEditableDropdownStyles,
} from "@/app/components/css/dropdown";
import Select, { SingleValue } from "react-select";
import BillingStatusSettings from "./billing_status_settings";
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import { Modal, Spin } from "antd";
import { useLogoStore } from "@/app/stores/logoStore";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";

const editableDrp = DropdownStyles;
const nonEditableDrp = NonEditableDropdownStyles;

const BillingPlatformSettings: React.FC = () => {
  const [partnersData, setPartnersData] = useState<Record<
    string,
    string[]
  > | null>(null);
  const [selectedPartner, setSelectedPartner] = useState<string>("");
  const [selectedSubPartner, setSelectedSubPartner] = useState<string>("");
  const [showUserRole, setShowUserRole] = useState<boolean>(false);
  const [subPartners, setSubPartners] = useState<string[]>([]);
  const [suspensionSettingsData, setSuspensionSettingsData] = useState(null);
  const [carrierMappingData, setCarrierMappingData] = useState(null);
  const [billingPlatformStatusData, setBillingPlatformStatusData] = useState(null);
  const [serviceLineDescription, setServiceLineDescription] = useState(null);
  const [loading, setLoading] = useState(true);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [rolesDataHeaders, setRolesDataHeaders] = useState<any[]>([]);
  const [moduleDataHeaders, setModuleDataHeaders] = useState<any[]>([]);
  const {
    username,
    partner,
    role,
    setSelectedPartnerModule,
    setSelectedEnvironment,
    token,metaData,
    selectedDb,selectedBillingDb, firstLastName, sessionId ,settabledata} = useAuth();
  const [rolesDataHeadersMap, setRolesDataHeadersMap] = useState<any>({});
  const [moduleDataHeadersMap, setModuleDataHeadersMap] = useState<any>({});
  const [partnerMenuIsOpen, setPartnerMenuIsOpen] = useState(false);
  const [subPartnerMenuIsOpen, setSubPartnerMenuIsOpen] = useState(false);
  const [isChecked, setIsChecked] = useState<boolean | null>(null);
  const [pagination1, setpagination1] = useState<any>({});
  const [pagination2, setpagination2] = useState<any>({});
  const setTitle = useLogoStore((state) => state.setTitle);
  const title = useLogoStore((state) => state.title);

  const fetchInitialData = async () => {
    settabledata([])
    setLoading(true);
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/bp_settings_list_view",
        role_name: role,
        parent_module: "Partner Info",
        module_name: "Billing Settings",
        flag: "withoutparameters",
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
          ...metaData,
          billing_db_name:selectedBillingDb,
        sessionID: sessionId,
         mod_pages: {
          start: 0,
          end: 6,
        },
      };
      console.log(getCurrentDateTime(),"Show the log time request sent from ui to lambda");
      const response = await axios.post(url, { data });
      const resp = JSON.parse(response.data.body);
      console.log(getCurrentDateTime(),"Show the log time response sent from lambda to ui");
      console.log(resp);
      // Check if the flag is false
      if (resp.flag === false) {
        Modal.warning({
          title: "Permission Denied",
          content:
            resp.message ||
            "An error occurred while fetching initial data. Please try again.",
          centered: true,
        });
        return; // Exit early if there's an error
      }

      console.log("Environment:", resp.data.partners_and_sub_partners);
      setPartnersData(resp.data.partners_and_sub_partners);
      // console.log("Roles:", resp.headers_map.Roles);
      // console.log("Modules:", resp.headers_map.Modules);
      // setRolesDataHeaders(resp.headers_map.Roles)
      // setModuleDataHeaders(resp.headers_map.Modules)
    } catch (err) {
      console.error("Error fetching initial data:", err);
      Modal.error({
        title: "Data Fetch Error",
        content:
          err instanceof Error
            ? err.message
            : "An unexpected error occurred while fetching initial data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  type HeaderMap = Record<string, [string, number]>;

  const sortHeaderMap = (headerMap: HeaderMap): HeaderMap => {
    // Convert the object to an array of [key, value] pairs
    const entries = Object.entries(headerMap) as [string, [string, number]][];

    // Sort the array based on the second item of each value
    entries.sort((a, b) => a[1][1] - b[1][1]);

    // Convert the sorted array back to an object
    return Object.fromEntries(entries) as HeaderMap;
  }; // Add dependencies if necessary

  const PartnersData = partnersData || {};
  const Partneroptions = Object.keys(PartnersData).map((partner) => ({
    value: partner,
    label: partner,
  }));
  const subPartnersoptions = subPartners.map((subPartner) => ({
    value: subPartner,
    label: subPartner,
  }));
  const subPartnersnoOptions = [
    { value: "", label: "No sub-partners available" },
  ];

  const fetchData = async (
    selectedPartner: string,
    selectedSubPartner: string
  ) => {
    setLoading(true);
    settabledata([]);
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/bp_settings_list_view",
        role_name: role,
        parent_module: "Partner Info",
        module_name: "Billing Settings",
        flag: "withparameters",
        Selected_Partner: selectedPartner,
        sub_partner: selectedSubPartner,
        // modules: ["role partner module", "partner module"],
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
          ...metaData,
          billing_db_name:selectedBillingDb,
        sessionID: sessionId,
         mod_pages: {
          start: 0,
          end: 6,
        },
        col_sort: {
          "service_provider_name": "asc",       
          },
        // Send selected sub-partner
      };
      console.log(getCurrentDateTime(),"Show the log time request sent from ui to lambda");
      const response = await axios.post(url, { data });
      const resp = JSON.parse(response.data.body);
    //   console.log(getCurrentDateTime(),"Show the log time response sent from lambda to ui");
      // Check if the flag is false
      if (resp.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            resp.message ||
            "An error occurred while fetching Data. Please try again.",
          centered: true,
        });
        setShowUserRole(false);
        return; // Exit early if there's an error
      }
      console.log("response",resp)
      setSuspensionSettingsData(resp.data.billing_platform_suspend);
      setCarrierMappingData(resp.data.billing_platform_status);
      setBillingPlatformStatusData(resp.billing_platfrom_enable_flag);
      setServiceLineDescription(resp?.data.service_line_description)

      const headerMap1 = resp.headers_map["Suspension Settings Data"]["header_map"];
      const headerMap2 = resp.headers_map["Carrier Mapping Data"]["header_map"];
      const sortedheaderMap1 = sortHeaderMap(headerMap1);
      const sortedheaderMap2 = sortHeaderMap(headerMap2);
      setRolesDataHeadersMap(sortedheaderMap1);
      setModuleDataHeadersMap(sortedheaderMap2);
      const headers1 = Object.keys(sortedheaderMap1);
      const headers2 = Object.keys(sortedheaderMap2);
      setLoading(false);
      setModuleDataHeaders(headers2);
      setRolesDataHeaders(headers1);
      setpagination1(resp?.["pages_data_suspend"]||{});
      setpagination2(resp?.["pages_data_status"]||{});
      setShowUserRole(true);
    } catch (err) {
      console.error("Error fetching data:", err);
      Modal.error({
        title: "Data Fetch Error",
        content:
          err instanceof Error
            ? err.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
      setShowUserRole(false);
    } finally {
      setLoading(false);
    }
  };
  const handleCancel = () => {
    setShowUserRole(false);
    setSelectedPartner("");
    setSelectedSubPartner("");
    setSubPartners([]);
    setSelectedPartnerModule("");
    setSelectedEnvironment("");
  };

  useEffect(() => {
    fetchInitialData();
  }, []);

  useEffect(() => {
    const handleScroll = () => {
      setPartnerMenuIsOpen(false);
      setSubPartnerMenuIsOpen(false);
    };

    window.addEventListener("scroll", handleScroll);

    // Cleanup event listener on component unmount
    return () => {
      window.removeEventListener("scroll", handleScroll);
    };
  }, []);

  const handlePartnerChange = (
    selectedOption: { value: string; label: string } | null
  ) => {
    if (selectedOption) {
      const partner = selectedOption.value;
      setSelectedPartner(partner);
      setSelectedPartnerModule(partner);
      setPartnerMenuIsOpen(false);
      setSubPartners(PartnersData[partner] || []);
      fetchData(partner, ""); // Fetch data with the selected partner and no sub-partner
      setSelectedSubPartner(""); // Reset selected sub-partner when partner changes
    } else {
      setSelectedPartner("");
      setSubPartners([]);
    }
  };

  const handleSubpartnerChange = (
    selectedOption: { value: string; label: string } | null
  ) => {
    if (selectedOption) {
      const subPartner = selectedOption.value;

      setSelectedSubPartner(subPartner);
      console.log(subPartner);
      setSelectedEnvironment(subPartner);
      setSubPartnerMenuIsOpen(false);
      fetchData(selectedPartner, subPartner); // Fetch data with the selected partner and sub-partner
    } else {
      setSelectedSubPartner("");
    }
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  const handlePartnerBlur = () => {
    setPartnerMenuIsOpen(false);
  };

  const handlePartnerFocus = () => {
    setPartnerMenuIsOpen(true);
  };

  const handleSubPartnerBlur = () => {
    setSubPartnerMenuIsOpen(false);
  };

  const handleSubPartnerFocus = () => {
    setSubPartnerMenuIsOpen(true);
  };

  const ClearData = () => {
    setSelectedPartner("");
    setSelectedSubPartner("");
    setShowUserRole(false);
  };



  return (
    <Suspense
      fallback={
        <div className="flex justify-center items-center h-screen">
          <Spin size="large" />
        </div>
      }
    >
      <div className="">
        {/* <div className="p-3 pl-2 pr-2">
          <h3 className="tabs-sub-headings">Partner Modules</h3>
        </div> */}
        <div className="gap-4 p-4 pt-1">
          <div className="flex flex-col md:flex-row items-center md:items-end gap-4 flex-wrap">
            <div className="w-[320px]">
              <label className="field-label">Partner</label>
              <Select
                value={
                  Partneroptions.find(
                    (option) => option.value === selectedPartner
                  ) || null
                }
                onChange={handlePartnerChange}
                options={Partneroptions}
                menuIsOpen={partnerMenuIsOpen}
                onFocus={handlePartnerFocus}
                onBlur={handlePartnerBlur}
                blurInputOnSelect
                styles={editableDrp}
                isClearable
              />
            </div>
            <div className="w-[320px]">
              <label className="field-label">Sub Partner</label>
              <Select
                value={
                  subPartnersoptions.find(
                    (option) => option.value === selectedSubPartner
                  ) || null
                }
                onChange={handleSubpartnerChange}
                options={
                  subPartners.length > 0
                    ? subPartnersoptions
                    : subPartnersnoOptions
                }
                menuIsOpen={subPartnerMenuIsOpen}
                onFocus={handleSubPartnerFocus}
                onBlur={handleSubPartnerBlur}
                blurInputOnSelect
                className="mt-1"
                styles={editableDrp}
                isClearable
              />
            </div>
            {/* <div className="flex  justify-center items-center gap-4">
              <button
                className={`save-btn mt-7 ${!selectedPartner && !selectedSubPartner ? "cursor-not-allowed" : ""
                  }`}
                type="button" // Change to "button" to prevent default form submission
                onClick={() => fetchData(selectedPartner, selectedSubPartner)}
                disabled={!selectedPartner && !selectedSubPartner}
              >
                Submit
              </button>
              <button
                className={`save-btn mt-7 ${!selectedPartner && !selectedSubPartner ? "cursor-not-allowed" : ""
                  }`}
                type="submit"
                onClick={() => ClearData()}
                disabled={!selectedPartner && !selectedSubPartner}
              >
                Clear
              </button>
            </div> */}
          </div>
         

        </div>
        {showUserRole && (
          <BillingStatusSettings
            popupHeading = {'Billing Settings'}
            suspensionSettingsData={suspensionSettingsData}
            carrierMappingData={carrierMappingData}
            rolesHeaders={rolesDataHeaders}
            moduleHeaders={moduleDataHeaders}
            rolesHeadersMap={rolesDataHeadersMap}
            moduleHeadersMap={moduleDataHeadersMap}
            suspensionPagination = {pagination1}
            statusPagination = {pagination2}
            selectedSubPartner = {selectedSubPartner}
            selectedPartner={selectedPartner}
            fetchData={fetchData}
            handleCancel={() => {handleCancel()}}
            billingPlatformStatusData={billingPlatformStatusData}
            service_line_description={serviceLineDescription}
          />
        )}
        
      </div>
    </Suspense>
  );
};

export default BillingPlatformSettings;
