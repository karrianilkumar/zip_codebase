"use client";

import {
  createCarrierCredentialConfig,
  getCarrierCredentialConfig,
  updateCarrierCredentialConfig,
} from "@/api/carrier-credential-config-api";
import { useCarrierCredentialStore } from "@/stores/carrier-credential-store";
import { CarrierType } from "@/types/carrier-config.types";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Alert, Button, Form, message, Select, Spin } from "antd";
import React, { useEffect, useState } from "react";
import BECForm from "./components/bec-form";
import PeplinkForm from "./components/peplink-form";
import { CONFIGURABLE_CARRIER_CONFIGS } from "./config";

const { Option } = Select;

const CarrierConfig: React.FC = () => {
  const [activeKey, setActiveKey] = useState(CarrierType.Peplink);
  const [loading, setLoading] = useState(true);
  const [form] = Form.useForm();
  const { setId, existConfig, setExistConfig } = useCarrierCredentialStore();
  const [addNew, setAddNew] = useState<boolean>(false);

  const { data, error } = useQuery({
    queryKey: ["carrier-config", activeKey],
    queryFn: () =>
      getCarrierCredentialConfig({
        type: activeKey,
      }),
  });

  const createCarrierConfigMutation = useMutation({
    mutationFn: createCarrierCredentialConfig,
    onSuccess: () => {
      message.success("Configuration saved successfully");
    },
    onError: (error) => {
      message.error(
        error instanceof Error ? error.message : "Failed to save configuration",
      );
    },
  });

  const updateCarrierCredentialConfigMutation = useMutation({
    mutationFn: updateCarrierCredentialConfig,
    onSuccess: () => {
      message.success("Configuration updated successfully");
    },
    onError: (error) => {
      message.error(
        error instanceof Error
          ? error.message
          : "Failed to update configuration",
      );
    },
  });

  useEffect(() => {
    if (data && Object.keys(data).length > 0) {
      form.setFieldsValue({
        ...data,
        clientSecret: data.password,
        clientId: data.username,
      });
      setId(data._id);
      setExistConfig(true);
    } else if (data !== undefined) {
      setExistConfig(false);
    }
    setLoading(false);
  }, [data, form, setId, setExistConfig]);

  const onFinishFailed = (errorInfo: any) => {
    message.error(`Failed: ${errorInfo}`);
  };

  if (error) {
    return (
      <Alert message="Error" description={`Error: ${error}`} type="error" />
    );
  }

  const renderForm = () => {
    switch (activeKey) {
      case CarrierType.Peplink:
        return (
          <PeplinkForm
            form={form}
            onFinishFailed={onFinishFailed}
            createCarrierConfigMutation={createCarrierConfigMutation}
            updateCarrierCredentialConfigMutation={
              updateCarrierCredentialConfigMutation
            }
          />
        );
      case CarrierType.BEC:
        return <BECForm form={form} />;
      default:
        return null;
    }
  };

  return (
    <div className="container p-4 h-screen">
      {loading ? (
        <div className="flex items-center justify-center h-full">
          <Spin />
        </div>
      ) : (
        <div className="mx-auto h-full w-full md:w-1/2">
          <Form
            form={form}
            layout="horizontal"
            labelCol={{ span: 8 }}
            wrapperCol={{ span: 16 }}
            colon={false}
            onFinishFailed={onFinishFailed}
          >
            <Form.Item
              label="Integration Type"
              wrapperCol={{ span: 16 }}
              labelCol={{ span: 8 }}
            >
              <Select defaultValue={activeKey} onChange={setActiveKey}>
                {Object.values(CarrierType).map((type) => (
                  <Option key={type} value={type}>
                    {type}
                  </Option>
                ))}
              </Select>
            </Form.Item>
            {existConfig === null && (
              <div className="flex justify-center">
                <Spin />
              </div>
            )}
            {CONFIGURABLE_CARRIER_CONFIGS.includes(activeKey) &&
              existConfig === false && (
                <>
                  <Alert
                    message="No Configuration Found"
                    description={`Please create a new configuration for ${activeKey} to sync devices.`}
                    type="error"
                    icon={true}
                    className="mb-4"
                  />
                  {!addNew && (
                    <Button
                      type="primary"
                      onClick={() => {
                        setAddNew(true);
                      }}
                    >
                      Create New Configuration
                    </Button>
                  )}
                </>
              )}
            {renderForm()}
            <Form.Item wrapperCol={{ offset: 8, span: 16 }}>
              <Button type="primary" htmlType="submit">
                Save
              </Button>
            </Form.Item>
          </Form>
        </div>
      )}
    </div>
  );
};

export default CarrierConfig;
