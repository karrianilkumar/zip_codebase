import { useCarrierCredentialStore } from "@/stores/carrier-credential-store";
import { CarrierType, PepLinkFormValues } from "@/types/carrier-config.types";
import { Form, Input, Tooltip } from "antd";
import React, { useState } from "react";
import { InfoCircleOutlined } from "@ant-design/icons";

interface PeplinkFormProps {
  form: any;
  onFinishFailed: (errorInfo: any) => void;
  createCarrierConfigMutation: any;
  updateCarrierCredentialConfigMutation: any;
}

const PeplinkForm: React.FC<PeplinkFormProps> = ({
  form,
  onFinishFailed,
  createCarrierConfigMutation,
  updateCarrierCredentialConfigMutation,
}) => {
  const { id, existConfig, setExistConfig } = useCarrierCredentialStore();

  const onFinish = (values: PepLinkFormValues) => {
    if (createCarrierConfigMutation.isLoading) {
      return;
    }

    const payload: any = {
      url: values.url,
      organizationId: values.organizationId,
      type: CarrierType.Peplink,
      name: CarrierType.Peplink,
    };

    const { clientId, clientSecret } = values;

    if (clientId) {
      payload.username = clientId;
    }

    if (clientSecret) {
      payload.password = clientSecret;
    }

    if (!id) {
      createCarrierConfigMutation.mutate(payload);
      setExistConfig(true);
    } else {
      updateCarrierCredentialConfigMutation.mutate({
        ...payload,
        id: id,
      });
    }
  };

  return (
    <Form<PepLinkFormValues>
      form={form}
      name="peplink"
      onFinish={onFinish}
      onFinishFailed={onFinishFailed}
      layout="horizontal"
      labelCol={{ span: 8 }}
      wrapperCol={{ span: 16 }}
      colon={false}
    >
      <Tooltip
        title="This field is read-only and can only be written to. Once set, it cannot be read."
        placement="right"
      >
        <Form.Item
          label="Client ID"
          name="clientId"
          rules={[
            {
              required: !existConfig,
              message: "Please input your Client ID!",
            },
          ]}
        >
          <Input.Password
            className="w-full md:w-1/2"
            autoComplete="new-password"
            suffix={<InfoCircleOutlined />}
            placeholder={existConfig ? "********" : ""}
          />
        </Form.Item>
      </Tooltip>
      <Tooltip
        title="This field is read-only and can only be written to. Once set, it cannot be read."
        placement="right"
      >
        <Form.Item
          label="Client Secret"
          name="clientSecret"
          rules={[
            {
              required: !existConfig,
              message: "Please input your Client Secret!",
            },
          ]}
        >
          <Input.Password
            className="w-full md:w-1/2"
            autoComplete="new-password"
            placeholder={existConfig ? "********" : ""}
          />
        </Form.Item>
      </Tooltip>
      <Form.Item
        label="URL"
        name="url"
        rules={[{ required: !existConfig, message: "Please input your URL!" }]}
      >
        <Input className="w-full md:w-1/2" autoComplete="new-password" />
      </Form.Item>
      <Form.Item
        label="Organization ID"
        name="organizationId"
        rules={[
          {
            required: !existConfig,
            message: "Please input your Organization ID!",
          },
        ]}
      >
        <Input className="w-full md:w-1/2" autoComplete="new-password" />
      </Form.Item>
    </Form>
  );
};

export default PeplinkForm;
