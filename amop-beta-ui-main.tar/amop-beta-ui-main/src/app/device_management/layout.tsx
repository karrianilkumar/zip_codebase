"use client";

import { useQuery } from "@tanstack/react-query";
import { TABLE_QUERY_KEY } from "@/common/constants/table-constants";
import useInventoryTableStore from "@/stores/inventory-table-store";
import useProvisionTableStore from "@/stores/provision-table-store";
import useModelChartStore from "@/stores/model-chart-store";
import { getInventoryItemOptions } from "@/api/device-api";
import {
  mappingFilterDataToInventoryColumns,
  mappingFilterDataToProvisionColumns,
} from "@/common/helper/table-helper";
import { ReactNode } from "react";

export default function DeviceManagementLayout({
  children,
}: {
  children: ReactNode;
}) {
  useLoadInitialData();
  return <div className="p-6 adm-wrapper">{children}</div>;
}

function useLoadInitialData() {
  const { setInventoryTableColumns } = useInventoryTableStore();
  const { setProvisionTableColumns } = useProvisionTableStore();
  const { setManufacturerModels } = useModelChartStore();

  useQuery({
    queryKey: [TABLE_QUERY_KEY.INVENTORY_COLUMNS_DATA],
    queryFn: async () => {
      try {
        const data = await getInventoryItemOptions();
        setManufacturerModels(data?.manufacturerModels || []);
        let mappedFilterDataInventoryColumns =
          mappingFilterDataToInventoryColumns(data);
        let mappedFilterDataProvisionColumns =
          mappingFilterDataToProvisionColumns(data);
        setInventoryTableColumns(mappedFilterDataInventoryColumns);
        setProvisionTableColumns(mappedFilterDataProvisionColumns);
        return data;
      } catch (error) {
        throw error;
      }
    },
    staleTime: 1000 * 60 * 5,
  });
}
