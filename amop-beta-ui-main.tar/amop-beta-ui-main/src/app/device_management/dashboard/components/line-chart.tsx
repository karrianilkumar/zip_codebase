"use client";

import React, { useState } from "react";
import {
  LineChartType,
  getSeries,
} from "@/common/constants/line-chart-constants";
import { Button, Select } from "antd";
import dynamic from "next/dynamic";
import type { ApexOptions } from "apexcharts";
import { DownloadOutlined, QuestionCircleOutlined } from "@ant-design/icons";
import { MultipleSelect } from "./multiple-select-model-chart";
import { lineChartExport } from "@/lib/xlsx";
import { formatByGranularity } from "@/common/helper/line-chart-helper";
import { CustomPopover } from "@/components/custom-popover";

const Chart = dynamic(() => import("react-apexcharts"), { ssr: false });

type Props = {
  data: LineChartType[];
  title?: string;
  tooltipDesc?: string;
  type?: string;
  handleChangeTime?: (value: string) => void;
  handleChangeFilter?: (value: string[]) => void;
  granularity?: "hour" | "day" | "month" | (string & {});
};

export const LineChart: React.FC<Props> = ({
  data,
  title = "",
  type = "",
  tooltipDesc = "",
  handleChangeTime,
  handleChangeFilter,
  granularity = "month",
}) => {
  /**
   * ApexChart does not re-render when the granularity changes,
   * so we need to use useRef to store the value of granularity
   * and use it in the formatter function of `xaxis.labels`
   */
  const granularityRef = React.useRef(granularity);
  granularityRef.current = granularity;

  const [openTip, setOpenTip] = useState(false);

  const handleChangeTimeLine = (value: string) => {
    if (handleChangeTime) {
      handleChangeTime(value);
    }
  };

  const handleChangeFilters = (value: string[]) => {
    if (handleChangeFilter) {
      handleChangeFilter(value);
    }
  };

  const options: ApexOptions = {
    chart: {
      id: "basic-bar",
    },
    xaxis: {
      type: "datetime",
      max: new Date().getTime(),
      labels: {
        formatter(_, timestamp) {
          return formatByGranularity(timestamp, granularityRef.current);
        },
      },
    },
    yaxis: {
      labels: {
        formatter: (value) => {
          return value?.toFixed(0);
        },
      },
    },
    stroke: {
      curve: "smooth",
      width: 4,
    },
    responsive: [],
  };

  const series = getSeries(data);

  const handleClickExport = async () => {
    lineChartExport(title.split(" ").join("-"), data, granularity);
  };

  return (
    <div>
      <div className="shadow-lg rounded-lg h-auto bg-white py-[0.8rem] px-4 overflow-hidden mb-4">
        {title.length ? (
          <div className="sm:text-lg md:text-xl lg:text-2xl font-medium my-2 pl-2">
            {title}
            <CustomPopover
              open={openTip}
              onOpenChange={() => setOpenTip(true)}
              content={tooltipDesc}
              title={title}
              handleClose={() => setOpenTip(false)}
            >
              <QuestionCircleOutlined
                className="pl-2 translate-y-[-2px] text-[1rem] cursor-pointer"
                style={{ color: "gray" }}
              />
            </CustomPopover>
          </div>
        ) : (
          ""
        )}
        <div className="select-none pl-2 flex flex-wrap gap-2">
          <Button
            icon={<DownloadOutlined />}
            type="primary"
            onClick={handleClickExport}
          >
            Export
          </Button>
          <Select
            defaultValue="month"
            style={{ width: 120 }}
            onChange={handleChangeTimeLine}
            options={[
              { value: "hour", label: "Hour" },
              { value: "day", label: "Day" },
              { value: "month", label: "Month" },
            ]}
          />
          {type === "multiple" ? (
            <div style={{ flex: "1 1 300px" }}>
              <MultipleSelect onSelect={handleChangeFilters} />
            </div>
          ) : (
            ""
          )}
        </div>
        <Chart options={options} series={series} type="line" />
      </div>
    </div>
  );
};
