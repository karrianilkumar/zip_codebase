"use client";

import React, { useEffect, useState } from "react";
import { LineChart } from "./line-chart";
import { DeviceManagementStatisticTimeDataType } from "@/types/statistic-time-types";
import { getTotalByTimeData } from "@/api/statistic-api";
import { useQuery } from "@tanstack/react-query";
import { LineChartType } from "@/common/constants/line-chart-constants";
import {
  calculateLineChartDataWithTimeType,
  mappingKeyNameForLicenseChart,
} from "@/common/helper/line-chart-helper";

export const QuantityLicenseChart: React.FC = () => {
  const [chartData, setChartData] = useState<LineChartType[]>([]);
  const [paramState, setParamState] = useState({ granularity: "month" });

  const handleChangeTime = (value: string) => {
    setParamState({
      granularity: value,
    });
  };

  const { data } = useQuery({
    queryKey: ["license-statistic-time-data", paramState],
    queryFn: async () => {
      const data = await getTotalByTimeData({
        type: "devices_by_license_status",
        ...paramState,
      });
      return data as DeviceManagementStatisticTimeDataType[];
    },
    staleTime: 1000 * 60 * 5,
    retry: 1,
  });

  useEffect(() => {
    let calculatedData = mappingKeyNameForLicenseChart(
      calculateLineChartDataWithTimeType(data),
    );
    setChartData(calculatedData);
  }, [data]);

  return (
    <LineChart
      data={chartData}
      granularity={paramState.granularity}
      title="Quantity Licenses Available"
      handleChangeTime={handleChangeTime}
    />
  );
};
