"use client";

import type { ApexOptions } from "apexcharts";
import React from "react";
import dynamic from "next/dynamic";

const Chart = dynamic(() => import("react-apexcharts"), { ssr: false });

type Props = {
  onChooseStatus: (value: string) => void;
  expiredQuantity: number;
  expiredInDaysQuantity: number;
  activeQuantity: number;
};

export const DonutChart: React.FC<Props> = ({
  onChooseStatus,
  expiredQuantity,
  expiredInDaysQuantity,
  activeQuantity,
}) => {
  const series = [activeQuantity, expiredInDaysQuantity, expiredQuantity];

  const options: ApexOptions = {
    chart: {
      type: "donut",
      events: {
        dataPointSelection: (event, chartContext, config) => {
          onChooseStatus(
            config.w.config.labels[config.selectedDataPoints[0]] || "",
          );
        },
      },
    },
    labels: ["Active", "Expired In 30 Days", "Expired"],
    colors: ["#00c057eb", "#f5d700", "#ff0000"],
    plotOptions: {
      pie: {
        donut: {
          labels: {
            show: true,
            total: {
              show: true,
              color: "black",
            },
          },
        },
      },
    },
    legend: {
      position: "right",
      onItemClick: {
        toggleDataSeries: false,
      },
    },
    responsive: [
      {
        breakpoint: 480,
        options: {
          legend: {
            position: "bottom",
            onItemClick: {
              toggleDataSeries: false,
            },
          },
        },
      },
    ],
  };
  return (
    <div style={{ display: "flex", justifyContent: "center" }}>
      <div className="py-1 w-full max-w-500 min-h-430">
        <Chart options={options} series={series} type="donut" />
      </div>
    </div>
  );
};
