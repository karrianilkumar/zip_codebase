"use client";

import React, { useState } from "react";
import { Button, Select } from "antd";
import dynamic from "next/dynamic";
import type { ApexOptions } from "apexcharts";
import { DownloadOutlined, QuestionCircleOutlined } from "@ant-design/icons";
import { MultipleSelect } from "./multiple-select-model-chart";
import { CustomPopover } from "@/components/custom-popover";
import { getBarChartSeries } from "@/common/helper/bar-chart-helper";
import { DeviceManagementStatisticTimeDataType } from "@/types/statistic-time-types";
import { barChartExport, lineChartExport } from "@/lib/xlsx";
import { formatByGranularity } from "@/common/helper/line-chart-helper";
import { MultipleSelectManufacture } from "./multiple-select-manufacture";

const Chart = dynamic(() => import("react-apexcharts"), { ssr: false });

type Props = {
  data: DeviceManagementStatisticTimeDataType[];
  title?: string;
  tooltipDesc?: string;
  type?: string;
  handleChangeTime?: (value: string) => void;
  handleChangeFilter?: (value: string[]) => void;
  granularity: "hour" | "day" | "month" | (string & {});
};

export const BarChart: React.FC<Props> = ({
  data,
  title = "",
  type = "",
  tooltipDesc = "",
  handleChangeTime,
  handleChangeFilter,
  granularity = "hour",
}) => {
  const [openTip, setOpenTip] = useState(false);

  const handleChangeTimeLine = (value: string) => {
    if (handleChangeTime) {
      handleChangeTime(value);
    }
  };

  const handleChangeFilters = (value: string[]) => {
    if (handleChangeFilter) {
      handleChangeFilter(value);
    }
  };

  const seriesData = getBarChartSeries(data);

  const handleClickExport = async () => {
    barChartExport(
      title.split(" ").join("-"),
      seriesData.data,
      granularity,
      seriesData.categories,
    );
  };

  const options: ApexOptions = {
    chart: {
      id: "bar",
    },
    plotOptions: {
      bar: {
        dataLabels: {
          position: "top",
        },
      },
    },
    dataLabels: {
      enabled: true,
      offsetX: -6,
      style: {
        fontSize: "12px",
        colors: ["#fff"],
      },
    },
    tooltip: {
      shared: true,
      intersect: false,
    },
    xaxis: {
      categories: seriesData?.categories,
      labels: {
        formatter: (value: any) => {
          return formatByGranularity(value, granularity);
        },
      },
    },
  };

  return (
    <div>
      <div className="shadow-lg rounded-lg h-auto bg-white py-[0.8rem] px-4 overflow-hidden mb-4">
        {title.length ? (
          <div className="sm:text-lg md:text-xl lg:text-2xl font-medium my-2 pl-2">
            {title}
            <CustomPopover
              open={openTip}
              onOpenChange={() => setOpenTip(true)}
              content={tooltipDesc}
              title={title}
              handleClose={() => setOpenTip(false)}
            >
              <QuestionCircleOutlined
                className="pl-2 translate-y-[-2px] text-[1rem] cursor-pointer"
                style={{ color: "gray" }}
              />
            </CustomPopover>
          </div>
        ) : (
          ""
        )}
        <div className="select-none pl-2 flex flex-wrap gap-2">
          <Button
            icon={<DownloadOutlined />}
            type="primary"
            onClick={handleClickExport}
          >
            Export
          </Button>
          <Select
            defaultValue="month"
            style={{ width: 120 }}
            onChange={handleChangeTimeLine}
            options={[
              { value: "hour", label: "Hour" },
              { value: "day", label: "Day" },
              { value: "month", label: "Month" },
            ]}
          />
          {type === "multiple" ? (
            <div style={{ flex: "1 1 300px" }}>
              <MultipleSelect onSelect={handleChangeFilters} />
            </div>
          ) : (
            ""
          )}
          {type === "network" ? (
            <div style={{ flex: "1 1 300px" }}>
              <MultipleSelectManufacture onSelect={handleChangeFilters} />
            </div>
          ) : (
            ""
          )}
        </div>
        <Chart options={options} series={seriesData.data} type="bar" />
      </div>
    </div>
  );
};
