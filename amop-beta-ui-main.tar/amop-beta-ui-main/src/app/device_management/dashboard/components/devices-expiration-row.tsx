"use client";

import { getDeviceManufacture, getInventoryData } from "@/api/device-api";
import { LAST_CONNECT_DESC_PARAM } from "@/common/constants/inventory-constants";
import { getAlertType } from "@/common/helper/donut-chart-helper";
import {
  convertToInventoryTableData,
  getDonutChartTableColumns,
  mapManufactureData,
} from "@/common/helper/table-helper";
import { CustomPopover } from "@/components/custom-popover";
import { inventoryTableExport, InventoryTableExportProps } from "@/lib/xlsx";
import useInventoryTableStore from "@/stores/inventory-table-store";
import { DownloadOutlined, QuestionCircleOutlined } from "@ant-design/icons";
import { useQuery } from "@tanstack/react-query";
import {
  Alert,
  Button,
  Col,
  message,
  notification,
  Pagination,
  Row,
  Table,
} from "antd";
import React, { useEffect, useState } from "react";
import { DonutChart } from "./donut-chart";
import { LastUpdated } from "@/app/device_management/components/last-updated";

const tooltipContent = (
  <>
    <p>This table shows the devices expiration status.</p>
    <p>
      The donut chart shows the number of devices with different expiration
      status.
    </p>
    <p>Click on the donut chart to filter the table by license status.</p>
  </>
);

const title = "Devices Expiration";

type ParamState = {
  licenseStatus?: string;
};

export const DevicesExpirationRow: React.FC = () => {
  const [api, contextHolder] = notification.useNotification({
    maxCount: 1,
    placement: "bottomRight",
  });

  const [pageSize, setPageSize] = useState(20);
  const [currentPage, setCurrentPage] = useState(1);
  const [paramState, setParamState] = useState<ParamState>({});
  const [openTip, setOpenTip] = useState(false);

  const { inventoryTableColumns } = useInventoryTableStore();

  const donutChartTableColumns = getDonutChartTableColumns(
    inventoryTableColumns,
  );

  const handleClickExport = async () => {
    let exportProps: InventoryTableExportProps = {
      fileName: "Device-Expiration",
      visibleColumns: donutChartTableColumns,
      paramState,
    };
    let exportResult = await inventoryTableExport(exportProps);
    if (exportResult === undefined) {
      api.error({
        message: `Error`,
        description: "Failed to export to XLSX file",
        duration: 4,
      });
    }
    if (exportResult?.length) {
      api.success({
        message: `Success`,
        description: `Export file successfully with name ${exportResult}.xlsx`,
        duration: 4,
      });
    }
  };

  const { data: deviceManufactureList } = useQuery({
    queryKey: ["deviceManufacture"],
    queryFn: async () => {
      try {
        const data = await getDeviceManufacture();
        return data.results;
      } catch (error) {
        message.error("Failed to get device manufacture list");
      }
    },
  });

  const {
    data: allData,
    isLoading,
    dataUpdatedAt,
    isError: allDataIsError,
  } = useQuery({
    queryKey: ["deviceInventoryDonutChart", pageSize, currentPage, paramState],
    queryFn: async () => {
      let data = await getInventoryData({
        page: currentPage,
        limit: pageSize,
        sort: LAST_CONNECT_DESC_PARAM,
        ...paramState,
      });
      if (data && data.results) {
        data.results = mapManufactureData(data.results, deviceManufactureList);
      }
      return data;
    },
    staleTime: 1000 * 60 * 5,
  });

  const { data: activeQuantity, isError: isErrorActiveData } = useQuery({
    queryKey: ["deviceInventoryDonutChartActive"],
    queryFn: async () => {
      const data = await getInventoryData({
        licenseStatus: "Active",
      });
      return data?.totalResults as number;
    },
    staleTime: 1000 * 60 * 5,
  });

  const { data: expiredInDaysQuantity, isError: isErrorExpiredInDaysData } =
    useQuery({
      queryKey: ["deviceInventoryDonutChartExpiredIn"],
      queryFn: async () => {
        const data = await getInventoryData({
          licenseStatus: "Expired In 30 Days",
        });
        return data?.totalResults as number;
      },
      staleTime: 1000 * 60 * 5,
    });

  const { data: expiredQuantity, isError: isErrorExpiredData } = useQuery({
    queryKey: ["deviceInventoryDonutChartExpired"],
    queryFn: async () => {
      const data = await getInventoryData({
        licenseStatus: "Expired",
      });
      return data?.totalResults as number;
    },
    staleTime: 1000 * 60 * 5,
  });

  const handleClickChart = (value: string) => {
    setPageSize(20);
    setCurrentPage(1);
    if (value === "") {
      setParamState((oldState) => ({
        ...oldState,
        licenseStatus: undefined,
      }));
    } else {
      setParamState((oldState) => ({
        ...oldState,
        licenseStatus: value,
      }));
    }
  };

  const handlePageSizeChange = (
    currentPage: number,
    selectedPageSize: number,
  ) => {
    setPageSize(selectedPageSize);
  };

  const handlePageChange = (selectedPage: number, currentPageSize: number) => {
    setCurrentPage(selectedPage);
  };

  useEffect(() => {
    if (
      allDataIsError ||
      isErrorActiveData ||
      isErrorExpiredInDaysData ||
      isErrorExpiredData
    ) {
      api.error({
        message: `Oups! Something went wrong!`,
        description:
          "We encountered an error when trying to get the data from server",
        duration: 4,
      });
    }
  }, [
    allDataIsError,
    isErrorActiveData,
    isErrorExpiredInDaysData,
    isErrorExpiredData,
    api,
  ]);

  const alertConfig = getAlertType(paramState?.licenseStatus || "");

  return (
    <div className="shadow-lg rounded-lg py-[0.8rem] px-4 mb-4 overflow-hidden bg-white">
      {contextHolder}
      <div className="flex justify-between items-center">
        <div className="sm:text-lg md:text-xl lg:text-2xl xl:text-3xl font-medium my-2 pl-2">
          {title}
          <CustomPopover
            open={openTip}
            onOpenChange={() => setOpenTip(true)}
            content={tooltipContent}
            title={title}
            handleClose={() => setOpenTip(false)}
          >
            <QuestionCircleOutlined
              className="pl-2 translate-y-[-2px] text-[1rem] cursor-pointer"
              style={{ color: "gray" }}
            />
          </CustomPopover>
        </div>
        <Button
          className="ml-2"
          type="primary"
          icon={<DownloadOutlined />}
          onClick={handleClickExport}
        >
          Export
        </Button>
      </div>
      <Row gutter={16}>
        <Col xs={24} xl={10} className="flex flex-col">
          <div className="mb-auto">
            <DonutChart
              onChooseStatus={handleClickChart}
              expiredQuantity={expiredQuantity || 0}
              expiredInDaysQuantity={expiredInDaysQuantity || 0}
              activeQuantity={activeQuantity || 0}
            />
          </div>
          <div>
            <Alert
              message={
                <div className="font-semibold">
                  License Status:{" "}
                  <span style={{ color: alertConfig.color }}>
                    {alertConfig.message}
                  </span>
                </div>
              }
              type={alertConfig.type}
            />
          </div>
          <div className="py-4">
            <LastUpdated time={dataUpdatedAt} />
          </div>
        </Col>
        <Col xs={24} xl={14}>
          <Table
            loading={isLoading}
            columns={donutChartTableColumns}
            dataSource={convertToInventoryTableData(allData?.results)}
            scroll={{ x: 400, y: 350 }}
            pagination={false}
            onChange={(pagination, filters: any, sorter: any) => {
              let paramObject: any;
              if (paramState?.licenseStatus?.length) {
                paramObject = {
                  licenseStatus: paramState.licenseStatus,
                };
              } else {
                paramObject = {};
              }
              if (sorter?.order) {
                paramObject.sort = `${sorter?.columnKey}:${(
                  sorter?.order as string
                ).substring(0, sorter?.order.length - 3)}`;
              }
              for (const [key, value] of Object.entries(filters)) {
                if (value !== null) {
                  paramObject[key] = value;
                }
              }
              setCurrentPage(1);
              setParamState(paramObject);
            }}
          />
          <div className={`text-right mt-4 ${isLoading ? "hidden" : "block"}`}>
            <Pagination
              showSizeChanger
              pageSizeOptions={[10, 20, 30, 40, 50]}
              pageSize={pageSize}
              onShowSizeChange={handlePageSizeChange}
              current={currentPage}
              total={allData?.totalResults}
              onChange={handlePageChange}
            />
          </div>
        </Col>
      </Row>
    </div>
  );
};
