import { CarrierType } from "@/types/carrier-config.types";
import { SelectProps } from "antd";
import Select from "antd/es/select";
import React, { useState } from "react";

type Props = {
  onSelect: (value: string[]) => void;
};

export const MultipleSelectManufacture: React.FC<Props> = ({ onSelect }) => {
  const [value, setValue] = useState<string[]>([]);

  const options = Object.values(CarrierType).map((value) => ({
    label: value,
    value,
  }));

  const allOption = { label: "All", value: "All" };

  const handleSelectAll = (newValue: string[]) => {
    if (newValue.includes(allOption.value)) {
      setValue(
        newValue.length === options.length + 1
          ? []
          : options.map((option) => option.value),
      );
      onSelect([]);
    } else {
      setValue(newValue);
      onSelect(newValue);
    }
  };

  const selectProps: SelectProps = {
    mode: "multiple",
    style: { width: "100%" },
    value,
    options: [allOption, ...options],
    onChange: handleSelectAll,
    placeholder: "Select Manufacture",
    maxTagCount: "responsive",
  };
  return <Select {...selectProps} />;
};
