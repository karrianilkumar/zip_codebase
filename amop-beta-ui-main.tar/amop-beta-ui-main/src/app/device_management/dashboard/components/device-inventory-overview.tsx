"use client";

import { CustomPopover } from "@/components/custom-popover";
import { useEffect, useState } from "react";
import { InfoCircleOutlined } from "@ant-design/icons";
import DeviceInventoryStatistic from "./device-inventory-statistic";
import { useQuery } from "@tanstack/react-query";
import { getDashboardStatistic, getTotalByTimeData } from "@/api/statistic-api";
import {
  DASHBOARD_QUERY_KEY,
  DASHBOARD_TEXT,
} from "@/common/constants/dashboard-constants";
import {
  DEVICE_API,
  DEVICE_API_ERROR,
  INVENTORY_API,
  INVENTORY_API_ERROR,
} from "@/common/constants/api-constants";
import { notification } from "antd";
import { convertToQuantityLicenseStatisticData } from "@/common/helper/dashboard-helper";
import { Skeleton } from "antd";

export const DeviceInventoryOverview = () => {
  const [openTip, setOpenTip] = useState(false);

  const [api, contextHolder] = notification.useNotification({
    maxCount: 1,
    placement: "bottomRight",
  });

  const {
    data: notDeleted,
    isError: notDeletedError,
    isLoading: notDeletedLoading,
  } = useQuery({
    queryKey: [DASHBOARD_QUERY_KEY.DEVICES_NOT_DELETED_AMOUNT],
    queryFn: () =>
      getDashboardStatistic(
        DEVICE_API.DASHBOARD_NOT_DELETED_DEVICES_AMOUNT,
        DEVICE_API_ERROR.DASHBOARD_NOT_DELETED_DEVICES_AMOUNT,
        {},
      ),
  });

  const {
    data: totalDevice,
    isError: totalDeviceError,
    isLoading: totalDeviceLoading,
  } = useQuery({
    queryKey: [DASHBOARD_QUERY_KEY.DEVICES_AMOUNT],
    queryFn: () =>
      getDashboardStatistic(
        DEVICE_API.DASHBOARD_DEVICES_AMOUNT,
        DEVICE_API_ERROR.DASHBOARD_DEVICES_AMOUNT,
        {},
      ),
  });

  const {
    data: activated,
    isError: activatedError,
    isLoading: activatedLoading,
  } = useQuery({
    queryKey: [DASHBOARD_QUERY_KEY.ACTIVATED_SIMS_AMOUNT],
    queryFn: () =>
      getDashboardStatistic(
        INVENTORY_API.DASHBOARD_ACTIVATED_SIMS_AMOUNT,
        INVENTORY_API_ERROR.DASHBOARD_ACTIVATED_SIMS_AMOUNT,
        {},
      ),
  });

  const {
    data: totalSim,
    isError: totalSimError,
    isLoading: totalSimLoading,
  } = useQuery({
    queryKey: [DASHBOARD_QUERY_KEY.SIMS_AMOUNT],
    queryFn: () =>
      getDashboardStatistic(
        INVENTORY_API.DASHBOARD_SIMS_AMOUNT,
        INVENTORY_API_ERROR.DASHBOARD_SIMS_AMOUNT,
        {},
      ),
  });

  const {
    data: provisoned,
    isError: provisonedError,
    isLoading: provisonedLoading,
  } = useQuery({
    queryKey: [DASHBOARD_QUERY_KEY.DEVICES_PROVISIONED_AMOUNT],
    queryFn: () =>
      getDashboardStatistic(
        DEVICE_API.DASHBOARD_PROVISIONED_DEVICES_AMOUNT,
        DEVICE_API_ERROR.DASHBOARD_PROVISIONED_DEVICES_AMOUNT,
        {},
      ),
  });

  const {
    data: quantityLicenseData,
    isError: quantityLicenseError,
    isLoading: quantityLicenseLoading,
  } = useQuery({
    queryKey: [DASHBOARD_QUERY_KEY.DEVICES_BY_LICENSE_STATUS],
    queryFn: async () => {
      const data = await getTotalByTimeData({
        type: "devices_by_license_status",
        granularity: "month",
      });
      return convertToQuantityLicenseStatisticData(data);
    },
    staleTime: 1000 * 60 * 5,
    retry: 1,
  });

  useEffect(() => {
    if (
      notDeletedError ||
      totalDeviceError ||
      activatedError ||
      totalSimError ||
      provisonedError
    ) {
      switch (true) {
        case notDeletedError:
          api.error({
            message: DEVICE_API_ERROR.DASHBOARD_NOT_DELETED_DEVICES_AMOUNT,
          });
          break;
        case totalDeviceError:
          api.error({ message: DEVICE_API_ERROR.DASHBOARD_DEVICES_AMOUNT });
          break;
        case activatedError:
          api.error({
            message: INVENTORY_API_ERROR.DASHBOARD_ACTIVATED_SIMS_AMOUNT,
          });
          break;
        case totalSimError:
          api.error({ message: INVENTORY_API_ERROR.DASHBOARD_SIMS_AMOUNT });
          break;
        case provisonedError:
          api.error({
            message: DEVICE_API_ERROR.DASHBOARD_PROVISIONED_DEVICES_AMOUNT,
          });
        case quantityLicenseError:
          api.error({ message: INVENTORY_API_ERROR.QUANTITY_LICENSE });
          break;
        default:
          break;
      }
    }
  }, [
    notDeletedError,
    totalDeviceError,
    activatedError,
    totalSimError,
    provisonedError,
    quantityLicenseError,
    api,
  ]);

  return (
    <>
      {contextHolder}
      {notDeletedLoading ||
      totalDeviceLoading ||
      activatedLoading ||
      totalSimLoading ||
      provisonedLoading ||
      quantityLicenseLoading ? (
        <Skeleton active paragraph={{ rows: 6 }} />
      ) : (
        <>
          <div className="rounded-[0.5rem] sm:text-lg md:text-xl lg:text-2xl font-[500] mb-[1rem] pl-[0.5rem]">
            {DASHBOARD_TEXT.TITLE}
            <CustomPopover
              open={openTip}
              onOpenChange={() => setOpenTip(true)}
              title={DASHBOARD_TEXT.TITLE}
              handleClose={() => setOpenTip(false)}
            >
              <InfoCircleOutlined
                className="pl-2 translate-y-[-2px] text-[1rem] cursor-pointer"
                style={{ color: "gray" }}
              />
            </CustomPopover>
          </div>
          <DeviceInventoryStatistic
            notDeleted={notDeleted}
            provisioned={provisoned}
            activated={activated}
            totalDevice={totalDevice}
            totalSim={totalSim}
            quantityLicenseData={quantityLicenseData}
          />
        </>
      )}
    </>
  );
};
