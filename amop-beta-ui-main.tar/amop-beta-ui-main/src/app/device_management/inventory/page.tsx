"use client";

import { ScrollToTop } from "@/components/scroll-to-top";
import { InventoryTableWrapper } from "./components/inventory-table-wrapper";
import { InventoryModalWrapper } from "./components/inventory-modal-wrapper";
import { FeatureFlagProvider } from "@/components/feature-flag/feature-flag-provider";
import {
  DeviceManagementFeatures,
  ModuleFeatures,
} from "@/common/enums/module-feature-enum";

export default function Inventory() {
  return (
    <FeatureFlagProvider
      parentModule={ModuleFeatures.DeviceManagement}
      module={DeviceManagementFeatures.Inventory}
    >
      <InventoryTableWrapper />
      <InventoryModalWrapper />
      <ScrollToTop visibilityHeight={400} />
    </FeatureFlagProvider>
  );
}
