import { DeviceManagementInventoryDataType } from "@/types/inventory-types";
import {
  deviceManagementInventoryActionItem,
  DeviceManagementInventoryActionItemKeys,
} from "@/common/constants/table-constants";
import { Dropdown, Space } from "antd";
import { MoreOutlined } from "@ant-design/icons";
import React, { useMemo, useState } from "react";
import { useCommonFeatureStore } from "@/stores/common-feature-store";
import { DeviceManagementInventoryFeatures } from "@/common/enums/module-feature-enum";

type InventoryTableItemActionProps = {
  record: DeviceManagementInventoryDataType;
  onClick: (e: any, record: DeviceManagementInventoryDataType) => void;
};

export function InventoryTableItemAction({
  record,
  onClick,
}: InventoryTableItemActionProps) {
  const { hasFeature } = useCommonFeatureStore();
  const [actionItems] = useState(
    () => deviceManagementInventoryActionItem(record) || [],
  );

  const filteredActionItems = useMemo(
    () =>
      actionItems.filter((item) => {
        switch (item?.key) {
          case DeviceManagementInventoryActionItemKeys.ARCHIVE_DEVICE:
            return hasFeature(DeviceManagementInventoryFeatures.Archive);
          case DeviceManagementInventoryActionItemKeys.PROVISION_DEVICE:
            return hasFeature(DeviceManagementInventoryFeatures.Provision);
          default:
            return true;
        }
      }),
    [actionItems, hasFeature],
  );

  if (!filteredActionItems.length) {
    return null;
  }

  return (
    <Dropdown
      className="cursor-pointer"
      menu={{
        items: filteredActionItems,
        onClick: (e) => onClick(e, record),
      }}
    >
      <Space>
        <MoreOutlined rotate={90} />
      </Space>
    </Dropdown>
  );
}
