"use client";

import {
  postProvisionData,
  postValidateProvisionData,
} from "@/api/provision-api";
import { INVENTORY_QUERY_KEY } from "@/common/constants/inventory-constants";
import { MODAL_WIDTH } from "@/common/constants/modal-size-constants";
import {
  CheckValidSelectedDeviceResult,
  PROVISION_MULTI_DEVICES_VALIDATE_STEP_KEY,
  PROVISION_QUERY_KEY,
  PROVISION_TEXT,
} from "@/common/constants/provisioning-constants";
import { ValidationError } from "@/common/errors/validation-error";
import {
  checkValidSelectedDevice,
  convertDataToProvisionParamObject,
} from "@/common/helper/provision-helper";
import { ModalWrapper } from "@/components/modal-wrapper";
import { AddCustomerRate } from "@/components/provision-device/add-customer-rate";
import { AssignCustomer } from "@/components/provision-device/assign-customer";
import { ConfirmationModal } from "@/components/provision-device/confirmation-modal";
import { ProvisionDevice } from "@/components/provision-device/provision-device";
import { ProvisionResult } from "@/components/provision-device/provision-result";
import { ProvisionSummary } from "@/components/provision-device/provision-summary";
import useConfirmationModalStore from "@/stores/confirmation-modal-store";
import useInventoryTableStore from "@/stores/inventory-table-store";
import useProvisionMultipleModalStore from "@/stores/provision-multiple-modal-store";
import { DeviceManagementInventoryDataType } from "@/types/inventory-types";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Alert, Button, Col, Form, Row, Steps, notification } from "antd";
import { use, useEffect, useState } from "react";
import { SelectedItemMultiple } from "./selected-item-multiple";
import LoadingPanelWrapper from "../../components/loading-panel-wrapper";
import { FormState } from "@/types/form/form-types";

export const ProvisionMultipleModal = () => {
  const [isLoading, setIsLoading] = useState(false);

  const [provisionDeviceForm] = Form.useForm();
  const [assignCustomerForm] = Form.useForm();
  const [addCustomerRateForm] = Form.useForm();
  const {
    onOpenProvisionMultipleModal,
    setOpenProvisionMultipleModal,
    selectedProvisionMultipleDeviceModal,
    provisionMultipleDeviceData,
    setProvisionMultipleDeviceData,
    updateProvisionMultipleDeviceData,
    currentProvisionStep,
    provisionStepList,
    updateProvisionStepStatus,
    setCurrentProvisionStep,
    submitted,
    setSubmitted,
    removeSelectedProvisionMultipleDeviceModalItem,
    summaryData,
    resetProvisionMultipleModalStore,
    updateSummaryData,
    searchString,
    setSearchString,
    setFormStatus,
  } = useProvisionMultipleModalStore();
  const { setSelectedInventoryTableItems, setSelectedInventoryTableItemsKey } =
    useInventoryTableStore();
  const { openConfirmationProvisionModal, setOpenConfirmationProvisionModal } =
    useConfirmationModalStore();

  const [api, contextHolder] = notification.useNotification({
    maxCount: 1,
    placement: "bottomRight",
  });

  const handleModalActions = ({
    reset,
    close,
    unselect,
  }: {
    reset?: boolean;
    close?: boolean;
    unselect?: boolean;
  }) => {
    if (reset) {
      provisionDeviceForm.resetFields();
      assignCustomerForm.resetFields();
      addCustomerRateForm.resetFields();
      resetProvisionMultipleModalStore();
    }
    if (close) {
      setOpenProvisionMultipleModal(false);
    }
    if (unselect) {
      setSelectedInventoryTableItems([]);
      setSelectedInventoryTableItemsKey([]);
    } else {
      setSelectedInventoryTableItems(selectedProvisionMultipleDeviceModal);
      setSelectedInventoryTableItemsKey(
        selectedProvisionMultipleDeviceModal.map((item) => item.id),
      );
    }
  };
  const [provisionResultId, setProvisionResultId] = useState("");

  const queryClient = useQueryClient();

  const handleCloseModal = () => {
    provisionDeviceForm.resetFields();
    assignCustomerForm.resetFields();
    addCustomerRateForm.resetFields();
    setOpenProvisionMultipleModal(false);
  };

  const handleCancel = () => {
    setOpenConfirmationProvisionModal(true);
  };

  const handleRemoveSelectedProvisionMultipleDeviceModalItem = (
    value: DeviceManagementInventoryDataType,
  ) => {
    if (selectedProvisionMultipleDeviceModal.length === 1) {
      handleCloseModal();
      return;
    }
    removeSelectedProvisionMultipleDeviceModalItem(value);
  };

  const handleChangeStep = async (value: number) => {
    try {
      await provisionDeviceForm.validateFields();
      await assignCustomerForm.validateFields();
      await addCustomerRateForm.validateFields();

      if (currentProvisionStep < value) {
        const provisionStep =
          PROVISION_MULTI_DEVICES_VALIDATE_STEP_KEY[currentProvisionStep];
        if (provisionStep) {
          const validateData = {
            step: provisionStep,
            data: convertDataToProvisionParamObject(
              provisionMultipleDeviceData,
              summaryData,
            ),
          };
          setIsLoading(true);
          await postValidateProvisionData(validateData);
        }
      }

      let firstErrorStep = provisionStepList.findIndex(
        (step) => step.status === PROVISION_TEXT.error,
      );
      if (
        value > currentProvisionStep &&
        ((firstErrorStep > currentProvisionStep && firstErrorStep < value) ||
          (value > currentProvisionStep + 1 &&
            provisionStepList[value]?.status === undefined &&
            provisionStepList[value - 1]?.status === undefined))
      )
        return;
      updateProvisionStepStatus(value, "process");
      setCurrentProvisionStep(value);
    } catch (error) {
      if (error instanceof ValidationError) {
        api.error({
          message: error.message,
        });
      }

      if (value < currentProvisionStep) {
        updateProvisionStepStatus(currentProvisionStep, "error");
        setCurrentProvisionStep(value);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const usePostProvisionData = useMutation({
    mutationFn: postProvisionData,
    onSuccess: (data) => {
      setProvisionResultId(data?.data?.id || "");
    },
  });
  const {
    isSuccess: postProvisionDataSuccess,
    isError: postProvisionDataError,
    isLoading: postProvisionDataLoading,
  } = usePostProvisionData;

  const handleSubmitProvisionData = async () => {
    setSubmitted(true);
    await usePostProvisionData.mutateAsync(
      convertDataToProvisionParamObject(
        provisionMultipleDeviceData,
        summaryData,
      ),
    );
    queryClient.invalidateQueries({ queryKey: [INVENTORY_QUERY_KEY.DEVICE] });
    queryClient.invalidateQueries({
      queryKey: [PROVISION_QUERY_KEY.GET_PROVISION],
    });
  };

  const footer = (
    <div className="mt-2 flex justify-between items-center">
      <div>
        <p className="font-medium text-base">
          {PROVISION_TEXT.NUMBER_OF_SELECTED_DEVICE}:{" "}
          {selectedProvisionMultipleDeviceModal.length}
        </p>
      </div>
      <div>
        <Button
          className="w-32"
          size="large"
          type="primary"
          ghost
          onClick={() => handleCancel()}
        >
          {PROVISION_TEXT.CANCEL}
        </Button>
        <Button
          className="w-32"
          size="large"
          type="primary"
          disabled={currentProvisionStep !== provisionStepList.length - 1}
          onClick={handleSubmitProvisionData}
        >
          {PROVISION_TEXT.SUBMIT}
        </Button>
      </div>
    </div>
  );

  let checkValidSelectedDeviceResult = checkValidSelectedDevice(
    selectedProvisionMultipleDeviceModal,
  );

  useEffect(() => {
    if (postProvisionDataSuccess) {
      setFormStatus({ state: FormState.Success });
    } else if (postProvisionDataError) {
      setFormStatus({ state: FormState.Error });
    } else if (postProvisionDataLoading) {
      setFormStatus({ state: FormState.Loading });
    }
  }, [
    postProvisionDataSuccess,
    postProvisionDataError,
    postProvisionDataLoading,
    setFormStatus,
  ]);

  return (
    <div>
      {openConfirmationProvisionModal && (
        <ConfirmationModal
          title={PROVISION_TEXT.CANCEL_CONFIRMATION_TITLE}
          description={PROVISION_TEXT.CANCEL_CONFIRMATION_DESCRIPTION}
          onResetAndClose={() =>
            handleModalActions({ reset: true, close: true, unselect: true })
          }
          onRetainAndClose={() => handleModalActions({ close: true })}
          setOpenParent={setOpenProvisionMultipleModal}
        />
      )}
      <ModalWrapper
        title={PROVISION_TEXT.PROVISION_DEVICES}
        openState={onOpenProvisionMultipleModal}
        onCloseModel={
          submitted
            ? () =>
                handleModalActions({ reset: true, close: true, unselect: true })
            : () => handleCancel()
        }
        footer={submitted ? "" : footer}
        width={MODAL_WIDTH.LARGE}
        className="min-h-[90vh]"
      >
        {contextHolder}
        <div className="h-[80vh] overflow-y-auto">
          {submitted ? (
            <ProvisionResult
              goToProvisioning
              data={provisionMultipleDeviceData}
              handleCloseModal={() =>
                handleModalActions({ reset: true, close: true, unselect: true })
              }
              handleResetModal={() => handleModalActions({ reset: true })}
              handleBack={setSubmitted}
              provisionId={provisionResultId}
            />
          ) : (
            <>
              <Row className="h-full overflow-hidden">
                <Col span={5} className="border-r-stone-300 border-r h-full">
                  <div className="font-medium text-base h-8">
                    {PROVISION_TEXT.SELECTED_DEVICES}
                  </div>
                  <div className="overflow-y-auto h-[calc(100%-2rem)]">
                    {selectedProvisionMultipleDeviceModal.map((item) => (
                      <SelectedItemMultiple
                        key={item.id}
                        item={item}
                        handleRemoveItem={
                          removeSelectedProvisionMultipleDeviceModalItem
                        }
                      />
                    ))}
                  </div>
                </Col>
                <Col span={19} className="h-full">
                  <div className="overflow-x-hidden overflow-y-auto h-full px-4">
                    {checkValidSelectedDeviceResult ===
                    CheckValidSelectedDeviceResult.VALID ? (
                      <LoadingPanelWrapper loadingText="" isLoading={isLoading}>
                        <div className="w-4/5 my-8 mx-auto">
                          <Steps
                            progressDot
                            current={currentProvisionStep}
                            onChange={handleChangeStep}
                            items={provisionStepList}
                          />
                        </div>
                        {currentProvisionStep === 0 && (
                          <ProvisionDevice
                            showDeviceModal={false}
                            formInstance={provisionDeviceForm}
                            data={provisionMultipleDeviceData}
                            setData={setProvisionMultipleDeviceData}
                            updateData={updateProvisionMultipleDeviceData}
                            updateSummary={updateSummaryData}
                            handleClickNextStep={() =>
                              handleChangeStep(currentProvisionStep + 1)
                            }
                          />
                        )}
                        {currentProvisionStep === 1 && (
                          <AssignCustomer
                            useExistingCustomer
                            formInstance={assignCustomerForm}
                            data={provisionMultipleDeviceData}
                            setData={setProvisionMultipleDeviceData}
                            updateSummary={updateSummaryData}
                            handleClickBackStep={() =>
                              handleChangeStep(currentProvisionStep - 1)
                            }
                            handleClickNextStep={() =>
                              handleChangeStep(currentProvisionStep + 1)
                            }
                            searchString={searchString}
                            setSearchString={setSearchString}
                          />
                        )}
                        {currentProvisionStep === 2 && (
                          <AddCustomerRate
                            formInstance={addCustomerRateForm}
                            data={provisionMultipleDeviceData}
                            setData={setProvisionMultipleDeviceData}
                            updateSummary={updateSummaryData}
                            handleClickBackStep={() =>
                              handleChangeStep(currentProvisionStep - 1)
                            }
                            handleClickNextStep={() =>
                              handleChangeStep(currentProvisionStep + 1)
                            }
                          />
                        )}
                        {currentProvisionStep === 3 && (
                          <ProvisionSummary
                            summaryData={summaryData}
                            provisionData={provisionMultipleDeviceData}
                            handleClickBackStep={() =>
                              handleChangeStep(currentProvisionStep - 1)
                            }
                          />
                        )}
                      </LoadingPanelWrapper>
                    ) : (
                      <Alert
                        message="Warning"
                        type="warning"
                        description={
                          checkValidSelectedDeviceResult ===
                          CheckValidSelectedDeviceResult.PROVISIONED
                            ? PROVISION_TEXT.SELECTED_DEVICES_PROVISIONED_ERROR
                            : checkValidSelectedDeviceResult ===
                                CheckValidSelectedDeviceResult.INVALID_PROVIDER
                              ? PROVISION_TEXT.SELECTED_DEVICES_PROVIDER_ERROR
                              : PROVISION_TEXT.SELECTED_DEVICES_MANUFACTURER_ERROR
                        }
                        showIcon
                      />
                    )}
                  </div>
                </Col>
              </Row>
            </>
          )}
        </div>
      </ModalWrapper>
    </div>
  );
};
