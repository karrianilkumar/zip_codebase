import { cleanup, render, screen, waitFor } from "@testing-library/react";
import Inventory from "./page";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { PropsWithChildren } from "react";
import * as deviceApi from "@/api/device-api";

jest.mock("@/api/device-api");

const mockedDeviceApi = deviceApi as jest.Mocked<typeof deviceApi>;

const wrapper = ({ children }: PropsWithChildren) => {
  return (
    <QueryClientProvider client={new QueryClient()}>
      {children}
    </QueryClientProvider>
  );
};

describe("InventoryPage", () => {
  afterEach(() => {
    cleanup();
    jest.clearAllMocks();
  });

  it("should render successfully", async () => {
    mockedDeviceApi.getDeviceManufacture.mockResolvedValueOnce({ results: [] });
    mockedDeviceApi.getInventoryData.mockResolvedValueOnce({
      results: [],
      count: 0,
    });

    render(<Inventory />, { wrapper });
    await waitFor(() => expect(screen.getByText("ICCID")).toBeInTheDocument());
  });
});
