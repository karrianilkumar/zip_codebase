"use client";

import {
  postActivateData,
  postProvisionData,
  postValidateProvisionData
} from "@/api/provision-api";
import { INVENTORY_QUERY_KEY } from "@/common/constants/inventory-constants";
import { MODAL_WIDTH } from "@/common/constants/modal-size-constants";
import {
  PROVISION_DEVICE_VALIDATE_STEP_KEY,
  PROVISION_QUERY_KEY,
  PROVISION_TEXT
} from "@/common/constants/provisioning-constants";
import { ValidationError } from "@/common/errors/validation-error";
import {
  convertDataToActivateICCIDParamObject,
  convertDataToProvisionParamObject
} from "@/common/helper/provision-helper";
import { ModalWrapper } from "@/components/modal-wrapper";
import { AddCustomerRate } from "@/components/provision-device/add-customer-rate";
import { AddDevice } from "@/components/provision-device/add-device";
import { AssignCustomer } from "@/components/provision-device/assign-customer";
import { ChooseManufacturer } from "@/components/provision-device/choose-manufacturer";
import { ConfirmationModal } from "@/components/provision-device/confirmation-modal";
import { ProvisionDevice } from "@/components/provision-device/provision-device";
import { ProvisionResult } from "@/components/provision-device/provision-result";
import { ProvisionSummary } from "@/components/provision-device/provision-summary";
import useActivateModalStore from "@/stores/activate-modal-store";
import useConfirmationModalStore from "@/stores/confirmation-modal-store";
import useProvisionModalStore from "@/stores/provision-modal-store";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button, Form, notification, Steps } from "antd";
import { useEffect, useState } from "react";
import LoadingPanelWrapper from "../../components/loading-panel-wrapper";
import { FormState } from "@/types/form/form-types";
import { FeatureFlag } from "@/components/feature-flag/feature-flag";
import { DeviceManagementProvisioningFeatures } from "@/common/enums/module-feature-enum";

export const ProvisionModal = () => {
  const queryClient = useQueryClient();

  const [provisionResultId, setProvisionResultId] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isError, setIsError] = useState(false);

  const [addDeviceForm] = Form.useForm();
  const [provisionDeviceForm] = Form.useForm();
  const [assignCustomerForm] = Form.useForm();
  const [addCustomerRateForm] = Form.useForm();
  const {
    onOpenProvisionModal,
    setOpenProvisionModal,
    provisionDeviceData,
    setProvisionDeviceData,
    currentProvisionStep,
    setCurrentProvisionStep,
    provisionStepList,
    updateProvisionStepStatus,
    submitted,
    setSubmitted,
    summaryData,
    resetProvisionModalStore,
    updateSummaryData,
    searchString,
    setSearchString,
    isFromActivate,
    setIsFromActivate,
    setFormStatus
  } = useProvisionModalStore();
  const { activateIccidData, targetStatus, resetActivateModalStore } =
    useActivateModalStore();
  const { openConfirmationProvisionModal, setOpenConfirmationProvisionModal } =
    useConfirmationModalStore();

  const resetProvisionData = () => {
    addDeviceForm.resetFields();
    provisionDeviceForm.resetFields();
    assignCustomerForm.resetFields();
    addCustomerRateForm.resetFields();
    addDeviceForm.setFieldsValue({ deviceList: [undefined] });
    resetProvisionModalStore();
  };
  const [api, contextHolder] = notification.useNotification({
    maxCount: 1,
    placement: "bottomRight"
  });

  const handleModalActions = ({
                                reset,
                                close,
                                deactivate
                              }: {
    reset?: boolean;
    close?: boolean;
    deactivate?: boolean;
  }) => {
    if (reset) {
      resetProvisionData();
    }
    if (close) {
      setOpenProvisionModal(false);
    }
    if (deactivate) {
      setIsFromActivate(false);
    }
  };

  const handleCancel = () => {
    const isDirty = Object.keys(provisionDeviceData).length > 0;
    if (isDirty) {
      setOpenConfirmationProvisionModal(true);
    } else {
      handleModalActions({ reset: true, close: true });
    }
  };

  const usePostProvisionData = useMutation({
    mutationFn: postProvisionData,
    onSuccess: (data) => {
      setProvisionResultId(data?.data?.id || "");
    }
  });

  const {
    mutateAsync: postActivateDataMutateAsync,
    isPending: postActivateDataLoading,
    isError: postActivateDataError,
    isSuccess: postActivateDataSuccess,
    error: postActivateDataErrorRes
  } = useMutation({
    mutationFn: postActivateData,
    onSuccess: () => {
    }
  });

  const handleSubmitProvisionData = async () => {
    try {
      setSubmitted(true);
      const provisionParams = convertDataToProvisionParamObject(
        provisionDeviceData,
        summaryData
      );
      const provisionPromise =
        usePostProvisionData.mutateAsync(provisionParams);

      if (isFromActivate) {
        if (!targetStatus) {
          notification.error({
            message: PROVISION_TEXT.REQUIRED_TARGET_STATUS
          });
          return;
        }
        const activateParams = convertDataToActivateICCIDParamObject(
          activateIccidData,
          targetStatus
        );
        const activatePromise = postActivateDataMutateAsync(activateParams);
        await Promise.all([provisionPromise, activatePromise]);
        resetActivateModalStore();
      } else {
        await provisionPromise;
      }
      queryClient.invalidateQueries({ queryKey: [INVENTORY_QUERY_KEY.DEVICE] });
      queryClient.invalidateQueries({
        queryKey: [PROVISION_QUERY_KEY.GET_PROVISION]
      });
    } catch (unknownError) {
      const error = unknownError as Error;
      api.error({
        message: error.message
      });
      setIsError(true);
    }
  };

  const handleChangeStep = async (value: number) => {
    const chooseManufacturerStepIndex = provisionStepList.findIndex(
      (step) => step.title === PROVISION_TEXT.CHOOSE_MANUFACTURER
    );
    if (
      chooseManufacturerStepIndex !== -1 &&
      value > chooseManufacturerStepIndex &&
      !provisionDeviceData?.manufacturer?.length
    )
      return;
    try {
      await addDeviceForm.validateFields();
      await provisionDeviceForm.validateFields();
      await assignCustomerForm.validateFields();
      await addCustomerRateForm.validateFields();

      if (currentProvisionStep < value) {
        const provisionStep =
          PROVISION_DEVICE_VALIDATE_STEP_KEY[currentProvisionStep];
        if (provisionStep) {
          const validateData = {
            step: provisionStep,
            data: convertDataToProvisionParamObject(
              provisionDeviceData,
              summaryData
            )
          };
          setIsLoading(true);
          await postValidateProvisionData(validateData);
        }
      }

      let firstErrorStep = provisionStepList.findIndex(
        (step) => step.status === PROVISION_TEXT.error
      );
      if (
        value > currentProvisionStep &&
        ((firstErrorStep > currentProvisionStep && firstErrorStep < value) ||
          (value > currentProvisionStep + 1 &&
            provisionStepList[value]?.status === undefined &&
            provisionStepList[value - 1]?.status === undefined))
      )
        return;
      updateProvisionStepStatus(currentProvisionStep, "process");
      setCurrentProvisionStep(value);
    } catch (error) {
      if (error instanceof ValidationError) {
        api.error({
          message: error.message
        });
      }

      if (value < currentProvisionStep) {
        updateProvisionStepStatus(currentProvisionStep, "error");
        setCurrentProvisionStep(value);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleCancelProvision = () => {
    if (submitted && isFromActivate) {
      handleModalActions({
        reset: true,
        close: true,
        deactivate: isFromActivate
      });
    } else if (submitted) {
      handleModalActions({ reset: true, close: true });
    } else {
      handleCancel();
    }
  };

  const footer = (
    <div className="mt-2">
      <Button
        className="w-32"
        size="large"
        type="primary"
        ghost
        onClick={() => handleCancelProvision()}
      >
        {PROVISION_TEXT.CANCEL}
      </Button>
      <Button
        className={isFromActivate ? "w-72" : "w-32"}
        size="large"
        type="primary"
        disabled={currentProvisionStep !== provisionStepList.length - 1}
        onClick={handleSubmitProvisionData}
      >
        {isFromActivate
          ? PROVISION_TEXT.SUBMIT_ACTIVATION_AND_PROVISION
          : PROVISION_TEXT.SUBMIT}
      </Button>
    </div>
  );

  useEffect(() => {
    if (isFromActivate) {
      if (usePostProvisionData.isPending || postActivateDataLoading) {
        setFormStatus({ state: FormState.Loading });
      } else if (
        postActivateDataSuccess &&
        usePostProvisionData.isSuccess &&
        !isError
      ) {
        setFormStatus({ state: FormState.Success });
      } else if (
        usePostProvisionData.isError ||
        postActivateDataError ||
        isError
      ) {
        setFormStatus({ state: FormState.Error });
      }
    } else {
      if (usePostProvisionData.isPending) {
        setFormStatus({ state: FormState.Loading });
      } else if (usePostProvisionData.isSuccess && !isError) {
        setFormStatus({ state: FormState.Success });
      } else if (usePostProvisionData.isError || isError) {
        setFormStatus({ state: FormState.Error });
      }
    }
  }, [
    usePostProvisionData.isPending,
    postActivateDataLoading,
    postActivateDataSuccess,
    usePostProvisionData.isSuccess,
    isError,
    usePostProvisionData.isError,
    postActivateDataError,
    isFromActivate,
    setFormStatus
  ]);

  return (
    <div>
      {openConfirmationProvisionModal && (
        <ConfirmationModal
          title={PROVISION_TEXT.CANCEL_CONFIRMATION_TITLE}
          description={PROVISION_TEXT.CANCEL_CONFIRMATION_DESCRIPTION}
          onResetAndClose={() =>
            handleModalActions({ reset: true, close: true })
          }
          onRetainAndClose={() => handleModalActions({ close: true })}
          setOpenParent={setOpenProvisionModal}
        />
      )}
      <ModalWrapper
        title={
          isFromActivate
            ? PROVISION_TEXT.ACTIVATE_ICCID_AND_PROVISION_DEVICES
            : PROVISION_TEXT.PROVISION_DEVICES
        }
        openState={onOpenProvisionModal}
        onCloseModel={handleCancelProvision}
        footer={submitted ? "" : footer}
        width={MODAL_WIDTH.LARGE}
        className="min-h-[90vh]"
      >
        {contextHolder}
        <div className="h-[80vh] overflow-y-auto">
          {submitted ? (
            <ProvisionResult
              data={provisionDeviceData}
              allowNewProvision
              handleCloseModal={handleCancelProvision}
              handleResetModal={() => handleModalActions({ reset: true })}
              handleBack={setSubmitted}
              provisionId={provisionResultId}
              error={usePostProvisionData.error || postActivateDataErrorRes}
            />
          ) : (
            <LoadingPanelWrapper loadingText="" isLoading={isLoading}>
              <div className="w-4/5 my-8 mx-auto">
                <Steps
                  progressDot
                  current={currentProvisionStep}
                  onChange={handleChangeStep}
                  items={provisionStepList}
                />
              </div>
              {currentProvisionStep === 0 && (
                <AddDevice
                  formInstance={addDeviceForm}
                  handleClickNextStep={() =>
                    handleChangeStep(currentProvisionStep + 1)
                  }
                />
              )}
              {currentProvisionStep === 1 && (
                <ChooseManufacturer
                  handleClickBackStep={() =>
                    handleChangeStep(currentProvisionStep - 1)
                  }
                  handleClickNextStep={() =>
                    handleChangeStep(currentProvisionStep + 1)
                  }
                />
              )}
              {currentProvisionStep === 2 && (
                <ProvisionDevice
                  formInstance={provisionDeviceForm}
                  data={provisionDeviceData}
                  setData={setProvisionDeviceData}
                  updateSummary={updateSummaryData}
                  handleClickBackStep={() =>
                    handleChangeStep(currentProvisionStep - 1)
                  }
                  handleClickNextStep={() =>
                    handleChangeStep(currentProvisionStep + 1)
                  }
                />
              )}
              {currentProvisionStep === 3 && (
                <FeatureFlag
                  feature={DeviceManagementProvisioningFeatures.AssignCustomer}
                >
                  <AssignCustomer
                    formInstance={assignCustomerForm}
                    data={provisionDeviceData}
                    setData={setProvisionDeviceData}
                    updateSummary={updateSummaryData}
                    handleClickBackStep={() =>
                      handleChangeStep(currentProvisionStep - 1)
                    }
                    handleClickNextStep={() =>
                      handleChangeStep(currentProvisionStep + 1)
                    }
                    searchString={searchString}
                    setSearchString={setSearchString}
                  />
                </FeatureFlag>
              )}
              {currentProvisionStep === 4 && (
                <FeatureFlag
                  feature={
                    DeviceManagementProvisioningFeatures.AssignCustomerRatePlans
                  }
                >
                  <AddCustomerRate
                    formInstance={addCustomerRateForm}
                    data={provisionDeviceData}
                    setData={setProvisionDeviceData}
                    updateSummary={updateSummaryData}
                    handleClickBackStep={() =>
                      handleChangeStep(currentProvisionStep - 1)
                    }
                    handleClickNextStep={() =>
                      handleChangeStep(currentProvisionStep + 1)
                    }
                  />
                </FeatureFlag>
              )}
              {currentProvisionStep === 5 && (
                <ProvisionSummary
                  summaryData={summaryData}
                  provisionData={provisionDeviceData}
                  handleClickBackStep={() =>
                    handleChangeStep(currentProvisionStep - 1)
                  }
                />
              )}
            </LoadingPanelWrapper>
          )}
        </div>
      </ModalWrapper>
    </div>
  );
};
