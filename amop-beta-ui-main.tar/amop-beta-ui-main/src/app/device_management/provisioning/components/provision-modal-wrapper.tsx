import React, { Suspense, lazy } from "react";
const ProvisionModal = lazy(() =>
  import("./provision-modal").then((module) => ({
    default: module.ProvisionModal,
  })),
);
const ActivateModal = lazy(() =>
  import("./activate-modal").then((module) => ({
    default: module.ActivateModal,
  })),
);

export const ProvisionModalWrapper = () => {
  return (
    <Suspense>
      <ProvisionModal />
      <ActivateModal />
    </Suspense>
  );
};
