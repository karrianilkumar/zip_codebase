"use client";

import { ServiceProvider } from "@/components/activate-iccid/service-provider";
import { MODAL_WIDTH } from "@/common/constants/modal-size-constants";
import { ModalWrapper } from "@/components/modal-wrapper";
import useActivateModalStore from "@/stores/activate-modal-store";
import { Button, Form, notification, Steps } from "antd";
import React from "react";
import { ACTIVATE_ICCID_TEXT } from "@/common/constants/activate-constants";
import {
  PROVISION_QUERY_KEY,
  PROVISION_TEXT,
} from "@/common/constants/provisioning-constants";
import { TargetStatus } from "@/components/activate-iccid/target-status";
import { IccidImei } from "@/components/activate-iccid/iccid-imei";
import useConfirmationModalStore from "@/stores/confirmation-modal-store";
import { ConfirmationModal } from "@/components/provision-device/confirmation-modal";
import { AssignCustomer } from "@/components/provision-device/assign-customer";
import { AddCustomerRate } from "@/components/provision-device/add-customer-rate";
import { ActivateSummary } from "@/components/activate-iccid/activate-summary";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { ActivateResult } from "@/components/activate-iccid/activate-result";
import { postActivateData } from "@/api/provision-api";
import { convertDataToActivateICCIDParamObject } from "@/common/helper/provision-helper";
import useProvisionModalStore from "@/stores/provision-modal-store";
import { ProvisionNewDeviceType } from "@/types/provision-types";
import { FormState } from "@/types/form/form-types";

export const ActivateModal = () => {
  const [serviceProviderForm] = Form.useForm();
  const [targetStatusForm] = Form.useForm();
  const [iccidImeiForm] = Form.useForm();
  const [assignCustomerForm] = Form.useForm();
  const [addCustomerRateForm] = Form.useForm();
  const [api, contextHolder] = notification.useNotification();
  const queryClient = useQueryClient();

  const {
    activateIccidData,
    setActivateIccidData,
    onOpenActivateModal,
    setOpenActivateModal,
    currentActivateStep,
    activateStepList,
    updateActivateStepStatus,
    setCurrentActivateStep,
    resetActivateModalStore,
    updateSummaryData,
    summaryData,
    submitted,
    setSubmitted,
    targetStatus,
    setFormStatus,
  } = useActivateModalStore();
  const {
    setProvisionDeviceData,
    setOpenProvisionModal,
    setCurrentProvisionStep,
    validateProvisionData,
    searchString,
    setSearchString,
    updateSummaryData: updateProvisionSummaryData,
    setIsFromActivate,
  } = useProvisionModalStore();
  const {
    openConfirmationActivateICCIDModal,
    setOpenConfirmationActivateICCIDModal,
  } = useConfirmationModalStore();

  const {
    mutateAsync: postActivateDataMutateAsync,
    error: postActivateDataErrorData,
  } = useMutation({
    mutationFn: postActivateData,
    onSuccess: () => setFormStatus({ state: FormState.Success }),
    onError: () => setFormStatus({ state: FormState.Error }),
    onMutate: () => setFormStatus({ state: FormState.Loading }),
  });

  const handleChangeStep = async (value: number) => {
    try {
      await serviceProviderForm.validateFields();
      await targetStatusForm.validateFields();
      await iccidImeiForm.validateFields();
      await assignCustomerForm.validateFields();
      await addCustomerRateForm.validateFields();
      let firstErrorStep = activateStepList.findIndex(
        (step) => step.status === PROVISION_TEXT.error,
      );
      if (
        value > currentActivateStep &&
        ((firstErrorStep > currentActivateStep && firstErrorStep < value) ||
          (value > currentActivateStep + 1 &&
            activateStepList[value]?.status === undefined &&
            activateStepList[value - 1]?.status === undefined))
      )
        return;
      updateActivateStepStatus(value, "process");
      setCurrentActivateStep(value);
    } catch (error) {
      if (value < currentActivateStep) {
        updateActivateStepStatus(currentActivateStep, "error");
        setCurrentActivateStep(value);
      }
    }
  };

  const resetActivateData = () => {
    serviceProviderForm.resetFields();
    targetStatusForm.resetFields();
    iccidImeiForm.setFieldsValue({ deviceList: [undefined] });
    assignCustomerForm.resetFields();
    addCustomerRateForm.resetFields();
    resetActivateModalStore();
  };

  const handleModalActions = ({
    reset,
    close,
  }: {
    reset?: boolean;
    close?: boolean;
  }) => {
    if (reset) {
      resetActivateData();
    }
    if (close) {
      setOpenActivateModal(false);
    }
  };

  const handleCancel = () => {
    const isDirty = Object.keys(activateIccidData).length > 0;
    if (isDirty) {
      setOpenConfirmationActivateICCIDModal(true);
    } else {
      handleModalActions({ reset: true, close: true });
    }
  };

  const handleSubmitActivateData = async () => {
    try {
      if (targetStatus) {
        setSubmitted(true);
        const result = await postActivateDataMutateAsync(
          convertDataToActivateICCIDParamObject(
            activateIccidData,
            targetStatus,
          ),
        );
        queryClient.invalidateQueries({
          queryKey: [PROVISION_QUERY_KEY.GET_PROVISION],
        });
        return result.data;
      } else {
        api.error({
          message: PROVISION_TEXT.REQUIRED_TARGET_STATUS,
        });
        setSubmitted(false);
      }
    } catch (unknownError) {
      const error = unknownError as Error;
      setSubmitted(false);
      api.error({
        message: error.message,
      });
    }
  };

  const handleContinueToProvision = () => {
    const provisionData: ProvisionNewDeviceType = {
      devices: activateIccidData.devices,
      manufacturer: "",
      deviceModel: null,
      group: null,
      licenseType: null,
      deviceAlertOverride: false,
      deviceAlertOverrideList: [],
      emailAddress: "",
      useExistingCustomer: activateIccidData.useExistingCustomer ?? false,
      customerId: activateIccidData.customerId ?? null,
      customerName: activateIccidData.customerName ?? null,
      createServiceProduct: activateIccidData.createServiceProduct ?? false,
      provider: activateIccidData.provider ?? "",
      serviceType: activateIccidData.serviceType ?? "",
      product: activateIccidData.product ?? null,
      package: activateIccidData.package ?? null,
      rates: activateIccidData.rates ?? [],
      prorate: activateIccidData.prorate ?? false,
      prorateEffectiveDate: activateIccidData.prorateEffectiveDate ?? null,
      useCarrierActivation: activateIccidData.useCarrierActivation ?? false,
      addCustomerRatePlan: activateIccidData.addCustomerRatePlan ?? false,
      customerRatePlan: activateIccidData.customerRatePlan ?? null,
      rateEffectiveDate: activateIccidData.rateEffectiveDate ?? null,
      customerPool: activateIccidData.customerPool ?? null,
    };
    updateProvisionSummaryData({
      provider: summaryData?.provider,
      serviceType: summaryData.serviceType,
      product: summaryData.product,
      package: summaryData.package,
      rates: summaryData.rates,
      useCarrierActivation: summaryData.useCarrierActivation,
      customerName: summaryData.customerName,
      customerId: summaryData.customerId,
      prorateEffectiveDate: summaryData.prorateEffectiveDate,
      customerRatePlan: summaryData.customerRatePlan,
      customerPool: summaryData.customerPool,
      rateEffectiveDate: summaryData.rateEffectiveDate,
    } as ProvisionNewDeviceType);
    setOpenProvisionModal(true);
    setProvisionDeviceData(provisionData);
    handleModalActions({ reset: false, close: true });
    validateProvisionData();
    setCurrentProvisionStep(0);
    setIsFromActivate(true);
  };

  const footer = (
    <div className="mt-2 flex justify-end space-x-2">
      <Button
        className="w-32"
        size="large"
        type="primary"
        ghost
        onClick={() => handleCancel()}
      >
        {PROVISION_TEXT.CANCEL}
      </Button>
      <Button
        className="w-32"
        size="large"
        type="primary"
        disabled={currentActivateStep !== activateStepList.length - 1}
        onClick={handleSubmitActivateData}
      >
        {PROVISION_TEXT.SUBMIT}
      </Button>
      {currentActivateStep === activateStepList.length - 1 && (
        <Button
          className="w-48"
          size="large"
          type="primary"
          onClick={handleContinueToProvision}
        >
          {PROVISION_TEXT.CONTINUE_TO_PROVISION}
        </Button>
      )}
    </div>
  );

  return (
    <div>
      {contextHolder}
      {openConfirmationActivateICCIDModal && (
        <ConfirmationModal
          title={ACTIVATE_ICCID_TEXT.CANCEL_CONFIRMATION_TITLE}
          description={ACTIVATE_ICCID_TEXT.CANCEL_CONFIRMATION_DESCRIPTION}
          onResetAndClose={() =>
            handleModalActions({ reset: true, close: true })
          }
          onRetainAndClose={() => handleModalActions({ close: true })}
          setOpenParent={setOpenActivateModal}
        />
      )}
      <ModalWrapper
        title={ACTIVATE_ICCID_TEXT.ACTIVATE_ICCID}
        openState={onOpenActivateModal}
        onCloseModel={
          submitted
            ? () => handleModalActions({ reset: true, close: true })
            : () => handleCancel()
        }
        footer={submitted ? "" : footer}
        width={MODAL_WIDTH.LARGE}
        className="min-h-[90vh]"
      >
        <div className="h-[80vh] overflow-y-auto">
          {submitted ? (
            <ActivateResult
              handleCloseModal={() =>
                handleModalActions({ reset: true, close: true })
              }
              handleResetModal={() => handleModalActions({ reset: true })}
              handleBack={setSubmitted}
              error={postActivateDataErrorData}
            />
          ) : (
            <>
              <div className="w-4/5 my-8 mx-auto">
                <Steps
                  progressDot
                  current={currentActivateStep}
                  onChange={handleChangeStep}
                  items={activateStepList}
                />
              </div>
              {currentActivateStep === 0 && (
                <ServiceProvider
                  formInstance={serviceProviderForm}
                  handleClickNextStep={() =>
                    handleChangeStep(currentActivateStep + 1)
                  }
                  handleReset={resetActivateData}
                />
              )}
              {currentActivateStep === 1 && (
                <TargetStatus
                  formInstance={targetStatusForm}
                  handleClickBackStep={() =>
                    handleChangeStep(currentActivateStep - 1)
                  }
                  handleClickNextStep={() =>
                    handleChangeStep(currentActivateStep + 1)
                  }
                />
              )}
              {currentActivateStep === 2 && (
                <IccidImei
                  formInstance={iccidImeiForm}
                  handleClickBackStep={() =>
                    handleChangeStep(currentActivateStep - 1)
                  }
                  handleClickNextStep={() =>
                    handleChangeStep(currentActivateStep + 1)
                  }
                />
              )}
              {currentActivateStep === 3 && (
                <AssignCustomer
                  formInstance={assignCustomerForm}
                  data={activateIccidData}
                  setData={setActivateIccidData}
                  updateSummary={updateSummaryData}
                  handleClickBackStep={() =>
                    handleChangeStep(currentActivateStep - 1)
                  }
                  handleClickNextStep={() =>
                    handleChangeStep(currentActivateStep + 1)
                  }
                  searchString={searchString}
                  setSearchString={setSearchString}
                />
              )}
              {currentActivateStep === 4 && (
                <AddCustomerRate
                  formInstance={addCustomerRateForm}
                  data={activateIccidData}
                  setData={setActivateIccidData}
                  updateSummary={updateSummaryData}
                  handleClickBackStep={() =>
                    handleChangeStep(currentActivateStep - 1)
                  }
                  handleClickNextStep={() =>
                    handleChangeStep(currentActivateStep + 1)
                  }
                />
              )}
              {currentActivateStep === 5 && (
                <ActivateSummary
                  handleClickBackStep={() =>
                    handleChangeStep(currentActivateStep - 1)
                  }
                />
              )}
            </>
          )}
        </div>
      </ModalWrapper>
    </div>
  );
};
