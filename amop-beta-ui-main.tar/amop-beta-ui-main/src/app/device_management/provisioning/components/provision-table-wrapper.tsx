"use client";

import React, { Suspense, useEffect, useState } from "react";
import {
  convertStringArrayToString,
  convertTableColumnsToTitleArray,
} from "@/common/helper/table-helper";
import { useSearchParams } from "next/navigation";
import { SEARCH_PARAM } from "@/common/constants/inventory-constants";
import useProvisionTableStore from "@/stores/provision-table-store";
import { ADM_PROVISIONING_HIDE_COLUMNS } from "@/common/constants/provisioning-constants";
const ProvisionTableSorting = React.lazy(() =>
  import("./provision-table-sorting").then((module) => ({
    default: module.ProvisionTableSorting,
  })),
);
const ProvisionTable = React.lazy(() =>
  import("./provision-table").then((module) => ({
    default: module.ProvisionTable,
  })),
);

export const ProvisionTableWrapper = () => {
  const { provisionTableColumns } = useProvisionTableStore();
  const searchParams = useSearchParams();
  const [provisionColumns, setProvisionColumns] = useState(
    provisionTableColumns,
  );
  const [search, setSearch] = useState(searchParams.get(SEARCH_PARAM) ?? "");
  const [dateRangeFilter, setDateRangeFilter] = useState(["", ""] as [
    string,
    string,
  ]);

  const handleChangeColumns = (columns: string[]) => {
    let visibleColumns = provisionTableColumns.filter((item) =>
      columns.includes(item.title as string),
    );
    setProvisionColumns(visibleColumns);
    let hideColumns = provisionTableColumns.filter(
      (originalItem) =>
        visibleColumns.findIndex(
          (visibleItem) => visibleItem.title === originalItem.title,
        ) == -1,
    );
    let hideColumnsString = convertTableColumnsToTitleArray(hideColumns);
    typeof window !== "undefined" &&
      window.localStorage.setItem(
        ADM_PROVISIONING_HIDE_COLUMNS,
        convertStringArrayToString(hideColumnsString),
      );
  };

  const handleChangeDateRangeFilter = (dateRange: [string, string]) => {
    setDateRangeFilter(dateRange);
  };

  useEffect(() => {
    let hideColumnsStringArrStorage: string[] =
      (typeof window !== "undefined" &&
        (
          window.localStorage.getItem(ADM_PROVISIONING_HIDE_COLUMNS) ?? ""
        ).split(",")) ||
      [];
    let initialColumns = provisionTableColumns;
    if (hideColumnsStringArrStorage.length) {
      initialColumns = provisionTableColumns.filter(
        (column) =>
          !hideColumnsStringArrStorage.includes(column.title as string),
      );
    }
    setProvisionColumns(initialColumns);
  }, [provisionTableColumns]);

  return (
    <Suspense>
      <ProvisionTableSorting
        handleChangeColumns={handleChangeColumns}
        visibleColumns={provisionColumns}
        onSearchFilterChanged={setSearch}
        initialSearch={search}
        onDateRangeChange={handleChangeDateRangeFilter}
      />
      <ProvisionTable
        columnList={provisionColumns}
        searchString={search}
        dateRangeFilter={dateRangeFilter}
      />
    </Suspense>
  );
};
