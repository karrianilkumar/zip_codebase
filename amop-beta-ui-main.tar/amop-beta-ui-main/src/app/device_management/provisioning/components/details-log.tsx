import useDetailsLogModalStore from "@/stores/details-log-modal-store";
import { ProvisionLogDetailsType } from "@/types/provision-types";
import { Button, Col, Form, Input, Modal, Row, Table } from "antd";
import React from "react";

type Props = {};

export const DetailsLog: React.FC<Props> = () => {
  const {
    onOpenDetailsLogModal,
    setOpenDetailsLogModal,
    detailsLogData,
    setDetailsLogData,
  } = useDetailsLogModalStore();

  const handleClose = () => {
    setOpenDetailsLogModal(false);
    setDetailsLogData({} as ProvisionLogDetailsType);
  };

  const { statusDetails, changeRequest, detailedLogEntries, status, iccid } =
    detailsLogData;

  return (
    <div>
      <Modal
        title="Status Details"
        onOk={handleClose}
        open={onOpenDetailsLogModal}
        width={1000}
        className="h-screen overflow-auto p-0"
        footer={<Button onClick={handleClose}>Close</Button>}
        onCancel={handleClose}
      >
        <Form layout="vertical">
          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                label={<span className="font-bold text-md">ICCID</span>}
              >
                <Input value={iccid} disabled />
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                label={<span className="font-bold text-md">Status</span>}
              >
                <Input value={status} disabled />
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={16}>
            <Col span={12}>
              <Form.Item
                label={<span className="font-bold text-md">Request</span>}
              >
                <textarea
                  className="w-full h-32 resize-none border border-black"
                  value={changeRequest}
                  readOnly
                ></textarea>
              </Form.Item>
            </Col>
            <Col span={12}>
              <Form.Item
                label={<span className="font-bold text-md">Response</span>}
              >
                <textarea
                  className="w-full h-32 resize-none border border-black"
                  readOnly
                  value={statusDetails}
                ></textarea>
              </Form.Item>
            </Col>
          </Row>
          <Row gutter={16}>
            <Col span={24}>
              <Form.Item
                label={
                  <span className="font-bold text-md">
                    Detailed Log Entries
                  </span>
                }
              >
                <Table
                  dataSource={detailedLogEntries}
                  columns={[
                    {
                      title: "Timestamp",
                      dataIndex: "processedDate",
                      key: "processedDate",
                      render: (text) => {
                        return new Date(text).toLocaleString();
                      },
                    },
                    {
                      title: "Description",
                      dataIndex: "logEntryDescription",
                      key: "logEntryDescription",
                      render: (text) => {
                        return <div style={{ maxWidth: "280px" }}>{text}</div>;
                      },
                    },
                    {
                      title: "Status",
                      dataIndex: "responseStatus",
                      key: "responseStatus",
                    },
                    {
                      title: "Request",
                      dataIndex: "requestText",
                      key: "requestText",
                      render: (text) => {
                        return <div style={{ maxWidth: "280px" }}>{text}</div>;
                      },
                    },
                    {
                      title: "Response",
                      dataIndex: "responseText",
                      key: "responseText",
                      render: (text) => {
                        return <div style={{ maxWidth: "280px" }}>{text}</div>;
                      },
                    },
                  ]}
                />
              </Form.Item>
            </Col>
          </Row>
        </Form>
      </Modal>
    </div>
  );
};
