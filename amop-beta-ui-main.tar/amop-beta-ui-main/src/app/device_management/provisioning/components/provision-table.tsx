"use client";

import React, { useCallback, useEffect, useState } from "react";
import { Drawer, Dropdown, notification, Pagination, Space, Table } from "antd";
import { ColumnsType } from "antd/es/table/interface";
import {
  convertToProvisionTableData,
  processProvisionLogs,
} from "@/common/helper/table-helper";
import { getProvisionData } from "@/api/device-api";
import { useQuery } from "@tanstack/react-query";
import { PROVISION_TABLE_TEXT } from "@/common/constants/inventory-constants";
import { ScrollHint } from "../../components/scroll-hint";
import useProvisionTableStore from "@/stores/provision-table-store";
import {
  DetailedLogEntryType,
  DeviceManagementProvisionDataType,
  ProvisionLogType,
  ProvisionParamState,
} from "@/types/provision-types";
import {
  deviceManagementProvisionActionItem,
  DeviceManagementProvisionActionItemKeys,
} from "@/common/constants/table-constants";
import { MoreOutlined } from "@ant-design/icons";
import { MenuInfo } from "rc-menu/lib/interface";
import {
  PROVISION_QUERY_KEY,
  PROVISION_TEXT,
  PROVISIONING_ACTION_TYPE,
} from "@/common/constants/provisioning-constants";
import { DetailsLog } from "./details-log";
import useDetailsLogModalStore from "@/stores/details-log-modal-store";
import { getUTCDate } from "@/common/utils";
import { exportProvisionData } from "@/api/provision-api";
import { LastUpdated } from "@/app/device_management/components/last-updated";

type Props = {
  columnList: ColumnsType<any>;
  searchString?: string;
  dateRangeFilter: [string, string];
};

export const ProvisionTable: React.FC<Props> = ({
  columnList,
  searchString = "",
  dateRangeFilter,
}) => {
  const {
    setQueryIsFetching,
    triggerExport,
    setTriggerExport,
    selectedRow,
    setSelectedRow,
  } = useProvisionTableStore();
  const { setOpenDetailsLogModal, setDetailsLogData } =
    useDetailsLogModalStore();
  const [pageSize, setPageSize] = useState(20);
  const [currentPage, setCurrentPage] = useState(1);
  const [paramState, setParamState] = useState({} as ProvisionParamState);
  const [provisionLogDetails, setProvisionLogDetails] = useState<
    ProvisionLogType[]
  >([]);
  const [openDrawer, setOpenDrawer] = useState(false);

  const onClose = () => {
    setOpenDrawer(false);
  };

  const handleActionClick = (
    e: MenuInfo,
    record: DeviceManagementProvisionDataType,
  ) => {
    switch (e.key) {
      case DeviceManagementProvisionActionItemKeys.VIEW_LOG_DETAILS:
        setSelectedRow(record);
        setOpenDrawer(true);
        break;
      default:
        break;
    }
  };

  const handleDetailsLogClick = (mac: string) => {
    const isProvision =
      selectedRow?.actionType === PROVISIONING_ACTION_TYPE.PROVISION;
    const selectedMAC = mac;
    const result = selectedRow?.results?.find((r) => r.mac === selectedMAC);
    const deviceRequest = {
      ...selectedRow?.data,
      devices: undefined,
      ...selectedRow?.data?.devices?.find((d: any) => d.mac === selectedMAC),
    };

    const changeRequest = isProvision
      ? JSON.stringify(deviceRequest, null, 4)
      : result?.changeRequest || "Empty Change Request";
    const statusDetails = result?.statusDetails || "Empty Status Details";
    let detailedLogEntries: DetailedLogEntryType[] = [];

    if (isProvision) {
      const logs: string[] = result?.logs || [];

      detailedLogEntries.push(
        ...logs.map((log) => {
          let logObj = {} as any;
          try {
            logObj = JSON.parse(log) as any;
          } catch (e) {
            console.warn("Error parsing log", e);
          }

          return {
            logEntryDescription: logObj.message,
            processedDate: result.updatedAt,
            requestText: "",
            responseStatus: "",
            responseText: "",
          };
        }),
      );
    } else {
      detailedLogEntries = result?.detailsLogEntries || [];
    }

    const status = result?.status || "Empty Status";

    setDetailsLogData({
      iccid: result?.iccid,
      mac: selectedMAC,
      status: status,
      changeRequest: changeRequest,
      statusDetails: statusDetails,
      detailedLogEntries: detailedLogEntries,
    });
    setOpenDetailsLogModal(true);
  };

  let actionColumnList = columnList.map((col) => {
    if (col.key === PROVISION_TABLE_TEXT.action) {
      col.render = (text, record) => (
        <Dropdown
          className="cursor-pointer"
          menu={{
            items: deviceManagementProvisionActionItem,
            onClick: (e) => handleActionClick(e, record),
          }}
        >
          <Space>
            <MoreOutlined rotate={90} />
          </Space>
        </Dropdown>
      );
    }
    return col;
  });

  const [api, contextHolder] = notification.useNotification({
    maxCount: 1,
    placement: "bottomRight",
  });

  const { data, isLoading, dataUpdatedAt, isFetching, isError } = useQuery({
    //TODO: Update queryKey when API supported
    queryKey: [
      PROVISION_QUERY_KEY.GET_PROVISION,
      pageSize,
      currentPage,
      paramState,
      searchString,
    ],
    queryFn: async () => {
      if (searchString.length) {
        paramState.search = searchString;
      } else {
        delete paramState.search;
      }
      const data = await getProvisionData({
        page: currentPage,
        limit: pageSize,
        sort: PROVISION_TABLE_TEXT.createdAtAsc,
        ...paramState,
      });
      return data;
    },
    staleTime: 1000 * 60 * 5,
    retry: 1,
  });

  useEffect(() => {
    setCurrentPage(1);
  }, [searchString, setCurrentPage]);

  useEffect(() => {
    const paramState: ProvisionParamState = {};
    if (dateRangeFilter[0].length && dateRangeFilter[1].length) {
      paramState.startDate = getUTCDate(dateRangeFilter[0]).toISOString();
      paramState.endDate = getUTCDate(dateRangeFilter[1]).toISOString();
      setParamState((prev: ProvisionParamState) => {
        return {
          ...prev,
          startDate: paramState.startDate,
          endDate: paramState.endDate,
        };
      });
    } else {
      setParamState((prev: ProvisionParamState) => {
        return {
          ...prev,
          startDate: undefined,
          endDate: undefined,
        };
      });
    }
    setCurrentPage(1);
  }, [dateRangeFilter]);

  useEffect(() => {
    setQueryIsFetching(isFetching);
  }, [isFetching, setQueryIsFetching]);

  const handlePageChange = (selectedPage: number, currentPageSize: number) => {
    setCurrentPage(selectedPage);
  };

  const handlePageSizeChange = (
    currentPage: number,
    selectedPageSize: number,
  ) => {
    setPageSize(selectedPageSize);
  };

  const exportHandler = useCallback(async () => {
    let exportResult = await exportProvisionData(paramState);
    const status = exportResult?.status;
    if (status === 200) {
      api.success({
        message: PROVISION_TABLE_TEXT.successMessage,
        description: PROVISION_TABLE_TEXT.successDescription,
        duration: 4,
      });
    } else {
      api.error({
        message: PROVISION_TABLE_TEXT.errorMessage,
        description: PROVISION_TABLE_TEXT.errorDescription,
        duration: 4,
      });
    }
    setTriggerExport(false);
  }, [api, paramState, setTriggerExport]);

  useEffect(() => {
    if (triggerExport) {
      exportHandler();
    }
  }, [triggerExport, exportHandler]);

  useEffect(() => {
    if (isError) {
      api.error({
        message: PROVISION_TABLE_TEXT.serverErrorMessage,
        description: PROVISION_TABLE_TEXT.serverErrorDescription,
        duration: 4,
      });
    }
  }, [isError, api]);

  useEffect(() => {
    if (data?.results) {
      const provisionLogDetails = processProvisionLogs(data.results);
      setProvisionLogDetails(provisionLogDetails);
    }
  }, [data?.results]);

  return (
    <div>
      {contextHolder}
      <div>
        <Table
          loading={isLoading || isFetching}
          columns={actionColumnList}
          dataSource={convertToProvisionTableData(data?.results)}
          scroll={{ x: "max-content" }}
          pagination={false}
          onChange={(pagination, filters, sorter) => {
            const sorters = Array.isArray(sorter) ? sorter : [sorter];

            sorters.forEach((sorter) => {
              if (sorter.order && sorter.columnKey) {
                const sortParam =
                  sorter.order === "ascend"
                    ? `${sorter?.columnKey}`
                    : `-${sorter?.columnKey}`;
                filters.sort = [...(filters.sort || []), sortParam];
              }
            });
            setCurrentPage(1);
            if (dateRangeFilter[0].length && dateRangeFilter[1].length) {
              const startDate = getUTCDate(dateRangeFilter[0]).toISOString();
              const endDate = getUTCDate(dateRangeFilter[1]).toISOString();
              setParamState({ ...filters, startDate, endDate });
            } else {
              setParamState(filters);
            }
          }}
          className="mt-4"
        />
      </div>
      <div
        className="flex justify-between mt-4 flex-wrap-reverse gap-4"
        style={{ display: isLoading ? "none" : "flex" }}
      >
        <LastUpdated time={dataUpdatedAt} />
        <div className="flex items-center">
          <Pagination
            showSizeChanger
            pageSizeOptions={[5, 10, 20, 30, 40, 50]}
            pageSize={pageSize}
            onShowSizeChange={handlePageSizeChange}
            current={currentPage}
            total={data?.totalResults}
            onChange={handlePageChange}
          />
          <ScrollHint />
        </div>
      </div>
      <Drawer
        title={PROVISION_TEXT.VIEW_LOG_DETAILS}
        placement="right"
        onClose={onClose}
        open={openDrawer}
      >
        <DetailsLog />
        {provisionLogDetails.map(
          (log, index) =>
            selectedRow?.id === log.id &&
            log.devices.map((device, index) => {
              const mac = device.mac;
              const sims: any[] = device.sims || [];
              const iccids = sims.map((sim) => sim.iccid).join(", ");
              return (
                <div key={index}>
                  <p className="font-medium">
                    {PROVISION_TEXT.DEVICE} {index + 1}
                  </p>
                  {iccids.length > 0 && (
                    <p>
                      {PROVISION_TEXT.ICCID}: {iccids}
                    </p>
                  )}
                  <p>
                    {PROVISION_TEXT.MACADDRESS}: {mac}
                  </p>
                  <p>
                    {PROVISION_TEXT.PROVIDER}: {log?.serviceProvider}
                  </p>
                  <p onClick={() => setOpenDetailsLogModal(true)}>
                    {PROVISION_TEXT.STATUS}:&nbsp;
                    <span
                      className="cursor-pointer text-blue-600 hover:text-blue-800"
                      onClick={() => handleDetailsLogClick(mac)}
                    >
                      {
                        selectedRow?.results.find(
                          (result) => result.mac === mac,
                        )?.status
                      }
                    </span>
                  </p>
                  <br />
                </div>
              );
            }),
        )}
      </Drawer>
    </div>
  );
};
