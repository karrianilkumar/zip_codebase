"use client";
import React, { useEffect, useState } from "react";
import { Modal, Select, Button, Form, notification, Spin } from "antd";
import { ChevronDownIcon } from "@heroicons/react/24/outline";
import axios from "axios";
import { useAuth } from "./auth_context";
import { getCurrentDateTime } from "./header_constants";
import { ENV_ROUTES } from "./routes/route_constants";
import VirtualizedMultiSelect from "./virtualized_multi_dropdown";
import { fireSideCannons } from "@/app/components/confetti";

const { Option } = Select;

export interface FeatureCodeRowData {
  service_provider_name: string;
  customer_name: string;
  soc_code: string;
  id: any;
}

interface EditableFeatureCodeProps {
  isOpen: boolean;
  onClose: () => void;
  rowData: FeatureCodeRowData | null;
  generalFields: any;
}

const messageStyle = {
  fontSize: '14px',  // Adjust font size
  fontWeight: 'bold', // Make the text bold
  padding: '16px',
  // Add padding
};

const EditableFeatureCode: React.FC<EditableFeatureCodeProps> = ({
  isOpen,
  onClose,
  rowData,
  generalFields,
}) => {
  const [form] = Form.useForm();
  const [selectedProvider, setSelectedProvider] = useState<string>("");
  const [selectedCustomer, setSelectedCustomer] = useState<string>("");
  const [selectedFeatureCodes, setSelectedFeatureCodes] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);
  const [serviceProviders, setServiceProviders] = useState<string[]>([]);
  const [customers, setCustomers] = useState<string[]>([]);
  const [featureCodes, setFeatureCodes] = useState<string[]>([]);
  const [serviceProviderCustomers, setServiceProviderCustomers] = useState<Record<string, string[]>>({});
  const { username, tenantNames, role, partner, settabledata, token ,selectedDb,metaData, firstLastName,sessionId} =
    useAuth();

  const fetchData = async () => {
    setLoading(true);
    try {
        const url = ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/customers_dropdown_data",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "Feature Codes",
            feature_module_name:"Rate Plans/SOCs",
            mod_pages: {
                start: 0,
                end: 100,
            },
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
            setLoading(false);
            Modal.error({
                title: 'Data Fetch Error',
                content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                centered: true,
            });
        } else {
            setLoading(false);
            setServiceProviders(Object.keys(parsedData?.service_provider_customers || []));
            setServiceProviderCustomers(parsedData?.service_provider_customers || []);
            setFeatureCodes(parsedData?.feature_codes || []);
            const providerCustomerMap=parsedData?.service_provider_customers || {}
            const customers_=providerCustomerMap[rowData?.service_provider_name || ""] ||[]
            setCustomers(customers_)
        }
    } catch (error) {
        Modal.error({
            title: 'Data Fetch Error',
            content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
            centered: true,
        });
    } finally {
        setLoading(false);
    }
};

const parseOptions = (value: any) => {
  if (typeof value === "string") {
    let parsedPlans: string[];
    try {
      parsedPlans = JSON.parse(value);
    } catch (err) {
      console.log("Error parsing JSON:", err);
      parsedPlans = [];
    }
    return Array.isArray(parsedPlans) ? parsedPlans : [];
  }

  if (Array.isArray(value)) {
    return value;
  }

  return [];
};
useEffect(() => {
  if (isOpen) {
    console.log("rowData",rowData)
    // Initialize form fields and state with default values
    form.setFieldsValue({
      provider: rowData?.service_provider_name || "",
      customer: rowData?.customer_name || "",
      featureCodes: rowData?.soc_code || "",
    });
    setSelectedProvider(rowData?.service_provider_name || "");
    setSelectedCustomer(rowData?.customer_name || "");
    const feature_codes =rowData?.soc_code || "";
    console.log("feature_codes",feature_codes)
    setSelectedFeatureCodes(feature_codes);
  }
}, [isOpen, rowData, form]);

useEffect(() => {
  fetchData()
}, [isOpen]);

  const handleProviderChange = (value: string) => {
    setCustomers([]);
    setSelectedProvider(value);
    setSelectedCustomer(""); // Reset customer selection
    if (value) {
      setCustomers(serviceProviderCustomers[value] || []);
    } else {
      setCustomers([]);
    }
    form.setFieldsValue({ customer: "", featureCodes: [] }); // Reset form fields
    setSelectedFeatureCodes("");
  };

  const renderLabel = (label: string, required: boolean) => (
    <span className="field-label">
      {label}{" "}
      {required && (
        <span className="required-indicator" style={{ color: "red" }}>
          *
        </span>
      )}
    </span>
  );

  const handleCustomerChange = (value: string) => {
    setSelectedCustomer(value);
  };

  const handleFeatureCodeChange = (value: string) => {
    setSelectedFeatureCodes(value);
  };

  const onFinish = async (values: { [key: string]: any }) => {
    setLoading(true);
    try {
      const { provider, customer, featureCodes } = values;
      const formData = {
        service_provider_name: provider,
        // customer_name: customer,
        soc_code: featureCodes,
        is_active: "True",
        is_deleted : "False",
        id: rowData?.id,
        modified_by:firstLastName,
        modified_date:getCurrentDateTime()
      };

      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/update_sim_management_modules_data",
        role_name: role,
        parent_module: "Sim Management",
        module: "Feature Codes",
        table_name: "mobility_feature",
        action: "update",
        changed_data: formData,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name:selectedDb,
        ...metaData,
        sessionID: sessionId,
      };

      // API call to update data
      const response = await axios.post(
        ENV_ROUTES.SIM_MANAGEMENT,
        { data }
      );
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        // Show error modal if data update fails
        Modal.error({
          title: "Data Update Error",
          content:
            parsedData.message ||
            "An error occurred while updating data. Please try again.",
          centered: true,
        });
      } else {
        // Close the modal after successfully fetching new data
        onClose();
        notification.success({
          message: 'Success',
          description: 'Successfully updated the record!',
          style: messageStyle,
          placement: 'top', // Apply custom styles here
          });
          fireSideCannons()
          setLoading(false)
        // Fetch updated data
        try {
          const url =ENV_ROUTES.MODULE_MANAGEMENT;
          const fetchData = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/get_module_data",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "Feature Codes",
            feature_module_name:"Rate Plans/SOCs",
            mod_pages: {
              start: 0,
              end: 100,
            },
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name:selectedDb,
            sessionID: sessionId,
          };

          const fetchResponse = await axios.post(url, { data: fetchData });
          const fetchParsedData = JSON.parse(fetchResponse.data.body);
          const tableData_ =
            fetchParsedData?.data?.mobility_feature ||
            [];
          settabledata(tableData_);
          
        } catch (error) {
          console.error("Error fetching data:", error);
          Modal.error({
            title: "Data Fetch Error",
            content:
              error instanceof Error
                ? error.message
                : "An unexpected error occurred while fetching data. Please try again.",
            centered: true,
          });
        }
      }
    } catch (error) {
      notification.error({
        message: "Error",
        description: "Failed to update the record. Please try again.",
      });
    } finally {
      setLoading(false);
    }
  };

  const customOptionRenderer = (value: any) => {
    return featureCodes.includes(value) ? (
      <Option key={value} value={value}>
        {value}
      </Option>
    ) : (
      <Option key={value} value={value} disabled>
        {value} (Not in options)
      </Option>
    );
  };

  return (
    <Modal
      title="Edit Feature Codes Plans"
      visible={isOpen}
      onCancel={onClose}
      footer={null}
      centered
    >
      {loading ? (
        <div className="flex justify-center items-center w-full h-32">
          <Spin size="large" />
        </div>
      ) : (
        <Form
          form={form}
          layout="vertical"
          onFinish={onFinish}
          requiredMark={false}
        >
          <Form.Item
            label={renderLabel("Service Provider", true)}
            name="provider"
            rules={[
              { required: true, message: "Please select service provider" },
            ]}
          >
            <Select
              value={selectedProvider}
              onChange={handleProviderChange}
              style={{ width: "100%" }}
              placeholder="Select a Service Provider"
              suffixIcon={
                <ChevronDownIcon className="w-5 h-5 mt-2 text-gray-600" />
              }
              className='mb-2'
            >
              {serviceProviders.map((provider: string) => (
                <Option key={provider} value={provider}>
                  {provider}
                </Option>
              ))}
            </Select>
          </Form.Item>

          {/* <Form.Item
            label={renderLabel("Customer", true)}
            name="customer"
            rules={[{ required: true, message: "Please select customer" }]}
          >
            <Select
              showSearch
              value={selectedCustomer}
              onChange={handleCustomerChange}
              style={{ width: "100%" }}
              placeholder="Select a customer"
              disabled={!selectedProvider}
              suffixIcon={
                <ChevronDownIcon className="w-5 h-5 mt-2 text-gray-600" />
              }
              className='mb-2'
            >
              {customers.map((customer: string, index: number) => (
                <Option key={index} value={customer}>
                  {customer}
                </Option>
              ))}
            </Select>
          </Form.Item> */}

          <Form.Item
            label={renderLabel("Feature Codes", true)}
            name="featureCodes"
            rules={[{ required: true, message: "Please select feature codes" }]}
          >
            <Select
            // mode="multiple"
            style={{ width: "100%" }}
            value={selectedFeatureCodes}
            onChange={handleFeatureCodeChange}
            maxTagCount="responsive"
            showSearch
            // maxTagPlaceholder={(omittedValues) =>
            //   `+${omittedValues.length} more`
            // }
          >
            {featureCodes.map((carrier) => (
              <Option key={carrier} value={carrier}>
                {carrier}
              </Option>
            ))}
          </Select>
            {/* <Select
              mode="multiple"
              style={{ width: "100%" }}
              placeholder="Select feature codes"
              value={selectedFeatureCodes}
              onChange={handleFeatureCodeChange}
              suffixIcon={
                <ChevronDownIcon className="w-5 h-5 mt-2 text-gray-600" />
              }
              maxTagCount="responsive"
              maxTagPlaceholder={(omittedValues) =>
                `+${omittedValues.length} more`
              }
            >
              {featureCodes.map((feature: string, index: number) => (
                <Option key={index} value={feature}>
                  {feature}
                </Option>
              ))}
            </Select> */}
          </Form.Item>

          <div className="flex justify-center space-x-2 mt-4">
            <button onClick={onClose} className="cancel-btn">
              Cancel
            </button>
            <button
              
              type="submit"
              className="save-btn"
              
            >
              Save
            </button>
          </div>
        </Form>
      )}
    </Modal>
  );
};

export default EditableFeatureCode;
