import React, { useCallback, useEffect, useRef, useState } from "react";
import { Input, Button, Modal, Spin } from "antd";
import { SearchOutlined, CloseOutlined } from "@ant-design/icons";
import axios from "axios";
import { useAuth } from "./auth_context";
import { useFeatureStore } from "../sim_management/inventory/featureStore";
import { MultiValue } from "react-select";
import { ENV_ROUTES } from "./routes/route_constants";
import { useSearchStore } from "../stores/searchStore";
import { debounce } from "lodash";
import { useOptimizationStore } from "@/app/stores/optimizationStore";
import { useCustomerRatePlanStore } from "../stores/customerRateplanStore";
import { useCustomerProfileStore } from "../billing/killbill_stores/customer_profile_store";
import { useChargesModalDataStore } from "../billing/killbill_stores/chargesModalData_store";
import { usePartnerCreationStore } from "../stores/partnerCreationStore";
interface SearchInputProps {
  searchTerm: string;
  setSearchTerm: (term: string) => void;
  placeholder?: string;
  width?: string;
  tableName: string;
  headerMap: Record<string, any>;
  loader?: boolean;
  selectedSubPartner?: any;
  selectedPartner?: any;
  isPartnerInfoModal?: boolean;
  filters?: {
    sync_status: string;
    service_provider: string;
    tenant_name: string;
    start_date: any;
    end_date: any;
  };
}

interface HeaderOption {
  value: string;
  label: string;
}

const TableSearch: React.FC<SearchInputProps> = ({
  searchTerm,
  setSearchTerm,
  placeholder = "Search...",
  headerMap = {},
  tableName,
  selectedSubPartner,
  selectedPartner,
  isPartnerInfoModal,filters
}) => {
  const { SetselectedRowData2o } = useFeatureStore();
  const headers = Object.keys(headerMap); // Get the keys of the headerMap
  const [selectedHeaders, setSelectedHeaders] = useState<HeaderOption[]>([]);
  const [colsList, setColsList] = useState<string[]>([]);
  const [searchTable, setSearchTable] = useState<any[]>([]);
  const { setCombineAdnvaceStoredpagination,advancedStoredpagination,storedpagination,combineAdnvaceStoredpagination,username, partner, role, settabledata, tabledata, setStoredPagination, setAdvancedStoredPagination, tenantId, selectedDb,selectedBillingDb,metaData, tenantName, sessionId, setWholeSearchWord,firstLastName } =
    useAuth();
  const { setSearchData, setOptimizationErrorsData, setOptimizationErrorsPagination,advancedSearchData,combineAdnvaceSearchData,setCombineAdnvaceSearchData, setIsSearchComponentCall ,optimizationErrorsData,optimizationErrorsPagination,isRedirectedFromDetails, detailsRedirectedFilters, detailsRedirectedSearchTerm , setDetailsRedirectedSearchTerm, setIsRedirectedFromDetails,setDetailsRedirectedFilters,setChargeDetailsSearchData ,chargeDetailsSearchData,setChargeDetailsTableData,setChargesDetailsPagination,setCreditDetailsTableData, creditDetailsSearchData ,setCreditDetailsPagination,setCreditDetailsSearchData, setRecurringChargesPagination,setRecurringChargesSearchData,setRecurringChargesTableData, recurringChargesSearchData,recurringChargesPagination,recurringChargesTableData,chargeDetailsTableData,chargesDetailsPagination,creditDetailsPagination,creditDetailsTableData} = useSearchStore();
  const [loading, setLoading] = useState(false);
  const [inputValue, setInputValue] = useState(searchTerm);
  const { optimizationRow } = useOptimizationStore();
  const { customerShowActive ,partnerUsersShowActive,privateNetworksShowActive} = useCustomerRatePlanStore();
  const { accountNumber, BillId } = useCustomerProfileStore();
  const { setUsageDetailsTableData, setCreditTableData, setChargesTableData, setChargeByServiceTableData, setRecurringChargeData } = useChargesModalDataStore();
  const bulkRow :any= JSON.parse(localStorage.getItem('bulk_row') || '{}');
  const iccid :any= localStorage.getItem('iccid') || '0';

  const { editPartnerDBName, editPartnerMetaData, setUpAction, customerGroupName } = usePartnerCreationStore()
  const partner_row = JSON.parse(localStorage.getItem("partner_row") || "{}")
  const isUnpostedUploadRow = JSON.parse(sessionStorage.getItem('UnpostedUploadRow') || '{}');

  const setupAction_ = setUpAction ? setUpAction.toString().toLowerCase() : ""
  const partnerName = partner_row?.partner || ""
  const subPartner = partner_row?.sub_partner && setupAction_.includes("sub tenant") ? partner_row?.sub_partner : ""
  const selected_info_partner = subPartner ? subPartner : partnerName || ""
  const defaultPartner = partner || ""
  const selectedPartnerName = isPartnerInfoModal ? selected_info_partner : defaultPartner
  const selectedPartnerDBName = isPartnerInfoModal ? editPartnerDBName : selectedDb
  const selectedPartnerMetaData = isPartnerInfoModal ? editPartnerMetaData : metaData


  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if(tableName === "Inventory" || tableName === "sim_management_bulk_change"){
      if (isRedirectedFromDetails) {
              const allEmpty = Object.values(detailsRedirectedFilters).every(
                (value) => Array.isArray(value) && value.length === 0
              );
              const isEmptySearchTerm = detailsRedirectedSearchTerm === ""
              if (!isEmptySearchTerm) {
                setInputValue(detailsRedirectedSearchTerm)
                setSearchTerm(detailsRedirectedSearchTerm)
                handleNormalButtonClick(detailsRedirectedSearchTerm)
              }
            }
    }
  }, []);
  useEffect(() => {
    if(tableName === "customer_optimization_list_view" || tableName === "carrier_optimization_list_view"){
      if (isRedirectedFromDetails) {
              const allEmpty = Object.values(detailsRedirectedFilters).every(
                (value) => Array.isArray(value) && value.length === 0
              );
              const isEmptySearchTerm = detailsRedirectedSearchTerm === ""
              if (!isEmptySearchTerm) {
                setInputValue(detailsRedirectedSearchTerm)
                setSearchTerm(detailsRedirectedSearchTerm)
                handleNormalButtonClick(detailsRedirectedSearchTerm)
              }
            }
    }
  }, [isRedirectedFromDetails]);

  useEffect(() => {
    setWholeSearchWord(searchTerm);
    console.log(searchTerm,"searchTerm");
  }, [searchTerm]);

  // useEffect(() => {
  //   setInputValue(inputValue);
  // }, [inputValue]);
  
  // useEffect(() => {
  //   if(searchTable.length>0 && tabledata.length>0 && searchTable!==tabledata){
  //     if(!combineAdnvaceStoredpagination){
  //       handleClear()
  //     }
  //   }
  // }, [tabledata,searchTable]);

  useEffect(() => {
      if(!advancedStoredpagination && !combineAdnvaceStoredpagination && searchTerm!==""){
        // handleNormalButtonClick();
        handleClear()
      }
    }, [advancedStoredpagination, combineAdnvaceStoredpagination]);
  
  const debouncedSearch = useCallback(
    debounce((value: string) => {
      // setStoredPagination(null);
      // setAdvancedStoredPagination(null);
      console.log("debouncedSearch called with value:", value);
      if(tableName !== "Carrier Status Mapping"){
        setOptimizationErrorsPagination(null)
      }
      setSearchTerm(value);
    }, 300),
    [setStoredPagination, setAdvancedStoredPagination, setSearchTerm]
  );

  // useEffect(() => {
  //   return () => {
  //     debouncedSearch.cancel();
  //   };
  // }, [debouncedSearch]);

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;

    // Immediately update input value
    setInputValue(value);

    // Trigger debounced search for the actual search functionality (API call)
    debouncedSearch(value);
  };

  const handleClear = () => {
    SetselectedRowData2o([])
    setInputValue("");
    setStoredPagination(null);
    setCombineAdnvaceStoredpagination(null)
    setCombineAdnvaceSearchData(null)
    setOptimizationErrorsPagination(null)
    // setAdvancedStoredPagination(null)
    setSearchTerm("");
    setIsRedirectedFromDetails(false)
    setDetailsRedirectedSearchTerm("")
    if(tableName === "Credit Details"){
      setChargesDetailsPagination(null)
      setChargeDetailsSearchData({})
    }
    if(tableName === "Charge Details"){
      setCreditDetailsPagination(null)
      setCreditDetailsSearchData({})
    }
    if(tableName === "Recurring Charge Details"){
      setRecurringChargesPagination(null)
      setRecurringChargesSearchData({})
    }
  };


  const handleHeaderChange = (selectedOptions: MultiValue<HeaderOption>) => {
    const selectedValues = selectedOptions.map((option) => option.value);
    setSelectedHeaders(selectedOptions as HeaderOption[]);
    setColsList(selectedValues);
  };

  const handleNormalButtonClick = async (redirectedValue?:any) => {
    SetselectedRowData2o([])
    setIsSearchComponentCall(true)
    // console.log(advancedStoredpagination,"AdvancedStoredPagination");
    // console.log(storedpagination,"storedpagination");
    // console.log(optimizationErrorsPagination,"optimizationErrorsPagination");
    // console.log(optimizationErrorsData,"optimizationErrorsData");

    // setAdvancedStoredPagination(null)
    console.log(advancedSearchData,"AdnvacedsearchData");
    // setStoredPagination(null);  removed the pagination setting to null
    if (tableName === "Charge Details" || tableName === "Credit Details" || tableName === "Recurring Charge Details") {
      handleChargesModalButtonClick(redirectedValue);
    }
    else{
      handlegeneralButtonClick(redirectedValue);
    }
   
  };
  const handleChargesModalButtonClick = async (redirectedValue?: any ) => {
  const pagination_ =
        tableName === "Charge Details"
          ? chargesDetailsPagination
          : tableName === "Credit Details"
            ? creditDetailsPagination
            : tableName === "Recurring Charge Details"
              ? recurringChargesPagination
              : advancedStoredpagination;

      const tableSearchData =
        tableName === "Charge Details"
          ? chargeDetailsSearchData
          : tableName === "Credit Details"
            ? creditDetailsSearchData
            : tableName === "Recurring Charge Details"
              ? recurringChargesSearchData
              : advancedSearchData;

      const effectiveSearchData = combineAdnvaceSearchData
        ? combineAdnvaceSearchData
        : tableSearchData;

    if ((pagination_ && effectiveSearchData) && combineAdnvaceStoredpagination) {
      handleCombineButtonClick(effectiveSearchData);
    }else{
      try {
        setLoading(true);
        const url = ENV_ROUTES.OPEN_SEARCH;
        const data = {
          data: {
            path: "/perform_search",
            search_word: (tableName === "Credit Details" || tableName === "Charge Details" || tableName === "Recurring Charge Details" )? searchTerm : redirectedValue ? redirectedValue :inputValue,
            search_all_columns:
              colsList.length === headers.length || colsList.length === 0
                ? "True"
                : "False",
            index_name: tableName,
            tenant_id: tenantId,
            partner: selectedPartnerName,
            username: username,
            db_name:["Usage Details","Charge By Service","Credit Details" ,"Charge Details","Recurring Charge Details" ,"Billing Service Providers"].includes(tableName)? selectedBillingDb:selectedPartnerDBName,
            sessionID: sessionId,
            ...selectedPartnerMetaData,
            search: "whole",
            pages: {
              start: 0,
              end:tableName === "optimization_instance_summary" || tableName === "optimization_error_details" ? 10 : 100,
            },
            ...(tableName === "status_history" && iccid && iccid !== "None" && iccid !== ""
              ? { iccid: [iccid] }
              : {}),
            ...(tableName === "status_history" && iccid && iccid !== "None" && iccid !== ""
              ? { flag: "status_history" }
              : {}),
            ...(tableName === "sim_management_bulk_change_request" && bulkRow && bulkRow !== null ? { flag: "bulk_history" } : {}),
            ...(tableName === "sim_management_bulk_change_request" && bulkRow && bulkRow !== null
              ? { bulk_change_id:bulkRow?.row?.bulk_change_id || bulkRow?.row?.id || "0"}
              : {}),
            ...(tableName === "optimization_instance_summary" || tableName === "optimization_error_details"
              ? { session_id: optimizationRow.session_id }
              : {}),
            ...(tableName === "Customer_Rate_Plan"
              ? { toggle: customerShowActive }
              : {}),
            ...(tableName === "rev_assurance"
              ? { toggle: customerShowActive }
              : {}),
               ...(tableName === "partner_users"
              ? { toggle: partnerUsersShowActive }
              : {}),
              ...(tableName === "Private_Networks"
              ? { toggle: privateNetworksShowActive }
              : {}),
              ...(tableName === "Unposted Upload Data"
                ? {upload_id : isUnpostedUploadRow?.row.id || 0} : {}),
                ...(tableName === "Usage Details" || tableName === "Charge By Service" || tableName === "Credit Details" || tableName === "Charge Details"|| tableName === "Recurring Charge Details" ? { bill_id : BillId , account_number: accountNumber,} : {}),
               ...(tableName === "Billing Service Providers" && selectedPartner && { Selected_Partner: selectedPartner }),
          ...(tableName === "Billing Service Providers" && selectedSubPartner && { sub_partner: selectedSubPartner }),
          ...(tableName ==="customer_groups" && {
            firstLastName:firstLastName
          }),
          },
        };
        setSearchData(data)
        const response = await axios.post(url, data);
        const parsedData = JSON.parse(response.data.body);
        if (parsedData?.flag) {
          const tableData = parsedData?.data?.table || [];
          const pagination_ = parsedData?.pages || {};
          if (tableName === "optimization_error_details" || tableName === "tenant_based_banners_logs") {
            setOptimizationErrorsData(tableData)
            setOptimizationErrorsPagination(pagination_)
          }
           //billing charges related tables
          else if(tableName === "Usage Details"){
            setUsageDetailsTableData(tableData)
          }
          else if(tableName === "Charge By Service"){
            setChargeByServiceTableData(tableData)
          }

          else if(tableName === "Charge Details"){
            setChargeDetailsTableData(tableData)
            setChargesDetailsPagination(pagination_)
            setChargeDetailsSearchData(data);
          }
           else if(tableName === "Credit Details"){
            setCreditDetailsTableData(tableData)
            setCreditDetailsPagination(pagination_)
            setCreditDetailsSearchData(data);
          }
           else if(tableName === "Recurring Charge Details"){
            setRecurringChargesTableData(tableData)
            setRecurringChargeData(tableData)
            setRecurringChargesPagination(pagination_)
            setRecurringChargesSearchData(data);
          }

          // else if(tableName === "Charge Overview"){
          //   setRecurringChargeData(parsedData?.data?.table?.charge_overview_recurring_charges || [])
          //   setCreditTableData(parsedData?.data?.table?.charge_overview_account_credits || [])
          //   setChargesTableData(parsedData?.data?.table?.charge_overview_account_charges || [])
          // }
          else {
            settabledata(tableData);
          }
            setSearchTable(tableData)
            // if(tableName !== "Credit Details" && tableName !== "Charge Details"){
              setStoredPagination(pagination_);
            // }
            
            if((tableName === "Inventory" || tableName === "sim_management_bulk_change"  || tableName === "customer_optimization_list_view" || tableName === "carrier_optimization_list_view") && inputValue ){
              setDetailsRedirectedSearchTerm(inputValue)
              setDetailsRedirectedFilters({})
            }
          if (tableData.length === 0) {
            Modal.error({
              title: "No Records found",
            });
          handleClear()
          }
        } else {
          Modal.error({
            title: "Search error",
            content:
              parsedData.error ||
              "An error occurred while searching. Please try again.",
          });
          handleClear()
        }
        console.log(response);
      } catch (error) {
        console.log(error);
      } finally {
        setLoading(false); // Stop loader
      }
    } 
  }
  const handlegeneralButtonClick = async (redirectedValue?: any) => {
     if(((advancedStoredpagination && advancedSearchData) || (optimizationErrorsPagination && optimizationErrorsData) || (chargesDetailsPagination && chargeDetailsTableData) || (creditDetailsPagination && creditDetailsTableData) || (recurringChargesPagination && recurringChargesTableData)) || combineAdnvaceStoredpagination ){
      const data = tableName === "Charge Details" ? chargeDetailsSearchData: tableName === "Credit Details" ? creditDetailsSearchData : tableName === "Recurring Charge Details" ? recurringChargesSearchData : combineAdnvaceSearchData ?combineAdnvaceSearchData : advancedSearchData
      handleCombineButtonClick(data);
    }else{
      try {
        setLoading(true);
        const url = ENV_ROUTES.OPEN_SEARCH;
        const data = {
          data: {
            path: "/perform_search",
            search_word: (tableName === "Credit Details" || tableName === "Charge Details" || tableName === "Recurring Charge Details" )? searchTerm : redirectedValue ? redirectedValue :inputValue,
            search_all_columns:
              colsList.length === headers.length || colsList.length === 0
                ? "True"
                : "False",
            index_name: tableName,
            tenant_id: tenantId,
            partner: selectedPartnerName,
            username: username,
            db_name:["Usage Details","Charge By Service","Credit Details" ,"Charge Details","Recurring Charge Details" ,"Billing Service Providers","Unposted Upload Data"].includes(tableName)? selectedBillingDb:selectedPartnerDBName,
            sessionID: sessionId,
            ...selectedPartnerMetaData,
            search: "whole",
            pages: {
              start: 0,
              end:tableName === "optimization_instance_summary" || tableName === "optimization_error_details" ? 10 : 100,
            },
            ...(tableName === "status_history" && iccid && iccid !== "None" && iccid !== ""
              ? { iccid: [iccid] }
              : {}),
            ...(tableName === "status_history" && iccid && iccid !== "None" && iccid !== ""
              ? { flag: "status_history" }
              : {}),
            ...(tableName === "sim_management_bulk_change_request" && bulkRow && bulkRow !== null ? { flag: "bulk_history" } : {}),
            ...(tableName === "sim_management_bulk_change_request" && bulkRow && bulkRow !== null
              ? { bulk_change_id:bulkRow?.row?.bulk_change_id || bulkRow?.row?.id || "0"}
              : {}),
            ...(tableName === "optimization_instance_summary" || tableName === "optimization_error_details"
              ? { session_id: optimizationRow.session_id }
              : {}),
            ...(tableName === "Customer_Rate_Plan"
              ? { toggle: customerShowActive }
              : {}),
            ...(tableName === "Filtered_Customer_Rate_Plan" && isPartnerInfoModal
            ? { customer_group_name: customerGroupName }
            : {}),
            ...(tableName === "rev_assurance"
              ? { toggle: customerShowActive }
              : {}),
               ...(tableName === "partner_users"
              ? { toggle: partnerUsersShowActive }
              : {}),
              ...(tableName === "Private_Networks"
              ? { toggle: privateNetworksShowActive }
              : {}),
                ...(tableName === "Unposted Upload Data"
                ? {upload_id : isUnpostedUploadRow?.row.id || 0} : {}),
                ...(tableName === "Usage Details" || tableName === "Charge By Service" || tableName === "Credit Details" || tableName === "Charge Details"|| tableName === "Recurring Charge Details" ? { bill_id : BillId , account_number: accountNumber,} : {}),
               ...(tableName === "Billing Service Providers" && selectedPartner && { Selected_Partner: selectedPartner }),
          ...(tableName === "Billing Service Providers" && selectedSubPartner && { sub_partner: selectedSubPartner }),
          ...(tableName ==="customer_groups" && {
            firstLastName:firstLastName
          }),
           ...(tableName === "Carrier Syncs" && {
            service_provider: filters?.service_provider,
            start_date: filters?.start_date,
            end_date: filters?.end_date,
            tenant_name: filters?.tenant_name})
          },
        };
        setSearchData(data)
        const response = await axios.post(url, data);
        const parsedData = JSON.parse(response.data.body);
        if (parsedData?.flag) {
          const tableData = parsedData?.data?.table || [];
          const pagination_ = parsedData?.pages || {};
          if (tableName === "optimization_error_details" || tableName === "tenant_based_banners_logs") {
            setOptimizationErrorsData(tableData)
            setOptimizationErrorsPagination(pagination_)
          }
           //billing charges related tables
          else if(tableName === "Usage Details"){
            setUsageDetailsTableData(tableData)
          }
          else if(tableName === "Charge By Service"){
            setChargeByServiceTableData(tableData)
          }

          else if(tableName === "Charge Details"){
            setChargeDetailsTableData(tableData)
            setChargesDetailsPagination(pagination_)
            setChargeDetailsSearchData(data);
          }
           else if(tableName === "Credit Details"){
            setCreditDetailsTableData(tableData)
            setCreditDetailsPagination(pagination_)
            setCreditDetailsSearchData(data);
          }
           else if(tableName === "Recurring Charge Details"){
            setRecurringChargesTableData(tableData)
            setRecurringChargeData(tableData)
            setRecurringChargesPagination(pagination_)
            setRecurringChargesSearchData(data);
          }

          // else if(tableName === "Charge Overview"){
          //   setRecurringChargeData(parsedData?.data?.table?.charge_overview_recurring_charges || [])
          //   setCreditTableData(parsedData?.data?.table?.charge_overview_account_credits || [])
          //   setChargesTableData(parsedData?.data?.table?.charge_overview_account_charges || [])
          // }
          else {
            settabledata(tableData);
          }
            setSearchTable(tableData)
            // if(tableName !== "Credit Details" && tableName !== "Charge Details"){
              setStoredPagination(pagination_);
            // }
            
            if((tableName === "Inventory" || tableName === "sim_management_bulk_change"  || tableName === "customer_optimization_list_view" || tableName === "carrier_optimization_list_view") && inputValue ){
              setDetailsRedirectedSearchTerm(inputValue)
              setDetailsRedirectedFilters({})
            }
          if (tableData.length === 0) {
            Modal.error({
              title: "No Records found",
            });
          handleClear()
          }
        } else {
          Modal.error({
            title: "Search error",
            content:
              parsedData.error ||
              "An error occurred while searching. Please try again.",
          });
          handleClear()
        }
        console.log(response);
      } catch (error) {
        console.log(error);
      } finally {
        setLoading(false); // Stop loader
      }
    }
  }
  const handleCombineButtonClick = async (advancedSearchData_: any) => {
    setLoading(true);
    const filters_ =advancedSearchData_?.data?.filters
    try {
      const url = ENV_ROUTES.OPEN_SEARCH;
      const data = {
        data: {
          path: "/perform_search",
          search: "combined",
          filters: filters_,
          search_word: (tableName === "Credit Details" || tableName === "Charge Details" || tableName === "Recurring Charge Details") ? searchTerm : inputValue,
          search_all_columns: "True",
          index_name: tableName,
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: selectedPartnerName,
          username: username,
             ...(tableName === "Billing Service Providers" && selectedPartner && { Selected_Partner: selectedPartner }),
          ...(tableName === "Billing Service Providers" && selectedSubPartner && { sub_partner: selectedSubPartner }),
           ...(tableName === "Usage Details" || tableName === "Charge By Service" || tableName === "Credit Details" || tableName === "Charge Details"|| tableName === "Recurring Charge Details" ? { bill_id : BillId , account_number: accountNumber,} : {}),
          db_name:["Usage Details","Charge By Service","Credit Details" ,"Charge Details","Recurring Charge Details","Billing Service Providers"].includes(tableName)? selectedBillingDb:selectedPartnerDBName,
          sessionID: sessionId,
          ...selectedPartnerMetaData,
        ...(tableName === "rev_assurance" || tableName === "Customer_Rate_Plan"
          ? { toggle: customerShowActive }
          : {}),
        ...(tableName === "Filtered_Customer_Rate_Plan" && isPartnerInfoModal
            ? { customer_group_name: customerGroupName }
            : {}),
        ...(tableName === "status_history" && iccid && iccid !== "None" && iccid !== ""
          ? { flag: "status_history" }
          : {}),
        ...(tableName === "sim_management_bulk_change_request" && bulkRow && bulkRow !== null
          ? { flag: "bulk_history" }
          : {}),
        ...(tableName === "high_usage_customers" || tableName === "optimization_errors"
          ? { session_id: optimizationRow.session_id }
          : {}),
           ...(tableName === "partner_users"
              ? { toggle: partnerUsersShowActive }
              : {}),
              ...(tableName === "Private_Networks"
              ? { toggle: privateNetworksShowActive }
              : {}),
          ...(tableName ==="customer_groups" && {
            firstLastName:firstLastName
          }),
          ...(tableName === "Carrier Syncs" && {
            service_provider: filters?.service_provider,
            start_date: filters?.start_date,
            end_date: filters?.end_date,
            tenant_name: filters?.tenant_name})
          },
      };
      
      setCombineAdnvaceSearchData(data);
      const response = await axios.post(url, data);
      const parsedData = JSON.parse(response.data.body);
      
      if (parsedData?.flag) {
        const tableData = parsedData?.data?.table;
          const pagination__ = parsedData?.pages || {};
         //billing charges related tables
          if(tableName === "Usage Details"){
            setUsageDetailsTableData(tableData)
          }
          else if(tableName === "Charge By Service"){
            setChargeByServiceTableData(tableData)
          }

          else if(tableName === "Charge Details"){
            setChargeDetailsTableData(tableData)
            setChargesDetailsPagination(pagination__)
            setChargeDetailsSearchData(data);
          }
           else if(tableName === "Credit Details"){
            setCreditDetailsTableData(tableData)
            setCreditDetailsPagination(pagination__)
            setCreditDetailsSearchData(data);
          }
           else if(tableName === "Recurring Charge Details"){
            setRecurringChargesTableData(tableData)
            setRecurringChargeData(tableData)
            setRecurringChargesPagination(pagination__)
            setRecurringChargesSearchData(data);
          }
          else{
            settabledata(tableData);
          }
          const pagination_ = parsedData?.pages || {};
          setCombineAdnvaceStoredpagination(pagination_);
          setSearchTable(tableData)
        
        if (tableData.length === 0) {
          Modal.error({
            title: "No Records found",
          });
        handleClear()
        }
      } else {
        Modal.error({
          title: "Search error",
          content: parsedData.error || "An error occurred while searching. Please try again.",
        });
        handleClear()
      }
    } catch (error) {
      console.error(error);
    }
    finally{
    setLoading(false);
    }
  };

  return (
    <div className="">
      {loading && (
        <div className="fixed inset-0 flex justify-center items-center adv-search-loader bg-white bg-opacity-75 z-50 pointer-events-none">
          <Spin size="large" />
        </div>
      )}
      <div className="flex items-center space-x-2">
        <div className="relative flex items-center border border-gray-300 rounded-lg p-1 w-full space-x-4 w-[250px]">
          <input
            placeholder={placeholder}
            value={inputValue}
            onChange={handleSearch}
            ref={inputRef}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                handleNormalButtonClick();
              }
            }}
            className="h-8 border-none outline-none w-full pl-2 pr-12 rounded-lg search-input"
          />
          {searchTerm && (
            <CloseOutlined
              className="absolute right-8 text-gray-500 cursor-pointer"
              onClick={handleClear}
            />
          )}
          <SearchOutlined
            className="absolute right-2 text-gray-500 cursor-pointer"
            onClick={()=>handleNormalButtonClick()}
          />
        </div>
        {(searchTerm && (typeof window !== "undefined" && window.innerWidth > 700))&& (
          <button
            className="filter-btn save-btn hidden md:inline-flex"
            onClick={()=>handleNormalButtonClick()}
          >
            Search
          </button>
        )}
      </div>
    </div>
  );
};

export default TableSearch;
