"use client";
import React, { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import {
  PencilIcon,
  TrashIcon,
  InformationCircleIcon,
  UserIcon,
  CheckCircleIcon,
  XCircleIcon,KeyIcon,
  ChevronDownIcon,
  CheckIcon,
  NoSymbolIcon
} from "@heroicons/react/24/outline";
import dayjs, { Dayjs } from "dayjs";
import { CopyOutlined, DownOutlined, MoreOutlined } from "@ant-design/icons";
import EditModal from "../../components/editPopup";
import Pagination from "@/app/components/pagination";
import EditUsernameCellRenderer from "./data-grid-cell-renderers/edit-username-cell-renderer";
import { StatusCellRenderer } from "./data-grid-cell-renderers/status-cell-renderer";
import { StatusHistoryCellRenderer } from "./data-grid-cell-renderers/status-history-cell-renderer";
import ServiceProviderCellRenderer from "./data-grid-cell-renderers/service-provider-cell-renderer";
import { Modal, Checkbox, notification, Spin, Tooltip, Button, Radio, Dropdown, Menu } from "antd";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import ActionItems from "@/app/components/Table-feautures/action-items";
import {
  ArrowUpOutlined,
  ArrowDownOutlined,
  ExclamationCircleOutlined,
} from "@ant-design/icons";
import StatusIndicator from "./data-grid-cell-renderers/status-indicator";
import QuantityCell, {
  STATUS_TYPE,
} from "./data-grid-cell-renderers/quantity-cell-renderer";
import RatePlansCountCell from "./data-grid-cell-renderers/rate-plans-count-renderer";
import { ChangeDetailCellRenderer } from "./data-grid-cell-renderers/change-details-cell";
import { useAuth } from "../auth_context";
import axios from "axios";
import { getCurrentDateTime } from "../header_constants";
import { usePartnerStore } from "@/app/partner/partner_info/partnerStore";
import DisplaySimOrder from "../simOrderPopup";
import CommPlanModal from "../commPlanPopup";
import EditableFeatureCode from "../featureCodeEditPopup";
import { FeatureCodeRowData } from "../featureCodeEditPopup";
import EditCustomerModal from "@/app/sim_management/carrier_rate_plans_socs/optimization_groups/edit_optimization_type_group";
import EditEmailAuditTemplateModal from "@/app/partner/notifications/email_audit_info_popup";
import CreateEmailAuditTemplateModal from "@/app/partner/notifications/create_email_aduit_temp";
// import { useStateManager } from "react-select";
import { ENV_ROUTES } from "../routes/route_constants";
import EditRevCustomerModal from "../EditRevCustomerPopup";
import InfoRevIoPopup from "@/app/people/billing_customers/info_rev_io_customer";
import EditAutomation from "@/app/automation/edit_automation";
import AutomationInfo from "@/app/automation/automation_log_info/page";
import ImpersonateUserModal from "@/app/partner/partner_info/users/impersonateUserModal";
import { useSearchStore } from "@/app/stores/searchStore";
import { useDateRangeStore } from "@/app/stores/dateStoreDailyUsageReport";
import { usePartnerAPIStore } from "@/app/stores/partnerAPIStore";
import { usePartnerCreationStore } from "@/app/stores/partnerCreationStore";
import EditCustomerRatePlan from "@/app/sim_management/customer_rate_plans/editCustomerRatePlan";
import InfoCustomerRatePlan from "@/app/sim_management/customer_rate_plans/infoCustomerRatePlan";
import CopyCustomerRatePlan from "@/app/sim_management/customer_rate_plans/copyCustomerRatePlan";
import { useCustomerRatePlanStore } from "@/app/stores/customerRateplanStore";
import EditServiceProvider from "@/app/partner/partner_info/partner_info/editServiceProviderPopup";
import EditNotificationsModal from "@/app/partner/notifications/edit_notification";
import useCrossProviderStore from "@/app/stores/useCrossProviderStore";
import RowDetailsModal from "../rowDetailsModal";
import EditBanner from "@/app/super_admin/deployment_notifier/editTenantBanner";
import Select from "react-select";
import ProgressBar from "../optimizationTableComponent/cell-renderers/progressBar";
import { PerformanceLogStore } from "@/app/stores/performance_matrix_store";
import EditBillingCustomer from "../edit_billing_customer";
import { useCustomerProfileStore } from "@/app/billing/killbill_stores/customer_profile_store";
import { fireSideCannons } from "@/app/components/confetti";
import PrivateNetworksInfo from "@/app/super_admin/private_networks/privateNetworksInfo/page";
import AddPrivateNetworkIP from "@/app/super_admin/private_networks/privateNetworksActionPopup";
import { useChargesModalDataStore } from "@/app/billing/killbill_stores/chargesModalData_store";


interface TableComponentProps {
  headers: string[];
  initialData: { [key: string]: any }[];
  searchQuery: string;
  visibleColumns: string[];
  itemsPerPage: number;
  allowedActions?: (
    | "edit"
    | "delete"
    | "info"
    | "Actions"
    | "SingleClick"
    | "tabsEdit"
    | "tabsInfo"
    | "form"
    | "commPlan"
    | "formEditFeatureModal"
    | "editCustomerModal"
    | "infoCustomerModal"
    | "emailAuditing"
    | "copy"
    | "editEmail"
    | "editRev.ioCustomer"
    | "editCustomerRatePlan"
    | "copyCustomerRatePlan"
    | "infoCustomerRatePlan"
    | "infoRev.ioCustomer"
    | "copyFeature"
    | "automationEdit"
    | "automationInfo"
    | "impersonateUser"
    | "editServiceProvider"
    |"editBanner"
    |"copyBanner"
    | "editNotification"
    | "resetPassword"
    |"editPartnerCreation"
    | "lnpActions"
  )[];
  popupHeading: string;
  advancedFilters?: any;
  createModalData?: any[];
  generalFields?: any;
  isSelectRowVisible?: boolean;
  headerMap?: any;
  pagination: any;
  height?: any;
  onsave?:any;
  onRowAction?: (action: string, row: any) => void;
  onRowDataChange?: (updatedData: any[]) => void;
  selectedSubPartner?: any;
  selectedPartnerBP?:any;
  isPartnerInfoTable?:boolean;
  syncsData?: {
        start_date?: string;
        end_date?: string;
        sync_status?: string;
        selectedServiceProvider?: string;
        tenant_name?: string;
    };
}

export default function TableComponent({
  headers,
  initialData,
  searchQuery,
  visibleColumns,
  itemsPerPage,
  allowedActions,
  popupHeading,
  createModalData,
  generalFields,
  advancedFilters,
  isSelectRowVisible = true,
  headerMap,
  pagination,
  height,onsave,onRowAction,onRowDataChange,
  selectedSubPartner,
  selectedPartnerBP ,
  isPartnerInfoTable,
  syncsData = {}
}: TableComponentProps) {
  const router = useRouter();
  const { showAdvanced } = useCustomerRatePlanStore();
  const { customerShowActive, setCustomerShowActive, emailConditionModal, partnerUsersShowActive , privateNetworksShowActive } = useCustomerRatePlanStore();
  const {setModifiedPartnerRolesData,setModifiedPartnerModuleAccessData,setUpAction,editPartnerDBName,editPartnerMetaData,customerGroupName} = usePartnerCreationStore()
  const [rowData, setRowData] = useState<{ [key: string]: any }[]>(initialData);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [editRowIndex, setEditRowIndex] = useState<number | null>(null);
  // const [copyRowIndex, setCopyRowIndex] = useState<number | null>(null);
  const [formRowIndex, setFormRowIndex] = useState<number | null>(null);
  const [formModalOpen, setFormModalOpen] = useState(false);
  const [editFeatureModal, setEditFeatureModal] = useState(false);
  const [editRevIoCustomerModal, setEditRevIoCustomerModal] = useState(false);
  const [editRevIoCustomerRowIndex, setEditeditRevIoCustomerRowIndex] = useState<number | null>(null);
  const [editCustomerRatePlanModal, setEditCustomerRatePlanModal] = useState(false);
  const [editCustomerRatePlanRowIndex, setEditCustomerRatePlanRowIndex] = useState<number | null>(null);
  const [copyCustomerRatePlanModal, setCopyCustomerRatePlanModal] = useState(false);
  const [copyCustomerRatePlanRowIndex, setCopyCustomerRatePlanRowIndex] = useState<number | null>(null);
  const [infoCustomerRatePlanModal, setInfoCustomerRatePlanModal] = useState(false);
  const [infoCustomerRatePlanRowIndex, setInfoCustomerRatePlanRowIndex] = useState<number | null>(null);
  const [editOptimizationModal, setEditOptimizationModal] = useState(false);
  const [EditOptimizationRowIndex, setEditOptimizationRowIndex] = useState<number | null>(null);
  const [EditFeatureRowIndex, setEditFeatureRowIndex] = useState<number | null>(null);
  const [commPlanModalOpen, setCommPLanModalOpen] = useState(false);
  const [commPlanRowIndex, setCommPlanRowIndex] = useState<number | null>(null);
  const [isEditable, setIsEditable] = useState(false);
  const [isEmailAuditInfoModal, setisEmailAuditInfoModal] = useState(false);
  const [isCopyEmailModal, setCopyEmailModal] = useState(false);
  const [isEditEmailModal, setEditEmailModal] = useState(false);
  const [isEditAddServiceProvider, setEditServiceProvider] = useState(false);
  const [isEditBannerOpen, setEditBannerOPen] = useState(false);
  const [editBannerRowIndex, setEditBannerRowIndex] = useState<number | null>(null);
  const [bannerAction, setBannerAction] = useState<string>("edit");
  const [isEditNotification, setEditNotification] = useState(false);
  const [isEditAutomationModalOpen, setEditAutomationModal] = useState(false);
  const [isInfoAutomationModalOpen, setInfoAutomationModal] = useState(false);
  const [isInfoRevIoCustomerModal, setInfoRevIoCustomerModal] = useState(false);
  const [openPrivateNetworksInfo, setOpenPrivateNetworksInfo] = useState(false);
  const [openPrivateNetworksEditModal, setOpenPrivateNetworksEditModal] = useState(false);
  const [openPrivateNetworksDeleteModal, setOpenPrivateNetworksDeleteModal] = useState(false);
   const [privateNetworkDeleteData, setPrivateNetworksDeleteData] = useState<any[]>([])
  const [privateNetworksDeleteRowIndex, setPrivateNetworksDeleteRowIndex] = useState<number | null>(null);
  const [privateNetworksInfoRowIndex, setPrivateNetworksInfoRowIndex] = useState<number | null>(null);
  const [privateNetworksEditRowIndex, setPrivateNetworksEditRowIndex] = useState<number | null>(null);
  const [isInfoRevIoCustomerRowIndex, setInfoRevIoCustomerRowIndex] = useState<number | null>(null);
  const [isCopyEmailRowIndex, setCopyEmailRowIndex] = useState<number | null>(null);
  const [isEditEmailRowIndex, setEditEmailRowIndex] = useState<number | null>(null);
  const [serviceProviderRowIndex, setServiceProviderRowIndex] = useState<number | null>(null);
  const [editNotificationRowIndex, setEditNotificationRowIndex] = useState<number | null>(null);
  const [isEmailAuditRowIndex, setEmailAuditRowIndex] = useState<number | null>(null);
  const [editAutomationRowIndex, setEditAutomationRowIndex] = useState<number | null>(null);
  const [infoAutomationRowIndex, setInfoAutomationRowIndex] = useState<number | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [resetPasswordModal, setResetPasswordModal] = useState(false);
  const [resetPasswordRowIndex, setResetPasswordRowIndex] = useState<number | null>(null);
  const [editPartnerModal, setEditPartnerModal] = useState(false);
  const [editPartnerRowIndex, setEditPartnerRowIndex] = useState<number | null>(null);
  const isFirstRender = useRef(true);
  const isFirstTableDataRender = useRef(true);
  const isFirstSearchRender = useRef(true);
  const isFirstAdvancedSearchRender = useRef(true);
  const [state, setState] = useState<string>("");
  const [rowIndex, setRowIndex] = useState<number>(0);
  const [columnName, setColumnName] = useState<string>("");
  const [selectAll, setSelectAll] = useState(false);
  const [selectedRows, setSelectedRows] = useState<number[]>([]);
  const [EnableModalOpen, setEnableModalOpen] = useState(false);
  const [DisableModalOpen, setDisableModalOpen] = useState(false);
  // const [currentRowData, setCurrentRowData] = useState<any>({});
  const [deleteModalOpen, setDeleteModalOpen] = useState(false);
  const [deleteRowIndex, setDeleteRowIndex] = useState<number | null>(null);
  const [sortConfig, setSortConfig] = useState<{ key: string; direction: "ascending" | "descending"; } | null>(null);
  const [tabsEdit, setTabsEdit] = useState(false);
  const [copyFeature, setCopyFeature] = useState(false);
  const [isConfirmationVisible, setIsConfirmationVisible] = useState(false);
  const [impersonateUser, setImpersonateUser] = useState(false);
  const [impersonateUserRowIndex, setImpersonateUserRowIndex] = useState<number | null>(null);
  const { startDateDailyReport, endDateDailyReport } = useDateRangeStore();
  const { selectedEnvironment, selectedPartner } = usePartnerAPIStore();
  const { usageByLineFilter, usageByLineFilterData } = useCrossProviderStore();
  const { getTargetTenantProvider, IsTargetTenantProvider } = PerformanceLogStore();
  const {
    username,
    tenantNames,
    role,
    partner,
    selectedPartnerModule,
    Environment,
    tabledata,
    settabledata,
    storedpagination,
    advancedStoredpagination,
    combineAdnvaceStoredpagination,
    token,
    selectedDb,
    selectedBillingDb,
    metaData,
    serviceProviderList,
    selectedServiceProvider,
    setAdvancedStoredPagination,
    setStoredPagination,
    setCombineAdnvaceStoredpagination,
    firstLastName,
    sessionId,
  } = useAuth();

  const [totalPages, setTotalPages] = useState(1);
  const [lastPageWithData, setLastPageWithData] = useState(1);
  const hasMounted = useRef(false);
  const { partnerData, setCustomerGroups, setPartnerUsers } =
    usePartnerStore.getState();
  const {features: moduleFeatures } = useFeatureStore();
  const [loading, setLoading] = useState(false);
  const [refreshPage, setRefreshPage] = useState(false)
  const { searchData, advancedSearchData, combineAdnvaceSearchData, isSearchComponentCall,setIsSearchComponentCall , billableOnSuspensionData , setbillableOnSuspensionData ,chargeDetailsTableData,setChargeDetailsTableData,chargesDetailsPagination,chargeDetailsSearchData,setChargesDetailsPagination} = useSearchStore();
  const bulkRow :any= JSON.parse(localStorage.getItem('bulk_row') || '{}');
  //Viewport height
  const [viewportHeight, setViewportHeight] = useState(window.innerHeight);
  // Add state to track screen width
  const [isSmallScreen, setIsSmallScreen] = useState(false);
  const [showRowModal, setShowRowModal] = useState<boolean>(false);
  const [showRowModalData, setShowRowModalData] = useState<any>(null);
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [newPasswordError, setNewPasswordError] = useState("");
  const [confirmPasswordError, setConfirmPasswordError] = useState("");
    const { setAccountNumber, accountNumber, setBillId, BillId } = useCustomerProfileStore();
   const [actionType, setActionType] = useState<string>("");
  const {setChargesTableData,chargesTableData} = useChargesModalDataStore();
   
  const billingStatusOptions = [
  { label: "Active", value: "Active" },
  { label: "Suspended", value: "Suspended" },
  { label: "Pending", value: "Pending" },
  { label: "Deactivated", value: "Deactivated" },
];
  // Check for small screen on component mount and window resize
  useEffect(() => {
      const checkScreenSize = () => {
          setIsSmallScreen(window.innerWidth < 700);
      };
      
      // Initial check
      checkScreenSize();
      
      // Add event listener for window resize
      window.addEventListener('resize', checkScreenSize);
      
      // Clean up
      return () => window.removeEventListener('resize', checkScreenSize);
  }, []);


  useEffect(() => {
    setAdvancedStoredPagination(null)
    setStoredPagination(null)
    setCombineAdnvaceStoredpagination(null)
    setChargesDetailsPagination(null)
    setIsSearchComponentCall(false)
    const handleResize = () => {
      setViewportHeight(window.innerHeight);
    };

    // Add event listener for window resize
    window.addEventListener("resize", handleResize);

    // Cleanup event listener on component unmount
    return () => {
      window.removeEventListener("resize", handleResize);
    };
    
  }, []);


  useEffect(() => {
    if (!router) {
      console.error("NextRouter is not available.");
    }
  }, [router]);
useEffect(() => {
  if (popupHeading === "Billable on Suspension") {
    const newRowData = billableOnSuspensionData?.length > 0 ? billableOnSuspensionData : initialData;
    setRowData(newRowData);
  } else if (popupHeading === "Module Access" || popupHeading === "Partner Module Access" ||  popupHeading === "Bulk Change History status log" || popupHeading === "Usage Details" || popupHeading === "Billing Status Log") {
    // Handle Module Access if needed
    setRowData(initialData);
  } else if(popupHeading === "Rev.io Syncs"){
       const newRowData = chargeDetailsTableData?.length > 0 
      ? chargeDetailsTableData :
       initialData || []; 
    setRowData(newRowData);
  }
  else {
    const newRowData = tabledata?.length > 0 ? tabledata : initialData;
    setRowData(newRowData);
  }
}, [tabledata, initialData, popupHeading, billableOnSuspensionData,chargeDetailsTableData]);

  useEffect(() => {
    console.log("tabledata,sortConfig useeffect",isSearchComponentCall)
    setCurrentPage(1);
    setIsSearchComponentCall(false)
  }, [tabledata,sortConfig]);
  useEffect(() => {
    setCurrentPage(1);
  }, [totalPages]);

  useEffect(() => {
    let pagination_;
    if(popupHeading === "Rev.io Syncs"){
      pagination_ = chargesDetailsPagination ? chargesDetailsPagination : pagination
    }
    else{

    if(combineAdnvaceStoredpagination){
      pagination_=combineAdnvaceStoredpagination

  }
  else if (advancedStoredpagination && !storedpagination ) {
      pagination_=advancedStoredpagination

  }
  else if (storedpagination && !advancedStoredpagination) {
      pagination_=storedpagination

  }
  else{
      pagination_=pagination
  }
    }

    // const pagination_ =combineAdnvaceStoredpagination? storedpagination ? storedpagination : advancedStoredpagination ? advancedStoredpagination : pagination
    // const pagination_ = pagination;
    const start = pagination_?.start || 1;
    const total = pagination_?.total || 1;
    const end = pagination_?.end || 1;
    const lastPageWithData_ = Math.floor(end / itemsPerPage);
    const totalPages_ = Math.ceil(total / itemsPerPage);
    const currentPage_ = Math.floor(start / itemsPerPage) + 1;
    setTotalPages(totalPages_);
    // setCurrentPage(currentPage_);
    setLastPageWithData(lastPageWithData_);
  }, [tabledata, initialData, pagination, itemsPerPage, currentPage, storedpagination, advancedStoredpagination, combineAdnvaceStoredpagination , sortConfig,chargesDetailsPagination]);
   const tenant_id_ = localStorage.getItem("tenant_id") || "0";
  const updatePaginator = async () => {
    console.log(customerShowActive, "customerShowActive")
    let start_ = Math.floor((currentPage - 1) * itemsPerPage);
    let end_ = Math.floor((currentPage - 1) * itemsPerPage + 100);
    let end2 = Math.floor((currentPage - 1) * itemsPerPage + 10);
    try {
      const colSortKey=sortConfig?sortConfig.key:""
      const colSortDirection=sortConfig?sortConfig.direction:""
      const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";
      // if (currentPage !== 1) {
      if(!tabsEdit){
        setLoading(true);
      }
      // }

      const partner_row = JSON.parse(localStorage.getItem("partner_row") || "{}")
      const setupAction_ = setUpAction ? setUpAction.toString().toLowerCase() : ""
      const partnerName = partner_row?.partner || ""
      const subPartner = partner_row?.sub_partner && setupAction_.includes("sub tenant") ? partner_row?.sub_partner : ""
      const selected_info_partner = subPartner ? subPartner : partnerName || ""
      const defaultPartner = partner || ""
      const selectedPartnerName = isPartnerInfoTable ? selected_info_partner:defaultPartner
      const selectedPartnerDBName = isPartnerInfoTable ? editPartnerDBName:selectedDb
      const selectedPartnerMetaData = isPartnerInfoTable ? editPartnerMetaData:metaData



      if (popupHeading === "Partner Creation") {
        try {
          const url = ENV_ROUTES.TENANT_ONBOARDING;
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/get_partner_creation_list_view",
            role_name: role,
            parent_module: "Super Admin",
            module_name: "Partner Creation",
            feature_module_name: "Partner Creation",
             mod_pages: {
              start: start_,
              end: end_,
            },
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
            ...metaData,
            sessionID: sessionId,
            ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
              : {}),
          };
          const response = await axios.post(url, { data });
          const parsedData = JSON.parse(response.data.body);
          if (parsedData.flag === false) {
            Modal.error({
              title: "Data Fetch Error",
              content:
                parsedData.message ||
                "An error occurred while fetching data. Please try again.",
              centered: true,
            });
          } else {
            const tableData_ = parsedData?.data || [];
            setRowData(tableData_);
          }
        } catch (err) {
          console.error("Error fetching data:", err);
          Modal.error({
            title: "Data Fetch Error",
            content:
              err instanceof Error
                ? err.message
                : "An unexpected error occurred while fetching data. Please try again.",
            centered: true,
          });
        } finally {
          // setLoading(false);
        }
      }
      if (popupHeading === "Private Networks") {
        try {
          const url = ENV_ROUTES.TENANT_ONBOARDING;
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/get_private_networks_list_view",
            role_name: role,
            parent_module: "Super Admin",
            module_name:"Private Networks",
            feature_module_name: "Private Networks",
             mod_pages: {
              start: start_,
              end: end_,
            },
            tenant_id:tenant_id_,
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
            ...metaData,
            sessionID: sessionId,
            ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
              : {}),
            toggle_status:privateNetworksShowActive
          };
          const response = await axios.post(url, { data });
          const parsedData = JSON.parse(response.data.body);
          if (parsedData.flag === false) {
            Modal.error({
              title: "Data Fetch Error",
              content:
                parsedData.message ||
                "An error occurred while fetching data. Please try again.",
              centered: true,
            });
          } else {
            const tableData_ = parsedData?.data || [];
            setRowData(tableData_);
          }
        } catch (err) {
          console.error("Error fetching data:", err);
          Modal.error({
            title: "Data Fetch Error",
            content:
              err instanceof Error
                ? err.message
                : "An unexpected error occurred while fetching data. Please try again.",
            centered: true,
          });
        } finally {
          // setLoading(false);
        }
      }
      if (popupHeading === "Tenant Banner") {
        try {
          const url = ENV_ROUTES.TENANT_ONBOARDING;
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/get_tenant_banners_list_view_data",
            role_name: role,
            parent_module: "Super Admin",
            module_name: "Deployment Notifier",
            sub_module: "Tenant Based Banners",
            mod_pages: {
              start: start_,
              end:  Math.floor((currentPage - 1) * itemsPerPage + 25),
            },
            limit: 25,
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
              : {}),
          };
          const response = await axios.post(url, { data });
          const parsedData = JSON.parse(response.data.body);
          if (parsedData.flag === false) {
            Modal.error({
              title: "Data Fetch Error",
              content:
                parsedData.message ||
                "An error occurred while fetching data. Please try again.",
              centered: true,
            });
          } else {
            const tableData_ = parsedData?.data || [];
            setRowData(tableData_);
          }
        } catch (err) {
          console.error("Error fetching data:", err);
          Modal.error({
            title: "Data Fetch Error",
            content:
              err instanceof Error
                ? err.message
                : "An unexpected error occurred while fetching data. Please try again.",
            centered: true,
          });
        } finally {
          // setLoading(false);
        }
      }
      if (popupHeading === "Customers") {
        try {
          const url = ENV_ROUTES.PEOPLE_MODULE;
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/get_customers_list_view_data",
            role_name: role,
            parent_module: "People",
            mod_pages: {
              start: start_,
              end: end_,
            },
            // Environment: selectedEnvironment,
            module_name: "Customers",
            feature_module_name: "Customers",
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
              : {}),
          };
          const response = await axios.post(url, { data: data });
          const resp = JSON.parse(response.data.body);
          const table_ = resp.data
          setRowData(table_);
        } catch (err) {
          console.error("Error fetching data:", err);
          Modal.error({
            title: "Data Fetch Error",
            content:
              err instanceof Error
                ? err.message
                : "An unexpected error occurred while fetching data. Please try again.",
            centered: true,
          });
        } finally {
          // setLoading(false);
        }
      }
      if (popupHeading === "Carrier") {
        try {
          const url = ENV_ROUTES.TENANT_ONBOARDING;
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/get_superadmin_info",
            role_name: role,
            parent_module: "Super Admin",
            sub_module: "Partner API",
            mod_pages: {
              start: start_,
              end: end_,
            },
            // Environment: selectedEnvironment,
            Selected_Partner: selectedPartner,
            sub_tab: "Carrier APIs",
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
              : {}),
          };
          const response = await axios.post(url, { data: data });
          const resp = JSON.parse(response.data.body);
          const carrierApis = resp.data.Carrier_apis_data.carrier_apis;
          setRowData(carrierApis);
        } catch (err) {
          console.error("Error fetching data:", err);
          Modal.error({
            title: "Data Fetch Error",
            content:
              err instanceof Error
                ? err.message
                : "An unexpected error occurred while fetching data. Please try again.",
            centered: true,
          });
        } finally {
          // setLoading(false);
        }
      }
      if (popupHeading === "API") {
        try {
          const url = ENV_ROUTES.TENANT_ONBOARDING;
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/get_superadmin_info",
            role_name: role,
            parent_module: "Super Admin",
            sub_module: "Partner API",
            sub_tab: "Amop APIs",
            mod_pages: {
              start: start_,
              end: end_,
            },
            // Environment: selectedEnvironment,
            Selected_Partner: selectedPartner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
              : {}),
          };

          const response = await axios.post(url, { data: data });
          const resp = JSON.parse(response.data.body);
          const carrierApis = resp.data.amop_apis_data.amop_apis;
          setRowData(carrierApis);
        } catch (err) {
          console.error("Error fetching data:", err);
          Modal.error({
            title: "Data Fetch Error",
            content:
              err instanceof Error
                ? err.message
                : "An unexpected error occurred while fetching data. Please try again.",
            centered: true,
          });
        } finally {
          // setLoading(false); // Set loading to false after the request is done
        }
      }
      if (popupHeading === "Inventory") {
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/get_inventory_data",
          role_name: role,
          parent_module: "Sim Management",
          module_name: "SimManagement Inventory",
          feature_module_name: "Inventory",
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching Inventory data. Please try again.",
            centered: true,
          });
        } else {
          const inventoryData =
            parsedData?.inventory_data || [];
          setRowData(inventoryData);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Bulk Change") {
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
          tenant_name: selectedPartnerName || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/get_bulk_change_list_view_data",
          role_name: role,
          parent_module: "Sim Management",
          module_name: "Bulk Change",
          feature_module_name: "Bulk Change",
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: selectedPartnerName,
          access_token: token,
          db_name: selectedPartnerDBName,
                ...selectedPartnerMetaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);

        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData_ =
            parsedData?.data?.sim_management_bulk_change || [];
          setRowData(tableData_);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Central Bulk Change") {
        const url = ENV_ROUTES.CENTRALIZED_VIEW;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/get_centralized_list_view_data",
          role_name: role,
          parent_module: "Super Admin",
          module_name: "Centralized Bulk Change View",
          feature_module_name: "Centralized Bulk Change View",
          sub_module: "Central Bulk Change",
          table_name: "vw_all_device_bulk_changes",
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: "central_db",
          ... metaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);

        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData_ =
            parsedData?.data || [];
          setRowData(tableData_);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Sim Order Form") {
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/get_sim_order_form_list_view_data",
          role_name: role,
          parent_module: "Sim Management",
          module_name: "Sim Order Form",
          feature_module_name: "Sim Order Form",
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);

        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData_ = parsedData?.data?.sim_order_form || []
          setRowData(tableData_);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Bulk Change History") {
        const url = ENV_ROUTES.SIM_MANAGEMENT
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/get_bulk_change_history",
          role_name: role,
          module_name: "Bulk Change History",
          mod_pages: {
            start: start_,
            end: end_,
          },
          access_token: token,
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          list_view_data_id:bulkRow?.row?.bulk_change_id || bulkRow?.row?.id || "0",
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);

        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching History. Please try again.",
            centered: true,
          });
        } else {
          const tableData_ = parsedData?.status_history_data || [];
          setRowData(tableData_);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Communication plans") {
        const url = ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/get_module_data",
          role_name: role,
          parent_module: "Sim Management",
          module_name: "Communication plans",
          feature_module_name: "Communication Plans",
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);

        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData_ =
            parsedData?.data?.sim_management_communication_plan || [];
          setRowData(tableData_);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "IMEI Master Table") {
        const url = ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/get_module_data",
          role_name: role,
          parent_module: "Sim Management",
          module_name: "IMEI Master Table",
          feature_module_name: "IMEI Master Table",
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);

        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData_ = parsedData?.data?.imei_master || [];
          setRowData(tableData_);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Feature Codes") {
        const url = ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: selectedPartnerName || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/get_module_data",
          role_name: role,
          parent_module: "Sim Management",
          module_name: "Feature Codes",
          feature_module_name: "Rate Plans/SOCs",
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: selectedPartnerName,
          access_token: token,
          db_name: selectedPartnerDBName,
                ...selectedPartnerMetaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);

        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData_ =
            parsedData?.data?.mobility_feature || [];
          setRowData(tableData_);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Email Audit") {
        const url = ENV_ROUTES.NOTIFICATION_SERVICES;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/email_list",
          role_name: role,
          parent_module: "Partner",
          module_name: "Notifications",
          feature_module_name: "Notifications",
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);

        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData_ =
            parsedData?.data?.Notifications || [];
          setRowData(tableData_);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Email Template") {
        const url = ENV_ROUTES.NOTIFICATION_SERVICES;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/email_template_list_view",
          role_name: role,
          parent_module: "Partner",
          module_name: "Notifications",
          feature_module_name: "Notifications",
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);

        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData_ =
            parsedData?.data || [];
          setRowData(tableData_);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Device notifications") {
        const url = ENV_ROUTES.NOTIFICATION_SERVICES;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/get_notification_rules",
          role_name: role,
          parent_module: "Partner",
          module_name: "Usage Notification",
          feature_module_name: "Usage Notification",
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);

        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData_ =
            parsedData?.rule_data || [];
          setRowData(tableData_);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "service providers") {
        const url = ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: selectedPartnerName || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/service_provider_list_view",
          role_name: role,
          parent_module: "Partner",
          feature_module_name: "Partner Info",
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: selectedPartnerName,
          access_token: token,
          db_name: selectedPartnerDBName,
                ...selectedPartnerMetaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);

        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData_ =
            parsedData?.data || [];
          setRowData(tableData_);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Rate Plan Socs") {
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
          tenant_name: selectedPartnerName || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/carrier_rate_plan_list_view",
          role_name: role,
          parent_module: "Sim Management",
          module_name: "Rate Plan Socs",
          feature_module_name: "Rate Plans/SOCs",
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: selectedPartnerName,
          access_token: token,
          db_name: selectedPartnerDBName,
                ...selectedPartnerMetaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);

        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData_ = parsedData?.data?.carrier_rate_plan || [];
          setRowData(tableData_);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Create Rate Plan Type") {
        const url = ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: selectedPartnerName || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/get_module_data",
          role_name: role,
          parent_module: "Sim Management",
          module_name: "Create Rate Plan Type",
          feature_module_name: "Rate Plans/SOCs",
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: selectedPartnerName,
          access_token: token,
          db_name: selectedPartnerDBName,
                ...selectedPartnerMetaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);

        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData_ =
            parsedData?.data?.optimization_rate_plan_type || [];
          setRowData(tableData_);
          pagination = parsedData?.pages || pagination
        }
      }

      if (popupHeading === "Filtered Customer Rate Plan") {
        const url = ENV_ROUTES.TENANT_ONBOARDING;
        const data = {
          tenant_name: selectedPartnerName || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/filter_customer_rate_plans_from_customer_groups",
          role_name: role,
          parent_module: "Super Admin",
          module_name: "Edit Partner",
          customer_name:customerGroupName || "",
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: selectedPartnerName,
          access_token: token,
          db_name: selectedPartnerDBName,
                ...selectedPartnerMetaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);

        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData_ = parsedData?.data?.customerrateplan || [];
          setRowData(tableData_);
          pagination = parsedData?.pages || pagination
        }
      }

      if (popupHeading === "Customer Rate Plan") {
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
          tenant_name: selectedPartnerName || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/get_customer_rate_plan_list_view_data",
          role_name: role,
          parent_module: "Sim Management",
          module_name: customerShowActive ? "Active Customer Rate Plan" : "Customer Rate Plan",
          feature_module_name: "Customer Rate Plans",
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: selectedPartnerName,
          access_token: token,
          db_name: selectedPartnerDBName,
                ...selectedPartnerMetaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);

        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData_ = parsedData?.data?.customerrateplan || [];
          setRowData(tableData_);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Customer Rate Pool") {
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/get_customer_rate_pool_list_view_data",
          role_name: role,
          parent_module: "Sim Management",
          module_name: "Customer Rate Pool",
          feature_module_name: "Customer Rate Pools",
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);

        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData_ = parsedData?.data?.customer_rate_pool || [];
          setRowData(tableData_);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "E911 Customer") {
        const url = ENV_ROUTES.PEOPLE_MODULE;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/people_list_view",
          role_name: role,
          parent_module: "People",
          module_name: "E911 Customers",
          feature_module_name: "E911 Customers",
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          access_token: token,
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching E911 Customers data. Please try again.",
            centered: true,
          });
        } else {
          const customertableData = parsedData.data;
          setRowData(customertableData);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "NetSapien Customer") {
        const url = ENV_ROUTES.PEOPLE_MODULE;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/people_list_view",
          role_name: role,
          parent_module_name: "people", // Corrected spelling from 'poeple'
          module_name: "NetSapiens Customers",
          feature_module_name: "NetSapiens Customers",
          mod_pages: {
            start: start_,
            end: end_,
          },
          Partner: partner,
          request_received_at: getCurrentDateTime(),
          access_token: token,
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        // Check if the flag is false in the parsed data
        const tableData = parsedData.data;
        setRowData(tableData);
        pagination = parsedData?.pages || pagination
      }
      if (popupHeading === "Bandwidth Customer") {
        const url = ENV_ROUTES.PEOPLE_MODULE;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/people_list_view",
          role_name: role,
          parent_module_name: "people",
          module_name: "Bandwidth Customers",
          feature_module_name: "Bandwidth Customers",
          mod_pages: {
            start: start_,
            end: end_,
          },
          Partner: partner,
          request_received_at: getCurrentDateTime(),
          access_token: token,
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching Bandwidth customers data. Please try again.",
            centered: true,
          });
        } else {
          const tableData = parsedData.data;
          setRowData(tableData);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Customer Group") {
        const url = ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: selectedPartnerName || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/get_partner_info",

          role_name: role,
          parent_module: "Partner",
          modules_list: ["Customer groups"],
          feature_module_name: "Partner Info",
          pages: {
            "Customer groups": { start: start_, end: end_ },
            "Partner users": { start: start_, end: end_ },
          },
          offset:currentPage-1,
          Partner: selectedPartnerName,
          request_received_at: getCurrentDateTime(),
          access_token: token,
          db_name: selectedPartnerDBName,
                ...selectedPartnerMetaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching Customer groups data. Please try again.",
            centered: true,
          });
        } else {
          const tableData =
            parsedData?.data?.["Customer groups"]?.customergroups || [];
          setRowData(tableData);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "User") {
        const url = ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: selectedPartnerName || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/get_partner_info",
          role_name: role,
          parent_module: "Partner",
          modules_list: ["Partner users"],
          feature_module_name: "Partner Info",
          pages: {
            "Customer groups": { start: start_, end: end_ },
            "Partner users": { start: start_, end: end_ },
          },

          Partner: selectedPartnerName,
          request_received_at: getCurrentDateTime(),
          access_token: token,
          db_name: selectedPartnerDBName,
                ...selectedPartnerMetaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
          active_toggle:partnerUsersShowActive ?? false
        };
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching Users data. Please try again.",
            centered: true,
          });
        } else {
          const tableData = parsedData?.data?.["Partner users"]?.users || [];
          setRowData(tableData);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Rev.io customers") {
        const url = ENV_ROUTES.PEOPLE_MODULE;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/people_revio_customers_list_view",
          role_name: role,
          parent_module: "People",
          module_name: "Rev.IO customer",
          feature_module_name: "Billing Customers",
          dropdown_options: { label: serviceProviderList.find(option => option.value === selectedServiceProvider)?.label || "All", value: selectedServiceProvider === null ? "all" : selectedServiceProvider },
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
                ...metaData,
          tenant_id: tenant_id_,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: 'Data Fetch Error',
            content: parsedData.message || 'An error occurred while fetching E911 Customers data. Please try again.',
            centered: true,
          });
        } else {
          const tableData = parsedData.data;
          setRowData(tableData);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Automation rule") {
        const url = ENV_ROUTES.AUTOMATION_RULE;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/get_automation_rule_data",
          table: "automation_rule",
          role_name: role,
          module_name: "Automation rule",
          feature_module_name: "Automation",
          mod_pages: {
            start: start_,
            end: end_,
          },
          Partner: partner,
          request_received_at: getCurrentDateTime(),
          access_token: token,
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData_ = parsedData?.automation_rule_data || []
          setRowData(tableData_);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Automation rule log") {
        const url = ENV_ROUTES.AUTOMATION_RULE;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/get_automation_rule_data",
          table: "vw_automation_rule_log_list_view",
          role_name: role,
          module_name: "Automation rule log",
          feature_module_name: "Automation",
          mod_pages: {
            start: start_,
            end: end_,
          },
          Partner: partner,
          request_received_at: getCurrentDateTime(),
          access_token: token,
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData_ = parsedData?.automation_rule_data || []
          setRowData(tableData_);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Zero usage report") {
        const url = ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/reports_data",
          role_name: role,
          parent_module: "Reports",
          module_name: "Zero Usage Report",
          feature_module_name: "Zero Usage Report",
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          table_name: "vw_zero_usage_report",
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content: parsedData.message || "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData = parsedData?.data || [];
          setRowData(tableData);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Active Lines Report") {
        const url = ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/reports_data",
          role_name: role,
          parent_module: "Reports",
          module_name: "Active Lines Report",
          feature_module_name: "Active Lines Report",
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          table_name: "vw_zero_usage_report",
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content: parsedData.message || "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData = parsedData?.data || [];
          setRowData(tableData);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Audit Logs Report") {
        const url = ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/reports_data",
          role_name: role,
          parent_module: "Reports",
          module_name: "Audit Logs Report",
          feature_module_name: "Audit Logs Report",
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content: parsedData.message || "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData = parsedData?.data || [];
          setRowData(tableData);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Usage by line report") {
        const url =
          ENV_ROUTES.MODULE_MANAGEMENT;
          let data;
          if(usageByLineFilter){
            data={...usageByLineFilterData , ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
              : {}),}
            const mod_pages_={
              start: start_,
              end:end_
            }
            data["mod_pages"]=mod_pages_
            console.log("data",data)
          }
          else{
            data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/reports_data",
              role_name: role,
              parent_module: "Reports",
              module_name: "Usage By Line Report",
              feature_module_name: "Usage by Line Report",
              mod_pages: {
                start: start_,
                end: end_,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              access_token: token,
              table_name: "vw_usage_by_line_report",
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,
              ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
                : {}),
            };
          }
        
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData = parsedData?.data || [];
          setRowData(tableData);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "New Usage By Line Report") {
        const url =
          ENV_ROUTES.MODULE_MANAGEMENT;
          let data;
          if(usageByLineFilter){
            data={...usageByLineFilterData , ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
              : {}),}
            const mod_pages_={
              start: start_,
              end:end_
            }
            data["mod_pages"]=mod_pages_
            console.log("data",data)
          }
          else{
            data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/reports_data",
              role_name: role,
              parent_module: "Reports",
              module_name: "New Usage By Line Report",
              feature_module_name: "New Usage By Line Report",
              mod_pages: {
                start: start_,
                end: end_,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              access_token: token,
              table_name: "vw_usage_by_line_report2_v20",
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,
              ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
                : {}),
            };
          }
        
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData = parsedData?.data || [];
          setRowData(tableData);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Status history report") {
        const url =
          ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/reports_data",
          role_name: role,
          parent_module: "Reports",
          module_name: "Status History Report",
          feature_module_name: "Status History Report",
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          table_name: "vw_status_history_report",
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData = parsedData?.data || [];
          setRowData(tableData);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Pool group summary report") {
        const url =
          ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/reports_data",
          role_name: role,
          parent_module: "Reports",
          module_name: "Pool Group Summary Report",
          feature_module_name: "Pool/Group Summary Report",
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          table_name: "vw_pool_group_summary_report",
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData = parsedData?.data || [];
          setRowData(tableData);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Newly actvated report") {
        const url =
          ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/reports_data",
          role_name: role,
          parent_module: "Reports",
          module_name: "Newly Activated Report",
          feature_module_name: "Newly Activated Report",
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          table_name: "vw_newly_activated_report",
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData = parsedData?.data || [];
          setRowData(tableData);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Customer rate pool usage report") {
        const url =
          ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/reports_data",
          role_name: role,
          parent_module: "Reports",
          module_name: "Customer Rate Pool Usage Report",
          feature_module_name: "Customer Rate Pool Usage Report",
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          table_name: "vw_customer_rate_pool_usage_report",
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData = parsedData?.data || [];
          setRowData(tableData);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Automation rule verification report") {
        const url =
          ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/reports_data",
          role_name: role,
          parent_module: "Reports",
          module_name: "Automation rule verification report",
          feature_module_name: "Automation Rule Verification Report",
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          table_name: "automation_rule_verification_report_view",
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData = parsedData?.data || [];
          setRowData(tableData);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Daily usage report") {
        console.log(startDateDailyReport, endDateDailyReport, "show the start and end Date daily usage report")
        const url =
          ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/reports_data_with_date_filter",
          role_name: role,
          parent_module: "Reports",
          module_name: "Daily usage report",
          feature_module_name: "Daily Usage Report",
          start_date: startDateDailyReport,
          end_date: endDateDailyReport,
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          table_name: "vw_daily_usage_report",
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData = parsedData?.data || [];
          setRowData(tableData);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Actions History Report") {
        console.log(startDateDailyReport, endDateDailyReport, "show the start and end Date Actions History Report")
        const url =
          ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/reports_data_with_date_filter",
          role_name: role,
          parent_module: "Reports",
          module_name: "Actions History Report",
          feature_module_name: "Actions History Report",
          start_date: startDateDailyReport,
          end_date: endDateDailyReport,
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          table_name: "sim_management_inventory_action_history",
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData = parsedData?.data || [];
          setRowData(tableData);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Optimization Group") {
        const url =ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName:firstLastName,
          path: "/get_module_data",
          role_name: role,
          parent_module: "Sim Management",
          module_name: "Optimization Group",
          feature_module_name:"Optimization Groups",
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData_ = parsedData?.data?.optimization_group || []
          setRowData(tableData_);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Billable on Suspension") {
        const url =ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName:firstLastName,
          path: "/bp_settings_list_view",
          role_name: role,
          parent_module: "Partner Info",
          module_name: "Billing Settings",
          sub_partner: selectedSubPartner || "",
          Selected_Partner: selectedPartnerBP,
          mod_pages: {
            start: start_,
            end: end2,
          },
          flag:'withparameters',
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
           col_sort: {
          "service_provider_name": "asc",       
          },
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData_ = parsedData?.data?.billing_platform_suspend || []
          setbillableOnSuspensionData(tableData_);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Billing Customers") {
        const url =ENV_ROUTES.PEOPLE_MODULE;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName:firstLastName,
          path: "/get_billing_platform_customer_list_view_data",
          role_name: role,
           parent_module: "People",
          module_name: "Billing Customers",
          feature_module_name:"Billing Customers",
          sub_partner: selectedSubPartner || "",
          Selected_Partner: selectedPartnerBP,
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
          ...(sortConfig? {col_sort:{ [colSortKey]: colSortValue }}
            : {}),
        };
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData_ = parsedData?.data || []
          setRowData(tableData_);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Usage Details") {
        const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/usage_sms_charges_list_view",
          role_name: role,
          parent_module: "Billing Platform",
          module_name: "Usage Details",
          mod_pages: {
            start: 0,
            end: 100,
          },
          bill_id: BillId,
          account_number: accountNumber,
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
          billing_db_name: selectedBillingDb,
          sessionID: sessionId,
          main_module_name: "Customer Profiles",
          feature_module_name: "Usage Details",
          ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
            : {}),
        };
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData_ = parsedData?.data?.usage_sms_charges || []
          setRowData(tableData_);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "Rev.io Syncs") {
        const url = ENV_ROUTES.DASHBOARD;
        const data = {
          tenant_name: syncsData?.tenant_name || "All" || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/get_revio_sync_dashboard_data",
          role_name: role,
          parent_module: "Sim Management",
          module_name: "Dashboard",
          mod_pages: {
            start: 0,
            end: 100,
          },
          start_date: syncsData?.start_date,
          end_date: syncsData?.end_date,
          sync_status: syncsData?.sync_status || "All",
          service_provider: syncsData?.selectedServiceProvider || "All",
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
            : {}),
        };
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData_ = parsedData?.data || []
          setChargeDetailsTableData(tableData_ || []);
          setRowData(tableData_);
          pagination = parsedData?.pages || pagination
        }
      }
      if (popupHeading === "LNP") {
        const url = ENV_ROUTES.LNP;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/lnp_phone_numbers_list_view",
          role_name: role,
          parent_module: "LNP",
          module_name: "LNP",
          feature_module_name: "LNP",
          mod_pages: {
            start: start_,
            end: end_,
          },
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } } : {}),
        };
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching LNP data. Please try again.",
            centered: true,
          });
        } else {
          const tableData_ = parsedData?.phone_numbers || [];
          setRowData(tableData_);
          pagination = parsedData?.pages || pagination;
        }
      }
      if (popupHeading === "Number Orders") {
        const url = ENV_ROUTES.LNP;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/lnp_get_number_orders",
          role_name: role,
          parent_module: "LNP",
          module_name: "Number Orders",
          feature_module_name: "Number Orders",
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
        };
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching Number Orders. Please try again.",
            centered: true,
          });
        } else {
          const tableData_ = parsedData?.orders || [];
          setRowData(tableData_);
          pagination = parsedData?.pages || pagination;
        }
      }

    } catch (err) {
      console.error("Error fetching data:", err);
    } finally {
      setLoading(false);
    }
    // }
  };
  const updateSearchPaginator = async () => {
    let start_ = Math.floor((currentPage - 1) * itemsPerPage);
    let end_ = Math.floor((currentPage - 1) * itemsPerPage + 100);
    const colSortKey=sortConfig?sortConfig.key:""
    const colSortDirection=sortConfig?sortConfig.direction:""
    const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";
    try {
      if(!tabsEdit){
        setLoading(true);
      }
      const url = ENV_ROUTES.OPEN_SEARCH;
      let data = { ...popupHeading === "Rev.io Syncs"?{...chargeDetailsSearchData}:{...searchData}, username: username, }
      data.data.pages = {
        start: start_,
        end: end_,
      }
      data.data.col_sort={ [colSortKey]: colSortValue }
      if (popupHeading === "Automation rule") {
        await new Promise((resolve) => setTimeout(resolve, 2000));
      }
      const response = await axios.post(url, data);
      const parsedData = JSON.parse(response.data.body);
      console.log("parsed", parsedData);
      if (parsedData?.flag) {
        const tableData = parsedData?.data?.table || [];
        setRowData(tableData);
        const pagination_ = parsedData?.pages || {};
        if(popupHeading === "Rev.io Syncs"){
          setChargesDetailsPagination(pagination_)
        }
        setStoredPagination(pagination_);
        setAdvancedStoredPagination(null);
        setCombineAdnvaceStoredpagination(null)
        if (tableData.length === 0) {
          Modal.error({
            title: "No Records found",
          });
        }
      } else {
        Modal.error({
          title: "Search error",
          content:
            parsedData.error ||
            "An error occurred while searching. Please try again.",
        });
      }
      console.log(response);
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false); // Stop loader
    }
  }
  const updateAdvancedSearchPaginator = async () => {
    let start_ = Math.floor((currentPage - 1) * itemsPerPage);
    let end_ = Math.floor((currentPage - 1) * itemsPerPage + 100);
    const colSortKey=sortConfig?sortConfig.key:""
    const colSortDirection=sortConfig?sortConfig.direction:""
    const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";
    try {
      if(!tabsEdit){
        setLoading(true);
      }
      const url = ENV_ROUTES.OPEN_SEARCH;
      let data = { ...popupHeading === "Rev.io Syncs"?{...chargeDetailsSearchData}:{...advancedSearchData}, username: username, }
      data.data.pages = {
        start: start_,
        end: end_,
      }
      data.data.col_sort={ [colSortKey]: colSortValue }
      if (popupHeading === "Automation rule") {
        await new Promise((resolve) => setTimeout(resolve, 2000));
      }
      const response = await axios.post(url, data);
      const parsedData = JSON.parse(response.data.body);
      console.log("parsed", parsedData);
      if (parsedData?.flag) {
        const tableData = parsedData?.data?.table;
        setRowData(tableData);
        const pagination_ = parsedData?.pages || {}
        setStoredPagination(null)
        setAdvancedStoredPagination(pagination_)
         if(popupHeading === "Rev.io Syncs"){
          setChargesDetailsPagination(pagination_)
        }
        setCombineAdnvaceStoredpagination(null)
        if (tableData.length === 0) {
          Modal.error({
            title: "No Records found",
          });
        }
      } else {
        Modal.error({
          title: "Search error",
          content:
            parsedData.error ||
            "An error occurred while searching. Please try again.",
        });
      }
      console.log(response);
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false); // Stop loader
    }
  }
  const updateCombinedSearchPaginator = async () => {
    let start_ = Math.floor((currentPage - 1) * itemsPerPage);
    let end_ = Math.floor((currentPage - 1) * itemsPerPage + 100);
    const colSortKey=sortConfig?sortConfig.key:""
    const colSortDirection=sortConfig?sortConfig.direction:""
    const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";
    try {
      if(!tabsEdit){
        setLoading(true);
      }
      const url = ENV_ROUTES.OPEN_SEARCH;
      let data = { ...popupHeading === "Rev.io Syncs"?{...chargeDetailsSearchData}:{...combineAdnvaceSearchData}, username: username, }
      data.data.pages = {
        start: start_,
        end: end_,
      }
      data.data.col_sort={ [colSortKey]: colSortValue }
      const response = await axios.post(url, data);
      const parsedData = JSON.parse(response.data.body);
      console.log("parsed", parsedData);
      if (parsedData?.flag) {
        const tableData = parsedData?.data?.table;
        setRowData(tableData);
        const pagination_ = parsedData?.pages || {}
        setStoredPagination(null)
        setAdvancedStoredPagination(null)
        if(popupHeading === "Rev.io Syncs"){
          setChargesDetailsPagination(pagination_)
        }
        setCombineAdnvaceStoredpagination(pagination_)
        if (tableData.length === 0) {
          Modal.error({
            title: "No Records found",
          });
        }
      } else {
        Modal.error({
          title: "Search error",
          content:
            parsedData.error ||
            "An error occurred while searching. Please try again.",
        });
      }
      console.log(response);
    } catch (error) {
      console.log(error);
    } finally {
      setLoading(false); // Stop loader
    }
  }
  useEffect(() => {
    // console.clear()
    // console.log("refreshPage",refreshPage)
    if (!isFirstRender.current) {
      
    if (combineAdnvaceStoredpagination) {
      updateCombinedSearchPaginator()
    }
    else if (storedpagination && !advancedStoredpagination) {
      updateSearchPaginator()
    }
    else if (advancedStoredpagination && !storedpagination) {
      updateAdvancedSearchPaginator()
    }
    else {
      updatePaginator();
    }

  }  else { isFirstRender.current = false }
  }, [currentPage, sortConfig,refreshPage]);

  useEffect(() => {
    console.log("tabledata useeffect",isSearchComponentCall)

    if (!isFirstTableDataRender.current && !isSearchComponentCall) {
      
      if(tabledata!==rowData && currentPage===1){
        if (combineAdnvaceStoredpagination) {
          updateCombinedSearchPaginator()
        }
        else if (storedpagination && !advancedStoredpagination) {
          updateSearchPaginator()
        }
        else if (advancedStoredpagination && !storedpagination) {
          updateAdvancedSearchPaginator()
        }
        else {
          updatePaginator();
        }
      }

  }  else { isFirstTableDataRender.current = false }
  }, [tabledata]);

  useEffect(() => {
    // console.log("searchQuery",searchQuery)
    if (!isFirstSearchRender.current) {
      if (searchQuery==="") {
        if (storedpagination) {
          updateSearchPaginator()
        }
        else if (advancedStoredpagination) {
          updateAdvancedSearchPaginator()
        }
        else {
          updatePaginator();
        }
      }
    } else { isFirstSearchRender.current = false }
  }, [searchQuery]);

  useEffect(() => {
    // console.log("advancedFilters",advancedFilters)
    if (!isFirstAdvancedSearchRender.current) {
      if (advancedFilters) {
        const allEmpty = Object.values(advancedFilters).every(
          (value) => Array.isArray(value) && value.length === 0
        );
      
      if (allEmpty) {
        console.log("advancedFilters",advancedFilters)
        if (storedpagination) {
          updateSearchPaginator()
        }
        else if (advancedStoredpagination) {
          updateAdvancedSearchPaginator()
        }
        else {
          updatePaginator();
        }
      }
    }
    } else { isFirstAdvancedSearchRender.current = false }
    
  }, [advancedFilters]);

  const handleActionSingleClick = () => {
    if (router) {
      router.push("/super_admin/partner_modules/user_role");
    } else {
      console.error("NextRouter is not available.");
    }
  };

  const handleSwitchChange = (checked: boolean) => {
    setCustomerShowActive(checked);
  };

  const handleSelectAllChange = (e: {
    target: { checked: boolean | ((prevState: boolean) => boolean) };
  }) => {
    setSelectAll(e.target.checked);
    if (e.target.checked) {
      const allRowIndices = paginatedData.map((_, index) => index);
      setSelectedRows(allRowIndices);
    } else {
      setSelectedRows([]);
    }
  };

  const handleRowCheckboxChange = (index: number) => {
    const currentIndex = selectedRows.indexOf(index);
    const newSelectedRows = [...selectedRows];

    if (currentIndex === -1) {
      newSelectedRows.push(index);
    } else {
      newSelectedRows.splice(currentIndex, 1);
    }

    setSelectedRows(newSelectedRows);
  };

  const handleEditPartnerClick = (rowIndex: number) => {
    const row = rowIndex !== null && rowIndex !== undefined
      ? rowData[rowIndex]
      : {};

    console.log("row rowData", row)
    localStorage.setItem('partner_row', JSON.stringify(row || "{}"));
    if (row) {
      router.push(`/super_admin/partner_addition/editPartner`);
    }
  };

  const renderActionButtons = (value: any, index: number, col: any) => {
    const row = rowData[index];
    return (
      <div className="flex items-center space-x-2">
        
        <Tooltip title="Edit">
          <PencilIcon
            className={`h-5 w-5 ${row.is_active ? "text-blue-500 cursor-pointer" : "text-gray-300 cursor-not-allowed pointer-events-none"}`}
             onClick={() => {setOpenPrivateNetworksEditModal(true)
              setPrivateNetworksEditRowIndex(index)
               setActionType("")
            }}
          />
        </Tooltip>
        <Tooltip title="Info">
          <InformationCircleIcon
            className="h-5 w-5 text-green-400 cursor-pointer"
            onClick={() => {
              setPrivateNetworksInfoRowIndex(index)
              setOpenPrivateNetworksInfo(true)
               setActionType("")
            }}
          />
        </Tooltip>
        {/* <Tooltip title="Delete">
          <TrashIcon
            className={`h-5 w-5 ${row.is_active
                ? "text-red-400 cursor-pointer"
                : "text-gray-300 cursor-not-allowed pointer-events-none"

              }`}
              
            onClick={() => {
              setPrivateNetworksDeleteRowIndex(index)
              handleDelete(index,false)
              setActionType("")
            }}
          />
        </Tooltip> */}
        <Tooltip
        title={
          row.is_active === true || row.status === "Active"
            ? "Deactivate"
            : row.is_active === false || row.status === "Inactive"
              ? "Activate"
              : "Unknown Status"
        }
      >
        {row.is_active === true || row.status === "Active" ? (
          <NoSymbolIcon
            className="h-5 w-5 text-red-500 cursor-pointer"
            onClick={() => {setPrivateNetworksDeleteRowIndex(index),handleDelete(index,false,"Deactive")}}
          />
        ) : row.is_active === false || row.status === "Inactive" ? (
          <CheckIcon
            className="h-5 w-5 text-green-500 cursor-pointer"
            onClick={() =>{setPrivateNetworksDeleteRowIndex(index),setDeleteModalOpen(true) ,setActionType( "Active")}}
          />
        ) : (
          <NoSymbolIcon
            className="h-5 w-5 text-gray-400 cursor-pointer"
            onClick={() => Modal.warning({
              title:"Update Error",
              content:"Unknow Status of the row",
              centered:true
            })}
          />
        )}
      </Tooltip>
      </div>
    );
  };
  const handleActionClick = (action: string, rowIndex: number) => {
    switch (action) {
      case "edit":
        setEditRowIndex(rowIndex);
        setIsEditable(true);
        setEditModalOpen(true);
        console.log(editModalOpen);
        break;
      case "tabsEdit":
        setTabsEdit(true);
        setEditRowIndex(rowIndex);
        setIsEditable(true);
        setEditModalOpen(true);
        break;
      case "tabsInfo":
        setTabsEdit(true);
        setEditRowIndex(rowIndex);
        setIsEditable(false);
        setEditModalOpen(true);
        break;
      case "delete":
        console.log("rowIndex", rowIndex)
        setDeleteRowIndex(rowIndex);
        setDeleteModalOpen(true);
        break;
      case "info":
        setEditRowIndex(rowIndex);
        setIsEditable(false);
        setEditModalOpen(true);
        break;
      case "form":
        setFormRowIndex(rowIndex);
        setFormModalOpen(true);
        break;
      case "commPlan":
        setCommPlanRowIndex(rowIndex);
        setCommPLanModalOpen(true);
        break;
      case "editCustomerModal":
        setIsEditable(true);
        setEditOptimizationModal(true);
        setEditOptimizationRowIndex(rowIndex);
        break;
      case "editRev.ioCustomer":
        setIsEditable(true);
        setEditRevIoCustomerModal(true);
        setEditeditRevIoCustomerRowIndex(rowIndex);
        break;
      case `editCustomerRatePlan`:
        setIsEditable(true);
        setEditCustomerRatePlanModal(true);
        setEditCustomerRatePlanRowIndex(rowIndex);
        break;
      case "copyCustomerRatePlan":
        setIsEditable(true);
        setCopyCustomerRatePlanModal(true);
        setCopyCustomerRatePlanRowIndex(rowIndex);
        break;
      case "infoCustomerRatePlan":
        setIsEditable(false);
        setInfoCustomerRatePlanModal(true);
        setInfoCustomerRatePlanRowIndex(rowIndex);
        break;
      case "infoRev.ioCustomer":
        setIsEditable(false);
        setInfoRevIoCustomerModal(true);
        setInfoRevIoCustomerRowIndex(rowIndex);
        break;
      case "infoCustomerModal":
        setIsEditable(false);
        setEditOptimizationModal(true);
        setEditOptimizationRowIndex(rowIndex);
        break;
      case "formEditFeatureModal":
        setEditFeatureModal(true);
        setEditFeatureRowIndex(rowIndex);
        break;
      case "emailAuditing":
        setisEmailAuditInfoModal(true);
        setEmailAuditRowIndex(rowIndex);
        break;
      case "copy":
        setCopyEmailModal(true);
        setCopyEmailRowIndex(rowIndex);
        break;
      case "editEmail":
        setEditEmailModal(true);
        setEditEmailRowIndex(rowIndex);
        break;
      case "copyFeature":
        setEditRowIndex(rowIndex);
        setIsEditable(true);
        setEditModalOpen(true);
        // setCopyFeature(true)
        break;
      case "automationEdit":
        setEditAutomationRowIndex(rowIndex);
        setEditAutomationModal(true);
        break;
      case "automationInfo":
        setInfoAutomationRowIndex(rowIndex);
        setInfoAutomationModal(true);
        break;
      case "impersonateUser":
        setImpersonateUser(true);
        setImpersonateUserRowIndex(rowIndex);
        setIsEditable(true);
        break;
      case "editServiceProvider":
        setEditServiceProvider(true);
        setServiceProviderRowIndex(rowIndex);
        break;
      case "editBanner":
        setEditBannerOPen(true);
        setEditBannerRowIndex(rowIndex);
        setBannerAction("edit")
        break;
      case "copyBanner":
        setEditBannerOPen(true);
        setEditBannerRowIndex(rowIndex);
        setBannerAction("copy")
        break;
      case "editNotification":
        setEditNotification(true);
        setEditNotificationRowIndex(rowIndex);
        break;
      case "resetPassword":
        setResetPasswordModal(true);
        setResetPasswordRowIndex(rowIndex);
        break;
      case "editPartnerCreation":
        setEditPartnerModal(true);
        setEditPartnerRowIndex(rowIndex);
        handleEditPartnerClick(rowIndex)
        break;
      default:
        break;
    }
  };


  const handleSaveModal = (
    updatedRow: { [key: string]: any },
    tableData: any
  ) => {
    if (editRowIndex !== null) {
      // const updatedData = [...rowData];
      // updatedData[editRowIndex] = updatedRow;
      // setRowData(updatedData);
      handleCloseModal();
      // setRowData(tableData)
    }
  };

  const handleAutomationSuccess = () => {
    handleCloseModal()
    // updatePaginator()
  }
  const handleCustomerRatePlanClose = () => {
    handleCloseModal()
    // updatePaginator()
  }

  const handleCloseModal = () => {
    setOpenPrivateNetworksInfo(false)
    setOpenPrivateNetworksEditModal(false)
    setOpenPrivateNetworksDeleteModal(false)
    setEditModalOpen(false);
    setIsEditable(false);
    setTabsEdit(false);
    setCopyFeature(false);
    setEditRowIndex(null);
    setFormModalOpen(false);
    setFormRowIndex(null);
    setCommPLanModalOpen(false);
    setCommPlanRowIndex(null);
    setEditFeatureModal(false);
    setEditFeatureRowIndex(null);
    setEditOptimizationModal(false);
    setEditOptimizationRowIndex(null);
    setisEmailAuditInfoModal(false);
    setEmailAuditRowIndex(null);
    setEditEmailModal(false);
    setCopyEmailModal(false);
    setCopyEmailRowIndex(null);
    setEditEmailRowIndex(null);
    setEditRevIoCustomerModal(false);
    setEditeditRevIoCustomerRowIndex(null);
    setInfoRevIoCustomerModal(false);
    setInfoRevIoCustomerRowIndex(null);
    setEditCustomerRatePlanModal(false);
    setEditCustomerRatePlanRowIndex(null);
    setCopyCustomerRatePlanModal(false);
    setCopyCustomerRatePlanRowIndex(null);
    setInfoCustomerRatePlanModal(false);
    setInfoCustomerRatePlanRowIndex(null);
    setEditAutomationModal(false);
    setEditAutomationRowIndex(null);
    setInfoAutomationModal(false);
    setInfoAutomationRowIndex(null);
    setImpersonateUser(false);
    setImpersonateUserRowIndex(null);
    setEditServiceProvider(false);
    setServiceProviderRowIndex(null);
    setEditBannerOPen(false)
    setEditAutomationRowIndex(null)
    setEditNotification(false);
    setEditNotificationRowIndex(null);
    // updatePaginator()
  };

  // Function to call Notification_sync API
  const callNotificationSync = async (ruleDefId: string, actionType: string) => {
    const syncUrl = ENV_ROUTES.NOTIFICATION_SERVICES;

    const syncData = {
      tenant_name: partner || "default_value",
      username: username,
      path: "/Notification_sync",
      action: actionType,
      rule_def_id: ruleDefId,
      parent_module: "Partner",
      module_name: "Usage Notification",
      feature_module_name: "Usage Notification",
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
                ...metaData,
      sessionID: sessionId,
    };

    try {
      await axios.post(syncUrl, { data: syncData });
    } catch (error) {
      console.error("Error in Notification Sync:", error);
    }
  };

  const callCustomersLambdaSync = async () => {
      const url = ENV_ROUTES.OPTIMIZATION_SYNC_LAMBDA;
      const data = {
        path: "/lambda_sync_jobs_",
        key_name: "customers_sub_tenant_insert",
        tenant_name:partner
      };
  
      try {
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
      } catch (error) {
      }
  
    }

    const callCustomerRatePoolsSync = async () =>{
          try {
            const url = ENV_ROUTES.OPTIMIZATION_SYNC_LAMBDA;
            const data = {
              key_name:"customer_rate_pool_sync",
              path:"/lambda_sync_jobs_",
              tenant_name:partner || "default_value",
            };
      
            const response = await axios.post(url, { data });
            const responseData = JSON.parse(response.data.body);
      
            if (responseData.flag === false) {
              console.error("Data Fetch Error: " + responseData.message);
            } else {
              console.log("Success: Inventory lambda sync successful.");
            }
          } catch (error) {
            console.error("Error fetching data:", error);
          }
      
        }

  const handleDelete = async (rowIndex: number,allow_delete ?: boolean,actionType_?:string) => {
    setOpenPrivateNetworksDeleteModal(false)
    if (rowIndex >= 0 && rowIndex < rowData.length) {
      const updatedData: any = [...rowData];
      const row = rowData[rowIndex];
      const originalRowCopy = {... rowData[rowIndex]}
      console.log(row);
      if (!(popupHeading === "Private Networks" && !allow_delete)) {
        row["deleted_by"] = firstLastName;
        row["is_deleted"] = true;
        row["is_active"] = false;
      }

      try {
        setLoading(true)
        let url = ENV_ROUTES.MODULE_MANAGEMENT;
        let data;

        if (popupHeading === "Customers") {
          url=ENV_ROUTES.PEOPLE_MODULE
          if (row) {
            row['modified_by'] = firstLastName;
            row["modified_date"] = getCurrentDateTime();
          }
          data = {
            tenant_name: partner || 'default_value',
            username: username,
            firstLastName: firstLastName,
            path: '/create_customer',
            role_name: role,
            module_name: 'Customers',
            new_data: row,
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            action:"edit"
          };
        }
        if (popupHeading === "Customer Group") {
          if (row) {
            row["modified_by"] = firstLastName;
            row["modified_date"] = getCurrentDateTime();
            delete row["sub_tanant"];
            delete row["sub_tenant_name"];
          }

          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/update_partner_info",
            role_name: role,
            module_name: "Customer groups",
            action: "delete",
            changed_data: row,
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }
        if (popupHeading === "User") {
          if (row) {
            row["modified_by"] = firstLastName;
            delete row["modified_date"]
            delete row["deleted_date"]

          }
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/update_partner_info",
            role_name: role,
            module_name: "Partner users",
            action: "delete_",
            changed_data: row,
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }

        if (popupHeading === "E911 Customer") {
          url = ENV_ROUTES.PEOPLE_MODULE
          if (row) {
            row["modified_by"] = firstLastName;
            row["modified_date"] = getCurrentDateTime();
            row["deleted_date"] = getCurrentDateTime();
            delete row['account_name'];
            delete row['account_id']
          }
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/update_people_data",
            role_name: role,
            parent_module: "People",
            module: "E911 Customers",
            table_name: "customers",
            changed_data: row,
            action: "delete",
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }
        if (popupHeading === "NetSapien Customer") {
          url = ENV_ROUTES.PEOPLE_MODULE
          if (row) {
            row["modified_by"] = firstLastName;
            row["modified_date"] = getCurrentDateTime();
          }
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/update_people_data",
            role_name: role,
            parent_module: "People",
            module: "NetSapien Customers",
            table_name: " customers",
            changed_data: row,
            action: "delete",
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }
        if (popupHeading === "Customer Rate Plan") {
          url = ENV_ROUTES.SIM_MANAGEMENT
          if (row) {
            row["modified_by"] = firstLastName;
            row["modified_date"] = getCurrentDateTime();
            row["is_active"] = false;

            row["base_rate"] =typeof row["base_rate"] === "string"? row["base_rate"]?.replace('$', ''): row["base_rate"] ;
            row["rate_charge_amt"] =typeof row["rate_charge_amt"] === "string"? row["rate_charge_amt"]?.replace('$', ''): row["rate_charge_amt"] ;
            row["sms_rate"] =typeof row["sms_rate"] === "string"? row["sms_rate"]?.replace('$', ''): row["sms_rate"] ;
            row["overage_rate_cost"] =typeof row["overage_rate_cost"] === "string"? row["overage_rate_cost"]?.replace('$', ''): row["overage_rate_cost"] ;
            row["min_plan_data_mb"] =typeof row["min_plan_data_mb"] === "string"? row["min_plan_data_mb"]?.replace('$', ''): row["min_plan_data_mb"] ;
            row["max_plan_data_mb"] =typeof row["max_plan_data_mb"] === "string"? row["max_plan_data_mb"]?.replace('$', ''): row["max_plan_data_mb"] ;
            row["data_per_overage_charge"] =typeof row["data_per_overage_charge"] === "string"? row["data_per_overage_charge"]?.replace('$', ''): row["data_per_overage_charge"] ;

          }
          const syncData =  {
            customerrateplan: [
              {
                is_deleted:true ,
                is_active:false,
                id:row.id
              },
            ],
          };
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/update_sim_management_modules_data",
            role_name: role,
            parent_module: "Sim Management",
            module_name: customerShowActive ? "Active Customer Rate Plan" : "Customer Rate Plan",
            table_name: "customerrateplan",
            changed_data: row,
            action: "update",
            allow_delete: allow_delete ? true : false,
            sync_data:syncData,
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }
        if (popupHeading === "Customer Rate Pool") {
          url = ENV_ROUTES.SIM_MANAGEMENT
          if (row) {
            row["modified_by"] = firstLastName;
            row["modified_date"] = getCurrentDateTime();
            row["is_active"] = false;
            row["is_deleted"] = true;
          }
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/update_sim_management_modules_data",
            role_name: role,
            parent_module: "Sim Management",
            module: "Customer Rate Pool",
            table_name: "customer_rate_pool",
            changed_data: row,
            action: "delete",
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }
        if (popupHeading === "Create Rate Plan Type") {
          url = ENV_ROUTES.SIM_MANAGEMENT
          if (row) {
            row["modified_by"] = firstLastName;
            row["modified_date"] = getCurrentDateTime();
            row["is_active"] = false;
            row["is_deleted"] = true;
          }
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/update_sim_management_modules_data",
            role_name: role,
            parent_module: "Sim Management",
            module: "Create Rate Plan Type",
            table_name: "optimization_rate_plan_type",
            changed_data: row,
            action: "delete",
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }
        if (popupHeading === "service providers") {
          url = ENV_ROUTES.MODULE_MANAGEMENT
          if (row) {
            row["modified_by"] = firstLastName;
            row["modified_date"] = getCurrentDateTime();
            row["is_active"] = false;
            row["is_deleted"] = true;
          }
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/submit_update_edit_service_provider",
            role_name: role,
            parent_module: "Partner",
            feature_module_name: "Partner Info",
            table_name: "serviceprovider",
            delete_data: row,
            action: "delete",
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }
        if (popupHeading === "Device notifications") {
          url = ENV_ROUTES.NOTIFICATION_SERVICES;
          if (row) {
            row["modified_by"] = firstLastName;
            delete row["modified_date"]
            // row["is_active"] = false;
            // row["is_deleted"] = true;
          }
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/process_notification_rules",
            role_name: role,
            parent_module: "Partner",
            module_name: "Usage Notification",
            feature_module_name: "Usage Notification",
            changed_data: row,
            action: "delete",
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }
        if (popupHeading === "Feature Codes") {
          url = ENV_ROUTES.SIM_MANAGEMENT
          if (row) {
            row["modified_by"] = firstLastName;
            row["is_active"] = false;
            row["is_deleted"] = true;
          }
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/update_sim_management_modules_data",
            role_name: role,
            parent_module: "Sim Management",
            module: "Feature Codes",
            table_name: "mobility_feature",
            changed_data: row,
            action: "delete",
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }
        if (popupHeading === "Optimization Group") {
          url = ENV_ROUTES.SIM_MANAGEMENT
          if (row) {
            const ratePlanList = (value:any) => {
              if (typeof value === "string") {
                let parsedPlans: any[];
                try {
                  parsedPlans = JSON.parse(value);
                } catch (err) {
                  console.log(err);
                  parsedPlans = [];
                }
                return Array.isArray(parsedPlans) ? parsedPlans : [];
              }
              if (Array.isArray(value)) {
                return value;
              }
              return [];
            };
            row["modified_by"] = firstLastName;
            row["deleted_by"] = firstLastName;
            row["is_active"] = "false";
            row["is_deleted"] = "true";
            row["rate_plans_list"] = ratePlanList(row?.["rate_plans_list"] ||"[]");
          }
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/update_sim_management_modules_data",
            role_name: role,
            parent_module: "Sim Management",
            module: "Optimization Group",
            table_name: "optimization_group",
            changed_data: row,
            action: "delete",
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }
        const callRunDBScriptForAutomation = async () => {
          const url = ENV_ROUTES.SIM_MANAGEMENT;
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/run_db_script",
            role_name: role,
            module_name: "Automation",
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            update_flag: false,
            delete_flag: true,
            request_received_at: getCurrentDateTime(),
            Partner: partner || "default_value",
            data: {
              input_data: [{
                  automation_data:{
                      id:row?.id || ''
                  }
              }]
            },
          };
      
          try {
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
          } catch (error) {
          }
      
        }
        const callLambdaSync = async () => {
          const url = ENV_ROUTES.OPTIMIZATION_SYNC_LAMBDA;
          const data = {
            path: "/lambda_sync_jobs_",
            key_name: "automation_reverse_sync",
            tenant_name:partner
          };
      
          try {
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
          } catch (error) {
          }
      
        }

        if (popupHeading === "Automation rule") {
          url = ENV_ROUTES.AUTOMATION_RULE
          if (row) {
            row["modified_by"] = firstLastName;
            delete row["is_deleted"];
            delete row["created_date"];

          }
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/update_automation_actions_data",
            role_name: role,
            module: "Automation rule",
            table_name: "automation_rule",
            changed_data: row,
            action: "edit",
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }
        if (popupHeading === "Private Networks" && !allow_delete && actionType_ === "Deactive") {
          url = ENV_ROUTES.TENANT_ONBOARDING
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/check_private_network_can_deactivate",
            role_name: role,
            module: "Private Networks",
            row_id: row.id,
            action: "delete",
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }
        if (popupHeading === "Private Networks" && allow_delete) {
          url = ENV_ROUTES.TENANT_ONBOARDING
          if (row) {
            row["modified_by"] = firstLastName;
            delete row["is_deleted"];
            delete row["created_date"];

          }
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/update_service_provider_apn_pdp_ip",
            role_name: role,
            module: "Private Networks",
            row_id: row.id,
            action: actionType_ ? actionType_ :actionType,
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }
        //  if (popupHeading === "Private Networks" && allow_delete && !actionType) {
        //   url = ENV_ROUTES.TENANT_ONBOARDING
        //   if (row) {
        //     row["modified_by"] = firstLastName;
        //     delete row["is_deleted"];
        //     delete row["created_date"];

        //   }
        //   data = {
        //     tenant_name: partner || "default_value",
        //     username: username,
        //     firstLastName: firstLastName,
        //     path: "/deactivate_private_network",
        //     role_name: role,
        //     module: "Private Networks",
        //     row_id: row.id,
        //     action: "delete",
        //     Partner: partner,
        //     request_received_at: getCurrentDateTime(),
        //     access_token: token,
        //     db_name: selectedDb,
        //         ...metaData,
        //     sessionID: sessionId,
        //   };
        // }
        console.log("deleteIndex", url);
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (response && response.status === 200) {
          if (parsedData.flag === false) {
                  setLoading(false);
                  if(parsedData.error_type && parsedData.error_type=="Warning"){
                    console.log("parsedData.error_type",parsedData.error_type)
                    Modal.confirm({
                      title: 'Warning',
                      content: parsedData.message || 'An error occurred while submitting data. Please try again.',
                      centered: true,
                      onCancel:()=>{
                      console.log("rowData[rowIndex] before",rowData[rowIndex])
                          rowData[rowIndex] = {...originalRowCopy}
                        setRowData((prev: any) => {
                          const updated = [...prev];
                          updated[rowIndex] = { ...originalRowCopy };
                          return updated;
                        })
                          console.log("rowData[rowIndex] after",rowData[rowIndex])
                      },
                      onOk:()=>{
                        if (popupHeading === "Customer Rate Plan"){
                          handleDelete(rowIndex,true)
                        }
                        else{
                          return
                        }
                      }
                    });
                  }
                  else{
                    Modal.error({
                      title: "Submit Error",
                      content:
                        parsedData.message ||
                        "An error occurred while submitting data. Please try again.",
                      centered: true,
                    });
                  }
                  return
                }
                else{
                  if (popupHeading === "Private Networks" && !allow_delete) {
                    if (parsedData?.can_deactivate) {
                      setActionType(actionType_ === "Deactive" ? "Deactive" : "Active")
                      setDeleteModalOpen(true)
                     return;
                    }
                    else {
                      setOpenPrivateNetworksDeleteModal(true);
                      setPrivateNetworksDeleteData(parsedData)
                      return;
                    }
                  }
                  else if(popupHeading === "Private Networks" && parsedData.validation){
                    Modal.warning({
                      title:"Validation Error",
                      content:parsedData.message || "Error Saving Record",
                      centered:true
                    })
                    return;
                  }
                  else {
                    notification.success({
                      message: "Success",
                      description: popupHeading === "Private Networks"? parsedData.message: "Successfully Deleted the record!",
                      style: messageStyle,
                      placement: "top",
                    });
                    fireSideCannons()
                  }
          
        }
          if (popupHeading === "Customers") {
            const url = ENV_ROUTES.PEOPLE_MODULE;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/get_customers_list_view_data",
              role_name: role,
              parent_module: "People",
              module_name: "Customers",
              feature_module_name: "Customers",
              mod_pages: {
                start: 0,
                end: 100,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,
            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              setLoading(false)
              Modal.error({
                title: 'Data Fetch Error',
                content: parsedData.message || 'An error occurred while fetching Customers data. Please try again.',
                centered: true,
              });
            } else {
              const tableData = parsedData?.data || [];
              console.log("tableData", tableData)
              settabledata(tableData);
              setLoading(false)
              await callCustomersLambdaSync()
            }
          }
          if (popupHeading === "Customer Group") {
            // callCoustomerGroupsSyncLambda()
            const url = ENV_ROUTES.MODULE_MANAGEMENT;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/get_partner_info",
              role_name: role,
              parent_module: "Partner",
              modules_list: ["Customer groups"],
              feature_module_name: "Partner Info",
              pages: {
                "Customer groups": { start: 0, end: 100 },
                "Partner users": { start: 0, end: 100 },
              },
              offset:0,
              Partner: partner,
              request_received_at: getCurrentDateTime(),
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,
            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching Customer groups data. Please try again.",
                centered: true,
              });
            } else {
              setCustomerGroups(parsedData);
              const tableData =
                parsedData?.data?.["Customer groups"]?.customergroups || [];
              setRowData(tableData);
            }
          }
          if (popupHeading === "Optimization Group") {
            const url =ENV_ROUTES.MODULE_MANAGEMENT;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName:firstLastName,
              path: "/get_module_data",
              role_name: role,
              parent_module: "Sim Management",
              module_name: "Optimization Group",
              feature_module_name:"Optimization Groups",
              mod_pages: {
                start: 0,
                end: 100,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,
            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const tableData_ = parsedData?.data?.optimization_group || []
              setRowData(tableData_);
              pagination = parsedData?.pages || pagination
            }
          }
          const callRunDBScriptServiceProviders = async () => {
          const url = ENV_ROUTES.SIM_MANAGEMENT;
          const data = {
                 tenant_name: partner || "default_value",
                       username: username,
                       firstLastName: firstLastName,
                       path: "/run_db_script",
                       role_name: role,
                       module_name: "Service Provider",
                       access_token: token,
                       db_name: selectedDb,
                ...metaData,
                       sessionID: sessionId,
                       update_flag: false,
                       delete_flag: true,
                       request_received_at: getCurrentDateTime(),
                       Partner: partner || "default_value",
                       data: {
                         serviceprovider: [{
                 
                           ...(rowData[rowIndex]?.id && { id: rowData[rowIndex]?.id }),
                           ...(rowData[rowIndex]?.service_provider_name && { service_provider_name: rowData[rowIndex]?.service_provider_name }),
                           ...(rowData[rowIndex]?.integration_id && { integration_id: rowData[rowIndex]?.integration_id }),
                           ...(rowData[rowIndex]?.bill_period_end_day && { bill_period_end_day: rowData[rowIndex]?.bill_period_end_day }),
                           ...(rowData[rowIndex]?.bill_period_end_hour && { bill_period_end_hour: rowData[rowIndex]?.bill_period_end_hour }),
                           ...(rowData[rowIndex]?.optimization_start_hour_local_time && { optimization_start_hour_local_time: rowData[rowIndex]?.optimization_start_hour_local_time }),
                           ...(rowData[rowIndex]?.service_provider_name && { display_name: rowData[rowIndex]?.service_provider_name }),
                           deleted_by:firstLastName,
                           deleted_date: getCurrentDateTime(),
                           is_deleted:true ,
                           is_active:false,
                           ...(rowData[rowIndex]?.write_is_enabled && { write_is_enabled: rowData[rowIndex]?.write_is_enabled }),
                           tenant_id: row?.tenant_id || 1,
                         }]
                       },
               };
      
          try {
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
          } catch (error) {
          }
      
        }
          if (popupHeading === "service providers") {
            setLoading(true)
            const url = ENV_ROUTES.MODULE_MANAGEMENT;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/service_provider_list_view",
              role_name: role,
              parent_module: "Partner",
              feature_module_name: "Partner Info",
              mod_pages: {
                start: 0,
                end: 100,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,
            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
              // Check if the flag is false in the parsed data
              setLoading(false);
              const tableData =parsedData?.data || [];
               setRowData(tableData);
               pagination = parsedData?.pages || pagination
               console.log(rowData[rowIndex]?.id,"show rowIndex")
               const secondApiPayload = {
                 tenant_name: partner || "default_value",
                       username: username,
                       firstLastName: firstLastName,
                       path: "/run_db_script",
                       role_name: role,
                       module_name: "Service Provider",
                       access_token: token,
                       db_name: selectedDb,
                ...metaData,
                       sessionID: sessionId,
                       update_flag: false,
                       delete_flag: true,
                       request_received_at: getCurrentDateTime(),
                       Partner: partner || "default_value",
                       data: {
                         serviceprovider: [{
                 
                           ...(rowData[rowIndex]?.id && { id: rowData[rowIndex]?.id }),
                           ...(rowData[rowIndex]?.service_provider_name && { service_provider_name: rowData[rowIndex]?.service_provider_name }),
                           ...(rowData[rowIndex]?.integration_id && { integration_id: rowData[rowIndex]?.integration_id }),
                           ...(rowData[rowIndex]?.bill_period_end_day && { bill_period_end_day: rowData[rowIndex]?.bill_period_end_day }),
                           ...(rowData[rowIndex]?.bill_period_end_hour && { bill_period_end_hour: rowData[rowIndex]?.bill_period_end_hour }),
                           ...(rowData[rowIndex]?.optimization_start_hour_local_time && { optimization_start_hour_local_time: rowData[rowIndex]?.optimization_start_hour_local_time }),
                           ...(rowData[rowIndex]?.service_provider_name && { display_name: rowData[rowIndex]?.service_provider_name }),
                           deleted_by:firstLastName,
                           deleted_date: getCurrentDateTime(),
                           is_deleted:true ,
                           is_active:false,
                           ...(rowData[rowIndex]?.write_is_enabled && { write_is_enabled: rowData[rowIndex]?.write_is_enabled }),
                           tenant_id: row?.tenant_id || 1,
                         }]
                       },
               };
         
               // Call the second API
               callRunDBScriptServiceProviders()
              //  await axios.post(ENV_ROUTES.SIM_MANAGEMENT, { data :secondApiPayload });
          }
          if (popupHeading === "Device notifications") {
            setLoading(true)
            const url = ENV_ROUTES.NOTIFICATION_SERVICES;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/get_notification_rules",
              role_name: role,
              parent_module: "Partner",
              module_name: "Usage Notification",
              feature_module_name: "Usage Notification",
              mod_pages: {
                start: 0,
                end: 100,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
                ...metaData,
            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              setLoading(false)
              const tableData_ = parsedData?.rule_data || []
              setRowData(tableData_);
              await callNotificationSync(rowData[rowIndex].rule_def_id, "delete");
            }
          }
          if (popupHeading === "Automation rule") {
            await callRunDBScriptForAutomation()
            await callLambdaSync()
            const url = ENV_ROUTES.AUTOMATION_RULE;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/get_automation_rule_data",
              table: "automation_rule",
              role_name: role,
              module_name: "Automation rule",
              feature_module_name: "Automation",
              mod_pages: {
                start: 0,
                end: 100,
              },
              Partner: partner,
              request_received_at: getCurrentDateTime(),
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,
            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const tableData_ = parsedData?.automation_rule_data || []
              setRowData(tableData_);
              pagination = parsedData?.pages || pagination
            }
          }

          if (popupHeading === "E911 Customer") {
            const url = ENV_ROUTES.PEOPLE_MODULE;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/people_list_view",
              role_name: role,
              parent_module: "People",
              module_name: "E911 Customers",
              feature_module_name: "E911 Customers",
              mod_pages: {
                start: 0,
                end: 100,
              },
              Partner: partner,
              request_received_at: getCurrentDateTime(),
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching E911 Customers data. Please try again.",
                centered: true,
              });
            } else {
              const headerMap =
                parsedData.headers_map["E911 Customers"]["header_map"];
              const createModalData =
                parsedData.headers_map["E911 Customers"]["pop_up"];
              const customertableData = parsedData.data;
              setRowData(customertableData);
              pagination = parsedData?.pages || pagination
            }
          }
          if (popupHeading === "NetSapien Customer") {
            const url = ENV_ROUTES.PEOPLE_MODULE;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/people_list_view",
              role_name: role,
              parent_module_name: "people", // Corrected spelling from 'poeple'
              module_name: "NetSapiens Customers",
              feature_module_name: "NetSapiens Customers",
              mod_pages: {
                start: 0,
                end: 100,
              },
              Partner: partner,
              request_received_at: getCurrentDateTime(),
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            // Check if the flag is false in the parsed data
            const tableData = parsedData.data;
            const headerMap =
              parsedData.headers_map["NetSapiens Customers"]["header_map"];
            const createModalData =
              parsedData.headers_map["NetSapiens Customers"]["pop_up"];
            const generalFields = parsedData.data;
            setRowData(tableData);
            pagination = parsedData?.pages || pagination
          }
          const callRunDBScriptUser = async () => {
              const url = ENV_ROUTES.SIM_MANAGEMENT;
              const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/run_db_script",
                role_name: role,
                module_name: "Partner Users",
                access_token: token,
                db_name: selectedDb,
                    ...metaData,
                sessionID: sessionId,
                update_flag:false,
                delete_flag: true,
                transfer_name: "users_sync_beta",
                request_received_at: getCurrentDateTime(),
                Partner: partner || "default_value",
                data: {
                  users: [{
                    username:row?.username || "",
                    tenant_id: 1,
                    id: row.id,
                    is_active:false,
                    is_deleted:true
                  }]
                },
              };
          
              try {
                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);
              } catch (error) {
              }
          
            }
          if (popupHeading === "User") {
            const url = ENV_ROUTES.MODULE_MANAGEMENT;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/get_partner_info",
              role_name: role,
              parent_module: "Partner",
              modules_list: ["Partner users"],
              feature_module_name: "Partner Info",
              pages: {
                "Customer groups": { start: 0, end: 100 },
                "Partner users": { start: 0, end: 100 },
              },
              request_received_at: getCurrentDateTime(),
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,
              active_toggle:partnerUsersShowActive ?? false
            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
              callRunDBScriptUser()
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching Users data. Please try again.",
                centered: true,
              });
            } else {
              setPartnerUsers(parsedData);
              const tableData =
                parsedData?.data?.["Partner users"]?.users || [];
              setRowData(tableData);
              pagination = parsedData?.pages || pagination
            }
          }

          const callRunDBScriptCustomerRatePlans = async () => {
              const url = ENV_ROUTES.SIM_MANAGEMENT;
              const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/run_db_script",
              role_name: role,
              module_name: "Customer Rate Plan",
              mod_pages: {
                start: 0,
                end: 100,
              },
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,
              delete_flag: true,
              request_received_at: getCurrentDateTime(),
              Partner: partner || "default_value",
              data: {
                customer_rate_plan:[{
                  id:rowData[rowIndex]?.id,
                  service_provider_id:rowData[rowIndex]?.service_provider_id,
                  is_deleted:true ,
                  is_active:false,
                  deleted_by:firstLastName,
                  deleted_date: getCurrentDateTime(),
                }  ]
              },
            };;
          
              try {
                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);
              } catch (error) {
                console.log("error in callRunDBScriptCustomerRatePlans",error)
              }
          
            }
          if (popupHeading === "Customer Rate Plan") {
            const url = ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/get_customer_rate_plan_list_view_data",
              role_name: role,
              parent_module: "Sim Management",
              module_name: customerShowActive ? "Active Customer Rate Plan" : "Customer Rate Plan",
              feature_module_name: "Customer Rate Plans",
              mod_pages: {
                start: 0,
                end: 100,
              },
              Partner: partner,
              request_received_at: getCurrentDateTime(),
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            // Check if the flag is false in the parsed data
            const tableData = parsedData?.data?.customerrateplan || [];
            // setRowData(tableData);
            settabledata(tableData);
            pagination = parsedData?.pages || pagination
            console.log(rowData[rowIndex]?.id,"show rowIndex")
            callRunDBScriptCustomerRatePlans()
          }
          if (popupHeading === "Customer Rate Pool") {
            callCustomerRatePoolsSync()
            const url = ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/get_customer_rate_pool_list_view_data",
              role_name: role,
              parent_module: "Sim Management",
              module_name: "Customer Rate Pool",
              feature_module_name: "Customer Rate Pools",
              mod_pages: {
                start: 0,
                end: 100,
              },
              Partner: partner,
              request_received_at: getCurrentDateTime(),
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            // Check if the flag is false in the parsed data
            const tableData = parsedData?.data?.customer_rate_pool || [];
            // setRowData(tableData);
            settabledata(tableData);
            pagination = parsedData?.pages || pagination
          }
          if (popupHeading === "Create Rate Plan Type") {
            const url = ENV_ROUTES.MODULE_MANAGEMENT;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/get_module_data",
              role_name: role,
              parent_module: "Sim Management",
              module_name: "Create Rate Plan Type",
              feature_module_name: "Rate Plans/SOCs",
              mod_pages: {
                start: 0,
                end: 100,
              },
              Partner: partner,
              request_received_at: getCurrentDateTime(),
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            // Check if the flag is false in the parsed data
            const tableData =
              parsedData?.data?.optimization_rate_plan_type || [];
            setRowData(tableData);
            pagination = parsedData?.pages || pagination
          }
          if (popupHeading === "Feature Codes") {
            const url = ENV_ROUTES.MODULE_MANAGEMENT;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/get_module_data",
              role_name: role,
              parent_module: "Sim Management",
              module_name: "Feature Codes",
              feature_module_name: "Rate Plans/SOCs",
              mod_pages: {
                start: 0,
                end: 100,
              },
              Partner: partner,
              request_received_at: getCurrentDateTime(),
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            // Check if the flag is false in the parsed data
            const tableData =
              parsedData?.data?.mobility_feature || [];
            setRowData(tableData);
            pagination = parsedData?.pages || pagination
          }
          if (popupHeading === "Private Networks") {
            const url = ENV_ROUTES.TENANT_ONBOARDING;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/get_private_networks_list_view",
              role_name: role,
              parent_module: "Sim Management",
              module_name: "Private Networks",
              feature_module_name: "Private Networks",
              mod_pages: {
                start: 0,
                end: 100,
              },
              Partner: partner,
              tenant_id:tenant_id_,
              request_received_at: getCurrentDateTime(),
              access_token: token,
              db_name: selectedDb,
              ...metaData,
              toggle_status:privateNetworksShowActive,
              sessionID: sessionId,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            // Check if the flag is false in the parsed data
            const tableData =
              parsedData?.data || [];
            setRowData(tableData);
            pagination = parsedData?.pages || pagination
          }
        } else {
          const errorMsg = JSON.parse(response.data.body).message;
          Modal.error({
            title: "Saving Error",
            content: errorMsg,
            centered: true,
          });
        }
      } catch (err) {
        // console.error("Error fetching data:", err);
        notification.error({
          message: "Error",
          description: "Failed to Deleted the record. Please try again.",
          style: messageStyle,
          placement: "top", // Apply custom styles here
        }); //// place it after you make the call to load the table data
      }
      finally{
        setLoading(false)
      }
      // setRowData(updatedData);
    }
  };

  const handleToggle = (rowIndex: number, col: string, apiState: boolean) => {
    const updatedData = [...rowData];
    const row = updatedData[rowIndex];
    let state;
    setRowIndex(rowIndex);
    setColumnName(col);

    if (apiState) {
      if (
        col === "Module State" ||
        col === "API State" ||
        col === "Email Status"
      ) {
        state = "Disable";
        if (row?.email_type === "AWS") {
          setIsConfirmationVisible(true);
        } else {
          setDisableModalOpen(true);
        }

      } else {
        state = "Inactive";
        setDisableModalOpen(true);
      }
    } else {
      if (
        col === "Module State" ||
        col === "API State" ||
        col === "Email Status"
      ) {
        state = "Enable";
        if (row?.email_type === "AWS") {
          setIsConfirmationVisible(true);
        } else if (emailConditionModal === false) {
          Modal.error({
            title: "Note",
            content:
              "From email address is missing! Please verify in partner info.",
            centered: true,
          });
        }
        else {
          setEnableModalOpen(true);
        }

      } else {
        state = "Active";
        setEnableModalOpen(true);
      }
    }
    console.log("state", state)
    // Set the state for the modal prompt
    setState(state); // Make sure to define this state variable in your component
  };


  const handleConfirm = (state: any) => {
    console.log("handle confirm", state)
    if (state === "Enable") {
      setIsConfirmationVisible(false)
      setEnableModalOpen(true);
    } else if (state === "Disable") {
      setIsConfirmationVisible(false)
      setDisableModalOpen(true);
    }
  }

  const confirmDelete = () => {
    if (deleteRowIndex !== null) {
      handleDelete(deleteRowIndex);
    }
    if(privateNetworksDeleteRowIndex !== null){
      handleDelete(privateNetworksDeleteRowIndex,true);
    }
    setDeleteModalOpen(false);
    setDeleteRowIndex(null);
  };

const handleCellChange = (rowIndex: number, header: string, value: any) => {
  setRowData((prevData: any[]) => {
    const updatedRows = [...prevData];
   updatedRows[rowIndex] = {
  ...updatedRows[rowIndex],
  [header]: value,
  // isEdited: true,
  };
    if (onRowDataChange) {
      onRowDataChange(updatedRows);
    }
    if(popupHeading === "Roles"){
      settabledata(updatedRows)
    }
    return updatedRows;
  });
};


  type ModuleRow = {
  module_name: string;
  sub_module: string; // "" | "Reports" | "Reports - A/R Aging"
  module_status: boolean;
};

  const isDescendant = (parent: ModuleRow, child: ModuleRow) => {
    if (parent.module_name !== child.module_name) return false;

    if (!parent.sub_module) {
      // Root module → all rows with same module_name but having sub_module
      return Boolean(child.sub_module);
    }

    return child.sub_module.startsWith(parent.sub_module + " -");
  };

  const setModuleAndDescendantsState = (
    selectedRow: any,
    newState: any,
    data: any[]
  ): ModuleRow[] => {
    return data.map((row) => {
      if (
        row.module_name === selectedRow.module_name &&
        (row.sub_module === selectedRow.sub_module ||
          isDescendant(selectedRow, row))
      ) {
        return { ...row, module_status: newState };
      }

      return row;
    });
  };

  const confirmSubmit = async (
    rowIndex: number,
    col: string,
    apiState: boolean
  ) => {
    const updatedData = [...rowData];
    const row = updatedData[rowIndex];
    if (apiState) {
      if (col === "Module State" || col === "Role Status") {
        if (popupHeading === "Partner Roles"){
          row.role_status = true
        }
        else if(popupHeading === "Partner Module Access") {
          row.module_status = true
        }
        else{
          row.is_active = true; // Set to true for active
        }
        // Set to true for enable
      }
      else if (col === "Email Status") {
        row.email_status = true;
      }
      else if (col === "User Status") {
        row.is_active = "True";
        row.is_deleted = "False";
      } 
      else if (popupHeading==="Tenant Banner" && col === "Status") {
        row.status = true;
      }
      else {
        row.api_state = true; // Set to true for active
      }
    } else {
      if (col === "Module State" || col === "Role Status") {
        if (popupHeading === "Partner Roles"){
          row.role_status = false
        }
        else if(popupHeading === "Partner Module Access") {
          row.module_status = false
        }
        else{
        // Set to false for disable
        row.is_active = false; // Set to false for inactive
        }
        
      } else if (col === "Email Status") {
        row.email_status = false;
      }
      else if (col === "User Status") {
        row.is_active = "False";
        row.is_deleted = "True";
      }else if (popupHeading==="Tenant Banner" && col === "Status") {
        row.status = false;
      } 
      else {
        row.api_state = false; // Set to false for inactive
      }
    }

    updatedData[rowIndex] = row;
    if (popupHeading === "Partner Roles") {
      setModifiedPartnerRolesData(updatedData)
    }
    if (popupHeading === "Partner Module Access") {
  if (!row) return;

  const newState = !!row.module_status;

  const updated = setModuleAndDescendantsState(
    row,
    newState,
    updatedData
  );

  setRowData(updated);
  setModifiedPartnerModuleAccessData(updated);
}
    // setCurrentRowData(row)
    // setRowData(updatedData);
    setEnableModalOpen(false);
    setDisableModalOpen(false);

    if (row && popupHeading!=="Roles" && popupHeading !== "Partner Roles" && popupHeading !== "Partner Module Access") {
      try {
        let url = ENV_ROUTES.MODULE_MANAGEMENT;
        let data;
        if (popupHeading === "Tenant Banner") {
          let submitData: any = {}
          if (row) {
            submitData = {
              tenant_name: row?.["tenant_name"] || "",
              banner: row?.["banner"] || "",
              status: row?.status || false,
              modified_by: firstLastName,
              id: row?.id || 1
            }
          }
          url = ENV_ROUTES.TENANT_ONBOARDING;
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/user_actions_tenant_based_banners",
            role_name: role,
            parent_module: "Super Admin",
            module_name: "Deployment Notifier",
            sub_module: "Tenant Based Banners",
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            modified_by: firstLastName,
            request_received_at: getCurrentDateTime(),
            changed_data: submitData,
            action: "update"
          };
        }
        if (popupHeading === "Carrier") {
          if (row) {
            row["last_modified_by"] = firstLastName;
            // row["last_modified_date_time"] = getCurrentDateTime();
            delete row["last_modified_date_time"]
            delete row["modified_date"]
          }
          url = ENV_ROUTES.TENANT_ONBOARDING;
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/update_superadmin_data",
            role_name: role,
            sub_module: "Partner API",
            sub_tab: "Carrier APIs",
            table_name: "carrier_apis",
            changed_data: row,
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }

        if (popupHeading === "API") {
          if (row) {
            row["last_modified_by"] = firstLastName;
            // row["last_modified_date_time"] = getCurrentDateTime();
            delete row["last_modified_date_time"]
            delete row["modified_date"]
          }
          url = ENV_ROUTES.TENANT_ONBOARDING;
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/update_superadmin_data",
            role_name: role,
            sub_module: "Partner API",
            sub_tab: "Amop APIs",
            table_name: "amop_apis",
            changed_data: row,
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }
        // if (popupHeading === "Roles") {
        //   if (row) {
        //     row["modified_by"] = firstLastName;
        //     row["modified_date"] = getCurrentDateTime();
        //   }
        //   url = ENV_ROUTES.TENANT_ONBOARDING;
        //   data = {
        //     tenant_name: partner || "default_value",
        //     username: username,
        //     firstLastName: firstLastName,
        //     path: "/update_superadmin_data",
        //     role_name: role,
        //     sub_module: "Partner Modules",
        //     table_name: "roles",
        //     Partner: partner,
        //     changed_data: row,
        //     request_received_at: getCurrentDateTime(),
        //     access_token: token,
        //     db_name: selectedDb,
                // ...metaData,
        //     sessionID: sessionId,
        //   };
        // }
        if (popupHeading === "Module Access") {
          if (row) {
            row["modified_by"] = firstLastName;
            row["modified_date"] = getCurrentDateTime();
          }
          url = ENV_ROUTES.TENANT_ONBOARDING;
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/update_superadmin_data",
            role_name: role,
            sub_module: "Partner Modules",
            table_name: "tenant_module",
            changed_data: row,
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }
        if (popupHeading === "Email Template") {
          url = ENV_ROUTES.NOTIFICATION_SERVICES;
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/submit_update_copy_status_email_template",
            role_name: role,
            parent_module: "Partner",
            module: "Notifications",
            partner: partner,
            action: "update",
            table_name: "email_templates",
            changed_data: row,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }
        const callRunDBScript = async (formData: any) => {
          const url = ENV_ROUTES.SIM_MANAGEMENT;
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/run_db_script",
            role_name: role,
            module_name: "Partner Users",
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            update_flag:true,
            delete_flag: false,
            transfer_name:"users_sync",
            request_received_at: getCurrentDateTime(),
            Partner: partner || "default_value",
            data: {
              users: [{
                ...(formData.id && { id: formData.id }),
                ...(formData.role && { role: formData.role }),
                ...(formData.is_active && { is_active: formData.is_active }),
                ...(formData.is_deleted && { is_deleted: formData.is_deleted }),
                deleted_by: firstLastName,
                deleted_date: getCurrentDateTime(),
                tenant_id:1,
              }]
            },
          };
      
          try {
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
          } catch (error) {
          }
      
        }
        if (popupHeading === "User") {
          delete row["tenant_id"]
          row["modified_by"] = firstLastName;
          delete row["modified_date"]
          delete row["deleted_date"]
          url = ENV_ROUTES.MODULE_MANAGEMENT;
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/update_partner_info",
            role_name: role,
            template_name: "create_user",
            module_name: "Partner users",
            action: "delete",
            request_received_at: getCurrentDateTime(),
            changed_data: row,
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,

          };
        }
        const response = await axios.post(url, { data });
        const resp = JSON.parse(response.data.body);

        if (response.data.statusCode === 200 && resp.flag === true) {
          notification.success({
            message: "Success",
            description: "Successfully edited the record",
            style: messageStyle,
            placement: "top", // Apply custom styles here
          });
          fireSideCannons()
          // if (response.data.statusCode === 400 && resp.flag === false) {
          //   Modal.error({
          //     title: "Saving Error",
          //     content: resp.message,
          //     centered: true,
          //   });
          // }
          try{
            setLoading(true)
            const createAuditLogs = async () => {
              try {
                setLoading(true)
                const url = ENV_ROUTES.TENANT_ONBOARDING;
                const data = {
                  tenant_name: partner || "default_value",
                  username: username,
                  firstLastName: firstLastName,
                  path: "/log_deployment_audit_logs",
                  role_name: role,
                  parent_module: "Super Admin",
                  module_name: "Deployment Notifier",
                  sub_module: "Tenant Based Banners logs",
                  Partner: partner,
                  access_token: token,
                  db_name: selectedDb,
                ...metaData,
                  sessionID: sessionId,
                  modified_by: firstLastName,
                  audit_data: {
                    tenant_name: row?.["tenant_name"] || "",
                    banner: row?.["banner"] || "",
                    created_by: firstLastName || username,
                    modified_by: firstLastName || username,
                    status: row?.status ? "Active" : "Inactive"
                  },
                  action: "create",
                  request_received_at: getCurrentDateTime(),

                };

                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);

                if (parsedData.flag === false) {
                  Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching Inventory data. Please try again.',
                    centered: true,

                  });
                }
              } catch (error) {
                console.error("Error fetching data:", error);
                Modal.error({
                  title: 'Data Fetch Error',
                  content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                  centered: true,

                });
              } finally {
              }
            };
            if (popupHeading === "Tenant Banner") {
              createAuditLogs()
              onsave()
              settabledata([])
              try {
                const url = ENV_ROUTES.TENANT_ONBOARDING;
                const data = {
                  tenant_name: partner || "default_value",
                  username: username,
                  firstLastName: firstLastName,
                  path: "/get_tenant_banners_list_view_data",
                  role_name: role,
                  parent_module: "Super Admin",
                  module_name: "Deployment Notifier",
                  sub_module: "Tenant Based Banners",
                  mod_pages: {
                    start: 0,
                    end: 25,
                  },
                  limit: 25,
                  request_received_at: getCurrentDateTime(),
                  Partner: partner,
                  access_token: token,
                  db_name: selectedDb,
                ...metaData,
                  sessionID: sessionId,
                };
                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);
                if (parsedData.flag === false) {
                  Modal.error({
                    title: "Data Fetch Error",
                    content:
                      parsedData.message ||
                      "An error occurred while fetching data. Please try again.",
                    centered: true,
                  });
                } else {
                  const tableData_ = parsedData?.data || [];
                  setRowData(tableData_);
                }
               } catch (err) {
                  console.error("Error fetching data:", err);
                } finally {
                }
              }
            if (popupHeading === "User") {
              callRunDBScript(row)
              const url = ENV_ROUTES.MODULE_MANAGEMENT;
              const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_partner_info",
                role_name: role,
                parent_module: "Partner",
                modules_list: ["Partner users"],
                feature_module_name: "Partner Info",
                pages: {
                  "Customer groups": { start: 0, end: 100 },
                  "Partner users": { start: 0, end: 100 },
                },
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                active_toggle:partnerUsersShowActive ?? false
              };
              const response = await axios.post(url, { data });
              const parsedData = JSON.parse(response.data.body);
              if (parsedData.flag === false) {
                Modal.error({
                  title: "Data Fetch Error",
                  content:
                    parsedData.message ||
                    "An error occurred while fetching Users data. Please try again.",
                  centered: true,
                });
              } else {
                setPartnerUsers(parsedData);
                const tableData =
                  parsedData?.data?.["Partner users"]?.users || [];
                setRowData(tableData);
              }
            }
            if (popupHeading === "Carrier") {
              try {
                const url = ENV_ROUTES.TENANT_ONBOARDING;
                const data = {
                  tenant_name: partner || "default_value",
                  username: username,
                  firstLastName: firstLastName,
                  path: "/get_superadmin_info",
                  role_name: role,
                  parent_module: "Super Admin",
                  sub_module: "Partner API",
                  sub_tab: "Carrier APIs",
                  mod_pages: {
                    start: 0,
                    end: 100,
                  },
                  Partner: partner,
                  request_received_at: getCurrentDateTime(),
                  access_token: token,
                  db_name: selectedDb,
                ...metaData,
                  sessionID: sessionId,
                };
                const response = await axios.post(url, { data: data });
                const resp = JSON.parse(response.data.body);
                const carrierApis = resp.data.Carrier_apis_data.carrier_apis;
                setRowData(carrierApis);
              } catch (err) {
                console.error("Error fetching data:", err);
                // Modal.error({
                //   title: 'Data Fetch Error',
                //   content: err instanceof Error ? err.message : 'An unexpected error occurred while fetching data. Please try again.',
                //   centered: true,
                // });
              } finally {
                // setLoading(false); // Set loading to false after the request is done
              }
            }
            if (popupHeading === "API") {
              try {
                const url = ENV_ROUTES.TENANT_ONBOARDING;
                const data = {
                  tenant_name: partner || "default_value",
                  username: username,
                  firstLastName: firstLastName,
                  path: "/get_superadmin_info",
                  role_name: role,
                  parent_module: "Super Admin",
                  sub_module: "Partner API",
                  sub_tab: "Amop APIs",
                  mod_pages: {
                    start: 0,
                    end: 100,
                  },
                  Partner: partner,
                  request_received_at: getCurrentDateTime(),
                  access_token: token,
                  db_name: selectedDb,
                ...metaData,
                  sessionID: sessionId,
                };
  
                const response = await axios.post(url, { data: data });
                const resp = JSON.parse(response.data.body);
                const carrierApis = resp.data.amop_apis_data.amop_apis;
                setRowData(carrierApis);
              } catch (err) {
                console.error("Error fetching data:", err);
                // Modal.error({
                //   title: 'Data Fetch Error',
                //   content: err instanceof Error ? err.message : 'An unexpected error occurred while fetching data. Please try again.',
                //   centered: true,
                // });
              } finally {
                // setLoading(false); // Set loading to false after the request is done
              }
            }
            if (popupHeading === "Module Access") {
              try {
                const url = ENV_ROUTES.TENANT_ONBOARDING;
                const data = {
                  tenant_name: partner || "default_value",
                  username: username,
                  firstLastName: firstLastName,
                  path: "/get_superadmin_info",
                  role_name: role,
                  parent_module: "Super Admin",
                  sub_module: "Partner Modules",
                  flag: "withparameters",
                  Selected_Partner: selectedPartnerModule,
                  sub_partner: Environment,
                  modules: ["role partner module", "partner module"],
                  request_received_at: getCurrentDateTime(),
                  access_token: token,
                  db_name: selectedDb,
                ...metaData,
                  sessionID: sessionId,
  
                  // Send selected sub-partner
                };
  
                const response = await axios.post(url, { data: data });
                const resp = JSON.parse(response.data.body);
                // setRowData(resp.data.roles_data)
                setRowData(resp.data.role_module_data);
              } catch (err) {
                console.error("Error fetching data:", err);
                Modal.error({
                  title: "Data Fetch Error",
                  content:
                    err instanceof Error
                      ? err.message
                      : "An unexpected error occurred while fetching data. Please try again.",
                  centered: true,
                });
              } finally {
                // setLoading(false); // Set loading to false after the request is done
              }
            }
            if (popupHeading === "Roles") {
              try {
                const url = ENV_ROUTES.TENANT_ONBOARDING;
                const data = {
                  tenant_name: partner || "default_value",
                  username: username,
                  firstLastName: firstLastName,
                  path: "/get_superadmin_info",
                  role_name: role,
                  parent_module: "Super Admin",
                  sub_module: "Partner Modules",
                  flag: "withparameters",
                  Partner: selectedPartnerModule,
                  sub_partner: Environment,
                  modules: ["role partner module", "partner module"],
                  request_received_at: getCurrentDateTime(),
                  access_token: token,
                  db_name: selectedDb,
                ...metaData,
                  sessionID: sessionId,
  
                  // Send selected sub-partner
                };
  
                const response = await axios.post(url, { data: data });
                const resp = JSON.parse(response.data.body);
                setRowData(resp.data.roles_data);
                // setRowData(resp.data.role_module_data)
              } catch (err) {
                console.error("Error fetching data:", err);
                // Modal.error({
                //   title: 'Data Fetch Error',
                //   content: err instanceof Error ? err.message : 'An unexpected error occurred while fetching data. Please try again.',
                //   centered: true,
                // });
              } finally {
                // setLoading(false); // Set loading to false after the request is done
              }
            }
            if (popupHeading === "Email Template") {
              try {
                const url = ENV_ROUTES.NOTIFICATION_SERVICES;
                const data = {
                  tenant_name: partner || "default_value",
                  username: username,
                  firstLastName: firstLastName,
                  path: "/email_template_list_view",
                  role_name: role,
                  parent_module: "Partner",
                  module_name: "notification services",
                  feature_module_name: "Notifications",
                  mod_pages: {
                    start: 0,
                    end: 100,
                  },
                  request_received_at: getCurrentDateTime(),
                  Partner: partner,
                  access_token: token,
                  db_name: selectedDb,
                ...metaData,
                  sessionID: sessionId,
                };
                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);
                const tableData_ = parsedData?.data || [];
  
                setRowData(tableData_);
              } catch (err) {
                console.error("Error fetching data:", err);
                // Modal.error({
                //   title: 'Data Fetch Error',
                //   content: err instanceof Error ? err.message : 'An unexpected error occurred while fetching data. Please try again.',
                //   centered: true,
                // });
              } finally {
                // setLoading(false); // Set loading to false after the request is done
              }
            }
          }
          catch{
            console.log("Error occured in Confirm Submit")
          }
          finally{
            setLoading(false);
          }
          
        }
        else {
          Modal.error({
            title: "Saving Error",
            content: resp.message,
            centered: true,
          });
        }
      } catch (err) {
        console.error("Error fetching data:", err);
        Modal.error({
          title: "Saving Error",
          content: err instanceof Error ? err.message : 'An unexpected error occurred while submitting data. Please try again.',
          centered: true,
        });
      }
    }
  };
  const renderApiState = (apiState: any, index: number, col: any) => {
    const currentRow = rowData[index] || {}
    let isParentModuleDisabled = false;
    let isNotParent = false;
    if (popupHeading === "Partner Module Access" && col === "Module State") {
      // Not a parent if sub_module has value
      isNotParent = Boolean(currentRow?.sub_module);

      if (isNotParent) {
        const subModulePath = currentRow.sub_module;
        const parts = subModulePath.split(" - ");

        // Find immediate parent path
        const parentSubModule =
          parts.length === 1 ? "" : parts.slice(0, -1).join(" - ");

        const parentRow =
          rowData.find((row: any) =>
            row.module_name === currentRow.module_name &&
            row.sub_module === parentSubModule
          ) || null;

        if (parentRow) {
          isParentModuleDisabled = !parentRow.module_status;
        }
      }
    }
    return (
      <div className="flex items-center space-x-2">
        <button
          className={`${apiState === true || apiState === "True" ? "active" : "deactive"} ${(popupHeading === "Partner Module Access" && col === "Module State" && isParentModuleDisabled) || isPartnerInfoTable ? "cursor-not-allowed" : ""}`}
          style={{ width: "100%" }}
          onClick={() => handleToggle(index, col, false)}
          disabled={(popupHeading === "Partner Module Access" && col === "Module State" && isParentModuleDisabled) || isPartnerInfoTable}
        >
          {col === "Module State" ||
            col === "API State" ||
            col === "Email Status" ? (
            <span>Enable</span>
          ) : (
            <span>Active</span>
          )}
        </button>
        <button
          className={`${apiState === false || apiState === "False" ? "active" : "deactive"} ${(popupHeading === "Partner Module Access" && col === "Module State" && isParentModuleDisabled) || isPartnerInfoTable ? "cursor-not-allowed" : ""}`}
          style={{ width: "100%" }}
          onClick={() => handleToggle(index, col, true)}
          disabled={(popupHeading === "Partner Module Access" && col === "Module State" && isParentModuleDisabled) || isPartnerInfoTable}
        >
          {col === "Module State" ||
            col === "API State" ||
            col === "Email Status" ? (
            <span>Disable</span>
          ) : (
            <span>Inactive</span>
          )}
        </button>
      </div>
    );
  };

  const renderTimeOut = (value: any, index: number, col: any) => {
    const row = rowData[index];
    const displayValue =
      row && row[col] !== undefined
        ? row[col]
        : value !== undefined
          ? value
          : 15;
    return (
      <div className="flex items-center space-x-2">
        <input
          type="number"
          value={displayValue}
          min="0"
          step="1"
          className="w-[100px] border border-gray-400 rounded pl-2 time-out-frequency"
          onChange={(e) => {
            const newTime = e.target.value === "" ? 0 : Number(e.target.value);
            console.log("newTime", newTime, typeof newTime); 
            handleCellChange(index, col, newTime);
          }}
        />
      </div>
    );
  };

  


  const renderEmailStatus = (status: string) => {
    let textColorClass = "";
    if (status === "True" || status === "NEW" || status === "Successful") {
      textColorClass = "text-blue-500";
    } else if (
      status === "False" ||
      status === "ERROR" ||
      status === "Failed" || status === "failure"
    ) {
      textColorClass = "text-red-500";
    } else if (status === "PROCESSED" || status === "success" || status === "Success" || status === "Complete") {
      textColorClass = "text-green-500";
    }
    else if(status === "Inprogress"){
      textColorClass = "text-yellow-500";
    }
    else if(status === "Open"){
      textColorClass = "text-black";
    }
    if (status === "True") {
      return <span className={`${textColorClass}`}>Active</span>;
    } else if (status === "False") {
      return <span className={`${textColorClass}`}>Inactive</span>;
    } else {
      return <span className={`${textColorClass} text-[16px]`}>{status}</span>;
    }
  };

  const renderCustomIMEIData = (status: any) => {
    if (status === true || status === "True") {
      return <span>Yes</span>;
    } else if (status === false || status === "False") {
      return <span>No</span>;
    } else {
      return <span>{status}</span>;
    }
  };
  const renderCustomFeatureCodes = (status: any) => {

    let processedStatus;

    if(status && status!=="None"){
       // Check if `status` is an array
    if (Array.isArray(status)) {
      processedStatus = status.join(", ");
    }
    // Check if `status` is an object
    else if (typeof status === "object" && status !== null) {
      processedStatus = Object.values(status).join(", ");
    }
    // If `status` is a string, use it directly
    else {
      processedStatus = status;
    }    
  }else{
    processedStatus=""
  }

   
    // Ensure the final result is plain text without brackets or quotes
    processedStatus = processedStatus
      .toString()
      .replace(/[\{\}\[\]"']/g, ""); // Remove brackets and quotes

    return  (<Tooltip
              title={`${processedStatus}`}
              placement="topLeft"
              overlayStyle={{ whiteSpace: 'normal', maxWidth: '60vw', wordWrap: 'break-word' ,zIndex: 50}}
              getPopupContainer={() => document.body} // Render tooltip directly on the body to avoid stacking issues
            >
              <span>{processedStatus}</span>
           </Tooltip>)
  };

  const renderCustomProducts = (status: any) => {
  let processedStatus = "";

  if (status && status !== "None") {
    // If it's an array, process each item
    if (Array.isArray(status)) {
      processedStatus = status
        .map((item) => item.split("--")[0].trim()) // Take part before `--` and trim spaces
        .join(", ");
    }
    // If it's an object, process its values
    else if (typeof status === "object" && status !== null) {
      processedStatus = Object.values(status)
        .map((item:any) => item.toString().split("--")[0].trim())
        .join(", ");
    }
    // If it's a string, just take part before `--`
    else {
      processedStatus = status.toString().split("--")[0].trim();
    }
  }

  return (
    <Tooltip
      title={processedStatus}
      placement="topLeft"
      overlayStyle={{
        whiteSpace: "normal",
        maxWidth: "60vw",
        wordWrap: "break-word",
        zIndex: 50,
      }}
      getPopupContainer={() => document.body}
    >
      <span>{processedStatus}</span>
    </Tooltip>
  );
};

  const renderCustomPackage = (value: any) => {

    let cleanedValue;
    if (value && value !== "None") {
      const valueParts = value.split("--")
      if (valueParts.length > 1) {
        cleanedValue = valueParts[0]
      }
    } else {
      cleanedValue = ""
    }

    return (<Tooltip
      title={`${cleanedValue}`}
      placement="topLeft"
      overlayStyle={{ whiteSpace: 'normal', maxWidth: '60vw', wordWrap: 'break-word', zIndex: 50 }}
      getPopupContainer={() => document.body} // Render tooltip directly on the body to avoid stacking issues
    >
      <span>{cleanedValue}</span>
    </Tooltip>)
  };
  const renderWriteEnabled = (writeEnabled: boolean) => {
    if (writeEnabled === true) {
      return (
        <CheckCircleIcon className="ml-5 w-5 h-5 text-green-500" />
      );
    } else {
      return (
        <XCircleIcon className="ml-5 w-5 h-5 text-red-500" />
      )
    }
  };
  const renderSendToCustomer = (send_to_customer: boolean | string) => {
    const isTrue =
      send_to_customer === true || send_to_customer === "True" || send_to_customer === "true";
    if (isTrue) {
      return (
        <CheckCircleIcon className="ml-5 w-5 h-5 text-green-500" />
      );
    } else {
      return (
        <XCircleIcon className="ml-5 w-5 h-5 text-red-500" />
      )
    }
  };
  const renderSendToCarrier = (send_to_carrier: boolean | string) => {
    const isTrue =
      send_to_carrier === true || send_to_carrier === "True" || send_to_carrier === "true";
    if (isTrue) {
      return (
        <CheckCircleIcon className="ml-5 w-5 h-5 text-green-500" />
      );
    } else {
      return (
        <XCircleIcon className="ml-5 w-5 h-5 text-red-500" />
      )
    }
  };


  const renderCarrierAssignedCoumn = (assigned: string) => {
    if (assigned === "True") {
      return <span>Yes</span>;
    } else if (assigned === "False") {
      return <span>No</span>;
    } else {
      return <span>{assigned}</span>;
    }
  };

  const renderRatePlanStatus = (status: any, header: string) => {
    const isStatusHeader = header === "Status";
    const getClass = (condition: boolean) => (condition ? "text-green-500" : "text-red-500");
    const status_=status==="True" || status==="true" || status===true ?"True":"False"
    if (status_ === "True") {
      return <span className={getClass(true)}>{isStatusHeader ? "Active" : status_}</span>;
    } else if (status_ === "False") {
      return <span className={getClass(false)}>{isStatusHeader ? "Inactive" : status_}</span>;
    } else {
      return <span>{status_}</span>;
    }
  };

  const renderAutomationRuleStatus = (status: string) => {
    console.log("renderAutomationRuleStatus")

    if (status === "Failed") {
      return <span className="text-red-500">Failed</span>;
    } else if (status === "Success") {
      return <span className="text-blue-500">Success</span>;
    } else {
      return <span>{status}</span>;
    }
  }

  // const handleSort = (key: string) => {
  //   let direction: "ascending" | "descending" = "ascending";
  //   if (
  //     sortConfig &&
  //     sortConfig.key === key &&
  //     sortConfig.direction === "ascending"
  //   ) {
  //     direction = "descending";
  //   }

  //   const sortedData = [...rowData].sort((a, b) => {
  //     let aValue = a[key];
  //     let bValue = b[key];

  //     // Special handling for the "Assigned rate plans" or "Assigned rate plan count" columns
  //     if (key === "carrier_rate_plans") {
  //       aValue = Array.isArray(aValue) ? aValue.length : JSON.parse(aValue)?.length || 0;
  //       bValue = Array.isArray(bValue) ? bValue.length : JSON.parse(bValue)?.length || 0;
  //     }

  //     if (aValue === null || aValue === undefined || aValue === 'None') return direction === "ascending" ? -1 : 1;
  //     if (bValue === null || bValue === undefined || bValue === 'None') return direction === "ascending" ? 1 : -1;

  //     if (aValue < bValue) {
  //       return direction === "ascending" ? -1 : 1;
  //     }
  //     if (aValue > bValue) {
  //       return direction === "ascending" ? 1 : -1;
  //     }
  //     return 0;
  //   });

  //   setSortConfig({ key, direction });
  //   setRowData(sortedData);
  // };

  const handleSort = (key: string) => {
    let direction: "ascending" | "descending" = "ascending";
    if (
        sortConfig &&
        sortConfig.key === key &&
        sortConfig.direction === "ascending"
    ) {
        direction = "descending";
    }

    // const sortedData = [...rowData].sort((a, b) => {
    //     let aValue = a[key];
    //     let bValue = b[key];

    //     // Special handling for the "Assigned rate plans" or "Assigned rate plan count" columns
    //     if (key === "carrier_rate_plans") {
    //         aValue = Array.isArray(aValue) ? aValue.length : JSON.parse(aValue)?.length || 0;
    //         bValue = Array.isArray(bValue) ? bValue.length : JSON.parse(bValue)?.length || 0;
    //     }

    //     // Convert 'None' to null for easier comparison
    //     const normalizeValue = (value: any) => {
    //         if (value === 'None') return null;
    //         return value;
    //     };

    //     aValue = normalizeValue(aValue);
    //     bValue = normalizeValue(bValue);

    //     // Function to split a string into alphabetical and numeric segments
    //     const splitIntoSegments = (str: string) => {
    //         return str.toLowerCase().match(/([a-z]+|\d+)/g) || [];
    //     };

    //     // Split values into segments
    //     const aSegments = typeof aValue === "string" ? splitIntoSegments(aValue) : [aValue];
    //     const bSegments = typeof bValue === "string" ? splitIntoSegments(bValue) : [bValue];

    //     // Compare each segment one by one
    //     for (let i = 0; i < Math.max(aSegments.length, bSegments.length); i++) {
    //         const aSegment = aSegments[i];
    //         const bSegment = bSegments[i];

    //         // If one segment is undefined, consider it smaller
    //         if (aSegment === undefined) return direction === "ascending" ? -1 : 1;
    //         if (bSegment === undefined) return direction === "ascending" ? 1 : -1;

    //         // Compare numeric segments numerically, and character segments lexicographically
    //         const isANumber = !isNaN(Number(aSegment));
    //         const isBNumber = !isNaN(Number(bSegment));

    //         if (isANumber && isBNumber) {
    //             // Both segments are numbers; compare them numerically
    //             const numA = Number(aSegment);
    //             const numB = Number(bSegment);
    //             if (numA < numB) return direction === "ascending" ? -1 : 1;
    //             if (numA > numB) return direction === "ascending" ? 1 : -1;
    //         } else {
    //             // At least one segment is not a number; compare them as strings
    //             if (aSegment < bSegment) return direction === "ascending" ? -1 : 1;
    //             if (aSegment > bSegment) return direction === "ascending" ? 1 : -1;
    //         }
    //     }

    //     return 0;
    // });
    setCurrentPage(1)
    setSortConfig({ key, direction });
    // setRowData(sortedData);
};

  const formatColumnName = (name: string) => {
    return name
      .replace(/_/g, " ") // Replace underscores with spaces
      .split(" ") // Split the string into words
      .map(
        (
          word // Capitalize each word
        ) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
      )
      .join(" "); // Join the words back into a single string
  };

  const colorMap = {
    activated: "#12E620",
    activate: "#12E620",
    reactive: "#12E620",
    online: "#12E620",
    active: "#12E620",
    a: "#12E620",
    deactivated: "#E61224",
    deactivate: "#E61224",
    deactive: "#E61224",
    inactive: "#E61224",
    stopped: "#E61224",
    "activation ready": "#E6CA15",
    "pending activation": "#52A6E6",
    retired: "#7D7D7D",
    "pre-active": "#d1dade",
    waiting: "#ffc107",
    unactivated: "#ffc107",
    // Add more statuses and colors as needed
};
 const currencyHeaders = ["SMS","Usage","Usage Tax","SMS Tax"]
  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }
  // Pagination component to be used in both places
  const paginationComponent = (
    <Pagination
        currentPage={currentPage}
        totalPages={totalPages}
        onPageChange={setCurrentPage}
        moduleName={popupHeading}
    />
);

  let paginatedData = rowData?.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "bold",
    padding: "16px",
  };

  const freezeColumn = (header:string) =>{
    if(
      (popupHeading === "Customer Rate Plan" && header === "rate_plan_name") || 
      (popupHeading === "Automation rule" && header === "automation_rule_name") || 
      (popupHeading === "Automation rule log" && header === "automation_rule_name")||
      (popupHeading === "Zero usage report" && header === "iccid") ||
      (popupHeading === "Newly actvated report" && header === "iccid") ||
      (popupHeading === "Usage by line report" && header === "iccid") ||
      (popupHeading === "Pool group summary report" && header === "pool_id") ||
      (popupHeading === "Customer rate pool usage report" && header === "iccid") ||
      (popupHeading === "Status history report" && header === "iccid") ||
      (popupHeading === "Daily usage report" && header === "iccid") ||
      (popupHeading === "Automation rule verification report" && header === "rule_name") ||
      (popupHeading === "Active Lines Report" && header === "iccid") ||
      (popupHeading === "Audit Logs Report" && header === "iccid") ||
      (popupHeading === "User" && header === "username") 
    ){
      return true
    }
    else{
      return false
    }
  }

  const report = ["Zero usage report", "Usage by line report","New Usage By Line Report", "Status history report", "Pool group summary report", "Newly actvated report", "Customer rate pool usage report", "Automation rule verification report", "Daily usage report"]
  const filteredHeaders = headers.filter(header => {
    if (header === "S.no" && report.includes(popupHeading)) {
      return false;
    }
    return true;
  });

  const callRunDBScriptUser = async (row: any) => {
    const url = ENV_ROUTES.SIM_MANAGEMENT;
    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/run_db_script",
      role_name: role,
      module_name: "Partner Users",
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
      update_flag: true,
      delete_flag: false,
      transfer_name: "users_sync_beta",
      request_received_at: getCurrentDateTime(),
      Partner: partner || "default_value",
      data: {
        users: [{
          username: row?.username || "",
          tenant_id: 1,
          id: row.id,
          change_pass_sync: true,

        }]
      },
    };

    try {
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
    } catch (error) {
    }

  }

   const handleResetPassword = async () => {
      setNewPasswordError("");
      setConfirmPasswordError("");
      // Regex for password validation: must contain a number, lowercase, and uppercase letter
      const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/;
  
      // Validate new password
      if (!passwordRegex.test(newPassword)) {
        setNewPasswordError(
          "New password must contain a number, lowercase, and uppercase characters."
        );
        return; // Stop further checks if new password is invalid
      }
  
      // Validate confirm password
      if (newPassword !== confirmPassword) {
        setConfirmPasswordError("Password does not match.");
        return;
      }
      console.log("New Password:", rowData);
      console.log("Confirm Password:", resetPasswordRowIndex);
  
      const data = {
        path: "/password_reset",
          username: resetPasswordRowIndex !== null && resetPasswordRowIndex !== undefined
          ? rowData[resetPasswordRowIndex]?.username
          : undefined,
        login_username:username,
        New_password: newPassword,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
      };
      try {
         setLoading(true)
        setResetPasswordModal(false)
      
        const url = ENV_ROUTES.USER_AUTHENTICATION;
        const response = await axios.post(
          url,
          { data: data },
          {
            headers: {
              "Content-Type": "application/json",
            },
          }
        );
        console.log("Response:", response.data);
        const resp = JSON.parse(response.data.body);
        if (response.data && response.data.statusCode === 200) {
          // const tenant_names = resp["tenant_names"];
          // setTenantNames(tenant_names);
          // const role = resp["role"];
          // setRole(role);
          // setSelectedPartner(false)
          // setIsAuthenticated(false)
          // setShowPasswordUpdate(false)
          // localStorage.clear()
          // sessionStorage.clear()
          const row_ = resetPasswordRowIndex !== null && resetPasswordRowIndex !== undefined
          ? rowData[resetPasswordRowIndex]
          : {}
          callRunDBScriptUser(row_)
          notification.success({
            message: "Password Update",
            description: "Password Updated Successfully!",
            style: messageStyle,
            placement: "top",
          });
          fireSideCannons()
          setResetPasswordModal(false)
          setLoading(false)
          setRefreshPage(prev => !prev);
        }
        else{
          Modal.error({
            title:"Password Update Failed",
            content:resp.message || "Password Update Failed. Please try again.",
            centered:true
          })
        }
      } catch (error) {
        console.error("Error:", error);
        setLoading(false)
        setResetPasswordModal(false)
      }
      setLoading(false)
      setNewPassword("");
      setConfirmPassword("");
      // LogoutChooseTenant();
    };
  const handleCancel = () => {
    setResetPasswordModal(false)
    setNewPassword("");
    setConfirmPassword("");
    setNewPasswordError("");
    setConfirmPasswordError("");
  };
   const RatePlanSocspreferredOrder = [
      "service_provider",       // Provider
      "friendly_name",          // Rate Plan Name
      "data_per_overage_charge",// Data Per Overage Charge (MB)
      "rate_plan_code",         // Soc Code
      "plan_mb",                // Plan MB (if present)
      "overage_rate_cost",      // Overage Rate Cost
      "device_type",            // Device Type
      "base_rate",              // Base Price
      "allows_sim_pooling",     //Pool SIMs
      "is_retired"             //Retire Rate Plan
    ];

  const getEdiPartnerTableCellClass = (header: string) => {
    if (header === "order_of_action") {
      return "!text-center"
    }
    else if (header === "setup_action") {
      return "!whitespace-nowrap"
    }
    else if (header === "summary") {
      return "!min-w-[500px]"
    }
    else {
      return ""
    }
  }
  const tablesInModals = ["Usage Details"]

  return (
    <div>
      {/* Show pagination at top right for small screens */}
      {isSmallScreen && visibleColumns.length > 0 && (
                <div className="flex justify-end mb-2 mr-2">
                    {paginationComponent}
                </div>
            )}
      <div className="overflow-x-auto overflow-y-auto" style={{
        height: `${
        // popupHeading !== "service providers" &&
        popupHeading !== "Roles" &&
        popupHeading !== "Module Access" &&
        popupHeading !== "Bulk Change History status log"&&
        popupHeading !== "Billable on Suspension"
        ? `${viewportHeight - height}px` 
        : "auto" // Apply auto height when moduleName matches
      }`, // Only apply the height when popupHeading is not in the listed modules
      }}>
        <table className="table-auto w-full">
          <thead className={`sticky top-0 bg-gray-200 z-10 ${tablesInModals.includes(popupHeading)?"disconnect-table-header":"table-header-row"}`}>
            <tr>
              {/* Render actions column if allowedActions is true */}
              {/* {visibleColumns.length > 0 && !report.includes(popupHeading) && (
                <th className="px-6 border-b border-gray-300 text-left font-semibold">
                  S.No
                </th>
              )} */}
              {(typeof window !== "undefined" && window.innerWidth < 700) && (
                <th
                  className={`px-6 py-3 border-b border-gray-300 text-left font-semibold table-header sticky top-0 freeze-header`}
                  style={{
                    cursor: "pointer", position: "sticky", left: 0, zIndex: 11, backgroundColor: "#E5E7EB", minWidth: "40px"
                  }}>

                </th>
              )}
              {headers.map(
                (header, index) =>
                  visibleColumns.includes(header) ? (
                    <th
                      key={index}
                      className={`px-6 py-3 border-b border-gray-300 text-left font-semibold table-header sticky top-0 ${sortConfig && sortConfig.key === header? "text-blue-600 active-table-header" : ""
                        } ${freezeColumn(header)?'freeze-header':''}`}
                        onClick={() => {
                          headerMap && (headerMap[header][0] !== 'Change Details' && popupHeading !== "Billing Status Log") &&  handleSort(header);
                      }}
                      style={{
                        cursor: "pointer",
                        ...(freezeColumn(header)
                          ? { position: "sticky", left: (typeof window !== "undefined" && window.innerWidth < 700) ? "40px" : 0, zIndex: 11,cursor: "pointer"} 
                          : {})
                      }}
                    >
                      {headerMap && headerMap[header]
                        ? headerMap[header][0]
                        : formatColumnName(header)}
                        {headerMap && (headerMap[header][0] !== 'Change Details' && popupHeading !== "Billing Status Log") ?
                         (sortConfig && sortConfig.key === header ? (
                          sortConfig.direction === "ascending" ? (
                            <ArrowUpOutlined className="sorting-arrow" style={{ marginLeft: 8, color: "#2563EB" }} />
                          ) : (
                            <ArrowDownOutlined className="sorting-arrow"  style={{ marginLeft: 8, color: "#2563EB" }} />
                          )
                          ) : (
                            <ArrowUpOutlined style={{ marginLeft: 8, opacity: 0.5 }} />
                        )
                        ) : null}

                      {/* Check if the header is 'Select', render the Checkbox */}
                      {header === "Select" && (
                        <Checkbox
                          onChange={handleSelectAllChange}
                          checked={selectAll}
                          indeterminate={
                            selectedRows.length > 0 &&
                            selectedRows.length < paginatedData.length
                          }
                          style={{ fontSize: "1rem", marginLeft: 8 }}
                        />
                      )}
                    </th>
                  ) : null // Ensure non-visible columns return null
              )}
              {/* Render actions column if allowedActions is true */}
              {allowedActions && visibleColumns.length > 0 && (
                <th className="px-6 border-b border-gray-300 text-left font-semibold table-header">
                  {popupHeading === "Automation rule log"
                    ? "Details"
                    : allowedActions.includes("form")
                    ? "Sim Info"
                    : "Actions"}
                </th>
              )}
            </tr>
          </thead>
          <tbody>
            {visibleColumns.length > 0 ? (
              rowData.length > 0 ? (
                rowData?.map((row, index) => (
                  <tr key={index} className={index % 2 === 0 ? "bg-gray-50 even-table-row" : ""}>
                    {/* Render actions column if allowedActions is true */}
                    {/* {visibleColumns.length > 0 && !report.includes(popupHeading) && (
                <td className="px-6 border-b border-gray-300 table-cell">
                {(currentPage - 1) * itemsPerPage + index + 1}
                </td>
                )} */}
                    {(typeof window !== "undefined" && window.innerWidth < 700) && (
                      <td
                        className={`border-b border-gray-300 table-cell ${index % 2 === 0 ? "even-freeze-cell" : "freeze-cell"}`}
                        style={
                          { position: "sticky", left: 0, backgroundColor: "white", zIndex: 5 }
                        }>
                        <Radio
                          checked={true}
                          onClick={() => {
                            setShowRowModal(true);
                            setShowRowModalData(row);
                          }}
                          className="custom-gray-radio"
                        />
                      </td>
                    )}
                    {headers.map((header, columnIndex) =>
                      visibleColumns.includes(header) ? (
                        <td
                          key={columnIndex}
                          className={`border-b border-gray-300 ${popupHeading === "Bulk Change History status log"
                            ? "custom-table-cell"
                            : headerMap?.[header]?.[0] === "Billing Status"
                              ? "table-cell !px-[24px] !py-[3px]"
                              : "table-cell"
                            }  ${freezeColumn(header) ? index % 2 === 0 ? "even-freeze-cell" : "freeze-cell" : ""}`}
                          style={{
                            ...(freezeColumn(header)
                              ? { position: "sticky", left: (typeof window !== "undefined" && window.innerWidth < 700) ? "40px" : 0, zIndex: 5, cursor: "pointer" }
                              : {})
                          }}
                        >
                          {/* Check if the header is the selection column */}
                          {header === "S.no" ? (
                            (currentPage - 1) * itemsPerPage + index + 1
                          ) : header === "Select" ? (
                            <Checkbox
                              onChange={() => handleRowCheckboxChange(index)}
                              checked={selectedRows
                                .map(String)
                                .includes(String(index))}
                              style={{ fontSize: "2rem" }}
                            />
                          ) : (headerMap &&
                            headerMap?.[header]?.[0] === "Module State") ||
                            (headerMap &&
                              headerMap?.[header]?.[0] === "Role Status") ||
                            (headerMap &&
                              headerMap?.[header]?.[0] === "API State") ||
                            headerMap?.[header]?.[0] === "Email Status" ||
                            (popupHeading==="Tenant Banner" && headerMap?.[header]?.[0] === "Status") ||
                            headerMap?.[header]?.[0] === "User Status" ? (
                            renderApiState(
                              row[header],
                              index,
                              headerMap?.[header]?.[0]
                            )
                          ) : headerMap &&
                            (headerMap?.[header]?.[0] === "Timeout Frequency") ? (
                            renderTimeOut(
                              row[header],
                              index,
                              header
                            )
                          ) : headerMap &&
                            (headerMap?.[header]?.[0] === "Actions" && popupHeading === "Private Networks") ? (
                            renderActionButtons(
                              row[header],
                              index,
                              header
                            )
                          )  : headerMap &&
                            (headerMap?.[header]?.[0] === "Status ") || (headerMap?.[header]?.[0] === "Status" && popupHeading === "Partner Creation")? (
                            renderEmailStatus(row[header])
                          ): moduleFeatures.includes("Edit user-Inventory") && (headerMap &&
                            headerMap?.[header]?.[0] === "Username" ||
                            header === "Username") ? (

                            <EditUsernameCellRenderer rowData={row} />
                          ) : headerMap &&
                            headerMap?.[header]?.[0] === "SIM Status" ? (
                            <StatusCellRenderer
                              record={row}
                              value={row[header] || 'None'}
                              index={index}
                              colorMap={colorMap}
                            />
                          ) : moduleFeatures.includes("Action history-Inventory") &&
                            (headerMap?.[header]?.[0] === "Action History" || header === "Action History") ? (
                            <StatusHistoryCellRenderer row={row} />
                          )
                            // : ["Provider", "Service Provider"].includes(
                            //   headerMap?.[header]?.[0]
                            // ) ||
                            //   header === "service_provider" ? (
                            //   <ServiceProviderCellRenderer value={row[header]} index={row.id} />
                            // ) 
                            : header === "Status" ||
                              (headerMap && headerMap?.[header]?.[0] === "Status" && popupHeading !== "Customer Rate Plan" && popupHeading !== "Filtered Customer Rate Plan"&& popupHeading !== "Automation rule log" && popupHeading !== "Private Networks") ? (
                              <StatusIndicator
                                row={row}
                                status={row[header]}
                                heading={popupHeading}
                              />
                            ) : headerMap &&
                              headerMap?.[header]?.[0] === "Progress" && (popupHeading === "Bulk Change" || popupHeading === "Partner Creation")? (
                             <ProgressBar value={row[header]}/>
                            ) : headerMap &&
                              headerMap?.[header]?.[0] === "Uploaded" ? (
                              <QuantityCell
                                value={row[header]}
                                type={STATUS_TYPE.UPLOAD}
                              />
                            ) : headerMap &&
                              headerMap?.[header]?.[0] === "Successful" ? (
                              <QuantityCell
                                value={row[header]}
                                type={STATUS_TYPE.SUCCESSFUL}
                              />
                            ) : headerMap && headerMap?.[header]?.[0] === "Errors" ? (
                              <QuantityCell
                                value={row[header]}
                                type={STATUS_TYPE.ERRORS}
                              />
                            ) : ((moduleFeatures.includes("Info-Bulk change") && popupHeading==="Bulk Change") || ( popupHeading==="Central Bulk Change")) && (headerMap &&
                              headerMap?.[header]?.[0] === "Change Details") ? (
                              <ChangeDetailCellRenderer row={row} />
                            ) : (headerMap &&
                              headerMap?.[header]?.[0] === "Assigned Rate Plans") ||
                              (headerMap &&
                                headerMap?.[header]?.[0] ===
                                "Assigned Rate Plan Count") ? (
                              <RatePlansCountCell value={row[header]} />
                            ) : (headerMap &&
                              headerMap?.[header]?.[0].toLowerCase() === "nsdev") || 
                              (headerMap &&
                              headerMap?.[header]?.[0] === "AT&T Certified") ||
                              (headerMap &&
                                headerMap?.[header]?.[0] === "VoLTE") ? (
                              renderCustomIMEIData(row[header])
                            ) : (headerMap &&
                              (headerMap?.[header]?.[0] === "Feature Codes") || (popupHeading === "User" &&( headerMap?.[header]?.[0] === "Partner" ||  headerMap?.[header]?.[0] === "Role")) || ((popupHeading==="Customer Rate Plan" || popupHeading==="Filtered Customer Rate Plan") &&headerMap?.[header]?.[0] === "Automation Rule" || headerMap?.[header]?.[0] === "Soc Code") || (popupHeading === "Partner Creation" && headerMap?.[header]?.[0] === "Customers")) ? (
                              renderCustomFeatureCodes(row[header])
                            ) : (headerMap && ((popupHeading==="Customer Rate Plan" || popupHeading==="Filtered Customer Rate Plan")&& headerMap?.[header]?.[0] === "Product")) ? (
                              renderCustomProducts(row[header])
                            ) : (headerMap && ((popupHeading==="Customer Rate Plan" || popupHeading==="Filtered Customer Rate Plan") && headerMap?.[header]?.[0] === "Package")) ? (
                              renderCustomPackage(row[header])
                            ) : (headerMap &&
                              headerMap?.[header]?.[0] === "Assigned") ? (
                              renderCarrierAssignedCoumn(row[header])
                            ) :
                              (headerMap &&
                                headerMap?.[header]?.[0] === "Write Enabled") ? (
                                renderWriteEnabled(row[header])
                              ) :
                                (headerMap &&
                                  headerMap?.[header]?.[0] === "Send to Customer") ? (
                                  renderSendToCustomer(row[header])
                                )
                                  :
                                  (headerMap &&
                                    headerMap?.[header]?.[0] === "Send to Carrier") ? (
                                    renderSendToCarrier(row[header])
                                  )
                                    : (headerMap &&
                                      (headerMap?.[header]?.[0] === "Status" || headerMap?.[header]?.[0] === "Allows Sim Pooling" || headerMap?.[header]?.[0] === "Uses Bill In Advance" || headerMap?.[header]?.[0] === "Automation") &&
                                      (popupHeading==="Customer Rate Plan" || popupHeading==="Filtered Customer Rate Plan" || popupHeading === "Private Networks")) ? (
                                      renderRatePlanStatus(row[header],headerMap?.[header]?.[0])
                                    ) : headerMap &&
                                      (headerMap?.[header]?.[0] === "Status" &&
                                        popupHeading === "Automation rule log") ? (
                                      renderAutomationRuleStatus(row[header])
                                      ) : headerMap?.[header]?.[0] === "Billing Status" ? (
                                        <Select
                                          options={billingStatusOptions}
                                          value={billingStatusOptions.find(opt => opt.value === row["billing_platform_status"]) || null}
                                          onChange={(selectedOption) => {
                                          // You can call your change handler here
                                          handleCellChange(index, "billing_platform_status", selectedOption?.value || "");
                                         
                                          }}
                                          
                                          className="w-[250px]"
                                           menuPortalTarget={document.body} 
                                          />
                                      ):headerMap?.[header]?.[0] === "Suspended" ? (
                                        <div className="flex gap-4">
                                          <label className="flex items-center gap-1">
                                            <input
                                              type="checkbox"
                                              checked={row["suspension_status"] === true}
                                              onChange={() => handleCellChange(index, "suspension_status", true)}
                                            />

                                            True
                                          </label>
                                          <label className="flex items-center gap-1">
                                            <input
                                              type="checkbox"
                                              checked={row["suspension_status"] === false}
                                              onChange={() => handleCellChange(index, "suspension_status", false)}
                                            />
                                            False
                                          </label>
                                        </div>
                                      )
                                    : popupHeading === "LNP" && (headerMap?.[header]?.[0] === "E911" || headerMap?.[header]?.[0] === "CNAM") ? (
                                      row[header] ? (
                                        <span className="text-green-500">Yes</span>
                                      ) : (
                                        <span className="text-red-500">Off</span>
                                      )
                                    ) : popupHeading === "LNP" && headerMap?.[header]?.[0] === "Status" ? (
                                      String(row[header]).toLowerCase() === "active" || String(row[header]).toLowerCase() === "inservice" ? (
                                        <span className="text-green-500">{row[header]}</span>
                                      ) : String(row[header]).toLowerCase() === "inactive" ? (
                                        <span className="text-red-500">{row[header]}</span>
                                      ) : (
                                        <span>{row[header]}</span>
                                      )
                                    ) : popupHeading === "Number Orders" && headerMap?.[header]?.[0] === "Status" ? (
                                      String(row[header]).toLowerCase() === "complete" ? (
                                        <span className="text-green-500">{row[header]}</span>
                                      ) : String(row[header]).toLowerCase() === "failed" || String(row[header]).toLowerCase() === "cancelled" ? (
                                        <span className="text-red-500">{row[header]}</span>
                                      ) : String(row[header]).toLowerCase() === "partial" || String(row[header]).toLowerCase() === "processing" ? (
                                        <span className="text-yellow-500">{row[header]}</span>
                                      ) : (
                                        <span>{row[header]}</span>
                                      )
                                    )
                                    :row[header] != "None" ? (
                                      popupHeading === "Bulk Change History status log" ?
                                      (
                                        <span>{row[header]}</span>
                                      ) : (
                                        <Tooltip
                                          title={`${row[header]}`}
                                          placement="topLeft"
                                          overlayStyle={{ whiteSpace: 'normal', maxWidth: '60vw', wordWrap: 'break-word' ,zIndex: 50}}
                                          // getPopupContainer={(triggerNode) => (triggerNode.parentNode as HTMLElement) || document.body} // Fallback to document.body
                                          getPopupContainer={() => document.body} // Render tooltip directly on the body to avoid stacking issues
                                        >
                                          <span>{(currencyHeaders.includes(headerMap[header][0]) && row[header]
                                    ? `$${row[header]}`
                                    : row[header] && popupHeading === "Rev.io Syncs" && row[header] === "None" ? " " : row[header])}</span>

                                        </Tooltip>
                                      )
                                    ) : (
                                      ""
                                    )}
                        </td>
                      ) : null
                    )}

                    {allowedActions && visibleColumns.length > 0 && (
                      <td className="px-6 border-b border-gray-300 table-cell">
                        <div className="flex items-center space-x-2">
                          {allowedActions.includes("edit") && (
                            <>
                              <Tooltip title="Edit">
                                <PencilIcon
                                  className="h-5 w-5 text-blue-500 cursor-pointer"
                                  onClick={() =>
                                    handleActionClick(
                                      "edit",
                                      index
                                    )
                                  }
                                />
                              </Tooltip>

                              {<></>}
                            </>
                          )}
                          {allowedActions.includes("editServiceProvider") && (
                            <Tooltip title="Edit">
                              <PencilIcon
                                className="h-5 w-5 text-blue-500 cursor-pointer"
                                onClick={() =>
                                  handleActionClick(
                                    "editServiceProvider",
                                    index
                                  )
                                }
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("editBanner") && (
                            <Tooltip title="Edit">
                              <PencilIcon
                                className="h-5 w-5 text-blue-500 cursor-pointer"
                                onClick={() =>
                                  handleActionClick(
                                    "editBanner",
                                    index
                                  )
                                }
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("delete") && (
                            <Tooltip title="Delete">
                              <TrashIcon
                                className="h-5 w-5 text-red-500 cursor-pointer"
                                onClick={() =>
                                  handleActionClick(
                                    "delete",
                                    index
                                  )
                                }
                              />
                            </Tooltip>

                          )}
                          {allowedActions.includes("editNotification") && (
                            <Tooltip title="Edit">
                              <PencilIcon
                                className="h-5 w-5 text-blue-500 cursor-pointer"
                                onClick={() =>
                                  handleActionClick(
                                    "editNotification",
                                    index
                                  )
                                }
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("info") && (
                            <Tooltip title="Info">
                              <InformationCircleIcon
                                className="h-5 w-5 text-green-500 cursor-pointer"
                                onClick={() =>
                                  handleActionClick(
                                    "info",
                                    index
                                  )
                                }
                              />
                            </Tooltip>

                          )}

                          {allowedActions.includes("emailAuditing") && (
                            <Tooltip title="Info">
                              <InformationCircleIcon
                                className="h-5 w-5 text-green-500 cursor-pointer"
                                onClick={() =>
                                  handleActionClick(
                                    "emailAuditing",
                                    index
                                  )
                                }
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("editEmail") && (
                            <Tooltip title="Edit">
                              <PencilIcon
                                className="h-5 w-5 text-green-500 cursor-pointer"
                                onClick={() =>
                                  handleActionClick(
                                    "editEmail",
                                    index
                                  )
                                }
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("copy") && (
                            <Tooltip title="Copy">
                              <CopyOutlined
                                className="h-5 w-5 text-blue-500 cursor-pointer"
                                onClick={() =>
                                  handleActionClick(
                                    "copy",
                                    index
                                  )
                                }
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("copyBanner") && (
                            <Tooltip title="Copy">
                              <CopyOutlined
                                className="h-5 w-5 text-blue-500 cursor-pointer"
                                onClick={() =>
                                  handleActionClick(
                                    "copyBanner",
                                    index
                                  )
                                }
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("Actions") && (
                            <ActionItems
                              initialData={initialData}
                              currentPage={currentPage}
                              itemsPerPage={itemsPerPage}
                              index={index}
                              rowData={row}
                              is_2_0_flow = {false}
                            />
                          )}
                          {allowedActions.includes("lnpActions") && onRowAction && (
                            <Dropdown
                              overlay={
                                <Menu onClick={(e) => onRowAction(e.key, row)}>
                                  {popupHeading === "LNP" && (
                                    <>
                                      <Menu.Item key="move">Move Phone Number</Menu.Item>
                                      <Menu.Item key="dlda">DL/DA Order</Menu.Item>
                                      <Menu.Item key="lidb">LIDB Order</Menu.Item>
                                      <Menu.Item key="lineOptions">Line Options</Menu.Item>
                                      <Menu.Item key="sms">SMS Settings</Menu.Item>
                                    </>
                                  )}
                                  {popupHeading === "Number Orders" && (
                                    <>
                                      <Menu.Item key="checkStatus">Check Status</Menu.Item>
                                    </>
                                  )}
                                </Menu>
                              }
                              trigger={["click"]}
                              placement="bottomLeft"
                            >
                              <Tooltip title="Actions">
                                <MoreOutlined rotate={90} className="text-blue-500 cursor-pointer" />
                              </Tooltip>
                            </Dropdown>
                          )}
                          {allowedActions.includes("SingleClick") && (
                            <Tooltip title="Edit">
                              <PencilIcon
                                className="h-5 w-5 text-blue-500 cursor-pointer"
                                onClick={() => handleActionSingleClick()}
                              />
                            </Tooltip>
                          )}

                          {allowedActions.includes("copyFeature") && (
                            <Tooltip title="Copy">
                              <CopyOutlined
                                className="h-5 w-5 text-blue-500 cursor-pointer"
                                onClick={() =>
                                  handleActionClick(
                                    "copyFeature",
                                    index
                                  )
                                }
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("editCustomerModal") && (
                            <Tooltip title="Edit">
                              <PencilIcon
                                className="h-5 w-5 text-blue-500 cursor-pointer"
                                onClick={() =>
                                  handleActionClick(
                                    "editCustomerModal",
                                    index
                                  )
                                }
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("editRev.ioCustomer") && (
                            <Tooltip title="Edit">
                              <PencilIcon
                                className="h-5 w-5 text-blue-500 cursor-pointer"
                                onClick={() =>
                                  handleActionClick(
                                    "editRev.ioCustomer",
                                    index
                                  )
                                }
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("editCustomerRatePlan") && (
                            <Tooltip title="Edit">
                              <PencilIcon
                                className="h-5 w-5 text-blue-500 cursor-pointer"
                                onClick={() =>
                                  handleActionClick(
                                    "editCustomerRatePlan",
                                    index
                                  )
                                }
                              />
                            </Tooltip>
                          )}
                          {
                            allowedActions.includes("copyCustomerRatePlan") && (
                              <Tooltip title="Copy">
                                <CopyOutlined
                                  className="h-5 w-5 text-blue-500 cursor-pointer"
                                  onClick={() =>
                                    handleActionClick(
                                      "copyCustomerRatePlan",
                                      index
                                    )
                                  }
                                />
                              </Tooltip>
                            )
                          }
                          {allowedActions.includes("infoCustomerRatePlan") && (
                            <Tooltip title="info">
                              <InformationCircleIcon
                                className="h-5 w-5 text-green-500 cursor-pointer"
                                onClick={() =>
                                  handleActionClick(
                                    "infoCustomerRatePlan",
                                    index
                                  )
                                }
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("infoRev.ioCustomer") && (
                            <Tooltip title="info">
                              <InformationCircleIcon
                                className="h-5 w-5 text-green-500 cursor-pointer"
                                onClick={() =>
                                  handleActionClick(
                                    "infoRev.ioCustomer",
                                    index
                                  )
                                }
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("infoCustomerModal") && (
                            <Tooltip title="Info">
                              <InformationCircleIcon
                                className="h-5 w-5 text-green-500 cursor-pointer"
                                onClick={() =>
                                  handleActionClick(
                                    "infoCustomerModal",
                                    index
                                  )
                                }
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("tabsInfo") && (
                            <Tooltip title="Info">
                              <InformationCircleIcon
                                className="h-5 w-5 text-green-500 cursor-pointer"
                                onClick={() =>
                                  handleActionClick(
                                    "tabsInfo",
                                    index
                                  )
                                }
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("form") && (
                            <Tooltip title="Info">
                              <ExclamationCircleOutlined
                                className="h-5 w-5 text-blue-500 cursor-pointer"
                                onClick={() =>
                                  handleActionClick(
                                    "form",
                                    index
                                  )
                                }
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("commPlan") && (
                            <Tooltip title="Edit">
                              <PencilIcon
                                className="h-5 w-5 text-blue-500 cursor-pointer"
                                onClick={() =>
                                  handleActionClick(
                                    "commPlan",
                                    index
                                  )
                                }
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("formEditFeatureModal") && (
                            <Tooltip title="Edit">
                              <PencilIcon
                                className="h-5 w-5 text-blue-500 cursor-pointer"
                                onClick={() =>
                                  handleActionClick(
                                    "formEditFeatureModal",
                                    index
                                  )
                                }
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("automationEdit") && (
                            <Tooltip title="Edit">
                              <PencilIcon
                                className="h-5 w-5 text-blue-500 cursor-pointer"
                                onClick={() =>
                                  handleActionClick(
                                    "automationEdit",
                                    index
                                  )
                                }
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("automationInfo") && (
                            <Tooltip title="Info">
                              <InformationCircleIcon
                                className="h-5 w-5 text-blue-500 cursor-pointer"
                                onClick={() =>
                                  handleActionClick(
                                    "automationInfo",
                                    index
                                  )
                                }
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("impersonateUser") && (
                            <Tooltip title="impersonate">
                              <UserIcon
                                className="h-5 w-5 text-black-500 cursor-pointer"
                                onClick={() =>
                                  handleActionClick("impersonateUser", index)
                                }
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("tabsEdit") && (
                            <Tooltip title="Edit">
                              <PencilIcon
                                className="h-5 w-5 text-blue-500 cursor-pointer"
                                onClick={() =>
                                  handleActionClick(
                                    "tabsEdit",
                                    index
                                  )
                                }
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("editPartnerCreation") && (
                            <Tooltip title="Edit">
                              <PencilIcon
                                className="h-5 w-5 text-blue-500 cursor-pointer"
                                onClick={() =>
                                  handleActionClick(
                                    "editPartnerCreation",
                                    index
                                  )
                                }
                              />
                            </Tooltip>
                          )}
                          {allowedActions.includes("resetPassword") && (
                            <Tooltip title="Update Password">
                              <KeyIcon
                              className="h-5 w-5 text-blue-500 cursor-pointer"
                              onClick={() => handleActionClick("resetPassword", index)}
                            />
                            </Tooltip>
                          )}
                        </div>
                      </td>
                    )}
                  </tr>
                ))
              ) : (
                <tr>
                  <td
                    colSpan={
                      headers.filter((header) =>
                        visibleColumns.includes(header)
                      ).length + 1
                    }
                    className="px-6 py-3 border-b border-gray-300 text-center text-gray-500"
                  >
                    No Records Found
                  </td>
                </tr>
              )
            ) : null}
          </tbody>
        </table>
      </div>
      {/* {visibleColumns.length > 0 && popupHeading !== "Roles" && popupHeading !== "Module Access" && (
        <div className="flex justify-center mt-5">
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
            moduleName={popupHeading}
          />
        </div>
      )} */}
      {/* Show pagination at bottom for larger screens */}
      {(!isSmallScreen && visibleColumns.length > 0 && popupHeading !== "Roles" && popupHeading !== "Module Access" && popupHeading !== "Partner Roles" && popupHeading !== "Partner Module Access") && (
                <div className="flex justify-center mt-5">
                    {paginationComponent}
                </div>
            )}

      {editModalOpen && (
        <EditModal
          createModalData={
            createModalData &&
              popupHeading === "Rate Plan Socs" ?
              editRowIndex !== null &&
                // rowData[editRowIndex]?.service_provider?.startsWith("AT&T - Telegence")
                 (getTargetTenantProvider(rowData[editRowIndex]?.service_provider)).toLowerCase()
          .includes("telegence")
                ? createModalData
                : createModalData.filter(
                  (field: any) =>
                    ![
                      "default_optimization_group_id",
                      "optimization_rate_plan_type_id",
                    ].includes(field.db_column_name)
                ).sort((a: any, b: any) =>
                RatePlanSocspreferredOrder.indexOf(a.db_column_name) -
                RatePlanSocspreferredOrder.indexOf(b.db_column_name))
              : createModalData
          }
          isOpen={editModalOpen}
          isEditable={isEditable}
          rowData={editRowIndex !== null ? rowData[editRowIndex] : null}
          onSave={handleSaveModal}
          onClose={handleCloseModal}
          heading={popupHeading}
          isTabEdit={tabsEdit}
          generalFields={generalFields}
          tableData={rowData}
          action="Edit"
        />
      )}
      {copyFeature && (
        <EditModal
          createModalData={createModalData || []}
          isOpen={editModalOpen}
          isEditable={isEditable}
          rowData={editRowIndex !== null ? rowData[editRowIndex] : null}
          onSave={handleSaveModal}
          onClose={handleCloseModal}
          heading={popupHeading}
          isTabEdit={tabsEdit}
          generalFields={generalFields}
          tableData={rowData}
          action="copyFeature"
        />
      )}

      {isCopyEmailModal &&
        (<CreateEmailAuditTemplateModal
          onClose={handleCloseModal}
          visible={true}
          action="copy"
          isOpen={isCopyEmailModal}
        onsave={onsave}
          rowData={isCopyEmailRowIndex !== null ? rowData[isCopyEmailRowIndex] : null}
        />)

      }
      {isEditEmailModal &&
        (<CreateEmailAuditTemplateModal
          onClose={handleCloseModal}
          visible={true}
          action="edit"
          isOpen={isEditEmailModal}
        onsave={onsave}
          rowData={isEditEmailRowIndex !== null ? rowData[isEditEmailRowIndex] : null}
        />)

      }
      {isEditAddServiceProvider &&
        (<EditServiceProvider
          onClose={handleCloseModal}
          visible={true}
          action="editServiceProvider"
          isOpen={isEditAddServiceProvider}
          rowData={serviceProviderRowIndex !== null ? rowData[serviceProviderRowIndex] : null}
        />)

      }
      {isEditBannerOpen &&
        (<EditBanner
          onCancel={handleCloseModal}
          visible={isEditBannerOpen}
          action={bannerAction}
          rowData={editBannerRowIndex !== null ? rowData[editBannerRowIndex] : null}
        />)

      }
      {isEditNotification &&
        (<EditNotificationsModal
          onClose={handleCloseModal}
          visible={true}
          action="editNotification"
          isOpen={isEditNotification}
          rowData={editNotificationRowIndex !== null ? rowData[editNotificationRowIndex] : null}
        />)

      }
      {isEmailAuditInfoModal &&
        (<EditEmailAuditTemplateModal
          onClose={handleCloseModal}
          visible={true}
          isOpen={isEmailAuditInfoModal}
          rowData={isEmailAuditRowIndex !== null ? rowData[isEmailAuditRowIndex] : null}
          createModalData={createModalData}
        />)


      }
      {formModalOpen && (
        <DisplaySimOrder
          isOpen={formModalOpen}
          rowData={formRowIndex !== null ? rowData[formRowIndex] : null}
          onClose={handleCloseModal}
          tableData={rowData}
        />
      )}
      {commPlanModalOpen && (
        <CommPlanModal
          isOpen={commPlanModalOpen}
          rowData={commPlanRowIndex !== null ? rowData[commPlanRowIndex] : null}
          onClose={handleCloseModal}
          tableData={rowData}
          generalFields={generalFields}
          mode="edit"
        />
      )}
      {editFeatureModal && (
        <>
          <EditableFeatureCode
            isOpen={editFeatureModal}
            rowData={
              EditFeatureRowIndex !== null
                ? (rowData[EditFeatureRowIndex] as FeatureCodeRowData)
                : null
            }
            onClose={handleCloseModal}
            generalFields={generalFields}
          />
        </>
      )}
      {editOptimizationModal && (
        <EditCustomerModal
          isOpen={editOptimizationModal}
          rowData={
            EditOptimizationRowIndex !== null
              ? rowData[EditOptimizationRowIndex]
              : null
          }
          onClose={handleCloseModal}
          generalFields={generalFields}
          isEditable={isEditable}
        />
      )}
      {editRevIoCustomerModal && (
        editRevIoCustomerRowIndex !== null
          && rowData[editRevIoCustomerRowIndex] && rowData[editRevIoCustomerRowIndex]?.user_type === "Billing Customer" ? (
          <EditBillingCustomer
            isOpen={editRevIoCustomerModal}
            rowData={
              editRevIoCustomerRowIndex !== null
                ? rowData[editRevIoCustomerRowIndex]
                : null
            }
            onClose={handleCloseModal}
            generalFields={{...generalFields, state:[... generalFields?.state ? Object.keys(generalFields?.state)  || []: []]}}
            isEditable={true}
          />
        ) : (
          <EditRevCustomerModal
            isOpen={editRevIoCustomerModal}
            rowData={
              editRevIoCustomerRowIndex !== null
                ? rowData[editRevIoCustomerRowIndex]
                : null
            }
            onClose={handleCloseModal}
            generalFields={generalFields}
            isEditable={isEditable}
          />
        )

      )}
      {editCustomerRatePlanModal && (
        <EditCustomerRatePlan
          isOpen={editCustomerRatePlanModal}
          onClose={handleCustomerRatePlanClose}
          rowData={
            editCustomerRatePlanRowIndex !== null
              ? rowData[editCustomerRatePlanRowIndex]
              : null
          }
          generalFields={generalFields}
          isEditable={isEditable}
        />
      )}
      {copyCustomerRatePlanModal && (
        <CopyCustomerRatePlan
          isOpen={copyCustomerRatePlanModal}
          onClose={handleCustomerRatePlanClose}
          rowData={
            copyCustomerRatePlanRowIndex !== null
              ? rowData[copyCustomerRatePlanRowIndex]
              : null
          }
          generalFields={generalFields}
          isEditable={isEditable}
        />

      )}
      {infoCustomerRatePlanModal && (
        <InfoCustomerRatePlan
          isOpen={infoCustomerRatePlanModal}
          onClose={handleCloseModal}
          rowData={
            infoCustomerRatePlanRowIndex !== null
              ? rowData[infoCustomerRatePlanRowIndex]
              : null
          }
          generalFields={generalFields}
        />
      )}
      {impersonateUser && (
        <ImpersonateUserModal
          isOpen={impersonateUser}
          rowData={
            impersonateUserRowIndex !== null
              ? rowData[impersonateUserRowIndex]
              : null
          }
          onClose={handleCloseModal}
        />
      )}
      {isInfoRevIoCustomerModal && (
        isInfoRevIoCustomerRowIndex !== null
          && rowData[isInfoRevIoCustomerRowIndex] && rowData[isInfoRevIoCustomerRowIndex]?.user_type === "Billing Customer" ? (
          <EditBillingCustomer
            isOpen={isInfoRevIoCustomerModal}
            rowData={
              isInfoRevIoCustomerRowIndex !== null
                ? rowData[isInfoRevIoCustomerRowIndex]
                : null
            }
            onClose={handleCloseModal}
            generalFields={generalFields}
            isEditable={false}
          />
        ) : (
          <InfoRevIoPopup
          isOpen={isInfoRevIoCustomerModal}
          rowData={
            isInfoRevIoCustomerRowIndex !== null
              ? rowData[isInfoRevIoCustomerRowIndex]
              : null
          }
          onClose={handleCloseModal}
          generalFields={generalFields}
        />
        )

      )}
      {/* {isInfoRevIoCustomerModal && (
        <InfoRevIoPopup
          isOpen={isInfoRevIoCustomerModal}
          rowData={
            isInfoRevIoCustomerRowIndex !== null
              ? rowData[isInfoRevIoCustomerRowIndex]
              : null
          }
          onClose={handleCloseModal}
          generalFields={generalFields}
        />
      )

      } */}

      {isEditAutomationModalOpen && (
        <EditAutomation
          isOpen={isEditAutomationModalOpen}
          onClose={handleCloseModal}
          onSuccess={handleAutomationSuccess}
          row={
            editAutomationRowIndex !== null
              ? rowData[editAutomationRowIndex]
              : null
          }
        />
      )

      }
      {isInfoAutomationModalOpen && (
        <AutomationInfo
          isOpen={isInfoAutomationModalOpen}
          onClose={handleCloseModal}
          row={
            infoAutomationRowIndex !== null
              ? rowData[infoAutomationRowIndex]
              : null
          }
        />
      )

      }
      {openPrivateNetworksInfo && (
        <PrivateNetworksInfo
          isOpen={openPrivateNetworksInfo}
          onClose={handleCloseModal}
          row={
            privateNetworksInfoRowIndex !== null
              ? rowData[privateNetworksInfoRowIndex]
              : null
          }
          generalFields={generalFields}
          actionType={"info"}
        />
      )

      }
      {openPrivateNetworksEditModal &&(
        <PrivateNetworksInfo
          isOpen={openPrivateNetworksEditModal}
          onClose={handleCloseModal}
          generalFields={generalFields}
          actionType={"edit"}
          row = { privateNetworksEditRowIndex !== null ? rowData[privateNetworksEditRowIndex] : null} />

      )}
      {openPrivateNetworksDeleteModal &&(
           <AddPrivateNetworkIP
          open={openPrivateNetworksDeleteModal}
          onClose={handleCloseModal}
          onSubmit={() => handleDelete(privateNetworksDeleteRowIndex !== null ? privateNetworksDeleteRowIndex : 0,true,"Deactive")}
          generalFields={generalFields}
          deleteData={privateNetworkDeleteData}
          actionType={"delete"}
          row = { privateNetworksDeleteRowIndex !== null ? rowData[privateNetworksDeleteRowIndex] : null} />
      )}
      {showRowModal &&
        <RowDetailsModal
          row={showRowModalData}
          headerMap={headerMap}
          onClose={() => {
            setShowRowModal(false)
            setShowRowModalData(null)
          }}
          isOpen={showRowModal}
        />
      }
     <Modal
        title="Update Password"
        open={resetPasswordModal}
        onCancel={handleCancel}
        centered
        footer={null}>
        <div className="flex flex-col gap-y-4 max-w-md">
          <div className="flex flex-col items-end">
           
            <div className="flex items-center">
              <div className="w-1/4 items-end">
                <label
                  htmlFor="new-password"
                  className="whitespace-nowrap text-right font-semibold text-gray-700"
                >
                  New Password
                </label>
              </div>
              <div className="flex-1 ml-4">
                <input
                  type="password"
                  id="new-password"
                  value={newPassword}
                  autoComplete="new-password"
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="input w-full min-w-[320px]"
                />
              </div>
            </div>
          </div>

          <div className="flex flex-col items-start">
           
            <div className="flex items-center">
              <div className="w-1/4 items-end">
                <label
                  htmlFor="confirm-password"
                  className="whitespace-nowrap text-right font-semibold text-gray-700"
                >
                  Confirm Password
                </label>
              </div>
              <div className="flex-1 ml-4">
                <input
                  type="password"
                  id="confirm-password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  autoComplete="new-password"
                  className="input w-full min-w-[320px]"
                />
              </div>
            </div>
             {newPasswordError && (
              <div className="text-red-600 text-sm mb-1">
                {newPasswordError}
              </div>
            )}
             {confirmPasswordError && (
              <div className="text-red-600 text-sm mb-1">
                {confirmPasswordError}
              </div>
            )}
          </div>

          <div className="flex justify-center space-x-2 mt-4">
            <button onClick={handleCancel} className="cancel-btn">
              Cancel
            </button>
            <button onClick={handleResetPassword} className="save-btn">
              Save
            </button>
          </div>
        </div>
      </Modal>
      <Modal
        title={actionType === "Deactive" ? "Confirm Deactivation" :actionType === "Active" ? "Confirm Activation":"Confirm Deletion"}
        open={deleteModalOpen}
        onOk={confirmDelete}
        onCancel={() => setDeleteModalOpen(false)}
        centered
      >
        {popupHeading === "Customer Rate Plan" && deleteRowIndex !== null && rowData[deleteRowIndex]?.is_active === "True" ? (
          <p>Do you want to Delete this Active row</p>
        ) : popupHeading === "Customer Rate Plan" && deleteRowIndex !== null && rowData[deleteRowIndex]?.is_active === "False" ? (
          <p>Do you want to Delete this Inactive row</p>
        ) : popupHeading === "Private Networks" && actionType && privateNetworksDeleteRowIndex !== null && rowData[privateNetworksDeleteRowIndex]?.is_active === false ? (
          <p>Are you sure you want to Activate this row</p>
        ) :  popupHeading === "Private Networks" && actionType && privateNetworksDeleteRowIndex !== null && rowData[privateNetworksDeleteRowIndex]?.is_active === true ? (
          <p>Are you sure you want to Deactivate this row</p>
        ) : (
          <p>Do you want to Delete this row</p>
        )}
      </Modal>
      <Modal
        title={
          <span style={{ fontWeight: "bold", fontSize: "16px" }}>
            Confirm Enable
          </span>
        }
        open={EnableModalOpen}
        onOk={() => confirmSubmit(rowIndex, columnName, true)} // Pass true for enabling
        onCancel={() => setEnableModalOpen(false)}
        centered
      >
        <p>
          Do you want to <strong>{state}</strong> this State
        </p>
      </Modal>
      <Modal
        title={
          <span style={{ fontWeight: "bold", fontSize: "16px" }}>
            Confirm Disable
          </span>
        }
        open={DisableModalOpen}
        onOk={() => confirmSubmit(rowIndex, columnName, false)} // Pass false for disabling
        onCancel={() => setDisableModalOpen(false)}
        centered
      >
        <p>
          Do you want to <strong>{state}</strong> this State
        </p>
      </Modal>
      <Modal
        title={
          <div className="mt-[-9px]">
            <span className="confirm-popup-heading ">Confirm save</span>
          </div>
        }
        visible={isConfirmationVisible}
        onCancel={() => setIsConfirmationVisible(false)}
        styles={{ body: { top: "10px", padding: "4px" } }}
        footer={null}
        closable={true}
        centered
      >
        <div className="text-left">
          <p style={{ fontFamily: "Calibri, sans-serif", fontSize: "15px" }}>
            Are the related settings Activated in your AWS Account from AWS
            Admin
          </p>
          <div className="flex justify-center space-x-2 mt-4">
            <Button
              className="cancel-btn text-base border-none"
              style={{ fontFamily: "Calibri, sans-serif" }}
              onClick={() => setIsConfirmationVisible(false)}
            >
              Cancel
            </Button>
            <Button
              className="save-btn text-base border-none"
              style={{ fontFamily: "Calibri, sans-serif" }}
              onClick={() => handleConfirm(state)}
            >
              Confirm
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};

// export default TableComponent;
