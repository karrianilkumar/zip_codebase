import React from "react";

export enum STATUS_TYPE {
  UPLOAD = "upload",
  SUCCESSFUL = "successful",
  ERRORS = "errors",
}

interface CountCellProps {
  value: any;
}

// --- Unified parsing logic ---
const parseRatePlans = (value: any): string[] => {
  if (!value) return [];

  // Already an array
  if (Array.isArray(value)) {
    return value
      .map((p) => String(p))
      .filter((p) => p && p.toLowerCase() !== "none");
  }

  if (typeof value !== "string") return [];

  const raw = value.trim();
  if (!raw) return [];

  let existingPlans: string[] = [];

  try {
    if (raw.startsWith("[")) {
      try {
        const jsonParsed = JSON.parse(raw);
        if (Array.isArray(jsonParsed)) {
          existingPlans = jsonParsed;
        } else {
          existingPlans = [];
        }
      } catch {
        const inside = raw.substring(1, raw.length - 1);
        existingPlans = inside
          .split(",")
          .map((p) => p.trim())
          .filter(Boolean);
      }
    } else if (raw.startsWith("{") && raw.endsWith("}")) {
      existingPlans = raw
        .replace(/[{}]/g, "")
        .split(",")
        .map((p) => p.trim())
        .filter(Boolean);
    } else {
      existingPlans = raw
        .split(",")
        .map((p: string) => p.trim())
        .filter(Boolean);
    }
  } catch (err) {
    console.error("Failed to parse rate plans:", err);
    return [];
  }

  // Safe cleanup
  return existingPlans.filter((p) => {
    const str = String(p).trim().toLowerCase();
    return str !== "" && str !== "none";
  });
};



const RatePlansCountCell: React.FC<CountCellProps> = ({ value }) => {
  const parsedList = parseRatePlans(value);
  const displayValue = parsedList.length > 0 ? parsedList.length : "";

  return (
    <div>
      <span>{displayValue}</span>
    </div>
  );
};

export default RatePlansCountCell;
