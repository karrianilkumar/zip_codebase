import React, { useState } from "react";
import StatusLog from "@/app/sim_management/bulk_history/status_log";
import BillingStatusLog from "@/app/billing/killbill_components/billing_status_log";
const STATUS = {
  PROCESSED: "PROCESSED",
  ERROR: "ERROR",
  PENDING: "PENDING",
  Pending:"Pending",
  SUCCESSFUL:"Successful",
  SUCCESS:"SUCCESS",
  PROCESSING: "PROCESSING",
  ACTIVE: "Active",
  INACTIVE: "Inactive",
  OPEN:"OPEN",
  FAILED:"Failed",
  Generated:"Generated",
  CLOSE:"CLOSE",
  Returned:"Returned",
  Voided:"Voided"

};

interface StatusIndicatorProps {
  status: (typeof STATUS)[keyof typeof STATUS];
  row: any;
  heading: string;
}

const StatusIndicator: React.FC<StatusIndicatorProps> = ({
  status,
  row,
  heading,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleClick = () => {
    if (heading === "Bulk Change History" || heading === "Upload Status Data") {
      setIsModalOpen(true);
    }
  };

  let colorClass = "";
  switch ((status && typeof(status)==="string" ? status: "")?.toLowerCase()) {
  case "processed":
  case "active":
  case "activated":
  case "successful":
  case "success":
  case "open":
  case "generated":
  case "returned":
  case "voided":
    colorClass = "text-green-500";
    break;

  case "error":
  case "failed":
  case "inactive":
  case "close":
    colorClass = "text-red-500";
    break;

  case "pending":
  case "processing":
    colorClass = "text-yellow-500";
    break;

  default:
    colorClass = "text-gray-500";
}

  return (
    <>
      <div
       onClick={(heading === "Bulk Change History"  || heading === "Upload Status Data" )? handleClick : undefined}
       className={`rounded-md ${colorClass} ${
         heading === "Bulk Change History" || heading === "Upload Status Data"? "cursor-pointer" : ""
       }`}
      >
        {status}
      </div>
      {isModalOpen && (
        heading === "Bulk Change History" ? (
        <StatusLog
          row={row}
          isOpen={isModalOpen}
          onRequestClose={() => setIsModalOpen(false)}
        />
        ) : (
          <BillingStatusLog
            row={row}
            isOpen={isModalOpen}
            onRequestClose={() => setIsModalOpen(false)}
          />
        )
      )}
    </>
  );
};

export default StatusIndicator;
