import { FC, useEffect, useState } from "react";
import { useRouter } from 'next/navigation';
import { Tooltip } from "antd";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { InformationCircleIcon } from "@heroicons/react/24/outline";
import { useAuth } from "../../auth_context";
import { useSearchStore } from "@/app/stores/searchStore";

export const ChangeDetailCell: FC<{
  row?: any;
}> = ({ row }) => {
  const [isMounted, setIsMounted] = useState(false);
  const router = useRouter();
  const { setRowId, setBulkRow, setICCID } = useFeatureStore();
  const { username, partner, role, settabledata, token, selectedDb, firstLastName, sessionId, setAdvancedStoredPagination, setCombineAdnvaceStoredpagination, setStoredPagination } = useAuth();
  const current_bulk_history_active_module = localStorage.getItem("current_bulk_history_active_module");
const { setIsRedirectedFromDetails, detailsRedirectedFilters , detailsRedirectedSearchTerm } = useSearchStore();
  useEffect(() => {
    setIsMounted(true);
  }, []);

  const handleClick = () => {
    if (isMounted) {
      setBulkRow(row)
      localStorage.setItem('bulk_row', JSON.stringify(row || "{}"));
      setICCID("")
      localStorage.removeItem('iccid');
      setAdvancedStoredPagination(null)
      setStoredPagination(null)
      setCombineAdnvaceStoredpagination(null)
      const allEmpty = Object.values(detailsRedirectedFilters).every(
        (value) => Array.isArray(value) && value.length === 0
      );
      const isEmptySearchTerm = detailsRedirectedSearchTerm === ""
      console.log("details ...",detailsRedirectedFilters,detailsRedirectedSearchTerm)
      if (allEmpty && isEmptySearchTerm) {
        setIsRedirectedFromDetails(false)
      }
      else {
        setIsRedirectedFromDetails(true)
      }
      if (row) {
        if (current_bulk_history_active_module === "Bulk Change") {
          router.push(`/sim_management/bulk_history`);

        }
        if (current_bulk_history_active_module === "Central Bulk Change") {
          window.open("/sim_management/bulk_history", "_blank");

        }
      }
    }
  };

  return (
    <div className="flex w-full ml-8">
      <Tooltip title="More information about the bulk change">
        <a onClick={handleClick} className="text-center block cursor-pointer">
          <InformationCircleIcon className="h-5 w-5 text-green-500 cursor-pointer" />
        </a>
      </Tooltip>
    </div>
  );
};

export function ChangeDetailCellRenderer(row: any) {
  return <ChangeDetailCell row={row} />;
}

