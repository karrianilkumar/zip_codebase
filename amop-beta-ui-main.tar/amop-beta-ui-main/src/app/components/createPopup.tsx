import React, { useEffect, useMemo, useState } from 'react';
import { Checkbox, Input, Modal, notification, Popover, Spin, Switch } from 'antd';
import Select from 'react-select';
import { DropdownStyles, NonEditableDropdownStyles } from './css/dropdown';
import axios from 'axios';
import { useAuth } from './auth_context';
import { DatePicker } from 'antd';
import dayjs from 'dayjs';
import { getCurrentDateTime } from './header_constants';
import { usePartnerStore } from '../partner/partner_info/partnerStore';
import { ENV_ROUTES } from './routes/route_constants';
import { InformationCircleIcon } from '@heroicons/react/24/outline';
import useCrossProviderStore from '../stores/useCrossProviderStore';
import { ConfirmationModal } from '@/components/provision-device/confirmation-modal';
import PrivateNetworkTable from './private_network_table';
import { usePrivateNetworkStore } from '../stores/privateNetworksStore';
const { RangePicker } = DatePicker;
import { fireSideCannons } from "@/app/components/confetti";
interface Column {
  display_name: string;
  db_column_name: string;
  type: string;
  default: string;  mandatory: string;
}

interface CreateModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (newData: any, tableData: any) => void;
  columnNames: Column[];
  heading: string;
  generalFields?: Record<string, any>;
  header: any[];
  tableData?: any
}

const CreateModal: React.FC<CreateModalProps> = ({
  isOpen,
  onClose,
  onSave,
  columnNames: originalCreateModalData = [],
  heading,
  generalFields,
  header,
  tableData = []

}) => {
  const { crossProviderCustomerOptimizationStore } = useCrossProviderStore();
  const { editedTableData } = usePrivateNetworkStore();
  const [validationErrors, setValidationErrors] = useState<{ [key: string]: string }>({});
  const [formData, setFormData] = useState<any>({});
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);
  const editableDrp = DropdownStyles;
  const { username, tenantNames, role, partner, tenantId, settabledata, setStoredPagination, token, selectedDb,selectedBillingDb,metaData, firstLastName,sessionId,isSubTenant} = useAuth();
  const [loading, setLoading] = useState(false);
  const { partnerData, setCustomerGroups } = usePartnerStore.getState();
  const [optimizationType, setOptimizationType] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string[]>([]);
  const [isCrossProvider, setIsCrossProvider] = useState<boolean>(false);
  const [isOptimizatioPerRevIODates, setIsOptimizatioPerRevIODates] = useState<boolean>(false);
  const [customerGroupsDropdownData, setCustomerGroupsDropdownData] = useState<any>({});
  const [enablePrivateNetwork, setEnablePrivateNetwork] = useState(false);
  const [serviceProviderOptions, setServiceProviderOptions] = useState<any[]>([])

  const isAdmin = role?.toLowerCase() === "super admin" || role?.toLowerCase() === "partner admin"

  const columnNames = useMemo(() => {
  let filteredData = [...originalCreateModalData];

  if (heading === "Customers" && isSubTenant) {
    filteredData = filteredData.filter(item => item.db_column_name !== "sub_tenant_name");
  }

  if (heading === "Customer Group") {
    filteredData = filteredData.filter(item => item.db_column_name !== "tenant_name");

    if (!isAdmin) {
      filteredData = filteredData.filter(
        item => item.db_column_name !== "billing_account_number" && item.db_column_name !== "sub_tanant"
      );
    }
  }

  return filteredData;
}, [heading, isSubTenant, isAdmin, originalCreateModalData]);

  
  const callCustomersLambdaSync = async () => {
    const url = ENV_ROUTES.OPTIMIZATION_SYNC_LAMBDA;
    const data = {
      path: "/lambda_sync_jobs_",
      key_name: "customers_sub_tenant_insert",
      tenant_name:partner
    };

    try {
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
    } catch (error) {
    }

  }
  const fetchData = async () => {
      setLoading(true);
      try {
        const url = ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/get_cross_carrier_optimization",
          role_name: role,
          parent_module: "Sim Management",
          module_name: "Customer Rate Pool",
          feature_module_name:"Customer Rate Pools",
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
        };
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
  
        if (parsedData.flag === false) {
          Modal.error({
            title: 'Data Fetch Error',
            content: parsedData.message || 'An error occurred while fetching data. Please try again.',
            centered: true,
          });
        } else {
          const crossProvider_ = parsedData?.cross_carrier_optimization || false
          setIsCrossProvider(crossProvider_)

          const isOptimizatioPerRevIODates_ = parsedData?.optimization_per_revio_dates || false
          setIsOptimizatioPerRevIODates(isOptimizatioPerRevIODates_)
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        Modal.error({
          title: 'Data Fetch Error',
          content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
          centered: true,
        });
      } finally {
        setLoading(false);
  
      }
    };

    const fetchCustomerGroupsData = async (option:any) => {
      setLoading(true);
      try {
        const url = ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: partner || "Altaworx",
          username: username,
          firstLastName: firstLastName,
          path: "/get_submit_customer_group_dropdown_details",
          role_name: role,
          parent_module: "Partner",
          modules_list: ["Customer groups"],
          feature_module_name: "Partner Info",
          request_received_at: getCurrentDateTime(),
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
          sub_tenant_name:option
        };
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
  
        if (parsedData.flag === false) {
          Modal.error({
            title: 'Data Fetch Error',
            content: parsedData.message || 'An error occurred while fetching data. Please try again.',
            centered: true,
          });
        } else {
          const sub_tanant_=parsedData?.data?.tenant_details?.sub_tenants || []
          const feature_codes_=parsedData?.data?.feature_codes || []
          const customer_names_=parsedData?.data?.customer_names || []
          const billing_account_number_=parsedData?.data?.billing_account_number || []
          const rate_plan_name_=parsedData?.data?.rate_plan_name || []
          const notification_rules_=parsedData?.data?.notification_rules || []
          const comm_plans_=parsedData?.data?.comm_plans || []
          const dropdown_data={
            sub_tanant:sub_tanant_.map((option: string) => ({
              label: option,
              value: option,
            })),
            feature_codes:feature_codes_.map((option: string) => ({
              label: option,
              value: option,
            })),
            customer_names:customer_names_.map((option: string) => ({
              label: option,
              value: option,
            })),
            billing_account_number:billing_account_number_.map((option: string) => ({
              label: option,
              value: option,
            })),
            rate_plan_name:rate_plan_name_.map((option: string) => ({
              label: option,
              value: option,
            })),
            notification_rules:notification_rules_.map((option: string) => ({
              label: option,
              value: option,
            })),
            comm_plans:comm_plans_.map((option: string) => ({
              label: option,
              value: option,
            })),
          }

          setCustomerGroupsDropdownData(dropdown_data)
          const service_providers=parsedData?.data?.service_providers || []
          setServiceProviderOptions(service_providers)
          setFormData((prev: any) => ({
            ...prev,
            rate_plan_name:"",
            customer_names:[],
            billing_account_number:"",
            feature_codes:"",
            notification_rules:"",
            comm_plans:""
          }));
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        Modal.error({
          title: 'Data Fetch Error',
          content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
          centered: true,
        });
      } finally {
        setLoading(false);
  
      }
    };
  const handleOptimizationTypeChange = (selectedOption: any) => {
    const value = selectedOption ? (Array.isArray(selectedOption) ? selectedOption.map((option) => option.value) : selectedOption.value) : '';
    setOptimizationType(value);
    handleChange('optimization_type', value);
  };
  function isLeapYear(year: number): boolean {
    return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
  }

  const handleChange = (name: string, value: any) => {
    if(heading === "Customer Group" && name === "enable_private_networks")
    {
      setEnablePrivateNetwork(value)
      console.log("value",value)
    }
    if (heading === "Customer Group" && name === "sub_tanant") {
      const value_ = value ? value : partner || ""
      fetchCustomerGroupsData(value_)
    }
    setFormData((prevState: any) => {
      const updatedFormData = {
        ...prevState,
        [name]: value,
      };

      return updatedFormData;
    });
    // Clone the current validationErrors state
    let errors = { ...validationErrors };

    // Specific validation for 'postal_code'
    if (name === 'postal_code') {
      const regex = /^\d{5}$/; // Regex for exactly 5 digits
      if (!regex.test(value)) {
        errors[name] = 'Postal code must be exactly 5 digits';
      } else {
        delete errors[name]; // Remove error if validation passes
      }
    }
     if (name === "telephone_number") {
      const mobileRegex = /^\d{10}$/;
      if (value && !mobileRegex.test(value)) {
        errors[name] = "Mobile number must be 10 digits.";
      } else {
        delete errors[name];
      }
    }
    // Validation for 'customer_bill_period_end_hour'
    if (name === 'customer_bill_period_end_hour') {
      const hour = Number(value);
      if (isNaN(hour) || hour < 0 || hour > 23) {
        errors[name] = 'Customer bill period end hour must be between 0 and 23';
      } else {
        delete errors[name];
      }
    }
    if(name === "email_address" || name === "email_alias" || name === "billing_email"){
      console.log("value",value)
      
      const validateEmail = (email: string) => {
        const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        return emailRegex.test(email);
    };
    if (!validateEmail(value)) {
      errors[name] = "Invalid email address"
      console.log("Invalid email address");
      // You can show an error message or handle the invalid case
      // return;
  }
  else{
    delete errors[name];
  }
    }

    // Validation for 'customer_bill_period_end_date'
    if (name === 'customer_bill_period_end_date') {
      const date = Number(value);
      if (isNaN(date) || date < 1 || date > 28) {
        errors[name] = 'Customer bill period end date must be between 1 and 28';
      } else {
        delete errors[name];
      }
    }
    if (name === 'customer_bill_period_end_day') {
      const date = Number(value);
      if (isNaN(date) || date < 1 || date > 28) {
        errors[name] = 'Customer bill period end day must be between 1 and 28';
      } else {
        delete errors[name];
      }
    }
    if(heading==="Rate Plan Socs"){
        if (
          name === "overage_rate_cost" || 
          name === "data_per_overage_charge" || 
          name === "plan_mb" ) {
            console.log("field",name)
            const regex = /^\$?\d*(\.\d*)?$/; // Only allow digits and '$'
            const value_ = value ? value.toString().replace('$', '') : '0'; // Ensure value is a string
            console.log("value",value_)
            if ((value !== null && 
              value !== undefined && 
              value !== "" &&
              value !== "None") && value !== "None" && !regex.test(value)) {
              errors[name] = "Only numbers are allowed.";
            } 
            else{
              delete errors[name];
            }
        }
    }


    setValidationErrors(errors);

  };

  const handleCreate = () => {
    // if (Object.keys(validationErrors).length > 0) {
    //   // Display an error message or handle the validation error in some way
    //   const errorMessage: string[] = Object.entries(validationErrors).map(([name, message]) => (
    //     name + ': ' + message
    //   ));
    //   setErrorMessage(errorMessage);
    //   return; // Exit the function if there are validation errors
    // }
    onSave(formData, tableData);
    onClose();
  };
// Expand compressed IPv6 like "2001:db8::1" -> ["2001","0DB8","0000","0000","0000","0000","0000","0001"]
const expandIPv6 = (input: string): string[] | null => {
    const raw = input.trim();
    if (!raw) return null;
    
    if (raw.indexOf("::") !== -1) {
        const [left, right] = raw.split("::");
        const leftParts = left ? left.split(":").filter(Boolean) : [];
        const rightParts = right ? right.split(":").filter(Boolean) : [];
        if (leftParts.some(p => p.length > 4) || rightParts.some(p => p.length > 4)) return null;
        const missing = 8 - (leftParts.length + rightParts.length);
        if (missing < 0) return null;
        const mid = new Array(missing).fill("0");
        const parts = [...leftParts, ...mid, ...rightParts].map(p => p || "0");
        if (parts.length !== 8) return null;
        return parts.map(p => p.padStart(4, "0").toUpperCase());
    } else {
        const parts = raw.split(":");
        if (parts.length !== 8) return null;
        if (parts.some(p => p.length === 0 || p.length > 4)) return null;
        return parts.map(p => p.padStart(4, "0").toUpperCase());
    }
};

// Parse IPv4 numeric dotted -> parts
const ipv4ToParts = (ip: string): number[] => ip.split(".").map(p => {
    const n = Number(p);
    if (Number.isNaN(n)) return 0;
    return Math.max(0, Math.min(255, Math.trunc(n)));
}).slice(0, 4).concat([0, 0, 0, 0]).slice(0, 4);

interface ParseResult {
    valid: boolean;
    family?: "ipv4" | "ipv6";
    startParts: number[];
    endParts: number[];
}

const parseIpOrRange = (value?: string): ParseResult => {
    const ipv4Regex = /^(\d{1,3}\.){3}\d{1,3}$/;
    const ipv6SingleRegex = /^([0-9A-Fa-f:]+)$/;
    const rangeRegexIPv4 = /^(\d{1,3}\.){3}\d{1,3}\s*-\s*(\d{1,3}\.){3}\d{1,3}$/;
    const rangeRegexIPv6 = /^([0-9A-Fa-f:]+)\s*-\s*([0-9A-Fa-f:]+)$/;

    const raw = String(value ?? "").trim();
    if (!raw) return { valid: false, startParts: [0, 0, 0, 0], endParts: [0, 0, 0, 0] };

    // IPv4 single
    if (ipv4Regex.test(raw)) {
        const p = ipv4ToParts(raw) as number[];
        return { valid: true, family: "ipv4", startParts: p, endParts: p.slice() };
    }

    // IPv4 range
    if (rangeRegexIPv4.test(raw)) {
        const [s, e] = raw.split("-").map(s => s.trim());
        const sp = ipv4ToParts(s);
        const ep = ipv4ToParts(e);

        const lexCompare = (a: number[], b: number[]) => {
            for (let i = 0; i < 4; i++) {
                if (a[i] < b[i]) return -1;
                if (a[i] > b[i]) return 1;
            }
            return 0;
        };

        if (lexCompare(sp, ep) <= 0) return { valid: true, family: "ipv4", startParts: sp, endParts: ep };
        return { valid: true, family: "ipv4", startParts: ep, endParts: sp };
    }

    // IPv6 single or range
    if (ipv6SingleRegex.test(raw)) {
        if (!raw.includes("-")) {
            const expanded = expandIPv6(raw);
            if (!expanded) return { valid: false, startParts: [0, 0, 0, 0], endParts: [0, 0, 0, 0] };
            const parts = expanded.map(h => parseInt(h, 16));
            return { valid: true, family: "ipv6", startParts: parts, endParts: parts.slice() };
        }
    }

    // IPv6 range (a-b)
    const m6 = raw.match(rangeRegexIPv6);
    if (m6) {
        const sRaw = m6[1].trim();
        const eRaw = m6[2].trim();
        const sExp = expandIPv6(sRaw);
        const eExp = expandIPv6(eRaw);
        if (!sExp || !eExp) return { valid: false, startParts: [0, 0, 0, 0], endParts: [0, 0, 0, 0] };
        const sp = sExp.map(h => parseInt(h, 16));
        const ep = eExp.map(h => parseInt(h, 16));
        const lexCompare = (a: number[], b: number[]) => {
            for (let i = 0; i < 8; i++) {
                if (a[i] < b[i]) return -1;
                if (a[i] > b[i]) return 1;
            }
            return 0;
        };
        if (lexCompare(sp, ep) <= 0) return { valid: true, family: "ipv6", startParts: sp, endParts: ep };
        return { valid: true, family: "ipv6", startParts: ep, endParts: sp };
    }

    return { valid: false, startParts: [0, 0, 0, 0], endParts: [0, 0, 0, 0] };
};

// Check if two IP ranges overlap
const checkIpRangeOverlap = (
    start1: number[],
    end1: number[],
    start2: number[],
    end2: number[]
): boolean => {
    const compareIp = (a: number[], b: number[]): number => {
        for (let i = 0; i < a.length; i++) {
            if (a[i] < b[i]) return -1;
            if (a[i] > b[i]) return 1;
        }
        return 0;
    };

    const start1VsEnd2 = compareIp(start1, end2);
    const start2VsEnd1 = compareIp(start2, end1);

    return start1VsEnd2 <= 0 && start2VsEnd1 <= 0;
};

// Then your existing handleIpRangeChange and renderCell functions can use these
  const showConfirmation = () => {
    

     // private network rows required for Customer Group
if (enablePrivateNetwork && heading === "Customer Group") {
    const hasIncompleteRow = editedTableData.some((row: any) =>
        Object.keys(row).some((key) => {
            const value = row[key];
            return value === "" || value === null || value === undefined;
        })
    );

    if (hasIncompleteRow || editedTableData.length === 0) {
        Modal.info({
            title: "Incomplete Private Networks",
            content: "Please fill all the fields in private network rows before creating.",
            centered: true,
        });
        return;
    }

    // Check for overlapping IP ranges within the same service provider
    const hasOverlappingRanges = editedTableData.some((row: any, index: number) => {
        const serviceProvider = row.service_provider;
        const ipRange = row.ip_text;
        
        if (!serviceProvider || !ipRange) return false;

        const parsed1 = parseIpOrRange(ipRange);
        if (!parsed1.valid || !parsed1.family) return false;

        // Check against all other rows with the same service provider
        return editedTableData.some((otherRow: any, otherIndex: number) => {
            if (index === otherIndex) return false; // Skip self
            if (otherRow.service_provider !== serviceProvider) return false; // Different provider

            const otherIpRange = otherRow.ip_text;
            if (!otherIpRange) return false;

            const parsed2 = parseIpOrRange(otherIpRange);
            if (!parsed2.valid || !parsed2.family) return false;
            if (parsed1.family !== parsed2.family) return false; // Different IP versions

            // Check if ranges overlap
            return checkIpRangeOverlap(
                parsed1.startParts,
                parsed1.endParts,
                parsed2.startParts,
                parsed2.endParts
            );
        });
    });

    if (hasOverlappingRanges) {
        Modal.error({
            title: "Overlapping IP Ranges",
            content: "Multiple rows with the same Service Provider have overlapping IP ranges. Please ensure IP ranges don't overlap within the same provider.",
            centered: true,
        });
        return;
    }
}

    const errors: { [key: string]: string } = {};

    columnNames.forEach((column) => {
      if (column.db_column_name === 'optimization_type' && !formData['optimization_type']) {
        errors[column.db_column_name] = `${column.display_name} is required.`;
      }
      if (column.mandatory) {
        const value = formData[column.db_column_name];

        if (
          (Array.isArray(value) && value.length === 0) ||
          (!Array.isArray(value) && !value)              
        ) {
           if (column.db_column_name === "parent_accounts" && heading === "Customer" && formData.account_type !== "Child") {
              return;
            }
          errors[column.db_column_name] = `${column.display_name} is required.`;
        }
        // errors[column.db_column_name] = `${column.display_name} is required.`;
      }

     
    });

    if (formData['customer_bill_period_end_hour']) {
      const hour = Number(formData['customer_bill_period_end_hour']);
      if (isNaN(hour) || hour < 0 || hour > 23) {
        errors['customer_bill_period_end_hour'] = 'Customer bill period end hour must be between 0 and 23';
      }
    }
    if (formData['customer_bill_period_end_date']) {
      const date = Number(formData['customer_bill_period_end_date']);
      if (isNaN(date) || date < 1 || date > 28) {
        errors['customer_bill_period_end_date'] = 'Customer bill period end date must be between 1 and 28';
      }
    }
    if (formData['customer_bill_period_end_day']) {
      const date = Number(formData['customer_bill_period_end_day']);
      if (isNaN(date) || date < 1 || date > 28) {
        errors['customer_bill_period_end_day'] = 'Customer bill period end day must be between 1 and 28';
      }
    }
    if (formData['postal_code']) {
      const zipCode = formData['postal_code'];
      const regex = /^\d{5}$/; // Only 5 numerical values

      if (!regex.test(zipCode)) {
        errors['postal_code'] = 'Postal code must be exactly 5 digits';
      }
    }

    if (formData['telephone_number']) {
      const mobileRegex = /^\d{10}$/;
      if (formData['telephone_number'] && !mobileRegex.test(formData['telephone_number'])) {
        errors['telephone_number'] = "Mobile number must be 10 digits.";
      }
    }
    if (heading === 'Customer' && formData['customer_name']) {
        const nameRegex = /^[A-Za-z\s]+$/;
        if (!nameRegex.test(formData['customer_name'])) {
          errors['customer_name'] = 'Only alphabets are allowed';
        }
      }
    if (formData["billing_email"]) {

      const validateEmail = (email: string) => {
        const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        return emailRegex.test(email);
      };
      if (!validateEmail(formData["billing_email"])) {
        errors['billing_email'] = "Invalid email address"
      }
      else {
        delete errors['billing_email'];
      }
    }
       if(heading==="Rate Plan Socs"){
      Object.keys(formData).forEach((field) => {
        if (
          field === "overage_rate_cost" || 
          field === "data_per_overage_charge" || 
          field === "plan_mb" ) {
            console.log("field",field)
            const regex = /^\$?\d*(\.\d*)?$/; // Only allow digits and '$'
            const value = formData[field] ? formData[field].toString().replace('$', '') : '0'; // Ensure value is a string
            console.log("value",value)
            if ((formData[field] !== null && 
                 formData[field] !== undefined && 
                formData[field] !== "" &&
                formData[field] !== "None") && formData[field] !== "None" && !regex.test(value)) {
                errors[field] = "Only numbers are allowed.";
              } 
            }
  
      });
    }
    if (Object.keys(errors).length > 0) {
      setValidationErrors(errors);
      setIsConfirmationOpen(false); // Don't show confirmation popup if there are errors
    } else {
      setValidationErrors({});
      setIsConfirmationOpen(true); // Only open the confirmation popup if there are no errors
    }
    if (formData['postal_code'] && formData['postal_code'].length > 5) {
      setIsConfirmationOpen(false); // Don't show confirmation popup if zip code is more than 5 digits
    }
  };

  const handleCancelConfirmation = () => {
    setIsConfirmationOpen(false);
  };

  const callCustomerRatePoolsSync = async () =>{
      try {
        const url = ENV_ROUTES.OPTIMIZATION_SYNC_LAMBDA;
        const data = {
          key_name:"customer_rate_pool_sync",
          path:"/lambda_sync_jobs_",
          tenant_name:partner || "default_value",
        };
  
        const response = await axios.post(url, { data });
        const responseData = JSON.parse(response.data.body);
  
        if (responseData.flag === false) {
          console.error("Data Fetch Error: " + responseData.message);
        } else {
          console.log("Success: Inventory lambda sync successful.");
        }
      } catch (error) {
        console.error("Error fetching data:", error);
      }
  
    }
     const callLambdaSync = async () => {
          const url = ENV_ROUTES.OPTIMIZATION_SYNC_LAMBDA;
          const data = {
            path: "/lambda_sync_jobs_",
            key_name: "carrier_rate_plans_sync",
            tenant_name:partner
            };
          try {
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
          } catch (error) {
          }     
        }

  const  handleConfirmCreate = async () => {
    setIsConfirmationOpen(false);
    // const initialFormData_ = header.reduce((acc, column) => {
    //   acc[column] = formData[column] ? formData[column] : 'None';
    //   return acc;
    // }, {} as Record<string, any>);
    // setFormData(initialFormData_);
    if (formData) {
      setLoading(true)
      try {
        let url = ENV_ROUTES.MODULE_MANAGEMENT;
        let url2 = ENV_ROUTES.BP_CUSTOMER_PROFILES;
        let data;
        if (heading === 'Customer Group') {
          if (formData) {
            const tenant_id_map=generalFields?.tenant_id_map || {}
            const selected_parent_tenant=formData["tenant_name"] || ""
            const selected_sub_tenant=formData["sub_tanant"] || ""
            const selected_tenant=selected_sub_tenant && selected_sub_tenant!==""?selected_sub_tenant:selected_parent_tenant  || partner
            const tenant_id_=tenant_id_map[selected_tenant] || 1

            const defaultBAN=customerGroupsDropdownData && customerGroupsDropdownData["billing_account_number"] && customerGroupsDropdownData?.["billing_account_number"].length>0?customerGroupsDropdownData?.["billing_account_number"][0]?.value:customerGroupsDropdownData["billing_account_number_"] || ""
            const billing_account_number_=!isAdmin ? defaultBAN : formData["billing_account_number"] || ""

            formData["tenant_id"] = tenant_id_;
            formData["tenant_name"]=selected_tenant
            formData["parent_tenant_name"]=formData["parent_tenant_name"] || partner
            if(!isSubTenant && (selected_tenant===partner)){
              formData["parent_tenant_name"] = ""
            }
            formData["billing_account_number"]=billing_account_number_

            delete formData["sub_tanant"];
            delete formData["id"];
            // delete formData["customergroup_id"];
            delete formData["id_10"];
            delete formData["subtenant_id"];
            delete formData["subtenant_name"];
            delete formData["sub_tenant_name"];

            formData['created_by'] = firstLastName;
            formData['modified_by'] = firstLastName;
            formData["modified_date"] = getCurrentDateTime();
            formData["created_date"] = getCurrentDateTime();
            formData["is_deleted"] = false
            formData["is_active"] = true
            formData["private_networks_json"]=[...editedTableData]

            // delete formData["tenant_id"]
          }
          data = {
            tenant_name: partner || 'default_value',
            username: username,
            firstLastName: firstLastName,
            path: '/update_partner_info',
            role_name: role,
            module_name: 'Customer groups',
            action: 'create',
            changed_data: formData,
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,

          };
        }
        if (heading === "Customers") {
          url=ENV_ROUTES.PEOPLE_MODULE
          if (formData) {
            const parent_tenant_id_map=generalFields?.tenant_name || {}
            const sub_tenant_id_map=generalFields?.sub_tenant || {}
            const parent_tenant=Object.keys(generalFields?.tenant_name || {})[0] || partner

            const selected_tenant=formData["sub_tenant_name"] && formData["sub_tenant_name"]!==""?formData["sub_tenant_name"]:parent_tenant  || partner

            const tenant_id_=selected_tenant!==parent_tenant?sub_tenant_id_map[selected_tenant]:parent_tenant_id_map[selected_tenant] || 1
            formData["tenant_id"] =isSubTenant && partner?sub_tenant_id_map[partner]: tenant_id_;

            formData["tenant_name"]=isSubTenant?partner:selected_tenant

            delete formData["sub_tenant_name"];
            
            if(!isOptimizatioPerRevIODates){
              formData['amop_customer_bill_period_end_day'] = formData['customer_bill_period_end_day'] || ""
              formData['amop_customer_bill_period_end_hour'] = formData['customer_bill_period_end_hour'] || ""
              delete formData['customer_bill_period_end_day']
              delete formData['customer_bill_period_end_hour']
            }

            formData['created_by'] = firstLastName;
            formData['modified_by'] = firstLastName;
            formData["modified_date"] = getCurrentDateTime();
            formData["created_date"] = getCurrentDateTime();
            formData["is_deleted"] = false
            formData["is_active"] = true
          }
          data = {
            tenant_name: partner || 'default_value',
            username: username,
            firstLastName: firstLastName,
            path: '/create_customer',
            role_name: role,
            module_name: 'Customers',
            new_data: formData,
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }
        if (heading === 'Carrier') {
          if (formData) {
            // formData['created_by'] = firstLastName;
            formData["modified_date"] = getCurrentDateTime()
            formData["api_state"]="true"
            formData["env"]="uat"
            formData["partner"]=formData["Partner"]
            if (formData["Partner"]) {
              formData["partner"] = formData["Partner"];
              delete formData["Partner"]; // Remove the capital 'Partner' key
            }
          }
          data = {
            flag:"create",
            tenant_name: partner || 'default_value',
            username: username,
            firstLastName: firstLastName,
            path: '/update_superadmin_data',
            role_name: role,
            sub_module: 'Partner API',
            sub_tab: 'Carrier APIs',
            table_name: 'carrier_apis',
            changed_data: formData,
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,

          };
        }

        if (heading === 'API') {
          if (formData) {
            formData['created_by'] = firstLastName;
            formData["modified_date"] = getCurrentDateTime()
          }
          data = {
            tenant_name: partner || 'default_value',
            username: username,
            firstLastName: firstLastName,
            path: '/create_superadmin_data',
            role_name: role,
            sub_module: 'Partner API',
            sub_tab: 'Amop APIs',
            table_name: 'amop_apis',
            changed_data: formData,
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }

        if (heading === 'E911 Customer') {
          url = ENV_ROUTES.PEOPLE_MODULE
          if (formData) {
            formData["is_deleted"] = false
            formData["is_active"] = true
            formData['created_by'] = firstLastName;
            formData["modified_date"] = ""
            formData["modified_by"] = firstLastName;
          }
          data = {
            tenant_name: partner || 'default_value',
            username: username,
            firstLastName: firstLastName,
            path: '/update_people_data',
            role_name: role,
            parent_module: 'People',
            module: 'E911 Customers',
            table_name: 'e911_customers',
            action: 'create',
            changed_data: formData,
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,

          };
        }
        if (heading === 'NetSapien Customer') {
          url = ENV_ROUTES.PEOPLE_MODULE
          if (formData) {
            formData["is_deleted"] = false
            formData["is_active"] = true
            // formData["is_system_default"] = true;
            formData['created_by'] = firstLastName;
            formData["modified_date"] = ""
            formData["modified_by"] = firstLastName;
          }
          data = {
            tenant_name: partner || 'default_value',
            username: username,
            firstLastName: firstLastName,
            path: '/update_people_data',
            role_name: role,
            parent_module: 'People',
            module: 'NetSapiens Customers',
            table_name: 'customers',
            action: 'create',
            changed_data: formData,
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }
        if (heading === 'Bandwidth Customer') {
          url = ENV_ROUTES.PEOPLE_MODULE
          if (formData) {
            formData["is_deleted"] = false
            formData["is_active"] = true
            // formData["is_system_default"] = true;
            formData['created_by'] = firstLastName;
            formData["modified_date"] = getCurrentDateTime()
            formData["modified_by"] = firstLastName;
          }
          data = {
            tenant_name: partner || 'default_value',
            username: username,
            firstLastName: firstLastName,
            path: '/update_people_data',
            role_name: role,
            parent_module: 'People',
            module: 'Bandwidth Customers',
            table_name: 'customers',
            changed_data: formData,
            action: 'create',
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,     
          };
        }
        if (heading === 'Customer Rate Plan') {
          url = ENV_ROUTES.SIM_MANAGEMENT
          if (formData) {
            formData["created_by"] = firstLastName;
            formData['modified_by'] = firstLastName;
            formData['is_deleted'] = "False"
            formData['is_active'] = formData['is_active'] ? "True" : "False"
            formData['created_date'] = getCurrentDateTime()
            delete formData['id'];
            delete formData['service_provider'];
            delete formData['deleted_date'];
            delete formData['modified_date']
          }
          data = {
            tenant_name: partner || 'default_value',
            username: username,
            firstLastName: firstLastName,
            path: '/update_sim_management_modules_data',
            role_name: role,
            "parent_module": "Sim Management",
            "module": "Customer Rate Plan",
            action: 'create',
            table_name: 'customerrateplan',
            new_data: formData,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }
        if (heading === 'Customer Rate Pool') {
          const tenant_id_ = localStorage.getItem("tenant_id") || "0";
          const provider_id_map=generalFields?.service_provider_dict || {}
          console.log("provider_id_map",provider_id_map)
          const provider=formData['service_provider_name'] || ""
          console.log("provider",provider)

          
          let provider_ids=[];
          let provider_id_;
          if(isCrossProvider){
             provider_ids = provider.map((name:any) => provider_id_map[name]);
          console.log("provider_ids",provider_ids)

          }
          else{
            provider_id_=provider_id_map[provider] || "0"
            console.log("provider_id_",provider_id_)

          }


          url = ENV_ROUTES.SIM_MANAGEMENT
          if (formData) {
            formData["created_by"] = firstLastName;
            formData['modified_by'] = firstLastName;
            formData['is_deleted'] = "False"
            formData['is_active'] = "True"
            formData['created_date'] = getCurrentDateTime()
            delete formData['id'];
            delete formData['service_provider'];
            delete formData['deleted_date'];
            delete formData['modified_date']
          }
          data = {
            tenant_name: partner || 'default_value',
            username: username,
            firstLastName: firstLastName,
            path: '/update_sim_management_modules_data',
            role_name: role,
            "parent_module": "Sim Management",
            "module": "Customer Rate Pool",
            action: 'create',
            table_name: 'customer_rate_pool',
            new_data: { 
              ...formData, 
              tenant_id: typeof tenantId === "string" ? Number(tenantId) : tenantId || Number(tenant_id_) ,
              ...!isCrossProvider && {service_provider_id: typeof provider_id_ === "string"? Number(provider_id_) : provider_id_ },
              ...isCrossProvider && {service_provider_ids:provider_ids} ,
            },
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }
        if (heading === 'Rate Plan Type') {
          url = ENV_ROUTES.SIM_MANAGEMENT
          if (formData) {
            formData["created_by"] = firstLastName
            formData['modified_by'] = firstLastName;
            formData['is_deleted'] = "False"
            formData['is_active'] = "True"
            formData['created_date'] = getCurrentDateTime()
            delete formData['id'];
            delete formData['service_provider'];
            delete formData['deleted_date'];
            delete formData['modified_date']
          }
          data = {
            tenant_name: partner || 'default_value',
            username: username,
            firstLastName: firstLastName,
            path: '/update_sim_management_modules_data',
            role_name: role,
            "parent_module": "Sim Management",
            "module": "Create Rate Plan Type",
            action: 'create',
            table_name: 'optimization_rate_plan_type',
            new_data: formData,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }
        if (heading === 'Rate Plan Socs') {
          url = ENV_ROUTES.SIM_MANAGEMENT
           if (formData) {
            console.log(formData, "Show form data");
            formData["modified_by"] = firstLastName;
            formData['is_deleted'] = "False"
            formData['is_active'] = "True"
            formData["created_by"] = firstLastName || username
            delete formData["assigned"];
          }
          data = {
            tenant_name: partner || 'default_value',
            username: username,
            firstLastName: firstLastName,
            path: '/update_sim_management_modules_data',
            role_name: role,
            "parent_module": "Sim Management",
            "module": "Rate Plan Socs",
            action: 'create',
            table_name: 'carrier_rate_plan',
            new_data: formData,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }
        if (heading === 'Customer') {
          const tenant_id_ = localStorage.getItem("tenant_id") || "0";

          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/add_customer_profile",
            role_name: role,
            module_name: "Billing Customer Profiles",
            feature_module_name: "Billing Platform",
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            billing_db_name: selectedBillingDb,
            table_name: "customer_profiles",
            request_received_at: getCurrentDateTime(),
            sessionID: sessionId,
            tenant_id: tenant_id_,
            action: "create",
            modified_by: firstLastName,
            changed_data: { ...formData },
            user_type: "Billing Platform Customer"

          };
        }
        
        // if (heading === 'Rev.io customers') {
        //   if (formData) {
        //     formData["is_deleted"] = false
        //     formData["is_active"] = true
        //     formData['created_by'] = username;
        //     formData["modified_date"] = getCurrentDateTime()
        //   }
        //   data = {
        //     tenant_name: partner || "default_value",
        //       username: username,
        //       path: "/people_revio_customers_list_view",
        //       role_name: role,
        //       parent_module: "People",
        //       module_name: "Rev.IO customer",
        //       request_received_at: getCurrentDateTime(),
        //     new_data: formData,
        //     action: 'create',
        //     Partner: partner,
        //     access_token: token,
        //     db_name: selectedDb,
                // ...metaData,

        //   };
        // }
        const response = await axios.post(heading === 'Customer' ? url2 : url, { data });
        if (response.data.statusCode === 200) {
          handleCreate();
          setIsConfirmationOpen(false);
          notification.success({
            message: "Success",
            description: "Successfully saved the record!",
            style: messageStyle,
            placement: "top",
          });
          fireSideCannons()
          if (heading === "Carrier") {
            if (formData) {
              formData["last_modified_by"] = firstLastName;
            }
            url=ENV_ROUTES.TENANT_ONBOARDING;
            data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/update_superadmin_data",
              role_name: role,
              "sub_module": "Partner API",
              "sub_tab": "Carrier APIs",
              "table_name": "carrier_apis",
              "changed_data": formData,
              Partner: partner,
              request_received_at: getCurrentDateTime(),
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,


            };
          }

          if (heading === "API") {
            if (formData) {
              formData["last_modified_by"] = firstLastName;
            }
            url=ENV_ROUTES.TENANT_ONBOARDING;
            data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/update_superadmin_data",
              role_name: role,
              "sub_module": "Partner API",
              "sub_tab": "Amop APIs",
              "table_name": "amop_apis",
              "changed_data": formData,
              Partner: partner,
              request_received_at: getCurrentDateTime(),
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,


            };
          }

          if (heading === "E911 Customer") {
            const url = ENV_ROUTES.PEOPLE_MODULE;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/people_list_view",
              role_name: role,
              parent_module: "people",
              module_name: "E911 Customers",
              feature_module_name: "E911 Customers",
              mod_pages: {
                start: 0,
                end: 100,
              },
              Partner: partner,
              request_received_at: getCurrentDateTime(),
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,


            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: 'Data Fetch Error',
                content: parsedData.message || 'An error occurred while fetching E911 Customers data. Please try again.',
                centered: true,
              });
              setLoading(false)
            } else {
              const headerMap = parsedData.headers_map["E911 Customers"]["header_map"];
              const createModalData = parsedData.headers_map["E911 Customers"]["pop_up"];
              const customertableData = parsedData.data;
              settabledata(customertableData);
              setLoading(false)

            }
          }
          if (heading === "NetSapien Customer") {
            const url = ENV_ROUTES.PEOPLE_MODULE;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/people_list_view",
              role_name: role,
              parent_module: "people", // Corrected spelling from 'poeple'
              module_name: "NetSapiens Customers",
              feature_module_name: "NetSapiens Customers",
              mod_pages: {
                start: 0,
                end: 100,
              },
              Partner: partner,
              request_received_at: getCurrentDateTime(),
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,


            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: 'Data Fetch Error',
                content: parsedData.message || 'An error occurred while fetching Customers data. Please try again.',
                centered: true,
              });
              setLoading(false)
            } else {
              const tableData = parsedData.data;
              const headerMap = parsedData.headers_map["NetSapiens Customers"]["header_map"]
              const createModalData = parsedData.headers_map["NetSapiens Customers"]["pop_up"]
              const generalFields = parsedData.data
              settabledata(tableData);
              setLoading(false)
            }


          }
          if (heading === "Bandwidth Customer") {
            const url = ENV_ROUTES.PEOPLE_MODULE;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/people_list_view",
              role_name: role,
              parent_module: "people",
              module_name: "Bandwidth Customers",
              feature_module_name: "Bandwidth Customers",
              mod_pages: {
                start: 0,
                end: 100,
              },
              Partner: partner,
              request_received_at: getCurrentDateTime(),
              access_token: token,
              db_name: selectedDb,
                ...metaData,

              sessionID: sessionId,

            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              setLoading(false)
              Modal.error({
                title: 'Data Fetch Error',
                content: parsedData.message || 'An error occurred while fetching Customers data. Please try again.',
                centered: true,
              });
            } else {
              const tableData = parsedData.data;
              const headerMap = parsedData.headers_map["Bandwidth Customers"]["header_map"]
              const createModalData = parsedData.headers_map["Bandwidth Customers"]["pop_up"]
              const generalFields = parsedData.data
              settabledata(tableData);
              setLoading(false)
            }
          }
          // if (heading === "Rev.io customers") {
          //   const url = ENV_ROUTES.MODULE_MANAGEMENT;
          //   const data = {
          //     tenant_name: partner || "default_value",
          //     username: username,
          //     path: "/people_revio_customers_list_view",
          //     role_name: role,
          //     parent_module: "People",
          //     module_name: "Rev.IO customer",
          //     mod_pages: {
          //       start: 0,
          //       end: 100,
          //     },
          //     request_received_at: getCurrentDateTime(),
          //     Partner: partner,
          //     access_token: token,
          //     db_name: selectedDb,
                // ...metaData,
          //   };
          //   const response = await axios.post(url, { data });
          //   const parsedData = JSON.parse(response.data.body);
          //   if (parsedData.flag === false) {
          //     setLoading(false)
          //     Modal.error({
          //       title: 'Data Fetch Error',
          //       content: parsedData.message || 'An error occurred while fetching E911 Customers data. Please try again.',
          //       centered: true,
          //     });
          //   } else {
          //     const tableData = parsedData.data;
          //     const headerMap = parsedData.headers_map["people_rev_io_customers"]["header_map"]
          //     const createModalData = parsedData.headers_map["people_rev_io_customers"]["pop_up"]
          //     const generalFields = parsedData.data
          //     settabledata(tableData);
          //     setLoading(false)
          //   }
          // }
          if (heading === "Customer Group") {
            // callCoustomerGroupsSyncLambda()
            const url = ENV_ROUTES.MODULE_MANAGEMENT;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/get_partner_info",
              role_name: role,
              parent_module: "Partner",
              modules_list: ["Customer groups"],
              feature_module_name: "Partner Info",
              pages: {
                "Customer groups": { start: 0, end: 100 },
                "Partner users": { start: 0, end: 100 }
              },
              offset:0,
              Partner: partner,
              request_received_at: getCurrentDateTime(),
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,

            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              setLoading(false)
              Modal.error({
                title: 'Data Fetch Error',
                content: parsedData.message || 'An error occurred while fetching Customers data. Please try again.',
                centered: true,
              });
            } else {
              const tableData = parsedData?.data?.["Customer groups"]?.customergroups || [];
              setCustomerGroups(parsedData)
              console.log("tableData", tableData)
              settabledata(tableData);
              setLoading(false)
            }
          }
          if (heading === "Customers") {
            const url = ENV_ROUTES.PEOPLE_MODULE;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/get_customers_list_view_data",
              role_name: role,
              parent_module: "People",
              module_name: "Customers",
              feature_module_name: "Customers",
              mod_pages: {
                start: 0,
                end: 100,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,
            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              setLoading(false)
              Modal.error({
                title: 'Data Fetch Error',
                content: parsedData.message || 'An error occurred while fetching Customers data. Please try again.',
                centered: true,
              });
            } else {
              const tableData = parsedData?.data || [];
              console.log("tableData", tableData)
              settabledata(tableData);
              setLoading(false)
              onClose();
              await callCustomersLambdaSync()
            }
          }
          if (heading === "Customer Rate Plan") {
            const url = ENV_ROUTES.MODULE_MANAGEMENT;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/get_module_data",
              role_name: role,
              parent_module: "Sim Management",
              module_name: "Customer Rate Plan",
              feature_module_name: "Customer Rate Plans",
              mod_pages: {
                start: 0,
                end: 100,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,
            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              setLoading(false)
              Modal.error({
                title: 'Data Fetch Error',
                content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                centered: true,
              });
            } else {
              const tableData = parsedData?.data?.customerrateplan || []
              settabledata(tableData);
              setLoading(false)
            }
          }

          if (heading === "Customer Rate Pool") {
            callCustomerRatePoolsSync()
            const url = ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/get_customer_rate_pool_list_view_data",
              role_name: role,
              parent_module: "Sim Management",
              module_name: "Customer Rate Pool",
              feature_module_name: "Customer Rate Pools",
              mod_pages: {
                start: 0,
                end: 100,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,
            };
            const response = await axios.post(url, { data });
            console.log(crossProviderCustomerOptimizationStore,"Show the cross provider") // Access the Zustand store
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              setLoading(false)
              Modal.error({
                title: 'Data Fetch Error',
                content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                centered: true,
              });
            } else {
              const tableData = parsedData?.data?.customer_rate_pool || []
              settabledata(tableData);
              setLoading(false)
            }
          }
          if (heading === "Rate Plan Socs") {
            const url = ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/carrier_rate_plan_list_view",
              role_name: role,
              parent_module: "Sim Management",
              module_name: "Rate Plan Socs",
              feature_module_name: "Rate Plans/SOCs",
              mod_pages: {
                start: 0,
                end: 100,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const tableData = parsedData?.data?.carrier_rate_plan || [];
              //  console.log("tableData", tableData)
              settabledata(tableData);
            }
            callLambdaSync()
          }
          if (heading === "Rate Plan Type") {
            const url = ENV_ROUTES.MODULE_MANAGEMENT;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/get_module_data",
              role_name: role,
              parent_module: "Sim Management",
              module_name: "Create Rate Plan Type",
              feature_module_name: "Rate Plans/SOCs",
              mod_pages: {
                start: 0,
                end: 100,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,
            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              setLoading(false)
              Modal.error({
                title: 'Data Fetch Error',
                content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                centered: true,
              });
            } else {
              const tableData = parsedData?.data?.optimization_rate_plan_type || []
              settabledata(tableData);
              setLoading(false)
            }
          }
          if (heading === 'Customer') {
            const url = ENV_ROUTES.PEOPLE_MODULE;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/get_billing_platform_customer_list_view_data",
              role_name: role,
              parent_module: "People",
              module_name: "Billing Customers",
              feature_module_name: "Billing Customers",
              mod_pages: {
                start: 0,
                end: 100,
              },
              // dropdown_options: { label: filterOptions.find(option => option.value === selectedOption)?.label || "All", value: selectedOption },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
              billing_db_name:selectedBillingDb,
                ...metaData,
              sessionID: sessionId,
            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              setLoading(false)
              Modal.error({
                title: 'Data Fetch Error',
                content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                centered: true,
              });
            } else {
              const tableData = parsedData?.data|| []
              settabledata(tableData);
              setLoading(false)
            }
          }
        }
        else {
          const errorMsg = JSON.parse(response.data.body).message
          Modal.error({
            title: 'Saving Error',
            content: errorMsg,
            centered: true,
          });
          setLoading(false)

        }
        


      } catch (err) {
        console.error('Error fetching data:', err);
        notification.error({
          message: 'Error',
          description: 'Failed to create the record. Please try again.',
          style: messageStyle,
          placement: 'top',// Apply custom styles here
        });
        setLoading(false)

      }
      finally{
        setLoading(false)
      }
    }
    
  };
  useEffect(() => {
    setEnablePrivateNetwork(false)
    const initialFormData = header?.reduce((acc, column) => {
      acc[column] = ''; // Initialize each header item as an empty string
      return acc;
    }, {} as Record<string, any>);

    setFormData(initialFormData);
    setValidationErrors({});
    if (isOpen && (heading === "Customer Rate Pool" || heading === "Customers")) {
      fetchData()
    }
    if (isOpen && heading === "Customer Group") {
      fetchCustomerGroupsData(partner)
      if (isSubTenant) {
        setFormData((prevState: any) => {
          const updatedFormData = {
            ...prevState,
            sub_tanant: partner,
          }
          return updatedFormData;
        })
      }
    }
    if(heading==="Customers"){
      const parent_tenant=Object.keys(generalFields?.tenant_name || {})[0] || partner
      setFormData((prevState: any) => {
        const updatedFormData = {
          ...prevState,
          tenant_name:parent_tenant ,
        }
        return updatedFormData;
    })
  }
  }, [columnNames, isOpen]);


  const messageStyle = {
    fontSize: '14px',
    fontWeight: 'bold',
    padding: '16px',
  };
  const lowerCaseFirstLetter = (text: string) => {
    // if (!text) return '';
    // return text.charAt(0).toLowerCase() + text.slice(1);
    if (!text) return '';
    return text
      .split(' ') // Split the sentence into an array of words
      .map((word: string) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()) // Capitalize each word
      .join(' '); 
  };

 const multiplyFactor= (typeof window !== "undefined" && window.innerWidth < 700) ? 3.5 :2.5
  const modalHeight =
    typeof window !== "undefined" ? (window.innerHeight * 2.5) / 4 : 0;
    const modalWidth =
    typeof window !== "undefined" ? (window.innerWidth * multiplyFactor) / 4 : 0;

    const childrenContent = !loading ? (
          <div className={`${columnNames.length > 5 ? "popup" : ""}`}>
            <div
              className={`grid gap-4 ${
                columnNames.length > 5 ? "grid-cols-1 sm:grid-cols-2" : "grid-cols-1"
              }`}
            >
              {columnNames.some((column) => column.db_column_name === "optimization_type") ? (
                columnNames.map((column) => (
                  <div key={column.db_column_name} className="flex flex-col mb-2">
                    {column.db_column_name === "optimization_type" && (
                      <>
                        <label className="field-label text-sm sm:text-base">
                          {column.display_name}
                          <span className="text-red-500">*</span>
                        </label>
                        <div className="flex items-center gap-3">
                          <Select
                            className="w-full"
                            styles={DropdownStyles}
                            placeholder="Select Optimization Type"
                            value={
                              formData["optimization_type"]
                                ? {
                                    label: [formData["optimization_type"]],
                                    value: [formData["optimization_type"]],
                                  }
                                : []
                            }
                            onChange={(value:any) => handleChange("optimization_type", value?.value)}
                            options={[
                              { label: "Auto Change Rate Plan", value: "Auto Change Rate Plan" },
                              { label: "Cross Customer Pooling", value: "Cross Customer Pooling" },
                            ]}
                          />
                          <Popover
                            content={
                              <img
                                src="/images/rate-plan-info.png"
                                alt="Rate Plan Info"
                                style={{ width: "100%", maxWidth: "400px" }} // Responsive image
                              />
                            }
                            trigger="hover"
                            placement="right"
                          >
                            <InformationCircleIcon className="w-6 h-6 sm:w-7 sm:h-7 text-blue-600 cursor-pointer" />
                          </Popover>
                        </div>
                        {validationErrors["optimization_type"] && (
                          <span className="text-red-500 text-xs sm:text-sm mt-1">
                            {validationErrors[column.db_column_name]}
                          </span>
                        )}
                      </>
                    )}
  
                    {formData["optimization_type"] && column.db_column_name !== "optimization_type" && (
                      <>
                        {column.type !== "checkbox" && (
                          <label className="field-label text-sm sm:text-base">
                            {column.display_name}{" "}
                            {column.mandatory && column.mandatory !== null && (
                              <span className="text-red-500">*</span>
                            )}
                          </label>
                        )}
  
                        {column.type === "text" && (
                          <>
                            <Input
                              type="text"
                              value={formData[column.db_column_name] || ""}
                              onChange={(e) => handleChange(column.db_column_name, e.target.value)}
                              className="input w-full"
                              placeholder={`Enter ${lowerCaseFirstLetter(column.display_name)}`}
                            />
                            {validationErrors[column.db_column_name] && (
                              <span className="text-red-500 text-xs sm:text-sm">
                                {validationErrors[column.db_column_name]}
                              </span>
                            )}
                          </>
                        )}
                        {column.type === "date" && (
                          <>
                            <DatePicker
                              value={
                                formData[column.db_column_name]
                                  ? dayjs(formData[column.db_column_name])
                                  : null
                              }
                              onChange={(date, dateString) =>
                                handleChange(column.db_column_name, dateString)
                              }
                              className="input w-full"
                              disabledDate={(current) => {
                                if (!current) return false;
                                if (column.db_column_name === "inactivity_start" && current < dayjs().startOf("day")) {
                                  return true;
                                }
                                if (column.db_column_name === "billing_cycle_range" && current.date() >= 29) {
                                  return true;
                                }
                                return false; // Otherwise, all dates are enabled
                              }}

                            />
                            {validationErrors[column.db_column_name] && (
                              <span className="text-red-500 text-xs sm:text-sm">
                                {validationErrors[column.db_column_name]}
                              </span>
                            )}
                          </>
                        )}
                        {column.type === "checkbox" && (
                          <>
                            <Checkbox
                              checked={formData[column.db_column_name] || false}
                              onChange={(e) =>
                                handleChange(column.db_column_name, e.target.checked)
                              }
                              className="checkbox"
                            >
                              {column.display_name}
                            </Checkbox>
                            {validationErrors[column.db_column_name] && (
                              <span className="text-red-500 text-xs sm:text-sm">
                                {validationErrors[column.db_column_name]}
                              </span>
                            )}
                          </>
                        )}
                        {column.type === "dropdown" && (
                          <>
                            <Select
                              isClearable={heading === "Customer Group" && column.db_column_name === "sub_tanant"}
                              isMulti={
                                column.db_column_name === "customer_names" ||
                                column.db_column_name === "rate_plan_name" ||
                                column.db_column_name === "role_based" ||
                                (heading === "Customer Group" && (column.db_column_name === "feature_codes" || column.db_column_name === "comm_plans")) ||
                                (heading === "Customer Group" && column.db_column_name === "notification_rules")
                              }
                              className="w-full"
                              styles={heading === "Customer Group" && column.db_column_name === "sub_tanant" && isSubTenant ? NonEditableDropdownStyles : DropdownStyles}
                              isDisabled = {heading === "Customer Group" && column.db_column_name === "sub_tanant" && isSubTenant}
                              placeholder="Select..."
                              value={
                                formData[column.db_column_name]
                                  ? Array.isArray(formData[column.db_column_name])
                                    ? formData[column.db_column_name].map((item: string) => ({
                                        label: item,
                                        value: item,
                                      }))
                                    : { label: formData[column.db_column_name], value: formData[column.db_column_name] }
                                  : []
                              }
                              onChange={(value) => {
                                if (Array.isArray(value)) {
                                  handleChange(
                                    column.db_column_name,
                                    value.map((v) => v.value)
                                  );
                                } else {
                                  handleChange(column.db_column_name, value.value);
                                }
                              }}
                              options={
                                heading === "Customer Group"
                                  ? customerGroupsDropdownData[column.db_column_name]
                                  : column.db_column_name !== null &&
                                    generalFields &&
                                    generalFields[column.db_column_name] &&
                                    Array.isArray(generalFields[column.db_column_name])
                                  ? generalFields[column.db_column_name].map((option:string) => ({
                                      label: option,
                                      value: option,
                                    }))
                                  : []
                              }
                            />
                            {validationErrors[column.db_column_name] && (
                              <span className="text-red-500 text-xs sm:text-sm mt-1">
                                {validationErrors[column.db_column_name]}
                              </span>
                            )}
                          </>
                        )}
                        {column.type === "boolean" && (
                          <>
                            <div className="flex items-center">
                              <span className="mr-2 w-12 text-sm sm:text-base">
                                {formData[column.db_column_name] ? "Active" : "Inactive"}
                              </span>
                              <Switch
                                onChange={() =>
                                  handleChange(column.db_column_name, !formData[column.db_column_name])
                                }
                                checked={formData[column.db_column_name]}
                                className="custom-switch"
                              />
                            </div>
                            {validationErrors[column.db_column_name] && (
                              <span className="text-red-500 text-xs sm:text-sm">
                                {validationErrors[column.db_column_name]}
                              </span>
                            )}
                          </>
                        )}
                        {column.type === "textarea" && (
                          <>
                            <textarea
                              value={formData[column.db_column_name] || ""}
                              onChange={(e) => handleChange(column.db_column_name, e.target.value)}
                              className="input min-h-[80px] mt-1 w-full"
                            />
                            {validationErrors[column.db_column_name] && (
                              <span className="text-red-500 text-xs sm:text-sm">
                                {validationErrors[column.db_column_name]}
                              </span>
                            )}
                          </>
                        )}
                      </>
                    )}
                  </div>
                ))
              ) : (
                columnNames.map((column) => (
                  <div key={column.db_column_name} className="flex flex-col mb-4">
                    {column.type !== "checkbox" && (
                      <label className="field-label text-sm sm:text-base">
                        {(heading === "Customers" && !isOptimizatioPerRevIODates && (column.db_column_name==="customer_bill_period_end_hour" || column.db_column_name==="customer_bill_period_end_day"))?`AMOP ${column.display_name}`: column.display_name}{" "}
                        {column.mandatory && column.mandatory !== null && (
                          <span className="text-red-500">*</span>
                        )}
                      </label>
                    )}
                    {column.type === "text" && (
                      <>
                        <Input
                          type="text"
                          value={
                            heading === "Customer Group" && column.db_column_name === "tenant_name"
                              ? formData["parent_tenant_name"] || partner || formData[column.db_column_name]
                              : heading === "Customers" && column.db_column_name === "tenant_name"
                              ? isSubTenant
                                ? partner
                                : Object.keys(generalFields?.tenant_name || {})[0] ||
                                  formData[column.db_column_name]
                              : formData[column.db_column_name] || ""
                          }
                          onChange={(e) => handleChange(column.db_column_name, e.target.value)}
                          className="input w-full"
                          placeholder={`Enter ${lowerCaseFirstLetter(column.display_name)}`}
                          disabled={
                            (heading === "Customer Group" || heading === "Customers") &&
                            column.db_column_name === "tenant_name"
                          }
                        />
                        {validationErrors[column.db_column_name] && (
                          <span className="text-red-500 text-xs sm:text-sm">
                            {validationErrors[column.db_column_name]}
                          </span>
                        )}
                      </>
                    )}
                    {column.type === "date" && (
                      <>
                        <DatePicker
                          value={
                            formData[column.db_column_name]
                              ? dayjs(formData[column.db_column_name])
                              : null
                          }
                          onChange={(date, dateString) =>
                            handleChange(column.db_column_name, dateString)
                          }
                          className="input w-full"
                          disabledDate={(current) =>
                            (column.db_column_name === "inactivity_start" &&
                              current &&
                              current < dayjs().startOf("day")) ||
                            (column.db_column_name === "inactivity_end" &&
                              current &&
                              current < dayjs().startOf("day"))
                          }
                        />
                        {validationErrors[column.db_column_name] && (
                          <span className="text-red-500 text-xs sm:text-sm">
                            {validationErrors[column.db_column_name]}
                          </span>
                        )}
                      </>
                    )}
                    {column.type === "checkbox" && (
                      <>
                        <Checkbox
                          checked={formData[column.db_column_name] || false}
                          onChange={(e) =>
                            handleChange(column.db_column_name, e.target.checked)
                          }
                          className="checkbox"
                        >
                          {column.display_name}
                        </Checkbox>
                        {validationErrors[column.db_column_name] && (
                          <span className="text-red-500 text-xs sm:text-sm">
                            {validationErrors[column.db_column_name]}
                          </span>
                        )}
                      </>
                    )}
                    {column.type === "dropdown" && (
                      <>
                      {heading === "Customer Group" && column.db_column_name === "billing_account_number" && !isAdmin ?
                      
                    (
                      <Input
                        type="text"
                        value={customerGroupsDropdownData && customerGroupsDropdownData[column.db_column_name] && customerGroupsDropdownData?.[column.db_column_name].length>0?customerGroupsDropdownData?.[column.db_column_name][0]?.value:customerGroupsDropdownData[column.db_column_name] || ""}
                        // onChange={(e) => handleChange(column.db_column_name, e.target.value)}
                        className="non-editable-input w-full"
                        placeholder={`Enter ${lowerCaseFirstLetter(column.display_name)}`}
                        disabled
                      />
                    ):(
                      <>
                      <Select
                          isClearable={heading === "Customer Group" && column.db_column_name === "sub_tanant"}
                          isMulti={
                            column.db_column_name === "customer_names" ||
                            column.db_column_name === "rate_plan_name" ||
                            column.db_column_name === "role_based" ||
                            (heading === "Customer Rate Pool" &&
                              column.db_column_name === "service_provider_name" &&
                              isCrossProvider) ||
                            (heading === "Customer Group" && (column.db_column_name === "feature_codes" || column.db_column_name === "comm_plans")) ||
                            (heading === "Customer Group" && column.db_column_name === "notification_rules")
                          }
                          className="w-full"
                          styles={((column.db_column_name === "parent_accounts" && formData.account_type !== "Child") || (heading === "Customer Group" && column.db_column_name === "sub_tanant" && isSubTenant)) ? NonEditableDropdownStyles:DropdownStyles}
                          placeholder="Select..."
                          value={
                            formData[column.db_column_name]
                              ? Array.isArray(formData[column.db_column_name])
                                ? formData[column.db_column_name].map((item:string) => ({
                                    label: item,
                                    value: item,
                                  }))
                                : { label: formData[column.db_column_name], value: formData[column.db_column_name] }
                              : []
                          }
                          onChange={(value) => {
                            if (Array.isArray(value)) {
                              handleChange(
                                column.db_column_name,
                                value.map((v) => v.value)
                              );
                            } else {
                              handleChange(column.db_column_name, value?.value || value);
                            }
                          }}
                          options={
                            heading === "Customer Group"
                              ? customerGroupsDropdownData[column.db_column_name] || []
                              : heading === "Customers" && column.db_column_name === "sub_tenant_name"
                              ? Object.keys(generalFields?.sub_tenant || {}).map((option:string) => ({
                                  label: option,
                                  value: option,
                                })) || []
                              : column.db_column_name !== null &&
                                generalFields &&
                                generalFields[column.db_column_name] &&
                                Array.isArray(generalFields[column.db_column_name])
                              ? generalFields[column.db_column_name].map((option:string) => ({
                                  label: option,
                                  value: option,
                                }))
                              : []
                          }
                          isDisabled={(column.db_column_name === "parent_accounts" && formData.account_type !== "Child") || (heading === "Customer Group" && column.db_column_name === "sub_tanant" && isSubTenant) }
                        />
                        {validationErrors[column.db_column_name] && (
                          <span className="text-red-500 text-xs sm:text-sm mt-1">
                            {validationErrors[column.db_column_name]}
                          </span>
                        )}
                      </>
                    )}
                        
                      </>
                    )}
                    {column.type === "boolean" && (
                      <>
                        <div className="flex items-center">
                          <span className="mr-2 w-12 text-sm sm:text-base">
                            {formData[column.db_column_name] ? "Active" : "Inactive"}
                          </span>
                          <Switch
                            onChange={() =>
                              handleChange(column.db_column_name, !formData[column.db_column_name])
                            }
                            checked={formData[column.db_column_name]}
                            className="custom-switch"
                          />
                        </div>
                        {validationErrors[column.db_column_name] && (
                          <span className="text-red-500 text-xs sm:text-sm">
                            {validationErrors[column.db_column_name]}
                          </span>
                        )}
                      </>
                    )}
                    {column.type === "textarea" && (
                      <>
                        <textarea
                          value={formData[column.db_column_name] || ""}
                          onChange={(e) => handleChange(column.db_column_name, e.target.value)}
                          className="input min-h-[80px] mt-1 w-full"
                        />
                        {validationErrors[column.db_column_name] && (
                          <span className="text-red-500 text-xs sm:text-sm">
                            {validationErrors[column.db_column_name]}
                          </span>
                        )}
                      </>
                    )}
                    {column.type === "date_range" && (
                        <>
                          <RangePicker
                            style={{ marginLeft: "2px", marginRight: "5px", height: "43px" }}
                            name={column.db_column_name}
                            className="w-full"
                            getPopupContainer={(trigger) => trigger.parentElement!}
                            value={formData[column.db_column_name] || null}
                            onChange={(dates) =>
                              handleChange(column.db_column_name, dates)
                            }
                          />
                          {validationErrors[column.db_column_name] && (
                            <span className="text-red-500">
                              {validationErrors[column.db_column_name]}
                            </span>
                          )}
                        </>
                      )}
                  </div>
                ))
              )}
            </div>

            {/* Private Network List View */}
            {(heading === "Customer Group" && enablePrivateNetwork) && (
              <>
                <div style={{ marginBottom: "1rem" }}>
                  <div className="tabs-sub-headings w-full">
                      <h3>Private Networks</h3>
                  </div>
                  <PrivateNetworkTable
                    subTenant = {formData["sub_tanant"] || ""}
                    initialData={[]}
                    itemsPerPage={10}
                    popupHeading="Billing Customers"
                    pagination={{ start: 0, end: 0, total: 0 }}
                    serviceProviderOptions={serviceProviderOptions}
                    isEditable={false}
                    onFetch = {() => fetchCustomerGroupsData(partner)}
                  />
                </div>
              </>
            )}
                                    
          </div>
        ) : (
          <div
            className="flex justify-center items-center"
            style={{
              maxWidth: columnNames.length > 5 ? modalWidth : "100%", // Full width on small screens
              height: columnNames.length > 5 ? modalHeight : "auto",
              margin: "0 auto",
            }}
          >
            <Spin size="large" />
          </div>
        )
 return (
    <div>
      {heading === "Customer"?(
        <div className="" style={{width:"auto" , height:"auto"}}>
          {childrenContent}
          <div className="justify-center flex space-x-2">
        <button onClick={onClose} className="cancel-btn">
          Cancel
        </button>
        <button onClick={showConfirmation} className="save-btn">
          Create
        </button>
      </div>
        </div>
      ):(<Modal
    open={isOpen}
    onCancel={onClose}
    title={
      <h3 className="popup-heading">
        {`Create ${heading
          .toLowerCase()
          .split(" ")
          .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
          .join(" ")}`}
      </h3>
    }
    centered
    footer={
      <div className="justify-center flex space-x-2">
        <button onClick={onClose} className="cancel-btn">
          Cancel
        </button>
        <button onClick={showConfirmation} className="save-btn">
          Create
        </button>
      </div>
    }
    width={columnNames.length > 5 ? modalWidth : "500px"} // Responsive width
    styles={{
                    body: {
                      height: columnNames.length > 5 ? modalHeight : "auto",
                      padding: "4px",
                    },
                  }}
    // className="max-w-[90vw] sm:max-w-lg md:max-w-xl" // Responsive max-width
  >{childrenContent}</Modal>)}

     {/* <Modal
       open={isOpen}
       onCancel={onClose}
       title={
         <h3 className="popup-heading">
           {`Create ${heading
             .toLowerCase()
             .split(" ")
             .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
             .join(" ")}`}
         </h3>
       }
       centered
       footer={
         <div className="justify-center flex space-x-2">
           <button onClick={onClose} className="cancel-btn">
             Cancel
           </button>
           <button onClick={showConfirmation} className="save-btn">
             Create
           </button>
         </div>
       }
       width={columnNames.length > 5 ? modalWidth : "500px"} // Responsive width
       styles={{
         body: {
           height: columnNames.length > 5 ? modalHeight : "auto",
           padding: "4px",
         },
       }}
     // className="max-w-[90vw] sm:max-w-lg md:max-w-xl" // Responsive max-width
     >
       {!loading ? (
         <div className={`${columnNames.length > 5 ? "popup" : ""}`}>
           <div
             className={`grid gap-4 ${columnNames.length > 5 ? "grid-cols-1 sm:grid-cols-2" : "grid-cols-1"
               }`}
           >
             {columnNames.some((column) => column.db_column_name === "optimization_type") ? (
               columnNames.map((column) => (
                 <div key={column.db_column_name} className="flex flex-col mb-2">
                   {column.db_column_name === "optimization_type" && (
                     <>
                       <label className="field-label text-sm sm:text-base">
                         {column.display_name}
                         <span className="text-red-500">*</span>
                       </label>
                       <div className="flex items-center gap-3">
                         <Select
                           className="w-full"
                           styles={DropdownStyles}
                           placeholder="Select Optimization Type"
                           value={
                             formData["optimization_type"]
                               ? {
                                 label: [formData["optimization_type"]],
                                 value: [formData["optimization_type"]],
                               }
                               : []
                           }
                           onChange={(value: any) => handleChange("optimization_type", value?.value)}
                           options={[
                             { label: "Auto Change Rate Plan", value: "Auto Change Rate Plan" },
                             { label: "Cross Customer Pooling", value: "Cross Customer Pooling" },
                           ]}
                         />
                         <Popover
                           content={
                             <img
                               src="/images/rate-plan-info.png"
                               alt="Rate Plan Info"
                               style={{ width: "100%", maxWidth: "400px" }} // Responsive image
                             />
                           }
                           trigger="hover"
                           placement="right"
                         >
                           <InformationCircleIcon className="w-6 h-6 sm:w-7 sm:h-7 text-blue-600 cursor-pointer" />
                         </Popover>
                       </div>
                       {validationErrors["optimization_type"] && (
                         <span className="text-red-500 text-xs sm:text-sm mt-1">
                           {validationErrors[column.db_column_name]}
                         </span>
                       )}
                     </>
                   )}

                   {formData["optimization_type"] && column.db_column_name !== "optimization_type" && (
                     <>
                       {column.type !== "checkbox" && (
                         <label className="field-label text-sm sm:text-base">
                           {column.display_name}{" "}
                           {column.mandatory && column.mandatory !== null && (
                             <span className="text-red-500">*</span>
                           )}
                         </label>
                       )}

                       {column.type === "text" && (
                         <>
                           <Input
                             type="text"
                             value={formData[column.db_column_name] || ""}
                             onChange={(e) => handleChange(column.db_column_name, e.target.value)}
                             className="input w-full"
                             placeholder={`Enter ${lowerCaseFirstLetter(column.display_name)}`}
                           />
                           {validationErrors[column.db_column_name] && (
                             <span className="text-red-500 text-xs sm:text-sm">
                               {validationErrors[column.db_column_name]}
                             </span>
                           )}
                         </>
                       )}
                       {column.type === "date" && (
                         <>
                           <DatePicker
                             value={
                               formData[column.db_column_name]
                                 ? dayjs(formData[column.db_column_name])
                                 : null
                             }
                             onChange={(date, dateString) =>
                               handleChange(column.db_column_name, dateString)
                             }
                             className="input w-full"
                             disabledDate={(current) => {
                               if (!current) return false;
                               if (column.db_column_name === "inactivity_start" && current < dayjs().startOf("day")) {
                                 return true;
                               }
                               if (column.db_column_name === "billing_cycle_range" && current.date() >= 29) {
                                 return true;
                               }
                               return false; // Otherwise, all dates are enabled
                             }}

                           />
                           {validationErrors[column.db_column_name] && (
                             <span className="text-red-500 text-xs sm:text-sm">
                               {validationErrors[column.db_column_name]}
                             </span>
                           )}
                         </>
                       )}
                       {column.type === "checkbox" && (
                         <>
                           <Checkbox
                             checked={formData[column.db_column_name] || false}
                             onChange={(e) =>
                               handleChange(column.db_column_name, e.target.checked)
                             }
                             className="checkbox"
                           >
                             {column.display_name}
                           </Checkbox>
                           {validationErrors[column.db_column_name] && (
                             <span className="text-red-500 text-xs sm:text-sm">
                               {validationErrors[column.db_column_name]}
                             </span>
                           )}
                         </>
                       )}
                       {column.type === "dropdown" && (
                         <>
                           <Select
                             isClearable={heading === "Customer Group" && column.db_column_name === "sub_tanant"}
                             isMulti={
                               column.db_column_name === "customer_names" ||
                               column.db_column_name === "rate_plan_name" ||
                               column.db_column_name === "role_based" ||
                               (heading === "Customer Group" && column.db_column_name === "feature_codes") ||
                               (heading === "Customer Group" && column.db_column_name === "notification_rules")
                             }
                             className="w-full"
                             styles={DropdownStyles}
                             placeholder="Select..."
                             value={
                               formData[column.db_column_name]
                                 ? Array.isArray(formData[column.db_column_name])
                                   ? formData[column.db_column_name].map((item: string) => ({
                                     label: item,
                                     value: item,
                                   }))
                                   : { label: formData[column.db_column_name], value: formData[column.db_column_name] }
                                 : []
                             }
                             onChange={(value) => {
                               if (Array.isArray(value)) {
                                 handleChange(
                                   column.db_column_name,
                                   value.map((v) => v.value)
                                 );
                               } else {
                                 handleChange(column.db_column_name, value.value);
                               }
                             }}
                             options={
                               heading === "Customer Group"
                                 ? customerGroupsDropdownData[column.db_column_name]
                                 : column.db_column_name !== null &&
                                   generalFields &&
                                   generalFields[column.db_column_name] &&
                                   Array.isArray(generalFields[column.db_column_name])
                                   ? generalFields[column.db_column_name].map((option: string) => ({
                                     label: option,
                                     value: option,
                                   }))
                                   : []
                             }
                           />
                           {validationErrors[column.db_column_name] && (
                             <span className="text-red-500 text-xs sm:text-sm mt-1">
                               {validationErrors[column.db_column_name]}
                             </span>
                           )}
                         </>
                       )}
                       {column.type === "boolean" && (
                         <>
                           <div className="flex items-center">
                             <span className="mr-2 w-12 text-sm sm:text-base">
                               {formData[column.db_column_name] ? "Active" : "Inactive"}
                             </span>
                             <Switch
                               onChange={() =>
                                 handleChange(column.db_column_name, !formData[column.db_column_name])
                               }
                               checked={formData[column.db_column_name]}
                               className="custom-switch"
                             />
                           </div>
                           {validationErrors[column.db_column_name] && (
                             <span className="text-red-500 text-xs sm:text-sm">
                               {validationErrors[column.db_column_name]}
                             </span>
                           )}
                         </>
                       )}
                       {column.type === "textarea" && (
                         <>
                           <textarea
                             value={formData[column.db_column_name] || ""}
                             onChange={(e) => handleChange(column.db_column_name, e.target.value)}
                             className="input min-h-[80px] mt-1 w-full"
                           />
                           {validationErrors[column.db_column_name] && (
                             <span className="text-red-500 text-xs sm:text-sm">
                               {validationErrors[column.db_column_name]}
                             </span>
                           )}
                         </>
                       )}
                     </>
                   )}
                 </div>
               ))
             ) : (
               columnNames.map((column) => (
                 <div key={column.db_column_name} className="flex flex-col mb-4">
                   {column.type !== "checkbox" && (
                     <label className="field-label text-sm sm:text-base">
                       {column.display_name}{" "}
                       {column.mandatory && column.mandatory !== null && (
                         <span className="text-red-500">*</span>
                       )}
                     </label>
                   )}
                   {column.type === "text" && (
                     <>
                       <Input
                         type="text"
                         value={
                           heading === "Customer Group" && column.db_column_name === "tenant_name"
                             ? formData["parent_tenant_name"] || partner || formData[column.db_column_name]
                             : heading === "Customers" && column.db_column_name === "tenant_name"
                               ? isSubTenant
                                 ? partner
                                 : Object.keys(generalFields?.tenant_name || {})[0] ||
                                 formData[column.db_column_name]
                               : formData[column.db_column_name] || ""
                         }
                         onChange={(e) => handleChange(column.db_column_name, e.target.value)}
                         className="input w-full"
                         placeholder={`Enter ${lowerCaseFirstLetter(column.display_name)}`}
                         disabled={
                           (heading === "Customer Group" || heading === "Customers") &&
                           column.db_column_name === "tenant_name"
                         }
                       />
                       {validationErrors[column.db_column_name] && (
                         <span className="text-red-500 text-xs sm:text-sm">
                           {validationErrors[column.db_column_name]}
                         </span>
                       )}
                     </>
                   )}
                   {column.type === "date" && (
                     <>
                       <DatePicker
                         value={
                           formData[column.db_column_name]
                             ? dayjs(formData[column.db_column_name])
                             : null
                         }
                         onChange={(date, dateString) =>
                           handleChange(column.db_column_name, dateString)
                         }
                         className="input w-full"
                         disabledDate={(current) =>
                           (column.db_column_name === "inactivity_start" &&
                             current &&
                             current < dayjs().startOf("day")) ||
                           (column.db_column_name === "inactivity_end" &&
                             current &&
                             current < dayjs().startOf("day"))
                         }
                       />
                       {validationErrors[column.db_column_name] && (
                         <span className="text-red-500 text-xs sm:text-sm">
                           {validationErrors[column.db_column_name]}
                         </span>
                       )}
                     </>
                   )}
                   {column.type === "checkbox" && (
                     <>
                       <Checkbox
                         checked={formData[column.db_column_name] || false}
                         onChange={(e) =>
                           handleChange(column.db_column_name, e.target.checked)
                         }
                         className="checkbox"
                       >
                         {column.display_name}
                       </Checkbox>
                       {validationErrors[column.db_column_name] && (
                         <span className="text-red-500 text-xs sm:text-sm">
                           {validationErrors[column.db_column_name]}
                         </span>
                       )}
                     </>
                   )}
                   {column.type === "dropdown" && (
                     <>
                       {heading === "Customer Group" && column.db_column_name === "billing_account_number" && !isAdmin ?

                         (
                           <Input
                             type="text"
                             value={customerGroupsDropdownData && customerGroupsDropdownData[column.db_column_name] && customerGroupsDropdownData?.[column.db_column_name].length > 0 ? customerGroupsDropdownData?.[column.db_column_name][0]?.value : customerGroupsDropdownData[column.db_column_name] || ""}
                             // onChange={(e) => handleChange(column.db_column_name, e.target.value)}
                             className="non-editable-input w-full"
                             placeholder={`Enter ${lowerCaseFirstLetter(column.display_name)}`}
                             disabled
                           />
                         ) : (
                           <>
                             <Select
                               isClearable={heading === "Customer Group" && column.db_column_name === "sub_tanant"}
                               isMulti={
                                 column.db_column_name === "customer_names" ||
                                 column.db_column_name === "rate_plan_name" ||
                                 column.db_column_name === "role_based" ||
                                 (heading === "Customer Rate Pool" &&
                                   column.db_column_name === "service_provider_name" &&
                                   isCrossProvider) ||
                                 (heading === "Customer Group" && column.db_column_name === "feature_codes") ||
                                 (heading === "Customer Group" && column.db_column_name === "notification_rules")
                               }
                               className="w-full"
                               styles={column.db_column_name === "parent_accounts" && formData.account_type !== "Child" ? NonEditableDropdownStyles : DropdownStyles}
                               placeholder="Select..."
                               value={
                                 formData[column.db_column_name]
                                   ? Array.isArray(formData[column.db_column_name])
                                     ? formData[column.db_column_name].map((item: string) => ({
                                       label: item,
                                       value: item,
                                     }))
                                     : { label: formData[column.db_column_name], value: formData[column.db_column_name] }
                                   : []
                               }
                               onChange={(value) => {
                                 if (Array.isArray(value)) {
                                   handleChange(
                                     column.db_column_name,
                                     value.map((v) => v.value)
                                   );
                                 } else {
                                   handleChange(column.db_column_name, value?.value || value);
                                 }
                               }}
                               options={
                                 heading === "Customer Group"
                                   ? customerGroupsDropdownData[column.db_column_name] || []
                                   : heading === "Customers" && column.db_column_name === "sub_tenant_name"
                                     ? Object.keys(generalFields?.sub_tenant || {}).map((option: string) => ({
                                       label: option,
                                       value: option,
                                     })) || []
                                     : column.db_column_name !== null &&
                                       generalFields &&
                                       generalFields[column.db_column_name] &&
                                       Array.isArray(generalFields[column.db_column_name])
                                       ? generalFields[column.db_column_name].map((option: string) => ({
                                         label: option,
                                         value: option,
                                       }))
                                       : []
                               }
                               isDisabled={column.db_column_name === "parent_accounts" && formData.account_type !== "Child"}
                             />
                             {validationErrors[column.db_column_name] && (
                               <span className="text-red-500 text-xs sm:text-sm mt-1">
                                 {validationErrors[column.db_column_name]}
                               </span>
                             )}
                           </>
                         )}

                     </>
                   )}
                   {column.type === "boolean" && (
                     <>
                       <div className="flex items-center">
                         <span className="mr-2 w-12 text-sm sm:text-base">
                           {formData[column.db_column_name] ? "Active" : "Inactive"}
                         </span>
                         <Switch
                           onChange={() =>
                             handleChange(column.db_column_name, !formData[column.db_column_name])
                           }
                           checked={formData[column.db_column_name]}
                           className="custom-switch"
                         />
                       </div>
                       {validationErrors[column.db_column_name] && (
                         <span className="text-red-500 text-xs sm:text-sm">
                           {validationErrors[column.db_column_name]}
                         </span>
                       )}
                     </>
                   )}
                   {column.type === "textarea" && (
                     <>
                       <textarea
                         value={formData[column.db_column_name] || ""}
                         onChange={(e) => handleChange(column.db_column_name, e.target.value)}
                         className="input min-h-[80px] mt-1 w-full"
                       />
                       {validationErrors[column.db_column_name] && (
                         <span className="text-red-500 text-xs sm:text-sm">
                           {validationErrors[column.db_column_name]}
                         </span>
                       )}
                     </>
                   )}
                   {column.type === "date_range" && (
                     <>
                       <RangePicker
                         style={{ marginLeft: "2px", marginRight: "5px", height: "43px" }}
                         name={column.db_column_name}
                         className="w-full"
                         getPopupContainer={(trigger) => trigger.parentElement!}
                         value={formData[column.db_column_name] || null}
                         onChange={(dates) =>
                           handleChange(column.db_column_name, dates)
                         }
                       />
                       {validationErrors[column.db_column_name] && (
                         <span className="text-red-500">
                           {validationErrors[column.db_column_name]}
                         </span>
                       )}
                     </>
                   )}
                 </div>
               ))
             )}
           </div>

           {/* Private Network List View */}
           {/* {(heading === "Customer Group" && enablePrivateNetwork) && (
             <>
               <div style={{ marginBottom: "1rem" }}>
                 <PrivateNetworkTable
                   initialData={[]}
                   itemsPerPage={10}
                   popupHeading="Billing Customers"
                   pagination={{ start: 0, end: 0, total: 0 }}
                   serviceProviderOptions={serviceProviderOptions}
                   isEditable={false}
                 />
               </div>
             </>
           )} */}

         {/* </div> */}
       {/* ) : (
         <div
           className="flex justify-center items-center"
           style={{
             maxWidth: columnNames.length > 5 ? modalWidth : "100%", // Full width on small screens
             height: columnNames.length > 5 ? modalHeight : "auto",
             margin: "0 auto",
           }}
         >
           <Spin size="large" />
         </div>
       )} */}
      {/* </Modal> */}
      <Modal
        title="Confirmation"
        open={isConfirmationOpen}
        onOk={handleConfirmCreate}
        onCancel={handleCancelConfirmation}
        centered
        className="max-w-[90vw] sm:max-w-md" // Responsive confirmation modal
      >
        <p className="text-sm sm:text-base">
          Are you sure you want to Create this {heading.toLowerCase()}
        </p>
      </Modal>
    </div>
  );
};

export default CreateModal;
