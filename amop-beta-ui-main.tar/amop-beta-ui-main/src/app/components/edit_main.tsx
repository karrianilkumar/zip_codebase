"use client";

import React, { FC, useEffect, useMemo, useState } from "react";
import Select from "react-select";
import { Modal } from "antd";
import { DropdownStyles } from "@/app/components/css/dropdown";
import EditRevCustomerModal from "./EditRevCustomerPopup";
import EditBillingCustomer from "./edit_billing_customer";

// Types
interface EditMainProps {
    rowData: any;
    generalFields: any;
    isOpen: boolean;
    onClose: () => void;
    isEditable: boolean;
}

const DROPDOWN_OPTIONS = [
    { value: "revio", label: "Rev.IO customer" },
    { value: "billing", label: "Billing Customer" },
] as const;

type OptionValue = (typeof DROPDOWN_OPTIONS)[number]["value"];

const EditMain: FC<EditMainProps> = ({ rowData, generalFields, isOpen, onClose, isEditable }) => {

    const [selected, setSelected] = useState<OptionValue | null>(null);
    const [isRevIoCustomerModalOpen, setIsRevIoCustomerModalOpen] = useState(false);
    const [isbillingCustomerModalOpen, setIsBillingCustomerModalOpen] = useState(false);

    // When parent closes, reset everything
    const handleParentClose = () => {
        setSelected(null);
        setIsRevIoCustomerModalOpen(false);
        setIsBillingCustomerModalOpen(false);
        onClose?.();
    };

    // Open the appropriate child flow as soon as an option is chosen
    useEffect(() => {
        if (!selected) return;
        if (selected === "revio") {
            setIsRevIoCustomerModalOpen(true);
            setIsBillingCustomerModalOpen(false);
        } else if (selected === "billing") {
            setIsBillingCustomerModalOpen(true);
            setIsRevIoCustomerModalOpen(false);
        }
    }, [selected]);

    // Handlers
    const handleFormSubmitSuccess = () => {
        setIsRevIoCustomerModalOpen(false);
    };

    const handleCreateModalClose = () => {
        setIsBillingCustomerModalOpen(false);
    };

    const handleCreateRow = (row: Record<string, any>) => {
        setIsBillingCustomerModalOpen(false);
    };

    const multiplyFactor = (typeof window !== "undefined" && window.innerWidth < 700) ? 3.5 : 2.5
    const modalHeight =
        typeof window !== "undefined" ? (window.innerHeight * 2.5) / 4 : 0;
    const modalWidth =
        typeof window !== "undefined" ? (window.innerWidth * multiplyFactor) / 4 : 0;

    return (
        <Modal
            title="Create Customer"
            open={isOpen}
            onCancel={handleParentClose}
            footer={null}
            destroyOnClose
            maskClosable={false}
            width={modalWidth}
        >
            <div className="w-full space-y-4 overflow" style={{ height: modalHeight, overflow: "auto" }}>
                <div className="max-w-sm p-2">
                    <label className="block mb-1 text-sm font-semibold">Customer Type</label>
                    <Select
                        options={DROPDOWN_OPTIONS as unknown as { value: string; label: string }[]}
                        value={DROPDOWN_OPTIONS.find((o) => o.value === selected) as any}
                        onChange={(opt) => setSelected((opt?.value as OptionValue) ?? null)}
                        placeholder="Choose..."
                        styles={DropdownStyles}
                    />
                </div>

                {/* These are separate modals that open on top of the parent modal */}
                {selected === "revio" && (
                    <EditRevCustomerModal
                        isOpen={isRevIoCustomerModalOpen}
                        rowData={rowData}
                        onClose={onClose}
                        generalFields={generalFields}
                        isEditable={isEditable}
                    />
                )}

                {selected === "billing" && (
                    <EditBillingCustomer
                        isOpen={isbillingCustomerModalOpen}
                        onClose={onClose}
                        rowData={rowData}
                        generalFields={generalFields}
                        isEditable={isEditable}
                    />
                )}
            </div>
        </Modal>
    );
};

export default EditMain;
