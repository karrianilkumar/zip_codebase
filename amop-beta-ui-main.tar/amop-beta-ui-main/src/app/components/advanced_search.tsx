import { Modal, Select, Checkbox, Spin, InputNumber, Input } from "antd";
import { CloseOutlined } from "@ant-design/icons";
import React, { useEffect, useMemo, useState } from "react";
import axios from "axios";
import { useAuth } from "./auth_context";
import { useFeatureStore } from "../sim_management/inventory/featureStore";
import VirtualList from "rc-virtual-list";
import { ChevronDownIcon, ChevronUpIcon, FunnelIcon, ArrowPathIcon, CheckIcon } from "@heroicons/react/24/outline";
import { ENV_ROUTES } from "./routes/route_constants";
import { useSearchStore } from "../stores/searchStore";
// import { useCustomerRatePlanStore } from "@/app/stores/customerRateplanStore";
import { useCustomerRatePlanStore } from "../stores/customerRateplanStore";
import { useOptimizationStore } from "../stores/optimizationStore";
import { CheckboxChangeEvent } from "antd/es/checkbox";
import { useCustomerProfileStore } from "../billing/killbill_stores/customer_profile_store";
import { useChargesModalDataStore } from "../billing/killbill_stores/chargesModalData_store";
import { usePartnerCreationStore } from "../stores/partnerCreationStore";

// Define numeric fields that require range selection
const NUMERIC_FIELDS = [
  'overage_rate_cost',
  'rate_charge_amt',
  'base_rate',
  'sms_rate',
  'total_charge_amount',
  'total_charges'
];

interface RangeValue {
  min?: number;
  max?: number;
  single?: number;
}

interface FilterShape {
  [key: string]: string[];
}

const splitAndFilter = (input?: string): string[] => {
  return input?.split("\n").filter(Boolean) || [];
};

interface AdvancedFilterProps {
  showAdvanced?: boolean;
  setShowAdvanced: (value: boolean) => void;
  onFilter: (filters: FilterShape) => void;
  onReset: (filters: FilterShape) => void;
  headers?: string[];
  headerMap?: any;
  tableName?: string;
  selectedSubPartner?: any;
  selectedPartner?: any;
  isPartnerInfoModal?: boolean;
  filters?: {
    sync_status: string;
    service_provider: string;
    tenant_name: string;
    start_date: any;
    end_date: any;
  };
}

const AdvancedMultiFilter: React.FC<AdvancedFilterProps> = ({
  showAdvanced,
  setShowAdvanced,
  onFilter,
  onReset,
  headers = [],
  headerMap,
  tableName = "",
  selectedSubPartner,
  selectedPartner,
  isPartnerInfoModal,filters
}) => {
  const { SetselectedRowData2o } = useFeatureStore();
  const [activeFilters, setActiveFilters] = useState<FilterShape>({});
  const [formValues, setFormValues] = useState<{ [key: string]: string[] }>({});
  const [rangeValues, setRangeValues] = useState<{ [key: string]: RangeValue }>({});
  const [openRangeDropdown, setOpenRangeDropdown] = useState<string | null>(null);
  const [rangeErrors, setRangeErrors] = useState<{ [key: string]: string }>({});
  const {
    advancedStoredpagination,
    storedpagination,
    combineAdnvaceStoredpagination,
    settabledata,
    setStoredPagination,
    selectedDb,
    selectedBillingDb,
    metaData,
    sessionId,
    setAdvancedStoredPagination,
    setCombineAdnvaceStoredpagination,
    tenantId,
    partner,
    username,
    tenantName,
    tabledata,
    wholeSearchWord,
    firstLastName
  } = useAuth();
  const [options, setOptions] = useState<{ [key: string]: string[] }>({});
  const [loading, setLoading] = useState<{ [key: string]: boolean }>({});
  const [searchLoading, setSearchLoading] = useState(false);
  const [searchTable, setSearchTable] = useState<any[]>([]);
  const [visibleOptions, setVisibleOptions] = useState<{
    [key: string]: number;
  }>({});
  const [filteredOptions, setFilteredOptions] = useState<{
    [key: string]: string[];
  }>({});
  const [searchInput, setSearchInput] = useState<{ [key: string]: string }>({});
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
  const { setAdvancedSearchData,searchData,combineAdnvaceSearchData, setCombineAdnvaceSearchData, setIsSearchComponentCall ,setOptimizationErrorsData, setOptimizationErrorsPagination,isRedirectedFromDetails, detailsRedirectedFilters, detailsRedirectedSearchTerm, setDetailsRedirectedFilters , setIsRedirectedFromDetails, setDetailsRedirectedSearchTerm,setChargeDetailsSearchData, chargeDetailsSearchData, setChargeDetailsTableData,setChargesDetailsPagination,chargesDetailsPagination,setCreditDetailsTableData, creditDetailsSearchData, setCreditDetailsPagination,setCreditDetailsSearchData,creditDetailsPagination,setRecurringChargesPagination,setRecurringChargesSearchData, recurringChargesSearchData,recurringChargesPagination, setRecurringChargesTableData} = useSearchStore();
    const { setUsageDetailsTableData, setCreditTableData, setChargesTableData, setChargeByServiceTableData, setRecurringChargeData , creditTableData,usageDetailsTableData,chargeByServiceTableData,recurringChargeData} = useChargesModalDataStore();
  const { customerShowActive,partnerUsersShowActive,privateNetworksShowActive } = useCustomerRatePlanStore();
  const { optimizationRow } = useOptimizationStore();
  const bulkRow: any = JSON.parse(localStorage.getItem('bulk_row') || '{}');
  const isUnpostedUploadRow = JSON.parse(sessionStorage.getItem('UnpostedUploadRow') || '{}');
  const iccid: any = localStorage.getItem('iccid') || '0';
    const { accountNumber, BillId} = useCustomerProfileStore();

  const { editPartnerDBName, editPartnerMetaData, setUpAction, customerGroupName } = usePartnerCreationStore()
  const partner_row = JSON.parse(localStorage.getItem("partner_row") || "{}")
  const setupAction_ = setUpAction ? setUpAction.toString().toLowerCase() : ""
  const partnerName = partner_row?.partner || ""
  const subPartner = partner_row?.sub_partner && setupAction_.includes("sub tenant") ? partner_row?.sub_partner : ""
  const selected_info_partner = subPartner ? subPartner : partnerName || ""
  const defaultPartner = partner || ""
  const selectedPartnerName = isPartnerInfoModal ? selected_info_partner : defaultPartner
  const selectedPartnerDBName = isPartnerInfoModal ? editPartnerDBName : selectedDb
  const selectedPartnerMetaData = isPartnerInfoModal ? editPartnerMetaData : metaData

  
  // Function to check if a field should use range selection
const isNumericField = (header: string) => {
  return (
    (NUMERIC_FIELDS.includes(header) && tableName === "Customer_Rate_Plan") ||
    (['device_count', 'total_charges', 'total_charge_amount'].includes(header) && tableName === 'carrier_optimization_list_view' ) ||
    ( ['device_count', 'total_charges', 'total_charge_amount'].includes(header) && tableName === 'customer_optimization_list_view')
  );
};

  const handleScroll = () => {
    if (openDropdown) {
      setOpenDropdown(null);
    }
    if (openRangeDropdown) {
      setOpenRangeDropdown(null);
    }
  };
  useEffect(() => {
      if(tableName === "Inventory" || tableName === "sim_management_bulk_change"){
        if (isRedirectedFromDetails) {
                const allEmpty = Object.values(detailsRedirectedFilters).every(
                  (value) => Array.isArray(value) && value.length === 0
                );
              if (!allEmpty) {
                setShowAdvanced(true)
                setFormValues(detailsRedirectedFilters)
                handleNormalButtonClick(detailsRedirectedFilters)
              }
              }
      }
    }, []);
    useEffect(() => {
      if(tableName === "customer_optimization_list_view" || tableName === "carrier_optimization_list_view"){
        if (isRedirectedFromDetails) {
                const allEmpty = Object.values(detailsRedirectedFilters).every(
                  (value) => Array.isArray(value) && value.length === 0
                );
              if (!allEmpty) {
                setShowAdvanced(true)
                setFormValues(detailsRedirectedFilters)
                handleNormalButtonClick(detailsRedirectedFilters)
              }
              }
      }
    }, [isRedirectedFromDetails]);

  useEffect(() => {
      const allEmpty = Object.values(activeFilters).every(
        (value) => Array.isArray(value) && value.length === 0
      );
        if(!storedpagination && !combineAdnvaceStoredpagination && !allEmpty){
          // handleNormalButtonClick(activeFilters);
          handleClear()
        }
      }, [storedpagination, combineAdnvaceStoredpagination]);

useEffect(() => {
  const scrollContainer = document.querySelector(".overflow-x-auto");
  const modalBody = document.querySelector(".ant-modal-body"); // Add this
  
  if (scrollContainer) {
    scrollContainer.addEventListener("scroll", handleScroll);
  }
  
  if (modalBody) {
    modalBody.addEventListener("scroll", handleScroll);
  }
  
  return () => {
    if (scrollContainer) {
      scrollContainer.removeEventListener("scroll", handleScroll);
    }
    if (modalBody) {
      modalBody.removeEventListener("scroll", handleScroll);
    }
  };
}, [openDropdown, openRangeDropdown]);

  // useEffect(() => {
  //     if(searchTable.length>0 && tabledata.length>0 && searchTable!==tabledata){
  //       if(!combineAdnvaceStoredpagination){
  //         handleClear()
  //       }
  //     }
  //   }, [tabledata,searchTable]);

// Update handleRangeChange to handle the display format while maintaining original data
const handleRangeChange = (header: string, type: 'min' | 'max', value: number | null) => {
  setRangeValues(prev => {
    const newValues = { ...prev };
    if (!newValues[header]) {
      newValues[header] = {};
    }
 // Update the specific min/max value
    if (type === 'min') {
      newValues[header].min = value ?? undefined;
    } else {
      newValues[header].max = value ?? undefined;
    }
// Check if min is greater than or equal to max
    const { min, max } = newValues[header];
    let errorMessage = '';
    if (min !== undefined && max !== undefined && min >= max) {
      errorMessage = "minimum value should be less than the maximum value.";
    }
 // Update the error message state
    setRangeErrors(prev => ({
      ...prev,
      [header]: errorMessage,
    }));

    // Convert to filter format for backend
    const filterValues: string[] = [];
    if (min !== undefined && max === undefined) {
      filterValues.push(String(min));
    } else if (min !== undefined || max !== undefined) {
      filterValues.push(`${min ?? ''}:${max ?? ''}`);
    }

    handleSelectChange(header, filterValues);
    return newValues;
  });
};

const handleFocus = (header:any) => {
  if (searchInput[header]) {
    handleSearch(header, searchInput[header]);
  }
};
  const handleClear = () => {
    SetselectedRowData2o([])
    const emptyFilters = Object.keys(activeFilters).reduce<FilterShape>(
      (acc, key) => {
        acc[key] = [];
        return acc;
      },
      {} as FilterShape
    );
  
    if (Object.keys(activeFilters).length > 0) {
      onReset(emptyFilters);
    }

    onReset(emptyFilters);
    setFormValues({});
    setActiveFilters({});
    setSearchInput({});
    setFilteredOptions({});
    setRangeValues({});
    // Do not close the advanced filter section here
    setShowAdvanced(false); // Remove this line
    setAdvancedStoredPagination(null);
    setCombineAdnvaceStoredpagination(null)
    setCombineAdnvaceSearchData(null)
    setIsRedirectedFromDetails(false)
    setDetailsRedirectedFilters({})
    if(tableName === "Credit Details"){
      setCreditDetailsPagination(null)
      setCreditDetailsSearchData({})
    }
    if(tableName === "Charge Details"){
      setChargesDetailsPagination(null)
      setChargeDetailsSearchData({})
    }
    if(tableName === "Recurring Charge Details"){
      setRecurringChargesPagination(null)
      setRecurringChargesSearchData({})
    }
  };
  // const formatDisplayValue = (values: string[]): string => {
  //   if (!values || values.length === 0) return '';
    
  //   const value = values[0]; // We only handle one range/value at a time
  //   if (value.includes(':')) {
  //     const [min, max] = value.split(':');
  //     if (min && max) return `${min} to ${max}`;
  //     if (min) return `≥ ${min}`;
  //     if (max) return `≤ ${max}`;
  //   }
  //   return value; // Single value
  // };
 
  const formatDisplayValue = (values: string[], header: string): string => {
    if (!values || values.length === 0) return '';
    
    const value = values[0];
    if (value.includes(':')) {
      const [min, max] = value.split(':');
      // const showDollar = header === 'total_charge_amount' || header === 'total_charges';
    const showDollar = 
    ((header === 'total_charge_amount' || header === 'total_charges') && 
    (tableName === 'customer_optimization_list_view' || tableName === 'carrier_optimization_list_view'))
      const prefix = showDollar ? '$' : '';
      if (min && max) return `${prefix}${min} to ${prefix}${max}`;
      if (min) return `≥ ${prefix}${min}`;
      if (max) return `≤ ${prefix}${max}`;
    }
    return value;
  };
 
  const fetchOptions = async (header: string , searchedText?:string) => {
    setLoading((prev) => ({ ...prev, [header]: true }));
    const advancedFilters = Object.entries(formValues).reduce<FilterShape>((acc, [key, value]) => {
      const modifiedValue = value.map((item) => item === "" ? ' ' : item);
      acc[key] = value;
      return acc;
    }, {});
    const tenant_id_ = tenantId || localStorage.getItem('tenant_id') || '0';
    try {
      const url = ENV_ROUTES.OPEN_SEARCH;
      const data = {
        data: {
          path: "/fetch_dropdown",
          drop_down: header,
          table: tableName,
          ...(tableName === "status_history" && iccid && iccid !== "None" && iccid !== ""
            ? { iccid: [iccid] }
            : {}),
          ...(tableName === "status_history" && iccid && iccid !== "None" && iccid !== ""
            ? { flag: "status_history" }
            : {}),
          ...(tableName === "sim_management_bulk_change_request" && bulkRow && bulkRow !== null ? { flag: "bulk_history" } : {}),
          ...(tableName === "sim_management_bulk_change_request" && bulkRow && bulkRow !== null 
            ? { bulk_change_id:bulkRow?.row?.bulk_change_id || bulkRow?.row?.id || "0" }
            : {}),
          ...(tableName === "high_usage_customers" || tableName === "optimization_errors"
            ? { session_id: optimizationRow.session_id }
            : {}),
          ...(tableName === "Customer_Rate_Plan"
            ? { toggle: customerShowActive }
            : {}),
            ...(tableName === "Filtered_Customer_Rate_Plan" && isPartnerInfoModal
            ? { customer_group_name: customerGroupName }
            : {}),
          ...(tableName === "rev_assurance"
            ? { toggle: customerShowActive }
            : {}),
            ...(tableName === "partner_users"
              ? { toggle: partnerUsersShowActive }
              : {}),
              ...(tableName === "Private_Networks"
              ? { toggle: privateNetworksShowActive }
              : {}),
                ...(tableName === "Unposted Upload Data"
                ? {upload_id : isUnpostedUploadRow?.row.id || 0} : {}),
          ...(tableName === "Usage Details" || tableName === "Charge By Service" || tableName === "Credit Details" || tableName === "Charge Details"|| tableName === "Recurring Charge Details" ? { bill_id : BillId , account_number: accountNumber,} : {}),
             ...(tableName === "Billing Service Providers" && selectedPartner && { Selected_Partner: selectedPartner }),
          ...(tableName === "Billing Service Providers" && selectedSubPartner && { sub_partner: selectedSubPartner }),
          cascade: advancedFilters || {},
          db_name:["Suspension Settings","Usage Details","Charge By Service","Credit Details" ,"Charge Details","Recurring Charge Details" ,"Billing Service Providers","Unposted Upload Data"].includes(tableName)? selectedBillingDb:selectedPartnerDBName,
          partner: selectedPartnerName,
          ...((tableName === "Suspension Settings" || tableName === "Billing Service Providers") && {billing_db_name:selectedBillingDb}),
          sessionID: sessionId,
        tenant_id: tenant_id_,
          username: username,
          ...selectedPartnerMetaData,
          ...(tableName ==="customer_groups" && {
            firstLastName:firstLastName
          }),
          ...(tableName === "Carrier Syncs" && {
            sync_status: filters?.sync_status,
            service_provider: filters?.service_provider,
            start_date: filters?.start_date,
            end_date: filters?.end_date,
            tenant_name: filters?.tenant_name})
        },
      };
      
      const response = await axios.post(url, data);
      const parsedData = JSON.parse(response.data.body);
      
      if (parsedData?.flag) {
        setOptions((prevOptions) => ({
          ...prevOptions,
          [header]: parsedData?.[header] || [],
        }));

        if(searchedText){
          const filtered = parsedData?.[header]?.filter((option:any) =>
            option?.toString().toLowerCase().includes(searchedText.toLowerCase())
          ) || [];

          setFilteredOptions((prev) => ({
            ...prev,
            [header]: filtered,
          }));

        }else{
          setFilteredOptions((prevOptions) => ({
            ...prevOptions,
            [header]: parsedData?.[header] || [],
          }));

        }
        
        setVisibleOptions((prev) => ({
          ...prev,
          [header]: 20,
        }));
      } else {
        Modal.error({
          title: "Filter error",
          content: parsedData.error || "An error occurred while filtering. Please try again.",
        });
      }
    } catch (error) {
      console.error(error);
    } finally {
      setLoading((prev) => ({ ...prev, [header]: false }));
    }
  };

  const handleDropdownVisibleChange = (header: string, open: boolean) => {
    const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);
    if (open) {
      setOpenDropdown(header);
      if (!isNumericField(header)) {
        fetchOptions(header);
      }
       if (isMobile) {
    setTimeout(() => {
      const input = document.querySelector('.ant-select-selection-search-input') as HTMLInputElement;
      if (input) input.focus();
    }, 100);
  }
    } else {
      setOpenDropdown(null);
    }
  };

 
const handleSelectChange = (header: string, value: string[]) => {
  if (header) {
    setSearchInput((prev) => ({
      ...prev,
      [header]: "",
    }));
    // Allow removal of filters
    const newValue = value.filter(val => String(val).trim() !== ""); // Remove empty values
    setFormValues(prev => ({
      ...prev,
      [header]: newValue,
    }));

    const formValues_ = { ...formValues, [header]: newValue };
    const allEmpty = Object.values(formValues_).every(
      (value) => Array.isArray(value) && value.length === 0
    );

    if (allEmpty) {
      handleClear();
    }
  }
};

const handleSearch = (header: string, inputValue: string, isFinalSubmit = false) => {
  if(header==='iccid' || header==='msisdn' || header==='imei'|| header ==='eid'|| header ==='service_number'){
    handleBulkSearch(header,inputValue,isFinalSubmit)
  }
  else{
    handleNormalSearch(header,inputValue)
  }
};

const handleNormalSearch = (header: string, inputValue: string) => {
  // Prevent spaces from being accepted
  if (inputValue.trim() === "") {
    setSearchInput((prev) => ({
      ...prev,
      [header]: "",
    }));
    setFilteredOptions((prev) => ({
      ...prev,
      [header]: options[header] || [],
    }));
    return;
  }

  setSearchInput((prev) => ({
    ...prev,
    [header]: inputValue,
  }));

  if(loading[header]){
    fetchOptions(header,inputValue)
  }
  else{
    const filtered = options[header]?.filter((option) =>
      option?.toString().toLowerCase().includes(inputValue.toLowerCase())
    ) || [];
  
    setFilteredOptions((prev) => ({
      ...prev,
      [header]: filtered,
    }));
  }
};

const handleBulkSearch = (header: string, inputValue: string, isFinalSubmit = false) => {
  // Trim unnecessary spaces from the input
  const trimmedInput = inputValue.trim();
  // Show initial options if no comma is present in the input
  const shouldShowInitialOptions = !trimmedInput.includes(',');
  // If the input is empty and it's not a final submit, clear the input field
  if (!trimmedInput && !isFinalSubmit) {
    setSearchInput((prev) => ({
      ...prev,
      [header]: "",
    }));
    return;
  }

  // Keep track of already selected values
  const selectedValues = formValues[header] || [];

  // Logic to handle the input string and extract values
  const processInput = (input: string) => {
    // First, ensure we maintain spaces after commas if they exist
    const normalizedInput = input.replace(/,\s*/g, ', ');
    
    // Split only by comma or space
    const parts = normalizedInput.split(/[,\s]/);
    console.log("parts",parts)
    
    // If it's not a final submit, we only take values that are properly delimited
    if (!isFinalSubmit) {
      // Check if the input ends with a comma or space
      const endsWithDelimiter = input.endsWith(',') || input.endsWith(' ');
      const lastTypedValue = trimmedInput.split(/[,\s]/).pop() || "";
      const filtered = options[header]?.filter((option) =>
        option.toString().toLowerCase().includes(lastTypedValue.toLowerCase())
      ) || [];
      if (endsWithDelimiter||filtered.includes(lastTypedValue)) {
        // Take all parts except the last empty one
        return parts.filter(Boolean);
      } else {
        // Take all parts except the last one (which is still being typed)
        return parts.slice(0, -1).filter(Boolean);
      }
    } else {
      // On final submit, take all valid values including the last one
      return parts.filter(Boolean);
    }
  };

  // Get the new values to be added
  const newValues = processInput(trimmedInput);

  // If we have new values to add
  if (newValues.length > 0) {
    // Merge new values into selected options and remove duplicates
    const updatedValues = [...new Set([...selectedValues, ...newValues])];
    
    // Update the form values with the new values
    handleSelectChange(header, updatedValues);

    // Clear the input only if we're submitting or the input ends with a comma or space
    setSearchInput((prev) => ({
      ...prev,
      [header]: "",
    }));
  } 
  else if (!isFinalSubmit) {
    // If no new values to add and not final submit, update the input field for continued typing
    setSearchInput((prev) => ({
      ...prev,
      [header]: inputValue,
    }));
  }

  // Filter the options based on the current input value
  // Get the last typed value (after the last comma or space)
  const lastTypedValue = trimmedInput.split(/[,\s]/).pop() || "";
  // Use all options if no commas, otherwise filter
const filtered = shouldShowInitialOptions
? options[header]?.filter((option) =>
  option.toString().toLowerCase().includes(inputValue.toLowerCase())
) || []
: options[header]?.filter((option) =>
    option.toString().toLowerCase().includes("")
  ) || [];

setFilteredOptions((prev) => ({
...prev,
[header]: filtered,
}));

  // Optionally fetch additional options from the backend if necessary
  if (loading[header]) {
    fetchOptions(header, lastTypedValue);
  }
};

  const loadMoreOptions = (header: string) => {
    setVisibleOptions((prev) => ({
      ...prev,
      [header]: (prev[header] || 20) + 20,
    }));
  };

  const handleCheckboxChange = (header: string, option: string, checked: boolean) => {
    let newValues:any
    if (header) {
      setSearchInput((prev) => ({
        ...prev,
        [header]: "",
      }));
      if((tableName==="rev_assurance"||tableName==="rev_assurance_variance") && header=="customer_name" && option.toLowerCase()==="assigned"){
         // Push all options except "assigned" and "unassigned"
      const allOptions = options[header] || [];
      newValues = allOptions.filter(
        (item) => item.toLowerCase() !== "unassigned"
      );   // newValues = ["unassigned"];
      
      }
      else{
        const currentValues = formValues[header] || [];
      newValues = checked
        ? [...currentValues, option]
        : currentValues.filter((item) => item !== option);

      }
    
      setFormValues((prev) => ({
        ...prev,
        [header]: newValues,
      }));
      const formValues_ = { ...formValues, [header]: newValues };
      const allEmpty = Object.values(formValues_).every(
        (value) => Array.isArray(value) && value.length === 0
      );

      if (allEmpty) {
        handleClear();
      }
    }
  };

  const handleFilterLoad = () => {
    setSearchLoading(true);
    // if(searchLoading){
      handleFilter()
    // }
  }

  // const handleFilter = () => {
  //   const advancedFilters = Object.entries(formValues).reduce<FilterShape>((acc, [key, value]) => {
  //     const modifiedValue = value.map((item) => item === "" ? ' ' : item);
  //     acc[key] = modifiedValue;
  //     return acc;
  //   }, {});
    
  //   setActiveFilters(advancedFilters);
  //   onFilter(advancedFilters);
    
  //   if (Object.keys(advancedFilters).length > 0) {
  //     if (tableName === "status_history" && iccid && iccid !== "None") {
  //       advancedFilters["iccid"] = [iccid];
  //     }
  //     if (tableName === "sim_management_bulk_change_request" && bulkRow && bulkRow !== null) {
  //       advancedFilters["bulk_change_id"] = [bulkRow?.row?.id];
  //     }
  //     handleButtonClick(advancedFilters);
  //   }
  // };

  const handleFilter = () => {
    SetselectedRowData2o([])
    const advancedFilters = Object.entries(formValues).reduce<FilterShape>((acc, [key, value]) => {
      // Ensure no empty values, replace with a single space if necessary
      const modifiedValue = value.map((item) => (item === "" ? " " : item));
      acc[key] = modifiedValue;
      return acc;
    }, {});
    
    if (Object.keys(advancedFilters).length > 0) {
      if (tableName === "status_history" && iccid && iccid !== "None") {
        advancedFilters["iccid"] = [iccid];
      }
      if (tableName === "sim_management_bulk_change_request" && bulkRow && bulkRow !== null) {
        advancedFilters["bulk_change_id"] = [bulkRow?.row?.id];
      }
    }
  
    // Set active filters to the state
    setActiveFilters(advancedFilters);
  
    // Trigger the search with the constructed filters
    onFilter(advancedFilters);
  
    // Call the backend search function
    handleNormalButtonClick(advancedFilters);
    setSearchInput({})
  };
  
  const handleNormalButtonClick = async (filters: any) => {
    setIsSearchComponentCall(true)
    console.log(wholeSearchWord,"wholeSearchWord");
  const filteredFilters = { ...filters };
    if (tableName === "Charge Details" || tableName === "Credit Details" || tableName === "Recurring Charge Details") {
      handleChargesModalButtonClick(filteredFilters);
    }
    else{
      handlegeneralButtonClick(filteredFilters);
    }
     
  };
  const handleChargesModalButtonClick = async (filters: any) => {
    
      const pagination_ =
        tableName === "Charge Details"
          ? chargesDetailsPagination
          : tableName === "Credit Details"
            ? creditDetailsPagination
            : tableName === "Recurring Charge Details"
              ? recurringChargesPagination
              : storedpagination;

      const tableSearchData =
        tableName === "Charge Details"
          ? chargeDetailsSearchData
          : tableName === "Credit Details"
            ? creditDetailsSearchData
            : tableName === "Recurring Charge Details"
              ? recurringChargesSearchData
              : searchData;

      const effectiveSearchData = combineAdnvaceStoredpagination
        ? combineAdnvaceSearchData
        : tableSearchData;

    if ((pagination_ && effectiveSearchData) && combineAdnvaceStoredpagination) {
      const search_word_ = effectiveSearchData?.data?.search_word;
      handleCombineButtonClick(filters, search_word_);
    }

    else if (tableSearchData?.data?.search_word && tableSearchData?.data?.search_word  !== "") {
      handleCombineButtonClick(filters, wholeSearchWord);
    }

    else {
      setSearchLoading(true);
      try {
        const url = ENV_ROUTES.OPEN_SEARCH;
        const data = {
          data: {
            path: "/perform_search",
            search: "advanced",
            filters: filters,
            index_name: tableName,
            tenant_id: tenantId,
            pages: {
              start: 0,
              end: 100,
            },
            partner: selectedPartnerName,
            username: username,
            ...selectedPartnerMetaData,
            ...(tableName === "Unposted Upload Data"
                ? {upload_id : isUnpostedUploadRow?.row.id || 0} : {}),
            ...(tableName === "Billing Service Providers" && selectedPartner && { Selected_Partner: selectedPartner }),
            ...(tableName === "Billing Service Providers" && selectedSubPartner && { sub_partner: selectedSubPartner }),
            db_name: ["Suspension Settings", "Usage Details", "Charge By Service", "Credit Details", "Charge Details", "Recurring Charge Details", "Billing Service Providers","Unposted Upload Data"].includes(tableName) ? selectedBillingDb : selectedPartnerDBName,
            ...(tableName === "Usage Details" || tableName === "Charge By Service" || tableName === "Credit Details" || tableName === "Charge Details" || tableName === "Recurring Charge Details" ? { bill_id: BillId, account_number: accountNumber, } : {}),
            ...((tableName === "Suspension Settings" || tableName === "Billing Service Providers") && { billing_db_name: selectedBillingDb }),
            sessionID: sessionId,
          },

        };
        console.log(data, "Adnvaced data....");
        setAdvancedSearchData(data);
        const response = await axios.post(url, data);
        const parsedData = JSON.parse(response.data.body);

        if (parsedData?.flag) {
          const tableData = parsedData?.data?.table;
          const pagination_ = parsedData?.pages || {};
          if (tableName === "Usage Details") {
            setUsageDetailsTableData(tableData)
          }
          else if (tableName === "Charge By Service") {
            setChargeByServiceTableData(tableData)
          }
          else if (tableName === "Charge Details") {
            setChargeDetailsTableData(tableData)
            setChargesDetailsPagination(pagination_)
            setChargeDetailsSearchData(data);
          }
          else if (tableName === "Credit Details") {
            setCreditDetailsTableData(tableData)
            setCreditDetailsPagination(pagination_)
            setCreditDetailsSearchData(data);
          }
          else if (tableName === "Recurring Charge Details") {
            setRecurringChargesTableData(tableData)
            setRecurringChargeData(tableData)
            setRecurringChargesPagination(pagination_)
            setRecurringChargesSearchData(data);
          }
          // else if(tableName === "Charge Overview"){
          //   setRecurringChargeData(parsedData?.data?.table?.charge_overview_recurring_charges || [])
          //   setCreditTableData(parsedData?.data?.table?.charge_overview_account_credits || [])
          //   setChargesTableData(parsedData?.data?.table?.charge_overview_account_charges || [])
          // }
          else {
            settabledata(tableData);
          }
          setSearchTable(tableData)
          setAdvancedStoredPagination(pagination_);
          // }
          // setAdvancedStoredPagination(pagination_);
         


          if (tableData.length === 0) {
            Modal.error({
              title: "No Records found",
            });
            handleClear()
            setShowAdvanced(false)
          }
        } else {
          Modal.error({
            title: "Search error",
            content: parsedData.error || "An error occurred while searching. Please try again.",
          });
          handleClear()
          setShowAdvanced(false)
        }
      } catch (error) {
        console.error(error);
      }
      finally {
        setSearchLoading(false);
      }
    } 
  }
  const handlegeneralButtonClick = async (filters_: any) => {
    setIsSearchComponentCall(true)
    console.log(wholeSearchWord,"wholeSearchWord");
  const filteredFilters = { ...filters_ };
    if ((tableName === "rev_assurance" || tableName === "rev_assurance_variance") && filteredFilters.customer_name && filteredFilters.customer_name.includes("Assigned")) {
      filteredFilters.customer_name = filteredFilters.customer_name.filter((item:any) => item !== "Assigned");
    }
    // setStoredPagination(null);  removed the pagination setting to null
    if((storedpagination && (searchData || chargeDetailsSearchData || creditDetailsSearchData || recurringChargesSearchData)) || combineAdnvaceStoredpagination){
      let search_data_ = tableName === "Charge Details" ? chargeDetailsSearchData:
       tableName === "Credit Details" ? creditDetailsSearchData:
       tableName === "Recurring Charge Details" ? recurringChargesSearchData :
       searchData;
      const searchData_=combineAdnvaceStoredpagination?combineAdnvaceSearchData:search_data_
      const search_word_ =  searchData_?.data?.search_word;
      handleCombineButtonClick(filters_,search_word_);
    }
    
    else if(wholeSearchWord && wholeSearchWord!==""){
      handleCombineButtonClick(filters_,wholeSearchWord);
    }
    else{
      setSearchLoading(true);
      try {
        const url = ENV_ROUTES.OPEN_SEARCH;
        const data = {
          data: {
            path: "/perform_search",
            search: "advanced",
            filters: filteredFilters,
            index_name: tableName,
            tenant_id: tenantId,
            pages: {
              start: 0,
              end: 100,
            },
            partner: selectedPartnerName,
            ...(tableName === "Unposted Upload Data"
                ? {upload_id : isUnpostedUploadRow?.row.id || 0} : {}),
            username: username,
            ...selectedPartnerMetaData,
              ...(tableName === "Billing Service Providers" && selectedPartner && { Selected_Partner: selectedPartner }),
          ...(tableName === "Billing Service Providers" && selectedSubPartner && { sub_partner: selectedSubPartner }),
          db_name:["Suspension Settings","Usage Details","Charge By Service","Credit Details" ,"Charge Details","Recurring Charge Details","Billing Service Providers","Unposted Upload Data"].includes(tableName)? selectedBillingDb:selectedPartnerDBName,
           ...(tableName === "Usage Details" || tableName === "Charge By Service" || tableName === "Credit Details" || tableName === "Charge Details"|| tableName === "Recurring Charge Details"? { bill_id : BillId , account_number: accountNumber,} : {}),
          ...((tableName === "Suspension Settings" || tableName === "Billing Service Providers") && {billing_db_name:selectedBillingDb}),
            sessionID: sessionId,
          ...(tableName === "rev_assurance" || tableName === "Customer_Rate_Plan"
            ? { toggle: customerShowActive }
            : {}),
            ...(tableName === "Filtered_Customer_Rate_Plan" && isPartnerInfoModal
            ? { customer_group_name: customerGroupName }
            : {}),
          ...(tableName === "partner_users"
            ? { toggle: partnerUsersShowActive }
            : {}),
            ...(tableName === "Private_Networks"
              ? { toggle: privateNetworksShowActive }
              : {}),
          ...(tableName === "status_history" && iccid && iccid !== "None" && iccid !== ""
            ? { flag: "status_history" }
            : {}),
          ...(tableName === "sim_management_bulk_change_request" && bulkRow && bulkRow !== null
            ? { flag: "bulk_history" }
            : {}),
          ...(tableName === "high_usage_customers" || tableName === "optimization_errors"
            ? { session_id: optimizationRow.session_id }
            : {}),
            ...(tableName ==="customer_groups" && {
            firstLastName:firstLastName
          }),
          ...(tableName === "Carrier Syncs" && {
            sync_status: filters?.sync_status,
            service_provider: filters?.service_provider,
            start_date: filters?.start_date,
            end_date: filters?.end_date,
            tenant_name: filters?.tenant_name})
           },
        };
        console.log(data,"Adnvaced data....");
        setAdvancedSearchData(data);
        const response = await axios.post(url, data);
        const parsedData = JSON.parse(response.data.body);
        
        if (parsedData?.flag) {
          const tableData = parsedData?.data?.table;
          const pagination_ = parsedData?.pages || {};
           if (tableName === "optimization_error_details" || tableName === "tenant_based_banners_logs") {
            setOptimizationErrorsData(tableData)
            setOptimizationErrorsPagination(pagination_)
          }
          //billing charges related tables
          else if(tableName === "Usage Details"){
            setUsageDetailsTableData(tableData)
          }
          else if(tableName === "Charge By Service"){
            setChargeByServiceTableData(tableData)
          }
           else if(tableName === "Charge Details"){
            setChargeDetailsTableData(tableData)
            setChargesDetailsPagination(pagination_)
            setChargeDetailsSearchData(data);
          }
           else if(tableName === "Credit Details"){
            setCreditDetailsTableData(tableData)
            setCreditDetailsPagination(pagination_)
            setCreditDetailsSearchData(data);
          }
           else if(tableName === "Recurring Charge Details"){
            setRecurringChargesTableData(tableData)
            setRecurringChargesPagination(pagination_)
            setRecurringChargesSearchData(data);
          }
          // else if(tableName === "Charge Overview"){
          //   setRecurringChargeData(parsedData?.data?.table?.charge_overview_recurring_charges || [])
          //   setCreditTableData(parsedData?.data?.table?.charge_overview_account_credits || [])
          //   setChargesTableData(parsedData?.data?.table?.charge_overview_account_charges || [])
          // }
          else {
            settabledata(tableData);
          }
            setSearchTable(tableData)
            // if(tableName !== "Credit Details" && tableName !== "Charge Details"){
              setAdvancedStoredPagination(pagination_);
            // }
            // setAdvancedStoredPagination(pagination_);
            if(tableName === "Inventory" || tableName === "sim_management_bulk_change" || tableName === "customer_optimization_list_view" || tableName === "carrier_optimization_list_view"){
              setDetailsRedirectedFilters(filteredFilters)
              setDetailsRedirectedSearchTerm("")
            }

          
          if (tableData.length === 0) {
            Modal.error({
              title: "No Records found",
            });
            handleClear()
            setShowAdvanced(false)
          }
        } else {
          Modal.error({
            title: "Search error",
            content: parsedData.error || "An error occurred while searching. Please try again.",
          });
          handleClear()
          setShowAdvanced(false)
        }
      } catch (error) {
        console.error(error);
      }
      finally{
      setSearchLoading(false);
      }
    }  
  };
  const handleCombineButtonClick = async (filters_: any,searchWord: string) => {
      setSearchLoading(true);
      try {
        const url = ENV_ROUTES.OPEN_SEARCH;
        const data = {
          data: {
            path: "/perform_search",
            search: "combined",
            filters: filters_,
            search_word: searchWord,
            search_all_columns: "True",
            index_name: tableName,
            tenant_id: tenantId,
            pages: {
              start: 0,
              end: 100,
            },
            partner: selectedPartnerName,
            username: username,
            // db_name: selectedDb,
            db_name:["Suspension Settings","Usage Details","Charge By Service","Credit Details" ,"Charge Details","Recurring Charge Details" ,"Billing Service Providers","Unposted Upload Data"].includes(tableName)? selectedBillingDb:selectedPartnerDBName,
             ...(tableName === "Usage Details" || tableName === "Charge By Service" || tableName === "Credit Details" || tableName === "Charge Details"|| tableName === "Recurring Charge Details" ? { bill_id : BillId , account_number: accountNumber,} : {}),
             ...(tableName === "Unposted Upload Data"
                ? {upload_id : isUnpostedUploadRow?.row.id || 0} : {}),   
             ...metaData,
                ...selectedPartnerMetaData,
            sessionID: sessionId,
          ...(tableName === "rev_assurance" || tableName === "Customer_Rate_Plan"
            ? { toggle: customerShowActive }
            : {}),
          ...(tableName === "Filtered_Customer_Rate_Plan" && isPartnerInfoModal
            ? { customer_group_name: customerGroupName }
            : {}),
          ...(tableName === "partner_users"
            ? { toggle: partnerUsersShowActive }
            : {}),
            ...(tableName === "Private_Networks"
              ? { toggle: privateNetworksShowActive }
              : {}),
          ...(tableName === "status_history" && iccid && iccid !== "None" && iccid !== ""
            ? { flag: "status_history" }
            : {}),
          ...(tableName === "sim_management_bulk_change_request" && bulkRow && bulkRow !== null
            ? { flag: "bulk_history" }
            : {}),
          ...(tableName === "high_usage_customers" || tableName === "optimization_errors"
            ? { session_id: optimizationRow.session_id }
            : {}),
            ...(tableName ==="customer_groups" && {
            firstLastName:firstLastName
          }),
          ...(tableName === "Carrier Syncs" && {
            sync_status: filters?.sync_status,
            service_provider: filters?.service_provider,
            start_date: filters?.start_date,
            end_date: filters?.end_date,
            tenant_name: filters?.tenant_name})
          },
        };
        
        setCombineAdnvaceSearchData(data);
        const response = await axios.post(url, data);
        const parsedData = JSON.parse(response.data.body);
        
        if (parsedData?.flag) {
          const tableData = parsedData?.data?.table;
          const pagination_ = parsedData?.pages || {};
          //billing charges related tables
          if(tableData === "Usage Details"){
            setUsageDetailsTableData(tableData)
          }
          else if(tableData === "Charge By Service"){
            setChargeByServiceTableData(tableData)
          }
          else if(tableName === "Charge Details"){
            setChargeDetailsTableData(tableData)
            setChargesDetailsPagination(pagination_)
            setChargeDetailsSearchData(data);
          }
           else if(tableName === "Credit Details"){
            setCreditDetailsTableData(tableData)
            setCreditDetailsPagination(pagination_)
            setCreditDetailsSearchData(data);
          }
           else if(tableName === "Recurring Charge Details"){
            setRecurringChargesTableData(tableData)
            setRecurringChargesPagination(pagination_)
            setRecurringChargesSearchData(data);
          }
        //  else if(tableName === "Charge Overview"){
        //     setRecurringChargeData(parsedData?.data?.table?.charge_overview_recurring_charges || [])
        //     setCreditTableData(parsedData?.data?.table?.charge_overview_account_credits || [])
        //     setChargesTableData(parsedData?.data?.table?.charge_overview_account_charges || [])
        //   }

          else{
            settabledata(tableData);
          }
          setSearchTable(tableData)
          setCombineAdnvaceStoredpagination(pagination_);
          
          if (tableData.length === 0) {
            Modal.error({
              title: "No Records found",
            });
            handleClear()
            setShowAdvanced(false)
          }
         
        } else {
          Modal.error({
            title: "Search error",
            content: parsedData.error || "An error occurred while searching. Please try again.",
          });
          handleClear()
          setShowAdvanced(false)
        }
      } catch (error) {
        console.error(error);
      }
      finally{
      setSearchLoading(false);
      }
    };

const renderRangeDropdown = (header: string) => {
  const values = rangeValues[header] || {};
  const errorMessage = rangeErrors[header];
  const showDollar = 
    ((header === 'total_charge_amount' || header === 'total_charges') && 
    (tableName === 'customer_optimization_list_view' || tableName === 'carrier_optimization_list_view'));

  return (
    <div className="p-4 bg-white shadow-lg rounded-lg">
      <div className="space-y-2">
        <div className="flex items-center space-x-2">
          <div className="relative w-1/2">
            {showDollar && (
              <span className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
            )}
            <InputNumber
            className={`w-full`}
            value={values.min === undefined ? undefined : values.min}
            onChange={(value) => {
              if (value !== null && value < 0) {
                setRangeErrors(prev => ({
                  ...prev,
                  [header]: "Negative values are not accepted."
                }));
                return;
              }
              setRangeErrors(prev => ({ ...prev, [header]: "" }));
              handleRangeChange(header, 'min', value);
            }}
            placeholder="Min value"
            title={values.min !== undefined ? `Min Value: ${showDollar ? `$${values.min}` : values.min}` : "Enter minimum value"}
            formatter={(value) => {
              if (value === undefined || value === null) return '';
              return String(value);
            }}
            parser={(displayValue) => {
              if (!displayValue) return 0; // Return 0 for empty input
              const numericValue = displayValue.replace(/\$\s?|(,*)/g, ''); // Remove dollar sign and commas
              if (!/^[0-9]*$/.test(numericValue)) {
                setRangeErrors(prev => ({ ...prev, [header]: "Only numbers are accepted." }));
                return 0; // Return 0 for invalid input
              }
              setRangeErrors(prev => ({ ...prev, [header]: "" }));
              return Number(numericValue);
            }}
            min={0}
            addonBefore={showDollar}
          />
          </div>

          <span className="text-gray-500">to</span>

          <div className="relative w-1/2">
            {showDollar && (
              <span className="absolute left-2 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
            )}
            
            <InputNumber
            className={`w-full`}
            value={values.max === undefined ? undefined : values.max}
            onChange={(value) => {
              if (value !== null && value < 0) {
                setRangeErrors(prev => ({
                  ...prev,
                  [header]: "Negative values are not accepted."
                }));
                return;
              }
              if (value !== null && value <= (values.min === undefined ? 0 : values.min)) {
                setRangeErrors(prev => ({
                  ...prev,
                  [header]: "Max value must be greater than min value."
                }));
                return;
              }
              setRangeErrors(prev => ({ ...prev, [header]: "" }));
              handleRangeChange(header, 'max', value);
            }}
            placeholder="Max value"
            title={values.max !== undefined ? `Max value: ${showDollar ? `$${values.max}` : values.max}` : "Enter maximum value"}
            formatter={(value) => {
              if (value === undefined || value === null) return '';
              return String(value);
            }}
            parser={(displayValue) => {
              if (!displayValue) return 0; // Return 0 for empty input
              const numericValue = displayValue.replace(/\$\s?|(,*)/g, ''); // Remove dollar sign and commas
              if (!/^[0-9]*$/.test(numericValue)) {
                setRangeErrors(prev => ({ ...prev, [header]: "Only numbers are accepted." }));
                return 0; // Return 0 for invalid input
              }
              setRangeErrors(prev => ({ ...prev, [header]: "" }));
              return Number(numericValue);
            }}
            min={0}
            // style={{ paddingLeft: showDollar ? '0.5rem' : '0.5rem' }}
            addonBefore={showDollar}
          />
          </div>
        </div>
        {errorMessage && (
          <div className="text-red-500 text-xs mt-1">{errorMessage}</div>
        )}
        <div className="text-xs text-gray-500 mt-1">
          Enter single value in first box or specify a range
        </div>
      </div>
    </div>
  );
};


// Add this function to format values with dollar sign
const formatValueWithDollar = (value: string, header: string): string => {
  // const showDollar = (header === 'total_charge_amount' || header === 'total_charges') && (tableName === "Customer_Rate_Plan" ||tableName === 'customer_optimization_list_view'||tableName === 'carrier_optimization_list_view' );
  const showDollar = 
    ((header === 'total_charge_amount' || header === 'total_charges') && 
    (tableName === 'customer_optimization_list_view' || tableName === 'carrier_optimization_list_view')) ;
  return showDollar ? `$${value}` : value;
};

  const countActiveFilters = useMemo(() => {
    if (
      (tableName === "status_history" && activeFilters?.["iccid"]) ||
      (tableName === "sim_management_bulk_change_request" && activeFilters["bulk_change_id"] ) 
    ) {
      return (
        Object.values(activeFilters).filter((value) => value.length > 0)
          .length - 1
      );
    } else {
      return Object.values(activeFilters).filter((value) => value.length > 0)
        .length;
    }
  }, [activeFilters]);

  const isFilterButtonEnabled = () => {
    return Object.values(formValues).some((values) => values.length > 0) || 
           Object.values(rangeValues).some((range) => range.single !== undefined || (range.min !== undefined && range.max !== undefined))
          //  || Object.values(searchInput).some((input) => input.length > 0);
  };

  const checkSelectAll = (header: string) => {
    const currentOptions =
      filteredOptions[header]?.length
        ? filteredOptions[header]
        : options[header];

    const selectedOptions = formValues[header] || [];

    const isAllFilteredSelected =
      currentOptions?.length > 0 &&
      currentOptions.every((opt: any) =>
        selectedOptions.includes(opt)
      );

      return isAllFilteredSelected
  }
  
  return (
    <div>
      {searchLoading && (
              <div className="absolute inset-0 flex justify-center items-center adv-search-loader bg-white bg-opacity-75 z-50 pointer-events-none">
                <Spin size="large" />
              </div>
            )}
      {/* <div className="flex flex-col md:flex-row md:justify-end space-y-4 md:space-y-0 md:space-x-2">
        <button
          className="save-btn w-[150px]"
          onClick={() => setShowAdvanced(!showAdvanced)}
          style={{ fontWeight: "450" }}
        >
          {showAdvanced ? (
            <span className="flex items-center pl-2">
              Hide Advanced
              <ChevronUpIcon className="ml-2 w-4 h-4" />
            </span>
          ) : (
            <span className="flex items-center pl-2">
              Show Advanced
              <ChevronDownIcon className="ml-2 w-4 h-4" />
            </span>
          )}
        </button>

        {(showAdvanced && isFilterButtonEnabled()) && (
          <div className="relative w-full md:w-auto">
           <button
            className={`save-btn ${!showAdvanced || !isFilterButtonEnabled() ? "disabled" : ""}`}
            style={{ minWidth: '70px' }}
            onClick={handleFilterLoad} // Call handleFilter directly
            disabled={!showAdvanced || !isFilterButtonEnabled()}
          >
            Filter
          </button>
          </div>
        )}

        {(showAdvanced && isFilterButtonEnabled() && Object.keys(formValues).length > 0) && (
          <div className="relative w-full md:w-auto">
            <button
              className="min-h-[46px] text-gray-800 border bg-gray-200 border-gray-300 rounded-lg px-4 py-2 transition-colors duration-200 hover:bg-gray-300 disabled:cursor-not-allowed disabled:opacity-50"
              onClick={handleClear}
              disabled={Object.keys(formValues).length < 1}
            >
              Clear
            </button>
            <div className={`absolute top-0 right-0 -mt-2 -mr-2 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center ${countActiveFilters > 0 ? "bg-green-500" : "bg-blue-500"}`}>
              {countActiveFilters}
            </div>
          </div>
        )}
      </div> */}
      <div className="flex md:flex-row md:justify-end gap-2 md:space-y-0 md:space-x-2">
        <button
          className="save-btn w-fit md:w-auto px-2 !h-[40px] md:!h-[46px] "
          onClick={() => setShowAdvanced(!showAdvanced)}
          style={{ fontWeight: "450" }}
        >
          <span className="flex items-center justify-center pl-2">
            {/* Text for medium and up */}
            <span className="hidden md:flex items-center">
              {showAdvanced ? (
                <>
                  Hide Advanced <ChevronUpIcon className="ml-2 w-4 h-4" />
                </>
              ) : (
                <>
                  Show Advanced <ChevronDownIcon className="ml-2 w-4 h-4" />
                </>
              )}
            </span>

            {/* Icon only for small screens */}
            <span className="flex md:hidden items-center space-x-1">
              <FunnelIcon className="w-5 h-5" />
              {showAdvanced ? (
                <ChevronUpIcon className="w-5 h-5" />
              ) : (
                <ChevronDownIcon className="w-5 h-5" />
              )}
            </span>
          </span>
        </button>

        {showAdvanced && isFilterButtonEnabled() && (
          <>
            {/* Small screens - icon only */}
            <button
              className="save-btn !flex md:!hidden items-center justify-center"
              onClick={handleFilterLoad}
              disabled={!showAdvanced || !isFilterButtonEnabled()}
              title="Filter"
            >
            <CheckIcon className="w-6 h-6" />            
            </button>

            {/* Medium and up - full button */}
            {/* <div className="hidden md:flex"> */}
              <button
                className="filter-btn save-btn !hidden md:!flex items-center justify-center h-8"
                onClick={handleFilterLoad}
                disabled={!showAdvanced || !isFilterButtonEnabled()}
              >
                Filter
              </button>
            {/* </div> */}
          </>
        )}

        {showAdvanced && isFilterButtonEnabled() && Object.keys(formValues).length > 0 && (
          <>
            <div className="cancel-btn md:hidden relative">
              <button
                className="cancel-btn  flex items-center justify-center"
                onClick={handleClear}
                disabled={Object.keys(formValues).length < 1}
                title="Clear"
              >
                <ArrowPathIcon className="w-6 h-6 text-black-600" />
              </button>
               <div className={`absolute top-0 right-0 -mt-2 -mr-2 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center ${countActiveFilters > 0 ? "bg-green-500" : "bg-blue-500"}`}>
                {countActiveFilters}
              </div>
            </div>

            {/* Medium and up - full button */}
            <div className="hidden md:flex relative">
              <button
                className="cancel-btn h-8 text-gray-800 border bg-gray-200 border-gray-300 rounded-lg px-4 py-0 transition-colors duration-200 hover:bg-gray-300 disabled:cursor-not-allowed disabled:opacity-50"
                onClick={handleClear}
                disabled={Object.keys(formValues).length < 1}
              >
                Clear
              </button>
              <div className={`absolute top-0 right-0 -mt-2 -mr-2 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center ${countActiveFilters > 0 ? "bg-green-500" : "bg-blue-500"}`}>
                {countActiveFilters}
              </div>
            </div>
          </>
        )}
      </div>

      {showAdvanced && headers && (
        <div className="overflow-x-auto rounded-md mt-2 block absolute left-0 right-0">
          <div className="flex space-x-2 p-1">
            {headers.map(
              (header) =>
                header !== "modified_by" &&
                header !== "modified_date" &&
                header !== "actions_history" &&
                header !== "carrier_rate_plans" &&
                header !== "send_to_carrier" &&
                header !== "send_to_customer" &&
                header !== "pushed_charges" &&
                headerMap[header]?.[0] !== "Change Details" &&
                headerMap[header]?.[0] !== "Details" &&
                headerMap[header]?.[0] !== "Session Details" &&
                headerMap[header]?.[0] !== "Push Charges Details" &&
                !(header === "iccid" && tableName === "status_history") &&
                !(header === "actions" && tableName === "Private_Networks")&& (
                  <div className="flex-none w-64" key={header}>
                    {isNumericField(header) ? (
                       (() => {
                        const SelectProps = {
                          mode: "multiple" as "multiple",
                          placeholder: headerMap ? headerMap[header]?.[0] : "",
                          open: openRangeDropdown === header,
                          onDropdownVisibleChange: (open: boolean) => setOpenRangeDropdown(open ? header : null),
                          value: formValues[header] || [],
                          className: "w-full",
                          maxTagCount: 1,
                          maxTagPlaceholder: (omittedValues: any[]) => `+${omittedValues.length}`,
                          tagRender: (props: any) => {
                            const { label, closable, onClose } = props;
                            let displayValue = label;
                            
                            if (label.includes(':')) {
                              const [min, max] = label.split(':');
                              if (min && max) {
                                displayValue = `${formatValueWithDollar(min, header)} to ${formatValueWithDollar(max, header)}`;
                              } else if (min) {
                                displayValue = `≥ ${formatValueWithDollar(min, header)}`;
                              } else if (max) {
                                displayValue = `≤ ${formatValueWithDollar(max, header)}`;
                              }
                            } else {
                              displayValue = formatValueWithDollar(label, header);
                            }
                      
                            const handleRemove = () => {
                              const newValues = formValues[header]?.filter((val: any) => val !== label);
                              handleSelectChange(header, newValues);
                            };
                      
                            return (
                              <span
                                className="inline-flex items-center text-ellipsis px-2 py-1 overflow-hidden whitespace-nowrap relative bg-white shadow-lg rounded-lg max-w-[185px]"
                                title={displayValue}
                              >
                                {displayValue}
                                {closable && <CloseOutlined className="ml-2" onClick={handleRemove} />}
                              </span>
                            );
                          },
                          dropdownRender: () => renderRangeDropdown(header),
                          suffixIcon: <ChevronDownIcon className="ml-2 w-4 h-4" />,
                          // Temporary input value for search
                          onSearch: (inputValue: string) => {
                            if (inputValue.trim() === "") return;
                        
                            setSearchInput((prev) => ({
                              ...prev,
                              [header]: inputValue,
                            }));
                          },
                        
                          // Handle key press to add selected value
                          onKeyDown: (event: React.KeyboardEvent) => {
                            if (event.key === 'Enter') {
                              const inputValue = searchInput[header]?.trim();
                              if (inputValue && !formValues[header]?.includes(inputValue)) {
                                handleSelectChange(header, [...(formValues[header] || []), inputValue]);
                                setSearchInput((prev) => ({ ...prev, [header]: "" })); // Clear input after adding
                              }
                            }
                          },
                        };
                      
                        return <Select {...SelectProps} />;              
                      })()
                    ) : (
                      <Select
                        mode="multiple"
                        placeholder={headerMap ? headerMap[header]?.[0] : ""}
                        onChange={(value: any[]) => {
                          handleSelectChange(header, value); // ✅ Corrected logic
                          if (value.length === 0) {
                            handleSearch(header, "");
                          }
                        }}
                        onDropdownVisibleChange={(open) => handleDropdownVisibleChange(header, open)}
                        open={openDropdown === header}
                        value={formValues[header] || []}
                        className="w-full text-ellipsis overflow-hidden whitespace-nowrap adv-filter-drp"
                        maxTagCount={1}
                        maxTagPlaceholder={(omittedValues) => `+${omittedValues.length}`}
                        tagRender={(props) => {
                          const { label, closable, onClose } = props;
                          const labelString = String(label);
                          const truncatedLabel = labelString.length > 190 ? `${labelString.slice(0, 187)}...` : labelString;
                          const allSelectedLabels = formValues?.[header]?.join(", ");
                          return (
                            <span
                              className="inline-flex items-center text-ellipsis px-1 py-1 overflow-hidden whitespace-nowrap  bg-white relative shadow-lg rounded-lg max-w-[185px] selected-value"
                            title={`${allSelectedLabels}`}
                            >
                              {truncatedLabel}
                              {closable && <CloseOutlined onClick={onClose} />}
                            </span>
                          );
                        }}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            const previouslySelected = formValues[header] || [];
                            const currentOptions =
                              filteredOptions[header]?.length > 0
                                ? filteredOptions[header]
                                : options[header];
                        
                            // Append only newly unselected options
                            const newSelections = currentOptions.filter(
                              (item) => !previouslySelected.includes(item)
                            );
                        
                            handleSelectChange(header, [...previouslySelected, ...newSelections]);
                          }
                        }}
                        
                        showSearch={!loading[header]} // Disable search input when loading                        
                        filterOption={false}
                        onSearch={(input) => handleSearch(header, input)}
                        onFocus={() => handleFocus(header)}
                        autoClearSearchValue={loading[header]?true:false}
                        // onBlur={() => {
                        //   // ✅ Reapply the search input to persist text after blur
                        //   handleSearch(header, searchInput[header]);
                        // }}
                        // onBlur={() => handleSearch(header, "")} // Call handleSearch with empty input on blur
                        searchValue={searchInput[header]}
                        // searchValue={loading[header] ? "" : searchInput[header]}
                        dropdownRender={(menu) => (
                          <div className="relative bg-white shadow-lg rounded-lg max-w-full adv-filter-drp-div">
                            {options[header]?.length > 0 && (
                              <Checkbox
                                indeterminate={
                                  formValues[header]?.length > 0 &&
                                  formValues[header]?.length <
                                  (filteredOptions[header]?.length || options[header]?.length)
                                }
                                // checked={
                                //   formValues[header]?.length ===
                                //   (filteredOptions[header]?.length || options[header]?.length)
                                // }
                                checked = {checkSelectAll(header)}
                                onChange={(e) => {
                                  const isChecked = e.target.checked;

                                  const currentOptions =
                                    filteredOptions[header]?.length
                                      ? filteredOptions[header]
                                      : options[header];

                                  const selectedOptions = formValues[header] || [];

                                  let updatedValues;

                                  if (isChecked) {
                                    updatedValues = Array.from(
                                      new Set([...selectedOptions, ...currentOptions])
                                    );
                                  } else {
                                    // Remove only filtered options, keep others
                                    updatedValues = selectedOptions.filter(
                                      (opt: any) => !currentOptions.includes(opt)
                                    );
                                  }

                                  handleSelectChange(header, updatedValues);
                                }}

                                className="transform scale-100 px-2 adv-list-item"
                                style={{ width: '100%', overflowY: 'auto' }}
                              >
                                Select All
                              </Checkbox>
                            )}

                            {loading[header] ? (
                              <div className="flex justify-center p-4">
                                <Spin />
                              </div>
                            ) : (
                              <VirtualList
                                className="p-2"
                                data={
                                  filteredOptions[header]?.slice(0, visibleOptions[header] || 20) ||
                                  options[header]?.slice(0, visibleOptions[header] || 20)
                                }
                                height={250}
                                itemHeight={0}
                                itemKey="value"
                                onScroll={(e) => {
                                  const { scrollTop, scrollHeight, clientHeight } = e.currentTarget;
                                  const isBottom = Math.abs(scrollHeight - scrollTop - clientHeight) < 1;
                                  if (isBottom) {
                                    loadMoreOptions(header);
                                  }
                                }}
                              >
                                {(item) => (
                                  <span className="mb-2">
                                    <Checkbox
                                      key={item}
                                      checked={formValues[header]?.includes(item)}
                                      onChange={(e) => handleCheckboxChange(header, item, e.target.checked)}
                                      className="inline-flex mr-2 adv-list-item "
                                    >
                                      {item}
                                    </Checkbox>
                                  </span>
                                )}
                              </VirtualList>
                            )}
                          </div>
                        )}
                        suffixIcon={<ChevronDownIcon className="ml-2 w-4 h-4" />}
                      />
                    )}
                  </div>
                )
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default AdvancedMultiFilter;