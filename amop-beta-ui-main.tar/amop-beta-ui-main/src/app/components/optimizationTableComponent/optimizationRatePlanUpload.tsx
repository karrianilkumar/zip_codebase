import { Modal, Input, notification, Spin } from 'antd';
import React, { useCallback, useEffect, useState } from 'react';
import { ENV_ROUTES } from '../routes/route_constants';
import { useAuth } from '../auth_context';
import axios from 'axios';
import { getCurrentDateTime } from '../header_constants';
import { useOptimizationStore } from '@/app/stores/optimizationStore';
import { fireSideCannons } from '../confetti';


interface RatePlanUploadProps {
    onClose: () => void; // To close the modal
    isOpen: boolean;
}

const messageStyle = {
    fontSize: "14px",
    fontWeight: "bold",
    padding: "16px",
};

const RatePlanUploadModal: React.FC<RatePlanUploadProps> = ({ onClose, isOpen }) => {
    const [loading, setLoading] = useState<boolean>(false);
    const [startDisable, setStartDisable] = useState<boolean>(false);
    const [billPeriodError, setBillPeriodError] = useState<boolean>(false);
    const [cardsToOptimize, setCardsToOptimize] = useState<string | number>('');
    const [cardsToOChange, setCardsToChange] = useState<string | number>('');
    const { username, partner, role, token, selectedDb,metaData, firstLastName, sessionId } = useAuth();
    const { optimizationRow, optimizationType } = useOptimizationStore()

    useEffect(() => {
        if (isOpen) {
            const bill_period_start = optimizationRow?.billing_period_start_date || '';
            const bill_period_end = optimizationRow?.billing_period_end_date || '';
            function checkBillPeriod() {
                // Parse the strings into Date objects
                const startDate = new Date(bill_period_start);
                const endDate = new Date(bill_period_end);

                // Compare dates and set error flag
                if (endDate < startDate) {
                    setBillPeriodError(true)
                } else {
                    setBillPeriodError(false)
                }
            }

            // Run the check
            checkBillPeriod();
            fetchRatePlanUploadData()
        }
    }, [isOpen]);
    useEffect(() => {
        const convertToNumber = (value: any) => {
            let numericData = value && typeof value === 'number' ? value : Number(value);
            let normalizedValue = 0;

            if (!isNaN(numericData)) {
                normalizedValue = Math.max(0, Math.min(100, numericData));
            }
            return normalizedValue
        }
        const cards_optimize = convertToNumber(cardsToOptimize)
        const cards_change = convertToNumber(cardsToOChange)

        if (cards_optimize === 0 || cards_change === 0) {
            setStartDisable(true)
        }
        else {
            setStartDisable(false)
        }
    }, [cardsToOptimize, cardsToOChange]);


    const fetchRatePlanUploadData = async () => {
        try {
            setLoading(true)
            const url = ENV_ROUTES.OPTIMIZATION;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_rate_plan_upload_pop_up_values",
                role_name: role,
                parent_module: "Optimization",
                module_name: "Optimization",
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                instance_id: optimizationRow?.instance_id || '',
                service_provider_id: optimizationRow?.service_provider_id || '',
                billing_period_start_date: optimizationRow?.billing_period_start_date || '',
                billing_period_end_date: optimizationRow?.billing_period_end_date || '',

            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                const total_sim_cards_to_optimize = parsedData?.total_sim_cards_to_optimize || '0'
                setCardsToOptimize(total_sim_cards_to_optimize)
                const sim_cards_to_change = parsedData?.sim_cards_to_change || '0'
                setCardsToChange(sim_cards_to_change)
            }
            // addLog('BulkChange Table Data Processing Data Completed');
        } catch (error) {
            console.error("Error fetching data:", error);
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        } finally {
            setLoading(false)
        }
    };

    const submitRatePlanUpload = async () => {
        try {
            setLoading(true)
            const url = ENV_ROUTES.OPTIMIZATION;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/rate_plan_upload",
                role_name: role,
                parent_module: "Optimization",
                module_name: "Optimization",
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                instance_id: [optimizationRow?.instance_id || ''],
                service_provider_id: optimizationRow?.service_provider_id || '',
                billing_period_start_date: optimizationRow?.billing_period_start_date || '',
                billing_period_end_date: optimizationRow?.billing_period_end_date || '',
                carrier_assignments_queued:cardsToOChange || '0',
                optimization_list_view_id: optimizationRow?.id || '',

            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                // Modal.error({
                //     title: 'Data Fetch Error',
                //     content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                //     centered: true,
                // });
            } else {
                notification.success({
                    message: "Success",
                    description: " Successfully Started Rate Plan Upload!",
                    style: messageStyle,
                    placement: "top",
                });
                fireSideCannons()
            }
            // addLog('BulkChange Table Data Processing Data Completed');
        } catch (error) {
            console.error("Error fetching data:", error);
            // Modal.error({
            //     title: 'Data Fetch Error',
            //     content: error instanceof Error ? error.message : 'An unexpected error occurred while uploading data. Please try again.',
            //     centered: true,
            // });
        } finally {
            setLoading(false)
            onClose()
        }
    };

    return (
        <>
            <Modal
                title="Rate Plan Upload"
                visible={isOpen}
                onCancel={onClose}
                centered
                footer={
                    <div className='flex justify-center space-x-4'>
                        <button key="cancel" onClick={onClose} className="cancel-btn">Cancel</button>
                        <button
                            key="update"
                            className={`${startDisable ? 'cancel-btn cursor-not-allowed' : ' save-btn'}`}
                            onClick={submitRatePlanUpload}
                            disabled={startDisable}>Start</button>
                    </div>
                }
            >
                <>
                    {loading ? (
                        <div className="flex justify-center items-center h-[200px]">
                            <Spin size="large" />
                        </div>
                    ) : (
                        <div className='h-[200px] mt-8'>
                            <span>{`Pressing 'Start' will upload Rate Plan changes for the billing period from ${optimizationRow?.billing_period_start_date || ''} to ${optimizationRow?.billing_period_end_date || ''}.`}</span>
                            <div className='mt-4'>
                                <span className='font-[18px] font-semibold'>{`Total SIM cards optimized: ${cardsToOptimize}`}</span>

                            </div>
                            <div className='my-4'>
                                <span className='font-[18px] font-semibold'>{`SIM cards to change: ${cardsToOChange}`}</span>

                            </div>
                            {billPeriodError && <span className='text-red-500'>This Billing Period has closed. Are you sure you want to update cards to Rate Plans from a closed Billing Period?</span>}
                        </div>
                    )}

                </>
            </Modal>
        </>
    );
};

export default RatePlanUploadModal;
