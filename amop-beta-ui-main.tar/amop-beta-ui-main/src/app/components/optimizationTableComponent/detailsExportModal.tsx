import { Modal, Input, notification, Spin } from 'antd';
import React, { useCallback, useEffect, useState } from 'react';
import Select from 'react-select';
import { DropdownStyles } from '../css/dropdown';
import { ENV_ROUTES } from '../routes/route_constants';
import { useAuth } from '../auth_context';
import axios from 'axios';
import { getCurrentDateTime } from '../header_constants';
import { useOptimizationStore } from '@/app/stores/optimizationStore';
import { fireSideCannons } from '../confetti';

// Utility function to map strings to select options
const mapToSelectOptions = (options: string[]) =>
    options.map((option) => ({ value: option, label: option }));

interface ExportProps {
    rowData: any;
    onClose: () => void; // To close the modal
    isOpen: boolean;
    setLoading: (loading: boolean) => void;
    errorsLength: any;
}

const messageStyle = {
    fontSize: "14px",
    fontWeight: "bold",
    padding: "16px",
};
const reportsMap: any = {
    "Optimization Summary Report": "optimization_summary_report",
    // "Client listing report": "client_listing_report",
    "Customer Charge Break Down": "customer_charge_breakdown_report",
    "Device Assignments by Customer Report": "device_assignments_by_customer_report",
    "Error Breakdown": "error_breakdown_report",
    "Session Device Assignment Report": "session_device_assignments_report"
}
const ExportDetailsModal: React.FC<ExportProps> = ({ rowData, onClose, isOpen, setLoading, errorsLength }) => {
    // Sample data as arrays of strings
    const [reportOptions, setReportOptions] = useState<string[]>([
        "All",
        "Optimization Summary Report",
        "Customer Charge Break Down",
        "Device Assignments by Customer Report",
        "Error Breakdown",
        "Session Device Assignment Report",
    ]);
    // State variables for selected values
    const [selectedReport, setSelectedReport] = useState<string | null>("All");
    const { username, partner, role, token, selectedDb,metaData, firstLastName,sessionId} = useAuth();
    const { optimizationRow, optimizationType } = useOptimizationStore()

    useEffect(() => {
        setReportOptions(() => {
            console.log("optimizationRow",optimizationRow)
            const baseOptions = [
                "All",
                "Device Assignments by Customer Report",
                "Optimization Summary Report",
                "Session Device Assignment Report",
            ];
            // let updatedOptions = [...baseOptions, "Customer Charge Break Down"];
            let updatedOptions = [...baseOptions];

            if (errorsLength > 0) {
                updatedOptions.push("Error Breakdown"); // Add "Error Breakdown" if errorsLength > 0
            }
    
            if (optimizationRow?.push_charge_page === "true" 
                || optimizationRow?.push_charge_page === true 
                || optimizationRow?.push_charge_page === "True") {
                // return baseOptions; // Exclude "Customer Charge Break Down"
                updatedOptions.push("Customer Charge Break Down"); // Include "Customer Charge Break Down"
            }
    
            
    
            return updatedOptions.sort(); // Return sorted options
        });
    }, [optimizationRow]);
    

    const pollExportStatus = async () => {
        try {

            const export_url = ENV_ROUTES.OPTIMIZATION;
            const export_data = {
                tenant_name: partner || "default_value",
                username,
                path: "/get_export_status",
                role_name: role,
                parent_module: "Optimization",
                module_name: optimizationType,
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
            };

            const export_response = await axios.post(export_url, { data: export_data });
            const export_parsedData = JSON.parse(export_response.data.body);

            if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
                const s3Url = export_parsedData?.export_status_data?.url || null;
                if (s3Url) {
                    window.location.href = s3Url;
                    notification.success({
                        message: "Success",
                        description: "Successfully exported!",
                        style: messageStyle,
                        placement: "top",
                    });
                    fireSideCannons()
                } else {
                    Modal.error({
                        title: "Export Error",
                        content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
                        centered: true,
                    });
                }
                return true; // Stop polling
            }

            if (export_parsedData?.export_status_data?.status_flag === "Failure") {
                Modal.error({
                    title: "Export Error",
                    content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
                    centered: true,
                });
                return true; // Stop polling
            }

            return false; // Continue polling
        } catch (error) {
            // Modal.error({
            //     title: "Export Error",
            //     content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
            //     centered: true,
            // });
            return true; // Stop polling
        }
    };
    const startPolling = async () => {
        let isPollingComplete = false;

        while (!isPollingComplete) {
            isPollingComplete = await pollExportStatus();
            if (!isPollingComplete) {
                await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
            }
        }
    };

    const handleExport = async () => {
        setLoading(true);
        onClose()
        try {
            const url = ENV_ROUTES.OPTIMIZATION;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_optimization_details_reports_data",
                role_name: role,
                parent_module: "Optimization",
                module_name: "Optimization",
                optimization_type: optimizationType,
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                session_id: rowData?.session_id || '',
                report_type: selectedReport === "All" ? "All Reports" : selectedReport && reportsMap[selectedReport] || null,
                pushed_charges:selectedReport === "All" ?optimizationRow?.pushed_charges:'false',
                errors:errorsLength > 0 ? 'true' : 'false'

            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === true) {
                await startPolling();

            } else {
                await startPolling();
            }

        } catch (error) {
            await startPolling();
        } finally {
            setLoading(false);
        }
    };

    // Handlers for when an option is selected
    const handleReportChange = (selectedOption: any) => {
        if (selectedOption) {
            const value = selectedOption.value
            setSelectedReport(value);
        }
        else if (selectedOption === null) {
            setSelectedReport(null)
        }
    };

    return (
        <>
            <Modal
                title="Export"
                visible={isOpen}
                onCancel={onClose}
                centered
                className='h-[150px]'
                footer={
                    <div className='flex justify-center space-x-4'>
                        <button key="cancel" onClick={onClose} className="cancel-btn">Cancel</button>
                        <button key="update" className="save-btn" onClick={handleExport}>Download</button>
                    </div>
                }
            >
                <>

                    <div className='space-y-3'>
                        <div className="form-group">
                            <label className='field-label'>Report Types</label>
                            <Select
                                options={mapToSelectOptions(reportOptions)}
                                value={selectedReport ? { label: selectedReport, value: selectedReport } : null}
                                onChange={handleReportChange}
                                styles={DropdownStyles}
                            // placeholder="Select Rate Plan"
                            />
                        </div>
                    </div>


                </>
            </Modal>
        </>
    );
};

export default ExportDetailsModal;
