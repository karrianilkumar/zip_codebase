"use client"
import React from 'react';
import { Progress } from 'antd';

interface ProgressBarProps {
    value: number;
}

const ProgressBar: React.FC<ProgressBarProps> = ({ value }) => {

    let numericData = value && typeof value === 'number' ? value : Number(value);
    let normalizedValue = 0;

    if (!isNaN(numericData)) {
        normalizedValue = Math.max(0, Math.min(100, numericData));
    }


    return (
        <div className='flex'>
            <Progress
                percent={normalizedValue}
                status="active"
                showInfo={false}
                strokeWidth={12}
                className='w-[100px]'
            />
            <span className='ml-2 flex'>{normalizedValue}</span>
        </div>
    );
};

export default ProgressBar;
