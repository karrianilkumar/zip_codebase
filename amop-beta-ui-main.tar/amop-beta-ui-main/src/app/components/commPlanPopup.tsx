"use client";
import React, { useEffect, useState } from "react";
import { Input, Button, Modal, Spin, message, notification } from "antd";
import Select from "react-select";
import { useAuth } from "./auth_context";
import { getCurrentDateTime } from "./header_constants";
import axios from "axios";
import { ENV_ROUTES } from "./routes/route_constants";
import { DropdownStyles } from "./css/dropdown";
import { fireSideCannons } from "@/app/components/confetti";

interface CommPlanModalProps {
  isOpen: boolean;
  onClose: () => void;
  rowData: any;
  tableData?: any;
  generalFields: any;
  mode: "create" | "edit"; 
}

const messageStyle = {
  fontSize: '14px',
  fontWeight: 'bold',
  padding: '16px',
};

const CommPlanModal: React.FC<CommPlanModalProps> = ({
  isOpen,
  onClose,
  rowData,
  generalFields,mode
}) => {
  const [filteredRatePlans, setFilteredRatePlans] = useState<any[]>([]);
  const [communicationPlanName, setCommunicationPlanName] = useState("");
  const [aliasName, setAliasName] = useState("");
  const [serviceProviderName, setServiceProviderName] = useState("");
  const [selectedRatePlans, setSelectedRatePlans] = useState<any[]>([]);
  const [ratePlanCodeOptions, setRatePlanCodOptions] = useState<any[]>([]);
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);
  const [parsedData, setParsedData] = useState<any>(null);
  const [rateplanOptions, setRateplanOptions] = useState<any[]>([]);
  const ratePlansMap = generalFields?.carrier_rate_plan || [];
  const [loading, setLoading] = useState(false);
  const { username, tenantNames, role, partner, settabledata, token, selectedDb,metaData, firstLastName,sessionId} = useAuth();
  const [formData, setFormData] = useState<any>({});
  const [validationErrors, setValidationErrors] = useState<{
    communication_plan_name?: string;
    service_provider?: string;
  }>({});

useEffect(() => {
  if (isOpen) {
    if (mode === "edit" && rowData) {
      setCommunicationPlanName(rowData.communication_plan_name || "");
      setAliasName(rowData.alias_name || "");
      setServiceProviderName(rowData.service_provider_name || "");
      setFormData(rowData || {});
    } else if (mode === "create") {
      setCommunicationPlanName("");
      setAliasName("");
      setServiceProviderName("");
      setSelectedRatePlans([]);
      setFormData({});
    }
  }
}, [isOpen, mode, rowData]);
useEffect(() => {
  if (isOpen && mode === "edit" && rowData && rateplanOptions.length > 0) {

    const parseRatePlans = (value: any): string[] => {
      if (!value) return [];

      // Already an array
      if (Array.isArray(value)) {
        return value
          .map((p) => String(p))
          .filter((p) => p && p.toLowerCase() !== "none");
      }

      if (typeof value !== "string") return [];

      const raw = value.trim();
      if (!raw) return [];

      let existingPlans: string[] = [];

      try {
        if (raw.startsWith("[")) {
          try {
            const jsonParsed = JSON.parse(raw);
            if (Array.isArray(jsonParsed)) {
              existingPlans = jsonParsed;
            } else {
              existingPlans = [];
            }
          } catch {
            const inside = raw.substring(1, raw.length - 1);
            existingPlans = inside
              .split(",")
              .map((p) => p.trim())
              .filter(Boolean);
          }
        } else if (raw.startsWith("{") && raw.endsWith("}")) {
          existingPlans = raw
            .replace(/[{}]/g, "")
            .split(",")
            .map((p) => p.trim())
            .filter(Boolean);
        } else {
          existingPlans = raw
            .split(",")
            .map((p: string) => p.trim())
            .filter(Boolean);
        }
      } catch (err) {
        console.error("Failed to parse rate plans:", err);
        return [];
      }

      // Safe cleanup
      return existingPlans.filter((p) => {
        const str = String(p).trim().toLowerCase();
        return str !== "" && str !== "none";
      });
    };
    const rawPlans = rowData.carrier_rate_plans ?? "";
    let existingPlans: string[] = parseRatePlans(rawPlans);

    // try {
    //   const raw = String(rawPlans).trim();

    //   if (!raw) {
    //     existingPlans = [];
    //   }

    //   // Case 1: JSON array → ["A", "B"]
    //   else if (raw.startsWith("[")) {

    //     try {
    //       // Try normal JSON first
    //       const parsed = JSON.parse(raw);
    //       if (Array.isArray(parsed)) {
    //         existingPlans = parsed.map((x) => String(x).trim());
    //       } else {
    //         existingPlans = [];
    //       }
    //     } catch {
    //       // Fake array: [A, B, C]
    //       const inside = raw.slice(1, -1);
    //       existingPlans = inside
    //         .split(",")
    //         .map((p: string) => p.trim());
    //     }
    //   }

    //   // Case 2: {A, B, C}
    //   else if (raw.startsWith("{") && raw.endsWith("}")) {
    //     existingPlans = raw
    //       .slice(1, -1)
    //       .split(",")
    //       .map((p: string) => p.trim());
    //   }

    //   // Case 3: "A, B, C"
    //   else {
    //     existingPlans = raw
    //       .split(",")
    //       .map((p: string) => p.trim());
    //   }
    // } catch (err) {
    //   console.error("Failed to parse carrier_rate_plans:", err);
    //   existingPlans = [];
    // }

    // Final cleanup: remove empty/null/"None"
    existingPlans = existingPlans.filter((p) => {
      if (!p) return false;                           // null, undefined, ""
      const s = String(p).trim().toLowerCase();
      return s !== "" && s !== "none";
    });


    // Clean existingPlans first (remove null, empty, "none")
const cleanedPlans = existingPlans.filter((p) => {
  if (!p) return false;
  return p.toLowerCase() !== "none";
});

const initialSelectedPlans = rateplanOptions.filter((option) => {
  const val = (option?.value || "").trim();

  // Skip if the option itself is "None"
  if (val.toLowerCase() === "none") return false;

  // Direct match
  if (cleanedPlans.includes(val)) {
    return true;
  }

  // Extract code part after "--"
  const code = val.includes("--")
    ? val.split("--")[0]?.trim() || ""
    : val;

  // Skip if code is "None"
  if (code.toLowerCase() === "none") return false;

  return cleanedPlans.includes(code);
});

      console.log("existingPlans-",existingPlans)
      console.log("rateplanOptions-",rateplanOptions)
      console.log("initialSelectedPlans-",initialSelectedPlans)
    setSelectedRatePlans(initialSelectedPlans);
  }
}, [isOpen, mode, rowData, rateplanOptions]);




const carrierRatePlans = (() => {
  if (typeof rowData?.carrier_rate_plans === "string") {
    let parsedPlans: string[] = [];
    try {
      // remove { } and split by comma
      parsedPlans = rowData.carrier_rate_plans
        .replace(/[{}]/g, "") // remove { and }
        .split(",")           // split into array
        .map((plan:any) => plan.trim()) // remove extra spaces
        .filter((plan:any) => plan.length > 0); // clean empty values
    } catch (err) {
      console.log("Parse error:", err);
    }
    return parsedPlans;
  }

  if (Array.isArray(rowData?.carrier_rate_plans)) {
    return rowData.carrier_rate_plans;
  }

  return [];
})();


  const handleChange = (name: string, value: any) => {
    setFormData((prevState: any) => ({
      ...prevState,
      [name]: value,
    }));
  };
  const handleSelectChange = (name: string, value: any) => {
    setFormData((prevState: any) => ({
      ...prevState,
      [name]: JSON.stringify(value),
    }));
  };
  // Filter rate plans based on the selected service provider name
  useEffect(() => {
    if (serviceProviderName) {
      const filteredPlans = ratePlansMap.filter(
        (plan: any) => plan.service_provider === serviceProviderName
      );
      setFilteredRatePlans(
        filteredPlans.map((plan: any) => ({
          value: plan.rate_plan_code,
          label: plan.rate_plan_code,
        }))
      );
    }
  }, [serviceProviderName, ratePlansMap]);

  // Set initial selected rate plans
  useEffect(() => {
    const initialSelectedPlans = carrierRatePlans.map((plan: string) => ({
      value: plan,
      label: plan,
    }));
    // setSelectedRatePlans(initialSelectedPlans);
  }, [rowData]);

  const handleCancel = () => {
    onClose();
    setValidationErrors({});
  };

  useEffect(() => {
    const fetchData = async () => {
        setLoading(true);
      try {
        const url = ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/rate_plan_dropdown_data",
          service_provider: serviceProviderName,
          role_name: role,
          parent_module: "Sim Management",
          module_name: "Communication plans",
          feature_module_name: "Communication Plans",
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
                ...metaData,
          sessionID: sessionId,
        };
  
        const response = await axios.post(url, { data });
        const fetchedData = JSON.parse(response.data.body);
        console.log(fetchedData, "fetchedOptions");
        setParsedData(fetchedData);
  
        if (fetchedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content: fetchedData.message || "An error occurred while fetching Inventory data. Please try again.",
            centered: true,
            onOk: handleCancel,
          });
        } else {
          // const sortedOptions = Object.entries(fetchedData.carrier_rate_plans).reduce(
          //   (acc:any, [carrier, plans]) => {
          //     acc[carrier] = (plans as string[]).sort(); // Sort the array of plans for each carrier
          //     return acc;
          //   },
          //   {}
          // );
  
          // Carrier Rate Plans (names)
        const sortedOptions = fetchedData?.carrier_rate_plans || {};
        const filteredOptions: string[] = sortedOptions[serviceProviderName] || [];
        console.log("formattedOptions",sortedOptions[serviceProviderName])
        console.log("filteredOptions",filteredOptions)
        // Format plan names for dropdown
        const formattedOptions = Array.from(new Set(filteredOptions)).map((plan) => ({
          value: plan,
          label: plan,
        }));
        console.log("formattedOptions",formattedOptions)

        setRateplanOptions(formattedOptions);

        // Carrier Rate Plan Codes
        const ratePlanCodeOptions = fetchedData?.carrier_rate_plan_codes || {};
        const filteredCodeOptions: string[] = ratePlanCodeOptions[serviceProviderName] || [];
        setRatePlanCodOptions(filteredCodeOptions);

        // Map selected rate plan codes (carrierRatePlans) to their corresponding plan names
        const selectedRatePlanCodes: string[] = carrierRatePlans || [];

        // Match codes to plans based on index
        const selectedRatePlans = selectedRatePlanCodes.map((code, index) => {
          const plan = filteredOptions[index]; // align by index
          return {
            value: plan || code, // fallback to code if no plan found
            label: plan || code,
          };
        });

        setSelectedRatePlans(selectedRatePlans);


    console.log("selectedRatePlanCodes",selectedRatePlanCodes)
    console.log("selectedRatePlans",selectedRatePlans)
    console.log("initialSelectedPlans",selectedRatePlans)
    // console.log("selectedRatePlanCodes",selectedRatePlanCodes)

    setSelectedRatePlans(selectedRatePlans);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        Modal.error({
          title: "Data Fetch Error",
          content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
          centered: true,
          onOk: handleCancel,
        });
      } finally {
        setLoading(false);
      }
    };
  
    if (isOpen) {
      console.log(isOpen, "visible check")
      fetchData();
    }
  }, [isOpen]);

  useEffect(()=>{
    const sortedOptions = parsedData?.carrier_rate_plans || []
          // Filter the options based on the selected service provider
          const filteredOptions = sortedOptions[serviceProviderName] || [];
          const formattedOptions = filteredOptions.map((plan: string) => ({
            value: plan,
            label: plan,
          }));
  
          setRateplanOptions(formattedOptions);

          const rate_plan_code_options = parsedData?.carrier_rate_plan_codes || []
          // Filter the options based on the selected service provider
          const filteredCodeOptions = rate_plan_code_options[serviceProviderName] || [];
          setRatePlanCodOptions(filteredCodeOptions)

  },[serviceProviderName,parsedData])
  const handleSave = () => {
    onClose();
  };

  const showConfirmation = () => {
    if (!validateFields()) return;
    setIsConfirmationOpen(true);
  };
  const handleCancelConfirmation = () => {
    setIsConfirmationOpen(false);
  };
  const validateFields = () => {
  const errors: any = {};

  if (mode !== "edit") {
    if (!communicationPlanName.trim()) {
      errors.communication_plan_name = "Communication Plan Name is required";
    }
    if (!serviceProviderName.trim()) {
      errors.service_provider = "Service Provider Name is required";
    }
  }

  setValidationErrors(errors);
  return Object.keys(errors).length === 0; // return true if no errors
};
const callCommunicationPlanSync = async () => {
    const url = ENV_ROUTES.OPTIMIZATION_SYNC_LAMBDA;
    const data = {
      path: "/lambda_sync_jobs_",
      key_name: "communication_plan_sync",
      tenant_name:partner
    };

    try {
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
    } catch (error) {
    }

  }
  const handleConfirmEdit = async () => {
    setIsConfirmationOpen(false);
    formData["alias_name"] = aliasName;
    if(mode !== "edit"){
      formData["communication_plan_name"] = communicationPlanName;
      formData["service_provider_name"] = serviceProviderName;
    }
    const valuesList = selectedRatePlans.map((plan) => plan.value);
    // Get matching rate plan codes using the same indexes
  const selectedRatePlanCodes = valuesList.map((_, index) => ratePlanCodeOptions[index]);
  formData["carrier_rate_plans"] = valuesList;
    // formData["carrier_rate_plans"] = valuesList;
    formData["modified_by"] = firstLastName || username;
    if (mode !== "edit") {
      formData["created_by"] = firstLastName || username;
    }
    formData["is_deleted"] = "False";
    formData["is_active"] = "True";
    delete formData["carrier_rate_plans__1"];
    delete formData["modified_date"];

    const provider_id_map = parsedData?.service_provider_ids_map || {}
    const provider_id = provider_id_map[serviceProviderName] || 0
    formData["service_provider_id"] = provider_id;

    try {
      setLoading(true);
      const url =ENV_ROUTES.SIM_MANAGEMENT
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/update_sim_management_modules_data",
        role_name: role,
        parent_module: "Sim Management",
        module: "Communication plans",
        table_name: "sim_management_communication_plan",
        action: mode === "edit" ? "update" : "create",
        [mode === "edit" ? "changed_data" : "new_data"]: formData,        
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        setLoading(false);
        if (parsedData.error_type && parsedData.error_type == "Warning") {
          console.log("parsedData.error_type", parsedData.error_type)
          Modal.warning({
            title: 'Warning',
            content: parsedData.message || 'An error occurred while submitting data. Please try again.',
            centered: true,
          });
        }
        else {
    // handleSave();
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        }
      } else {
        try {
          const url =ENV_ROUTES.MODULE_MANAGEMENT;
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/get_module_data",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "Communication plans",
            feature_module_name:"Communication Plans",
            mod_pages: {
              start: 0,
              end: 100,
            },
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };

          const response = await axios.post(url, { data });

          if (parsedData.flag === false) {
            setLoading(false);

            Modal.error({
              title: "Data Fetch Error",
              content:
                parsedData.message ||
                "An error occurred while fetching data. Please try again.",
              centered: true,
            });
          } else {
            const parsedData = JSON.parse(response.data.body);
            const tableData_ =
              parsedData?.data?.sim_management_communication_plan || [];
            settabledata(tableData_);
            setLoading(false);
            const message = mode === "edit" ? "Successfully edited the record!" : "Successfully created the record!";
            notification.success({
              message: "Success",
              description: message,
              style: messageStyle,
              placement: "top",
            });
            fireSideCannons()
            callCommunicationPlanSync()
          }
        } catch (error) {
          setLoading(false);

          console.error("Error fetching data:", error);
          Modal.error({
            title: "Data Fetch Error",
            content:
              error instanceof Error
                ? error.message
                : "An unexpected error occurred while fetching data. Please try again.",
            centered: true,
          });
        } finally {
    // handleSave();
          setLoading(false);
        }
        // setLoading(false);
      }
    } catch (error) {
    // handleSave();
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    }
    finally{
      setLoading(false);
      handleSave();
    }
  };
  const modalWidth =
    typeof window !== "undefined" ? (window.innerWidth * 2.5) / 4 : 0;
  const modalHeight =
    typeof window !== "undefined" ? (window.innerHeight * 2) / 4 : 0;
  return (
    <div>
      <Modal
        visible={isOpen}
        onCancel={handleCancel}
        width={700}
        height = {500}
        centered
        style={{ 
          top: 55,
        }}
        title={
          <h3 className="popup-heading text-lg md:text-xl font-semibold">
            {mode === "edit" ? "Update Communication Plan" : "Create Communication Plan"}
          </h3>
        }
        footer={
          <div className="flex justify-center space-x-2 mt-4 md:mt-6">
            <button 
              onClick={handleCancel} 
              className="cancel-btn px-3 py-1 md:px-4 md:py-2 text-sm md:text-base"
            >
              Cancel
            </button>
            <button 
              onClick={showConfirmation} 
              className="save-btn px-3 py-1 md:px-4 md:py-2 text-sm md:text-base"
            >
              {mode === "edit" ? "Update" : "Create"}
            </button>
          </div>
        }
        
      >
        {!loading ? (
          <div className="px-2 py-1 md:px-4">
            <div className="grid grid-cols-2 gap-4">
              
             <div className="flex flex-col mb-2">
            <label className="field-label text-sm sm:text-base">
              Communication Plan Name <span className="text-red-500">*</span>
            </label>
            <Input
              disabled={mode === "edit"}
              className={`${mode === "edit" ? "non-editable-input" : "input"} w-full text-sm md:text-base`}
              placeholder="Enter Communication Plan Name"
              value={communicationPlanName}
              onChange={(e) => setCommunicationPlanName(e.target.value)}
            />
              {validationErrors["communication_plan_name"] && (
                <span className="text-red-500 text-xs sm:text-sm mt-1">
                  {validationErrors["communication_plan_name"]}
                </span>
              )}
          </div>
              <div className="flex flex-col mb-2">
              <label className="field-label text-sm sm:text-base">
                Service Provider Name<span className="text-red-500">*</span>
              </label>

              {mode === "edit" ? (
                <Input
                  className="non-editable-input w-full text-sm md:text-base"
                  disabled
                  placeholder="Enter Service Provider Name"
                  value={serviceProviderName}
                  onChange={(e) => setServiceProviderName(e.target.value)}
                />
              ) : (
                <Select
                  className="w-full"
                  styles={DropdownStyles}
                  placeholder="Select Service Provider"
                 value={serviceProviderName ? { value: serviceProviderName, label: serviceProviderName } : null}
                  onChange={(option) => {setServiceProviderName(option?.value || "");
                    setSelectedRatePlans([]);}
                  }
                     options={generalFields?.serviceprovider?.map(
                      (sp: { id: string; service_provider_name: string }) => ({
                        value: sp.service_provider_name,
                        label: sp.service_provider_name,
                      })
                    )}
                />
              )}
               {validationErrors["service_provider"] && (
                          <span className="text-red-500 text-xs sm:text-sm mt-1">
                            {validationErrors["service_provider"]}
                          </span>
                        )}
            </div>
            <div className="flex flex-col mb-2">
              <label className="field-label text-sm sm:text-base">Alias Name</label>
                <Input
                  className="input w-full text-sm md:text-base"
                  placeholder="Enter Alias Name"
                  value={ (aliasName && aliasName!=="None") ? aliasName : "" }
                  onChange={(e) => setAliasName(e.target.value)}
                />
              </div>


              <div className="flex flex-col mb-2">
                <label className="field-label text-sm sm:text-base">Rate Plans</label>
                <Select
                  isMulti
                  closeMenuOnSelect={false}
                  options={rateplanOptions}
                  value={selectedRatePlans}
                  onChange={(selectedOptions: any) => {
                    // Check if user attempts to select more than 15 rate plans
                    if (selectedOptions && selectedOptions.length > 15) {
                      // Display warning modal when limit is exceeded
                      Modal.warning({
                        title: 'Rate Plan Limit Exceeded',
                        content: 'You cannot select more than 15 rate plans.',
                        centered: true,
                      });
                    } else {
                      // Update selected rate plans if within limit
                      setSelectedRatePlans(selectedOptions);
                    }
                  }}
                  styles={DropdownStyles}
                  className="rate-plans-select w-full"
                 
                />
              </div>
            </div>
          </div>
        ) : (
          <div className="flex justify-center items-center w-full py-12">
            <Spin size={window.innerWidth <= 576 ? "default" : "large"} />
          </div>
        )}
      </Modal>
      <Modal
        title="Confirmation"
        open={isConfirmationOpen}
        onOk={handleConfirmEdit}
        onCancel={handleCancelConfirmation}
        centered
      >
        <p>Are you sure you want to {mode === "edit"? "Update" : "Create"} this Communication Plan</p>
      </Modal>
    </div>
  );
};

export default CommPlanModal;
