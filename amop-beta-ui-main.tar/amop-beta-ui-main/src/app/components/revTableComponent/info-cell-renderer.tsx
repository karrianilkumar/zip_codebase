import { FC, useEffect, useState } from "react";
import { useRouter } from 'next/navigation';
import { Tooltip } from "antd";
import { InformationCircleIcon } from "@heroicons/react/24/outline";
import { useOptimizationStore } from "@/app/stores/optimizationStore";
import { useLogoStore } from "@/app/stores/logoStore";
export const InfoCellRenderer: FC<{
  row?: any;
}> = ({ row }) => {
  const [isMounted, setIsMounted] = useState(false);
  const router = useRouter();
  const {setOptimizationRow}=useOptimizationStore()
  const setTitle = useLogoStore((state) => state.setTitle);

  useEffect(() => {
    setIsMounted(true);
  }, []);
  
  const handleClick = () => {
    if (isMounted) {
      setOptimizationRow(row)
      router.push(`/customer_charges/optimization_info`);
    }
  };


  return (
    <Tooltip title="Info">
        <InformationCircleIcon
        onClick={handleClick}
        className="h-6 w-6 text-green-500 cursor-pointer"
          />
    </Tooltip>
  );
};

