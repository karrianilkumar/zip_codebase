"use client";

import React, { useState, useEffect, useRef } from 'react';
import Pagination from '../pagination';
import { useRevStore } from '@/app/stores/revStore';
import EffectiveDate from '@/app/sim_management/revenue_assurance/effective-cell-renderer';
import { ArrowDownOutlined, ArrowUpOutlined, EyeOutlined } from '@ant-design/icons';
import { ArrowDownTrayIcon, ArrowUpTrayIcon, ChevronDownIcon, InformationCircleIcon, PencilIcon } from '@heroicons/react/24/outline';
import { EyeIcon } from "lucide-react";
import { useAuth } from '../auth_context';
import axios from 'axios';
import { getCurrentDateTime } from '../header_constants';
import { Dropdown, Modal, notification, Radio, Spin, Tooltip } from 'antd';
import { ENV_ROUTES } from '../routes/route_constants';
import DownloadModal from './downloadModal';
import RowUploadModal from '@/app/optimization_backup/optimization_row_upload';
import { InfoCellRenderer } from './info-cell-renderer';
import { useSearchStore } from '@/app/stores/searchStore';
import RowDetailsModal from '../rowDetailsModal';
import InfoModal from '@/app/super_admin/partner_addition/editPartner/InfoModal';
import { usePartnerCreationStore } from '@/app/stores/partnerCreationStore';
import {fireSideCannons} from '../confetti';
const STATUS_OPTIONS = [
    {
        value: "Open",
        label: "Open",
        bgClass: "bg-[#e7ae4b]",
    },
    {
        value: "In Progress",
        label: "In Progress",
        bgClass: "bg-blue-500",
    },
    {
        value: "Done",
        label: "Done",
        bgClass: "bg-green-500",
    },

];
interface TableComponentProps {
    headers: string[];
    headerMap: any;
    initialData: any[];
    searchQuery?: string;
    visibleColumns: string[];
    itemsPerPage: number;
    moduleName: string;
    allowedActions?: (
        | "download"
        | "upload"
        | "info-status"
    )[];
    pagination: {
        start: number;
        end: number;
        total: number;
    };
    onDateChange: (rowIndex: number, date: string | null) => void;
    advancedFilters?: any;
    height?: any;
    refreshPartnerData?: () => void;

}

const RevTableComponent: React.FC<TableComponentProps> = ({
    headers,
    headerMap,
    initialData,
    searchQuery,
    visibleColumns,
    itemsPerPage,
    moduleName,
    pagination,
    advancedFilters,
    onDateChange,
    allowedActions,
    height,
    refreshPartnerData
}) => {
    const [rowData, setRowData] = useState(initialData);
    const [currentPage, setCurrentPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [selectedRows, setSelectedRows] = useState<number[]>([]);
    const [selectAll, setSelectAll] = useState(false);
    const isFirstRender = useRef(true);
    const isFirstTableDataRender = useRef(true);
    const isFirstSearchRender = useRef(true);
    const isFirstAdvancedSearchRender = useRef(true);
    const [dates, setDates] = useState<{ [key: string]: string | null }>({});
    const [sortConfig, setSortConfig] = useState<{ key: string; direction: "ascending" | "descending"; } | null>(null);
    // Get revRows and setRevRows from the revStore
    const { revRows, setRevRows, revHeaders, setRevHeaders, isClosed, setIsClosed, showVarianceStatus } = useRevStore();
    const [loading, setLoading] = useState(false);
    const [isDownload, setIsDownload] = useState(false);
    const [downloadRowIndex, setDownloadRowIndex] = useState<number | null>(null);
    const [isUpload, setIsUpload] = useState(false);
    const [uploadRowIndex, setUploadRowIndex] = useState<number | null>(null);

    const [openPartnerInfoModal, setOpenPartnerInfoModal] = useState(false);
    const [partnerInfoModuleName, setPartnerInfoModuleName] = useState<string>("");
    const {
        setModifiedEditPartnerData,
        mainTenantEnabledModules,
        subTenantEnabledModules
    } = usePartnerCreationStore();

    console.log("Show variance", showVarianceStatus);

    const {
        username,
        tenantNames,
        role,
        partner,
        selectedPartnerModule,
        Environment,
        tabledata,
        storedpagination,
        advancedStoredpagination,
        combineAdnvaceStoredpagination,
        token,
        selectedDb,
        metaData,
        sessionId,
        serviceProviderList,
        selectedServiceProvider,
        setAdvancedStoredPagination,
        setCombineAdnvaceStoredpagination,
        setStoredPagination,
        firstLastName
    } = useAuth();
    const { searchData, advancedSearchData, combineAdnvaceSearchData, isSearchComponentCall,
        setIsSearchComponentCall } = useSearchStore();
    //Viewport height
    const [viewportHeight, setViewportHeight] = useState(window.innerHeight);
    // Add state to track screen width
    const [isSmallScreen, setIsSmallScreen] = useState(false);
    const [showRowModal, setShowRowModal] = useState<boolean>(false);
    const [showRowModalData, setShowRowModalData] = useState<any>(null);
    const [tableData, setTableData] = useState<any[]>([]);

    // Check for small screen on component mount and window resize
    useEffect(() => {
        const checkScreenSize = () => {
            setIsSmallScreen(window.innerWidth < 700);
        };

        // Initial check
        checkScreenSize();

        // Add event listener for window resize
        window.addEventListener('resize', checkScreenSize);

        // Clean up
        return () => window.removeEventListener('resize', checkScreenSize);
    }, []);


    useEffect(() => {
        setAdvancedStoredPagination(null)
        setStoredPagination(null)
        setCombineAdnvaceStoredpagination(null)
        setIsSearchComponentCall(false)
        const handleResize = () => {
            setViewportHeight(window.innerHeight);
        };

        // Add event listener for window resize
        window.addEventListener("resize", handleResize);

        // Cleanup event listener on component unmount
        return () => {
            window.removeEventListener("resize", handleResize);
        };
    }, []);


    // useEffect(() => {
    //     const newRowData = tabledata.length > 0 ? tabledata : initialData;
    //     setRowData(newRowData);
    // }, [initialData, tabledata]);
    //To display the initial data
useEffect(() => {
  if (moduleName === "Edit Partner") {
    setModifiedEditPartnerData(rowData);
  }
}, [rowData]);

    useEffect(() => {
        // if (moduleName === "Edit Partner") return;
        if (moduleName === "Rev assurance") {
            const newRowData = tabledata.length > 0 ? tabledata : initialData;
            setRowData(newRowData);
        }
        else {
            setRowData(initialData);
        }

    }, [initialData, tabledata]);

    useEffect(() => {
        setCurrentPage(1);
        setSelectedRows([])
        setIsSearchComponentCall(false)
    }, [tabledata]);

    useEffect(() => {
        setCurrentPage(1);
    }, [totalPages]);


    useEffect(() => {
        let pagination_: any

        if (moduleName === "Rev assurance") {
            if (combineAdnvaceStoredpagination) {
                pagination_ = combineAdnvaceStoredpagination
            }
            else if (advancedStoredpagination && !storedpagination) {
                pagination_ = advancedStoredpagination
            }
            else if (storedpagination && !advancedStoredpagination) {
                pagination_ = storedpagination
            }
            else {
                pagination_ = pagination
            }
        }
        else {
            pagination_ = pagination
        }
        // const pagination_ = pagination;
        const start = pagination_?.start || 1;
        const total = pagination_?.total || 1;
        const end = pagination_?.end || 1;
        const lastPageWithData_ = Math.floor(end / itemsPerPage);
        const totalPages_ = Math.ceil(total / itemsPerPage);
        const currentPage_ = Math.floor(start / itemsPerPage) + 1;
        setTotalPages(totalPages_);
        // setCurrentPage(currentPage_);
        // setLastPageWithData(lastPageWithData_);
    }, [tabledata, initialData, pagination, itemsPerPage, currentPage, storedpagination, advancedStoredpagination, combineAdnvaceStoredpagination, sortConfig]);


    // //To reset the store variables
    // useEffect(() => {
    //     if (isClosed) {
    //         setSelectedRows([])
    //         setSelectAll(false)
    //     }
    // }, [isClosed]);
    useEffect(() => {
        const updatedRows_ = selectedRows.map((i) => rowData[i])
        setRevRows(updatedRows_); // Store the selected rows in revStore
    }, [selectedRows]);


    //To manage the pagination routes

    const updatePaginator = async () => {
        let start_ = Math.floor((currentPage - 1) * itemsPerPage);
        let end_ = Math.floor((currentPage - 1) * itemsPerPage + 100);
        try {
            const colSortKey = sortConfig ? sortConfig.key : ""
            const colSortDirection = sortConfig ? sortConfig.direction : ""
            const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";
            // if (currentPage !== 1) {
            setLoading(true);
            // }
            if (moduleName === "Rev assurance") {
                const isVersionEnabled = localStorage.getItem("switch_user_2_0_rev_assurance") === "True";
                const url = isVersionEnabled 
                            ? ENV_ROUTES.REV_ASSURANCE 
                            : ENV_ROUTES.SIM_MANAGEMENT;
                const data = {
                    tenant_name: partner || "default_value",
                    username: username,
                    firstLastName: firstLastName,
                    path: "/get_rev_assurance_data",
                    role_name: role,
                    parent_module: "Sim Management",
                    module_name: showVarianceStatus ? "Rev assurance variance" : "Rev assurance",
                    feature_module_name: "Rev Assurance",
                    mod_pages: {
                        start: start_,
                        end: end_,
                    },
                    request_received_at: getCurrentDateTime(),
                    Partner: partner,
                    access_token: token,
                    db_name: selectedDb,
                    ...metaData,
                    sessionID: sessionId,
                    variance: showVarianceStatus,
                    ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
                        : {}),
                };
                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);
                if (parsedData.flag === false) {
                    Modal.error({
                        title: 'Data Fetch Error',
                        content: parsedData.message || 'An error occurred while fetching rev assurance data. Please try again.',
                        centered: true,
                    });
                } else {
                    const tableData = parsedData?.rev_assurance_data || []
                    setRowData(tableData);
                    pagination = parsedData?.pages || pagination
                }
            }
            if (moduleName === "Optimization") {
                const url = ENV_ROUTES.SIM_MANAGEMENT
                const data = {
                    tenant_name: partner || "default_value",
                    username: username,
                    firstLastName: firstLastName,
                    path: "/get_optimization_data",
                    role_name: role,
                    parent_module: "Sim Management",
                    module_name: "Optimization",
                    feature_module_name: "Optimization",
                    mod_pages: {
                        start: start_,
                        end: end_,
                    },
                    request_received_at: getCurrentDateTime(),
                    Partner: partner,
                    access_token: token,
                    db_name: selectedDb,
                    ...metaData,
                    sessionID: sessionId,
                    ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
                        : {}),
                };

                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);
                if (parsedData.flag === false) {
                    Modal.error({
                        title: 'Data Fetch Error',
                        content: parsedData.message || 'An error occurred while fetching optimization data. Please try again.',
                        centered: true,
                    });
                } else {
                    const tableData = parsedData?.optimization_data || []
                    console.log("tableData", tableData)
                    console.log("currentPage", currentPage)

                    setRowData(tableData);
                    pagination = parsedData?.pages || pagination
                }
            }
            if (moduleName === "Customer charges") {
                const url = ENV_ROUTES.SIM_MANAGEMENT
                const data = {
                    tenant_name: partner || "default_value",
                    username: username,
                    firstLastName: firstLastName,
                    path: "/get_customer_charges_data",
                    role_name: role,
                    module_name: "Customer charges",
                    feature_module_name: "Customer Charges",
                    mod_pages: {
                        start: start_,
                        end: end_,
                    },
                    request_received_at: getCurrentDateTime(),
                    Partner: partner,
                    access_token: token,
                    db_name: selectedDb,
                    ...metaData,
                    sessionID: sessionId,
                    ...(sortConfig ? { col_sort: { [colSortKey]: colSortValue } }
                        : {}),
                };

                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);
                if (parsedData.flag === false) {
                    Modal.error({
                        title: 'Data Fetch Error',
                        content: parsedData.message || 'An error occurred while fetching optimization data. Please try again.',
                        centered: true,
                    });
                } else {
                    const tableData = parsedData?.customer_charges_data || []
                    setRowData(tableData);
                    pagination = parsedData?.pages || pagination
                }
            }
        } catch (err) {
            console.error("Error fetching data:", err);
        } finally {
            setLoading(false);
        }
        // }
    };

    const updateSearchPaginator = async () => {
        let start_ = Math.floor((currentPage - 1) * itemsPerPage);
        let end_ = Math.floor((currentPage - 1) * itemsPerPage + 100);
        const colSortKey = sortConfig ? sortConfig.key : ""
        const colSortDirection = sortConfig ? sortConfig.direction : ""
        const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";
        try {
            setLoading(true);
            const url = ENV_ROUTES.OPEN_SEARCH;
            let data = { ...searchData, username: username, }
            data.data.pages = {
                start: start_,
                end: end_,
            }
            data.data.col_sort = { [colSortKey]: colSortValue }
            const response = await axios.post(url, data);
            const parsedData = JSON.parse(response.data.body);
            console.log("parsed", parsedData);
            if (parsedData?.flag) {
                const tableData = parsedData?.data?.table || [];
                setRowData(tableData);
                const pagination_ = parsedData?.pages || {};
                setStoredPagination(pagination_);
                setAdvancedStoredPagination(null)
                if (tableData.length === 0) {
                    Modal.error({
                        title: "No Records found",
                    });
                }
            } else {
                Modal.error({
                    title: "Search error",
                    content:
                        parsedData.error ||
                        "An error occurred while searching. Please try again.",
                });
            }
            console.log(response);
        } catch (error) {
            console.log(error);
        } finally {
            setLoading(false); // Stop loader
        }
    }
    const updateAdvancedSearchPaginator = async () => {
        let start_ = Math.floor((currentPage - 1) * itemsPerPage);
        let end_ = Math.floor((currentPage - 1) * itemsPerPage + 100);
        const colSortKey = sortConfig ? sortConfig.key : ""
        const colSortDirection = sortConfig ? sortConfig.direction : ""
        const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";
        try {
            setLoading(true);
            const url = ENV_ROUTES.OPEN_SEARCH;
            let data = { ...advancedSearchData, username: username, }
            data.data.pages = {
                start: start_,
                end: end_,
            }
            data.data.col_sort = { [colSortKey]: colSortValue }
            const response = await axios.post(url, data);
            const parsedData = JSON.parse(response.data.body);
            console.log("parsed", parsedData);
            if (parsedData?.flag) {
                const tableData = parsedData?.data?.table;
                setRowData(tableData);
                const pagination_ = parsedData?.pages || {}
                setStoredPagination(null)
                setAdvancedStoredPagination(pagination_)
                if (tableData.length === 0) {
                    Modal.error({
                        title: "No Records found",
                    });
                }
            } else {
                Modal.error({
                    title: "Search error",
                    content:
                        parsedData.error ||
                        "An error occurred while searching. Please try again.",
                });
            }
            console.log(response);
        } catch (error) {
            console.log(error);
        } finally {
            setLoading(false); // Stop loader
        }
    }
    const updateCombinedSearchPaginator = async () => {
        let start_ = Math.floor((currentPage - 1) * itemsPerPage);
        let end_ = Math.floor((currentPage - 1) * itemsPerPage + 100);
        const colSortKey = sortConfig ? sortConfig.key : ""
        const colSortDirection = sortConfig ? sortConfig.direction : ""
        const colSortValue = sortConfig ? (colSortDirection === "ascending" ? "ASC" : "DESC") : "ASC";
        try {
            setLoading(true);
            const url = ENV_ROUTES.OPEN_SEARCH;
            let data = { ...combineAdnvaceSearchData, username: username, }
            data.data.pages = {
                start: start_,
                end: end_,
            }
            data.data.col_sort = { [colSortKey]: colSortValue }
            const response = await axios.post(url, data);
            const parsedData = JSON.parse(response.data.body);
            console.log("parsed", parsedData);
            if (parsedData?.flag) {
                const tableData = parsedData?.data?.table;
                setRowData(tableData);
                const pagination_ = parsedData?.pages || {}
                setStoredPagination(null)
                setAdvancedStoredPagination(null)
                setCombineAdnvaceStoredpagination(pagination_)
                if (tableData.length === 0) {
                    Modal.error({
                        title: "No Records found",
                    });
                }
            } else {
                Modal.error({
                    title: "Search error",
                    content:
                        parsedData.error ||
                        "An error occurred while searching. Please try again.",
                });
            }
            console.log(response);
        } catch (error) {
            console.log(error);
        } finally {
            setLoading(false); // Stop loader
        }
    }

    useEffect(() => {
        if (!isFirstRender.current) {

            if (combineAdnvaceStoredpagination) {
                updateCombinedSearchPaginator()
            }
            else if (storedpagination && !advancedStoredpagination) {
                updateSearchPaginator()
            }
            else if (advancedStoredpagination && !storedpagination) {
                updateAdvancedSearchPaginator()
            }
            else {
                updatePaginator();
            }

        } else { isFirstRender.current = false }
        if (moduleName === "Rev assurance") {
            setSelectedRows([])
        }
    }, [currentPage, sortConfig]);

    useEffect(() => {
        if (!isFirstTableDataRender.current && !isSearchComponentCall) {

            if (tabledata !== rowData && currentPage === 1) {
                if (combineAdnvaceStoredpagination) {
                    updateCombinedSearchPaginator()
                }
                else if (storedpagination && !advancedStoredpagination) {
                    updateSearchPaginator()
                }
                else if (advancedStoredpagination && !storedpagination) {
                    updateAdvancedSearchPaginator()
                }
                else {
                    updatePaginator();
                }
            }

        } else { isFirstTableDataRender.current = false }

        //   if (moduleName === "Rev assurance") {
        //     setSelectedRows([])
        // }
    }, [tabledata]);

    useEffect(() => {
        // console.log("searchQuery",searchQuery)
        if (!isFirstSearchRender.current) {
            if (searchQuery === "") {
                console.log("searchQuery", isFirstRender)
                if (storedpagination) {
                    updateSearchPaginator()
                }
                else if (advancedStoredpagination) {
                    updateAdvancedSearchPaginator()
                }
                else {
                    updatePaginator();
                }
            }
        } else { isFirstSearchRender.current = false }
    }, [searchQuery]);

    useEffect(() => {
        // console.log("advancedFilters",advancedFilters)
        if (!isFirstAdvancedSearchRender.current) {
            if (advancedFilters) {
                const allEmpty = Object.values(advancedFilters).every(
                    (value) => Array.isArray(value) && value.length === 0
                );

                if (allEmpty) {
                    console.log("advancedFilters", advancedFilters)
                    if (storedpagination) {
                        updateSearchPaginator()
                    }
                    else if (advancedStoredpagination) {
                        updateAdvancedSearchPaginator()
                    }
                    else {
                        updatePaginator();
                    }
                }
            }
        } else { isFirstAdvancedSearchRender.current = false }

    }, [advancedFilters]);

    //For sorting the table
    const handleSort = (key: string) => {
        let direction: "ascending" | "descending" = "ascending";
        if (
            sortConfig &&
            sortConfig.key === key &&
            sortConfig.direction === "ascending"
        ) {
            direction = "descending";
        }

        // const sortedData = [...rowData].sort((a, b) => {
        //     let aValue = a[key];
        //     let bValue = b[key];

        //     // Special handling for the "Assigned rate plans" or "Assigned rate plan count" columns
        //     if (key === "carrier_rate_plans") {
        //         aValue = Array.isArray(aValue) ? aValue.length : JSON.parse(aValue)?.length || 0;
        //         bValue = Array.isArray(bValue) ? bValue.length : JSON.parse(bValue)?.length || 0;
        //     }

        //     // Convert 'None' to null for easier comparison
        //     const normalizeValue = (value: any) => {
        //         if (value === 'None') return null;
        //         return value;
        //     };

        //     aValue = normalizeValue(aValue);
        //     bValue = normalizeValue(bValue);

        //     // Function to split a string into alphabetical and numeric segments
        //     const splitIntoSegments = (str: string) => {
        //         return str.toLowerCase().match(/([a-z]+|\d+)/g) || [];
        //     };

        //     // Split values into segments
        //     const aSegments = typeof aValue === "string" ? splitIntoSegments(aValue) : [aValue];
        //     const bSegments = typeof bValue === "string" ? splitIntoSegments(bValue) : [bValue];

        //     // Compare each segment one by one
        //     for (let i = 0; i < Math.max(aSegments.length, bSegments.length); i++) {
        //         const aSegment = aSegments[i];
        //         const bSegment = bSegments[i];

        //         // If one segment is undefined, consider it smaller
        //         if (aSegment === undefined) return direction === "ascending" ? -1 : 1;
        //         if (bSegment === undefined) return direction === "ascending" ? 1 : -1;

        //         // Compare numeric segments numerically, and character segments lexicographically
        //         const isANumber = !isNaN(Number(aSegment));
        //         const isBNumber = !isNaN(Number(bSegment));

        //         if (isANumber && isBNumber) {
        //             // Both segments are numbers; compare them numerically
        //             const numA = Number(aSegment);
        //             const numB = Number(bSegment);
        //             if (numA < numB) return direction === "ascending" ? -1 : 1;
        //             if (numA > numB) return direction === "ascending" ? 1 : -1;
        //         } else {
        //             // At least one segment is not a number; compare them as strings
        //             if (aSegment < bSegment) return direction === "ascending" ? -1 : 1;
        //             if (aSegment > bSegment) return direction === "ascending" ? 1 : -1;
        //         }
        //     }

        //     return 0;
        // });
        setCurrentPage(1)
        setSortConfig({ key, direction });
        // setRowData(sortedData);
    };

    //To open the modals for each allowed action
    const handleActionClick = (action: string, rowIndex: number) => {
        switch (action) {
            case "download":
                setIsDownload(true);
                setDownloadRowIndex(rowIndex);
                break;
            case "upload":
                setIsUpload(true);
                setUploadRowIndex(rowIndex);
                break;
            default:
                break;
        }
    };

    const handleCloseModal = () => {
        setIsDownload(false);
        setDownloadRowIndex(null);
        setIsUpload(false);
        setUploadRowIndex(null);
    }

    // Toggle row selection and store in revStore
    const toggleRowSelection = (index: number) => {
        console.log("rev rows in assign modal", selectedRows)
        setSelectAll(false);
        setIsClosed(false)
        let updatedSelectedRows: number[];

        if (selectedRows.includes(index)) {
            updatedSelectedRows = selectedRows.filter((i) => i !== index);
        } else {
            updatedSelectedRows = [...selectedRows, index];
        }
        setSelectedRows(updatedSelectedRows);
    };

    // Toggle all rows selection and store in revStore
    const toggleSelectAll = () => {
        setIsClosed(false)
        let updatedSelectedRows: number[];

        if (selectAll) {
            updatedSelectedRows = [];
        } else {
            updatedSelectedRows = rowData.map((_, index) => index);
        }

        setSelectedRows(updatedSelectedRows);
        setSelectAll(!selectAll);
    };
    const handleDateChange = (rowIndex: number, date: string | null) => {
        const updatedRowData = [...rowData];
        updatedRowData[rowIndex]['Effective Date'] = date;
        setRowData(updatedRowData);
        onDateChange(rowIndex, date);
    };

    const getEdiPartnerTableCellClass = (header: string) => {
        if (header === "order_of_action") {
            return "!text-center"
        }
        else if (header === "setup_action") {
            return "!whitespace-nowrap"
        }
        else if (header === "summary") {
            return "!min-w-[500px]"
        }
        else {
            return ""
        }
    }

    const moduleAvailabilityWarning = (
        setup_action: string,
    ) => {
        const setupAction = (setup_action || "").toLowerCase();
        const isSubTenantAction = setupAction.includes("sub tenant");
        const partner_row = JSON.parse(localStorage.getItem("partner_row") || "{}")
        const mainPartner = partner_row?.partner || ""
        const subPartner = partner_row?.sub_partner && setupAction.includes("sub tenant") ? partner_row?.sub_partner : ""
        const selectedPartner = subPartner && isSubTenantAction ? subPartner : mainPartner || partner
        // Pick enabled modules once
        const enabledModules = isSubTenantAction
            ? subTenantEnabledModules
            : mainTenantEnabledModules;

        // Map setup action keywords to required modules
        const moduleMap: { keywords: string[]; module: string }[] = [
            {
                keywords: ["modules and roles"],
                module: "Partner Modules",
            },
            {
                keywords: ["customer assignment"],
                module:"Bulk Change"
            },
            {
                keywords: ["customers creation"],
                module: "Billing Customers",
            },
            {
                keywords: [
                    "carriers creation",
                    "customer group",
                    "role modules access",
                    "users creation",
                ],
                module: "Partner Info",
            },
            {
                keywords: ["customer rate plans"],
                module: "Customer Rate Plans",
            },
            {
                keywords: ["rate plans setup"],
                module: "Carrier Rate Plans/SOCs",
            },
        ];

        // Find matching rule
        const matchedRule = moduleMap.find(rule =>
            rule.keywords.some(keyword => setupAction.includes(keyword))
        );

        if (matchedRule && !enabledModules.includes(matchedRule.module)) {
            Modal.warning({
                title: "Warning",
                content: `${matchedRule?.module || ""} is not enabled for ${selectedPartner} tenant`,
                centered: true,
            });
            return true;
        }
        else{
            return false
        }
        return false
    };

    const handleRunSubmit = async (setup_action :string) => {
        const setUpAction = (setup_action || "")?.toLowerCase()
        const isModuleDisabled =  moduleAvailabilityWarning(setUpAction)
        if(isModuleDisabled){
            return
        }
        try {
            setLoading(true);
            const partner_row = JSON.parse(localStorage.getItem("partner_row") || "{}")
            const url = ENV_ROUTES.TENANT_ONBOARDING;
            const data = {
                tenant_name: partner || "default_value",
                username,
                firstLastName,
                path: "/trigger_test_run",
                role_name: role,
                parent_module: "Super Admin",
                module_name: "Edit Partner",
                Partner: partner,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                selected_tenant: partner_row?.partner || "",
                selected_sub_tenant: partner_row?.sub_partner || "",
                setup_action: setup_action || "",
            };

            const response = await axios.post(url, { data });
            const parsed = JSON.parse(response.data.body);
            if (parsed.flag) {
                notification.success({
                    message: "Success",
                    description: "Partner setup updated successfully",
                    placement: "top",
                });
                fireSideCannons()
                if (typeof refreshPartnerData === "function") {
                    await refreshPartnerData();

                }
            } else {                
                Modal.error({
                    title: "Submit Failed",
                    content: parsed.message || "Unable to submit partner setup",
                    centered: true,
                });
            }
        } catch (err) {
            console.error("Submit error:", err);
            Modal.error({
                title: "Error",
                content: "Something went wrong while submitting",
                centered: true,
            });
        } finally {
            setLoading(false);
        }
    };

    const renderTestButton = (value: any, index: number, col: any) => {
        const row = rowData[index];
        const setup_action = row?.setup_action || null

        return (
            <div className="flex items-center space-x-2">
                <button
                    className="test-run-btn"
                    onClick={() => { handleRunSubmit(setup_action)}}
                >
                    Run
                </button>
            </div>
        );
    };

    const handleSelectedPartner = async (
        partnerId: any,
        partnerName: string,
    ) => {
        const data = {
            path: "/get_modules",
            role_name: role,
            username: username,
            firstLastName: firstLastName,
            sessionID: sessionId,
            tenant_name: partnerName,
            Partner: partnerName,
            request_received_at: getCurrentDateTime(),
            access_token: token,
        };

        setLoading(true);

        try {
            const url = ENV_ROUTES.MODULE_MANAGEMENT;
            const response = await axios.post(url, { data: data }, {
                headers: {
                    'Content-Type': 'application/json',
                },
            });

            if (response.status === 200) {
                const parsedData = JSON.parse(response.data.body);

                if (parsedData.error) {
                    setLoading(false);
                    Modal.error({
                        title: 'Module Fetch Error',
                        content: parsedData.error || 'An error occurred while fetching modules. Please try again.',
                    });
                } else if (parsedData.flag === false) {
                    setLoading(false);
                    Modal.error({
                        title: 'Module Fetch Error',
                        content: parsedData.message || 'An error occurred while fetching modules. Please try again.',
                    });
                } else {
                    const dbName = parsedData?.db_name || "";
                    const billingDbName = dbName.includes("_beta")
                        ? dbName.replace("_beta", "_billing_platform_beta")
                        : dbName === "altaworx_test"
                            ? "billing_platform"
                            : `${dbName}_billing_platform`;
                    const logoUrl_ = parsedData?.logo;
                    // setLogoUrl(logoUrl_ || null);
                    // setSelectedPartner(true);
                    const modules = parsedData?.Modules || [];
                    const billingFlag = parsedData?.billing_platform_flag ?? false;

                    // If billing flag is false, remove the "Billing" parent module
                    const filteredModules = billingFlag
                        ? modules
                        : modules.filter(
                            (module: any) => module.parent_module_name !== "Billing"
                        );
                    const isSubTenantMap_: any = JSON.parse(localStorage.getItem('sub_tenant_map') || '{}');
                    const isSubPartner_ = isSubTenantMap_[partnerName] || false
                    const meta_data_ = {
                        db_config_details: parsedData?.db_config_details || {}
                    }
                    localStorage.setItem('meta_data', JSON.stringify(meta_data_));
                    localStorage.setItem('tenant_provider_map', JSON.stringify(parsedData?.tenant_provider_map || {}));
                    localStorage.setItem('tenant_name', partnerName);
                    localStorage.setItem('tenant_id', partnerId + "");
                    localStorage.setItem('modules', JSON.stringify(filteredModules || []));
                    localStorage.setItem('db_name', parsedData?.db_name || null);
                    localStorage.setItem("billing_db_name", billingDbName);
                    localStorage.setItem('logo', parsedData?.logo || null);
                    localStorage.setItem('collapsed_logo', parsedData?.collapsed_logo || null);
                    localStorage.setItem('dark_mode_collapsed_logo', parsedData?.dark_mode_collapsed_logo || null);
                    localStorage.setItem('dark_mode_logo', parsedData?.dark_mode_logo || null);
                    localStorage.setItem('is_sub_tenant', (isSubPartner_ || false).toString());
                    localStorage.setItem('bp_flag', parsedData?.billing_platform_flag || false);
                    const initial_timeout_frequency = parsedData?.ui_timeout
                    const ui_timeout = initial_timeout_frequency && initial_timeout_frequency !== "None"
                        ? Number(initial_timeout_frequency)
                        : 15
                    localStorage.setItem('ui_timeout', ui_timeout.toString())
                    // Extract the first module name
                    const firstModule = parsedData?.Modules?.[0];
                    let firstModulePath = '';
                    if (firstModule) {
                        // If there are sub-modules, route to the first child
                        if (firstModule.children && firstModule.children.length > 0) {
                            firstModulePath = `/${firstModule.parent_module_name.toLowerCase().replace(/\s+/g, '_')}/${firstModule.children[0].child_module_name.toLowerCase().replace(/\s+/g, '_')}`;
                        } else {
                            // Route to the parent module if no children exist
                            firstModulePath = `/${firstModule.parent_module_name.toLowerCase().replace(/\s+/g, '_')}`;
                        }
                    }
                    console.log(firstModulePath, "Print first module path");
                }
            } else {
                setLoading(false);
                Modal.error({
                    title: 'Module Fetch Error',
                    content: response.data.message || 'Fetching modules failed. Please try again.',
                });
            }
        } catch (error) {
            setLoading(false);
            Modal.error({
                title: 'Module Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching modules. Please try again.',
            });
        } finally {
            setLoading(false);
        }
    };

    const editActionPartnerCreation = async (setup_action: any) => {
        // console.log("order", order, typeof order)
        // const selectedOrder = setup_action ? setup_action.toString() : ""
        const setupAction = setup_action ? setup_action.toString().toLowerCase() : ""
        const isModuleDisabled =  moduleAvailabilityWarning(setupAction)
        if(isModuleDisabled){
            return
        }
        const partner_row = JSON.parse(localStorage.getItem("partner_row") || "{}")
        const partnerName = partner_row?.partner || ""
        const subPartner = partner_row?.sub_partner && setupAction.includes("sub tenant") ? partner_row?.sub_partner : ""
        const partnerId = partner_row?.tenant_id || ""
        const selected_partner = subPartner ? subPartner : partnerName
        await handleSelectedPartner(partnerId, selected_partner)
        const queryParams = new URLSearchParams({ partner: partnerName, sub_partner: subPartner });
        if (subPartner) queryParams.append("sub_partner", subPartner);
        if (setupAction.includes("modules and roles")) {
            window.open(`/super_admin/partner_modules?${queryParams.toString()}`, "_blank");
        }
        if (setupAction.includes("customers creation")) {
            window.open("/people/billing_customers", "_blank");
        }
        if (setupAction.includes("carriers creation")) {
            localStorage.setItem("activeTab", "partnerInfo")
            window.open("/partner/partner_info", "_blank");
        }
        if (setupAction.includes("customer rate plans")) {
            window.open("/sim_management/customer_rate_plans", "_blank");
        }
        if (setupAction.includes("rate plans setup")) {
            localStorage.setItem("activeTab", "carrierRatePlan")
            window.open("/sim_management/carrier_rate_plans_socs/rate_plans_socs", "_blank");
        }
        if (setupAction.includes("customer group")) {
            localStorage.setItem("activeTab", "customergroups")
            window.open("/partner/partner_info", "_blank");
        }
        if (setupAction.includes("role modules access")) {
            localStorage.setItem("activeTab", "partnermoduleaccess")
            window.open("/partner/partner_info", "_blank");
        }
        if (setupAction.includes("users creation")) {
            localStorage.setItem("activeTab", "partnerusers")
            window.open("/partner/partner_info", "_blank");
        }
        if (setupAction.includes("customer assignment")) {
            window.open("/sim_management/bulk_change", "_blank");
        }
    }

    const renderActionButtons = (value: any, index: number, col: any) => {
        const row = rowData[index];
        const setup_action = row?.setup_action || null
        const setupAction = (setup_action || "")?.toLowerCase()

        return (
            <div className="flex items-center space-x-2">
                <Tooltip title="Redirect">
                    <PencilIcon
                        className="h-5 w-5 text-blue-500 cursor-pointer"
                        onClick={() => { editActionPartnerCreation(setup_action) }}
                    />
                </Tooltip>
                <Tooltip title="Info">
                    <EyeIcon
                        className="h-5 w-5 text-blue-400 cursor-pointer"
                        onClick={() => {
                            const isModuleDisabled = moduleAvailabilityWarning(setupAction)
                            if (isModuleDisabled) {
                                return
                            }
                            setPartnerInfoModuleName(setup_action || "")
                            setOpenPartnerInfoModal(true)
                        }}
                    />
                </Tooltip>
            </div>
        );
    };

    const renderTestStatus = (status: string) => {
        let textColorClass = "";
        if (status === "True" || status === "NEW" || status === "Successful") {
            textColorClass = "text-blue-500";
        } else if (
            status === "False" ||
            status === "ERROR" ||
            status === "Failed" || status === "failure"
        ) {
            textColorClass = "text-red-500";
        } else if (status === "PROCESSED" || status === "success" || status === "Success" || status === "Complete") {
            textColorClass = "text-green-500";
        }
        else if (status === "Inprogress") {
            textColorClass = "text-yellow-500";
        }
        else if (status === "Open") {
            textColorClass = "test-status";
        }
        if (status === "True") {
            return <span className={`${textColorClass}`}>Active</span>;
        } else if (status === "False") {
            return <span className={`${textColorClass}`}>Inactive</span>;
        } else {
            return <span className={`${textColorClass} text-[16px]`}>{status}</span>;
        }
    };

    const renderActionStatusDropdown = (value: any, index: number, col: string) => {
        const row = rowData[index];


        const progress = row?.upload_progress_percentage;
        const isProgressMode = typeof progress === "number";
        const currentStatusValue = value || row?.[col] || "Open";

        const currentStatus =
            STATUS_OPTIONS.find((opt) => opt.label === currentStatusValue) ||
            STATUS_OPTIONS[0];

        const items = STATUS_OPTIONS.map((opt) => ({
            key: opt.value,
            label: <div className="text-sm">{opt.label}</div>,
        }));

        const handleMenuClick = ({ key }: { key: string }) => {
            const row = rowData[index];
            const setup_action = row?.setup_action || null
            const setupAction = (setup_action || "")?.toLowerCase()
            const isModuleDisabled = moduleAvailabilityWarning(setupAction)
            if (isModuleDisabled) {
                return
            }
            setRowData((prev: any[]) => {
                const next = [...prev];
                next[index] = { ...next[index], [col]: key };
                return next;
            });
        };


        return (
            <div className="flex items-center">
                <Dropdown
                    menu={{ items, onClick: handleMenuClick }}
                    trigger={["click"]}
                    disabled={isProgressMode && progress < 100}
                >
                    <button
                        type="button"
                        className={`relative overflow-hidden flex justify-between items-center px-[10px] rounded-[8px] text-white text-[14px] w-[120px] min-h-[32px] 
              ${!isProgressMode ? currentStatus.bgClass : "bg-gray-300"}
            `}
                    >
                        {/* Progress Fill */}
                        {isProgressMode && (
                            <div
                                className={`absolute left-0 top-0 h-full transition-all duration-300 ${currentStatus.bgClass}`}
                                style={{ width: `${progress}%` }}
                            />
                        )}

                        {/* Content */}
                        <span className="relative z-10">
                            {/* {isProgressMode ? `${progress}%` : currentStatus.label} */}
                            {currentStatus.label}
                        </span>

                        {/* {!isProgressMode && ( */}
                        <ChevronDownIcon className="relative z-10 w-4 h-4" />
                        {/* )} */}
                    </button>
                </Dropdown>
            </div>
        );
    };

    //For custom cell rendering
    const renderCell = (row: any, column: string, rowIndex: number) => {
        if (column === 'Effective Date') {
            return (
                <EffectiveDate
                    selectedDate={row['Effective Date'] || null}
                    handleDateChange={(date) => handleDateChange(rowIndex, date)}
                />
            );
        }
        if (headerMap && (headerMap?.[column]?.[0] === "Action Status" && moduleName === "Edit Partner")) {

            return (
                renderActionStatusDropdown(
                    row[column],
                    rowIndex,
                    column
                ))
        }
        if (headerMap && (headerMap?.[column]?.[0] === "Actions" && moduleName === "Edit Partner")) {

            return (
                renderActionButtons(
                    row[column],
                    rowIndex,
                    column
                ))
        } if (headerMap && (headerMap?.[column]?.[0] === "Test Run" && moduleName === "Edit Partner")) {

            return (
                renderTestButton(
                    row[column],
                    rowIndex,
                    column
                ))
        } if (headerMap && (headerMap?.[column]?.[0] === "Test Status" && moduleName === "Edit Partner")) {

            return (
                renderTestStatus(row[column]))
        }
        return (

            row[column] !== "None" && headerMap?.[column]?.[0] !== "Summary" ? (
                <Tooltip
                    title={`${row[column]}`}
                    placement="topLeft"
                    overlayStyle={{ whiteSpace: 'normal', maxWidth: '60vw', wordWrap: 'break-word', zIndex: 50 }}
                    // getPopupContainer={(triggerNode) => (triggerNode.parentNode as HTMLElement) || document.body} // Fallback to document.body
                    getPopupContainer={() => document.body} // Render tooltip directly on the body to avoid stacking issues
                >
                    {row[column]}
                </Tooltip>
            ) : (
                row[column]
            )
        );
    };

    const getRowBgColor = (index: number, row: any) => {
        if (selectedRows.includes(index)) {
            return 'bg-blue-100 text-[#000] rev-selected-row';
        } else if (moduleName === 'Optimization' && row.run_status === 'Complete with Success') {
            return 'bg-green-100 text-[#000]';
        } else if (moduleName === 'Optimization' && row.run_status === 'Complete with Errors') {
            return 'bg-red-100 text-[#000]';
        }
        else if (moduleName === 'Optimization' &&
            (row.run_status === 'Comm Group Setup'
                || row.run_status === 'Enqueue Permutations'
                || row.run_status === 'Running Permutations'
                || row.run_status === 'Cleaning Up')) {
            return 'bg-yellow-100';
        }
        else if (index % 2 === 0) {
            return "even-table-row"
        }

        return ''; // Default no background color
    };

    if (loading) {
        return (
            <div className="flex justify-center items-center h-screen">
                <Spin size="large" />
            </div>
        );
    }
    // Pagination component to be used in both places

    return (
        <div>
            {isSmallScreen && (
                <div className="flex justify-end mb-2 mr-2">
                    <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} moduleName={moduleName} />
                </div>
            )}
            <div className="overflow-x-auto">
                <div className="overflow-y-auto" style={{
                    height: (moduleName === "Rev assurance" || moduleName === 'Edit Partner')
                        ? `${viewportHeight - height}px`
                        : "auto" // Apply auto height when moduleName matches
                }}>
                    <table className="table-auto w-full">
                        <thead className="sticky top-0 bg-gray-200 z-10 table-header-row">
                            <tr>
                                {(typeof window !== "undefined" && window.innerWidth < 700) && (
                                    <th
                                        className={`px-6 py-3 border-b border-gray-300 text-left font-semibold table-header sticky top-0  freeze-header`}
                                        style={{
                                            cursor: "pointer", position: "sticky", left: 0, zIndex: 11, minWidth: "40px"
                                        }}>

                                    </th>
                                )}

                                {moduleName !== 'Edit Partner' && (
                                    <th className="px-6 py-3 border-b border-gray-300 text-left font-semibold table-header sticky top-0 w-[50px] freeze-header" style={{ position: "sticky", left: (typeof window !== "undefined" && window.innerWidth < 700) ? 40 : 0, zIndex: 11 }}>
                                        {moduleName !== 'Customer charges' && (
                                            <input
                                                type="checkbox"
                                                checked={selectAll}
                                                onChange={toggleSelectAll}
                                                className='hover:cursor-pointer'
                                            />
                                        )}
                                    </th>
                                )}
                                {headers.map((header) => (
                                    headerMap && headerMap[header] && visibleColumns.includes(header) && (
                                        <th
                                            key={header}
                                            className={`px-6 py-3 border-b border-gray-300 text-left font-semibold ${moduleName === "Edit Partner" ? "edit-partner-table-header" : "table-header"} sticky top-0 ${sortConfig && sortConfig.key === header ? "text-blue-600 active-table-header" : ""
                                                }  ${(moduleName === "Rev assurance" && header === "service_number") ? 'freeze-header' : ''}`}
                                            style={{
                                                cursor: "pointer",
                                                ...(moduleName === "Rev assurance" && header === "service_number"
                                                    ? { position: "sticky", left: (typeof window !== "undefined" && window.innerWidth < 700) ? 75 : 50, zIndex: 11 }
                                                    : {})
                                            }}
                                            onClick={() => {
                                                handleSort(header);
                                            }}
                                        >
                                            {headerMap[header][0] || header}
                                            {
                                                sortConfig && sortConfig.key === header ? (
                                                    sortConfig.direction === "ascending" ? (
                                                        <ArrowUpOutlined className="sorting-arrow" style={{ marginLeft: 8, color: "#2563EB" }} />
                                                    ) : (
                                                        <ArrowDownOutlined className="sorting-arrow" style={{ marginLeft: 8, color: "#2563EB" }} />
                                                    )
                                                ) : (
                                                    <ArrowUpOutlined style={{ marginLeft: 8, opacity: 0.5 }} />
                                                )
                                            }

                                        </th>
                                    )
                                ))}
                                {allowedActions && visibleColumns.length > 0 && (
                                    <th className="px-6 border-b border-gray-300 text-left font-semibold table-header">
                                        <span>Actions</span>
                                    </th>
                                )}

                            </tr>
                        </thead>
                        <tbody>
                            {rowData.length > 0 ? (
                                rowData.map((row, index) => (
                                    <tr
                                        key={index}
                                        className={getRowBgColor(index, row)}
                                    >
                                        {(typeof window !== "undefined" && window.innerWidth < 700) && (
                                            <td
                                                className={`border-b border-gray-300 table-cell  ${index % 2 === 0 ? "even-freeze-cell" : "freeze-cell"}`}
                                                style={
                                                    { position: "sticky", left: 0, backgroundColor: "white", zIndex: 5 }
                                                }>
                                                <Radio
                                                    checked={true}
                                                    onClick={() => {
                                                        setShowRowModal(true);
                                                        setShowRowModalData(row);
                                                    }}
                                                    className="custom-gray-radio"
                                                />
                                            </td>
                                        )}

                                        {moduleName !== 'Edit Partner' && (
                                            <td className={`border-b border-gray-300 table-cell ${index % 2 === 0 ? "even-freeze-cell" : "freeze-cell"}`} style={{ position: "sticky", left: (typeof window !== "undefined" && window.innerWidth < 700) ? 40 : 0, zIndex: 5 }}>
                                                {moduleName !== 'Customer charges' && (
                                                    <input
                                                        type="checkbox"
                                                        checked={selectedRows.includes(index)}
                                                        onChange={() => toggleRowSelection(index)}
                                                        className="hover:cursor-pointer"
                                                    />
                                                )}
                                            </td>
                                        )}

                                        {headers.map((header, columnIndex) =>
                                            visibleColumns.includes(header) && headerMap[header] && (
                                                <td key={columnIndex} className={` border-b border-gray-300 ${moduleName === "Edit Partner" ? `edit-partner-table-cell ${getEdiPartnerTableCellClass(header)}` : "table-cell"} ${(moduleName === "Rev assurance" && header === "service_number") ? index % 2 === 0 ? "even-freeze-cell" : "freeze-cell" : ""}`}
                                                    style={
                                                        moduleName === "Rev assurance" && header === "service_number"
                                                            ? { position: "sticky", left: (typeof window !== "undefined" && window.innerWidth < 700) ? 75 : 50, zIndex: 5 }
                                                            : {}
                                                    }>

                                                    {renderCell(row, header, index)}

                                                </td>
                                            )
                                        )}
                                        {allowedActions && visibleColumns.length > 0 && (
                                            <td className="border-b border-gray-300 table-cell">
                                                <div className="flex items-center space-x-2">
                                                    {allowedActions.includes("download") && (
                                                        moduleName === 'Optimization' ? (
                                                            row?.download && (
                                                                <Tooltip title="Download">
                                                                    <ArrowDownTrayIcon
                                                                        className="h-5 w-5 text-blue-500 cursor-pointer"
                                                                        onClick={() => handleActionClick("download", index)}
                                                                    />
                                                                </Tooltip>
                                                            )
                                                        ) : (
                                                            <Tooltip title="Download">
                                                                <ArrowDownTrayIcon
                                                                    className="h-5 w-5 text-blue-500 cursor-pointer"
                                                                    onClick={() => handleActionClick("download", index)}
                                                                />
                                                            </Tooltip>
                                                        )
                                                    )}
                                                    {allowedActions.includes("upload") && row?.upload && (
                                                        <Tooltip title="Upload">
                                                            <ArrowUpTrayIcon
                                                                className="h-5 w-5 text-red-500 cursor-pointer"
                                                                onClick={() => handleActionClick("upload", index)}
                                                            />
                                                        </Tooltip>
                                                    )}
                                                    {allowedActions.includes("info-status") && row?.info && (
                                                        <span>
                                                            <InfoCellRenderer row={row} />
                                                        </span>
                                                    )}
                                                </div>
                                            </td>
                                        )}
                                    </tr>
                                ))
                            ) : (
                                <tr>
                                    <td
                                        colSpan={
                                            headers.filter((header) => visibleColumns.includes(header)).length + 1
                                        }
                                        className="px-6 py-3 border-b border-gray-300 text-center text-gray-500"
                                    >
                                        No Records Found
                                    </td>
                                </tr>
                            )}
                        </tbody>

                    </table>
                </div>
            </div>
            <div className="flex justify-center">
                {/* {rowData.length===100 && visibleColumns.length > 0 && */}
                {/* <div className="flex justify-center mt-5">
                    <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} moduleName={moduleName} />
                </div> */}
                {/* } */}
                {(!isSmallScreen) && (
                    <div className="flex justify-center mt-5">
                        <Pagination currentPage={currentPage} totalPages={totalPages} onPageChange={setCurrentPage} moduleName={moduleName} />
                    </div>
                )}

                {/* {moduleName !== "Disconnect Service Product" && ( */}

                {/* )} */}
            </div>

            {
                isDownload && (
                    <DownloadModal
                        visible={isDownload}
                        rows={downloadRowIndex !== null ? [rowData[downloadRowIndex]] : null}
                        onCancel={handleCloseModal}
                        moduleName={moduleName}
                    />
                )
            }

            {
                isUpload && (
                    <RowUploadModal
                        visible={isUpload}
                        rows={uploadRowIndex !== null ? [rowData[uploadRowIndex]] : null}
                        onCancel={handleCloseModal}
                        optimization_type={uploadRowIndex !== null ? rowData[uploadRowIndex].optimization_type : null}
                    />
                )
            }
            {
                showRowModal &&
                <RowDetailsModal
                    row={showRowModalData}
                    headerMap={headerMap}
                    onClose={() => {
                        setShowRowModal(false)
                        setShowRowModalData(null)
                    }}
                    isOpen={showRowModal}
                />
            }
            {
                openPartnerInfoModal &&
                <InfoModal
                    openInfoModal={openPartnerInfoModal}
                    setInfoModal={setOpenPartnerInfoModal}
                    moduleName={partnerInfoModuleName}
                />
            }
        </div >
    );
};

export default RevTableComponent;
