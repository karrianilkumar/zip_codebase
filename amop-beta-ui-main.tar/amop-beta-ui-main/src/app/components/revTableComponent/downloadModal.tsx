import React from 'react';
import { Modal, notification } from 'antd';
import { useAuth } from '../auth_context';
import axios from 'axios';
import { ENV_ROUTES } from '../routes/route_constants';
import { getCurrentDateTime } from '../header_constants';

interface DownloadModalProps {
    visible: boolean;
    onCancel: () => void;
    rows: any;  // You can type this according to your data structure
    moduleName:any
}
const messageStyle = {
    fontSize: '14px',  
    fontWeight: 'bold', 
    padding: '16px',
  };
const DownloadModal: React.FC<DownloadModalProps> = ({ visible, onCancel, rows ,moduleName}) => {
    const { username, partner, role, token, selectedDb,metaData, firstLastName,sessionId} = useAuth();

    //To convert the blob to excel
    const downloadExcelBlob = (base64Blob: string,title:string) => {
        const byteCharacters = atob(base64Blob);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
          byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);
    
        const blobObject = new Blob([byteArray], {
          type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        });
        const link = document.createElement("a");
        link.href = URL.createObjectURL(blobObject);
        link.download = `${title}.xlsx`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      };
    
    const downloadZipBlob = (base64Blob: string) => {

        // Convert base64 string to binary data
        const byteCharacters = atob(base64Blob);
        const byteNumbers = new Array(byteCharacters.length);
        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }
        const byteArray = new Uint8Array(byteNumbers);

        // Create a Blob from the byteArray with a type of zip
        const blobObject = new Blob([byteArray], {
            type: "application/zip",
        });

        // Create a download link and trigger it to download the .zip file
        const link = document.createElement("a");
        link.href = URL.createObjectURL(blobObject);
        link.download =`${moduleName}.zip`; // Ensure to download as .zip
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };
    const handleSave=async()=>{
        let new_rows = rows.map((row:any) => {
            let newRow = { ...row }; // Create a shallow copy of the row
            if (newRow.id) {
                delete newRow.id;
            }
            return newRow; // Return the modified row
        });
        let path_
        try {
            if(moduleName==='Customer charges'){
                path_="/export_row_data_customer_charges"
            }
            if(moduleName==='Optimization'){
                path_="/download_row_data_optimization"
            }
        const url = ENV_ROUTES.SIM_MANAGEMENT
        let data :any= {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path:path_,
            role_name: role,
            module_name: moduleName,
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            new_data:new_rows,
        };
        if(moduleName==='Customer charges'){
            data['queue_id']=rows[0]?.queue_id
        }

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
            onCancel()
            Modal.error({
                title: 'Download Error',
                content: parsedData.message || 'An error occurred while downloading the record. Please try again.',
                centered: true,
            });
        } else {
            let title="";
            if(moduleName==='Customer charges'){
                downloadExcelBlob(parsedData?.blob,parsedData?.filename)
            }
            if(moduleName==='Optimization'){
                downloadZipBlob(parsedData?.blob);
            }
            onCancel()
            notification.success({
                message: 'Success',
                description: 'Downloaded successfully',
                style: messageStyle,
                placement: 'top', // Apply custom styles here
              });
        }
    }
    catch(error){
        console.log(error)
        onCancel()
    }
    finally{
        onCancel()
    }
    }

    return (
        <Modal
            title="Download Record"
            visible={visible}
            onCancel={onCancel}
            centered
            footer={
            <div className='flex justify-center space-x-4'>
                <button
                    key="cancel"
                    onClick={onCancel}
                    className='cancel-btn'>
                    Cancel
                </button>
                <button
                    key="save"
                    onClick={handleSave}
                    className='save-btn'>
                    Download
                </button>
            </div>
            }
        >
            <p>{`Do you want to download this ${rows.length>0?'records':'record'}`}</p>
        </Modal>
    );
};

export default DownloadModal;
