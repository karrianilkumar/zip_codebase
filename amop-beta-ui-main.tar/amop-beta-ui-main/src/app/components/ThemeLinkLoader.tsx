// components/ThemeLinkLoader.tsx
'use client';
import { useEffect, useState } from 'react';
import { useAuth } from './auth_context';

const THEME_MAP: Record<string, string> = {
  titanium: '/theme-titanium.css',
  red: '/theme-red.css',
  green: '/theme-green.css',
  dark: '/theme-dark.css',
};

export default function ThemeLinkLoader() {
  const { partner } = useAuth();
  const defaultTheme = partner && partner.toLowerCase().includes( "algonox")?'titanium':'normal'
  const [theme, setTheme] = useState('');

  useEffect(() => {
    const savedTheme = localStorage.getItem('app_theme') || defaultTheme;
    setTheme(savedTheme);
  }, []);

  useEffect(() => {
    // remove old theme <link>
    const existing = document.getElementById('dynamic-theme');
    if (existing) existing.remove();

    if (theme !== 'normal') {
      const link = document.createElement('link');
      link.id = 'dynamic-theme';
      link.rel = 'stylesheet';
      link.href = THEME_MAP[theme];
      document.head.appendChild(link);
    }
  }, [theme]);

  return null;
}
