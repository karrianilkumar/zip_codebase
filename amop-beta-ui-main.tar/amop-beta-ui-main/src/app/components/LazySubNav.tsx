import React from "react";
import Link from "next/link";
import { ChevronDownIcon, ChevronRightIcon } from "@heroicons/react/24/outline";

interface SubNavProps {
  subNav: any[];
  currentPath: string;
  getTitle: (title: string, href?: string) => void;
}

const LazySubNav: React.FC<SubNavProps> = ({
  subNav,
  currentPath,
  getTitle,
}) => {
  return (
    <ul className="pl-6 space-y-2 mt-2">
      {subNav.map((subItem) => (
        <li key={subItem.label}>
          {subItem.subNav && subItem.subNav.length > 0 ? (
            <>
              <button
                onClick={() => getTitle(subItem.label, subItem.href)}
                className={`flex items-center space-x-2 p-2 nav-link w-[100%] ${
                  currentPath.startsWith(subItem.href) ? "nav-active-link" : ""
                }`}
              >
                <span>{subItem.label}</span>
                {subItem.subNav.length > 0 ? (
                  <ChevronDownIcon
                    className="w-4 h-4 absolute"
                    style={{ right: "20px" }}
                  />
                ) : (
                  <ChevronRightIcon
                    className="w-4 h-4 absolute"
                    style={{ right: "20px" }}
                  />
                )}
              </button>
              <LazySubNav
                subNav={subItem.subNav}
                currentPath={currentPath}
                getTitle={getTitle}
              />
            </>
          ) : (
            <Link
              href={subItem.href || "/"}
              passHref
              prefetch={true} // Enable route prefetching
              className={`flex items-center space-x-2 p-2 nav-link ${
                currentPath === subItem.href ? "nav-active-link" : ""
              }`}
              onClick={() => getTitle(subItem.label, subItem.href)}
            >
              <span>{subItem.label}</span>
            </Link>
          )}
        </li>
      ))}
    </ul>
  );
};

export default LazySubNav;
