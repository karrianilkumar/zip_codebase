"use client";
import React, { useEffect, useRef, useState } from "react";
import Pagination from "@/app/components/pagination";
import { Modal, Spin, Tooltip, Select, Input, InputNumber, Upload, notification, message } from "antd";
import {
    ArrowUpOutlined,
    ArrowDownOutlined,
    UploadOutlined,
    DownloadOutlined,
    LoadingOutlined,
    CloseOutlined,
} from "@ant-design/icons";
import axios from "axios";
import { useSearchStore } from "@/app/stores/searchStore";
import { useAuth } from "@/app/components/auth_context";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { ArrowUpTrayIcon, PlusIcon } from "@heroicons/react/24/outline";
import { usePrivateNetworkStore } from "../stores/privateNetworksStore";
import { fireSideCannons } from "./confetti";

const headerMap: any = {
    "service_provider": [
        "Service Provider",
        "1"
    ],
    "apn": [
        "APN",
        "2"
    ],
    "pdp": [
        "PDP",
        "3"
    ],
    "ip_text": [
        "IP Range",
        "4"
    ],
    "ip_version": [
        "IP Version",
        "5"
    ]
}


const headers: string[] = ["service_provider", "apn", "pdp", "ip_text", "ip_version"]

interface PrivateNetworkTableProps {
    isPartnerCreation?: boolean;
    selectedPartnerName?: string;
    selectedPartnerDB?: string;
    selectedPartnerMetaData?: any;
    selectedPartnerID?: string;
    initialData: { [key: string]: any }[];
    itemsPerPage: number;
    popupHeading: string;
    pagination: any;
    height?: any;
    serviceProviderOptions: any[]
    isEditable: boolean;
    row?: any,
    onFetch?: () => void;
    subTenant?:string
}

const PrivateNetworkTable: React.FC<PrivateNetworkTableProps> = ({
    initialData,
    itemsPerPage,
    popupHeading,
    pagination,
    height,
    serviceProviderOptions,
    isEditable,
    isPartnerCreation,
    selectedPartnerName,
    selectedPartnerDB,
    selectedPartnerMetaData,
    selectedPartnerID,
    row, onFetch,subTenant
}) => {
    const { Option } = Select;

    const [rowData, setRowData] = useState<{ [key: string]: any }[]>(initialData);
    const [currentPage, setCurrentPage] = useState(1);
    const isFirstRender = useRef(true);

    const [sortConfig, setSortConfig] = useState<{ key: string; direction: "ascending" | "descending"; } | null>(null);
    const {
        username,
        role,
        partner,
        tabledata,
        storedpagination,
        advancedStoredpagination,
        combineAdnvaceStoredpagination,
        token,
        selectedDb, metaData,
        sessionId,
        setAdvancedStoredPagination,
        setStoredPagination,
        setCombineAdnvaceStoredpagination,
        firstLastName
    } = useAuth();
    const [totalPages, setTotalPages] = useState(1);
    const [loading, setLoading] = useState(false);
    const [modalloading, setModalLoading] = useState(false);

    //Viewport height
    const [viewportHeight, setViewportHeight] = useState(window.innerHeight);
    // Add state to track screen width
    const [isSmallScreen, setIsSmallScreen] = useState(false);

    const [pdpOptions, setPdpOptions] = useState<{ [key: string]: any }>({})
    const [apnOptions, setAPNOptions] = useState<{ [key: string]: any }>({})
    const [ipVersionOptions, setIPVersionOptions] = useState<any[]>([])
    const { setEditedTableData } = usePrivateNetworkStore();
    const [isUploadModalVisible, setIsUploadModalVisible] = useState(false);
    const [isFileSelected, setIsFileSelected] = useState(false);
    const [uploadKey, setUploadKey] = useState(Date.now());
    // Check for small screen on component mount and window resize
    useEffect(() => {
        const checkScreenSize = () => {
            setIsSmallScreen(window.innerWidth < 700);
        };

        // Initial check
        checkScreenSize();

        // Add event listener for window resize
        window.addEventListener('resize', checkScreenSize);

        // Clean up
        return () => window.removeEventListener('resize', checkScreenSize);
    }, []);

    useEffect(() => {
        // setAdvancedStoredPagination(null)
        setStoredPagination(null)
        setCombineAdnvaceStoredpagination(null)
        const handleResize = () => {
            setViewportHeight(window.innerHeight);
        };

        // Add event listener for window resize
        window.addEventListener("resize", handleResize);

        // Cleanup event listener on component unmount
        return () => {
            window.removeEventListener("resize", handleResize);
        };
    }, []);

    useEffect(() => {
        if (row) {
            console.log("row", row)
            const initial_data = row?.private_networks_json || []
            const updatedData = (initial_data.length > 0 ? initial_data : rowData).map((r: any) => ({
                ...r,
                canEdit: false,
            }));
            setRowData(updatedData)
        }
    }, [row]);

    useEffect(() => {
        setEditedTableData([...rowData])
    }, [rowData]);

    // Apply default IP version to rows that don't have it set
    useEffect(() => {
        if (ipVersionOptions && ipVersionOptions.length > 0 && rowData.length > 0) {
            const updatedRowData = rowData.map((row) => {
                if (!row.ip_version) {
                    return {
                        ...row,
                        ip_version: ipVersionOptions[0]
                    };
                }
                return row;
            });

            // Only update if something actually changed
            const hasChanges = updatedRowData.some((row, idx) => row.ip_version !== rowData[idx].ip_version);
            if (hasChanges) {
                setRowData(updatedRowData);
            }
        }
    }, [ipVersionOptions]);

    const fetchData = async (column: string, value: any, rowIndex: number) => {
        const currentRow = rowData[rowIndex]
        setLoading(true);
        try {
            const url = ENV_ROUTES.MODULE_MANAGEMENT;
            const data = {
                tenant_name: isPartnerCreation ? selectedPartnerName || "" :partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_service_provider_pdp_apn_ip_mappings",
                role_name: role,
                module_name: "Customer Group",
                request_received_at: getCurrentDateTime(),
                Partner: isPartnerCreation ? selectedPartnerName || "" :partner,
                access_token: token,
                db_name:isPartnerCreation ? selectedPartnerDB || "" : selectedDb,
                ...(isPartnerCreation ? selectedPartnerMetaData || "" : metaData),
                sessionID: sessionId,
                sub_partner: isPartnerCreation ? selectedPartnerName || "" : subTenant,
                ...(column === "service_provider" &&
                {
                    service_provider: value,
                    apn: "",
                    pdp: ""
                }),
                ...(column === "apn" &&
                {
                    service_provider: currentRow?.service_provider || "",
                    apn: value,
                    pdp: ""
                }),
                ...(column === "pdp" &&
                {
                    service_provider: currentRow?.service_provider || "",
                    apn: currentRow?.apn || "",
                    pdp: value
                }),

            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === false) {
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                if (column === "service_provider") {
                    const apn_names = parsedData?.data?.apn_names || []
                    setAPNOptions((prev) => {
                        const updated_options = {
                            ...prev,
                            [value]: [...apn_names]
                        }
                        return updated_options
                    })
                }
                if (column === "apn") {
                    const pdp_types = parsedData?.data?.pdp_types || []
                    setPdpOptions((prev) => {
                        const updated_options = {
                            ...prev,
                            [value]: [...pdp_types]
                        }
                        return updated_options
                    })
                }
                if (column === "pdp") {
                    const ip_addresses = parsedData?.data?.ip_addresses || [];
                    setRowData((prevData) => {
                        const newData = [...prevData];
                        newData[rowIndex] = {
                            ...newData[rowIndex],
                            ip_text: "",
                            ip_text_options: ip_addresses,
                        };
                        return newData;
                    });
                }
                const ip_versions = parsedData?.data?.ip_versions || []
                setIPVersionOptions(ip_versions)

            }
        } catch (error) {
            console.error("Error fetching data:", error);
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        } finally {
            setLoading(false);

        }
    };



    useEffect(() => {
        setCurrentPage(1);
    }, [totalPages]);

    // useEffect(() => {
    //     console.log("rowData",rowData)
    // }, [rowData]);

    useEffect(() => {
        let pagination_;
        // let pagination_;
        if (combineAdnvaceStoredpagination) {
            pagination_ = combineAdnvaceStoredpagination
        }
        else if (advancedStoredpagination && !storedpagination) {
            pagination_ = advancedStoredpagination
        }
        else if (storedpagination && !advancedStoredpagination) {
            pagination_ = storedpagination
        }
        else {
            pagination_ = pagination
        }


        const start = pagination_?.start || 1;
        const total = pagination_?.total || 1;
        const end = pagination_?.end || 1;
        const totalPages_ = Math.ceil(total / itemsPerPage);
        setTotalPages(totalPages_);
    }, [initialData, pagination, itemsPerPage, currentPage, storedpagination, advancedStoredpagination, combineAdnvaceStoredpagination, sortConfig]);

    const updatePaginator = async () => {
        const startIndex = (currentPage - 1) * itemsPerPage;
        const endIndex = startIndex + itemsPerPage;
        try {
            const updatedData = rowData.slice(startIndex, endIndex)
            setRowData(updatedData)
            console.log("updatedData paginator", updatedData)


        } catch (err) {
            console.error("Error fetching data:", err);
        } finally {
        }
        // }
    };

    // useEffect(() => {
    //     updatePaginator();

    // }, [currentPage]);
    //For sorting the table
    const handleSort = (key: string) => {
        let direction: "ascending" | "descending" = "ascending";
        if (
            sortConfig &&
            sortConfig.key === key &&
            sortConfig.direction === "ascending"
        ) {
            direction = "descending";
        }

        const sortedData = [...rowData].sort((a, b) => {
            let aValue = a[key];
            let bValue = b[key];

            // Special handling for the "Assigned rate plans" or "Assigned rate plan count" columns
            if (key === "carrier_rate_plans") {
                aValue = Array.isArray(aValue) ? aValue.length : JSON.parse(aValue)?.length || 0;
                bValue = Array.isArray(bValue) ? bValue.length : JSON.parse(bValue)?.length || 0;
            }

            // Convert 'None' to null for easier comparison
            const normalizeValue = (value: any) => {
                if (value === 'None') return null;
                return value;
            };

            aValue = normalizeValue(aValue);
            bValue = normalizeValue(bValue);

            // Function to split a string into alphabetical and numeric segments
            const splitIntoSegments = (str: string) => {
                return str.toLowerCase().match(/([a-z]+|\d+)/g) || [];
            };

            // Split values into segments
            const aSegments = typeof aValue === "string" ? splitIntoSegments(aValue) : [aValue];
            const bSegments = typeof bValue === "string" ? splitIntoSegments(bValue) : [bValue];

            // Compare each segment one by one
            for (let i = 0; i < Math.max(aSegments.length, bSegments.length); i++) {
                const aSegment = aSegments[i];
                const bSegment = bSegments[i];

                // If one segment is undefined, consider it smaller
                if (aSegment === undefined) return direction === "ascending" ? -1 : 1;
                if (bSegment === undefined) return direction === "ascending" ? 1 : -1;

                // Compare numeric segments numerically, and character segments lexicographically
                const isANumber = !isNaN(Number(aSegment));
                const isBNumber = !isNaN(Number(bSegment));

                if (isANumber && isBNumber) {
                    // Both segments are numbers; compare them numerically
                    const numA = Number(aSegment);
                    const numB = Number(bSegment);
                    if (numA < numB) return direction === "ascending" ? -1 : 1;
                    if (numA > numB) return direction === "ascending" ? 1 : -1;
                } else {
                    // At least one segment is not a number; compare them as strings
                    if (aSegment < bSegment) return direction === "ascending" ? -1 : 1;
                    if (aSegment > bSegment) return direction === "ascending" ? 1 : -1;
                }
            }

            return 0;
        });

        setSortConfig({ key, direction });
        setRowData(sortedData);
    };

    const handleDeleteRow = (rowIndex: any) => {
        setRowData((prevRows) => prevRows.filter((_, index) => index !== rowIndex));
    }

    // Add new row
    const handleAddRow = () => {
        // Validate every row
        const hasIncompleteRow = rowData.some((row) =>
            headers.some((header) => {
                const value = row[header];
                return value === "" || value === null || value === undefined;
            })
        );

        if (hasIncompleteRow) {
            Modal.info({
                title: "Incomplete Rows",
                content: "Please fill all fields in every row before adding a new row.",
                centered: true,
            });
            return;
        }

        // Create new empty row
        const newRow: any = { canEdit: true };

        headers.forEach((header) => {
            newRow[header] = "";
        });

        // Set IP version to first option by default
        newRow["ip_version"] = ipVersionOptions && ipVersionOptions.length > 0 ? ipVersionOptions[0] : null;

        setRowData((prev) => [...prev, newRow]);
    };


    // for Service Provider Name (dropdown)
    const handleDropdownChange = (value: string, rowIndex: number, header: any) => {
        setRowData((prevData) => {
            const newData = [...prevData];
            newData[rowIndex] = {
                ...newData[rowIndex],
                [header]: value,
                ...(header === "service_provider" ? {
                    apn: null,
                    pdp: null,
                    ip_text: null,
                    ip_text_options: []
                } : {}),
                ...(header === "apn" ? {
                    pdp: null,
                    ip_text: null,
                    ip_text_options: []
                } : {}),
                ...(header === "pdp" ? {
                    ip_text: null,
                    ip_text_options: []
                } : {})
            };
            return newData;
        });
        if (value && ["service_provider", "apn", "pdp"].includes(header)) {
            fetchData(header, value, rowIndex)
        }
    };


    type ParseResult = {
        valid: boolean;
        family?: "ipv4" | "ipv6";
        startParts: number[]; // length 4 for ipv4, 8 for ipv6
        endParts: number[];
    };

    const padHex4 = (n: number) => n.toString(16).toUpperCase().padStart(4, "0");

    // Expand compressed IPv6 like "2001:db8::1" -> ["2001","0DB8","0000","0000","0000","0000","0000","0001"]
    const expandIPv6 = (input: string): string[] | null => {
        const raw = input.trim();
        if (!raw) return null;
        // validation quick check
        const ipv6Regex = /^(([0-9A-Fa-f]{1,4}:){1,7}[0-9A-Fa-f]{1,4}|::|([0-9A-Fa-f]{1,4}:){1,7}:|:([0-9A-Fa-f]{1,4}:){1,7})$/;
        // We'll not rely only on regex; implement expansion more permissively:
        if (raw.indexOf("::") !== -1) {
            const [left, right] = raw.split("::");
            const leftParts = left ? left.split(":").filter(Boolean) : [];
            const rightParts = right ? right.split(":").filter(Boolean) : [];
            if (leftParts.some(p => p.length > 4) || rightParts.some(p => p.length > 4)) return null;
            const missing = 8 - (leftParts.length + rightParts.length);
            if (missing < 0) return null;
            const mid = new Array(missing).fill("0");
            const parts = [...leftParts, ...mid, ...rightParts].map(p => p || "0");
            if (parts.length !== 8) return null;
            return parts.map(p => p.padStart(4, "0").toUpperCase());
        } else {
            const parts = raw.split(":");
            if (parts.length !== 8) return null;
            if (parts.some(p => p.length === 0 || p.length > 4)) return null;
            return parts.map(p => p.padStart(4, "0").toUpperCase());
        }
    };

    // Parse IPv4 numeric dotted -> parts
    const ipv4ToParts = (ip: string): number[] => ip.split(".").map(p => {
        const n = Number(p);
        if (Number.isNaN(n)) return 0;
        return Math.max(0, Math.min(255, Math.trunc(n)));
    }).slice(0, 4).concat([0, 0, 0, 0]).slice(0, 4);

    // Check full dotted IPv4
    const ipv4Regex = /^(\d{1,3}\.){3}\d{1,3}$/;
    // Basic IPv6 range regex (loose) - accepts hex blocks and ::
    const ipv6SingleRegex = /^([0-9A-Fa-f:]+)$/;
    const rangeRegexIPv4 = /^(\d{1,3}\.){3}\d{1,3}\s*-\s*(\d{1,3}\.){3}\d{1,3}$/;
    const rangeRegexIPv6 = /^([0-9A-Fa-f:]+)\s*-\s*([0-9A-Fa-f:]+)$/;

    const parseIpOrRange = (value?: string): ParseResult => {
        const raw = String(value ?? "").trim();
        if (!raw) return { valid: false, startParts: [0, 0, 0, 0], endParts: [0, 0, 0, 0] };

        // IPv4 single
        if (ipv4Regex.test(raw)) {
            const p = ipv4ToParts(raw) as number[];
            return { valid: true, family: "ipv4", startParts: p, endParts: p.slice() };
        }

        // IPv4 range
        if (rangeRegexIPv4.test(raw)) {
            const [s, e] = raw.split("-").map(s => s.trim());
            const sp = ipv4ToParts(s);
            const ep = ipv4ToParts(e);

            const lexCompare = (a: number[], b: number[]) => {
                for (let i = 0; i < 4; i++) {
                    if (a[i] < b[i]) return -1;
                    if (a[i] > b[i]) return 1;
                }
                return 0;
            };

            if (lexCompare(sp, ep) <= 0) return { valid: true, family: "ipv4", startParts: sp, endParts: ep };
            return { valid: true, family: "ipv4", startParts: ep, endParts: sp };
        }

        // IPv6 single or range
        if (ipv6SingleRegex.test(raw)) {
            // is single IPv6?
            if (!raw.includes("-")) {
                const expanded = expandIPv6(raw);
                if (!expanded) return { valid: false, startParts: [0, 0, 0, 0], endParts: [0, 0, 0, 0] };
                const parts = expanded.map(h => parseInt(h, 16));
                return { valid: true, family: "ipv6", startParts: parts, endParts: parts.slice() };
            }
        }

        // IPv6 range (a-b)
        const m6 = raw.match(rangeRegexIPv6);
        if (m6) {
            const sRaw = m6[1].trim();
            const eRaw = m6[2].trim();
            const sExp = expandIPv6(sRaw);
            const eExp = expandIPv6(eRaw);
            if (!sExp || !eExp) return { valid: false, startParts: [0, 0, 0, 0], endParts: [0, 0, 0, 0] };
            const sp = sExp.map(h => parseInt(h, 16));
            const ep = eExp.map(h => parseInt(h, 16));
            const lexCompare = (a: number[], b: number[]) => {
                for (let i = 0; i < 8; i++) {
                    if (a[i] < b[i]) return -1;
                    if (a[i] > b[i]) return 1;
                }
                return 0;
            };
            if (lexCompare(sp, ep) <= 0) return { valid: true, family: "ipv6", startParts: sp, endParts: ep };
            return { valid: true, family: "ipv6", startParts: ep, endParts: sp };
        }

        return { valid: false, startParts: [0, 0, 0, 0], endParts: [0, 0, 0, 0] };
    };

const isRangeWithin = (
    start: number[],
    end: number[],
    allowedStart: number[],
    allowedEnd: number[]
) => {
    const lexCompare = (a: number[], b: number[]) => {
        for (let i = 0; i < a.length; i++) {
            if (a[i] < b[i]) return -1;
            if (a[i] > b[i]) return 1;
        }
        return 0;
    };

    return (
        lexCompare(start, allowedStart) >= 0 &&
        lexCompare(end, allowedEnd) <= 0
    );
};

    // octetIndex: 0..3 for ipv4, 0..7 for ipv6
    // value: for ipv4 use number; for ipv6 you can pass hex string or decimal number
    const handleIpRangeChange = (
        rowIndex: number,
        column: string,
        which: "start" | "end",
        octetIndex: number,
        value?: number | string
    ) => {
        if (value == null) return;
        const tableData_ =rowData[rowIndex]
        setRowData((prevData: any[]) => {
            const newData = prevData.map((row, idx) => {
                // Only update the specific row
                if (idx !== rowIndex) return row;

                const rawVal = String(row.ip_text ?? "");
                const parsed = parseIpOrRange(rawVal);
                const originalParsed = parseIpOrRange(tableData_?.ip_text);
                if (!parsed.valid || !parsed.family) return row;
                if (!originalParsed.valid || !originalParsed.family) {
                    return row;
                }                

                const isV4 = parsed.family === "ipv4";
                const clampV4 = (n: number) => Math.max(0, Math.min(255, Math.trunc(n)));
                const clampV6 = (n: number) => Math.max(0, Math.min(0xFFFF, Math.trunc(n)));

                const nextStart = [...parsed.startParts];
                const nextEnd = [...parsed.endParts];

                // parse value according to family
                let numericValue: number;
                if (typeof value === "string") {
                    const v = value.trim();
                    if (v === "" || v === "-") return row; // Ignore empty or just dash
                    if (v.startsWith("0x") || /^[0-9A-Fa-f]+$/.test(v)) {
                        numericValue = parseInt(v.replace(/^0x/i, ""), 16);
                    } else {
                        numericValue = Number(v);
                    }
                } else {
                    numericValue = Number(value);
                }

                if (Number.isNaN(numericValue)) return row;

                // Update the specific octet
                if (isV4) {
                    if (octetIndex < 0 || octetIndex > 3) return row;
                    if (which === "start") {
                        nextStart[octetIndex] = clampV4(numericValue);
                    } else {
                        nextEnd[octetIndex] = clampV4(numericValue);
                    }
                } else {
                    if (octetIndex < 0 || octetIndex > 7) return row;
                    if (which === "start") {
                        nextStart[octetIndex] = clampV6(numericValue);
                    } else {
                        nextEnd[octetIndex] = clampV6(numericValue);
                    }
                }

                // Ensure lexicographic order start <= end
                const lexCompare = (a: number[], b: number[]) => {
                    const len = a.length;
                    for (let i = 0; i < len; i++) {
                        if (a[i] < b[i]) return -1;
                        if (a[i] > b[i]) return 1;
                    }
                    return 0;
                };

                let finalStart = nextStart;
                let finalEnd = nextEnd;
                const isValidRange = isRangeWithin(
                    finalStart,
                    finalEnd,
                    originalParsed.startParts,
                    originalParsed.endParts
                );
                
                if (!isValidRange) {
                    Modal.warning({
                        title: "Invalid IP Range",
                        content: (
                            <div>
                                {("The selected IP range must remain within the original allocated range./nPlease adjust the start and end values.")
                                    .split('/n')
                                    .map((line: string, index: number) => (
                                        <div key={index}>{line}</div>
                                    ))}
                            </div>
                        ),
                        centered: true,
                    })
                    return row; // ❌ Prevent update
                }
                if (lexCompare(finalStart, finalEnd) > 0) {
                    [finalStart, finalEnd] = [finalEnd, finalStart];
                }

                // Format canonical display string
                let display = "";
                if (isV4) {
                    display = `${finalStart.join(".")}-${finalEnd.join(".")}`;
                } else {
                    display = `${finalStart.map(n => padHex4(n)).join(":")}-${finalEnd.map(n => padHex4(n)).join(":")}`;
                }

                return {
                    ...row,
                    ip_text: display,
                };
            });

            return newData;
        });
    };




    //For custom cell rendering
    const renderCell = (cellData: any, column: string, rowIndex: number) => {
        const currentRow = rowData[rowIndex] || {}
        // inside renderCell...
        if (
            popupHeading === "Billing Customers" &&
            headerMap?.[column]?.[0] === "IP Range" &&
            currentRow?.canEdit
        ) {
            const usedRanges = new Set(
                rowData
                    .filter((row, idx) =>
                        idx !== rowIndex &&
                        row?.service_provider === currentRow?.service_provider &&
                        row?.apn === currentRow?.apn &&
                        row?.pdp === currentRow?.pdp &&
                        row?.ip_text
                    )
                    .map((row) => row.ip_text)
            );
            const dropdownOptions = (currentRow?.ip_text_options || []).filter(
                (option: string) => !usedRanges.has(option) || option === cellData
            );

            if (dropdownOptions.length > 0) {
                return (
                    <Select
                        value={cellData}
                        placeholder="Select IP Range"
                        style={{ width: "100%", font: "16px" }}
                        className="min-w-[250px] table-drp"
                        onChange={(value) => handleDropdownChange(value, rowIndex, column)}
                        showSearch
                        allowClear
                    >
                        {dropdownOptions.map((option: string) => (
                            <Option key={option} value={option}>
                                {option}
                            </Option>
                        ))}
                    </Select>
                );
            }

            const rawVal = String(cellData ?? "");
            const parsed = parseIpOrRange(rawVal);

            if (!parsed.valid || !parsed.family) {
                return (
                    <Tooltip
                        title={rawVal}
                        placement="topLeft"
                        overlayStyle={{ whiteSpace: "normal", maxWidth: "60vw", wordWrap: "break-word", zIndex: 50 }}
                        getPopupContainer={() => document.body}
                    >
                        <span>{rawVal}</span>
                    </Tooltip>
                );
            }

            const isV4 = parsed.family === "ipv4";
            const startParts = parsed.startParts;
            const endParts = parsed.endParts;

            // For IPv4: number inputs; For IPv6: text inputs accepting hex (4-digit)
            const renderPartInput = (which: "start" | "end", idx: number, val: number) => {
                if (isV4) {
                    return (
                        <input
                            key={`${which}-${idx}-${rowIndex}`} // Add rowIndex to key
                            type="number"
                            min={0}
                            max={255}
                            step={1}
                            value={val}
                            onBlur={(e) => {
                                const newVal = e.target.valueAsNumber;
                                if (!isNaN(newVal)) {
                                    handleIpRangeChange(rowIndex, column, which, idx, newVal);
                                }
                            }}
                            onChange={(e) => {
                                const newVal = e.target.valueAsNumber;
                                if (!isNaN(newVal)) {
                                    handleIpRangeChange(rowIndex, column, which, idx, newVal);
                                }
                            }}
                            readOnly
                            className="border border-gray-300 rounded px-1 w-16 text-center focus:outline-none focus:ring-1 focus:ring-blue-500"
                        />
                    );
                } else {
                    const hexVal = padHex4(val);
                    return (
                        <input
                            key={`${which}-${idx}-${rowIndex}`} // Add rowIndex to key
                            type="text"
                            inputMode="text"
                            pattern="[0-9A-Fa-f]{1,4}"
                            value={hexVal}
                            onChange={(e) => {
                                const newVal = e.target.value.replace(/^0x/i, "");
                                if (newVal && /^[0-9A-Fa-f]*$/.test(newVal)) {
                                    handleIpRangeChange(rowIndex, column, which, idx, newVal);
                                }
                            }}
                            readOnly
                            className="border border-gray-300 rounded px-1 w-20 text-center font-mono text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
                        />
                    );
                }
            };
            if (isV4) {
                return (
                    <div className="items-center gap-2 space-y-2">
                        <div className="flex items-center gap-1">
                            {renderPartInput("start", 0, startParts[0])}
                            <span className="select-none">.</span>
                            {renderPartInput("start", 1, startParts[1])}
                            <span className="select-none">.</span>
                            {renderPartInput("start", 2, startParts[2])}
                            <span className="select-none">.</span>
                            {renderPartInput("start", 3, startParts[3])}
                        </div>

                        <div className="flex items-center gap-1">
                            {renderPartInput("end", 0, endParts[0])}
                            <span className="select-none">.</span>
                            {renderPartInput("end", 1, endParts[1])}
                            <span className="select-none">.</span>
                            {renderPartInput("end", 2, endParts[2])}
                            <span className="select-none">.</span>
                            {renderPartInput("end", 3, endParts[3])}
                        </div>
                    </div>
                );
            } else {
                return (
                    <div className="items-center gap-2 space-y-2">
                        <div className="flex items-center gap-1">
                            {startParts.map((p, i) => (
                                <React.Fragment key={`s-${i}`}>
                                    {renderPartInput("start", i, p)}
                                    {i < 7 && <span className="select-none">:</span>}
                                </React.Fragment>
                            ))}
                        </div>

                        <div className="flex items-center gap-1">
                            {endParts.map((p, i) => (
                                <React.Fragment key={`e-${i}`}>
                                    {renderPartInput("end", i, p)}
                                    {i < 7 && <span className="select-none">:</span>}
                                </React.Fragment>
                            ))}
                        </div>
                    </div>
                );
            }
        }


        // Service Provider dropdown
        if (
            popupHeading === "Billing Customers" &&
            headerMap?.[column]?.[0] === "Service Provider" && !(rowData[rowIndex].id)
            && currentRow?.canEdit
        ) {
            return (
                <Select
                    value={cellData}
                    placeholder="Select Provider"
                    style={{ width: "100%", font: "16px" }}
                    className="table-drp"
                    onChange={(value) => handleDropdownChange(value, rowIndex, column)}
                    showSearch
                    allowClear
                >
                    {serviceProviderOptions.map((provider: string) => (
                        <Option key={provider} value={provider}>
                            {provider}
                        </Option>
                    ))}
                </Select>
            );
        }

        // APN input
        if (
            popupHeading === "Billing Customers" &&
            headerMap?.[column]?.[0] === "APN" && currentRow?.canEdit
        ) {
            return (
                <Select
                    value={cellData}
                    placeholder="Select APN"
                    style={{ width: "100%", font: "16px" }}
                    className="table-drp"
                    onChange={(value) => handleDropdownChange(value, rowIndex, column)}
                    showSearch
                    allowClear
                >
                    {apnOptions[currentRow?.service_provider || ""]?.map((provider: string) => (
                        <Option key={provider} value={provider}>
                            {provider}
                        </Option>
                    ))}
                </Select>
            );
        }

        // PDP Name
        if (popupHeading === "Billing Customers" &&
            (headerMap?.[column]?.[0] === "PDP") && currentRow?.canEdit) {
            const getSelectedIpRangesForPdp = (apn: string, pdp: string, excludeIdx?: number) => {
                return rowData
                    .filter((row, idx) =>
                        idx !== excludeIdx &&
                        row?.apn === apn &&
                        row?.pdp === pdp &&
                        row?.ip_text
                    )
                    .map((row) => row.ip_text);
            };

            const getCandidateIpRanges = (apn: string, pdp: string) => {
                return rowData
                    .filter((row) =>
                        row?.apn === apn &&
                        row?.pdp === pdp &&
                        Array.isArray(row?.ip_text_options)
                    )
                    .flatMap((row) => row.ip_text_options);
            };

            const selectedPdpOptions = pdpOptions[currentRow?.apn || ""] || [];
            const availablePdpOptions = selectedPdpOptions.filter((pdp: string) => {
                if (pdp === currentRow?.pdp) {
                    return true;
                }

                const candidateRanges = getCandidateIpRanges(currentRow?.apn || "", pdp);
                if (candidateRanges.length === 0) {
                    return true;
                }

                const usedRanges = new Set(getSelectedIpRangesForPdp(currentRow?.apn || "", pdp));
                const remaining = candidateRanges.filter((range) => !usedRanges.has(range));
                return remaining.length > 0;
            });

            return (
                <Select
                    value={cellData}
                    placeholder="Select PDP"
                    style={{ width: "100%", font: "16px" }}
                    className="table-drp"
                    onChange={(value) => handleDropdownChange(value, rowIndex, column)}
                    showSearch
                    allowClear
                >
                    {availablePdpOptions.map((provider: string) => (
                        <Option key={provider} value={provider}>
                            {provider}
                        </Option>
                    ))}
                </Select>
            );
        }

        // IP Versions
        if (popupHeading === "Billing Customers" &&
            (headerMap?.[column]?.[0] === "IP Version") && currentRow?.canEdit) {
            return (
                <Select
                    value={cellData}
                    placeholder="Select IP Version"
                    style={{ width: "100%", font: "16px" }}
                    className="table-drp"
                    onChange={(value) => handleDropdownChange(value, rowIndex, column)}
                    showSearch
                    allowClear
                >
                    {ipVersionOptions.map((provider: string) => (
                        <Option key={provider} value={provider}>
                            {provider}
                        </Option>
                    ))}
                </Select>
            );
        }

        // Default: Tooltip with value
        return (
            <Tooltip
                title={`${cellData}`}
                placement="topLeft"
                overlayStyle={{
                    whiteSpace: "normal",
                    maxWidth: "60vw",
                    wordWrap: "break-word",
                    zIndex: 50,
                }}
                getPopupContainer={() => document.body}
            >
                <span>{cellData}</span>
            </Tooltip>
        );
    };


    //Upload Functions
    const handleUploadClick = () => {
        setIsUploadModalVisible(true);
    };

    const handleUploadModalClose = () => {
        setIsUploadModalVisible(false);
    };
    const handleUpload = async (blob: string) => {
        try {
            setModalLoading(true);
            const url = ENV_ROUTES.SIM_MANAGEMENT
            //   let flag: string = appendChecked ? "append" : "overwrite";

            const data = {
                tenant_name: isPartnerCreation ? selectedPartnerName || "" :partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/bulk_upload_private_networks",
                table_name: "customergroups",
                // insert_flag: flag,
                module_name: "Private Networks",
                role_name: role,
                Partner: isPartnerCreation ? selectedPartnerName || "" :partner,

                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: isPartnerCreation ? selectedPartnerDB || "" : selectedDb,
                ...(isPartnerCreation ? selectedPartnerMetaData || "" : metaData),
                sessionID: sessionId,
                blob: blob, // Include the Blob in the data
            };

            const response = await axios.post(url, { data });

            const resp = JSON.parse(response.data.body);
            if (response.data.statusCode === 200) {
                if (resp.flag === true) {
                    const updatedRowData_ = resp.data.map((row: any) => ({
                        ...row,
                        canEdit: true,
                    }));
                    setRowData(updatedRowData_);
                    setIsUploadModalVisible(false);
                    notification.success({
                        message: "Success",
                        description: "Successfully uploaded the record",
                        placement: "top",
                    });
                    fireSideCannons()
                    // onFetch()                
                } else {
                    Modal.error({
                        title: "Import Error",
                        content: resp.message,
                        centered: true,
                        onOk: handleErrorModalClose,
                        onCancel: handleErrorModalClose,
                    });
                }
            } else {
                Modal.error({
                    title: "Import Error",
                    content: resp.message,
                    centered: true,
                    onOk: handleErrorModalClose,
                    onCancel: handleErrorModalClose,
                });
            }
        } catch (error) {
            console.error("Error during file upload:", error);
            Modal.error({
                title: "Import Error",
                content: "There was an error uploading the file.",
                centered: true,
                onOk: handleErrorModalClose,
                onCancel: handleErrorModalClose,
            });
        }
        finally {
            setModalLoading(false);
        }
    };
    const handleErrorModalClose = () => {
        setIsUploadModalVisible(false);
    };
    const handleChange = (info: any) => {
        if (info.file.status === "done") {
            setIsFileSelected(true);
            let blob;
            const file = info.file.originFileObj; // Get the file object
            const reader = new FileReader();
            reader.onload = (e: any) => {
                // Get the file data URL (Base64 string)
                blob = e.target.result;
                console.log("File Base64 String:", blob);
                handleUpload(blob);
                setUploadKey(Date.now());
            };

            if (blob) {
            }

            reader.readAsDataURL(file); // Read the file as data URL
        } else if (info.file.status === "error") {
            // Handle upload error
            message.error("Upload failed.");
        } else if (info.file.status === "removed") {
            setIsFileSelected(false);
            //   setAppendChecked(false);
            //   setOverwriteChecked(false);
        }
    };

    const uploadProps = {
        key: uploadKey,
        accept: ".xlsx, .xls",
        beforeUpload: (file: any) => {
            // Check if file is an Excel file
            const isExcel =
                file.type ===
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
                file.type === "application/vnd.ms-excel";
            if (!isExcel) {
                message.error("You can only upload Excel files!");
            }
            return isExcel;
        },
        onChange: handleChange,
    };
    const messageStyle = {
        fontSize: "14px",
        fontWeight: "bold",
        padding: "16px",
    };

    const downloadBlob = (base64Blob: string) => {
        const byteCharacters = atob(base64Blob);
        const byteNumbers = new Array(byteCharacters.length);

        for (let i = 0; i < byteCharacters.length; i++) {
            byteNumbers[i] = byteCharacters.charCodeAt(i);
        }

        const byteArray = new Uint8Array(byteNumbers);
        const blobObject = new Blob([byteArray], {
            type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        });
        const link = document.createElement("a");

        link.href = URL.createObjectURL(blobObject);
        link.download = "Private Networks.xlsx";
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };
    const handleDownloadTemplate = async () => {
        setModalLoading(true);

        try {
            const url = ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: isPartnerCreation ? selectedPartnerName || "" :partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/download_bulk_upload_template",
                table_name: "customergroups",
                module_name: "Private Networks",
                role_name: role,
                Partner: isPartnerCreation ? selectedPartnerName || "" :partner,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: isPartnerCreation ? selectedPartnerDB || "" : selectedDb,
                ...(isPartnerCreation ? selectedPartnerMetaData || "" : metaData),
                sessionID: sessionId,
            };

            const response = await axios.post(url, { data });
            const resp = JSON.parse(response.data.body);
            const blob = resp.blob;

            console.log(resp);

            if (response.data.statusCode === 200) {
                if (resp.flag === true) {
                    notification.success({
                        message: "Success",
                        description: "Successfully downloaded the template!",
                        style: messageStyle,
                        placement: "top",
                    });
                    downloadBlob(blob);
                } else {
                    console.log("Error message:", resp.message);
                    Modal.error({
                        title: "Export Error",
                        content: resp.message || "Something went wrong during download.",
                        centered: true,
                    });
                }
            } else {
                console.log("Unexpected status code:", response.data.statusCode);
                Modal.error({
                    title: "Export Error",
                    content: resp.message || "Unexpected response from server.",
                    centered: true,
                });
            }
        } catch (error) {
            console.error("Download template failed:", error);
            Modal.error({
                title: "Download Error",
                content: "An unexpected error occurred while downloading the template.",
                centered: true,
            });
        } finally {
            // Always turn off loader, even if success or error
            setModalLoading(false);
        }
    };

    if (loading) {
        return (
            <div className="flex justify-center items-start h-auto pt-10">
                <Spin size="large" />
            </div>
        );
    }



    // Pagination component to be used in both places
    const paginationComponent = (
        <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            onPageChange={setCurrentPage}
            moduleName={popupHeading}
        />
    );

    return (
        <div>
            {/* Show pagination at top right for small screens */}
            {isSmallScreen && headers.length > 0 && (
                <div className="flex justify-end mb-2 mr-2">
                    {paginationComponent}
                </div>
            )}

            {/* Add button */}
            {
                <div className="mb-2 flex justify-end gap-2">
                    <button
                        onClick={handleAddRow}
                        // className={`${((serviceProviderOptions.length === 0) || (rowData.length === serviceProviderOptions.length)) ? "cancel-btn cursor-not-allowed" : "save-btn"}`}
                        className="save-btn"
                    // disabled={(serviceProviderOptions.length === 0) || (rowData.length === serviceProviderOptions.length)}
                    >
                        <PlusIcon className="h-5 w-5 text-black-500 mr-1" />
                        Add
                    </button>
                    <button className="save-btn" onClick={handleUploadClick}>
                        <ArrowUpTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                        <span>Upload</span>
                    </button>
                    <Modal
                        title="Upload Files"
                        visible={isUploadModalVisible}
                        onCancel={handleUploadModalClose}
                        footer={null} // No default footer buttons
                        centered
                        width={400}
                    >
                        <div className="relative flex flex-col gap-4 min-h-[100px]">
                            {/* ✅ Show loader inside modal when modalloading is true */}
                            {modalloading ? (
                                <div className="absolute inset-0 flex justify-center items-center bg-white/80 backdrop-blur-sm rounded-lg z-10">
                                    <Spin size="large" tip="Processing..." />
                                </div>
                            ) : (
                                <div className="flex flex-col md:flex-row gap-4 justify-center m-auto p-4">
                                    <Upload {...uploadProps} className="w-full md:w-auto">
                                        <button
                                            className="w-[200px] md:w-full upload-btn disabled:cursor-not-allowed"
                                            disabled={modalloading}
                                        >
                                            <span className="mr-2">
                                                <UploadOutlined />
                                            </span>
                                            Upload
                                        </button>
                                    </Upload>

                                    <button
                                        onClick={handleDownloadTemplate}
                                        className="w-[200px] md:w-full upload-btn disabled:cursor-not-allowed"
                                        disabled={modalloading}
                                    >
                                        <span className="mr-2">
                                            <DownloadOutlined />
                                        </span>
                                        Download Template
                                    </button>
                                </div>
                            )}
                        </div>
                    </Modal>
                </div>
            }


            {/* Table */}
            <div className="overflow-x-auto">
                <div
                    className="overflow-y-auto p-2"
                    style={{
                        height: `${viewportHeight - height}px`
                    }}
                >
                    <table className="table-auto w-full">
                        <thead className="sticky top-0 bg-gray-200 z-10 table-header-row">
                            <tr>
                                {headers.map((header) => (
                                    headerMap && headerMap[header] && headers.includes(header) && (
                                        <th
                                            key={header}
                                            className={`px-6 py-3 border-b border-gray-300 !text-center font-semibold table-header sticky top-0 !min-w-[200px] ${sortConfig && sortConfig.key === header ? "text-blue-600  active-table-header" : ""
                                                }`}
                                            onClick={() => {
                                                handleSort(header);
                                            }}
                                        >
                                            {headerMap?.[header]?.[0] || header}

                                            {
                                                sortConfig && sortConfig.key === header ? (
                                                    sortConfig.direction === "ascending" ? (
                                                        <ArrowUpOutlined className="sorting-arrow" style={{ marginLeft: 8, color: "#2563EB" }} />
                                                    ) : (
                                                        <ArrowDownOutlined className="sorting-arrow" style={{ marginLeft: 8, color: "#2563EB" }} />
                                                    )
                                                ) : (
                                                    <ArrowUpOutlined style={{ marginLeft: 8, opacity: 0.5 }} />
                                                )
                                            }
                                        </th>
                                    )
                                ))}
                                <th
                                    key={"delete"}
                                    className={`px-6 py-3 border-b border-gray-300 !text-center font-semibold table-header sticky top-0`}
                                >
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            {headers.length > 0 ? (
                                rowData.length > 0 ? (
                                    rowData.map((row, index) => (
                                        <tr
                                            key={index}
                                            className={index % 2 === 0 ? "bg-gray-50 even-table-row" : ""}
                                        >

                                            {headers.map((header, columnIndex) =>
                                                headers.includes(header) && headerMap[header] && (
                                                    <td
                                                        key={columnIndex}
                                                        className={`border-b border-gray-300 table-cell !min-w-[200px] ${header !== "ip_text" ? "!max-w-[290px]" : "!max-w-none"}`}
                                                    >
                                                        {header && headerMap?.[header]?.[0] && renderCell(row[header], header, index) || ""}
                                                    </td>
                                                )
                                            )}
                                            <td key={index} className="!text-center border-b border-gray-300 table-cell">
                                                {(row && row?.canEdit) ? (

                                                    <button onClick={() => handleDeleteRow(index)}>
                                                        <span className="text-red-500">
                                                            <CloseOutlined />
                                                        </span>
                                                    </button>
                                                ) : (<></>)
                                                }
                                            </td>
                                        </tr>
                                    ))
                                ) : (
                                    <tr>
                                        <td
                                            colSpan={
                                                headers.filter((header) =>
                                                    headers.includes(header)
                                                ).length + 1
                                            }
                                            className="px-6 py-3 border-b border-gray-300 text-center text-gray-500"
                                        >
                                            No Records Found
                                        </td>
                                    </tr>
                                )
                            ) : null
                            }
                        </tbody>
                    </table>
                </div>
            </div>
            {/* Show pagination at bottom for larger screens */}
            {(!isSmallScreen && headers.length > 0) && (
                <div className="flex justify-center mt-5">
                    {paginationComponent}
                </div>
            )}

        </div>
    );
};

export default PrivateNetworkTable;
