import React from 'react';
import { Modal } from 'antd';

interface RowDetailsModalProps {
    isOpen: boolean;
    onClose: () => void;
    headerMap: Record<string, string[]>;
    row: Record<string, any>;
    title?: string;
}

const RowDetailsModal: React.FC<RowDetailsModalProps> = ({
    isOpen,
    onClose,
    headerMap,
    row,
    title = 'Details',
}) => {
    const modalWidth =
        typeof window !== "undefined" ? (window.innerWidth * 2.5) / 4 : 0;
    const modalHeight =
        typeof window !== "undefined" ? (window.innerHeight * 2.5) / 4 : 0;
    return (
        <Modal
            open={isOpen}
            onCancel={onClose}
            // width={modalWidth}
            styles={{ body: { height: modalHeight } }}
            footer={null}
            title={<span className='text-[18px]'>{title}</span>}>
            <div className="space-y-2 row-details popup">
                {Object.keys(headerMap || {}).map((header) => (
                    <div key={header} className="grid grid-cols-2  gap-y-2 border-b pb-1">
                        <div className="flex items-center space-x-2">
                            <span className="text-md">•</span>
                            <div className="font-semibold">{headerMap?.[header]?.[0] || header}</div>
                        </div>

                        <div className='flex items-center space-x-4'>
                            {typeof row?.[header] === 'boolean' ? String(row[header]) : row?.[header] ?? ""}
                        </div>
                    </div>
                ))}
            </div>
        </Modal>
    );
};

export default RowDetailsModal;
