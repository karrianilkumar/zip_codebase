import React, {forwardRef, useImperativeHandle ,useState, useEffect } from "react";
import { Modal, Divider, Select, Button, DatePicker, Spin, Checkbox } from "antd";
import { ChevronDownIcon } from "@heroicons/react/24/outline";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { CloseOutlined } from "@ant-design/icons";
import dayjs from "dayjs";
import moment from "moment";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { useInventoryAllChangeTypesStore } from '@/app/stores/inventorytAllChangeTypesStore';
import EffectiveDate from "@/app/sim_management/revenue_assurance/effective-cell-renderer";
import { PerformanceLogStore } from "@/app/stores/performance_matrix_store";
import { useCustomerProfileStore } from "@/app/billing/killbill_stores/customer_profile_store";

const { Option } = Select;

interface UpdateStatusModalProps {
  visible: boolean;
  onCancel: () => void;
  onUpdate: (updatedRow: any, event_type: string) => void;
  rowData?: any;
  is2OChange?: boolean;
  isSingle?:boolean;
  isAllChangeTypesFlow?: Boolean;
}
export interface UpdateCarrierRatePlanContentRef {
  runValidation: () => Promise<void> | void;
   runSubmit: () => Promise<void> | void; // Add runSubmit method
  hasValidData: () => boolean; // Add hasValidData method
}
const UpdateCarrierRatePlan =forwardRef<UpdateCarrierRatePlanContentRef, UpdateStatusModalProps>(
({
  visible,
  onCancel,
  onUpdate,
  rowData,is2OChange,isSingle,isAllChangeTypesFlow
},ref) => {
  const { getTargetTenantProvider, IsTargetTenantProvider } = PerformanceLogStore();
  const { activeChange , isAllChangeType,setIsValidated,setValidationTrigger, setsuccessFullChangeTypes, successFullChangeTypes, setCommPlanChanges } = useInventoryAllChangeTypesStore();
  const [saveChanges, setSaveChanges] = useState<boolean>(true);
  const is_single_line = (!is2OChange || isSingle)
  const [selectedCarrierRatePlan, setSelectedCarrierRatePlan] = useState<
    string | undefined
  >(is_single_line ? rowData?.carrier_rate_plan_name || '': undefined);
  const [selectedCommPlan, setSelectedCommPlan] = useState<string | undefined>(
    is_single_line ? rowData?.communication_plan || '': undefined
  );
  const [selectedOptimizationGroup, setSelectedOptimizationGroup] = useState<string | undefined>(
  is_single_line ? rowData?.optimization_group || '' : undefined
);
  const [selectedDate, setSelectedDate] = useState<string | null>(null);
  const [formData, setFormData] = useState<any>(rowData);
  const [loading, setLoading] = useState(true);
  const { username, partner, role, token, selectedDb, metaData,firstLastName, sessionId } = useAuth();
  const [carrierRatePlanOptions, setCarrierRatePlanOptions] = useState<any[]>([]);
  const [ratePlanCodeOptions, setRatePlanCodOptions] = useState<any[]>([]);
  const [OptimizationGroupOptions,setOptimizationGroupOptions] = useState<any[]>([]);
  const [commPlans, setCommPlans] = useState<any[]>([]);
  const [parsedData, setParsedData] = useState<any>(null);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  // const { is2OFilterLoaded  } = useFeatureStore();
  const { is2OFilterLoaded ,setIs2OFilterLoaded } = useCustomerProfileStore();
  const versionBasedPath = is2OChange ? ENV_ROUTES.INVENTORY : ENV_ROUTES.SIM_MANAGEMENT
  const providerName = getTargetTenantProvider(rowData?.service_provider_display_name).toLowerCase() || "";
  const handleCarrierRatePlanChange = (value: string) => {
    if (value) {
      const formData_ = { ...formData };
      formData_.carrier_rate_plan_name = value;
      setSelectedCarrierRatePlan(value);
      setFormData(formData_);
      const communicationPlans = parsedData.communication_rate_plan_list[value] || [];
      const formattedCommPlans = communicationPlans.map((plan: any, index: any) => ({
        value: plan,
        name: plan,
        key: index,
      }));
      // setCommPlans(formattedCommPlans);
      setSelectedCommPlan(undefined);
    }
    else {
      setSelectedCarrierRatePlan(undefined);
      setSelectedCommPlan(undefined);
    }
  };

  const handleCommPlanChange = (value: string) => {
    if (value) {
      const formData_ = { ...formData };
      let commPlan_
      if (value === "no change") {
        commPlan_ = formData_.communication_plan ? rowData.communication_plan : null
      }
      else {
        commPlan_ = value
      }
      formData_.communication_plan = commPlan_;
      setSelectedCommPlan(value);
      setFormData(formData_);
      if (errors.commPlan) {
      setErrors(prev => ({ ...prev, commPlan: '' }));
    }
    }
    else {
      setSelectedCommPlan(undefined); // Clear selected communication plan
    }
  };

  const handleOptimizationGroupChange = (value: string) => {
    if (value){
      const formData_ = {...formData};
      formData_.optimization_group = value;
      setSelectedOptimizationGroup(value);
      setFormData(formData_);
    }
    else{
      setSelectedOptimizationGroup(undefined);

    }
  }

  const handleDateChange = (date: any, dateString: string | string[]) => {
    if (typeof dateString === "string") {
      setSelectedDate(dateString);
    } else {
      setSelectedDate(dateString[0]);
    }
    const formData_ = { ...formData };
    formData_["effective_date"] = dateString;
    setFormData(formData_);
  };

  const handleCancel = () => {
    setSelectedCarrierRatePlan(undefined);
    setSelectedCommPlan(undefined);
    setSelectedOptimizationGroup(undefined);
    onCancel();
  };

  const hasValidData = () => {
  const isAnyFieldFilled =
    !!selectedCarrierRatePlan ||
    !!selectedCommPlan ||
    !!selectedOptimizationGroup ||
    !!selectedDate;
  
  return isAnyFieldFilled;
};


const handleSubmit = () => {
  console.clear();
  console.log("handleSubmit called");

  const newErrors: { [key: string]: string } = {};

  // Carrier Rate Plan is always required
  if (!selectedCarrierRatePlan || selectedCarrierRatePlan === "") {
    newErrors.carrierRatePlan = "Carrier Rate Plan is required.";
  }
  if(!selectedDate){
    newErrors.effectiveDate = "Effective Date is required.";
  }

  setErrors(newErrors);

  // If regular flow (not All Change Types), handle as before
  if (Object.keys(newErrors).length === 0 && !isAllChangeType) {
    handleUpdate();
    return;
  }

  // --- Fix: All Change Types success path ---
  if (isAllChangeType && Object.keys(newErrors).length === 0) {
    // Add/change success, fire validators
    setCommPlanChanges((prev: any) => ({
      ...prev,
      carrierCommPlan: formData?.communication_plan || ""
    }))
    if (!successFullChangeTypes.includes(activeChange)) {
      if (saveChanges) {
        setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
      }
}
    setIsValidated(true);
    setValidationTrigger();
    return;
  }

  // --- All Change Types error path (as before) ---
  if (isAllChangeType) {
    setsuccessFullChangeTypes(
      successFullChangeTypes.filter((c: any) => c !== activeChange)
    );

    const hasAnyInput =
      !!selectedCarrierRatePlan || !!selectedCommPlan || !!selectedDate;

    if (!hasAnyInput) {
      setErrors({});
      setIsValidated(true);
      setValidationTrigger();
    } else {
      setIsValidated(false);
      setValidationTrigger();
    }
    return;
  }
};

const handleRunSubmit = () => {
  onUpdate(formData, "Update Carrier Rate Plan");
};


const handleUpdate = () => {
  if(is_single_line){
    setSelectedCarrierRatePlan(undefined);
    setSelectedCommPlan(undefined);
    setSelectedOptimizationGroup(undefined);
  }

  console.log("formData before update", formData);

  const ratePlan_ = selectedCarrierRatePlan;

  if (ratePlan_) {
    // Find matching plan code for selected plan
    const index = carrierRatePlanOptions.indexOf(ratePlan_);
    console.log("ratePlan_", ratePlan_)
    console.log("index", index)

    if (index !== -1 && ratePlanCodeOptions[index]) {
      const newRatePlanCode = ratePlanCodeOptions[index];
      console.log("newRatePlanCode", newRatePlanCode)

      // Update formData with new rate plan code
      let updatedFormData = {
        ...formData,
        carrier_rate_plan_name: newRatePlanCode,
      };

      console.log("formData after update", updatedFormData);

      onUpdate(updatedFormData, "Update Carrier Rate Plan");
      return;
    }
  }

  // Fallback
  onUpdate(formData, "Update Carrier Rate Plan");
};

  useEffect(() => {
    setErrors({})
    // setSelectedCarrierRatePlan(rowData?.carrier_rate_plan_name||'')
    setSelectedCommPlan(is_single_line ? rowData?.communication_plan || '': undefined)

    // setOptimizationGroupOptions(is_single_line ? rowData?.optimization_group || '': undefined)
    const fetchData = async () => {
      setLoading(true);
      try {
        const url = versionBasedPath;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/inventory_dropdowns_data",
          role_name: role,
          parent_module: "Sim Management",
          module_name: "SimManagement Inventory",
          feature_module_name: "Inventory",
          list_view_data_id: rowData?.id || 0,
          service_provider_id: rowData?.service_provider_id,
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          dropdown: "Carrier Rate Plan",
        };

        const response = await axios.post(url, { data });
        const fetchedData = JSON.parse(response.data.body);
        setParsedData(fetchedData);

        if (fetchedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content: fetchedData.message || "An error occurred while fetching Inventory data. Please try again.",
            centered: true,
            onOk: handleCancel,
          });
        } else {
          setLoading(false);
          // const carrierOptions_ = Object.entries(fetchedData.communication_rate_plan_list).map(([name]) => ({ name }));
          const carrierOptions_ = fetchedData?.rate_plan_list || []
          setCarrierRatePlanOptions(carrierOptions_);

          const ratePlanCodeOptions_ = fetchedData?.rate_plan_code_list || []
          setRatePlanCodOptions(ratePlanCodeOptions_);

          const optimization_group_dropdown = fetchedData?.optimization_group_dropdown || []
          setOptimizationGroupOptions(optimization_group_dropdown);

          // const allCommPlans = Object.values(carrierOptions_).flat();
          const allCommPlans = fetchedData?.communication_plan_list || []
          setCommPlans(allCommPlans);

          const ratePlanCode_ = rowData?.carrier_rate_plan_name || '';

          if (ratePlanCode_) {
            // Find the index of the selected rate plan in the options array
            const index = ratePlanCodeOptions_.indexOf(ratePlanCode_);
            console.log("ratePlanCode_", ratePlanCode_)

            console.log("index", index)

            if (index !== -1 && carrierOptions_[index]) {
              const newRatePlan = carrierOptions_[index];
              console.log("newRatePlanCode", newRatePlan)
              setSelectedCarrierRatePlan(is_single_line ? newRatePlan : undefined)

            }
            else {
              setSelectedCarrierRatePlan( is_single_line ? rowData?.carrier_rate_plan_name || '': undefined)

            }
          }
        }
      } catch (error) {
        setLoading(false);
        console.error("Error fetching data:", error);
        Modal.error({
          title: "Data Fetch Error",
          content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
          centered: true,
          onOk: handleCancel,
        });
      } finally {
        setLoading(false);
      }
    };

    if (visible) {
      fetchData();
    }
  }, [visible]);
  const disablePastDates = (current: any) => {
    // Disable all dates before today
    return current && current < moment().startOf('day'); // Start of the current day to include today's date
  };

const provider = rowData?.service_provider_display_name?.toLowerCase();

// Communication Plan dropdown visibility
const showCommPlanDropdown = is2OChange 
  ? !["webbing","multi-carrier sim", "teal", "telegence"].some(p => providerName?.includes(p))
  : true;
useImperativeHandle(ref, () => ({
       runValidation: handleSubmit,
       runSubmit: handleRunSubmit, // Add this line
       hasValidData: hasValidData, // Add this line
     }));
  // The main content that will be reused
      const renderContent = () => {
        if (loading || is2OFilterLoaded) {
          return (
            <div className="popup flex justify-center items-center w-full h-full">
              <Spin size="large" />
            </div>
          );
        }
    
     return(
      <>
         {isAllChangeType && (
           <div className="flex justify-end px-4">
             <span className="mr-2 font-semibold">Save Changes</span>
             <Checkbox
               checked={saveChanges}
               onChange={(e) => {
                 if (!e.target.checked) {
                   setsuccessFullChangeTypes(
                     successFullChangeTypes.filter((c: any) => c !== activeChange)
                   );
                 }
                 setSaveChanges(e.target.checked)
               }}
               className="custom-checkbox"
             >

             </Checkbox>
           </div>
         )}
         <div className={is2OChange ? "grid grid-cols-2  gap-x-6 gap-y-4 items-start" : "flex flex-col space-y-4"}>
           <div className="flex flex-col">
             <label
               htmlFor="carrier-rate-plan"
               className="field-label"
               style={{ fontFamily: "Calibri, sans-serif" }}
             >
               Carrier Rate Plan
               <span className="text-red-500 mt-2">*</span>
             </label>
             <Select
               id="carrier-rate-plan"
               placeholder="Select a Carrier Rate Plan"
               onChange={handleCarrierRatePlanChange}
               className="w-full h-10"
               value={selectedCarrierRatePlan}
               suffixIcon={<ChevronDownIcon className="w-5 h-5 text-gray-600" />}
               showSearch
               allowClear
               clearIcon={
                 <CloseOutlined className="clear" />
               }
             >
               {carrierRatePlanOptions.map((option, index) => (
                 <Option key={index} value={option}>
                   {option}
                 </Option>
               ))}
             </Select>
             {errors.carrierRatePlan && <div className="text-red-500 mt-1">{errors.carrierRatePlan}</div>}
           </div>

           {showCommPlanDropdown && (
             <div className="flex flex-col">
               <label
                 htmlFor="comm-plan"
                 className="field-label"
                 style={{ fontFamily: "Calibri, sans-serif" }}
               >
                 Communication Plan{!is2OChange && <span className="text-red-500 mt-2"></span>}
               </label>
               <Select
                 id="comm-plan"
                 placeholder="Select a Communication Plan"
                 onChange={handleCommPlanChange}
                 className="w-full h-10"
                 value={selectedCommPlan}
                 suffixIcon={<ChevronDownIcon className="w-5 h-5 text-gray-600" />}
                 showSearch
                 allowClear
                 clearIcon={
                   <CloseOutlined className="clear" />
                 }
               >
                 <Option value="no change">No Change</Option>
                 {commPlans.map((option, index) => (
                   <Option key={index} value={option}>
                     {option}
                   </Option>
                 ))}
               </Select>
               {errors.commPlan && <div className="text-red-500 mt-2">{errors.commPlan}</div>}
             </div>
           )}

           {/* Optimization Group - NEW FIELD */}
           {providerName.includes("telegence") && (
             <div className="flex flex-col">
               <label
                 htmlFor="optimization-group"
                 className="field-label"
                 style={{ fontFamily: "Calibri, sans-serif" }}
               >
                 Optimization Group
               </label>
               <Select
                 id="optimization-group"
                 placeholder="Select Optimization Group"
                 onChange={handleOptimizationGroupChange}
                 className="w-full h-10"
                 value={selectedOptimizationGroup}
                 suffixIcon={<ChevronDownIcon className="w-5 h-5 text-gray-600" />}
                 showSearch
                 allowClear
                 clearIcon={
                   <CloseOutlined className="clear" />
                 }
               >
                 {OptimizationGroupOptions && OptimizationGroupOptions.map((option, index) => (
                   <Option key={index} value={option}>
                     {option}
                   </Option>
                 ))}
               </Select>
             </div>
           )}


           <div className="flex flex-col">
             <label
               htmlFor="effective-date"
               className="field-label"
               style={{ fontFamily: "Calibri, sans-serif" }}
             >
               Effective Date
                <span className="text-red-500 mt-2">*</span>
             </label>
             <DatePicker
               id="effective-date"
               onChange={handleDateChange}
               className="w-full h-10"
             // disabledDate={disablePastDates}
             />
              {errors.effectiveDate && <div className="text-red-500 mt-2">{errors.effectiveDate}</div>}
           </div>
         </div>
      </>
        )
      };
      
    
      // Conditional rendering: Modal OR div based on isAllChangeTypesFlow
      if (isAllChangeTypesFlow) {
        // Render just the content (div) for All Change Types flow
        return (
          <div className="p-4">
            {renderContent()}
          </div>
        );
      }
  return (
    <Modal
      title={<span className="text-[19px]">Update Carrier Rate Plan</span>}
      visible={visible}
      centered
      onCancel={handleCancel}
      footer={[
        <div className="flex justify-center space-x-2 mt-12" key="buttons">
          <Button
            key="cancel"
            onClick={handleCancel}
            className="cancel-btn h-[30px] text-base"
            style={{ fontFamily: "Calibri, sans-serif" }}
          >
            Cancel
          </Button>
          <Button
            key="update"
            onClick={handleSubmit}
            className="save-btn text-base border-none"
            style={{ fontFamily: "Calibri, sans-serif" }}
          >
            Update
          </Button>
        </div>,
      ]}
      width={500}
      style={{ height: "500px" }}
    >
      <>
        {(loading ||  is2OFilterLoaded) ? (
          <div className="popup flex justify-center items-center w-full h-full">
            <Spin size="large" />
          </div>
        ) : (
          <div className="flex flex-col space-y-4">
            <div>
              <label
                htmlFor="carrier-rate-plan"
                className="font-normal text-lg"
                style={{ fontFamily: "Calibri, sans-serif" }}
              >
                Carrier Rate Plan
                <span className="text-red-500 mt-2">*</span>
              </label>
              <Select
                id="carrier-rate-plan"
                placeholder="Select a Carrier Rate Plan"
                onChange={handleCarrierRatePlanChange}
                className="w-full mt-1 mb-2"
                value={selectedCarrierRatePlan}
                suffixIcon={<ChevronDownIcon className="w-5 mt-2 h-5 text-gray-600" />}
                showSearch
                allowClear
                clearIcon={
                  <CloseOutlined className="clear" />
                }
              >
                {carrierRatePlanOptions.map((option, index) => (
                  <Option key={index} value={option}>
                    {option}
                  </Option>
                ))}
              </Select>
              {errors.carrierRatePlan && <div className="text-red-500 mt-1">{errors.carrierRatePlan}</div>}
            </div>

           {showCommPlanDropdown && (
            <div>
              <label
                htmlFor="comm-plan"
                className="font-normal text-lg"
                style={{ fontFamily: "Calibri, sans-serif" }}
              >
                Communication Plan{!is2OChange && <span className="text-red-500 mt-2"></span>}
              </label>
              <Select
                id="comm-plan"
                placeholder="Select a Communication Plan"
                onChange={handleCommPlanChange}
                className="w-full mt-2"
                value={selectedCommPlan}
                suffixIcon={<ChevronDownIcon className="w-5 mt-2 h-5 text-gray-600" />}
                showSearch
                allowClear
                clearIcon={
                  <CloseOutlined className="clear" />
                }
              >
                <Option value="no change">No Change</Option>
                {commPlans.map((option, index) => (
                  <Option key={index} value={option}>
                    {option}
                  </Option>
                ))}
              </Select>
            {errors.commPlan && <div className="text-red-500 mt-2">{errors.commPlan}</div>}
            </div>
             )}

            {/* Optimization Group - NEW FIELD */}
             {providerName.includes("telegence") && (
            <div>
              <label
                htmlFor="optimization-group"
                className="font-normal text-lg"
                style={{ fontFamily: "Calibri, sans-serif" }}
              >
                Optimization Group
              </label>
              <Select
                id="optimization-group"
                placeholder="Select Optimization Group"
                onChange={handleOptimizationGroupChange}
                className="w-full mt-2"
                value={selectedOptimizationGroup}
                suffixIcon={<ChevronDownIcon className="w-5 mt-2 h-5 text-gray-600" />}
                showSearch
                allowClear
                clearIcon={
                  <CloseOutlined className="clear" />
                }
              >
                {OptimizationGroupOptions && OptimizationGroupOptions.map((option, index) => (
                  <Option key={index} value={option}>
                    {option}
                  </Option>
                ))}
              </Select>
            </div>
             )}

            
            <div>
              <label
                htmlFor="effective-date"
                className="font-normal text-lg"
                style={{ fontFamily: "Calibri, sans-serif" }}
              >
                Effective Date
                <span className="text-red-500 mt-2">*</span>
              </label>
              <DatePicker
                id="effective-date"
                onChange={handleDateChange}
                className="w-full h-10 mt-2"
                value={selectedDate ? dayjs(selectedDate) : null}
              // disabledDate={disablePastDates}
              />
              {errors.effectiveDate && <div className="text-red-500 mt-2">{errors.effectiveDate}</div>}
            </div>
          </div>
        )}
      </>
    </Modal>
  );
}
);

export default UpdateCarrierRatePlan;
