"use client";
 
import { FC, useState, useRef, useEffect } from "react";
import { Modal, Tooltip } from "antd";
import { ChevronLeft, ChevronRight, InfoIcon } from "lucide-react";
import React from "react";
 
// Import existing components - they'll render fields directly when isAllChangeTypesFlow is true
import AssignCustomerModal from "./assign-customer";
import UpdateCarrierRatePlan from "./update-carrier-rate-plan";
import UpdateCustomerRatePlan from "./update-customer-rate-plan";
import InventoryEditCostCenterModal from "./invenotory-edit-cost-center";
import UpdateStatusModal from "./update-status";
import UpdateFeaturesModal from "./2_0_update_features";
import UpdatePhoneNumberModal from "./update-phone-number";
import RefreshLineModal from "./refresh-line";
import UpdateCommunicationPlanModal from "./update-communication-plan";
import UpdatePPUAddressModal from "./update-ppu-address";
import SendSMS from "./update_send_sms";
import ResetVoicemailPassword from "./update_reset_voice_mail_password";
import {AssignCustomerContentRef} from "./assign-customer";
import {EditCostCenterContentRef} from "./invenotory-edit-cost-center"
import {useInventoryAllChangeTypesStore} from '../../stores/inventorytAllChangeTypesStore'
import {UpdateCarrierRatePlanContentRef} from './update-carrier-rate-plan'
import {UpdateCustomerRatePlanContentRef} from './update-customer-rate-plan'
import {UpdateStatusContentRef} from './update-status'
import {UpdatePPUAddressContentRef} from './update-ppu-address'
import {Update2OFeaturesContentRef} from './2_0_update_features'
import {UpdatePhoneNumberContentRef} from './update-phone-number'
import {RefreshLineContentRef} from './refresh-line'
import {UpdateCommunicationPlanContentRef} from './update-communication-plan'
import {SendSMSContentRef} from './update_send_sms'
import {ResetVoicemailPasswordContentRef} from './update_reset_voice_mail_password'
import UpdatePrivateNetworkModal, {UpdatePrivateNetworkModalContentRef} from './update_private_network'
import { useRowWrapFlags } from "@/app/stores/useRowWrapFlags";

 
interface AllChangeTypesModalProps {
    visible: boolean;
    onCancel: () => void;
    onBack: () => void;
    onUpdate: (updatedRow: any, eventType: string, moduleStatus?: boolean) => void;
    rowData: any[];
    serviceProvider: string;
    changeTypeOptions: string[];
    allChangeTypes: string[]; // New prop to receive unfiltered change types
}
 
const AllChangeTypesModal: React.FC<AllChangeTypesModalProps> = ({
    visible,
    onCancel,
    onUpdate,
    rowData,
    serviceProvider,
    changeTypeOptions,onBack,
    allChangeTypes
}) => {
    const { isAllChangeType,isValidated ,validationTrigger,setIsValidated,setValidationTrigger, setsuccessFullChangeTypes, successFullChangeTypes,setActiveChange, isSubmit, setIsSubmit ,setAllChangetypesOptionsInStore, allChangetypeOptionsinStore, SequenceMap} = useInventoryAllChangeTypesStore();
    const [selectedTempAction, setSelectedTempAction] = useState<string>("");
    const [selectedAction, setSelectedAction] = useState<string>("");
    const containerRef = useRef<HTMLDivElement>(null);
    const [loading, setLoading] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);
    
    // NEW: Track which change types have valid data
    const [changeTypesWithData, setChangeTypesWithData] = useState<Set<string>>(new Set());
    const [hasCurrentChangeTypeData, setHasCurrentChangeTypeData] = useState(false);
    const itemRefs = useRef<HTMLDivElement[]>([]);
    const { isRowStart, isRowEnd, recompute } = useRowWrapFlags(containerRef, itemRefs, [changeTypeOptions]);
    const [isContinueClicked, setIsContinueClicked] = useState<boolean>(false);
    const filtered_change_types = changeTypeOptions.filter((option: any) => (option !== "All Change Types"))
    const [selectedChangeTypes, setSelectedChangeTypes] = useState<
            { type: string; order: number }[]
        >([]);
    const handleChangeTypeToggle = (type: string) => {
        setSelectedChangeTypes(prev => {
            const exists = prev.find(item => item.type === type);

            if (exists) {
                // ❌ Remove and re-order
                const filtered = prev.filter(item => item.type !== type);

                return filtered.map((item, index) => ({
                    ...item,
                    order: index + 1,
                }));
            } else {
                // ✅ Add with next order
                return [
                    ...prev,
                    { type, order: prev.length + 1 }
                ];
            }
        });
    };

    const [isSequenceModalVisible, setIsSequenceModalVisible] = useState(false);
    type SequenceType = {
        type: string;
        order: number;
    };

    const getSequenceForProvider = (
        provider: string
    ): SequenceType[] => {
        const uniqueMap = new Map<string, number>();

        SequenceMap.forEach((item: any) => {
            if (item.service_provider === provider) {
                // keep the lowest sequence if duplicates exist
                if (
                    !uniqueMap.has(item.change_type) ||
                    item.change_type_sequence < uniqueMap.get(item.change_type)!
                ) {
                    uniqueMap.set(item.change_type, item.change_type_sequence);
                }
            }
        });

        return Array.from(uniqueMap.entries())
            .map(([type, order]) => ({ type, order }))
            .sort((a, b) => a.order - b.order);
    };

    const isOrderValid = (
        original: { type: string; order: number }[],
        selected: { type: string; order: number }[]
    ) => {
        // Create a lookup map from original
        const orderMap = new Map<string, number>();
        original.forEach((item) => {
            orderMap.set(item.type, item.order);
        });

        // Check if selected is in increasing order based on original
        for (let i = 1; i < selected.length; i++) {
            const prev = orderMap.get(selected[i - 1].type);
            const curr = orderMap.get(selected[i].type);

            if (prev === undefined || curr === undefined || prev > curr) {
                return false;
            }
        }

        return true;
    };

    const handleOncontinue = () => {
        const originalOrder = getSequenceForProvider(serviceProvider || "")

        const isValid = isOrderValid(originalOrder, selectedChangeTypes);

        if (!isValid) {
            Modal.warning({
                title: 'Sequence Validation',
                content: "The selected actions do not follow the required execution sequence.Please update your selection to proceed.",
                centered: true,
                width: 600,
            });

            return;
        }
        const selectedChangeTypes_ = selectedChangeTypes.map((item:any)=>(item?.type || ""))
        setIsContinueClicked(true)
        setSelectedAction(selectedChangeTypes_[0] || "");
        setSelectedTempAction(selectedChangeTypes_[0] || "");
        if(selectedChangeTypes_.includes("Line Sync")){
        setAllChangetypesOptionsInStore([...selectedChangeTypes,"Line Sync"])
        }else{
        setAllChangetypesOptionsInStore(selectedChangeTypes)
        }
        // Reset data tracking when modal opens
        setChangeTypesWithData(new Set());
        setHasCurrentChangeTypeData(false);
    }
    const assignCustomerRef = useRef<AssignCustomerContentRef>(null);
    const editCostCenterRef = useRef<EditCostCenterContentRef>(null);
    const updateCarrierRatePlanRef = useRef<UpdateCarrierRatePlanContentRef>(null);
    const updateCustomerRatePlanRef = useRef<UpdateCustomerRatePlanContentRef>(null);
    const updateStatusContentRef = useRef<UpdateStatusContentRef>(null);
    const updatePPUAddressContentRef = useRef<UpdatePPUAddressContentRef>(null);
    const updatePhoneNumberContentRef = useRef<UpdatePhoneNumberContentRef>(null);
    const update2OFeaturesContentRef = useRef<Update2OFeaturesContentRef>(null);
    const refreshLineContentRef = useRef<RefreshLineContentRef>(null);
    const commPlanContentRef = useRef<UpdateCommunicationPlanContentRef>(null);
    const sendSMSContentRef = useRef<SendSMSContentRef>(null);
    const resetVoicemailPasswordRef = useRef<ResetVoicemailPasswordContentRef>(null);
    const UpdatePrivateNetworkModalContentRef= useRef<UpdatePrivateNetworkModalContentRef>(null);

    // NEW: Function to check if current change type has data
    const checkCurrentChangeTypeForData = () => {
        let hasData = false;
        
        if (selectedAction === "Edit Cost Center" && editCostCenterRef.current) {
            // Check if cost_center field has value
            hasData = editCostCenterRef.current.hasValidData?.() || false;
        } 
        else if (selectedAction === "Assign Customer" && assignCustomerRef.current) {
            hasData = assignCustomerRef.current.hasValidData?.() || false;
        }
         else if (selectedAction === "Update Carrier Rate Plan" && updateCarrierRatePlanRef.current) {
            hasData = updateCarrierRatePlanRef.current.hasValidData?.() || false;
        }
         else if (selectedAction === "Update Customer Rate Plan" && updateCustomerRatePlanRef.current) {
            hasData = updateCustomerRatePlanRef.current.hasValidData?.() || false;
        } 
        else if (selectedAction === "Update Device Status" && updateStatusContentRef.current) {
            hasData = updateStatusContentRef.current.hasValidData?.() || false;
        } 
        else if (selectedAction === "Update PPU Address" && updatePPUAddressContentRef.current) {
            hasData = updatePPUAddressContentRef.current.hasValidData?.() || false;
        } 
        else if (selectedAction === "Update Features" && update2OFeaturesContentRef.current) {
            hasData = update2OFeaturesContentRef.current.hasValidData?.() || false;
        }
         else if (selectedAction === "Change Phone Number" && updatePhoneNumberContentRef.current) {
            hasData = updatePhoneNumberContentRef.current.hasValidData?.() || false;
        }
         else if (selectedAction === "Refresh A Line" && refreshLineContentRef.current) {
            hasData = refreshLineContentRef.current.hasValidData?.() || false;
        } 
        else if (selectedAction === "Update Communication Plan" && commPlanContentRef.current) {
            hasData = commPlanContentRef.current.hasValidData?.() || false;
        } 
        else if (selectedAction === "Send SMS" && sendSMSContentRef.current) {
            hasData = sendSMSContentRef.current.hasValidData?.() || false;
        }
            else if (selectedAction === "Reset Voicemail Password" && resetVoicemailPasswordRef.current) {
            hasData = resetVoicemailPasswordRef.current.hasValidData?.() || false;
        }
         else if (selectedAction === "Change Private Static IP Address" && UpdatePrivateNetworkModalContentRef.current) {
            hasData = UpdatePrivateNetworkModalContentRef.current.hasValidData?.() || false;
        }
        
        setHasCurrentChangeTypeData(hasData);
        
        // Update the set of change types with data
        const newSet = new Set(changeTypesWithData);
        if (hasData) {
            newSet.add(selectedAction);
        } else {
            newSet.delete(selectedAction);
        }
        setChangeTypesWithData(newSet);
        
        return hasData;
    };

    // NEW: Check for data whenever selectedAction changes or components update
    useEffect(() => {
        if (selectedAction) {
            // Small delay to ensure refs are ready
            setTimeout(() => {
                checkCurrentChangeTypeForData();
            }, 100);
        }
    }, [selectedAction]);

    // NEW: Set up interval to periodically check current change type for data
    useEffect(() => {
        if (!selectedAction) return;
        
        const interval = setInterval(() => {
            checkCurrentChangeTypeForData();
        }, 500); // Check every 500ms
        
        return () => clearInterval(interval);
    }, [selectedAction]);

    const scroll = (direction: "left" | "right") => {
        if (containerRef.current) {
            const scrollAmount = direction === "left" ? -300 : 300;
            containerRef.current.scrollBy({ left: scrollAmount, behavior: "smooth" });
        }
    };
    
    // useEffect(() => {
    //     if (visible) {
    //         console.log("changeTypeOptions", allChangeTypes);
    //         const filtered_change_types = allChangeTypes.filter(
    //             (option) => option !== "All Change Types"
    //         );
    //         console.log("Filtered Change Types:", filtered_change_types);
    //         setSelectedAction(filtered_change_types[0] || "");
    //         setSelectedTempAction(filtered_change_types[0] || "");
    //         // Reset data tracking when modal opens
    //         setChangeTypesWithData(new Set());
    //         setHasCurrentChangeTypeData(false);
    //     }
    // }, [visible]);

    useEffect(() => {
        console.log("isValidated changed:", isValidated, "selectedTempAction:", selectedTempAction, "isSubmitting:", isSubmitting);
        
        if (isValidated && !isSubmitting && selectedTempAction) {
            console.log("Validation passed, moving to:", selectedTempAction);
            // Check and update data tracking before moving
            checkCurrentChangeTypeForData();
            // Move to the new change type
            setSelectedAction(selectedTempAction);
        } else if (isValidated && isSubmitting && isSubmit) { // ✅ ADD isSubmit check
            console.log("Validation passed, proceeding with submit");
            performSubmit();
            // ✅ Reset flags after submit attempt
            setIsSubmitting(false);
            setIsSubmit(false);
        }
    }, [validationTrigger, isValidated]);
    
    useEffect(() => {
        const filtered_change_types = allChangeTypes.filter(
            (option) => option !== "All Change Types"
        );
        setActiveChange(selectedAction || filtered_change_types[0] || "")
    }, [selectedAction])
    
    const handleChangeTypeClick = (changeType: string) => {
        if (loading) return;
        if (selectedAction === changeType) return;

        // Check current change type for data before switching
        checkCurrentChangeTypeForData();
        setIsSubmitting(false);
        setIsSubmit(false);

        // Reset validation state before attempting new move
        setIsValidated(false);
        setSelectedTempAction(changeType);
        validationCheck(changeType);
    };
    
    const handleComponentUpdate = (updatedRow: any, eventType: string, moduleStatus?: boolean) => {
        onUpdate(updatedRow, eventType, moduleStatus);
        // Check for data after component updates
        setTimeout(() => {
            checkCurrentChangeTypeForData();
        }, 100);
    };
 
    const handleComponentCancel = () => {
        setSelectedAction(""); // Just clear selection, don't close main modal
    };
    
    const handleSubmit = async () => {
        console.log("Submit clicked, validating current selection:", selectedAction);
        
        // Check current change type one more time before submit
        const hasData = checkCurrentChangeTypeForData();
        
        if (!hasData && changeTypesWithData.size === 0) {
            // No data in any change type, don't proceed
            console.log("No data found in any change type, cannot submit");
            return;
        }
        
        // Set submitting flag
        setIsSubmitting(true);
        setIsSubmit(true);
        setIsValidated(false);
        
        // Validate the current selection
        await validationCheck(selectedAction, true);
    };
    
    const performSubmit = async () => {
        const refMap: Record<string, React.RefObject<any>> = {
            "Assign Customer": assignCustomerRef,
            "Update Carrier Rate Plan": updateCarrierRatePlanRef,
            "Update Customer Rate Plan": updateCustomerRatePlanRef,
            "Update Device Status": updateStatusContentRef,
            "Edit Cost Center": editCostCenterRef,
            "Update PPU Address": updatePPUAddressContentRef,
            "Change Phone Number":updatePhoneNumberContentRef,
            "Update Features": update2OFeaturesContentRef,
            "Refresh A Line": refreshLineContentRef,
            "Update Communication Plan": commPlanContentRef,
            "Send SMS": sendSMSContentRef,
            "Reset Voicemail Password": resetVoicemailPasswordRef,
            "Change Private Static IP Address": UpdatePrivateNetworkModalContentRef,
        };

        // Include current change type if it has data but isn't in successFullChangeTypes
        const changeTypesToSubmit = new Set([...successFullChangeTypes]);
        if (hasCurrentChangeTypeData && !successFullChangeTypes.includes(selectedAction)) {
            changeTypesToSubmit.add(selectedAction);
        }

        // ✅ NEW: Add "Line Sync" to successFullChangeTypes BEFORE calling runSubmit
        // This ensures it appears in the validation table on first submit
        if (allChangetypeOptionsinStore.includes("Line Sync")) {
            console.log("Adding Line Sync to successFullChangeTypes before validation");
            if (!successFullChangeTypes.includes("Line Sync")) {
                setsuccessFullChangeTypes([...successFullChangeTypes, "Line Sync"]);
            }
        }

        console.log("changeTypesToSubmit", Array.from(changeTypesToSubmit));

        for (const changeType of Array.from(changeTypesToSubmit)) {
            const ref = refMap[changeType];
            if (ref?.current?.runSubmit) {
                console.log("Submitting for changeType:", changeType, ref?.current?.runSubmit);
                await ref.current.runSubmit();
            }
        }

        // ✅ NEW: Check if "Line Sync" is in allChangetypeOptionsinStore
        if (allChangetypeOptionsinStore.includes("Line Sync")) {
            console.log("Line Sync found in store, triggering update_line_sync API");
            // Ensure "Line Sync" is in successFullChangeTypes (redundant check but safe)
            if (!successFullChangeTypes.includes("Line Sync")) {
                setsuccessFullChangeTypes([...successFullChangeTypes, "Line Sync"]);
            }
            // Call onUpdate with "Line Sync" as the event type
            onUpdate(rowData[0] || {}, "Line Sync");
        }

        // Reset submitting flag
        setIsSubmitting(false);
        setIsSubmit(false);
    };
    
   const renderSelectedComponent = () => {
    const commonProps = {
        visible: true,
        onCancel: handleComponentCancel,
        onUpdate: handleComponentUpdate,
        rowData: rowData[0] || {},
        is2OChange: true,
        isAllChangeTypesFlow: true
    };

    // Map of all available components
    const componentMap: Record<string, JSX.Element> = {
        "Assign Customer": <AssignCustomerModal {...commonProps} ref={assignCustomerRef} />,
        "Update Carrier Rate Plan": <UpdateCarrierRatePlan {...commonProps} ref={updateCarrierRatePlanRef} />,
        "Update Customer Rate Plan": <UpdateCustomerRatePlan {...commonProps} ref={updateCustomerRatePlanRef}/>,
        "Edit Cost Center": <InventoryEditCostCenterModal {...commonProps} ref={editCostCenterRef} />,
        "Update Device Status": <UpdateStatusModal {...commonProps} ref={updateStatusContentRef}/>,
        "Change Phone Number": <UpdatePhoneNumberModal {...commonProps} ref={updatePhoneNumberContentRef} />,
        "Refresh A Line": <RefreshLineModal {...commonProps} ref={refreshLineContentRef}/>,
        "Update Communication Plan": <UpdateCommunicationPlanModal {...commonProps} ref={commPlanContentRef}/>,
        "Update PPU Address": <UpdatePPUAddressModal {...commonProps} ref={updatePPUAddressContentRef}/>,
        "Update Features": <UpdateFeaturesModal {...commonProps} ref={update2OFeaturesContentRef}/>,
        "Send SMS": <SendSMS {...commonProps} ref={sendSMSContentRef} />,
        "Reset Voicemail Password": <ResetVoicemailPassword {...commonProps} ref={resetVoicemailPasswordRef} />,
        "Change Private Static IP Address": <UpdatePrivateNetworkModal {...commonProps} ref={UpdatePrivateNetworkModalContentRef } />,
    };

    // Filter to only render components that are in changeTypeOptions
    // console.log("changeTypeOptions",allChangeTypes)
    const filteredChangeTypes = allChangeTypes.filter(
        (option) => option !== "All Change Types" && option !== "Line Sync"
    );

    return (
        <>
            {filteredChangeTypes.map((changeType) => {
                const component = componentMap[changeType];
                
                // Skip if no component exists for this change type
                if (!component) return null;
                
                return (
                    <div 
                        key={changeType}
                        className={selectedAction === changeType ? 'block' : 'hidden'}
                    >
                        {component}
                    </div>
                );
            })}
        </>
    );
};
 
 const validationCheck = async (targetChangeType: string, isSubmit: boolean = false) => {
        console.log("Running validation for:", isSubmit ? "SUBMIT" : "change type switch");
        console.log("Current selection:", selectedAction);
        console.log("Target change type:", targetChangeType);
        
        setLoading(true);
        
        try {
            // Run validation based on CURRENT selection
            if (selectedAction === "Assign Customer" && assignCustomerRef.current) {
                console.log("Validating Assign Customer");
                await assignCustomerRef.current.runValidation();
            } else if (selectedAction === "Edit Cost Center" && editCostCenterRef.current) {
                console.log("Validating Edit Cost Center");
                await editCostCenterRef.current.runValidation();
            } 
            else if (selectedAction === "Update Carrier Rate Plan" && updateCarrierRatePlanRef.current) {
                await updateCarrierRatePlanRef.current.runValidation();
            }
            else if (selectedAction === "Update Customer Rate Plan" && updateCustomerRatePlanRef.current) {
                await updateCustomerRatePlanRef.current.runValidation();
            }
            else if (selectedAction === "Update Device Status" && updateStatusContentRef.current) {
                await updateStatusContentRef.current.runValidation();
            }
            else if (selectedAction === "Update PPU Address" && updatePPUAddressContentRef.current){
                await updatePPUAddressContentRef.current.runValidation();
            }
            else if (selectedAction === "Update Features" && update2OFeaturesContentRef.current){
                await update2OFeaturesContentRef.current.runValidation();
            }
            else if (selectedAction === "Change Phone Number" && updatePhoneNumberContentRef.current){
                await updatePhoneNumberContentRef.current.runValidation();
            }
            else if (selectedAction === "Refresh A Line" && refreshLineContentRef.current){
                await refreshLineContentRef.current.runValidation();
            }
            else if (selectedAction === "Update Communication Plan" && commPlanContentRef.current){
                await commPlanContentRef.current.runValidation();
            }
            else if (selectedAction === "Send SMS" && sendSMSContentRef.current){
                await sendSMSContentRef.current.runValidation();
            }
            else if (selectedAction === "Reset Voicemail Password" && resetVoicemailPasswordRef.current){
                await resetVoicemailPasswordRef.current.runValidation();
            }
           
            else if (selectedAction === "Change Private Static IP Address" &&  UpdatePrivateNetworkModalContentRef.current){
                await UpdatePrivateNetworkModalContentRef.current.runValidation();
            }
            else {
                // If current selection doesn't need validation, allow move/submit
                console.log("No validation needed for:", selectedAction);
                setIsValidated(true);
                setValidationTrigger();
            }
            
        } catch (error) {
            console.error("Validation error:", error);
            setIsValidated(false);
             if (isSubmit) {
            setIsSubmitting(false);
            setIsSubmit(false);
        }
        } finally {
            setLoading(false);
        }
    };
    
     const getBGColor = (changeType: string) => {
        if (changeType === selectedAction) {
            return "bg-blue-300"
        }
        else if (successFullChangeTypes.includes(changeType) || changeTypesWithData.has(changeType)) {
            return "bg-green-400"
        }
        else {
            return "bg-gray-500"
        }
    }
    
    // NEW: Calculate if submit should be enabled
    const isSubmitDisabled = !hasCurrentChangeTypeData && changeTypesWithData.size === 0;
    const selectionModalWidth = typeof window !== 'undefined' ? (window.innerWidth * 1.2) / 4 : 0;
    itemRefs.current = [];
    const changeTypesToDisplay = selectedChangeTypes.map((item_:any)=>(item_?.type)) || []
    return (
        <Modal
            title={<span className="text-xl font-semibold">All Change Types</span>}
            visible={visible}
            onCancel={onCancel}
            footer={null}
            width={
                !isContinueClicked? 
                selectionModalWidth
                :selectedAction ? 1100 : 800} // Wider when a component is selected
            style={{maxHeight:'90vh', overflowY:'auto'}}
            centered
            maskClosable={false}
        >
            <div>
                {/* Change Type Selection Header */}
                    {isContinueClicked ? (
                        <>
                        <div className="flex justify-center">
                    {/* <button onClick={() => scroll("left")} className="bulkchange-navigation">
                        <ChevronLeft />
                    </button> */}
 
                    <div className="bulkchange-actions-container" ref={containerRef}>
                        {changeTypesToDisplay.filter((item) => item !== "Line Sync" && item !== "All Change Types")
                        .map((item: string, index: number) => (
                            <div
                                key={item}
                                className="bulkchange-action-box"
                                ref={(el) => { itemRefs.current[index] = el!; }}
                            >
                                <div className="bulkchange-action">
                                    {item}
                                </div>
                                <div
                                    className={`bulkchange-status-circle ${getBGColor(item)} hover:cursor-pointer`}
                                    onClick={() => {
                                        if (!loading) {
                                            handleChangeTypeClick(item);
                                        }
                                    }}>
                                </div>
                                {/* {(index !== allChangeTypes.length - 1 && index !== 0) && (
                                    <div className="bulkchange-horizontal-dotted-line"></div>
                                )}
                                {index === allChangeTypes.length - 1 && (
                                    <div className="last-bulkchange-horizontal-dotted-line"></div>
                                )}
                                {index === 0 && (
                                    <div className="start-bulkchange-horizontal-dotted-line"></div>
                                )} */}
                                {(!isRowEnd[index] && !isRowStart[index]) && (
                                    <div className="bulkchange-horizontal-dotted-line" />
                                )}

                                {(isRowStart[index] && !isRowEnd[index]) && (
                                    <div className="start-bulkchange-horizontal-dotted-line" />
                                )}

                                {(isRowEnd[index] && !isRowStart[index]) && (
                                    <div className="last-bulkchange-horizontal-dotted-line" />
                                )}
                            </div>
                        ))}
                    </div>
 
                    {/* <button onClick={() => scroll("right")} className="bulkchange-navigation">
                        <ChevronRight />
                    </button> */}
                </div>
 
                {/* Selected Component Fields Area */}
                <div className="min-h-[200px]">
                    {selectedAction ? (
                        <div>
                            {/* The selected component will render its fields here */}
                            {renderSelectedComponent()}
                        </div>
                    ) : (
                        <div className="text-center py-12">
                            <p className="text-lg text-gray-600">
                                Select a change type above to configure its settings
                            </p>
                            <p className="text-sm text-gray-500 mt-2">
                                Click on any change type circle to show its configuration fields
                            </p>
                        </div>
                    )}
                </div>
 
                {/* Main Modal Footer */}
                <div className="flex justify-center space-x-4 mt-6 pt-2">
                    
                    <button onClick={() => setIsContinueClicked(false)} className="cancel-btn">
                                {/* <ArrowLeftIcon className="h-5 w-5 mr-2" /> */}
                                Back
                            </button>
                    {selectedAction && (
                         <button 
                            className={`save-btn ${isSubmitDisabled ? 'opacity-50 cursor-not-allowed' : ''}`}
                            onClick={handleSubmit}
                            disabled={loading  || isSubmitDisabled}
                        >
                            Submit
                        </button>
                    )}
                </div>
                        </>
                    ) :(
                        <div>
                            <div className="flex justify-between">
                            <span>Select the change types to be completed :</span>
                            <Tooltip title="Change Types Sequence Details">
                                <InfoIcon
                                    className="h-5 w-5 text-gray-500 cursor-pointer"
                                    onClick={() => setIsSequenceModalVisible(true)}
                                />
                            </Tooltip>
                        </div>
                            <div className="mt-4">
                                {filtered_change_types.map((type: string) => {
                                    const selectedItem = selectedChangeTypes.find(
                                        item => item.type === type
                                    );

                                    return (
                                        <label
                                            key={type}
                                            className="flex items-center space-x-2 cursor-pointer hover:bg-gray-100 hover:!text-black p-1"
                                        >
                                            <input
                                                type="checkbox"
                                                checked={!!selectedItem}
                                                onChange={() => handleChangeTypeToggle(type)}
                                                className="h-4 w-4 cursor-pointer"
                                            />

                                            {selectedItem && (
                                                <span className="text-xs font-semibold bg-blue-500 text-white rounded-full px-2 py-0.5">
                                                    {/* <span className="text-xs font-semibold bg-[#bfdbfe] text-black rounded-full px-2 py-0.5"> */}
                                                    {selectedItem.order}
                                                </span>
                                            )}

                                            <span className="text-sm">{type}</span>
                                        </label>
                                    );
                                })}
                            </div>
                        <div className="flex justify-center space-x-4 mt-4">
                            <button onClick={onCancel}className="cancel-btn">
                        {/* <ArrowLeftIcon className="h-5 w-5 mr-2" /> */}
                        Cancel
                    </button>
                            <button
                                className={`${selectedChangeTypes.map((item:any)=>(item?.type || "")).length === 0 ? "cancel-btn cursor-not-allowed" : "save-btn"}`}
                                onClick={handleOncontinue}
                                disabled={selectedChangeTypes.map((item:any)=>(item?.type || "")).length === 0}>
                                Continue
                                {/* <ArrowRightIcon className="h-5 w-5 ml-2" /> */}
                            </button>
                        </div>
                    </div>
                    )}

                
            </div>
            <Modal
                title="Sequence Details"
                visible={isSequenceModalVisible}
                onCancel={() => setIsSequenceModalVisible(false)}
                centered
                footer={null}
            >
                <>
                    <div className="flex justify-between">
                        <span className="text-blue-500">Below is the sequence of change types that should be followed for successful operation.
                            The system will process the selected change types based on this order to avoid failures.</span>
                    </div>
                    <div className="mt-4">
                        {(getSequenceForProvider(serviceProvider || "") || []).map((item: any, index: number) => {
                            return (
                                <label
                                    key={`${item?.order}_${index}`}
                                    className="flex items-center space-x-2 cursor-pointer hover:bg-gray-100 hover:!text-black p-1"
                                >
                                    <span className="text-sm">{item?.order}. {item?.type || ""}</span>
                                </label>
                            );
                        })}
                    </div>
                </>
            </Modal>
        </Modal>
    );
};
 
export default AllChangeTypesModal;
