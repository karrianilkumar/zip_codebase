
import React, { useState, useEffect, forwardRef, useImperativeHandle } from "react";
import { Modal, Row, Col, Spin,Checkbox  } from "antd";
import { useAuth } from "@/app/components/auth_context";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { useInventoryAllChangeTypesStore } from '@/app/stores/inventorytAllChangeTypesStore';
import { useCustomerProfileStore } from "@/app/billing/killbill_stores/customer_profile_store";

interface UpdatePhoneNumberModalProps {
    visible: boolean;
    onCancel: () => void;
    onUpdate: (updatedRow: any, event_type: string) => void;
    rowData?: any;
    isAllChangeTypesFlow?: Boolean;
}

export interface UpdatePhoneNumberContentRef {
    runValidation: () => Promise<void> | void;
    runSubmit: () => Promise<void> | void; 
     hasValidData: () => boolean; // NEW: Method to check if data is valid
}

const UpdatePhoneNumberModal = forwardRef<UpdatePhoneNumberContentRef, UpdatePhoneNumberModalProps>(
    ({ visible, onCancel, onUpdate, rowData, isAllChangeTypesFlow }, ref) => {
        const { is2OChange } = useFeatureStore();
            const { setIs2OFilterLoaded,is2OFilterLoaded } = useCustomerProfileStore();
        
        const [formData, setFormData] = useState<any>({ ...rowData });
        const { username, token, partner, selectedDb, role, firstLastName, sessionId } = useAuth();
        const [loading, setLoading] = useState(false);
        const [currentDate, setCurrentDate] = useState('');
        const { activeChange, isAllChangeType, setIsValidated, setValidationTrigger, setsuccessFullChangeTypes, successFullChangeTypes } = useInventoryAllChangeTypesStore();
        const [saveChanges, setSaveChanges] = useState(true);


        useEffect(() => {
            if (visible) {
                console.log("formData", formData);
                const date = new Date();
                const formattedDate =
                    `${(date.getMonth() + 1).toString().padStart(2, '0')}/${date.getDate().toString().padStart(2, '0')}/${date.getFullYear()}`;
                setCurrentDate(formattedDate);
                setFormData({ ...formData, effective_date: formattedDate });
            }
        }, [visible, rowData]);

      const hasValidData = () => {
            // Return false if Save Changes is unchecked
            if (!saveChanges) {
                return false;
            }
            return true; // Phone number change doesn't require specific validation
        };

        const handleUpdate = () => {
            // For this modal, no validation is needed as per the original code
            // Just proceed with update
            onUpdate(formData, "Change Phone Number");

            // Handle all change types validation flow
            if (isAllChangeType) {
                // Check if Save Changes is checked
                if (!saveChanges) {
                    // If unchecked, remove from successful changes and validate
                    setsuccessFullChangeTypes(
                        successFullChangeTypes.filter((c: any) => c !== activeChange)
                    );
                    setIsValidated(true);
                    setValidationTrigger();
                    return;
                }
                
                // Since there's no required fields, always mark as validated
                setIsValidated(true);
                setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
                setValidationTrigger();
                return;
            }
        };

        const handleCancel = () => {
            setFormData(rowData);
            onCancel();
        };
        const handlesubmit = () => {
             onUpdate(formData, "Change Phone Number")
        }

        useImperativeHandle(ref, () => ({
            runValidation: handleUpdate,
            runSubmit: handlesubmit,
            hasValidData: hasValidData // NEW: Add this method
        }));

        // The main content that will be reused
        const renderContent = () => {
            if (loading || is2OFilterLoaded) {
                return (
                    <div className="popup flex justify-center items-center w-full h-full">
                        <Spin size="large" />
                    </div>
                );
            }

            return (
                <>
                {isAllChangeType && (
                    <div className="flex justify-end px-4 mb-4">
                        <span className="mr-2 font-semibold">Save Changes</span>
                        <Checkbox
                        checked={saveChanges}
                        onChange={(e) => {
                            if (!e.target.checked) {
                            setsuccessFullChangeTypes(
                                successFullChangeTypes.filter((c:any) => c !== activeChange)
                            );
                            }
                            setSaveChanges(e.target.checked);
                        }}
                        />
                    </div>
                    )}

                    <Row style={{ marginBottom: 16 }}>
                        <Col span={8}>
                            <label className="text-lg" style={{ fontFamily: "Calibri, sans-serif" }}>
                                Effective Date
                            </label>
                        </Col>
                        <Col span={16}>
                            <input
                                type="text"
                                value={currentDate}
                                className="non-editable-input"
                                disabled
                            />
                        </Col>
                    </Row>
                    {!is2OChange && (
                        <Row style={{ marginBottom: 16 }}>
                            <Col span={8}>
                                <label className="text-lg" htmlFor="old_msisdn" style={{ fontFamily: "Calibri, sans-serif" }}>
                                    Old Subscriber Number
                                </label>
                            </Col>
                            <Col span={16}>
                                <input
                                    className="non-editable-input"
                                    id="old_msisdn"
                                    value={rowData.msisdn || ""}
                                    disabled
                                />
                            </Col>
                        </Row>
                    )}
                </>
            );
        };

        // Conditional rendering: Modal OR div based on isAllChangeTypesFlow
        if (isAllChangeTypesFlow) {
            // Render just the content (div) for All Change Types flow
            return (
                <div className="p-4">
                    {renderContent()}
                </div>
            );
        }

        return (
            <Modal
                title={
                    <div className="mt-[-10px]">
                        <span className="text-[19px]">Change Phone Number</span>
                    </div>
                }
                visible={visible}
                centered
                onCancel={handleCancel}
                footer={[
                    <div className="flex justify-center space-x-2 mt-12" key="buttons">
                        <button
                            key="cancel"
                            onClick={onCancel}
                            className="cancel-btn h-[30px] text-base"
                            style={{ fontFamily: "Calibri, sans-serif" }}
                        >
                            Cancel
                        </button>
                        <button
                            key="update"
                            onClick={handleUpdate}
                            className="save-btn text-base border-none"
                            style={{ fontFamily: "Calibri, sans-serif" }}
                        >
                            Update
                        </button>
                    </div>,
                ]}
                width={500}
                style={{ height: "500px" }}
            >
                {renderContent()}
            </Modal>
        );
    }
);

export default UpdatePhoneNumberModal;