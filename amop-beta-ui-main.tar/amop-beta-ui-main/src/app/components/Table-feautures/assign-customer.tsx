import React, { forwardRef, useEffect,useImperativeHandle, useState } from 'react';
import { Modal, Divider, Select, Button, Spin, DatePicker, Checkbox } from 'antd';
import { ChevronDownIcon } from '@heroicons/react/24/outline';
import { useAuth } from '@/app/components/auth_context';
import axios from 'axios';
import { ENV_ROUTES } from '@/app/components/routes/route_constants';
import { CloseOutlined } from '@ant-design/icons';
import { getCurrentDateTime } from '../header_constants';
import dayjs from 'dayjs';
import { useFeatureStore } from '@/app/sim_management/inventory/featureStore';
import ReactSelect ,{ MultiValue } from 'react-select';
import { DropdownStyles } from '../css/dropdown';
import { useInventoryAllChangeTypesStore } from '@/app/stores/inventorytAllChangeTypesStore';
import { useCustomerProfileStore } from '@/app/billing/killbill_stores/customer_profile_store';
import moment from 'moment';

const { Option } = Select;

interface AssignCustomerModalProps {
  visible: boolean;
  onCancel: () => void;
  onUpdate: (updatedRow: any,event_type:string,moduleStatus:boolean) => void;
  rowData?: any;
  is2OChange?: Boolean;
  isSingle?:Boolean;
  isAllChangeTypesFlow?:Boolean;
}
interface ProductRate {
    product_id: number;
    description: string;
    rate: string | number; // Assuming rate can be a string or number
}

interface PackageRate {
    package_id: string;
    description: string;
}

interface RateDetail {
    subdescription: string;
    product_id: number;
    rate: string | number; // Assuming rate can be a string or number
}

export interface AssignCustomerContentRef {
  runValidation: () => Promise<void> | void;
  runSubmit: () => Promise<void> | void;
   hasValidData: () => boolean; // Add this line
}
 const AssignCustomerModal = forwardRef<AssignCustomerContentRef, AssignCustomerModalProps>(
      ({ visible, onCancel, onUpdate, rowData ,is2OChange ,isSingle,isAllChangeTypesFlow}, ref) => {
    // console.log(rowData?.customer_name,"rowdata customer name")
   const is_single_line = (!is2OChange || isSingle)
    const [theme, setTheme] = useState('normal');
    // const { is2OFilterLoaded  } = useFeatureStore();
        const { setIs2OFilterLoaded,is2OFilterLoaded } = useCustomerProfileStore();
    
      const { activeChange , isAllChangeType,setIsValidated,setValidationTrigger, setsuccessFullChangeTypes, successFullChangeTypes,setAssignCustomerData } = useInventoryAllChangeTypesStore();
    const [assignCustomer, setAssignCustomer] = useState<string>( is_single_line ? rowData?.customer_name || '':'');
    const [createServiceProduct, setCreateServiceProduct] = useState(false);
    const [saveChanges, setSaveChanges] = useState<boolean>(true);
    const [revIOProviderId, setRevIOProviderId] = useState<number | null>(null);
    const [selectedProduct, setSelectedProduct] = useState<MultiValue<{ label: string; value: number }>>([]); // Update type here
    const [selectedPackage, setSelectedPackage] = useState<any | null>(null);
    const [revIOProduct, setRevIOProduct] = useState<any[]>([]); // Initialize as an empty array
    const [revIOPackage, setRevIOPackage] = useState<string>("");
    const [description, setDescription] = useState("");
    const [selectedRates, setSelectedRates] = useState<{ [key: string]: string | number }>({});
    const [productOptions, setProductOptions] = useState<any[]>([]);
    const [packageOptions, setPackageOptions] = useState<any[]>([]);
    const [providerPackageMap, setProviderPackageMap] = useState<any>([]);
    const [productRateMap, setProductRateMap] = useState<any[]>([]);
    const [packageRateMap, setPackageRateMap] = useState<any[]>([]);
    const [productError, setProductError] = useState(false);
    const [packageProductIds, setPackageProductIds] = useState<number[]>([]);
    const [activationFlag, setActivationFlag] = useState(false);
    const [errors, setErrors] = useState<any>([]);
    const [revCustomersOptions, setRevCustomersOptions] = useState<any>([]);
    const [revIOProviderOptions, setRevIOProviderOptions] = useState<any>([]);
    const [customerRatePlansOptions, setCustomerRatePlanOptions] = useState<any>(      []
       );
       const [customerRatePoolOptions, setCustomerRatePoolOptions] = useState<any>(
           []
       );
    const [useCarrierActivation, setUseCarrierActivation] = useState(false);
    const [formData, setFormData] = useState<any>(rowData)
    const [loading, setLoading] = useState(true);
    const { username, partner, role, settabledata, token, selectedDb,metaData, firstLastName,sessionId} = useAuth();
    const [AssignCustomerOptions, setAssignCustomerOptions] = useState<any[]>([])
    const [customersMap, setCustomersMap] = useState<any>({})
    const [revIOModuleStatus, setRevIOModuleStatus] = useState<boolean>(false);
    const [isBPEnabled, setIsBPEnabled] = useState(false);
    const [showValidation, setShowValidation] = useState(false);
    //customer rate plans states
    const [customerRatePlan, setcustomerRatePlan] = useState<string>(is_single_line ? rowData?.customer_rate_plan_name || '' :'');
      const [ratePool, setRatepool] = useState<string>(is_single_line ? rowData?.customer_rate_pool_name || '':'');
      const [CustomerRatePlanCodeOptions, setCustomerRatePlanCodeOptions] = useState<any[]>([])
      const [ratePools, setRatePools] = useState<any[]>([])
      const [activatedPlans, setActivatedPlans] = useState<any[]>([])
      const [activationDate, setActivationDate] = useState<string>('');
      const [effectiveDate, setEffectiveDate] = useState<string | null>(null);
      const [isCustomDateChecked, setIsCusomDateChecked] = useState<boolean>(false);
      const [selectedDateOption, setSelectedDateOption] = useState<string | null>(null);
      const [effectiveDateOptions, setEffectiveDateOptions] = useState<any[]>([]);
      const [effectiveDateOptionsMap, setEffectiveDateOptionsMap] = useState<any>({});
      const [prorate, setProrate] = useState(false);
      const versionBasedPath = is2OChange ? ENV_ROUTES.INVENTORY : ENV_ROUTES.SIM_MANAGEMENT

      // Service type State
      const [serviceType, setServiceType] = useState<string>("");
      const [serviceTypeOptions, setServiceTypeOptions] = useState<any>([]);
      const [serviceTypeError,setServiceTypeError] = useState<string>("")

      const [billingProviderError, setBillingProviderError] = useState<string>("");
      const [billingProductError, setBillingProductError] = useState<string>("");
      const [billingPackageError, setBillingPackageError] = useState<string>("");

      const fetchServiceTypeOptions = async () => {
        try {
            setLoading(true);
            const url =
                ENV_ROUTES.INVENTORY;
            const data = {
                tenant_name: partner || "default_value",
                path: "/get_rev_service_type_bulk_change_data",
                request_received_at: getCurrentDateTime(),
                username: username,
                firstLastName: firstLastName,
                role_name: role,
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: rowData?.service_provider_display_name,
                change_type: "Assign customer"
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                setLoading(false);
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                const options_ = parsedData?.dropdown_data?.rev_service_type || [];
                setServiceTypeOptions(options_);
                setLoading(false);
            }
        } catch (error) {
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        }
    };
    const handleselectServiceType = (selectedOption: any) => {
        setServiceType(selectedOption);
    };

  const handleCustomerRatePlanChange = (value: string) => {
    if (value) {
      const formData_ = formData
      formData_.customer_rate_plan_name = value
      setcustomerRatePlan(value);
      setFormData(formData_)
      if (activatedPlans.includes(value)) {
        setEffectiveDate(activationDate);
        const formData_ = formData
        formData_["effective_date"] = activationDate
        setFormData(formData_)
      }
    }
    else {
    formData.customer_rate_plan_name = "";
      setcustomerRatePlan("");
      setEffectiveDate(null);
      setFormData(formData);

      setErrors((prevErrors: Record<string, string>) => {
      const updatedErrors = { ...prevErrors };
      delete updatedErrors.effectiveDate;
      return updatedErrors;
});
    }
    
  };

  const handleCommPlanChange = (value: string) => {
    if (value) {
      const formData_ = formData
      formData_["customer_rate_pool_name"] = value
      setRatepool(value);
      setFormData(formData_)
    }
    else {
      setRatepool("");
    }
  };
    const handleAssignCustomer = (value: string) => {
      if (value) {
        const formData_ = formData
        let customer_name_=value.toLowerCase()
        if (customer_name_.endsWith(" -- bp") || customer_name_.endsWith(" -- revio")){
          customer_name_ = value.replace(" -- BP", "").replace(" -- RevIO", "");
        }
        else{
          customer_name_=value
        }
        formData_.customer_name = customer_name_
        const customer_id_=customersMap?.[value] || null
        formData_.customer_id = customer_id_
        setAssignCustomer(value);
        setFormData(formData_)

         //Clear Assign Customer error when user selects or changes it
    setErrors((prev: any) => {
      const updated = { ...prev };
      delete updated.assignCustomer;
      return updated;
    });


      }
      else{
        setAssignCustomer("");
      }
    };
    const handleCheckboxChange = (e: {
        target: { checked: boolean | ((prevState: boolean) => boolean) };
    }) => {
        const isChecked = e.target.checked;

   //Clear stale validation errors when toggling Create Service/Product
  setErrors((prev: any) => {
    const updated = { ...prev };
    delete updated.serviceType;
    delete updated.revIOProviderId;
    delete updated.productOrPackage;
    return updated;
  });

  // ✅ Validation: Assign Customer must be selected before enabling Create Service/Product
  if (isChecked && (!assignCustomer || assignCustomer.trim() === "")) {
    setErrors((prev: any) => ({
      ...prev,
      assignCustomer: "Assign Customer is required.",
    }));
     setShowValidation(true); 
    // Don’t allow enabling Create Service/Product
    setCreateServiceProduct(false);
    return;
  } 

   //Case 2: Unchecked → remove Assign Customer validation
  if (!isChecked) {
    setErrors((prev: any) => {
      const updated = { ...prev };
      delete updated.assignCustomer;
      return updated;
    });
  }

  //Case 3: Checked and Assign Customer is valid → clear any old error
  if (isChecked && assignCustomer && assignCustomer.trim() !== "") {
    setErrors((prev: any) => {
      const updated = { ...prev };
      delete updated.assignCustomer;
      return updated;
    });
  }

        setRevIOProviderId(null)
        setServiceType("")
        setSelectedPackage("")
        setSelectedProduct([])
        setRevIOPackage("")
        setRevIOProduct([])
        setDescription("")
        setSelectedRates({})
        if (!activationFlag) {
            setUseCarrierActivation(false)
        }
        setCreateServiceProduct(e.target.checked);

        //  const isChecked = e.target.checked;
    setCreateServiceProduct(isChecked);

    // Auto-check Prorate when Create Service/Product is selected
    if (isChecked) {
        setProrate(true);
    } else {
        setProrate(false);
    }
    
        // if (!revCustomer && e.target.checked && !isSubmitScreen) {
        //     // setErrors("Please select Billing customer");
        //     setErrors((prev: any) => ({
        //         ...prev,
        //         revCustomer: "Please select Billing Customer"
        //     }))
        // }
        // else if (revMultiCustomer.length === 0 && isSubmitScreen && e.target.checked) {
        //     // setErrors("Please select Billing customer");
        //     setErrors((prev: any) => ({
        //         ...prev,
        //         revCustomer: "Please select Billing Customer"
        //     }))
        // } else {
        //     setCreateServiceProduct(e.target.checked);
        //     setProrate(true)
        //     setErrors("");
        //     setErrors((prev: any) => ({
        //         ...prev,
        //         revCustomer: ""
        //     }))
        // }

        
    };
const hasValidData = () => {
      const isAnyFieldFilled =
        !!assignCustomer ||
        !!serviceType ||
        !!customerRatePlan ||
        !!ratePool ||
        !!effectiveDate ||
        createServiceProduct ||
        (selectedProduct && selectedProduct.length > 0) ||
        !!selectedPackage ||
        !!revIOProviderId ||
        !!description ||
        Object.keys(selectedRates).length > 0;
      
      return isAnyFieldFilled;
    };
    
const handleUpdate = () => {
  const newErrors: { [key: string]: string } = {};
  let formData_ = {...formData};
    if(is2OChange){
      const serviceTypeParts = (serviceType || "").split(" -- ")
      const service_type_id = serviceTypeParts.length>0 ? serviceTypeParts[1] : "0"
    formData_ = { ...formData, service_type_id: Number(service_type_id),createRevService: createServiceProduct,ProviderId:revIOProviderId , RevProductId:selectedProduct.map(e=>e.value), RevPackageId:selectedPackage,RateList:Object.values(selectedRates).map(rate => Number(rate)),Prorate:prorate,effective_date:effectiveDate ,useCarrierActivation:useCarrierActivation,Description:description,customer_rate_plan_name: customerRatePlan,customer_rate_pool_name:ratePool};
    }
  console.log("formData__",formData_)
  // Validate Assign Customer & Service Type (same as handleUpdate)
  if (is2OChange && !assignCustomer && !isAllChangeType) {
    newErrors.assignCustomer = "Assign Customer is required.";
  }
 
  // Validate Create Service/Product mandatory fields
  if (createServiceProduct && is2OChange) {
     if ( !serviceType && !isAllChangeType) {
    newErrors.serviceType = "Service type is required.";
  }

    if (!revIOProviderId) {
      newErrors.revIOProviderId = "Billing Provider is required.";
    }
    if (selectedProduct.length === 0 && !selectedPackage) {
      newErrors.productOrPackage = "Billing Product or Billing Package is required.";
    }
  }

// Validate Effective Date
if (!useCarrierActivation && createServiceProduct) {
    // When Customer Rate Plan is selected, Effective Date is mandatory
    if (customerRatePlan) {
        if (!effectiveDate) {
            newErrors.effectiveDate = "Effective Date is required when a Customer Rate Plan is selected.";
        } else {
            delete newErrors.effectiveDate;
        }
    } else {
        // When Customer Rate Plan is cleared, remove any old Effective Date error
        delete newErrors.effectiveDate;
    }
} else {
    //Skip validation entirely if Create Service/Product or Use Carrier Activation is active
    delete newErrors.effectiveDate;
}


  
  // ✅ Show all errors together (no early return)
  setErrors(newErrors);
  setShowValidation(true);

  // 🛑 Stop here if any validation errors exist
  if (Object.keys(newErrors).length > 0) {
    console.log("updated formdta",formData)
    setsuccessFullChangeTypes(
      successFullChangeTypes.filter((c: any) => c !== activeChange)
    );
    return;
  }

 
  // If no validation errors → proceed with update
  if (Object.keys(newErrors).length === 0 && !isAllChangeType) {
    onUpdate(formData_, "Assign Customer", revIOModuleStatus);
    setShowValidation(false);
    setServiceTypeError("");
    setBillingProviderError("");
    setBillingProductError("");
    setBillingPackageError("");
  }
  setsuccessFullChangeTypes(
    successFullChangeTypes.filter((c: any) => c !== activeChange)
  );
 
  if (isAllChangeType) {
  const isAnyFieldFilled =
    !!assignCustomer ||
    !!serviceType ||
    !!customerRatePlan ||
    !!ratePool ||
    !!effectiveDate ||
    createServiceProduct;
 
  if (!isAnyFieldFilled) {
    // None of the fields entered → clear errors and allow
    setErrors({});
    setIsValidated(true);
    setValidationTrigger();
    return;
  } else {
    const allChangeErrors: { [key: string]: string } = {};

      // ✅ Collect all errors (don’t stop at first)
      if (is2OChange && !assignCustomer) {
        allChangeErrors.assignCustomer = "Assign Customer is required.";
      }
      if (is2OChange && createServiceProduct) {
        if (is2OChange && !serviceType) {
          allChangeErrors.serviceType = "Service type is required.";
        }
        if (!revIOProviderId) {
          allChangeErrors.revIOProviderId = "Billing Provider is required.";
        }
        if (selectedProduct.length === 0 && !selectedPackage) {
          allChangeErrors.productOrPackage =
            "Billing Product or Billing Package is required.";
        }
      }
       // ✅ Show all at once
      setErrors(allChangeErrors);
      setShowValidation(true);

       // 🛑 Stop if there are still validation errors
      if (Object.keys(allChangeErrors).length > 0) {
        setIsValidated(false);
        setsuccessFullChangeTypes(
          successFullChangeTypes.filter((c: any) => c !== activeChange)
        );
        return;
      }
        
    setErrors({});
    setIsValidated(true);
    if (saveChanges) {
     setAssignCustomerData(formData_)
      setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
    }    
    setValidationTrigger();
    return;
  }
} else {
  // 🔁 Normal validation path
  setErrors(newErrors);
  return;
}
 
};
 
    
    const fetchActivationDate = async () => {
    setLoading(true);
    try {
      const url = versionBasedPath;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/carrier_activation_date_rata_plans",
        role_name: role,
        // parent_module: "Sim Management",
        module_name: "SimManagement Inventory",
        // feature_module_name: "Inventory",
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        iccid: rowData?.iccid || '',
        msisdn: rowData?.msisdn || '',
        table_name: "sim_management_inventory"
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching Inventory data. Please try again.',
          centered: true,
          onOk: onCancel

        });
      } else {
        const activatedPlans_ = parsedData?.rate_plans || [];
        const activation_date = parsedData?.activation_date || null;
        setActivatedPlans(activatedPlans_)
        setActivationDate(activation_date)
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
        onOk: onCancel

      });
    } finally {
      setLoading(false);
    }
  };

    const fetchBPData = async () => {
      setLoading(true);
      try {
        const url =  versionBasedPath;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/inventory_dropdowns_data",
          role_name: role,
          parent_module: "Sim Management",
          module_name: "SimManagement Inventory",
          feature_module_name:"Inventory",
          service_provider_id:rowData?.service_provider_id || 0,
          list_view_data_id: rowData?.id || 0,
          Partner: partner,
          access_token: token,
          db_name:selectedDb,
          ...metaData,
          sessionID: sessionId,
          dropdown: "Customer Rate Plan",
          modified_by: firstLastName
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);

        if (parsedData.flag === false) {
          Modal.error({
            title: 'Data Fetch Error',
            content: parsedData.message || 'An error occurred while fetching Inventory data. Please try again.',
            centered: true,
            onOk: onCancel

          });
        } else {
          const carrierOptions_ = parsedData?.rate_plan_list || []
          setCustomerRatePlanCodeOptions(carrierOptions_)
          const commOptions_ = parsedData?.rate_pool_list || []
          setRatePools(commOptions_)
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        Modal.error({
          title: 'Data Fetch Error',
          content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
          centered: true,
          onOk: onCancel

        });
      } finally {
        setLoading(false);
      }
    };
    const fetchBpFlag = async () => {
        setLoading(true);
        try {
          const url = ENV_ROUTES.MODULE_MANAGEMENT;
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/get_cross_provider_optimization_status",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "Active Customer Rate Plan",
            feature_module_name: "Customer Rate Plans",
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
            ...metaData,
            sessionID: sessionId,
          };
          const response = await axios.post(url, { data });
          const parsedData = JSON.parse(response.data.body);
          if (parsedData.flag === false) {
            Modal.error({
              title: 'Data Fetch Error',
              content: parsedData.message || 'An error occurred while fetching data. Please try again.',
              centered: true,
            });
          } else {
            const billing_plaform_flag = parsedData?.billing_platform_flag || false
            setIsBPEnabled(billing_plaform_flag)
            if (billing_plaform_flag) {
              fetchBPData()
              fetchActivationDate()
            }
          }
        } catch (error) {
          console.error("Error fetching data:", error);
          Modal.error({
            title: 'Data Fetch Error',
            content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
            centered: true,
          });
        } finally {
          setLoading(false);
    
        }
      };
    useEffect(() => {
      setAssignCustomer(is_single_line ? rowData?.customer_name || '':'')
      const fetchData = async () => {
        setLoading(true);
        try {
          const url =  versionBasedPath;
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/customers_dropdown_inventory",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "SimManagement Inventory",
            feature_module_name:"Inventory",
            Partner: partner,
            service_provider:rowData?.service_provider_display_name,
            service_provider_id:rowData?.service_provider_id,
            billing_platform_flag:isBPEnabled,
            access_token: token,
            db_name:selectedDb,
            ...metaData,
            sessionID: sessionId,
            dropdown: "Assign customer",
            modified_by: firstLastName
          };
  
          const response = await axios.post(url, { data });
          const parsedData = JSON.parse(response.data.body);
  
          if (parsedData.flag === false) {
            Modal.error({
              title: 'Data Fetch Error',
              content: parsedData.message || 'An error occurred while fetching Inventory data. Please try again.',
              centered: true,
              onOk: onCancel
  
            });
          } else {
            const customersMap_ = parsedData?.customer_name|| {}
            setCustomersMap(customersMap_)
            const customerOptions_=Object.keys(customersMap_) || []
            setAssignCustomerOptions(customerOptions_)
            setRevIOModuleStatus(parsedData?.module_status)
          }
        } catch (error) {
          console.error("Error fetching data:", error);
          Modal.error({
            title: 'Data Fetch Error',
            content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
            centered: true,
            onOk: onCancel
  
          });
        } finally {
          setLoading(false);
        }
      };

      const fetchDropdownData = async () => {
        setLoading(true);
        try {
          const url = versionBasedPath;
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/inventory_dropdowns_data",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "SimManagement Inventory",
            feature_module_name: "Inventory",
            service_provider_id: rowData?.service_provider_id || 0,
            list_view_data_id: rowData?.id || 0,
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
            ...metaData,
            sessionID: sessionId,
            dropdown: "Customer Rate Plan",
            modified_by: firstLastName
          };

          const response = await axios.post(url, { data });
          const parsedData = JSON.parse(response.data.body);

          if (parsedData.flag === false) {
            Modal.error({
              title: 'Data Fetch Error',
              content: parsedData.message || 'An error occurred while fetching data. Please try again.',
              centered: true,
              onOk: onCancel

            });
          } else {

            const billing_start_dates_options_map = parsedData?.billing_start_dates || {};
            setEffectiveDateOptionsMap(billing_start_dates_options_map)
            setEffectiveDateOptions([
              ...Object.keys(billing_start_dates_options_map).map((option: string) => (option))
            ]);
          }
        } catch (error) {
          console.error("Error fetching data:", error);
          Modal.error({
            title: 'Data Fetch Error',
            content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
            centered: true,
            onOk: onCancel

          });
        } finally {
          setLoading(false);
        }
      };

      if (visible === true) {
        fetchData()
        fetchDropdownData()
        fetchBpFlag()
        if(is2OChange){
          fetchServiceTypeOptions()
        }
      }
    }, [visible]);  

     const handleSelectEffectiveDate = (selectedOption: any) => {
       setIsCusomDateChecked(false)
       setEffectiveDate(null)
       if (selectedOption) {
         const value = selectedOption || "";
         setSelectedDateOption(value)
         const mappedDate = effectiveDateOptionsMap[value] || null
         const normalizedValue = value.toLowerCase()
         if (normalizedValue.includes("bill")) {
           setEffectiveDate(mappedDate)
         }
         else if (normalizedValue.includes("current")) {
           setEffectiveDate(moment().toISOString());
         }
         else if (normalizedValue.includes("custom")) {
           setIsCusomDateChecked(true)
         }

       }
       else {
         setEffectiveDate(null)
         setSelectedDateOption(null)
       }
     };
        
    const fetchRevProviderOptions = async () => {
        try {
            setLoading(true);
            const url =
                ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                path: "/get_rev_provider_bulk_change_data",
                request_received_at: getCurrentDateTime(),
                username: username,
                firstLastName: firstLastName,
                role_name: role,
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: rowData?.service_provider_display_name,
                change_type: "Assign customer"
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                setLoading(false);
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                const rev_provider = parsedData?.dropdown_data?.rev_provider || {};
                const revProviderOptions = Object.entries(rev_provider).flatMap(
                    ([description, providerIds]) => {
                        // Type assertion to ensure providerIds is an array of numbers
                        const ids = providerIds as number[];
                        return ids.map(provider_id => ({
                            label: description,
                            value: provider_id, // Use the provider ID as the value
                        }));
                    }
                );
                setRevIOProviderOptions(revProviderOptions);
                setLoading(false);
            }
        } catch (error) {
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        }
    };

    const fetchRevPackageRateOptions = async () => {
            try {
                setLoading(true);
                const url =
                    ENV_ROUTES.SIM_MANAGEMENT;
                const data = {
                    tenant_name: partner || "default_value",
                    path: "/get_rev_package_rate_bulk_change_data",
                    request_received_at: getCurrentDateTime(),
                    username: username,
                    firstLastName: firstLastName,
                    role_name: role,
                    Partner: partner,
                    access_token: token,
                    db_name: selectedDb,
                    ...metaData,
                    sessionID: sessionId,
                    service_provider: rowData?.service_provider_display_name,
                    change_type: "Assign customer"
                };
    
                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);
                if (parsedData.flag === false) {
                    setLoading(false);
                    Modal.error({
                        title: 'Data Fetch Error',
                        content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                        centered: true,
                    });
                } else {
                    const rev_package_rate = parsedData?.dropdown_data?.rev_package_rate || [];
                    setPackageRateMap(rev_package_rate)
                    setProviderPackageMap(rev_package_rate);
                    setLoading(false);
                }
            } catch (error) {
                Modal.error({
                    title: 'Data Fetch Error',
                    content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                    centered: true,
                });
            }
        };

    const fetchRevProductRateOptions = async () => {
              try {
                  setLoading(true);
                  const url =
                      ENV_ROUTES.SIM_MANAGEMENT;
                  const data = {
                      tenant_name: partner || "default_value",
                      path: "/get_rev_product_rate_bulk_change_data",
                      request_received_at: getCurrentDateTime(),
                      username: username,
                      firstLastName: firstLastName,
                      role_name: role,
                      Partner: partner,
                      access_token: token,
                      db_name: selectedDb,
                      ...metaData,
                      sessionID: sessionId,
                      service_provider: rowData?.service_provider_display_name,
                      change_type: "Assign customer"
                  };
      
                  const response = await axios.post(url, { data });
                  const parsedData = JSON.parse(response.data.body);
                  if (parsedData.flag === false) {
                      setLoading(false);
                      Modal.error({
                          title: 'Data Fetch Error',
                          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                          centered: true,
                      });
                  } else {
                      const rev_product_rate: ProductRate[] = parsedData?.dropdown_data?.rev_product_rate || [];
                      // const rev_package_rate: [PackageRate, RateDetail[]][] = dropdown.rev_package_rate || [];
                      setProductRateMap(rev_product_rate)
                      // Set product options
                      const productOptions_ = rev_product_rate.map(product => ({
                          label: `${product.description} - ${product.product_id}`,
                          value: product.product_id,
                      }));
                      setProductOptions(productOptions_);
                      setLoading(false);
                  }
              } catch (error) {
                  Modal.error({
                      title: 'Data Fetch Error',
                      content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                      centered: true,
                  });
              }
          };

     useEffect(() => {
            if (createServiceProduct) {
                fetchRevProviderOptions()
                fetchServiceTypeOptions()
                fetchRevPackageRateOptions()
                fetchRevProductRateOptions()
            }
        }, [createServiceProduct])
  
    const handleDateChange = (date: any, dateString: string | string[]) => {
    if (typeof dateString === 'string') {
      setEffectiveDate(dateString);
    } else {
      setEffectiveDate(dateString[0]);
    }
    const formData_ = formData
    formData_["effective_date"] = dateString
    setFormData(formData_)
  };
   const getSelectStyles = (theme: string) => {
        let bgColor = 'white';
        let optionBg = '#F9FAFB';
        let selectedOptionBg = '#BFDBFE';
        let textColor = 'black';

        if (theme === 'dark') {
            bgColor = '#2d2f52';
            optionBg = '#031731';
            selectedOptionBg = '#5e5bb3';
            textColor = 'white';
        } else if (theme === 'red') {
            selectedOptionBg = '#FCA5A5';
        } else if (theme === 'green') {
            selectedOptionBg = '#6EE7B7';
        } else if (theme === 'blue') {
            selectedOptionBg = '#BFDBFE';
        }

        return {
            menu: (base: any) => ({
                ...base,
                maxHeight: 400,
                zIndex: 9999,
                backgroundColor: optionBg,
            }),
            menuPortal: (base: any) => ({
                ...base,
                zIndex: 9999,
            }),
            container: (base: any) => ({
                ...base,
                zIndex: 1000,
            }),
            control: (base: any) => ({
                ...base,
                // height: "40px",
                backgroundColor: bgColor,
                color: textColor,
                border: "1px solid #d1d5db",
                fontSize: "16px",
            }),
            singleValue: (provided: any) => ({
                ...provided,
                color: textColor,
            }),
            option: (base: any, state: any) => ({
                ...base,
                whiteSpace: "nowrap",
                textOverflow: "ellipsis",
                padding: "8px 10px",
                fontSize: "16px",
                color: textColor,
                backgroundColor: state.isSelected ? selectedOptionBg : optionBg,
                ":hover": {
                    backgroundColor: selectedOptionBg,
                },
            }),
            input: (base: any) => ({
                ...base,
                color: textColor,
            }),
        };
    };
      //Function for handling provider change
        const handleProviderChange = (selectedOption: any) => {
            if (selectedOption) {
                setSelectedPackage(null)
                const value = selectedOption.value || ""
                setRevIOProviderId(value)
    
    
                // Filter packages with matching provider_id and push descriptions
                const packageOptions_ = providerPackageMap
                    .filter((pkg: any) => pkg[0].provider_id === value)
                    .map((pkg: any) => ({
                        label: `${pkg[0].description} - ${pkg[0].package_id}`,
                        value: pkg[0].package_id,
                    }));
                //  const packageOptions_ = rev_package_rate.map(pkg => ({
                //   label: `${pkg[0].description} - ${pkg[0].package_id}`,
                //   value: pkg[0].package_id,
                // }));
                setPackageOptions(packageOptions_)
            }
            else if (selectedOption === null) {
                setRevIOProviderId(null)
            }
    
        };
        // const handleselectServiceType = (selectedOption: any) => {
        //     setServiceType(selectedOption?.value || "");
        // };
    
        const handleProductChange = (newValue: MultiValue<{ label: string; value: number }>) => {
            setSelectedProduct(newValue);
            const productIds = newValue.map(option => option.value);
            setRevIOProduct(productIds); // Update revIOProduct with the array of product IDs
    
            // Update rates based on selected products
            const newRates: { [key: string]: string | number } = {};
            const productDescriptions = newValue.map(option => {
                const productRate = (productRateMap).find((product: ProductRate) => product.product_id === option.value);
    
                if (productRate) {
                    newRates[productRate.description] = productRate.rate || "";
                    return productRate.description; // Collect product descriptions
                }
                return null;
            }).filter(Boolean); // Filter out null values
    
            setSelectedRates(newRates);
    
            // Set the description to the concatenated product descriptions
            // setDescription(productDescriptions.join(", "));
    
            // Clear package selection when products are selected
            setSelectedPackage(null);
            setRevIOPackage("");
        };
    
        // Update the handlePackageChange function
        const handlePackageChange = (selectedOption: any) => {
            setSelectedPackage(selectedOption);
            if (selectedOption) {
                setRevIOPackage(selectedOption.value);
                const packageInfo = packageRateMap.find(
                    (pkg: [PackageRate, RateDetail[]]) => pkg[0].package_id === selectedOption.value
                );
    
                if (packageInfo) {
                    const rates: RateDetail[] = packageInfo[1];
                    const newRates: { [key: string]: string | number } = {};
                    const productIdsSet: Set<number> = new Set(); // Use a Set to store unique product IDs
    
                    rates.forEach(rate => {
                        newRates[rate.subdescription] = rate.rate || "";
                        if (rate.product_id) {
                            productIdsSet.add(rate.product_id); // Add product_id to the Set
                        }
                    });
    
                    const productIds = Array.from(productIdsSet); // Convert Set back to an array
    
    
                    setSelectedRates(prevRates => ({
                        // ...prevRates,
                        ...newRates,
                    }));
                    setPackageProductIds(productIds); // Store unique package product IDs
    
                    // Set the description to the package description
                    // setDescription(packageInfo[0].description); // Set the description to the package description
                }
                // Clear product selection when package is selected
                setSelectedProduct([]);
                setRevIOProduct([]);
            } else {
                setRevIOPackage("");
                setSelectedRates({});
                setPackageProductIds([]); // Clear package product IDs
                setDescription(""); // Clear description if no package is selected
            }
        };

        const sanitizeFormData = (data: any) => {
          const sanitized: any = {};
          for (const key in data) {
            const value = data[key];

            if (value === "") {
              sanitized[key] = null; // ✅ Convert empty strings to null
            } else if (value && typeof value === "object" && !Array.isArray(value)) {
              sanitized[key] = sanitizeFormData(value); // Recursive clean for nested objects
            } else {
              sanitized[key] = value;
            }
          }

          return sanitized;
        };

      
      const handleSubmit = () => {
        let formData_ = { ...formData };

        // 🔹 Clean up unselected / stale optional fields
        if (!assignCustomer) formData_.customer_name = null;
        if (!customerRatePlan) formData_.customer_rate_plan_name = null;
        if (!ratePool) formData_.customer_rate_pool_name = null;
        if (!effectiveDate) formData_.effective_date = null;
        if (!createServiceProduct) {
          formData_.service_type_id = null;
          formData_.ProviderId = null;
          formData_.RevProductId = [];
          formData_.RevPackageId = null;
          formData_.RateList = [];
          formData_.Description = "";
        }
         // 🧹 Clean all empty strings -> null
        formData_ = sanitizeFormData(formData_);

        onUpdate(formData_, "Assign Customer", revIOModuleStatus);
      };

     useImperativeHandle(ref, () => ({
       runValidation: handleUpdate,
       runSubmit: handleSubmit,
       hasValidData: hasValidData
     }));
  // The main content that will be reused
      const renderContent = () => {
        if (loading || is2OFilterLoaded) {
          return (
            <div className="popup flex justify-center items-center w-full h-full">
              <Spin size="large" />
            </div>
          );
        }
    
        return (
          <div className="pr-2">
          {loading || is2OFilterLoaded ? (
            <div className="popup flex justify-center items-center w-full h-full">
              <Spin size="large" />
            </div>
          ) : (
            <>
              { isAllChangeType && (
                <div className="flex justify-end px-4">
                  <span className="mr-2 font-semibold">Save Changes</span>
                  <Checkbox
                    checked={saveChanges}
                    onChange={(e) => {
                      if (!e.target.checked) {
                        setsuccessFullChangeTypes(
                          successFullChangeTypes.filter((c: any) => c !== activeChange)
                        );
                      }
                      setSaveChanges(e.target.checked)
                    }}
                    className="custom-checkbox"
                  >

                  </Checkbox>
                </div>
              )}
            <div className={is2OChange?"grid grid-cols-2 gap-x-6 gap-y-4 items-center":"flex flex-col space-y-4"}>
              <div className="relative">
                <label htmlFor='customer-rate-plan' className="field-label block mb-1" style={{ fontFamily: 'Calibri, sans-serif' }}>Assign Customer
                  {is2OChange && (<span className="text-red-500">*</span>)}
                </label>
                <Select
                  id='customer-rate-plan'
                  placeholder="Select Assign Customer"
                  onChange={handleAssignCustomer}
                  className="w-full"
                  value={assignCustomer}
                  showSearch={true}
                  allowClear
                  clearIcon={
                    <CloseOutlined className="clear"/>
                  }
                  suffixIcon={<ChevronDownIcon className="w-5 mt-2 h-5 text-gray-600" />}                 >
                  {AssignCustomerOptions?.map((option,index) => (
                    <Option key={index} value={option}>
                      {`${option} -- ${customersMap && option && customersMap[option] ? customersMap[option] : ""}`}
                    </Option>
                  ))}
                </Select>
                {errors.assignCustomer && (
                  <p className="text-red-500 text-sm mt-[10px] absolute left-0"  style={{
        position: "relative",
        top: "2px",
        fontSize: "13px",
        lineHeight: "16px",
      }}>
                   {errors.assignCustomer}
                  </p>
                )}
              </div>
            
                {(is2OChange && (partner && partner.toLowerCase() !== "wingtel")) && (
                <div className="flex items-center mt-2 gap-x-3">
                  {/*  <div className="grid grid-cols-2"> */}
                  <label className="field-label block mb-1">Create Service/Product</label>
                  <Checkbox
                    checked={createServiceProduct}
                    onChange={handleCheckboxChange}
                    className="w-6 h-6 accent-blue-500"
                  />
                </div>
                )}
                {createServiceProduct && (
                // <div className="space-y-4">
                 <> 
                        <div className="relative">
                          <label htmlFor='customer-rate-plan' className="field-label block mb-1" style={{ fontFamily: 'Calibri, sans-serif' }}>Service Type<span className="text-red-500">*</span>
                          </label>
                          <Select
                            id='customer-rate-plan'
                            placeholder="Select Service Type"
                            onChange={handleselectServiceType}
                            className="w-full"
                            value={serviceType}
                            showSearch={true}
                            allowClear
                            clearIcon={
                              <CloseOutlined className="clear" />
                            }
                            suffixIcon={<ChevronDownIcon className="w-5 mt-2 h-5 text-gray-600" />}                 >
                            {serviceTypeOptions?.map((option: any, index: any) => (
                              <Option key={index} value={option}>
                                {option}
                              </Option>
                            ))}
                          </Select>
                          {errors.serviceType && (
                            <p className="text-red-500 text-sm mt-[10px] absolute left-0" style={{
                              position: "relative",
                              top: "2px",
                              fontSize: "13px",
                              lineHeight: "16px",
                            }}>
                              {errors.serviceType}
                            </p>
                          )}
                        </div>
                        <div>
                          <label className="field-label block mb-1">
                            Billing Provider<span className="text-red-500">*</span>
                          </label>
                          <ReactSelect
                            value={
                              revIOProviderId
                                ? {
                                  label: revIOProviderOptions.find(
                                    (option: any) => option.value === revIOProviderId
                                  )?.label,
                                  value: revIOProviderId,
                                }
                                : null
                            }
                            isClearable
                            onChange={(selectedOption) => {
                              handleProviderChange(selectedOption)
                            }}
                            styles={DropdownStyles}
                            menuPortalTarget={document.body}
                            menuPosition="fixed"
                            menuPlacement="auto"
                            options={
                              revIOProviderOptions.length > 0
                                ? revIOProviderOptions
                                : [{ label: "No options", value: "No options" }]
                            }
                            className="w-full"
                            placeholder="Please Select a Billing Provider"
                          />
                          {errors.revIOProviderId && (
                            <p className="text-red-500 text-sm mt-1">{errors.revIOProviderId}</p>
                          )}
                        </div>
                    
                    <div className="col-span-2 grid grid-cols-[1fr_auto_1fr] gap-x-4 items-center">
                    <div className="">
                      <label className="field-label block mb-1">
                        Billing Product<span className="text-red-500">*</span>
                      </label>
                      <ReactSelect
                        className="w-full"
                        // options={productOptions}
                        // options={productOptions.sort((a, b) => a.label.localeCompare(b.label))}
                        options={[
                          ...new Map(productOptions.map((item) => [item.label, item])).values(),
                        ].sort((a, b) => a.label.localeCompare(b.label))}
                        value={selectedProduct}
                        onChange={handleProductChange}
                        isDisabled={!!selectedPackage}
                        isMulti
                        styles={DropdownStyles}
                        // menuPortalTarget={document.body}
                        // menuPosition="fixed"
                        // menuPlacement="auto"
                        isClearable
                      />
                    {/* <p><b>(OR)</b></p> */}
                    </div>

                    <div className="flex justify-center items-center pt-6 px-1">
                          <b>(OR)</b>
                    </div>

                   
                      {/* <span className="w-1/4 font-semibold">
                        OR
                      </span>
               */}

                    <div className="">
                      <label className="field-label block mb-1">
                        Billing Package<span className="text-red-500">*</span>
                      </label>
                      <ReactSelect
                        className="w-full"
                        // options={packageOptions}
                        // options={packageOptions.sort((a, b) => a.label.localeCompare(b.label))}
                        options={[
                          ...new Map(packageOptions.map((item) => [item.label, item])).values(),
                        ].sort((a, b) => a.label.localeCompare(b.label))}
                        value={selectedPackage}
                        onChange={handlePackageChange}
                        isDisabled={selectedProduct.length > 0}
                        isClearable
                        styles={DropdownStyles}
                      // menuPortalTarget={document.body}
                      // menuPosition="fixed"
                      // menuPlacement="auto"
                      />
                    </div>
                    {(errors.productOrPackage) && (
                      <div className="text-red-500 text-sm mt-1">{errors.productOrPackage}</div>
                    )}
                    </div>
                    {selectedProduct && selectedProduct.length > 0 && (
                    <div className='mb-4'>
                      <label className="field-label block mb-1">
                        Rates
                      </label>
                      {Object.keys(selectedRates).length > 0 && (
                        <div className="grid grid-cols-2 gap-4">
                          {Object.entries(selectedRates).map(([description, rate], index) => (
                            <React.Fragment key={index}>
                              <div className="text-left pr-4">{description}:</div>
                              <div>
                                <input
                                  type="number"
                                  value={Number(rate)}
                                  min="0"
                                  step="0.01"
                                  className="rates w-[100px] border border-gray-400 rounded pl-2"
                                  onChange={(e) => {
                                    const newRate = e.target.value === "" ? "0.0" : e.target.value;
                                    setSelectedRates((prevRates) => ({
                                      ...prevRates,
                                      [description]: newRate,
                                    }));
                                  }}
                                />
                              </div>
                            </React.Fragment>
                          ))}
                        </div>
                      )}
                    </div>
                    )}



                    <div className="flex items-center space-x-4">
                      <label className="field-label block mb-1">Prorate</label>

                      <Checkbox
                        // defaultChecked={true}
                        checked={prorate}
                        onChange={(e) => setProrate(e.target.checked)}
                      ></Checkbox>
                    </div>

                    {createServiceProduct && (
                      <>
                        {(prorate || customerRatePlan || (!prorate && !createServiceProduct)) && (
                              <>
                              <div className="flex flex-col">
                                <label htmlFor="effectiveDateDrp" className="field-label block mb-1">Effective Date</label>
                                <Select
                                  id='effectiveDateDrp'
                                  placeholder="Select..."
                                  onChange={handleSelectEffectiveDate}
                                  className="w-full"
                                  value={selectedDateOption}
                                  showSearch={true}
                                  allowClear
                                  clearIcon={
                                    <CloseOutlined className="clear" />
                                  }
                                  suffixIcon={<ChevronDownIcon className="w-5 mt-2 h-5 text-gray-600" />}                 >
                                  {effectiveDateOptions?.map((option: any, index: any) => (
                                    <Option key={index} value={option}>
                                      {option}
                                    </Option>
                                  ))}
                                </Select>

                              </div>
                              {isCustomDateChecked && (
                                <div>
                                  <label className="field-label block mb-1">
                                    Effective Date
                                    {/* <span className="text-red-500">*</span> */}
                                  </label>
                                  <DatePicker
                                    value={effectiveDate}
                                    onChange={(date) => setEffectiveDate(date)}
                                    // className="w-3/4"
                                    className={`w-full ${useCarrierActivation ? 'non-editable-input' : 'input'}`}
                                    format="MM/DD/YYYY"
                                    placeholder="MM/DD/YYYY"
                                    // disabledDate={(date) => date.isBefore(dayjs(), "day")} // Disable previous dates
                                    disabled={useCarrierActivation}
                                  />
                                </div>
                              )}
                            </>
                          
                        )}
                        {errors.effectiveDate && (
                          <div className="text-red-500 text-sm">{errors.effectiveDate}</div>
                        )}
                      </>
                    )}

                    {(prorate) && (role?.toLowerCase() === "super admin" || role?.toLowerCase() === "partner admin") && (
                      <div className="flex items-center space-x-4 mt-4">
                        <label className="field-label block mb-1">
                          Use Carrier Activation?
                        </label>

                        <Checkbox
                          checked={useCarrierActivation}
                          onChange={(e) => setUseCarrierActivation(e.target.checked)}
                        ></Checkbox>
                      </div>
                    )}
                    <div className="">
                      <label className="field-label block mb-1">Product Description</label>
                      <textarea
                        rows={2}
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        className="w-full border border-gray-300 rounded-md p-2"
                        placeholder="Enter Description"
                        disabled={!createServiceProduct} // Disable if createServiceProduct is false
                      />
                    </div>
                    </>
                    // </div>
                   

               

                )}
              {isBPEnabled && (
                <>
                <div>
                  <label htmlFor='customer-rate-plan' className="field-label block mb-1" style={{ fontFamily: 'Calibri, sans-serif' }}>Customer Rate Plan</label>
                  <Select
                    id='customer-rate-plan'
                    placeholder="Select a Customer Rate Plan"
                    onChange={handleCustomerRatePlanChange}
                    className="w-full text-[15px] font-medium"
                    value={customerRatePlan}
                    showSearch
                    allowClear
                    clearIcon={
                      <CloseOutlined className="clear" />
                    }
                    suffixIcon={<ChevronDownIcon className="w-5 mt-2 h-5 text-gray-600" />}                 >
                    {CustomerRatePlanCodeOptions.map((option) => (
                      <Option key={option} value={option}>
                        {option}
                      </Option>
                    ))}
                  </Select>
                </div>
                {(!createServiceProduct) && (
                 <>
                        {(prorate || customerRatePlan || (!prorate && !createServiceProduct)) && (
                              <>
                                <div className="flex flex-col">
                                  <label htmlFor="effectiveDateDrp" className="field-label block mb-1">Effective Date</label>
                                  <Select
                                    id='effectiveDateDrp'
                                    placeholder="Select..."
                                    onChange={handleSelectEffectiveDate}
                                    className="w-full"
                                    value={selectedDateOption}
                                    showSearch={true}
                                    allowClear
                                    clearIcon={
                                      <CloseOutlined className="clear" />
                                    }
                                    suffixIcon={<ChevronDownIcon className="w-5 mt-2 h-5 text-gray-600" />}                 >
                                    {effectiveDateOptions?.map((option: any, index: any) => (
                                      <Option key={index} value={option}>
                                        {option}
                                      </Option>
                                    ))}
                                  </Select>

                                </div>
                                {isCustomDateChecked && (
                                  <div>
                                    <label className="field-label block mb-1">
                                      Effective Date
                                      {/* <span className="text-red-500">*</span> */}
                                    </label>
                                    <DatePicker
                                      value={effectiveDate}
                                      onChange={(date) => setEffectiveDate(date)}
                                      // className="w-3/4"
                                      className={`w-full ${useCarrierActivation ? 'non-editable-input' : 'input'}`}
                                      format="MM/DD/YYYY"
                                      placeholder="MM/DD/YYYY"
                                      // disabledDate={(date) => date.isBefore(dayjs(), "day")} // Disable previous dates
                                      disabled={useCarrierActivation}
                                    />
                                  </div>
                                )}
                              </>
                        )}
                        {errors.effectiveDate && (
                          <div className="text-red-500 text-sm">{errors.effectiveDate}</div>
                        )}
                      </>
                )}
                <div>
                  <label htmlFor='comm-plan' className="field-label block mb-1" style={{ fontFamily: 'Calibri, sans-serif' }}>Customer Rate Pool</label>
                  <Select
                    id='comm-plan'
                    placeholder="Select a Communication Plan"
                    onChange={handleCommPlanChange}
                    className="w-full"
                    value={ratePool}
                    showSearch
                    allowClear
                    clearIcon={
                      <CloseOutlined className="clear" />
                    }
                    suffixIcon={<ChevronDownIcon className="w-5 mt-2 h-5 text-gray-600" />}
                  >
                    <Option key="none" value="None">
                      None
                    </Option>
                    {ratePools.map((option, index) => (
                      <Option key={index} value={option}>
                        {option}
                      </Option>
                    ))}
                  </Select>
                </div>
                {(!is2OChange) && (
                <div className='mt-7'>
                  <label htmlFor='date-picker' className="field-label block mb-1" style={{ fontFamily: 'Calibri, sans-serif' }}>Effective Date </label>
                  <DatePicker
                    id='date-picker'
                    onChange={handleDateChange}
                    className="w-full h-12"
                    value={effectiveDate ? dayjs(effectiveDate) : null} />
                    {isBPEnabled && <span className='text-sm'> The default Effective Date represents Carrier Activation Date of the Device.</span>}
                </div>
                )}
              </>
              )}
            </div>
            </>
          )}
          </div>
        );
      };
    
      // Conditional rendering: Modal OR div based on isAllChangeTypesFlow
      if (isAllChangeTypesFlow) {
        // Render just the content (div) for All Change Types flow
        return (
          <div className="p-4">
            {renderContent()}
          </div>
        );
      }
    return (
      <Modal
        title={
          <div className='mt-[-10px]'><span className='text-[19px]'>Assign Customer</span></div>}
        open={visible}  
        centered
        onCancel={onCancel}
        footer={[
          <div className="flex justify-center space-x-2 mt-12" key="buttons">
            <button key="cancel" onClick={onCancel} className="cancel-btn h-[30px] text-base" style={{ fontFamily: 'Calibri, sans-serif' }}>
              Cancel
            </button>
            <button key="update" onClick={handleUpdate} className="save-btn text-base border-none" style={{ fontFamily: 'Calibri, sans-serif' }}>
              Update
            </button>
          </div>,
        ]}
      width={is2OChange ? 800:500} 
      style={{
      maxHeight: is2OChange ? '90vh' : '85vh', 
      overflow: 'visible',
  }}
        // style={{ height: '500px'}}
      > <>
      <div className="max-h-none overflow-y-visible pr-2">
          {loading || is2OFilterLoaded ? (
            <div className="popup flex justify-center items-center w-full h-full">
              <Spin size="large" />
            </div>
          ) : (
            <div className={is2OChange?"grid grid-cols-2 gap-x-6 gap-y-5 items-start":"flex flex-col space-y-4"}>

              {/*assign customer*/}
              <div className="flex flex-col">
                <label htmlFor='customer-rate-plan' className="field-label block mb-1" style={{ fontFamily: 'Calibri, sans-serif' }}>Assign Customer
                  {is2OChange && (<span className="text-red-500">*</span>)}
                </label>
                <Select
                  id='customer-rate-plan'
                  placeholder="Select Assign Customer"
                  onChange={handleAssignCustomer}
                  className="w-full"
                  value={assignCustomer}
                  showSearch={true}
                  allowClear
                  clearIcon={
                    <CloseOutlined className="clear"/>
                  }
                  suffixIcon={<ChevronDownIcon className="w-5 mt-2 h-5 text-gray-600" />}                 >
                  {AssignCustomerOptions?.map((option,index) => (
                    <Option key={index} value={option}>
                      {`${option} -- ${customersMap && option && customersMap[option] ? customersMap[option] : ""}`}
                    </Option>
                  ))}
                </Select>
                {showValidation && is2OChange && !assignCustomer && (
                  <p className="text-red-500 text-sm mt-3">
                    Assign Customer is required.
                  </p>
                )}
              </div>
              
                {(is2OChange && (partner && partner.toLowerCase() !== "wingtel")) && (
                <div className="flex items-center mt-6 gap-x-3">
                  {/*  <div className="grid grid-cols-2"> */}
                  <label className="field-label block mb-1">Create Service/Product</label>
                  <Checkbox
                    checked={createServiceProduct}
                    onChange={handleCheckboxChange}
                    className="w-6 h-6 accent-blue-500"
                  />
                </div>
                )}
                {createServiceProduct && (
                // <div className="space-y-4">
                 <> 
                   <div className="flex flex-col">
                      <label className="field-label block mb-1">
                        Billing Provider<span className="text-red-500">*</span>
                      </label>
                      <ReactSelect
                        value={
                          revIOProviderId
                            ? {
                              label: revIOProviderOptions.find(
                                (option: any) => option.value === revIOProviderId
                              )?.label,
                              value: revIOProviderId,
                            }
                            : null
                        }
                        isClearable
                        onChange={(selectedOption) => {
                          handleProviderChange(selectedOption)
                        }}
                        styles={DropdownStyles}
                        menuPortalTarget={document.body}
                        menuPosition="fixed"
                        menuPlacement="auto"
                        options={
                          revIOProviderOptions.length > 0
                            ? revIOProviderOptions
                            : [{ label: "No options", value: "No options" }]
                        }
                        className="w-full"
                        placeholder="Please Select a Billing Provider"
                      />
                       {(errors.revIOProviderId) && (
                      <div className="text-red-500 text-sm">{errors.revIOProviderId}</div>
                    )}
                    </div>
                      
                      <div className="flex flex-col">
                        <label htmlFor='customer-rate-plan' className="field-label block mb-1" style={{ fontFamily: 'Calibri, sans-serif' }}>Service Type<span className="text-red-500">*</span>
                        </label>
                        <ReactSelect
                        id="service-type"
                        placeholder="Select Service Type"
                        options={serviceTypeOptions.map((option: any) => ({
                        label: option,
                        value: option,
                        }))}
                        value={
                        serviceType
                        ? { label: serviceType, value: serviceType }
                        : null
                        }
                        onChange={(selectedOption) => handleselectServiceType(selectedOption?.value)}
                        isClearable
                        styles={DropdownStyles}
                        className="w-full"
                        />
                        {(showValidation && errors.serviceType) && (
                          <p className="text-red-500 text-sm text-left">
                          {errors.serviceType}
                        </p>
                        )}

                      </div>
                  
                   
                    <div className="col-span-2 grid grid-cols-[1fr_auto_1fr] gap-x-4 items-center">
                    <div className="flex flex-col mb-1">
                      <label className="field-label block mb-1">
                        Billing Product<span className="text-red-500">*</span>
                      </label>
                      <ReactSelect
                        className="w-full"
                        // options={productOptions}
                        // options={productOptions.sort((a, b) => a.label.localeCompare(b.label))}
                        options={[
                          ...new Map(productOptions.map((item) => [item.label, item])).values(),
                        ].sort((a, b) => a.label.localeCompare(b.label))}
                        value={selectedProduct}
                        onChange={handleProductChange}
                        isDisabled={!!selectedPackage}
                        isMulti
                        styles={DropdownStyles}
                        // menuPortalTarget={document.body}
                        // menuPosition="fixed"
                        // menuPlacement="auto"
                        isClearable
                      />
                    {/* <p><b>(OR)</b></p> */}
                    </div>

                    <div className="flex justify-center items-center pt-6 px-1">
                          <b>(OR)</b>
                    </div>

                   
                      {/* <span className="w-1/4 font-semibold">
                        OR
                      </span>
               */}

                    <div className="">
                      <label className="field-label block mb-1">
                        Billing Package<span className="text-red-500">*</span>
                      </label>
                      <ReactSelect
                        className="w-full"
                        // options={packageOptions}
                        // options={packageOptions.sort((a, b) => a.label.localeCompare(b.label))}
                        options={[
                          ...new Map(packageOptions.map((item) => [item.label, item])).values(),
                        ].sort((a, b) => a.label.localeCompare(b.label))}
                        value={selectedPackage}
                        onChange={handlePackageChange}
                        isDisabled={selectedProduct.length > 0}
                        isClearable
                        styles={DropdownStyles}
                      // menuPortalTarget={document.body}
                      // menuPosition="fixed"
                      // menuPlacement="auto"
                      />
                    </div>
                    {(errors.productOrPackage || productError) && (
                      <div className="text-red-500 text-sm">{errors.productOrPackage}</div>
                    )}
                    </div>

                    


                    

                    {selectedProduct && selectedProduct.length > 0 && (
                    <div className='mb-4'>
                      <label className="field-label block mb-1">
                        Rates
                      </label>
                      {Object.keys(selectedRates).length > 0 && (
                        <div className="grid grid-cols-2 gap-4">
                          {Object.entries(selectedRates).map(([description, rate], index) => (
                            <React.Fragment key={index}>
                              <div className="text-left pr-4">{description}:</div>
                              <div>
                                <input
                                  type="number"
                                  value={Number(rate)}
                                  min="0"
                                  step="0.01"
                                  className="rates w-[100px] border border-gray-400 rounded pl-2"
                                  onChange={(e) => {
                                    const newRate = e.target.value === "" ? "0.0" : e.target.value;
                                    setSelectedRates((prevRates) => ({
                                      ...prevRates,
                                      [description]: newRate,
                                    }));
                                  }}
                                />
                              </div>
                            </React.Fragment>
                          ))}
                        </div>
                      )}
                    </div>
                    )}



                     
                      <div className="flex items-center space-x-2">
                      <label className="field-label block mb-1">Prorate</label>

                      <Checkbox
                        // defaultChecked={true}
                        checked={prorate}
                        onChange={(e) => setProrate(e.target.checked)}
                      ></Checkbox>
                    </div>

                   


                    {/* <div className="grid grid-cols-2 gap-x-6 items-center mt-4"></div> */}
                    {createServiceProduct && (
                      <>
                        {(prorate || customerRatePlan || (!prorate && !createServiceProduct)) && (
                            <>
                              <div className="flex flex-col">
                                <label htmlFor="effectiveDateDrp" className="field-label block mb-1">Effective Date</label>
                                <Select
                                  id='effectiveDateDrp'
                                  placeholder="Select..."
                                  onChange={handleSelectEffectiveDate}
                                  className="w-full"
                                  value={selectedDateOption}
                                  showSearch={true}
                                  allowClear
                                  clearIcon={
                                    <CloseOutlined className="clear" />
                                  }
                                  suffixIcon={<ChevronDownIcon className="w-5 mt-2 h-5 text-gray-600" />}                 >
                                  {effectiveDateOptions?.map((option: any, index: any) => (
                                    <Option key={index} value={option}>
                                      {option}
                                    </Option>
                                  ))}
                                </Select>

                              </div>
                              {isCustomDateChecked && (
                                <div>
                                  <label className="field-label block mb-1">
                                    Effective Date
                                    {/* <span className="text-red-500">*</span> */}
                                  </label>
                                  <DatePicker
                                    value={effectiveDate}
                                    onChange={(date) => setEffectiveDate(date)}
                                    // className="w-3/4"
                                    className={`w-full ${useCarrierActivation ? 'non-editable-input' : 'input'}`}
                                    format="MM/DD/YYYY"
                                    placeholder="MM/DD/YYYY"
                                    // disabledDate={(date) => date.isBefore(dayjs(), "day")} // Disable previous dates
                                    disabled={useCarrierActivation}
                                  />
                                </div>
                              )}
                            </>
                        )}
                        
                      </>
                    )}

                     {(prorate) && (role?.toLowerCase() === "super admin" || role?.toLowerCase() === "partner admin") && (
                      <div className="flex items-center space-x-4">
                        <label className="field-label block mb-1">
                          Use Carrier Activation?
                        </label>

                        <Checkbox
                          checked={useCarrierActivation}
                          onChange={(e) => setUseCarrierActivation(e.target.checked)}
                        ></Checkbox>
                      </div>
                    )}
                    

                    
                    <div className="">
                      <label className="field-label block mb-1">Product Description</label>
                      <textarea
                        rows={2}
                        value={description}
                        onChange={(e) => setDescription(e.target.value)}
                        className="w-full border border-gray-300 rounded-md p-2"
                        placeholder="Enter Description"
                        disabled={!createServiceProduct} // Disable if createServiceProduct is false
                      />
                    </div>
                    </>
                    // </div>
                   

               

                )}
              {isBPEnabled && (
                <>
                <div>
                  <label htmlFor='customer-rate-plan' className="field-label block mb-1" style={{ fontFamily: 'Calibri, sans-serif' }}>Customer Rate Plan</label>
                  <Select
                    id='customer-rate-plan'
                    placeholder="Select a Customer Rate Plan"
                    onChange={handleCustomerRatePlanChange}
                    className="w-full text-[15px] font-medium"
                    value={customerRatePlan}
                    showSearch
                    allowClear
                    clearIcon={
                      <CloseOutlined className="clear" />
                    }
                    suffixIcon={<ChevronDownIcon className="w-5 mt-2 h-5 text-gray-600" />}                 >
                    {CustomerRatePlanCodeOptions.map((option) => (
                      <Option key={option} value={option}>
                        {option}
                      </Option>
                    ))}
                  </Select>
                </div>

                  {(!createServiceProduct) && (

                        <>
                          <div className={`${!isAllChangeType ? "flex items-center space-x-4" : ""}`}>

                            <label htmlFor="effectiveDateDrp" className={`${!isAllChangeType ? "w-1/4 font-semibold" : "field-label"}`}>Effective Date</label>
                            <Select
                              id='effectiveDateDrp'
                              placeholder="Select..."
                              onChange={handleSelectEffectiveDate}
                              className="w-full"
                              value={selectedDateOption}
                              showSearch={true}
                              allowClear
                              clearIcon={
                                <CloseOutlined className="clear" />
                              }
                              suffixIcon={<ChevronDownIcon className="w-5 mt-2 h-5 text-gray-600" />}                 >
                              {effectiveDateOptions?.map((option: any, index: any) => (
                                <Option key={index} value={option}>
                                  {option}
                                </Option>
                              ))}
                            </Select>

                          </div>
                          {isCustomDateChecked && (
                            <div className=''>
                              <label htmlFor='date-picker' className="field-label block mb-1" style={{ fontFamily: 'Calibri, sans-serif' }}>Effective Date </label>
                              <DatePicker
                                id='date-picker'
                                onChange={handleDateChange}
                                className="w-full h-12"
                                value={effectiveDate ? dayjs(effectiveDate) : null} />
                              {errors.effectiveDate && !createServiceProduct && (
                                <div className="text-red-500 text-sm">{errors.effectiveDate}</div>
                              )}
                              {isBPEnabled && <span className='text-sm'> The default Effective Date represents Carrier Activation Date of the Device.</span>}
                            </div>
                          )}
                        </>

                )}
                
                <div>
                  <label htmlFor='comm-plan' className="field-label block mb-1" style={{ fontFamily: 'Calibri, sans-serif' }}>Customer Rate Pool</label>
                  <Select
                    id='comm-plan'
                    placeholder="Select a Communication Plan"
                    onChange={handleCommPlanChange}
                    className="w-full"
                    value={ratePool}
                    showSearch
                    allowClear
                    clearIcon={
                      <CloseOutlined className="clear" />
                    }
                    suffixIcon={<ChevronDownIcon className="w-5 mt-2 h-5 text-gray-600" />}
                  >
                    <Option key="none" value="None">
                      None
                    </Option>
                    {ratePools.map((option, index) => (
                      <Option key={index} value={option}>
                        {option}
                      </Option>
                    ))}
                  </Select>
                </div>
              
               
              </>
              )}
            </div>
          )}
          </div>
        </>
      </Modal>
    );
}
 )

export default AssignCustomerModal;
