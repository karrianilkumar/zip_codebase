import React, {forwardRef, useImperativeHandle,useEffect, useState } from 'react';
import { Modal, Divider, Select, Button, DatePicker, Checkbox, Spin } from 'antd';
import { ChevronDownIcon } from '@heroicons/react/24/outline';
import { useAuth } from '@/app/components/auth_context';
import axios from 'axios';
import { ENV_ROUTES } from '@/app/components/routes/route_constants';
import { CloseOutlined } from '@ant-design/icons';
import dayjs from 'dayjs';
import moment from 'moment';
import { getCurrentDateTime } from '../header_constants';
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { useInventoryAllChangeTypesStore } from '@/app/stores/inventorytAllChangeTypesStore';
import { useCustomerProfileStore } from '@/app/billing/killbill_stores/customer_profile_store';

const { Option } = Select;

interface UpdateStatusModalProps {
  visible: boolean;
  onCancel: () => void;
  onUpdate: (updatedRow: any,event_type:string,moduleStatus:boolean) => void;
  rowData?: any;
  is2OChange?: boolean;
  isSingle?:boolean;
  isAllChangeTypesFlow?: Boolean;
}
export interface UpdateCustomerRatePlanContentRef {
  runValidation: () => Promise<void> | void;
  runSubmit: () => Promise<void> | void;
   hasValidData: () => boolean; // Add this method
}
const UpdateCustomerRatePlan =forwardRef<UpdateCustomerRatePlanContentRef, UpdateStatusModalProps>(
({ visible, onCancel, onUpdate, rowData ,is2OChange,isSingle,isAllChangeTypesFlow },ref) => {
  const is_single_line = (!is2OChange || isSingle)

  const [customerRatePlan, setcustomerRatePlan] = useState<string>(is_single_line ? rowData?.customer_rate_plan_name || '': '');
  const [ratePool, setRatepool] = useState<string>(is_single_line ? rowData?.customer_rate_pool_name || '' : '');
  
  const [effectiveDate, setEffectiveDate] = useState<string | null>(null);
  const [isCustomDateChecked, setIsCusomDateChecked] = useState<boolean>(false);
  const [selectedDateOption, setSelectedDateOption] = useState<string | null>(null);
  const [effectiveDateOptions, setEffectiveDateOptions] = useState<any[]>([]);
  const [effectiveDateOptionsMap, setEffectiveDateOptionsMap] = useState<any>({});

  const [isEffectiveDateChecked, setIsEffectiveDateChecked] = useState<boolean>(false);
  const [formData, setFormData] = useState<any>(is_single_line ? rowData : {... rowData , customer_rate_plan_name:"",customer_name:"",customer_rate_pool_name:"",effective_date:""})
  const [loading, setLoading] = useState(true);
  const { username, partner, role, settabledata, token, selectedDb,metaData, firstLastName, sessionId } = useAuth();
  const [CustomerRatePlanCodeOptions, setCustomerRatePlanCodeOptions] = useState<any[]>([])
  const [ratePools, setRatePools] = useState<any[]>([])
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  //bp states
  const [isBPEnabled, setIsBPEnabled] = useState(false);
  const [AssignCustomerOptions, setAssignCustomerOptions] = useState<any[]>([])
  const [customersMap, setCustomersMap] = useState<any>({})
  const [revIOModuleStatus, setRevIOModuleStatus] = useState<boolean>(false);
  const [assignCustomer, setAssignCustomer] = useState<string>(is_single_line ? rowData?.customer_name || '': '');
  const [activatedPlans, setActivatedPlans] = useState<any[]>([])
  const [activationDate, setActivationDate] = useState<string>('');
  // const { is2OFilterLoaded  } = useFeatureStore();
    const { setIs2OFilterLoaded,is2OFilterLoaded } = useCustomerProfileStore();
  const { activeChange, isAllChangeType, setIsValidated, setValidationTrigger, setsuccessFullChangeTypes, successFullChangeTypes,setCustomerRatePlanData } = useInventoryAllChangeTypesStore();
  const [saveChanges, setSaveChanges] = useState<boolean>(true);
  const [showValidation, setShowValidation] = useState(false);
  const [customerRatePlanError, setCustomerRatePlanError] = useState<string>("");
  
  const versionBasedPath = is2OChange ? ENV_ROUTES.INVENTORY : ENV_ROUTES.SIM_MANAGEMENT
  
  const handleCustomerRatePlanChange = (value: string) => {
    const selectedvalue =  value === "No Change" ? rowData?.customer_rate_plan_name || value : value
    if (value) {
      const formData_ = formData
      formData_.customer_rate_plan_name = selectedvalue
      setcustomerRatePlan(value);
      setFormData(formData_)
      if (isBPEnabled && activatedPlans.includes(selectedvalue)) {
        setEffectiveDate(activationDate);
        const formData_ = formData
        formData_["effective_date"] = activationDate
        setFormData(formData_)
      }
      else{
        setEffectiveDate(null);
      }
    }
    else {
      setcustomerRatePlan("");
    }
  };

  const handleCommPlanChange = (value: string) => {
    if (value) {
      const formData_ = formData
      formData_["customer_rate_pool_name"] = value
      setRatepool(value);
      setFormData(formData_)
    }
    else {
      setRatepool("");
    }
  };

  const handleAssignCustomer = (value: string) => {
    if (value) {
      const formData_ = formData
      let customer_name_ = value.toLowerCase()
      formData_.isRevCustomer = customer_name_.endsWith(" -- revio")
      console.log("formData_",formData_)
      if (customer_name_.endsWith(" -- bp") || customer_name_.endsWith(" -- revio")) {
        customer_name_ = value.replace(" -- BP", "").replace(" -- RevIO", "");
      }
      else {
        customer_name_ = value
      }
      formData_.customer_name = customer_name_
      const customer_id_ = customersMap?.[value] || null
      formData_.customer_id = customer_id_
      setAssignCustomer(value);
      setFormData(formData_)
    }
    else {
      setAssignCustomer("");
      setFormData({...formData , customer_name:""})
    }
  };

  const handleDateChange = (date: any, dateString: string | string[]) => {
    if (typeof dateString === 'string') {
      setEffectiveDate(dateString);
    } else {
      setEffectiveDate(dateString[0]);
    }
    const formData_ = formData
    formData_["effective_date"] = dateString
    setFormData(formData_)
  };

  const handleEffectiveDateCheck = (e: any) => {
    setIsEffectiveDateChecked(e.target.checked);
    if (!e.target.checked) {
      setEffectiveDate(null);
    }
  };
   // Add this method to check if any field has valid data
  const hasValidData = () => {
    const isAnyFieldFilled =
      !!customerRatePlan ||
      !!ratePool ||
      !!assignCustomer ||
      !!effectiveDate ||
      isEffectiveDateChecked;
    
    return isAnyFieldFilled;
  };

  const handleUpdate = () => {
    const newErrors: { [key: string]: string } = {};
    let formData_ = { ...formData,customer_rate_plan_name: customerRatePlan,customer_rate_pool_name:ratePool,effective_date: effectiveDate || null };
    
    // Validate Customer Rate Plan (mandatory field)
    if (CustomerRatePlanCodeOptions.length > 0 && (!customerRatePlan || customerRatePlan === "")) {
      newErrors.customerRatePlan = "Customer Rate Plan is required.";
    }
    if ((isEffectiveDateChecked || isBPEnabled) && !effectiveDate) {
      newErrors.effectiveDate = "Effective Date is required.";
    }
    if (!effectiveDate && isAllChangeType && isEffectiveDateChecked){
      newErrors.effectiveDate = "Effective Date is required.";
    }
    // If no validation errors → proceed with update
    if (Object.keys(newErrors).length === 0 && !isAllChangeType) {
      onUpdate(formData_, "Update Customer Rate Plan", revIOModuleStatus);
      setShowValidation(false);
      setCustomerRatePlanError("");
    }

    setsuccessFullChangeTypes(
      successFullChangeTypes.filter((c: any) => c !== activeChange)
    );

    if (isAllChangeType) {
      const isAnyFieldFilled =
        !!customerRatePlan ||
        !!ratePool ||
        !!assignCustomer ||
        !!effectiveDate;

      if (!isAnyFieldFilled) {
        // None of the fields entered → clear errors and allow
        setErrors({});
        setIsValidated(true);
        setValidationTrigger();
        return;
      } else {
        // At least one field is filled, validate mandatory field
        if (CustomerRatePlanCodeOptions.length > 0 && (!customerRatePlan || customerRatePlan === "")) {
          // setCustomerRatePlanError("Customer Rate Plan is required.");
        newErrors.customerRatePlan = "Customer Rate Plan is required.";
        }
        if (!effectiveDate && isEffectiveDateChecked){
        newErrors.effectiveDate = "Effective Date is required.";
        }
        setErrors(newErrors);
        setShowValidation(true);
        if (Object.keys(newErrors).length > 0) {
        setIsValidated(false);
        setsuccessFullChangeTypes(
          successFullChangeTypes.filter((c: any) => c !== activeChange)
        );
        return;
        }
      setErrors({});
      setIsValidated(true);
      if (saveChanges) {
        setCustomerRatePlanData(formData_)
        setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
      }    
      setValidationTrigger();
      return;
      }
    } else {
      // Normal validation path
      setErrors(newErrors);
      return;
    }
  };

  const handleSubmit = () => {
      console.log("Update Customer Rate Plan Formdata",formData);
      onUpdate(formData, "Update Customer Rate Plan", revIOModuleStatus);
  };

  // const disablePastDates = (current: any) => {
  //   // Disable all dates before today
  //   return current && current < moment().startOf('day'); // Start of the current day to include today's date
  // };

  const fetchBPData = async () => {
    setLoading(true);
    try {
      const url = versionBasedPath;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/customers_dropdown_inventory",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "SimManagement Inventory",
        feature_module_name: "Inventory",
        Partner: partner,
        service_provider: rowData?.service_provider,
        service_provider_id: rowData?.service_provider_id,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        dropdown: "Assign customer",
        modified_by: firstLastName,
        billing_platform_flag:isBPEnabled,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching Inventory data. Please try again.',
          centered: true,
          onOk: onCancel

        });
      } else {
        const customersMap_ = parsedData?.customer_name || {}
        setCustomersMap(customersMap_)
        const customerOptions_ = Object.keys(customersMap_) || []
        setAssignCustomerOptions(customerOptions_)
        setRevIOModuleStatus(parsedData?.module_status)
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
        onOk: onCancel

      });
    } finally {
      setLoading(false);
    }
  };

  const fetchBpFlag = async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_cross_provider_optimization_status",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Active Customer Rate Plan",
        feature_module_name: "Customer Rate Plans",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        const billing_plaform_flag = parsedData?.billing_platform_flag || false
        setIsBPEnabled(billing_plaform_flag)
        if (billing_plaform_flag) {
          fetchBPData()
          fetchActivationDate()
        }
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      setLoading(false);

    }
  };
  const fetchActivationDate = async () => {
    setLoading(true);
    try {
      const url = versionBasedPath;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/carrier_activation_date_rata_plans",
        role_name: role,
        // parent_module: "Sim Management",
        module_name: "SimManagement Inventory",
        // feature_module_name: "Inventory",
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        iccid: rowData?.iccid || '',
        msisdn: rowData?.msisdn || '',
        table_name: "sim_management_inventory"
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching Inventory data. Please try again.',
          centered: true,
          onOk: onCancel

        });
      } else {
        const activatedPlans_ = parsedData?.rate_plans || [];
        const activation_date = parsedData?.activation_date || null;
        setActivatedPlans(activatedPlans_)
        setActivationDate(activation_date)
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
        onOk: onCancel

      });
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    setcustomerRatePlan(is_single_line ? rowData?.customer_rate_plan_name || '': '')
    setRatepool(is_single_line ? rowData?.customer_rate_pool_name || '': '')
    const fetchData = async () => {
      setLoading(true);
      try {
        const url = versionBasedPath;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/inventory_dropdowns_data",
          role_name: role,
          parent_module: "Sim Management",
          module_name: "SimManagement Inventory",
          feature_module_name: "Inventory",
          service_provider_id: rowData?.service_provider_id || 0,
          list_view_data_id: rowData?.id || 0,
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          dropdown: "Customer Rate Plan",
          modified_by: firstLastName
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);

        if (parsedData.flag === false) {
          Modal.error({
            title: 'Data Fetch Error',
            content: parsedData.message || 'An error occurred while fetching Inventory data. Please try again.',
            centered: true,
            onOk: onCancel

          });
        } else {
          const carrierOptions_ = parsedData?.rate_plan_list || []
          setCustomerRatePlanCodeOptions(carrierOptions_)
          const commOptions_ = parsedData?.rate_pool_list || []
          setRatePools(commOptions_)
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        Modal.error({
          title: 'Data Fetch Error',
          content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
          centered: true,
          onOk: onCancel

        });
      } finally {
        setLoading(false);
      }
    };
    const fetchDropdownData = async () => {
      setLoading(true);
      try {
        const url = versionBasedPath;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/inventory_dropdowns_data",
          role_name: role,
          parent_module: "Sim Management",
          module_name: "SimManagement Inventory",
          feature_module_name: "Inventory",
          service_provider_id: rowData?.service_provider_id || 0,
          list_view_data_id: rowData?.id || 0,
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          dropdown: "Customer Rate Plan",
          modified_by: firstLastName
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);

        if (parsedData.flag === false) {
          Modal.error({
            title: 'Data Fetch Error',
            content: parsedData.message || 'An error occurred while fetching data. Please try again.',
            centered: true,
            onOk: onCancel

          });
        } else {

          const billing_start_dates_options_map = parsedData?.billing_start_dates || {};
          setEffectiveDateOptionsMap(billing_start_dates_options_map)
          setEffectiveDateOptions([
            ...Object.keys(billing_start_dates_options_map).map((option: string) => (option))
          ]);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        Modal.error({
          title: 'Data Fetch Error',
          content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
          centered: true,
          onOk: onCancel

        });
      } finally {
        setLoading(false);
      }
    };
    if (visible === true) {
      fetchBpFlag()
      fetchData()
      fetchDropdownData()
    }
  }, [visible]);

  const handleSelectEffectiveDate = (selectedOption: any) => {
         setIsCusomDateChecked(false)
         setEffectiveDate(null)
         if (selectedOption) {
           const value = selectedOption || "";
           setSelectedDateOption(value)
           const mappedDate = effectiveDateOptionsMap[value] || null
           const normalizedValue = value.toLowerCase()
           if (normalizedValue.includes("bill")) {
             setEffectiveDate(mappedDate)
           }
           else if (normalizedValue.includes("current")) {
             setEffectiveDate(moment().toISOString());
           }
           else if (normalizedValue.includes("custom")) {
             setIsCusomDateChecked(true)
           }
  
         }
         else {
           setEffectiveDate(null)
           setSelectedDateOption(null)
         }
       };

  const showDataAllocationCheckbox = CustomerRatePlanCodeOptions.some(option => customerRatePlan.includes('Sim Pooling Enabled'));

  useImperativeHandle(ref, () => ({
    runValidation: handleUpdate,
    runSubmit:handleSubmit,
    hasValidData: hasValidData,
  }));

  // The main content that will be reused
  const renderContent = () => {
    if (loading || is2OFilterLoaded) {
      return (
        <div className="popup flex justify-center items-center w-full h-full">
          <Spin size="large" />
        </div>
      );
    }

    return (
      <>
        {isAllChangeType && (
          <div className="flex justify-end px-4">
            <span className="mr-2 font-semibold">Save Changes</span>
            <Checkbox
              checked={saveChanges}
              onChange={(e) => {
                if (!e.target.checked) {
                  setsuccessFullChangeTypes(
                    successFullChangeTypes.filter((c: any) => c !== activeChange)
                  );
                }
                setSaveChanges(e.target.checked)
              }}
              className="custom-checkbox"
            >

            </Checkbox>
          </div>
        )}
        <div className={is2OChange ? "grid grid-cols-2  gap-x-6 gap-y-4 items-start" : "flex flex-col space-y-4"}>
          <div>
            <label htmlFor='customer-rate-plan' className="field-label" style={{ fontFamily: 'Calibri, sans-serif' }}>
              Customer Rate Plan<span className="text-red-500">*</span>
            </label>
            <Select
              id='customer-rate-plan'
              placeholder="Select a Customer Rate Plan"
              onChange={handleCustomerRatePlanChange}
              className="w-full mt-1 mb-2"
              value={customerRatePlan}
              showSearch
              allowClear
              clearIcon={<CloseOutlined className="clear" />}
              suffixIcon={<ChevronDownIcon className="w-5 mt-2 h-5 text-gray-600" />}
            >
              <Option key="no-change" value="No Change">
                No Change
              </Option>
              {CustomerRatePlanCodeOptions.map((option) => (
                <Option key={option} value={option}>
                  {option}
                </Option>
              ))}
            </Select>
            {(customerRatePlanError || errors.customerRatePlan) && (
              <p className="text-red-500 text-sm mt-1">
                {customerRatePlanError || errors.customerRatePlan}
              </p>
            )}
          </div>
          <div>
            <label htmlFor='comm-plan' className="field-label" style={{ fontFamily: 'Calibri, sans-serif' }}>Customer Rate Pool</label>
            <Select
              id='comm-plan'
              placeholder="Select a Communication Plan"
              onChange={handleCommPlanChange}
              className="w-full mt-1 mb-2"
              value={ratePool}
              showSearch
              allowClear
              clearIcon={<CloseOutlined className="clear" />}
              suffixIcon={<ChevronDownIcon className="w-5 mt-2 h-5 text-gray-600" />}
            >
              <Option key="none" value="None">
                None
              </Option>
              {ratePools.map((option, index) => (
                <Option key={index} value={option}>
                  {option}
                </Option>
              ))}
            </Select>
            {errors.ratePool && <div className="text-red-500 mt-2">{errors.ratePool}</div>}
          </div>
          {isBPEnabled && (
            <>
              <div>
                <label htmlFor='customer-rate-plan' className="field-label" style={{ fontFamily: 'Calibri, sans-serif' }}>Assign Customer</label>
                <Select
                  id='customer-rate-plan'
                  placeholder="Select Assign Customer"
                  onChange={handleAssignCustomer}
                  className="w-full mt-1 mb-2"
                  value={assignCustomer}
                  showSearch={true}
                  allowClear
                  clearIcon={<CloseOutlined className="clear" />}
                  suffixIcon={<ChevronDownIcon className="w-5 mt-2 h-5 text-gray-600" />}
                >
                  {AssignCustomerOptions?.map((option, index) => (
                    <Option key={index} value={option}>
                      {`${option} -- ${customersMap && option && customersMap[option] ? customersMap[option] : ""}`}
                    </Option>
                  ))}
                </Select>
              </div>
            </>
          )}
          <div className="flex flex-col justify-start mb-2">
            {!isBPEnabled && (
              <div className="flex items-center space-x-2">
                <label htmlFor='eff-date' className="field-label" style={{ fontFamily: 'Calibri, sans-serif' }}>Effective Date</label>
                <Checkbox id='eff-date' className="ml-7 custom-checkbox" onChange={handleEffectiveDateCheck}></Checkbox>
              </div>
            )}

            {(isEffectiveDateChecked || isBPEnabled) && (

              // <>
                <div className="">

                  <label htmlFor="effectiveDateDrp" className="field-label">Effective Date<span className="text-red-500">*</span></label>
                  <Select
                    id='effectiveDateDrp'
                    placeholder="Select..."
                    onChange={handleSelectEffectiveDate}
                    className="w-full mt-1 mb-2"
                    value={selectedDateOption}
                    showSearch={true}
                    allowClear
                    clearIcon={
                      <CloseOutlined className="clear" />
                    }
                    suffixIcon={<ChevronDownIcon className="w-5 mt-2 h-5 text-gray-600" />}                 >
                    {effectiveDateOptions?.map((option: any, index: any) => (
                      <Option key={index} value={option}>
                        {option}
                      </Option>
                    ))}
                  </Select>

                  {errors.effectiveDate && (
                  <p className="text-red-500 text-sm mt-1">{errors.effectiveDate}</p>
                )}

                </div>
                )}
               {/* </> */}

          </div>
          {isCustomDateChecked && (
                  <div className="">
                    <label htmlFor='date-picker' className="field-label" style={{ fontFamily: 'Calibri, sans-serif' }}>Effective Date <span className="text-red-500">*</span> </label>
                    <DatePicker
                      id='date-picker'
                      onChange={handleDateChange}
                      className="w-full h-10"
                      value={effectiveDate ? dayjs(effectiveDate) : null}
                    />
                    {isBPEnabled && <span className='text-sm'>The default Effective Date represents Carrier Activation Date of the Device.</span>}

                  </div>
                )}

          {showDataAllocationCheckbox && (
            <div style={{ marginTop: '1.5rem' }}>
              <span className="text-lg">Show Customer Data Allocation</span>
              <Checkbox className="ml-7 custom-checkbox" />
            </div>
          )}
        </div>
      </>
    );
  };

  // Conditional rendering: Modal OR div based on isAllChangeTypesFlow
  if (isAllChangeTypesFlow) {
    // Render just the content (div) for All Change Types flow
    return (
      <div className="p-4">
        {renderContent()}
      </div>
    );
  }

  return (
    <Modal
      title={
        <div className='mt-[-10px]'><span className='text-[19px]'>Update Customer Rate Plan</span></div>}
      visible={visible}
      centered
      onCancel={onCancel}
      footer={[
        <div className="flex justify-center space-x-2 mt-12" key="buttons">
          <button key="cancel" onClick={onCancel} className="cancel-btn h-[30px] text-base" style={{ fontFamily: 'Calibri, sans-serif' }}>
            Cancel
          </button>
          <button key="update" onClick={handleUpdate} className="save-btn text-base border-none" style={{ fontFamily: 'Calibri, sans-serif' }}>
            Update
          </button>
        </div>,
      ]}
      width={500}
      style={{ height: '500px' }}
    >
        <>
              {(loading ||  is2OFilterLoaded) ? (
                <div className="popup flex justify-center items-center w-full h-full">
                  <Spin size="large" />
                </div>
              ) : (
        <div className="flex flex-col space-y-4">
          <div>
            <label htmlFor='customer-rate-plan' className="field-label" style={{ fontFamily: 'Calibri, sans-serif' }}>
              Customer Rate Plan<span className="text-red-500">*</span>
            </label>
            <Select
              id='customer-rate-plan'
              placeholder="Select a Customer Rate Plan"
              onChange={handleCustomerRatePlanChange}
              className="w-full mt-1 mb-2"
              value={customerRatePlan}
              showSearch
              allowClear
              clearIcon={<CloseOutlined className="clear" />}
              suffixIcon={<ChevronDownIcon className="w-5 mt-2 h-5 text-gray-600" />}
            >
              <Option key="no-change" value="No Change">
                No Change
              </Option>
              {CustomerRatePlanCodeOptions.map((option) => (
                <Option key={option} value={option}>
                  {option}
                </Option>
              ))}
            </Select>
            {(customerRatePlanError || errors.customerRatePlan) && (
              <p className="text-red-500 text-sm mt-1">
                {customerRatePlanError || errors.customerRatePlan}
              </p>
            )}
          </div>
          <div>
            <label htmlFor='comm-plan' className="field-label" style={{ fontFamily: 'Calibri, sans-serif' }}>Customer Rate Pool</label>
            <Select
              id='comm-plan'
              placeholder="Select a Communication Plan"
              onChange={handleCommPlanChange}
              className="w-full mt-1 mb-2"
              value={ratePool}
              showSearch
              allowClear
              clearIcon={<CloseOutlined className="clear" />}
              suffixIcon={<ChevronDownIcon className="w-5 mt-2 h-5 text-gray-600" />}
            >
              <Option key="none" value="None">
                None
              </Option>
              {ratePools.map((option, index) => (
                <Option key={index} value={option}>
                  {option}
                </Option>
              ))}
            </Select>
            {errors.ratePool && <div className="text-red-500 mt-2">{errors.ratePool}</div>}
          </div>
          {isBPEnabled && (
            <>
              <div>
                <label htmlFor='customer-rate-plan' className="field-label" style={{ fontFamily: 'Calibri, sans-serif' }}>Assign Customer</label>
                <Select
                  id='customer-rate-plan'
                  placeholder="Select Assign Customer"
                  onChange={handleAssignCustomer}
                  className="w-full mt-1 mb-2"
                  value={assignCustomer}
                  showSearch={true}
                  allowClear
                  clearIcon={<CloseOutlined className="clear" />}
                  suffixIcon={<ChevronDownIcon className="w-5 mt-2 h-5 text-gray-600" />}
                >
                  {AssignCustomerOptions?.map((option, index) => (
                    <Option key={index} value={option}>
                      {`${option} -- ${customersMap && option && customersMap[option] ? customersMap[option] : ""}`}
                    </Option>
                  ))}
                </Select>
              </div>
            </>
          )}
          <div style={{ marginTop: '1.5rem' }} className='mb-2'>
            {!isBPEnabled && (
              <>
                <label htmlFor='eff-date' className="text-lg" style={{ fontFamily: 'Calibri, sans-serif' }}>Effective Date</label>
                <Checkbox id='eff-date' className="ml-7 custom-checkbox" onChange={handleEffectiveDateCheck}></Checkbox>
              </>
            )}

            {(isEffectiveDateChecked || isBPEnabled) && (
                  <>
                    <div className="mt-2">

                      <label htmlFor="effectiveDateDrp" className="field-label">Effective Date<span className="text-red-500">*</span></label>
                      <Select
                        id='effectiveDateDrp'
                        placeholder="Select..."
                        onChange={handleSelectEffectiveDate}
                        className="w-full mt-1 mb-2"
                        value={selectedDateOption}
                        showSearch={true}
                        allowClear
                        clearIcon={
                          <CloseOutlined className="clear" />
                        }
                        suffixIcon={<ChevronDownIcon className="w-5 mt-2 h-5 text-gray-600" />}                 >
                        {effectiveDateOptions?.map((option: any, index: any) => (
                          <Option key={index} value={option}>
                            {option}
                          </Option>
                        ))}
                      </Select>

                      {errors.effectiveDate && (
                          <p className="text-red-500 text-sm mt-1">{errors.effectiveDate}</p>
                        )}

                    </div>
                    {isCustomDateChecked && (
                      <div className="mt-2 ">
                        <label htmlFor='date-picker' className="field-label">Effective Date <span className="text-red-500">*</span></label>
                        <DatePicker
                          id='date-picker'
                          onChange={handleDateChange}
                          className="w-full mt-1 h-10"
                          value={effectiveDate ? dayjs(effectiveDate) : null}
                        />
                        {isBPEnabled && <span className='text-sm'>The default Effective Date represents Carrier Activation Date of the Device.</span>}
                        
                      </div>
                    )}
                  </>
              
            )}
          </div>

          {showDataAllocationCheckbox && (
            <div style={{ marginTop: '1.5rem' }}>
              <span className="text-lg">Show Customer Data Allocation</span>
              <Checkbox className="ml-7 custom-checkbox" />
            </div>
          )}
        </div>
        )}
      </>
    </Modal>
  );
});

export default UpdateCustomerRatePlan;