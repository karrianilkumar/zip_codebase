import React, { useEffect, useState, forwardRef, useImperativeHandle } from 'react';
import { Modal, Button, Spin, DatePicker, Checkbox } from 'antd';
import Select from 'react-select';
import { useAuth } from '@/app/components/auth_context';
import axios from 'axios';
import { ENV_ROUTES } from '@/app/components/routes/route_constants';
import { DropdownStyles, NonEditableDropdownStyles } from '@/app/components/css/dropdown';
import dayjs from 'dayjs';
import { useFeatureStore } from '@/app/sim_management/inventory/featureStore';
import { useInventoryAllChangeTypesStore } from '@/app/stores/inventorytAllChangeTypesStore';
import { useCustomerProfileStore } from '@/app/billing/killbill_stores/customer_profile_store';

interface Update_2_0_FeaturesModalProps {
    visible: boolean;
    onCancel: () => void;
    onUpdate: (updatedRow: any, event_type: string) => void;
    rowData?: any;
    is2OChange?: Boolean;
    isAllChangeTypesFlow?: Boolean;
}

interface OptionType {
    value: number;
    label: string;
    soc_code: string;
    friendly_name: string;
}

export interface Update2OFeaturesContentRef {
    runValidation: () => Promise<void> | void;
    runSubmit: () => Promise<void> | void; // Add runSubmit
    hasValidData: () => boolean; // Add this method
}

const Update_2_0_FeaturesModal = forwardRef<Update2OFeaturesContentRef, Update_2_0_FeaturesModalProps>(
    ({ visible, onCancel, onUpdate, rowData, is2OChange, isAllChangeTypesFlow }, ref) => {
        const [formData, setFormData] = useState<any>(rowData);
        const [loading, setLoading] = useState(true);
        const [featureCodes, setFeatureCodes] = useState<any[]>([]);
        const [effectiveDate, setEffectiveDate] = useState<string | null>(null);
        const [specifyEffectiveDate, setSpecifyEffectiveDate] = useState<boolean>(false);
        const { username, partner, role, token, selectedDb,metaData, sessionId } = useAuth();
        const [featureCodesOptions, setFeatureCodesOptions] = useState<any[]>([]);
        const [selectedSOCCodes, setSelectedSOCCodes] = useState<string[]>([]);
        const [currentDate, setCurrentDate] = useState('');
        const [errors, setErrors] = useState<any>([]);
        const [removeFeatureCodes, setRemoveFeatureCodes] = useState<any[]>([]);
        const [overWrite, setOverWrite] = useState<boolean>(false);
        // const { is2OFilterLoaded } = useFeatureStore();
            const { setIs2OFilterLoaded,is2OFilterLoaded } = useCustomerProfileStore();
        
        const { activeChange, isAllChangeType, setIsValidated, setValidationTrigger, setsuccessFullChangeTypes, successFullChangeTypes } = useInventoryAllChangeTypesStore();
        const [saveChanges, setSaveChanges] = useState<boolean>(true);
        const [showValidation, setShowValidation] = useState(false);
        const [featureCodesError, setFeatureCodesError] = useState<string>("");

        const versionBasedPath = is2OChange ? ENV_ROUTES.INVENTORY : ENV_ROUTES.SIM_MANAGEMENT;

        useEffect(() => {
            const date = new Date();
            const formattedDate = date.toISOString().split('T')[0];
            setCurrentDate(formattedDate);
        }, []);

        // Fetch dropdown options when modal is visible
        useEffect(() => {
            const fetchData = async () => {
                setLoading(true);
                try {
                    const url = versionBasedPath;
                    const data = {
                        tenant_name: partner || 'default_value',
                        username,
                        path: '/update_features_pop_up_data',
                        role_name: role,
                        parent_module: 'Sim Management',
                        module_name: 'SimManagement Inventory',
                        feature_module_name: 'Inventory',
                        Partner: partner,
                        service_provider: rowData?.service_provider,
                        service_provider_id: rowData?.service_provider_id,
                        access_token: token,
                        db_name: selectedDb,
                        ...metaData,
                        sessionID: sessionId,
                        dropdown: 'Update features',
                        modified_by: username
                    };

                    const response = await axios.post(url, { data });
                    const parsedData = JSON.parse(response.data.body);

                    if (!parsedData.flag) {
                        Modal.error({
                            title: 'Data Fetch Error',
                            content: parsedData.message || 'An error occurred while fetching Inventory data. Please try again.',
                            centered: true,
                            onOk: onCancel
                        });
                    } else {
                        const feature_codes_map = parsedData?.soc_codes || [];
                        const options_ = feature_codes_map.map((option: any) => ({
                            value: option?.id || "",
                            label: `${option?.friendly_name || ""} - ${option?.soc_code || ""}`,
                            soc_code: option?.soc_code || "",
                            friendly_name: option?.friendly_name || "",
                        }));
                        setFeatureCodesOptions(options_);
                    }
                } catch (error) {
                    console.error('Error fetching data:', error);
                    Modal.error({
                        title: 'Data Fetch Error',
                        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                        centered: true,
                        onOk: onCancel
                    });
                } finally {
                    setLoading(false);
                }
            };

            if (visible) {
                fetchData();
            }
        }, [visible]);

        const handleSpecifyEffectiveDateChange = (checked: boolean) => {
            setSpecifyEffectiveDate(checked);
            if (!checked) {
                setEffectiveDate(null);
            }
        };
        // Add this method to check if any field has valid data
        const hasValidData = () => {
            const isAnyFieldFilled =
                (featureCodes && featureCodes.length > 0) ||
                (removeFeatureCodes && removeFeatureCodes.length > 0) ||
                overWrite ||
                specifyEffectiveDate ||
                !!effectiveDate;
            
            return isAnyFieldFilled;
        };
        const handleUpdate = () => {
            const newErrors: any = {};

            // Validate feature codes
            if (featureCodes && featureCodes.length === 0) {
                newErrors.featureCodes = "Feature Codes are required.";
            }

            // If no validation errors, proceed with update
            if (Object.keys(newErrors).length === 0 && !isAllChangeType) {
                let add_codes: any = [];
                let remove_codes: any = [];

                if (featureCodes && featureCodes.length > 0) {
                    add_codes = featureCodes.map((opt: any) => opt?.soc_code);
                }
                if (removeFeatureCodes && removeFeatureCodes.length > 0) {
                    remove_codes = removeFeatureCodes.map((opt: any) => opt?.soc_code);
                }

                const configuration_change_details_ = {
                    MobilityConfigurationIDsToAdd: add_codes,
                    MobilityConfigurationIDsToRemove: remove_codes,
                    effectiveDate: effectiveDate,
                    over_write: overWrite,
                };

                const featureCodesString = selectedSOCCodes.join(",");
                const formData_ = { 
                    ...formData, 
                    telegence_features: featureCodesString, 
                    configuration_change_details: configuration_change_details_, 
                    effective_date: effectiveDate || currentDate 
                };
                
                onUpdate(formData_, 'Update feature');
                setShowValidation(false);
                setFeatureCodesError("");
            }

            // Remove from successful change types if there are errors
            setsuccessFullChangeTypes(
                successFullChangeTypes.filter((c: any) => c !== activeChange)
            );

            // Handle all change types validation flow
            if (isAllChangeType) {
                const isAnyFieldFilled =
                    featureCodes.length > 0 ||
                    removeFeatureCodes.length > 0 ||
                    overWrite ||
                    specifyEffectiveDate ||
                    !!effectiveDate;

                if (!isAnyFieldFilled) {
                    // None of the fields entered → clear errors and allow
                    setErrors({});
                    setIsValidated(true);
                    setValidationTrigger();
                    return;
                } else {
                    // Check if feature codes are required and missing
                    if (featureCodes.length === 0 && !removeFeatureCodes.length) {
                        setFeatureCodesError("Feature Codes are required.");
                        return;
                    }

                    // All validations passed
                    setErrors({});
                    setIsValidated(true);
                    if (saveChanges) {
                        setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
                    }
                    setValidationTrigger();
                    return;
                }
            } else {
                // Normal validation path
                setErrors(newErrors);
                return;
            }
        };

        const handleSubmit = () => {
            let add_codes: any = [];
            let remove_codes: any = [];

            if (featureCodes && featureCodes.length > 0) {
                add_codes = featureCodes.map((opt: any) => opt?.soc_code);
            }
            if (removeFeatureCodes && removeFeatureCodes.length > 0) {
                remove_codes = removeFeatureCodes.map((opt: any) => opt?.soc_code);
            }

            const configuration_change_details_ = {
                MobilityConfigurationIDsToAdd: add_codes,
                MobilityConfigurationIDsToRemove: remove_codes,
                effectiveDate: effectiveDate,
                over_write: overWrite,
            };

            const featureCodesString = selectedSOCCodes.join(",");
            const formData_ = { 
                ...formData, 
                telegence_features: featureCodesString, 
                configuration_change_details: configuration_change_details_, 
                effective_date: effectiveDate || currentDate 
            };

            onUpdate(formData_, 'Update feature');
        };

        const handleFeatureCodesChange = (selectedOptions: any) => {
            if (!selectedOptions) {
                setFeatureCodes([]);
                return;
            }
            setFeatureCodes(selectedOptions);
        };

        const handleRemoveFeatureCodesChange = (selectedOptions: any) => {
            if (!selectedOptions) {
                setRemoveFeatureCodes([]);
                return;
            }
            setRemoveFeatureCodes(selectedOptions);
        };

        useImperativeHandle(ref, () => ({
            runValidation: handleUpdate,
            runSubmit: handleSubmit,
            hasValidData: hasValidData
        }));

        // The main content that will be reused
        const renderContent = () => {
            if (loading || is2OFilterLoaded) {
                return (
                    <div className="popup flex justify-center items-center w-full h-full">
                        <Spin size="large" />
                    </div>
                );
            }

            return (
                <>
                    {isAllChangeType && (
                        <div className="flex justify-end px-4">
                            <span className="mr-2 font-semibold">Save Changes</span>
                            <Checkbox
                                checked={saveChanges}
                                onChange={(e) => {
                                    if (!e.target.checked) {
                                        setsuccessFullChangeTypes(
                                            successFullChangeTypes.filter((c: any) => c !== activeChange)
                                        );
                                    }
                                    setSaveChanges(e.target.checked)
                                }}
                                className="custom-checkbox"
                            />
                        </div>
                    )}
                    <div className="flex flex-col space-y-4">
                        <div>
                            <label className="field-label">
                                Update Feature Codes
                                <span className="text-red-500">*</span>
                            </label>
                            <Select
                                isMulti
                                value={featureCodes}
                                options={featureCodesOptions}
                                onChange={handleFeatureCodesChange}
                                placeholder="Select feature codes"
                                styles={isAllChangeType && removeFeatureCodes.length>0?NonEditableDropdownStyles:DropdownStyles}
                                isDisabled={isAllChangeType && removeFeatureCodes.length>0}
                            />
                            {(errors.featureCodes || featureCodesError) && (
                                <div className="text-red-500 text-sm mt-1">
                                    {errors.featureCodes || featureCodesError}
                                </div>
                            )}
                        </div>

                        <div className='flex'>
                            <label className="field-label">Overwrite Feature Codes</label>
                            <Checkbox
                                id="overwrite"
                                checked={overWrite}
                                onChange={(e) => setOverWrite(e.target.checked)}
                                className='ml-4'
                            />
                        </div>

                        <div>
                            <label className="field-label">Remove Feature Codes</label>
                            <Select
                                isMulti
                                value={removeFeatureCodes}
                                options={featureCodesOptions}
                                onChange={handleRemoveFeatureCodesChange}
                                placeholder="Select feature codes"
                                styles={isAllChangeType && featureCodes.length>0?NonEditableDropdownStyles:DropdownStyles}
                                isDisabled={isAllChangeType && featureCodes.length>0}
                            />
                        </div>

                        <div className='flex'>
                            <label className="field-label">Specify Effective Date</label>
                            <Checkbox
                                id="applicableRatePlanForAll"
                                checked={specifyEffectiveDate}
                                onChange={(e) => handleSpecifyEffectiveDateChange(e.target.checked)}
                                className='ml-4'
                            />
                        </div>

                        {specifyEffectiveDate && (
                            <>
                                <div>
                                    <label className="field-label">Effective Date</label>
                                    <DatePicker
                                        value={effectiveDate ? dayjs(effectiveDate) : null}
                                        onChange={(date) =>
                                            setEffectiveDate(date ? date.format('YYYY-MM-DD') : null)
                                        }
                                        className="input"
                                        format="MM/DD/YYYY"
                                        placeholder="MM/DD/YYYY"
                                    />
                                </div>
                                <div className="info-message">
                                    <p className="text-sm">
                                        Date cannot be after 30 days and not before the first day of the current billing cycle.
                                    </p>
                                </div>
                            </>
                        )}
                    </div>
                </>
            );
        };

        // Conditional rendering: Modal OR div based on isAllChangeTypesFlow
        if (isAllChangeTypesFlow) {
            // Render just the content (div) for All Change Types flow
            return (
                <div className="p-4">
                    {renderContent()}
                </div>
            );
        }

        return (
            <Modal
                title="Update Telegence Device Feature"
                visible={visible}
                centered
                onCancel={onCancel}
                footer={[
                    <div className="flex justify-center space-x-2" key="buttons">
                        <button onClick={onCancel} className="cancel-btn">Cancel</button>
                        <button onClick={handleUpdate} className="save-btn">Update</button>
                    </div>
                ]}
                width={500}
            >
                {renderContent()}
            </Modal>
        );
    }
);

export default Update_2_0_FeaturesModal;