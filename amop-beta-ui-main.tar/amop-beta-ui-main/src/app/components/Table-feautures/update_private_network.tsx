import React, { useEffect, useState } from "react";
import { forwardRef, useImperativeHandle } from "react";
import { Modal, Button, Spin, DatePicker, Checkbox, Input, Tooltip } from "antd";
import Select from "react-select";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { DropdownStyles } from "@/app/components/css/dropdown";
import dayjs from "dayjs";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { PerformanceLogStore } from "@/app/stores/performance_matrix_store";
import { useInventoryAllChangeTypesStore } from "@/app/stores/inventorytAllChangeTypesStore";
import { getCurrentDateTime } from "../header_constants";
import { EyeIcon, InfoIcon } from "lucide-react";
import PrivateNetworkPreviewModal from "@/app/sim_management/bulk_change/new_change/private_network_preview";
import { useCustomerProfileStore } from "@/app/billing/killbill_stores/customer_profile_store";

interface UpdatePrivateNetworkModalProps {
  visible: boolean;
  onCancel: () => void;
  onUpdate: (updatedRow: any, event_type: string) => void;
  rowData?: any;
  is2OChange?: Boolean;
  isSingle?: Boolean;
  isAllChangeTypesFlow?: Boolean;
}

export interface UpdatePrivateNetworkModalContentRef {
  runValidation: () => Promise<void> | void;
  runSubmit: () => Promise<void> | void;
  hasValidData: () => boolean;
}

const UpdatePrivateNetworkModal = forwardRef<
  UpdatePrivateNetworkModalContentRef,
  UpdatePrivateNetworkModalProps
>(
  (
    {
      visible,
      onCancel,
      onUpdate,
      rowData,
      isSingle,
      isAllChangeTypesFlow = false,
    },
    ref
  ) => {
    const [formData, setFormData] = useState<any>(rowData);
    const [loading, setLoading] = useState(false);
    const {
      username,
      role,
      partner,
      token,
      selectedDb,
      metaData,
      firstLastName,
      sessionId,
      modulesVersionMap,
    } = useAuth();
    const { getTargetTenantProvider, IsTargetTenantProvider } =
      PerformanceLogStore();
    const service_provider = rowData?.service_provider_display_name;
    // const { is2OFilterLoaded } = useFeatureStore();
        const { setIs2OFilterLoaded,is2OFilterLoaded } = useCustomerProfileStore();
    
    //  console.log(rowData,"rowdata")
    const providerName =
      getTargetTenantProvider(service_provider)?.toLowerCase() ||
      service_provider;
    const isTelegence = providerName.toLowerCase().includes("telegence");
    const isVerizon =
      providerName.toLowerCase().includes("verizon") ||
      providerName.toLowerCase().includes("vzn")|| 
      providerName.toLowerCase().includes("vzwcr") || 
      providerName.toLowerCase().includes("2215-so01");
    const isTeal = providerName.toLowerCase().includes("teal");
    const is_parent_provider_exists = IsTargetTenantProvider(service_provider);
    //States
    const {
      activeChange,
      isAllChangeType,
      setIsValidated,
      setValidationTrigger,
      setsuccessFullChangeTypes,
      successFullChangeTypes,
    } = useInventoryAllChangeTypesStore();
    const [errors, setErrors] = useState<{ [key: string]: string }>({});

    const [saveChanges, setSaveChanges] = useState<boolean>(true);

    const [billingAccountNumber, setBillingAccountNumber] = useState<
      string | undefined
    >(undefined);
    const [BANOptions, setBANOptions] = useState<any>([]);
    const [BANError, setBANError] = useState<string>("");

    const [carrierRatePlan, setCarrierRatePlan] = useState<string | null>(null);
    const [carrierRatePlanError, setCarrierRatePlanError] = useState<
      string | null
    >(null);
    const [ratePlanOptions, setRatePlanOptions] = useState<any>([]);

    const [commPlan, setCCommPlan] = useState<string | null>(null);
    const [commPlanError, setCommPlanError] = useState<string | null>(null);
    const [commPlanOptions, setCommPlanOptions] = useState<any>([]);

    const [pdpOptions, setPdpOptions] = useState<any>([]);
    const [selectedPDP, setSelectedPDP] = useState<string | null>(null);
    const [pdpError, setPdpError] = useState<string | null>(null);

    const [IPOptions, setIPOptions] = useState<any>([]);
    const [IpAddress, setIpAddress] = useState<string | null>(null);
    const [IpError, setIpError] = useState<string | null>(null);
    const [IPAddressMap, setIPAddressMap] = useState<any>({});
    const [IPRange, setIPRange] = useState<string | null>(null);

    const [subscriberNumber, setSubscriberNumber] = useState<string>("");
    const [iccids, setIccids] = useState<string>("");
    const [errorMessage, setErrorMessage] = useState("");

    const [apnOptions, setApnOptions] = useState<any>([]);
    const [apn, setApn] = useState<string | null>(null);
    const [apnError, setApnError] = useState<string | null>(null);

    const [apnPdpMap, setApnPdpMap] = useState<any>({});
    const [pdpIpMap, setPdpIpMap] = useState<any>({});

    const [openPreviewModal, setPreviewModal] = useState<boolean>(false);

    const handlePreviewOpen = async () => {
      setPreviewModal(true)
    };
    useEffect(() => {
      if (IPOptions && IPOptions.length > 0) {
        const ip_ranges = IPOptions.join(",")
        console.log("ip_ranges", ip_ranges)
        setIPRange(ip_ranges)
      }
    }, [IPOptions])

    useEffect(() => {
      if (visible) {
        if (!isAllChangeType) {
          setBillingAccountNumber(undefined);
        }

        // setCommPlanOptions(comm_plan_dropdown)

        const fetchOptionsData = async () => {
          try {
            setLoading(true);
            await fetchOptionsMappings();
            await fetchBANs();
            // await fetchPDPOptions()
          } catch (err) {
            console.log("error fetching dropdown data", err);
          } finally {
            setLoading(false);
          }
        };
        fetchOptionsData();
      }

    }, [visible]);
    // Detect IPv6 (rough)
    const looksLikeIPv6 = (s: string) => s.includes(":");

    // IPv6: expand compressed forms into 8 hextets of 4 hex digits
    const expandIPv6 = (input: string): string[] | null => {
      const raw = input.trim();
      if (!raw) return null;
      // split on :: (0..1 times)
      if (raw.includes("::")) {
        const [left, right] = raw.split("::");
        const leftParts = left ? left.split(":").filter(Boolean) : [];
        const rightParts = right ? right.split(":").filter(Boolean) : [];
        if (
          leftParts.some((p) => p.length > 4) ||
          rightParts.some((p) => p.length > 4)
        )
          return null;
        const missing = 8 - (leftParts.length + rightParts.length);
        if (missing < 0) return null;
        const mid = new Array(missing).fill("0");
        const parts = [...leftParts, ...mid, ...rightParts].map(
          (p) => p || "0"
        );
        if (parts.length !== 8) return null;
        return parts.map((p) => p.padStart(4, "0").toUpperCase());
      } else {
        const parts = raw.split(":");
        if (parts.length !== 8) return null;
        if (parts.some((p) => p.length === 0 || p.length > 4)) return null;
        return parts.map((p) => p.padStart(4, "0").toUpperCase());
      }
    };

    const parseSavedRange = (ipRange: string) => {
      if (!ipRange) return { ok: false as const };

      const parts = ipRange.split("-");
      if (parts.length !== 2) return { ok: false as const };

      const s = parts[0].trim();
      const e = parts[1].trim();

      // IPv4 branch
      if (!looksLikeIPv6(s) && !looksLikeIPv6(e)) {
        if (!isValidIPv4(s) || !isValidIPv4(e)) return { ok: false as const };
        const sN = ipv4ToUint32(s);
        const eN = ipv4ToUint32(e);
        const start = Math.min(sN, eN);
        const end = Math.max(sN, eN);
        return {
          ok: true as const,
          family: "ipv4" as const,
          startNum: start,
          endNum: end,
        };
      }

      // IPv6 branch
      const sExp = expandIPv6(s);
      const eExp = expandIPv6(e);
      if (!sExp || !eExp) return { ok: false as const };
      const sBig = ipv6PartsToBigInt(sExp);
      const eBig = ipv6PartsToBigInt(eExp);
      const startBig = sBig <= eBig ? sBig : eBig;
      const endBig = sBig <= eBig ? eBig : sBig;
      return { ok: true as const, family: "ipv6" as const, startBig, endBig };
    };

    const ipv6PartsToBigInt = (parts: string[]) => {
      // each part is 4 hex digits -> 16 bits
      let acc = BigInt(0);
      for (let i = 0; i < 8; i++) {
        const v = BigInt(parseInt(parts[i], 16) & 0xffff);
        acc = (acc << BigInt(16)) + v;
      }
      return acc;
    };

    // IPv4
    const ipv4Regex = /^(\d{1,3}\.){3}\d{1,3}$/;
    const isValidIPv4 = (ip: string) => {
      if (!ipv4Regex.test(ip)) return false;
      return ip.split(".").every((p) => {
        if (!/^\d+$/.test(p)) return false;
        const n = Number(p);
        return Number.isInteger(n) && n >= 0 && n <= 255;
      });
    };

    const ipv4ToUint32 = (ip: string) => {
      const [a, b, c, d] = ip.split(".").map(Number);
      return ((a << 24) >>> 0) + (b << 16) + (c << 8) + d;
    };
    // const handleUpdate = () => {

    //     const formData_ = { ...formData }
    //     // console.log("effectiveDate", effectiveDate)
    //     // console.log("currentDate", currentDate)
    //     console.log("formData_", formData_)
    //     onUpdate(formData_, 'Update feature');
    // };

    useEffect(() => {
      if (visible) {
        setIpError("");
        setPdpError("");
      }
    }, [visible]);

    //     const handleUpdate = () => {
    //           const errorsObj: { [key: string]: string } = {};

    //      // 1️⃣ If no data entered → allow navigation (skip validation)
    //     if (!hasValidData()) {
    //         setErrors({});
    //         setIpError("");
    //         setIsValidated(true);
    //         setValidationTrigger();
    //         return;
    //     }

    //     // ---------- VALIDATE PRIVATE IP ----------
    //     if (!IpAddress || IpAddress.trim() === "") {
    //         setIpError("Private Static IP Address is required.");
    //         return; //
    //     }

    //     const ipValidation = validateFieldIp(IpAddress, IPRange || "");
    //     if (!ipValidation.valid) {
    //         setIpError(ipValidation.error);
    //         return;
    //     }

    //     setIpError(""); // Clear error

    //     // ---------- PROCEED ONLY IF VALID ----------
    //     const updatedRow = {
    //         ...formData,
    //         ip_address: IpAddress.trim(),
    //         pdp_name: selectedPDP,
    //         apn: apn,
    //         billing_account_number: billingAccountNumber
    //     };
    //      setIsValidated(true);
    //     setValidationTrigger();

    //     onUpdate(updatedRow, "Private Static IP Update");
    // };

    const handleUpdate = () => {

      /* 🟢 CASE 1: User didn’t enter anything → DO NOT SHOW ERRORS */
      if (!hasValidData()) {
        setIpError("");
        setPdpError("");
        setApnError("");
        setBANError("");

        // ❗ Mark validated & remove from success list
        setsuccessFullChangeTypes(
          successFullChangeTypes.filter((c: any) => c !== activeChange)
        );

        setIsValidated(true);
        setValidationTrigger();
        return;
      }

      /* 🔴 CASE 2: User entered SOMETHING → VALIDATE */
      let errorFound = false;

      // Validate IP
      if (!IpAddress || IpAddress.trim() === "") {
        setIpError("Private Static IP Address is required.");
        errorFound = true;
      } else {
        const ipValidation = validateFieldIp(IpAddress, IPOptions || []);
        if (!ipValidation.valid) {
          setIpError(ipValidation.error);
          errorFound = true;
        } else {
          setIpError("");
        }
      }

      // Validate PDP / APN / BAN
      // if (!isVerizon) {
        if (!selectedPDP) {
          setPdpError("PDP is required.");
          errorFound = true;
        } else setPdpError("");

        if (!isTelegence) {
          if (!apn) {
            setApnError("APN is required.");
            errorFound = true;
          } else setApnError("");
        }

        if (isTelegence) {
          if (!billingAccountNumber) {
            setBANError("Billing Account Number is required.");
            errorFound = true;
          } else setBANError("");
        }
      // }

      /* 🚫 Block if any error */
      if (errorFound) return;

      /* 🟢 All valid → Build final payload */
      const changedData = {
        pdp: selectedPDP || "",
        apn: apn || "",
        ip_address: IpAddress?.trim() || "",
        ban: billingAccountNumber || "",
      };

      const updatedRow = { ...formData, ...changedData };

      setIsValidated(true);
      setValidationTrigger();

      /* 📌 CASE 3: All Change Types Save handling */
      if (isAllChangeType) {
        if (saveChanges && !successFullChangeTypes.includes(activeChange)) {
          setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
        }
        return;
      }

      /* 🚀 Normal Submit */
      onUpdate(updatedRow, "Change Private Static IP Address");
    };


    const handleSubmit = () => {
      console.log("handleSubmit called in update private network");

      let updatedData;
      const changedData = {
        pdp: selectedPDP || "",
        apn: apn || "",
        ip_address: IpAddress?.trim() || "",
        ban: billingAccountNumber || "",
      }
      if (Array.isArray(rowData)) {
        updatedData = rowData.map((row) => ({
          ...row,
          ...formData, // includes msisdn, billing_account_number, voicemail_field_name, etc.
          ...changedData
        }));
      } else {
        updatedData = {
          ...rowData,
          ...formData,
          ...changedData
        };
      }

      console.log("Submitting:", updatedData);
      onUpdate(updatedData, "Change Private Static IP Address");
    };

    // const hasValidData = () => {
    //   //  If user has not touched Private Static IP Address → No data
    //   if (!IpAddress || IpAddress.trim() === "") {
    //     return false;
    //   }

    //   //  Validate IP + Range
    //   const result = validateFieldIp(IpAddress, IPRange || "");

    //   // Return true ONLY when valid
    //   return result.valid === true;
    // };

  const hasValidData = (): boolean => {
  return !!(
    IpAddress?.trim() ||
    selectedPDP?.trim() ||
    apn?.trim() ||
    billingAccountNumber?.trim()
  );
};


    const handleAPNSelect = (selectedOption: any) => {
      setSelectedPDP(null);
      if (selectedOption) {
        const value = selectedOption?.value;
        setApn(value);
        const pdp_options = apnPdpMap[value] || [];
        setPdpOptions(pdp_options);
      } else {
        setApn(null);
        setPdpOptions([]);
      }
    };

    const validateFieldIp = (
      value: string,
      ipRange: string | string[]
    ): { valid: boolean; error: string } => {
      const v = String(value ?? "").trim();
      if (!v) return { valid: false, error: "Enter a valid IP address" };

      // Normalize list of allowed IPs
      const ips = (Array.isArray(ipRange) ? ipRange : [ipRange])
        .map((r) => String(r ?? "").trim())
        .filter((r) => r.length > 0);

      if (ips.length === 0) {
        return {
          valid: false,
          error: "Enter IP address within the available IP list",
        };
      }

      const isV6 = looksLikeIPv6(v);

      // ================= IPv6 =================
      if (isV6) {
        const expanded = expandIPv6(v);
        if (!expanded) {
          return { valid: false, error: "Enter a valid IP address" };
        }

        const exists = ips.some((ip) => {
          const ex = expandIPv6(ip);
          return ex && ex.join(":") === expanded.join(":");
        });

        if (!exists) {
          return {
            valid: false,
            error: "Enter IP address within the available IP list",
          };
        }

        return { valid: true, error: "" };
      }

      // ================= IPv4 =================
      if (!isValidIPv4(v)) {
        return { valid: false, error: "Enter a valid IP address" };
      }

      const allowedSet = new Set(ips);

      if (!allowedSet.has(v)) {
        return {
          valid: false,
          error: "Enter IP address within the available IP list",
        };
      }

      return { valid: true, error: "" };
    };


    const fetchIPAddress = async (pdpName: any) => {
      try {
        setLoading(true);
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/get_ipdetails_by_pdpname",
          role_name: role,
          Partner: partner,
          request_received_at: getCurrentDateTime(),
          access_token: token,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          pdp_name: pdpName || "",
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Submit Error",
            content:
              parsedData.message ||
              "An error occurred while submitting data. Please try again.",
            centered: true,
          });
        } else {
          const ip_options_map = parsedData?.ip_addresses || [];
          setIPAddressMap(ip_options_map);
          const ip_options = ip_options_map.map(
            (opt: any) => opt?.ipAddress || ""
          );
          setIPOptions(ip_options);
        }
      } catch (error) {
        Modal.error({
          title: "Submit Error",
          content:
            error instanceof Error
              ? error.message
              : "An unexpected error occurred while fetching BANs. Please try again.",
          centered: true,
        });
      } finally {
        setLoading(false);
      }
    };

    const handleSelectBAN = (selectedOption: any | null) => {
      if (selectedOption) {
        const value = selectedOption?.value;
        setBillingAccountNumber(value);
      } else {
        setBillingAccountNumber(undefined); // Clear the selection
      }
    };

    const handleIPAddressSelect = (selectedOption: any) => {
      if (selectedOption) {
        const value = selectedOption?.value;
        setIpAddress(value);
      } else {
        setIpAddress(null);
      }
    };

    const handleSelectRatePlan = (selectedOption: any) => {
      if (selectedOption) {
        const value = selectedOption?.value;
        setCarrierRatePlan(value);
      } else {
        setCarrierRatePlan(null);
      }
    };

    const handleCommunicationPlan = (selectedOption: any) => {
      if (selectedOption) {
        const value = selectedOption?.value;
        setCCommPlan(value);
      } else {
        setCCommPlan(null);
      }
    };

    const handlePDPNameSelect = (selectedOption: any) => {
      setIpAddress(null);
      if (selectedOption) {
        const value = selectedOption?.value;
        setSelectedPDP(value);
        fetchOptionsMappings(value)
        // fetchIPAddress(value);
      } else {
        setSelectedPDP(null);
      }
    };

    const fetchBANs = async () => {
      try {
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/get_user_billing_account_number",
          role_name: role,
          Partner: partner,
          request_received_at: getCurrentDateTime(),
          access_token: token,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Submit Error",
            content:
              parsedData.message ||
              "An error occurred while submitting data. Please try again.",
            centered: true,
          });
        } else {
          const ban_options = parsedData?.data || [];
          setBANOptions(ban_options);
        }
      } catch (error) {
        Modal.error({
          title: "Submit Error",
          content:
            error instanceof Error
              ? error.message
              : "An unexpected error occurred while fetching BANs. Please try again.",
          centered: true,
        });
      } finally {
      }
    };

    const fetchOptionsMappings = async (selected_pdp?:string) => {
      try {
        const url = ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          path: "/get_private_network_pdp_apn_ip_mappings",
          request_received_at: getCurrentDateTime(),
          username: username,
          firstLastName: firstLastName,
          role_name: role,
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          service_provider: service_provider,
          selected_pdp:selected_pdp || "",
          info_flag:false,
          ...{
            parent_provider_name: is_parent_provider_exists
              ? getTargetTenantProvider(service_provider)
              : "",
          },
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const apn_pdp_map = parsedData?.apn_pdp_map || {};
          setApnPdpMap(apn_pdp_map);
          const pdp_ip_map = parsedData?.pdp_ip_map || {};
          setPdpIpMap(pdp_ip_map);

          const apn_options = Object.keys(apn_pdp_map) || [];
          setApnOptions(apn_options);

          const pdp_options = parsedData?.pdp || [];
          setPdpOptions(pdp_options);

          // const ip_options = parsedData?.ip_addresses || [];
          // setIPOptions(ip_options)

          const ip_options = parsedData?.pdp_ip_map[selected_pdp ||  ""] || {};
          setIPOptions(ip_options)
        }
      } catch (error) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            error instanceof Error
              ? error.message
              : "An unexpected error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    };

    // The main content that will be reused
    const renderContent = () => {
      if (loading || is2OFilterLoaded) {
        return (
          <div className="popup flex justify-center items-center w-full h-full">
            <Spin size="large" />
          </div>
        );
      }

      return (
        <>
          {isAllChangeType && (
            <div className="flex justify-end px-4">
              <span className="mr-2 font-semibold">Save Changes</span>
              <Checkbox
                checked={saveChanges}
                onChange={(e) => {
                  if (!e.target.checked) {
                    setsuccessFullChangeTypes(
                      successFullChangeTypes.filter(
                        (c: any) => c !== activeChange
                      )
                    );
                  }
                  setSaveChanges(e.target.checked);
                }}
                className="custom-checkbox"
              ></Checkbox>
            </div>
          )}




          {/* </div> */}
          {/* <div className="flex grid grid-cols-2 gap-6 mt-4"> */}
          {/* <div className="flex flex-col space-y-4"> */}
          {!isTeal && (
            <div
              className={"grid grid-cols-2 gap-6 mt-4"}
            >
              <>
                {!isVerizon && (
                  <>
                    {isTelegence && (
                      <>
                        {/* Billing Account Number */}
                        <div
                          className={`${!isAllChangeType ? "flex flex-col space-y-2" : ""
                            }`}
                        >
                          <label
                            htmlFor="billingAccountNumber"
                            className="field-label"
                          >
                            Billing Account Number
                            <span className="text-red-500">*</span>
                          </label>
                          {BANOptions.length === 0 ? (
                            <Input
                              id="billingAccountNumber"
                              // placeholder="Enter Billing Account Number"
                              value={billingAccountNumber}
                              onChange={(e) =>
                                setBillingAccountNumber(e.target.value)
                              }
                              className="input"
                            />
                          ) : (
                            <Select
                              id="billingAccountNumber"
                              placeholder="Select Carrier Rate Plan"
                              options={
                                BANOptions.length > 0
                                  ? BANOptions.map((option: string) => ({
                                    label: option,
                                    value: option,
                                  }))
                                  : [
                                    {
                                      value: "No options",
                                      label: "No options",
                                    },
                                  ]
                              }
                              value={{
                                label: billingAccountNumber,
                                value: billingAccountNumber,
                              }}
                              onChange={handleSelectBAN}
                              isClearable
                              className="w-full"
                              styles={DropdownStyles}
                            />
                          )}
                          {BANError && isAllChangeType && (
                            <span className="text-red-500">{BANError}</span>
                          )}
                        </div>
                        {BANError && !isAllChangeType && (
                          <span className="text-red-500">{BANError}</span>
                        )}
                      </>
                    )}
                    {!isTelegence && (
                      <>
                        {/* APN */}
                        <div
                          className={`${!isAllChangeType ? "flex flex-col space-y-2" : ""
                            }`}
                        >
                          <label htmlFor="pdpName" className="field-label">
                            APN
                            <span className='text-red-500'>*</span>
                          </label>
                          <Select
                            id="pdpName"
                            placeholder="Select PDP Name"
                            options={apnOptions.map((option: string) => ({
                              label: option,
                              value: option,
                            }))}
                            value={{ label: apn, value: apn }}
                            onChange={handleAPNSelect}
                            styles={DropdownStyles}
                            className="w-full"
                            isClearable
                          />
                          {apnError && isAllChangeType && (
                            <span className="text-red-500">{apnError}</span>
                          )}
                        </div>
                        {apnError && !isAllChangeType && (
                          <span className="text-red-500">{apnError}</span>
                        )}
                      </>
                    )}
                    {/* PDP Name */}
                    <div
                      className={`${!isAllChangeType ? "flex flex-col space-y-2" : ""
                        }`}
                    >
                      <label htmlFor="pdpName" className="field-label">
                        {`${isTelegence ? "PDP Name" : "PDP ID"}`}
                        <span className='text-red-500'>*</span>
                      </label>
                      <Select
                        id="pdpName"
                        placeholder={`Select ${isTelegence ? "PDP Name" : "PDP ID"
                          }`}
                        options={pdpOptions.map((option: string) => ({
                          label: option,
                          value: option,
                        }))}
                        value={{ label: selectedPDP, value: selectedPDP }}
                        onChange={handlePDPNameSelect}
                        styles={DropdownStyles}
                        className="w-full"
                        isClearable
                      />
                      {pdpError && isAllChangeType && (
                        <span className="text-red-500">{pdpError}</span>
                      )}
                      {(!selectedPDP && (
                      <span className="text-blue-500">* Please select a PDP to view available IP addresses.</span>
                    ))}
                    </div>
                    {pdpError && !isAllChangeType && (
                      <span className="text-red-500">{pdpError}</span>
                    )}
                    

                    
                  </>
                )}
                {/* IP Address */}
                <div
                  className={`${!isAllChangeType ? "flex flex-col space-y-2" : ""
                    }`}
                >
                  <div className="flex items-center justify-between">
                    <label htmlFor="ipAddress" className="field-label">
                      Private Static IP Address
                      <span className="text-red-500">*</span>
                    </label>
                    {selectedPDP && (<Tooltip title="view IP details">
                      <InfoIcon
                        className="h-5 w-5 text-gray-500 cursor-pointer"
                        onClick={handlePreviewOpen}
                      />
                    </Tooltip>)}
                  </div>

                  {/* <Select
                                            id="ipAddress"
                                            placeholder="Select PDP Name"
                                            options={IPOptions.map((option: string) => ({
                                                label: option,
                                                value: option,
                                            }))}
                                            value={{ label: IpAddress, value: IpAddress }}
                                            onChange={handleIPAddressSelect}
                                            styles={DropdownStyles}
                                            className="w-full"
                                            isClearable
                                        /> */}
                  <Input
                    id="ipAddress"
                    placeholder="Enter IP Address"
                    value={IpAddress || ""}
                    onChange={(e) => {
                      const v = e.target.value;
                      setIpAddress(v);

                      const res = validateFieldIp(v, IPOptions || []);
                      setIpError(res.error);
                    }}
                    onBlur={(e) => {
                      const res = validateFieldIp(
                        e.target.value,
                        IPOptions || []
                      );
                      setIpError(res.error || "");
                    }}
                    className="input"
                  />
                  {/* <div className="text-sm text-blue-500 mt-1">
                    Enter IP address within the given ip range:{" "}
                    <span className="font-mono">{IPRange}</span>
                  </div> */}
                  {IpError && isAllChangeType && (
                    <span className="text-red-500">{IpError}</span>
                  )}
                </div>
                {IpError && !isAllChangeType && (
                  <span className="text-red-500">{IpError}</span>
                )}
              </>
            </div>
          )}
           <PrivateNetworkPreviewModal
          service_provider={service_provider}
          change_type={"Change Private Static IP Address"}
          openPreviewModal={openPreviewModal}
          setPreviewModal={setPreviewModal}
          selectedPDP={selectedPDP || ""}
        />
          {/* </div> */}
          {/* </div> */}
        </>
      );
    };

    useImperativeHandle(ref, () => ({
      runValidation: handleUpdate,
      runSubmit: handleSubmit,
      hasValidData: hasValidData,
    }));

    // Conditional rendering: Modal OR div based on isAllChangeTypesFlow
    if (isAllChangeTypesFlow) {
      // Render just the content (div) for All Change Types flow
      return <div className="p-4">{renderContent()}</div>;
    }
    return (
      <Modal
        title="Private Network Change"
        visible={visible}
        centered
        onCancel={onCancel}
        footer={[
          <div className="flex justify-center space-x-2" key="buttons">
            <button onClick={onCancel} className="cancel-btn">
              Cancel
            </button>
            <button onClick={handleUpdate} className="save-btn">
              Update
            </button>
          </div>,
        ]}
        width={500}
      >
        {(loading || is2OFilterLoaded) ? (
          <div className="popup flex justify-center items-center w-full h-full">
            <Spin size="large" />
          </div>
        ) : (
          <div className="flex flex-col space-y-4">
            {!isTeal && (
              <div
                className={`${!isAllChangeType
                  ? "flex flex-col space-y-4 my-4"
                  : "flex flex-col space-y-4 my-4"
                  }`}
              >
                <>
                  {(
                    <>
                      {isTelegence && (
                        <>
                          {/* Billing Account Number */}
                          <div
                            className={`${!isAllChangeType ? "flex flex-col space-y-2" : ""
                              }`}
                          >
                            <label
                              htmlFor="billingAccountNumber"
                              className="field-label"
                            >
                              Billing Account Number
                              <span className="text-red-500">*</span>
                            </label>
                            {BANOptions.length === 0 ? (
                              <Input
                                id="billingAccountNumber"
                                // placeholder="Enter Billing Account Number"
                                value={billingAccountNumber}
                                onChange={(e) =>
                                  setBillingAccountNumber(e.target.value)
                                }
                                className="input"
                              />
                            ) : (
                              <Select
                                id="billingAccountNumber"
                                placeholder="Select Carrier Rate Plan"
                                options={
                                  BANOptions.length > 0
                                    ? BANOptions.map((option: string) => ({
                                      label: option,
                                      value: option,
                                    }))
                                    : [
                                      {
                                        value: "No options",
                                        label: "No options",
                                      },
                                    ]
                                }
                                value={{
                                  label: billingAccountNumber,
                                  value: billingAccountNumber,
                                }}
                                onChange={handleSelectBAN}
                                isClearable
                                className="w-full"
                                styles={DropdownStyles}
                              />
                            )}
                            {BANError && isAllChangeType && (
                              <span className="text-red-500">{BANError}</span>
                            )}
                          </div>
                          {BANError && !isAllChangeType && (
                            <span className="text-red-500">{BANError}</span>
                          )}
                        </>
                      )}
                      {!isTelegence && (
                        <>
                          {/* APN */}
                          <div
                            className={`${!isAllChangeType ? "flex flex-col space-y-2" : ""
                              }`}
                          >
                            <label htmlFor="pdpName" className="field-label">
                              APN
                              <span className='text-red-500'>*</span>
                            </label>
                            <Select
                              id="pdpName"
                              placeholder="Select PDP Name"
                              options={apnOptions.map((option: string) => ({
                                label: option,
                                value: option,
                              }))}
                              value={{ label: apn, value: apn }}
                              onChange={handleAPNSelect}
                              styles={DropdownStyles}
                              className="w-full"
                              isClearable
                            />
                            {apnError && isAllChangeType && (
                              <span className="text-red-500">{apnError}</span>
                            )}
                          </div>
                          {apnError && !isAllChangeType && (
                            <span className="text-red-500">{apnError}</span>
                          )}
                        </>
                      )}
                      {/* PDP Name */}
                      <div
                        className={`${!isAllChangeType ? "flex flex-col space-y-2" : ""
                          }`}
                      >
                        <label htmlFor="pdpName" className="field-label">
                          {`${isTelegence ? "PDP Name" : "PDP ID"}`}
                          <span className='text-red-500'>*</span>
                        </label>
                        <Select
                          id="pdpName"
                          placeholder={`Select ${isTelegence ? "PDP Name" : "PDP ID"
                            }`}
                          options={pdpOptions.map((option: string) => ({
                            label: option,
                            value: option,
                          }))}
                          value={{ label: selectedPDP, value: selectedPDP }}
                          onChange={handlePDPNameSelect}
                          styles={DropdownStyles}
                          className="w-full"
                          isClearable
                        />
                        {pdpError && isAllChangeType && (
                          <span className="text-red-500">{pdpError}</span>
                        )}
                      </div>
                      {pdpError && !isAllChangeType && (
                        <span className="text-red-500">{pdpError}</span>
                      )}
                      {(!selectedPDP && !isAllChangeType && (
                        <span className="text-blue-500">* Please select a PDP to view available IP addresses.</span>
                      ))}
                      
                    </>
                  )}
                  {/* IP Address */}
                  <div
                    className={`${!isAllChangeType ? "flex flex-col space-y-2" : ""
                      }`}
                  >
                    <div className="flex items-center justify-between">
                    <label htmlFor="ipAddress" className="field-label">
                      Private Static IP Address
                      <span className="text-red-500">*</span>
                    </label>
                   {selectedPDP && ( <Tooltip title="view IP details">
                      <InfoIcon
                        className="h-5 w-5 text-gray-500 cursor-pointer"
                        onClick={handlePreviewOpen}
                      />
                    </Tooltip>)}
                  </div>
                    <Input
                      id="ipAddress"
                      placeholder="Enter IP Address"
                      value={IpAddress || ""}
                      onChange={(e) => {
                        const v = e.target.value;
                        setIpAddress(v);

                        const res = validateFieldIp(v, IPOptions || []);
                        setIpError(res.error);
                      }}
                      onBlur={(e) => {
                        const res = validateFieldIp(e.target.value, IPOptions || []);
                        setIpError(res.error);
                      }}
                      className="input"
                    />
                    {/* <div className="text-sm text-blue-500 mt-1">
                      <span className="block"> Enter IP address within the given ip range: </span>
                      {IPOptions.map((opt: any) => {
                        return <span className="font-mono font-semibold block">{opt || ""}</span>

                      })}
                    </div> */}
                    {IpError && isAllChangeType && (
                      <span className="text-red-500">{IpError}</span>
                    )}
                  </div>
                  {IpError && !isAllChangeType && (
                    <span className="text-red-500">{IpError}</span>
                  )}
                </>
              </div>
            )}
          </div>
        )}
        <PrivateNetworkPreviewModal
          service_provider={service_provider}
          change_type={"Change Private Static IP Address"}
          openPreviewModal={openPreviewModal}
          setPreviewModal={setPreviewModal}
          selectedPDP ={selectedPDP || ""}
        />
      </Modal>
    );
  }
);

export default UpdatePrivateNetworkModal;
