import React, { forwardRef,useImperativeHandle,useState, useEffect } from "react";
import { Modal,Row, Col, Spin, Checkbox } from "antd";
import { useAuth } from "@/app/components/auth_context";
import { ENV_ROUTES } from "../routes/route_constants";
import axios from "axios";
import { getCurrentDateTime } from "../header_constants";
import Select from "react-select";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { useInventoryAllChangeTypesStore } from "@/app/stores/inventorytAllChangeTypesStore";
import { useCustomerProfileStore } from "@/app/billing/killbill_stores/customer_profile_store";

interface SendSMSModalProps {
  visible: boolean;
  onCancel: () => void;
  onUpdate: (updatedRow: any, event_type: string) => void;
  rowData?: any;
  is2OChange?: Boolean;
  isSingle ?:Boolean;
  isAllChangeTypesFlow?: Boolean;
}
export interface SendSMSContentRef {
  runValidation: () => Promise<void> | void;
  runSubmit: () => Promise<void> | void;
  hasValidData: () => boolean; // NEW: Method to check if data is valid
}
 const SendSMS = forwardRef<SendSMSContentRef, SendSMSModalProps>(({
  visible,
  onCancel,
  onUpdate,
  rowData,is2OChange ,isSingle,
   isAllChangeTypesFlow = false 
},ref) => {
  // const [formData, setFormData] = useState<any>((!is2OChange || isSingle) ? rowData : {});
  const [formData, setFormData] = useState<any>(rowData ? rowData : {});
  const { username, token, partner, selectedDb, role, firstLastName, sessionId } = useAuth();
  const [loading, setLoading] = useState(false);
  const [costCenterOptions, setCostCenterOptions] = useState<any>([]);
  // const { is2OFilterLoaded  } = useFeatureStore();

    const { setIs2OFilterLoaded,is2OFilterLoaded } = useCustomerProfileStore();
  const versionBasedPath = is2OChange ? ENV_ROUTES.INVENTORY : ENV_ROUTES.SIM_MANAGEMENT
  const { activeChange , isAllChangeType,setIsValidated,setValidationTrigger, setsuccessFullChangeTypes, successFullChangeTypes } = useInventoryAllChangeTypesStore();
  const [saveChanges, setSaveChanges] = useState<boolean>(true);
  const [errors, setErrors] = useState<any>([]);
 
  // NEW: Add method to check if component has valid data
   // NEW: Add method to check if component has valid data
  const hasValidData = () => {
    return formData.text_message && formData.text_message.trim() !== "";
  };

const handleUpdate = () => {
  const errors: { [key: string]: string } = {};

  if (!formData.text_message && !isAllChangeType) {
    errors.text_message = "Please Enter Message Text";
  }
  setErrors(errors);

  // ✅ Update FULL DATA for single or multiple rows
  let updatedData;
  if (Array.isArray(rowData)) {
    updatedData = rowData.map((row) => ({
      ...row,
      text_message: formData.text_message
    }));
  } else {
    updatedData = { ...rowData, text_message: formData.text_message };
  }

  if (isAllChangeType) {
    if (!formData.text_message || formData.text_message.trim() === "") {
      setsuccessFullChangeTypes(
        successFullChangeTypes.filter((c: any) => c !== activeChange)
      );
      setIsValidated(true);
      setValidationTrigger();
      return;
    }

    if (saveChanges && formData.text_message !== "") {
      setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
    }

    setIsValidated(true);
    setValidationTrigger();

    // ✅ Pass updated row(s) to parent
    onUpdate(updatedData, "Send SMS");
    return;
  }

  // ✅ Normal edit flow
  if (Object.keys(errors).length === 0) {
    onUpdate(updatedData, "Send SMS");
  }
};
const handleSubmit = () => {
  console.log("handleSubmit called in Send SMS");

  let updatedData;
  if (Array.isArray(rowData)) {
    updatedData = rowData.map((row) => ({
      ...row,
      text_message: formData.text_message
    }));
  } else {
    updatedData = { ...rowData, text_message: formData.text_message };
  }

  console.log("Submitting:", updatedData);
  onUpdate(updatedData, "Send SMS");
};

const handleCancel = () => {
    setFormData((!is2OChange || isSingle) ? rowData : {});
    onCancel();
  };
 
  useEffect(() => {
    if (visible) {
        setFormData((!is2OChange || isSingle) ? rowData : {});
      }
  }, [rowData, visible]);

  // The main content that will be reused
    const renderContent = () => {
      if (loading || is2OFilterLoaded) {
        return (
          <div className="popup flex justify-center items-center w-full h-full">
            <Spin size="large" />
          </div>
        );
      }
  
      return (
        <>
          {isAllChangeType && (
            <div className="flex justify-end px-4">
              <span className="mr-2 font-semibold">Save Changes</span>
              <Checkbox
                checked={saveChanges}
                onChange={(e) => {
                  if (!e.target.checked) {
                    setsuccessFullChangeTypes(
                      successFullChangeTypes.filter((c: any) => c !== activeChange)
                    );
                  }
                  setSaveChanges(e.target.checked)
                }}
                className="custom-checkbox"
              >

              </Checkbox>
            </div>
          )}
           <Row>
        <Col span={16}>
          <label className="text-lg" htmlFor="text_message" style={{ fontFamily: "Calibri, sans-serif" }}>
            Message Text<span className="text-red-500">*</span>
          </label>
        </Col>
        <Col span={24}>
          
            <textarea
            className="textarea message-description"
            id="text_message"
            value={formData.text_message}
            onChange={(e) => {
                if (e.target.value.length <= 320) {
                    console.log("text_message",e.target.value)
                setFormData({ ...formData, text_message: e.target.value });
                }
            }}
            placeholder="Enter your message (max 320 characters)"
            maxLength={500}
            rows={4}
            />
                  {errors.text_message && (
                    <div>
                      <span className="text-red-500 mt-2">{errors.text_message}</span>
                    </div>
                  )}
        </Col>
      </Row>

          </>
      );
    };

    useImperativeHandle(ref, () => ({
       runValidation: handleUpdate,
       runSubmit:handleSubmit,
       hasValidData: hasValidData // NEW: Add this method
     }));
  
    // Conditional rendering: Modal OR div based on isAllChangeTypesFlow
    if (isAllChangeTypesFlow) {
      // Render just the content (div) for All Change Types flow
      return (
        <div className="p-4">
          {renderContent()}
        </div>
      );
    }
  return (
    <Modal
      title={
        <div className="mt-[-10px]">
          <span className="text-[19px]">Send SMS</span>
        </div>
      }
      visible={visible}
      centered
      onCancel={handleCancel}
      footer={[
        <div className="flex justify-center space-x-2 mt-12" key="buttons">
          <button
            key="cancel"
            onClick={onCancel}
            className="cancel-btn h-[30px] text-base"
            style={{ fontFamily: "Calibri, sans-serif" }}
          >
            Cancel
          </button>
          <button
            key="update"
            onClick={handleUpdate}
            className="save-btn  text-base border-none"
            style={{ fontFamily: "Calibri, sans-serif" }}
          >
            Update
          </button>
        </div>,
      ]}
      width={400}
      style={{ height: "500px" }}
    >
      <>
      {(loading || is2OFilterLoaded) ? (
          <div className="popup flex justify-center items-center w-full h-full mt-4">
            <Spin size="large" />
          </div>
        ) : (
          <>  
        <Row>
        <Col span={16}>
          <label className="text-lg" htmlFor="text_message" style={{ fontFamily: "Calibri, sans-serif" }}>
            Message Text<span className="text-red-500">*</span>
          </label>
        </Col>
        <Col span={24}>
          
            <textarea
            className="textarea message-description"
            id="text_message"
            value={formData.text_message}
            onChange={(e) => {
                if (e.target.value.length <= 320) {
                    console.log("text_message",e.target.value)
                setFormData({ ...formData, text_message: e.target.value });
                }
            }}
            placeholder="Enter your message (max 320 characters)"
            maxLength={500}
            rows={4}
            />
                  {errors.text_message && (
                    <div>
                      <span className="text-red-500 mt-2">{errors.text_message}</span>
                    </div>
                  )}
        </Col>
      </Row>

          </>
        )
      }
      </>
     
    </Modal>
  );
}
 );

export default SendSMS;
