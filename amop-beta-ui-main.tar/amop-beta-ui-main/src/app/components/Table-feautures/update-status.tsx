import React, { useState, useEffect, forwardRef, useImperativeHandle } from "react";
import { Modal, Divider, Select, Button, Input, Spin, Checkbox, DatePicker } from "antd";
import { ChevronDownIcon } from "@heroicons/react/24/outline";
import { useAuth } from "@/app/components/auth_context";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import axios from "axios";
import { text } from "stream/consumers";
import { CloseOutlined } from "@ant-design/icons";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
const { Option } = Select;
import dayjs from "dayjs";
import { PerformanceLogStore } from "@/app/stores/performance_matrix_store";
import { useInventoryAllChangeTypesStore } from '@/app/stores/inventorytAllChangeTypesStore';
import { useCustomerProfileStore } from "@/app/billing/killbill_stores/customer_profile_store";

interface UpdateStatusModalProps {
  visible: boolean;
  onCancel: () => void;
  onUpdate: (updatedRow: any, event_type: string) => void;
  rowData?: any;
  is2OChange?: Boolean;
  isSingle?:Boolean;
  isAllChangeTypesFlow?: Boolean;
}

export interface UpdateStatusContentRef {
  runValidation: () => Promise<void> | void;
  runSubmit: () => Promise<void> | void;
  hasValidData: () => boolean; // Add this method
}
// type FormData = Record<string, string | undefined>;
 const UpdateStatusModal = forwardRef<UpdateStatusContentRef, UpdateStatusModalProps>(
      ({  visible,
  onCancel,
  onUpdate,
  rowData,is2OChange,isSingle,isAllChangeTypesFlow}, ref) => {
  const [currentStatus, setCurrentStatus] = useState("");
  const [selectedStatus, setSelectedStatus] = useState("");
  const [formData, setFormData] = useState<any>(rowData || {});
  const { username, partner, role, settabledata, token, selectedDb, metaData, firstLastName, sessionId } = useAuth();
  const [loading, setLoading] = useState<boolean>(false);
  const [parsedData, setParsedData] = useState<any>(null);
  const [newStatusOptions, setNewStatusOptions] = useState<string[]>([]);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [imei, setImei] = useState("");
  const zipCodeRegex = /^\d{5}(-\d{4})?$/;

  const [selectedProfile, setSelectedProfile] = useState("");
  // const [selectedReasonCodeID, setSelectedReasonCodeID] = useState<string | null>(null);
  const [profileOptions, setProfileOptions] = useState<string[]>([]);
  const [stateOptions, setStateOptions] = useState<string[]>([]);
  const [ratePlanOptions, setRatePlanOptions] = useState<any[]>([]);
  const [ratePlanCodeOptions, setRatePlanCodOptions] = useState<any[]>([]);
  const [publicIPOptions, setPublicIPOPtions] = useState<string[]>(["Restricted", "Unrestricted"]);
  const [reasonCodeOptions, setReasonCodeOptions] = useState<any[]>([]);
  const [statusMap, setStatusMap] = useState<any>({});
  const [statusCodeMap, setStatusCodeMap] = useState<any>({});
  const [selectedStatusCode, setSelectedStatusCode] = useState<string | null>(null);
  const [accountNumber, setAccountNumber] = useState<string | null>('');
  const [accountNumberOptions, setAccountNumberOptions] = useState<any>([]);
  const [effectiveDateCheckbox, setEffectiveDateCheckbox] = useState<boolean>(false);
  const [effectiveDate, setEffectiveDate] = useState<Date | null>(null);
  const isAdmin = role?.toLowerCase() === "super admin" || role?.toLowerCase() === "partner admin"
  // const { is2OFilterLoaded  } = useFeatureStore();
      const { setIs2OFilterLoaded,is2OFilterLoaded } = useCustomerProfileStore();
  
  const { getTargetTenantProvider, IsTargetTenantProvider } = PerformanceLogStore();
  const providerName = getTargetTenantProvider(rowData?.service_provider_display_name).toLowerCase() || "";
  const versionBasedPath = is2OChange ? ENV_ROUTES.INVENTORY : ENV_ROUTES.SIM_MANAGEMENT
  const { activeChange , isAllChangeType,setIsValidated,setValidationTrigger, setsuccessFullChangeTypes, successFullChangeTypes } = useInventoryAllChangeTypesStore();
  const [saveChanges, setSaveChanges] = useState<boolean>(true);
  useEffect(() => {
    if (visible) {
      setErrors({}); // Clear errors on modal open
      setSelectedStatus("");
      setSelectedProfile("");
      const currentUserName = rowData?.username || ""
      if (currentUserName && currentUserName !== 'None') {
        const nameParts = currentUserName.split(" ");
        setFormData((prevFormData: any) => ({ ...prevFormData, first_name: nameParts[0], last_name: nameParts.slice(1).join(" ") }));
      }
    }
  }, [visible]);

  const disablePastDates = (current: any) => {
    return current && current < dayjs().startOf('day');
  };

const validateFields = (): boolean => {
  const newErrors: Record<string, string> = {};

  if (isAllChangeType) {
    const provider = providerName?.toLowerCase() || "";

    // Check if any relevant field is filled
    const relevantInputs: boolean[] = [];

    // Add selectedStatus to relevant inputs
    if (selectedStatus) {
      relevantInputs.push(true);
    }

    if ((provider.includes("verizon") || provider.includes("vzn") || provider.toLowerCase().includes("vzwcr") || provider.toLowerCase().includes("2215-so01")) && selectedStatus === "Active") {
      relevantInputs.push(
        !!formData.account_number,
        !!formData.first_name,
        !!formData.last_name,
        !!formData.address,
        !!formData.city,
        !!formData.state,
        !!formData.country,
        !!formData.service_zip_code,
        !!formData.rate_plan_code,
        !!imei 
      );
    }

    if (
      provider.includes("kore") &&
      (selectedStatus?.toLowerCase() === "activate" || selectedStatus?.toLowerCase() === "active")
    ) {
      relevantInputs.push(!!selectedProfile);
    }

    if (provider.includes("at&t - telegence")) {
      relevantInputs.push(!!effectiveDateCheckbox || !!effectiveDate);
    }

    // If no relevant inputs have been entered, allow moving
    const hasAnyInput = relevantInputs.some((val) => val === true);

    if (!hasAnyInput) {
      // ✅ nothing filled for relevant provider-specific fields → allow skipping
      return true;
    }

    // If user started filling, run actual validation
    
    // Validate selectedStatus if any field is filled
    if (hasAnyInput && !selectedStatus) {
      newErrors.selectedStatus = "New Status is required";
    }

    if (selectedStatus && provider) {
      /** ----------------
       *  VERIZON VALIDATION
       * ----------------*/
      if ((provider.includes("verizon") || provider.includes("vzn")|| provider.toLowerCase().includes("vzwcr") || provider.toLowerCase().includes("2215-so01")) && selectedStatus === "Active") {
        if (!formData.account_number) newErrors.account_number = "Account Number is required.";
        if (!formData.first_name) newErrors.first_name = "First name is required";
        if (!formData.last_name) newErrors.last_name = "Last name is required";
        if (is2OChange && !formData.rate_plan_code)
          newErrors.rate_plan_code = "Rate Plan Code is required";
        if (!formData.address) newErrors.address = "Address line is required";
        if (!formData.city) newErrors.city = "City is required";
        if (!formData.state) newErrors.state = "State is required";
        if (!formData.country) newErrors.country = "Country is required";
        if (!formData.service_zip_code || !zipCodeRegex.test(formData.service_zip_code))
          newErrors.service_zip_code = "Valid ZIP code is required";
         if (!imei) {
          newErrors.imei = "IMEI is required";
        } else if (!/^\d{15}$/.test(imei)) {
          newErrors.imei = "IMEI must be exactly 15 digits";
        }
      }

      /** ----------------
       *  KORE VALIDATION
       * ----------------*/
      if (
        provider.includes("kore") &&
        (selectedStatus.toLowerCase() === "activate" || selectedStatus.toLowerCase() === "active")
      ) {
        if (!selectedProfile) newErrors.selectedProfile = "Activation Profile is required";
      }

      /** ----------------
       *  TELEGENCE VALIDATION
       * ----------------*/
      if (provider.includes("at&t - telegence")) {
        if (effectiveDateCheckbox && !effectiveDate) {
          newErrors.effectiveDate = "Effective Date is required";
        }
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }

  // ---------- Non-All Change Types (unchanged) ----------
  if (selectedStatus) {
    const provider = providerName.toLowerCase();

    if (selectedStatus === "Active" && (provider.includes("verizon") || provider.includes("vzn")|| provider.toLowerCase().includes("vzwcr") || provider.toLowerCase().includes("2215-so01"))) {
      if (!formData.account_number) newErrors.account_number = "Account Number is required.";
      if (!formData.first_name) newErrors.first_name = "First name is required";
      if (!formData.last_name) newErrors.last_name = "Last name is required";
      if (is2OChange && !formData.rate_plan_code)
        newErrors.rate_plan_code = "Rate Plan Code is required";
      if (!formData.address) newErrors.address = "Address line is required";
      if (!formData.city) newErrors.city = "City is required";
      if (!formData.state) newErrors.state = "State is required";
      if (!formData.country) newErrors.country = "Country is required";
      if (!formData.service_zip_code || !zipCodeRegex.test(formData.service_zip_code))
        newErrors.service_zip_code = "Valid ZIP code is required";
      // ADD IMEI VALIDATION HERE TOO
      if (!imei) {
        newErrors.imei = "IMEI is required";
      } else if (!/^\d{15}$/.test(imei)) {
        newErrors.imei = "IMEI must be exactly 15 digits";
      }
    }

    if (
      (selectedStatus.toLowerCase() === "activate" || selectedStatus.toLowerCase() === "active") &&
      provider.includes("kore")
    ) {
      if (!selectedProfile) newErrors.selectedProfile = "Activation Profile is required";
    }

    if (provider.includes("at&t - telegence")) {
      if (effectiveDateCheckbox && !effectiveDate)
        newErrors.effectiveDate = "Effective Date is required";
    }
  }

  setErrors(newErrors);
  return Object.keys(newErrors).length === 0;
};

  const handleChange = (value: string): void => {
    setSelectedProfile("")
    setSelectedStatus(value);
    const status_id = statusMap?.[value] || null
    setFormData((prevFormData: any) => ({ ...prevFormData, sim_status: value, device_status_id: status_id }));
    if (providerName.includes("telegence") || (value === "Deactivated" && (providerName.includes("verizon") || providerName.includes("vzn")|| providerName.toLowerCase().includes("vzwcr") || providerName.toLowerCase().includes("2215-so01")))) {
      fetchreasonCodes(value)
    }
    const selectedItem = statusCodeMap.find((item: any) => item.display_name === value);
    // setSelectedStatusId(selectedItem?.id || "22"); // `id`
    setSelectedStatusCode(selectedItem?.status || "A"); // `status`
  };

  const handleIccidChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const imei_ = e.target.value || ""
    setImei(imei_);
    setFormData((prevFormData: any) => ({ ...prevFormData, imei: imei_ }));
  };

  const handleImeiInputChange = (e: React.ChangeEvent<HTMLInputElement>) => { 
  const value = e.target.value || "";
  // Only allow numeric characters and limit to 15 digits
  const numericValue = value.replace(/\D/g, '').slice(0, 15);
  setImei(numericValue);
  setFormData((prevFormData: any) => ({ ...prevFormData, imei: numericValue }));
};

  const handleSelectActivationProfile = (selectedOption: any) => {
    if (selectedOption) {
      // const value = selectedOption?.value
      setSelectedProfile(selectedOption)
      setFormData((prevFormData: any) => ({ ...prevFormData, activation_profile: selectedOption }));
    }
    else {
      setSelectedProfile("")
    }
  };
// Add this method to check if any field has valid data
  const hasValidData = () => {
    const provider = providerName?.toLowerCase() || "";

    // Check if selectedStatus is filled
    if (selectedStatus) return true;

    // Check provider-specific fields
    if ((provider.includes("verizon") || provider.includes("vzn")|| provider.toLowerCase().includes("vzwcr") || provider.toLowerCase().includes("2215-so01")) && selectedStatus === "Active") {
      return !!(
        formData.first_name ||
        formData.last_name ||
        formData.address ||
        formData.city ||
        formData.state ||
        formData.country ||
        formData.service_zip_code ||
        formData.rate_plan_code ||
        imei
      );
    }

    if (provider.includes("kore") && (selectedStatus?.toLowerCase() === "activate" || selectedStatus?.toLowerCase() === "active")) {
      return !!selectedProfile;
    }

    if (provider.includes("at&t - telegence")) {
      return !!(effectiveDateCheckbox || effectiveDate);
    }

    // For other scenarios, check basic form data changes
    return !!(
      formData.reason_code ||
      formData.activation_profile ||
      formData.public_ip_restriction ||
      effectiveDateCheckbox ||
      effectiveDate
    );
  };
const handleUpdate = (): void => {
  const isValid = validateFields();
  const provider = providerName?.toLowerCase() || "";

  if (isAllChangeType) {
    // Determine if user entered any relevant fields based on provider & status
    const relevantInputs: boolean[] = [];

    // Add selectedStatus to check
    if (selectedStatus) {
      relevantInputs.push(true);
    }

    if ((provider.includes("verizon") || provider.includes("vzn")|| provider.toLowerCase().includes("vzwcr") || provider.toLowerCase().includes("2215-so01")) && selectedStatus === "Active") {
      relevantInputs.push(
        !!formData.account_number,
        !!formData.first_name,
        !!formData.last_name,
        !!formData.address,
        !!formData.city,
        !!formData.state,
        !!formData.country,
        !!formData.service_zip_code,
        !!formData.rate_plan_code
      );
    }

    if (provider.includes("kore") &&
        (selectedStatus?.toLowerCase() === "activate" || selectedStatus?.toLowerCase() === "active")) {
      relevantInputs.push(!!selectedProfile);
    }

    if (provider.includes("telegence") || provider.includes("att")) {
      relevantInputs.push(!!effectiveDateCheckbox || !!effectiveDate);
    }

    const hasAnyRelevantInput = relevantInputs.some(val => val === true);

    if (!hasAnyRelevantInput) {
      // ✅ No input → remove from successFullChangeTypes
      setsuccessFullChangeTypes(
        successFullChangeTypes.filter((c: any) => c !== activeChange)
      );
      setIsValidated(true);
      setValidationTrigger();
      return;
    }

    // ✅ User entered relevant input → update successFullChangeTypes based on validation
    if (isValid) {
      // Passed validation → add if not already present
      if (!successFullChangeTypes.includes(activeChange)) {
        if (saveChanges) {
          setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
        }
      }
      setIsValidated(true);
    } else {
      // Failed validation → remove from success list
      setsuccessFullChangeTypes(
        successFullChangeTypes.filter((c: any) => c !== activeChange)
      );
      setIsValidated(false);
    }

    setValidationTrigger();
    return;
  }

  // ---------- Non-All Change Types (Original Logic) ----------
  const getCurrentDateTimeFormatted = (): string => {
  const now = new Date();

  const pad = (num: number) => num.toString().padStart(2, '0');

  const month = pad(now.getMonth() + 1); // 10 → October
  const day = pad(now.getDate());        // 02
  const year = now.getFullYear();        // 2025

  const hours = pad(now.getHours());
  const minutes = pad(now.getMinutes());
  const seconds = pad(now.getSeconds());

  return `${month}-${day}-${year} ${hours}:${minutes}:${seconds}`;
};
  if (isValid) {
    let formdata_ :any = {... formData}
    // if(formData?.effective_date){
        const effectiveDate = formData?.effective_date !== rowData?.effective_date ? formData?.effective_date : getCurrentDateTimeFormatted() || getCurrentDateTimeFormatted()
        const updatedFormData:any = {
        ...formData,
        effective_date: effectiveDate,
      };
        formdata_ = {... updatedFormData}
      // }
    if (isAdmin) {
      const ratePlan_ = formData?.rate_plan_code || null;
      if (ratePlan_) {
        const index = ratePlanOptions.indexOf(ratePlan_);
        if (index !== -1 && ratePlanCodeOptions[index]) {
          const newRatePlanCode = ratePlanCodeOptions[index];
          const updatedFormData = {
            ...formdata_,
            rate_plan_code: newRatePlanCode,
          };

          if (provider.includes("telegence")) {
            const updatedStatusesData = {
              ...updatedFormData,
              mode: selectedStatusCode,
            };
            onUpdate(updatedStatusesData, "Update Device Status");
          } else {
            onUpdate(updatedFormData, "Update Device Status");
          }
          return;
        }
      }
    }

    if (provider.includes("telegence")) {
      const updatedStatusesData = {
        ...formdata_,
        mode: selectedStatusCode,
      };
      onUpdate(updatedStatusesData, "Update Device Status");
    } else {
      onUpdate(formdata_, "Update Device Status");
    }
    setSelectedStatus("");
    setSelectedProfile("");
  }
};

  const handleSubmit = () => {
    if (isAdmin) {
      const ratePlan_ = formData?.rate_plan_code || null;
      if (ratePlan_) {
        const index = ratePlanOptions.indexOf(ratePlan_);
        if (index !== -1 && ratePlanCodeOptions[index]) {
          const newRatePlanCode = ratePlanCodeOptions[index];
          const updatedFormData = {
            ...formData,
            rate_plan_code: newRatePlanCode,
          };

          if (providerName.includes("telegence")) {
            const updatedStatusesData = {
              ...updatedFormData,
              mode: selectedStatusCode,
            };
            onUpdate(updatedStatusesData, "Update Device Status");
          } else {
            onUpdate(updatedFormData, "Update Device Status");
          }
          return;
        }
      }
    }

    if (providerName.includes("telegence")) {
      const updatedStatusesData = {
        ...formData,
        mode: selectedStatusCode,
      };
      onUpdate(updatedStatusesData, "Update Device Status");
    } else {
      onUpdate(formData, "Update Device Status");
    }
  };

  useImperativeHandle(ref, () => ({
    runValidation: handleUpdate,
    runSubmit: handleSubmit,
    hasValidData: hasValidData
  }));

  const handleCancel = (): void => {
    onCancel();
    setSelectedStatus("");
    setSelectedProfile("")
  };

  const getDefaultReasonCode = (targetStatus: any) => {
    const selected_status=targetStatus?.toLowerCase()
    switch (selected_status) {
      case "suspended":
        return {label:"Customer Request",value:"CR"};
      case "cancel subscriber":
        return {label:"Customer Cutting Back",value:"CB"};
      case "restore suspended":
        return {label:"Customer Request",value:"CR"};
      case "restore cancelled":
        return {label:"Customer Request",value:"CR"};
      default:
        return null;
    }
  };

  const fetchreasonCodes = async (new_status: any) => {
    setLoading(true);
    try {
      const url = versionBasedPath;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/reason_codes_inventory",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "SimManagement Inventory",
        feature_module_name: "Inventory",
        service_provider_id: rowData?.service_provider_id,
        service_provider: rowData?.service_provider_display_name,
        status: new_status,
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const fetchedData = JSON.parse(response.data.body);
      setParsedData(fetchedData);

      if (fetchedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content: fetchedData.message || "An error occurred while fetching Inventory data. Please try again.",
          centered: true,
          onOk: handleCancel,
        });
      } else {
        setLoading(false);
        const reasonCodeMap = fetchedData.reason_codes || []
        const filteredReasonCodes = reasonCodeMap.map((reason: any) => ({
          label: reason.description,
          value: reason.reason_code,
        }));
        setReasonCodeOptions(filteredReasonCodes);
        if(providerName.includes("telegence")){
          const reason_code = getDefaultReasonCode(new_status)
          setFormData((prevFormData: any) => ({ ...prevFormData, reason_code: reason_code?.value || "" }));
        }
        
      }
    } catch (error) {
      setLoading(false);
      console.error("Error fetching data:", error);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
        onOk: handleCancel,
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const url = versionBasedPath;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/statuses_inventory",
          role_name: role,
          parent_module: "Sim Management",
          module_name: "SimManagement Inventory",
          feature_module_name: "Inventory",
          service_provider_id: rowData?.service_provider_id,
          service_provider: rowData?.service_provider_display_name,
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
        };

        const response = await axios.post(url, { data });
        const fetchedData = JSON.parse(response.data.body);
        setParsedData(fetchedData);

        if (fetchedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content: fetchedData.message || "An error occurred while fetching Inventory data. Please try again.",
            centered: true,
            onOk: handleCancel,
          });
        } else {
          setLoading(false);
          const statusMap_ = fetchedData?.update_status_values || {}
          setStatusMap(statusMap_)
          const status_options = Object.keys(statusMap_) || []
          const sortedOptions = (status_options || [])
            .filter((status: any) => status.toLowerCase() !== currentStatus.toLowerCase())
            .sort();

          const filteredOptions = (providerName.includes("verizon") || providerName.includes("vzn")|| providerName.toLowerCase().includes("vzwcr") || providerName.toLowerCase().includes("2215-so01"))
            ? sortedOptions.filter(
              (option: any) => !option.toLowerCase().includes("pending activation")
            )
            : sortedOptions;
          setNewStatusOptions(filteredOptions);
          const active_profile_dropdown = fetchedData?.activation_profiles || []
          setProfileOptions(active_profile_dropdown)
          const states = fetchedData?.state || []
          setStateOptions(states)
          const rate_plan_codes = fetchedData?.carrier_rate_plan || []
          setRatePlanOptions(rate_plan_codes)

          const ratePlanCodeOptions = fetchedData?.rate_plan_code_list || []
          setRatePlanCodOptions(ratePlanCodeOptions);
          const Device_Status_dropdown = fetchedData?.Device_Status_dropdown || []
          setStatusCodeMap(Device_Status_dropdown || [])
          const account_options = fetchedData?.account_numbers || []
          setAccountNumberOptions(account_options)
        }
      } catch (error) {
        setLoading(false);
        console.error("Error fetching data:", error);
        Modal.error({
          title: "Data Fetch Error",
          content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
          centered: true,
          onOk: handleCancel,
        });
      } finally {
        setLoading(false);
      }
    };

    if (visible) {
      fetchData();
    }
  }, [visible]);

  useEffect(() => {
    const status_ = rowData?.sim_status || "Deactivated";
    setCurrentStatus(status_);
    const imei_ = rowData?.imei || "";
    setImei(imei_);
  }, [rowData]);

  // The main content that will be reused
  const renderContent = () => {
    if (loading || is2OFilterLoaded) {
      return (
        <div className="popup flex justify-center items-center w-full h-full">
          <Spin size="large" />
        </div>
      );
    }

    return (
      <>
        {isAllChangeType && (
          <div className="flex justify-end px-4">
            <span className="mr-2 font-semibold">Save Changes</span>
            <Checkbox
              checked={saveChanges}
              onChange={(e) => {
                if (!e.target.checked) {
                  setsuccessFullChangeTypes(
                    successFullChangeTypes.filter((c: any) => c !== activeChange)
                  );
                }
                setSaveChanges(e.target.checked)
              }}
              className="custom-checkbox"
            />
          </div>
        )}
        <div className={is2OChange?"grid grid-cols-2 gap-x-6 gap-y-4 items-start":"flex flex-col space-y-4"} id={(selectedStatus === "Active" &&(providerName.includes("verizon") || providerName.includes("vzn")|| providerName.toLowerCase().includes("vzwcr") || providerName.toLowerCase().includes("2215-so01")) ) ? "updateStatusPopup" : "updatedStatus"}>
          {/* <div>
            <label className="field-label mb-[6px]" htmlFor="current-status">
              Current Status
            </label>
            <Input
              className="non-editable-input w-full h-10"
              id="current-status"
              value={currentStatus}
              readOnly
            />
          </div> */}

          <div className="relative">
            <label className="field-label mb-[6px]" htmlFor="new-status">
              New Status{isAllChangeType && <span className="text-red-500">*</span>}
            </label>
            <Select
              id="new-status"
              value={selectedStatus}
              style={{ width: "100%"}}
              onChange={handleChange}
              showSearch
              allowClear
              clearIcon={<CloseOutlined className="clear" />}
              suffixIcon={<ChevronDownIcon className="w-5 h-5 text-gray-600 arrow" />}
              notFoundContent="No options"
            >
              {newStatusOptions.map((status) => (
                <Option key={status} value={status}>{status}</Option>
              ))}
            </Select>
            {errors.selectedStatus && (
              <p className="text-red-500 text-sm mt-[10px] absolute left-0" style={{
                position: "relative",
                top: "2px",
                fontSize: "13px",
                lineHeight: "16px",
              }}>
                {errors.selectedStatus}
              </p>
            )}
          </div>
             
          {(providerName).toUpperCase().includes("AT&T - TELEGENCE") && (
            <>
              <div>
                <label className="field-label mb-[6px]" htmlFor="current-status">
                  Reason Code
                </label>
                <Select
                  id="reasonCode"
                  showSearch
                  allowClear
                  style={{ width: "100%", marginBottom: '16px' }}
                  onChange={(value) => {
                    setFormData({ ...formData, reason_code: value })
                  }}
                  value={formData?.reason_code || ""}
                  suffixIcon={<ChevronDownIcon className="w-5 h-5 text-gray-600 arrow" />}
                >
                  {reasonCodeOptions.map((code) => (
                    <Option key={code.value} value={code.value}>{code.label}</Option>
                  ))}
                </Select>
              </div>

              {!(selectedStatus && selectedStatus.toLowerCase()==="restore cancelled") && (
                <div>
                  <div>
                    <label htmlFor="effectiveDateCheckbox" className="w-1/3 field-label">
                      Effective Date
                    </label>
                  </div>
                  <Checkbox
                    id="effectiveDateCheckbox"
                    checked={effectiveDateCheckbox}
                    onChange={(e) => setEffectiveDateCheckbox(e.target.checked)}
                  />
                </div>
              )}

              {effectiveDateCheckbox && (
                <>
                  <div>
                    <div>
                      <label htmlFor="effectiveDate" className="w-1/3  field-label">
                        Effective Date <span className="text-red-500">*</span>
                      </label>
                      <DatePicker
                        value={effectiveDate}
                        onChange={(date) => {
                          setEffectiveDate(date)
                          setFormData({ ...formData, effective_date: date })
                        }}
                        className="input"
                        format="DD/MM/YYYY"
                        placeholder="DD/MM/YYYY"
                        disabledDate={disablePastDates}
                      />
                    </div>
                    {errors.effectiveDate && (
                      <div className="text-red-500 text-sm">
                        {errors.effectiveDate}
                      </div>
                    )}
                  </div>
                </>
              )}
            </>
          )}

          {((rowData?.service_provider_display_name).toLowerCase() === "kore" && (selectedStatus?.toLowerCase() === "activate" || selectedStatus?.toLowerCase() === "active")) && (
            <>
              <div className="relative">
                <div>
                  <label className="text-lg font-calibri mb-4 status" htmlFor="new-status">
                    Activation Profile<span className="text-red-500">*</span>
                  </label>
                </div>
                <Select
                  id="new-status"
                  value={selectedProfile}
                  style={{ width: "100%", marginBottom: '3px' }}
                  onChange={handleSelectActivationProfile}
                  showSearch
                  allowClear
                  clearIcon={<CloseOutlined className="clear" />}
                  suffixIcon={<ChevronDownIcon className="w-5 h-5 text-gray-600 arrow" />}
                  notFoundContent="No options"
                >
                  {profileOptions.map((profile) => (
                    <Option key={profile} value={profile}>{profile}</Option>
                  ))}
                </Select>
                {errors.selectedProfile && (
                  <p className="text-red-500 text-sm mt-[10px] absolute left-0" style={{
                    position: "relative",
                    top: "2px",
                    fontSize: "13px",
                    lineHeight: "16px",
                  }}>
                    {errors.selectedProfile}
                  </p>
                )}
              </div>
              
              <div>
                <div>
                  <label className="text-lg font-calibri mb-4 status" htmlFor="imei">
                    IMEI
                  </label>
                </div>
                <textarea
                  id="imei"
                  value={imei}
                  onChange={handleIccidChange}
                  className="w-full border rounded-md p-2 non-editable-input"
                  rows={3}
                  placeholder="Enter IMEI"
                  disabled
                />
              </div>
            </>
          )}

          {selectedStatus === "Active" && ((providerName).toUpperCase().includes("VERIZON") || (providerName).toUpperCase().includes("VZN")|| providerName.toLowerCase().includes("vzwcr") || providerName.toLowerCase().includes("2215-so01")) && (
            <>
              {/* REMOVE the inner <div className="space-y-4"> wrapper and place fields directly in the grid */}
              
              <div>
                <label className="field-label mb-[6px]" htmlFor="first-name">
                  First Name<span className="text-red-500">*</span>
                </label>
                <Input
                  id="first-name"
                  className="input"
                  value={formData.first_name || ""}
                  required
                  onChange={(e) => setFormData({ ...formData, first_name: e.target.value })}
                />
                {errors.first_name && <span className="text-red-500 text-sm">{errors.first_name}</span>}
              </div>

              <div>
                <label className="field-label mb-[6px]" htmlFor="last-name">
                  Last Name<span className="text-red-500">*</span>
                </label>
                <Input
                  id="last-name"
                  className="input"
                  value={formData.last_name || ""}
                  required
                  onChange={(e) => setFormData({ ...formData, last_name: e.target.value })}
                />
                {errors.last_name && <span className="text-red-500 text-sm">{errors.last_name}</span>}
              </div>

              <div>
                <label className="field-label mb-[6px]" htmlFor="imei-verizon">
                  IMEI<span className="text-red-500">*</span>
                </label>
                <Input
                  id="imei-verizon"
                  className="input"
                  value={imei || ""}
                  required
                  maxLength={15}
                  onChange={handleImeiInputChange}
                  placeholder="Enter 15-digit IMEI"
                />
                {errors.imei && <span className="text-red-500 text-sm">{errors.imei}</span>}
              </div>

              <div>
                <label className="field-label mb-[6px]" htmlFor="ratePlan">
                  {isAdmin ? "Rate Plan Code" : "Customer Rate Plan"}{is2OChange && <span className="text-red-500">*</span>}
                </label>
                <Select
                  id="ratePlan"
                  showSearch
                  allowClear
                  style={{ width: "100%", marginBottom: '16px' }}
                  onChange={(value) => setFormData({ ...formData, rate_plan_code: value })}
                  suffixIcon={<ChevronDownIcon className="w-5 h-5 text-gray-600 arrow" />}
                >
                  {ratePlanOptions.map((plan) => {
                    const label = isAdmin ? plan : plan.rate_plan;
                    const value = isAdmin ? plan : plan.code;
                    return (
                      <Option key={label} value={value}>
                        {label}
                      </Option>
                    );
                  })}
                </Select>
                {errors.rate_plan_code && <span className="text-red-500 text-sm">{errors.rate_plan_code}</span>}
              </div>
              {/* Account Number */}

              {is2OChange && (
                <div>
                  <label className="field-label mb-[6px]" htmlFor="accountNumber">
                    Account Number{errors.state}<span className="text-red-500">*</span>
                  </label>
                  <Select
                    id="accountNumber"
                    showSearch
                    allowClear
                    style={{ width: "100%", marginBottom: '16px' }}
                    onChange={(value) => {
                      setAccountNumber(value)
                      setFormData({ ...formData, account_number: value })
                    }}
                    suffixIcon={<ChevronDownIcon className="w-5 h-5 text-gray-600 arrow" />}
                  >
                    {accountNumberOptions.map((number: any) => {
                      const label = number;
                      const value = number;
                      return (
                        <Option key={label} value={value}>
                          {label}
                        </Option>
                      );
                    })}
                  </Select>
                  {errors.account_number && <span className="text-red-500 text-sm">{errors.acccount_number}</span>}
                </div>
              )}
              <div>
                <label className="field-label mb-[6px]" htmlFor="publicIP">
                  Public IP Restriction
                </label>
                <Select
                  id="publicIP"
                  showSearch
                  allowClear
                  style={{ width: "100%" }}
                  onChange={(value) => setFormData({ ...formData, public_ip_restriction: value })}
                  suffixIcon={<ChevronDownIcon className="w-5 h-5 text-gray-600 arrow" />}
                >
                  {publicIPOptions.map((ip) => (
                    <Option key={ip} value={ip}>{ip}</Option>
                  ))}
                </Select>
              </div>

              <div>
                <label className="field-label mb-[6px]" htmlFor="address-line">
                  Address Line<span className="text-red-500">*</span>
                </label>
                <Input
                  id="address-line"
                  className="input"
                  value={formData.address || ""}
                  required
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                />
                {errors.address && <span className="text-red-500 text-sm">{errors.address}</span>}
              </div>

              <div>
                <label className="field-label mb-[6px]" htmlFor="city">
                  City<span className="text-red-500">*</span>
                </label>
                <Input
                  id="city"
                  className="input"
                  value={formData.city || ""}
                  required
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                />
                {errors.city && <span className="text-red-500 text-sm">{errors.city}</span>}
              </div>

              <div>
                <label className="field-label mb-[6px]" htmlFor="state">
                  State<span className="text-red-500">*</span>
                </label>
                <Select
                  id="state"
                  style={{ width: "100%", marginBottom: '16px' }}
                  onChange={(value) => setFormData({ ...formData, state: value })}
                  suffixIcon={<ChevronDownIcon className="w-5 h-5 text-gray-600 arrow" />}
                >
                  {stateOptions.map((state: any) => (
                    <Option key={state.code} value={state.code}>
                      {state.name}
                    </Option>
                  ))}
                </Select>
                {errors.state && <span className="text-red-500 text-sm">{errors.state}</span>}
              </div>

              <div>
                <label className="field-label mb-[6px]" htmlFor="country">
                  Country<span className="text-red-500">*</span>
                </label>
                <Input
                  id="country"
                  className="input"
                  value={formData.country || ""}
                  required
                  onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                />
                {errors.country && <span className="text-red-500 text-sm">{errors.country}</span>}
              </div>

              <div>
                <label className="field-label mb-[6px]" htmlFor="zip-code">
                  MDN zip Code<span className="text-red-500">*</span>
                </label>
                <Input
                  id="zip-code"
                  className="input"
                  value={formData.service_zip_code || ""}
                  required
                  onChange={(e) => setFormData({ ...formData, service_zip_code: e.target.value })}
                />
                {errors.service_zip_code && <span className="text-red-500 text-sm">{errors.service_zip_code}</span>}
              </div>
            </>
          )}

          {((selectedStatus === "Deactivated" || selectedStatus === "Suspended" || selectedStatus === "Inventory") && ((providerName).toUpperCase().includes("VERIZON") || (providerName).toUpperCase().includes("VZN")|| providerName.toLowerCase().includes("vzwcr") || providerName.toLowerCase().includes("2215-so01"))) && (
            <>
              <div>
                <div>
                  <label className="text-lg font-calibri " htmlFor="current-status">
                    Reason Code
                  </label>
                </div>

                <Select
                  id="reasonCode"
                  showSearch
                  allowClear
                  style={{ width: "100%", marginBottom: '16px' }}
                  onChange={(value) => {
                    setFormData({ ...formData, reason_code: value })
                  }}
                  suffixIcon={<ChevronDownIcon className="w-5 h-5 text-gray-600 arrow" />}
                >
                  {reasonCodeOptions.map((code) => (
                    <Option key={code.value} value={code.value}>{code.label}</Option>
                  ))}
                </Select>
              </div>
            </>
          )}
        </div>
      </>
    );
  };

  // Conditional rendering: Modal OR div based on isAllChangeTypesFlow
  if (isAllChangeTypesFlow) {
    return (
      <div className="p-4">
        {renderContent()}
      </div>
    );
  }

  return (
    <Modal
      title={
        <div className="mt-[-10px]">
          <span className="text-[21px] updateStatus">{"Update Device Status"}</span>
        </div>
      }
      className={(selectedStatus === "Active" && (providerName.includes("verizon") || providerName.includes("vzn")|| providerName.toLowerCase().includes("vzwcr") || providerName.toLowerCase().includes("2215-so01")) ) ? "updateStatusHeight" : "updatedHeight"}
      visible={visible}
      centered
      onCancel={handleCancel}
      footer={[
        <div className="flex justify-center space-x-4 mt-6" key="buttons">
          <button
            key="cancel"
            onClick={onCancel}
            className="cancel-btn h-[30px] text-base"
            style={{ fontFamily: "Calibri, sans-serif" }}
          >
            Cancel
          </button>
          <button
            key="update"
            onClick={handleUpdate}
            className="save-btn  text-base border-none"
            style={{ fontFamily: "Calibri, sans-serif" }}
          >
            Update
          </button>
        </div>,
      ]}
      width={600}
      style={{ height: "500px" }}
    >
      <>
        {(loading || is2OFilterLoaded) ? (
          <div className="popup flex justify-center items-center w-full h-full">
            <Spin size="large" />
          </div>
        ) : (
          <div className="flex flex-col space-y-4 mt-6" id={(selectedStatus === "Active" &&(providerName.includes("verizon") || providerName.includes("vzn")|| providerName.toLowerCase().includes("vzwcr") || providerName.toLowerCase().includes("2215-so01")) ) ? "updateStatusPopup" : "updatedStatus"}>
            <div className="flex w-full">
              <div className="w-2/5">
                <label className="text-lg font-calibri status" htmlFor="current-status">
                  Current Status
                </label>
              </div>

              <Input
                className="non-editable-input"
                id="current-status"
                value={currentStatus}
                readOnly
              />
            </div>

            <div className="flex w-full">
              <div className="w-2/5">
                <label className="text-lg font-calibri mb-4 status" htmlFor="new-status">
                  New Status
                </label>
              </div>
              <Select
                id="new-status"
                value={selectedStatus}
                style={{ width: "100%", marginBottom: '3px' }}
                onChange={handleChange}
                showSearch
                allowClear
                clearIcon={<CloseOutlined className="clear" />}
                suffixIcon={<ChevronDownIcon className="w-5 h-5 text-gray-600 arrow" />}
                notFoundContent="No options"
              >
                {newStatusOptions.map((status) => (
                  <Option key={status} value={status}>{status}</Option>
                ))}
              </Select>
            </div>

            {providerName.includes("telegence") && (
              <>
                <div className="flex w-full">
                  <div className="w-2/5">
                    <label className="text-lg font-calibri " htmlFor="current-status">
                      Reason Code
                    </label>
                  </div>
                  <Select
                    id="reasonCode"
                    showSearch
                    allowClear
                    style={{ width: "100%", marginBottom: '16px' }}
                    onChange={(value) => {
                      setFormData({ ...formData, reason_code: value })
                    }}
                    value={formData?.reason_code || ""}
                    suffixIcon={<ChevronDownIcon className="w-5 h-5 text-gray-600 arrow" />}
                  >
                    {reasonCodeOptions.map((code) => (
                      <Option key={code.value} value={code.value}>{code.label}</Option>
                    ))}
                  </Select>
                </div>
                {!(selectedStatus && selectedStatus.toLowerCase()==="restore cancelled") && (
                  <div className="flex w-full">
                    <div className="w-2/5">
                      <label htmlFor="effectiveDateCheckbox" className="w-1/3 font-semibold">
                        Effective Date
                      </label>
                    </div>

                    <Checkbox
                      id="effectiveDateCheckbox"
                      checked={effectiveDateCheckbox}
                      onChange={(e) => setEffectiveDateCheckbox(e.target.checked)}
                    />
                  </div>
                )}

                {effectiveDateCheckbox && (
                  <>
                    <div className="flex w-full">
                      <div className="w-2/5">
                        <label htmlFor="effectiveDate" className="w-1/3 font-semibold ">
                          Effective Date <span className="text-red-500">*</span>
                        </label>
                      </div>

                      <DatePicker
                        value={effectiveDate}
                        onChange={(date) => {
                          setEffectiveDate(date)
                          setFormData({ ...formData, effective_date: date })
                        }}
                        className="input"
                        format="DD/MM/YYYY"
                        placeholder="DD/MM/YYYY"
                        disabledDate={disablePastDates}
                      />
                    </div>
                    {errors.effectiveDate && (
                      <div className="text-red-500 text-sm">
                        {errors.effectiveDate}
                      </div>
                    )}
                  </>
                )}
              </>
            )}

            {(providerName === "kore" && (selectedStatus?.toLowerCase() === "activate" || selectedStatus?.toLowerCase() === "active")) && (
              <>
                <div className="flex w-full">
                  <div className="w-2/5">
                    <label className="text-lg font-calibri mb-4 status" htmlFor="new-status">
                      Activation Profile<span className="text-red-500">*</span>
                    </label>
                  </div>
                  <Select
                    id="new-status"
                    value={selectedProfile}
                    style={{ width: "100%", marginBottom: '3px' }}
                    onChange={handleSelectActivationProfile}
                    showSearch
                    allowClear
                    clearIcon={<CloseOutlined className="clear" />}
                    suffixIcon={<ChevronDownIcon className="w-5 h-5 text-gray-600 arrow" />}
                    notFoundContent="No options"
                  >
                    {profileOptions.map((profile) => (
                      <Option key={profile} value={profile}>{profile}</Option>
                    ))}
                  </Select>
                </div>
                <div className="errorMessage">
                  {errors.selectedProfile && <span className="text-red-500">{errors.selectedProfile}</span>}
                </div>
                <div className="flex w-full mt-4">
                  <div className="w-2/5">
                    <label className="text-lg font-calibri mb-4 status" htmlFor="imei">
                      IMEI
                    </label>
                  </div>
                  <textarea
                    id="imei"
                    value={imei}
                    onChange={handleIccidChange}
                    className="w-full border rounded-md p-2 non-editable-input"
                    rows={3}
                    placeholder="Enter IMEI"
                    disabled
                  />
                </div>
              </>
            )}

            {selectedStatus === "Active" && (providerName.includes("verizon") || providerName.includes("vzn")|| providerName.toLowerCase().includes("vzwcr") || providerName.toLowerCase().includes("2215-so01")) && (
              <>
                <div className="space-y-4 ">
                  <div className="flex  w-full mt-2">
                    <div className="w-2/5">
                      <label className="text-lg font-calibri status" htmlFor="first-name">First Name<span className="text-red-500">*</span></label>
                    </div>
                    <Input
                      id="first-name"
                      className="input"
                      value={formData.first_name || ""}
                      required
                      onChange={(e) => setFormData({ ...formData, first_name: e.target.value })}
                    />
                  </div>
                  <div className="errorMessage">
                    {errors.first_name && <span className="text-red-500">{errors.first_name}</span>}
                  </div>

                  <div className="flex  w-full">
                    <div className="w-2/5">
                      <label className="text-lg font-calibri status" htmlFor="last-name">Last Name<span className="text-red-500">*</span></label>
                    </div>
                    <Input
                      id="last-name"
                      className="input"
                      value={formData.last_name || ""}
                      required
                      onChange={(e) => setFormData({ ...formData, last_name: e.target.value })}
                    />
                  </div>
                  <div className="errorMessage">
                    {errors.last_name && <span className="text-red-500">{errors.last_name}</span>}
                  </div>
                  <div className="flex w-full">
                    <div className="w-2/5">
                      <label className="text-lg font-calibri status" htmlFor="imei-verizon-modal">
                        IMEI<span className="text-red-500">*</span>
                      </label>
                    </div>
                    <Input
                      id="imei-verizon-modal"
                      className="input"
                      value={imei || ""}
                      required
                      maxLength={15}
                      onChange={handleImeiInputChange}
                      placeholder="Enter 15-digit IMEI"
                    />
                  </div>
                  <div className="errorMessage">
                    {errors.imei && <span className="text-red-500">{errors.imei}</span>}
                  </div>
                  <div className="flex  w-[100%] mb-4">
                    <div className="min-w-[28%]">
                      <label className="text-lg font-calibri status" htmlFor="ratePlan">{isAdmin ? "Rate Plan Code" : "Customer Rate Plan"}{is2OChange && <span className="text-red-500">*</span>} </label>
                    </div>
                    <Select
                      id="ratePlan"
                      showSearch
                      allowClear
                      className="min-w-[72%]"
                      style={{ marginBottom: '16px' }}
                      onChange={(value) => setFormData({ ...formData, rate_plan_code: value })}
                      suffixIcon={<ChevronDownIcon className="w-5 h-5 text-gray-600 arrow" />}
                    >
                      {ratePlanOptions.map((plan) => {
                        const label = isAdmin ? plan : plan.rate_plan;
                        const value = isAdmin ? plan : plan.code;

                        return (
                          <Option key={label} value={value}>
                            {label}
                          </Option>
                        );
                      })}
                    </Select>
                  </div>
                    <div className="errorMessage">
                      {(errors.rate_plan_code && is2OChange) && <span className="text-red-500">{errors.rate_plan_code}</span>}
                    </div>

                  {is2OChange && (
                    <div className="flex  w-full mb-4">
                    <div className="w-2/5">
                      <label className="text-lg font-calibri status" htmlFor="accountNumber">Account Number<span className="text-red-500">*</span></label>
                    </div>
                    <Select
                      id="accountNumber"
                      showSearch
                      allowClear
                      style={{ width: "100%", marginBottom: '16px' }}
                      onChange={(value) => {
                      setAccountNumber(value)
                      setFormData({ ...formData, account_number: value })
                    }}
                      suffixIcon={<ChevronDownIcon className="w-5 h-5 text-gray-600 arrow" />}
                    >
                      {accountNumberOptions.map((number:any) => {
                        const label = number;
                        const value = number;

                        return (
                          <Option key={label} value={value}>
                            {label}
                          </Option>
                        );
                      })}
                    </Select>
                  </div>
                  )}
                  <div className="errorMessage">
                    {errors.account_number && <span className="text-red-500">{errors.account_number}</span>}
                  </div>
                  <div className="flex  w-full mb-4">
                    <div className="w-2/5">
                      <label className="text-lg font-calibri status" htmlFor="publicIP">Public IP Restriction</label>
                    </div>
                    <Select
                      id="publicIP"
                      showSearch
                      allowClear
                      style={{ width: "100%", marginBottom: '16px' }}
                      onChange={(value) => setFormData({ ...formData, public_ip_restriction: value })}
                      suffixIcon={<ChevronDownIcon className="w-5 h-5 text-gray-600 arrow" />}
                    >
                      {publicIPOptions.map((ip) => (
                        <Option key={ip} value={ip}>{ip}</Option>
                      ))}
                    </Select>
                  </div>

                  <div className="flex  w-full">
                    <div className="w-2/5">
                      <label className="text-lg font-calibri status" htmlFor="address-line">Address Line<span className="text-red-500">*</span></label>
                    </div>
                    <Input
                      id="address-line"
                      className="input"
                      value={formData.address || ""}
                      required
                      onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                    />
                  </div>
                  <div className="errorMessage">
                    {errors.address && <span className="text-red-500">{errors.address}</span>}
                  </div>

                  <div className="flex  w-full">
                    <div className="w-2/5">
                      <label className="text-lg font-calibri status" htmlFor="city">City<span className="text-red-500">*</span></label>
                    </div>
                    <Input
                      id="city"
                      className="input"
                      value={formData.city || ""}
                      required
                      onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    />
                  </div>
                  <div className="errorMessage">
                    {errors.city && <span className="text-red-500">{errors.city}</span>}
                  </div>

                  <div className="flex  w-full mb-4">
                    <div className="w-2/5">
                      <label className="text-lg font-calibri status" htmlFor="state">State<span className="text-red-500">*</span></label>
                    </div>
                    <Select
                      id="state"
                      style={{ width: "100%", marginBottom: '16px' }}
                      onChange={(value) => setFormData({ ...formData, state: value })}
                      suffixIcon={<ChevronDownIcon className="w-5 h-5 text-gray-600 arrow" />}
                    >
                      {stateOptions.map((state: any) => (
                        <Option key={state.code} value={state.code}>
                          {state.name}
                        </Option>
                      ))}
                    </Select>
                  </div>
                  <div className="errorMessage">
                    {errors.state && <span className="text-red-500">{errors.state}</span>}
                  </div>

                  <div className="flex w-full">
                    <div className="w-2/5">
                      <label className="text-lg font-calibri status" htmlFor="country">Country<span className="text-red-500">*</span></label>
                    </div>
                    <Input
                      id="country"
                      className="input"
                      value={formData.country || ""}
                      required
                      onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                    />
                  </div>
                  <div className="errorMessage">
                    {errors.country && <span className="text-red-500">{errors.country}</span>}
                  </div>

                  <div className="flex  w-full">
                    <div className="w-2/5">
                      <label className="text-lg font-calibri status" htmlFor="zip-code">MDN zip Code<span className="text-red-500">*</span></label>
                    </div>
                    <Input
                      id="zip-code"
                      className="input"
                      value={formData.service_zip_code || ""}
                      required
                      onChange={(e) => setFormData({ ...formData, service_zip_code: e.target.value })}
                    />
                  </div>
                  <div className="errorMessage">
                    {errors.service_zip_code && <span className="text-red-500">{errors.service_zip_code}</span>}
                  </div>
                </div>
              </>
            )}

            {(selectedStatus === "Deactivated" && (providerName.includes("verizon") || providerName.includes("vzn")|| providerName.toLowerCase().includes("vzwcr") || providerName.toLowerCase().includes("2215-so01"))) && (
              <>
                <div className="flex w-full">
                  <div className="w-2/5">
                    <label className="text-lg font-calibri " htmlFor="current-status">
                      Reason Code
                    </label>
                  </div>

                  <Select
                    id="reasonCode"
                    showSearch
                    allowClear
                    style={{ width: "100%", marginBottom: '16px' }}
                    onChange={(value) => {
                      setFormData({ ...formData, reason_code: value })
                    }}
                    suffixIcon={<ChevronDownIcon className="w-5 h-5 text-gray-600 arrow" />}
                  >
                    {reasonCodeOptions.map((code) => (
                      <Option key={code.value} value={code.value}>{code.label}</Option>
                    ))}
                  </Select>
                </div>
              </>
            )}
          </div>
        )}
      </>
    </Modal>
  );
});

export default UpdateStatusModal;