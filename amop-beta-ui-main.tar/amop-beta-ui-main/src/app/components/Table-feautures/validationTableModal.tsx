"use client";
import React from 'react';
import { Modal, Table } from 'antd';
import { CheckCircleOutlined, CloseCircleOutlined } from '@ant-design/icons';

// Helper function to check if a row can process a specific change type
export const canProcessChangeType = (
  row: any,
  changeType: string,
  partner: string,
  getTargetTenantProvider: (provider: string) => string
): boolean => {
  const providerName = getTargetTenantProvider(row.service_provider_display_name.toUpperCase()) || "";
  const simStatus = (row?.sim_status || "").toUpperCase();
  const isActivated = simStatus === "ACTIVATED" || simStatus === "ACTIVE" || simStatus === "A" || simStatus === "ONLINE" || simStatus === "ACTIVATE";
  const isRestore = simStatus === "RESTORE SUSPENDED";
  const isActiveOrRestore = isActivated || isRestore;

  const allowedProviders = [
    "AT&T - POD19",
    "WEBBING",
    "MULTI-CARRIER SIM",
    "VERIZON - THINGSPACE IOT",
    "AT&T - CISCO JASPER",
    "AT&T - TELEGENCE",
    "ROGERS SANDBOX"
  ];

  const hasAllowedProvider = allowedProviders.some(provider =>
    providerName.includes(provider.toUpperCase())
  );

  switch (changeType) {
    case "Line Sync":
      return hasAllowedProvider;

    case "Update Device Status":
      return true;

    case "Edit Cost Center":
      if (providerName.includes("TELEGENCE") || providerName === "EBONDING" || providerName === "ROGERS") {
        return partner === "Titanium - AWX" || providerName.includes("TELEGENCE");
      }
      return true;

    case "Update Carrier Rate Plan":
      if (providerName.includes("TELEGENCE")) {
        return isActiveOrRestore;
      }
      if (providerName === "EBONDING" || providerName === "ROGERS") {
        return isActivated;
      }
      return !providerName.includes("KORE");

    case "Update Customer Rate Plan":
      if (providerName.includes("TELEGENCE")) {
        return isActiveOrRestore;
      }
      if (providerName === "EBONDING" || providerName === "ROGERS") {
        return isActivated;
      }
      return isActivated;

    case "Assign Customer":
      if (providerName.includes("TELEGENCE")) {
        return isActiveOrRestore;
      }
      if (providerName === "EBONDING") {
        return isActivated;
      }
      return true;

    case "Update Features":
      return providerName.includes("TELEGENCE") && isActiveOrRestore;

    case "Refresh A Line":
      return providerName.includes("TELEGENCE") && isActiveOrRestore;

    case "Update PPU Address":
      return providerName.includes("TELEGENCE");

    case "Change Phone Number":
      return providerName.includes("TELEGENCE") && isActiveOrRestore;

    // ---------- NEW: Send SMS ----------
    case "Send SMS": {
      // allowed providers for Send SMS (as per your list)
      const sendSmsAllowed = [
        "AT&T - POD19",
        "AT&T - CISCO JASPER",
        "ROGERS",
        "T - MOBILE"
      ].map(p => p.toUpperCase());

      // providerName from getTargetTenantProvider is uppercased already, so just check includes
      return sendSmsAllowed.some(p => providerName.includes(p));
    }

    
    case "Update Communication Plan": {
      // allowed providers for Send SMS (as per your list)
      const sendCommPlanAllowed = [
        "AT&T - POD19",
        "AT&T - CISCO JASPER",
        "ROGERS",
        "T - MOBILE"
      ].map(p => p.toUpperCase());

      // providerName from getTargetTenantProvider is uppercased already, so just check includes
      return sendCommPlanAllowed.some(p => providerName.includes(p));
    }

    // ---------- NEW: Reset Voicemail Password ----------
    case "Reset Voicemail Password":
      // Only Telegence providers
      return providerName.includes("TELEGENCE");
    case "Change Private Static IP Address": {
      const validProviders = [
       "CISCO JASPER", "POD19", "ROGERS", "T-MOBILE", "VERIZON", "TELEGENCE", "TEAL","VZN","VZWCR"].map(p => p.toUpperCase());

     return validProviders.some(p => providerName.includes(p));
    }
      

    default:
      return false;
  }

};

interface ValidationModalProps {
  visible: boolean;
  onCancel: () => void;
  onSubmit: () => void;
  processableRows: any[];
  nonProcessableRows: any[];
  changeTypes: string[];
}

const ValidationTableModal: React.FC<ValidationModalProps> = ({
  visible,
  onCancel,
  onSubmit,
  processableRows,
  nonProcessableRows,
  changeTypes
}) => {
  // Remove duplicate change types using Set
  const uniqueChangeTypes = Array.from(new Set(changeTypes));

  const columns = [
    {
      title: 'ICCID',
      dataIndex: 'iccid',
      key: 'iccid',
      width: 200,
      fixed: 'left' as const,
    },
    {
      title: 'SIM Status',
      dataIndex: 'sim_status',
      key: 'sim_status',
      width: 120,
      fixed: 'left' as const,
    },
    ...uniqueChangeTypes.map((changeType) => ({
      title: changeType,
      dataIndex: changeType,
      key: changeType,
      width: 180,
      align: 'center' as const,
      render: (value: boolean) => (
        value ? (
          <CheckCircleOutlined style={{ color: '#52c41a', fontSize: '18px' }} />
        ) : (
          <CloseCircleOutlined style={{ color: '#ff4d4f', fontSize: '18px' }} />
        )
      ),
    })),
  ];

  const allRows = [
    ...nonProcessableRows.map(row => ({ ...row, key: row.iccid })),
    ...processableRows.map(row => ({ ...row, key: row.iccid }))
  ];

  // Calculate scroll height based on number of rows
  const getScrollHeight = () => {
    const rowCount = allRows.length;
    if (rowCount <= 3) {
      return rowCount * 50 + 50; // 50px per row + header
    }
    return 200; // Max height for scrolling
  };

  const hasNonProcessableRows = nonProcessableRows.length > 0;

  return (
    <Modal
      title="Change Type Validation Summary"
      open={visible}
      onCancel={onCancel}
      width="85%"
      centered
      maskClosable={false}
      keyboard={false}
      style={{ top: 20 }}
      styles={{
        body: { 
          maxHeight: '50vh',
          minHeight: '200px',
          overflowY: 'auto' 
        }
      }}
      footer={
        <div className='flex justify-center space-x-4 mt-4'>
          <button 
            key="cancel" 
            onClick={onCancel} 
            className="cancel-btn"
          >
            Cancel
          </button>
          <button 
            key="submit" 
            onClick={onSubmit} 
            className="save-btn"
            disabled={processableRows.length === 0}
          >
            Update
          </button>
        </div>
      }
      zIndex={10000}
    >
    
    <div className="mb-4">
        {/* <div className="flex gap-6 mb-3 p-3 bg-gray-50 rounded">
          <span className="text-green-600 font-semibold flex items-center">
            <CheckCircleOutlined className="mr-2" />
            Processable
          </span>
          {hasNonProcessableRows && (
            <span className="text-red-600 font-semibold flex items-center">
              <CloseCircleOutlined className="mr-2" />
              Non-Processable
            </span>
          )}
        </div> */}
        
        {(() => {
          // Check if there are ANY green checkmarks in the entire table
          const hasAnyGreen = allRows.some(row =>
            uniqueChangeTypes.some(changeType => row[changeType] === true)
          );
          
          // Check if there are ANY red X marks in the entire table
          const hasAnyRed = allRows.some(row =>
            uniqueChangeTypes.some(changeType => row[changeType] === false)
          );

          if (hasAnyGreen && !hasAnyRed) {
            return (
              <div className="p-3 bg-green-50 border-l-4 border-green-400 mb-3">
                <p className="text-sm text-green-800 font-medium">
                  ✓ All change types show <span className="text-green-600 font-semibold">green ✓ marks</span> for all rows.
                </p>
                <p className="text-xs text-green-700 mt-1">
                  Every selected change type can be successfully processed for all rows.
                </p>
              </div>
            );
          } else if (hasAnyRed && !hasAnyGreen) {
            return (
              <div className="p-3 bg-red-50 border-l-4 border-red-400 mb-3">
                <p className="text-sm text-red-800 font-medium">
                  ✗ All change types show <span className="text-red-600 font-semibold">red ✗ marks</span> for all rows.
                </p>
                <p className="text-xs text-red-700 mt-1">
                  None of the selected change types can be processed for any row due to validation rules.
                </p>
              </div>
            );
          } else {
            return (
              <div className="p-3 bg-yellow-50 border-l-4 border-yellow-400 mb-3">
                <p className="text-sm text-yellow-800 font-medium">
                  ⚠️Validation results across change types.
                </p>
                <p className="text-xs text-yellow-700 mt-1">
                  • <span className="text-green-600 font-semibold">Green ✓ marks</span> indicate change types that can be processed for specific rows.
                </p>
                <p className="text-xs text-yellow-700 mt-1">
                  • <span className="text-red-600 font-semibold">Red ✗ marks</span> indicate change types that cannot be processed for specific rows due to validation rules.
                </p>
                {/* <p className="text-xs text-yellow-700 mt-1">
                  • Only change types with green checkmarks will be processed for their corresponding rows.
                </p> */}
              </div>
            );
          }
        })()}
      </div>
      <Table
        columns={columns}
        dataSource={allRows}
        pagination={false}
        scroll={{ 
          y: getScrollHeight(), 
          x: 'max-content' 
        }}
        rowClassName={(record) => {
          const isProcessable = processableRows.some(r => r.iccid === record.iccid);
          return isProcessable ? 'bg-green-50 hover:bg-green-100' : 'bg-red-50 hover:bg-red-100';
        }}
        size="small"
        bordered
      />
    </Modal>
  );
};

export default ValidationTableModal;