import React, { useEffect, useState } from "react";
import { Modal, Divider, Select, Button, Spin } from "antd";
import { ChevronDownIcon } from "@heroicons/react/24/outline";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";

const { Option } = Select;

interface AssignCustomerModalProps {
  visible: boolean;
  onCancel: () => void;
  onUpdate: (updatedRow: any, event_type: string) => void;
  rowData?: any;
}

const EditCostCenter: React.FC<AssignCustomerModalProps> = ({
  visible,
  onCancel,
  onUpdate,
  rowData,
}) => {
  // console.log(rowData?.customer_name,"rowdata customer name")
  const [assignCustomer, setAssignCustomer] = useState<string>(
    rowData?.customer_name || ""
  );
  const [formData, setFormData] = useState<any>(rowData);
  const [loading, setLoading] = useState(true);
  const { username, partner, role, settabledata, token, selectedDb,metaData, firstLastName,sessionId} =
    useAuth();

  const handleAssignCustomer = (value: string) => {
    if (value) {
      const formData_ = formData;
      formData_.customer_name = value;
      setFormData(formData_);
    }
  };

  const handleUpdate = () => {
    onUpdate(formData, "Assign Customer");
  };
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/customers_dropdown_inventory",
          role_name: role,
          parent_module: "Sim Management",
          module_name: "SimManagement Inventory",
          feature_module_name:"Inventory",
          Partner: partner,
          service_provider: rowData?.service_provider,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          dropdown: "Assign customer",
          modified_by: firstLastName,
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);

        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching Inventory data. Please try again.",
            centered: true,
            onOk: onCancel,
          });
        } else {
          const carrierOptions_ = parsedData?.customer_name || [];
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        Modal.error({
          title: "Data Fetch Error",
          content:
            error instanceof Error
              ? error.message
              : "An unexpected error occurred while fetching data. Please try again.",
          centered: true,
          onOk: onCancel,
        });
      } finally {
        setLoading(false);
      }
    };
    if (visible === true) {
      fetchData();
    }
  }, [visible]);

  return (
    <Modal
      title={
        <div className="mt-[-10px]">
          <span className="text-[19px]">Edit Cost Center</span>
        </div>
      }
      visible={visible}
      centered
      onCancel={onCancel}
      footer={[
        <div className="flex justify-center space-x-2 mt-12" key="buttons">
          <Button
            key="cancel"
            onClick={onCancel}
            className="cancel-btn h-[30px] text-base"
            style={{ fontFamily: "Calibri, sans-serif" }}
          >
            Cancel
          </Button>
          <Button
            key="update"
            onClick={handleUpdate}
            className="save-btn text-base border-none"
            style={{ fontFamily: "Calibri, sans-serif" }}
          >
            Update
          </Button>
        </div>,
      ]}
      width={500}
      style={{ height: "500px" }}
    >
      {" "}
      <>
        {loading ? (
          <div className="popup flex justify-center items-center w-full h-full">
            <Spin size="large" />
          </div>
        ) : (
          <div className="flex flex-col space-y-4">
            <div>
              <label
                htmlFor="Cost center 1"
                className="font-normal text-lg"
                style={{ fontFamily: "Calibri, sans-serif" }}
              >
                Cost Center 1
              </label>
              <input
                id="assign-customer"
                type="text"
                className="input"
                placeholder="Enter Cost Input"
              />
            </div>
            <div>
              <label
                htmlFor="Cost center 1"
                className="font-normal text-lg"
                style={{ fontFamily: "Calibri, sans-serif" }}
              >
                Cost Center 2
              </label>
              <input
                id="assign-customer"
                type="text"
                className="input"
                placeholder="Enter Cost Input"
              />
            </div>
            <div>
              <label
                htmlFor="Cost center 1"
                className="font-normal text-lg"
                style={{ fontFamily: "Calibri, sans-serif" }}
              >
                Cost Center 3
              </label>
              <input
                id="assign-customer"
                type="text"
                className="input"
                placeholder="Enter Cost Input"
              />
            </div>
          </div>
        )}
      </>
    </Modal>
  );
};

export default EditCostCenter;
