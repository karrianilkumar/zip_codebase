import React, { useEffect, useState } from 'react';
import { Modal, Button, Spin, DatePicker, Checkbox } from 'antd';
import Select from 'react-select';
import { useAuth } from '@/app/components/auth_context';
import axios from 'axios';
import { ENV_ROUTES } from '@/app/components/routes/route_constants';
import { DropdownStyles } from '@/app/components/css/dropdown';
import dayjs from 'dayjs';
import { useFeatureStore } from '@/app/sim_management/inventory/featureStore';

interface UpdateFeaturesModalProps {
    visible: boolean;
    onCancel: () => void;
    onUpdate: (updatedRow: any, event_type: string) => void;
    rowData?: any;
}

interface OptionType {
    value: number;
    label: string;
    soc_code: string;
    friendly_name: string;
}


const UpdateFeaturesModal: React.FC<UpdateFeaturesModalProps> = ({ visible, onCancel, onUpdate, rowData }) => {
    const [formData, setFormData] = useState<any>(rowData);
    const [loading, setLoading] = useState(true);
    const [featureCodes, setFeatureCodes] = useState<any[]>([]);
    const [effectiveDate, setEffectiveDate] = useState<string | null>(null);
    const [specifyEffectiveDate, setSpecifyEffectiveDate] = useState<boolean>(false);
    const { username, partner, role, token, selectedDb,metaData, sessionId, } = useAuth();
    const [featureCodesOptions, setFeatureCodesOptions] = useState<any[]>([]);
    const [featureCodesMap, setFeatureCodesMap] = useState<any[]>([]);

    const [selectedSOCCodes, setSelectedSOCCodes] = useState<string[]>([]);
    const [selectedIds, setSelectedIds] = useState<number[]>([]);
    const [selectedFriendlyNames, setSelectedFriendlyNames] = useState<string[]>([]);
    const [currentDate, setCurrentDate] = useState('');
    useEffect(() => {
        const date = new Date();
        const formattedDate = date.toISOString().split('T')[0]; // e.g., "2025-05-01"
        setCurrentDate(formattedDate);
    }, []);

    // Function to map string arrays to react-select's format
    const mapToSelectOptions = (options: string[]) =>
        options.map((option) => ({ value: option, label: option }));
    // Fetch dropdown options when modal is visible
    useEffect(() => {
        const fetchData = async () => {
            setLoading(true);
            try {
                const url = ENV_ROUTES.SIM_MANAGEMENT;
                const data = {
                    tenant_name: partner || 'default_value',
                    username,
                    path: '/update_features_pop_up_data',
                    role_name: role,
                    parent_module: 'Sim Management',
                    module_name: 'SimManagement Inventory',
                    feature_module_name: 'Inventory',
                    Partner: partner,
                    service_provider: rowData?.service_provider,
                    service_provider_id: rowData?.service_provider_id,
                    // service_provider_id: '6',
                    access_token: token,
                    db_name: selectedDb,
                    ...metaData,
                    sessionID: sessionId,
                    dropdown: 'Update features',
                    modified_by: username
                };

                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);

                if (!parsedData.flag) {
                    Modal.error({
                        title: 'Data Fetch Error',
                        content: parsedData.message || 'An error occurred while fetching Inventory data. Please try again.',
                        centered: true,
                        onOk: onCancel
                    });
                } else {
                    const feature_codes_map = parsedData?.soc_codes || []
                    setFeatureCodesMap(feature_codes_map);
                    // const featureOptions_ = feature_codes_map.map((item: any) => `${item.friendly_name} ${item.soc_code}`);
                    // setFeatureCodesOptions(feature_codes_map)
                    const featureCodes_ = rowData?.telegence_features || "";
                    const featureCodesArray = featureCodes_.split(",").map((item: any) => item.trim());
                    // setFeatureCodes(featureCodesArray);
                    const filtered = feature_codes_map.filter((item: any) => featureCodesArray.includes(item.soc_code));

                    setSelectedIds(filtered.map((item: any) => item.id)); // Extract IDs
                    setSelectedFriendlyNames(filtered.map((item: any) => item.friendly_name)); // Extract friendly names
                    setSelectedSOCCodes(filtered.map((item: any) => item.soc_code)); // Ensure selectedSOCCodes updates

                    // Set the initial selected options for react-select
                    const selected_ = filtered.map((item: any) => ({
                        value: item.id,
                        label: `${item.friendly_name} - ${item.soc_code}`,
                        soc_code: item.soc_code,
                        friendly_name: item.friendly_name,
                    }));
                    setFeatureCodes(selected_);
                    // Transform options for react-select
                    const options_ = feature_codes_map.map((option: any) => ({
                        value: option?.id || "",
                        label: `${option?.friendly_name || ""} - ${option?.soc_code || ""}`,
                        soc_code: option?.soc_code || "",
                        friendly_name: option?.friendly_name || "",
                    }));
                    setFeatureCodesOptions(options_)

                }
            } catch (error) {
                console.error('Error fetching data:', error);
                Modal.error({
                    title: 'Data Fetch Error',
                    content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                    centered: true,
                    onOk: onCancel
                });
            } finally {
                setLoading(false);
            }
        };

        if (visible) {
            fetchData();
        }
    }, [visible]);

    // Handlers

    // const handleFeatureCodesChange = (selectedOptions: any) => {
    //     setFeatureCodes(selectedOptions ? selectedOptions.map((opt: any) => opt.value) : []);
    //     setFormData({ ...formData, soc: selectedOptions });
    // };

    const handleFeatureCodesChange = (selectedOptions: any) => {
        if (!selectedOptions) {
            setSelectedSOCCodes([]);
            setSelectedIds([]);
            setSelectedFriendlyNames([]);
            return;
        }

        setFeatureCodes(selectedOptions)
        setSelectedSOCCodes(selectedOptions.map((opt: any) => opt.soc_code));
        setSelectedIds(selectedOptions.map((opt: any) => opt.value));
        setSelectedFriendlyNames(selectedOptions.map((opt: any) => opt.friendly_name));
    };

    const handleSpecifyEffectiveDateChange = (checked: boolean) => {
        setSpecifyEffectiveDate(checked);
        if (!specifyEffectiveDate) {
            setEffectiveDate(null);
        }
    };

    const handleUpdate = () => {
        // console.log("selectedsoccodes", selectedSOCCodes)
        // console.log("selectedIds", selectedIds)
        // console.log("selectedFriendlyNames", selectedFriendlyNames)

        const featureCodes_ = rowData?.telegence_features || "";
        const featureCodesArray = featureCodes_.split(",").map((item: any) => item.trim());
        const filtered = featureCodesMap.filter((item: any) => featureCodesArray.includes(item.soc_code));
        const prevCodes = filtered.map((item: any) => item.soc_code)
        const prevIDs = filtered.map((item: any) => item.id)
        const prevNames = filtered.map((item: any) => item.friendly_name)

        // console.log("prevCodes", prevCodes)
        // console.log("prevIDs", prevIDs)

        const newly_added_codes = selectedSOCCodes.filter((item: any) => !prevCodes.includes(item));
        const removed_codes = prevCodes.filter((item: any) => !selectedSOCCodes.includes(item))
        const newly_added_ids = selectedIds.filter((item: any) => !prevIDs.includes(item))

        // console.log("newly_added_codes", newly_added_codes)
        // console.log("removed_codes", removed_codes)
        // console.log("newly_added_ids", newly_added_ids)

        const configuration_change_details_ = {
            MobilityConfigurationIDsToAdd: newly_added_codes,
            MobilityConfigurationIDsToRemove: removed_codes,
            MobilityConfigurationsCurrent: selectedSOCCodes.join(","),
            ConfigurationType: "MobilityFeature",
            effectiveDate: effectiveDate,
            // telegenceDeviceId:null
        }
        const mobility_configuration_ids_ = newly_added_ids

        const featureCodesString = selectedSOCCodes.join(",");
        const formData_ = { ...formData, telegence_features: featureCodesString, mobility_configuration_ids: mobility_configuration_ids_, configuration_change_details: configuration_change_details_, effective_date: effectiveDate || currentDate }
        console.log("effectiveDate", effectiveDate)
        console.log("currentDate", currentDate)
        console.log("formData_", formData_)
        onUpdate(formData_, 'Update feature');
    };

    return (
        <Modal
            title="Update Telegence Device Feature"
            visible={visible}
            centered
            onCancel={onCancel}
            footer={[
                <div className="flex justify-center space-x-2" key="buttons">
                    <button onClick={onCancel} className="cancel-btn">Cancel</button>
                    <button onClick={handleUpdate} className="save-btn">Update</button>
                </div>
            ]}
            width={500}
        >
            {(loading) ? (
                <div className="popup flex justify-center items-center w-full h-full">
                    <Spin size="large" />
                </div>
            ) : (
                <div className="flex flex-col space-y-4">
                    <div>
                        <label className="field-label">Feature Codes</label>
                        <Select
                            isMulti
                            value={featureCodes}
                            options={featureCodesOptions}
                            onChange={handleFeatureCodesChange}
                            placeholder="Select feature codes"
                            styles={DropdownStyles}
                        />
                    </div>
                    <div className='flex'>
                        <label className="field-label">Specify Effective Date</label>
                        <Checkbox
                            id="applicableRatePlanForAll"
                            checked={specifyEffectiveDate}
                            onChange={(e) => handleSpecifyEffectiveDateChange(e.target.checked)}
                            className='ml-4'
                        />
                    </div>
                    {specifyEffectiveDate && (
                        <>
                            <div>
                                <label className="field-label">Effective Date</label>
                                <DatePicker
                                    value={effectiveDate ? dayjs(effectiveDate) : null}
                                    onChange={(date) =>
                                        setEffectiveDate(date ? date.format('YYYY-MM-DD') : null)
                                    }
                                    className="input"
                                    format="MM/DD/YYYY"
                                    placeholder="MM/DD/YYYY"
                                />
                            </div>
                            <div className="info-message">
                                <p className="text-sm">
                                    Date cannot be after 30 days and not before the first day of the current billing cycle.
                                </p>
                            </div>
                        </>
                    )}

                </div>
            )}
        </Modal>
    );
};

export default UpdateFeaturesModal;
