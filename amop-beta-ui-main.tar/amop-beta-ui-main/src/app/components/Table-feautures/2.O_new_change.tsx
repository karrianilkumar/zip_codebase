"use client";

import { FC, useState, lazy, Suspense, useEffect, Key, useRef } from "react";
import Select from "react-select";
import { Modal, Button, Spin, Input, notification } from "antd";
import { PlusIcon } from "@heroicons/react/24/outline";
import { DropdownStyles } from "@/app/components/css/dropdown";
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import React from "react";
import { useFeatureStore } from "../../sim_management/inventory/featureStore";
import AssignCustomerModal from "./assign-customer";
import UpdatePhoneNumberModal from "./update-phone-number";
import RefreshLineModal from "./refresh-line";
import UpdateCommunicationPlanModal from "./update-communication-plan";
import UpdatePPUAddressModal from "./update-ppu-address";
import ResetVoicemailPassword from "./update_reset_voice_mail_password";
import UpdatePrivateNetworkModal from "./update_private_network";
import { PerformanceLogStore } from "@/app/stores/performance_matrix_store";
import AllChangeTypesModal from "./AllChangeTypesModal";
import { useInventoryAllChangeTypesStore } from "@/app/stores/inventorytAllChangeTypesStore";
import ValidationTableModal, { canProcessChangeType } from './validationTableModal';
import { useCustomerProfileStore } from "@/app/billing/killbill_stores/customer_profile_store";
import { fireSideCannons } from "@/app/components/confetti";
import { serviceProviders } from "@/app/constants/partnercarrier";

const UpdateCarrierRatePlan = lazy(() => import("./update-carrier-rate-plan"));
const UpdateCustomerRatePlan = lazy(() => import("./update-customer-rate-plan"));
const InventoryEditCostCenterModal = lazy(() => import("./invenotory-edit-cost-center"));
const UpdateStatusModal = lazy(() => import("./update-status"));
const UpdateFeaturesModal = lazy(() => import("./2_0_update_features"));
const SendSMSModal = lazy(() => import("./update_send_sms"));
const PrivateNetworkIPModal = lazy(() => import("./update_private_network"));


interface NewChangeProps {
  rowdata: any[]
  features: any[];
  callFetchData: (isRefresh: boolean) => void;
  is_2_0_flow:boolean;
}

const NewChange2: React.FC<NewChangeProps> = ({ features, rowdata, callFetchData, is_2_0_flow }) => {
  const { setIsAllChangeType,isAllChangeType, setIsValidated,setValidationTrigger, setsuccessFullChangeTypes,setActiveChange, successFullChangeTypes, isSubmit, setIsSubmit ,assignCustomerData, customerRatePlanData, commPlanChanges, allChangetypeOptionsinStore, setSequenceMap,set_all_2_0_payloads,all_2_0_payloads, SequenceMap} = useInventoryAllChangeTypesStore();
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [selectedServiceProvider, setSelectedServiceProvider] = useState(rowdata[0]?.service_provider_display_name || '');
  const [selectedAction, setSelectedAction] = useState<string | null>(null);
  const [showInitialScreen, setShowInitialScreen] = useState(true);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [changeTypeOptions, setChangeTypeOptions] = useState<any>([])

  const [isBPEnabled, setIsBPEnabled] = useState(false);
  const [openUpdateCarrierRatePlan, setUpdateCarrierRatePlan] = useState<boolean>(false);
  const [openUpdateCustomerRatePlan, setUpdateCustomerRatePlan] = useState<boolean>(false);
  const [openUpdateStatusModal, setOpenUpdateStatusModal] = useState<boolean>(false);
  const [openInventoryEditCostCenterModal, setOpenInventoryEditCostCenterModal] = useState<boolean>(false)
  const [openUpdateFeaturesModal, setOpenUpdateFeatures] = useState<boolean>(false);
  const [openAssignCustomerModal, setOpenAssignCustomer] = useState<boolean>(false);
  const [openChangePhoneNumberModal, setOpenChangePhoneNumberModal] = useState<boolean>(false);
  const [openRefreshLineModal, setOpenRefreshLineModal] = useState<boolean>(false);
  const [openCommPlanModal, setOpenCommPlanModal] = useState<boolean>(false);
  const [openPPUAdressModal, setOpenPPUAddressModal] = useState<boolean>(false);
  const [openIndividualLineSyncModal, setOpenIndividualLineSyncModal] = useState<boolean>(false);
  // add to state variables (near other openXModal states)
  const [openSendSMSModal, setOpenSendSMSModal] = useState<boolean>(false);
  const { username, role, partner, token, selectedDb, metaData ,firstLastName, sessionId, isSubTenant, settabledata } = useAuth(); // Add isSubTenant
  const [writesFlag, setWritesFlag] = useState(false);
  const { getTargetTenantProvider, IsTargetTenantProvider } = PerformanceLogStore();
  const isFetchInProgressRef = useRef(false);
  const fetchTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  // Add these state variables
const [showValidationModal, setShowValidationModal] = useState(false);
const [processableRows, setProcessableRows] = useState<any[]>([]);
const [nonProcessableRows, setNonProcessableRows] = useState<any[]>([]);
const [selectedChangeTypes, setSelectedChangeTypes] = useState<string[]>([]);
// Add this state variable
const [unfilteredChangeTypes, setUnfilteredChangeTypes] = useState<any[]>([]);
const [lastUpdatedRow, setLastUpdatedRow] = useState<any[]>([]);
const [lastUpdatedRowByType, setLastUpdatedRowByType] = useState<Record<string, any>>({});
const [openResetVoiceMailPasswordModal, setopenResetVoiceMailPasswordModal] = useState<boolean>(false);
const is_parent_provider_exists = IsTargetTenantProvider(rowdata[0]?.service_provider_display_name)

const [openPrivateNetworkIPModal, setopenPrivateNetworkIPModal] = useState<boolean>(false);
  
  const isAdmin = role?.toLowerCase() === "super admin" || role?.toLowerCase() === "partner admin"
  const editableDrp = DropdownStyles;
  const messageStyle = {
    fontSize: "14px",
    fontWeight: "bold",
    padding: "16px",
  };
    const { setIs2OFilterLoaded,is2OFilterLoaded } = useCustomerProfileStore();
  const [openAllChangeTypesModal, setOpenAllChangeTypesModal] = useState<boolean>(false);
  useEffect(() => {
    console.log("rowdata", rowdata)
    if(isModalVisible){
      fetchBpFlag();
    }
    if (Array.isArray(rowdata) && rowdata.length > 0) {
      console.log("rowdata[0].service_provider_display_name", rowdata[0].service_provider_display_name)
      setSelectedServiceProvider(rowdata[0].service_provider_display_name || "");
    } else {
      setSelectedServiceProvider(""); // reset when no rows
    }
  }, [rowdata, isModalVisible]);

const getChangeTypeOptions = (options: any[]) => {
  let updatedOptions: any = []
  const providerName = getTargetTenantProvider(rowdata[0].service_provider_display_name.toUpperCase()) || "";
  const isSameStatus = rowdata.every((item: any) => item.sim_status === rowdata[0].sim_status);
  const simStatus = (rowdata[0]?.sim_status).toUpperCase() || ""
  const isActivated = isSameStatus && (simStatus && (simStatus === "ACTIVATED" || simStatus === "ACTIVE" || simStatus === "A" || simStatus === "ONLINE" || simStatus === "ACTIVATE"));
  const isRestore = isSameStatus && (simStatus && (simStatus === "RESTORE SUSPENDED"));
  const allowedProviders = [
    "AT&T - POD19",
    "WEBBING",
    "MULTI-CARRIER SIM",
    "VERIZON - THINGSPACE IOT",
    "AT&T - CISCO JASPER",
    "AT&T - TELEGENCE - UAT ONLY",
    "ROGERS SANDBOX"
  ];

  const hasAllowedProvider = allowedProviders.some(provider =>
    providerName.includes(provider.toUpperCase())
  );

  // if (hasAllowedProvider) {
    if (options?.includes("Line Sync")) {
      updatedOptions.push("Line Sync");
    }
  // }
  if (options?.includes("Update Device Status")) {
    updatedOptions.push("Update Device Status");
  }

  console.log("issamestatus",isSameStatus)
  console.log("isActivated",isActivated)
  console.log("isRestore",isRestore)


  if (providerName && providerName.includes("TELEGENCE")) {
    const isActiveOrRestore = isActivated || isRestore;

    if (options?.includes("Edit Cost Center")) {
      updatedOptions.push("Edit Cost Center");
    }

    if (options?.includes("Reset Voicemail Password")) {
      updatedOptions.push("Reset Voicemail Password");
    }

     if (options?.includes("Change Private Static IP Address")) {
      updatedOptions.push("Change Private Static IP Address");
    }

    if (isActiveOrRestore && options?.includes("Update Carrier Rate Plan")) {
      updatedOptions.push("Update Carrier Rate Plan");
    }

    if (isActiveOrRestore && options?.includes("Update Customer Rate Plan")) {
      updatedOptions.push("Update Customer Rate Plan");
    }

    if (isActiveOrRestore && options?.includes("Assign Customer")) {
      updatedOptions.push("Assign Customer");
    }

    if (isActiveOrRestore && options?.includes("Update Features")) {
      updatedOptions.push("Update Features");
    }

    if (isActiveOrRestore && options?.includes("Refresh A Line")) {
      updatedOptions.push("Refresh A Line");
    }

    if (options?.includes("Update PPU Address")) {
      updatedOptions.push("Update PPU Address");
    }

    if (isActiveOrRestore) {
      updatedOptions.push("Change Phone Number");
    }
  }
  else if (providerName && providerName === "EBONDING") {

    if (isActivated && options?.includes("Update Carrier Rate Plan")) {
      updatedOptions.push("Update Carrier Rate Plan");
    }

    if (isActivated && options?.includes("Update Customer Rate Plan")) {
      updatedOptions.push("Update Customer Rate Plan");
    }

    if (isActivated && options?.includes("Assign Customer")) {
      updatedOptions.push("Assign Customer");
    }
    if (options?.includes("Edit Cost Center")) {
      updatedOptions.push("Edit Cost Center");
    }

    // if (options?.includes("Edit Cost Center")) {
    //   if (partner === "Titanium - AWX") {
    //     updatedOptions.push("Edit Cost Center");
    //   }
    // }
  }
  else if (providerName && providerName === "ROGERS") {

    // Add Send SMS for Rogers
    if (options?.includes("Send SMS")) {
      updatedOptions.push("Send SMS");
    }

    if (options?.includes("Update Communication Plan")) {
      updatedOptions.push("Update Communication Plan");
    }

    if (isActivated && options?.includes("Update Carrier Rate Plan")) {
      updatedOptions.push("Update Carrier Rate Plan");
    }

    if (isActivated && options?.includes("Update Customer Rate Plan")) {
      updatedOptions.push("Update Customer Rate Plan");
    }

    if (options?.includes("Edit Cost Center")) {
        updatedOptions.push("Edit Cost Center");
    }
      if (options?.includes("Change Private Static IP Address")) {
      updatedOptions.push("Change Private Static IP Address");
    }
  }

 
  else {
    const isKoreProvider = providerName === "kore";

    // Add Send SMS for AT&T - Pod 19, AT&T - Cisco Jasper, T-Mobile Jasper
    const JasperProviders = ["POD19", "CISCO JASPER", "T-MOBILE JASPER", "T - MOBILE"];
    const hasJasperProvider = JasperProviders.some(provider => 
      providerName.includes(provider.replace(/\s+/g, '').toUpperCase()) || 
      providerName.includes(provider.toUpperCase())
    );

    const privatenetworkProviders = ["POD19", "CISCO JASPER", "T-MOBILE JASPER", "VERIZON - THINGSPACE IOT", "TEAL"];
    
    if (hasJasperProvider && options?.includes("Send SMS")) {
      updatedOptions.push("Send SMS");
    }

    if (hasJasperProvider && options?.includes("Update Communication Plan")) {
      updatedOptions.push("Update Communication Plan");
    }

        if (privatenetworkProviders && options?.includes("Change Private Static IP Address")) {
      updatedOptions.push("Change Private Static IP Address");
    }

    if (options?.includes("Edit Cost Center")) {
      updatedOptions.push("Edit Cost Center");
    }

    if (options?.includes("Update Carrier Rate Plan") && !isKoreProvider) {
      updatedOptions.push("Update Carrier Rate Plan");
    }

    if (isActivated && options?.includes("Update Customer Rate Plan")) {
      updatedOptions.push("Update Customer Rate Plan");
    }

    if (options?.includes("Assign Customer")) {
      updatedOptions.push("Assign Customer");
    }

    // if (options?.includes("Edit Cost Center")) {
    //   if (partner === "Titanium - AWX") {
    //     updatedOptions.push("Edit Cost Center");
    //   }
    // }
  }

  return updatedOptions
}


  const fetchData = async () => {
    handleClearFields()
    try {
      setLoading(true);
      const url =
        ENV_ROUTES.INVENTORY;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/service_provider_change_types",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        service_provider_id: rowdata.length > 0 && rowdata[0].service_provider_id || null,
        service_provider_display_name: rowdata.length > 0 && rowdata[0].service_provider_display_name || null,
        ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(rowdata[0]?.service_provider_display_name) : "" } 
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        setLoading(false);
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {

        const change_type_options: any = parsedData?.change_types || [];
        const sequence_map_: any = parsedData?.sequence_map || [];
        setSequenceMap(sequence_map_)
        if (change_type_options.length === 0) {
        setChangeTypeOptions([]);
        setUnfilteredChangeTypes([]);
      }

       else{
          // Store unfiltered options for All Change Types modal
        const unfilteredChangeTypes = [...change_type_options];
          const filtered = unfilteredChangeTypes.filter(changeType =>
            features.some(feature =>
              feature.toLowerCase().startsWith(changeType.toLowerCase()) &&
              feature.toLowerCase().endsWith("-inventory")
            )
          )
          console.log("filtered",filtered)
        const filteredChangeTypes = getChangeTypeOptions(filtered);
        const FinalChangeTypeOptions = ["All Change Types", ...filteredChangeTypes.sort()];
       
        setChangeTypeOptions(FinalChangeTypeOptions);
         console.log("FinalChangeTypeOptions",FinalChangeTypeOptions)
        setUnfilteredChangeTypes(unfilteredChangeTypes); // Add new state

        // Finish loading
      
       }
      setLoading(false);
      }

    } catch (error) {
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
      setLoading(false);

    }
  };
  const fetchDataInitial = async () => {
    // setIs2OFilterLoaded(true);
    // setLoading(true);
    let parsedData: any;
    const url = ENV_ROUTES.SIM_MANAGEMENT;
    const data = {
      tenant_name: partner || "default_value",
      username,
      path: "/get_inventory_data",
      role_name: role,
      parent_module: "Sim Management",
      module_name: "SimManagement Inventory",
      feature_module_name: "Inventory",
      mod_pages: {
        start: 0,
        end: 100,
      },
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
    };

    try {
      const response = await axios.post(url, { data });
      parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === true) {
        // notification.success({
        //   message: "Success",
        //   description: "Updated successfully",
        //   style: messageStyle,
        //   placement: "top",
        // });
      //   setShowInitialScreen(false);
      //  setIsModalVisible(false);
        // setLoading(false);
        // setIs2OFilterLoaded(false);
        // closeModals();
        // requestIdleCallback(() => {
          settabledata(parsedData?.inventory_data || []);
          console.log("table response:", getCurrentDateTime());
        // });
        notification.success({
          message: "Success",
          description: "Updated successfully",
          style: messageStyle,
          placement: "top",
        });
        fireSideCannons()
      } else {
        Modal.error({
          title: "Data Update Error",
          content: parsedData.message || "An error occurred while updating Inventory data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      // setLoading(false);
      Modal.error({
        title: "Data Update Error",
        content: error instanceof Error ? error.message : "An error occurred while updating Inventory data. Please try again.",
        centered: true,
      });
    } finally {
      // closeModals();
      // setLoading(false);
    }
  };
  const fetchBpFlag = async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_cross_provider_optimization_status",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Active Customer Rate Plan",
        feature_module_name: "Customer Rate Plans",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        const billing_plaform_flag = parsedData?.billing_platform_flag || false;
        setIsBPEnabled(billing_plaform_flag);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };


  const handleClearFields = () => {
    setSelectedServiceProvider('');
    setSelectedAction('');
    setShowInitialScreen(true);
    setErrorMessage(null);
  };

  const handleSelectAction = (selectedOption: any) => {
    if (selectedOption) {
      const value = selectedOption?.value
      if (value === "Update Device Status") {
        const sameStatus = rowdata.every((item: any) => item.sim_status === rowdata[0].sim_status);
        if (sameStatus) {
          setSelectedAction(value);
        }
        else {
          Modal.warning({
            title: 'Selection Error',
            content: 'Selected devices have different statuses. Please select devices with the same status to proceed with "Update Device Status".',
            centered: true,
          })
          setSelectedAction('')
          return;
        }
      }
      if (value === "Reset Voicemail Password") {
        const sameBAN = rowdata.every((item: any) => item.billing_account_number === rowdata[0].billing_account_number);
        if (sameBAN) {
          setSelectedAction(value);
        }
        else {
          Modal.warning({
            title: 'Selection Error',
            content: 'Selected devices have different Billing Account Number. Please select devices with the same BAN to proceed with "Reset Voicemail Password".',
            centered: true,
          })
          setSelectedAction('')
          return;
        }
      }
      if (value === "Update Customer Rate Plan") {
        const activeStatus = rowdata.every((item: any) => item.sim_status.toLowerCase() === "active" || item.sim_status.toLowerCase() === "activated")
        if (activeStatus) {
          setSelectedAction(value);
        }
        else {
          Modal.warning({
            title: 'Selection Error',
            content: 'Update Customer Rate Plan is only available for SIMs in Active status',
            centered: true,
          })
          setSelectedAction('')
          return;
        }
      }
       if (value === "Change Private Static IP Address") {
        if(rowdata && rowdata.length>1) {
          Modal.info({
            title: 'Selection Error',
            content: 'Cannot change Private Static IP Address for multiple rows.',
            centered: true,
          })
          setSelectedAction('')
          return;
        }
         setSelectedAction(value);
    return;

      }
      else {
        setSelectedAction(value);
      }

    }
    else {
      setSelectedAction(null);

    }
  };

  const handleFinish = () => {
    setIsModalVisible(false);
    handleClearFields();
  };

  const showModal = () => {
    fetchData();
    setIsModalVisible(true);
  };

  const handleCancel = () => {
    setIsModalVisible(false);
    setUpdateCarrierRatePlan(false)
    setUpdateCustomerRatePlan(false)
    setOpenInventoryEditCostCenterModal(false)
    setOpenUpdateStatusModal(false)
    setOpenUpdateFeatures(false)
    setOpenSendSMSModal(false)
    setopenResetVoiceMailPasswordModal(false)
    setOpenIndividualLineSyncModal(false)
    setOpenAssignCustomer(false)
    setOpenChangePhoneNumberModal(false)
    setOpenRefreshLineModal(false)
    setOpenCommPlanModal(false)
    setOpenPPUAddressModal(false)
    setopenPrivateNetworkIPModal(false);
    setOpenAllChangeTypesModal(false) // Add this
    handleClearFields();
  };

  const handleContinue = async () => {
    if (!selectedServiceProvider || !selectedAction) {
      setErrorMessage("Please select both a Service Provider and a Change Type.");
      return; // ✅ Stop execution if validation fails
    }
    
      // Check if "All Change Types" is selected
    // if (selectedAction === "All Change Types") {
    //   setOpenAllChangeTypesModal(true);
    //   setShowInitialScreen(false);
    //   setIsModalVisible(false);
    //   setIsAllChangeType(true)
    //   setIsValidated(false)
    //   setsuccessFullChangeTypes([])
    //   return;
    // }
    // else{
    // setIsAllChangeType(false);
    // setActiveChange("");
    // }

    // If valid selections
    setErrorMessage(null);
    if(selectedAction !== "Line Sync"){
      setShowInitialScreen(false);
      setIsModalVisible(false);
    }

     if(selectedAction !== "Change Private Static IP Address" && selectedServiceProvider.toLowerCase().includes("teal")){
      setShowInitialScreen(false);
      setIsModalVisible(false);
    }
    
    switch (selectedAction) {
      case "Update Carrier Rate Plan": 
        setIsAllChangeType(false)
        setUpdateCarrierRatePlan(true);
        break;
      case "Edit Cost Center":
        setIsAllChangeType(false)
        setOpenInventoryEditCostCenterModal(true);
        break;
      case "Update Customer Rate Plan":
        setIsAllChangeType(false)
        setUpdateCustomerRatePlan(true);
        break;
      case "Update Device Status":
        setIsAllChangeType(false)
        setOpenUpdateStatusModal(true);
        break;
      case "Update Features":
        setIsAllChangeType(false)
        setOpenUpdateFeatures(true);
        break;
      case "Line Sync":
        updateChanges(rowdata, "Line Sync")
        break;
      case "Assign Customer":
        setIsAllChangeType(false)
        setOpenAssignCustomer(true)
        break;
      case "Change Phone Number":
        setIsAllChangeType(false)
        setOpenChangePhoneNumberModal(true)
        break;
      case "Refresh A Line":
        setIsAllChangeType(false)
        setOpenRefreshLineModal(true)
        break;
      case "Update Communication Plan":
        setIsAllChangeType(false)
        setOpenCommPlanModal(true)
        break;
      case "Update PPU Address":
        setIsAllChangeType(false)
        setOpenPPUAddressModal(true)
        break;
      
      case "Send SMS":
        setIsAllChangeType(false)
        setOpenSendSMSModal(true);
        break;

      case "Reset Voicemail Password":
        setIsAllChangeType(false)
        setopenResetVoiceMailPasswordModal(true);
        break;

        case "Change Private Static IP Address":
        if(selectedServiceProvider.toLowerCase().includes("teal")) {
          updateChanges(rowdata, "Change Private Static IP Address")
        }
        else{
              setIsAllChangeType(false)
        setopenPrivateNetworkIPModal(true);
        }
        break;

      case "All Change Types":
        setIsAllChangeType(true)
        setOpenAllChangeTypesModal(true);
        setActiveChange("");
        setIsValidated(false);
        setsuccessFullChangeTypes([]);
        break

      default:
        break;
    }
  };
  const fetchCarrierWritesFlag = async () => {
    let parsedData: any
    const url = ENV_ROUTES.SIM_MANAGEMENT;
    const data = {
      tenant_name: partner || "default_value",
      username,
      path: "/get_writes_enable_for_service_provider",
      role_name: role,
      parent_module: "Sim Management",
      module_name: "Inventory",
      service_provider: rowdata[0]?.service_provider_display_name || "",
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
      environment: "BETA",
      ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(rowdata[0]?.service_provider_display_name) : "" } 
    };

    try {
      setLoading(true);
      const response = await axios.post(url, { data });
      parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === true) {
        const write_is_enabled = parsedData?.write_is_enabled || false;
        setWritesFlag(write_is_enabled);
        return write_is_enabled;
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      return false; // fallback in case of error
    } finally {
      setLoading(false);
    }
  };
  const submitCarrierStatus = async (event_type: any, write_is_enabled:boolean) => {
    let parsedData: any
    const url = ENV_ROUTES.SIM_MANAGEMENT;
    const data = {
      tenant_name: partner || "default_value",
      username,
      path: "/insert_carrier_status_validation_audit",
      role_name: role,
      parent_module: "Sim Management",
      module_name: "Inventory",
      service_provider: rowdata[0]?.service_provider_display_name || "",
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
      environment: "BETA",
      msisdn: [],
      iccid: rowdata.map((item: any) => item.iccid) || [],
      change_type: event_type,
      write_is_enabled:write_is_enabled,
      ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(rowdata[0]?.service_provider_display_name) : "" } 
    };

    try {
      const response = await axios.post(url, { data });
      parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === true) {
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
    }
  };
  const callSyncLambda = async () => {
    const isTelegenceProvider = (rowdata[0]?.service_provider_display_name).toLowerCase().includes("at&t - telegence")
    try {
      const url = ENV_ROUTES.OPTIMIZATION_SYNC_LAMBDA;
      const data = {
        key_name: "m2m_inventory_live_sync_from_20",
        path: "/lambda_sync_jobs_",
        tenant_name: partner || "default_value",
        service_provider_id: rowdata[0]?.service_provider_id || "",
        device_id: rowdata?.map((item: any) => item.device_id) || '',
        mobility_device_id: rowdata?.map((item: any) => item.mobility_device_id) || "",
      };

      const response = await axios.post(url, { data });
      const responseData = JSON.parse(response.data.body);

      if (responseData.flag === false) {
        console.error("Data Fetch Error: " + responseData.message);
      } else {
        console.log("Success: Inventory lambda sync successful.");
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }

  }
  const sendUpdatedData = async (updatedRow: any, event_type: any, moduleStatus?: boolean) => {
    const providerName = getTargetTenantProvider(rowdata[0]?.service_provider_display_name).toLowerCase() || "";
    const isKoreProvider = providerName.includes("kore")
    const isVerizonProvider = (providerName.includes("verizon") || providerName.includes("vzn") || providerName.toLowerCase().includes("vzwcr") || providerName.toLowerCase().includes("2215-so01"))
    const isTelgencerovider = providerName.includes("telegence")
    const path = event_type === "Update Carrier Rate Plan" ? "/update_carrier_rate_plan" : event_type === "Update Customer Rate Plan" ? "/update_customer_rate_plan" : event_type === "Edit Cost Center" ? "/edit_cost_center" : event_type === "Update Device Status" ? "/update_status" : event_type.toLowerCase().includes("update feature") ? "/update_features" : event_type === "Line Sync" ? "/update_line_sync" : event_type === "Assign Customer" ? "/update_assign_customer" : event_type === "Change Phone Number" ? "/update_phone_number" : event_type === "Refresh A Line" ? "/update_refresh_a_line" :event_type === "Update Communication Plan" ? "/update_communication_plan" : event_type === "Update PPU address" ? "/update_ppu_address" : event_type === "Send SMS" ? "/send_sms" : event_type === "Reset Voicemail Password" ? "/reset_voicemail_password"  :event_type === "Change Private Static IP Address" ? "/update_private_network_ip" : "";
    setShowInitialScreen(true);
    setLoading(true);
    setIs2OFilterLoaded(true);
    let data: any = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: path,
      role_name: role,
      module_name: "SimManagement Inventory",
      feature_module_name: "Inventory",
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
      table_name: "sim_management_inventory",
      service_provider_display_name: rowdata[0]?.service_provider_display_name || '',
      //   old_data: oldData,
      carrier_api_status: true,
      change_event_type :event_type === "Update Customer Rate Plan" ? "Change Customer Rate Plan" : event_type === "Update Device Status" ? "Update Status" : event_type,
      ...(event_type === "Assign Customer" && { billing_platform_flag: isBPEnabled ,createRevService:updatedRow?.createRevService || "", ProviderId:updatedRow?.ProviderId || "", RevProductId:updatedRow?.RevProductId || "", RevPackageId:updatedRow?.RevPackageId || "", RateList:updatedRow?.RateList || [], Prorate:updatedRow?.Prorate || "", effective_date:updatedRow?.effective_date || "", useCarrierActivation:updatedRow?.useCarrierActivation || "", Description:updatedRow?.Description || ""}),
      request_received_at: getCurrentDateTime(),
      template_name: "Inventory Status Update",
      ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(rowdata[0]?.service_provider_display_name) : "" } 

    };
    try {
      const url = ENV_ROUTES.INVENTORY;
      if (event_type === "Update Carrier Rate Plan") {
        console.log("updatedRow", updatedRow)
         const isCommpLan = !["webbing","multi-carrier sim" ,"teal", "telegence"].includes(providerName?.toLowerCase()) || false
        const isTelegence = (providerName?.toLowerCase()).includes("telegence") || false
        data["changed_data"] = rowdata.map((item: any) => ({
          id: item.id,
          effective_date: updatedRow.effective_date,
          carrier_rate_plan_name: updatedRow.carrier_rate_plan_name || "",
          communication_plan: updatedRow.communication_plan || "",
           ...(isCommpLan
          ? { communication_plan: updatedRow.communication_plan || "" }
          : {}),
          ...(isTelegence
        ? { optimization_group: updatedRow.optimization_group || "" }
        : {}),
          modified_by: firstLastName,
        }));
      }
      // Add Update Customer Rate Plan logic
      if (event_type === "Update Customer Rate Plan") {
        console.log("updatedRow", updatedRow)
        data["changed_data"] = rowdata.map((item: any) => ({
          id: item.id,
          effective_date: updatedRow.effective_date,
          customer_rate_plan_name: updatedRow.customer_rate_plan_name || "",
          customer_rate_pool_name: updatedRow.customer_rate_pool_name !== "None" ? updatedRow.customer_rate_pool_name : "",
          modified_by: firstLastName,
          ...(isSubTenant ? { sub_tenant_customer_rate_plan_name: updatedRow.customer_rate_plan_name || "" } : { sub_tenant_carrier_rate_plan_name: updatedRow.customer_rate_plan_name || "" }),
          ...(isBPEnabled ? {
            customer_name: updatedRow.customer_name,
            ...(moduleStatus ? { account_number: updatedRow.customer_id || "" } : { customer_id: updatedRow.customer_id || "" })
          } : {})
        }));
      }
      if (event_type === "Edit Cost Center") {
        data["changed_data"] = rowdata.map((item: any) => ({
          id: item.id,
          iccid: updatedRow.iccid,
          cost_center: updatedRow.cost_center || "",
          modified_by: firstLastName,
        }));
      }
      if (event_type === "Update Device Status") {

        const isVerizonActive = isVerizonProvider && updatedRow?.sim_status === "Active"
        const isVerizonDecactive = isVerizonProvider && (updatedRow?.sim_status === "Deactive" || updatedRow?.sim_status === "Deactivated")
        const verizonActiveDetails = rowdata.map((item: any) => ({
          FirstName: updatedRow?.first_name || "",
          LastName: updatedRow?.last_name || "",
          BillingAccountNo: item?.billing_account_number || "",
          StreetNo: updatedRow?.address || "",
          StreetName: updatedRow?.address || "",
          StreetDirection: updatedRow?.address || "",
          City: updatedRow?.city || "",
          State: updatedRow?.state || "",
          ZipCode: updatedRow?.service_zip_code || "",
          IMEI: item?.imei || "",
          ReasonCode: "",
          EffectiveDate: isTelgencerovider ? updatedRow?.effective_date : getCurrentDateTime(),
          SubscriberNo: item?.msisdn || "",
        }))
        const verizonDeactiveDetails = {
          imei: updatedRow?.imei || "",
          revAccountNumber: updatedRow?.rev_customer_id || "",
          reasonCode: updatedRow?.reason_code || "CB"
        }
        const telegence_additional_details_ = rowdata.map((item: any) => ({
          FirstName: updatedRow?.first_name || "",
          LastName: updatedRow?.last_name || "",
          BillingAccountNo: item?.billing_account_number || "",
          StreetNo: updatedRow?.address || "",
          StreetName: updatedRow?.address || "",
          StreetDirection: updatedRow?.address || "",
          City: updatedRow?.city || "",
          State: updatedRow?.state || "",
          ZipCode: updatedRow?.service_zip_code || "",
          IMEI: item?.imei || "",
          ReasonCode: updatedRow?.reason_code || "CB",
          EffectiveDate: updatedRow?.effective_date || getCurrentDateTime(),
          SubscriberNo: item?.msisdn || "",
          RevAccountNumber: item?.account_number || "",

        }))
        let telegence_additional_details: any = "";

        if (isTelgencerovider) {
          telegence_additional_details = telegence_additional_details_;
        } else if (isVerizonActive) {
          telegence_additional_details = verizonActiveDetails;
        } else if (isVerizonDecactive) {
          telegence_additional_details = verizonDeactiveDetails;
        }
        data["changed_data"] = rowdata.map((item: any) => ({
          id: item.id,
          sim_status: updatedRow.sim_status,
          device_status_id: updatedRow?.device_status_id || null,
          iccid: item.iccid,
          modified_by: firstLastName,
          public_ip_restriction: updatedRow?.public_ip_restriction || "",
          ...( updatedRow?.reason_code && {reason_code: updatedRow?.reason_code}),
          ...(updatedRow?.activation_profile && { activation_profile: updatedRow.activation_profile }),
          ...(isKoreProvider ? { imei: updatedRow.imei } : { imei: item.imei }),
          telegence_additional_details,
          ...(updatedRow?.mode && {mode:updatedRow.mode}),
          ...(updatedRow?.rate_plan_code && {rate_plan_code:updatedRow?.rate_plan_code}),
          ... (isVerizonActive && {account_number:updatedRow.account_number}),
        }));
        if (updatedRow.sim_status === "Activated") {
          data["changed_data"]["date_activated"] = getCurrentDateTime();
        }
        data["changed_data"]["last_used_date"] = getCurrentDateTime();

      }
      if (event_type.toLowerCase().includes("update feature") ) {
        data["changed_data"] = rowdata.map((item: any) => ({
          id: item.id,
          effective_date: updatedRow.effective_date,
          // telegence_features: updatedRow.telegence_features || "",
          modified_by: firstLastName,
          configuration_change_details: updatedRow?.configuration_change_details || {},
          // mobility_configuration_ids: updatedRow?.mobility_configuration_ids || [],
        }));
      }
      if (event_type === "Line Sync") {
        // const iccid = updatedRow.map((item:any) => (item.iccid))
        data["changed_data"] = rowdata.map((item: any) => ({
          id: item.id,
          iccid: item.iccid,
          modified_by: firstLastName,
        }));
      }
      if (event_type === "Assign Customer") {
        data["changed_data"] = rowdata.map((item: any) => ({
          id: item.id,
          customer_name: updatedRow.customer_name,
          modified_by: firstLastName,
          service_type_id: updatedRow?.service_type_id || "",
          ...(moduleStatus ? { account_number: updatedRow.customer_id || "" } : { customer_id: updatedRow.customer_id || "" }),
          ...(isBPEnabled ? {
            customer_rate_plan_name: updatedRow.customer_rate_plan_name || "",
            customer_rate_pool_name: updatedRow.customer_rate_pool_name !== "None" ? updatedRow.customer_rate_pool_name : "",
            effective_date: updatedRow?.effective_date || "",
            ...(isSubTenant ? { sub_tenant_customer_rate_plan_name: updatedRow.customer_rate_plan_name || "" } : { sub_tenant_carrier_rate_plan_name: updatedRow.customer_rate_plan_name || "" })
          } : {})
        }));
      }
      if (event_type === "Change Phone Number") {
        data["changed_data"] = rowdata.map((item: any) => ({
          id: item.id,
          effective_date: updatedRow.effective_date,
          modified_by: firstLastName,
          old_msisdn: item?.msisdn || "",
          msisdn: item?.msisdn || ""
        }));
      }
      if (event_type === "Refresh A Line") {
        const billing_account_number = updatedRow?.billingAccountNumber || "";
        data["changed_data"] = rowdata.map((item: any) => ({
          id: item.id,
          iccid: item.iccid,
          refresh_a_line: {
            requestType: "resendOTAProfile",
            billingAccount: {
              "id": billing_account_number
            },
            serviceCharacteristic: [
              {
                "name": "sim",
                "value": ""
              }
            ]
          },
          modified_by: firstLastName,
        }));
      }
      if (event_type === "Update Communication Plan") {
        const communicationPlan_ = updatedRow?.communicationPlan || "";
        data["changed_data"] = rowdata.map((item: any) => ({
          id: item.id,
          iccid: item.iccid,
          Comm_plan_name:communicationPlan_ || "",
          modified_by: firstLastName,
        }));
      }
      if (event_type === "Update PPU address") {
        const user_address_ = updatedRow?.user_address || "";
        data["changed_data"] = rowdata.map((item: any) => ({
          id: item.id,
          iccid: item.iccid,
          msisdn: item.msisdn,
          user_address: { ...user_address_ },
          modified_by: firstLastName,
        }));
      }

      if (event_type === "Send SMS") {
        data["changed_data"] = rowdata.map((item: any) => ({
          id: item.id,
          iccid: item.iccid,
          message_text: updatedRow?.text_message || "",
          modified_by: firstLastName,
        }));
      }

       if (event_type === "Reset Voicemail Password") {
        data["changed_data"] = rowdata.map((item: any) => ({
          id: item.id,
          modified_by: firstLastName,
          billingAccount:updatedRow.billing_account_number,
          pin:updatedRow.new_voicemail_pin
        }));
      }

      if (event_type === "Change Private Static IP Address") {
        console.log("updatedRow",updatedRow)
        const getCurrentDateTimeFormatted = (): string => {
            const now = new Date();

            const pad = (num: number) => num.toString().padStart(2, '0');

            const month = pad(now.getMonth() + 1); // 10 → October
            const day = pad(now.getDate());        // 02
            const year = now.getFullYear();        // 2025

            const hours = pad(now.getHours());
            const minutes = pad(now.getMinutes());
            const seconds = pad(now.getSeconds());

            return `${month}-${day}-${year} ${hours}:${minutes}:${seconds}`;
        };
        const providerName =
          getTargetTenantProvider(
            rowdata[0]?.service_provider_display_name
          ).toLowerCase() || "";
        const isTelegence = providerName.toLowerCase().includes("telegence");
        const isVerizon =
          providerName.toLowerCase().includes("verizon") ||
          providerName.toLowerCase().includes("vzn") || 
          providerName.toLowerCase().includes("vzwcr") || 
          providerName.toLowerCase().includes("2215-so01");
        const isTeal = providerName.toLowerCase().includes("teal");
        let changedData = {};
        if (isTelegence) {
          changedData = {
            pdpName: updatedRow.pdp || "",
            billingAccountNumber: updatedRow.ban || "",
            subscriber: [
              {
                subscriberNumber: "",
                ipAddressRecord: {
                  ipAddress: updatedRow.ip_address || "",
                  ipAddressCode: "",
                  ipAddressType: "",
                },
                effectiveDate:
                  getCurrentDateTimeFormatted() || getCurrentDateTime(),
              },
            ],
          };
        } else if (isVerizon) {
          changedData = {
            apn: updatedRow.apn || "",
            pdpName: updatedRow.pdp || "",
            ipAddress: updatedRow.ip_address || "",
          };
        } else if (isTeal) {
          changedData = {
             ipAddress:updatedRow.ip_address || "",
          };
        } else {
          changedData = {
            ipv6Address: updatedRow.ip_address || "",
            apn: updatedRow.apn || "",
            pdpId: updatedRow.pdp || "",
          };
        }
        console.log("changeRequest",changedData)
        data["changed_data"] = rowdata.map((item: any) => ({
          id: item.id,
          iccid: item.iccid,
          modified_by: firstLastName,
          changeRequest : {...changedData}
        }));

        data["iccid_ip_map"] = rowdata.reduce((acc: any, item: any) => {
          acc[item.iccid] = updatedRow.ip_address;
          return acc;
        }, {});      
      }


      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        setLoading(false);
        if (parsedData.error_type && parsedData.error_type == "Warning") {
          console.log("parsedData.error_type", parsedData.error_type)
          Modal.warning({
            title: 'Warning',
            content: parsedData.message || 'An error occurred while submitting data. Please try again.',
            centered: true,
          });
          setIs2OFilterLoaded(false)

        }
        else {
          Modal.error({
            title: "Data Update Error",
            content: parsedData.message || "An error occurred while updating Inventory data. Please try again.",
            centered: true,
          });
          setIs2OFilterLoaded(false)
        }

      } else {
        // setIs2OFilterLoaded(false);
        // fetchDataInitial()
        await scheduleSingleFetch();
        closeModals()
        callSyncLambda()
        // fetchData();
        //  callFetchData(true)


      }

    } catch (error) {
      setLoading(false);
      console.error("Error fetching data:", error);
    }
    finally {
      setLoading(false);
      setIs2OFilterLoaded(false);
    }
  };
const scheduleSingleFetch = async () => {
  // 🔒 If already fetching, do NOTHING
  if (isFetchInProgressRef.current) {
    return;
  }

  isFetchInProgressRef.current = true;

  try {
    await fetchDataInitial();   // ✅ only ONE call allowed
  } finally {
    isFetchInProgressRef.current = false;
  }
};



// Don't forget to cleanup on unmount
useEffect(() => {
  return () => {
    if (fetchTimeoutRef.current) {
      clearTimeout(fetchTimeoutRef.current);
    }
  };
}, []);
  const closeModals = () => {
    setUpdateCarrierRatePlan(false);
    setUpdateCustomerRatePlan(false);
    setOpenInventoryEditCostCenterModal(false);
    setOpenUpdateFeatures(false);
    setOpenUpdateStatusModal(false);
    setOpenAssignCustomer(false)
    setOpenChangePhoneNumberModal(false)
    setOpenRefreshLineModal(false);
    setOpenCommPlanModal(false);
    setOpenSendSMSModal(false);
    setOpenPPUAddressModal(false);
    setopenResetVoiceMailPasswordModal(false)
    setopenPrivateNetworkIPModal(false)
    setOpenAllChangeTypesModal(false)
    setIsModalVisible(false) // Add this
  }


// ============================================
// COMPLETE sendUpdatedDataForMultipleRows Function
// Handles BOTH single and multiple rows for ALL change types
// ============================================

const sendUpdatedDataForMultipleRows = async (
  validRows: any[], 
  event_type: string, 
  updateData: any,
  moduleStatus?: boolean
) => {
  // Validate input
  if (!validRows || validRows.length === 0) {
    console.log(`⚠️ No valid rows provided for ${event_type}`);
    return;
  }

  console.log(`📤 Sending ${validRows.length} row(s) for ${event_type}`);

  const providerName = getTargetTenantProvider(validRows[0]?.service_provider_display_name).toLowerCase() || "";
  const isKoreProvider = providerName.includes("kore");
  const isVerizonProvider = (providerName.includes("verizon") || providerName.includes("vzn") || providerName.includes("vzwcr") || providerName.includes("2215-so01"))
  const isTelgenceProvider = providerName.includes("telegence");

  console.log("updateData...........", updateData, event_type );
  console.log("event_type.......", event_type );

  // Determine API path
  const path = event_type === "Update Carrier Rate Plan" ? "/update_carrier_rate_plan" 
    : event_type === "Update Customer Rate Plan" ? "/update_customer_rate_plan" 
    : event_type === "Edit Cost Center" ? "/edit_cost_center" 
    : event_type === "Update Device Status" ? "/update_status" 
    : event_type.toLowerCase().includes("update feature") ? "/update_features" 
    : event_type === "Line Sync" ? "/update_line_sync" 
    : event_type === "Assign Customer" ? "/update_assign_customer" 
    : event_type === "Change Phone Number" ? "/update_phone_number" 
    : event_type === "Refresh A Line" ? "/update_refresh_a_line" 
    :event_type === "Update Communication Plan" ? "/update_communication_plan"
    : event_type === "Update PPU Address" ? "/update_ppu_address" 
    :event_type === "Reset Voicemail Password" ? "/reset_voicemail_password"
    : event_type === "Send SMS" ? "/send_sms" // <-- new mapping
    :event_type === "Change Private Static IP Address" ? "/update_private_network_ip"
    : "";

  if (!path) {
    console.error(`❌ Unknown event type: ${event_type}`);
    return;
  }

  setLoading(true);
  setIs2OFilterLoaded(true);
  setShowInitialScreen(true);

  // Base data structure
  let data: any = {
    tenant_name: partner || "default_value",
    username: username,
    firstLastName: firstLastName,
    path: path,
    role_name: role,
    module_name: "SimManagement Inventory",
    feature_module_name: "Inventory",
    Partner: partner,
    access_token: token,
    db_name: selectedDb,
    sessionID: sessionId,
    table_name: "sim_management_inventory",
    service_provider_display_name: validRows[0]?.service_provider_display_name || '',
    carrier_api_status: true,
    change_event_type: event_type === "Update Customer Rate Plan" 
      ? "Change Customer Rate Plan" 
      : event_type === "Update Device Status" 
      ? "Update Status" 
      : event_type,
    request_received_at: getCurrentDateTime(),
    template_name: "Inventory Status Update",
    ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(rowdata[0]?.service_provider_display_name) : "" } 
  };

  try {
    const url = ENV_ROUTES.INVENTORY;

    // ============================================
    // 1. UPDATE CARRIER RATE PLAN
    // ============================================

    if (event_type === "Update Carrier Rate Plan") {
      const isCommpLan = !["webbing","multi-carrier sim", "teal", "telegence"].includes(
        providerName?.toLowerCase()
      );
      const isTelegence =providerName?.toLowerCase().includes("telegence");

      data["changed_data"] = validRows.map((item: any) => ({
        id: item.id,
        effective_date: updateData.effective_date,
        carrier_rate_plan_name: updateData.carrier_rate_plan_name || "",
        ...(isCommpLan ? { communication_plan: updateData.communication_plan || "" } : {}),
        ...(isTelegence ? { optimization_group: updateData.optimization_group || "" } : {}),
        modified_by: firstLastName,
      }));
    }

    // ============================================
    // 2. UPDATE CUSTOMER RATE PLAN
    // ============================================
    else if (event_type === "Update Customer Rate Plan") {
      data["changed_data"] = validRows.map((item: any) => ({
        id: item.id,
        effective_date: updateData.effective_date,
        customer_rate_plan_name: updateData.customer_rate_plan_name || "",
        customer_rate_pool_name: updateData.customer_rate_pool_name !== "None" 
          ? updateData.customer_rate_pool_name 
          : "",
        modified_by: firstLastName,
        ...(isSubTenant 
          ? { sub_tenant_customer_rate_plan_name: updateData.customer_rate_plan_name || "" } 
          : { sub_tenant_carrier_rate_plan_name: updateData.customer_rate_plan_name || "" }),
        ...(isBPEnabled ? {
          customer_name: updateData.customer_name,
          ...(moduleStatus 
            ? { account_number: updateData.customer_id || "" } 
            : { customer_id: updateData.customer_id || "" })
        } : {})
      }));
    }

    // ============================================
    // 3. EDIT COST CENTER
    // ============================================
    else if (event_type === "Edit Cost Center") {
      console.log("updateData222222", updateData, event_type );
      data["changed_data"] = validRows.map((item: any) => ({
        id: item.id,
        iccid: item.iccid,
        cost_center: updateData.cost_center || "",
        modified_by: firstLastName,
      }));
    }
    // ======================
      // SEND SMS
      // ======================
      else if (event_type === "Send SMS") {
        data["changed_data"] = validRows.map((item: any) => ({
          id: item.id,
          iccid: item.iccid,
          message_text: updateData.text_message || "",
          modified_by: firstLastName,
        }));
      }
    // ======================
      // RESET VOICEMAIL PASSWORD
      else if (event_type === "Reset Voicemail Password") {
        data["changed_data"] = validRows.map((item: any) => ({
        id: item.id,
        billingAccount:updateData.billing_account_number,
        pin:updateData.new_voicemail_pin
      }));
       
      }

      // ======================
      // PRIVATE NETWORK IP
      // else if (event_type === "Change Private Static IP Address") {
      //   data["changed_data"] = validRows.map((item: any) => ({
      //   id: item.id,
      //   iccid: item.iccid,
      //   modified_by: firstLastName,
      //    billingAccount:updateData.billing_account_number,
      //    ip_address:updateData.ip_address

      // }));
       
      // }
       if (event_type === "Change Private Static IP Address") {
        console.log("updatedRow",validRows)
        const getCurrentDateTimeFormatted = (): string => {
            const now = new Date();

            const pad = (num: number) => num.toString().padStart(2, '0');

            const month = pad(now.getMonth() + 1); // 10 → October
            const day = pad(now.getDate());        // 02
            const year = now.getFullYear();        // 2025

            const hours = pad(now.getHours());
            const minutes = pad(now.getMinutes());
            const seconds = pad(now.getSeconds());

            return `${month}-${day}-${year} ${hours}:${minutes}:${seconds}`;
        };
        const providerName =
          getTargetTenantProvider(
            rowdata[0]?.service_provider_display_name
          ).toLowerCase() || "";
        const isTelegence = providerName.toLowerCase().includes("telegence");
        const isVerizon =
          providerName.toLowerCase().includes("verizon") ||
          providerName.toLowerCase().includes("vzn") || 
          providerName.toLowerCase().includes("vzwcr") || 
          providerName.toLowerCase().includes("2215-so01");
        const isTeal = providerName.toLowerCase().includes("teal");
        let changedData = {};
        if (isTelegence) {
          changedData = {
            pdpName: updateData.pdp || "",
            billingAccountNumber: updateData.ban || "",
            subscriber: [
              {
                subscriberNumber: "",
                ipAddressRecord: {
                  ipAddress: updateData.ip_address || "",
                  ipAddressCode: "",
                  ipAddressType: "",
                },
                effectiveDate:
                  getCurrentDateTimeFormatted() || getCurrentDateTime(),
              },
            ],
          };
        } else if (isVerizon) {
          changedData = {
            ipAddress:updateData.ip_address || "",
          };
        } else if (isTeal) {
          changedData = {
             ipAddress:updateData.ip_address || "",
          };
        } else {
          changedData = {
            ipv6Address: updateData.ip_address || "",
            apn: updateData.apn || "",
            pdpId: updateData.pdp || "",
            billingAccount:updateData.billing_account_number,
          };
        }
console.log("changeRequest",changedData)
        data["changed_data"] = validRows.map((item: any) => ({
          id: item.id,
          iccid: item.iccid,
          modified_by: firstLastName,
          changeRequest : {...changedData}
        }));
      }

      // ======================
    // ============================================
    // 4. UPDATE DEVICE STATUS
    // ============================================
    else if (event_type === "Update Device Status") {
      const isVerizonActive = isVerizonProvider && updateData?.sim_status === "Active";
      const isVerizonDeactive = isVerizonProvider && 
        (updateData?.sim_status === "Deactive" || updateData?.sim_status === "Deactivated");

      // Prepare Verizon-specific details for active status
      const verizonActiveDetails = validRows.map((item: any) => ({
        FirstName: updateData?.first_name || "",
        LastName: updateData?.last_name || "",
        BillingAccountNo: item?.billing_account_number || "",
        StreetNo: updateData?.address || "",
        StreetName: updateData?.address || "",
        StreetDirection: updateData?.address || "",
        City: updateData?.city || "",
        State: updateData?.state || "",
        ZipCode: updateData?.service_zip_code || "",
        IMEI: item?.imei || "",
        ReasonCode: "",
        EffectiveDate: isTelgenceProvider ? updateData?.effective_date : getCurrentDateTime(),
        SubscriberNo: item?.msisdn || "",
      }));

      // Verizon deactivate details
      const verizonDeactiveDetails = {
        imei: updateData?.imei || "",
        revAccountNumber: updateData?.rev_customer_id || "",
        reasonCode: updateData?.reason_code || "CB"
      };

      // Telegence additional details
      const telegence_additional_details_ = validRows.map((item: any) => ({
        FirstName: updateData?.first_name || "",
        LastName: updateData?.last_name || "",
        BillingAccountNo: item?.billing_account_number || "",
        StreetNo: updateData?.address || "",
        StreetName: updateData?.address || "",
        StreetDirection: updateData?.address || "",
        City: updateData?.city || "",
        State: updateData?.state || "",
        ZipCode: updateData?.service_zip_code || "",
        IMEI: item?.imei || "",
        ReasonCode: updateData?.reason_code || "CB",
        EffectiveDate: updateData?.effective_date || getCurrentDateTime(),
        SubscriberNo: item?.msisdn || "",
        RevAccountNumber: item?.account_number || "",
      }));

      let telegence_additional_details: any = "";
      if (isTelgenceProvider) {
        telegence_additional_details = telegence_additional_details_;
      } else if (isVerizonActive) {
        telegence_additional_details = verizonActiveDetails;
      } else if (isVerizonDeactive) {
        telegence_additional_details = verizonDeactiveDetails;
      }

      data["changed_data"] = validRows.map((item: any) => ({
        id: item.id,
        sim_status: updateData.sim_status,
        device_status_id: updateData?.device_status_id || null,
        iccid: item.iccid,
        modified_by: firstLastName,
        public_ip_restriction: updateData?.public_ip_restriction || "",
        ...(updateData?.reason_code && { reason_code: updateData?.reason_code }),
        ...(updateData?.activation_profile && { activation_profile: updateData.activation_profile }),
        ...(isKoreProvider ? { imei: updateData.imei } : { imei: item.imei }),
        telegence_additional_details,
        ...(updateData?.mode && { mode: updateData.mode }),
        ...(updateData?.rate_plan_code && { rate_plan_code: updateData?.rate_plan_code }),
        ... (isVerizonActive && {account_number:updateData.account_number}),
      }));

      // Add activation date if status is Activated
      if (updateData.sim_status === "Activated") {
        data["changed_data"].forEach((item: any) => {
          item["date_activated"] = getCurrentDateTime();
        });
      }
      
      data["changed_data"].forEach((item: any) => {
        item["last_used_date"] = getCurrentDateTime();
      });
    }

    // ============================================
    // 5. UPDATE FEATURES
    // ============================================
    else if (event_type.toLowerCase().includes("update feature")) {
      data["changed_data"] = validRows.map((item: any) => ({
        id: item.id,
        effective_date: updateData.effective_date,
        modified_by: firstLastName,
        configuration_change_details: updateData?.configuration_change_details || {},
      }));
    }

    // ============================================
    // 6. LINE SYNC
    // ============================================
    else if (event_type === "Line Sync") {
      data["changed_data"] = validRows.map((item: any) => ({
        id: item.id,
        iccid: item.iccid,
        modified_by: firstLastName,
      }));
    }

    // ============================================
    // 7. ASSIGN CUSTOMER
    // ============================================
    else if (event_type === "Assign Customer") {
      data["billing_platform_flag"] = isBPEnabled;
      data["createRevService"] = updateData?.createRevService || "";
      data["ProviderId"] = updateData?.ProviderId || "";
      data["RevProductId"] = updateData?.RevProductId || "";
      data["RevPackageId"] = updateData?.RevPackageId || "";
      data["RateList"] = updateData?.RateList || [];
      data["Prorate"] = updateData?.Prorate || "";
      data["effective_date"] = updateData?.effective_date || "";
      data["useCarrierActivation"] = updateData?.useCarrierActivation || "";
      data["Description"] = updateData?.Description || "";

      data["changed_data"] = validRows.map((item: any) => ({
        
        id: item.id,
        customer_name: updateData.customer_name,
        modified_by: firstLastName,
        service_type_id: updateData?.service_type_id || "",
        ...(moduleStatus 
          ? { account_number: updateData.customer_id || "" } 
          : { customer_id: updateData.customer_id || "" }),
        ...(isBPEnabled ? {
          customer_rate_plan_name: updateData.customer_rate_plan_name === null ? null : updateData.customer_rate_plan_name || "",
          customer_rate_pool_name: updateData.customer_rate_pool_name !== "None" 
            ? updateData.customer_rate_pool_name 
            : "",
          effective_date: updateData?.effective_date || "",
          ...(isSubTenant 
            ? { sub_tenant_customer_rate_plan_name: updateData.customer_rate_plan_name || "" } 
            : { sub_tenant_carrier_rate_plan_name: updateData.customer_rate_plan_name || "" })
        } : {})
      }));
    }

    // ============================================
    // 8. CHANGE PHONE NUMBER
    // ============================================
    else if (event_type === "Change Phone Number") {
      data["changed_data"] = validRows.map((item: any) => ({
        id: item.id,
        effective_date: updateData.effective_date,
        modified_by: firstLastName,
        old_msisdn: item?.msisdn || "",
        msisdn: item?.msisdn || ""
      }));
    }

    // ============================================
    // 9. REFRESH A LINE
    // ============================================
    else if (event_type === "Refresh A Line") {
      const billing_account_number = updateData?.billingAccountNumber || "";
      
      data["changed_data"] = validRows.map((item: any) => ({
        id: item.id,
        iccid: item.iccid,
        refresh_a_line: {
          requestType: "resendOTAProfile",
          billingAccount: {
            "id": billing_account_number
          },
          serviceCharacteristic: [
            {
              "name": "sim",
              "value": ""
            }
          ]
        },
        modified_by: firstLastName,
      }));
    }

    //Update Communication Plan
    if (event_type === "Update Communication Plan") {
      const communicationPlan_ = updateData?.communicationPlan || "";
        data["changed_data"] = validRows.map((item: any) => ({
          id: item.id,
          iccid: item.iccid,
          Comm_plan_name:communicationPlan_ || "",
          modified_by: firstLastName,
        }));
      }

    // ============================================
    // 10. UPDATE PPU ADDRESS
    // ============================================
    else if (event_type === "Update PPU Address") {
      const user_address_ = updateData?.user_address || "";
      
      data["changed_data"] = validRows.map((item: any) => ({
        id: item.id,
        iccid: item.iccid,
        msisdn: item.msisdn,
        user_address: { ...user_address_ },
        modified_by: firstLastName,
      }));
    }


    // ============================================
    // SEND REQUEST
    // ============================================
    console.log(`🚀 Submitting ${event_type} for ${validRows.length} row(s)`);
    if(isAllChangeType){
      set_all_2_0_payloads((prev: any) => ({
        ...prev,
        [event_type]: { ...data }
      }));
      return
    }
    const response = await axios.post(url, { data });
    const parsedData = JSON.parse(response.data.body);

    if (parsedData.flag === false) {
      setLoading(false);
      if (parsedData.error_type && parsedData.error_type === "Warning") {
        Modal.warning({
          title: 'Warning',
          content: parsedData.message || `An error occurred while submitting ${event_type}.`,
          centered: true,
        });
      } else {
        Modal.error({
          title: "Data Update Error",
          content: parsedData.message || `An error occurred while updating ${event_type}.`,
          centered: true,
        });
      }
      setIs2OFilterLoaded(false);
    } else {
      console.log(`✅ ${event_type} submitted successfully for ${validRows.length} row(s)`);
      await scheduleSingleFetch();
      closeModals()
      callSyncLambda();
    }
  } catch (error) {
    setLoading(false);
    console.error(`❌ Error submitting ${event_type}:`, error);
    Modal.error({
      title: "Submission Error",
      content: error instanceof Error ? error.message : `An unexpected error occurred while submitting ${event_type}.`,
      centered: true,
    });
  } finally {
    setLoading(false);
    setIs2OFilterLoaded(false);
    setOpenAllChangeTypesModal(false)
  }
};
const validateRowsForAllChangeTypes = () => {
  const processable: any[] = [];
  const nonProcessable: any[] = [];
  const changeTypeValidCount: Record<string, number> = {};

  // ✅ NEW: Include change types from successFullChangeTypes AND check allChangetypeOptionsinStore for "Line Sync"
  const changeTypesToValidate = [...successFullChangeTypes];
  if (allChangetypeOptionsinStore.includes("Line Sync") && !changeTypesToValidate.includes("Line Sync")) {
    changeTypesToValidate.push("Line Sync");
  }

  // Initialize counters
  changeTypesToValidate.forEach((changeType: string) => {
    changeTypeValidCount[changeType] = 0;
  });

  rowdata.forEach((row) => {
    const rowValidation: any = {
      iccid: row.iccid,
      sim_status: row.sim_status,
      service_provider_display_name: row.service_provider_display_name,
    };

    let canProcessAny = false;

    changeTypesToValidate.forEach((changeType: string) => {
      const canProcess = canProcessChangeType(
        row,
        changeType,
        partner || "",
        getTargetTenantProvider
      );
      rowValidation[changeType] = canProcess;

      if (canProcess) {
        canProcessAny = true;
        changeTypeValidCount[changeType]++;
      }
    });

    if (canProcessAny) {
      processable.push(rowValidation);
    } else {
      nonProcessable.push(rowValidation);
    }
  });

  // Log summary
  console.log("📊 Validation Summary:");
  changeTypesToValidate.forEach((changeType: string) => {
    const count = changeTypeValidCount[changeType];
    console.log(`  - ${changeType}: ${count}/${rowdata.length} valid rows`);
  });

  setProcessableRows(processable);
  setNonProcessableRows(nonProcessable);
  setSelectedChangeTypes(changeTypesToValidate);

  return { processable, nonProcessable, changeTypeValidCount };
};
// Add handler for validation modal submit
// Update handleValidationSubmit function

type SequenceType = {
        type: string;
        order: number;
    };

  const getSequenceForProvider = (
    provider: string
  ): SequenceType[] => {
    const uniqueMap = new Map<string, number>();

    SequenceMap.forEach((item: any) => {
      if (item.service_provider === provider) {
        // keep the lowest sequence if duplicates exist
        if (
          !uniqueMap.has(item.change_type) ||
          item.change_type_sequence < uniqueMap.get(item.change_type)!
        ) {
          uniqueMap.set(item.change_type, item.change_type_sequence);
        }
      }
    });

    return Array.from(uniqueMap.entries())
      .map(([type, order]) => ({ type, order }))
      .sort((a, b) => a.order - b.order);
  };

  const submitAllPayloads = async (all_2_0_payloads_: any) => {
    let parsedData: any
    const url = ENV_ROUTES.BULKCHANGE_PROCESSOR;
    const data = {
      tenant_name: partner || "default_value",
      username,
      path: "/all_change_types_scheduler",
      role_name: role,
      parent_module: "Sim Management",
      module_name: "Bulk Change",
      service_provider: selectedServiceProvider || "",
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
      change_type: "All Change Types",
      All_change_types: { ...all_2_0_payloads_ },
      source:"inventory"
    };

    try {
      // setLoading(true);
      const response = await axios.post(url, { data });
      parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === true) {
        console.log("submitAllPayloads success")
      }
    } catch (error) {
      console.error("submitAllPayloads failed");
      return false;
    } finally {
      // setLoading(false);
    }
  };

const handleValidationSubmit = async () => {
  setShowValidationModal(false);

  // ✅ NEW: Include change types from allChangetypeOptionsinStore
  const changeTypesToProcess = [...successFullChangeTypes];
  if (allChangetypeOptionsinStore.includes("Line Sync") && !changeTypesToProcess.includes("Line Sync")) {
    changeTypesToProcess.push("Line Sync");
  }

  const changeTypeToValidRows: Record<string, any[]> = {};
  changeTypesToProcess.forEach((changeType: string) => {
    const validRows = rowdata.filter((row: any) =>
      canProcessChangeType(row, changeType, partner || "", getTargetTenantProvider)
    );
    if (validRows.length > 0) {
      changeTypeToValidRows[changeType] = validRows;
    }
  });

  if (Object.keys(changeTypeToValidRows).length === 0) return;

  // ✅ Show loader while fetching carrier writes flag
  setLoading(true);
  setIs2OFilterLoaded(true);

  const writes_flag = await fetchCarrierWritesFlag();

  // ✅ Hide loader after getting the flag
  setLoading(false);
  setIs2OFilterLoaded(false);

const processAll = () => {
  // ✅ Show loader again when actually processing
  setLoading(true);
  setIs2OFilterLoaded(true);

  Object.entries(changeTypeToValidRows).forEach(([changeType, validRows]) => {

    // 🔥 Normalize the key (case-insensitive, trim, remove possible colon)
    const normalizedKey = changeType.trim().toLowerCase().replace(/:$/, "");

    // 🔑 Fetch using normalized key
    let updateDataForThisType = lastUpdatedRowByType[changeType];

    // 🩹 Special case fix for Update Features (API sends text different)
    if (!updateDataForThisType && changeType.toLowerCase().includes("update feature")) {
      updateDataForThisType = lastUpdatedRowByType["Update feature"]
                            || lastUpdatedRowByType["Update Feature"]
                            || lastUpdatedRowByType["Update Features"];
    }

    if (!updateDataForThisType) {
      // ✅ NEW: Skip validation for "Line Sync" since it doesn't have form data
      if (changeType === "Line Sync") {
        console.log(`Processing Line Sync without form data`);
        sendUpdatedDataForMultipleRows(validRows, changeType, {});
        if (writes_flag) submitCarrierStatus(changeType, writes_flag);
        return;
      }

      console.error(`No update data found for ${changeType}`);
      return;
    }

    console.log(`Processing ${changeType} with its specific data:`, updateDataForThisType);

    // 🚀 Pass normalized change type to API
    sendUpdatedDataForMultipleRows(validRows, changeType, updateDataForThisType);

    if (writes_flag) submitCarrierStatus(changeType, writes_flag);
  });

  const originalOrder = getSequenceForProvider(serviceProviders[0] || "");

  const originalOrderMap = new Map(
    originalOrder.map(item => [item.type.trim(), item.order])
  );

  const selectedChangeTypesOrder = selectedChangeTypes
    .map(type => ({
      type,
      order: originalOrderMap.get(type.trim())
    }))
    .filter(item => item.order !== undefined)
    .sort((a, b) => a.order! - b.order!)
    .map((item, index) => ({
      type: item.type,
      order: index + 1
    }));
  const orderMap = new Map<string, number>();
  selectedChangeTypesOrder.forEach(({ type, order }) => {
    orderMap.set(type, order);
  });

  if (isAllChangeType) {
    const latestPayloads = useInventoryAllChangeTypesStore.getState().all_2_0_payloads;
    console.log("latestPayloads", latestPayloads)

    // Step 4: Collect valid items
    const tempArray: {
      type: string;
      order: number;
      payload: any;
    }[] = [];

    Object.entries(changeTypeToValidRows).forEach(([changeType, validRows]) => {
      const payload = latestPayloads?.[changeType];

      console.log("payload_2_0", changeType, payload);
      if (payload && Object.keys(payload).length > 0) {
        tempArray.push({
          type: changeType,
          order: orderMap.get(changeType)!,
          payload: { ...payload },
        });
      }
    })

    // Step 5: Sort by order
            tempArray.sort((a, b) => a.order - b.order);

            // Step 6: Convert to required object format
            const orderedPayload: Record<string, any> = {};

            tempArray.forEach((item, index) => {
                orderedPayload[(index + 1).toString()] = {
                    ...item.payload,
                };
            });

            console.log("Final Ordered Payload:", orderedPayload);
            submitAllPayloads(orderedPayload)

  }

};


  if (writes_flag) {
    Modal.confirm({
      title: "Carrier API Enabled",
      content:
        "Carrier API settings are enabled. Submitting now will trigger the Carrier API call directly. Do you want to proceed?",
      centered: true,
      onOk: processAll,
      onCancel: () => {
        // ✅ Ensure loader is hidden if user cancels
        setLoading(false);
        setIs2OFilterLoaded(false);
      }
    });
  } else {
    processAll();
  }
};
const COMMON_FIELDS_MAP: Record<string, string[]> = {
  "Assign Customer|Update Customer Rate Plan": [
    "customer_name",
    "customer_rate_plan_name",
    "customer_rate_pool_name", 
  ],
  // Add more common field mappings as needed
  // "ChangeType1|ChangeType2": ["field1", "field2"]
};

// Helper function to get field display name
const getFieldDisplayName = (fieldName: string): string => {
  const displayNames: Record<string, string> = {
    customer_name: "Customer Name",
    customer_rate_plan_name: "Customer Rate Plan",
    customer_rate_pool_name: "Customer Rate Pool",
    // Add more field display names as needed
  };
  return displayNames[fieldName] || fieldName;
};
const validateCommonFields = (): { isValid: boolean; errors: string[] } => {
  console.log("customerRatePlanData",customerRatePlanData)
  console.log("assignCustomerData",assignCustomerData)

  const errors: string[] = [];
  const processedPairs = new Set<string>(); // Track processed pairs to avoid duplicates
  
  // Get all selected change types that have data (remove duplicates)
  const selectedTypes = [...new Set(successFullChangeTypes)] as string[];
  
  if (selectedTypes.length < 2) {
    return { isValid: true, errors: [] };
  }

  // Check each pair of change types for common fields
  for (let i = 0; i < selectedTypes.length; i++) {
    for (let j = i + 1; j < selectedTypes.length; j++) {
      const type1: string = selectedTypes[i];
      const type2: string = selectedTypes[j];
      
      // Create a unique key for this pair (sorted alphabetically to avoid duplicates)
      const pairKey = [type1, type2].sort().join('|');
      
      // Skip if we've already processed this pair
      if (processedPairs.has(pairKey)) {
        continue;
      }
      
      processedPairs.add(pairKey);
      
      // Create keys for lookup (both orders)
      const key1 = `${type1}|${type2}`;
      const key2 = `${type2}|${type1}`;
      
      const commonFields = COMMON_FIELDS_MAP[key1] || COMMON_FIELDS_MAP[key2];
      
      if (commonFields && commonFields.length > 0) {
        // Get data for both change types
        const data1 = customerRatePlanData;
        const data2 = assignCustomerData;
        
        if (!data1 || !data2) continue;
        
        // Check each common field
        const mismatchedFields: string[] = [];
        
        commonFields.forEach(field => {
          const value1 = data1[field];
          const value2 = data2[field];
          
          // Handle null, undefined, empty string, and "None" as equivalent
          const normalizeValue = (val: any) => {
            if (val === null || val === undefined || val === "" ) {
              return null;
            }
            return val;
          };
          
          const normalizedValue1 = normalizeValue(value1);
          const normalizedValue2 = normalizeValue(value2);
          if (normalizedValue1 === null || normalizedValue2 === null) {
            return; // skip mismatch
          }
          // Compare normalized values
          if (normalizedValue1 !== normalizedValue2) {
            mismatchedFields.push(getFieldDisplayName(field));
          }
        });
        
        if (mismatchedFields.length > 0) {
          errors.push(
            `${type1} and ${type2} have mismatched values for: ${mismatchedFields.join(", ")}`
          );
        }
      }
    }
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
};
const updateChanges = async (updatedRow: any, event_type: any, moduleStatus?: boolean) => {
  console.log("updateChanges called with event_type:", event_type, "updatedRow:", updatedRow);
 
  if (isAllChangeType) {
    console.log("All Change Types mode - storing update data");
   
    // ✅ Store by event_type key
    setLastUpdatedRowByType(prev => ({
      ...prev,
      [event_type]: updatedRow
    }));
    
    console.log("successFullChangeTypes", successFullChangeTypes);
    // 🛠 Special handling only for Update Feature
    if (event_type.toLowerCase().includes("update feature")) {
      // skip normal includes check (allow it to pass even with mismatch)
      // but still prevent if no saved valid change exists at all
      if (!successFullChangeTypes.some((x: string) => x.toLowerCase().includes("update feature"))) {
        console.log(`Validation failed or not completed for ${event_type}, skipping API call`);
        return;
      }
    } 
    // 🧠 Normal check for the rest
    else if (!successFullChangeTypes.includes(event_type)) {
      console.log(`Validation failed or not completed for ${event_type}, skipping API call`);
      return;
    }


    console.log(`Validation passed for ${event_type}`);
    
    // ✅ NEW: Only proceed to carrier check if isSubmit is true
    if (!isSubmit) {
      console.log("Not final submit yet, just storing data");
      return; // Exit here - don't call carrier API yet
    }
    
    console.log("Final submit - proceeding with carrier API check");
  }

  // ✅ Validation check before carrier API (ONLY runs when isSubmit=true)
  if (isAllChangeType && isSubmit) {
    console.log("Final submit triggered - validating all rows against all change types");
    console.log("successFullChangeTypes", successFullChangeTypes);
    const commonFieldValidation = validateCommonFields();
    const uniqueChangeTypes = [...new Set(successFullChangeTypes)];

    if (uniqueChangeTypes.includes("Update Carrier Rate Plan") &&
      uniqueChangeTypes.includes("Update Communication Plan")) {
      const carrierCommPlan_ = commPlanChanges?.carrierCommPlan
      const CommPlan_ = commPlanChanges?.commPlan
      if (carrierCommPlan_ && CommPlan_ && carrierCommPlan_ !== CommPlan_) {
        commonFieldValidation.isValid = false
        commonFieldValidation.errors.push(
          `Update Carrier Rate Plan and Update Communication Plan have mismatched values for: Communication Plan`
        );
      }
    }
    if (!commonFieldValidation.isValid) {
      // Show error modal with all mismatched fields
      Modal.warning({
        title: 'Common Fields Validation',
        content: (
          <div>
            <ul className="list-none pl-0">
              {commonFieldValidation.errors.map((error, index) => (
                <li key={index} className="mb-2">{error}</li>
              ))}
            </ul>
          </div>
        ),
        centered: true,
        width: 600,
      });

      
      // Reset submit flags
      setIsSubmit(false);
      setLoading(false);
      setIs2OFilterLoaded(false);
      
      return; // Stop submission
    }
    // Validate all rows against all successful change types
    validateRowsForAllChangeTypes();
    
    // Show validation modal
    setShowValidationModal(true);
    return; // Exit here, will continue after user clicks Submit in modal
  }

  // ✅ For All Change Type mode, only the FIRST validated change type should trigger the carrier check
  if (isAllChangeType) {
    // If this is not the first change type in the success list, skip entirely
    const firstValidatedType = successFullChangeTypes[0];
    if (event_type !== firstValidatedType) {
      console.log(`${event_type} is not first in queue, will be processed with first type`);
      return; // ✅ Don't send data - wait for first type to handle everything
    }

    // ✅ This is the first change type - do the carrier check once
    console.log(`${event_type} is first validated type, checking carrier writes flag`);
    setIs2OFilterLoaded(true);
    const writes_flag = await fetchCarrierWritesFlag();
    setIs2OFilterLoaded(false);

    if (writes_flag) {
      Modal.confirm({
        title: "Carrier API Enabled",
        content:
          "Carrier API settings are enabled. Submitting now will trigger the Carrier API call directly. Do you want to proceed?",
        centered: true,
        onOk: () => {
          // ✅ Process ALL validated change types together
          successFullChangeTypes.forEach((type: any) => {
            console.log(`Processing ${type} with carrier API`);
            sendUpdatedData(updatedRow, type, moduleStatus);
            submitCarrierStatus(type, writes_flag);
          });
        },
        onCancel: () => {},
      });
    } else {
      // ✅ No carrier writes - process all change types immediately
      successFullChangeTypes.forEach((type: any) => {
        console.log(`Processing ${type} without carrier API`);
        sendUpdatedData(updatedRow, type, moduleStatus);
      });
    }
    
    return; // ✅ Important: Exit after handling all change types
  }

  // ✅ Original flow for non-All Change Type mode
  setIs2OFilterLoaded(true);
  const writes_flag = await fetchCarrierWritesFlag();

  if (writes_flag) {
    setIs2OFilterLoaded(false);

    Modal.confirm({
      title: "Carrier API Enabled",
      content:
        "Carrier API settings are enabled. Submitting now will trigger the Carrier API call directly. Do you want to proceed?",
      centered: true,
      onOk: () => {
        sendUpdatedData(updatedRow, event_type, moduleStatus);
        submitCarrierStatus(event_type, writes_flag);
      },
      onCancel: () => {},
    });
  } else {
    sendUpdatedData(updatedRow, event_type, moduleStatus);
  }
};

  const renderContent = () => {
    // setIsModalVisible
    switch (selectedAction) {
      case "Update Carrier Rate Plan":
        return (
          <UpdateCarrierRatePlan
            rowData={rowdata[0]}
            visible={openUpdateCarrierRatePlan}
            onCancel={handleCancel}
            onUpdate={updateChanges}
            is2OChange={true}
          />
        );
      case "Edit Cost Center":
        return (
          <InventoryEditCostCenterModal
            rowData={rowdata[0] || {}}
            visible={openInventoryEditCostCenterModal}
            onCancel={handleCancel}
            onUpdate={updateChanges}
            is2OChange={true}
          />
        );
  
      case "Update Customer Rate Plan": // Add this case
        return (
          <UpdateCustomerRatePlan
            rowData={rowdata[0]}
            visible={openUpdateCustomerRatePlan}
            onCancel={handleCancel}
            onUpdate={updateChanges}
            is2OChange={true}
          />
        );
      case "Update Device Status":
        return (
          <UpdateStatusModal
            rowData={rowdata[0] || {}}
            visible={openUpdateStatusModal}
            onCancel={handleCancel}
            onUpdate={updateChanges}
            is2OChange={true}
          />
        );
      case "Update Features":
        return (
          <UpdateFeaturesModal
            rowData={rowdata[0] || {}}
            visible={openUpdateFeaturesModal}
            onCancel={handleCancel}
            onUpdate={updateChanges}
            is2OChange={true}
          />
        );
      case "Assign Customer":
        return (
          <AssignCustomerModal
            rowData={rowdata[0] || {}}
            visible={openAssignCustomerModal}
            onCancel={handleCancel}
            onUpdate={updateChanges}
            is2OChange={true}
          />
        );
      case "Change Phone Number":
        return (
          <UpdatePhoneNumberModal
            rowData={rowdata[0] || {}}
            visible={openChangePhoneNumberModal}
            onCancel={handleCancel}
            onUpdate={updateChanges}
          />
        );
      case "Refresh A Line":
        return (
          <RefreshLineModal
            rowData={rowdata[0] || {}}
            visible={openRefreshLineModal}
            onCancel={handleCancel}
            onUpdate={updateChanges}
          />
        );
      
      case "Update Communication Plan":
        return (
          <UpdateCommunicationPlanModal
            rowData={rowdata[0] || {}}
            visible={openCommPlanModal}
            onCancel={handleCancel}
            onUpdate={updateChanges}
            is2OChange={true}
          />
        );

      case "Update PPU Address":
        return (
          <UpdatePPUAddressModal
            rowData={rowdata[0] || {}}
            visible={openPPUAdressModal}
            onCancel={handleCancel}
            onUpdate={updateChanges}
            is2OChange={true}

          />
        );
      case "Reset Voicemail Password":
        return(
           <ResetVoicemailPassword
            rowData={rowdata[0] || {}}
            visible={openResetVoiceMailPasswordModal}
            onCancel={handleCancel}
            onUpdate={updateChanges}
            is2OChange={is_2_0_flow}
            isSingle={true}/>
        )

      case "Send SMS":
        return (
          <SendSMSModal
            rowData={rowdata[0] || {}}
            visible={openSendSMSModal}
            onCancel={handleCancel}
            onUpdate={updateChanges}
            is2OChange={true}
          />
        );

      case "Change Private Static IP Address":
        return (
          <PrivateNetworkIPModal 
           rowData={rowdata[0] || {}}
            visible={openPrivateNetworkIPModal}
            onCancel={handleCancel}
            onUpdate={updateChanges}
            is2OChange={true}
            />
        )

      case "All Change Types":
        return (
          <AllChangeTypesModal
          visible={openAllChangeTypesModal}
          onCancel={handleCancel}
          onBack={() => setShowInitialScreen(true)}
          onUpdate={updateChanges}
          rowData={rowdata}
          serviceProvider={selectedServiceProvider}
          // changeTypeOptions={changeTypeOptions.filter((option: string) => option !== "All Change Types")}
            changeTypeOptions={
        changeTypeOptions
          .filter((option: string) => option !== "All Change Types")
          .filter((option: string) =>
            rowdata.length > 1
              ? option !== "Change Private Static IP Address" // ❌ remove when multi-selection
              : true // ✔ keep it for single row
          )
      }
          
          // allChangeTypes={unfilteredChangeTypes} // Pass unfiltered options
          allChangeTypes={
  rowdata.length > 1
    ? unfilteredChangeTypes.filter(
        (option: string) => option !== "Change Private Static IP Address"
      )
    : unfilteredChangeTypes
}


        />
        )
      // case "Line Sync":
      //   return (
      //     <IndividualLineSyncModal
      //       rowData={rowdata[0] || {}}
      //       visible={openIndividualLineSyncModal}
      //       onCancel={handleCancel}
      //       onUpdate={updateChanges}
      //     />
      //   );
      case "select-devices":
        return null;

      default:
        return null;
    }
  };

  const modalWidth = typeof window !== 'undefined' ? (window.innerWidth * 2.5) / 4 : 0;
  const modalHeight =
    typeof window !== "undefined" ? (window.innerHeight * 3) / 4 : 0;
  // if (loading) {
  //     return (
  // <>
  //     <Modal
  //         title="Loading"
  //         visible={isModalVisible}
  //         onCancel={handleCancel}
  //         footer={null}
  //         width={modalWidth}
  //         centered
  //     >
  //         <div className="flex justify-center items-center h-[400px]">
  //             <Spin size="large" />
  //         </div>
  //     </Modal>
  // </>
  //     );
  // }

  return (
    <>
      <button className={`flex items-center ${rowdata.length === 0 ? "cancel-btn" : "save-btn"}`} onClick={showModal} disabled={rowdata.length === 0}>
        {/* <PlusIcon className="h-5 w-5 text-black-500" /> */}
        <span>Update</span>
      </button>

      <>
        {/* Parent Modal */}
        <Modal
          title={`Change Type: ${selectedAction ? selectedAction : ''}`}
          visible={isModalVisible}
          onCancel={handleCancel}
          footer={null}
          width={'550px'}
          centered
          maskClosable={false}
          styles={{ body: { height: 'auto' } }}
        >
          <div className="modal-content container pt-3">
            {loading || is2OFilterLoaded ? (
              <div className="flex justify-center items-center h-[250px]">
                <Spin size="large" />
              </div>
            ) : (
              showInitialScreen && (
                <div className="flex flex-col space-y-4">
                  <div>
                    <label htmlFor="serviceProvider" className="field-label">
                      Service Provider <span className="text-red-500">*</span>
                    </label>
                    <Input
                      value={selectedServiceProvider || ''}
                      className="input"
                      id="serviceProvider"
                      readOnly
                    />
                    {errorMessage && !selectedServiceProvider && (
                      <div>
                        <span className="text-red-500 mt-2">Please Select Service Provider</span>
                      </div>
                    )}
                  </div>

                  <div>
                    <label htmlFor="action" className="field-label">
                      Change Type <span className="text-red-500">*</span>
                    </label>
                    <Select
                      id="action"
                      options={changeTypeOptions.map((option: string) => ({
                        label: option,
                        value: option,
                      }))}
                      value={{ label: selectedAction, value: selectedAction }}
                      onChange={handleSelectAction}
                      placeholder="Select Change Type"
                      styles={editableDrp}
                      isClearable
                    />
                    {errorMessage && !selectedAction && (
                      <div>
                        <span className="text-red-500 mt-2">Please Select Change Type</span>
                      </div>
                    )}
                    
                  </div>

                  <div className="justify-center flex space-x-4">
                    <button onClick={handleCancel} className="cancel-btn">
                      Cancel
                    </button>
                    <button onClick={handleContinue} className="save-btn">
                      {selectedAction === "Line Sync" || (selectedServiceProvider.toLowerCase().includes("teal") &&  selectedAction === "Change Private Static IP Address")  ? "Submit" : "Continue"}
                      {/* // {selectedServiceProvider === "isTeal" && selectedAction === "Change Private Static IP Address"? "Submit": "Continue"} */}
                    </button>
                  </div>
                </div>
              ))}

          </div>
        </Modal>
        {/* All Change Types Modal */}
        {/* <AllChangeTypesModal
          visible={openAllChangeTypesModal}
          onCancel={handleCancel}
          onUpdate={updateChanges}
          rowData={rowdata}
          serviceProvider={selectedServiceProvider}
          changeTypeOptions={changeTypeOptions.filter((option: string) => option !== "All Change Types")}
        /> */}
        {rowdata.length !== 0 && (
        renderContent()

        )}

        {/* Other modals or components can be added here based on the selected action */}
      </>
       <ValidationTableModal
      visible={showValidationModal}
      onCancel={() => setShowValidationModal(false)}
      onSubmit={handleValidationSubmit}
      processableRows={processableRows}
      nonProcessableRows={nonProcessableRows}
      changeTypes={selectedChangeTypes}
    />

    </>
  );

};

export default NewChange2;