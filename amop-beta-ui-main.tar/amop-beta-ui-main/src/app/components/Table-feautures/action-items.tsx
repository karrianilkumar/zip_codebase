import React, { useMemo, useState, useCallback, useEffect } from "react";
import {
  Dropdown,
  Menu,
  Modal,
  notification,
  Space,
  Spin,
  Tooltip,
} from "antd";
import { MoreOutlined } from "@ant-design/icons";
import UpdateStatusModal from "./update-status"; // Adjust path as per your application structure
import UpdateCarrierRatePlan from "./update-carrier-rate-plan";
import UpdateCustomerRatePlan from "./update-customer-rate-plan";
import UpdateFeaturesModal from "./update_features";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import AssignCustomerModal from "./assign-customer";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import EditCostCenter from "./edit-cost-center";
import InventoryEditCostCenterModal from "./invenotory-edit-cost-center";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import UpdatePhoneNumberModal from "./update-phone-number";
import RefreshLineModal from "./refresh-line";
import UpdateCommunicationPlanModal from "./update-communication-plan";
import UpdatePPUAddressModal from "./update-ppu-address";
import UpdateFeaturesModal_2_0 from "./2_0_update_features";
import { PerformanceLogStore } from "@/app/stores/performance_matrix_store";
import SendSMS from "./update_send_sms";
import ResetVoicemailPassword from "./update_reset_voice_mail_password";
import UpdatePrivateNetworkModal from "./update_private_network";
import { fireSideCannons } from "@/app/components/confetti";

interface ActionItemsProps {
  initialData: any;
  currentPage: number;
  itemsPerPage: number;
  index: number;
  rowData?: any;
  is_2_0_flow: boolean;
}

interface ItemType {
  key: string;
  label: string;
}

const simManagementInventoryActionItem = (
  is_2_0_flow: boolean,
  record?: { [key: string]: any },
  partner?: any,
  moduleFeatures?: any,
  rowData?: any,
) => {
  const { getTargetTenantProvider } = PerformanceLogStore();
  const results: ItemType[] = [];
  const isActivated = (rowData.sim_status && (rowData.sim_status.toUpperCase() === "ACTIVATED" || rowData.sim_status.toUpperCase() === "ACTIVE" || rowData.sim_status.toUpperCase() === "A" || rowData.sim_status.toUpperCase() === "ONLINE" || rowData.sim_status.toUpperCase() === "ACTIVATE"));

  if (record && rowData?.service_provider_display_name) {
    const providerName = getTargetTenantProvider(rowData?.service_provider_display_name).toUpperCase() || "";
    const allowedProviders = [
      "AT&T - POD19",
      "WEBBING",
      "MULTI-CARRIER SIM",
      "VERIZON - THINGSPACE IOT",
      "AT&T - CISCO JASPER",
      "AT&T - TELEGENCE - UAT ONLY",
      "ROGERS SANDBOX"
    ];

    const hasAllowedProvider = allowedProviders.some(provider =>
      providerName.includes(provider.toUpperCase())
    );

    // if (hasAllowedProvider) {
    if (moduleFeatures?.includes("Line Sync-Inventory")) {
      results.push({
        key: "line-sync",
        label: "Line Sync"
      });
    }
    // }

    if (rowData && providerName && providerName.includes("AT&T - TELEGENCE")) {
      const isActiveOrRestore = isActivated || (rowData.sim_status && (rowData.sim_status.toUpperCase() === "RESTORE SUSPENDED"));

      if (moduleFeatures?.includes("Update Device Status-Inventory")) {
        results.push({
          key: "update-status",
          label: "Update Device Status",
        });
      }

      if (moduleFeatures?.includes("Edit cost center-Inventory")) {
        results.push({
          key: "inventory-edit-cost-center",
          label: "Edit Cost Center"
        });
      }
     
      if (moduleFeatures?.includes("Reset Voicemail Password-Inventory")) {
        results.push({
          key: "reset-voice-mail-password",
          label: "Reset Voicemail Password"
        });
      }

       if (moduleFeatures?.includes("Change Private Static IP Address-Inventory")) {
        results.push({
          key: "private-network-ip",
          label: "Change Private Static IP Address"
        });
      }

      if (isActiveOrRestore && moduleFeatures?.includes("Update carrier rate plan-Inventory")) {
        results.push({
          key: "update-carrier-rate-plan",
          label: "Update Rate Plan",
        });
      }

      if (isActiveOrRestore && moduleFeatures?.includes("Update customer rate plan-Inventory")) {
        results.push({
          key: "update-customer-rate-plan",
          label: "Update Customer Rate Plan",
        });
      }

      if (isActiveOrRestore && moduleFeatures?.includes("Assign customer-Inventory")) {
        results.push({
          key: "assign-customer",
          label: "Assign Customer"
        });
      }

      if (isActiveOrRestore && moduleFeatures?.includes("Update features-Inventory")) {
        results.push({
          key: "update-features",
          label: "Update Features"
        });
      }

      if (isActiveOrRestore && moduleFeatures?.includes("Refresh A Line-Inventory")) {
        results.push({
          key: "refresh-line",
          label: "Refresh A Line"
        });
      }

      if (moduleFeatures?.includes("Update PPU address-Inventory")) {
        results.push({
          key: "update-ppu-address",
          label: "Update PPU address"
        });
      }

      // if (moduleFeatures?.includes("Edit cost center-Inventory")) {
      //   if (partner === "Titanium - AWX") {
      //     results.push({
      //       key: "update-cost-center",
      //       label: "Update Cost Center",
      //     });
      //   }
      // }

      if (isActiveOrRestore) {
        results.push({
          key: "change-phone-number",
          label: "Change Phone Number"
        });
      }
    }
    else if (rowData && providerName && providerName === "EBONDING") {
      if (moduleFeatures?.includes("Update Device Status-Inventory")) {
        results.push({
          key: "update-status",
          label: "Update Device Status",
        });
      }

      if (isActivated && moduleFeatures?.includes("Update carrier rate plan-Inventory")) {
        results.push({
          key: "update-carrier-rate-plan",
          label: "Update Rate Plan",
        });
      }

      if (isActivated && moduleFeatures?.includes("Update customer rate plan-Inventory")) {
        results.push({
          key: "update-customer-rate-plan",
          label: "Update Customer Rate Plan",
        });
      }

      if (isActivated && moduleFeatures?.includes("Assign customer-Inventory")) {
        results.push({
          key: "assign-customer",
          label: "Assign Customer"
        });
      }
      if (moduleFeatures?.includes("Edit cost center-Inventory")) {
        results.push({
          key: "inventory-edit-cost-center",
          label: "Edit Cost Center"
        });
      }
      // if (moduleFeatures?.includes("Edit cost center-Inventory")) {
      //   if (partner === "Titanium - AWX") {
      //     results.push({
      //       key: "update-cost-center",
      //       label: "Update Cost Center",
      //     });
      //   }
      // }
    }
    else if (rowData && providerName && providerName === "ROGERS") {
      if (moduleFeatures?.includes("Update Device Status-Inventory")) {
        results.push({
          key: "update-status",
          label: "Update Device Status",
        });
      }

      if (isActivated && moduleFeatures?.includes("Update carrier rate plan-Inventory")) {
        results.push({
          key: "update-carrier-rate-plan",
          label: "Update Rate Plan",
        });
      }

      if (isActivated && moduleFeatures?.includes("Update customer rate plan-Inventory")) {
        results.push({
          key: "update-customer-rate-plan",
          label: "Update Customer Rate Plan",
        });
      }

      if (moduleFeatures?.includes("Edit cost center-Inventory")) {
        results.push({
          key: "inventory-edit-cost-center",
          label: "Edit Cost Center"
        });
      }
      
      // if (moduleFeatures?.includes("Edit cost center-Inventory")) {
      //   if (partner === "Titanium - AWX") {
      //     results.push({
      //       key: "update-cost-center",
      //       label: "Update Cost Center",
      //     });
      //   }
      // }
      if (moduleFeatures?.includes("Send SMS-Inventory")) {
        results.push({
          key: "update-send-sms",
          label: "Update Send SMS",
        });
      }

        if (moduleFeatures?.includes("Change Private Static IP Address-Inventory")) {
        results.push({
          key: "private-network-ip",
          label: "Change Private Static IP Address"
        });
      }

      if (moduleFeatures?.includes("Update Communication Plan-Inventory")) {
        results.push({
          key: "update-comm-plan",
          label: "Update Communication Plan"
        });
      }

    }
    else {
      const isKoreProvider = providerName.includes("KORE");
       const isJasper = providerName.includes("CISCO JASPER");
      const isPod19 = providerName.includes("POD19");
      // const isRogers = providerName.includes("ROGERS");
      const isTMobileJasper = providerName.includes("T-MOBILE");
      const isVerizon = providerName.includes("VERIZON") || providerName.includes("VZN") || providerName.includes("VZWCR") || providerName.includes("2215-SO01");

      
    if (moduleFeatures?.includes("Send SMS-Inventory") && (isJasper||isPod19||isTMobileJasper)) {
        results.push({
          key: "update-send-sms",
          label: "Update Send SMS",
        });
      }

      if (moduleFeatures?.includes("Update Communication Plan-Inventory") && (isJasper||isPod19||isTMobileJasper)) {
        results.push({
          key: "update-comm-plan",
          label: "Update Communication Plan"
        });
      }

           if (moduleFeatures?.includes("Change Private Static IP Address-Inventory")  && (isVerizon||isJasper||isPod19||isTMobileJasper)) {
        results.push({
          key: "private-network-ip",
          label: "Change Private Static IP Address"
        });
      }

      if (moduleFeatures?.includes("Update Device Status-Inventory")) {
        results.push({
          key: "update-status",
          label: "Update Device Status",
        });
      }

      if (moduleFeatures?.includes("Edit cost center-Inventory")) {
        results.push({
          key: "inventory-edit-cost-center",
          label: "Edit Cost Center"
        });
      }
      

      if (moduleFeatures?.includes("Update carrier rate plan-Inventory") && !isKoreProvider) {
        results.push({
          key: "update-carrier-rate-plan",
          label: "Update Carrier Rate Plan",
        });
      }

      if (isActivated && moduleFeatures?.includes("Update customer rate plan-Inventory")) {
        results.push({
          key: "update-customer-rate-plan",
          label: "Update Customer Rate Plan",
        });
      }

      if (moduleFeatures?.includes("Assign customer-Inventory")) {
        results.push({
          key: "assign-customer",
          label: "Assign Customer"
        });
      }

      // if (moduleFeatures?.includes("Edit cost center-Inventory")) {
      //   if (partner === "Titanium - AWX") {
      //     results.push({
      //       key: "update-cost-center",
      //       label: "Update Cost Center",
      //     });
      //   }
      //   }
      }
    }
   
  return results;
};

const ActionItems: React.FC<ActionItemsProps> = ({
  initialData,
  currentPage,
  itemsPerPage,
  index,
  rowData,
  is_2_0_flow,
}) => {
  const { getTargetTenantProvider, IsTargetTenantProvider } = PerformanceLogStore();
  const [openUpdateStatusModal, setOpenUpdateStatusModal] = useState<boolean>(false);
  const [openInventoryEditCostCenterModal, setOpenInventoryEditCostCenterModal] = useState<boolean>(false);
  const [openUpdateCarrierRatePlan, setUpdateCarrierRatePlan] = useState<boolean>(false);
  const [openUpdateCustomerRatePlan, setUpdateCustomerRatePlan] = useState<boolean>(false);
  const [openAssignCustomerModal, setOpenAssignCustomer] = useState<boolean>(false);
  const [openUpdateFeaturesModal, setOpenUpdateFeatures] = useState<boolean>(false);
  const [openUpdateFeatures_2_0_Modal, setOpenUpdateFeatures_2_0] = useState<boolean>(false);
  const [openRefreshLineModal, setOpenRefreshLineModal] = useState<boolean>(false);
  const [openCommPlanModal, setOpenCommPlanModal] = useState<boolean>(false);
  const [openPPUAdressModal, setOpenPPUAddressModal] = useState<boolean>(false);
  const [openEditCostCenterModal, setEditCostCenter] = useState<boolean>(false);
  const [openChangePhoneNumberModal, setOpenChangePhoneNumberModal] = useState<boolean>(false);
  const { username, partner, role, settabledata, token, selectedDb, metaData,firstLastName, sessionId, isSubTenant } = useAuth();
  const [openSendSMSModal,setOpenSendSMSModal] = useState<boolean>(false);
  const [openResetVoiceMailPasswordModal,setOpenResetVoiceMailPasswordModal] = useState<boolean>(false);
  const [openPrivateNetworkIPModal, setopenPrivateNetworkIPModal] = useState<boolean>(false);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const [tableData, setTableData] = useState<any>([]);
  const { features: moduleFeatures } = useFeatureStore();
  const originaldata = JSON.stringify(rowData);
  const [isBPEnabled, setIsBPEnabled] = useState(false);
  const [writesFlag, setWritesFlag] = useState(false);
  const is_parent_provider_exists = IsTargetTenantProvider(rowData?.service_provider_display_name)

  const handleMenuClick = useCallback(
    (e: any) => {
      setOpen(!open);
      const indexPosition = (currentPage - 1) * itemsPerPage + index;

      switch (e.key) {
        case "update-status":
          setOpenUpdateStatusModal(true);
          break;
        case "inventory-edit-cost-center":
          setOpenInventoryEditCostCenterModal(true);
          break;
        case "update-send-sms":
          setOpenSendSMSModal(true);
          break;
        case "reset-voice-mail-password":
          setOpenResetVoiceMailPasswordModal(true);
          break;
        case "private-network-ip":
           setopenPrivateNetworkIPModal(true);
          break;
        case "update-carrier-rate-plan":
          setUpdateCarrierRatePlan(true);
          break;
        case "update-customer-rate-plan":
          setUpdateCustomerRatePlan(true);
          break;
        case "assign-customer":
          setOpenAssignCustomer(true);
          break;
        case "update-cost-center":
          setEditCostCenter(true);
          break;
        case "update-features":

          if (is_2_0_flow) {
            setOpenUpdateFeatures_2_0(true)
          }
          else {
            setOpenUpdateFeatures(true);
          }
          break;
        case "refresh-line":
          setOpenRefreshLineModal(true);
          break;
        case "update-comm-plan":
          setOpenCommPlanModal(true);
          break;
        case "line-sync":
          // Directly trigger the update without opening a modal
          updateChanges(rowData, "Line Sync");
          break;
        case "update-ppu-address":
          setOpenPPUAddressModal(true);
          break;
        case "change-phone-number":
          setOpenChangePhoneNumberModal(true);
          break;
        default:
          break;
      }
    },
    [open, currentPage, itemsPerPage, index]
  );

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "bold",
    padding: "16px",
  };

  const menuItems_ = simManagementInventoryActionItem(is_2_0_flow, initialData[0], partner, moduleFeatures, rowData);
  const menuItems = menuItems_.sort((a, b) => a.label.localeCompare(b.label));


  const submitPartnerToProvider = async (eventType: string) => {
    let parsedData: any;
    const url = ENV_ROUTES.PARTNER_BECOMING_PROVIDER;
    const data = {
      tenant_name: partner || "default_value",
      username,
      path: "/update_for_partner_to_provider",
      role_name: role,
      parent_module: "Sim Management",
      module_name: "Inventory",
      service_provider: rowData?.service_provider_display_name || "",
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
      source_db: rowData?.source_db || "",
      table_name: "sim_management_inventory",
      change_event_type: eventType || "",
      ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(rowData?.service_provider_display_name) : "" } ,
      ...rowData?.target_details && {
        target_details: [{
          [rowData.id]: rowData?.target_details,
        }]
      },
      ...rowData?.source_id && {
        changed_data: [{
          source_id: rowData.source_id,
          id: rowData.id,
          modified_by: firstLastName || username || ""
        }]
      }
    };

    try {
      setLoading(true);
      const response = await axios.post(url, { data });
      parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === true) {
        const write_is_enabled = parsedData?.write_is_enabled || false;
        setWritesFlag(write_is_enabled);
        return write_is_enabled;
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      return false;
    } finally {
      setLoading(false);
    }
  };

  const fetchCarrierWritesFlag = async () => {
    let parsedData: any;
    const url = ENV_ROUTES.SIM_MANAGEMENT;
    const data = {
      tenant_name: partner || "default_value",
      username,
      path: "/get_writes_enable_for_service_provider",
      role_name: role,
      parent_module: "Sim Management",
      module_name: "Inventory",
      service_provider: rowData?.service_provider_display_name || "",
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
      environment: "BETA",
    };

    try {
      setLoading(true);
      const response = await axios.post(url, { data });
      parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === true) {
        const write_is_enabled = parsedData?.write_is_enabled || false;
        setWritesFlag(write_is_enabled);
        return write_is_enabled;
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      return false;
    } finally {
      setLoading(false);
    }
  };

  const submitCarrierStatus = async (event_type: any, write_is_enabled: boolean) => {
    let parsedData: any;
    const url = ENV_ROUTES.SIM_MANAGEMENT;
    const data = {
      tenant_name: partner || "default_value",
      username,
      path: "/insert_carrier_status_validation_audit",
      role_name: role,
      parent_module: "Sim Management",
      module_name: "Inventory",
      service_provider: rowData?.service_provider_display_name || "",
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
      environment: "BETA",
      msisdn: [],
      iccid: [rowData?.iccid || ""],
      change_type: event_type,
      write_is_enabled: write_is_enabled,
    };

    try {
      const response = await axios.post(url, { data });
      parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === true) {
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const fetchBpFlag = async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_cross_provider_optimization_status",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Active Customer Rate Plan",
        feature_module_name: "Customer Rate Plans",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        const billing_plaform_flag = parsedData?.billing_platform_flag || false;
        setIsBPEnabled(billing_plaform_flag);
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };


  useEffect(() => {
    if (openAssignCustomerModal || openUpdateCustomerRatePlan) {
      fetchBpFlag();
    }
  }, [openAssignCustomerModal, openUpdateCustomerRatePlan]);

  const fetchData = async (event_type: string) => {
    let parsedData: any;
    const url = ENV_ROUTES.SIM_MANAGEMENT;
    const data = {
      tenant_name: partner || "default_value",
      username,
      path: "/get_inventory_data",
      role_name: role,
      parent_module: "Sim Management",
      module_name: "SimManagement Inventory",
      feature_module_name: "Inventory",
      mod_pages: {
        start: 0,
        end: 100,
      },
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
    };

    try {
      const response = await axios.post(url, { data });
      parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === true) {
        notification.success({
          message: "Success",
          description: "Updated successfully",
          style: messageStyle,
          placement: "top",
        });
        fireSideCannons()
        setLoading(false);
        closeModals();
        requestIdleCallback(() => {
          settabledata(parsedData?.inventory_data || []);
          console.log("table response:", getCurrentDateTime());
        });
        if(rowData?.source_db){
          submitPartnerToProvider(event_type)
        }
      } else {
        Modal.error({
          title: "Data Update Error",
          content: parsedData.message || "An error occurred while updating Inventory data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      setLoading(false);
      Modal.error({
        title: "Data Update Error",
        content: error instanceof Error ? error.message : "An error occurred while updating Inventory data. Please try again.",
        centered: true,
      });
    } finally {
      closeModals();
      setLoading(false);
    }
  };

  const callSyncLambda_2_0 = async () => {
    const isTelegenceProvider = (rowData?.service_provider_display_name).toLowerCase().includes("at&t - telegence")
    try {
      const url = ENV_ROUTES.OPTIMIZATION_SYNC_LAMBDA;
      const data = {
        key_name: "m2m_inventory_live_sync_from_20",
        path: "/lambda_sync_jobs_",
        tenant_name: partner || "default_value",
        service_provider_id: rowData?.service_provider_id || "",
        device_ids: [rowData]?.map((item: any) => item.device_id) || '',
        mobility_device_ids: [rowData]?.map((item: any) => item.mobility_device_id) || "",
      };

      const response = await axios.post(url, { data });
      const responseData = JSON.parse(response.data.body);

      if (responseData.flag === false) {
        console.error("Data Fetch Error: " + responseData.message);
      } else {
        console.log("Success: Inventory lambda sync successful.");
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }

  }
  const callSyncLambda = async () => {
    const isTelegenceProvider = (rowData?.service_provider_display_name).toLowerCase().includes("at&t - telegence");
    try {
      const url = ENV_ROUTES.OPTIMIZATION_SYNC_LAMBDA;
      const data = {
        key_name: "m2m_inventory_live_sync_from_20",
        path: "/lambda_sync_jobs_",
        tenant_name: partner || "default_value",
        service_provider_id: rowData?.service_provider_id || "",
        device_id: rowData?.device_id || "",
        mobility_device_id: rowData?.mobility_device_id || "",
      };

      const response = await axios.post(url, { data });
      const responseData = JSON.parse(response.data.body);

      if (responseData.flag === false) {
        console.error("Data Fetch Error: " + responseData.message);
      } else {
        console.log("Success: Inventory lambda sync successful.");
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const sendUpdatedData_2_0 = async (updatedRow: any, event_type: any, moduleStatus?: boolean) => {
    const providerName = getTargetTenantProvider(rowData?.service_provider_display_name).toLowerCase() || "";
    const isKoreProvider = providerName.includes("KORE")
    const isVerizonProvider = (providerName.includes("verizon") || providerName.includes("vzn") || providerName.includes("vzwcr") || providerName.includes("2215-so01"))
    const isTelgencerovider = providerName.includes("telegence")
    const path = event_type === "Update Carrier Rate Plan" ? "/update_carrier_rate_plan" : event_type === "Update Customer Rate Plan" ? "/update_customer_rate_plan" : event_type === "Edit Cost Center" ? "/edit_cost_center" : event_type === "Update Device Status" ? "/update_status" : event_type === "Update feature" ? "/update_features" : event_type === "Line Sync" ? "/update_line_sync" : event_type === "Assign Customer" ? "/update_assign_customer" : event_type === "Change Phone Number" ? "/update_phone_number" : event_type === "Refresh A Line" ? "/update_refresh_a_line" :event_type === "Update Communication Plan" ? "/update_communication_plan" : event_type === "Update PPU address" ? "/update_ppu_address" : event_type === "Reset Voicemail Password" ? "/reset_voicemail_password":event_type === "Send SMS" ? "/send_sms":event_type === "Change Private Static IP Address" ? "/update_private_network_ip" : "";
    setLoading(true);
    let data: any = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: path,
      role_name: role,
      module_name: "SimManagement Inventory",
      feature_module_name: "Inventory",
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
      table_name: "sim_management_inventory",
      service_provider_display_name: rowData?.service_provider_display_name || '',
      //   old_data: oldData,
      carrier_api_status: true,
      change_event_type: event_type === "Update Customer Rate Plan" ? "Change Customer Rate Plan" : event_type === "Update Device Status" ? "Update Status" : event_type,
      request_received_at: getCurrentDateTime(),
      template_name: "Inventory Status Update",
      ...(event_type === "Assign Customer" && { billing_platform_flag: isBPEnabled }),
      ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(rowData?.service_provider_display_name) : "" } 

    };
    try {
      const url = ENV_ROUTES.INVENTORY;
      if (event_type === "Update Carrier Rate Plan") {
        console.log("updatedRow", updatedRow)
        data["changed_data"] = [rowData].map((item: any) => ({
          id: item.id,
          effective_date: updatedRow.effective_date,
          carrier_rate_plan_name: updatedRow.carrier_rate_plan_name || "",
          communication_plan: updatedRow.communication_plan || "",
          modified_by: firstLastName,
        }));
      }
      // Add Update Customer Rate Plan logic
      if (event_type === "Update Customer Rate Plan") {
        console.log("updatedRow", updatedRow)
        let customerData = updatedRow?.isRevCustomer ? {rev_customer_id:updatedRow.customer_id || ""} : {customer_id: updatedRow.customer_id || "" }
        data["changed_data"] = [rowData].map((item: any) => ({
          id: item.id,
          effective_date: updatedRow.effective_date,
          customer_rate_plan_name: updatedRow.customer_rate_plan_name || "",
          customer_rate_pool_name: updatedRow.customer_rate_pool_name !== "None" ? updatedRow.customer_rate_pool_name : "",
          modified_by: firstLastName,
          ...(isSubTenant ? { sub_tenant_customer_rate_plan_name: updatedRow.customer_rate_plan_name || "" } : { sub_tenant_carrier_rate_plan_name: updatedRow.customer_rate_plan_name || "" }),
          ...(isBPEnabled ? {
            customer_name: updatedRow.customer_name,
            ...(moduleStatus ? customerData : { customer_id: updatedRow.customer_id || "" }),
          } : {})
        }));
      }
      if (event_type === "Edit Cost Center") {
        data["changed_data"] = [rowData].map((item: any) => ({
          id: item.id,
          iccid: updatedRow.iccid,
          cost_center: updatedRow.cost_center || "",
          modified_by: firstLastName,
        }));
      }
      if (event_type === "Update Device Status") {

        const isVerizonActive = isVerizonProvider && updatedRow?.sim_status === "Active"
        const isVerizonDecactive = isVerizonProvider && (updatedRow?.sim_status === "Deactive" || updatedRow?.sim_status === "Deactivated")
        const verizonActiveDetails = [rowData].map((item: any) => ({
          FirstName: updatedRow?.first_name || "",
          LastName: updatedRow?.last_name || "",
          BillingAccountNo: item?.billing_account_number || "",
          StreetNo: updatedRow?.address || "",
          StreetName: updatedRow?.address || "",
          StreetDirection: updatedRow?.address || "",
          City: updatedRow?.city || "",
          State: updatedRow?.state || "",
          ZipCode: updatedRow?.service_zip_code || "",
          IMEI: item?.imei || "",
          ReasonCode: "",
          EffectiveDate: isTelgencerovider ? updatedRow?.effective_date : getCurrentDateTime(),
          SubscriberNo: item?.msisdn || "",
        }))
        const verizonDeactiveDetails = {
          imei: updatedRow?.imei || "",
          revAccountNumber: updatedRow?.rev_customer_id || "",
          reasonCode: updatedRow?.reason_code || "CB"
        }
        const telegence_additional_details_ = [rowData].map((item: any) => ({
          FirstName: updatedRow?.first_name || "",
          LastName: updatedRow?.last_name || "",
          BillingAccountNo: item?.billing_account_number || "",
          StreetNo: updatedRow?.address || "",
          StreetName: updatedRow?.address || "",
          StreetDirection: updatedRow?.address || "",
          City: updatedRow?.city || "",
          State: updatedRow?.state || "",
          ZipCode: updatedRow?.service_zip_code || "",
          IMEI: item?.imei || "",
          ReasonCode: updatedRow?.reason_code || "CB",
          EffectiveDate: updatedRow?.effective_date || getCurrentDateTime(),
          SubscriberNo: item?.msisdn || "",
          RevAccountNumber: item?.account_number || "",

        }))
        let telegence_additional_details: any = "";

        if (isTelgencerovider) {
          telegence_additional_details = telegence_additional_details_;
        } else if (isVerizonActive) {
          telegence_additional_details = verizonActiveDetails;
        } else if (isVerizonDecactive) {
          telegence_additional_details = verizonDeactiveDetails;
        }
        data["changed_data"] = [rowData].map((item: any) => ({
          id: item.id,
          sim_status: updatedRow.sim_status,
          device_status_id: updatedRow?.device_status_id || null,
          iccid: item.iccid,
          modified_by: firstLastName,
          public_ip_restriction: updatedRow?.public_ip_restriction || "",
          reason_code: updatedRow?.reason_code || "",
          ...(updatedRow?.activation_profile && { activation_profile: updatedRow.activation_profile }),
          ...(isKoreProvider ? { imei: updatedRow.imei } : { imei: item.imei }),
          ...(updatedRow?.mode && {mode:updatedRow.mode}),
          ... (isVerizonActive && {account_number:updatedRow.account_number}),
          telegence_additional_details,
        }));
        if (updatedRow.sim_status === "Activated") {
          data["changed_data"]["date_activated"] = getCurrentDateTime();
        }
        data["changed_data"]["last_used_date"] = getCurrentDateTime();

      }
      if (event_type === "Update feature") {
        data["changed_data"] = [rowData].map((item: any) => ({
          id: item.id,
          effective_date: updatedRow.effective_date,
          // telegence_features: updatedRow.telegence_features || "",
          modified_by: firstLastName,
          configuration_change_details: updatedRow?.configuration_change_details || {},
          // mobility_configuration_ids: updatedRow?.mobility_configuration_ids || [],
        }));
      }
      if (event_type === "Line Sync") {
        // const iccid = updatedRow.map((item:any) => (item.iccid))
        data["changed_data"] = [rowData].map((item: any) => ({
          id: item.id,
          iccid: item.iccid,
          modified_by: firstLastName,
        }));
      }
      if (event_type === "Assign Customer") {
        data["changed_data"] = [rowData].map((item: any) => ({
          id: item.id,
          customer_name: updatedRow.customer_name,
          modified_by: firstLastName,
          service_type_id: updatedRow?.service_type_id || "",
          ...(moduleStatus ? { account_number: updatedRow.customer_id || "" } : { customer_id: updatedRow.customer_id || "" }),
          ...(isBPEnabled ? {
            customer_rate_plan_name: updatedRow.customer_rate_plan_name || "",
            customer_rate_pool_name: updatedRow.customer_rate_pool_name !== "None" ? updatedRow.customer_rate_pool_name : "",
            effective_date: updatedRow?.effective_date || "",
            ...(isSubTenant ? { sub_tenant_customer_rate_plan_name: updatedRow.customer_rate_plan_name || "" } : { sub_tenant_carrier_rate_plan_name: updatedRow.customer_rate_plan_name || "" })
          } : {})
        }));
      }
      if (event_type === "Change Phone Number") {
        data["changed_data"] = [rowData].map((item: any) => ({
          id: item.id,
          effective_date: updatedRow.effective_date,
          modified_by: firstLastName,
          old_msisdn: item?.msisdn || "",
          msisdn: item?.msisdn || ""
        }));
      }
      if (event_type === "Refresh A Line") {
        const billing_account_number = updatedRow?.billingAccountNumber || "";
        data["changed_data"] = [rowData].map((item: any) => ({
          id: item.id,
          iccid: item.iccid,
          refresh_a_line: {
            requestType: "resendOTAProfile",
            billingAccount: {
              "id": billing_account_number
            },
            serviceCharacteristic: [
              {
                "name": "sim",
                "value": ""
              }
            ]
          },
          modified_by: firstLastName,
        }));
      }
      if (event_type === "Update Communication Plan") {
        const communicationPlan_ = updatedRow?.communicationPlan || "";
        data["changed_data"] = [rowData].map((item: any) => ({
          id: item.id,
          iccid: item.iccid,
          Comm_plan_name:communicationPlan_ || "",
          modified_by: firstLastName,
        }));
      }
      if (event_type === "Update PPU address") {
        const user_address_ = updatedRow?.user_address || "";
        data["changed_data"] = [rowData].map((item: any) => ({
          id: item.id,
          iccid: item.iccid,
          msisdn: item.msisdn,
          user_address: { ...user_address_ },
          modified_by: firstLastName,
        }));
      }

      if (event_type === "Reset Voicemail Password") {
        data["changed_data"] = [rowData].map((item: any) => ({
           id: item.id,
           modified_by: firstLastName,
           billingAccount:updatedRow.billing_account_number,
          pin:updatedRow.new_voicemail_pin
        }));
      }

        if (event_type === "Send SMS") {
        data["changed_data"] = [rowData].map((item: any) => ({
          id: item.id,
          iccid: item.iccid,
          modified_by: firstLastName,
          message_text:updatedRow.text_message
        }));
      }

      // if (event_type === "Change Private Static IP Address") {
      //   data["changed_data"] = [rowData].map((item: any) => ({
      //      id: item.id,
      //      modified_by: firstLastName,
      //      pdpId: updatedRow.pdp_name || "",

      //   }));
      // }

          const getCurrentDateTimeFormatted = (): string => {
                  const now = new Date();
      
                  const pad = (num: number) => num.toString().padStart(2, '0');
      
                  const month = pad(now.getMonth() + 1); // 10 → October
                  const day = pad(now.getDate());        // 02
                  const year = now.getFullYear();        // 2025
      
                  const hours = pad(now.getHours());
                  const minutes = pad(now.getMinutes());
                  const seconds = pad(now.getSeconds());
      
                  return `${month}-${day}-${year} ${hours}:${minutes}:${seconds}`;
              };
            if (event_type === "Change Private Static IP Address") {
              const providerName = getTargetTenantProvider(rowData?.service_provider_display_name).toUpperCase() || "";
              const isTelegence = providerName.toLowerCase().includes("telegence");
              const isVerizon =
                providerName.toLowerCase().includes("verizon") ||
                providerName.toLowerCase().includes("vzn")|| 
                providerName.toLowerCase().includes("vzwcr") || 
                providerName.toLowerCase().includes("2215-so01");
              const isTeal = providerName.toLowerCase().includes("teal");
              let changedData = {};
              if (isTelegence) {
                changedData = {
                  pdpName: updatedRow.pdp || "",
                  billingAccountNumber: updatedRow.ban || "",
                  subscriber: [
                    {
                      subscriberNumber: "",
                      ipAddressRecord: {
                        ipAddress: updatedRow.ip_address || "",
                        ipAddressCode: "",
                        ipAddressType: "",
                      },
                      effectiveDate:
                        getCurrentDateTimeFormatted() || getCurrentDateTime(),
                    },
                  ],
                };
              } else if (isVerizon) {
                changedData = {
                  ipAddress: updatedRow.billing_account_number || "",
                };
              } else if (isTeal) {
                changedData = {};
              } else {
                changedData = {
                  ipv6Address: updatedRow.ip_address || "",
                  apn: updatedRow.apn || "",
                  pdpId: updatedRow.pdp || "",
                };
              }
      
              data["changed_data"] = 
              [rowData].map((item: any) => ({
                id: rowData.id,
                iccid: rowData.iccid,
                modified_by: firstLastName,
                changeRequest : {...changedData}
              }));
          }


      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        setLoading(false);
        if (parsedData.error_type && parsedData.error_type == "Warning") {
          console.log("parsedData.error_type", parsedData.error_type)
          Modal.warning({
            title: 'Warning',
            content: parsedData.message || 'An error occurred while submitting data. Please try again.',
            centered: true,
          });
        }
        else {
          Modal.error({
            title: "Data Update Error",
            content: parsedData.message || "An error occurred while updating Inventory data. Please try again.",
            centered: true,
          });
        }

      } else {
        // setIs2OFilterLoaded(false);
        // closeModals()
        setTimeout(() => {
          callSyncLambda_2_0();
        }, 30000);
        fetchData(event_type);
        //  callFetchData(true)


      }

    } catch (error) {
      setLoading(false);
      console.error("Error fetching data:", error);
    }
    finally {
      // setLoading(false);
      // setIs2OFilterLoaded(false);
    }
  };
  const sendUpdatedData_1_0 = async (updatedRow: any, event_type: any, moduleStatus?: boolean) => {
    let oldData = JSON.parse(originaldata);
    const providerName = getTargetTenantProvider(rowData?.service_provider_display_name).toLowerCase() || "";
    const isKoreProvider = providerName.includes("KORE");
    const isVerizonProvider = (providerName.includes("verizon") || providerName.includes("vzn") || providerName.includes("vzwcr") || providerName.includes("2215-so01"));
    const isTelgencerovider = providerName.includes("telegence");
    setLoading(true);
    let data: any = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/update_inventory_data",
      role_name: role,
      module_name: "SimManagement Inventory",
      feature_module_name: "Inventory",
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
      table_name: "sim_management_inventory",
      old_data: oldData,
      carrier_api_status: true,
      change_event_type: event_type === "Update Device Status" ? "Update Status" : event_type,
      request_received_at: getCurrentDateTime(),
      template_name: "Inventory Status Update",
      ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(rowData?.service_provider_display_name) : "" } 
    };
    try {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      if (event_type === "Update Device Status") {
        const isVerizonActive = isVerizonProvider && updatedRow?.sim_status === "Active";
        const isVerizonDecactive = isVerizonProvider && (updatedRow?.sim_status === "Deactive" || updatedRow?.sim_status === "Deactivated");
        const verizonActiveDetails = {
          FirstName: updatedRow?.first_name || "",
          LastName: updatedRow?.last_name || "",
          BillingAccountNo: rowData?.billing_account_number || "",
          StreetNo: updatedRow?.address || "",
          StreetName: updatedRow?.address || "",
          StreetDirection: updatedRow?.address || "",
          City: updatedRow?.city || "",
          State: updatedRow?.state || "",
          ZipCode: updatedRow?.service_zip_code || "",
          IMEI: rowData?.imei || "",
          ReasonCode: "",
          EffectiveDate: isTelgencerovider ? updatedRow?.effective_date : getCurrentDateTime(),
          SubscriberNo: rowData?.msisdn || "",
        };
        const verizonDeactiveDetails = {
          imei: updatedRow?.imei || "",
          revAccountNumber: updatedRow?.rev_customer_id || "",
          reasonCode: updatedRow?.reason_code || "CB"
        };
        const telegence_additional_details_ = {
          FirstName: updatedRow?.first_name || "",
          LastName: updatedRow?.last_name || "",
          BillingAccountNo: rowData?.billing_account_number || "",
          StreetNo: updatedRow?.address || "",
          StreetName: updatedRow?.address || "",
          StreetDirection: updatedRow?.address || "",
          City: updatedRow?.city || "",
          State: updatedRow?.state || "",
          ZipCode: updatedRow?.service_zip_code || "",
          IMEI: rowData?.imei || "",
          ReasonCode: updatedRow?.reason_code || "CB",
          EffectiveDate: updatedRow?.effective_date || getCurrentDateTime(),
          SubscriberNo: rowData?.msisdn || "",
          RevAccountNumber: rowData?.account_number || "",
        };
        let telegence_additional_details: any = "";

        if (isTelgencerovider) {
          telegence_additional_details = telegence_additional_details_;
        } else if (isVerizonActive) {
          telegence_additional_details = verizonActiveDetails;
        } else if (isVerizonDecactive) {
          telegence_additional_details = verizonDeactiveDetails;
        }
        data["changed_data"] = {
          id: rowData.id,
          sim_status: updatedRow.sim_status,
          device_status_id: updatedRow?.device_status_id || null,
          iccid: oldData.iccid,
          modified_by: firstLastName,
          public_ip_restriction: updatedRow?.public_ip_restriction || "",
          reason_code: updatedRow?.reason_code || "",
          ...(updatedRow?.activation_profile && { activation_profile: updatedRow.activation_profile }),
          ...(isKoreProvider ? { imei: updatedRow.imei } : { imei: rowData.imei }),
          telegence_additional_details,
        };
        if (updatedRow.sim_status === "Activated") {
          data["changed_data"]["date_activated"] = getCurrentDateTime();
        }
        data["changed_data"]["last_used_date"] = getCurrentDateTime();
        data["history"] = {
          service_provider: oldData.service_provider_display_name,
          sim_management_inventory_id: oldData.id,
          imei: isKoreProvider ? updatedRow.imei : oldData.imei,
          msisdn: oldData.msisdn,
          previous_value: oldData.sim_status,
          current_value: updatedRow.sim_status,
          date_of_change: getCurrentDateTime(),
          change_event_type: event_type === "Update Device Status" ? "Update Status" : event_type,
          changed_by: firstLastName,
          customer_account_name: oldData?.customer_name || "",
          ...(updatedRow?.activation_profile && { activation_profile: updatedRow.activation_profile }),
        };
      }
      if (event_type === "Edit Cost Center") {
        data["changed_data"] = {
          id: rowData.id,
          iccid: updatedRow.iccid,
          cost_center: updatedRow.cost_center || "",
          modified_by: firstLastName,
        };
        data["history"] = {
          service_provider: oldData.service_provider_display_name,
          sim_management_inventory_id: oldData.id,
          iccid: oldData.iccid,
          msisdn: oldData.msisdn,
          previous_value: oldData.cost_center,
          current_value: updatedRow.cost_center,
          date_of_change: getCurrentDateTime(),
          change_event_type: event_type,
          changed_by: firstLastName,
          customer_account_name: oldData?.customer_name || "",
        };
      }
      if (event_type === "Update Carrier Rate Plan") {
        data["changed_data"] = {
          id: rowData.id,
          effective_date: updatedRow.effective_date,
          carrier_rate_plan_name: updatedRow.carrier_rate_plan_name || "",
          communication_plan: updatedRow.communication_plan || "",
          modified_by: firstLastName,
        };
        data["history"] = {
          service_provider: oldData.service_provider_display_name,
          sim_management_inventory_id: oldData.id,
          iccid: oldData.iccid,
          msisdn: oldData.msisdn,
          previous_value: oldData.carrier_rate_plan_name,
          current_value: updatedRow.carrier_rate_plan_name,
          date_of_change: getCurrentDateTime(),
          change_event_type: event_type,
          changed_by: firstLastName,
          customer_account_name: oldData?.customer_name || "",
        };
      }
      if (event_type === "Update Customer Rate Plan") {
        let customerData = updatedRow?.isRevCustomer ? {rev_customer_id:updatedRow.customer_id || ""} : {customer_id: updatedRow.customer_id || "" }
        data["changed_data"] = {
          id: rowData.id,
          effective_date: updatedRow.effective_date,
          customer_rate_plan_name: updatedRow.customer_rate_plan_name || "",
          customer_rate_pool_name: updatedRow.customer_rate_pool_name !== "None" ? updatedRow.customer_rate_pool_name : "",
          modified_by: firstLastName,
          ...(isSubTenant ? { sub_tenant_customer_rate_plan_name: updatedRow.customer_rate_plan_name || "" } : { sub_tenant_carrier_rate_plan_name: updatedRow.customer_rate_plan_name || "" }),
          ...(isBPEnabled ? {
            customer_name: updatedRow.customer_name,
          ...(moduleStatus ? customerData : { customer_id: updatedRow.customer_id || "" }),
          } : {})
        };
        data["history"] = {
          service_provider: oldData.service_provider_display_name,
          sim_management_inventory_id: oldData.id,
          iccid: oldData.iccid,
          msisdn: oldData.msisdn,
          previous_value: oldData.customer_rate_plan_name,
          current_value: updatedRow.customer_rate_plan_name,
          date_of_change: getCurrentDateTime(),
          change_event_type: event_type,
          changed_by: firstLastName,
          customer_account_name: oldData?.customer_name || "",
        };
      }
      if (event_type === "Assign Customer") {
        data["changed_data"] = {
          id: rowData.id,
          customer_name: updatedRow.customer_name,
          modified_by: firstLastName,
          ...(moduleStatus ? { account_number: updatedRow.customer_id || "" } : { customer_id: updatedRow.customer_id || "" }),
          ...(isBPEnabled ? {
            customer_rate_plan_name: updatedRow.customer_rate_plan_name || "",
            customer_rate_pool_name: updatedRow.customer_rate_pool_name !== "None" ? updatedRow.customer_rate_pool_name : "",
            effective_date: updatedRow?.effective_date || "",
            ...(isSubTenant ? { sub_tenant_customer_rate_plan_name: updatedRow.customer_rate_plan_name || "" } : { sub_tenant_carrier_rate_plan_name: updatedRow.customer_rate_plan_name || "" })
          } : {})
        };
        data["history"] = {
          service_provider: oldData.service_provider_display_name,
          sim_management_inventory_id: oldData.id,
          iccid: oldData.iccid,
          msisdn: oldData.msisdn,
          previous_value: oldData.customer_name,
          current_value: updatedRow.customer_name,
          date_of_change: getCurrentDateTime(),
          change_event_type: event_type,
          changed_by: firstLastName,
          customer_account_name: oldData?.customer_name || "",
        };
      }
      if (event_type === "Update feature") {
        data["changed_data"] = {
          id: rowData.id,
          effective_date: updatedRow.effective_date,
          telegence_features: updatedRow.telegence_features || "",
          modified_by: firstLastName,
          configuration_change_details: updatedRow?.configuration_change_details || {},
          mobility_configuration_ids: updatedRow?.mobility_configuration_ids || []
        };
        data["history"] = {
          service_provider: oldData.service_provider_display_name,
          sim_management_inventory_id: oldData.id,
          iccid: oldData.iccid,
          msisdn: oldData.msisdn,
          previous_value: oldData.soc,
          current_value: updatedRow.soc,
          date_of_change: getCurrentDateTime(),
          change_event_type: event_type,
          changed_by: firstLastName,
          customer_account_name: oldData?.customer_name || "",
        };
      }
      if (event_type === "Refresh A Line") {
        const billing_account_number = updatedRow?.billingAccountNumber || "";
        data["changed_data"] = {
          id: rowData.id,
          iccid: oldData.iccid,
          refresh_a_line: {
            requestType: "resendOTAProfile",
            billingAccount: {
              "id": billing_account_number
            },
            serviceCharacteristic: [
              {
                "name": "sim",
                "value": ""
              }
            ]
          },
          modified_by: firstLastName,
        };
        data["history"] = {
          service_provider: oldData.service_provider_display_name,
          sim_management_inventory_id: oldData.id,
          iccid: oldData.iccid,
          msisdn: oldData.msisdn,
          previous_value: oldData.sim_status,
          current_value: updatedRow.sim_status,
          date_of_change: getCurrentDateTime(),
          change_event_type: event_type,
          changed_by: firstLastName,
          customer_account_name: oldData?.customer_name || "",
        };
      }
      if (event_type === "Update Communication Plan") {
        const communication_plan_ = updatedRow?.communicationPlan || "";
        data["changed_data"] = {
          id: rowData.id,
          iccid: oldData.iccid,
          Comm_plan_name: communication_plan_ ,
          modified_by: firstLastName,
        };
        data["history"] = {
          service_provider: oldData.service_provider_display_name,
          sim_management_inventory_id: oldData.id,
          iccid: oldData.iccid,
          msisdn: oldData.msisdn,
          previous_value: oldData.communication_plan,
          current_value: updatedRow.communicationPlan,
          date_of_change: getCurrentDateTime(),
          change_event_type: event_type,
          changed_by: firstLastName,
          customer_account_name: oldData?.customer_name || "",
        };
      }
      if (event_type === "Line Sync") {
        const iccid = updatedRow?.iccid || "";
        data["changed_data"] = {
          id: rowData.id,
          iccid: iccid,
          modified_by: firstLastName,
        };
      }
      if (event_type === "Update PPU address") {
        const user_address_ = updatedRow?.user_address || "";
        data["changed_data"] = {
          id: rowData.id,
          iccid: oldData.iccid,
          user_address: { ...user_address_ },
          modified_by: firstLastName,
        };
        data["history"] = {
          service_provider: oldData.service_provider_display_name,
          sim_management_inventory_id: oldData.id,
          iccid: oldData.iccid,
          msisdn: oldData.msisdn,
          previous_value: oldData.sim_status,
          current_value: updatedRow.sim_status,
          date_of_change: getCurrentDateTime(),
          change_event_type: event_type,
          changed_by: firstLastName,
          customer_account_name: oldData?.customer_name || "",
        };
      }
      if (event_type === "Change Phone Number") {
        data["changed_data"] = {
          id: rowData.id,
          effective_date: updatedRow.effective_date,
          modified_by: firstLastName,
          old_msisdn: rowData?.msisdn || "",
          msisdn: rowData?.msisdn || ""
        };
         data["history"] = {
          service_provider: oldData.service_provider_display_name,
          sim_management_inventory_id: oldData.id,
          iccid: oldData.iccid,
          msisdn: oldData.msisdn,
          previous_value: oldData.msisdn,
          current_value: oldData.msisdn,
          date_of_change: getCurrentDateTime(),
          change_event_type: event_type,
          changed_by: firstLastName,
          customer_account_name: oldData?.customer_name || "",
        };
        
      }
       if (event_type === "Reset Voicemail Password") {
        data["changed_data"] = {
          id: rowData.id,
          modified_by: firstLastName,
          billingAccount:updatedRow.billing_account_number,
          pin:updatedRow.new_voicemail_pin
        };
        data["history"] = {
          service_provider: oldData.service_provider_display_name,
          sim_management_inventory_id: oldData.id,
          iccid: oldData.iccid,
          msisdn: oldData.msisdn,
          previous_value: oldData.msisdn,
          current_value: oldData.msisdn,
          date_of_change: getCurrentDateTime(),
          change_event_type: event_type,
          changed_by: firstLastName,
          customer_account_name: oldData?.customer_name || "",
        };
      }
        if (event_type === "Send SMS") {
        data["changed_data"] ={
          id: rowData.id,
          iccid: rowData.iccid,
          modified_by: firstLastName,
          message_text:updatedRow.text_message
        };
        data["history"] = {
          service_provider: oldData.service_provider_display_name,
          sim_management_inventory_id: oldData.id,
          iccid: oldData.iccid,
          msisdn: oldData.msisdn,
          previous_value: oldData.msisdn,
          current_value: oldData.msisdn,
          date_of_change: getCurrentDateTime(),
          change_event_type: event_type,
          changed_by: firstLastName,
          customer_account_name: oldData?.customer_name || "",
        };
      }

      //  if (event_type === "Change Private Static IP Address") {
      //   data["changed_data"] = [rowData].map((item: any) => ({
      //      id: item.id,
      //      modified_by: firstLastName,
      //      pdpId: updatedRow.pdp_name || "",

      //   }));
      // }

         const getCurrentDateTimeFormatted = (): string => {
                  const now = new Date();
      
                  const pad = (num: number) => num.toString().padStart(2, '0');
      
                  const month = pad(now.getMonth() + 1); // 10 → October
                  const day = pad(now.getDate());        // 02
                  const year = now.getFullYear();        // 2025
      
                  const hours = pad(now.getHours());
                  const minutes = pad(now.getMinutes());
                  const seconds = pad(now.getSeconds());
      
                  return `${month}-${day}-${year} ${hours}:${minutes}:${seconds}`;
              };
            if (event_type === "Change Private Static IP Address") {
              const providerName = getTargetTenantProvider(rowData?.service_provider_display_name).toUpperCase() || "";
              const isTelegence = providerName.toLowerCase().includes("telegence");
              const isVerizon =
                providerName.toLowerCase().includes("verizon") ||
                providerName.toLowerCase().includes("vzn") || 
                providerName.toLowerCase().includes("vzwcr") || 
                providerName.toLowerCase().includes("2215-so01");
              const isTeal = providerName.toLowerCase().includes("teal");
              let changedData = {};
              if (isTelegence) {
                changedData = {
                  pdpName: updatedRow.pdp || "",
                  billingAccountNumber: updatedRow.ban || "",
                  subscriber: [
                    {
                      subscriberNumber: "",
                      ipAddressRecord: {
                        ipAddress: updatedRow.ip_address || "",
                        ipAddressCode: "",
                        ipAddressType: "",
                      },
                      effectiveDate:
                        getCurrentDateTimeFormatted() || getCurrentDateTime(),
                    },
                  ],
                };
              } else if (isVerizon) {
                changedData = {
                  ipAddress: updatedRow.billing_account_number || "",
                };
              } else if (isTeal) {
                changedData = {};
              } else {
                changedData = {
                  ipv6Address: updatedRow.ip_address || "",
                  apn: updatedRow.apn || "",
                  pdpId: updatedRow.pdp || "",
                };
              }
      
              data["changed_data"] = {
              // rowdata.map((item: any) => ({
                id: rowData.id,
                iccid: rowData.iccid,
                modified_by: firstLastName,
                changeRequest : {...changedData}
              // }));
            }
          }



      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        setLoading(false);
        if (parsedData.error_type && parsedData.error_type === "Warning") {
          Modal.warning({
            title: 'Warning',
            content: parsedData.message || 'An error occurred while submitting data. Please try again.',
            centered: true,
          });
        } else {
          Modal.error({
            title: "Data Update Error",
            content: parsedData.message || "An error occurred while updating Inventory data. Please try again.",
            centered: true,
          });
        }
      } else {
        setTimeout(() => {
          callSyncLambda();
        }, 30000);
        fetchData(event_type);
      }
    } catch (error) {
      setLoading(false);
      console.error("Error fetching data:", error);
    }
  };

  const closeModals = () => {
    setOpenUpdateStatusModal(false);
    setOpenInventoryEditCostCenterModal(false);
    setUpdateCarrierRatePlan(false);
    setUpdateCustomerRatePlan(false);
    setOpenAssignCustomer(false);
    setOpenChangePhoneNumberModal(false);
    setOpenSendSMSModal(false);
    setOpenResetVoiceMailPasswordModal(false);
  };

  const updateChanges = async (updatedRow: any, event_type: any, moduleStatus?: boolean) => {
    const writes_flag = await fetchCarrierWritesFlag();

    if (writes_flag) {
      const modal = Modal.confirm({
        title: "Carrier API Enabled",
        content: "Carrier API settings are enabled. Submitting now will trigger the Carrier API call directly. Do you want to proceed?",
        centered: true,
        onOk: () => {
          closeModals();
          if (is_2_0_flow) {
            sendUpdatedData_2_0(updatedRow, event_type, moduleStatus);
          }
          else {
            sendUpdatedData_1_0(updatedRow, event_type, moduleStatus);
          }
          submitCarrierStatus(event_type, writes_flag);
        },
        onCancel: () => {

        },
      });
    } else {
      if (is_2_0_flow) {
        sendUpdatedData_2_0(updatedRow, event_type, moduleStatus);
      }
      else {
        sendUpdatedData_1_0(updatedRow, event_type, moduleStatus);
      }
    }
  };

  const menu = useMemo(
    () => (
      <Menu onClick={handleMenuClick} className="bg-white shadow-lg rounded-lg">
        {menuItems?.map((item) => {
          if (!item) return null;

          return <Menu.Item key={item.key}>{item.label}</Menu.Item>;
        })}
      </Menu>
    ),
    [menuItems, handleMenuClick]
  );

  return (
    <>
      {loading ? (
        <>
          <Modal
            title={
              <div>
                <span className="font-semibold text-xl">Updating....</span>
                <hr className="border-gray-300 mt-2 mb-8" />
              </div>
            }
            centered
            open={true}
            width={600}
            height={500}
            onCancel={() => { setLoading(false); closeModals(); }}
            footer={null}
          >
            <div className="popup flex justify-center items-center w-full h-full">
              <Spin size="large" />
            </div>
          </Modal>
        </>
      ) : (
        <>
          <Dropdown
            overlay={menu}
            trigger={["click"]}
            open={open}
            placement="bottomLeft"
            onOpenChange={(visible) => setOpen(visible)}
          >
            <Space onClick={handleMenuClick}>
              <Tooltip title="Click to update the record">
                <MoreOutlined rotate={90} className="text-blue-500" />
              </Tooltip>
            </Space>
          </Dropdown>

          <UpdateStatusModal
            rowData={rowData || {}}
            visible={openUpdateStatusModal}
            onCancel={() => setOpenUpdateStatusModal(false)}
            onUpdate={updateChanges}
            is2OChange={is_2_0_flow}
          />
          <UpdateCarrierRatePlan
            rowData={rowData || {}}
            visible={openUpdateCarrierRatePlan}
            onCancel={() => setUpdateCarrierRatePlan(false)}
            onUpdate={updateChanges}
            is2OChange={is_2_0_flow}
            isSingle={true}
          />
          <UpdateCustomerRatePlan
            rowData={rowData || {}}
            visible={openUpdateCustomerRatePlan}
            onCancel={() => setUpdateCustomerRatePlan(false)}
            onUpdate={updateChanges}
            is2OChange={is_2_0_flow}
            isSingle={true}
          />
          <AssignCustomerModal
            rowData={rowData || {}}
            visible={openAssignCustomerModal}
            onCancel={() => setOpenAssignCustomer(false)}
            onUpdate={updateChanges}
            is2OChange={is_2_0_flow}
            isSingle={true}
          />
          <InventoryEditCostCenterModal
            rowData={rowData || {}}
            visible={openInventoryEditCostCenterModal}
            onCancel={() => setOpenInventoryEditCostCenterModal(false)}
            onUpdate={updateChanges}
            is2OChange={is_2_0_flow}
            isSingle={true}
          />
          <EditCostCenter
            rowData={rowData || {}}
            visible={openEditCostCenterModal}
            onCancel={() => setEditCostCenter(false)}
            onUpdate={updateChanges}
          />
          <UpdateFeaturesModal
            rowData={rowData || {}}
            visible={openUpdateFeaturesModal}
            onCancel={() => setOpenUpdateFeatures(false)}
            onUpdate={updateChanges}

          />
          <UpdateFeaturesModal_2_0
            rowData={rowData || {}}
            visible={openUpdateFeatures_2_0_Modal}
            onCancel={() => setOpenUpdateFeatures_2_0(false)}
            onUpdate={updateChanges}
            is2OChange={is_2_0_flow}

          />
          <RefreshLineModal
            rowData={rowData || {}}
            visible={openRefreshLineModal}
            onCancel={() => setOpenRefreshLineModal(false)}
            onUpdate={updateChanges}
          />
          <UpdateCommunicationPlanModal
            rowData={rowData || {}}
            visible={openCommPlanModal}
            onCancel={() => setOpenCommPlanModal(false)}
            onUpdate={updateChanges}
            isSingle={true}
            is2OChange={is_2_0_flow}
          />
          <UpdatePPUAddressModal
            rowData={rowData || {}}
            visible={openPPUAdressModal}
            onCancel={() => setOpenPPUAddressModal(false)}
            onUpdate={updateChanges}
            is2OChange={is_2_0_flow}
          />
          <UpdatePhoneNumberModal
            rowData={rowData || {}}
            visible={openChangePhoneNumberModal}
            onCancel={() => setOpenChangePhoneNumberModal(false)}
            onUpdate={updateChanges}
          />
          <SendSMS 
            rowData={rowData || {}}
            visible={openSendSMSModal}
            onCancel={() => setOpenSendSMSModal(false)}
            onUpdate={updateChanges}
            is2OChange={is_2_0_flow}
            isSingle={true}/>
            <ResetVoicemailPassword 
            rowData={rowData || {}}
            visible={openResetVoiceMailPasswordModal}
            onCancel={() => setOpenResetVoiceMailPasswordModal(false)}
            onUpdate={updateChanges}
            is2OChange={is_2_0_flow}
            isSingle={true}/>
               <UpdatePrivateNetworkModal
            rowData={rowData || {}}
            visible={openPrivateNetworkIPModal}
            onCancel={() => setopenPrivateNetworkIPModal(false)}
            onUpdate={updateChanges}
            is2OChange={is_2_0_flow}
            isSingle={true}/>
        </>
      )}
    </>
  );
};

export default ActionItems;