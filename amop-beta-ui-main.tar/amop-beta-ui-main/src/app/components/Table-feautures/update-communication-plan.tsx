// UpdateCommunicationPlanModal.tsx
import React, { useState, useEffect, forwardRef, useImperativeHandle } from "react";
import { Modal, Spin, Input, Checkbox } from "antd";
import { useFeatureStore } from '@/app/sim_management/inventory/featureStore';
import { useInventoryAllChangeTypesStore } from '@/app/stores/inventorytAllChangeTypesStore';
import { useCustomerProfileStore } from "@/app/billing/killbill_stores/customer_profile_store";
import { DropdownStyles } from "../css/dropdown";
import Select from "react-select";
import { ENV_ROUTES } from "../routes/route_constants";
import { useAuth } from "../auth_context";
import axios from "axios";

interface UpdateCommunicationPlanProps {
    visible: boolean;
    onCancel: () => void;
    onUpdate: (updatedRow: any, event_type: string) => void;
    rowData?: any;
    isAllChangeTypesFlow?: Boolean;
    is2OChange?: boolean;
    isSingle?: boolean;

}

export interface UpdateCommunicationPlanContentRef {
    runValidation: () => Promise<void> | void;
    runSubmit: () => Promise<void> | void;
    hasValidData: () => boolean; // Add this method
}

const UpdateCommunicationPlanModal = forwardRef<UpdateCommunicationPlanContentRef, UpdateCommunicationPlanProps>(
    ({ visible, onCancel, onUpdate, rowData, isAllChangeTypesFlow, is2OChange, isSingle }, ref) => {
        const [formData, setFormData] = useState<any>({ ...rowData });
        const [loading, setLoading] = useState(false);
        const [communicationPlan, setCommunicationPlan] = useState<string | undefined>(undefined);
        const [CommPlanOptions, setCommPlanOptions] = useState<any>([])
        const [commPlanError, setCommPlanError] = useState("");
        // const { is2OFilterLoaded } = useFeatureStore();
        const { setIs2OFilterLoaded, is2OFilterLoaded } = useCustomerProfileStore();

        const { activeChange, isAllChangeType, setIsValidated, setValidationTrigger, setsuccessFullChangeTypes, successFullChangeTypes, setCommPlanChanges } = useInventoryAllChangeTypesStore();
        const [saveChanges, setSaveChanges] = useState<boolean>(true);
        const versionBasedPath = is2OChange ? ENV_ROUTES.INVENTORY : ENV_ROUTES.SIM_MANAGEMENT
        const { username, partner, role, settabledata, token, selectedDb, metaData, firstLastName, sessionId } = useAuth();

        useEffect(() => {
            const is_single_line = (!is2OChange || isSingle)

            setCommunicationPlan(is_single_line ? rowData?.communication_plan || '' : '')
            const fetchData = async () => {
                setLoading(true);
                try {
                    const url = versionBasedPath;
                    const data = {
                        tenant_name: partner || "default_value",
                        username: username,
                        firstLastName: firstLastName,
                        path: "/inventory_dropdowns_data",
                        role_name: role,
                        parent_module: "Sim Management",
                        module_name: "SimManagement Inventory",
                        feature_module_name: "Inventory",
                        service_provider_id: rowData?.service_provider_id || 0,
                        list_view_data_id: rowData?.id || 0,
                        Partner: partner,
                        access_token: token,
                        db_name: selectedDb,
                        ...metaData,
                        sessionID: sessionId,
                        dropdown: "Update Communication Plan",
                        modified_by: firstLastName
                    };

                    const response = await axios.post(url, { data });
                    const parsedData = JSON.parse(response.data.body);

                    if (parsedData.flag === false) {
                        Modal.error({
                            title: 'Data Fetch Error',
                            content: parsedData.message || 'An error occurred while fetching Inventory data. Please try again.',
                            centered: true,
                            onOk: onCancel

                        });
                    } else {
                        const commPlanOptions_ = parsedData?.communication_plan_list || []
                        setCommPlanOptions(commPlanOptions_)
                    }
                } catch (error) {
                    console.error("Error fetching data:", error);
                    Modal.error({
                        title: 'Data Fetch Error',
                        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                        centered: true,
                        onOk: onCancel

                    });
                } finally {
                    setLoading(false);
                }
            };
            if (visible === true) {
                fetchData()
            }
        }, [visible]);
        // Add this method to check if any field has valid data
        const hasValidData = () => {
            return !!(communicationPlan && communicationPlan.trim() !== "");
        };
        const handleUpdate = () => {
            let hasError = false;

            if (!communicationPlan) {
                setCommPlanError("Communication Plan is required.");
                console.log("Validation failed: Communication Plan is required.");
                hasError = true;
            } else {
                setCommPlanError("");
            }

            // Stop if validation failed in normal flow
            if (hasError && !isAllChangeType) {
                return;
            }


            // If no validation errors, proceed with update
            if (!hasError && !isAllChangeType) {
                onUpdate({ ...formData, communicationPlan: communicationPlan?.trim() }, "Update Communication Plan");
                setCommPlanError("");
            }

            // Remove from successful change types if there are errors
            setsuccessFullChangeTypes(
                successFullChangeTypes.filter((c: any) => c !== activeChange)
            );

            // Handle all change types validation flow
            if (isAllChangeType) {
                const isAnyFieldFilled = !!communicationPlan;

                if (!isAnyFieldFilled) {
                    // None of the fields entered → clear errors and allow
                    setCommPlanError("");
                    setIsValidated(true);
                    setValidationTrigger();
                    return;
                } else {
                    // Check if Communication Plan is required and missing
                    if (!communicationPlan) {
                        setCommPlanError("Communication Plan is required.");
                        return;
                    }

                    // All validations passed
                    setCommPlanError("");
                    setIsValidated(true);
                    if (saveChanges) {
                        setCommPlanChanges((prev: any) =>( {
          ... prev,
          commPlan :communicationPlan || ""
        }))
                        setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
                    }
                    setValidationTrigger();
                    return;
                }
            } else {
                // Normal validation path
                return;
            }
        };

        const handleCancel = () => {
            setCommPlanError("");
            setFormData(rowData);
            onCancel();
        };
        const handlesubmit = () => {
            onUpdate({ ...formData, communicationPlan: communicationPlan?.trim() }, "Update Communication Plan");
            setCommPlanError("");
        }
        useImperativeHandle(ref, () => ({
            runValidation: handleUpdate,
            runSubmit: handlesubmit,
            hasValidData: hasValidData // NEW: Add this method
        }));

        const handleSelectCommPlan = (selectedOption: any | null) => {
            if (selectedOption) {
                const value = selectedOption?.value
                setCommunicationPlan(value)

            }
            else {
                setCommunicationPlan(undefined); // Clear the selection
            }
        };

        // The main content that will be reused
        const renderContent = () => {
            if (loading || is2OFilterLoaded) {
                return (
                    <div className="popup flex justify-center items-center w-full h-full">
                        <Spin size="large" />
                    </div>
                );
            }

            return (
                <>
                    {isAllChangeType && (
                        <div className="flex justify-end px-4">
                            <span className="mr-2 font-semibold">Save Changes</span>
                            <Checkbox
                                checked={saveChanges}
                                onChange={(e) => {
                                    if (!e.target.checked) {
                                        setsuccessFullChangeTypes(
                                            successFullChangeTypes.filter((c: any) => c !== activeChange)
                                        );
                                    }
                                    setSaveChanges(e.target.checked)
                                }}
                                className="custom-checkbox"
                            >

                            </Checkbox>
                        </div>
                    )}
                    <div className="flex flex-col space-y-4 my-4">
                        {/* Communication Plan */}
                        <div className="flex items-center space-x-4">
                            <label htmlFor="communicationPlan" className="field-label !w-[40%]">
                                Communication Plan<span className="text-red-500">*</span>
                            </label>
                            <Select
                                id="communicationPlan"
                                placeholder="Select Carrier Rate Plan"
                                options={CommPlanOptions.length > 0 ? CommPlanOptions.map((option: string) => ({
                                    label: option,
                                    value: option,
                                })) : [{ value: 'No options', label: 'No options' }]}
                                value={{ label: communicationPlan, value: communicationPlan }}
                                onChange={handleSelectCommPlan}
                                isClearable
                                className="w-full"
                                styles={DropdownStyles}
                                menuPortalTarget={document.body}
                                menuPosition="fixed"
                                menuPlacement="auto"
                            />
                        </div>
                        {commPlanError && (
                            <div className="text-red-500 text-sm mt-1">{commPlanError}</div>
                        )}
                    </div>
                </>
            );
        };

        // Conditional rendering: Modal OR div based on isAllChangeTypesFlow
        if (isAllChangeTypesFlow) {
            // Render just the content (div) for All Change Types flow
            return (
                <div className="p-4">
                    {renderContent()}
                </div>
            );
        }

        return (
            <Modal
                title={
                    <div className="mt-[-10px]">
                        <span className="text-[19px]">Update Communication Plan</span>
                    </div>
                }
                visible={visible}
                centered
                onCancel={handleCancel}
                footer={[
                    <div className="flex justify-center space-x-2 mt-12" key="buttons">
                        <button
                            key="cancel"
                            onClick={onCancel}
                            className="cancel-btn h-[30px] text-base"
                            style={{ fontFamily: "Calibri, sans-serif" }}
                        >
                            Cancel
                        </button>
                        <button
                            key="update"
                            onClick={handleUpdate}
                            className="save-btn text-base border-none"
                            style={{ fontFamily: "Calibri, sans-serif" }}
                        >
                            Update
                        </button>
                    </div>,
                ]}
                width={500}
                style={{ height: "500px" }}
            >
                {renderContent()}
            </Modal>
        );
    }
);

export default UpdateCommunicationPlanModal;