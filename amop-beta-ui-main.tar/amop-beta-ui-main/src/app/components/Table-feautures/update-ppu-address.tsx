import React, { forwardRef,useImperativeHandle,useState, useEffect } from "react";
import { Modal, Row, Col, Spin, Input, Select } from "antd";
import { useAuth } from "@/app/components/auth_context";
import { ENV_ROUTES } from "../routes/route_constants";
import axios from "axios";
import { getCurrentDateTime } from "../header_constants";
import { ChevronDownIcon } from "@heroicons/react/24/outline";
import { useInventoryAllChangeTypesStore } from "@/app/stores/inventorytAllChangeTypesStore";
import { useCustomerProfileStore } from "@/app/billing/killbill_stores/customer_profile_store";

interface UpdatePPUAddressProps {
    visible: boolean;
    onCancel: () => void;
    onUpdate: (updatedRow: any, event_type: string) => void;
    rowData?: any;
    is2OChange?: Boolean;
    isAllChangeTypesFlow?: Boolean;
}
export interface UpdatePPUAddressContentRef {
  runValidation: () => Promise<void> | void;
   runSubmit: () => Promise<void> | void; // Add runSubmit method
  hasValidData: () => boolean; // Add hasValidData method
}
const UpdatePPUAddressModal =forwardRef<UpdatePPUAddressContentRef, UpdatePPUAddressProps>(
    ({
    visible,
    onCancel,
    onUpdate,
    rowData,
    isAllChangeTypesFlow,
    is2OChange,
},ref) => {

    const [formData, setFormData] = useState<any>({ ...rowData });
    const [loading, setLoading] = useState(false);
    const [billingAccountNumber, setBillingAccountNumber] = useState<string | undefined>(undefined);
    const [selectedRole, setSelectedRole] = useState<string>("");
    const [city, setCity] = useState<string>("");
    const [streetName, setStreetName] = useState<string>("");
    const [streetNumber, setStreetNumber] = useState<any>("");
    const [streetDirection, setStreetDirection] = useState<string>("");
    const [errors, setErrors] = useState<{ [key: string]: string }>({});
    const [subscribeFirstName, setSubscribeFirstName] = useState<string>("");
    const [subscribeLastName, setSubscribeLastName] = useState<string>("");
    const [zipCode, setZipCode] = useState<any | null>(null);
    const [stateOptions, setStateOptions] = useState<any>([]);
    const [selectedStateCode, setSelectedStateCode] = useState("");
    const versionBasedPath = is2OChange ? ENV_ROUTES.INVENTORY : ENV_ROUTES.SIM_MANAGEMENT
    const { activeChange , isAllChangeType,setIsValidated,setValidationTrigger, setsuccessFullChangeTypes, successFullChangeTypes } = useInventoryAllChangeTypesStore();
    const { is2OFilterLoaded } = useCustomerProfileStore()
    const { username, partner, role, settabledata, token, selectedDb, firstLastName, sessionId } = useAuth();

    const fetchData = async () => {
      setLoading(true);
      try {
        const url = versionBasedPath;
        const data = {
          tenant_name: partner || "default_value",
          username: username,
          firstLastName: firstLastName,
          path: "/inventory_dropdowns_data",
          role_name: role,
          parent_module: "Sim Management",
          module_name: "SimManagement Inventory",
          feature_module_name: "Inventory",
          service_provider_id: rowData?.service_provider_id || 0,
          list_view_data_id: rowData?.id || 0,
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
          sessionID: sessionId,
          dropdown: "Update PPU address",
          modified_by: firstLastName
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);

        if (parsedData.flag === false) {
          Modal.error({
            title: 'Data Fetch Error',
            content: parsedData.message || 'An error occurred while fetching Inventory data. Please try again.',
            centered: true,
            onOk: onCancel

          });
        } else {
          const state = parsedData?.state || [];

        const stateOptions = state.map((item: any) => ({
            label: item.name,
            value: item.code,
        }));

        setStateOptions(stateOptions);
        }
      } catch (error) {
        console.error("Error fetching data:", error);
        Modal.error({
          title: 'Data Fetch Error',
          content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
          centered: true,
          onOk: onCancel

        });
      } finally {
        setLoading(false);
      }
    };
    useEffect(() => {
        if (visible) {
            // setBillingAccountNumber(undefined)
            fetchData()
        }
        setErrors({})
    }, [visible]);
 // Add this method to check if any field has valid data
    const hasValidData = () => {
      const isAnyFieldFilled =
        !!billingAccountNumber ||
        !!selectedRole ||
        !!subscribeFirstName ||
        !!subscribeLastName ||
        !!streetNumber ||
        !!streetName ||
        !!streetDirection ||
        !!city ||
        !!zipCode ||
        !!selectedStateCode;
      
      return isAnyFieldFilled;
    };
const handleUpdate = () => {
  const newErrors: { [key: string]: string } = {};

  // Mandatory field list
  const mandatoryFields = [
    billingAccountNumber,
    selectedRole,
    subscribeFirstName,
    subscribeLastName,
    streetNumber,
    streetName,
    city,
    zipCode,
    selectedStateCode,
  ];

  const hasAnyMandatoryInput = mandatoryFields.some(field => !!field);

  // 🟦 CASE 1: When isAllChangeType = true (conditional validation)
  if (isAllChangeType) {
    if (hasAnyMandatoryInput) {
      // Validate only if user entered something
      if (!billingAccountNumber) newErrors.billingAccountNumber = "Billing account number is required.";
      if (!selectedRole) newErrors.role = "Role is required.";
      if (!subscribeFirstName) newErrors.subscribeFirstName = "Subscribe first name is required.";
      if (!subscribeLastName) newErrors.subscribeLastName = "Subscribe last name is required.";
      if (!streetNumber) newErrors.streetNumber = "Street number is required.";
      if (!streetName) newErrors.streetName = "Street name is required.";
      if (!city) newErrors.city = "City is required.";
      if (!zipCode) newErrors.zipCode = "Zip code is required.";
      if (zipCode) {
        const regex = /^\d{5}$/;
        if (!regex.test(zipCode)) newErrors.zipCode = "Zip code must be exactly 5 digits.";
      }
      if (!selectedStateCode) newErrors.state = "State is required.";
    }

    // Handle validation results
    if (Object.keys(newErrors).length > 0) {
      // Validation failed → remove from successFullChangeTypes
      setErrors(newErrors);
      setsuccessFullChangeTypes(
        successFullChangeTypes.filter((c: any) => c !== activeChange)
      );
      setIsValidated(false);
      setValidationTrigger();
      return;
    } else {
      // Validation passed
      setErrors({});
      if (hasAnyMandatoryInput) {
        // All mandatory fields entered correctly
        if (!successFullChangeTypes.includes(activeChange)) {
          setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
        }
      } else {
        // None entered → remove from success list
        setsuccessFullChangeTypes(
          successFullChangeTypes.filter((c: any) => c !== activeChange)
        );
      }
      setIsValidated(true);
      setValidationTrigger();
      return;
    }
  }

  // 🟩 CASE 2: When isAllChangeType = false (standard validation)
  if (!billingAccountNumber) newErrors.billingAccountNumber = "Billing account number is required.";
  if (!selectedRole) newErrors.role = "Role is required.";
  if (!subscribeFirstName) newErrors.subscribeFirstName = "Subscribe first name is required.";
  if (!subscribeLastName) newErrors.subscribeLastName = "Subscribe last name is required.";
  if (!streetNumber) newErrors.streetNumber = "Street number is required.";
  if (!streetName) newErrors.streetName = "Street name is required.";
  if (!city) newErrors.city = "City is required.";
  if (!zipCode) newErrors.zipCode = "Zip code is required.";
  if (zipCode) {
    const regex = /^\d{5}$/;
    if (!regex.test(zipCode)) newErrors.zipCode = "Zip code must be exactly 5 digits.";
  }
  if (!selectedStateCode) newErrors.state = "State is required.";

  if (Object.keys(newErrors).length > 0) {
    setErrors(newErrors);
  } else {
    setErrors({});
    const UserAddress = {
      billingAccount: { id: billingAccountNumber || "" },
      relatedParty: {
        role: selectedRole || "subscriber",
        firstName: subscribeFirstName || "",
        lastName: subscribeLastName || "",
        address: {
          streetNumber: streetNumber || "",
          streetDirection: streetDirection || "",
          streetName: streetName || "",
          streetType: "",
          city: city || "",
          state: selectedStateCode || "",
          zipCode: zipCode || "",
        },
      },
    };

    const formData_ = { ...formData, user_address: { ...UserAddress } };
    onUpdate(formData_, "Update PPU address");
  }
};

const handleSubmit = () => {
  handleUpdate();
};

    const handleSelectedStateChange = (value: any) => {
        // 'value' is the state code, so set it to selectedStateCode
        setSelectedStateCode(value);
    };

    const handleCancel = () => {
        setErrors({})
        setFormData(rowData);
        onCancel();
    };
      useImperativeHandle(ref, () => ({
           runValidation: handleUpdate,
           runSubmit: handleSubmit, // Add this line
      hasValidData: hasValidData, // Add this line
         }));
      // The main content that will be reused
      const renderContent = () => {
        if (loading || is2OFilterLoaded ) {
          return (
            <div className="popup flex justify-center items-center w-full h-full">
              <Spin size="large" />
            </div>
          );
        }
    
        return (
          <div className="max-h-[400px] overflow-y-auto pr-2">
          {(loading || is2OFilterLoaded) ? (
            <div className="popup flex justify-center items-center w-full h-full">
              <Spin size="large" />
            </div>
          ) : (
            <div className="flex flex-col space-y-4 my-4">
                            {
                                <>
                                    {/* Billing Account Number */}
                                    <div className="flex items-center space-x-4">
                                        <label htmlFor="billingAccountNumber" className="w-1/3 font-semibold">
                                            Billing Account Number<span className="text-red-500">*</span>
                                        </label>
                                        <Input
                                            id="billingAccountNumber"
                                            // placeholder="Enter Billing Account Number"
                                            value={billingAccountNumber}
                                            onChange={(e) => setBillingAccountNumber(e.target.value)}
                                            className="w-2/3 ActiveServiceinput" />
                                    </div>
                                    {errors.billingAccountNumber && <div className="text-red-500">{errors.billingAccountNumber}</div>}

                                    {/* Role */}
                                    <div className="flex items-center space-x-4">
                                        <label htmlFor="role" className="w-1/3 font-semibold">
                                            Role<span className="text-red-500">*</span>
                                        </label>
                                        <Input
                                            id="role"
                                            // placeholder="Enter First Name"
                                            value={selectedRole}
                                            onChange={(e) => setSelectedRole(e.target.value)}
                                            className="w-2/3 ActiveServiceinput" />
                                    </div>
                                    {errors.role && <div className="text-red-500">{errors.role}</div>}
                                    {/* <div className="flex items-center space-x-4">
                                    <label htmlFor="ratePlanGroup" className="w-1/3 font-semibold">
                                        Role
                                    </label>
                                    <Select
                                        showSearch
                                        value={selectedRole === 'No options' ? null : { label: selectedRole, value: selectedRole }}
                                        id="ratePlanGroup"
                                        // placeholder="Select Rate Plan Group"
                                        options={roleOptions > 0 ? roleOptions.map((option: string) => ({
                                            label: option,
                                            value: option,
                                        })) : [{ value: 'No options', label: 'No options' }]}
                                        onChange={handleRoleChange}
                                        suffixIcon={
                                            <ChevronDownIcon className="w-4 h-4 text-gray-600 arrow " />
                                        }
                                        className="w-2/3 mt-1 mb-2" />
                                </div> */}

                                    {/* Subscriber First Name */}
                                    <div className="flex items-center space-x-4">
                                        <label htmlFor="subscribeFirstName" className="w-1/3 font-semibold">
                                            Subscriber First Name<span className="text-red-500">*</span>
                                        </label>
                                        <Input
                                            id="subscribeFirstName"
                                            // placeholder="Enter First Name"
                                            value={subscribeFirstName}
                                            onChange={(e) => setSubscribeFirstName(e.target.value)}
                                            className="w-2/3 ActiveServiceinput" />
                                    </div>
                                    {errors.subscribeFirstName && <div className="text-red-500">{errors.subscribeFirstName}</div>}

                                    {/* Subscriber Last Name */}
                                    <div className="flex items-center space-x-4">
                                        <label htmlFor="subscribeLastName" className="w-1/3 font-semibold">
                                            Subscriber Last Name<span className="text-red-500">*</span>
                                        </label>
                                        <Input
                                            id="subscribeLastName"
                                            // placeholder="Enter Last Name"
                                            value={subscribeLastName}
                                            onChange={(e) => setSubscribeLastName(e.target.value)}
                                            className="w-2/3 ActiveServiceinput" />
                                    </div>
                                    {errors.subscribeLastName && <div className="text-red-500">{errors.subscribeLastName}</div>}

                                    {/* Street Number */}
                                    <div className="flex items-center space-x-4">
                                        <label htmlFor="streetNumber" className="w-1/3 font-semibold">
                                            Street Number<span className="text-red-500">*</span>
                                        </label>
                                        <Input
                                            id="streetNumber"
                                            // placeholder="Enter Street Number"
                                            value={streetNumber}
                                            onChange={(e) => setStreetNumber(e.target.value)}
                                            className="w-2/3 ActiveServiceinput" />
                                    </div>
                                    {errors.streetNumber && <div className="text-red-500">{errors.streetNumber}</div>}

                                    {/* Street Direction */}
                                    <div className="flex items-center space-x-4">
                                        <label htmlFor="streetDirection" className="w-1/3 font-semibold">
                                            Street Direction
                                        </label>
                                        <Input
                                            id="streetDirection"
                                            // placeholder="Enter Street Direction"
                                            value={streetDirection}
                                            onChange={(e) => setStreetDirection(e.target.value)}
                                            className="w-2/3 ActiveServiceinput" />
                                    </div>
                                    {errors.streetDirection && <div className="text-red-500">{errors.streetDirection}</div>}

                                    {/* Street Name */}
                                    <div className="flex items-center space-x-4">
                                        <label htmlFor="streetName" className="w-1/3 font-semibold">
                                            Street Name<span className="text-red-500">*</span>
                                        </label>
                                        <Input
                                            id="streetName"
                                            // placeholder="Enter Street Name"
                                            value={streetName}
                                            onChange={(e) => setStreetName(e.target.value)}
                                            className="w-2/3 ActiveServiceinput" />
                                    </div>
                                    {errors.streetName && <div className="text-red-500">{errors.streetName}</div>}

                                    {/* City */}
                                    <div className="flex items-center space-x-4">
                                        <label htmlFor="city" className="w-1/3 font-semibold">
                                            City<span className="text-red-500">*</span>
                                        </label>
                                        <Input
                                            id="city"
                                            // placeholder="Enter City"
                                            value={city}
                                            onChange={(e) => setCity(e.target.value)}
                                            className="w-2/3 ActiveServiceinput" />
                                    </div>
                                    {errors.city && <div className="text-red-500">{errors.city}</div>}

                                    {/* State */}
                                    <div className="flex items-center space-x-4">
                                        <label htmlFor="state" className="w-1/3 font-semibold">
                                            State<span className="text-red-500">*</span>
                                        </label>
                                        <Select
                                            showSearch
                                            value={selectedStateCode || null}
                                            id="state"
                                            // placeholder="Select State"
                                            options={stateOptions.length > 0 ? stateOptions : [{ value: 'No options', label: 'No options' }]}
                                            onChange={handleSelectedStateChange}
                                            suffixIcon={
                                                <ChevronDownIcon className="w-4 h-4 arrow  text-gray-600" />
                                            }
                                            className="w-2/3 mb-2" />
                                    </div>
                                    {errors.state && <div className="text-red-500">{errors.state}</div>}

                                    {/* Zip Code */}
                                    <div className="flex items-center space-x-4">
                                        <label htmlFor="zipCode" className="w-1/3 font-semibold">
                                            Zip Code<span className="text-red-500">*</span>
                                        </label>
                                        <Input
                                            id="zipCode"
                                            // placeholder="Enter Zip Code"
                                            value={zipCode}
                                            onChange={(e) => setZipCode(e.target.value)}
                                            className="w-2/3  mt-1 ActiveServiceinput" />
                                    </div>
                                    {errors.zipCode && <div className="text-red-500">{errors.zipCode}</div>}

                                </>
                            }
                        </div>

          )}
          </div>
        );
      };
    
      // Conditional rendering: Modal OR div based on isAllChangeTypesFlow
      if (isAllChangeTypesFlow) {
        // Render just the content (div) for All Change Types flow
        return (
          <div className="p-4">
            {renderContent()}
          </div>
        );
      }
    const modalHeight =
        typeof window !== "undefined" ? (window.innerHeight * 3) / 4 : 0;
    return (
        <Modal
            title={
                <div className="mt-[-10px]">
                    <span className="text-[19px]">Update PPU Address</span>
                </div>
            }
            visible={visible}
            centered
            onCancel={handleCancel}
            style={{
                maxHeight: modalHeight,
                overflowY: "auto",
                overflowX: "hidden",
            }}
            footer={[
                <div className="flex justify-center space-x-2 mt-12" key="buttons">
                    <button
                        key="cancel"
                        onClick={onCancel}
                        className="cancel-btn h-[30px] text-base"
                        style={{ fontFamily: "Calibri, sans-serif" }}
                    >
                        Cancel
                    </button>
                    <button
                        key="update"
                        onClick={handleUpdate}
                        className="save-btn  text-base border-none"
                        style={{ fontFamily: "Calibri, sans-serif" }}
                    >
                        Update
                    </button>
                </div>,
            ]}
            width={500}
        >
            <>
                {(loading || is2OFilterLoaded) ? (
                    <div className="popup flex justify-center items-center w-full h-full mt-4">
                        <Spin size="large" />
                    </div>
                ) : (
                    <>
                        <div className="flex flex-col space-y-4 my-4">
                            {
                                <>
                                    {/* Billing Account Number */}
                                    <div className="flex items-center space-x-4">
                                        <label htmlFor="billingAccountNumber" className="w-1/3 font-semibold">
                                            Billing Account Number<span className="text-red-500">*</span>
                                        </label>
                                        <Input
                                            id="billingAccountNumber"
                                            // placeholder="Enter Billing Account Number"
                                            value={billingAccountNumber}
                                            onChange={(e) => setBillingAccountNumber(e.target.value)}
                                            className="w-2/3 ActiveServiceinput" />
                                    </div>
                                    {errors.billingAccountNumber && <div className="text-red-500">{errors.billingAccountNumber}</div>}

                                    {/* Role */}
                                    <div className="flex items-center space-x-4">
                                        <label htmlFor="role" className="w-1/3 font-semibold">
                                            Role<span className="text-red-500">*</span>
                                        </label>
                                        <Input
                                            id="role"
                                            // placeholder="Enter First Name"
                                            value={selectedRole}
                                            onChange={(e) => setSelectedRole(e.target.value)}
                                            className="w-2/3 ActiveServiceinput" />
                                    </div>
                                    {errors.role && <div className="text-red-500">{errors.role}</div>}
                                    {/* <div className="flex items-center space-x-4">
                                    <label htmlFor="ratePlanGroup" className="w-1/3 font-semibold">
                                        Role
                                    </label>
                                    <Select
                                        showSearch
                                        value={selectedRole === 'No options' ? null : { label: selectedRole, value: selectedRole }}
                                        id="ratePlanGroup"
                                        // placeholder="Select Rate Plan Group"
                                        options={roleOptions > 0 ? roleOptions.map((option: string) => ({
                                            label: option,
                                            value: option,
                                        })) : [{ value: 'No options', label: 'No options' }]}
                                        onChange={handleRoleChange}
                                        suffixIcon={
                                            <ChevronDownIcon className="w-4 h-4 text-gray-600 arrow " />
                                        }
                                        className="w-2/3 mt-1 mb-2" />
                                </div> */}

                                    {/* Subscriber First Name */}
                                    <div className="flex items-center space-x-4">
                                        <label htmlFor="subscribeFirstName" className="w-1/3 font-semibold">
                                            Subscriber First Name<span className="text-red-500">*</span>
                                        </label>
                                        <Input
                                            id="subscribeFirstName"
                                            // placeholder="Enter First Name"
                                            value={subscribeFirstName}
                                            onChange={(e) => setSubscribeFirstName(e.target.value)}
                                            className="w-2/3 ActiveServiceinput" />
                                    </div>
                                    {errors.subscribeFirstName && <div className="text-red-500">{errors.subscribeFirstName}</div>}

                                    {/* Subscriber Last Name */}
                                    <div className="flex items-center space-x-4">
                                        <label htmlFor="subscribeLastName" className="w-1/3 font-semibold">
                                            Subscriber Last Name<span className="text-red-500">*</span>
                                        </label>
                                        <Input
                                            id="subscribeLastName"
                                            // placeholder="Enter Last Name"
                                            value={subscribeLastName}
                                            onChange={(e) => setSubscribeLastName(e.target.value)}
                                            className="w-2/3 ActiveServiceinput" />
                                    </div>
                                    {errors.subscribeLastName && <div className="text-red-500">{errors.subscribeLastName}</div>}

                                    {/* Street Number */}
                                    <div className="flex items-center space-x-4">
                                        <label htmlFor="streetNumber" className="w-1/3 font-semibold">
                                            Street Number<span className="text-red-500">*</span>
                                        </label>
                                        <Input
                                            id="streetNumber"
                                            // placeholder="Enter Street Number"
                                            value={streetNumber}
                                            onChange={(e) => setStreetNumber(e.target.value)}
                                            className="w-2/3 ActiveServiceinput" />
                                    </div>
                                    {errors.streetNumber && <div className="text-red-500">{errors.streetNumber}</div>}

                                    {/* Street Direction */}
                                    <div className="flex items-center space-x-4">
                                        <label htmlFor="streetDirection" className="w-1/3 font-semibold">
                                            Street Direction
                                        </label>
                                        <Input
                                            id="streetDirection"
                                            // placeholder="Enter Street Direction"
                                            value={streetDirection}
                                            onChange={(e) => setStreetDirection(e.target.value)}
                                            className="w-2/3 ActiveServiceinput" />
                                    </div>
                                    {errors.streetDirection && <div className="text-red-500">{errors.streetDirection}</div>}

                                    {/* Street Name */}
                                    <div className="flex items-center space-x-4">
                                        <label htmlFor="streetName" className="w-1/3 font-semibold">
                                            Street Name<span className="text-red-500">*</span>
                                        </label>
                                        <Input
                                            id="streetName"
                                            // placeholder="Enter Street Name"
                                            value={streetName}
                                            onChange={(e) => setStreetName(e.target.value)}
                                            className="w-2/3 ActiveServiceinput" />
                                    </div>
                                    {errors.streetName && <div className="text-red-500">{errors.streetName}</div>}

                                    {/* City */}
                                    <div className="flex items-center space-x-4">
                                        <label htmlFor="city" className="w-1/3 font-semibold">
                                            City<span className="text-red-500">*</span>
                                        </label>
                                        <Input
                                            id="city"
                                            // placeholder="Enter City"
                                            value={city}
                                            onChange={(e) => setCity(e.target.value)}
                                            className="w-2/3 ActiveServiceinput" />
                                    </div>
                                    {errors.city && <div className="text-red-500">{errors.city}</div>}

                                    {/* State */}
                                    <div className="flex items-center space-x-4">
                                        <label htmlFor="state" className="w-1/3 font-semibold">
                                            State<span className="text-red-500">*</span>
                                        </label>
                                        <Select
                                            showSearch
                                            value={selectedStateCode || null}
                                            id="state"
                                            // placeholder="Select State"
                                            options={stateOptions.length > 0 ? stateOptions : [{ value: 'No options', label: 'No options' }]}
                                            onChange={handleSelectedStateChange}
                                            suffixIcon={
                                                <ChevronDownIcon className="w-4 h-4 arrow  text-gray-600" />
                                            }
                                            className="w-2/3 mb-2" />
                                    </div>
                                    {errors.state && <div className="text-red-500">{errors.state}</div>}

                                    {/* Zip Code */}
                                    <div className="flex items-center space-x-4">
                                        <label htmlFor="zipCode" className="w-1/3 font-semibold">
                                            Zip Code<span className="text-red-500">*</span>
                                        </label>
                                        <Input
                                            id="zipCode"
                                            // placeholder="Enter Zip Code"
                                            value={zipCode}
                                            onChange={(e) => setZipCode(e.target.value)}
                                            className="w-2/3  mt-1 ActiveServiceinput" />
                                    </div>
                                    {errors.zipCode && <div className="text-red-500">{errors.zipCode}</div>}

                                </>
                            }
                        </div>

                    </>
                )
                }
            </>

        </Modal>
    );
}
);

export default UpdatePPUAddressModal;
