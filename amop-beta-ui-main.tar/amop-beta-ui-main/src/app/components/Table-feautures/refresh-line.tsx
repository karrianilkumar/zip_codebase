// RefreshLineModal.tsx
import React, { useState, useEffect, forwardRef, useImperativeHandle } from "react";
import { Modal, Spin, Input, Checkbox } from "antd";
import { useFeatureStore } from '@/app/sim_management/inventory/featureStore';
import { useInventoryAllChangeTypesStore } from '@/app/stores/inventorytAllChangeTypesStore';
import { useCustomerProfileStore } from "@/app/billing/killbill_stores/customer_profile_store";

interface RefreshLineProps {
    visible: boolean;
    onCancel: () => void;
    onUpdate: (updatedRow: any, event_type: string) => void;
    rowData?: any;
    isAllChangeTypesFlow?: Boolean;
}

export interface RefreshLineContentRef {
    runValidation: () => Promise<void> | void;
    runSubmit: () => Promise<void> | void; 
     hasValidData: () => boolean; // Add this method
}

const RefreshLineModal = forwardRef<RefreshLineContentRef, RefreshLineProps>(
    ({ visible, onCancel, onUpdate, rowData, isAllChangeTypesFlow }, ref) => {
        const [formData, setFormData] = useState<any>({ ...rowData });
        const [loading, setLoading] = useState(false);
        const [billingAccountNumber, setBillingAccountNumber] = useState<string | undefined>(undefined);
        const [billingAccountError, setBillingAccountError] = useState("");
        // const { is2OFilterLoaded } = useFeatureStore();
            const { setIs2OFilterLoaded,is2OFilterLoaded } = useCustomerProfileStore();
        
        const { activeChange, isAllChangeType, setIsValidated, setValidationTrigger, setsuccessFullChangeTypes, successFullChangeTypes } = useInventoryAllChangeTypesStore();
        const [saveChanges, setSaveChanges] = useState<boolean>(true);

        useEffect(() => {
            if (visible) {
                setBillingAccountNumber(undefined);
            }
            setBillingAccountError("");
        }, [visible]);
         // Add this method to check if any field has valid data
        const hasValidData = () => {
            return !!(billingAccountNumber && billingAccountNumber.trim() !== "");
        };
        const handleUpdate = () => {
            let hasError = false;

            if (!billingAccountNumber) {
                setBillingAccountError("Billing account number is required.");
                console.log("Validation failed: Billing account number is required.");
                hasError = true;
            } else {
                setBillingAccountError("");
            }

            // Stop if validation failed in normal flow
            if (hasError && !isAllChangeType) {
            return;
            }


            // If no validation errors, proceed with update
            if (!hasError && !isAllChangeType) {
                onUpdate({ ...formData, billingAccountNumber: billingAccountNumber?.trim() }, "Refresh A Line");
                setBillingAccountError("");
            }

            // Remove from successful change types if there are errors
            setsuccessFullChangeTypes(
                successFullChangeTypes.filter((c: any) => c !== activeChange)
            );

            // Handle all change types validation flow
            if (isAllChangeType) {
                const isAnyFieldFilled = !!billingAccountNumber;

                if (!isAnyFieldFilled) {
                    // None of the fields entered → clear errors and allow
                    setBillingAccountError("");
                    setIsValidated(true);
                    setValidationTrigger();
                    return;
                } else {
                    // Check if billing account number is required and missing
                    if (!billingAccountNumber) {
                        setBillingAccountError("Billing account number is required.");
                        return;
                    }

                    // All validations passed
                    setBillingAccountError("");
                    setIsValidated(true);
                    if (saveChanges) {
                        setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
                    }
                    setValidationTrigger();
                    return;
                }
            } else {
                // Normal validation path
                return;
            }
        };

        const handleCancel = () => {
            setBillingAccountError("");
            setFormData(rowData);
            onCancel();
        };
        const handlesubmit = () => {
            onUpdate({ ...formData, billingAccountNumber: billingAccountNumber?.trim() }, "Refresh A Line");
            setBillingAccountError("");
        }
        useImperativeHandle(ref, () => ({
            runValidation: handleUpdate,
            runSubmit:handlesubmit,
            hasValidData: hasValidData // NEW: Add this method
        }));

        // The main content that will be reused
        const renderContent = () => {
            if (loading || is2OFilterLoaded) {
                return (
                    <div className="popup flex justify-center items-center w-full h-full">
                        <Spin size="large" />
                    </div>
                );
            }

            return (
                <>
                    {isAllChangeType && (
                        <div className="flex justify-end px-4">
                            <span className="mr-2 font-semibold">Save Changes</span>
                            <Checkbox
                                checked={saveChanges}
                                onChange={(e) => {
                                    if (!e.target.checked) {
                                        setsuccessFullChangeTypes(
                                            successFullChangeTypes.filter((c: any) => c !== activeChange)
                                        );
                                    }
                                    setSaveChanges(e.target.checked)
                                }}
                                className="custom-checkbox"
                            >

                            </Checkbox>
                        </div>
                    )}
                <div className="flex flex-col space-y-4 my-4">
                    {/* Billing Account Number */}
                    <div className="flex items-center space-x-4">
                        <label htmlFor="billingAccountNumber" className="field-label !w-[40%]">
                            Billing Account Number<span className="text-red-500">*</span>
                        </label>
                        <Input
                            id="billingAccountNumber"
                            value={billingAccountNumber}
                            onChange={(e) => {
                                setFormData({ ...formData, billingAccountNumber: e.target.value });
                                setBillingAccountNumber(e.target.value);
                            }}
                            className="input !w-[60%]"
                        />
                    </div>
                    {billingAccountError && (
                        <div className="text-red-500 text-sm mt-1">{billingAccountError}</div>
                    )}
                </div>
                </>
            );
        };

        // Conditional rendering: Modal OR div based on isAllChangeTypesFlow
        if (isAllChangeTypesFlow) {
            // Render just the content (div) for All Change Types flow
            return (
                <div className="p-4">
                    {renderContent()}
                </div>
            );
        }

        return (
            <Modal
                title={
                    <div className="mt-[-10px]">
                        <span className="text-[19px]">Refresh A Line</span>
                    </div>
                }
                visible={visible}
                centered
                onCancel={handleCancel}
                footer={[
                    <div className="flex justify-center space-x-2 mt-12" key="buttons">
                        <button
                            key="cancel"
                            onClick={onCancel}
                            className="cancel-btn h-[30px] text-base"
                            style={{ fontFamily: "Calibri, sans-serif" }}
                        >
                            Cancel
                        </button>
                        <button
                            key="update"
                            onClick={handleUpdate}
                            className="save-btn text-base border-none"
                            style={{ fontFamily: "Calibri, sans-serif" }}
                        >
                            Update
                        </button>
                    </div>,
                ]}
                width={500}
                style={{ height: "500px" }}
            >
                {renderContent()}
            </Modal>
        );
    }
);

export default RefreshLineModal;