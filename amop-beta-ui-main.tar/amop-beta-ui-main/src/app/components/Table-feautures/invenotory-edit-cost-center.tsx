import React, { forwardRef,useImperativeHandle,useState, useEffect } from "react";
import { Modal,Row, Col, Spin, Checkbox } from "antd";
import { useAuth } from "@/app/components/auth_context";
import { ENV_ROUTES } from "../routes/route_constants";
import axios from "axios";
import { getCurrentDateTime } from "../header_constants";
import Select from "react-select";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { useInventoryAllChangeTypesStore } from "@/app/stores/inventorytAllChangeTypesStore";
import { useCustomerProfileStore } from "@/app/billing/killbill_stores/customer_profile_store";

interface InventoryEditCostCenterModalProps {
  visible: boolean;
  onCancel: () => void;
  onUpdate: (updatedRow: any, event_type: string) => void;
  rowData?: any;
  is2OChange?: Boolean;
  isSingle ?:Boolean;
  isAllChangeTypesFlow?: Boolean;
}
export interface EditCostCenterContentRef {
  runValidation: () => Promise<void> | void;
  runSubmit: () => Promise<void> | void;
  hasValidData: () => boolean; // NEW: Method to check if data is valid
}
 const InventoryEditCostCenterModal = forwardRef<EditCostCenterContentRef, InventoryEditCostCenterModalProps>(({
  visible,
  onCancel,
  onUpdate,
  rowData,is2OChange ,isSingle,
   isAllChangeTypesFlow = false 
},ref) => {
  // const [formData, setFormData] = useState<any>((!is2OChange || isSingle) ? rowData : {});
  const [formData, setFormData] = useState<any>(rowData ? rowData : {});
  const { username, token, partner, selectedDb, metaData,role, firstLastName, sessionId } = useAuth();
  const [loading, setLoading] = useState(false);
  const [costCenterOptions, setCostCenterOptions] = useState<any>([]);
  // const { is2OFilterLoaded  } = useFeatureStore();
      const { setIs2OFilterLoaded,is2OFilterLoaded } = useCustomerProfileStore();
  
  const versionBasedPath = is2OChange ? ENV_ROUTES.INVENTORY : ENV_ROUTES.SIM_MANAGEMENT
  const { activeChange , isAllChangeType,setIsValidated,setValidationTrigger, setsuccessFullChangeTypes, successFullChangeTypes, isSubmit } = useInventoryAllChangeTypesStore();
  const [saveChanges, setSaveChanges] = useState<boolean>(true);
  const [errors, setErrors] = useState<any>([]);
  const fetchData = async () => {
    setLoading(true);
    try {
      const url = versionBasedPath;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/fetch_cost_centers",
        role_name: role,
        parent_module: "Sim Management",
        module_name:"Inventory",
        feature_module_name: "Inventory",
        request_received_at: getCurrentDateTime(),
        service_provider_id:Number(rowData?.service_provider_id) || 1,
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);  
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        const cost_centers = parsedData?.cost_centers || []
        setCostCenterOptions(cost_centers)
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      setLoading(false);

    }
  };

  useEffect(() => {
    if (visible) {
      fetchData();
    }
  }, [visible]);

  // NEW: Add method to check if component has valid data
  const hasValidData = () => {
    return formData.cost_center && formData.cost_center.trim() !== "";
  };
 
const handleUpdate = () => {
  const errors: { [key: string]: string } = {};

  if (!formData.cost_center && !isAllChangeType) {
    errors.costcenter = "Please Enter Cost Center";
  }
  setErrors(errors);

  // ✅ Update FULL DATA for single or multiple rows
  let updatedData;
  if (Array.isArray(rowData)) {
    updatedData = rowData.map((row) => ({
      ...row,
      cost_center: formData.cost_center
    }));
  } else {
    updatedData = { ...rowData, cost_center: formData.cost_center };
  }

  if (isAllChangeType) {
    if (!formData.cost_center || formData.cost_center.trim() === "") {
      setsuccessFullChangeTypes(
        successFullChangeTypes.filter((c: any) => c !== activeChange)
      );
      setIsValidated(true);
      setValidationTrigger();
      return;
    }

    if (saveChanges && formData.cost_center !== "") {
      setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
    }

    setIsValidated(true);
    setValidationTrigger();

    // ✅ Pass updated row(s) to parent
    onUpdate(updatedData, "Edit Cost Center");
    return;
  }

  // ✅ Normal edit flow
  if (Object.keys(errors).length === 0) {
    onUpdate(updatedData, "Edit Cost Center");
  }
};
const handleSubmit = () => {
  console.log("handleSubmit called in Edit Cost Center");

  let updatedData;
  if (Array.isArray(rowData)) {
    updatedData = rowData.map((row) => ({
      ...row,
      cost_center: formData.cost_center
    }));
  } else {
    updatedData = { ...rowData, cost_center: formData.cost_center };
  }

  console.log("Submitting:", updatedData);
  onUpdate(updatedData, "Edit Cost Center");
};

const handleCancel = () => {
    setFormData((!is2OChange || isSingle) ? rowData : {});
    onCancel();
  };
 
  useEffect(() => {
    if (visible) {
        setFormData((!is2OChange || isSingle) ? rowData : {});
      }
  }, [rowData, visible]);

  

  // The main content that will be reused
    const renderContent = () => {
      if (loading || is2OFilterLoaded) {
        return (
          <div className="popup flex justify-center items-center w-full h-full">
            <Spin size="large" />
          </div>
        );
      }
  
      return (
        <>
          {isAllChangeType && (
            <div className="flex justify-end px-4">
              <span className="mr-2 font-semibold">Save Changes</span>
              <Checkbox
                checked={saveChanges}
                onChange={(e) => {
                  if (!e.target.checked) {
                    setsuccessFullChangeTypes(
                      successFullChangeTypes.filter((c: any) => c !== activeChange)
                    );
                  }
                  setSaveChanges(e.target.checked)
                }}
                className="custom-checkbox"
              >

              </Checkbox>
            </div>
          )}
          <Row style={{marginBottom:16}}>
    {/* <Col span={8}>
      <label
        className="text-lg"
        htmlFor="iccid"
        style={{ fontFamily: "Calibri, sans-serif" }}
      >
        ICCID
      </label>
    </Col> */}
    {/* <Col span={16}>
      <Input
        className="mt-1"
        id="iccid"
        value={formData.iccid}
        onChange={(e) => setFormData({ ...formData, iccid: e.target.value })}
      />
    </Col> */}
  </Row>
  <Row>
        <Col span={8}>
          <label className="text-lg" htmlFor="cost_center" style={{ fontFamily: "Calibri, sans-serif" }}>
            Cost Center<span className="text-red-500">*</span>
          </label>
        </Col>
        <Col span={16}>
          {formData?.service_provider_display_name === "Kore" ? (
            <Select
              id="cost_center"
              className="mt-1"
              options={costCenterOptions.map((option:any)=>({value:option,label:option}))}
              value={{value:formData.cost_center,label:formData.cost_center}}
              onChange={(selectedOption) =>
                setFormData({ ...formData, cost_center: selectedOption ? selectedOption.value : "" })
              }
              isClearable
              placeholder="Select Cost Center"
              isLoading={loading}
            />
          ) : (
            <input
              className="input"
              id="cost_center"
              value={formData.cost_center}
              onChange={(e) => setFormData({ ...formData, cost_center: e.target.value })}
            />
          )}
              {errors.costcenter && (
                <div>
                  <span className="text-red-500 mt-2">{errors.costcenter}</span>
                </div>
              )}
        </Col>
      </Row>

          </>
      );
    };

    useImperativeHandle(ref, () => ({
       runValidation: handleUpdate,
       runSubmit:handleSubmit,
      hasValidData: hasValidData, // NEW: Expose this method
     }));
  
    // Conditional rendering: Modal OR div based on isAllChangeTypesFlow
    if (isAllChangeTypesFlow) {
      // Render just the content (div) for All Change Types flow
      return (
        <div className="p-4">
          {renderContent()}
        </div>
      );
    }
  return (
    <Modal
      title={
        <div className="mt-[-10px]">
          <span className="text-[19px]">Edit Cost Center</span>
        </div>
      }
      visible={visible}
      centered
      onCancel={handleCancel}
      footer={[
        <div className="flex justify-center space-x-2 mt-12" key="buttons">
          <button
            key="cancel"
            onClick={onCancel}
            className="cancel-btn h-[30px] text-base"
            style={{ fontFamily: "Calibri, sans-serif" }}
          >
            Cancel
          </button>
          <button
            key="update"
            onClick={handleUpdate}
            className="save-btn  text-base border-none"
            style={{ fontFamily: "Calibri, sans-serif" }}
          >
            Update
          </button>
        </div>,
      ]}
      width={400}
      style={{ height: "500px" }}
    >
      <>
      {(loading || is2OFilterLoaded) ? (
          <div className="popup flex justify-center items-center w-full h-full mt-4">
            <Spin size="large" />
          </div>
        ) : (
          <>
          <Row style={{marginBottom:16}}>
    {/* <Col span={8}>
      <label
        className="text-lg"
        htmlFor="iccid"
        style={{ fontFamily: "Calibri, sans-serif" }}
      >
        ICCID
      </label>
    </Col> */}
    {/* <Col span={16}>
      <Input
        className="mt-1"
        id="iccid"
        value={formData.iccid}
        onChange={(e) => setFormData({ ...formData, iccid: e.target.value })}
      />
    </Col> */}
  </Row>
  <Row>
        <Col span={8}>
          <label className="text-lg" htmlFor="cost_center" style={{ fontFamily: "Calibri, sans-serif" }}>
            Cost Center <span className="text-red-500">*</span>
          </label>
        </Col>
        <Col span={16}>
          {rowData?.service_provider_display_name === "Kore" ? (
            <Select
              id="cost_center"
              className="mt-1"
              options={costCenterOptions.map((option:any)=>({value:option,label:option}))}
              value={{value:formData.cost_center,label:formData.cost_center}}
              onChange={(selectedOption) =>
                setFormData({ ...formData, cost_center: selectedOption ? selectedOption.value : "" })
              }
              isClearable
              placeholder="Select Cost Center"
              isLoading={loading}
            />
          ) : (
            <input
              className="input"
              id="cost_center"
              value={formData.cost_center}
              onChange={(e) => setFormData({ ...formData, cost_center: e.target.value })}
            />
          )}
                  {errors.costcenter && (
                    <div>
                      <span className="text-red-500 mt-2">{errors.costcenter}</span>
                    </div>
                  )}
        </Col>
      </Row>

          </>
        )
      }
      </>
     
    </Modal>
  );
}
 );

export default InventoryEditCostCenterModal;
