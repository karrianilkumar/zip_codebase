import React, { forwardRef,useImperativeHandle,useState, useEffect } from "react";
import { Modal,Row, Col, Spin, Checkbox } from "antd";
import { useAuth } from "@/app/components/auth_context";
import { ENV_ROUTES } from "../routes/route_constants";
import axios from "axios";
import { getCurrentDateTime } from "../header_constants";
import Select from "react-select";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { useInventoryAllChangeTypesStore } from "@/app/stores/inventorytAllChangeTypesStore";
import { DropdownStyles } from "@/app/components/css/dropdown";
import { useCustomerProfileStore } from "@/app/billing/killbill_stores/customer_profile_store";

interface ResetVoicemailPasswordModalProps {
  visible: boolean;
  onCancel: () => void;
  onUpdate: (updatedRow: any, event_type: string) => void;
  rowData?: any;
  is2OChange?: Boolean;
  isSingle ?:Boolean;
  isAllChangeTypesFlow?: Boolean;
}
export interface ResetVoicemailPasswordContentRef {
  runValidation: () => Promise<void> | void;
  runSubmit: () => Promise<void> | void;
  hasValidData: () => boolean;
}
 const ResetVoicemailPassword = forwardRef<ResetVoicemailPasswordContentRef, ResetVoicemailPasswordModalProps>(({
  visible,
  onCancel,
  onUpdate,
  rowData,is2OChange ,isSingle,
   isAllChangeTypesFlow = false 
},ref) => {
  // const [formData, setFormData] = useState<any>((!is2OChange || isSingle) ? rowData : {});
  const [formData, setFormData] = useState<any>(rowData ? rowData : {});
  const { username, token, partner, selectedDb, role, firstLastName, sessionId } = useAuth();
  const [loading, setLoading] = useState(false);
  const [costCenterOptions, setCostCenterOptions] = useState<any>([]);
  // const { is2OFilterLoaded  } = useFeatureStore();

    const { setIs2OFilterLoaded,is2OFilterLoaded } = useCustomerProfileStore();
  const versionBasedPath = is2OChange ? ENV_ROUTES.INVENTORY : ENV_ROUTES.SIM_MANAGEMENT
  const { activeChange , isAllChangeType,setIsValidated,setValidationTrigger, setsuccessFullChangeTypes, successFullChangeTypes } = useInventoryAllChangeTypesStore();
  const [saveChanges, setSaveChanges] = useState<boolean>(true);
  const [errors, setErrors] = useState<any>([]);
  const [billingAccountOptions, setBillingAccountOptions] = useState<any[]>([]);

useEffect(() => {
  const fetchBillingAccounts = async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username,
        firstLastName,
        path: "/get_user_billing_account_number",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Inventory",
        feature_module_name: "Inventory",
        request_received_at: getCurrentDateTime(),
        service_provider_id: Number(rowData?.service_provider_id) || 1,
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const parsed = JSON.parse(response.data.body);

      if (parsed.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content: parsed.message || "Unable to fetch billing accounts.",
          centered: true,
        });
      } else {
        const options = parsed?.data || [];
        setBillingAccountOptions(options);
      }
    } catch (error) {
      console.error("Error fetching billing accounts:", error);
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  // ✅ Only fetch when modal becomes visible
  if (visible === true) {
    if (!isAllChangeType) {
      setFormData((prev: any) => ({
        ...prev,
        billing_account_number: "",
      }));
    }
    fetchBillingAccounts();
  }
}, [visible]); // Keep visible as dependency, but add condition inside

// Add this method to check if any field has valid data
const hasValidData = () => {
  const isAnyFieldFilled =
    (formData.billing_account_number && formData.billing_account_number.trim() !== "") ||
    (formData.new_voicemail_pin && formData.new_voicemail_pin.trim() !== "");
  return isAnyFieldFilled;
};

 
const handleUpdate = () => {
  const errors: { [key: string]: string } = {};

  if (!hasValidData()) {
  // no user input — skip validations and allow move
  setErrors({});
  setIsValidated(true);
  setValidationTrigger();
  return;
}

  // ✅ Validation rules (always require billing account)
  if (!formData.billing_account_number || formData.billing_account_number.trim() === "") {
    errors.billing_account_number = "Please enter Billing Account Number";
  }

  // When "Apply to All" (isAllChangeType) we also require new_voicemail_pin
  if (isAllChangeType) {
    if (!formData.new_voicemail_pin || formData.new_voicemail_pin.trim() === "") {
      errors.new_voicemail_pin = "Please enter New Voicemail PIN";
    }
  }

  setErrors(errors);

  // Stop execution if validation errors exist
  if (Object.keys(errors).length > 0) {
    return;
  }

  // rest of your logic remains the same...
  let updatedData;
  if (Array.isArray(rowData)) {
    updatedData = rowData.map((row) => ({
      ...row,
      ...formData, // merge all fields
    }));
  } else {
    updatedData = { ...rowData, ...formData };
  }

  if (isAllChangeType) {
    // This block already handles billing_account_number checks & successFullChangeTypes.
    // Since above we enforced new_voicemail_pin presence, you can continue with same flow.

    if (saveChanges) {
      if (!successFullChangeTypes.includes(activeChange)) {
        setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
      }
    }

    setIsValidated(true);
    setValidationTrigger();

    onUpdate(updatedData, "Reset Voicemail Password");
    return;
  }

  // Normal edit flow
  onUpdate(updatedData, "Reset Voicemail Password");
};


const handleSubmit = () => {
  console.log("handleSubmit called in Reset Voicemail Password");

  let updatedData;
  if (Array.isArray(rowData)) {
    updatedData = rowData.map((row) => ({
      ...row,
      ...formData, // includes msisdn, billing_account_number, voicemail_field_name, etc.
    }));
  } else {
    updatedData = { ...rowData, ...formData };
  }

  console.log("Submitting:", updatedData);
  onUpdate(updatedData, "Reset Voicemail Password");
};

const handleCancel = () => {
    setFormData((!is2OChange || isSingle) ? rowData : {});
    onCancel();
  };
 
  useEffect(() => {
    if (visible) {
        setFormData((!is2OChange || isSingle) ? rowData : {});
      }
  }, [rowData, visible]);

  // The main content that will be reused
    const renderContent = () => {
      if (loading || is2OFilterLoaded) {
        return (
          <div className="popup flex justify-center items-center w-full h-full">
            <Spin size="large" />
          </div>
        );
      }
  
      return (
        <>
          {isAllChangeType && (
            <div className="flex justify-end px-4">
              <span className="mr-2 font-semibold">Save Changes</span>
              <Checkbox
                checked={saveChanges}
                onChange={(e) => {
                  if (!e.target.checked) {
                    setsuccessFullChangeTypes(
                      successFullChangeTypes.filter((c: any) => c !== activeChange)
                    );
                  }
                  setSaveChanges(e.target.checked)
                }}
                className="custom-checkbox"
              >

              </Checkbox>
            </div>
          )}
          
              {/* Service/Subscriber Number (MSISDN) */}
              {/* <Row>
                  <Col span={8}>
                      <label className="text-lg" htmlFor="msisdn" style={{ fontFamily: "Calibri, sans-serif" }}>
                          Service/Subscriber Number (MSISDN)<span className="text-red-500">*</span>
                      </label>
                  </Col>
                  <Col span={16}>
                      <input
                          className="input"
                          id="msisdn"
                          value={formData.msisdn}
                          onChange={(e) => setFormData({ ...formData, msisdn: e.target.value })}
                      />
                      {errors.msisdn && (
                          <div>
                              <span className="text-red-500 mt-2">{errors.msisdn}</span>
                          </div>
                      )}
                  </Col>
              </Row> */}

              {/* Billing Account Number */}
              <div className="mb-4">
              <Row>
                  <Col span={8}>
                      <label className="text-lg" htmlFor="billing_account_number" style={{ fontFamily: "Calibri, sans-serif" }}>
                          Billing Account Number<span className="text-red-500">*</span>
                      </label>
                  </Col>
                  <Col span={16}>
                      {billingAccountOptions.length === 0 ? (
  <input
    id="billing_account_number"
    className="input w-full"
    value={formData.billing_account_number || ""}
    onChange={(e) =>
      setFormData({ ...formData, billing_account_number: e.target.value })
    }
  />
) : (
  <Select
    id="billing_account_number"
    placeholder="Select Billing Account Number"
    options={
      billingAccountOptions.map((item: string) => ({
        label: item,
        value: item,
      })) || []
    }
    value={
      formData.billing_account_number
        ? { label: formData.billing_account_number, value: formData.billing_account_number }
        : null
    }
    onChange={(selectedOption: any) =>
      setFormData({
        ...formData,
        billing_account_number: selectedOption ? selectedOption.value : "",
      })
    }
    isClearable
    className="w-full"
    styles={DropdownStyles}
     maxMenuHeight={150}    
  />
)}
{errors.billing_account_number && (
  <span className="text-red-500 mt-1 block">{errors.billing_account_number}</span>
)}
                  </Col>
              </Row>
              </div>

              {/* Voicemail Field Name */}
              {/* <Row>
                  <Col span={8}>
                      <label className="text-lg" htmlFor="voicemail_field_name" style={{ fontFamily: "Calibri, sans-serif" }}>
                          Voicemail Field Name<span className="text-red-500">*</span>
                      </label>
                  </Col>
                  <Col span={16}>
                      <input
                          className="input"
                          id="voicemail_field_name"
                          value={formData.voicemail_field_name}
                          onChange={(e) => setFormData({ ...formData, voicemail_field_name: e.target.value })}
                      />
                      {errors.voicemail_field_name && (
                          <div>
                              <span className="text-red-500 mt-2">{errors.voicemail_field_name}</span>
                          </div>
                      )}
                  </Col>
              </Row> */}

              {/* New Voicemail PIN */}
              <div className="mb-4">
              <Row>
                  <Col span={8}>
                      <label className="text-lg" htmlFor="new_voicemail_pin" style={{ fontFamily: "Calibri, sans-serif" }}>
                          New Voicemail PIN
                           {isAllChangeType && <span className="text-red-500"> *</span>}
                      </label>
                  </Col>
                  <Col span={16}>
                      <input
                          className="input"
                          id="new_voicemail_pin"
                          value={formData.new_voicemail_pin}
                          onChange={(e) => setFormData({ ...formData, new_voicemail_pin: e.target.value })}
                      />
                     {errors.new_voicemail_pin && (
                        <span className="text-red-500 mt-1 block">{errors.new_voicemail_pin}</span>
                      )}
                  </Col>
              </Row>
              </div>


          </>
      );
    };

    useImperativeHandle(ref, () => ({
       runValidation: handleUpdate,
       runSubmit:handleSubmit,
        hasValidData: hasValidData,
     }));
  
    // Conditional rendering: Modal OR div based on isAllChangeTypesFlow
    if (isAllChangeTypesFlow) {
      // Render just the content (div) for All Change Types flow
      return (
        <div className="p-4">
          {renderContent()}
        </div>
      );
    }
  return (
      <Modal
          title={
              <div className="mt-[-10px]">
                  <span className="text-[19px]">Reset Voicemail Password</span>
              </div>
          }
          visible={visible}
          centered
          onCancel={handleCancel}
          footer={[
              <div className="flex justify-center space-x-2 mt-12" key="buttons">
                  <button
                      key="cancel"
                      onClick={onCancel}
                      className="cancel-btn h-[30px] text-base"
                      style={{ fontFamily: "Calibri, sans-serif" }}
                  >
                      Cancel
                  </button>
                  <button
                      key="update"
                      onClick={handleUpdate}
                      className="save-btn  text-base border-none"
                      style={{ fontFamily: "Calibri, sans-serif" }}
                  >
                      Update
                  </button>
              </div>,
          ]}
          width={400}
          style={{ height: "500px" }}
      >
          <>
              {(loading || is2OFilterLoaded) ? (
                  <div className="popup flex justify-center items-center w-full h-full mt-4">
                      <Spin size="large" />
                  </div>
              ) : (
                  <>
                      {/* Service/Subscriber Number (MSISDN) */}
                      {/* <div className="mb-4">
                          <label
                              htmlFor="msisdn"
                              className="block text-lg font-medium mb-1"
                              style={{ fontFamily: "Calibri, sans-serif" }}
                          >
                              Service/Subscriber Number (MSISDN)<span className="text-red-500">*</span>
                          </label>
                          <input
                              className="input w-full"
                              id="msisdn"
                              value={formData.msisdn}
                              onChange={(e) => setFormData({ ...formData, msisdn: e.target.value })}
                          />
                          {errors.msisdn && <span className="text-red-500 mt-1 block">{errors.msisdn}</span>}
                      </div> */}

                      {/* Billing Account Number */}
                      <div className="mb-4">
                          {/* <label
                              htmlFor="billing_account_number"
                              className="block text-lg font-medium mb-1"
                              style={{ fontFamily: "Calibri, sans-serif" }}
                          >
                              Billing Account Number<span className="text-red-500">*</span>
                          </label>
                         <Select
  id="billing_account_number"
  className="w-full"
  placeholder="Select Billing Account Number"
  options={billingAccountOptions}
  value={
    billingAccountOptions.find(
      (opt) => opt.value === formData.billing_account_number
    ) || null
  }
  onChange={(selectedOption: any) =>
    setFormData({ ...formData, billing_account_number: selectedOption?.value })
  }
/> */}
<label
                              htmlFor="billing_account_number"
                              className="block text-lg font-medium mb-1"
                              style={{ fontFamily: "Calibri, sans-serif" }}
                          >
                              Billing Account Number<span className="text-red-500">*</span>
                          </label>
{billingAccountOptions.length === 0 ? (
  <input
    id="billing_account_number"
    className="input w-full"
    value={formData.billing_account_number || ""}
    onChange={(e) =>
      setFormData({ ...formData, billing_account_number: e.target.value })
    }
  />
) : (
  <Select
    id="billing_account_number"
    placeholder="Select Billing Account Number"
    options={
      billingAccountOptions.map((item: string) => ({
        label: item,
        value: item,
      })) || []
    }
    value={
      formData.billing_account_number
        ? { label: formData.billing_account_number, value: formData.billing_account_number }
        : null
    }
    onChange={(selectedOption: any) =>
      setFormData({
        ...formData,
        billing_account_number: selectedOption ? selectedOption.value : "",
      })
    }
    isClearable
    className="w-full"
    styles={DropdownStyles}
  />
)}
{errors.billing_account_number && (
  <span className="text-red-500 mt-1 block">{errors.billing_account_number}</span>
)}
                      </div>

                      {/* Voicemail Field Name */}
                      {/* <div className="mb-4">
                          <label
                              htmlFor="voicemail_field_name"
                              className="block text-lg font-medium mb-1"
                              style={{ fontFamily: "Calibri, sans-serif" }}
                          >
                              Voicemail Field Name<span className="text-red-500">*</span>
                          </label>
                          <input
                              className="input w-full"
                              id="voicemail_field_name"
                              value={formData.voicemail_field_name}
                              onChange={(e) => setFormData({ ...formData, voicemail_field_name: e.target.value })}
                          />
                          {errors.voicemail_field_name && (
                              <span className="text-red-500 mt-1 block">{errors.voicemail_field_name}</span>
                          )}
                      </div> */}

                      {/* New Voicemail PIN */}
                      <div className="mb-4">
                          <label
                              htmlFor="new_voicemail_pin"
                              className="block text-lg font-medium mb-1"
                              style={{ fontFamily: "Calibri, sans-serif" }}
                          >
                              New Voicemail PIN
                          </label>
                          <input
                              className="input w-full"
                              id="new_voicemail_pin"
                              value={formData.new_voicemail_pin}
                              onChange={(e) => setFormData({ ...formData, new_voicemail_pin: e.target.value })}
                          />
                          {errors.new_voicemail_pin && (
                              <span className="text-red-500 mt-1 block">{errors.new_voicemail_pin}</span>
                          )}
                      </div>
                  </>
              )
              }
          </>

      </Modal>
  );
}
 );

export default ResetVoicemailPassword;
