import React, { useState } from "react";
import { Checkbox, Divider, Popover, Spin } from "antd";
import { AdjustmentsHorizontalIcon } from "@heroicons/react/24/outline";

interface ColumnFilterProps {
  headers: string[];
  visibleColumns: string[];
  setVisibleColumns: (columns: string[]) => void;
  headerMap?: any;
  popupHeading?: string;
}

const ColumnFilter: React.FC<ColumnFilterProps> = ({
  headers,
  visibleColumns,
  setVisibleColumns,
  headerMap,
  popupHeading
}) => {
  const allColumns = headers;
  const [loading, setLoading] = useState(false);
  const theme = localStorage.getItem('app_theme') || 'normal';
  const ColumnIconModules = ["Service Type","Unposted","Services","Packages","Reversals","Bills","Collection Template","Product","Product Level Mapping"]
  const handleColumnVisibilityChange = (checked: boolean, column: string) => {
    const updatedVisibleColumns = checked
      ? [...visibleColumns, column]
      : visibleColumns.filter((col) => col !== column);
    setVisibleColumns(updatedVisibleColumns);
  };

  const handleCheckAllChange = (e: { target: { checked: boolean } }) => {
    setLoading(true);
    // Allow loading state to apply before proceeding
    setTimeout(() => {
      if (e.target.checked) {
        setVisibleColumns(allColumns);
      } else {
        setVisibleColumns([]);
      }
      setLoading(false);
    }, 100); // shorter delay is enough to trigger loader render
  };
  

  const formatColumnName = (name: string) => {
    return name
      .replace(/_/g, ' ')
      .split(' ')
      .map(word =>
        word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
      )
      .join(' ');
  };

  const columnContent = (
    <Spin spinning={loading}>
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          maxHeight: "300px",
          overflowY: "auto",
        }}
      >
        <Checkbox
          onChange={handleCheckAllChange}
          checked={visibleColumns.length === allColumns.length}
          style={{ marginBottom: "4px"}}
        >
          All
        </Checkbox>
        <Divider style={{ margin: "0.5rem 0 0.2rem" }} />
        {allColumns.map((column) => (
          <Checkbox
            key={column}
            value={column}
            checked={visibleColumns.includes(column)}
            onChange={(e) =>
              handleColumnVisibilityChange(e.target.checked, column)
            }
            style={{ marginBottom: "4px", whiteSpace: "nowrap"}}
          >
            {headerMap && headerMap[column]
              ? headerMap[column][0]
              : formatColumnName(column)}
          </Checkbox>
        ))}
      </div>
    </Spin>
  );


  return (
  <Popover content={columnContent} trigger="click" placement="bottom">
    <button
      className={`flex items-center p-2 ${theme === 'titanium' ? 'cancel-btn' : 'save-btn'} ${
        popupHeading  ? "w-8 justify-center" : ""
      }`}
      style={popupHeading ? { minWidth: "2rem", width: "2rem", padding: 0 } : {}}
    >
      {/* {popupHeading && ColumnIconModules.includes(popupHeading) &&( */}
      <AdjustmentsHorizontalIcon className="h-5 w-5 text-black-500" />
      {/* )} */}
      {(!popupHeading)&& (
        <span className="hidden md:inline">Columns</span>
      )}
    </button>
  </Popover>
);
};

export default ColumnFilter;