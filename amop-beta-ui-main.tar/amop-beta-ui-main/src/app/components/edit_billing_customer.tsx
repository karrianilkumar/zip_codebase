"use client";

import React, { useEffect, useState } from "react";
import { Input, Modal, DatePicker, message, Spin } from "antd";
import Select from "react-select";
import dayjs from "dayjs";
import { DropdownStyles, NonEditableDropdownStyles } from "./css/dropdown";
import { useAuth } from "./auth_context";
import { ENV_ROUTES } from "./routes/route_constants";
import { getCurrentDateTime } from "./header_constants";
import axios from "axios";
import { fireSideCannons } from "@/app/components/confetti";
interface Props {
  isOpen: boolean;
  onClose: () => void;
  rowData?: any;
  generalFields?: any;
  isEditable?: boolean;
}

const FIELD_MAP = [
  { label: "Customer Name", column: "customer_name", type: "input", mandatory: true },
  { label: "Billing Email", column: "billing_email", type: "input", mandatory: true },
  { label: "Mobile Number", column: "telephone_number", type: "input", mandatory: true },
  { label: "Account Type", column: "account_type", type: "dropdown", mandatory: true },
  { label: "Parent Accounts", column: "parent_accounts", type: "dropdown", mandatory: true },
  { label: "Billing Cycle Start Date", column: "billing_cycle_range", type: "date", mandatory: true },
  { label: "BTN Provider", column: "btn_provider", type: "dropdown", mandatory: false },
  { label: "Address Line 1", column: "address_line_1", type: "input", mandatory: true },
  { label: "Address Line 2", column: "address_line_2", type: "input", mandatory: false },
  { label: "City", column: "city", type: "input", mandatory: true },
  { label: "State", column: "state", type: "dropdown", mandatory: true },
  { label: "Postal Code", column: "postal_code", type: "input", mandatory: true },
  { label: "Country", column: "country", type: "input", mandatory: true },
  { label: "Agent", column: "agent", type: "dropdown", mandatory: true },

];

export default function EditBillingCustomer({
  isOpen,
  onClose,
  rowData = {},
  generalFields = {},
  isEditable = true,
}: Props) {
  const [formData, setFormData] = useState<Record<string, any>>({});
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const { username, role, partner, token, selectedDb, metaData, settabledata, firstLastName, sessionId, selectedBillingDb } = useAuth();
  useEffect(() => {
    // console.clear()
    console.log("rowData", rowData)
    if (!isOpen) return;
    const initial: Record<string, any> = {};
    FIELD_MAP.forEach((f) => {
      if (f.type === "date") {
        initial[f.column] = rowData?.[f.column]
          ? dayjs(rowData[f.column])
          : null;
      } else {
        initial[f.column] = rowData?.[f.column] ?? "";
      }
    });

    setFormData(initial);
    setErrors({});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [isOpen, rowData]);

  const fetchUpdatedTableData = async () => {
    try {
      setLoading(true);
      const url = ENV_ROUTES.PEOPLE_MODULE;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/people_revio_customers_list_view",
        role_name: role,
        parent_module: "People",
        module_name: "Rev.IO customer",
        feature_module_name: "Billing Customers",
        mod_pages: {
          start: 0,
          end: 100,
        },
        dropdown_options: { label: "All", value: "all" },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "Error fetching updated data. Please try again.",
          centered: true,
        });
      } else {
        const tableData_ = parsedData.data || [];
        settabledata(tableData_); // Update table data in context
      }
    } catch (error) {
      Modal.error({
        title: "Data Fetch Error",
        content: "Error fetching updated data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const onSubmit = async () => {
    const changedData = {
      ...formData,
      billing_cycle_range: formData.billing_cycle_range
        ? formData.billing_cycle_range.format("YYYY-MM-DD")
        : "",
    };

    console.log("Updated formData:", changedData);
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/update_customer_basic_details",
        role_name: role,
        module_name: "Customer Basic Details",
        feature_module_name: "Billing Platform",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        table_name: "customer_profiles",
        account_number: rowData?.account || "",
        billing_db_name: selectedBillingDb,
        action: "update",
        modified_by: firstLastName || username,
        tenant_id: rowData?.tenant_id || "",
        changed_data: { ...changedData }
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        Modal.error({
          title: "Submit Error",
          content: parsedData.message || "Error while submitting. Please try again.",
          centered: true,
        });
      } else {
        await fetchUpdatedTableData();
        fireSideCannons()
        message.success("Customer updated successfully!");
        onClose()
      }
    } catch (error) {
      Modal.error({
        title: "Submit Error",
        content: "Error while submitting. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const normalizeOptions = (arr: any[] = []) => {
    return arr.map((opt) => {
      if (opt && typeof opt === "object")
        return { label: opt.label ?? String(opt.value), value: opt.value ?? opt.label };
      return { label: String(opt), value: opt };
    });
  };

  const validateEmail = (email: string) => {
    const re = /^[\w-.]+@([\w-]+\.)+[\w-]{2,}$/;
    return re.test(String(email).toLowerCase());
  };

  const validate = () => {
    const e: Record<string, string> = {};

    FIELD_MAP.forEach((f) => {
      const val = formData?.[f.column];

      if (f.mandatory) {
        if (!val || (typeof val === "string" && val.trim() === "")) {
          if (f.column === "parent_accounts" && formData?.account_type !== "Child") {
            // skip
          } else {
            e[f.column] = `${f.label} is required`;
            return;
          }
        }
      }

      if (f.column === "billing_email" && val) {
        if (!validateEmail(val)) e.billing_email = "Enter a valid email";
      }

      if (f.column === "telephone_number" && val) {
        const digits = val.replace(/\D/g, "");
        if (digits.length !== 10) e.telephone_number = "Mobile Number must contain exactly 10 digits";
      }
      if (f.column === "customer_name" && val) {
        const nameRegex = /^[A-Za-z\s]+$/;
        if (!nameRegex.test(val)) e.customer_name = "Only alphabets are allowed";
      }

      if (f.column === "parent_accounts" && formData?.account_type === "Child") {
        if (!val || val.trim() === "") e.parent_accounts = "Parent Account is required for Child account type";
      }
      if (f.column === "postal_code" && val) {
        const postalCodeRegex = /^\d{5}$/;
        if (!postalCodeRegex.test(val)) e.postal_code = "Postal code must be exactly 5 digits";
      }
    });

    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const onSave = () => {
    if (!validate()) {
      console.warn("Validation failed", errors);
      return;
    }

    // convert date to ISO string

    onSubmit()
    // onClose();
  };

  const onChange = (column: string, value: any) => {
    if (column === "account_type" && value !== "Child") {
      setFormData((s) => ({ ...s, [column]: value, parent_accounts: "" }));
      setErrors((prev) => {
        const next = { ...prev };
        delete next.parent_accounts;
        delete next.account_type;
        return next;
      });
      return;
    }
    if (column === "postal_code") {
    const sanitizedValue = value.replace(/\D/g, "");

    setFormData((s) => ({ ...s, [column]: sanitizedValue }));
    setErrors((prev) => {
    const next = { ...prev };
    if (sanitizedValue.length !== 5) {
      next.postal_code = "Postal code must be exactly 5 digits";
    } else {
      delete next.postal_code; 
    }
    return next;
  });
    return;
   }
    setFormData((s) => ({ ...s, [column]: value }));
    setErrors((prev) => {
      const next = { ...prev };
      delete next[column];
      return next;
    });
  };

  if (!isOpen) return null;

  const multiplyFactor = (typeof window !== "undefined" && window.innerWidth < 700) ? 3.5 : 2.5;
  const modalHeight = typeof window !== "undefined" ? (window.innerHeight * 2.5) / 4 : 0;
  const modalWidth = typeof window !== "undefined" ? (window.innerWidth * multiplyFactor) / 4 : 0;

  return (
    <Modal
      title="Edit Customer"
      open={isOpen}
      onCancel={onClose}
      footer={isEditable && (
        <div className="flex justify-center gap-4 mt-4">
          <button onClick={onClose} className="cancel-btn">Cancel</button>
          <button onClick={onSave} className="save-btn">Save</button>
        </div>
      )}
      destroyOnClose
      maskClosable={false}
      width={modalWidth}
    >
      <div className="p-2 w-full space-y-4 overflow" style={{ height: modalHeight, overflow: "auto" }}>
        {loading ? (
          <div className="flex justify-center items-center h-full">
            <Spin size="large" />
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-4 mt-4">
            {FIELD_MAP.map((f) => {
              const value = formData?.[f.column] ?? "";

              const rawOptions = generalFields?.[f.column] ?? [];
              const options = normalizeOptions(rawOptions);
              const isParentDisabled = f.column === "parent_accounts" && formData?.account_type !== "Child";

              return (
                <div key={f.column}>
                  <label className="field-label">
                    {f.label} {f.mandatory && <span className="text-red-500">*</span>}
                  </label>

                  {f.type === "input" && (
                    <Input
                      disabled={!isEditable}
                      value={value}
                      onChange={(e) => onChange(f.column, e.target.value)}
                      placeholder={`Enter ${f.column}`}
                      className={`${!isEditable ? "non-editable-input" : "input"}`}
                    />
                  )}

                  {f.type === "date" && (
                    <DatePicker
                      disabled={!isEditable}
                      value={value ? dayjs(value) : null}
                      onChange={(date) => onChange(f.column, date)}
                      format="YYYY-MM-DD"
                      className={`${!isEditable ? "non-editable-input" : "input"}`}
                    />
                  )}

                  {f.type === "dropdown" && (
                    <Select
                      isDisabled={!isEditable || (f.column === "parent_accounts" && isParentDisabled)}
                      value={value ? { value, label: value } : null}
                      onChange={(option) => onChange(f.column, option?.value || "")}
                      styles={
                        !isEditable || (f.column === "parent_accounts" && isParentDisabled)
                          ? NonEditableDropdownStyles
                          : DropdownStyles
                      }
                      options={f.column === "agent" ? [{ value: "Catapult", label: "Catapult" }] : options}
                    />
                  )}

                  {errors[f.column] && <div style={{ color: "red" }}>{errors[f.column]}</div>}
                </div>
              );
            })}
          </div>
        )}

      </div>
    </Modal>
  );
}
