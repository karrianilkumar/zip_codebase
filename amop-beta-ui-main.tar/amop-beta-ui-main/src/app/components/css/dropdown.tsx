import { Color } from "antd/es/color-picker";

let theme = 'normal';

if (typeof window !== 'undefined') {
  try {
    theme = localStorage.getItem('app_theme') || 'normal';
  } catch (e) {
    console.warn("localStorage error:", e);
  }
}

let bgColor = 'white';
let NEbgColor = '#f3f4f6';
let optionBg = '#F9FAFB';
let selectedOptionBg = '#BFDBFE';
let textColor = 'black';
let optionTextColor = 'black';
console.log("Current theme:", theme);
if (theme === 'titanium') {
  bgColor = '#ffffff';
  // NEbgColor = '#ffffff';
  optionBg = '#ffffff';
  selectedOptionBg = '#2d67c2';
  textColor = '#000';
  optionTextColor = '#ffffff';
}else if (theme === 'dark') {
  bgColor = '#2d2f52';
  NEbgColor = '#031731';
  optionBg = '#031731';
  selectedOptionBg = '#5e5bb3';
  textColor = 'white';
  optionTextColor = 'white';
} else if (theme === 'red') {
  selectedOptionBg = '#FCA5A5';
} else if (theme === 'green') {
  selectedOptionBg = '#6EE7B7';
} else if (theme === 'blue') {
  selectedOptionBg = '#BFDBFE';
}

const isTitanium = theme === 'titanium';

// Non-editable styles
export const NonEditableDropdownStyles = {
  control: (base: any, state: any) => ({
    ...base,
    color: textColor,
    backgroundColor: NEbgColor, // light gray or translucent dark
    fontSize: "16px",
    width: "100%",
    border: "1px solid #d1d5db",
    borderRadius: "4px",
    transition: "border-color 0.2s ease, box-shadow 0.2s ease",
    textAlign: "left",
    padding: "2px",
    cursor: "not-allowed !important",
    "&:hover": {
      borderColor: "#3B82F6",
      backgroundColor: bgColor, // match current theme
    },
  }),

  singleValue: (provided: any) => ({
    ...provided,
    color: textColor,
    cursor: "not-allowed",
  }),

  option: (provided: any, state: any) => ({
    ...provided,
    backgroundColor: state.isSelected
      ? selectedOptionBg
      : state.isFocused
      ? selectedOptionBg
      : optionBg,
    color: optionTextColor,
    cursor: "not-allowed",
    ":hover": {
      backgroundColor: selectedOptionBg,
    },
    ":active": {
      backgroundColor: selectedOptionBg,
    },
  }),

  multiValue: (provided: any) =>
    isTitanium
      ? provided
      : {
          ...provided,
          backgroundColor: selectedOptionBg,
          color: textColor,
        },

  multiValueLabel: (provided: any) =>
    isTitanium
      ? provided
      : {
          ...provided,
          color: optionTextColor,
        },

  multiValueRemove: (provided: any) => ({
    ...provided,
    display: "none", // optional: hide "×" for non-editable mode
  }),
};

// Editable styles
export const DropdownStyles = {
  control: (base: any, state: any) => ({
    ...base,
    color: textColor,
    backgroundColor: bgColor,
    fontSize: "16px",
    width: "100%",
    border: "1px solid #d1d5db",
    borderRadius: "4px",
    transition: "border-color 0.2s ease, box-shadow 0.2s ease",
    textAlign: "left",
    padding: "2px",
    zIndex: 1, // ✅ keep control below menu
    "&:hover": {
      borderColor: "#3B82F6",
    },
  }),

  menuPortal: (base: any) => ({
    ...base,
    zIndex: 9999, // ✅ menu always on top
  }),
  singleValue: (provided: any) => ({
    ...provided,
    color: `${textColor} !important`,
  }),
  menu: (provided: any) => ({
    ...provided,
    backgroundColor: optionBg,
    zIndex: 9999, // ✅ overlay other dropdowns
  }),

  option: (provided: any, state: any) => ({
    ...provided,
     backgroundColor: state.isSelected
    ? selectedOptionBg
    : state.isFocused
    ? selectedOptionBg
    : optionBg,
    color: state.isSelected
    ? optionTextColor
    : state.isFocused
    ? optionTextColor
    : textColor,
    ":hover": {
      backgroundColor: selectedOptionBg,
      color: optionTextColor,
    },
    ":active": {
    backgroundColor: selectedOptionBg,
    color: optionTextColor,
    }
  }),

  input: (base: any) => ({
    ...base,
    color: textColor,
  }),

  multiValueRemove: (base: any) => ({
    ...base,
    color: "#000",
  }),
};


