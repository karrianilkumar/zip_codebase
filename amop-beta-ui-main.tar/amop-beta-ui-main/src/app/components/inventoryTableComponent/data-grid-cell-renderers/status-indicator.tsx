import React, { useState } from "react";
import StatusLog from "@/app/sim_management/bulk_history/status_log";

const STATUS = {
  PROCESSED: "PROCESSED",
  ERROR: "ERROR",
  PENDING: "PENDING",
  PROCESSING: "PROCESSING",
};

interface StatusIndicatorProps {
  status: (typeof STATUS)[keyof typeof STATUS];
  row: any;
  heading: string;
}

const StatusIndicator: React.FC<StatusIndicatorProps> = ({
  status,
  row,
  heading,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleClick = () => {
    if (heading === "Bulk Change History") {
      setIsModalOpen(true);
    }
  };

  let colorClass = "";

  switch (status) {
    case STATUS.PROCESSED:
      colorClass = "text-green-500";
      break;
    case STATUS.ERROR:
      colorClass = "text-red-500";
      break;
    case STATUS.PENDING:
      colorClass = "text-yellow-500";
      break;
    case STATUS.PROCESSING:
      colorClass = "text-blue-500";
      break;
    default:
      colorClass = "text-gray-500";
  }

  return (
    <>
      <div
        onClick={handleClick}
        className={`cursor-pointer rounded-md ${colorClass}`}
      >
        {status}
      </div>
      {isModalOpen&& (
        <StatusLog
          row={row}
          isOpen={isModalOpen}
          onRequestClose={() => setIsModalOpen(false)}
        />
      )}
    </>
  );
};

export default StatusIndicator;
