import { useState, useEffect } from "react";
import { FaCircle } from "react-icons/fa";
import { Tooltip } from "antd";

type UserAddressRendererProps<TRecord = any> = {
  record: TRecord;
  value: any;
  index: number;
};

export function UserAddressRenderer<TRecord>(
  props: UserAddressRendererProps<TRecord>
) {
  const { value } = props as { value: any };

  const [newValue, setNewValue] = useState<Record<string, any>>({});

  useEffect(() => {
    if (!value || value === "None") {
      setNewValue({});
      return;
    }

    const originalValue = { ...value };

    const address = originalValue?.relatedParty?.address || {};
    // delete originalValue?.relatedParty?.address;

    const relatedParty = originalValue?.relatedParty || {};
    // delete originalValue?.relatedParty;

    const billingAccount = originalValue?.billingAccount?.id || "";

    // Merge into flat object
    const merged = {
      ...relatedParty,
      ...address,
      billingAccount: billingAccount,
      hello:"hello"
    };

    setNewValue(merged);
  }, [value]);

  // Define display order (excluding role & billingAccount)
  const displayOrder = [
    "firstName",
    "lastName",
    "streetNumber",
    "streetName",
    "streetDirection",
    "streetType",
    "city",
    "state",
    "zipCode",
  ];

  // Tooltip content in fixed order
  const tooltipContent = (
    <div style={{ padding: "4px 8px" }}>
      {displayOrder.map((key) => (
        <div key={key} style={{ display: "flex", marginBottom: 2 }}>
          <strong style={{ marginRight: 6, textTransform: "capitalize" }}>
            {key.replace(/([A-Z])/g, " $1").trim()}&nbsp;&nbsp;:&nbsp;
          </strong>
          <span>
            {newValue[key] !== undefined && newValue[key] !== ""
              ? String(newValue[key])
              : "N/A"}
          </span>
        </div>
      ))}
    </div>
  );

  return (
    <Tooltip title={tooltipContent}>
      <div className="flex items-center justify-center gap-1">
        {/* <FaCircle size={8} color="green" /> */}
        {/* <span><i className="fi fi-ts-postal-address text-[#00D3E6] w-10 h-10"></i></span> */}
        <span className=""><i className="fi fi-sr-marker text-[#00D3E6] w-10 h-10"></i></span>
      </div>
    </Tooltip>
  );
}
