import React from "react";

export enum STATUS_TYPE {
  UPLOAD = "upload",
  SUCCESSFUL = "successful",
  ERRORS = "errors",
}

interface CountCellProps {
  value: any;
}

const RatePlansCountCell: React.FC<CountCellProps> = ({ value }) => {
  const ratePlanList = () => {
    if (typeof value === "string") {
      let parsedPlans: any[];
      try {
        parsedPlans = JSON.parse(value);
      } catch (err) {
        console.log(err);
        parsedPlans = [];
      }
      return Array.isArray(parsedPlans) ? parsedPlans : [];
    }
    if (Array.isArray(value)) {
      return value;
    }
    return [];
  };
  const parsedList = ratePlanList();
  const displayValue =
    parsedList && parsedList !== null ? parsedList.length : 0;

  return (
    <div>
      <span className="">{displayValue}</span>
    </div>
  );
};

export default RatePlansCountCell;
