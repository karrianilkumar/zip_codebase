import React, { FC, useState, useEffect } from "react";
import { Tooltip } from "antd";

interface ServiceProviderCellProps {
  value: string;
  index: any;
}

const ServiceProviderCellRenderer: FC<ServiceProviderCellProps> = ({
  value,
  index
}) => {
  const [hideImage, setHideImage] = useState(false);

  const getNetworkCarrierLogoUrl = (networkCarrier: string): string | undefined => {
    const formattedName = networkCarrier
      ?.trim()
      .replace(/\./g, "")
      .toUpperCase();

    switch (formattedName) {
      case "AT&T":
      // case "AT&T - CISCO JASPER":
        // return `/att.png`;
      // case "CENTENNIAL COMMUNICATIONS":
        // return `/centennial-comm.png`;
      // case "VERIZON":
      // case "VERIZON WIRELESS":
      // case "VERIZON - THINGSPACE IOT":
      // case "VERIZON - THINGSPACE MOBILE DATA":
      // case "VERIZON - HDP":
      //   return `/verizon.png`;
      default:
        return undefined 
    }
  };

  const logoUrl = getNetworkCarrierLogoUrl(value);

  useEffect(() => {
    setHideImage(false); // Always reset the state when the value or logoUrl changes

    const img = new Image();
    img.src = logoUrl ||"";
    img.onload = () => setHideImage(false); // Image loaded successfully
    img.onerror = () => setHideImage(true); // Image failed to load

  }, [value, logoUrl]); // Re-run effect when value or logoUrl changes

  return (
    <Tooltip title={value?.toUpperCase()}>
      {hideImage ? (
        <span>{value}</span>
      ) : (
        <img
          src={logoUrl}
          alt={value ?? ""}
          style={{
            maxWidth: "4rem",
            visibility: value ? "visible" : "hidden",
            height: value ? "auto" : "2.5rem",
          }}
          onError={() => setHideImage(true)} // Just a fallback
        />
      )}
    </Tooltip>
  );
};

export function renderServiceProviderCell(value: string, index: any) {
  return <ServiceProviderCellRenderer value={value} index={index} />;
}

export default ServiceProviderCellRenderer;
