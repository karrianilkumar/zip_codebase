import { FC, useEffect, useState } from "react";
import { useRouter } from 'next/navigation';
import { Tooltip } from "antd";
import { HistoryOutlined } from "@ant-design/icons";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { useSearchStore } from "@/app/stores/searchStore";

export const StatusHistoryCellRenderer: FC<{
  row?: any;
}> = ({ row }) => {
  const [isMounted, setIsMounted] = useState(false);
  const router = useRouter();
  const { setRowId, setICCID } = useFeatureStore();
  const { setIsRedirectedFromDetails, detailsRedirectedFilters , detailsRedirectedSearchTerm } = useSearchStore();
  useEffect(() => {
    setIsMounted(true);
  }, []);

  const handleClick = () => {
    if (isMounted) {
      setRowId(row?.id || "0");
      localStorage.setItem('row_id', row?.id || "0");
      setICCID(row?.iccid || "0");
      localStorage.setItem('iccid', row?.iccid || "0");
      const allEmpty = Object.values(detailsRedirectedFilters).every(
        (value) => Array.isArray(value) && value.length === 0
      );
      const isEmptySearchTerm = detailsRedirectedSearchTerm === ""
      console.log("details ...",detailsRedirectedFilters,detailsRedirectedSearchTerm)
      if (allEmpty && isEmptySearchTerm) {
        setIsRedirectedFromDetails(false)
      }
      else {
        setIsRedirectedFromDetails(true)
      }

      router.push(`/sim_management/status_history`);
    }
  };


  return (
    <Tooltip title="Click to view status history">
      <a onClick={handleClick} className="text-center block cursor-pointer">
        <HistoryOutlined className='text-[#00D3E6] ' />
      </a>
    </Tooltip>
  );
};

export function renderStatusHistoryCell(row: any) {
  return <StatusHistoryCellRenderer row={row} />;
}
