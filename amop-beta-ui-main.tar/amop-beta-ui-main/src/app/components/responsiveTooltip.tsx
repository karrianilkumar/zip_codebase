import React, { useState, useCallback, useRef, useEffect } from "react";
import { Tooltip } from "antd";
import type { TooltipProps } from "antd/es/tooltip";

const isSmallOrMediumScreen = () => window.innerWidth <= 1024;

type LongPressTooltipProps = TooltipProps & {
  children: React.ReactElement;
  longPressDelay?: number;
};

const ResponsiveTooltip: React.FC<LongPressTooltipProps> = ({
  children,
  title,
  longPressDelay = 500,
  ...rest
}) => {
  const [visible, setVisible] = useState(false);
  const [isSmallScreen, setIsSmallScreen] = useState(isSmallOrMediumScreen());
  const timer = useRef<NodeJS.Timeout | null>(null);
  const isLongPressRef = useRef(false);

  useEffect(() => {
    const handleResize = () => setIsSmallScreen(isSmallOrMediumScreen());
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const showTooltip = useCallback(() => {
    setVisible(true);
    isLongPressRef.current = true;
    setTimeout(() => {
      setVisible(false);
      isLongPressRef.current = false;
    }, 2000);
  }, []);

  const startPress = () => {
    if (isSmallScreen) {
      timer.current = setTimeout(showTooltip, longPressDelay);
    }
  };

  const endPress = (e: React.SyntheticEvent) => {
    if (timer.current) {
      clearTimeout(timer.current);
      timer.current = null;
    }
    // Prevent click event if it was a long press
    if (isLongPressRef.current) {
      e.preventDefault();
      e.stopPropagation();
    }
  };

  return (
    <Tooltip
      title={title}
      {...(isSmallScreen ? { open: visible } : {})}
      {...rest}
    >
      {React.cloneElement(children, {
        onTouchStart: startPress,
        onTouchEnd: endPress,
        onTouchMove: endPress,
        onMouseDown: startPress,
        onMouseUp: endPress,
        onMouseLeave: endPress,
      })}
    </Tooltip>
  );
};

export default ResponsiveTooltip;
