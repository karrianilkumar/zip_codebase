import React, { useState, useCallback, useEffect } from "react";
import Select from "react-select";
import { FixedSizeList as List } from "react-window";

const VirtualizedMultipleOptionList = ({
  options,
  children,
  maxHeight,
  selectProps,
  ...props
}: any) => {
  const [optionCount, setOptionCount] = useState(20); // Initially load 20 options
  const height = 35; // Height of each option
  const totalHeight = Math.min(maxHeight, options.length * height);

  const loadMoreItems = () => {
    if (optionCount < options.length) {
      setOptionCount(optionCount + 20); // Load 20 more items
    }
  };

  const Option = ({ index, style }: any) => {
    const option = options[index]; // Get the correct option
    console.log("selectProps",selectProps)
    const isSelected = selectProps?.value?.some(
      (selected: any) => selected?.value === option.value
    );

    return (
      <div
        style={style}
        onClick={() => {
          const { isMulti, onChange, value } = selectProps;
          const selectedOptions = value || [];

          if (isMulti) {
            if (isSelected) {
              console.log("isSelected");
              // Remove option if it's already selected
              const updatedOptions = selectedOptions?.filter(
                (selected: any) => selected.value !== option.value
              );
              console.log("updatedOptions", updatedOptions);
              onChange(updatedOptions);
            } else {
              // Add option if it's not selected
              console.log("isNotSelected");
              const updatedOptions = [...selectedOptions, option];
              console.log("updatedOptions", updatedOptions);
              onChange(updatedOptions);
            }
          } else {
            // Handle single-selection
            onChange(option);
          }
        }}
        className={`cursor-pointer ${isSelected ? "bg-gray-200" : ""}`} // Highlight selected option
      >
        {children[index]}
      </div>
    );
  };

  const Row = ({ index, style }: any) => (
    <Option key={index} index={index} style={style} />
  );

  return (
    <List
      height={totalHeight}
      itemCount={Math.min(optionCount, options?.length)} // Show only the available options
      itemSize={height}
      width="100%"
      onItemsRendered={loadMoreItems} // Load more items as needed
    >
      {Row}
    </List>
  );
};

const VirtualizedMultiSelect = (props: any) => {
  const { options, isMulti, onChange, value } = props;
  const [filteredOptions, setFilteredOptions] = useState(options || []);

  // Ensure that filteredOptions is set on the initial render
  useEffect(() => {
    setFilteredOptions(options || []);
  }, [options]);

  const handleInputChange = useCallback(
    (inputValue: string) => {
      const newFilteredOptions = (options || []).filter((option: any) =>
        option?.label.toLowerCase().includes(inputValue.toLowerCase())
      );
      setFilteredOptions(newFilteredOptions);
    },
    [options]
  );

  return (
    <Select
      {...props}
      options={filteredOptions} // Use the filtered options
      isMulti={isMulti} // Pass isMulti prop
      components={{ MenuList: VirtualizedMultipleOptionList }}
      onInputChange={handleInputChange}
      onChange={onChange}
      value={value} // Ensure value is an array of objects
    />
  );
};

export default VirtualizedMultiSelect;
