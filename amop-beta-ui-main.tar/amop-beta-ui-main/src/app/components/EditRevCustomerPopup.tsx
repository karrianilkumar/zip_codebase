"use client";
import React, { useEffect, useState } from "react";
import { Input, Button, Modal, Spin, message, InputNumber, Form } from "antd";
import Select from "react-select";
import { useAuth } from "./auth_context";
import { getCurrentDateTime } from "./header_constants";
import axios from "axios";
import { ENV_ROUTES } from "./routes/route_constants";
import { fireSideCannons } from "@/app/components/confetti";
interface EditRevCustomerProps {
  isOpen: boolean;
  onClose: () => void;
  rowData: any;
  generalFields: any;
  isEditable: boolean;
}

const EditRevCustomerModal: React.FC<EditRevCustomerProps> = ({
  isOpen,
  onClose,
  rowData,
  generalFields,
}) => {
  const [defaultRatePlan, setDefaultRatePlan] = useState<any[]>([]);
  const [selectedRatePlan, setSelectedRatePlan] = useState<any>(null);
  // const [billPeriodEndDay, setBillPeriodEndDay] = useState<number | null>(null);
  // const [billPeriodEndHour, setBillPeriodEndHour] = useState<number | null>(null);
  const [billPeriodEndDay, setBillPeriodEndDay] = useState(() => rowData?.customer_bill_period_end_day ?? null);
const [billPeriodEndHour, setBillPeriodEndHour] = useState(() => rowData?.customer_bill_period_end_hour ?? null);
  const [loading, setLoading] = useState(false);
  const [form] = Form.useForm();
  const { username, tenantNames, role, partner, token, selectedDb,metaData, settabledata, firstLastName,sessionId} = useAuth();
  const [formData, setFormData] = useState<any>({});
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false); // State for confirmation modal
  const [isOptimizatioPerRevIODates, setIsOptimizatioPerRevIODates] = useState<boolean>(false);

  // Handle "Save" button click: Show confirmation first
  const handleSaveClick = () => {
    form.validateFields()
      .then(() => {
        setIsConfirmationOpen(true); // Open the confirmation modal if validation is successful
      })
      .catch((error) => {
        console.error("Validation Failed:", error);
      });
  };
  
  useEffect(() => {
    if (isOpen) {
      setFormData(rowData || {});
      // setBillPeriodEndDay(rowData?.customer_bill_period_end_day || null);
      // setBillPeriodEndHour(rowData?.customer_bill_period_end_hour || null);
      fetchRatePlans();
      fetchOptimizatioPerRevIODates()
    }
  }, [isOpen, rowData]);

  const renderLabel = (label: string, required: boolean) => (
    <span className="field-label">
      {label}{" "}
      {required && (
        <span className="required-indicator" style={{ color: "red" }}>
          *
        </span>
      )}
    </span>
  );

  const handleCancelConfirmation = () => {
    setIsConfirmationOpen(false);
  };

  const validateBillPeriod = (rule: any, value: any) => {
    if (value < rule.min || value > rule.max) {
      return Promise.reject(`Value must be between ${rule.min} and ${rule.max}`);
    }
    return Promise.resolve();
  };
  console.log(rowData,"Show the rowdata")

  const callCustomersLambdaSync = async () => {
          const url = ENV_ROUTES.OPTIMIZATION_SYNC_LAMBDA;
          const data = {
            path: "/lambda_sync_jobs_",
            key_name: "customers_sub_tenant_insert",
            tenant_name:partner
          };
      
          try {
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
          } catch (error) {
          }
      
        }

  const handleSave = async () => {
    try {
      setIsConfirmationOpen(false);
      setLoading(true);
      const url = ENV_ROUTES.PEOPLE_MODULE;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/submit_update_info_people_revcustomer",
        role_name: role,
        parent_module: "People",
        module_name: "Rev.IO customer",
        action: "update",
        changed_data: {
          id: rowData?.cust_id || rowData?.id,
          agent_name: rowData.agent_name,
          selected_rate_plan: selectedRatePlan?.label,
          [isOptimizatioPerRevIODates ? "customer_bill_period_end_day" :"amop_customer_bill_period_end_day"]: billPeriodEndDay,
          [isOptimizatioPerRevIODates ? "customer_bill_period_end_hour" :"amop_customer_bill_period_end_hour"]: billPeriodEndHour,
          modified_by:firstLastName,
          modified_date:getCurrentDateTime()
        },
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        Modal.error({
          title: "Update Error",
          content: parsedData.message || "Error updating data. Please try again.",
          centered: true,
        });
      } else {
        callCustomersLambdaSync()
        await fetchUpdatedTableData();
        fireSideCannons()
        message.success("Customer updated successfully!");
        onClose();
      }
    } catch (error) {
      Modal.error({
        title: "Update Error",
        content: "Error updating data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
      setIsConfirmationOpen(false); // Close confirmation modal after saving
    }
  };

  const fetchOptimizatioPerRevIODates = async () => {
        // setLoading(true);
        try {
          const url = ENV_ROUTES.MODULE_MANAGEMENT;
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/get_cross_carrier_optimization",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "Customer Rate Pool",
            feature_module_name:"Customer Rate Pools",
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
                  ...metaData,
            sessionID: sessionId,
          };
          const response = await axios.post(url, { data });
          const parsedData = JSON.parse(response.data.body);
    
          if (parsedData.flag === false) {
            Modal.error({
              title: 'Data Fetch Error',
              content: parsedData.message || 'An error occurred while fetching data. Please try again.',
              centered: true,
            });
          } else {

            const isOptimizatioPerRevIODates_ = parsedData?.optimization_per_revio_dates || false
            setIsOptimizatioPerRevIODates(isOptimizatioPerRevIODates_)
          }
        } catch (error) {
          console.error("Error fetching data:", error);
          Modal.error({
            title: 'Data Fetch Error',
            content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
            centered: true,
          });
        } finally {
          // setLoading(false);
    
        }
      };

  // Function to fetch rate plans from the API
  const fetchRatePlans = async () => {
    try {
      setLoading(true);
      const url = ENV_ROUTES.PEOPLE_MODULE;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/add_people_revcustomer_dropdown_data",
        role_name: role,
        parent_module: "People",
        module_name: "Rev.IO customer",
        feature_module_name: "Billing Customers",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "Error fetching rate plans. Please try again.",
          centered: true,
        });
      } else {
        const ratePlans = parsedData?.response_data?.customer_rate_plan.map((plan: string) => {
          const [name, id] = plan.split(" - ");
          return { label: name, value: id };
        });

        setDefaultRatePlan(ratePlans);
      }
    } catch (error) {
      Modal.error({
        title: "Data Fetch Error",
        content: "Error fetching rate plans. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  // Fetch updated table data after save
  const fetchUpdatedTableData = async () => {
    try {
      setLoading(true);
      const url = ENV_ROUTES.PEOPLE_MODULE;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/people_revio_customers_list_view",
        role_name: role,
        parent_module: "People",
        module_name: "Rev.IO customer",
        feature_module_name: "Billing Customers",
        mod_pages: {
          start: 0,
          end: 100,
        },
        dropdown_options: { label: "All", value: "all" },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "Error fetching updated data. Please try again.",
          centered: true,
        });
      } else {
        const tableData_ = parsedData.data || [];
        settabledata(tableData_); // Update table data in context
      }
    } catch (error) {
      Modal.error({
        title: "Data Fetch Error",
        content: "Error fetching updated data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  // Handle dropdown selection change
  const handleSelectChange = (selectedOption: any) => {
    setSelectedRatePlan(selectedOption);
  };

  return (
    <div>
      <Modal
        visible={isOpen}
        onCancel={onClose}
        width={600}
        centered
        title={"Update Billing Customer"}
        footer={
          <div className="justify-center flex space-x-2 mt-5">
            <button onClick={onClose} className="cancel-btn">
              Cancel
            </button>
            <button onClick={handleSaveClick} className="save-btn">
              Save
            </button>
          </div>
        }
      >
        {!loading ? (
          <Form form={form} layout="vertical" requiredMark={false}>
            <Form.Item label="Name">
              <Input disabled className="non-editable-input" value={rowData.name} />
            </Form.Item>

            <Form.Item
              label={renderLabel(`${isOptimizatioPerRevIODates?"":"AMOP "}Bill Period End Day (1-28)`, true)}
              name="billPeriodEndDay"
              initialValue={billPeriodEndDay}
              rules={[
                { required: true, message: "Please select a bill period end day" },
                { validator: (_, value) => validateBillPeriod({ min: 1, max: 28 }, value) },
              ]}
            >
              <InputNumber
              className="input"
                value={billPeriodEndDay}
                onChange={setBillPeriodEndDay}
                placeholder="Select Day (1-28)"
                style={{ width: "100%" }}
              />
            </Form.Item>

            <Form.Item
              label={renderLabel(`${isOptimizatioPerRevIODates?"":"AMOP "}Bill Period End Hour (0-23)`, true)}
              name="billPeriodEndHour"
              initialValue={billPeriodEndHour}
              rules={[
                { required: true, message: "Please select a bill period end hour" },
                { validator: (_, value) => validateBillPeriod({ min: 0, max: 23 }, value) },
              ]}
            >
              <InputNumber
              className="input"
                value={billPeriodEndHour}
                onChange={setBillPeriodEndHour}
                placeholder="Select Hour (0-23)"
                style={{ width: "100%" }}
              />
            </Form.Item>

            {/* <Form.Item
              label="Default Rate"
              name="defaultRatePlan"
              // rules={[{ required: true, message: "Please select a rate plan" }]}
            >
              <Select
                options={defaultRatePlan}
                onChange={handleSelectChange}
                value={selectedRatePlan}
                isSearchable
                placeholder="Select Rate Plan"
              />
            </Form.Item> */}
          </Form>
        ) : (
          <div className="flex justify-center">
            <Spin size="large" />
          </div>
        )}
      </Modal>

      {/* Confirmation Modal */}
      <Modal
        visible={isConfirmationOpen}
        title="Confirmation"
        onCancel={handleCancelConfirmation}
        centered
        onOk={handleSave} // Calls the save function on confirmation
      >
        <p>Are you sure you want to Save these Changes?</p>
      </Modal>
    </div>
  );
};

export default EditRevCustomerModal;
