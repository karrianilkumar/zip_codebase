import { Modal, Select, Checkbox, Spin, InputNumber, Input } from "antd";
import { CloseOutlined } from "@ant-design/icons";
import React, { useEffect, useMemo, useState } from "react";
import axios from "axios";
import { useAuth } from "./auth_context";
import { useFeatureStore } from "../sim_management/inventory/featureStore";
import VirtualList from "rc-virtual-list";
import { ChevronDownIcon, ChevronUpIcon, FunnelIcon, ArrowPathIcon, CheckIcon } from "@heroicons/react/24/outline";
import { ENV_ROUTES } from "./routes/route_constants";
import { useSearchStore } from "../stores/searchStore";
// import { useCustomerRatePlanStore } from "@/app/stores/customerRateplanStore";
import { useCustomerRatePlanStore } from "../stores/customerRateplanStore";
import { useOptimizationStore } from "../stores/optimizationStore";
import { CheckboxChangeEvent } from "antd/es/checkbox";



interface RangeValue {
  min?: number;
  max?: number;
  single?: number;
  initialData?: number;
}

interface FilterShape {
  [key: string]: string[];
}

interface AdvancedFilterProps {
  showAdvanced?: boolean;
  setShowAdvanced: (value: boolean) => void;
  headers?: string[];
  headerMap?: any;
  tableName?: string;
  initialData?: any[]; 
}


const AdvancedMultiFilterWithoutAPI: React.FC<AdvancedFilterProps> = ({
  showAdvanced,
  setShowAdvanced,
  headers = [],
  headerMap,
  tableName = "",
  initialData = [], 
}) => {
  // const [activeFilters, setActiveFilters] = useState<FilterShape>({});
  const [formValues, setFormValues] = useState<{ [key: string]: string[] }>({});
  const [rangeValues, setRangeValues] = useState<{ [key: string]: RangeValue }>({});
  const [openRangeDropdown, setOpenRangeDropdown] = useState<string | null>(null);
  const [rangeErrors, setRangeErrors] = useState<{ [key: string]: string }>({});
  const {setAdvancedStoredPagination,setCombineAdnvaceStoredpagination,} = useAuth();
  const [options, setOptions] = useState<{ [key: string]: string[] }>({});
  const [loading, setLoading] = useState<{ [key: string]: boolean }>({});
  const [searchLoading, setSearchLoading] = useState(false);
  
  const [visibleOptions, setVisibleOptions] = useState<{
    [key: string]: number;
  }>({});
  const [filteredOptions, setFilteredOptions] = useState<{
    [key: string]: string[];
  }>({});
  const [searchInput, setSearchInput] = useState<{ [key: string]: string }>({});
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);
    const { setOptimizationErrorsData,optimizationErrorsData,withoutAPISearchData , setWithoutAPISearchData ,setActiveFilters ,activeFilters , searchTerm , setSearchTerm} = useSearchStore();
  const bulkRow: any = JSON.parse(localStorage.getItem('bulk_row') || '{}');
  const iccid: any = localStorage.getItem('iccid') || '0';
  
  const handleScroll = () => {
    if (openDropdown) {
      setOpenDropdown(null);
    }
    if (openRangeDropdown) {
      setOpenRangeDropdown(null);
    }
  };


  useEffect(() => {
    const scrollContainer = document.querySelector(".overflow-x-auto");
    if (scrollContainer) {
      scrollContainer.addEventListener("scroll", handleScroll);
    }
    return () => {
      if (scrollContainer) {
        scrollContainer.removeEventListener("scroll", handleScroll);
      }
    };
  }, [openDropdown, openRangeDropdown]);

const handleFocus = (header:any) => {
  if (searchInput[header]) {
    handleSearch(header, searchInput[header]);
  }
};
  const handleClear = () => {
  const emptyFilters = Object.keys(activeFilters).reduce<FilterShape>((acc, key) => {
    acc[key] = [];
    return acc;
  }, {} as FilterShape);

  setFormValues({});
  setOptimizationErrorsData([]);
  setActiveFilters({});
  setSearchInput({});
  setFilteredOptions({});
  setRangeValues({});
  setShowAdvanced(false);

  // Handle case where searchTerm is still active
  if (searchTerm.trim() !== "") {
    const term = searchTerm.toLowerCase().trim();
    const filteredBySearchTerm = initialData.filter((row: any) =>
      headers.some((header: any) =>
        row[header]?.toString().toLowerCase().includes(term)
      )
    );

    setWithoutAPISearchData(initialData);
    setSearchTerm('');
  } else {
    // No search term, clear data
    setWithoutAPISearchData([]);
    setSearchTerm('');
  }

};

 
const handleDropdownVisibleChange = (header: string, open: boolean) => {
  const isMobile = /iPhone|iPad|iPod|Android/i.test(navigator.userAgent);

  if (open) {
    setOpenDropdown(header);


    // Step 1: Filter initialData using all filters except the current header
    const filteredData = initialData.filter((item: any) =>
      Object.entries(activeFilters).every(([key, values]) => {
        if (key === header || !Array.isArray(values) || values.length === 0) return true;

        const itemVal = item[key] !== null && item[key] !== undefined
          ? String(item[key]).trim().toLowerCase()
          : "";

        return values
          .map((v) => (v !== null && v !== undefined ? String(v).toLowerCase().trim() : ""))
          .includes(itemVal);
      })
    );

    // console.log(`🔍 Filtered data for "${header}" dropdown:`, filteredData);

    // Step 2: Extract values for the currently opened column
    const allValues = filteredData
      .map((item) => item[header])
      .filter((val) => val !== undefined && val !== null);
    const uniqueValues = Array.from(new Set(allValues));

    // Step 3: Apply client-side search filtering if needed
    const searchedText: string = ""; // Replace if dynamic search text used
    const filtered = searchedText
      ? uniqueValues.filter((option: any) =>
          option?.toString().toLowerCase().includes(searchedText.toLowerCase())
        )
      : uniqueValues;

    // Step 4: Set options for the dropdown
    setFilteredOptions((prev) => ({
      ...prev,
      [header]: filtered,
    }));

    // Optional: Focus for mobile
    if (isMobile) {
      setTimeout(() => {
        const input = document.querySelector('.ant-select-selection-search-input') as HTMLInputElement;
        if (input) input.focus();
      }, 100);
    }
  } else {
    setOpenDropdown(null);
  }
};

 
const handleSelectChange = (header: string, value: string[]) => {
  if (header) {
    setSearchInput((prev) => ({
      ...prev,
      [header]: "",
    }));
    // Allow removal of filters
    const newValue = value.filter(val => String(val).trim() !== ""); // Remove empty values
    setFormValues(prev => ({
      ...prev,
      [header]: newValue,
    }));

    const formValues_ = { ...formValues, [header]: newValue };
    const allEmpty = Object.values(formValues_).every(
      (value) => Array.isArray(value) && value.length === 0
    );

    if (allEmpty) {
      handleClear();
    }
  }
};

const handleSearch = (header: string, inputValue: string, isFinalSubmit = false) => {
    handleNormalSearch(header,inputValue)
};

const handleNormalSearch = (header: string, inputValue: string) => {
  // Prevent spaces from being accepted
  if (inputValue.trim() === "") {
    setSearchInput((prev) => ({
      ...prev,
      [header]: "",
    }));
    return;
  }

  setSearchInput((prev) => ({
    ...prev,
    [header]: inputValue,
  }));

  
};


  const loadMoreOptions = (header: string) => {
    setVisibleOptions((prev) => ({
      ...prev,
      [header]: (prev[header] || 20) + 20,
    }));
  };

 const handleCheckboxChange = (header: string, option: string, checked: boolean) => {
  let newValues: any;

  if (header) {
    // Clear search input for the header
    setSearchInput((prev) => ({
      ...prev,
      [header]: "",
    }));

    // Update form values locally
    const currentValues = formValues[header] || [];
    newValues = checked
      ? [...currentValues, option]
      : currentValues.filter((item) => item !== option);

    const updatedFormValues = {
      ...formValues,
      [header]: newValues,
    };

    setFormValues(updatedFormValues);
    setActiveFilters(updatedFormValues);

    // If all filters are cleared, call handleClear
    const allEmpty = Object.values(updatedFormValues).every(
      (value) => Array.isArray(value) && value.length === 0
    );

    if (allEmpty) {
      handleClear();
    }
  }
};


  const handleFilterLoad = () => {
    // setSearchLoading(true);
    // if(searchLoading){
      handleFilter()
    // }
  }
const handleFilter = () => {
  const term = searchTerm.toLowerCase().trim();

  // Prepare filters from formValues
  const advancedFilters = Object.entries(formValues).reduce<FilterShape>((acc, [key, value]) => {
    const modifiedValue = value.map((item) => (item === "" ? " " : item));
    acc[key] = modifiedValue;
    return acc;
  }, {});

  setActiveFilters(advancedFilters);
  setSearchInput({});

  try {
    const filteredData = initialData.filter((row: any) => {
      // ✅ Safely handle all filter comparisons
      const matchesFilters = Object.entries(advancedFilters).every(([key, values]) => {
        if (!values || values.length === 0) return true;

        const rowValue = row[key] !== null && row[key] !== undefined
          ? String(row[key]).trim().toLowerCase()
          : "";

        return values
          .map((v) => (v !== null && v !== undefined ? String(v).trim().toLowerCase() : ""))
          .includes(rowValue);
      });

      // ✅ Safely handle search term comparison too
      const matchesSearchTerm = searchTerm
        ? headers.some((header: any) => {
            const cellValue = row[header];
            return cellValue !== null && cellValue !== undefined
              ? String(cellValue).toLowerCase().includes(term)
              : false;
          })
        : true;

      return matchesFilters && matchesSearchTerm;
    });

    if (filteredData.length === 0) {
      Modal.error({
        title: "No Records Found",
        centered: true,
        onOk: () => {
          setActiveFilters({});
          setSearchTerm('');
          setFormValues({});
          setShowAdvanced(false);
          setWithoutAPISearchData(initialData);
        },
      });
    } else {
      setWithoutAPISearchData(filteredData);
    }
  } catch (error) {
    console.error("Error filtering data:", error);
    setWithoutAPISearchData([]);
  }
};





  const countActiveFilters = useMemo(() => {
    if (
      (tableName === "status_history" && activeFilters?.["iccid"]) ||
      (tableName === "sim_management_bulk_change_request" && activeFilters["bulk_change_id"] ) 
    ) {
      return (
        Object.values(activeFilters).filter((value) => (value as any[]).length > 0)
          .length - 1
      );
    } else {
      return Object.values(activeFilters).filter((value) => (value as string[]).length > 0)
        .length;
    }
  }, [activeFilters]);

  const isFilterButtonEnabled = () => {
    return Object.values(formValues).some((values) => values.length > 0) || 
           Object.values(rangeValues).some((range) => range.single !== undefined || (range.min !== undefined && range.max !== undefined))
          //  || Object.values(searchInput).some((input) => input.length > 0);
  };

  return (
    <div>
      {searchLoading && (
              <div className="absolute inset-0 flex justify-center items-center bg-white bg-opacity-75 z-50 pointer-events-none">
                <Spin size="large" />
              </div>
            )}
      <div className="flex md:flex-row md:justify-end gap-2 md:space-y-0 md:space-x-2">
        <button
          className="save-btn w-fit md:w-auto px-2 !h-[40px] md:!h-[46px] "
          onClick={() => setShowAdvanced(!showAdvanced)}
          style={{ fontWeight: "450" }}
        >
          <span className="flex items-center justify-center pl-2">
            {/* Text for medium and up */}
            <span className="hidden md:flex items-center">
              {showAdvanced ? (
                <>
                  Hide Advanced <ChevronUpIcon className="ml-2 w-4 h-4" />
                </>
              ) : (
                <>
                  Show Advanced <ChevronDownIcon className="ml-2 w-4 h-4" />
                </>
              )}
            </span>

            {/* Icon only for small screens */}
            <span className="flex md:hidden items-center space-x-1">
              <FunnelIcon className="w-5 h-5" />
              {showAdvanced ? (
                <ChevronUpIcon className="w-5 h-5" />
              ) : (
                <ChevronDownIcon className="w-5 h-5" />
              )}
            </span>
          </span>
        </button>

        {showAdvanced && isFilterButtonEnabled() && (
          <>
            {/* Small screens - icon only */}
            <button
              className="save-btn !flex md:!hidden items-center justify-center"
              onClick={handleFilterLoad}
              disabled={!showAdvanced || !isFilterButtonEnabled()}
              title="Filter"
            >
            <CheckIcon className="w-6 h-6" />            
            </button>

            {/* Medium and up - full button */}
            {/* <div className="hidden md:flex"> */}
              <button
                className="save-btn !hidden md:!flex items-center justify-center h-8"
                onClick={handleFilterLoad}
                disabled={!showAdvanced || !isFilterButtonEnabled()}
              >
                Filter
              </button>
            {/* </div> */}
          </>
        )}

        {showAdvanced && isFilterButtonEnabled() && Object.keys(formValues).length > 0 && (
          <>
            <div className="cancel-btn md:hidden relative">
              <button
                className="cancel-btn  flex items-center justify-center"
                onClick={handleClear}
                disabled={Object.keys(formValues).length < 1}
                title="Clear"
              >
                <ArrowPathIcon className="w-6 h-6 text-black-600" />
              </button>
               <div className={`absolute top-0 right-0 -mt-2 -mr-2 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center ${countActiveFilters > 0 ? "bg-green-500" : "bg-blue-500"}`}>
                {countActiveFilters}
              </div>
            </div>

            {/* Medium and up - full button */}
            <div className="hidden md:flex relative">
              <button
                className="cancel-btn h-8 text-gray-800 border bg-gray-200 border-gray-300 rounded-lg px-4 py-0 transition-colors duration-200 hover:bg-gray-300 disabled:cursor-not-allowed disabled:opacity-50"
                onClick={handleClear}
                disabled={Object.keys(formValues).length < 1}
              >
                Clear
              </button>
              <div className={`absolute top-0 right-0 -mt-2 -mr-2 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center ${countActiveFilters > 0 ? "bg-green-500" : "bg-blue-500"}`}>
                {countActiveFilters}
              </div>
            </div>
          </>
        )}
      </div>

      {showAdvanced && headers && (
        <div className="overflow-x-auto rounded-md mt-2 block absolute left-0 right-0">
          <div className="flex space-x-2 p-1">
            {headers.map(
              (header) =>
                (
                  <div className="flex-none w-64" key={header}>
                    
                      <Select
                        mode="multiple"
                        placeholder={headerMap ? headerMap[header]?.[0] : ""}
                        onChange={(value: any[]) => {
                          handleSelectChange(header, value);
                          if (value.length === 0) {
                            handleSearch(header, "");
                          }
                        }}
                        onDropdownVisibleChange={(open) => handleDropdownVisibleChange(header, open)}
                        open={openDropdown === header}
                        value={formValues[header] || []}
                        className="w-full text-ellipsis overflow-hidden whitespace-nowrap adv-filter-drp"
                        maxTagCount={1}
                        maxTagPlaceholder={(omittedValues) => `+${omittedValues.length}`}
                        tagRender={(props) => {
                          const { label, closable, onClose } = props;
                          const labelString = String(label);
                          const truncatedLabel = labelString.length > 190 ? `${labelString.slice(0, 187)}...` : labelString;
                          const allSelectedLabels = formValues?.[header]?.join(", ");
                          return (
                            <span
                              className="inline-flex items-center text-ellipsis px-1 py-1 overflow-hidden whitespace-nowrap  bg-white relative shadow-lg rounded-lg max-w-[185px] selected-value"
                            title={`${allSelectedLabels}`}
                            >
                              {truncatedLabel}
                              {closable && <CloseOutlined onClick={onClose} />}
                            </span>
                          );
                        }}
                        onKeyDown={(e) => {
                          if (e.key === "Enter") {
                            const previouslySelected = formValues[header] || [];
                            const currentOptions =
                              filteredOptions[header]?.length > 0
                                ? filteredOptions[header]
                                : options[header];
                        
                            // Append only newly unselected options
                            const newSelections = currentOptions.filter(
                              (item) => !previouslySelected.includes(item)
                            );
                        
                            handleSelectChange(header, [...previouslySelected, ...newSelections]);
                          }
                        }}
                        
                        showSearch={!loading[header]} // Disable search input when loading                        
                        filterOption={false}
                        onSearch={(input) => handleSearch(header, input)}
                        onFocus={() => handleFocus(header)}
                        autoClearSearchValue={loading[header]?true:false}
                        // onBlur={() => {
                        //   // ✅ Reapply the search input to persist text after blur
                        //   handleSearch(header, searchInput[header]);
                        // }}
                        // onBlur={() => handleSearch(header, "")} // Call handleSearch with empty input on blur
                        searchValue={searchInput[header]}
                        // searchValue={loading[header] ? "" : searchInput[header]}
                        dropdownRender={(menu) => (
                          <div className="relative bg-white shadow-lg rounded-lg max-w-full adv-filter-drp-div">
                            {options[header]?.length > 0 && (
                              <Checkbox
                                indeterminate={
                                  formValues[header]?.length > 0 &&
                                  formValues[header]?.length <
                                  (filteredOptions[header]?.length || options[header]?.length)
                                }
                                checked={
                                  formValues[header]?.length ===
                                  (filteredOptions[header]?.length || options[header]?.length)
                                }
                                onChange={(e) => {
                                  const isChecked = e.target.checked;
                                const currentOptions = filteredOptions[header]
                                  ?.length
                                  ? filteredOptions[header] // Use filtered options if available
                                  : options[header]; // Fallback to all options

                                handleSelectChange(
                                  header,
                                  isChecked ? currentOptions : []
                                );
                                  if (!isChecked) {
                                  handleSearch(header, ""); // Clear search text when deselecting all
                                  }
                                }}
                                className="transform scale-100 px-2 adv-list-item"
                                style={{ width: '100%', overflowY: 'auto' }}
                              >
                                Select All
                              </Checkbox>
                            )}

                            {loading[header] ? (
                              <div className="flex justify-center p-4">
                                <Spin />
                              </div>
                            ) : (
                              <VirtualList
                                className="p-2"
                                data={
                                  filteredOptions[header]?.slice(0, visibleOptions[header] || 20) ||
                                  options[header]?.slice(0, visibleOptions[header] || 20)
                                }
                                height={250}
                                itemHeight={0}
                                itemKey="value"
                                onScroll={(e) => {
                                  const { scrollTop, scrollHeight, clientHeight } = e.currentTarget;
                                  const isBottom = Math.abs(scrollHeight - scrollTop - clientHeight) < 1;
                                  if (isBottom) {
                                    loadMoreOptions(header);
                                  }
                                }}
                              >
                                {(item) => (
                                  <span className="mb-2">
                                    <Checkbox
                                      key={item}
                                      checked={formValues[header]?.includes(item)}
                                      onChange={(e) => handleCheckboxChange(header, item, e.target.checked)}
                                      className="inline-flex mr-2 adv-list-item "
                                    >
                                      {item}
                                    </Checkbox>
                                  </span>
                                )}
                              </VirtualList>
                            )}
                          </div>
                        )}
                        suffixIcon={<ChevronDownIcon className="ml-2 w-4 h-4" />}
                      />
                    
                  </div>
                )
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default AdvancedMultiFilterWithoutAPI;