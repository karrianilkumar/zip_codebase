// components/ThemeSelector.tsx
'use client';
import { useState, useEffect } from 'react';
import { useAuth } from './auth_context';

const themes = [
  { name: 'titanium', color: '#3b82f6' },
  { name: 'red', color: '#ef4444' },
  { name: 'green', color: '#10b981' },
  { name: 'dark', color: '#111827' },
  { name: 'normal', color: '#d1d5db' }, // default
];

export default function ThemeSelector() {

  const { partner } = useAuth();
  const defaultTheme = partner && partner.toLowerCase().includes( "algonox")?'titanium':'normal'
  const [selected, setSelected] = useState(defaultTheme);

  useEffect(() => {
    const saved = localStorage.getItem('app_theme') || defaultTheme;
    setSelected(saved);
  }, []);

  const handleClick = (theme: string) => {
    setSelected(theme);
    localStorage.setItem('app_theme', theme);
    location.reload(); // reload to trigger the theme change
  };
  const toggleTheme = () => {
    const newTheme = selected === 'dark' ? defaultTheme : 'dark';
    handleClick(newTheme);
  };
  return (
    <>
      {/* {themes.map((theme) => (
        <div
          key={theme.name}
          title={theme.name}
          className={`w-6 h-6 rounded-full cursor-pointer ring-2 flex inline${selected === theme.name ? 'ring-black' : 'ring-transparent'
            }`}
          style={{ backgroundColor: theme.color }}
          onClick={() => handleClick(theme.name)}
        ></div>
      ))} */}

      {/* Contrast icon for dark/normal toggle */}
      <span
        title="Toggle dark/normal theme"
        className="text-2xl cursor-pointer"
        onClick={toggleTheme}
      >
        &#9681; {/* Unicode character for ◑ */}
      </span>
    </>
  );
}
