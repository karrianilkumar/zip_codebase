"use client";

import confetti from "canvas-confetti";

/**
 * Create ONE high-zIndex canvas for confetti
 * This ensures confetti appears above AntD Modals, Drawers, etc.
 */
const GREEN = "#22c55e";
const RED = "#cb1f1f";
const COLORS = ["#4e08ff","#f55858","#f466d3","#ece924","#51d9ff","#06ff59"];
const SHAPES:any = ["circle", "square", "star"];

const confettiInstance = (() => {
    if (typeof window === "undefined") return confetti;

    const canvas = document.createElement("canvas");
    canvas.style.position = "fixed";
    canvas.style.top = "0";
    canvas.style.left = "0";
    canvas.style.width = "100%";
    canvas.style.height = "100%";
    canvas.style.pointerEvents = "none"; // allow clicks through
    canvas.style.zIndex = "9999"; //  higher than AntD modal (1000+)

    document.body.appendChild(canvas);

    return confetti.create(canvas, {
        resize: true,
        useWorker: true, // better performance
    });
})();


// Strong burst

export const fireBasicConfetti = () => {
    confettiInstance({
        particleCount: 250,
        spread: 90,
        startVelocity: 45,
        origin: { y: 0.6 },
    });
};


// Double cannon (center-focused)

export const fireSideCannons = () => {
    confettiInstance({
        particleCount: 150,
        angle: 60,
        spread: 90,
        origin: { x: 0.5 },
        // colors: [GREEN,RED],
        // shapes: SHAPES,
    });

    confettiInstance({
        particleCount: 150,
        angle: 120,
        spread: 90,
        origin: { x: 0.5 },
        // colors: [RED,GREEN],
        // shapes: SHAPES,
    });
};


// Confetti rain

export const fireConfettiRain = (duration = 2000) => {
    const end = Date.now() + duration;
const randomColor =
      COLORS[Math.floor(Math.random() * COLORS.length)];
    const frame = () => {
        confettiInstance({
            particleCount: 8,
            spread: 70,
            startVelocity: 30,
            origin: {
                x: Math.random(),
                y: Math.random() - 0.2,
            },
            //  colors: [randomColor],
        });

        if (Date.now() < end) {
            requestAnimationFrame(frame);
        }
    };

    frame();
};

// Ultimate combo (burst + cannons + rain)

export const fireUltimateConfetti = () => {
    // Big initial burst
    confettiInstance({
        particleCount: 300,
        spread: 120,
        startVelocity: 50,
        origin: { y: 0.6 },
    });

    // Side cannons
    setTimeout(() => {
        fireSideCannons();
    }, 300);

    // Rain finish
    setTimeout(() => {
        fireConfettiRain(1500);
    }, 600);
};