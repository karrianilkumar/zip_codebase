import React, { useState, useEffect, useMemo } from "react";
import { Checkbox, Input, Modal, notification, Spin, Switch } from "antd";
import { DropdownStyles, NonEditableDropdownStyles } from "./css/dropdown";
import CreateUser from "../partner/partner_info/users/createUser/page";
import axios from "axios";
import { useAuth } from "./auth_context";
import { DatePicker } from "antd";
import dayjs from "dayjs";
import InfoPopup from "../people/info_popup";
import { useUserStore } from "../partner/partner_info/users/createUser/createUserStore";
import { getCurrentDateTime } from "./header_constants";
import { usePartnerStore } from "../partner/partner_info/partnerStore";
import { ENV_ROUTES } from "./routes/route_constants";
import Select from "react-select";
import InfoNetsepiansPopup from "../people/info_netsepians_popup";
import useCrossProviderStore from "../stores/useCrossProviderStore";
import { PerformanceLogStore } from "../stores/performance_matrix_store";
import PrivateNetworkTable from './private_network_table';
import { usePrivateNetworkStore } from '../stores/privateNetworksStore';
import { fireSideCannons } from "@/app/components/confetti";
interface Column {
  display_name: string;
  db_column_name: string;
  type: string;
  default: string;
  mandatory: string;
}

interface EditModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (updatedRow: any, tableData: any) => void;
  rowData: any;
  createModalData?: any[];
  isEditable: boolean;
  heading: string;
  isTabEdit: any;
  generalFields?: Record<string, any>; // To store general fields for dropdowns
  tableData?: any;
  action: any;
}

const EditModal: React.FC<EditModalProps> = ({
  isOpen,
  onClose,
  onSave,
  rowData,
  action,
  createModalData: originalCreateModalData = [],
  isEditable,
  heading,
  isTabEdit,
  generalFields,
  tableData = [],
}) => {
  const { crossProviderCustomerOptimizationStore } = useCrossProviderStore();
  const { editedTableData } = usePrivateNetworkStore();
  const [formData, setFormData] = useState<any>({});
  const [isConfirmationOpen, setIsConfirmationOpen] = useState(false);
  const editableDrp = DropdownStyles;
  const [isCreateUserOpen, setIsCreateUserOpen] = useState(isTabEdit);
  const {
    username,
    tenantNames,
    role,
    partner,
    settabledata,
    token,
    selectedDb,
    metaData,
    firstLastName,
    sessionId,
    isSubTenant
  } = useAuth();
  const isAdmin = role?.toLowerCase() === "super admin" || role?.toLowerCase() === "partner admin"

  const createModalData = useMemo(() => {
  if (heading === "Customers") {
    return originalCreateModalData.filter(item => item.db_column_name !== "sub_tenant_name");
  }

  if (heading === "Customer Group") {
    return originalCreateModalData.filter(item => {
      const excludeColumns = ["tenant_name"];
      if (!isAdmin) {
        excludeColumns.push("billing_account_number", "sub_tanant");
      }
      return !excludeColumns.includes(item.db_column_name);
    });
  }

  return originalCreateModalData;
}, [heading, isAdmin, originalCreateModalData]);


  const rate_plan_name_drp =
    generalFields &&
    generalFields.rate_plan_name &&
    Array.isArray(generalFields.rate_plan_name)
      ? generalFields.rate_plan_name
      : [];
  const [loading, setLoading] = useState(false);
  const { partnerData, setCustomerGroups } = usePartnerStore.getState();
  const [error, setError] = useState<string | null>(null);
  const [mandatoryError, setMandatoryError] = useState<string | null>(null);
  const [initialData, setTableData] = useState<any>(tableData);
  const [validationErrors, setValidationErrors] = useState<{
    [key: string]: string;
  }>({});
  const {
    tenant,
    role_name,
    sub_tenant,
    user_name,
    setTenant,
    setRoleName,
    setSubTenant,
  } = useUserStore();
  const { getTargetTenantProvider } = PerformanceLogStore();

  const [isCrossProvider, setIsCrossProvider] = useState<boolean>(false);
  const [isOptimizatioPerRevIODates, setIsOptimizatioPerRevIODates] = useState<boolean>(false);
  const [customerGroupsDropdownData, setCustomerGroupsDropdownData] = useState<any>({});
  const [enablePrivateNetwork, setEnablePrivateNetwork] = useState(false);
  const [serviceProviderOptions, setServiceProviderOptions] = useState<any[]>([])
  const { setEditedTableData } = usePrivateNetworkStore();

  const callCustomersLambdaSync = async () => {
    const url = ENV_ROUTES.OPTIMIZATION_SYNC_LAMBDA;
    const data = {
      path: "/lambda_sync_jobs_",
      key_name: "customers_sub_tenant_insert",
      tenant_name:partner
    };

    try {
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
    } catch (error) {
    }

  }
    const fetchData = async () => {
        setLoading(true);
        try {
          const url = ENV_ROUTES.MODULE_MANAGEMENT;
          const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/get_cross_carrier_optimization",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "Customer Rate Pool",
            feature_module_name:"Customer Rate Pools",
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
          const response = await axios.post(url, { data });
          const parsedData = JSON.parse(response.data.body);
    
          if (parsedData.flag === false) {
            Modal.error({
              title: 'Data Fetch Error',
              content: parsedData.message || 'An error occurred while fetching data. Please try again.',
              centered: true,
            });
          } else {
            const crossProvider_ = parsedData?.cross_carrier_optimization || false
            setIsCrossProvider(crossProvider_)

            const isOptimizatioPerRevIODates_ = parsedData?.optimization_per_revio_dates || false
            setIsOptimizatioPerRevIODates(isOptimizatioPerRevIODates_)
          }
        } catch (error) {
          console.error("Error fetching data:", error);
          Modal.error({
            title: 'Data Fetch Error',
            content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
            centered: true,
          });
        } finally {
          setLoading(false);
    
        }
      };

      const fetchCustomerGroupsData = async (option:any) => {
            setLoading(true);
            try {
              const url = ENV_ROUTES.MODULE_MANAGEMENT;
              const data = {
                tenant_name: partner || "Altaworx",
                username: username,
                firstLastName: firstLastName,
                path: "/get_submit_customer_group_dropdown_details",
                role_name: role,
                parent_module: "Partner",
                modules_list: ["Customer groups"],
                feature_module_name: "Partner Info",
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                sub_tenant_name:option
              };
              const response = await axios.post(url, { data });
              const parsedData = JSON.parse(response.data.body);
        
              if (parsedData.flag === false) {
                Modal.error({
                  title: 'Data Fetch Error',
                  content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                  centered: true,
                });
              } else {
                const sub_tanant_=parsedData?.data?.tenant_details?.sub_tenants || []
                const feature_codes_=parsedData?.data?.feature_codes || []
                const customer_names_=parsedData?.data?.customer_names || []
                const billing_account_number_=parsedData?.data?.billing_account_number || []
                const rate_plan_name_=parsedData?.data?.rate_plan_name || []
                const notification_rules_=parsedData?.data?.notification_rules || []
                const comm_plans_=parsedData?.data?.comm_plans || []
                const dropdown_data={
                  sub_tanant:sub_tanant_.map((option: string) => ({
                    label: option,
                    value: option,
                  })),
                  feature_codes:feature_codes_.map((option: string) => ({
                    label: option,
                    value: option,
                  })),
                  customer_names:customer_names_.map((option: string) => ({
                    label: option,
                    value: option,
                  })),
                  billing_account_number:billing_account_number_.map((option: string) => ({
                    label: option,
                    value: option,
                  })),
                  rate_plan_name:rate_plan_name_.map((option: string) => ({
                    label: option,
                    value: option,
                  })),
                  notification_rules:notification_rules_.map((option: string) => ({
                    label: option,
                    value: option,
                  })),
                  comm_plans: comm_plans_.map((option: string) => ({
                    label: option,
                    value: option,
                  })),
                }
                // const tenant_name_ = rowData?.sub_tenant_name || ""
                // console.log("tenant_name_",tenant_name_)
                //         if (sub_tanant_.includes(tenant_name_)) {
                //           setFormData((prev: any) => ({
                //             ...prev,
                //             sub_tanant: tenant_name_,
                //           })); //phani
                //         }
                // console.log("formdata",formData)

                setCustomerGroupsDropdownData(dropdown_data)
                const service_providers=parsedData?.data?.service_providers || []
                setServiceProviderOptions(service_providers)
              }
            } catch (error) {
              console.error("Error fetching data:", error);
              Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
              });
            } finally {
              setLoading(false);
        
            }
          };

    const callLambdaSync = async () => {
      const url = ENV_ROUTES.OPTIMIZATION_SYNC_LAMBDA;
      const data = {
        path: "/lambda_sync_jobs_",
        key_name: "carrier_rate_plans_sync",
        tenant_name:partner
        };
      try {
        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
      } catch (error) {
      }     
    }

  const handleChange = (name: string, value: any) => {
    if(heading === "Customer Group" && name === "enable_private_networks")
    {
      setEnablePrivateNetwork(value)
      console.log("value",value)
    }
    console.log(name, value, "show name and value");
    setFormData((prevState: any) => ({
      ...prevState,
      [name]: value,
    }));
    // Clone the current validationErrors state
    let errors = { ...validationErrors };

    // Specific validation for 'postal_code'
    if (name === "postal_code") {
      const regex = /^\d{5}$/; // Regex for exactly 5 digits
      if (!regex.test(value)) {
        errors[name] = "Postal code must be exactly 5 digits";
      } else {
        delete errors[name]; // Remove error if validation passes
      }
    }
    // Validation for 'customer_bill_period_end_hour'
    if (name === "customer_bill_period_end_hour") {
      const hour = Number(value);
      if (isNaN(hour) || hour < 0 || hour > 23) {
        errors[name] = "Customer bill period end hour must be between 0 and 23";
      } else {
        delete errors[name];
      }
    }

    // Validation for 'customer_bill_period_end_date'
    if (name === "customer_bill_period_end_date") {
      const date = Number(value);
      if (isNaN(date) || date < 1 || date > 28) {
        errors[name] = "Customer bill period end date must be between 1 and 28";
      } else {
        delete errors[name];
      }
    }
    if (name === "customer_bill_period_end_day") {
      const date = Number(value);
      if (isNaN(date) || date < 1 || date > 28) {
        errors[name] = "Customer bill period end day must be between 1 and 28";
      } else {
        delete errors[name];
      }
    }

    if(heading==="Rate Plan Socs"){
        if (
          name === "overage_rate_cost" || 
          name === "data_per_overage_charge" || 
          name === "plan_mb" ) {
            console.log("field",name)
            const regex = /^\$?\d*(\.\d*)?$/; // Only allow digits and '$'
            const value_ = value ? value.toString().replace('$', '') : '0'; // Ensure value is a string
            console.log("value",value_)
            if ((value !== null && 
              value !== undefined && 
              value !== "" &&
              value !== "None") && value !== "None" && !regex.test(value)) {
              errors[name] = "Only numbers are allowed.";
            } 
            else{
              delete errors[name];
            }
        }
    }
    setValidationErrors(errors);
  };

  const handleSelectChange = (name: string, value: any) => {
    if (heading === "Customer Group" && name === "sub_tanant") {
      const value_ = value ? value : partner || ""
      fetchCustomerGroupsData(value_)
      setFormData((prevState: any) => ({
        ...prevState,
        rate_plan_name: "",
        customer_names: [],
        billing_account_number: "",
        feature_codes: "",
        notification_rules: "",
        comm_plans: ""
      }));
    }
    setFormData((prevState: any) => ({
      ...prevState,
      [name]: value,
    }));
  };

  // const handleSelectChange = (name: string, value: any) => {
  //   console.log("Selected value", value)

  //   let selectedId = value;
  //   if (name === "default_optimization_group_id") {
  //     selectedId = selectedId = value.split(" - ")[1]; // extract the ID from the value); // convert to integer only for this field
  //   }
  //   console.log("selectedId", selectedId)
  //   setFormData((prevState: any) => ({
  //     ...prevState,
  //     [name]: selectedId,
  //   }));
  // };

  const handleSave = () => {
    onSave(formData, initialData);
    onClose();
  };

  const handleCancel = () => {
    setEditedTableData([])
    setTenant([]);
    setSubTenant([]);
    setRoleName("");
    onClose();
  };
// Expand compressed IPv6 like "2001:db8::1" -> ["2001","0DB8","0000","0000","0000","0000","0000","0001"]
const expandIPv6 = (input: string): string[] | null => {
    const raw = input.trim();
    if (!raw) return null;
    
    if (raw.indexOf("::") !== -1) {
        const [left, right] = raw.split("::");
        const leftParts = left ? left.split(":").filter(Boolean) : [];
        const rightParts = right ? right.split(":").filter(Boolean) : [];
        if (leftParts.some(p => p.length > 4) || rightParts.some(p => p.length > 4)) return null;
        const missing = 8 - (leftParts.length + rightParts.length);
        if (missing < 0) return null;
        const mid = new Array(missing).fill("0");
        const parts = [...leftParts, ...mid, ...rightParts].map(p => p || "0");
        if (parts.length !== 8) return null;
        return parts.map(p => p.padStart(4, "0").toUpperCase());
    } else {
        const parts = raw.split(":");
        if (parts.length !== 8) return null;
        if (parts.some(p => p.length === 0 || p.length > 4)) return null;
        return parts.map(p => p.padStart(4, "0").toUpperCase());
    }
};

// Parse IPv4 numeric dotted -> parts
const ipv4ToParts = (ip: string): number[] => ip.split(".").map(p => {
    const n = Number(p);
    if (Number.isNaN(n)) return 0;
    return Math.max(0, Math.min(255, Math.trunc(n)));
}).slice(0, 4).concat([0, 0, 0, 0]).slice(0, 4);

interface ParseResult {
    valid: boolean;
    family?: "ipv4" | "ipv6";
    startParts: number[];
    endParts: number[];
}

const parseIpOrRange = (value?: string): ParseResult => {
    const ipv4Regex = /^(\d{1,3}\.){3}\d{1,3}$/;
    const ipv6SingleRegex = /^([0-9A-Fa-f:]+)$/;
    const rangeRegexIPv4 = /^(\d{1,3}\.){3}\d{1,3}\s*-\s*(\d{1,3}\.){3}\d{1,3}$/;
    const rangeRegexIPv6 = /^([0-9A-Fa-f:]+)\s*-\s*([0-9A-Fa-f:]+)$/;

    const raw = String(value ?? "").trim();
    if (!raw) return { valid: false, startParts: [0, 0, 0, 0], endParts: [0, 0, 0, 0] };

    // IPv4 single
    if (ipv4Regex.test(raw)) {
        const p = ipv4ToParts(raw) as number[];
        return { valid: true, family: "ipv4", startParts: p, endParts: p.slice() };
    }

    // IPv4 range
    if (rangeRegexIPv4.test(raw)) {
        const [s, e] = raw.split("-").map(s => s.trim());
        const sp = ipv4ToParts(s);
        const ep = ipv4ToParts(e);

        const lexCompare = (a: number[], b: number[]) => {
            for (let i = 0; i < 4; i++) {
                if (a[i] < b[i]) return -1;
                if (a[i] > b[i]) return 1;
            }
            return 0;
        };

        if (lexCompare(sp, ep) <= 0) return { valid: true, family: "ipv4", startParts: sp, endParts: ep };
        return { valid: true, family: "ipv4", startParts: ep, endParts: sp };
    }

    // IPv6 single or range
    if (ipv6SingleRegex.test(raw)) {
        if (!raw.includes("-")) {
            const expanded = expandIPv6(raw);
            if (!expanded) return { valid: false, startParts: [0, 0, 0, 0], endParts: [0, 0, 0, 0] };
            const parts = expanded.map(h => parseInt(h, 16));
            return { valid: true, family: "ipv6", startParts: parts, endParts: parts.slice() };
        }
    }

    // IPv6 range (a-b)
    const m6 = raw.match(rangeRegexIPv6);
    if (m6) {
        const sRaw = m6[1].trim();
        const eRaw = m6[2].trim();
        const sExp = expandIPv6(sRaw);
        const eExp = expandIPv6(eRaw);
        if (!sExp || !eExp) return { valid: false, startParts: [0, 0, 0, 0], endParts: [0, 0, 0, 0] };
        const sp = sExp.map(h => parseInt(h, 16));
        const ep = eExp.map(h => parseInt(h, 16));
        const lexCompare = (a: number[], b: number[]) => {
            for (let i = 0; i < 8; i++) {
                if (a[i] < b[i]) return -1;
                if (a[i] > b[i]) return 1;
            }
            return 0;
        };
        if (lexCompare(sp, ep) <= 0) return { valid: true, family: "ipv6", startParts: sp, endParts: ep };
        return { valid: true, family: "ipv6", startParts: ep, endParts: sp };
    }

    return { valid: false, startParts: [0, 0, 0, 0], endParts: [0, 0, 0, 0] };
};

// Check if two IP ranges overlap
const checkIpRangeOverlap = (
    start1: number[],
    end1: number[],
    start2: number[],
    end2: number[]
): boolean => {
    const compareIp = (a: number[], b: number[]): number => {
        for (let i = 0; i < a.length; i++) {
            if (a[i] < b[i]) return -1;
            if (a[i] > b[i]) return 1;
        }
        return 0;
    };

    const start1VsEnd2 = compareIp(start1, end2);
    const start2VsEnd1 = compareIp(start2, end1);

    return start1VsEnd2 <= 0 && start2VsEnd1 <= 0;
};
  const showConfirmation = () => {
    const errors: { [key: string]: string } = {};
    console.log("editedTableData",editedTableData)
    // return;
    if (heading === "Customer Group") {
      const hasIncompleteRow = editedTableData.some((row: any) =>
        Object.keys(row).some((key) => {
          const value = row[key];
          return value === "" || value === null || value === undefined;
        })
      );

      if ((hasIncompleteRow || editedTableData.length === 0) && enablePrivateNetwork) {
        Modal.info({
          title: "Incomplete Private Networks",
          content: "Please fill all the fields in private network rows before creating.",
          centered: true,
        });
        return;
      }
      const hasOverlappingRanges = editedTableData.some((row: any, index: number) => {
        const serviceProvider = row.service_provider;
        const ipRange = row.ip_text;

        if (!serviceProvider || !ipRange) return false;

        const parsed1 = parseIpOrRange(ipRange);
        if (!parsed1.valid || !parsed1.family) return false;

        // Check against all other rows with the same service provider
        return editedTableData.some((otherRow: any, otherIndex: number) => {
          if (index === otherIndex) return false; // Skip self
          if (otherRow.service_provider !== serviceProvider) return false; // Different provider

          const otherIpRange = otherRow.ip_text;
          if (!otherIpRange) return false;

          const parsed2 = parseIpOrRange(otherIpRange);
          if (!parsed2.valid || !parsed2.family) return false;
          if (parsed1.family !== parsed2.family) return false; // Different IP versions

          // Check if ranges overlap
          return checkIpRangeOverlap(
            parsed1.startParts,
            parsed1.endParts,
            parsed2.startParts,
            parsed2.endParts
          );
        });
      });

      if (hasOverlappingRanges) {
        Modal.error({
          title: "Overlapping IP Ranges",
          content: "Multiple rows with the same Service Provider have overlapping IP ranges. Please ensure IP ranges don't overlap within the same provider.",
          centered: true,
        });
        return;
      }
    }

    createModalData.forEach((column) => {
      const value = formData[column.db_column_name];
      if (
        column.mandatory && column.display_name !=="Partner" &&
        ((Array.isArray(value) && value.length === 0) || // Check if array and empty
          (!Array.isArray(value) && (!value || value === "None"))) // Check if not array and empty or "None"
      ) {
        errors[column.db_column_name] = `${column.display_name} is required.`;
      }
    });

    // Check if all mandatory fields are filled
    const unfilledMandatoryFields = createModalData.filter(
      (column: Column) =>
        column.mandatory &&column.display_name !=="Partner" &&
        (!formData[column.db_column_name] ||
          formData[column.db_column_name] === "None")
    );

    if (formData["customer_bill_period_end_hour"]) {
      const hour = Number(formData["customer_bill_period_end_hour"]);
      if (isNaN(hour) || hour < 0 || hour > 23) {
        errors["customer_bill_period_end_hour"] =
          "Customer bill period end hour must be between 0 and 23";
      }
    }
    if (formData["customer_bill_period_end_date"]) {
      const date = Number(formData["customer_bill_period_end_date"]);
      if (isNaN(date) || date < 1 || date > 28) {
        errors["customer_bill_period_end_date"] =
          "Customer bill period end date must be between 1 and 28";
      }
    }
    if (formData["customer_bill_period_end_day"]) {
      const date = Number(formData["customer_bill_period_end_day"]);
      if (isNaN(date) || date < 1 || date > 28) {
        errors["customer_bill_period_end_day"] =
          "Customer bill period end day must be between 1 and 28";
      }
    }
    if (formData["postal_code"]) {
      const zipCode = formData["postal_code"];
      const regex = /^\d{5}$/; // Only 5 numerical values

      if (!regex.test(zipCode)) {
        errors["postal_code"] = "Postal code must be exactly 5 digits";
      }
    }
    if(heading==="Rate Plan Socs"){
      Object.keys(formData).forEach((field) => {
        if (
          field === "overage_rate_cost" || 
          field === "data_per_overage_charge" || 
          field === "plan_mb" ) {
            console.log("field",field)
            const regex = /^\$?\d*(\.\d*)?$/; // Only allow digits and '$'
            const value = formData[field] ? formData[field].toString().replace('$', '') : '0'; // Ensure value is a string
            console.log("value",value)
            if ((formData[field] !== null && 
                 formData[field] !== undefined && 
                formData[field] !== "" &&
                formData[field] !== "None") && formData[field] !== "None" && !regex.test(value)) {
                errors[field] = "Only numbers are allowed.";
              } 
            }
  
      });
    }
    
    if (Object.keys(errors).length > 0 || unfilledMandatoryFields.length > 0) {
      setValidationErrors(errors);
      setIsConfirmationOpen(false);
      // setMandatoryError("Please fill in all required fields.");
      return; // Prevent further actions
    } else {
      setValidationErrors({});
      setMandatoryError(null);
      setIsConfirmationOpen(true); // Only open the confirmation popup if there are no errors
    }
    // Additional check for zip code length
    if (formData["postal_code"] && formData["postal_code"].length > 5) {
      setIsConfirmationOpen(false); // Don't show confirmation popup if zip code is more than 5 digits
    }
  };

  const getOptions = (column: any) => {
    if (column && generalFields && generalFields[column]) {
      const optionList = generalFields[column].map((option: any) => ({
        label: getKey(option),
        value: getKey(option),
      }));

      return optionList;
    } else {
      return [];
    }
  };

  const callCustomerRatePoolsSync = async () =>{
        try {
          const url = ENV_ROUTES.OPTIMIZATION_SYNC_LAMBDA;
          const data = {
            key_name:"customer_rate_pool_sync",
            path:"/lambda_sync_jobs_",
            tenant_name:partner || "default_value",
          };
    
          const response = await axios.post(url, { data });
          const responseData = JSON.parse(response.data.body);
    
          if (responseData.flag === false) {
            console.error("Data Fetch Error: " + responseData.message);
          } else {
            console.log("Success: Inventory lambda sync successful.");
          }
        } catch (error) {
          console.error("Error fetching data:", error);
        }
    
      }

  const handleConfirmSave = async () => {
    if (formData) {
      try {
        setLoading(true);
        setIsConfirmationOpen(false);
        let data;
        let url = ENV_ROUTES.MODULE_MANAGEMENT;
        if (heading === "Customer Group") {
          if (formData) {
            const tenant_id_map=generalFields?.tenant_id_map || {}
            const selected_parent_tenant=formData["tenant_name"] || ""
            const selected_sub_tenant=formData["sub_tanant"] || ""
            const selected_tenant=selected_sub_tenant && selected_sub_tenant!==""?selected_sub_tenant:selected_parent_tenant  || partner
            const tenant_id_=tenant_id_map[selected_tenant] || 1
            const defaultBAN=customerGroupsDropdownData && customerGroupsDropdownData["billing_account_number"] && customerGroupsDropdownData?.["billing_account_number"].length>0?customerGroupsDropdownData?.["billing_account_number"][0]?.value:customerGroupsDropdownData["billing_account_number_"] || ""
            const billing_account_number_=!isAdmin ? defaultBAN : formData["billing_account_number"] || ""

            formData["tenant_id"] = tenant_id_;
            formData["tenant_name"]=selected_tenant
            formData["parent_tenant_name"]=formData["parent_tenant_name"] || partner
            if(!isSubTenant && (selected_tenant===partner)){
              formData["parent_tenant_name"] = ""
            } //Phani & Ajay 2
            formData["billing_account_number"]=billing_account_number_
            
            delete formData["sub_tanant"];
            // delete formData["id"];
            // delete formData["customergroup_id"];
            delete formData["id_10"];
            delete formData["subtenant_id"];
            delete formData["subtenant_name"];
            delete formData["sub_tenant_name"];
            
            delete formData["sub_tanant"];
            formData["tenant_id"] = tenant_id_;
            formData["modified_by"] = firstLastName;
            formData["modified_date"] = getCurrentDateTime();
            // delete formData["tenant_id"];
            formData["private_networks_json"]=[...editedTableData]
          }
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/update_partner_info",
            role_name: role,
            module_name: "Customer Groups",
            action: "update",
            changed_data: formData,
            Partner: partner,

            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }
        if (heading === "Customers") {
                  url=ENV_ROUTES.PEOPLE_MODULE
                  if (formData) {

                    if (!isOptimizatioPerRevIODates) {
                      formData['amop_customer_bill_period_end_day'] = formData['customer_bill_period_end_day'] || ""
                      formData['amop_customer_bill_period_end_hour'] = formData['customer_bill_period_end_hour'] || ""
                      delete formData['customer_bill_period_end_day']
                      delete formData['customer_bill_period_end_hour']
                    }

                    formData['modified_by'] = firstLastName;
                    formData["modified_date"] = getCurrentDateTime();
                    formData["is_deleted"] = false
                    formData["is_active"] = true

                  }
                  data = {
                    tenant_name: partner || 'default_value',
                    username: username,
                    firstLastName: firstLastName,
                    path: '/create_customer',
                    role_name: role,
                    module_name: 'Customers',
                    new_data: formData,
                    Partner: partner,
                    request_received_at: getCurrentDateTime(),
                    access_token: token,
                    db_name: selectedDb,
                ...metaData,
                    sessionID: sessionId,
                    action:"edit"
                  };
                }
        if (heading === "Carrier") {
          if (formData) {
            formData["last_modified_by"] = firstLastName;
            // formData["last_modified_date_time"] = getCurrentDateTime();
            delete formData["last_modified_date_time"]
            delete formData["modified_date"]
          }
          url = ENV_ROUTES.TENANT_ONBOARDING;
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/update_superadmin_data",
            role_name: role,
            sub_module: "Partner API",
            sub_tab: "Carrier APIs",
            table_name: "carrier_apis",
            changed_data: formData,
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }

        if (heading === "API") {
          if (formData) {
            formData["last_modified_by"] = firstLastName;
            // formData["last_modified_date_time"] = getCurrentDateTime();
            delete formData["last_modified_date_time"]
            delete formData["modified_date"]

          }
          url = ENV_ROUTES.TENANT_ONBOARDING;
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/update_superadmin_data",
            role_name: role,
            sub_module: "Partner API",
            sub_tab: "Amop APIs",
            table_name: "amop_apis",
            changed_data: formData,
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }

        if (heading === "E911 Customer") {
          url = ENV_ROUTES.PEOPLE_MODULE;
          if (formData) {
            formData["modified_by"] = firstLastName;
            formData["modified_date"] = "";
          }
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/update_people_data",
            role_name: role,
            parent_module: "People",
            module: "E911 Customers",
            table_name: "e911_customers",
            action: "update",
            changed_data: formData,
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }
        if (heading === "NetSapien Customer") {
          url = ENV_ROUTES.PEOPLE_MODULE;
          if (formData) {
            formData["modified_by"] = firstLastName;
            formData["modified_date"] = "";
            // formData["is_system_default"] = true;
            formData["is_active"] = true;
            formData["is_deleted"] = null;
          }
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/update_people_data",
            role_name: role,
            parent_module: "People",
            module: "NetSapiens Customers",
            table_name: "customers",
            action: "update",
            changed_data: formData,
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }
        if (heading === "Bandwidth Customer") {
          url = ENV_ROUTES.PEOPLE_MODULE;
          if (formData) {
            formData["modified_by"] = firstLastName;
            formData["modified_date"] = getCurrentDateTime();
            // formData["is_system_default"] = true;
            formData["is_active"] = true;
            formData["is_deleted"] = null;
          }
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/update_people_data",
            role_name: role,
            parent_module: "People",
            module: "Bandwidth Customers",
            table_name: "customers",
            action: "update",
            changed_data: formData,
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }
        if (heading === "Customer Rate Plan" && action === "copyFeature") {
          url = ENV_ROUTES.SIM_MANAGEMENT;
          if (formData) {
            formData["modified_by"] = firstLastName;
            delete formData["service_provider"];
            delete formData["deleted_date"];
            formData["is_deleted"] = false;
            delete formData["id"];
          }
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/update_sim_management_modules_data",
            role_name: role,
            parent_module: "Sim Management",
            module: "Customer Rate Plan",
            table_name: "customerrateplan",
            action: "create",
            new_data: formData,
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        } else if (heading === "Customer Rate Plan") {
          url = ENV_ROUTES.SIM_MANAGEMENT;
          if (formData) {
            console.log(formData, "Show form data");
            formData["modified_by"] = firstLastName;
            delete formData["service_provider"];
            delete formData["deleted_date"];
            formData["is_deleted"] = false;
          }
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/update_sim_management_modules_data",
            role_name: role,
            parent_module: "Sim Management",
            module: "Customer Rate Plan",
            table_name: "customerrateplan",
            action: "update",
            changed_data: formData,
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,

            sessionID: sessionId,
          };
        }
        if (heading === "Customer Rate Pool") {
          url = ENV_ROUTES.SIM_MANAGEMENT;
          if (formData) {
            console.log(formData, "Show form data");
            const provider_id_map=generalFields?.service_provider_dict || {}
            const provider=formData['service_provider_name'] || ""
            // const provider_id_=provider_id_map[provider] || "0"
            formData["modified_by"] = firstLastName;
            delete formData["service_provider"];
            delete formData["deleted_date"];
            formData["is_deleted"] = false;
            let provider_ids=[];
            let provider_id_;
            if(isCrossProvider){
              // Ensure provider is an array
              const providerArray = Array.isArray(provider) ? provider : provider.split(",");
              provider_ids = providerArray.map((name: any) => provider_id_map[name.trim()]);
              console.log("provider_ids",provider_ids)
            }
            else{
              provider_id_=provider_id_map[provider] || "0"
              console.log("provider_id_",provider_id_)
  
            }
  
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/update_sim_management_modules_data",
            role_name: role,
            parent_module: "Sim Management",
            module: "Customer Rate Pool",
            table_name: "customer_rate_pool",
            action: "update",
            changed_data: {
              ...formData,
              ...!isCrossProvider && {service_provider_id: typeof provider_id_ === "string"? Number(provider_id_) : provider_id_ },
              ...isCrossProvider && {service_provider_ids:provider_ids} ,
            },
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }
        }
        if (heading === "Rate Plan Socs") {
          url = ENV_ROUTES.SIM_MANAGEMENT;
          if (formData) {
            console.log(formData, "Show form data");
            formData["modified_by"] = firstLastName || username;
            delete formData["assigned"];
          }
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/update_sim_management_modules_data",
            role_name: role,
            parent_module: "Sim Management",
            module: "Rate Plan Socs",
            table_name: "carrier_rate_plan",
            action: "update",
            changed_data: formData,
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }
        if (heading === "Create Rate Plan Type") {
          url = ENV_ROUTES.SIM_MANAGEMENT;
          if (formData) {
            formData["modified_by"] = firstLastName;
          }
          data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/update_sim_management_modules_data",
            role_name: role,
            parent_module: "Sim Management",
            module: "Create Rate Plan Type",
            table_name: "optimization_rate_plan_type",
            action: "update",
            changed_data: formData,
            Partner: partner,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
          };
        }

        const response = await axios.post(url, { data });
        const resp = JSON.parse(response.data.body);
        console.log(resp, "show the response");
        if (response.data.statusCode === 200 && resp.flag === true) {
          if (heading === "Customers") {
                      const url = ENV_ROUTES.PEOPLE_MODULE;
                      const data = {
                        tenant_name: partner || "default_value",
                        username: username,
                        firstLastName: firstLastName,
                        path: "/get_customers_list_view_data",
                        role_name: role,
                        parent_module: "People",
                        module_name: "Customers",
                        feature_module_name: "Customers",
                        mod_pages: {
                          start: 0,
                          end: 100,
                        },
                        request_received_at: getCurrentDateTime(),
                        Partner: partner,
                        access_token: token,
                        db_name: selectedDb,
                ...metaData,
                        sessionID: sessionId,
                      };
                      const response = await axios.post(url, { data });
                      const parsedData = JSON.parse(response.data.body);
                      if (parsedData.flag === false) {
                        setLoading(false)
                        Modal.error({
                          title: 'Data Fetch Error',
                          content: parsedData.message || 'An error occurred while fetching Customers data. Please try again.',
                          centered: true,
                        });
                      } else {
                        const tableData = parsedData?.data || [];
                        console.log("tableData", tableData)
                        settabledata(tableData);
                        callCustomersLambdaSync()
                        setLoading(false)
                      }
                    }
          if (heading === "Carrier") {
            try {
              setLoading(true);
              const url = ENV_ROUTES.TENANT_ONBOARDING;
              const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                parent_module: "Super Admin",
                sub_module: "Partner API",
                path: "/get_superadmin_info",
                role_name: role,
                mod_pages: {
                  start: 0,
                  end: 100,
                },
                sub_tab: "Carrier APIs",
                Partner: partner,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
              };
              const response = await axios.post(url, { data: data });
              const resp = JSON.parse(response.data.body);
              const carrierApis = resp.data.Carrier_apis_data.carrier_apis;
              settabledata(carrierApis);
            } catch (err) {
            } finally {
              setLoading(false);
            }
          }
          if (heading === "API") {
            try {
              setLoading(true);
              const url = ENV_ROUTES.TENANT_ONBOARDING;
              const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_superadmin_info",
                role_name: role,
                parent_module: "Super Admin",
                sub_module: "Partner API",
                mod_pages: {
                  start: 0,
                  end: 100,
                },
                sub_tab: "Amop APIs",
                Partner: partner,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
              };

              const response = await axios.post(url, { data: data });
              const resp = JSON.parse(response.data.body);
              console.log(resp);
              const carrierApis = resp.data.amop_apis_data.amop_apis;
              console.log(carrierApis);
              settabledata(carrierApis);
            } catch (err) {
              console.error("Error fetching data:", err);
              // Modal.error({
              //   title: 'Data Fetch Error',
              //   content: err instanceof Error ? err.message : 'An unexpected error occurred while fetching data. Please try again.',
              //   centered: true,
              // });
            } finally {
              setLoading(false); // Set loading to false after the request is done
            }
          }
          if (heading === "E911 Customer") {
            const url = ENV_ROUTES.PEOPLE_MODULE;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/people_list_view",
              role_name: role,
              parent_module: "people",
              module_name: "E911 Customers",
              feature_module_name: "E911 Customers",
              mod_pages: {
                start: 0,
                end: 100,
              },
              Partner: partner,
              request_received_at: getCurrentDateTime(),
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching E911 Customers data. Please try again.",
                centered: true,
              });
            } else {
              const headerMap =
                parsedData.headers_map["E911 Customers"]["header_map"];
              const createModalData =
                parsedData.headers_map["E911 Customers"]["pop_up"];
              const customertableData = parsedData.data;
              settabledata(customertableData);
            }
          }
          if (heading === "NetSapien Customer") {
            const url = ENV_ROUTES.PEOPLE_MODULE;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/people_list_view",
              role_name: role,
              parent_module: "people", // Corrected spelling from 'poeple'
              module_name: "NetSapiens Customers",
              feature_module_name: "NetSapiens Customers",
              mod_pages: {
                start: 0,
                end: 100,
              },
              Partner: partner,
              request_received_at: getCurrentDateTime(),
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching E911 Customers data. Please try again.",
                centered: true,
              });
            } else {
              console.log(parsedData);
              // Check if the flag is false in the parsed data
              const tableData = parsedData.data;
              const headerMap =
                parsedData.headers_map["NetSapiens Customers"]["header_map"];
              const createModalData =
                parsedData.headers_map["NetSapiens Customers"]["pop_up"];
              const generalFields = parsedData.data;
              settabledata(tableData);
            }
          }
          if (heading === "Bandwidth Customer") {
            const url = ENV_ROUTES.PEOPLE_MODULE;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/people_list_view",
              role_name: role,
              parent_module: "people",
              module_name: "Bandwidth Customers",
              feature_module_name: "Bandwidth Customers",
              mod_pages: {
                start: 0,
                end: 100,
              },
              Partner: partner,
              request_received_at: getCurrentDateTime(),
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,
            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching E911 Customers data. Please try again.",
                centered: true,
              });
            } else {
              const tableData = parsedData.data;
              const headerMap =
                parsedData.headers_map["Bandwidth Customers"]["header_map"];
              const createModalData =
                parsedData.headers_map["Bandwidth Customers"]["pop_up"];
              const generalFields = parsedData.data;
              settabledata(tableData);
            }
          }
          if (heading === "Customer Group") {
            // callCoustomerGroupsSyncLambda()
            const url = ENV_ROUTES.MODULE_MANAGEMENT;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/get_partner_info",
              role_name: role,
              parent_module: "Partner",
              modules_list: ["Customer groups"],
              feature_module_name: "Partner Info",
              pages: {
                "Customer groups": { start: 0, end: 100 },
                "Partner users": { start: 0, end: 100 },
              },
              Partner: partner,
              offset:0,
              request_received_at: getCurrentDateTime(),
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,
            };
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching E911 Customers data. Please try again.",
                centered: true,
              });
            } else {
              setCustomerGroups(parsedData);
              const tableData =
                parsedData?.data?.["Customer groups"]?.customergroups || [];
              console.log("tableData", tableData);
              settabledata(tableData);
            }
          }
          if (heading === "Customer Rate Plan") {
            const url = ENV_ROUTES.MODULE_MANAGEMENT;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/get_module_data",
              role_name: role,
              parent_module: "Sim Management",
              module_name: "Customer Rate Plan",
              feature_module_name: "Customer Rate Plans",
              mod_pages: {
                start: 0,
                end: 100,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const tableData = parsedData?.data?.customerrateplan || [];
              //  console.log("tableData", tableData)
              settabledata(tableData);
            }
          }
          if (heading === "Customer Rate Pool") {
            callCustomerRatePoolsSync()
            const url = ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/get_customer_rate_pool_list_view_data",
              role_name: role,
              parent_module: "Sim Management",
              module_name: "Customer Rate Pool",
              feature_module_name: "Customer Rate Pools",
              mod_pages: {
                start: 0,
                end: 100,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const tableData = parsedData?.data?.customer_rate_pool || [];
              //  console.log("tableData", tableData)
              settabledata(tableData);
            }
          }
          if (heading === "Rate Plan Socs") {
            const url = ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/carrier_rate_plan_list_view",
              role_name: role,
              parent_module: "Sim Management",
              module_name: "Rate Plan Socs",
              feature_module_name: "Rate Plans/SOCs",
              mod_pages: {
                start: 0,
                end: 100,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const tableData = parsedData?.data?.carrier_rate_plan || [];
              //  console.log("tableData", tableData)
              settabledata(tableData);
            }
            callLambdaSync()
          }
          if (heading === "Create Rate Plan Type") {
            const url = ENV_ROUTES.MODULE_MANAGEMENT;
            const data = {
              tenant_name: partner || "default_value",
              username: username,
              firstLastName: firstLastName,
              path: "/get_module_data",
              role_name: role,
              parent_module: "Sim Management",
              module_name: "Create Rate Plan Type",
              feature_module_name: "Rate Plans/SOCs",
              mod_pages: {
                start: 0,
                end: 100,
              },
              request_received_at: getCurrentDateTime(),
              Partner: partner,
              access_token: token,
              db_name: selectedDb,
                ...metaData,
              sessionID: sessionId,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
              Modal.error({
                title: "Data Fetch Error",
                content:
                  parsedData.message ||
                  "An error occurred while fetching data. Please try again.",
                centered: true,
              });
            } else {
              const tableData =
                parsedData?.data?.optimization_rate_plan_type || [];
              //  console.log("tableData", tableData)
              settabledata(tableData);
            }
          }
          if (response && response.data.statusCode === 200) {
            // Show success message
            notification.success({
              message: "Success",
              description: "Successfully edited the record!",
              style: messageStyle,
              placement: "top", // Apply custom styles here
            });
            fireSideCannons()
          } else {
            const errorMsg = JSON.parse(response.data.body).message;
            Modal.error({
              title: "Saving Error",
              content: errorMsg,
              centered: true,
            });
          }
        } else {
          Modal.error({
            title: "Saving Error",
            content: resp.message,
            centered: true,
          });
        }
      } catch (error) {
        if (error instanceof Error) {
          Modal.error({
            title: "Saving Error",
            content:
              error.message ||
              "An unexpected error occurred during login. Please try again.",
            centered: true,
          });
        } else {
          Modal.error({
            title: "Saving Error",
            content:
              "An unexpected error occurred during login. Please try again.",
            centered: true,
          });
        }
      } finally {
        setLoading(false);
      }
    }
    handleSave();
    setIsConfirmationOpen(false);
  };

  const handleCancelConfirmation = () => {
    setIsConfirmationOpen(false);
  };

  const capitalizeFirstLetter = (text: any) => {
    console.log("text", text);
    if (!text) return "";
    return text
      .split(" ") // Split the sentence into an array of words
      .map(
        (word: string) =>
          word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()
      ) // Capitalize each word
      .join(" ");
  };

  const handleTabEditClose = () => {
    setIsCreateUserOpen(false);
  };

  const handleTabEditOpen = () => {
    setIsCreateUserOpen(true);
  };
  const getKey = (obj: any) => {
    if (obj) {
      const list = Object.values(obj);
      return list[0];
    }
  };

  useEffect(() => {
    if (isOpen) {
      console.log("rowData",rowData)
      setFormData(rowData || {});
      setValidationErrors({});
      if (heading === "Customer Rate Pool" || heading === "Customers") {
        fetchData()
      }
      if (isOpen && heading === "Customer Group") {
        setEnablePrivateNetwork(rowData?.enable_private_networks)
        const tenant_name_ = rowData?.sub_tenant_name || partner ||""
        fetchCustomerGroupsData(tenant_name_)

        if (isSubTenant) {
          setFormData((prevState: any) => {
            const updatedFormData = {
              ...prevState,
              sub_tanant: partner,
            }
            return updatedFormData;
          })
        }
        else {
          if (tenant_name_ && tenant_name_ !== partner) {
            setFormData((prev: any) => ({
              ...prev,
              sub_tanant: tenant_name_,
            })); //phani
          }
        }

      }
    }
  }, [isOpen, rowData]);

  const messageStyle = {
    fontSize: "14px",
    fontWeight: "bold",
    padding: "16px",
  };

  const multiplyFactor= (typeof window !== "undefined" && window.innerWidth < 700) ? 3.5 :2.5
  const modalHeight =
    typeof window !== "undefined" ? (window.innerHeight * 2.5) / 4 : 0;
    const modalWidth =
    typeof window !== "undefined" ? (window.innerWidth * multiplyFactor) / 4 : 0;
// const modalWidth =
// typeof window !== "undefined"
//   ? window.innerWidth < 640
//     ? "90vw" // Use 90% of viewport width for small screens
//     : (window.innerWidth * 2.5) / 4 // Maintain original calculation for larger screens
//   : "90vw"; // Default for SSR

  const tabModalHeight =
    typeof window !== "undefined" ? (window.innerHeight * 2.5) / 4 : 0;

  // return (
  //   <div>
  //     {isTabEdit ? (
  //       typeof window !== "undefined" && (window.innerWidth < 700)?(
  //         <div className="absolute bottom-0 left-0 right-0 top-0">
  //         <CreateUser isPopup={true} row={rowData} editable={isEditable} isSmallScreen={true} onClose={onClose}/>
  //         </div>
  //       ):(
  //          <>
  //         <Modal
  //           title={isEditable ? `Edit User` : `User Details`}
  //           open={isOpen}
  //           onCancel={handleCancel}
  //           width={modalWidth}
  //           styles={{ body: { height: tabModalHeight, padding: "4px" } }}
  //           footer={null}
  //           centered
  //         >
  //           <div className="popup">
  //             <CreateUser isPopup={true} row={rowData} editable={isEditable} onClose={onClose}/>
  //           </div>
  //         </Modal>
  //       </>
  //       )
       
  //     ) : (
  //       <>
  //         {!isEditable &&
  //         (heading === "NetSapien Customer" ||
  //           heading === "Bandwidth Customer") ? (
  //           <Modal
  //             open={isOpen}
  //             onCancel={handleCancel}
  //             title={
  //               <div className="">
  //                 <span className="text-[18px]">
  //                   {isEditable
  //                     ? `Edit ${capitalizeFirstLetter(heading)}`
  //                     : `${capitalizeFirstLetter(heading)} Details`}
  //                 </span>
  //               </div>
  //             }
  //             width={500}
  //             footer={
  //               <>
  //                 {isEditable ? (
  //                   <div className="justify-center flex space-x-2">
  //                     <button onClick={handleCancel} className="cancel-btn">
  //                       Cancel
  //                     </button>
  //                     <button onClick={showConfirmation} className="save-btn">
  //                       Save
  //                     </button>
  //                   </div>
  //                 ) : null}
  //               </>
  //             }
  //             centered
  //             styles={{ body: { height: "auto", padding: "4px" } }}
  //           >
  //             {/* <div className=''>
  //               <InfoPopup rate_plan={rate_plan_name_drp} rowData={rowData} isOpen={isOpen}
  //             onClose={handleCancel} />

  //             </div> */}
  //             {heading === "NetSapien Customer" ? (
  //               <InfoNetsepiansPopup
  //                 rate_plan={rate_plan_name_drp}
  //                 rowData={rowData}
  //                 isOpen={isOpen}
  //                 onClose={handleCancel}
  //               />
  //             ) : heading === "Bandwidth Customer" ? (
  //               <InfoPopup
  //                 rate_plan={rate_plan_name_drp}
  //                 rowData={rowData}
  //                 isOpen={isOpen}
  //                 onClose={handleCancel}
  //               />
  //             ) : null}
  //           </Modal>
  //         ) : (
  //           <>
  //               <Modal
  //                 open={isOpen}
  //                 onCancel={handleCancel}
  //                 title={
  //                   <h3 className="popup-heading">
  //                     {action === "copyFeature"
  //                       ? `Copy ${heading.toLowerCase()}`
  //                       : isEditable
  //                       ? heading === "Rate Plan Socs"
  //                         ? "Edit Rate Plan/SOC"
  //                         : `Edit ${capitalizeFirstLetter(heading)}`
  //                       : `${capitalizeFirstLetter(heading)} Details`}
  //                   </h3>
  //                 }
  //                 footer={
  //                   <>
                    
  //                     {isEditable ? (
  //                       <div className="justify-center flex space-x-2">
  //                         <button onClick={handleCancel} className="cancel-btn">
  //                           Cancel
  //                         </button>
  //                         <button
  //                           onClick={showConfirmation}
  //                           className="save-btn"
  //                         >
  //                           Save
  //                         </button>
  //                         {rowData?.email_type === "Infra" && (
  //                           <button className="save-btn">Email</button>
  //                         )}
  //                       </div>
  //                     ) : null}
  //                     {rowData &&
  //                       rowData.email_type &&
  //                       rowData.status === "Failed" && (
  //                         <>
  //                           <div className="justify-center flex space-x-2">
  //                             <button className="save-btn">Retry</button>
  //                           </div>
  //                         </>
  //                       )}
  //                   </>
  //                 }
  //                 width={createModalData.length > 5 ? modalWidth : "500px"}
  //                 styles={{
  //                   body: {
  //                     height: createModalData.length > 5 ? modalHeight : "auto",
  //                     padding: "4px",
  //                   },
  //                 }}
  //                 centered
  //               >
  //                 {!loading ? 
  //                   (
  //                     <div
  //                   className={`${createModalData.length > 5 ? "popup" : ""}`}
  //                 >
  //                   <>
  //                     <div
  //                       className={`grid gap-4 ${
  //                         createModalData.length > 5
  //                           ? "grid-cols-2"
  //                           : "grid-cols-1"
  //                       }`}
  //                     >
  //                       {createModalData
  //                         .filter((column: Column) => {
  //                           // Conditions for AT&T provider specific columns
  //                           const isATTProvider =
  //                             rowData?.service_provider?.includes(
  //                               "AT&T - Telegence"
  //                             );
  //                           const isRatePlanSocsHeading =
  //                             heading === "Rate Plan Socs";

  //                           const atTSpecificColumns = [
  //                             "default_optimization_group_id",
  //                             "optimization_rate_plan_type_id",
  //                             "Is_exclude_from_optimization",
  //                           ];

  //                           // Show all columns if it's AT&T provider and Rate Plan Socs heading
  //                           if (isATTProvider && isRatePlanSocsHeading) {
  //                             return true;
  //                           }

  //                           // Show columns that are not AT&T specific
  //                           if (
  //                             !atTSpecificColumns.includes(
  //                               column.db_column_name
  //                             )
  //                           ) {
  //                             return true;
  //                           }

  //                           // Hide AT&T specific columns for non-AT&T providers
  //                           return false;
  //                         })
  //                         .map((column: Column) => (
  //                           <div
  //                             key={column.db_column_name}
  //                             className="flex flex-col"
  //                           >
  //                             {column.type !== "checkbox" && column.db_column_name!=="Partner"&&(
  //                               <label className="field-label">
  //                                 {column.display_name}{" "}
  //                                 {column.mandatory &&
  //                                   column.mandatory !== null && column.db_column_name!=="Partner"&&(
  //                                     <span className="text-red-500">*</span>
  //                                   )}
  //                               </label>
  //                             )}
  //                             {column.type === "text" && (
  //                               <>
  //                                 <Input
  //                                   type="text"
  //                                   name={
  //                                     formData[column.db_column_name] &&
  //                                     formData[column.db_column_name] !== "None"
  //                                       ? column.db_column_name
  //                                       : ""
  //                                   }
  //                                   value={heading==="Customer Group"&&column.db_column_name==="tenant_name"?partner:
  //                                     formData[column.db_column_name] &&
  //                                     formData[column.db_column_name] !== "None"
  //                                       ? formData[column.db_column_name]
  //                                       : ""
  //                                   }
  //                                   onChange={(e) =>
  //                                     handleChange(
  //                                       column.db_column_name,
  //                                       e.target.value
  //                                     )
  //                                   }
  //                                   className={
  //                                     isEditable
  //                                       ? "input"
  //                                       : "non-editable-input"
  //                                   }
  //                                   disabled={(heading==="Customer Group" || heading==="Customers")&&column.db_column_name==="tenant_name"}
  //                                 />
  //                                 {validationErrors[column.db_column_name] && (
  //                                   <span className="text-red-500">
  //                                     {validationErrors[column.db_column_name]}
  //                                   </span>
  //                                 )}
  //                               </>
  //                             )}
  //                             {(column.type === "dropdown" && column.db_column_name!=="Partner" )&&(
  //                               <>
  //                                 <Select
  //                                 isClearable={(heading==="Customer Group"&&column.db_column_name==="sub_tanant")}
  //                                   isMulti={
  //                                     column.db_column_name ===
  //                                       "customer_names" ||
  //                                     column.db_column_name ===
  //                                       "rate_plan_name" ||
  //                                     column.db_column_name === "role_based" ||
  //                                     column.db_column_name ===
  //                                       "rate_plans_list" ||
  //                                       (heading==='Customer Rate Pool' && column.db_column_name === 'service_provider_name' && isCrossProvider)
  //                                       ||  (heading==='Customer Group' && column.db_column_name === 'feature_codes')
  //                                       ||  (heading==='Customer Group' && column.db_column_name === 'notification_rules')
  //                                   }
  //                                   styles={
  //                                     isEditable
  //                                       ? DropdownStyles
  //                                       : NonEditableDropdownStyles
  //                                   }
  //                                   isDisabled={!isEditable}
  //                                   placeholder="Select..."
  //                                   value={(() => {
  //                                     let selectedValues =formData[column.db_column_name]&&formData[column.db_column_name] !=="None"?formData[column.db_column_name]:[];

  //                                     // Special handling for ID-based columns
  //                                     const idBasedColumns = [
  //                                       "default_optimization_group_id",
  //                                       "optimization_rate_plan_type_id",
  //                                     ];

  //                                     if (
  //                                       idBasedColumns.includes(
  //                                         column.db_column_name
  //                                       )
  //                                     ) {
  //                                       // If the value is an ID, find the corresponding full option
  //                                       if (
  //                                         typeof selectedValues === "number"
  //                                       ) {
  //                                         const matchingOption =
  //                                           generalFields?.[
  //                                             column.db_column_name
  //                                           ]?.find(
  //                                             (option: string) =>
  //                                               parseInt(
  //                                                 option.split(" - ")[0]
  //                                               ) === selectedValues
  //                                           );

  //                                         return matchingOption
  //                                           ? {
  //                                               label:
  //                                                 matchingOption.split(
  //                                                   " - "
  //                                                 )[1],
  //                                               value: parseInt(
  //                                                 matchingOption.split(" - ")[0]
  //                                               ),
  //                                             }
  //                                           : null;
  //                                       }

  //                                       // Fallback to existing logic if needed
  //                                       return null;
  //                                     }

  //                                     try {
  //                                       // Existing logic for other columns
  //                                       selectedValues =
  //                                         typeof selectedValues === "string"
  //                                           ? JSON.parse(selectedValues)
  //                                           : selectedValues;

  //                                       selectedValues = Array.isArray(
  //                                         selectedValues
  //                                       )
  //                                         ? selectedValues
  //                                         : [selectedValues];

  //                                       return selectedValues.map(
  //                                         (item: any) => ({
  //                                           label: item,
  //                                           value: item,
  //                                         })
  //                                       );
  //                                     } catch (error) {
  //                                       const values =
  //                                         selectedValues?.split(",") || [];
  //                                       return values.map((item: string) => ({
  //                                         label: item.trim(),
  //                                         value: item.trim(),
  //                                       }));
  //                                     }
  //                                   })()}
  //                                   onChange={(values) => {
  //                                     const isMultiSelect =
  //                                       column.db_column_name ===
  //                                         "customer_names" ||
  //                                       column.db_column_name ===
  //                                         "rate_plan_name" ||
  //                                       column.db_column_name ===
  //                                         "role_based" ||
  //                                       column.db_column_name ===
  //                                         "rate_plans_list" ||
  //                                         (heading==='Customer Rate Pool' && column.db_column_name === 'service_provider_name' && isCrossProvider)
  //                                         ||  (heading==='Customer Group' && column.db_column_name === 'feature_codes')
  //                                         ||  (heading==='Customer Group' && column.db_column_name === 'notification_rules')
  //                                     // Special handling for ID-based columns
  //                                     const idBasedColumns = [
  //                                       "default_optimization_group_id",
  //                                       "optimization_rate_plan_type_id",
  //                                     ];

  //                                     if (
  //                                       idBasedColumns.includes(
  //                                         column.db_column_name
  //                                       )
  //                                     ) {
  //                                       // Specific handling for ID-based columns
  //                                       const selectedId = values
  //                                         ? values.value
  //                                         : null;
  //                                       handleSelectChange(
  //                                         column.db_column_name,
  //                                         selectedId
  //                                       );
  //                                     }
  //                                     //  else if (
  //                                     //   heading==='Customer Rate Pool' && column.db_column_name === 'service_provider_name' && isCrossProvider
  //                                     // ) {
  //                                     //   // Existing single-value logic for service_provider_name
  //                                     //   const newValue = Array.isArray(values)
  //                                     //     ? values[values.length - 1]?.value
  //                                     //     : values?.value;

  //                                     //   const updatedValues =
  //                                     //     formData[column.db_column_name] || [];

  //                                     //   if (!updatedValues.includes(newValue)) {
  //                                     //     handleSelectChange(
  //                                     //       column.db_column_name,
  //                                     //       [newValue]
  //                                     //     );
  //                                     //   }
  //                                     // } 
  //                                     else if (isMultiSelect) {
  //                                       // Allow multi-selection normally
  //                                       if (Array.isArray(values)) {
  //                                         if (values.length > 20) {
  //                                           setError(
  //                                             "You can select up to 20 options only."
  //                                           );
  //                                           return;
  //                                         }
  //                                         setError(null);

  //                                         const updatedValues = values.map(
  //                                           (option) => option.value
  //                                         );
  //                                         handleSelectChange(
  //                                           column.db_column_name,
  //                                           updatedValues
  //                                         );
  //                                       } else {
  //                                         handleSelectChange(
  //                                           column.db_column_name,
  //                                           values ? [values.value] : []
  //                                         );
  //                                       }
  //                                     } else {
  //                                       // Default behavior for single select
  //                                       handleSelectChange(
  //                                         column.db_column_name,
  //                                         values ? values.value : null
  //                                       );
  //                                     }
  //                                   }}
  //                                   options={heading==="Customer Group"?customerGroupsDropdownData[column.db_column_name]:
  //                                     column.db_column_name ===
  //                                           "default_optimization_group_id" ||
  //                                         column.db_column_name ===
  //                                           "optimization_rate_plan_type_id"
  //                                       ? generalFields?.[
  //                                           column.db_column_name
  //                                         ]?.map((option: any) => ({
  //                                           label: option.split(" - ")[1], // display only the name
  //                                           value: parseInt(
  //                                             option.split(" - ")[0]
  //                                           ), // convert ID to integer
  //                                         }))
  //                                       : column.db_column_name &&
  //                                         generalFields &&
  //                                         generalFields[
  //                                           column.db_column_name
  //                                         ] &&
  //                                         Array.isArray(
  //                                           generalFields[column.db_column_name]
  //                                         )
  //                                       ? generalFields[
  //                                           column.db_column_name
  //                                         ].map((option: any) => ({
  //                                           label: option,
  //                                           value: option,
  //                                         }))
  //                                       : []
  //                                   }
  //                                 />

  //                                 {validationErrors[column.db_column_name] && (
  //                                   <span className="text-red-500 mt-2">
  //                                     {validationErrors[column.db_column_name]}
  //                                   </span>
  //                                 )}
  //                               </>
  //                             )}
  //                             {error && (
  //                               <div
  //                                 style={{ color: "red", marginTop: "10px" }}
  //                               >
  //                                 {error}
  //                               </div>
  //                             )}{" "}
  //                             {/* Error message displayed here */}
  //                             {column.type === "checkbox" && (
  //                               <>
  //                                 <Checkbox
  //                                   checked={
  //                                     formData[column.db_column_name] &&
  //                                     formData[column.db_column_name] !== "None" &&
  //                                     formData[column.db_column_name] !== "False"
  //                                       ? formData[column.db_column_name]
  //                                       : false
  //                                   }
  //                                   onChange={(e) =>
  //                                     handleChange(
  //                                       column.db_column_name,
  //                                       e.target.checked
  //                                     )
  //                                   }
  //                                   className="mt-1"
  //                                 >
  //                                   {column.display_name}
  //                                 </Checkbox>
  //                                 {validationErrors[column.db_column_name] && (
  //                                   <span className="text-red-500">
  //                                     {validationErrors[column.db_column_name]}
  //                                   </span>
  //                                 )}
  //                               </>
  //                             )}
  //                             {column.type === "date" && (
  //                               <>
  //                                 <DatePicker
  //                                   value={
  //                                     formData[column.db_column_name] &&
  //                                     dayjs(
  //                                       formData[column.db_column_name]
  //                                     ).isValid()
  //                                       ? dayjs(formData[column.db_column_name])
  //                                       : null
  //                                   }
  //                                   onChange={(date) =>
  //                                     handleChange(
  //                                       column.db_column_name,
  //                                       date ? date.format("YYYY-MM-DD") : null
  //                                     )
  //                                   }
  //                                   className="input min-h-[40px]"
  //                                   disabledDate={(current) =>
  //                                     (column.db_column_name ===
  //                                       "inactivity_start" &&
  //                                       current &&
  //                                       current < dayjs().startOf("day")) ||
  //                                     (column.db_column_name ===
  //                                       "inactivity_end" &&
  //                                       current &&
  //                                       current < dayjs().startOf("day"))
  //                                   }
  //                                   format="YYYY-MM-DD"
  //                                   placeholder="Select a date"
  //                                   disabled={!isEditable}
  //                                 />
  //                                 {validationErrors[column.db_column_name] && (
  //                                   <span className="text-red-500">
  //                                     {validationErrors[column.db_column_name]}
  //                                   </span>
  //                                 )}
  //                               </>
  //                             )}
  //                             {column.type === "textarea" && (
  //                               <textarea
  //                                 value={formData[column.db_column_name] || ""}
  //                                 onChange={(e) =>
  //                                   handleChange(
  //                                     column.db_column_name,
  //                                     e.target.value
  //                                   )
  //                                 }
  //                                 className="input min-h-[80px] mt-1 w-full"
  //                                 // placeholder={`Enter ${column.display_name}`}
  //                                 disabled={!isEditable}
  //                               />
  //                             )}
  //                             {/* New block to handle boolean column type */}
  //                             {column.type === "boolean" && (
  //                               <>
  //                                 <div className="flex items-center">
  //                                   <span className="mr-2 w-12">
  //                                     {formData[column.db_column_name] ===
  //                                     "True"
  //                                       ? "Active"
  //                                       : "Inactive"}
  //                                   </span>
  //                                   <Switch
  //                                     onChange={() =>
  //                                       handleChange(
  //                                         column.db_column_name,
  //                                         formData[column.db_column_name] ===
  //                                           "True"
  //                                           ? "False"
  //                                           : "True"
  //                                       )
  //                                     }
  //                                     checked={
  //                                       formData[column.db_column_name] ===
  //                                       "True"
  //                                     }
  //                                     className="custom-switch"
  //                                   />
  //                                 </div>
  //                                 {validationErrors[column.db_column_name] && (
  //                                   <span className="text-red-500">
  //                                     {validationErrors[column.db_column_name]}
  //                                   </span>
  //                                 )}
  //                               </>
  //                             )}
  //                           </div>
  //                         ))}
  //                     </div>
  //                     {/* {mandatoryError && (
  //                     <div>
  //                       <span className='text-red-500'>{mandatoryError}</span>
  //                     </div>
  //                   )} */}
  //                   </>
  //                 </div>
  //                   ):(
  //                     <div className="flex justify-center items-center" 
  //                     style={
  //                       {maxWidth:createModalData.length > 5 ? modalWidth : "500px",
  //                       height: createModalData.length > 5 ? modalHeight : "auto",
  //                        margin: "0 auto",}}>
  //                       <Spin size="large" />
  //                     </div>
  //                   )}
                  
  //               </Modal>
              
  //           </>
  //         )}

  //         <Modal
  //           visible={isConfirmationOpen}
  //           onOk={handleConfirmSave}
  //           onCancel={handleCancelConfirmation}
  //           style={{ zIndex: 10000 }}
  //           title="Confirmation"
  //           footer={
  //             <div className="justify-center flex space-x-2 mt-10">
  //               <button
  //                 onClick={handleCancelConfirmation}
  //                 className="cancel-btn"
  //               >
  //                 Cancel
  //               </button>
  //               <button onClick={handleConfirmSave} className="save-btn">
  //                 Ok
  //               </button>
  //             </div>
  //           }
  //           centered
  //         >
  //           <p>Are you sure you want to Save the Changes</p>
  //         </Modal>
  //       </>
  //     )}
  //   </div>
  // );
  return (
    <div className="relative">
      {isTabEdit ? (
        typeof window !== "undefined" && window.innerWidth < 700 ? (
          <div className="fixed inset-0 overflow-y-auto bg-white z-50">
            <CreateUser
              isPopup={true}
              row={rowData}
              editable={isEditable}
              isSmallScreen={true}
              onClose={()=>{
                onClose()
                setEditedTableData([])
              }}
            />
          </div>
        ) : (
          <Modal
            title={isEditable ? `Edit User` : `User Details`}
            open={isOpen}
            onCancel={handleCancel}
            width={modalWidth}
            className="responsive-modal"
            styles={{
              body: { height: tabModalHeight, padding: "8px", overflowY: "auto" },
            }}
            footer={null}
            centered
          >
            <div className="popup">
              <CreateUser
                isPopup={true}
                row={rowData}
                editable={isEditable}
                  onClose={() => {
                    onClose()
                    setEditedTableData([])
                  }}
              />
            </div>
          </Modal>
        )
      ) : (
        <>
          {!isEditable &&
          (heading === "NetSapien Customer" || heading === "Bandwidth Customer") ? (
            <Modal
              open={isOpen}
              onCancel={handleCancel}
              title={
                <div className="">
                  <span className="text-[18px]">
                    {isEditable
                      ? `Edit ${capitalizeFirstLetter(heading)}`
                      : `${capitalizeFirstLetter(heading)} Details`}
                  </span>
                </div>
              }
              width={500}
              footer={
                <>
                  {isEditable ? (
                    <div className="justify-center flex space-x-2">
                      <button onClick={handleCancel} className="cancel-btn">
                        Cancel
                      </button>
                      <button onClick={showConfirmation} className="save-btn">
                        Save
                      </button>
                    </div>
                  ) : null}
                </>
              }
              centered
              styles={{ body: { height: "auto", padding: "4px" } }}
            >
              {heading === "NetSapien Customer" ? (
                <InfoNetsepiansPopup
                  rate_plan={rate_plan_name_drp}
                  rowData={rowData}
                  isOpen={isOpen}
                  onClose={handleCancel}
                />
              ) : heading === "Bandwidth Customer" ? (
                <InfoPopup
                  rate_plan={rate_plan_name_drp}
                  rowData={rowData}
                  isOpen={isOpen}
                  onClose={handleCancel}
                />
              ) : null}
            </Modal>
          ) : (
            <Modal
              open={isOpen}
              onCancel={handleCancel}
              title={
                    <h3 className="popup-heading">
                      {action === "copyFeature"
                        ? `Copy ${heading.toLowerCase()}`
                        : isEditable
                        ? heading === "Rate Plan Socs"
                          ? "Edit Rate Plan/SOC"
                          : `Edit ${capitalizeFirstLetter(heading)}`
                        : `${capitalizeFirstLetter(heading)} Details`}
                    </h3>
                  }
              footer={
                <>
                  {isEditable ? (
                    <div className="flex justify-center space-x-4">
                      <button onClick={handleCancel} className="cancel-btn">
                        Cancel
                      </button>
                      <button onClick={showConfirmation} className="save-btn">
                        Save
                      </button>
                      {rowData?.email_type === "Infra" && (
                        <button className="save-btn">Email</button>
                      )}
                    </div>
                  ) : null}
                  {rowData?.email_type && rowData.status === "Failed" && (
                    <div className="flex justify-center space-x-4">
                      <button className="save-btn">Retry</button>
                    </div>
                  )}
                </>
              }
              width={createModalData.length > 5 ? modalWidth : "500px"}
                  styles={{
                    body: {
                      height: createModalData.length > 5 ? modalHeight : "auto",
                      padding: "4px",
                    },
                  }}
              centered
            >
              {!loading ? (
                <div className="popup">
                <div
                  className={`${createModalData.length > 5 ? "grid grid-cols-1 md:grid-cols-2 gap-4" : "grid grid-cols-1 gap-4"}`}
                >
                  {createModalData
                    .filter((column) => {
                      const isATTProvider = getTargetTenantProvider(rowData?.service_provider)?.includes("AT&T - Telegence");
                      const isRatePlanSocsHeading = heading === "Rate Plan Socs";
                      const atTSpecificColumns = [
                        "default_optimization_group_id",
                        "optimization_rate_plan_type_id",
                        "Is_exclude_from_optimization",
                      ];
                      if (isATTProvider && isRatePlanSocsHeading) return true;
                      return !atTSpecificColumns.includes(column.db_column_name);
                    })
                    .map((column) => (
                      <div key={column.db_column_name} className="flex flex-col">
                        {column.type !== "checkbox" && column.db_column_name !== "Partner" && (
                          <label className="field-label">
                            {(heading === "Customers" && !isOptimizatioPerRevIODates && (column.db_column_name==="customer_bill_period_end_hour" || column.db_column_name==="customer_bill_period_end_day"))?`AMOP ${column.display_name}`: column.display_name}{" "}
                            {column.mandatory && column.db_column_name !== "Partner" && (
                              <span className="text-red-500">*</span>
                            )}
                          </label>
                        )}
                        {column.type === "text" && (
                          <>
                            <Input
                              type="text"
                              name={formData[column.db_column_name] && formData[column.db_column_name] !== "None" ? column.db_column_name : ""}
                              value={
                                heading === "Customer Group" && column.db_column_name === "tenant_name"
                                  ? formData["parent_tenant_name"] || partner || formData[column.db_column_name]
                                  : formData[column.db_column_name] !== undefined && formData[column.db_column_name] !== null && formData[column.db_column_name] !== "None"
                                  ? formData[column.db_column_name]
                                  : ""
                              }
                              onChange={(e) => handleChange(column.db_column_name, e.target.value)}
                              className={isEditable ? "input" : "non-editable-input"}
                              disabled={((heading === "Customer Group" || heading === "Customers") && column.db_column_name === "tenant_name") || !isEditable} 
                            />
                            {validationErrors[column.db_column_name] && (
                              <span className="text-red-500 text-xs">
                                {validationErrors[column.db_column_name]}
                              </span>
                            )}
                          </>
                        )}
                        {column.type === "dropdown" && column.db_column_name !== "Partner" && (
                          <>
                          {heading === "Customer Group" && column.db_column_name === "billing_account_number" && !isAdmin ?
                      
                    (
                      <Input
                        type="text"
                        value={customerGroupsDropdownData && customerGroupsDropdownData[column.db_column_name] && customerGroupsDropdownData?.[column.db_column_name].length>0?customerGroupsDropdownData?.[column.db_column_name][0]?.value:customerGroupsDropdownData[column.db_column_name] || ""}
                        // onChange={(e) => handleChange(column.db_column_name, e.target.value)}
                        className="non-editable-input w-full"
                        placeholder={`Enter Billing Account Number`}
                        disabled
                      />
                    ):(
                      <>
                      <Select
                              isClearable={heading === "Customer Group" && column.db_column_name === "sub_tanant"}
                              isMulti={
                                column.db_column_name === "customer_names" ||
                                column.db_column_name === "rate_plan_name" ||
                                column.db_column_name === "role_based" ||
                                column.db_column_name === "rate_plans_list" ||
                                (heading === "Customer Rate Pool" && column.db_column_name === "service_provider_name" && isCrossProvider) ||
                                (heading === "Customer Group" && (column.db_column_name === "feature_codes" || column.db_column_name === "notification_rules"|| column.db_column_name === "comm_plans"))
                              }
                              styles={(!isEditable || (heading === "Customer Group" && column.db_column_name === "sub_tanant" && isSubTenant)) ? NonEditableDropdownStyles : DropdownStyles}
                              isDisabled={!isEditable || (heading === "Customer Group" && column.db_column_name === "sub_tanant" && isSubTenant)}
                              placeholder="Select..."
                              value={(() => {
                                let selectedValues = formData[column.db_column_name] && formData[column.db_column_name] !== "None" ? formData[column.db_column_name] : [];
                                const idBasedColumns = ["default_optimization_group_id", "optimization_rate_plan_type_id"];
                                if (idBasedColumns.includes(column.db_column_name)) {
                                  if (typeof selectedValues === "number") {
                                    const matchingOption = generalFields?.[column.db_column_name]?.find(
                                      (option:string) => parseInt(option.split(" - ")[0]) === selectedValues
                                    );
                                    return matchingOption
                                      ? { label: matchingOption.split(" - ")[1], value: parseInt(matchingOption.split(" - ")[0]) }
                                      : null;
                                  }
                                  return null;
                                }
                                try {
                                  selectedValues = typeof selectedValues === "string" ? JSON.parse(selectedValues) : selectedValues;
                                  selectedValues = Array.isArray(selectedValues) ? selectedValues : [selectedValues];
                                  return selectedValues.map((item:any) => ({ label: item, value: item }));
                                } catch (error) {
                                  const values = selectedValues?.split(",") || [];
                                  return values.map((item:string) => ({ label: item.trim(), value: item.trim() }));
                                }
                              })()}
                              onChange={(values) => {
                                const isMultiSelect =
                                  column.db_column_name === "customer_names" ||
                                  column.db_column_name === "rate_plan_name" ||
                                  column.db_column_name === "role_based" ||
                                  column.db_column_name === "rate_plans_list" ||
                                  (heading === "Customer Rate Pool" && column.db_column_name === "service_provider_name" && isCrossProvider) ||
                                  (heading === "Customer Group" && (column.db_column_name === "feature_codes" || column.db_column_name === "notification_rules"|| column.db_column_name === "comm_plans"));
                                const idBasedColumns = ["default_optimization_group_id", "optimization_rate_plan_type_id"];
                                if (idBasedColumns.includes(column.db_column_name)) {
                                  const selectedId = values ? values.value : null;
                                  handleSelectChange(column.db_column_name, selectedId);
                                } else if (isMultiSelect) {
                                  if (Array.isArray(values)) {
                                    // if (values.length > 20) {
                                    //   setError("You can select up to 20 options only.");
                                    //   return;
                                    // }
                                    setError(null);
                                    const updatedValues = values.map((option) => option.value);
                                    handleSelectChange(column.db_column_name, updatedValues);
                                  } else {
                                    handleSelectChange(column.db_column_name, values ? [values.value] : []);
                                  }
                                } else {
                                  handleSelectChange(column.db_column_name, values ? values.value : null);
                                }
                              }}
                              options={
                                heading === "Customer Group"
                                  ? customerGroupsDropdownData[column.db_column_name]
                                  : column.db_column_name === "default_optimization_group_id" || column.db_column_name === "optimization_rate_plan_type_id"
                                  ? generalFields?.[column.db_column_name]?.map((option:any) => ({
                                      label: option.split(" - ")[1],
                                      value: parseInt(option.split(" - ")[0]),
                                    }))
                                  : column.db_column_name && generalFields && generalFields[column.db_column_name] && Array.isArray(generalFields[column.db_column_name])
                                  ? generalFields[column.db_column_name].map((option:any) => ({ label: option, value: option }))
                                  : []
                              }
                            />
                            {validationErrors[column.db_column_name] && (
                              <span className="text-red-500 text-xs">
                                {validationErrors[column.db_column_name]}
                              </span>
                            )}
                      </>
                    )}
                            
                          </>
                        )}
                        {error && (
                          <div className="text-red-500 text-xs mt-2">{error}</div>
                        )}
                        {column.type === "checkbox" && (
                          <>
                            <Checkbox
                              checked={formData[column.db_column_name] && formData[column.db_column_name] !== "None" && formData[column.db_column_name] !== "False" ? formData[column.db_column_name] : false}
                              onChange={(e) => handleChange(column.db_column_name, e.target.checked)}
                              className="mt-1"
                            >
                              {column.display_name}
                            </Checkbox>
                            {validationErrors[column.db_column_name] && (
                              <span className="text-red-500 text-xs">
                                {validationErrors[column.db_column_name]}
                              </span>
                            )}
                          </>
                        )}
                        {column.type === "date" && (
                          <>
                            <DatePicker
                              value={formData[column.db_column_name] && dayjs(formData[column.db_column_name]).isValid() ? dayjs(formData[column.db_column_name]) : null}
                              onChange={(date) => handleChange(column.db_column_name, date ? date.format("YYYY-MM-DD") : null)}
                              className="input min-h-[40px] w-full"
                              disabledDate={(current) =>
                                (column.db_column_name === "inactivity_start" && current && current < dayjs().startOf("day")) ||
                                (column.db_column_name === "inactivity_end" && current && current < dayjs().startOf("day"))
                              }
                              format="YYYY-MM-DD"
                              placeholder="Select a date"
                              disabled={!isEditable}
                            />
                            {validationErrors[column.db_column_name] && (
                              <span className="text-red-500 text-xs">
                                {validationErrors[column.db_column_name]}
                              </span>
                            )}
                          </>
                        )}
                        {column.type === "textarea" && (
                          <textarea
                            value={formData[column.db_column_name] || ""}
                            onChange={(e) => handleChange(column.db_column_name, e.target.value)}
                            className="input min-h-[80px] mt-1 w-full"
                            disabled={!isEditable}
                          />
                        )}
                        {column.type === "boolean" && (
                          <>
                            <div className="flex items-center">
                              <span className="mr-2 w-12 text-sm">
                                {formData[column.db_column_name] === "True" ? "Active" : "Inactive"}
                              </span>
                              <Switch
                                onChange={() => handleChange(column.db_column_name, formData[column.db_column_name] === "True" ? "False" : "True")}
                                checked={formData[column.db_column_name] === "True"}
                                className="custom-switch"
                              />
                            </div>
                            {validationErrors[column.db_column_name] && (
                              <span className="text-red-500 text-xs">
                                {validationErrors[column.db_column_name]}
                              </span>
                            )}
                          </>
                        )}
                      </div>
                    ))}
                </div>
                
             {/* Private Network List View */}
            {(heading === "Customer Group" && (enablePrivateNetwork || formData?.enable_private_networks)) && (
              <>
                <div style={{ marginBottom: "1rem" }} className="mt-2">
                  <div className="tabs-sub-headings w-full">
                    <h3>Private Networks</h3>
                  </div>
                  <PrivateNetworkTable
                    initialData={[]}
                    itemsPerPage={10}
                    popupHeading="Billing Customers"
                    pagination={{ start: 0, end: 0, total: 0 }}
                    serviceProviderOptions={serviceProviderOptions}
                    isEditable={true}
                    row={rowData}
                  />
                </div>
              </>
            )}
                </div>
              ) : (
                <div className="flex justify-center items-center" style={{ height: createModalData.length > 5 ? modalHeight : "auto" }}>
                  <Spin size="large" />
                </div>
              )}
            </Modal>
          )}
          <Modal
            visible={isConfirmationOpen}
            onOk={handleConfirmSave}
            onCancel={handleCancelConfirmation}
            className="responsive-modal"
            title="Confirmation"
            footer={
              <div className="flex justify-center space-x-4 mt-4">
                <button onClick={handleCancelConfirmation} className="cancel-btn">
                  Cancel
                </button>
                <button onClick={handleConfirmSave} className="save-btn">
                  Ok
                </button>
              </div>
            }
            centered
          >
            <p className="text-sm">Are you sure you want to Save the Changes?</p>
          </Modal>
        </>
      )}
    </div>
  );
};

export default EditModal;
