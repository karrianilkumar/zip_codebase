"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { Suspense, useEffect, useState } from "react";
import { useAuth } from "@/app/components/auth_context";
import { Spin } from "antd";

function LoginCallback() {
  const params = useSearchParams();
  const {
    setIsAuthenticated,
    handleSelectedPartner,
    handleLoginUsingCode,
    setUsername,
    error,
    loading,
  } = useAuth();

  const router = useRouter();
  const [isLoggingIn, setIsLoggingIn] = useState(true);
  const [triggered, setTriggered] = useState(false);

  useEffect(() => {
    if (loading || triggered) {
      return;
    }
    setTriggered(true);
    console.info("LoginCallbackPage: useEffect");
    const _code = params.get("code") || "";
    const _tenantId = params.get("tenantId");
    const _tenantName = params.get("tenant_name");
    const _username = params.get("username") || "";
    const _returnUrl = params.get("returnUrl");
    const _role = params.get("role");
    async function login() {
      await handleLoginUsingCode(
        _code,
        _username,
        _role,
        _tenantId,
        _tenantName,
      );
      if (_username) {
        setUsername(_username);
      }
      if (_tenantName) {
        handleSelectedPartner(_tenantName);
      }
      setIsAuthenticated(true);

      // redirect to returnUrl
      if (!_returnUrl || _returnUrl.startsWith("/auth")) {
        router.replace("/dashboard");
      } else {
        router.replace(_returnUrl);
      }
      setIsLoggingIn(false);
    }

    login();

    // Only run once, so no need to add dependencies
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading, triggered]);

  if (isLoggingIn) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex justify-center items-center h-screen">
        <h1>Cannot load modules</h1>
        <p>{error.message}</p>
      </div>
    );
  }

  return null;
}

export default function LoginCallbackPage() {
  return (
    <Suspense>
      <LoginCallback />
    </Suspense>
  );
}
