"use client";

import { useEffect } from "react";

export default function AuthPage() {
  useEffect(() => {
    const currentBaseUrl = window.location.origin;
    const returnUrlHere = window.location.pathname;
    const callbackUrl = `${currentBaseUrl}/auth/callback?returnUrl=${encodeURIComponent(returnUrlHere)}`;
    window.location.href = `${process.env.NEXT_PUBLIC_AMOP_1_BASE_URL}/Login?returnUrl=${encodeURIComponent(
      callbackUrl,
    )}`;
  }, []);

  return null;
}
