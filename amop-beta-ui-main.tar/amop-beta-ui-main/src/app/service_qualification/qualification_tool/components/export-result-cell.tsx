import { exportResults } from "@/api/qualification-api";
import { ServiceQualification } from "@/types/qualification-types";
import { FileSearchOutlined } from "@ant-design/icons";
import { useMutation } from "@tanstack/react-query";
import { Button, notification, Tooltip } from "antd";

interface ExportResultCellProps {
  qualification: ServiceQualification;
}

const ExportResultCell: React.FC<ExportResultCellProps> = ({
  qualification,
}) => {
  const id = qualification.id.toString();

  const { mutateAsync: handleExport, isPending } = useMutation({
    mutationFn: async (id: string) => {
      await exportResults(id);
    },
    onError: (error) => {
      notification.error({
        message: "Error",
        description: `Error exporting results: ${error}`,
      });
    },
    onSuccess: () => {
      notification.success({
        message: "Success",
        description: "Results exported successfully",
      });
    },
  });

  return (
    <Tooltip title="Export Results">
      <Button
        type="link"
        onClick={() => handleExport(id)}
        icon={<FileSearchOutlined />}
        loading={isPending}
      />
    </Tooltip>
  );
};

export const exportResultCellRenderer = (
  qualification: ServiceQualification,
) => <ExportResultCell qualification={qualification} />;
