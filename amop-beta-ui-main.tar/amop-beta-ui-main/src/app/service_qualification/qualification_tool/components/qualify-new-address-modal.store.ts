import { create } from "zustand";

export type QualifyNewAddressModalStore = {
  open: boolean;
  isSubmitting: boolean;
  isFetching: boolean;
  uploadModalVisible: boolean;
};
export type QualifyNewAddressModalActions = {
  openModal: () => void;
  closeModal: () => void;
  setIsSubmitting: (isSubmitting: boolean) => void;
  setIsFetching: (isFetching: boolean) => void;
  setUploadModalVisible: (uploadModalVisible: boolean) => void;
};

const initialState: QualifyNewAddressModalStore = {
  open: false,
  isSubmitting: false,
  isFetching: false,
  uploadModalVisible: false,
};

export const useQualifyNewAddressModalStore = create<
  QualifyNewAddressModalStore & QualifyNewAddressModalActions
>((set) => ({
  ...initialState,
  openModal: () => set({ open: true }),
  closeModal: () => set(initialState),
  setIsSubmitting: (isSubmitting) => set({ isSubmitting }),
  setIsFetching: (isFetching) => set({ isFetching }),
  setUploadModalVisible: (uploadModalVisible) => set({ uploadModalVisible }),
}));
