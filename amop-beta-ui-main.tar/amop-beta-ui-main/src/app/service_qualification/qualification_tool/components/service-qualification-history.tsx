"use client";

import {
  checkAuthorization,
  getServiceQualificationHistory,
} from "@/api/qualification-api";
import { QUALIFICATION_QUERY_KEY } from "@/common/constants/qualification-constants";
import { TableName } from "@/common/constants/table-constants";
import { AmopDataGrid, useAmopDataGridStates } from "@/components/data-grid";
import { ScrollToTop } from "@/components/scroll-to-top";
import useQualificationStore from "@/stores/qualification-store";
import { PlusOutlined } from "@ant-design/icons";
import { useQuery } from "@tanstack/react-query";
import { Button } from "antd";
import { QualifyNewAddressModal } from "./qualify-new-address-modal";
import { useQualifyNewAddressModalStore } from "./qualify-new-address-modal.store";
import { FeatureFlag } from "@/components/feature-flag/feature-flag";
import { ServiceQualificationQualificationFeatures } from "@/common/enums/module-feature-enum";
import { useCommonFeatureStore } from "@/stores/common-feature-store";
import { useMemo } from "react";

export default function ServiceQualificationHistory() {
  const { hasFeature } = useCommonFeatureStore();
  const { openModal } = useQualifyNewAddressModalStore();
  const { columns } = useQualificationStore();
  const [tableStates, { onChange, onSearch }] = useAmopDataGridStates<any>({
    page: 1,
    pageSize: 10,
    sorter: [],
    filters: {},
    search: "",
  });

  const { data, isFetching } = useQuery({
    queryKey: [
      QUALIFICATION_QUERY_KEY.SERVICE_QUALIFICATION,
      tableStates,
    ] as const,
    queryFn: async ({ queryKey: [, params] }) => {
      const { page, pageSize, search } = params;
      return await getServiceQualificationHistory(page, pageSize, search);
    },
    staleTime: Infinity,
  });

  const { data: isAuthorized, isFetching: isAuthLoading } = useQuery({
    queryKey: ["service-qualification", "check-authorization"],
    queryFn: checkAuthorization,
    staleTime: Infinity,
  });

  const filteredColumns = useMemo(
    () =>
      columns.filter((colDef) => {
        switch (colDef.key) {
          case "proceedToActivation":
            return (
              isAuthorized &&
              !isAuthLoading &&
              hasFeature(
                ServiceQualificationQualificationFeatures.ProceedToActivation,
              )
            );
          case "requalify":
            return hasFeature(
              ServiceQualificationQualificationFeatures.Requalify,
            );
          case "exportActivationTemplate":
            return hasFeature(
              ServiceQualificationQualificationFeatures.ExportActivationTemplate,
            );
          case "exportResults":
            return hasFeature(
              ServiceQualificationQualificationFeatures.ExportResult,
            );
          default:
            return true;
        }
      }),
    [columns, isAuthorized, isAuthLoading, hasFeature],
  );

  return (
    <div>
      <FeatureFlag feature={ServiceQualificationQualificationFeatures.Submit}>
        <Button
          type="primary"
          icon={<PlusOutlined />}
          className="mb-4"
          onClick={openModal}
        >
          Qualify New Address
        </Button>
      </FeatureFlag>
      <AmopDataGrid
        onChange={onChange}
        onSearch={onSearch}
        tableLayout="fixed"
        rowSelection={undefined}
        columns={filteredColumns}
        data={data?.results || []}
        total={data?.totalResults || 0}
        pageSize={tableStates.pageSize}
        currentPage={tableStates.page}
        loading={isFetching || isAuthLoading}
        tableName={TableName.QUALIFICATION_HISTORY}
        sticky={{
          offsetHeader: 64,
        }}
        scroll={{ x: 1200 }}
      />
      <FeatureFlag feature={ServiceQualificationQualificationFeatures.Submit}>
        <QualifyNewAddressModal />
      </FeatureFlag>
      <ScrollToTop visibilityHeight={400} />
    </div>
  );
}
