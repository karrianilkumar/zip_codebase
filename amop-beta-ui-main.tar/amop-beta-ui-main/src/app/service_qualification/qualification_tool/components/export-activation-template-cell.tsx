import { exportActivationTemplate } from "@/api/qualification-api";
import { DownloadOutlined } from "@ant-design/icons";
import { useMutation } from "@tanstack/react-query";
import { Button, Tooltip, notification } from "antd";
import React from "react";

interface ExportActivationTemplateCellProps {
  qualificationId: number;
}

const ExportActivationTemplateCell: React.FC<
  ExportActivationTemplateCellProps
> = ({ qualificationId }) => {
  const mutation = useMutation({
    mutationFn: () => {
      exportActivationTemplate(qualificationId);
      return Promise.resolve();
    },
    onSuccess: () => {
      notification.success({
        message: "Download Successful",
        description: "The Activation Template has been downloaded.",
      });
    },
    onError: (error) => {
      console.error(
        "Error occurred while downloading the Activation Template",
        error,
      );
      notification.error({
        message: "Download Failed",
        description:
          "Failed to download the Activation Template. Please try again.",
      });
    },
  });

  const handleDownloadClick = () => {
    mutation.mutate();
  };

  return (
    <Tooltip title="Export Activation Template">
      <Button
        type="link"
        onClick={handleDownloadClick}
        icon={<DownloadOutlined />}
        loading={mutation.isPending}
      />
    </Tooltip>
  );
};

export const exportActivationTemplateCellRenderer = (
  qualificationId: number,
) => <ExportActivationTemplateCell qualificationId={qualificationId} />;

export default ExportActivationTemplateCell;
