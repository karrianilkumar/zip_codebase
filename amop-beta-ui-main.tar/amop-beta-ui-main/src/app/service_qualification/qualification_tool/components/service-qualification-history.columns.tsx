import { STATUS_TYPE } from "@/common/constants/bulk-change-constant";
import { dateTimeCellRenderer } from "@/components/data-grid-cell-renderers/date-time-cell-renderer";
import { quantityCellRenderer } from "@/components/data-grid-cell-renderers/quantity-cell-renderer";
import { ServiceQualification } from "@/types/qualification-types";
import { TableColumnType, Tooltip } from "antd";
import { activationStatusCellRenderer } from "./activation-status-cell";
import { exportActivationTemplateCellRenderer } from "./export-activation-template-cell";
import { exportResultCellRenderer } from "./export-result-cell";
import { qualificationDetailCellRenderer } from "./qualification-detail-cell";
import { requalifyCellRenderer } from "./requalify-cell";

export const serviceQualificationHistoryColumns: TableColumnType<ServiceQualification>[] =
  [
    {
      title: "Service Type",
      dataIndex: "ServiceLineId",
      key: "serviceType",
    },
    {
      title: "Status",
      dataIndex: "Status",
      key: "status",
    },
    {
      key: "uploaded",
      dataIndex: "Uploaded",
      title: "Uploaded",
      sorter: true,
      render: quantityCellRenderer(STATUS_TYPE.UPLOADED),
      width: 100,
    },
    {
      key: "successful",
      dataIndex: "Successful",
      title: "Successful",
      sorter: true,
      render: quantityCellRenderer(STATUS_TYPE.SUCCESSFUL),
      width: 100,
    },
    {
      key: "errors",
      dataIndex: "Errors",
      title: "Errors",
      sorter: true,
      render: quantityCellRenderer(STATUS_TYPE.ERRORS),
      width: 100,
    },
    {
      title: "Processed By",
      dataIndex: "CreatedBy",
      key: "processedBy",
    },
    {
      title: "Processed Date",
      dataIndex: "CreatedDate",
      key: "processedDate",
      render: dateTimeCellRenderer,
    },
    {
      title: "Qualification Details",
      key: "qualificationDetails",
      render: qualificationDetailCellRenderer,
      align: "center",
    },
    {
      title: (
        <Tooltip title="Tooltip text to be defined">
          <span>Re-qualify</span>
        </Tooltip>
      ),
      dataIndex: "requalify",
      key: "requalify",
      align: "center",
      render: (_text, record) => requalifyCellRenderer(record.id),
    },
    {
      title: "Export Activation Template",
      dataIndex: "exportActivationTemplate",
      key: "exportActivationTemplate",
      align: "center",
      render: (_text, record) =>
        exportActivationTemplateCellRenderer(record.id),
    },
    {
      title: "Proceed to Activation",
      dataIndex: "proceedToActivation",
      key: "proceedToActivation",
      align: "center",
      render: (text, record) =>
        activationStatusCellRenderer(record.IsQualified, record.id),
    },
    {
      title: "Export Results",
      dataIndex: "exportResults",
      key: "exportResults",
      align: "center",
      render: (text, record) => exportResultCellRenderer(record),
    },
  ];
