import { requalifyQualification } from "@/api/qualification-api";
import { QUALIFICATION_QUERY_KEY } from "@/common/constants/qualification-constants";
import { ReloadOutlined } from "@ant-design/icons";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button, Modal, notification, Tooltip } from "antd";
import React from "react";
import { FeatureFlag } from "@/components/feature-flag/feature-flag";
import { ServiceQualificationQualificationFeatures } from "@/common/enums/module-feature-enum";

interface RequalifyCellProps {
  qualificationId: number;
}

const RequalifyCell: React.FC<RequalifyCellProps> = ({ qualificationId }) => {
  const queryClient = useQueryClient();

  const mutation = useMutation({
    mutationFn: () => requalifyQualification(qualificationId),
    onSuccess: async () => {
      await queryClient.invalidateQueries({
        queryKey: [QUALIFICATION_QUERY_KEY.SERVICE_QUALIFICATION],
      });
      notification.success({
        message: "Re-qualification Successful",
        description:
          "Your re-qualification request has been successfully submitted.",
      });
    },
    onError: (error) => {
      notification.error({
        message: "Re-qualification Failed",
        description: "Failed to re-qualify. Please try again later.",
      });
      console.error("Error re-qualifying:", error);
    },
  });

  const handleRequalifyClick = () => {
    Modal.confirm({
      title: "Are you sure you want to re-qualify?",
      content:
        "All addresses in this qualification will be re-qualified. You may not be able to re-qualify again for a certain period of time.",
      onOk: () => {
        mutation.mutate();
      },
      onCancel() {},
    });
  };

  return (
    <FeatureFlag feature={ServiceQualificationQualificationFeatures.Requalify}>
      <Tooltip title="Qualification tokens are only valid for an hour. Requalify to get a new token for ordering.">
        <Button
          type="link"
          onClick={handleRequalifyClick}
          icon={<ReloadOutlined />}
          loading={mutation.isPending}
        >
          {mutation.isPending ? "Re-qualifying..." : "Re-qualify"}
        </Button>
      </Tooltip>
    </FeatureFlag>
  );
};

export const requalifyCellRenderer = (qualificationId: number) => (
  <RequalifyCell qualificationId={qualificationId} />
);
