import { getQualificationAddressLogs } from "@/api/qualification-api";
import { QUALIFICATION_QUERY_KEY } from "@/common/constants/qualification-constants";
import useQualificationStore from "@/stores/qualification-store";
import { ServiceQualificationLog } from "@/types/qualification-types";
import { ExclamationCircleOutlined } from "@ant-design/icons";
import { useQuery } from "@tanstack/react-query";
import { Modal, Spin, Table } from "antd";
import React from "react";
import { statusDetailsColumns } from "./status-details-columns";

const StatusDetailsPopup: React.FC = () => {
  const {
    isOpenStatusPopup,
    setIsOpenStatusPopup,
    selectedAddressQualification,
  } = useQualificationStore();
  const { id: qualificationAddressId } = selectedAddressQualification || {};

  const { data, isLoading, isError } = useQuery<ServiceQualificationLog[]>({
    queryKey: [
      QUALIFICATION_QUERY_KEY.SERVICE_QUALIFICATION_LOG,
      qualificationAddressId,
    ] as const,
    queryFn: async ({ queryKey: [, id] }) => {
      return await getQualificationAddressLogs(id as number);
    },
  });

  const qualificationLogs: ServiceQualificationLog[] = data || [];

  const qualificationToken =
    qualificationLogs.length > 0
      ? JSON.parse(qualificationLogs[qualificationLogs.length - 1].Response)
          ?.qualificationId
      : null;
  const firstRequest = qualificationLogs[0]?.Request || "{}";
  const lastResponse =
    qualificationLogs[qualificationLogs.length - 1]?.Response || "{}";

  const handleOk = () => {
    setIsOpenStatusPopup(false);
  };

  const handleCancel = () => {
    setIsOpenStatusPopup(false);
  };

  return (
    <Modal
      title="Status Details"
      open={isOpenStatusPopup}
      onOk={handleOk}
      onCancel={handleCancel}
      width="100%"
      style={{ maxWidth: 1400 }}
      className="adm-wrapper"
    >
      <div className="p-4 grid grid-cols-1 gap-4">
        {isLoading ? (
          <div className="flex justify-center items-center">
            <Spin size="large" />
          </div>
        ) : isError ? (
          <div className="text-center text-red-500">
            <ExclamationCircleOutlined className="mr-2" />
            Error loading data. Please try again later.
          </div>
        ) : (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="font-bold">Qualification Token:</label>
                <div className="bg-gray-200 p-2 rounded">
                  {qualificationToken || "Qualification Token not found"}
                </div>
              </div>
              <div>
                <label className="font-bold">Status:</label>
                <div className="bg-gray-200 p-2 rounded">
                  {selectedAddressQualification?.Status || "Status not found"}
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex flex-col">
                <label className="font-bold">Request</label>
                <div className="flex-1 border border-gray-300 rounded overflow-auto p-2 max-h-64">
                  {handleJsonParsing(
                    firstRequest,
                    "Request data not available",
                  )}
                </div>
              </div>
              <div className="flex flex-col">
                <label className="font-bold">Response</label>
                <div className="flex-1 border border-gray-300 rounded overflow-auto p-2 max-h-64">
                  {handleJsonParsing(
                    lastResponse,
                    "Response data not available",
                  )}
                </div>
              </div>
            </div>

            <div>
              <h3 className="font-bold mb-2">Detailed Log Entries</h3>
              <Table
                dataSource={qualificationLogs}
                columns={statusDetailsColumns}
                scroll={{ x: true }}
                bordered
              />
            </div>
          </>
        )}
      </div>
    </Modal>
  );
};

const handleJsonParsing = (jsonString: string, fallbackMessage: string) => {
  try {
    const parsedData = JSON.parse(jsonString);
    return (
      <pre className="whitespace-pre-wrap break-words">
        {JSON.stringify(parsedData, null, 2)}
      </pre>
    );
  } catch (error) {
    console.error("Error parsing JSON: ", error);
    return (
      <div className="text-red-500">
        <ExclamationCircleOutlined className="mr-2" />
        {fallbackMessage}
      </div>
    );
  }
};

export default StatusDetailsPopup;
