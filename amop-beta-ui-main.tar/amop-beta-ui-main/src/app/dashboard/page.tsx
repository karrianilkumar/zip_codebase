"use client";
import React, { useEffect, useState, lazy, Suspense } from "react";
import { useAuth } from "@/app/components/auth_context";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { Button, Modal, Spin, Switch } from "antd";

// Lazy-loaded dashboard components
const Dashboard_2_0 = lazy(() => import("@/app/dashboard_2_0/page"));
const Dashboard_1_0 = lazy(() => import("@/app/dashboard_1_0/page"));

interface InfoProps {
  isOpen: boolean;
  onClose: () => void;
  row: any;
}

const ToggleDashboard: React.FC<InfoProps> = ({ isOpen, onClose, row }) => {
  const switch_user_2_0 = localStorage.getItem("switch_user_2_0");
  const [switchVersion, setSwitchVersion] = useState(false);
  const { username, partner, role, token, selectedDb,metaData, modulesVersionMap, setModulesVersionMap, sessionId } = useAuth();
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const initial_version_flag = modulesVersionMap?.["Dashboard-None"] || false;
    if (!initial_version_flag || initial_version_flag === "False" || initial_version_flag === "None") {
      setSwitchVersion(false);
    } else {
      setSwitchVersion(true);
    }
    saveVersionFlag();
  }, [modulesVersionMap]);

  const saveVersionFlag = async () => {
    const url = ENV_ROUTES.MODULE_MANAGEMENT;
    const data = {
      tenant_name: partner || "default_value",
      username,
      path: "/update_version_flag",
      role_name: role,
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
      version_flag: modulesVersionMap,
    };

    try {
      setLoading(true);
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === true) {
        console.log("Successfully saved version flag");
      }
    } catch (error) {
      console.error("Error saving version flag:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleVersionChange = (checked: boolean) => {
    setSwitchVersion(checked);
    const value_ = checked ? "True" : "False";
    setModulesVersionMap((prev: any) => {
      const updated = { ...prev, "Dashboard-None": checked };
      localStorage.setItem("switch_user_20_modules_json", JSON.stringify(updated));
      return updated;
    });
  };

  return (
    <div className="toggle-dashboard">
      {loading ? (
        <div className="flex justify-center items-center h-full">
          <Spin size="large" />
        </div>
      ) : (
        <>
          {/* Show toggle button only when Dashboard 1.0 is active and switch_user_2_0 is "True" */}
          {!switchVersion && switch_user_2_0 === "True" && (
            <div className="flex justify-end items-center !mt-[10px] switch-container">
              <span className="font-semibold mr-2 md:mr-4 toggle-span">1.0</span>
              <Switch
                checked={switchVersion}
                onChange={handleVersionChange}
                className="scale-[0.8] md:scale-[1.3] ml-4 custom-switch"
              />
              <span className="font-semibold ml-2 md:ml-4">2.0</span>
            </div>
          )}
          <div>
            <Suspense fallback={<div className="flex justify-center items-center h-full"><Spin size="large" /></div>}>
              {!switchVersion && <Dashboard_1_0 />}
              {switchVersion && <Dashboard_2_0 />}
            </Suspense>
          </div>
        </>
      )}
    </div>
  );
};

export default ToggleDashboard;