"use client";

import React, {
  useCallback,
  useEffect,
  useRef,
  useState,
  lazy,
  Suspense,
} from "react";
import { ArrowDownTrayIcon } from "@heroicons/react/24/outline";
import {
  Modal,
  Spin,
  notification,
  Input,
  Button,
  Select,
  Checkbox,
} from "antd";
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
const TableComponent = lazy(
  () => import("@/app/components/TableComponent/page")
);
const TableSearch = lazy(() => import("@/app/components/entire_table_search"));
const AdvancedMultiFilter = lazy(
  () => import("@/app/components/advanced_search")
);
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));

// default header map matching what the backend returns
const DEFAULT_HEADER_MAP: Record<string, [string, number]> = {
  orderId:         ["Order ID", 0],
  customerOrderId: ["Customer Order ID", 1],
  orderDate:       ["Order Date", 2],
  orderType:       ["Order Type", 3],
  user:            ["User", 4],
  provider:        ["Provider", 5],
  phoneNumbers:    ["Phone Numbers", 6],
  status:          ["Status", 7],
};

const TABLE_NAME = "Number Orders";
const ITEMS_PER_PAGE = 100;

// US state options for the search form
const US_STATES = [
  "AL","AK","AZ","AR","CA","CO","CT","DE","FL","GA","HI","ID","IL","IN","IA",
  "KS","KY","LA","ME","MD","MA","MI","MN","MS","MO","MT","NE","NV","NH","NJ",
  "NM","NY","NC","ND","OH","OK","OR","PA","RI","SC","SD","TN","TX","UT","VT",
  "VA","WA","WV","WI","WY","DC",
];

const NumberOrders: React.FC = () => {
  const {
    username,
    partner,
    role,
    token,
    selectedDb,
    metaData,
    sessionId,
    firstLastName,
    settabledata,
    storedpagination,
    advancedStoredpagination,
    combineAdnvaceStoredpagination,
    setStoredPagination,
    setAdvancedStoredPagination,
    setCombineAdnvaceStoredpagination,
  } = useAuth();

  const [headers, setHeaders] = useState<string[]>(
    Object.keys(DEFAULT_HEADER_MAP)
  );
  const [headerMap, setHeaderMap] = useState<
    Record<string, [string, number]>
  >(DEFAULT_HEADER_MAP);
  const [visibleColumns, setVisibleColumns] = useState<string[]>(
    Object.keys(DEFAULT_HEADER_MAP)
  );

  const [tableRows, setTableRows] = useState<any[]>([]);
  const [pagination, setPagination] = useState<any>({});
  const [loading, setLoading] = useState(false);

  const [searchTerm, setSearchTerm] = useState("");
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [filteredData, setFilteredData] = useState<any[]>([]);

  // new order modal state
  const [newOrderVisible, setNewOrderVisible] = useState(false);
  const [searchState, setSearchState] = useState("");
  const [searchAreaCode, setSearchAreaCode] = useState("");
  const [searchCity, setSearchCity] = useState("");
  const [searchRateCenter, setSearchRateCenter] = useState("");
  const [searchQuantity, setSearchQuantity] = useState("10");
  const [rateCenters, setRateCenters] = useState<string[]>([]);
  const [availableNumbers, setAvailableNumbers] = useState<string[]>([]);
  const [selectedNumbers, setSelectedNumbers] = useState<string[]>([]);
  const [orderSiteId, setOrderSiteId] = useState("");
  const [orderCustomerId, setOrderCustomerId] = useState("");
  const [searchLoading, setSearchLoading] = useState(false);
  const [orderLoading, setOrderLoading] = useState(false);

  // status check modal
  const [statusModalVisible, setStatusModalVisible] = useState(false);
  const [statusOrderData, setStatusOrderData] = useState<any>(null);
  const [statusLoading, setStatusLoading] = useState(false);

  const hasFetchedData = useRef(false);

  // helper to build request payload
  const buildPayload = (path: string, extra: Record<string, any> = {}) => ({
    path,
    username,
    firstLastName,
    role_name: role,
    parent_module: "LNP",
    module_name: TABLE_NAME,
    feature_module_name: TABLE_NAME,
    request_received_at: getCurrentDateTime(),
    Partner: partner,
    access_token: token,
    db_name: selectedDb,
    ...metaData,
    sessionID: sessionId,
    ...extra,
  });

  // fetch orders list
  const fetchData = useCallback(async () => {
    settabledata([]);
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    setCombineAdnvaceStoredpagination(null);
    setShowAdvanced(false);

    if (!ENV_ROUTES.LNP) return;

    try {
      setLoading(true);
      const data = buildPayload("/lnp_get_number_orders");
      const response = await axios.post(ENV_ROUTES.LNP, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === true) {
        const backendHeaderMap =
          parsedData?.header_map?.[TABLE_NAME]?.header_map || null;

        if (backendHeaderMap) {
          const sortedEntries = Object.entries(
            backendHeaderMap as Record<string, [string, number]>
          ).sort((a, b) => a[1][1] - b[1][1]);
          const sorted = Object.fromEntries(sortedEntries) as Record<
            string,
            [string, number]
          >;
          setHeaderMap(sorted);
          const keys = Object.keys(sorted);
          setHeaders(keys);
          setVisibleColumns(keys);
        }

        setTableRows(parsedData?.orders || []);
        setPagination(parsedData?.pages || {});
      } else {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching orders. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      console.error("Number Orders fetch error:", error);
    } finally {
      setLoading(false);
    }
  }, [
    username,
    firstLastName,
    role,
    partner,
    token,
    selectedDb,
    metaData,
    sessionId,
    settabledata,
    setStoredPagination,
    setAdvancedStoredPagination,
    setCombineAdnvaceStoredpagination,
  ]);

  useEffect(() => {
    if (!hasFetchedData.current) {
      fetchData();
      hasFetchedData.current = true;
    }
  }, [fetchData]);

  const handleFilter = useCallback((filters: any) => {
    setFilteredData(filters);
  }, []);

  const handleReset = useCallback((emptyFilters: any) => {
    setFilteredData(emptyFilters);
  }, []);

  // fetch rate centers when state changes
  const handleStateChange = async (state: string) => {
    setSearchState(state);
    setSearchRateCenter("");
    setRateCenters([]);
    if (!state) return;

    try {
      const data = buildPayload("/lnp_get_rate_centers", { state });
      const response = await axios.post(ENV_ROUTES.LNP, { data });
      const parsed = JSON.parse(response.data.body);
      if (parsed.flag) {
        const centers = (parsed.rate_centers || []).map(
          (rc: any) => (typeof rc === "string" ? rc : rc.name || rc.Name || rc.rateCenter || "")
        );
        setRateCenters(centers.filter(Boolean));
      }
    } catch (err) {
      console.error("Rate centers error:", err);
    }
  };

  // search available numbers
  const handleSearchNumbers = async () => {
    if (!searchState && !searchAreaCode) {
      notification.warning({
        message: "Validation",
        description: "Enter at least a state or area code to search",
        placement: "top",
      });
      return;
    }

    try {
      setSearchLoading(true);
      setAvailableNumbers([]);
      setSelectedNumbers([]);

      const data = buildPayload("/lnp_search_available_numbers", {
        state: searchState,
        area_code: searchAreaCode,
        city: searchCity,
        rate_center: searchRateCenter,
        quantity: searchQuantity,
      });
      const response = await axios.post(ENV_ROUTES.LNP, { data });
      const parsed = JSON.parse(response.data.body);

      if (parsed.flag) {
        setAvailableNumbers(parsed.available_numbers || []);
        if ((parsed.available_numbers || []).length === 0) {
          notification.info({ message: "No numbers found matching your criteria", placement: "top" });
        }
      } else {
        notification.error({ message: "Search Failed", description: parsed.message, placement: "top" });
      }
    } catch (err) {
      console.error("Search error:", err);
      notification.error({ message: "Error", description: "Failed to search numbers", placement: "top" });
    } finally {
      setSearchLoading(false);
    }
  };

  // place order for selected numbers
  const handlePlaceOrder = async () => {
    if (selectedNumbers.length === 0) {
      notification.warning({ message: "Select at least one number", placement: "top" });
      return;
    }
    if (!orderSiteId) {
      notification.warning({ message: "Site ID is required", placement: "top" });
      return;
    }

    try {
      setOrderLoading(true);
      const data = buildPayload("/lnp_create_number_order", {
        phone_numbers: selectedNumbers,
        site_id: orderSiteId,
        customer_order_id: orderCustomerId,
      });
      const response = await axios.post(ENV_ROUTES.LNP, { data });
      const parsed = JSON.parse(response.data.body);

      if (parsed.flag) {
        notification.success({
          message: "Order Placed",
          description: `Order ${parsed.order_id || ""} created for ${selectedNumbers.length} number(s)`,
          placement: "top",
        });
        setNewOrderVisible(false);
        // refresh the orders table
        hasFetchedData.current = false;
        fetchData();
        hasFetchedData.current = true;
      } else {
        notification.error({ message: "Order Failed", description: parsed.message, placement: "top" });
      }
    } catch (err) {
      console.error("Place order error:", err);
      notification.error({ message: "Error", description: "Failed to place order", placement: "top" });
    } finally {
      setOrderLoading(false);
    }
  };

  // check order status from actions dropdown
  const handleCheckStatus = async (row: any) => {
    const orderId = row?.orderId;
    if (!orderId) return;

    try {
      setStatusLoading(true);
      setStatusModalVisible(true);
      setStatusOrderData(null);

      const data = buildPayload("/lnp_get_number_order_status", {
        order_id: orderId,
      });
      const response = await axios.post(ENV_ROUTES.LNP, { data });
      const parsed = JSON.parse(response.data.body);

      if (parsed.flag) {
        setStatusOrderData(parsed);
      } else {
        notification.error({ message: "Status Check Failed", description: parsed.message, placement: "top" });
        setStatusModalVisible(false);
      }
    } catch (err) {
      console.error("Status check error:", err);
      notification.error({ message: "Error", description: "Failed to check order status", placement: "top" });
      setStatusModalVisible(false);
    } finally {
      setStatusLoading(false);
    }
  };

  // handle row action from actions dropdown
  const handleRowAction = (action: string, row: any) => {
    if (action === "checkStatus") {
      handleCheckStatus(row);
    }
  };

  // toggle number selection
  const toggleNumber = (num: string) => {
    setSelectedNumbers((prev) =>
      prev.includes(num) ? prev.filter((n) => n !== num) : [...prev, num]
    );
  };

  // select/deselect all
  const toggleAll = () => {
    if (selectedNumbers.length === availableNumbers.length) {
      setSelectedNumbers([]);
    } else {
      setSelectedNumbers([...availableNumbers]);
    }
  };

  // reset the new order modal
  const openNewOrderModal = () => {
    setSearchState("");
    setSearchAreaCode("");
    setSearchCity("");
    setSearchRateCenter("");
    setSearchQuantity("10");
    setRateCenters([]);
    setAvailableNumbers([]);
    setSelectedNumbers([]);
    setOrderSiteId("");
    setOrderCustomerId("");
    setNewOrderVisible(true);
  };

  if (loading && tableRows.length === 0) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  return (
    <>
      {/* loading overlay */}
      {loading && tableRows.length > 0 && (
        <div className="fixed inset-0 flex justify-center items-center adv-search-loader bg-white bg-opacity-75 z-50 pointer-events-none">
          <Spin size="large" />
        </div>
      )}

      {/* order status modal */}
      <Modal
        title="Order Status"
        open={statusModalVisible}
        onCancel={() => setStatusModalVisible(false)}
        footer={[
          <Button key="close" onClick={() => setStatusModalVisible(false)}>
            Close
          </Button>,
        ]}
        centered
        destroyOnClose
      >
        {statusLoading ? (
          <div className="flex justify-center py-8">
            <Spin size="large" />
          </div>
        ) : statusOrderData ? (
          <div>
            <p><strong>Order ID:</strong> {statusOrderData.order_id}</p>
            <p><strong>Status:</strong> {statusOrderData.status}</p>
            {statusOrderData.order && (
              <div className="mt-4">
                <p className="text-sm text-gray-500">Full order details:</p>
                <pre className="bg-gray-50 p-3 rounded text-xs mt-1 max-h-60 overflow-auto">
                  {JSON.stringify(statusOrderData.order, null, 2)}
                </pre>
              </div>
            )}
          </div>
        ) : null}
      </Modal>

      {/* new order modal */}
      <Modal
        title="New Phone Number Order"
        open={newOrderVisible}
        onCancel={() => setNewOrderVisible(false)}
        footer={null}
        width={700}
        centered
        destroyOnClose
      >
        <div className="p-2">
          {/* search section */}
          <h3 className="text-base font-semibold mb-3">Search Available Numbers</h3>
          <div className="grid grid-cols-2 gap-3 mb-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">State</label>
              <Select
                value={searchState || undefined}
                onChange={handleStateChange}
                placeholder="Select state"
                allowClear
                style={{ width: "100%" }}
                showSearch
                options={US_STATES.map((s) => ({ value: s, label: s }))}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Area Code</label>
              <Input
                value={searchAreaCode}
                onChange={(e) => setSearchAreaCode(e.target.value)}
                placeholder="e.g. 919"
                maxLength={3}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">City</label>
              <Input
                value={searchCity}
                onChange={(e) => setSearchCity(e.target.value)}
                placeholder="Optional"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Rate Center</label>
              <Select
                value={searchRateCenter || undefined}
                onChange={setSearchRateCenter}
                placeholder="Select rate center"
                allowClear
                style={{ width: "100%" }}
                showSearch
                options={rateCenters.map((rc) => ({ value: rc, label: rc }))}
                disabled={rateCenters.length === 0}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Quantity</label>
              <Input
                value={searchQuantity}
                onChange={(e) => setSearchQuantity(e.target.value)}
                placeholder="10"
                type="number"
              />
            </div>
            <div className="flex items-end">
              <Button
                type="primary"
                onClick={handleSearchNumbers}
                loading={searchLoading}
                className="w-full"
              >
                Search
              </Button>
            </div>
          </div>

          {/* results section */}
          {availableNumbers.length > 0 && (
            <>
              <hr className="border-gray-200 my-4" />
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-base font-semibold">
                  Available Numbers ({availableNumbers.length})
                </h3>
                <Button size="small" onClick={toggleAll}>
                  {selectedNumbers.length === availableNumbers.length
                    ? "Deselect All"
                    : "Select All"}
                </Button>
              </div>
              <div className="max-h-48 overflow-auto border border-gray-200 rounded p-2 mb-4">
                {availableNumbers.map((num) => (
                  <div key={num} className="flex items-center py-1">
                    <Checkbox
                      checked={selectedNumbers.includes(num)}
                      onChange={() => toggleNumber(num)}
                    >
                      {num}
                    </Checkbox>
                  </div>
                ))}
              </div>

              {/* order fields */}
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Site ID <span className="text-red-500">*</span>
                  </label>
                  <Input
                    value={orderSiteId}
                    onChange={(e) => setOrderSiteId(e.target.value)}
                    placeholder="Enter Site ID"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Customer Order ID
                  </label>
                  <Input
                    value={orderCustomerId}
                    onChange={(e) => setOrderCustomerId(e.target.value)}
                    placeholder="Optional reference"
                  />
                </div>
              </div>

              <div className="flex justify-end">
                <Button
                  type="primary"
                  onClick={handlePlaceOrder}
                  loading={orderLoading}
                  disabled={selectedNumbers.length === 0 || !orderSiteId}
                >
                  Place Order ({selectedNumbers.length} number
                  {selectedNumbers.length !== 1 ? "s" : ""})
                </Button>
              </div>
            </>
          )}
        </div>
      </Modal>

      <div className="relative">
        {/* toolbar */}
        <div className="pr-4 pl-4 pt-2 flex md:flex-row md:items-center md:justify-between mt-1 mb-4 space-y-4">
          {/* left: search and advanced filter */}
          <div className="flex space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last">
            <Suspense fallback={null}>
              <TableSearch
                searchTerm={searchTerm}
                setSearchTerm={setSearchTerm}
                tableName={TABLE_NAME}
                headerMap={headerMap}
              />
              <AdvancedMultiFilter
                showAdvanced={showAdvanced}
                setShowAdvanced={setShowAdvanced}
                onFilter={handleFilter}
                onReset={handleReset}
                headers={headers}
                headerMap={headerMap}
                tableName={TABLE_NAME}
              />
            </Suspense>
          </div>

          {/* right: new order button and column filter */}
          <div className="hidden md:flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-first pb-2 md:pb-4">
            <button className="save-btn" onClick={openNewOrderModal}>
              <span>New Order</span>
            </button>
            <Suspense fallback={null}>
              <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
              />
            </Suspense>
          </div>
        </div>

        {/* shared table component */}
        <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
          <Suspense fallback={<Spin size="large" />}>
            <TableComponent
              headers={headers}
              headerMap={headerMap}
              initialData={tableRows}
              searchQuery={searchTerm}
              visibleColumns={visibleColumns}
              itemsPerPage={ITEMS_PER_PAGE}
              allowedActions={["lnpActions"]}
              onRowAction={handleRowAction}
              popupHeading={TABLE_NAME}
              pagination={pagination}
              advancedFilters={filteredData}
              height={showAdvanced ? 330 : 280}
            />
          </Suspense>
        </div>

        {/* sticky footer - mobile only */}
        <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
          <button className="save-btn" onClick={openNewOrderModal}>
            New Order
          </button>
          <Suspense fallback={null}>
            <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
            />
          </Suspense>
        </div>
      </div>
    </>
  );
};

export default NumberOrders;
