"use client";

import React, {
  useCallback,
  useEffect,
  useRef,
  useState,
  lazy,
  Suspense,
} from "react";
import { ArrowDownTrayIcon } from "@heroicons/react/24/outline";
import { Modal, Spin, notification, Input, Button, Select } from "antd";
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
const TableComponent = lazy(
  () => import("@/app/components/TableComponent/page")
);
const TableSearch = lazy(() => import("@/app/components/entire_table_search"));
const AdvancedMultiFilter = lazy(
  () => import("@/app/components/advanced_search")
);
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));

// default header map used until the backend provides its own
const DEFAULT_HEADER_MAP: Record<string, [string, number]> = {
  vendorName:    ["Service Provider", 0],
  accountId:     ["Account", 1],
  phoneNumber:   ["Phone Number", 2],
  city:          ["City", 3],
  state:         ["State", 4],
  lata:          ["LATA", 5],
  rateCenter:    ["Rate Center", 6],
  status:        ["Status", 7],
};

const TABLE_NAME = "LNP";
const ITEMS_PER_PAGE = 100;

const PhoneNumbers: React.FC = () => {
  const {
    username,
    partner,
    role,
    token,
    selectedDb,
    metaData,
    sessionId,
    firstLastName,
    settabledata,
    tabledata,
    storedpagination,
    advancedStoredpagination,
    combineAdnvaceStoredpagination,
    setStoredPagination,
    setAdvancedStoredPagination,
    setCombineAdnvaceStoredpagination,
    tenantProviderMap,
  } = useAuth();

  const isAdmin =
    role?.toLowerCase() === "super admin" ||
    role?.toLowerCase() === "partner admin";

  const serviceProviderKeys =
    !isAdmin && tenantProviderMap ? Object.keys(tenantProviderMap) : [];

  const {
    addExport,
    removeExport,
    exports: activeExports,
  } = exportLoadingStore();

  const [headers, setHeaders] = useState<string[]>(
    Object.keys(DEFAULT_HEADER_MAP)
  );
  const [headerMap, setHeaderMap] = useState<
    Record<string, [string, number]>
  >(DEFAULT_HEADER_MAP);
  const [visibleColumns, setVisibleColumns] = useState<string[]>(
    Object.keys(DEFAULT_HEADER_MAP)
  );

  const [tableRows, setTableRows] = useState<any[]>([]);
  const [pagination, setPagination] = useState<any>({});
  const [loading, setLoading] = useState(false);

  const [searchTerm, setSearchTerm] = useState("");
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [filteredData, setFilteredData] = useState<any[]>([]);

  // update options modal state
  const [updateOptionsVisible, setUpdateOptionsVisible] = useState(false);
  const [updateOptionsRow, setUpdateOptionsRow] = useState<any>(null);

  // move phone number modal state
  const [moveModalVisible, setMoveModalVisible] = useState(false);
  const [moveRow, setMoveRow] = useState<any>(null);
  const [moveSiteId, setMoveSiteId] = useState("");
  const [moveSipPeerId, setMoveSipPeerId] = useState("");
  const [actionLoading, setActionLoading] = useState(false);

  // line options form state
  const [callingNameDisplay, setCallingNameDisplay] = useState("on");
  const [callForwardNumber, setCallForwardNumber] = useState("");
  const [customUri, setCustomUri] = useState("");

  // sms settings form state
  const [smsStatus, setSmsStatus] = useState("Enabled");

  // lidb form state
  const [lidbServiceType, setLibdServiceType] = useState("Business");
  const [lidbDisplay, setLibdDisplay] = useState("Allowed");
  const [lidbName, setLibdName] = useState("");

  const hasFetchedData = useRef(false);

  // initial data fetch
  const fetchData = useCallback(async () => {
    settabledata([]);
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    setCombineAdnvaceStoredpagination(null);
    setShowAdvanced(false);

    if (!ENV_ROUTES.LNP) return;

    try {
      setLoading(true);
      const data = {
        path: "/lnp_phone_numbers_list_view",
        username,
        firstLastName,
        role_name: role,
        parent_module: "LNP",
        module_name: TABLE_NAME,
        feature_module_name: TABLE_NAME,
        mod_pages: { start: 0, end: ITEMS_PER_PAGE },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        ...(serviceProviderKeys.length === 1
          ? { service_provider: serviceProviderKeys[0] }
          : serviceProviderKeys.length > 1
          ? { service_providers: serviceProviderKeys }
          : {}),
      };

      const response = await axios.post(ENV_ROUTES.LNP, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === true) {
        const backendHeaderMap =
          parsedData?.header_map?.[TABLE_NAME]?.header_map || null;

        if (backendHeaderMap) {
          const sortedEntries = Object.entries(
            backendHeaderMap as Record<string, [string, number]>
          ).sort((a, b) => a[1][1] - b[1][1]);
          const sorted = Object.fromEntries(sortedEntries) as Record<
            string,
            [string, number]
          >;
          setHeaderMap(sorted);
          const keys = Object.keys(sorted);
          setHeaders(keys);
          setVisibleColumns(keys);
        }

        setTableRows(parsedData?.phone_numbers || parsedData?.data || []);
        setPagination(parsedData?.pages || {});
      } else {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      console.error("LNP fetch error:", error);
    } finally {
      setLoading(false);
    }
  }, [
    username,
    firstLastName,
    role,
    partner,
    token,
    selectedDb,
    metaData,
    sessionId,
    settabledata,
    setStoredPagination,
    setAdvancedStoredPagination,
    setCombineAdnvaceStoredpagination,
    tenantProviderMap,
  ]);

  useEffect(() => {
    if (!hasFetchedData.current) {
      fetchData();
      hasFetchedData.current = true;
    }
  }, [fetchData]);

  const handleFilter = useCallback((filters: any) => {
    setFilteredData(filters);
  }, []);

  const handleReset = useCallback((emptyFilters: any) => {
    setFilteredData(emptyFilters);
  }, []);

  const handleExport = async () => {
    if (activeExports.some((e) => e.popupHeading === "LNP")) return;

    if (!ENV_ROUTES.LNP) {
      Modal.info({
        title: "Export Unavailable",
        content: "The LNP backend is not configured yet.",
        centered: true,
      });
      return;
    }

    try {
      addExport("LNP", "LNP");

      const data = {
        path: "/lnp_phone_numbers_export",
        username,
        firstLastName,
        role_name: role,
        parent_module: "LNP",
        module_name: TABLE_NAME,
        feature_module_name: TABLE_NAME,
        filter: searchTerm,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        ...(serviceProviderKeys.length === 1
          ? { service_provider: serviceProviderKeys[0] }
          : serviceProviderKeys.length > 1
          ? { service_providers: serviceProviderKeys }
          : {}),
      };

      const response = await axios.post(ENV_ROUTES.LNP, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        throw new Error(parsedData.message || "Export failed");
      }

      // Generate Excel file client-side from the returned data
      const rows = parsedData?.phone_numbers || [];
      if (rows.length === 0) {
        notification.info({ message: "No data to export", placement: "top" });
        return;
      }

      // Build CSV and download as .xlsx-compatible file
      const exportHeaders = Object.values(headerMap).map((v) => v[0]);
      const exportKeys = Object.keys(headerMap);
      const csvContent = [
        exportHeaders.join(","),
        ...rows.map((row: any) =>
          exportKeys.map((k) => `"${(row[k] ?? "").toString().replace(/"/g, '""')}"`).join(",")
        ),
      ].join("\n");

      const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
      const link = document.createElement("a");
      link.href = URL.createObjectURL(blob);
      link.download = "PhoneNumbers.csv";
      link.click();
      URL.revokeObjectURL(link.href);

      notification.success({
        message: "Success",
        description: "Successfully exported the record!",
        placement: "top",
      });
    } catch (error) {
      console.error("LNP export error:", error);
      Modal.error({
        title: "Export Error",
        content:
          error instanceof Error
            ? error.message
            : "An error occurred while exporting. Please try again.",
        centered: true,
      });
    } finally {
      removeExport("LNP");
    }
  };

  // open the update options modal and reset form fields
  const openUpdateOptionsModal = (row: any) => {
    setUpdateOptionsRow(row);
    setCallingNameDisplay("on");
    setCallForwardNumber("");
    setCustomUri("");
    setSmsStatus("Enabled");
    setLibdServiceType("Business");
    setLibdDisplay("Allowed");
    setLibdName("");
    setUpdateOptionsVisible(true);
  };

  // format phone number for display e.g. +12025551234 -> (202) 555-1234
  const formatPhoneDisplay = (phone: string): string => {
    if (!phone) return "";
    const digits = phone.replace(/\D/g, "");
    if (digits.length === 11 && digits.startsWith("1")) {
      return `(${digits.slice(1, 4)}) ${digits.slice(4, 7)}-${digits.slice(7)}`;
    }
    if (digits.length === 10) {
      return `(${digits.slice(0, 3)}) ${digits.slice(3, 6)}-${digits.slice(6)}`;
    }
    return phone;
  };

  // helper to build the common request payload for LNP actions
  const buildActionPayload = (path: string, extra: Record<string, any> = {}) => ({
    path,
    username,
    firstLastName,
    role_name: role,
    parent_module: "LNP",
    module_name: TABLE_NAME,
    feature_module_name: TABLE_NAME,
    request_received_at: getCurrentDateTime(),
    Partner: partner,
    access_token: token,
    db_name: selectedDb,
    ...metaData,
    sessionID: sessionId,
    ...extra,
  });

  // submit handlers for each section inside the update options modal
  const handleCreateDlda = async () => {
    const phoneNumber = updateOptionsRow?.phoneNumber || "";
    if (!phoneNumber) return;
    try {
      setActionLoading(true);
      const data = buildActionPayload("/lnp_create_dlda_order", {
        phone_number: phoneNumber,
      });
      const response = await axios.post(ENV_ROUTES.LNP, { data });
      const parsed = JSON.parse(response.data.body);
      if (parsed.flag) {
        notification.success({ message: "DL/DA Order", description: parsed.message, placement: "top" });
      } else {
        notification.error({ message: "DL/DA Order Failed", description: parsed.message, placement: "top" });
      }
    } catch (err) {
      console.error("DL/DA error:", err);
      notification.error({ message: "Error", description: "Failed to create DL/DA order", placement: "top" });
    } finally {
      setActionLoading(false);
    }
  };

  const handleUpdateLidb = async () => {
    const phoneNumber = updateOptionsRow?.phoneNumber || "";
    if (!phoneNumber || !lidbName) {
      notification.warning({ message: "Validation", description: "Phone number and name are required", placement: "top" });
      return;
    }
    try {
      setActionLoading(true);
      const data = buildActionPayload("/lnp_update_lidb", {
        phone_number: phoneNumber,
        subscriber_name: lidbName,
        service_type: lidbServiceType,
        display: lidbDisplay,
      });
      const response = await axios.post(ENV_ROUTES.LNP, { data });
      const parsed = JSON.parse(response.data.body);
      if (parsed.flag) {
        notification.success({ message: "LIDB Update", description: parsed.message, placement: "top" });
      } else {
        notification.error({ message: "LIDB Update Failed", description: parsed.message, placement: "top" });
      }
    } catch (err) {
      console.error("LIDB error:", err);
      notification.error({ message: "Error", description: "Failed to update LIDB", placement: "top" });
    } finally {
      setActionLoading(false);
    }
  };

  const handleUpdateLineOptions = async () => {
    const phoneNumber = updateOptionsRow?.phoneNumber || "";
    if (!phoneNumber) return;
    try {
      setActionLoading(true);
      const data = buildActionPayload("/lnp_update_line_options", {
        phone_number: phoneNumber,
        calling_name_display: callingNameDisplay,
        call_forward_number: callForwardNumber,
      });
      const response = await axios.post(ENV_ROUTES.LNP, { data });
      const parsed = JSON.parse(response.data.body);
      if (parsed.flag) {
        notification.success({ message: "Line Options", description: parsed.message, placement: "top" });
      } else {
        notification.error({ message: "Line Options Failed", description: parsed.message, placement: "top" });
      }
    } catch (err) {
      console.error("Line options error:", err);
      notification.error({ message: "Error", description: "Failed to update line options", placement: "top" });
    } finally {
      setActionLoading(false);
    }
  };

  const handleUpdateSms = async () => {
    const phoneNumber = updateOptionsRow?.phoneNumber || "";
    if (!phoneNumber) return;
    try {
      setActionLoading(true);
      const data = buildActionPayload("/lnp_update_sms_settings", {
        phone_number: phoneNumber,
        sms_enabled: smsStatus === "Enabled",
      });
      const response = await axios.post(ENV_ROUTES.LNP, { data });
      const parsed = JSON.parse(response.data.body);
      if (parsed.flag) {
        notification.success({ message: "SMS Settings", description: parsed.message, placement: "top" });
      } else {
        notification.error({ message: "SMS Settings Failed", description: parsed.message, placement: "top" });
      }
    } catch (err) {
      console.error("SMS error:", err);
      notification.error({ message: "Error", description: "Failed to update SMS settings", placement: "top" });
    } finally {
      setActionLoading(false);
    }
  };

  // move phone number handler
  const handleMovePhoneNumber = async () => {
    const phoneNumber = moveRow?.phoneNumber || "";
    if (!phoneNumber || !moveSiteId || !moveSipPeerId) {
      notification.warning({ message: "Validation", description: "Phone number, Site ID, and SIP Peer ID are required", placement: "top" });
      return;
    }
    try {
      setActionLoading(true);
      const data = buildActionPayload("/lnp_move_phone_number", {
        phone_number: phoneNumber,
        site_id: moveSiteId,
        sip_peer_id: moveSipPeerId,
      });
      const response = await axios.post(ENV_ROUTES.LNP, { data });
      const parsed = JSON.parse(response.data.body);
      if (parsed.flag) {
        notification.success({ message: "Move Phone Number", description: parsed.message, placement: "top" });
        setMoveModalVisible(false);
      } else {
        notification.error({ message: "Move Failed", description: parsed.message, placement: "top" });
      }
    } catch (err) {
      console.error("Move error:", err);
      notification.error({ message: "Error", description: "Failed to move phone number", placement: "top" });
    } finally {
      setActionLoading(false);
    }
  };

  // handle action dropdown click from the table row
  const handleRowAction = (action: string, row: any) => {
    if (action === "move") {
      setMoveRow(row);
      setMoveSiteId("");
      setMoveSipPeerId("");
      setMoveModalVisible(true);
    } else {
      openUpdateOptionsModal(row);
    }
  };

  if (loading && tableRows.length === 0) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  return (
    <>
      {/* loading overlay */}
      {loading && tableRows.length > 0 && (
        <div className="fixed inset-0 flex justify-center items-center adv-search-loader bg-white bg-opacity-75 z-50 pointer-events-none">
          <Spin size="large" />
        </div>
      )}

      {/* update options modal */}
      <Modal
        title={null}
        open={updateOptionsVisible}
        onCancel={() => setUpdateOptionsVisible(false)}
        footer={null}
        width={700}
        centered
        destroyOnClose
      >
        {updateOptionsRow && (
          <div className="p-2">
            <h2 className="text-2xl font-semibold mb-6">
              {formatPhoneDisplay(updateOptionsRow.phoneNumber)}
            </h2>

            {/* directory listing / directory assistance section */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-lg font-semibold" style={{ color: "#000" }}>
                  Directory Listing/Directory Assistance (DL/DA)
                </h3>
                <Button
                  type="default"
                  onClick={handleCreateDlda}
                  loading={actionLoading}
                  style={{ borderColor: "#d1d5db", color: "#000" }}
                >
                  Create DL/DA Order
                </Button>
              </div>
              <hr className="border-gray-200 mb-2" />
            </div>

            {/* outbound calling name (LIDB) section */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-lg font-semibold" style={{ color: "#000" }}>
                  Outbound Calling Name (LIDB) Information
                </h3>
                <Button
                  type="default"
                  onClick={handleUpdateLidb}
                  loading={actionLoading}
                  style={{ borderColor: "#d1d5db", color: "#000" }}
                >
                  Update LIDB Order
                </Button>
              </div>
              <hr className="border-gray-200 mb-3" />
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Service Type</label>
                  <Select
                    value={lidbServiceType}
                    onChange={setLibdServiceType}
                    style={{ width: "100%" }}
                    options={[
                      { value: "Business", label: "Business" },
                      { value: "Residential", label: "Residential" },
                    ]}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Display</label>
                  <Select
                    value={lidbDisplay}
                    onChange={setLibdDisplay}
                    style={{ width: "100%" }}
                    options={[
                      { value: "Allowed", label: "Allowed" },
                      { value: "Restricted", label: "Restricted" },
                    ]}
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Name</label>
                  <Input
                    value={lidbName}
                    onChange={(e) => setLibdName(e.target.value)}
                    placeholder="Company Name"
                  />
                </div>
              </div>
            </div>

            {/* line options section */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-lg font-semibold" style={{ color: "#000" }}>
                  Line Options
                </h3>
                <Button
                  type="default"
                  onClick={handleUpdateLineOptions}
                  loading={actionLoading}
                  style={{ borderColor: "#d1d5db", color: "#000" }}
                >
                  Update Line Options
                </Button>
              </div>
              <hr className="border-gray-200 mb-3" />
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Calling Name Display</label>
                  <Select
                    value={callingNameDisplay}
                    onChange={setCallingNameDisplay}
                    style={{ width: "100%" }}
                    options={[
                      { value: "on", label: "On" },
                      { value: "off", label: "Off" },
                    ]}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Call Forward Number</label>
                  <Input
                    value={callForwardNumber}
                    onChange={(e) => setCallForwardNumber(e.target.value)}
                    placeholder="Enter forwarding number"
                  />
                </div>
                <div className="col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Custom URI</label>
                  <Input
                    value={customUri}
                    onChange={(e) => setCustomUri(e.target.value)}
                    placeholder="Enter custom URI"
                  />
                </div>
              </div>
            </div>

            {/* sms settings section */}
            <div className="mb-2">
              <div className="flex items-center justify-between mb-2">
                <h3 className="text-lg font-semibold" style={{ color: "#000" }}>
                  SMS Settings
                </h3>
                <Button
                  type="default"
                  onClick={handleUpdateSms}
                  loading={actionLoading}
                  style={{ borderColor: "#d1d5db", color: "#000" }}
                >
                  Update SMS Settings
                </Button>
              </div>
              <hr className="border-gray-200 mb-3" />
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">SMS Status</label>
                <Select
                  value={smsStatus}
                  onChange={setSmsStatus}
                  style={{ width: "100%", maxWidth: 300 }}
                  options={[
                    { value: "Enabled", label: "Enabled" },
                    { value: "Disabled", label: "Disabled" },
                  ]}
                />
              </div>
            </div>
          </div>
        )}
      </Modal>

      {/* move phone number modal */}
      <Modal
        title="Move Phone Number"
        open={moveModalVisible}
        onCancel={() => setMoveModalVisible(false)}
        onOk={handleMovePhoneNumber}
        okText="Move"
        okButtonProps={{ loading: actionLoading }}
        centered
        destroyOnClose
      >
        {moveRow && (
          <div className="p-2">
            <p className="mb-4 text-base">
              Moving: <strong>{formatPhoneDisplay(moveRow.phoneNumber)}</strong>
            </p>
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Site ID</label>
              <Input
                value={moveSiteId}
                onChange={(e) => setMoveSiteId(e.target.value)}
                placeholder="Enter destination Site ID"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">SIP Peer ID (Location)</label>
              <Input
                value={moveSipPeerId}
                onChange={(e) => setMoveSipPeerId(e.target.value)}
                placeholder="Enter destination SIP Peer ID"
              />
            </div>
          </div>
        )}
      </Modal>

      <div className="relative">
        {/* toolbar */}
        <div className="pr-4 pl-4 pt-2 flex md:flex-row md:items-center md:justify-between mt-1 mb-4 space-y-4">
          {/* left: search and advanced filter */}
          <div className="flex space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last">
            <Suspense fallback={null}>
              <TableSearch
                searchTerm={searchTerm}
                setSearchTerm={setSearchTerm}
                tableName={TABLE_NAME}
                headerMap={headerMap}
              />
              <AdvancedMultiFilter
                showAdvanced={showAdvanced}
                setShowAdvanced={setShowAdvanced}
                onFilter={handleFilter}
                onReset={handleReset}
                headers={headers}
                headerMap={headerMap}
                tableName={TABLE_NAME}
              />
            </Suspense>
          </div>

          {/* right: export and column filter */}
          <div className="hidden md:flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-first pb-2 md:pb-4">
            <button className="save-btn" onClick={handleExport}>
              <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
              <span>Export</span>
            </button>
            <Suspense fallback={null}>
              <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
              />
            </Suspense>
          </div>
        </div>

        {/* shared table component */}
        <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
          <Suspense fallback={<Spin size="large" />}>
            <TableComponent
              headers={headers}
              headerMap={headerMap}
              initialData={tableRows}
              searchQuery={searchTerm}
              visibleColumns={visibleColumns}
              itemsPerPage={ITEMS_PER_PAGE}
              allowedActions={["lnpActions"]}
              onRowAction={handleRowAction}
              popupHeading={TABLE_NAME}
              pagination={pagination}
              advancedFilters={filteredData}
              height={showAdvanced ? 330 : 280}
            />
          </Suspense>
        </div>

        {/* sticky footer - mobile only */}
        <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
          <button className="save-btn" onClick={handleExport}>
            <ArrowDownTrayIcon className="h-5 w-5 text-black-500" />
          </button>
          <Suspense fallback={null}>
            <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
            />
          </Suspense>
        </div>
      </div>
    </>
  );
};

export default PhoneNumbers;
