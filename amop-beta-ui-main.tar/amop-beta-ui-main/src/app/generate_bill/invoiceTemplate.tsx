"use client";
import { useEffect, useRef, useState } from "react";
import { useItemStore } from "../stores/useItemStore";
import { Modal } from "antd";
import { PDFDownloadLink } from "@react-pdf/renderer";
import InvoicePDF from "./invocePdf";
import { pdf } from "@react-pdf/renderer";
import { saveAs } from "file-saver";

  
  interface InvoiceTemplateProps {
    invoiceData: any;
    downloadPDF: boolean;
    isOpen: boolean;
    isClose: boolean;
    onClose: () => void;
  }
  
  const InvoiceTemplate = ({ invoiceData, downloadPDF, isOpen, isClose, onClose }: InvoiceTemplateProps) => {
  const { items, setItems, loadItems } = useItemStore();
  const [Open, setIsOpen] = useState(true);
  const invoiceRef = useRef<HTMLDivElement>(null);
  
  // PDF Download Function
  // PDF Download Function
  const downloadPdfDocument = async () => {
    if (!invoiceData) return;
    
    try {
      // Generate PDF blob
      const blob = await pdf(<InvoicePDF invoiceData={invoiceData} />).toBlob();
      
      // Save the blob as a file using FileSaver.js
      saveAs(blob, `Bill_${invoiceData?.bill_id || 'document'}.pdf`);
      
      // Optionally close the modal after download
      if (onClose) {
        onClose();
      }
    } catch (error) {
      console.error("Error generating PDF:", error);
    }
  };


  useEffect(() => {
    console.log("useEffect template called");
    
    const savedItems = loadItems();
    if (savedItems.length > 0) {
      setItems(savedItems);
      return;
    }

    const formattedItems = [];

    // Header with Logo and Billing Info
    formattedItems.push({
      id: "Header",
      content: (
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px', borderBottom: '1px solid #000' }}>
          <div>
            <img src="/path/to/logo.png" alt="Logo" style={{ height: '50px' }} />
          </div>
          <div style={{ border: '1px solid #000', padding: '10px', textAlign: 'right' }}>
            <div style={{ color: 'black' }}>Bill Date: {invoiceData?.billDate}</div>
            <div style={{ fontWeight: 'bold' }}>Due: {invoiceData?.dueDate}</div>
            <div style={{ fontWeight: 'bold' }}>Total: ${invoiceData?.totalAmount}</div>
            <div style={{ color: 'gray' }}>Bill#: {invoiceData?.bill_id}</div>
            <div style={{ color: 'gray' }}>Customer#: {invoiceData?.customer_id}</div>
          </div>
        </div>
      ),
      type: "text",
    });

    // Addresses
    formattedItems.push({
      id: "Addresses",
      content: (
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px' }}>
          <div>
            <strong>Bill To:</strong>
            <div>{invoiceData?.billTo || "N/A"}</div>
          </div>
          <div>
            <strong>Remit To:</strong>
            <div>{invoiceData?.remitTo || "N/A"}</div>
          </div>
        </div>
      ),
      type: "text",
    });

    // Summary Section
    formattedItems.push({
      id: "Summary",
      content: (
        <div style={{ padding: '10px' }}>
          <h3 style={{ fontWeight: 'bold' }}>Summary</h3>
          <hr />
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <div>Payments Received:</div>
            <div>${invoiceData?.summary?.paymentsReceived || 0}</div>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <div>Recurring Charges:</div>
            <div>${invoiceData?.summary?.["Reccurring Charges"] || 0}</div>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <div>Non-Recurring Charges:</div>
            <div>${invoiceData?.summary?.["Non-Reccurring Charges"] || 0}</div>
          </div>
          <div style={{ display: 'flex', justifyContent: 'space-between' }}>
            <div>Total Amount Due:</div>
            <div>${invoiceData?.summary?.["Total Amount Due"] || 0}</div>
          </div>
          <hr />
        </div>
      ),
      type: "text",
    });

    // Payments Section
    const payments = invoiceData?.items?.find((item: { heading: string; }) => item.heading === "Payments");
    if (payments) {
      formattedItems.push({
        id: "Payments",
        content: (
          <div style={{ padding: '10px' }}>
            <h3 style={{ fontWeight: 'bold' }}>Payments</h3>
            <hr />
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr>
                  {Object.values(payments.table_headers || {}).map((header, index) => (
                    <th key={index} style={{ padding: '5px' }}>{header as string}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {payments.table_rowData?.map((row: any, rowIndex: number) => (
                  <tr key={rowIndex}>
                    <td style={{ padding: '5px' }}>{row.description}</td>
                    <td style={{ padding: '5px' }}>{row.date}</td>
                    <td style={{ padding: '5px' }}>${row.amt}</td>
                  </tr>
                )) || <tr><td colSpan={3}>No payments found</td></tr>}
              </tbody>
            </table>
            <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px' }}>
              <div>Subtotal:</div>
              <div>${payments.sub_total || 0}</div>
            </div>
            <hr />
          </div>
        ),
        type: "text",
      });
    }

    // Recurring Charges Section
    const recurringCharges = invoiceData?.items?.find((item: { heading: string; }) => item.heading === "Recurring Charges");
    if (recurringCharges) {
      formattedItems.push({
        id: "RecurringCharges",
        content: (
          <div style={{ padding: '10px' }}>
            <h3 style={{ fontWeight: 'bold' }}>Recurring Charges</h3>
            <hr />
            <div>MSISDN / Phone #: {recurringCharges.msisdn_phone || "N/A"} SIM #/ ICCID: {recurringCharges.sim_iccid || "N/A"}</div>
            <div>{recurringCharges.recurring_charges_address || "N/A"}</div>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr>
                  {Object.values(recurringCharges.table_headers || {}).map((header, index) => (
                    <th key={index} style={{ padding: '5px' }}>{header as string}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {recurringCharges.table_rowData?.map((row: any, rowIndex: number) => (
                  <tr key={rowIndex}>
                    <td style={{ padding: '5px' }}>{row.description}</td>
                    <td style={{ padding: '5px' }}>{row.start || "N/A"}</td>
                    <td style={{ padding: '5px' }}>{row.end || "N/A"}</td>
                    <td style={{ padding: '5px' }}>${row.amt}</td>
                  </tr>
                )) || <tr><td colSpan={4}>No recurring charges found</td></tr>}
              </tbody>
            </table>
            <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px' }}>
              <div>Subtotal:</div>
              <div>${recurringCharges.sub_total || 0}</div>
            </div>
            <hr />
          </div>
        ),
        type: "text",
      });
    }

    // Non-Recurring Charges Section
    const nonRecurringCharges = invoiceData?.items?.find((item: { heading: string }) => item.heading === "Non Recurring Charges");
    if (nonRecurringCharges) {
      formattedItems.push({
        id: "NonRecurringCharges",
        content: (
          <div style={{ padding: '10px' }}>
            <h3 style={{ fontWeight: 'bold' }}>Non Recurring Charges</h3>
            <hr />
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr>
                  {Object.values(nonRecurringCharges.table_headers || {}).map((header, index) => (
                    <th key={index} style={{ padding: '5px' }}>{header as string}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {nonRecurringCharges.table_rowData?.map((row: any, rowIndex: number) => (
                  <tr key={rowIndex}>
                    <td style={{ padding: '5px' }}>{row.description}</td>
                    <td style={{ padding: '5px' }}>{row.start || "N/A"}</td>
                    <td style={{ padding: '5px' }}>{row.end || "N/A"}</td>
                    <td style={{ padding: '5px' }}>${row.amt}</td>
                  </tr>
                )) || <tr><td colSpan={4}>No non-recurring charges found</td></tr>}
              </tbody>
            </table>
            <div style={{ display: 'flex', justifyContent: 'space-between', padding: '10px' }}>
              <div>Subtotal:</div>
              <div>${nonRecurringCharges.sub_total || 0}</div>
            </div>
            <hr />
          </div>
        ),
        type: "text",
      });
    }

    // Taxes and Surcharges Section
    const taxesAndSurcharges = invoiceData?.items?.find((item: { heading: string }) => item.heading === "Taxes and Surcharges");
    if (taxesAndSurcharges) {
      formattedItems.push({
        id: "TaxesAndSurcharges",
        content: (
          <div style={{ padding: '10px' }}>
            <h3 style={{ fontWeight: 'bold' }}>Taxes and Surcharges</h3>
            <hr />
            {Object.entries(taxesAndSurcharges.taxes_dict || {}).map(([key, value], index) => (
              <div key={index} style={{ display: 'flex', justifyContent: 'space-between' }}>
                <div>{key}:</div>
                <div>${value as string}</div>
              </div>
            )) || <div>No taxes and surcharges found</div>}
            <hr />
          </div>
        ),
        type: "text",
      });
    }

    // Management Reports Section
    const managementReports = invoiceData?.items?.find((item: { heading: string }) => item.heading === "Management Reports");
    if (managementReports) {
      formattedItems.push({
        id: "ManagementReports",
        content: (
          <div style={{ padding: '10px' }}>
            <h3 style={{ fontWeight: 'bold' }}>Management Reports</h3>
            <hr />
            <div><strong>{managementReports.sub_heading || "N/A"}</strong></div>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr>
                  {Object.values(managementReports.table_headers || {}).map((header, index) => (
                    <th key={index} style={{ padding: '5px' }}>{header as string}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {managementReports.table_rowData?.map((row: any, rowIndex: number) => (
                  <tr key={rowIndex}>
                    <td style={{ padding: '5px' }}>{row.acct}</td>
                    <td style={{ padding: '5px' }}>${row.mrc || 0}</td>
                    <td style={{ padding: '5px' }}>${row.nrc || 0}</td>
                    <td style={{ padding: '5px' }}>${row.usage || 0}</td>
                    <td style={{ padding: '5px' }}>${row.cred || 0}</td>
                    <td style={{ padding: '5px' }}>${row.tax || 0}</td>
                  </tr>
                )) || <tr><td colSpan={6}>No management reports found</td></tr>}
                {/* Total Row */}
                <tr>
                  <td style={{ padding: '5px' }}></td>
                  <td style={{ padding: '5px' }}>${managementReports.total_mrc || 0}</td>
                  <td style={{ padding: '5px' }}>${managementReports.total_nrc || 0}</td>
                  <td style={{ padding: '5px' }}>${managementReports.total_usage || 0}</td>
                  <td style={{ padding: '5px' }}>${managementReports.total_cred || 0}</td>
                  <td style={{ padding: '5px' }}>${managementReports.total_tax || 0}</td>
                </tr>
              </tbody>
            </table>
            <hr />
          </div>
        ),
        type: "text",
      });
    }

    // Contact Information
    formattedItems.push({
      id: "ContactInfo",
      content: (
        <div style={{ padding: '10px', border: '1px solid #000' }}>
          --For billing questions, please contact us at <a href={`tel:${invoiceData?.constact_number || ""}`}>{invoiceData?.contact_number || "N/A"}</a> or email us at <a href={`mailto:${invoiceData?.contact_email || ""}`}>{invoiceData?.contact_email || "N/A"}</a>.
        </div>
      ),
      type: "text",
    });

    // Set items to the state
    setItems(formattedItems);
    // Trigger automatic download if downloadPDF is true
    if (downloadPDF) {
      downloadPdfDocument();
    }
    
  }, [invoiceData]);
  const handleCancel = () => {
    setIsOpen(isClose);
    if (onClose) {
      onClose();
    }
  };
// This determines whether to show the modal or not
const showModal = isOpen && !downloadPDF;
  return (
    <>
      {showModal ? (
        <Modal
          open={showModal}
          closable={true}
          onCancel={handleCancel}
          footer={null}
        >
          <div>
            {/* Invoice Template */}
            <div 
              id="invoice-template" 
              ref={invoiceRef}
              style={{ 
                padding: '40px', 
                border: '1px solid #000', 
                backgroundColor: 'white'
              }}
            >
              {/* Render the invoice content here */}
              {items.map(item => (
                <div key={item.id}>{item.content}</div>
              ))}
            </div>
            <div>
              <button onClick={downloadPdfDocument}>Download PDF</button>
            </div>
          </div>
        </Modal>
      ) : null}
    </>
  );
}

export default InvoiceTemplate;