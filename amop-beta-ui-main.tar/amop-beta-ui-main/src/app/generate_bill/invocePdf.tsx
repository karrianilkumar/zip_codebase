"use client";
// InvoicePDF.tsx
import React from 'react';
import { Page, Text, View, Document, StyleSheet, Image, Styles } from '@react-pdf/renderer';

const styles: Styles = StyleSheet.create({
  page: {
    padding: 10, // Reduced padding for more space
    fontSize: 8, // Reduced font size
    flexDirection: 'column',
    justifyContent: 'flex-start',
  },
  section: {
    marginBottom: 3, // Reduced margin for less spacing
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    borderBottom: '1px solid #000',
    paddingBottom: 5, // Reduced padding
  },
//   logo: {
//     height: 40, // Reduced logo height
//   },
  logo: {
    width: 250,
    height: 45,
    marginBottom: 5,
    alt:"Altaworx"
  },
  tableRow: {
    flexDirection: 'row',
    justifyContent: 'space-between', // Add this line
  },
  table: {
    width: '100%',
    margin: '5px 0', // Reduced margin
  },
//   tableCol: {
//     width: '33.33%', // Adjusted to fit three columns
//     padding: 3, // Reduced padding
//   },
  tableCol: {
    width: '20%', // Adjusted to fit more columns without overlap
    padding: 4, // Reduced padding
  },
  bold: {
    fontWeight: 'bold',
  },
  hr: {
    borderBottom: '1px solid #000',
    margin: '5px 0', // Reduced margin
  },
  dottedHr: {
    borderBottom: '1px dotted #000',
    margin: '5px 0', // Reduced margin
  },
  verticalLine: {
    borderLeft: '1px solid #000',
    height: '100%',
    margin: '0 5px', // Reduced margin
  },
  leftColumn: {
    flex: 1,
    marginRight: 5, // Reduced margin
  },
  rightColumn: {
    flex: 1,
    marginLeft: 5, // Reduced margin
  },
  contactInfo: {
    border: '1px solid #000',
    padding: 5, // Reduced padding
    marginBottom: 5, // Reduced margin
  },
});

const InvoicePDF = ({ invoiceData }: { invoiceData: any }) => {
  return (
    <Document>
      <Page size="A4" style={styles.page}>
        {/* Header with Logo and Billing Info */}
        <View style={styles.header}>
          {/* <Image src="/path/to/logo.png" style={styles.logo} /> */}
          <Image src="/amop_logo_header.png" style={styles.logo} />
          
          <View style={{ border: '1px solid #000', padding: 5, textAlign: 'right' }}>
            <Text style={{ color: 'black' }}>Bill Date: {invoiceData?.billDate}</Text>
            <Text style={styles.bold}>Due: {invoiceData?.dueDate}</Text>
            <Text style={styles.bold}>Total: ${invoiceData?.totalAmount}</Text>
            <Text style={{ color: 'gray' }}>Bill#: {invoiceData?.bill_id}</Text>
            <Text style={{ color: 'gray' }}>Customer#: {invoiceData?.customer_id}</Text>
          </View>
        </View>

        {/* Addresses */}
        <View style={styles.section}>
          <View style={{ flexDirection: 'row', justifyContent: 'space-between', padding: 5 }}>
            <View>
              <Text style={styles.bold}>Bill To:</Text>
              <Text>{invoiceData?.billTo || "N/A"}</Text>
            </View>
            <View>
              <Text style={styles.bold}>Remit To:</Text>
              <Text>{invoiceData?.remitTo || "N/A"}</Text>
            </View>
          </View>
          <View style={styles.dottedHr} />
        </View>

        {/* Summary, Payments, Recurring Charges, Non-Recurring Charges, Taxes and Surcharges, Management Reports */}
        <View style={{ flexDirection: 'row' }}>
             {/* Additional Information Section */}
        
          <View style={styles.leftColumn}>
          <View style={styles.contactInfo}>
          <Text>
            --For billing questions, please contact us at 
            <Text style={{ fontWeight: 'bold' }}> {invoiceData?.contact_number || "N/A"}</Text> or email us at 
            <Text style={{ fontWeight: 'bold' }}> {invoiceData?.contact_email || "N/A"}</Text>.
          </Text>
        </View>
            {/* Summary Section */}
            <Text style={styles.bold}>Summary</Text>
            <View style={styles.hr} />
            <View style={styles.table}>
              <View style={styles.tableRow}>
                <Text style={styles.tableCol}>Payments Received:</Text>
                <Text style={styles.tableCol}>${invoiceData?.summary?.paymentsReceived || 0}</Text>
              </View>
              <View style={styles.tableRow}>
                <Text style={styles.tableCol}>Recurring Charges:</Text>
                <Text style={styles.tableCol}>${invoiceData?.summary?.["Reccurring Charges"] || 0}</Text>
              </View>
              <View style={styles.tableRow}>
                <Text style={styles.tableCol}>Non-Recurring Charges:</Text>
                <Text style={styles.tableCol}>${invoiceData?.summary?.["Non-Reccurring Charges"] || 0}</Text>
              </View>
              <View style={styles.tableRow}>
                <Text style={styles.tableCol}>Total Amount Due:</Text>
                <Text style={styles.tableCol}>${invoiceData?.summary?.["Total Amount Due"] || 0}</Text>
              </View>
            </View>
            <View style={styles.hr} />

            {/* Payments Section */}
            {invoiceData?.items?.find((item: { heading: string }) => item.heading === "Payments") && (
              <View style={styles.section}>
                <Text style={styles.bold}>Payments</Text>
                <View style={styles.hr} />
                <View style={styles.table}>
                  <View style={styles.tableRow}>
                    <Text style={styles.tableCol}>Description</Text>
                    <Text style={styles.tableCol}>Date</Text>
                    <Text style={styles.tableCol}>Amount</Text>
                  </View>
                  {invoiceData.items.find((item: { heading: string }) => item.heading === "Payments").table_rowData?.map((row: any, index: React.Key) => (
                    <View style={styles.tableRow} key={index}>
                      <Text style={styles.tableCol}>{row.description}</Text>
                      <Text style={styles.tableCol}>{row.date}</Text>
                      <Text style={styles.tableCol}>${row.amt}</Text>
                    </View>
                  )) || <Text>No payments found</Text>}
                </View>
                <View style={styles.hr} />
                {/* <Text>Subtotal: ${invoiceData.items.find((item: { heading: string }) => item.heading === "Payments").sub_total || 0}</Text> */}
                <View style={styles.tableRow}>
                    <Text style={styles.tableCol}>Subtotal:</Text>
                    <Text style={styles.tableCol}>${invoiceData.items.find((item: { heading: string }) => item.heading === "Payments").sub_total || 0}</Text>
                </View>
                <View style={styles.hr} />
              </View>
            )}

            {/* Recurring Charges Section */}
            {invoiceData?.items?.find((item: { heading: string }) => item.heading === "Recurring Charges") && (
              <View style={styles.section}>
                <Text style={styles.bold}>Recurring Charges</Text>
                <View style={styles.hr} />
                <View style={styles.table}>
                  <View style={styles.tableRow}>
                    <Text style={styles.tableCol}>Description</Text>
                    <Text style={styles.tableCol}>Start</Text>
                    <Text style={styles.tableCol}>End</Text>
                    <Text style={styles.tableCol}>Amount</Text>
                  </View>
                  {invoiceData.items.find((item: { heading: string }) => item.heading === "Recurring Charges").table_rowData?.map((row: any, index: React.Key) => (
                    <View style={styles.tableRow} key={index}>
                      <Text style={styles.tableCol}>{row.description}</Text>
                      <Text style={styles.tableCol}>{row.start || "N/A"}</Text>
                      <Text style={styles.tableCol}>{row.end || "N/A"}</Text>
                      <Text style={styles.tableCol}>${row.amt}</Text>
                    </View>
                  )) || <Text>No recurring charges found</Text>}
                </View>
                <View style={styles.hr} />
                <View style={styles.tableRow}>
                    <Text style={styles.tableCol}>Subtotal:</Text>
                    <Text style={styles.tableCol}>${invoiceData.items.find((item: { heading: string }) => item.heading === "Recurring Charges").sub_total || 0}</Text>
                </View>
                <View style={styles.hr} />
              </View>
            )}

            {/* Non-Recurring Charges Section */}
            {invoiceData?.items?.find((item: { heading: string }) => item.heading === "Non Recurring Charges") && (
              <View style={styles.section}>
                <Text style={styles.bold}>Non Recurring Charges</Text>
                <View style={styles.hr} />
                <View style={styles.table}>
                  <View style={styles.tableRow}>
                    <Text style={styles.tableCol}>Description</Text>
                    <Text style={styles.tableCol}>Start</Text>
                    <Text style={styles.tableCol}>End</Text>
                    <Text style={styles.tableCol}>Amount</Text>
                  </View>
                  {invoiceData.items.find((item: { heading: string }) => item.heading === "Non Recurring Charges").table_rowData?.map((row: any, index: React.Key) => (
                    <View style={styles.tableRow} key={index}>
                      <Text style={styles.tableCol}>{row.description}</Text>
                      <Text style={styles.tableCol}>{row.start || "N/A"}</Text>
                      <Text style={styles.tableCol}>{row.end || "N/A"}</Text>
                      <Text style={styles.tableCol}>${row.amt}</Text>
                    </View>
                  )) || <Text>No non-recurring charges found</Text>}
                </View>
                <View style={styles.hr} />
                <View style={styles.tableRow}>
                    <Text style={styles.tableCol}>Subtotal:</Text>
                    <Text style={styles.tableCol}> ${invoiceData.items.find((item: { heading: string }) => item.heading === "Non Recurring Charges").sub_total || 0}</Text>
                </View>
                <View style={styles.hr} />
              </View>
            )}
          </View>

          {/* Vertical Line */}
          <View style={styles.verticalLine} />

          {/* Right Column for Taxes and Surcharges, Management Reports */}
          <View style={styles.rightColumn}>
            {/* Taxes and Surcharges Section */}
            {invoiceData?.items?.find((item: { heading: string }) => item.heading === "Taxes and Surcharges") && (
              <View style={styles.section}>
                <Text style={styles.bold}>Taxes and Surcharges</Text>
                <View style={styles.hr} />
                {Object.entries(invoiceData.items.find((item: { heading: string }) => item.heading === "Taxes and Surcharges").taxes_dict || {}).map(([key, value], index) => (
                  <View key={index} style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                    <Text>{key}:</Text>
                    <Text>${value as number}</Text>
                  </View>
                )) || <Text>No taxes and surcharges found</Text>}
              </View>
            )}

            {/* Management Reports Section */}
            {invoiceData?.items?.find((item: { heading: string }) => item.heading === "Management Reports") && (
              <View style={styles.section}>
                <Text style={styles.bold}>Management Reports</Text>
                <View style={styles.hr} />
                <View style={styles.table}>
                  <View style={styles.tableRow}>
                    <Text style={styles.tableCol}>Account</Text>
                    <Text style={styles.tableCol}>MRC</Text>
                    <Text style={styles.tableCol}>NRC</Text>
                    <Text style={styles.tableCol}>Usage</Text>
                    <Text style={styles.tableCol}>Credit</Text>
                    <Text style={styles.tableCol}>Tax</Text>
                  </View>
                  {invoiceData.items.find((item: { heading: string }) => item.heading === "Management Reports").table_rowData?.map((row: any, index: React.Key) => (
                    <View style={styles.tableRow} key={index}>
                      <Text style={styles.tableCol}>{row.acct}</Text>
                      <Text style={styles.tableCol}>${row.mrc || 0}</Text>
                      <Text style={styles.tableCol}>${row.nrc || 0}</Text>
                      <Text style={styles.tableCol}>${row.usage || 0}</Text>
                      <Text style={styles.tableCol}>${row.cred || 0}</Text>
                      <Text style={styles.tableCol}>${row.tax || 0}</Text>
                    </View>
                  )) || <Text>No management reports found</Text>}
                </View>
              </View>
            )}
             {/* Additional Information Section */}
        <View style={styles.contactInfo}>
        <View style={styles.hr} />
          <Text>
            --For billing questions, please contact us at 
            <Text style={{ fontWeight: 'bold' }}> {invoiceData?.contact_number || "N/A"}</Text> or email us at 
            <Text style={{ fontWeight: 'bold' }}> {invoiceData?.contact_email || "N/A"}</Text>.
          </Text>
        </View>
          </View>
        </View>
      </Page>
    </Document>
  );
};

export default InvoicePDF;