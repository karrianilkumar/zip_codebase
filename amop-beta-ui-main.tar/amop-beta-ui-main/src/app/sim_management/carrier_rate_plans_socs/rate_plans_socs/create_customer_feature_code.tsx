'use client'
import React, { useState, useEffect } from 'react';
import { Modal, Select, Button, Form, notification, Spin } from 'antd';
import { ChevronDownIcon } from '@heroicons/react/24/outline';
import axios from 'axios';
import { useAuth } from '@/app/components/auth_context';
import { getCurrentDateTime } from '@/app/components/header_constants';
import { ENV_ROUTES } from '@/app/components/routes/route_constants';
import { fireSideCannons } from "@/app/components/confetti";
const { Option } = Select;

interface CreateCustomerFeatureCodeModalProps {
    isOpen: boolean;
    onClose: () => void;
    onSuccess: () => void
}

const CustomerModal: React.FC<CreateCustomerFeatureCodeModalProps> = ({
    isOpen,
    onClose,
    onSuccess
}) => {
    const [form] = Form.useForm();
    const [selectedProvider, setSelectedProvider] = useState<string>('');
    const [selectedCustomer, setSelectedCustomer] = useState<string>('');
    const [customers, setCustomers] = useState<string[]>([]);
    const [serviceProviders, setServiceProviders] = useState<string[]>([]);
    const [serviceProviderCustomers, setServiceProviderCustomers] = useState<Record<string, string[]>>({});
    const [featureCodes, setFeatureCodes] = useState<string[]>([]);
    const [selectedFeatureCodes, setSelectedFeatureCodes] = useState<string>("");
    const { username, token, partner, selectedDb, metaData, role, firstLastName,sessionId, } = useAuth();
    const [loading, setLoading] = useState(false);


    const handleCreateCustomerFeatureCode = async () => {
        setLoading(true);
        try {
            const url = ENV_ROUTES.MODULE_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName:firstLastName,
                path: "/customers_dropdown_data",
                role_name: role,
                parent_module: "Sim Management",
                module_name: "Feature Codes",
                feature_module_name:"Rate Plans/SOCs",
                mod_pages: {
                    start: 0,
                    end: 100,
                },
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            console.log(parsedData, 'parsed')
            if (parsedData.flag === false) {
                setLoading(false);
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                setLoading(false);
                setServiceProviders(Object.keys(parsedData.service_provider_customers || {}));
                setServiceProviderCustomers(parsedData.service_provider_customers || {});
                setFeatureCodes(parsedData.feature_codes || []);
            }
        } catch (error) {
            console.error("Error fetching data:", error);
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        } finally {
            setLoading(false);
        }
    };
    useEffect(() => {
        if (selectedProvider) {
            setCustomers(serviceProviderCustomers[selectedProvider] || []);
        } else {
            setCustomers([]);
        }
    }, [selectedProvider, serviceProviderCustomers]);

    useEffect(() => {
        if (isOpen) {
            handleCreateCustomerFeatureCode();
    
            // Reset Ant Design form fields
            form.resetFields();
    
            // Reset state variables
            setSelectedProvider('');
            setSelectedCustomer('');
            setSelectedFeatureCodes('');
    
            // Ensure Ant Design form reflects these changes
            form.setFieldsValue({
                provider: '',
                customer: '',
                featureCodes: '',
            });
        }
    }, [isOpen]);

    const handleProviderChange = (value: string) => {
        setSelectedProvider(value);
        setSelectedCustomer(''); // Reset customer selection
        form.resetFields(['customer', 'featureCodes']);
    };

    const handleCustomerChange = (value: string) => {
        setSelectedCustomer(value);
    };

    const handleFeatureCodeChange = (value: string) => {
        setSelectedFeatureCodes(value);
    };
    const messageStyle = {
        fontSize: '14px',  // Adjust font size
        fontWeight: 'bold', // Make the text bold
        padding: '16px',
        // Add padding
    };

    const renderLabel = (label: string, required: boolean) => (
        <span className="field-label">
            {label} {required && <span className="required-indicator" style={{ color: 'red' }}>*</span>}
        </span>
    );

    const onFinish = async (values: { [key: string]: any }) => {
        // Prepare form data
        setLoading(true)

        const formData = {
            service_provider_name: selectedProvider,
            // customer_name: selectedCustomer,
            soc_code: selectedFeatureCodes,
            created_by:firstLastName,
            modified_by: firstLastName,
            modified_date:getCurrentDateTime(),
            is_deleted: false,
            is_active: true,
            created_date: getCurrentDateTime()
        };

        const requestData = {
            tenant_name: partner || 'default_value',
            username: username,
            firstLastName:firstLastName,
            path: "/update_sim_management_modules_data",
            module_name: "Feature Codes",
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            new_data: formData,
            action: "create",
            access_token: token,
            db_name: selectedDb,
            ...metaData,
            sessionID: sessionId,
            table_name: "mobility_feature"
        };

        try {
            // Make the POST request
            const response = await axios.post(ENV_ROUTES.SIM_MANAGEMENT, {
                data: requestData,
            });
            // if (response.data.statusCode === 200) {
            //     onSuccess();
            //     setLoading(false)

            // }
            // else {
            //     const errorMsg = JSON.parse(response.data.body).message
            //     Modal.error({
            //         title: 'Saving Error',
            //         content: errorMsg,
            //         centered: true,
            //     });
            //     setLoading(false)

            // }
            if (response && response.data.statusCode === 200) {
                // Show success message
                onSuccess();
                notification.success({
                    message: 'Success',
                    description: 'Successfully created the record!',
                    style: messageStyle,
                    placement: 'top', // Apply custom styles here
                });
                fireSideCannons()
                setLoading(false)
            }
            else {
                const errorMsg = JSON.parse(response.data.body).message
                Modal.error({
                    title: 'Saving Error',
                    content: errorMsg,
                    centered: true,
                });
                setLoading(false)

            }

        } catch (err) {
            console.error('Error fetching data:', err);
            notification.error({
                message: 'Error',
                description: 'Failed to create the record. Please try again.',
                style: messageStyle,
                placement: 'top',// Apply custom styles here
            });
            setLoading(false)

        }
    };

    return (
        <Modal
            title="Create Feature Codes"
            open={isOpen}
            onCancel={onClose}
            footer={null}
            centered
            width={500}
            styles={{ body: { height:loading?'370px': 'auto', padding: "4px" } }}
        >
            {loading ? (
                <div className="flex justify-center items-center h-[500px]">
                    <Spin size="large" />
                </div>
            ) : (
                <>
                <Form
                    form={form}
                    layout="vertical"
                    initialValues={{
                        provider: selectedProvider,
                        customer: selectedCustomer,
                        featureCodes: selectedFeatureCodes,
                    }}
                    onFinish={onFinish}
                    requiredMark={false}
                >
                    <Form.Item label={renderLabel("Service Provider", true)} name="provider" rules={[{ required: true, message: 'Please select service provider' }]} >
                        <Select
                            value={selectedProvider}
                            onChange={handleProviderChange}
                            style={{ width: '100%' }}
                            placeholder="Select a Service Provider"
                            suffixIcon={<ChevronDownIcon className="w-5 h-5 mt-2 text-gray-600" />}
                            className='mb-2'
                            showSearch
                        >
                            {serviceProviders.map(provider => (
                                <Option key={provider} value={provider}>{provider}</Option>
                            ))}
                        </Select>
                    </Form.Item>

                    {/* <Form.Item label={renderLabel("Customer", true)} name="customer" rules={[{ required: true, message: 'Please select customer' }]}>
                        <Select
                         showSearch
                            value={selectedCustomer}
                            onChange={handleCustomerChange}
                            style={{ width: '100%' }}
                            placeholder="Select a Customer"
                            suffixIcon={<ChevronDownIcon className="w-5 h-5 mt-2 text-gray-600" />}
                            disabled={!selectedProvider}
                            className='mb-2'
                           
                        >
                            {customers.map((customer, index) => (
                                <Option key={index} value={customer}>{customer}</Option>
                            ))}
                        </Select>
                    </Form.Item> */}

                    <Form.Item label={renderLabel("Feature Codes", true)} name="featureCodes" rules={[{ required: true, message: 'Please select feature codes' }]}>
                        <Select
                            // mode="multiple"
                            style={{ width: '100%' }}
                            placeholder="Select Feature Codes"
                            value={selectedFeatureCodes}
                            onChange={handleFeatureCodeChange}
                            maxTagCount="responsive"
                            suffixIcon={<ChevronDownIcon className="w-5 h-5 mt-2 text-gray-600" />}
                            maxTagPlaceholder={(omittedValues) => `+${omittedValues.length} more`}
                            showSearch
                        >
                            {featureCodes.map((feature, index) => (
                                <Option key={index} value={feature}>{feature}</Option>
                            ))}
                        </Select>
                    </Form.Item>

                    <div className="flex justify-center space-x-2 mt-4">
                        <button type="button" onClick={onClose} className='cancel-btn' style={{ fontFamily: 'Calibri, sans-serif' }}>Cancel</button>
                        <button type="submit" className='save-btn' style={{ fontFamily: 'Calibri, sans-serif' }}>Save</button>
                    </div>
                </Form></>
                
            )}

        </Modal>
    );
};

export default CustomerModal;
