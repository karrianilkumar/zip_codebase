"use client";
import React, { useEffect, useState, lazy, Suspense } from 'react';
// import dynamic from 'next/dynamic';
import { useSidebarStore } from '@/app/stores/navBarStore';
import { useLogoStore } from "@/app/stores/logoStore";
import { Spin } from 'antd';


const CarrierRatePlan = lazy(() => import('./carrier_rate_plan'));
const FeatureCode = lazy(() => import('./feature_codes'));
const RatePlanType = lazy(() => import('./rate_plan_type'))

interface RatePlanSocsProps {
    isPartnerInfoModal?: boolean;
}

const RatePlanSocs: React.FC<RatePlanSocsProps> = ({ isPartnerInfoModal })=> {
  const title = useLogoStore((state) => state.title);
  const setTitle = useLogoStore((state) => state.setTitle);

  const active_tab = localStorage.getItem("activeTab") || "carrierRatePlan"
  const active_tabs_list = ["carrierRatePlan", "featureCode", "ratePlanType"]
  const [activeTab, setActiveTab] = useState(() => {
    // Check if active_tab is in active_tabs_list; default to 'customer' if not
    return active_tabs_list.includes(active_tab) ? active_tab : "carrierRatePlan";
  });

  const isExpanded = useSidebarStore((state: any) => state.isExpanded);

  const [loading, setLoading] = useState(false); // State to manage loading

  useEffect(() => {
    // Save activeTab state to localStorage on change
    localStorage.setItem("activeTab", activeTab);
  }, [activeTab]);

  if (loading && !isPartnerInfoModal) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }
  return (
    // <Suspense fallback={<div className="flex justify-center items-center h-screen"><Spin size="large" /></div>}>

    <div className="">
      <div className={`bg-white shadow-md gap-4  ${isPartnerInfoModal?'':"tabs mb-4 "} ${isExpanded
            ? "left-[250px]"
            : "lg:left-[70px] left-0"
        }`}>


        <button
          className={`tab-headings ${activeTab === 'carrierRatePlan' ? 'active-tab-heading' : ''}`}
          onClick={() => setActiveTab('carrierRatePlan')}
        >
          Carrier Rate Plans/SOCs
        </button>
        <button
          className={`tab-headings ${activeTab === 'featureCode' ? 'active-tab-heading' : ''}`}
          onClick={() => setActiveTab('featureCode')}
        >
          Feature Codes
        </button>
        <button
          className={`tab-headings ${activeTab === 'ratePlanType' ? 'active-tab-heading' : ''}`}
          onClick={() => setActiveTab('ratePlanType')}
        >
          Rate Plan Type
        </button>

      </div>
      <div className={`${isPartnerInfoModal?'':"h-[calc(100vh-150px)] pt-[70px]"}`}>
        {activeTab === 'carrierRatePlan' && <CarrierRatePlan isPartnerInfoModal={isPartnerInfoModal} />}
        {activeTab === 'featureCode' && <FeatureCode isPartnerInfoModal={isPartnerInfoModal} />}
        {activeTab === 'ratePlanType' && <RatePlanType isPartnerInfoModal={isPartnerInfoModal} />}

      </div>
    </div>
    // </Suspense>
  );
};

export default RatePlanSocs;

