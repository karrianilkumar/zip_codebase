"use client";
import React, { useEffect, useState, lazy, Suspense, useRef, useCallback } from "react";
import {
  PlusIcon,
  ArrowDownTrayIcon,
} from "@heroicons/react/24/outline";
import { Button, Modal, Spin, DatePicker, notification } from "antd";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import dayjs, { Dayjs } from "dayjs";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import CreateCustomerModal from "./create_optimization_type_group";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useCustomerRatePlanStore } from "@/app/stores/customerRateplanStore";
import { fireSideCannons } from "@/app/components/confetti";
const { RangePicker } = DatePicker;
const TableComponent = lazy(() => import("@/app/components/TableComponent/page"));
const CreateModal = lazy(() => import("@/app/components/createPopup"));
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));
const TableSearch = lazy(() => import("@/app/components/entire_table_search"));
const AdvancedMultiFilter = lazy(() => import("@/app/components/advanced_search"));

const OptimizationTypeGroups: React.FC = () => {
  
    const [isCreateModalOpen, setCreateModalOpen] = useState(false);
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, settabledata, token ,selectedDb,metaData, firstLastName,sessionId,dynamicColumns,setDynamicColumns} = useAuth();
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([null, null]);
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  // const { showAdvanced, setShowAdvanced} = useCustomerRatePlanStore();
  const [createModalData, setcreateModalData] = useState<any[]>([]);
  const [generalFields, setgeneralFields] = useState<any[]>([])
  const { features: moduleFeatures, setFeatures: setModuleFeatures } = useFeatureStore();
  const hasFetchedData = useRef(false);
  const [isCustomerModalOpen, setCustomerModalOpen] = useState(false); // State for CustomerModal
  const [serviceProviderMap, setServiceProviderMap] = useState<any>({});
  const [isLogModalOpen, setIsLogModalOpen] = useState(false); // State to manage log modal visibility
  const [logs, setLogs] = useState<{ step: string; time: string }[]>([]); // State for logs
  const [performanceMatrix, setPerformanceMatrix] = useState<any>({});
  const [latestNavClick, setLatestNavClick] = useState<{ label: string; clickTime: string } | null>(null);
  const [allowedActions, setAllowedActions] = useState<any[]>([]);

  useEffect(() => {
    // Retrieve the latest navigation click time from localStorage
    const storedNavClick = localStorage.getItem('latestNavClick');
    if (storedNavClick) {
      setLatestNavClick(JSON.parse(storedNavClick));
    }
  }, []);
  
   // Function to add a log
   const addLog = (step: string) => {
    const now = dayjs().format('HH:mm:ss.SSS'); // 24-hour format with milliseconds
    setLogs((prevLogs) => [...prevLogs, { step, time: now }]);
  };
  type HeaderMap = Record<string, [string, number]>;
  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);

  const sortPopup = (fields: any[]): any[] => {
    return fields.sort((a: any, b: any) => a?.id - b?.id);
  };
  const handleFilter = useCallback((advancedFilters: any) => {
    console.log(advancedFilters);
  }, []);

  const handleReset = useCallback((EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  }, []);
  const handleFormSubmitSuccess = () => {
    fetchData();// Re-fetch data to get the latest row
    setCustomerModalOpen(false) 
  };

const handleCreateCustomerFeatureCode = () => {
    setCustomerModalOpen(true);
};

useEffect(() => {
      setDynamicColumns((prev:any)=>({...prev,"Optimization Group":visibleColumns}))
    }, [visibleColumns]);

  const fetchData = useCallback(async () => {
    setLoading(true);
    addLog("UI API call");
    try {
      const url =ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName:firstLastName,
        path: "/get_module_data",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Optimization Group",
        feature_module_name:"Optimization Groups",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };
      console.log(getCurrentDateTime(),"Show the log time request sent from ui to lambda");
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      setPerformanceMatrix(JSON.parse(response.data.performance_matrix)) ; // Set performance_matrix here
      addLog("Lambda response to UI");
      console.log(getCurrentDateTime(),"Show the log time response sent from lambda to ui");


      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching Inventory data. Please try again.',
          centered: true,
        });
      } else {
          const headersMap_ = parsedData?.headers_map?.["Optimization Group"]?.header_map || {}
          const sortedheaderMap = sortHeaderMap(headersMap_)
          setHeaderMap(sortedheaderMap)
          const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : []
          setHeaders(headers_)          
          const dynamic_cols=dynamicColumns?.["Optimization Group"]&& dynamicColumns["Optimization Group"] .length>0 ?dynamicColumns["Optimization Group"]  :headers_ || headers_
          setVisibleColumns(dynamic_cols)
          const tableData_ = parsedData?.data?.optimization_group || []
          setTableData(tableData_)
          const features_ = parsedData?.headers_map?.["Optimization Group"]?.module_features || []
          setFeatures(features_)
          const allowedActions_:any=[]
          if(features_.includes("Edit-Optimization types/groups")){
            allowedActions_.push("editCustomerModal")
          }
          if(features_.includes("Delete-Optimization types/groups")){
            allowedActions_.push("delete")
          }
          if(features_.includes("Info-Optimization types/groups")){
            allowedActions_.push("infoCustomerModal")
          }
          setAllowedActions(allowedActions_)
          const createModalData_=parsedData?.headers_map?.["Optimization Group"]?.pop_up||[]
          const sortedCreatemodeldata_=sortPopup(createModalData_)
          setcreateModalData(sortedCreatemodeldata_)
          const generalFields_=parsedData?.data || {}
          setgeneralFields(generalFields_)
          setModuleFeatures(features_)
          const pagination_ = parsedData?.pages || {}
          setPagination(pagination_)
          const serviceProviderMap_=parsedData.data.rate_plans_list || {}
          setServiceProviderMap(serviceProviderMap_);
             }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      setLoading(false);
      
    }
  }, [username, partner, role, token, sortHeaderMap, setModuleFeatures]);

  useEffect(() => {
    if (!hasFetchedData.current) {
      fetchData();
      hasFetchedData.current = true;
    }
  }, [fetchData]);

  const messageStyle = {
    fontSize: '14px',
    fontWeight: 'bold',
    padding: '16px',
  };
  const closeLogModal = () => {
    setIsLogModalOpen(false);
  };

  const handleExportModalOpen = () => {
    setExportModalOpen(true);
  };

  const handleExportModalClose = () => {
    setExportModalOpen(false);
    console.log("Modal closed, resetting date range.");
  };

  const handleExport = async () => {
    if (!dateRange || dateRange[0] === null || dateRange[1] === null) {
      Modal.error({ title: 'Error', content: 'Please select a date range.' });
      return;
    }

    const [startDate, endDate] = dateRange;

    const data = {
      path: "/export",
      username: username,
      firstLastName:firstLastName,
      module_name: "Optimization Group",
      request_received_at: getCurrentDateTime(),
      start_date: startDate.format("YYYY-MM-DD 00:00:00"),
      end_date: endDate.format("YYYY-MM-DD 23:59:59"),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
    };

    try {
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const response = await axios.post(url, { data: data }, {
        headers: {
          'Content-Type': 'application/json',
        },
      });

      const resp = JSON.parse(response.data.body);
      const blob = resp.blob;
      // console.log(resp);

      if (response.data.statusCode === 200) {
        if (resp.flag === true) {
          notification.success({
            message: 'Success',
            description: 'Successfully exported the record!',
            style: messageStyle,
            placement: 'top',
          });
          fireSideCannons()
          downloadBlob(blob);
        } else {
          console.log('Error message:', resp.message);
          Modal.error({
            title: 'Export Error',
            content: resp.message,
            centered: true,
          });
        }
      } else {
        console.log('Unexpected status code:', response.data.statusCode);
        Modal.error({
          title: 'Export Error',
          content: resp.message,
          centered: true,
        });
      }

      handleExportModalClose();
    } catch (error) {
      console.error("Error downloading the file:", error);
      Modal.error({ title: 'Export Error', content: 'An error occurred while exporting the file. Please try again.' });
    }
  };
 
  const handleCreateModalOpen = () => {
    setCreateModalOpen(true);
  };

  const handleCreateModalClose = () => {
    setCreateModalOpen(false);
  };
  const handleCreateRow = (newRow: any, tableData: any) => {
    const updatedData = [...tableData, newRow];
    // setTable(tableData);
    // setTableData(tableData);
    handleCreateModalClose();
  };
  const downloadBlob = (base64Blob: string) => {
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    const blobObject = new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blobObject);
    link.download = 'Optimization Group.xlsx';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
    // Add log after Suspense
    useEffect(() => {
      addLog("Component rendered");
    }, []);

    // useEffect(() => {
    //   if (!loading) {
    //     addLog("Data Displayed in UI");
    //   }
    // }, [loading]);
    useEffect(() => {
      if (!loading) {
        console.log("Data Displayed in UI", getCurrentDateTime());
      }
    }, [loading]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  const disableFutureDates = (current: any) => {
    console.log("future dates:", current && current > dayjs().endOf('day'));
    return current && current > dayjs().endOf('day');
  };


  return (
    <>
    <Suspense fallback={<div className="flex justify-center items-center h-screen"><Spin size="large" /></div>}>
      <div className="relative">
      <div className="px-4  pt-2 flex md:flex-row md:items-center md:justify-between mt-1 space-y-4">
          {/* Search and Advanced Filter Container */}
          <div className="flex  space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last ">
          {features.includes("Search-Optimization types/groups") && (
            <TableSearch
              searchTerm={searchTerm}
              setSearchTerm={setSearchTerm}
              tableName={"optimization_group"} 
              headerMap={headerMap}
            />
          )}
            {features.includes("Advanced filter-Optimization types/groups") && (
              <AdvancedMultiFilter
                showAdvanced={showAdvanced}
                setShowAdvanced={setShowAdvanced}
                onFilter={handleFilter}
                onReset={handleReset}
                headers={headers}
                headerMap={headerMap}
                tableName={"optimization_group"} 
                 />
            )}
          </div>
           {/* Export and ColumnFilter Container */}
           <div className="hidden md:flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2  md:order-none order-first pb-2 md:pb-4">
          {features.includes("Create-Optimization types/groups") && (

            <button className="save-btn" onClick={handleCreateCustomerFeatureCode}>
                <PlusIcon className="h-5 w-5 text-black-500 mr-1" />
                    Create 
            </button>
            )}
            {/* {moduleFeatures.includes("Export Optimization Group") && ( */}
              {/* <button className="save-btn" onClick={handleExportModalOpen}>
                <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                <span>Export</span>
              </button> */}
             {/* )}  */}
            <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
            />
             {/* <Button onClick={() => setIsLogModalOpen(true)} className="save-btn text-base">
                  Show Logs
                </Button> */}
          </div>
        </div>
        <div className={`${showAdvanced ? 'mt-[70px]' : ''}`}>
          <TableComponent
            headers={headers}
            headerMap={headerMap}
            initialData={tableData}
            searchQuery={searchTerm}
            visibleColumns={visibleColumns}
            itemsPerPage={100}
            allowedActions={allowedActions}
            popupHeading="Optimization Group"
            pagination={pagination}
            advancedFilters={filteredData}
            createModalData={createModalData}
            generalFields={generalFields}
            height = {showAdvanced?280:230}
          />
        </div>
        <CreateCustomerModal
          isOpen={isCustomerModalOpen}
          onClose={() => setCustomerModalOpen(false)}
          onSuccess={handleFormSubmitSuccess}
          // serviceProviderMap={serviceProviderMap}
        />
        <Modal
          title="Export Output"
          visible={isExportModalOpen}
          onCancel={() => {
            handleExportModalClose();
            setDateRange([null, null]);
          }}
          footer={null}
          centered
          afterClose={() => setDateRange([null, null])}
        >
          <div className="flex flex-col space-y-4">
            <span>Select Date Range</span>
            <RangePicker
              value={dateRange[0] && dateRange[1] ? [dateRange[0], dateRange[1]] : null}
              onChange={(dates) => {
                console.log("Selected dates:", dates);
                if (dates && dates.length === 2) {
                  setDateRange([dates[0], dates[1]] as [Dayjs, Dayjs]);
                } else {
                  setDateRange([null, null]);
                }
              }}
              format="YYYY-MM-DD"
              popupClassName="custom-range-popup"
              disabledDate={disableFutureDates}
            />
            <div className="flex justify-center space-x-2">
              <button className="cancel-btn" onClick={handleExportModalClose}>Cancel</button>
              <button className="save-btn" onClick={handleExport}>Export</button>
            </div>
          </div>
        </Modal>
           {/* Sticky Footer for Small Screens */}
           <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
           {features.includes("Create-Optimization types/groups") && (

            <button className="save-btn" onClick={handleCreateCustomerFeatureCode}>
                <PlusIcon className="h-5 w-5 text-black-500 " />
            </button>
            )}
          
            <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
            />
            </div>
      </div>
    </Suspense>
    </>
  );
};

export default OptimizationTypeGroups;
