"use client";

import { FC, forwardRef, useEffect, useImperativeHandle, useMemo, useState } from "react";
import { Checkbox, Input, Modal, Spin, Tooltip } from "antd";
import Select from "react-select";
import SelectDevices from "./select_devices";
import React from "react";
import { DropdownStyles, NonEditableDropdownStyles } from "@/app/components/css/dropdown";
import { useAuth } from "@/app/components/auth_context";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import axios from "axios";
import { useFeatureStore } from "../../inventory/featureStore";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { useRouter } from "next/navigation";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { useAllChangeTypesStore } from "@/app/stores/allChangeTypesStore";
import { PerformanceLogStore } from "@/app/stores/performance_matrix_store";
import PreviewModal from "./private_network_preview";
import { EyeIcon, InfoIcon } from "lucide-react";
import UploadComponent2 from "./upload_component_2";

interface PrivateNetworkProps {
    onContinue: () => void;
    onBack: () => void;
    dropdown: any;
    service_provider: any;
    change_type: any;
    onClose: () => void;
}

export interface PrivateNetworkContentRef {
    runValidation: () => Promise<void> | void;
    runSubmit: () => Promise<void> | void;
    returnUpdate: () => React.ReactNode | Promise<React.ReactNode>;
    IPOptions: any
}
type IccidIpPair = {
  iccid: string;
  ip: string;
  ipValid: boolean;
  ipError: string;
};

const PrivateNetwork = forwardRef<PrivateNetworkContentRef, PrivateNetworkProps>(
    ({ onContinue, onBack, dropdown, service_provider, change_type, onClose }, ref) => {
        //Stores
        const { setBulkRow, bulkChangeLimit, simIdentifierMap } = useFeatureStore();
        const router = useRouter();
        const { username, role, partner, token, selectedDb, metaData, firstLastName, sessionId, modulesVersionMap } = useAuth();
        const { addExport, removeExport, exports } = exportLoadingStore();
        const { isAllChangeType, setIsValidated, setValidationTrigger, setsuccessFullChangeTypes, activeChange, successFullChangeTypes, allChangeTypesDevices ,SelectedPDPGlobal , SelectedAPNGlobal,all_2_0_payloads, set_all_2_0_payloads } = useAllChangeTypesStore();
        const { getTargetTenantProvider, IsTargetTenantProvider } = PerformanceLogStore();
        //Flags
        const initial_version_flag = modulesVersionMap?.["Sim Management-Bulk Change"] || false
        const isVersionEnabled = localStorage.getItem("switch_user_2_0_bulk_change") === "True";
        const switch_user_2_0 = isVersionEnabled && initial_version_flag ? "True" : "False";
        const is_parent_provider_exists = IsTargetTenantProvider(service_provider)
        const providerName = getTargetTenantProvider(service_provider).toLowerCase() || service_provider;
        const isTelegence = providerName.toLowerCase().includes("telegence");
        const isVerizon = (providerName.toLowerCase().includes("verizon") || providerName.toLowerCase().includes("vzn") || providerName.toLowerCase().includes("vzwcr") || providerName.toLowerCase().includes("2215-so01"));
        const isTeal = providerName.toLowerCase().includes("teal");

        //States
        const [errors, setErrors] = useState<string[]>([]);
        const [loading, setLoading] = useState(false);
        const [saveChanges, setSaveChanges] = useState<boolean>(true);

        const [billingAccountNumber, setBillingAccountNumber] = useState<string | undefined>(undefined);
        const [BANOptions, setBANOptions] = useState<any>([])
        const [BANError, setBANError] = useState<string>("");

        const [carrierRatePlan, setCarrierRatePlan] = useState<string | null>(null);
        const [carrierRatePlanError, setCarrierRatePlanError] = useState<string | null>(null);
        const [ratePlanOptions, setRatePlanOptions] = useState<any>([])

        const [commPlan, setCCommPlan] = useState<string | null>(null);
        const [commPlanError, setCommPlanError] = useState<string | null>(null);
        const [commPlanOptions, setCommPlanOptions] = useState<any>([])

        const [pdpOptions, setPdpOptions] = useState<any>([]);
        const [selectedPDP, setSelectedPDP] = useState<string | null>(null);
        const [pdpError, setPdpError] = useState<string | null>(null);
        const [noPdpsError, setNoPdpsError] = useState<string | null>(null);


        const [apnOptions, setApnOptions] = useState<any>([]);
        const [apn, setApn] = useState<string | null>(null);
        const [apnError, setApnError] = useState<string | null>(null);

        const [IPOptions, setIPOptions] = useState<any>([]);
        const [PdpIPOptions, setPdpIPOptions] = useState<any>([]);

        const [IPRange, setIPRange] = useState<string | null>(null);
        const [IpAddress, setIpAddress] = useState<string | null>(null);
        const [IpError, setIpError] = useState<string | null>(null);
        const [IPAddressMap, setIPAddressMap] = useState<any>({});

        const [apnPdpMap, setApnPdpMap] = useState<any>({});
        const [pdpIpMap, setPdpIpMap] = useState<any>({});

        const [subscriberNumber, setSubscriberNumber] = useState<string>("");
        const [rawSubscriberNoInput, setRawSubscriberNoInput] = useState("");
        const [rawInput, setRawInput] = useState("");
        const [parsedPairs, setParsedPairs] = useState<IccidIpPair[]>([]);
        const [iccids, setIccids] = useState<string>("");
        const [rawIccidInput, setRawIccidInput] = useState("");
        const [errorMessage, setErrorMessage] = useState("");
        const [openPreviewModal, setPreviewModal] = useState<boolean>(false);

        const ipAddresses = useMemo(() => {
        if (!allChangeTypesDevices?.iccid_ip_map) return [];
        console.log("allChangeTypesDevices",allChangeTypesDevices)
        return Object.values(allChangeTypesDevices.iccid_ip_map);
        }, [allChangeTypesDevices?.iccid_ip_map]);
        useEffect(() => {
            if (!isAllChangeType) {
                setBillingAccountNumber(undefined)
            }
            const rate_plan_options = dropdown?.carrier_rate_plan_dropdown || []
            setRatePlanOptions(rate_plan_options)
            const comm_plan_dropdown = dropdown?.comm_plan_dropdown || []
            // setCommPlanOptions(comm_plan_dropdown)

            const fetchOptionsData = async () => {
                try {
                    setLoading(true)
                    await fetchOptionsMappings()
                    await fetchBANs()
                    // await fetchPDPOptions()
                }
                catch (err) {
                    console.log("error fetching dropdown data", err)
                }
                finally {
                    setLoading(false)
                }
            }
            fetchOptionsData()

        }, [dropdown]);

        useEffect(() => {
            if (IPOptions && IPOptions.length > 0) {
                const ip_ranges = IPOptions.join(",")
                console.log("ip_ranges", ip_ranges)
                setIPRange(ip_ranges)
            }
        }, [IPOptions])

        useEffect(() => {
            if (isAllChangeType) {
                console.log("SelectedPDPGlobal",SelectedPDPGlobal)
                setSelectedPDP(SelectedPDPGlobal) //to fetch pdp that is selected in the devices preview modal
                setApn(SelectedAPNGlobal) // to fetch apn for the selcted pdp in the devices preview screen
                const devices = allChangeTypesDevices?.iccids || []
                const devicesString = devices.join('\n')
                if (allChangeTypesDevices?.isIccid) {
                    setSubscriberNumber("")
                    setRawIccidInput(devicesString)
                    setIccids(devicesString);
                }
                else {
                    setIccids("")
                    setRawSubscriberNoInput(devicesString)
                    setSubscriberNumber(devicesString);
                }
            }
        }, [isAllChangeType, allChangeTypesDevices]);

        const fetchBANs = async () => {
            try {
                const url =
                    ENV_ROUTES.SIM_MANAGEMENT;
                const data = {
                    tenant_name: partner || "default_value",
                    username: username,
                    firstLastName: firstLastName,
                    path: "/get_user_billing_account_number",
                    role_name: role,
                    Partner: partner,
                    request_received_at: getCurrentDateTime(),
                    access_token: token,
                    db_name: selectedDb,
                    ...metaData,
                    sessionID: sessionId,
                };

                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);
                if (parsedData.flag === false) {
                    Modal.error({
                        title: 'Submit Error',
                        content: parsedData.message || 'An error occurred while submitting data. Please try again.',
                        centered: true,
                    });
                } else {
                    const ban_options = parsedData?.data || []
                    setBANOptions(ban_options)
                }
            } catch (error) {
                Modal.error({
                    title: 'Submit Error',
                    content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching BANs. Please try again.',
                    centered: true,
                });
            }
            finally {
            }
        };
        const fetchOptionsMappings = async (selectedPDP_?:string) => {
            setNoPdpsError("")
            try {
                const url =
                    ENV_ROUTES.MODULE_MANAGEMENT;
                const data = {
                    tenant_name: partner || "default_value",
                    path: "/get_private_network_pdp_apn_ip_mappings",
                    request_received_at: getCurrentDateTime(),
                    username: username,
                    firstLastName: firstLastName,
                    role_name: role,
                    Partner: partner,
                    access_token: token,
                    db_name: selectedDb,
                    ...metaData,
                    sessionID: sessionId,
                    service_provider: service_provider,
                    selected_pdp:selectedPDP_?selectedPDP_ :selectedPDP,
                    info_flag:false,
                    ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" },
                    change_type: change_type
                };

                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);
                if (parsedData.flag === false) {
                    Modal.error({
                        title: 'Data Fetch Error',
                        content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                        centered: true,
                    });
                } else {
                    if(parsedData.message){
                        setNoPdpsError(parsedData.message)
                        return;
                    }
                    const apn_pdp_map = parsedData?.apn_pdp_map || {};
                    setApnPdpMap(apn_pdp_map)
                    const pdp_ip_map = parsedData?.pdp_ip_map || {};
                    setPdpIpMap(pdp_ip_map)

                    const apn_options = Object.keys(apn_pdp_map) || []
                    setApnOptions(apn_options)

                    const pdp_options = parsedData?.pdp || [];
                    setPdpOptions(pdp_options)
                    const selectedpdpKey = isAllChangeType ? SelectedPDPGlobal : selectedPDP_ ? selectedPDP_ :selectedPDP || "" // only need to fetch ip options in the selected PDP IP Range
                    const ip_options = parsedData?.pdp_ip_map[selectedpdpKey] || {};
                    setIPOptions(ip_options)
                    setPdpIPOptions(ip_options)
                }
            } catch (error) {
                Modal.error({
                    title: 'Data Fetch Error',
                    content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                    centered: true,
                });
            }
        };
        const fetchPDPOptions = async () => {
            try {
                const url =
                    ENV_ROUTES.SIM_MANAGEMENT;
                const data = {
                    tenant_name: partner || "default_value",
                    path: "/get_static_ip_setting_values",
                    request_received_at: getCurrentDateTime(),
                    username: username,
                    firstLastName: firstLastName,
                    role_name: role,
                    Partner: partner,
                    access_token: token,
                    db_name: selectedDb,
                    ...metaData,
                    sessionID: sessionId,
                    service_provider: service_provider,
                    ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" },
                    change_type: change_type
                };

                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);
                if (parsedData.flag === false) {
                    Modal.error({
                        title: 'Data Fetch Error',
                        content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                        centered: true,
                    });
                } else {
                    const pdpname_list = parsedData?.pdpname_list || [];
                    setPdpOptions(pdpname_list)

                }
            } catch (error) {
                Modal.error({
                    title: 'Data Fetch Error',
                    content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                    centered: true,
                });
            }
        };

        // IPv4
        const ipv4Regex = /^(\d{1,3}\.){3}\d{1,3}$/;
        const isValidIPv4 = (ip: string) => {
            if (!ipv4Regex.test(ip)) return false;
            return ip.split(".").every(p => {
                if (!/^\d+$/.test(p)) return false;
                const n = Number(p);
                return Number.isInteger(n) && n >= 0 && n <= 255;
            });
        };
        const ipv4ToUint32 = (ip: string) => {
            const [a, b, c, d] = ip.split(".").map(Number);
            return ((a << 24) >>> 0) + (b << 16) + (c << 8) + d;
        };

        // IPv6: expand compressed forms into 8 hextets of 4 hex digits
        const expandIPv6 = (input: string): string[] | null => {
            const raw = input.trim();
            if (!raw) return null;
            // split on :: (0..1 times)
            if (raw.includes("::")) {
                const [left, right] = raw.split("::");
                const leftParts = left ? left.split(":").filter(Boolean) : [];
                const rightParts = right ? right.split(":").filter(Boolean) : [];
                if (leftParts.some(p => p.length > 4) || rightParts.some(p => p.length > 4)) return null;
                const missing = 8 - (leftParts.length + rightParts.length);
                if (missing < 0) return null;
                const mid = new Array(missing).fill("0");
                const parts = [...leftParts, ...mid, ...rightParts].map(p => p || "0");
                if (parts.length !== 8) return null;
                return parts.map(p => p.padStart(4, "0").toUpperCase());
            } else {
                const parts = raw.split(":");
                if (parts.length !== 8) return null;
                if (parts.some(p => p.length === 0 || p.length > 4)) return null;
                return parts.map(p => p.padStart(4, "0").toUpperCase());
            }
        };

        // Detect IPv6 (rough)
        const looksLikeIPv6 = (s: string) => s.includes(":");

        // Convert expanded 8 hextets -> BigInt
        const ipv6PartsToBigInt = (parts: string[]) => {
            // each part is 4 hex digits -> 16 bits
            let acc = BigInt(0);
            for (let i = 0; i < 8; i++) {
                const v = BigInt(parseInt(parts[i], 16) & 0xFFFF);
                acc = (acc << BigInt(16)) + v;
            }
            return acc;
        };

        // Format canonical expanded IPv6 for storing/comparison (optional)
        const canonicalIPv6 = (parts: string[]) => parts.map(p => p.toUpperCase().padStart(4, "0")).join(":");

        // ---------- Range parse (we assume ipRange is already validated & saved) ----------
        /**
         * ipRange: string like "10.1.4.100 - 10.1.4.200" OR
         *                 "2001:db8::1 - 2001:db8::ff"
         * returns: { ok, family: "ipv4" | "ipv6", startNum, endNum }
         */
        const parseSavedRange = (ipRange: string) => {
            if (!ipRange) return { ok: false as const };

            const parts = ipRange.split("-");
            if (parts.length !== 2) return { ok: false as const };

            const s = parts[0].trim();
            const e = parts[1].trim();

            // IPv4 branch
            if (!looksLikeIPv6(s) && !looksLikeIPv6(e)) {
                if (!isValidIPv4(s) || !isValidIPv4(e)) return { ok: false as const };
                const sN = ipv4ToUint32(s);
                const eN = ipv4ToUint32(e);
                const start = Math.min(sN, eN);
                const end = Math.max(sN, eN);
                return { ok: true as const, family: "ipv4" as const, startNum: start, endNum: end };
            }

            // IPv6 branch
            const sExp = expandIPv6(s);
            const eExp = expandIPv6(e);
            if (!sExp || !eExp) return { ok: false as const };
            const sBig = ipv6PartsToBigInt(sExp);
            const eBig = ipv6PartsToBigInt(eExp);
            const startBig = sBig <= eBig ? sBig : eBig;
            const endBig = sBig <= eBig ? eBig : sBig;
            return { ok: true as const, family: "ipv6" as const, startBig, endBig };
        };
        interface IPValidation {
            valid: boolean;
            error: string;
        }

        const unavailableIPError = async (
            ipList: string | string[],
            changeType: string
        ): Promise<IPValidation> => {
            try {
                setLoading(true);

                const url = ENV_ROUTES.MODULE_MANAGEMENT;

                const data = {
                    tenant_name: partner || "default_value",
                    username,
                    firstLastName,
                    path: "/validate_ips_availability",
                    role_name: role,
                    Partner: partner,
                    request_received_at: getCurrentDateTime(),
                    access_token: token,
                    db_name: selectedDb,
                    ...metaData,
                    sessionID: sessionId,
                    change_type: changeType || "",
                    ip_list: ipList || [],
                    service_provider: service_provider || "",
                };

                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);

                // ❌ Invalid cases
                if (parsedData.flag === false || parsedData?.validation) {
                    return {
                        valid: false,
                        error: parsedData?.message || "Enter IP address within the available IP list",
                    };
                }

                // ✅ Success case
                return {
                    valid: true,
                    error: "",
                };

            } catch (error) {
                return {
                    valid: false,
                    error: "Enter IP address within the available IP list",
                };
            } finally {
                setLoading(false);
            }
        };

        const validateFieldIp = async (
            value: string[],
            ipRange: string | string[]
        ): Promise<IPValidation> => {

            // const v = String(value ?? "").trim();

            if (!value || value.length === 0) {
                return { valid: false, error: "Enter a valid IP address" };
            }

            return await unavailableIPError(value, change_type);
        };

        const validateFieldIp_ = (
            value: string,
            ipRange: string | string[]
        ): { valid: boolean; error: string } => {
            const v = String(value ?? "").trim();
            if (!v) return { valid: false, error: "Enter a valid IP address" };

            // Normalize list of allowed IPs
            const ips = (Array.isArray(ipRange) ? ipRange : [ipRange])
                .map((r) => String(r ?? "").trim())
                .filter((r) => r.length > 0);

            if (ips.length === 0) {
                return {
                    valid: false,
                    error: "Enter IP address within the available IP list",
                };
            }

            const isV6 = looksLikeIPv6(v);

            // ================= IPv6 =================
            if (isV6) {
                const expanded = expandIPv6(v);
                if (!expanded) {
                    return { valid: false, error: "Enter a valid IP address" };
                }

                const exists = ips.some((ip) => {
                    const ex = expandIPv6(ip);
                    return ex && ex.join(":") === expanded.join(":");
                });

                if (!exists) {
                    return {
                        valid: false,
                        error: "Enter IP address within the available IP list",
                    };
                }

                return { valid: true, error: "" };
            }

            // ================= IPv4 =================
            if (!isValidIPv4(v)) {
                return { valid: false, error: "Enter a valid IP address" };
            }

            const allowedSet = new Set(ips);

            if (!allowedSet.has(v)) {
                return {
                    valid: false,
                    error: "Enter IP address within the available IP list",
                };
            }

            return { valid: true, error: "" };
        };

        const parseCommaSeparatedIccidIp = (
            value: string,
            ipRanges: string[]
        ): IccidIpPair[] => {
            const parts = value
                .split(",")
                .map(v => v.trim())
                .filter(Boolean);

            const result: IccidIpPair[] = [];

            for (let i = 0; i < parts.length; i += 2) {
                const iccid = parts[i];
                const ip = parts[i + 1];

                if (!iccid || !ip) {
                    result.push({
                        iccid: iccid || "",
                        ip: ip || "",
                        ipValid: false,
                        ipError: "ICCID and IP must be entered in pairs",
                    });
                    continue;
                }

                // const { valid, error } = validateFieldIp(ip, ipRanges);

                // result.push({
                //     iccid,
                //     ip,
                //     ipValid: valid,
                //     ipError: error,
                // });
            }

            return result;
        };

        const handleContinue = async () => {
  if (isVerizon && isAllChangeType) {
    if (saveChanges) {
      setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
    }
    setIsValidated(true);
    setValidationTrigger();
    return;
  }
  let hasError = false;
  const newErrors: string[] = [];

  /* ---------- BASIC REQUIRED CHECKS ---------- */
  if (!isTeal && !isVerizon) {
    if (!selectedPDP) {
      hasError = true;
      setPdpError("PDP is required.");
    } else setPdpError("");

    if (!isTelegence && !apn) {
      hasError = true;
      setApnError("APN is required.");
    } else setApnError("");

    if (isTelegence && !billingAccountNumber) {
      hasError = true;
      setBANError("Billing account number is required.");
    } else setBANError("");
  }

  if (!isAllChangeType) {
    if (!rawIccidInput && !rawSubscriberNoInput) {
      setErrorMessage("Please fill ICCID field or MSISDN field.");
      return;
    }
    setErrorMessage("");
  }

  if (!isAllChangeType) {
    const isSubscriberMode = !!rawSubscriberNoInput && !rawIccidInput;
    const inputText = isSubscriberMode ? rawSubscriberNoInput : rawIccidInput;

    const label = isSubscriberMode ? "Subscriber Number" : "ICCID";
    const minLength = isSubscriberMode ? 10 : 14;
    const maxLength = isSubscriberMode ? 18 : 22;

    const lines = inputText
      .split("\n")
      .map(l => l.trim())
      .filter(Boolean);

    const seen = new Map<string, number>();
    const ipList:any = []


            /* ---------- LINE VALIDATION ---------- */
    lines.forEach((line, index) => {
      const lineNo = index + 1;
      const parts = line.split(",").map(p => p.trim());

      if (parts.length !== 2) {
        newErrors.push(
          `Line ${lineNo}: Invalid format. Use "${label},IP Address"`
        );
        return;
      }

      const [id, ip] = parts;

                /* ---- ID ---- */
      if (!id) {
        newErrors.push(`Line ${lineNo}: ${label} is required`);
      } else if (!/^\d+$/.test(id)) {
        newErrors.push(`Line ${lineNo}: ${label} must contain numbers only`);
      } else if (id.length < minLength || id.length > maxLength) {
        newErrors.push(
          `Line ${lineNo}: ${label} must be between ${minLength} and ${maxLength} digits`
        );
      } else if (seen.has(id)) {
        newErrors.push(
          `Line ${lineNo}: Duplicate ${label} (already in Line ${seen.get(id)})`
        );
      } else {
        seen.set(id, lineNo);
      }

      /* ---- IP validation ---- */
      if (!ip) {
        newErrors.push(`Line ${lineNo}: IP Address is required`);
      } else {
        if (!ipList.includes(ip)) {
            ipList.push(ip);
          }
        // const ipResult = validateFieldIp(ip, IPOptions || []);
        // if (!ipResult.valid) {
        //   const clean = ipResult.error.replace(/^Line\s*\d+:\s*/i, "");
        //   newErrors.push(`Line ${lineNo}: ${clean}`);
        // }
      }
    });
    const ipResult: any = await validateFieldIp(ipList, IPOptions || []);
    if (!ipResult?.valid) {
        errors.push(
            ipResult?.result || "Enter IP address within the available IP list"
        );
    }

    /* ---------- BULK LIMIT ---------- */
    if (lines.length > bulkChangeLimit) {
      newErrors.push(
        `This request exceeds the allowed record limit of ${bulkChangeLimit}`
      );
    }
  }

  const isValid =
    newErrors.length === 0 &&
    !errorMessage &&
    !IpError &&
    !hasError;

  /* ---------------- SUCCESS PATH ---------------- */
  if (isValid) {
    setErrors([]);

                /* ---------- SUBMIT ---------- */
    if (!isAllChangeType) {
      const writes_flag = await fetchCarrierWritesFlag();
      if (writes_flag) {
        Modal.confirm({
          title: "Carrier API Enabled",
          content:
            "Carrier API settings are enabled. Submitting now will trigger the Carrier API directly. Do you want to proceed?",
          centered: true,
          okText: "Submit",
          onOk: () => {
            onsubmit();
            submitCarrierStatus(writes_flag);
          },
          onCancel: onBack,
        });
      } else {
        onsubmit();
      }
    } else {
      if (saveChanges) {
        setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
      }

      setIsValidated(true);
      setValidationTrigger();
      setBANError("");
      setPdpError("");
      setIpError("");
      setCarrierRatePlanError("");
      setCommPlanError("");
      setErrors([]);
    }

    return;
  }

  /* ---------------- FAILURE PATH ---------------- */
  setErrors(newErrors);

  if (isAllChangeType) {
    setsuccessFullChangeTypes(
      successFullChangeTypes.filter((c: string) => c !== activeChange)
    );

    if ((!billingAccountNumber && !selectedPDP) || !saveChanges) {
      setIsValidated(true);
      setValidationTrigger();
      setErrors([]);
      setBANError("");
      setPdpError("");
      setIpError("");
    } else {
      setIsValidated(false);
      setValidationTrigger();
    }
  }
};

        const fetchCarrierWritesFlag = async () => {
            let parsedData: any
            const url = ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                username,
                path: "/get_writes_enable_for_service_provider",
                role_name: role,
                parent_module: "Sim Management",
                module_name: "Inventory",
                service_provider: service_provider || "",
                ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" },
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                environment: "BETA",
                change_type: change_type,
            };

            try {
                setLoading(true);
                const response = await axios.post(url, { data });
                parsedData = JSON.parse(response.data.body);

                if (parsedData.flag === true) {
                    const write_is_enabled = parsedData?.write_is_enabled || false;
                    // setWritesFlag(write_is_enabled);
                    return write_is_enabled;
                }
            } catch (error) {
                console.error("Error fetching data:", error);
                return false; // fallback in case of error
            } finally {
                // setLoading(false);
            }
        };
        const submitCarrierStatus = async (write_is_enabled: boolean) => {
            let parsedData: any
            const url = ENV_ROUTES.SIM_MANAGEMENT;
            const iccidList = await getIccidList()
            const data = {
                tenant_name: partner || "default_value",
                username,
                path: "/insert_carrier_status_validation_audit",
                role_name: role,
                parent_module: "Sim Management",
                module_name: "Inventory",
                service_provider: service_provider || "",
                ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" },
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                environment: "BETA",
                msisdn: [],
                iccid: iccidList,
                change_type: change_type,
                write_is_enabled: write_is_enabled,
            };

            try {
                // setLoading(true);
                const response = await axios.post(url, { data });
                parsedData = JSON.parse(response.data.body);

                if (parsedData.flag === true) {

                }
            } catch (error) {
                console.error("Error fetching data:", error);
            } finally {
                // setLoading(false);
            }
        };
        const fetchDevices = async (devices_list: any[], deviceKey: string,IdsIpMap:any) => {
            try {
                setLoading(true);
                const url =
                    ENV_ROUTES.BULKCHANGE_PROCESSOR;
                const data = {
                    tenant_name: partner || "default_value",
                    username: username,
                    firstLastName: firstLastName,
                    path: "/get_standard_iccid_msisdn_data",
                    role_name: role,
                    Partner: partner,
                    request_received_at: getCurrentDateTime(),
                    access_token: token,
                    db_name: selectedDb,
                    ...metaData,
                    sessionID: sessionId,
                    service_provider: service_provider,
                    ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" },
                    change_type: change_type,
                    [deviceKey]: devices_list || [],
                    ...{ iccid_ip_map: IdsIpMap || {} },

                };

                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);
                if (parsedData.flag === false) {
                    // setLoading(false);
                    Modal.error({
                        title: 'Submit Error',
                        content: parsedData.message || 'An error occurred while submitting data. Please try again.',
                        centered: true,
                    });
                    return []
                } else {
                    const responseKey = deviceKey === "iccids" ? "msisdns" : "iccids"
                    const devices = parsedData?.[responseKey] || []
                    console.log("devices", devices)
                    // return devices
                return {
                     iccids: parsedData?.iccids || parsedData?.[responseKey] || [],
                    IdsIpMap: parsedData?.iccids_ip_map || {},
                }
                  // setLoading(false);
                }
            } catch (error) {
                Modal.error({
                    title: 'Submit Error',
                    content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting data. Please try again.',
                    centered: true,
                });
                return []
                // setLoading(false);
            }
            finally {
                // setLoading(false)
            }
        };

        type GetIccidListResult = {
          iccids: string[];
          IdsIpMap: any;
        };


        const getIccidList = async (IdsIpMap?:any): Promise<GetIccidListResult> => {
            // Pick devices based on subscriberNumber or iccids
            const devices_ = subscriberNumber ? subscriberNumber : iccids;

            // Find matching device type from the map
            const matchedDeviceTypeItem = simIdentifierMap.find((item: any) => {
                return (
                    item.service_provider === service_provider &&
                    item.change_type === change_type
                );
            });
            const matchedDeviceType = matchedDeviceTypeItem?.sim_identifier || ""
            // Decide expected type
            const selectDeviceType = subscriberNumber ? "msisdns" : "iccids";
            // Split devices into a list
            let iccidList = devices_
                .split(/\s*[\n,]\s*/)
                .map((line) => line.trim())
                .filter((line) => line.length > 0);
            

            if (matchedDeviceType !== selectDeviceType) {
              const result: any = await fetchDevices(
                iccidList,
                selectDeviceType,
                IdsIpMap
              );

              iccidList = result?.iccids;
              IdsIpMap = result?.IdsIpMap;
            }

            return {
              iccids: iccidList,
              IdsIpMap,
            };
        };
        const call_2_0_submit = async (parsedData: any, payload: any,isRouteCall: boolean) => {
            try {
                const payload_data = { ...payload }
                const url = ENV_ROUTES.BULKCHANGE_PROCESSOR;
                if (providerName.toLowerCase().includes("telegence")) {
                    payload_data["msisdns"] = payload_data?.iccids;
                    delete payload_data["iccids"];
                }
                const payloadData = {
                    ...payload_data,
                    path: "/bulk_change_processor",
                    request_received_at: getCurrentDateTime(),
                    bulk_change_id: parsedData?.bulk_chnage_id_20,
                }
                const data = { ...payloadData };
                if (!isRouteCall) {
                    return data
                }
                const response = await axios.post(url, { data });
                const responseData = JSON.parse(response.data.body);
                if (responseData.flag === false) {
                    console.log("Failure: 2.0 Bulk change update failed.");
                } else {
                    console.log("Success: 2.0 Bulk change update successful.");
                }
            }
            catch (error) {
                console.error("Error running DB script:", error);
            } finally {
                setLoading(false);
            }
        }

        const call_2_0_sync = async (parsedData: any) => {
            try {
                const runDbScriptUrl = ENV_ROUTES.SIM_MANAGEMENT;
                const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
                const runDbScriptData = {
                    tenant_name: partner || "default_value",
                    username: username,
                    firstLastName: firstLastName,
                    path: "/update_bulk_change_tables_10",
                    role_name: role,
                    module_name: "Bulk Change",
                    access_token: token,
                    db_name: selectedDb,
                    ...metaData,
                    sessionID: sessionId,
                    request_received_at: getCurrentDateTime(),
                    Partner: partner,
                    // service_provider_id: service_provider_id_,
                    // bulkchange_id: parsedData?.bulkchange_id?.id,
                    // data: parsedData?.data,
                    data: {
                        bulk_change_id: parsedData?.bulk_chnage_id_20,
                    },
                    is_update: false,
                    // bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
                };

                const runDbScriptResponse = await axios.post(runDbScriptUrl, { data: runDbScriptData });
                const runDbScriptResponseData = JSON.parse(runDbScriptResponse.data.body);

                if (runDbScriptResponseData.flag === false) {
                    console.error("Data Fetch Error: " + runDbScriptResponseData.message);
                } else {
                    console.log("Success: Bulk update successful.");
                }
            }
            catch (error) {
                console.error("Error running DB script:", error);
            } finally {
                setLoading(false);
            }
        }
        const bulkChangeInsert = async (payload: any) => {
            let partner_name = partner
            let db_name_ = selectedDb
            try {
                const url = ENV_ROUTES.SIM_MANAGEMENT;
                const data = {
                    tenant_name: partner_name || "default_value",
                    username: username,
                    firstLastName: firstLastName,
                    path: "/get_bulk_change_insertion",
                    role_name: role,
                    module_name: "Bulk Change History",
                    service_provider_name: service_provider,
                    ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" },
                    change_type: change_type,
                    access_token: token,
                    db_name: selectedDb,
                    ...metaData,
                    sessionID: sessionId,
                    request_received_at: getCurrentDateTime(),
                    Partner: partner_name,
                };

                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);

                if (parsedData.flag === false) {
                    console.error("Error fetching bulk change data:", parsedData.message ||
                        "An error occurred while fetching bulk change data. Please try again.");
                    return false
                } else {
                    const statusFlag = parsedData?.bulk_change_data?.status || "";
                    const response_data = parsedData?.bulk_change_data?.bulk_change_data || "{}";
                    const parsedResp = JSON.parse(response_data)
                    console.log("status_flag", statusFlag)
                    const status_flag = statusFlag ? (statusFlag).toLowerCase() : ""

                    if (status_flag && status_flag === "pending") {
                        return false
                    }
                    else if (status_flag && status_flag === "success") {
                        call_2_0_submit(parsedResp, payload,true)
                        call_2_0_sync(parsedResp)
                        return true
                    }
                    else if (status_flag && status_flag === "error") {
                        Modal.error({
                            title: 'Submit Error',
                            content: parsedData.message || 'An error occurred while submitting. Please try again.',
                            centered: true,
                        });
                        return true
                    }
                    else {
                        return false
                    }
                }
            } catch (error) {
                console.error("Error fetching auto refresh data:", error);
                return false
            } finally {
            }
        };
        const bulkChangePolling = async (data: any) => {
            const result = await bulkChangeInsert(data);
            if (!result) {
                setTimeout(() => bulkChangePolling(data), 5000); // Try again after 5 seconds
            } else {
                removeExport("bulkChangeInsert");
                console.log("Auto-refresh complete.");
            }
            // if (window.location.pathname.includes("/sim_management/bulk_change")) {
            //     window.location.reload();
            // }
        };
        const getCurrentDateTimeFormatted = (): string => {
            const now = new Date();

            const pad = (num: number) => num.toString().padStart(2, '0');

            const month = pad(now.getMonth() + 1); // 10 → October
            const day = pad(now.getDate());        // 02
            const year = now.getFullYear();        // 2025

            const hours = pad(now.getHours());
            const minutes = pad(now.getMinutes());
            const seconds = pad(now.getSeconds());

            return `${month}-${day}-${year} ${hours}:${minutes}:${seconds}`;
        };
        const buildIccidIpMap = (rawIccidInput: string) => {
            const map: Record<string, string> = {};

            rawIccidInput
                .split(/\n/)
                .map(l => l.trim())
                .filter(Boolean)
                .forEach(line => {
                    const [iccid, ip] = line.split(",").map(v => v?.trim());

                    if (iccid && ip) {
                        map[iccid] = ip;
                    }
                });

            return map;
        };

        const onsubmit = async () => {
            let data: any
            let IdsIpMap_: any
            IdsIpMap_ = isAllChangeType ? allChangeTypesDevices.iccid_ip_map :buildIccidIpMap(rawIccidInput ? rawIccidInput : rawSubscriberNoInput);
            const { iccids, IdsIpMap }  = await getIccidList(IdsIpMap_);
            
            

            try {
                let changedData = {}
                if (isTelegence) {
                    changedData = {
                        pdpName: selectedPDP || "",
                        billingAccountNumber: billingAccountNumber || "",
                        subscriber: [
                            {
                                subscriberNumber: "",
                                ipAddressRecord: {
                                    ipAddress: IpAddress || "",
                                    ipAddressCode: "",
                                    ipAddressType: ""
                                },
                                effectiveDate: getCurrentDateTimeFormatted() || getCurrentDateTime(),
                            }
                        ]
                    };
                }
                else if (isVerizon) {
                    changedData = {
                        ipAddress: IpAddress || "",
                    }
                }
                else if (isTeal) {
                    changedData = {}
                }
                else {
                    changedData = {
                        ipv6Address: IpAddress || "",
                        apn: apn || "",
                        pdpId: selectedPDP || ""
                    }

                }

                setLoading(true);

                // Prepare payload for the first API
                const url = ENV_ROUTES.SIM_MANAGEMENT;
                data = {
                    tenant_name: partner || "default_value",
                    path: "/update_bulk_change_data",
                    role_name: role,
                    username: username,
                    request_received_at: getCurrentDateTime(),
                    access_token: token,
                    db_name: selectedDb,
                    ...metaData,
                    sessionID: sessionId,
                    service_provider: service_provider,
                    ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" },
                    change_type: change_type,
                    created_by: firstLastName,
                    iccids: iccids || [],
                    iccid_ip_map: IdsIpMap ||'',
                    changed_data: { changedData: { ...changedData } }

                };

                // Send request to the first API
                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);

                if (parsedData.flag === false) {
                    setLoading(false);
                    Modal.error({
                        title: 'Submit Error',
                        content: parsedData.message || 'An error occurred while submitting. Please try again.',
                        centered: true,
                    });
                    return;
                }

                const bulkrow_ = parsedData?.bulkchange_id || {};
                const bulkRow: any = { row: bulkrow_ };
                setBulkRow(bulkRow);
                localStorage.setItem('bulk_row', JSON.stringify(bulkRow || "{}"));
                if (bulkRow) {
                    if (!isAllChangeType) {
                        router.push(`/sim_management/bulk_history`);
                    }
                }

                if (!isAllChangeType) {
                    call_2_0_submit(parsedData, data, true);
                    call_2_0_sync(parsedData);
                }
                else {
                    const payload_2_0_: any = await call_2_0_submit(parsedData, data, false)
                    set_all_2_0_payloads((prev: any) => ({
                        ...prev,
                        [change_type]: { ...payload_2_0_ }
                    }));
                }
            } catch (error) {
                const isTelegence = providerName.toLowerCase().includes("telegence");
                const isWebbing = providerName.toLowerCase().includes("webbing");
                const isVerizon = (providerName.toLowerCase().includes("verizon") || providerName.toLowerCase().includes("vzn") || providerName.toLowerCase().includes("vzwcr") || providerName.toLowerCase().includes("2215-so01"));
                const isPod19 = providerName.toLowerCase().includes("pod19");
                const isPondIOT = providerName.toLowerCase().includes("pond");
                if (switch_user_2_0 === "True" && (isTelegence || isWebbing || isVerizon || isPod19 || isPondIOT)) {
                    onClose()
                    setLoading(false)
                    addExport("bulkChangeInsert", "Bulk Change Submission");
                    bulkChangePolling(data)
                }
                else {
                    Modal.error({
                        title: 'Submit Error',
                        content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting. Please try again.',
                        centered: true,
                    });
                }
            } finally {
                setLoading(false);
            }
        };

        // const returnUpdatedValue = () =>{
        //     return (
        //     <Tooltip title={`${billingAccountNumber}`}>
        //         <span>
        //             {billingAccountNumber}
        //         </span>
        //     </Tooltip>)
        // }

        const returnUpdatedValue = () => {
            return (
                <div className="flex flex-col gap-2">
                    {isTelegence ? (
                        <div className="flex grid grid-cols-2 ">
                            {/* <span className="font-semibold">Billing Account Number:</span>
                            <span>{billingAccountNumber}</span>
                            <span className="font-semibold">PDP Name:</span>
                            <span>{selectedPDP}</span> */}
                            <span className="font-semibold">IP Address:</span>
                            {ipAddresses.join(", ")}
                        </div>
                    ) : (isTeal || isVerizon) ? (
                        <div className="flex grid grid-cols-2 ">
                            <span className="font-semibold">Carrier Rate Plan:</span>
                            <span>{carrierRatePlan}</span>
                        </div>
                    ) : (
                        <div className="flex grid grid-cols-2 ">
                            <span className="font-semibold">Communication Plan:</span>
                            <span>{commPlan}</span>
                        </div>
                    )}

                </div>
            )
        }
        useImperativeHandle(ref, () => ({
            runValidation: handleContinue,
            runSubmit: onsubmit,
            returnUpdate: returnUpdatedValue,
            IPOptions:PdpIPOptions
        }));

        const fetchIPAddress = async (pdpName: any) => {
            try {
                setLoading(true)
                const url =
                    ENV_ROUTES.SIM_MANAGEMENT;
                const data = {
                    tenant_name: partner || "default_value",
                    username: username,
                    firstLastName: firstLastName,
                    path: "/get_ipdetails_by_pdpname",
                    role_name: role,
                    Partner: partner,
                    request_received_at: getCurrentDateTime(),
                    access_token: token,
                    db_name: selectedDb,
                    ...metaData,
                    sessionID: sessionId,
                    pdp_name: pdpName || "",
                };

                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);
                if (parsedData.flag === false) {
                    Modal.error({
                        title: 'Submit Error',
                        content: parsedData.message || 'An error occurred while submitting data. Please try again.',
                        centered: true,
                    });
                } else {
                    const ip_options_map = parsedData?.ip_addresses || []
                    setIPAddressMap(ip_options_map)
                    const ip_options = ip_options_map.map((opt: any) => (opt?.ipAddress || ""))
                    setIPOptions(ip_options)
                }
            } catch (error) {
                Modal.error({
                    title: 'Submit Error',
                    content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching BANs. Please try again.',
                    centered: true,
                });
            }
            finally {
                setLoading(false)
            }
        };
        const handleSelectRatePlan = (selectedOption: any) => {
            if (selectedOption) {
                const value = selectedOption?.value
                setCarrierRatePlan(value)
            }
            else {
                setCarrierRatePlan(null)

            }
        };
        const handleCommunicationPlan = (selectedOption: any) => {
            if (selectedOption) {
                const value = selectedOption?.value
                setCCommPlan(value)
            }
            else {
                setCCommPlan(null)

            }
        };

        const handlePDPNameSelect = (selectedOption: any) => {
            setIpAddress(null)
            if (selectedOption) {
                const value = selectedOption?.value
                setSelectedPDP(value)
                fetchOptionsMappings(value) //to fetch Available IP's for the selected PDP

                const ip_options = pdpIpMap[value] || []
                setIPOptions(ip_options)
                setPdpIPOptions(ip_options)
            }
            else {
                setSelectedPDP(null)
                setIPOptions([])

            }
        };

        const handleIPAddressSelect = (selectedOption: any) => {
            if (selectedOption) {
                const value = selectedOption?.value
                setIpAddress(value)
            }
            else {
                setIpAddress(null)

            }
        };

        const handleAPNSelect = (selectedOption: any) => {
            if(!isAllChangeType && !SelectedPDPGlobal){
                setSelectedPDP(null) // do not clear for all change types and if pdp is selected in devices screen
            }
            if (selectedOption) {
                const value = selectedOption?.value
                setApn(value)
                const pdp_options = apnPdpMap[value] || []
                setPdpOptions(pdp_options)
            }
            else {
                setApn(null)
                setPdpOptions([])
            }
        };

        const handleSelectBAN = (selectedOption: any | null) => {
            if (selectedOption) {
                const value = selectedOption?.value
                setBillingAccountNumber(value)

            }
            else {
                setBillingAccountNumber(undefined); // Clear the selection
            }
        };
        const handlePreviewOpen = async () => {
            setPreviewModal(true)
        };
        if (loading) {
            return (
                <>
                    <div className="flex justify-center items-center h-[400px]">
                        <Spin size="large" />
                    </div>
                </>
            );
        }

        return (
            <>
             { !isAllChangeType && (
                <UploadComponent2
                    service_provider={service_provider}
                    change_type={"Change Private Static IP Address"}
                />
             )}
            <div className="max-h-[600px] overflow-auto p-4">
                <>
                    {isAllChangeType && (
                        <div className="flex justify-end px-4">
                            <span className="mr-2 font-semibold">Save Changes</span>
                            <Checkbox
                                checked={saveChanges}
                                onChange={(e) => {
                                    if (!e.target.checked) {
                                        setsuccessFullChangeTypes(
                                            successFullChangeTypes.filter((c: any) => c !== activeChange)
                                        );
                                    }
                                    setSaveChanges(e.target.checked)
                                }}
                                className="custom-checkbox"
                            >

                            </Checkbox>
                        </div>
                    )}
                    <>

                        {!isTeal && (
                            <div className={`${!isAllChangeType ? "flex flex-col space-y-4 mb-4" : "flex grid grid-cols-2 gap-4"}`}>
                                <>
                                        <>
                                            {(isTelegence) && (
                                                <>
                                                    {/* Billing Account Number */}
                                                    <div className={`${!isAllChangeType ? "flex flex-col space-y-2" : ""}`}>
                                                        <label htmlFor="billingAccountNumber" className={`${!isAllChangeType ? " font-semibold" : "field-label"}`}>
                                                            Billing Account Number
                                                            <span className="text-red-500">*</span>
                                                        </label>
                                                        {BANOptions.length === 0 ? (
                                                            <Input
                                                                id="billingAccountNumber"
                                                                // placeholder="Enter Billing Account Number"
                                                                value={billingAccountNumber}
                                                                onChange={(e) => setBillingAccountNumber(e.target.value)}
                                                                className="input" />
                                                        ) : (
                                                            <Select
                                                                id="billingAccountNumber"
                                                                placeholder="Select Carrier Rate Plan"
                                                                options={BANOptions.length > 0 ? BANOptions.map((option: string) => ({
                                                                    label: option,
                                                                    value: option,
                                                                })) : [{ value: 'No options', label: 'No options' }]}
                                                                value={{ label: billingAccountNumber, value: billingAccountNumber }}
                                                                onChange={handleSelectBAN}
                                                                isClearable
                                                                className="w-full"
                                                                styles={DropdownStyles}
                                                                menuPortalTarget={document.body}
                                                                menuPosition="fixed"
                                                                menuPlacement="auto"
                                                            />
                                                        )}
                                                        {(BANError && isAllChangeType) && (
                                                            <span className="text-red-500">{BANError}</span>
                                                        )}
                                                    </div>
                                                    {(BANError && !isAllChangeType) && (
                                                        <span className="text-red-500">{BANError}</span>
                                                    )}
                                                </>
                                            )}

                                            {(!isTelegence) && (
                                                <>
                                                    {/* APN */}
                                                    <div className={`${!isAllChangeType ? "flex flex-col space-y-2" : ""}`}>
                                                        <label htmlFor="pdpName" className={`${!isAllChangeType ? "w-1/3 font-semibold" : "field-label"}`}>
                                                            APN
                                                            <span className='text-red-500'>*</span>
                                                        </label>
                                                        <Select
                                                            id="pdpName"
                                                            placeholder="Select PDP Name"
                                                            options={apnOptions.map((option: string) => ({
                                                                label: option,
                                                                value: option,
                                                            }))}
                                                            value={{ label: apn, value: apn }}
                                                            onChange={handleAPNSelect}
                                                            styles={isAllChangeType && !!SelectedAPNGlobal ? NonEditableDropdownStyles :DropdownStyles}
                                                            className="w-full"
                                                            isClearable
                                                            menuPortalTarget={document.body}
                                                            menuPosition="fixed"
                                                            menuPlacement="auto"
                                                            isDisabled={isAllChangeType && !!SelectedAPNGlobal}
                                                        />
                                                        {(apnError && isAllChangeType) && (
                                                            <span className="text-red-500">{apnError}</span>
                                                        )}
                                                    </div>
                                                    {(apnError && !isAllChangeType) && (
                                                        <span className="text-red-500">{apnError}</span>
                                                    )}
                                                </>
                                            )}
                                            
                                            {/* PDP Name */}
                                            <div className={`${!isAllChangeType ? "flex flex-col space-y-2" : ""}`}>
                                                <label htmlFor="pdpName" className={`${!isAllChangeType ? "w-1/3 font-semibold" : "field-label"}`}>
                                                    {`${isTelegence ? "PDP Name" : "PDP ID"}`}
                                                    <span className='text-red-500'>*</span>
                                                </label>
                                                <Select
                                                    id="pdpName"
                                                    placeholder={`Select ${isTelegence ? "PDP Name" : "PDP ID"}`}
                                                    options={pdpOptions.map((option: string) => ({
                                                        label: option,
                                                        value: option,
                                                    }))}
                                                    value={{ label: selectedPDP, value: selectedPDP }}
                                                    onChange={handlePDPNameSelect}
                                                    styles={isAllChangeType && !!SelectedPDPGlobal ? NonEditableDropdownStyles :DropdownStyles}
                                                    className="w-full"
                                                    isClearable
                                                    menuPortalTarget={document.body}
                                                    menuPosition="fixed"
                                                    menuPlacement="auto"
                                                    isDisabled={isAllChangeType && !!SelectedPDPGlobal}
                                                />
                                                {((pdpError || noPdpsError) && isAllChangeType) && (
                                                    <span className="text-red-500">{noPdpsError ? noPdpsError :pdpError}</span>
                                                )}
                                            </div>
                                            {((pdpError || noPdpsError) && !isAllChangeType) && (
                                                <span className="text-red-500">{noPdpsError ? noPdpsError :pdpError}</span>
                                            )}
                                            {(!selectedPDP && !isAllChangeType && !pdpError && (
                                                <span className="text-blue-500">* Please select a PDP to view available IP addresses.</span>
                                            ))}

                                            

                                        </>
                                    {/* IP Address */}
                                    {/* <div className={`${!isAllChangeType ? "flex flex-col space-y-2" : ""}`}> */}
                                        {/* <div className="flex items-center justify-between">
                                            <label
                                                htmlFor="ipAddress"
                                                className={`${!isAllChangeType ? "w-1/3 font-semibold" : "field-label"}`}
                                            >
                                                Private Static IP Address<span className='text-red-500'>*</span>
                                            </label>

                                            <Tooltip title="Preview or view IP details">
                                                <InfoIcon
                                                    className="h-5 w-5 text-gray-500 cursor-pointer"
                                                    onClick={handlePreviewOpen}
                                                />
                                            </Tooltip>
                                        </div> */}
                                        {/* <Select
                                            id="ipAddress"
                                            placeholder="Select PDP Name"
                                            options={IPOptions.map((option: string) => ({
                                                label: option,
                                                value: option,
                                            }))}
                                            value={{ label: IpAddress, value: IpAddress }}
                                            onChange={handleIPAddressSelect}
                                            styles={DropdownStyles}
                                            className="w-full"
                                            isClearable
                                        /> */}
                                        {/* <Input
                                            id="ipAddress"
                                            placeholder="Enter IP Address"
                                            value={IpAddress || ""}
                                            onChange={(e) => {
                                                const v = e.target.value;
                                                setIpAddress(v);

                                                const res = validateFieldIp(v, IPOptions || []);
                                                setIpError(res.error);
                                            }}
                                            onBlur={(e) => {
                                                const res = validateFieldIp(e.target.value, IPOptions || []);
                                                setIpError(res.error);
                                            }}
                                            className="input"
                                        /> */}
                                        {/* <PreviewModal
                                            service_provider={service_provider}
                                            change_type={change_type}
                                            openPreviewModal={openPreviewModal}
                                            setPreviewModal={setPreviewModal}
                                        /> */}
                                       {/* <div className="text-sm text-blue-500 mt-1">
                                            <span className="block"> Enter IP address within the given ip range: </span>
                                            {IPOptions.map((opt: any) => {
                                                return <span className="font-mono font-semibold block">{opt || ""}</span>

                                            })}
                                        </div>
                                        */}
                                        {/* {(IpError && isAllChangeType) && (
                                            <span className="text-red-500">{IpError}</span>
                                        )}
                                    </div> */}
                                    {/* {(IpError && !isAllChangeType) && (
                                        <span className="text-red-500">{IpError}</span>
                                    )} */}
                                </>
                            </div>
                        )}
                        {(!isAllChangeType || (isAllChangeType && isVerizon)) && (
                            <div className={`${!isAllChangeType?"flex flex-col space-y-4 my-4":"flex grid grid-cols-2 gap-4"}`}>
                                <div className= "flex flex-col space-y-2">
                                    <div className="flex items-center justify-between">

                                        <label htmlFor="iccids" className="font-semibold">{`Devices (Start typing ICCID and IP Address)`}<span className='text-red-500'>*</span></label>
                                        {!isAllChangeType && selectedPDP && (<Tooltip title="Preview or view IP details">
                                            <InfoIcon
                                                className="h-5 w-5 text-gray-500 cursor-pointer"
                                                onClick={handlePreviewOpen}
                                            />
                                        </Tooltip>)}
                                    </div>
                                    <Input.TextArea
                                        id="iccids"
                                        rows={4}
                                        placeholder="Enter ICCID,IP per line"
                                        value={rawIccidInput}
                                        onChange={(e) => {
                                            const value = e.target.value;

                                            // 1️⃣ keep what user types (ICCID,IP)
                                            setRawIccidInput(value);

                                            // 2️⃣ extract ONLY ICCIDs
                                            const onlyIccids = value
                                                .split("\n")
                                                .map(line => line.split(",")[0]?.trim())
                                                .filter(Boolean)
                                                .join("\n");

                                            setIccids(onlyIccids);

                                            setErrors([]);
                                            setErrorMessage("");
                                            if (value) setSubscriberNumber(""); setRawSubscriberNoInput("");
                                        }}

                                        disabled={!!subscriberNumber || isAllChangeType}
                                    />
                                    <PreviewModal
                                        service_provider={service_provider}
                                        change_type={change_type}
                                        openPreviewModal={openPreviewModal}
                                        setPreviewModal={setPreviewModal}
                                        selectedPDP ={selectedPDP || ""}
                                    />
                                </div>
                                {(IpError && !isAllChangeType) && (
                                        <span className="text-red-500">{IpError}</span>
                                    )}

                                <div className="flex flex-col space-y-2">
                                    <label htmlFor="msisdns" className="font-semibold">{`Devices (Start typing Subscriber Number and IP Address)`}<span className='text-red-500'>*</span></label>
                                    <Input.TextArea
                                        id="msisdns"
                                        rows={4}
                                        placeholder={"Enter Subscriber Number,IP per line"}
                                        value={rawSubscriberNoInput}
                                        onChange={(e) => {
                                            const value = e.target.value;

                                            // 1️⃣ keep what user types (ICCID,IP)
                                            setRawSubscriberNoInput(value);

                                            // 2️⃣ extract ONLY ICCIDs
                                            const onlySubscriberNo = value
                                                .split("\n")
                                                .map(line => line.split(",")[0]?.trim())
                                                .filter(Boolean)
                                                .join("\n");

                                            setSubscriberNumber(onlySubscriberNo);

                                            setErrors([]);
                                            setErrorMessage("");
                                            if (value) setIccids("");setRawIccidInput("")
                                        }}
                                        disabled={!!iccids || isAllChangeType}
                                    />
                                    {errors.some((err) => err) && (
                                        <div className="mt-2 space-y-1">
                                            {errors.map((err, idx) =>
                                                err ? (
                                                    <div key={idx} className="text-red-500 text-sm">
                                                       {err}
                                                    </div>
                                                ) : null
                                            )}
                                        </div>
                                    )}
                                </div>
                                {errorMessage && <div className="text-red-500 text-sm">{errorMessage}</div>}
                            </div>
                        )}

                        {!isAllChangeType && (
                            <div className="flex justify-center space-x-4 mt-4">
                                <button onClick={onBack} className="cancel-btn">
                                    Back
                                </button>
                                <button onClick={handleContinue} className="save-btn">
                                    Submit
                                </button>
                            </div>
                        )}
                    </>
                </>
            </div >
            </>
        );
    }
)

export default PrivateNetwork;