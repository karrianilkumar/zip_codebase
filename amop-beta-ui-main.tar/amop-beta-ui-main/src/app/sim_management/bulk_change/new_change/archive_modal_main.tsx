/* eslint-disable react/jsx-key */
"use client";

import { FC, useState, useEffect, forwardRef, useImperativeHandle, useRef  } from "react";
import { Input, Button, Modal, Spin, Checkbox, Tooltip } from "antd";
import { InfoCircleOutlined, MinusCircleOutlined } from "@ant-design/icons";
import { ArrowLeftIcon, ArrowRightIcon } from "@heroicons/react/24/outline";
import ArchiveSummaryContent from "./archive_modal_summary";
import React from "react";
import { useFeatureStore } from "../../inventory/featureStore";
import { useAuth } from "@/app/components/auth_context";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { useAllChangeTypesStore } from "@/app/stores/allChangeTypesStore";
import { ArchiveSummaryContentRef } from "./archive_modal_summary";
import { PerformanceLogStore } from "@/app/stores/performance_matrix_store";

interface ArchiveContentProps {
    onContinue: (iccids: string[]) => void;
    onBack: () => void;
    dropdown: any;
    service_provider: any;
    change_type: any
    onCancel: () => void;
}

export interface ArchiveContentRef {
  runValidation: () => Promise<void> | void;
  runSubmit: () => Promise<void> | void;
  returnUpdate: () => React.ReactNode | Promise<React.ReactNode>; 
}

const ArchiveContent = forwardRef<ArchiveContentRef, ArchiveContentProps>(
  ({ onContinue, onBack, dropdown, service_provider, change_type, onCancel }, ref) => {
    const [iccids, setIccids] = useState<string[]>([""]);
    const [msisdns, setMsisdns] = useState<string[]>([""]);
    const [selectedDevices, setSelectedDevices] = useState<string[]>([]);
    const [errors, setErrors] = useState<string[]>([]);
    const [MsisdnErrors, setMsisdnErrors] = useState<string[]>([]);
    const [isModalVisible, setIsModalVisible] = useState(false);
    const [bulkInput, setBulkInput] = useState("");
    const [bulkMSISDNInput, setBulkMSISDNInput] = useState("");
    const [bulkError, setBulkError] = useState<string | null>(null);
    const [showSummary, setShowSummary] = useState(false);
    const [previousContent, setPreviousContent] = useState<string[]>([]);
    const [previousMSISDNContent, setPreviousMSISDNContent] = useState<string[]>([]);
    const { bulkChangeLimit, simIdentifierMap } = useFeatureStore();
    const { username, role, partner, token, selectedDb,metaData ,firstLastName, sessionId } = useAuth();
    const [loading, setLoading] = useState(false);
    const { isAllChangeType,setIsValidated,setValidationTrigger,allChangeTypesDevices, setsuccessFullChangeTypes, activeChange, successFullChangeTypes  } = useAllChangeTypesStore();
    const archiveSummaryRef = useRef<ArchiveSummaryContentRef>(null);
    const [saveChanges, setSaveChanges] = useState<boolean>(true);
    const { getTargetTenantProvider, IsTargetTenantProvider } = PerformanceLogStore();
    const is_parent_provider_exists = IsTargetTenantProvider(service_provider)
    const providerName = getTargetTenantProvider(service_provider).toLowerCase() || service_provider;

    const fetchDevices = async (devices_list: any[], deviceKey: string) => {
        try {
            setLoading(true);
            const url =
                ENV_ROUTES.BULKCHANGE_PROCESSOR;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_standard_iccid_msisdn_data",
                role_name: role,
                Partner: partner,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: service_provider,
                 ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type,
                [deviceKey]: devices_list || []
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                // setLoading(false);
                Modal.error({
                    title: 'Submit Error',
                    content: parsedData.message || 'An error occurred while submitting data. Please try again.',
                    centered: true,
                });
                return []
            } else {
                const responseKey = deviceKey === "iccids" ? "msisdns" : "iccids"
                const devices = parsedData?.[responseKey] || []
                console.log("devices", devices)
                return devices
                // setLoading(false);
            }
        } catch (error) {
            Modal.error({
                title: 'Submit Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting data. Please try again.',
                centered: true,
            });
            return []
            // setLoading(false);
        }
        finally {
            setLoading(false)
        }
    };

    const getIccidList = async (): Promise<string[]> => {
        // Pick devices based on subscriberNumber or iccids
        let iccidList = (msisdns.length > 1 || (msisdns[0] && msisdns[0] !== "")) ? msisdns : iccids;

        // Find matching device type from the map
        const matchedDeviceTypeItem = simIdentifierMap.find((item: any) => {
            return (
                item.service_provider === service_provider &&
                item.change_type === change_type
            );
        });
        const matchedDeviceType = matchedDeviceTypeItem?.sim_identifier || ""
        // Decide expected type
        const selectDeviceType = (msisdns.length > 1 || (msisdns[0] && msisdns[0] !== "")) ? "msisdns" : "iccids";

        // Fetch devices only if types mismatch
        if (matchedDeviceType !== selectDeviceType) {
            iccidList = await fetchDevices(iccidList, selectDeviceType);
        }

        return iccidList;
    };

    useEffect(() => {
        if(isAllChangeType){
            const devices = allChangeTypesDevices?.iccids || []
            if(allChangeTypesDevices?.isIccid){
                setMsisdns([])
                setIccids([...devices]);
            }
            else{
                setIccids([])
                setMsisdns([...devices]);
            }
        }
    }, [isAllChangeType , allChangeTypesDevices]);

    useEffect(() => {
        // Update the bulkInput state whenever iccids change
        setBulkInput(iccids.join('\n'));
    }, [iccids]);
    useEffect(() => {
        // Update the bulkInput state whenever iccids change
        setBulkMSISDNInput(msisdns.join('\n'));
    }, [msisdns]);

    const handleIccidChange = (index: number, value: string) => {
        const newIccids = [...iccids];
        newIccids[index] = value;
        setIccids(newIccids);
    };

    const handleAddMore = () => {
        setIccids([...iccids, ""]);
    };

    const handleRemove = (index: number) => {
        const newIccids = iccids.filter((_, i) => i !== index);
        setIccids(newIccids);
    };
    const handleMsisdnChange = (index: number, value: string) => {
        const newMsisdns = [...msisdns];
        newMsisdns[index] = value;
        setMsisdns(newMsisdns);
    };

    const handleMsisdnAddMore = () => {
        setMsisdns([...msisdns, ""]);
    };

    const handleMsisdnRemove = (index: number) => {
        const newMsisdns = msisdns.filter((_, i) => i !== index);
        setMsisdns(newMsisdns);
    };

    const hasDuplicates = (iccids: string[]): boolean => {
        const uniqueIccids = new Set(iccids);
        return uniqueIccids.size !== iccids.length;
    };
    const hasMsisdnDuplicates = (msisdns_: string[]): boolean => {
        const uniqueMsisdns = new Set(msisdns_);
        return uniqueMsisdns.size !== msisdns.length;
    };

    const handleContinue = async () => {
        setMsisdnErrors([])
        setPreviousMSISDNContent([""])
        const newErrors: string[] = [];
        const trimmedIccids = iccids.map(iccid => iccid.trim());
        // Check for duplicates
        if (hasDuplicates(trimmedIccids)) {
            newErrors.push("There are duplicate ICCIDs in the list.");
        }
        
        trimmedIccids.forEach((iccid, index) => {
        if (iccid.length === 0) {
            newErrors[index] = "ICCID must not be empty";
        } else if (providerName.toLowerCase().includes("t-mobile")) {
            // ✅ Mobile Jasper: allow alphanumeric
            if (!/^[a-zA-Z0-9]+$/.test(iccid)) {
            newErrors[index] =
                "ICCID must only contain letters and numbers. Special characters are not allowed.";
            } else if (iccid.length < 8 || iccid.length > 22) {
            newErrors[index] =
                "ICCID must be between 8 and 22 characters long.";
            }
        } else {
            // ✅ Default: numbers only
            if (!/^\d+$/.test(iccid)) {
            newErrors[index] =
                "Please enter numbers only for ICCID. Letters or special characters are not allowed.";
            } else if (iccid.length < 14 || iccid.length > 22) {
            newErrors[index] = "ICCID must be between 14 and 22 digits long.";
            }
        }
        });


        if (trimmedIccids.length > bulkChangeLimit) {
            newErrors.push(`This request exceeds the allowed record limit  of ${bulkChangeLimit} and cannot be processed`);
            console.log("Limit Exceeded");
        }

        if (newErrors.length > 0) {
            setsuccessFullChangeTypes(
                    successFullChangeTypes.filter((c: any) => c !== activeChange)
                );
            setErrors(newErrors);
            return;
        }

        const devices_ = await getIccidList()
        setSelectedDevices(devices_)
        setErrors([]);
        setPreviousContent(trimmedIccids); // Save the current content before showing the summary
        if(!isAllChangeType){
            setShowSummary(true); // Show the bulk change summary
        }
        else{
            if(saveChanges){
                setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
            }
            setIsValidated(true)
            setValidationTrigger()
        }
    };

    const handleMSISDNContinue = async () => {
        setErrors([])
        setPreviousContent([""])
        const newErrors: string[] = [];
        const trimmedMSISDNs = msisdns.map(msisdn => msisdn.trim());
        // Check for duplicates
        if (hasMsisdnDuplicates(trimmedMSISDNs)) {
            newErrors.push("There are duplicate MSISDNs in the list.");
        }

        trimmedMSISDNs.forEach((msisdn, index) => {
            if (msisdn.length === 0) {
                newErrors[index] = `MSISDN must not be empty`;
            } else if (!/^\d+$/.test(msisdn)) {
                newErrors[index] = `Please enter numbers only for MSISDN. Letters or special characters are not allowed`;
            } else if (msisdn.length < 10 || msisdn.length > 18) {
                newErrors[index] = `MSISDN must be between 10 and 18 digits long`;
            }
        });

        if (trimmedMSISDNs.length > bulkChangeLimit) {
            newErrors.push(`This request exceeds the allowed record limit  of ${bulkChangeLimit} and cannot be processed`);
            console.log("Limit Exceeded");
        }

        if (newErrors.length > 0) {
            setsuccessFullChangeTypes(
                    successFullChangeTypes.filter((c: any) => c !== activeChange)
                );
            console.log("newErrors", newErrors)
            setMsisdnErrors(newErrors);
            return;
        }

        const devices_ = await getIccidList()
        setSelectedDevices(devices_)
        setMsisdnErrors([]);
        setPreviousMSISDNContent(trimmedMSISDNs); // Save the current content before showing the summary
        if(!isAllChangeType){
            setShowSummary(true); // Show the bulk change summary
        }
        else{
            if(saveChanges){
                setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
            }
            setIsValidated(true)
            setValidationTrigger()
        }
    };

    const showModal = () => {
        setIsModalVisible(true);
    };

    const validateBulkInput = (input: string) => {
        const lines = input.split(/\s*[\n,]\s*/).map(line => line.trim()).filter(line => line.length > 0);
        const validNumbersOnly = lines.every(line => /^[0-9]{8,22}$/.test(line));
        const validAlphaNumeric = lines.every(line => /^[a-zA-Z0-9]{8,22}$/.test(line));
        if (lines && lines.length === 0) {
            setBulkError("Please fill in either ICCIDs or MSISDNs.");
            return
        }
        if(providerName.toLowerCase().includes("t-mobile")){
            // Special rule for Mobile Jasper: allow alphanumeric
            if (!validAlphaNumeric) {
            setBulkError("ICCID must only contain letters and numbers, between 8 and 22 characters.");
            return false;
            }
        }
        else{
            // Default rule: only numbers
            if (!validNumbersOnly) {
            setBulkError("ICCID must only contain numbers and be between 8 and 22 digits.");
            return false;
            }
        }

        setBulkError(null);
        return lines;
    };

    const validateBulkMSISDNInput = (input: string) => {
        const lines = input.split(/\s*[\n,]\s*/).map(line => line.trim()).filter(line => line.length > 0);
        const validLines = lines.every(line => /^[0-9]{10,18}$/.test(line));
        if (lines && lines.length === 0) {
            setBulkError("Please fill in either ICCIDs or MSISDNs.");

            return
        }
        if (!validLines) {
            setBulkError("MSISDN must only contain numbers and be between 10 and 18 digits.");
            return false;
        }
        setBulkError(null);
        return lines;
    };

    const handleAdd = () => {
        const lines = validateBulkInput(bulkInput);
        if (lines) {
            setIccids(lines);
            setBulkInput("");
            setIsModalVisible(false);
            setMsisdnErrors([])
            setPreviousMSISDNContent([""])
            setMsisdns([""])
        }
    };
    const handleMSISDNAdd = () => {
        const lines = validateBulkMSISDNInput(bulkMSISDNInput);
        if (lines) {
            setMsisdns(lines);
            setBulkMSISDNInput("");
            setIsModalVisible(false);
            setErrors([])
            setPreviousContent([""])
            setIccids([""])
        }
    };

    const handleModalCancel = () => {
        setBulkInput("");
        setBulkMSISDNInput("");
        setBulkError(null);
        setIsModalVisible(false);
    };

    const handleTextAreaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        setBulkInput(e.target.value);
    };
    const handleMSISDNTextAreaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        setBulkMSISDNInput(e.target.value);
    };

    const handleBack = () => {
        setShowSummary(false);
        setIccids(previousContent);
        setMsisdns(previousMSISDNContent);

    };

    const handleMainContinue = () =>{
        if(msisdns){
            handleMSISDNContinue()
        }
        else{
            handleContinue()
        }
    }

        const returnUpdatedValue = () => {
            const devices = allChangeTypesDevices?.iccids
            return (
                <div className="flex flex-col gap-2">
                    <div className="flex grid grid-cols-2 ">
                        <span className="font-semibold">{allChangeTypesDevices?.isIccid ? "ICCIDs:" : "MSISDNs"}</span>
                        <span>{devices.join(",")}</span>
                    </div>
                </div>
            )
        }

        // const returnUpdatedValue = () => {
        //     const devices = allChangeTypesDevices?.iccids
        //     return (
        //         <Tooltip title={`${devices.join(",")}`}>
        //             <span>
        //                 {/* {allChangeTypesDevices?.isIccid?`ICCIDs: ${devices}`:`MSISDNs: ${devices}`} */}
        //                 {devices.join(",")}
        //             </span>
        //         </Tooltip>)
        // }

     useImperativeHandle(ref, () => ({
      runValidation: handleMainContinue,
      runSubmit: () => {
        archiveSummaryRef.current?.runSubmit();
      },
      returnUpdate: returnUpdatedValue
    }));

    if (loading) {
        return (
            <>
                <div className="flex justify-center items-center h-[400px]">
                    <Spin size="large" />
                </div>
            </>
        );
    }

    return (
        <div>
            {/* {!showSummary ? ( */}
                <div className={showSummary ? "hidden" : "block"}>
                <>
                    {isAllChangeType && (
                        <div className="flex justify-end px-4">
                            <span className="mr-2 font-semibold">Save Changes</span>
                            <Checkbox
                                checked={saveChanges}
                                onChange={(e) => {
                                    if (!e.target.checked) {
                                        setsuccessFullChangeTypes(
                                            successFullChangeTypes.filter((c: any) => c !== activeChange)
                                        );
                                    }
                                    setSaveChanges(e.target.checked)
                                }}
                                className="custom-checkbox"
                            >

                            </Checkbox>
                        </div>
                    )}
                    <div className="flex flex-col space-y-4 my-4 max-h-[400px] overflow-y-auto">
                        {iccids.map((iccid, index) => (
                            <div className=" w-full">
                                <div className="flex w-full" key={index}>
                                    <label htmlFor={`iccid-${index}`} className="inline mr-2 w-[70px]">ICCID {index + 1}<span className="text-red-500">*</span></label>
                                    <Input
                                        id={`iccid-${index}`}
                                        value={iccid}
                                        onChange={(e) => handleIccidChange(index, e.target.value)}
                                        placeholder={`Enter ICCID ${index + 1}`}
                                        className="w-[300px]"
                                        disabled={(msisdns.length > 1 || msisdns[0] !== "")|| isAllChangeType}
                                    />
                                    {!isAllChangeType && (
                                        <Button
                                        type="text"
                                        onClick={() => handleRemove(index)}
                                        disabled={index === 0}
                                    >
                                        <MinusCircleOutlined className="h-5 w-5" />
                                    </Button>
                                    )}
                                    
                                </div>
                                {errors[index] && <div className="text-red-500 mt-2 w-full">{errors[index]}</div>}
                            </div>
                        ))}
                    </div>
                    <div className="flex flex-col space-y-4 my-4 max-h-[400px] overflow-y-auto">
                        {msisdns.map((msisdn, index) => (
                            <div className=" w-full">
                                <div className="flex w-full" key={index}>
                                    <label htmlFor={`msisdn-${index}`} className="inline mr-2 w-[70px]">MSISDN {index + 1}<span className="text-red-500">*</span></label>
                                    <Input
                                        id={`msisdn-${index}`}
                                        value={msisdn}
                                        onChange={(e) => handleMsisdnChange(index, e.target.value)}
                                        placeholder={`Enter MSISDN ${index + 1}`}
                                        className="w-[300px]"
                                        disabled={(iccids.length > 1 || iccids[0] !== "")|| isAllChangeType}
                                    />
                                    {!isAllChangeType && (
                                        <Button
                                        type="text"
                                        onClick={() => handleMsisdnRemove(index)}
                                        disabled={index === 0}
                                    >
                                        <MinusCircleOutlined className="h-5 w-5" />
                                    </Button>
                                    )}
                                    
                                </div>
                                {MsisdnErrors[index] && <div className="text-red-500 mt-2 w-full">{MsisdnErrors[index]}</div>}
                            </div>
                        ))}
                    </div>
                    {!isAllChangeType && (
                        <div className="flex flex-col space-y-4 w-full justify-center">
                        <div className="flex space-x-4">
                            <Button onClick={() => {
                                if (msisdns.length > 1 || msisdns[0] !== "") {
                                    handleMsisdnAddMore()

                                }
                                else {
                                    handleAddMore()
                                }
                            }}>Add more</Button>
                            <Button onClick={showModal}>Bulk Devices</Button>
                        </div>
                        <div className="flex w-full space-x-4 justify-center">
                            <button onClick={onBack} className="cancel-btn">
                                {/* <ArrowLeftIcon className="h-5 w-5 mr-2" /> */}
                                Back</button>
                            <button className="save-btn" onClick={() => {
                                if (msisdns.length > 1 || msisdns[0] !== "") {
                                    handleMSISDNContinue()
                                }
                                else {
                                    handleContinue()
                                }
                            }}>
                                Continue
                                {/* <ArrowRightIcon className="h-5 w-5 mr-2" /> */}
                            </button>
                        </div>

                    </div>
                    )}
                    
                    <Modal
                        title="Bulk ICCIDs"
                        visible={isModalVisible}
                        footer={null}
                        onCancel={handleModalCancel}
                        centered
                        maskClosable={false}
                    >
                        <div
                            style={{ backgroundColor: '#E6F4FF', border: '#91CAFF', padding: '16px', marginBottom: '12px', borderRadius: '8px' }}
                            className="flex items-center">
                            <InfoCircleOutlined style={{ marginRight: 8, color: '#1890ff' }} />
                            <span>Enter one SIM per line, such as the following: ICCID/MSISDN.</span>
                        </div>

                        <Input.TextArea
                            value={bulkInput}
                            onChange={handleTextAreaChange}
                            rows={6}
                            placeholder="Enter ICCIDs here"
                            disabled={!!bulkMSISDNInput}
                            className="mb-4"
                        />
                        {/* {bulkError && <div className="text-red-500">{bulkError}</div>} */}
                        <Input.TextArea
                            value={bulkMSISDNInput}
                            onChange={handleMSISDNTextAreaChange}
                            rows={6}
                            placeholder="Enter MSISDNs here"
                            disabled={!!bulkInput}

                        />
                        {bulkError && <div className="text-red-500">{bulkError}</div>}
                        <div style={{ marginTop: '16px', textAlign: 'right' }}>
                            <Button onClick={() => {
                                if (!!bulkMSISDNInput) {
                                    handleMSISDNAdd()
                                }
                                else {
                                    handleAdd()
                                }
                            }} type="primary">Add</Button>
                            <Button onClick={handleModalCancel} style={{ marginLeft: '8px' }}>Close</Button>
                        </div>
                    </Modal>
                </>
                </div>
            {/* ) : ( */}
                <div className={showSummary ? "block" : "hidden"}>
                <ArchiveSummaryContent
                    ref={archiveSummaryRef}
                    iccids={selectedDevices}
                    onContinue={handleContinue}
                    onBack={handleBack}
                    service_provider={service_provider}
                    change_type={change_type}
                    onCancel={onCancel}
                />
                </div>
             {/* )} */}
        </div>
    );
}
)

export default ArchiveContent;
