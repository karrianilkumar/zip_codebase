"use client";
import { FC, forwardRef, useEffect, useImperativeHandle, useRef, useState } from "react";
import { Input, Button, Checkbox, Tooltip, Modal } from "antd";
import { ArrowLeftIcon, ArrowRightIcon } from "@heroicons/react/24/outline";
import SelectDevices from "./select_devices";
import moment from "moment";
import { DatePicker } from "antd/lib";
import Select from 'react-select';
import React from "react";
import { useAuth } from "@/app/components/auth_context";
import { DropdownStyles } from "@/app/components/css/dropdown";
import { useAllChangeTypesStore } from "@/app/stores/allChangeTypesStore";
import dayjs from "dayjs";
import { SelectContentRef } from "./select_devices";
import { PerformanceLogStore } from "@/app/stores/performance_matrix_store";
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import UploadComponent2 from "./upload_component_2";
import PreviewModal from "./private_network_preview";
import { InfoIcon } from "lucide-react";

interface Activated1Props {
    onContinue: () => void;
    onBack: () => void;
    dropdown: any;
    service_provider: any;
    change_type: any;
    onClose: () => void;
    onTargetStatusChange?: (status: string) => void;
}

export interface Activated1ContentRef {
  runValidation: () => Promise<void> | void;
  runSubmit: () => Promise<void> | void;
  returnUpdate: () => React.ReactNode | Promise<React.ReactNode>;
}

const Activated1 = forwardRef<Activated1ContentRef, Activated1Props>(
    ({ onContinue, onBack, dropdown, service_provider, change_type, onClose,onTargetStatusChange }, ref) => {
    const { username, role, partner, token, selectedDb, metaData, firstLastName, sessionId } = useAuth();
    const [targetStatus, setSelectedTargetStatus] = useState<string | null>(null);
    const [selectedStatus, setSelectedStatus] = useState<string | null>(null);
    const [selectedStatusID, setSelectedStatusId] = useState<string | null>(null);
    const [statusMap, setStatusMap] = useState<any>([]);

    const [reasonCodeMap, setReasonCodeMap] = useState<any>([]);
    const [selectedReasonCode, setSelectedReasonCode] = useState<string | null>(null);
    const [selectedReasonCodeID, setSelectedReasonCodeID] = useState<string | null>(null);
    const [reasonCodeOptions, setReasonCodeOptions] = useState<any>([]);



    const [statusOptions, setStatusOptions] = useState<any>([]);

    const [firstName, setFirstName] = useState<string>("");
    const [lastName, setLastName] = useState<string>("");
    const [addressLine, setAddressLine] = useState<string>("");
    const [ipAddress, setIpAddress] = useState<string | undefined>(undefined);
    const [IPOptions, setIPOptions] = useState<any>([]);
    const [city, setCity] = useState<string>("");
    const [country, setCountry] = useState<string>("");
    const [selectedRatePlan, setSelectedRatePlan] = useState<string | null>('');
    const [accountNumber, setAccountNumber] = useState<string | null>('');
    const [notAdminSelectedRatePlan, setNotAdminSelectedRatePlan] = useState<string | null>('');
    const [publicIpRestriction, setPublicIpRestriction] = useState<string | undefined>("restricted");
    const [mdnZipCode, setMdnZipCode] = useState<string>("");
    const [revIoAccountNumber, setRevIoAccountNumber] = useState<string>("");
    const [showSelectDevices, setShowSelectDevices] = useState(false);
    const [errors, setErrors] = useState<{ [key: string]: string }>({});
    const [effectiveDateCheckbox, setEffectiveDateCheckbox] = useState<boolean>(false);
    const [effectiveDateError, setEffectiveDateError] = useState<string | null>(null);
    const [effectiveDate, setEffectiveDate] = useState<Date | null>(null);
    const [ratePlanOptions, setRatePlanOptions] = useState<any>([]);
    const [accountNumberOptions, setAccountNumberOptions] = useState<any>([]);
    const [selectedPublicIpRestriction, setSelectedPublicIpRestriction] = useState<string>('restricted');
    const [publicIpOptions, setPublicIpOptions] = useState<any>([]);

    const [selectedState, setSelectedState] = useState<string>('');
    const [selectedStateCode, setSelectedStateCode] = useState("");
    const [stateOptions, setStateOptions] = useState<any>([]);
    const { isAllChangeType,setIsValidated,setValidationTrigger, setsuccessFullChangeTypes, activeChange, successFullChangeTypes  } = useAllChangeTypesStore();
    const selectDevicesRef = useRef<SelectContentRef>(null);
    const isAdmin = role?.toLowerCase() === "super admin" || role?.toLowerCase() === "partner admin"
    const [saveChanges, setSaveChanges] = useState<boolean>(true);

    const { getTargetTenantProvider, IsTargetTenantProvider } = PerformanceLogStore();
    const is_parent_provider_exists = IsTargetTenantProvider(service_provider)
    const providerName = getTargetTenantProvider(service_provider).toLowerCase() || service_provider;
        const [IpError, setIpError] = useState<string | null>(null);
        const isVerizon_ = providerName.toLowerCase().includes("verizon") || 
        providerName.toLowerCase().includes("vzn") || providerName.toLowerCase().includes("vzwcr") || 
        providerName.toLowerCase().includes("2215-so01") 
        const [openPreviewModal, setPreviewModal] = useState<boolean>(false);

        const handlePreviewOpen = async () => {
            setPreviewModal(true)
        };
         // IPv4
        const ipv4Regex = /^(\d{1,3}\.){3}\d{1,3}$/;
        const isValidIPv4 = (ip: string) => {
            if (!ipv4Regex.test(ip)) return false;
            return ip.split(".").every(p => {
                if (!/^\d+$/.test(p)) return false;
                const n = Number(p);
                return Number.isInteger(n) && n >= 0 && n <= 255;
            });
        };
        const ipv4ToUint32 = (ip: string) => {
            const [a, b, c, d] = ip.split(".").map(Number);
            return ((a << 24) >>> 0) + (b << 16) + (c << 8) + d;
        };

        // IPv6: expand compressed forms into 8 hextets of 4 hex digits
        const expandIPv6 = (input: string): string[] | null => {
            const raw = input.trim();
            if (!raw) return null;
            // split on :: (0..1 times)
            if (raw.includes("::")) {
                const [left, right] = raw.split("::");
                const leftParts = left ? left.split(":").filter(Boolean) : [];
                const rightParts = right ? right.split(":").filter(Boolean) : [];
                if (leftParts.some(p => p.length > 4) || rightParts.some(p => p.length > 4)) return null;
                const missing = 8 - (leftParts.length + rightParts.length);
                if (missing < 0) return null;
                const mid = new Array(missing).fill("0");
                const parts = [...leftParts, ...mid, ...rightParts].map(p => p || "0");
                if (parts.length !== 8) return null;
                return parts.map(p => p.padStart(4, "0").toUpperCase());
            } else {
                const parts = raw.split(":");
                if (parts.length !== 8) return null;
                if (parts.some(p => p.length === 0 || p.length > 4)) return null;
                return parts.map(p => p.padStart(4, "0").toUpperCase());
            }
        };

        // Detect IPv6 (rough)
        const looksLikeIPv6 = (s: string) => s.includes(":");

        // Convert expanded 8 hextets -> BigInt
        const ipv6PartsToBigInt = (parts: string[]) => {
            // each part is 4 hex digits -> 16 bits
            let acc = BigInt(0);
            for (let i = 0; i < 8; i++) {
                const v = BigInt(parseInt(parts[i], 16) & 0xFFFF);
                acc = (acc << BigInt(16)) + v;
            }
            return acc;
        };
        const parseSavedRange = (ipRange: string) => {
            if (!ipRange) return { ok: false as const };

            const parts = ipRange.split("-");
            if (parts.length !== 2) return { ok: false as const };

            const s = parts[0].trim();
            const e = parts[1].trim();

            // IPv4 branch
            if (!looksLikeIPv6(s) && !looksLikeIPv6(e)) {
                if (!isValidIPv4(s) || !isValidIPv4(e)) return { ok: false as const };
                const sN = ipv4ToUint32(s);
                const eN = ipv4ToUint32(e);
                const start = Math.min(sN, eN);
                const end = Math.max(sN, eN);
                return { ok: true as const, family: "ipv4" as const, startNum: start, endNum: end };
            }

            // IPv6 branch
            const sExp = expandIPv6(s);
            const eExp = expandIPv6(e);
            if (!sExp || !eExp) return { ok: false as const };
            const sBig = ipv6PartsToBigInt(sExp);
            const eBig = ipv6PartsToBigInt(eExp);
            const startBig = sBig <= eBig ? sBig : eBig;
            const endBig = sBig <= eBig ? eBig : sBig;
            return { ok: true as const, family: "ipv6" as const, startBig, endBig };
        };

        interface IPValidation {
            valid: boolean;
            error: string;
        }

        const unavailableIPError = async (
            ipList: string | string[],
            changeType: string
        ): Promise<IPValidation> => {
            try {
                // setLoading(true);

                const url = ENV_ROUTES.MODULE_MANAGEMENT;

                const data = {
                    tenant_name: partner || "default_value",
                    username,
                    firstLastName,
                    path: "/validate_ips_availability",
                    role_name: role,
                    Partner: partner,
                    request_received_at: getCurrentDateTime(),
                    access_token: token,
                    db_name: selectedDb,
                    ...metaData,
                    sessionID: sessionId,
                    change_type: changeType || "",
                    ip_list: ipList || [],
                    service_provider: service_provider || "",
                };

                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);

                // ❌ Invalid cases
                if (parsedData.flag === false || parsedData?.validation) {
                    return {
                        valid: false,
                        error: parsedData?.message || "Enter IP address within the available IP list",
                    };
                }

                // ✅ Success case
                return {
                    valid: true,
                    error: "",
                };

            } catch (error) {
                return {
                    valid: false,
                    error: "Enter IP address within the available IP list",
                };
            } finally {
                // setLoading(false);
            }
        };

        const validateFieldIp = async (
            value: string[],
            ipRange: string | string[]
        ): Promise<IPValidation> => {

            // const v = String(value ?? "").trim();

            if (!value || value.length === 0) {
                return { valid: false, error: "Enter a valid IP address" };
            }

            return await unavailableIPError(value, change_type);
        };

        const validateFieldIp_ = (
            value: string,
            ipRange: string | string[]
        ): { valid: boolean; error: string } => {
            const v = String(value ?? "").trim();
            if (!v) return { valid: false, error: "Enter a valid IP address" };

            // Normalize ranges to array of non-empty strings
            const ranges = (Array.isArray(ipRange) ? ipRange : [ipRange])
                .map(r => String(r ?? "").trim())
                .filter(r => r.length > 0);

            if (ranges.length === 0) {
                return {
                    valid: false,
                    error: "Enter IP address within the given IP range",
                };
            }

            const isV6 = looksLikeIPv6(v);

            // ================= IPv6 =================
            if (isV6) {
                const expanded = expandIPv6(v);
                if (!expanded) {
                    return { valid: false, error: "Enter a valid IP address" };
                }

                // Parse all ranges that are valid IPv6
                const parsedV6Ranges = ranges
                    .map(r => parseSavedRange(r))
                    .filter(p => p.ok && p.family === "ipv6");

                if (parsedV6Ranges.length === 0) {
                    return {
                        valid: false,
                        error: "Enter IP address within the given IP range",
                    };
                }

                const vBig = ipv6PartsToBigInt(expanded);

                const inAnyRange = parsedV6Ranges.some(p => {
                    return vBig >= p.startBig && vBig <= p.endBig;
                });

                if (!inAnyRange) {
                    return {
                        valid: false,
                        error: "Enter IP address within the given IP range",
                    };
                }

                return { valid: true, error: "" };
            }

            // ================= IPv4 =================
            if (!isValidIPv4(v)) {
                return { valid: false, error: "Enter a valid IP address" };
            }

            // Parse all ranges that are valid IPv4
            const parsedV4Ranges = ranges
                .map(r => parseSavedRange(r))
                .filter(p => p.ok && p.family === "ipv4");

            if (parsedV4Ranges.length === 0) {
                return {
                    valid: false,
                    error: "Enter IP address within the given IP range",
                };
            }

            const vN = ipv4ToUint32(v);

            const inAnyRange = parsedV4Ranges.some(p => {
                return vN >= p.startNum && vN <= p.endNum;
            });

            if (!inAnyRange) {
                return {
                    valid: false,
                    error: "Enter IP address within the given IP range",
                };
            }

            return { valid: true, error: "" };
        };
    const fetchOptionsMappings = async () => {
            try {
                const url =
                    ENV_ROUTES.MODULE_MANAGEMENT;
                const data = {
                    tenant_name: partner || "default_value",
                    path: "/get_private_network_pdp_apn_ip_mappings",
                    request_received_at: getCurrentDateTime(),
                    username: username,
                    firstLastName: firstLastName,
                    role_name: role,
                    Partner: partner,
                    access_token: token,
                    db_name: selectedDb,
                    ...metaData,
                    sessionID: sessionId,
                    service_provider: service_provider,
                    ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" },
                    change_type: change_type
                };

                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);
                if (parsedData.flag === false) {
                    Modal.error({
                        title: 'Data Fetch Error',
                        content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                        centered: true,
                    });
                } else {
                    
                    const ip_options = parsedData?.ip_addresses || {};
                    setIPOptions(ip_options)
                }
            } catch (error) {
                Modal.error({
                    title: 'Data Fetch Error',
                    content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                    centered: true,
                });
            }
        };
        
    useEffect(() => {
        fetchOptionsMappings()
        // console.log("dropdown", dropdown)
        const public_ip = dropdown?.public_ip || []
        setPublicIpOptions(public_ip)
        const state = dropdown?.state || [];

        // Map state array to options with 'name' as label and 'code' as value
        const stateOptions = state.map((item: any) => ({
            label: item.name,  // Display state name in the dropdown
            value: item.code,  // Use state code as the value
        }));

        setStateOptions(stateOptions);
        const default_state = stateOptions.length>0 ? stateOptions[0] : null
        setSelectedState(default_state?.label || "")
        setSelectedStateCode(default_state?.value || "")
        if(isAdmin){
        const carrier_rate_plan_dropdown = dropdown?.carrier_rate_plan_dropdown || []
        setRatePlanOptions(carrier_rate_plan_dropdown)
        }else{
        const carrier_rate_plan_dropdown = dropdown?.original_customer_rate_plans_dropdown || []
        setRatePlanOptions(carrier_rate_plan_dropdown)

        }
       
        const account_options = dropdown?.account_numbers || []
        setAccountNumberOptions(account_options)

        if (typeof service_provider === "string" && providerName.includes("telegence")) {
            const reason_code = dropdown?.reason_code || []
            setReasonCodeMap(reason_code)
            const Device_Status_dropdown = dropdown?.Device_Status_dropdown || []
            setStatusMap(Device_Status_dropdown || [])
            const statusOptions = Device_Status_dropdown.map((option: any) => (option.display_name));
            setStatusOptions(statusOptions)
            // console.log("statusOptions", statusOptions)
        }
        else {
            const Device_Status_dropdown = dropdown?.Device_Status_dropdown || []
            setStatusMap(Device_Status_dropdown || [])
            const statusOptions = Device_Status_dropdown.map((option: any) => (option.display_name));
            setStatusOptions(statusOptions)
            const reason_code = dropdown?.reason_code || []
            setReasonCodeMap(reason_code) 
            // const reasonCodeOptions = reason_code.map((option: any) => ({ label: option, value: option }));
            // setReasonCodeOptions(reasonCodeOptions)
        }

    }, [dropdown]);
    const getDefaultReasonCode = (targetStatus: any) => {
        const selected_status=targetStatus.toLowerCase()
        switch (selected_status) {
            case "suspended":
                return {label:"Customer Request",value:"CR"};
            case "cancel subscriber":
                return {label:"Customer Cutting Back",value:"CB"};
            case "restore suspended":
                return {label:"Customer Request",value:"CR"};
            case "restore cancelled":
                return {label:"Customer Request",value:"CR"};
            default:
                return null; // or a suitable default value
        }
    };

    // const defaultReasonCode = getDefaultReasonCode(targetStatus);
    // const handleContinue = () => {
    //     const newErrors: { [key: string]: string } = {};
    //     if (!targetStatus) {
    //         setErrors((prevErrors) => ({ ...prevErrors, targetStatus: 'Please select a target status.' }));
    //     }
    //     else {
    //         if (targetStatus === "Active") {
    //             if (!firstName) newErrors.firstName = "First name is required.";
    //             if (!lastName) newErrors.lastName = "Last name is required.";
    //             if (!addressLine) newErrors.addressLine = "Address line is required.";
    //             if (!city) newErrors.city = "City is required.";
    //             if (!country) newErrors.country = "Country is required.";
    //             if (!selectedRatePlan) newErrors.ratePlan = "Rate plan is required.";
    //             if (!mdnZipCode) newErrors.mdnZipCode = "MDN zip code is required.";
    //         }

    //         if (Object.keys(newErrors).length > 0) {
    //             setErrors(newErrors);
    //         } else {
    //             setErrors({});
    //             setShowSelectDevices(true);
    //         }
    //     }


    // };

    const handleIPAddressSelect = (selectedOption: any) => {
            if (selectedOption) {
                const value = selectedOption?.value
                setIpAddress(value)
            }
            else {
                setIpAddress(undefined)

            }
        };

    const handleContinue = () => {
        const newErrors: { [key: string]: string } = {};

        if (!targetStatus) {
            newErrors.targetStatus = 'Please select a target status.';
            if(isAllChangeType){
                setsuccessFullChangeTypes(
                    successFullChangeTypes.filter((c: any) => c !== activeChange)
                );
                setErrors({});
                setIsValidated(true)
                setValidationTrigger();
            }
        } else {
            if (targetStatus === "Active") {
                if (!accountNumber) newErrors.account_number = "Account Number is required.";
                if (!firstName) newErrors.firstName = "First name is required.";
                if (!lastName) newErrors.lastName = "Last name is required.";
                if (!addressLine) newErrors.addressLine = "Address line is required.";
                if (!city) newErrors.city = "City is required.";
                if (!country) newErrors.country = "Country is required.";
                if (!selectedRatePlan) newErrors.ratePlan = "Rate plan is required.";
                if (!mdnZipCode) newErrors.mdnZipCode = "MDN zip code is required.";
            }

            // Check for effective date only if the checkbox is checked
            if (effectiveDateCheckbox && !effectiveDate) {
                newErrors.effectiveDate = "Effective date is required.";
            } else if (effectiveDateCheckbox && effectiveDate) {
                // Clear the effective date error if provided
                setErrors((prevErrors) => {
                    const { effectiveDate, ...rest } = prevErrors;
                    return rest;
                });
            }

            if (Object.keys(newErrors).length > 0) {
                setErrors(newErrors);
                if(isAllChangeType){
                    setsuccessFullChangeTypes(
                        successFullChangeTypes.filter((c: any) => c !== activeChange)
                    );
                    setIsValidated(false)
                    setValidationTrigger();
                }
                

            } else {
                setErrors({});
                if(isAllChangeType){
                    if(saveChanges){
                        setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
                    }
                    setIsValidated(true)
                    setValidationTrigger()
                }
                else{
                    setShowSelectDevices(true);
                }
                
            }
        }
    };

    const handleSelectedTargetStatusChange = (selectedOption: any) => {
        if (typeof service_provider === "string" && providerName.includes("telegence")) {
            handleTelegenceTargetStatusChange(selectedOption)
        }
        else {
            handleVerizonTargetStatusChange(selectedOption)

        }


    }

    const handleTelegenceTargetStatusChange = (selectedOption: any) => {
        console.log("selectedOption", selectedOption)
        if (selectedOption) {
            setSelectedTargetStatus(selectedOption.value)
            onTargetStatusChange?.(selectedOption?.value)
            const selectedItem = statusMap.find((item: any) => item.display_name === selectedOption.value);
            setSelectedStatusId(selectedItem?.id || "22"); // `id`
            setSelectedStatus(selectedItem?.status || "A"); // `status`
            setSelectedReasonCode(null);
            setSelectedReasonCodeID(null);
            // Filter reasonCodeMap based on the selectedStatusId
            const filteredReasonCodes = reasonCodeMap
                .filter((reason: any) => reason.device_status_id === selectedItem?.id)
                .map((reason: any) => ({
                    label: reason.description,
                    value: reason.reason_code,
                }));
            console.log("filteredReasonCodes", filteredReasonCodes)
            setReasonCodeOptions(filteredReasonCodes);
            // const reason_code=filteredReasonCodes.length>0?filteredReasonCodes[0]:null
            // console.log(reason_code?.label,reason_code?.value,"show label.....")
            const reason_code = getDefaultReasonCode(selectedOption.value)
            setSelectedReasonCode(reason_code?.label || null)
            setSelectedReasonCodeID(reason_code?.value || null)
            setErrors((prevErrors) => ({ ...prevErrors, targetStatus: '' })); // Clear error when an option is selected

        } else {
            setSelectedTargetStatus(null)
            setSelectedStatusId(null);
            setSelectedStatus("");
            setReasonCodeOptions([]); // Clear options if no target status is selected
            setSelectedReasonCode(null);
            setSelectedReasonCodeID(null);
            setErrors((prevErrors) => ({ ...prevErrors, targetStatus: 'Please select a target status.' }));

        }
    };

    const handleVerizonTargetStatusChange = (selectedOption: any) => {
        console.log("selectedOption", selectedOption)
        if (selectedOption) {
            const value = selectedOption?.value;
            if (typeof service_provider === "string" && service_provider.toLowerCase()==="verizon - thingspace iot" && value.toLowerCase()==="inventory"){
                const ratePlan=ratePlanOptions.length>0 ? ratePlanOptions[ratePlanOptions.length-1] :null
                const ratePlan_=isAdmin?ratePlan:ratePlan.code || null
                console.log("ratePlan",ratePlan)
                setSelectedRatePlan(ratePlan_)
            }
            if((isVerizon_) && value.toLowerCase()==="pending activation"){
                const zip_code = dropdown?.thingspace_zipcode || null
                setMdnZipCode(zip_code)
            }
            setSelectedTargetStatus(selectedOption.value)
            onTargetStatusChange?.(selectedOption?.value)
            const selectedItem = statusMap.find((item: any) => item.display_name === selectedOption.value);
            setSelectedStatusId(selectedItem?.id || "22"); // `id`
            setSelectedStatus(selectedItem?.status || "A"); // `status`
            setSelectedReasonCode(null);
            setSelectedReasonCodeID(null);
            setErrors((prevErrors) => ({ ...prevErrors, targetStatus: '' })); // Clear error when an option is selected
            setSelectedReasonCode(null);
            setSelectedReasonCodeID(null);
            // Filter reasonCodeMap based on the selectedStatusId
            const filteredReasonCodes = reasonCodeMap
                .map((reason: any) => ({
                    label: reason.description,
                    value: reason.reason_code,
                }));
            console.log("filteredReasonCodes", filteredReasonCodes)
            setReasonCodeOptions(filteredReasonCodes);
        } else {
            setErrors((prevErrors) => ({ ...prevErrors, targetStatus: 'Please select a target status.' }));
            setSelectedTargetStatus(null)
            onTargetStatusChange?.("")
            setSelectedReasonCode(null);
            setSelectedReasonCodeID(null);
            setSelectedStatusId(null);
            setSelectedStatus("");
        }
    };
    const handleSelectedReasonCodeChange = (selectedOption: any) => {
        if (selectedOption) {
            console.log(selectedOption,"showwwwwwww")
            setSelectedReasonCode(selectedOption.label); // Store selected reason_code
            console.log(selectedOption.label,selectedOption.value,"show .........")
            setSelectedReasonCodeID(selectedOption.value); // Store selected reason_code

        } else {
            setSelectedReasonCode("");
            setSelectedReasonCodeID(null); // Store selected reason_code
        }
    };

    const handleSelectedRatePlanChange = (selectedOption: any) => {
        if (selectedOption) {
            const value = selectedOption?.value
            const label = selectedOption?.label
            setSelectedRatePlan(value)
            setNotAdminSelectedRatePlan(label)
        }
        else {
            setSelectedRatePlan(null)

        }
    }
    const handleAccountNumberChange = (selectedOption: any) => {
        if (selectedOption) {
            const value = selectedOption?.value
            setAccountNumber(value)
        }
        else {
            setAccountNumber(null)
        }
    }
    const handleSelectedPublicIpChange = (selectedOption: any) => {
        if (selectedOption) {
            const value = selectedOption?.value;
            setSelectedPublicIpRestriction(value);
        }
    };

    const handleSelectedStateChange = (option: any) => {
        const code_ =option?.value || null
        const name_ =option?.label || null
        // 'value' is the state code, so set it to selectedStateCode
        setSelectedStateCode(code_);
        setSelectedState(name_);
    };

    const handleBack = () => {
        setShowSelectDevices(false);
    };
    const returnChangedData = () => {
        let changedData: any = {}
        if (typeof service_provider === "string" && providerName.includes("telegence")) {
            changedData = {
                sim_status:targetStatus,
                device_status_id:selectedStatusID,
                effectiveDate:effectiveDate,
                UpdateStatus: selectedStatus,
                IsIgnoreCurrentStatus: false,
                Request: {
                    mode: selectedStatus,
                    reasonCode: selectedReasonCodeID ? selectedReasonCodeID : "CB"
                }
            }
        }
        else {
            const isDeactiveStatus = targetStatus?.toLowerCase()==="deactive" || targetStatus?.toLowerCase()==="deactivated"
            const isActiveStatus = targetStatus?.toLowerCase()==="active"

            const ratePlan_= typeof selectedRatePlan ==="string" && !selectedRatePlan.startsWith("missing-code")?selectedRatePlan:null
            let selected_rate_plan
            if (isAdmin){
            const ratePlanNameParts=(ratePlan_ || "").split(" -- ")
            selected_rate_plan = ratePlanNameParts.length>0 ? ratePlanNameParts[0] : null
            }
            else{
                selected_rate_plan = ratePlan_
            }
            changedData = {
                ... (isActiveStatus && {account_number:accountNumber}),
                sim_status:targetStatus,
                device_status_id:selectedStatusID,
                //previously done
                // effective_date:effectiveDate,
                // selectedPublicIpRestriction:selectedPublicIpRestriction,
                // revIoAccountNumber:revIoAccountNumber,
                effectiveDate:effectiveDate,
                // selected_reason_code:selectedReasonCode,

                UpdateStatus: targetStatus,
                ... (isActiveStatus && {publicIpRestriction:selectedPublicIpRestriction,}),
                // PostUpdateStatusId: 8,
                Request: {
                    // ICCID: "89148000001474951901",
                    RatePlanCode: selected_rate_plan,
                    MdnZipCode: mdnZipCode || null,
                    ipAddress: ipAddress || null,
                    ...isDeactiveStatus?{
                        ReasonCode: selectedReasonCodeID || ""
                    }
                    :{},
                    thingSpacePPU: {
                        FirstName: firstName || null,
                        LastName: lastName || null,
                        AddressLine: addressLine || null,
                        City: city || null,
                        State: selectedStateCode || null,
                        ZipCode: mdnZipCode || null,
                        Country: country || null
                    }
                },
                // IntegrationAuthenticationId: 0

            }

        }
        return changedData
    }
    const disablePastDates = (current: any) => {
      return current && current < dayjs().startOf('day');
    };

    // const returnUpdatedValue = () =>{
    //     return (
    //     <Tooltip title={`${targetStatus}`}>
    //         <span>
    //             {targetStatus}
    //         </span>
    //     </Tooltip>)
    // }

    const returnUpdatedValue = () => {
            return (
                <div className="flex flex-col gap-2">
                    <div className="flex grid grid-cols-2 ">
                        <span className="font-semibold">Status:</span>
                        <span>{targetStatus}</span>
                    </div>
                </div>
            )
        }

        useImperativeHandle(ref, () => ({
            runValidation: handleContinue,
            runSubmit: () => {
            selectDevicesRef.current?.runSubmit();
        },
        returnUpdate: returnUpdatedValue
        }));

    return (

        <div className="flex flex-col h-full">
            <div>
                {/* {!showSelectDevices ? ( */}
                    <div className={showSelectDevices ? "hidden" : "block"}>
                        {isAllChangeType && (
                                        <div className="flex justify-end px-4">
                                            <span className="mr-2 font-semibold">Save Changes</span>
                                            <Checkbox
                                                checked={saveChanges}
                                                onChange={(e) => {
                                                    if (!e.target.checked) {
                                                        setsuccessFullChangeTypes(
                                                            successFullChangeTypes.filter((c: any) => c !== activeChange)
                                                        );
                                                    }
                                                    setSaveChanges(e.target.checked)
                                                }}
                                                className="custom-checkbox"
                                            >
                
                                            </Checkbox>
                                        </div>
                                    )}
                    { !isAllChangeType && (
                        <UploadComponent2
                            service_provider={service_provider}
                            change_type={change_type}
                            changed_data={{
                                ...returnChangedData(),
                            }} />
                    )}
                    <div className={`${!isAllChangeType?"flex flex-col space-y-4 my-4":"flex grid grid-cols-2 gap-4"}`}>
                        <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                            <label htmlFor="targetStatus" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                Target Status<span className="text-red-500">*</span>
                            </label>

                            <div className={`${!isAllChangeType?"w-2/3":""}`}>
                                <Select
                                    value={{ label: targetStatus, value: targetStatus }}
                                    id="targetStatus"
                                    placeholder="Select Target Status"
                                    options={statusOptions.map((option: string) => ({
                                        label: option,
                                        value: option,
                                    }))}
                                    onChange={handleSelectedTargetStatusChange}
                                    isClearable
                                    styles={DropdownStyles}
                                    menuPortalTarget={document.body}
                                    menuPosition="fixed"
                                    menuPlacement="auto"
                                />
                                {errors.targetStatus && <div className="text-red-500">{errors.targetStatus}</div>}
                            </div>
                        </div>


                        {(targetStatus === "Active" || targetStatus === "Inventory" || targetStatus === "Pending activation") && (
                            <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                <label htmlFor="ratePlan" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                {isAdmin ? "Rate Plan Code" : "Customer Rate Plan"} {targetStatus === "Active" && <span className="text-red-500">*</span>}
                                </label>
                                <div className={`${!isAllChangeType?"w-2/3":""}`}>
                                    <Select
                                        value={{ label:isAdmin? selectedRatePlan:notAdminSelectedRatePlan, value: selectedRatePlan }}
                                        id="ratePlan"
                                        styles={DropdownStyles}
                                        placeholder={isAdmin ? 'Select Rate Plan Code' : 'Select Customer Rate Plan'}
                                        // options={ratePlanOptions.map((option: string) => ({
                                        //     label: option,
                                        //     value: option,
                                        // }))}
                                        options={ratePlanOptions.map((option: any, index: number) => {
                                                    if (isAdmin) {
                                                        return {
                                                            label: option,
                                                            value: option, // keep it same, but now it's wrapped in an object
                                                        };
                                                    } else {
                                                        return {
                                                            label: option ,
                                                            value: option ,
                                                        };
                                                    }
                                                })
                                        }
                                        onChange={handleSelectedRatePlanChange}
                                        menuPortalTarget={document.body}
                                        menuPosition="fixed"
                                        menuPlacement="auto"
                                        // isClearable
                                    />
                                    {targetStatus === "Active" && errors.ratePlan && (
                                        <div className="text-red-500">{errors.ratePlan}</div>
                                    )}
                                </div>
                            </div>
                        )}
                        {(targetStatus === "Active" ) && (
                            <>
                                <div className={`${!isAllChangeType ? "flex items-center space-x-4" : ""}`}>
                                    <label htmlFor="accountNumber" className={`${!isAllChangeType ? "w-1/3 font-semibold" : "field-label"}`}>
                                        Account Number<span className="text-red-500">*</span>
                                    </label>
                                    <div className={`${!isAllChangeType ? "w-2/3" : ""}`}>
                                        <Select
                                            value={{ label: accountNumber, value: accountNumber }}
                                            id="accountNumber"
                                            styles={DropdownStyles}
                                            placeholder={'Select Account Number'}
                                            options={accountNumberOptions.map((option: string) => ({
                                                label: option,
                                                value: option,
                                            }))}
                                            onChange={handleAccountNumberChange}
                                            menuPortalTarget={document.body}
                                            menuPosition="fixed"
                                            menuPlacement="auto"
                                        // isClearable
                                        />
                                        {errors.account_number && (
                                            <div className="text-red-500">{errors.account_number}</div>
                                        )}
                                    </div>
                                </div>
                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="publicIpRestriction" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        Public IP Restriction
                                    </label>
                                    <div className={`${!isAllChangeType?"w-2/3":""}`}>
                                        <Select
                                            value={{ label: selectedPublicIpRestriction, value: selectedPublicIpRestriction }}
                                            id="publicIpRestriction"
                                            placeholder="Select public IP restriction"
                                            styles={DropdownStyles}
                                            options={publicIpOptions.map((option: string) => ({
                                                label: option,
                                                value: option,
                                            }))}
                                            defaultValue={{ label: 'restricted', value: 'restricted' }}
                                            onChange={handleSelectedPublicIpChange}
                                            menuPortalTarget={document.body}
                                            menuPosition="fixed"
                                            menuPlacement="auto"

                                        />
                                        {errors.publicIpRestriction && <div className="text-red-500">{errors.publicIpRestriction}</div>}

                                    </div>
                                </div>

                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="firstName" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        First Name<span className="text-red-500">*</span>
                                    </label>
                                    <div className={`${!isAllChangeType?"w-2/3":""}`}>
                                        <Input
                                            id="firstName"
                                            placeholder="Enter First Name"
                                            value={firstName}
                                            onChange={(e) => setFirstName(e.target.value)}
                                            className="input"
                                        />
                                        {errors.firstName && <div className="text-red-500">{errors.firstName}</div>}

                                    </div>

                                </div>

                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="lastName" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        Last Name<span className="text-red-500">*</span>
                                    </label>
                                    <div className={`${!isAllChangeType?"w-2/3":""}`}>

                                        <Input
                                            id="lastName"
                                            placeholder="Enter Last Name"
                                            value={lastName}
                                            onChange={(e) => setLastName(e.target.value)}
                                            className="input"
                                        />
                                        {errors.lastName && <div className="text-red-500">{errors.lastName}</div>}
                                    </div>
                                </div>

                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="addressLine" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        Address Line<span className="text-red-500">*</span>
                                    </label>
                                    <div className={`${!isAllChangeType?"w-2/3":""}`}>
                                        <Input
                                            id="addressLine"
                                            placeholder="Enter Address Line"
                                            value={addressLine}
                                            onChange={(e) => setAddressLine(e.target.value)}
                                            className="input"
                                        />
                                        {errors.addressLine && <div className="text-red-500">{errors.addressLine}</div>}
                                    </div>

                                </div>

                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="city" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        City<span className="text-red-500">*</span>
                                    </label>
                                    <div className={`${!isAllChangeType?"w-2/3":""}`}>
                                        <Input
                                            id="city"
                                            placeholder="Enter City"
                                            value={city}
                                            onChange={(e) => setCity(e.target.value)}
                                            className="input"
                                        />
                                        {errors.city && <div className="text-red-500">{errors.city}</div>}

                                    </div>
                                </div>

                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="state" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        State
                                    </label>
                                    <div className={`${!isAllChangeType?"w-2/3":""}`}>
                                        <Select
                                            value={{value:selectedStateCode , label:selectedState}}
                                            id="state"
                                            placeholder="Select State"
                                            options={stateOptions.length > 0 ? stateOptions : [{ value: 'No options', label: 'No options' }]}
                                            styles={DropdownStyles}
                                            onChange={handleSelectedStateChange}
                                            menuPortalTarget={document.body}
                                            menuPosition="fixed"
                                            menuPlacement="auto"
                                        />
                                        {errors.state && <div className="text-red-500">{errors.state}</div>}

                                    </div>
                                </div>

                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="country" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        Country<span className="text-red-500">*</span>
                                    </label>
                                    <div className={`${!isAllChangeType?"w-2/3":""}`}>
                                        <Input
                                            id="country"
                                            placeholder="Enter Country"
                                            value={country} // Assuming this should be the country value
                                            onChange={(e) => setCountry(e.target.value)}
                                            className="input"
                                        />
                                        {errors.country && <div className="text-red-500">{errors.country}</div>}
                                    </div>
                                </div>

                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="mdnZipCode" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        MDN Zip Code<span className="text-red-500">*</span>
                                    </label>
                                    <div className={`${!isAllChangeType?"w-2/3":""}`}>
                                        <Input
                                            id="mdnZipCode"
                                            placeholder="Enter MDN Zip Code"
                                            value={mdnZipCode}
                                            onChange={(e) => setMdnZipCode(e.target.value)}
                                            className="input"
                                        />
                                        {errors.mdnZipCode && <div className="text-red-500">{errors.mdnZipCode}</div>}
                                    </div>
                                </div>

                                {!isVerizon_ && (
                                    <>
                                <div className="flex justify-end px-4">
                                    <Tooltip title="Preview or view IP details">
                                        <InfoIcon
                                            className="h-5 w-5 text-gray-500 cursor-pointer"
                                            onClick={handlePreviewOpen}
                                        />
                                    </Tooltip>
                                </div>

                                    <div className={`${!isAllChangeType ? "flex items-center space-x-4" : ""}`}>
                                    <label
                                        htmlFor="ipAddress"
                                        className={`${!isAllChangeType ? "w-1/3 font-semibold" : "field-label"}`}
                                    >
                                        Private Static IP Address
                                    </label>
                                    {/* <Select
                                            id="ipAddress"
                                            placeholder="Select PDP Name"
                                            options={IPOptions.map((option: string) => ({
                                                label: option,
                                                value: option,
                                            }))}
                                            value={{ label: IpAddress, value: IpAddress }}
                                            onChange={handleIPAddressSelect}
                                            styles={DropdownStyles}
                                            className="w-full"
                                            isClearable
                                        /> */}
                                    <div className={`${!isAllChangeType ? "w-2/3" : ""}`}>
                                        <Input
                                            id="ipAddress"
                                            placeholder="Enter IP Address"
                                            value={ipAddress || ""}
                                            onChange={(e) => {
                                                const v = e.target.value;
                                                setIpAddress(v);
                                                // const res = validateFieldIp(v, IPOptions || []);
                                                const ipResult: any = validateFieldIp([v], IPOptions || []);
                                                setIpError(ipResult?.result || "Enter IP address within the available IP list")
                                            }}
                                            onBlur={(e) => {
                                                const v = e.target.value;
                                                // const res = validateFieldIp(e.target.value, IPOptions || []);
                                                const ipResult: any = validateFieldIp([v], IPOptions || []);
                                                setIpError(ipResult?.result || "Enter IP address within the available IP list")
                                            }}
                                            className="input"
                                        />
                                         {(IpError) && (
                                            <span className="text-red-500">{IpError}</span>
                                        )}
                                        </div>

                                       {/* <div className="text-sm text-blue-500 mt-1">
                                            <span className="block"> Enter IP address within the given ip range: </span>
                                            {IPOptions.map((opt: any) => {
                                                return <span className="font-mono font-semibold block">{opt || ""}</span>

                                            })}
                                        </div>
                                        */}
                                    </div>
                                    </>
                                )}


                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="revIoAccountNumber" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                    Billing Account Number (optional)
                                    </label>
                                    <div className={`${!isAllChangeType?"w-2/3":""}`}>
                                        <Input
                                            id="revIoAccountNumber"
                                            placeholder="Enter Billing Account Number"
                                            value={revIoAccountNumber}
                                            onChange={(e) => setRevIoAccountNumber(e.target.value)}
                                            className="input"
                                        />
                                        {errors.revIoAccountNumber && <div className="text-red-500">{errors.revIoAccountNumber}</div>}
                                    </div>
                                </div>
                            </>
                        )}

                        {targetStatus === "Deactivated" && (
                            <>
                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="reasonCode" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        Reason Code
                                    </label>
                                    <Select
                                        value={{ label: selectedReasonCode, value: selectedReasonCode }}
                                        id="reasonCode"
                                        placeholder="Select Reason Code"
                                        options={reasonCodeOptions}
                                        defaultValue={{ label: 'General/Admin Maintainance', value: 'General/Admin Maintainance' }}
                                        onChange={handleSelectedReasonCodeChange}
                                        className={`${!isAllChangeType?"w-2/3":""}`}
                                        styles={DropdownStyles}
                                        menuPortalTarget={document.body}
                                menuPosition="fixed"
                                menuPlacement="auto"
                                    />
                                </div>

                            </>
                        )}
                        {(targetStatus === "Inventory") && (
                            <>
                                {!isVerizon_ && (
                                    <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                        <label htmlFor="reasonCode" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                            Reason Code
                                        </label>
                                        <Select
                                            value={{ label: selectedReasonCode, value: selectedReasonCode }}
                                            id="reasonCode"
                                            placeholder="Select Reason Code"
                                            options={reasonCodeOptions}
                                            defaultValue={{ label: 'General/Admin Maintainance', value: 'General/Admin Maintainance' }}
                                            onChange={handleSelectedReasonCodeChange}
                                            className={`${!isAllChangeType?"w-2/3":""}`}
                                            styles={DropdownStyles}
                                            menuPortalTarget={document.body}
                                            menuPosition="fixed"
                                            menuPlacement="auto"
                                        />
                                    </div>
                                )}
                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="revIoAccountNumber" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                    Billing Account Number (optional)
                                    </label>
                                    <Input
                                        id="revIoAccountNumber"
                                        placeholder="Enter Billing Account Number"
                                        value={revIoAccountNumber}
                                        onChange={(e) => setRevIoAccountNumber(e.target.value)}
                                        className="w-2/3 input"
                                    />
                                </div>
                            </>
                        )}
                        {(targetStatus === "Pending activation") && (
                            <>
                                {/* {(
                                    <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                        <label htmlFor="reasonCode" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                            Reason Code
                                        </label>
                                        <Select
                                            value={{ label: selectedReasonCode, value: selectedReasonCode }}
                                            id="reasonCode"
                                            placeholder="Select Reason Code"
                                            options={reasonCodeOptions}
                                            defaultValue={{ label: 'General/Admin Maintainance', value: 'General/Admin Maintainance' }}
                                            onChange={handleSelectedReasonCodeChange}
                                            className={`${!isAllChangeType?"w-2/3":""}`}
                                            styles={DropdownStyles}
                                        />
                                    </div>
                                )} */}
                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="revIoAccountNumber" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                    Billing Account Number (optional)
                                    </label>
                                    <Input
                                        id="revIoAccountNumber"
                                        placeholder="Enter Billing Account Number"
                                        value={revIoAccountNumber}
                                        onChange={(e) => setRevIoAccountNumber(e.target.value)}
                                        className="w-2/3 input"
                                    />
                                </div>
                            </>
                        )}
                        {(targetStatus === "Suspended" || targetStatus === "Restore Suspended" || targetStatus === "Cancel Subscriber" || targetStatus === "Restore Cancelled") && (
                            <>

                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="reasonCode" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        Reason Code
                                    </label>
                                    <Select
                                        value={{ label: selectedReasonCode, value: selectedReasonCode }}
                                        id="reasonCode"
                                        placeholder="Select Reason Code"
                                        options={reasonCodeOptions}
                                        defaultValue={{ label: 'General/Admin Maintainance', value: 'General/Admin Maintainance' }}
                                        onChange={handleSelectedReasonCodeChange}
                                        className={`${!isAllChangeType?"w-2/3":""}`}
                                        styles={DropdownStyles}
                                        menuPortalTarget={document.body}
                                        menuPosition="fixed"
                                        menuPlacement="auto"
                                    />
                                </div>
                                {/* <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                <label htmlFor="effectiveDateCheckbox" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                    Effective date
                                </label>
                                <Checkbox
                                    id="effectiveDateCheckbox"
                                    checked={effectiveDateCheckbox}
                                    onChange={(e) => setEffectiveDateCheckbox(e.target.checked)}
                                />
                            </div> */}

                                {/* Effective Date */}
                                {/* {effectiveDateCheckbox && (
                                <div className="flex flex-col space-y-1">
                                    <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                        <label htmlFor="effectiveDate" className="w-1/3 font-semibold ">
                                            Effective date
                                        </label>
                                        <DatePicker
                                            value={effectiveDate}
                                            onChange={(date) => setEffectiveDate(date)}
                                            className={`${!isAllChangeType?"w-2/3":""}`}
                                            format="DD/MM/YYYY"
                                            placeholder="DD/MM/YYYY"
                                        />
                                    </div>
                                    {effectiveDateError && (
                                        <div className="text-red-500 text-sm">
                                            {effectiveDateError}
                                        </div>
                                    )}
                                </div>
                            )} */}
                                {targetStatus !== "Restore Cancelled" && (
                                    <>
                                        <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                            <label htmlFor="effectiveDateCheckbox" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                                Effective Date
                                            </label>
                                            <Checkbox
                                                id="effectiveDateCheckbox"
                                                checked={effectiveDateCheckbox}
                                                onChange={(e) => setEffectiveDateCheckbox(e.target.checked)}
                                            />
                                        </div>

                                        {/* Effective Date */}
                                        {effectiveDateCheckbox && (
                                            <div className="flex flex-col space-y-1">
                                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                                    <label htmlFor="effectiveDate" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                                        Effective Date <span className="text-red-500">*</span>
                                                    </label>
                                                    <DatePicker
                                                        value={effectiveDate}
                                                        onChange={(date) => setEffectiveDate(date)}
                                                        className={`${!isAllChangeType?"w-2/3":"input"}`}
                                                        format="DD/MM/YYYY"
                                                        placeholder="DD/MM/YYYY"
                                                        disabledDate={disablePastDates}
                                                    />
                                                </div>
                                                {errors.effectiveDate && (
                                                    <div className="text-red-500 text-sm">
                                                        {errors.effectiveDate}
                                                    </div>
                                                )}
                                            </div>
                                        )}
                                    </>
                                )}

                            </>
                        )}


                        {/* Action Buttons */}
                        {!isAllChangeType && (
                            <div className="flex justify-center space-x-4 mt-4">
                            <button onClick={onBack} className="cancel-btn">
                                {/* <ArrowLeftIcon className="h-5 w-5 mr-2" /> */}
                                Back
                            </button>
                            <button onClick={handleContinue} className="save-btn">
                                Continue
                                {/* <ArrowRightIcon className="h-5 w-5 mr-2" /> */}
                            </button>
                        </div>
                        )}
                        
                    </div>
                    </div>
                {/* ) : ( */}
                    <div className={showSelectDevices ? "block" : "hidden"}>
                    <SelectDevices targetStatus= {targetStatus ?? undefined}  ref={selectDevicesRef} onContinue={handleContinue} onBack={onBack} service_provider={service_provider} change_type={change_type} changed_data={returnChangedData()} onCancel={onClose}/>
                    </div>
                {/* )} */}
            </div>
            <PreviewModal
                service_provider={service_provider}
                change_type={change_type}
                openPreviewModal={openPreviewModal}
                setPreviewModal={setPreviewModal}
            />
        </div>
    );
}
)

export default Activated1;
