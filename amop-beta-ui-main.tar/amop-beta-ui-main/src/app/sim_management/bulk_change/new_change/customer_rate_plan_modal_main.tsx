"use client";

import { FC, forwardRef, useCallback, useEffect, useImperativeHandle, useState } from "react";
import { Input, Button, DatePicker, Checkbox, Modal, Spin, Table, Tooltip } from "antd";
import { ArrowLeftIcon, ArrowRightIcon, EyeIcon } from "@heroicons/react/24/outline";
import Select from "react-select";
import SelectDevices from "./select_devices";
import dayjs, { Dayjs } from "dayjs";
import React from "react";
import UploadComponent from "./upload_component";
import { DropdownStyles } from "@/app/components/css/dropdown";
import { useAuth } from "@/app/components/auth_context";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { useFeatureStore } from "../../inventory/featureStore";
import { useRouter } from 'next/navigation';
import VirtualizedSelect from "@/app/components/virtualized_dropdown";
import DisconnectProductTable from "@/app/components/revTableComponent/disconnectProductTable";
import TableSearch from "@/app/components/entire_table_search";
import TableComponent from "@/app/components/TableComponent/page";
import PreviewModal from "./previewModal";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { useAllChangeTypesStore } from "@/app/stores/allChangeTypesStore";
import { PerformanceLogStore } from "@/app/stores/performance_matrix_store";
import UploadComponent2 from "./upload_component_2";
import { useInventoryAllChangeTypesStore } from "@/app/stores/inventorytAllChangeTypesStore";
import moment , { Moment } from "moment";
interface CustomerRatePlanProps {
    onContinue: () => void;
    onBack: () => void;
    dropdown: any;
    service_provider: any;
    change_type: any;
    isSubmitScreen: boolean;
    onClose: () => void;
}
export interface CustomerRatePlanContentRef {
  runValidation: () => Promise<void> | void;
  runSubmit: () => Promise<void> | void;
  returnUpdate: () => React.ReactNode | Promise<React.ReactNode>;
}

const ChangeCustomerRatePlan = forwardRef<CustomerRatePlanContentRef, CustomerRatePlanProps>(
    ({ onContinue, onBack, dropdown, service_provider, change_type, isSubmitScreen, onClose }, ref) => {
    const [customerRatePlan, setCustomerRatePlan] = useState<string | null>(null);
    const [effectiveDateChecked, setEffectiveDateChecked] = useState<boolean>(true);
    const [effectiveDate, setEffectiveDate] = useState<moment.Moment | null>(null);
    const [isCustomDateChecked, setIsCusomDateChecked] = useState<boolean>(false);
    const [selectedDateOption, setSelectedDateOption] = useState<string | null>(null);
    const [effectiveDateOptions, setEffectiveDateOptions] = useState<any[]>([]);
    const [effectiveDateOptionsMap, setEffectiveDateOptionsMap] = useState<any>({});

    const [customerRatePool, setCustomerRatePool] = useState<string | undefined>(undefined);
    const [showSelectDevices, setShowSelectDevices] = useState(false);
    const [errors, setErrors] = useState<any>([]);
    const [ratePlanOptions, setRatePlanOptions] = useState<any>([]);
    const [customerPoolOptions, setCustomerPoolOptions] = useState<any>([]);
    const { username, role, partner, token, selectedDb, firstLastName, sessionId, modulesVersionMap,metaData } = useAuth();
    const [isRedirected, setIsRedirected] = useState(false);
    const { setRowId, setBulkRow, activationPayload ,simIdentifierMap} = useFeatureStore();
    const router = useRouter();
    const initial_version_flag = modulesVersionMap?.["Sim Management-Bulk Change"] || false
    const isVersionEnabled = localStorage.getItem("switch_user_2_0_bulk_change") === "True";
    const switch_user_2_0 = isVersionEnabled && initial_version_flag ? "True" : "False"
    const [loading, setLoading] = useState(false);
    const [activationFlag, setActivationFlag] = useState(false);
    const [useCarrierActivation, setUseCarrierActivation] = useState<boolean>(false);
    const [revCustomersOptions, setRevCustomersOptions] = useState<any>([]);
    const [revCustomer, setRevCustomer] = useState<any[]>([]);
    const [openPreviewModal, setPreviewModal] = useState<boolean>(false);
    const [tableData, setTableData] = useState<any>([]);
    const [headers, setHeaders] = useState<any[]>([]);
    const [headerMap, setHeaderMap] = useState<any>({});
    const [pagination, setPagination] = useState<any>({});
    const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
    const [searchTerm, setSearchTerm] = useState("");
    const [theme, setTheme] = useState('normal');
    const { addExport, removeExport, exports } = exportLoadingStore();
    const { isAllChangeType,setIsValidated,setValidationTrigger,allChangeTypesDevices, setsuccessFullChangeTypes, activeChange, successFullChangeTypes, all_2_0_payloads, set_all_2_0_payloads  } = useAllChangeTypesStore();
    const [saveChanges, setSaveChanges] = useState<boolean>(true);
    const { getTargetTenantProvider, IsTargetTenantProvider } = PerformanceLogStore();
    const is_parent_provider_exists = IsTargetTenantProvider(service_provider)
    const providerName = getTargetTenantProvider(service_provider).toLowerCase() || service_provider;
    const {setCustomerRatePlanData } = useInventoryAllChangeTypesStore();
    useEffect(() => {
        if (typeof window !== 'undefined') {
            try {
                const storedTheme = localStorage.getItem('app_theme');
                if (storedTheme) setTheme(storedTheme);
            } catch (e) {
                console.warn("Error reading theme from localStorage:", e);
            }
        }
    }, []);

    useEffect(() => {
        if (isSubmitScreen && !isRedirected && !isAllChangeType) {
            setShowSelectDevices(true)
        }
        else{
            setShowSelectDevices(false)
        }
    }, [isSubmitScreen, isRedirected, isAllChangeType])

    useEffect(()=>{
        if(!effectiveDateChecked){
            delete errors.effectiveDate
        }
    },[effectiveDateChecked])

    useEffect(() => {
        // console.log("dropdown", dropdown);
        const customer_rate_plan_dropdown = dropdown?.customer_rate_plan_dropdown || [];
        setRatePlanOptions([
            { label: "No Change", value: "No Change" }, // Add No Change option first
            ...customer_rate_plan_dropdown.map((option: string) => ({
                label: option,
                value: option,
            }))
        ]);

        const billing_start_dates_options_map = dropdown?.billing_start_dates || {};
        setEffectiveDateOptionsMap(billing_start_dates_options_map)
        setEffectiveDateOptions([
            ...Object.keys(billing_start_dates_options_map).map((option: string) => ({
                label: option,
                value: option,
            }))
        ]);

        const customer_rate_pool_dropdown = dropdown?.customer_rate_pool_dropdown || [];
        setCustomerPoolOptions([
            { label: "No Change", value: "No Change" }, // Add No Change option first
            ...customer_rate_pool_dropdown.map((option: string) => ({
                label: option,
                value: option,
            }))
        ]);
        fetchCustomerOptions()
    }, [dropdown]);

    const getAvailableOptions = (allOptions: any[], selectedOptions: any[]) => {
        // console.log("getAvailableOptions", selectedOptions)
        const selectedValues = selectedOptions.map((opt) => JSON.stringify(opt.value));
        return allOptions.filter(
            (opt) => !selectedValues.includes(JSON.stringify(opt.value))
        );
    };

    const handleRevCustomer = (selectedOptions: any) => {
        // const selectedOptions_ = selectedOptions.map((option: any) => option.value);
        setRevCustomer(selectedOptions);
    };

    const fetchCustomerOptions = async () => {
        try {
            setLoading(true);
            const url =
                ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                path: "/get_assign_customer_bulk_change_data",
                request_received_at: getCurrentDateTime(),
                username: username,
                firstLastName: firstLastName,
                role_name: role,
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: service_provider,
                ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                setLoading(false);
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                const options_ = parsedData?.dropdown_data?.rev_customer_dropdown || []
                const formatted_options = options_.map((opt: any) => ({ label: opt, value: opt }))
                setRevCustomersOptions(formatted_options)
                setLoading(false);
            }
        } catch (error) {
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        }
    };
    type HeaderMap = Record<string, [string, number]>;
    const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
        const entries = Object.entries(headerMap) as [string, [string, number]][];
        entries.sort((a, b) => a[1][1] - b[1][1]);
        return Object.fromEntries(entries) as HeaderMap;
    }, []);


    const fetchActivationFlag = async (value: string) => {
        const customerRatePlan_ = (value && value !== 'No options') ? value : null
        let ratePlanNameParts = []
        ratePlanNameParts = (customerRatePlan_ || "").split(" -- ")
        const customer_rate_plan_ = ratePlanNameParts && ratePlanNameParts.length > 0 ? ratePlanNameParts[0] : null
        try {
            setLoading(true);
            const url =
                ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                path: "/crp_carrier_activation_flag",
                request_received_at: getCurrentDateTime(),
                username: username,
                firstLastName: firstLastName,
                role_name: role,
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: service_provider,
                ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type,
                customer_rate_plan: customer_rate_plan_,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                setLoading(false);
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                const activation_flag = parsedData?.use_carrier_activation || false
                setActivationFlag(activation_flag)
                // if (activation_flag) {
                //     setUseCarrierActivation(true)
                //     setEffectiveDateChecked(false)
                // }
                // else{
                //     setUseCarrierActivation(false)
                //     setEffectiveDateChecked(true)
                // }
                setLoading(false);
            }
        } catch (error) {
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        }
    };

    const fetchCarrierWritesFlag = async () => {
        let parsedData: any
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
            tenant_name: partner || "default_value",
            username,
            path: "/get_writes_enable_for_service_provider",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "Inventory",
            service_provider: service_provider || "",
            ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            environment: "BETA",
            change_type: change_type,
        };

        try {
            setLoading(true);
            const response = await axios.post(url, { data });
            parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === true) {
                const write_is_enabled = parsedData?.write_is_enabled || false;
                // setWritesFlag(write_is_enabled);
                return write_is_enabled;
            }
        } catch (error) {
            console.error("Error fetching data:", error);
            return false; // fallback in case of error
        } finally {
        }
    };
    const submitCarrierStatus = async (payload: { iccids: any; imeis: any; }, write_is_enabled:boolean) => {
        let parsedData: any
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
            tenant_name: partner || "default_value",
            username,
            path: "/insert_carrier_status_validation_audit",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "Inventory",
            service_provider: service_provider || "",
            ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            environment: "BETA",
            msisdn: [],
            iccid: payload?.iccids,
            change_type: change_type,
             write_is_enabled:write_is_enabled,
        };

        try {
            // setLoading(true);
            const response = await axios.post(url, { data });
            parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === true) {

            }
        } catch (error) {
            console.error("Error fetching data:", error);
        } finally {
            // setLoading(false);
        }
    };

    const callKoreSync = async (data: any) => {
        const koreUrl = ENV_ROUTES.SM_BULK_CHANGE;
        let koreData = { ...data }
        koreData["path"] = "/start_sync"

        try {
            const koreResponse = await axios.post(koreUrl, { data: koreData });
            const koreResponseData = JSON.parse(koreResponse.data.body);

            if (koreResponseData.flag === false) {
                console.log("Data Fetch Error: " + koreResponseData.message);
            } else {
                console.log("Success: Bulk update successful.");
            }

        }
        catch {
            console.log("error in Start Sync");
        }
    }
    const bulkChangeInsert = async (payload:any) => {
    let partner_name = partner
    let db_name_ = selectedDb
    try {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner_name || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_bulk_change_insertion",
        role_name: role,
        module_name: "Bulk Change History",
        service_provider_name:service_provider,
        ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
        change_type:change_type,
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
        request_received_at: getCurrentDateTime(),
        Partner: partner_name,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        console.error("Error fetching bulk change data:", parsedData.message ||
          "An error occurred while fetching bulk change data. Please try again.");
          return false
      } else {
        const statusFlag = parsedData?.bulk_change_data?.status || "";
        const response_data = parsedData?.bulk_change_data?.bulk_change_data || "{}";
        const parsedResp = JSON.parse(response_data)
        console.log("status_flag", statusFlag)
        const status_flag = statusFlag ? (statusFlag).toLowerCase() : ""

        if(status_flag && status_flag==="pending"){
          return false
        }
        else if (status_flag && status_flag==="success"){
            call_2_0_submit(parsedResp, payload, false);
            call_2_0_sync(parsedResp)
            return true
        }
        else if (status_flag && status_flag==="error"){
            Modal.error({
                title: 'Submit Error',
                content: parsedData.message || 'An error occurred while submitting. Please try again.',
                centered: true,
            });
            return true
        }
        else{
          return false
        }
      }
    } catch (error) {
      console.error("Error fetching auto refresh data:", error);
      return false
    } finally {
    }
  };
  const bulkChangePolling = async (data:any) => {
    const result = await bulkChangeInsert(data);
    if (!result) {
      setTimeout(() => bulkChangePolling(data), 5000); // Try again after 5 seconds
    } else {
      removeExport("bulkChangeInsert");
      console.log("Auto-refresh complete.");
    }
    // if (window.location.pathname.includes("/sim_management/bulk_change")) {
    //     window.location.reload();
    // }
  };

  const fetchDevices = async (devices_list: any, deviceKey: string) => {
    try {
      setLoading(true);
      const url =
        ENV_ROUTES.BULKCHANGE_PROCESSOR;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_standard_iccid_msisdn_data",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        service_provider: service_provider,
        ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" },
        change_type: change_type,
        [deviceKey]: devices_list || []
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        // setLoading(false);
        Modal.error({
          title: 'Submit Error',
          content: parsedData.message || 'An error occurred while submitting data. Please try again.',
          centered: true,
        });
        return []
      } else {
        let responseKey = deviceKey === "iccids" ? "msisdns" : "iccids"
        let devices = parsedData?.[responseKey] || []
        console.log("devices", devices)
        return devices
        // setLoading(false);
      }
    } catch (error) {
      Modal.error({
        title: 'Submit Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting data. Please try again.',
        centered: true,
      });
      return []
      // setLoading(false);
    }
    finally {
      // setLoading(false)
    }
  };
  const getIccidList = async (iccids_: any[], isMSISDN: boolean): Promise<string[]> => {
    // Pick devices based on subscriberNumber or iccids
    const devices_ = iccids_;

    // Find matching device type from the map
    const matchedDeviceTypeItem = simIdentifierMap.find((item: any) => {
      return (
        item.service_provider === service_provider &&
        item.change_type === change_type
      );
    });
    const matchedDeviceType = matchedDeviceTypeItem?.sim_identifier || ""
    // Decide expected type
    const selectDeviceType = isMSISDN ? "msisdns" : "iccids";
    const selectedIMEIType = isMSISDN ? "msisdns_imei_map" : "iccids_imei_map"
    // Split devices into a list
    let iccidList: any = devices_

    let iccidMap: Record<string, string> = {};
    console.log("iccidMap", iccidMap)
    console.log("iccidList", iccidList)


    // Fetch devices only if types mismatch
    if (matchedDeviceType !== selectDeviceType) {
      iccidList = await fetchDevices(iccidList, selectDeviceType);
    }
    else {
      iccidList = iccids_
    }

    return iccidList;
  };


    const onsubmit = async (payload: any) => {
        let data
        try {
            let iccidList = payload.iccids || []
            if(isAllChangeType){
                const devices = allChangeTypesDevices?.iccids || []
                const isIccid = allChangeTypesDevices?.isIccid
                iccidList = await getIccidList(devices,!isIccid)
                console.log(iccidList, "show the iccid list");
            }
            setLoading(true)
            const returnChangedData_ = returnChangedData()
            const changedData = returnChangedData_ ? { ...returnChangedData_ } : {};

            // Prepare payload for the first API
            const url = ENV_ROUTES.SIM_MANAGEMENT;
            data = {
                tenant_name: partner || "default_value",
                path: "/update_bulk_change_data",
                role_name: role,
                username: username,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: service_provider,
                ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type,
                created_by: firstLastName,
                iccids: iccidList,
                imeids: payload.imeis,
                use_carrier_activation:useCarrierActivation,
                changed_data: {
                    OverrideValidation: false,
                    Devices: iccidList,
                    ...changedData
                }
            };

            // Send request to the first API
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === false) {
                Modal.error({
                    title: 'Submit Error',
                    content: parsedData.message || 'An error occurred while submitting. Please try again.',
                    centered: true,
                });
                return;
            }

            if (isSubmitScreen) {
                callBPSync(parsedData, data)
            }
            const bulkrow_ = parsedData?.bulkchange_id || {};
            const bulkRow: any = { row: bulkrow_ };
            setBulkRow(bulkRow);
            localStorage.setItem('bulk_row', JSON.stringify(bulkRow || "{}"));
            if (bulkRow) {
                if(!isAllChangeType){
                    router.push(`/sim_management/bulk_history`);
                }
            }

            let type = change_type.toLowerCase()

            if (service_provider.toLowerCase().includes("kore") && switch_user_2_0 !== "True") {
                const path = "/update_customer_rate_plan";
                // Prepare payload for the first API
                const url = ENV_ROUTES.SM_BULK_CHANGE;
                let changed_customer_rate_plan_data: any = { ...changedData }
                // changed_customer_rate_plan_data["CustomerRatePlanUpdate"]["CustomerRatePlanId"] = changed_customer_rate_plan_data["CustomerRatePlanUpdate"]["CustomerRatePlanId"] && changed_customer_rate_plan_data["CustomerRatePlanUpdate"]["CustomerRatePlanId"] !== -1 ? changed_customer_rate_plan_data["CustomerRatePlanUpdate"]["CustomerRatePlanId"] : ""
                // changed_customer_rate_plan_data["CustomerRatePlanUpdate"]["CustomerRatePoolId"] = changed_customer_rate_plan_data["CustomerRatePlanUpdate"]["CustomerRatePoolId"] && changed_customer_rate_plan_data["CustomerRatePlanUpdate"]["CustomerRatePoolId"] !== -1 ? changed_customer_rate_plan_data["CustomerRatePlanUpdate"]["CustomerRatePoolId"] : ""

                const data: any = {
                    tenant_name: partner || "default_value",
                    path: path,
                    request_received_at: getCurrentDateTime(),
                    access_token: token,
                    db_name: selectedDb,
                ...metaData,
                    sessionID: sessionId,
                    service_provider: service_provider,
                    ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                    change_type: change_type,
                    bulk_change_id: parsedData?.bulkchange_id?.id,
                    data: parsedData?.data,
                    created_by: firstLastName,
                    iccids: payload.iccids,
                    imeids: payload.imeis,
                    changed_data: {
                        OverrideValidation: false,
                        Devices: payload.iccids,
                        ...changed_customer_rate_plan_data,
                    },
                    updated_data: {
                        CustomerRatePlanUpdate: {
                            effective_date: changed_customer_rate_plan_data?.CustomerRatePlanUpdate?.EffectiveDate || "",
                            customer_rate_plan_name: changed_customer_rate_plan_data?.CustomerRatePlanUpdate?.CustomerRatePlanId || "",
                            customer_rate_pool_name: changed_customer_rate_plan_data?.CustomerRatePlanUpdate?.CustomerRatePoolId || "",

                        }
                    }
                };
                const kore_response = await axios.post(url, { data });
                const kore_parsedData = JSON.parse(kore_response.data.body);

                if (kore_parsedData.flag === false) {
                    console.error("Data Fetch Error: " + kore_parsedData.message);
                } else {
                    console.log("Success: Bulk update successful.");
                }
                const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
                data["service_provider_id"] = service_provider_id_
                callKoreSync(data)
            }
            else {
                // Call run_db_script API
                const isTelegence = providerName.toLowerCase().includes("telegence");
                const isWebbing = providerName.toLowerCase().includes("webbing") || providerName.toLowerCase().includes("multi-carrier sim");
                const isVerizon = (providerName.toLowerCase().includes("verizon") || providerName.toLowerCase().includes("vzn") || providerName.toLowerCase().includes("vzwcr") || providerName.toLowerCase().includes("2215-so01"));
                const isPod19 = providerName.toLowerCase().includes("pod19");
                const isPondIOT = providerName.toLowerCase().includes("pond");
                const isJasper = providerName.toLowerCase().includes("jasper");
                const isKore = providerName.toLowerCase().includes("kore");
                const isTeal = providerName.toLowerCase().includes("teal")
                const isRogers = providerName.toLowerCase().includes("rogers");

                if ((switch_user_2_0 === "True" && (isTelegence || isVerizon || isPod19 || isPondIOT || isJasper || isKore || isTeal || isRogers)) || isWebbing) {
                    if(!isAllChangeType){
                        call_2_0_submit(parsedData, data, true);
                        call_2_0_sync(parsedData);
                    }
                    else{
                        const payload_2_0_:any = await call_2_0_submit(parsedData, data, false)
                        const all_2_0_payloads_ = {... all_2_0_payloads,[change_type]:{...payload_2_0_}}
                        set_all_2_0_payloads((prev: any) => ({
                            ...prev,
                            [change_type]: { ...payload_2_0_ }
                        }));
                    }
                }
                else {
                    await callRunDbScript(parsedData);
                }
                // await callSyncLambda()
            }
        } catch (error) {
            const isTelegence = providerName.toLowerCase().includes("telegence");
            const isWebbing = providerName.toLowerCase().includes("webbing") || providerName.toLowerCase().includes("multi-carrier sim");
            const isVerizon = (providerName.toLowerCase().includes("verizon") || providerName.toLowerCase().includes("vzn") || providerName.toLowerCase().includes("vzwcr") || providerName.toLowerCase().includes("2215-so01"));
            const isPod19 = providerName.toLowerCase().includes("pod19");
            const isPondIOT = providerName.toLowerCase().includes("pond");
            const isJasper = providerName.toLowerCase().includes("jasper");
            const isKore = providerName.toLowerCase().includes("kore");
            const isTeal = providerName.toLowerCase().includes("teal")
            const isRogers = providerName.toLowerCase().includes("rogers");
            if ((switch_user_2_0 === "True" && (isTelegence || isVerizon || isPod19 || isPondIOT || isJasper || isKore || isTeal || isRogers)) || isWebbing) {
                onClose()
                setLoading(false)
                addExport("bulkChangeInsert", "Bulk Change Submission");
                bulkChangePolling(data)
            }
            else{
                Modal.error({
                title: 'Submit Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting. Please try again.',
                centered: true,
            });
            }
        } finally {
            setLoading(false)
        }
    };

    const callBPSync = async (parsedData: any, payload: any) => {
        const isTelegence = providerName.toLowerCase().includes("telegence");
        const isWebbing = providerName.toLowerCase().includes("webbing") || providerName.toLowerCase().includes("multi-carrier sim");
        const payload_data = { ...payload }
        try {
            let prevChangedData
            let lowerCase_customer_name_
            let customerNameParts = []
            let original_customer
            let selected_customers = revCustomer && revCustomer.length > 0 ? revCustomer.map((opt: any) => (opt?.value || "")) : null
            lowerCase_customer_name_ = selected_customers ? selected_customers[0].toLowerCase() : ""
            original_customer = selected_customers ? selected_customers[0] : ""
            if (lowerCase_customer_name_.endsWith(" -- bp") || lowerCase_customer_name_.endsWith(" -- revio")) {
                original_customer = original_customer.replace(" -- BP", "").replace(" -- RevIO", "");
            }
            if (original_customer) {
                customerNameParts = (original_customer || "").split(" -- ")
            }
            delete payload_data["changed_data"]
            const url = ENV_ROUTES.SM_BULK_CHANGE;
            const payloadData = {
                ...payload_data,
                path: "/bulk_update_assign_customer_bp",
                request_received_at: getCurrentDateTime(),
                bulk_change_id: parsedData?.bulk_chnage_id_20,
                customer_name: customerNameParts && customerNameParts.length > 0 ? customerNameParts[0] : null,
                customer_id: customerNameParts && customerNameParts.length > 0 ? customerNameParts[1] : null
                // changed_data: { ...newChangedData }
            }
            const data = { ...payloadData };
            const response = await axios.post(url, { data });
            const responseData = JSON.parse(response.data.body);
            if (responseData.flag === false) {
                console.log("Failure: 2.0 Bulk change update failed.");
            } else {
                console.log("Success: 2.0 Bulk change update successful.");
            }
        }
        catch (error) {
            console.error("Error running DB script:", error);
        } finally {
        }
    }

    const callSyncLambda = async () => {
        try {
            const url = ENV_ROUTES.OPTIMIZATION_SYNC_LAMBDA;
            const data = {
                key_name: "bulk_chnage_history",
                path: "/lambda_sync_jobs_",
                tenant_name: partner
            };

            const response = await axios.post(url, { data });
            const responseData = JSON.parse(response.data.body);

            if (responseData.flag === false) {
                console.error("Data Fetch Error: " + responseData.message);
            } else {
                console.log("Success: Bulk update successful.");
            }
        } catch (error) {
            console.error("Error fetching data:", error);
        }
    };
    const call_2_0_sync = async (parsedData: any) => {
        try {
            const runDbScriptUrl = ENV_ROUTES.SIM_MANAGEMENT;
            const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
            const runDbScriptData = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/update_bulk_change_tables_10",
                role_name: role,
                module_name: "Bulk Change",
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                // service_provider_id: service_provider_id_,
                // bulkchange_id: parsedData?.bulkchange_id?.id,
                // data: parsedData?.data,
                data: {
                    bulk_change_id: parsedData?.bulk_chnage_id_20,
                },
                is_update: false,
                // bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
            };

            const runDbScriptResponse = await axios.post(runDbScriptUrl, { data: runDbScriptData });
            const runDbScriptResponseData = JSON.parse(runDbScriptResponse.data.body);

            if (runDbScriptResponseData.flag === false) {
                console.error("Data Fetch Error: " + runDbScriptResponseData.message);
            } else {
                console.log("Success: Bulk update successful.");
            }
        }
        catch (error) {
            console.error("Error running DB script:", error);
        } finally {
        }
    }
    const call_2_0_submit = async (parsedData: any, payload: any, isRouteCall:boolean) => {
        const isTelegence = providerName.toLowerCase().includes("telegence");
        const isWebbing = providerName.toLowerCase().includes("webbing") || providerName.toLowerCase().includes("multi-carrier sim");
        const isVerizon = (providerName.toLowerCase().includes("verizon") || providerName.toLowerCase().includes("vzn") || providerName.toLowerCase().includes("vzwcr") || providerName.toLowerCase().includes("2215-so01"));
        try {
            let prevChangedData
            let newChangedData
            const changeType = change_type ? change_type.toLowerCase() : ""
            let ratePlanNameParts = []
            let ratePoolNameParts = []
            prevChangedData = payload?.changed_data?.CustomerRatePlanUpdate || {}
            if (prevChangedData?.CustomerRatePlanId && prevChangedData?.CustomerRatePlanId !== -1 && prevChangedData?.CustomerRatePlanId !== -2) {
                ratePlanNameParts = (prevChangedData?.CustomerRatePlanId || "").split(" -- ")

            }
            if (prevChangedData?.CustomerRatePoolId && prevChangedData?.CustomerRatePoolId !== -1 && prevChangedData?.CustomerRatePoolId !== -2) {
                ratePoolNameParts = (prevChangedData?.CustomerRatePoolId || "").split(" -- ")

            }

            newChangedData = {
                customer_rate_plan_name: ratePlanNameParts && ratePlanNameParts.length > 0 ? ratePlanNameParts[0] : null,
                customer_rate_pool_name: ratePoolNameParts && ratePoolNameParts.length > 0 ? ratePoolNameParts[0] : null,
                effective_date: prevChangedData?.EffectiveDate || "",
            }
            if (isTelegence) {
                payload["msisdns"] = payload?.iccids
                delete payload["iccids"]
                delete payload["imeids"]
            }
            else {
                delete payload["imeids"]
            }

            let path_ = isFutureDate(effectiveDate) ? "/schedule_bulk_change_execution" : "/bulk_change_processor"
            const url = ENV_ROUTES.BULKCHANGE_PROCESSOR;
            const payloadData = {
                ...payload,
                path: path_,
                request_received_at: getCurrentDateTime(),
                bulk_change_id: parsedData?.bulk_chnage_id_20,
                ...(!isVerizon?{changed_data: { ...newChangedData }}:{})
            }
            const data = { ...payloadData };
            if(!isRouteCall){
                return {
                    ... data,
                    ...(isFutureDate(effectiveDate) && {is_future : true})
                };
            }
            const response = await axios.post(url, { data });
            const responseData = JSON.parse(response.data.body);
            if (responseData.flag === false) {
                console.log("Failure: 2.0 Bulk change update failed.");
            } else {
                console.log("Success: 2.0 Bulk change update successful.");
            }
        }
        catch (error) {
            console.error("Error running DB script:", error);
        } finally {
        }
    }
    // Helper function to call run_db_script API
    const callRunDbScript = async (parsedData: any) => {
        const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
        console.log("parsedData", parsedData)
        try {
            const url = ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/run_db_script",
                role_name: role,
                module_name: "Bulk Change",
                mod_pages: { start: 0, end: 100 },
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                service_provider_id: service_provider_id_,
                bulkchange_id: parsedData?.bulkchange_id?.id,
                data: parsedData?.data,
                bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
                verizon_inventory_flag: false,
                use_carrier_activation:useCarrierActivation,
            };

            const response = await axios.post(url, { data });
            const responseData = JSON.parse(response.data.body);

            if (responseData.flag === false) {
                console.error("Data Fetch Error: " + responseData.message);
            } else {
                console.log("Success: Bulk update successful.");
            }
        } catch (error) {
            console.error("Error fetching data:", error);
        }
        };
        
    type CustomerRatePlanUpdate = {
    EffectiveDate: Moment | null;
    CustomerRatePlanId: string | number | null;
    CustomerRatePoolId: string | number | null;
    customerName?: string;
    };

    type ChangedData = {
    CustomerRatePlanUpdate?: CustomerRatePlanUpdate;
    };

        const confirmCarrierActivation = () => {
            return new Promise<boolean>((resolve) => {
                Modal.confirm({
                    title: "Warning",
                    content: "Are you sure you want to proceed with Carrier Activation Date",
                    centered: true,
                    onOk: () => resolve(true),
                    onCancel: () => resolve(false),
                });
            });
        };

    const handleContinue = async () => {
        const newErrors: any = {};

        if (!isAllChangeType) {
            if (isSubmitScreen && !effectiveDateChecked && !useCarrierActivation) {
                Modal.warning({
                    title: "Warning",
                    content: "Either Carrier Activation or Effective Date is required.",
                    centered: true,
                });
                return
            }
            if (useCarrierActivation) {
                const proceed = await confirmCarrierActivation();
                if (!proceed) return; // Stop execution
            }
        }
        
        if (!customerRatePlan) {
            newErrors.customerRatePlan = "Customer rate plan is required.";
        }

        if (effectiveDateChecked && !effectiveDate) {
            newErrors.effectiveDate = "Effective date is required when 'Effective date' is checked.";
        }
        if (revCustomer && revCustomer.length > 1) {
            newErrors.revCustomer = "Single Billing customer is allowed.";
        }

        if (Object.keys(newErrors).length > 0) {
            setsuccessFullChangeTypes(
                    successFullChangeTypes.filter((c: any) => c !== activeChange)
                );
            if(isAllChangeType){
                if ((revCustomer.length === 0 && !customerRatePlan && !customerRatePool &&!effectiveDate && !effectiveDateChecked) || !saveChanges) {
                    setErrors({});
                    setIsValidated(true)
                    setValidationTrigger();
                    return
                }
                else{
                    setIsValidated(false)
                    setErrors(newErrors);
                    setValidationTrigger();
                    return
                }

            }else{
                console.log("new errors", newErrors)
                setErrors(newErrors);
                return;
            }
        }

        setErrors({});
        if (saveChanges && isAllChangeType) {
            if (isSubmitScreen && !effectiveDateChecked && !useCarrierActivation) {
                Modal.warning({
                    title: "Warning",
                    content: "Either Carrier Activation or Effective Date is required.",
                    centered: true,
                });
                return
            }
            if (useCarrierActivation) {
                const proceed = await confirmCarrierActivation();
                if (!proceed) return; // Stop execution
            }
            const returnChangedData_ = returnChangedData();

            const changedData_: ChangedData = returnChangedData_
                ? { ...returnChangedData_ }
                : {};

            const crpUpdate = changedData_?.CustomerRatePlanUpdate;

            if (crpUpdate) {
                const customerName =
                    crpUpdate.customerName?.split(" -- ")?.[0] || null;

                const mappedData = {
                    customer_rate_plan_name: crpUpdate.CustomerRatePlanId,
                    customer_rate_pool_name: crpUpdate.CustomerRatePoolId,
                    customer_name: customerName || null,
                    effective_date: crpUpdate.EffectiveDate || "",
                };
                console.log("mappedData",mappedData)
                setCustomerRatePlanData(mappedData);
            }
            setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
        }
        setIsValidated(true)
        setValidationTrigger()
        if(!isAllChangeType){
            if (isSubmitScreen) {
            const writes_flag = await fetchCarrierWritesFlag()

            if (writes_flag) {
                const modal = Modal.confirm({
                    title: "Carrier API Enabled",
                    content: "Carrier API settings are enabled. Submitting now will trigger the Carrier API directly. Do you want to proceed?",
                    centered: true,
                    okText: "Submit",
                    onOk: () => {
                        // modal.destroy(); // closes the modal
                        // handleCloseModal();

                        onsubmit(activationPayload);
                        submitCarrierStatus(activationPayload,writes_flag);
                    },
                    onCancel: () => {
                        setLoading(false)
                        setShowSelectDevices(false)
                        setIsRedirected(true)
                    },
                });
            }
            else {
                onsubmit(activationPayload);
            }
        }
        else {
            setShowSelectDevices(true);
        }
        }
        
    };

    const handleBack = () => {
        setShowSelectDevices(false);
        setEffectiveDate(effectiveDate);
        if (isSubmitScreen) {
            onBack()
        }
    };

    const handleSelectRatePlan = (selectedOption: any) => {
        if (selectedOption) {
            const value = selectedOption?.value;
            setCustomerRatePlan(value);
            if (isSubmitScreen) {
                fetchActivationFlag(value)
            }
        }
        else {
            setActivationFlag(false)
            setUseCarrierActivation(false)
            setCustomerRatePlan("");

        }
    };

    const handleSelectEffectiveDate = (selectedOption: any) => {
        setIsCusomDateChecked(false)
        setEffectiveDate(null)
        if (selectedOption) {
            const value = selectedOption?.value || "";
            setSelectedDateOption(value)
            const mappedDate = effectiveDateOptionsMap[value] || null
            const normalizedValue = value.toLowerCase()
            if(normalizedValue.includes("bill")){
                setEffectiveDate(mappedDate)
            }
            else if(normalizedValue.includes("current")){
                setEffectiveDate(moment());
            }
            else if(normalizedValue.includes("custom")){
                setIsCusomDateChecked(true)
            }

        }
        else {
            setEffectiveDate(null)
            setSelectedDateOption(null)
        }
    };

    const handleSelectCustomerPool = (selectedOption: any) => {
        if (selectedOption) {
            const value = selectedOption?.value;
            setCustomerRatePool(value);
        }
        else {
            setCustomerRatePool("");

        }
    };

    const handlePreviewOpen = async () => {
        setPreviewModal(true)
    };
    const getSelectStyles = (theme: string) => {
        let bgColor = 'white';
        let optionBg = '#F9FAFB';
        let selectedOptionBg = '#BFDBFE';
        let textColor = 'black';

        if (theme === 'dark') {
            bgColor = '#2d2f52';
            optionBg = '#031731';
            selectedOptionBg = '#5e5bb3';
            textColor = 'white';
        } else if (theme === 'red') {
            selectedOptionBg = '#FCA5A5';
        } else if (theme === 'green') {
            selectedOptionBg = '#6EE7B7';
        } else if (theme === 'blue') {
            selectedOptionBg = '#BFDBFE';
        }

        return {
            menu: (base: any) => ({
                ...base,
                maxHeight: 400,
                zIndex: 9999,
                backgroundColor: optionBg,
            }),
            menuPortal: (base: any) => ({
                ...base,
                zIndex: 9999,
            }),
            container: (base: any) => ({
                ...base,
                zIndex: 1000,
            }),
            control: (base: any) => ({
                ...base,
                height: "40px",
                backgroundColor: bgColor,
                color: textColor,
                border: "1px solid #d1d5db",
                fontSize: "16px",
            }),
            singleValue: (provided: any) => ({
                ...provided,
                color: textColor,
            }),
            option: (base: any, state: any) => ({
                ...base,
                whiteSpace: "nowrap",
                textOverflow: "ellipsis",
                padding: "8px 10px",
                fontSize: "16px",
                color: textColor,
                backgroundColor: state.isSelected ? selectedOptionBg : optionBg,
                ":hover": {
                    backgroundColor: selectedOptionBg,
                },
            }),
            input: (base: any) => ({
                ...base,
                color: textColor,
            }),
        };
    };
    const returnChangedData = () => {
        let lowerCase_customer_name_
        let customerNameParts = []
        let original_customer
        if(isSubmitScreen){
            let selected_customers = revCustomer && revCustomer.length > 0 ? revCustomer.map((opt: any) => (opt?.value || "")) : null
        lowerCase_customer_name_ = selected_customers ? selected_customers[0].toLowerCase() : ""
        original_customer = selected_customers ? selected_customers[0] : ""
        if (lowerCase_customer_name_.endsWith(" -- bp") || lowerCase_customer_name_.endsWith(" -- revio")) {
            original_customer = original_customer.replace(" -- BP", "").replace(" -- RevIO", "");
        }
        if (original_customer) {
            customerNameParts = (original_customer || "").split(" -- ")
        }

        }
        
        const changedData = {
            CustomerRatePlanUpdate: {
                EffectiveDate: effectiveDate,
                CustomerRatePlanId: customerRatePlan === "No Change" ? -1 : (customerRatePlan && customerRatePlan !== 'No options' && customerRatePlan !== 'None' ? customerRatePlan : null),
                CustomerRatePoolId: customerRatePool === "No Change" ? -1 : (customerRatePool === "" || customerRatePool === undefined ) ? -2 : (customerRatePool && customerRatePool !== 'No options' && customerRatePool !== 'None' ? customerRatePool : null),
                ...(isSubmitScreen ? {
                    customerName: customerNameParts && customerNameParts.length > 0 ? customerNameParts[0] : null
                } : {})
            }
        };
        return changedData;
    };

    // const returnUpdatedValue = () =>{
    //     const ratePlan_ = customerRatePlan && customerRatePlan !== 'No options' ? customerRatePlan : ""
    //     return (
    //     <Tooltip title={`${ratePlan_}`}>
    //         <span>
    //             {ratePlan_}
    //         </span>
    //     </Tooltip>)
    // }

    const returnUpdatedValue = () => {
            const ratePlan_ = customerRatePlan && customerRatePlan !== 'No options' ? customerRatePlan : ""
            return (
                <div className="flex flex-col gap-2">
                    <div className="flex grid grid-cols-2 ">
                        <span className="font-semibold">Customer Rate Plan:</span>
                        <span>{ratePlan_}</span>
                    </div>
                </div>
            )
        }

        useImperativeHandle(ref, () => ({
            runValidation: handleContinue,
            runSubmit: () => onsubmit(allChangeTypesDevices),
            returnUpdate: returnUpdatedValue,

        }));

        const isFutureDate = (
            effectiveDate: string | Date | moment.Moment | null
        ): boolean => {
            if (!effectiveDate) return false;

            const date = moment.isMoment(effectiveDate)
                ? effectiveDate.clone()
                : moment.utc(effectiveDate);

            if (!date.isValid()) return false;
            return date.startOf("day").isAfter(moment().startOf("day"));
        };

    if (loading) {
        return (
            <div className="flex justify-center items-center h-[400px]">
                <Spin size="large" />
            </div>
        );
    }
    return (
        <div>
            {(!showSelectDevices) ? (
                <>
                    <div className="flex justify-end space-x-4">
                        {isAllChangeType && (
                            <div className="mt-3">
                                <span className="mr-2 font-semibold">Save Changes</span>
                                <Checkbox
                                    checked={saveChanges}
                                    onChange={(e) => {
                                        if (!e.target.checked) {
                                            setsuccessFullChangeTypes(
                                                successFullChangeTypes.filter((c: any) => c !== activeChange)
                                            );
                                        }
                                        setSaveChanges(e.target.checked)
                                    }}
                                    className="custom-checkbox"
                                >

                                </Checkbox>
                            </div>
                        )}
                        {(!isSubmitScreen && !isAllChangeType) && (
                            switch_user_2_0 === "True" ? (
                                <UploadComponent2
                                    service_provider={service_provider}
                                    change_type={change_type}
                                    changed_data={{
                                        ...returnChangedData(),
                                    }} />
                            ) : (
                                <UploadComponent
                                    service_provider={service_provider}
                                    change_type={change_type}
                                    changed_data={{
                                        ...returnChangedData(),
                                    }} />
                            )
                             
                        )}
                        {(useCarrierActivation && isSubmitScreen) && (
                            <button onClick={handlePreviewOpen} className="save-btn">
                                <EyeIcon className="h-5 w-5 mr-2" />Preview
                            </button>
                        )}
                    </div>

                    <div className={`${!isAllChangeType?"flex flex-col space-y-4 mb-4":"flex grid grid-cols-2 gap-4"}`}>
                        <div className="flex flex-col space-y-2">
                            <label htmlFor="customerRatePlan" className="font-semibold">Customer Rate Plan<span className='text-red-500'>*</span></label>
                            <Select
                                id="customerRatePlan"
                                placeholder="Select Customer Rate Plan"
                                options={[{ label: "None", value: "None" } , ...ratePlanOptions]}
                                value={customerRatePlan === 'No options' ? null : { label: customerRatePlan, value: customerRatePlan }}
                                onChange={handleSelectRatePlan}
                                className="w-full"
                                isClearable
                                styles={getSelectStyles(theme)}
                                menuPortalTarget={document.body}
                                menuPosition="fixed"
                                menuPlacement="auto"
                            />
                            {(errors.customerRatePlan && isAllChangeType) && (
                            <span className="text-red-500">{errors.customerRatePlan}</span>
                        )}
                        </div>
                        {(errors.customerRatePlan && !isAllChangeType) && (
                            <div className="text-red-500">{errors.customerRatePlan}</div>
                        )}

                        {/* <div className="flex flex-col space-y-2"> */}
                            <>
                            {activationFlag && (
                                <div className={`${isAllChangeType?"flex mt-6":""}`}>
                                <Checkbox
                                    checked={useCarrierActivation}
                                    onChange={(e) => setUseCarrierActivation(e.target.checked)}
                                    disabled={effectiveDateChecked}
                                >
                                    <span className={`${isAllChangeType?"relative top-[10px]":""}`}>Use Carrier Activation</span>
                                    
                                </Checkbox>
                                </div>
                            )}

                            <div className={`${isAllChangeType?"flex mt-6":""}`}>
                            <Checkbox
                                checked={effectiveDateChecked}
                                onChange={(e) =>{ 
                                    if(!e.target.checked){
                                        setEffectiveDate(null)
                                        setSelectedDateOption("")
                                    }
                                    setEffectiveDateChecked(e.target.checked)}}
                                disabled={useCarrierActivation}

                            >
                                <span className={`${isAllChangeType?"relative top-[10px]":""}`}>Effective Date</span>
                            </Checkbox>
                            </div>
                            {effectiveDateChecked && (
                                <>
                                    <div className="flex flex-col space-y-2">
                                        <label htmlFor="effectiveDateDrp" className="font-semibold">Effective Date <span className="text-red-500">*</span></label>
                                        <Select
                                            id="effectiveDateDrp"
                                            placeholder="Select..."
                                            options={effectiveDateOptions}
                                            value={{ label: selectedDateOption, value: selectedDateOption }}
                                            onChange={handleSelectEffectiveDate}
                                            className="w-full"
                                            isClearable
                                            styles={getSelectStyles(theme)}
                                            menuPortalTarget={document.body}
                                            menuPosition="fixed"
                                            menuPlacement="auto"
                                            isDisabled={useCarrierActivation}
                                            
                                        />
                                        {errors.effectiveDate && (
                                            <div className="text-red-500">{errors.effectiveDate}</div>
                                        )}
                                    </div>
                                    {isCustomDateChecked && (
                                        <div className="flex flex-col space-y-2">
                                            <label htmlFor="effectiveDate" className="font-semibold">Effective Date <span className="text-red-500">*</span></label>
                                            <DatePicker
                                                id="effectiveDate"
                                                value={effectiveDate}
                                                onChange={(date) => {
                                                    if (date) {
                                                        const safeDate = date.hour(12).minute(0).second(0).millisecond(0);
                                                        console.log(safeDate)
                                                        setEffectiveDate(safeDate);
                                                    } else {
                                                        setEffectiveDate(null);
                                                    }
                                                }}
                                                className={`${useCarrierActivation ? "non-editable-input" : "input"}`}
                                                disabled={useCarrierActivation}

                                            />
                                            {/* {errors.effectiveDate && (
                                        <div className="text-red-500">{errors.effectiveDate}</div>
                                    )} */}
                                        </div>
                                    )}
                                </>
                            )}
                            </>
                        {/* </div> */}

                        <div className="flex flex-col space-y-2">
                            <label htmlFor="customerRatePool" className="font-semibold">Customer Rate Pool</label>
                            <Select
                                id="customerRatePool"
                                placeholder="Select Customer Rate Pool"
                                options={[
                                    { label: "None", value: "None" }, // Add "None" as the first option
                                    ...customerPoolOptions // Spread the existing options
                                ]}
                                value={(customerRatePool === 'No options') ? null : { label: customerRatePool, value: customerRatePool }}
                                onChange={handleSelectCustomerPool}
                                className="w-full"
                                isClearable
                                styles={getSelectStyles(theme)}
                                menuPortalTarget={document.body}
                                menuPosition="fixed"
                                menuPlacement="auto"
                            />
                        </div>
                        {isSubmitScreen && (
                            <>
                                <div className="flex flex-col space-y-2">
                                    <label className="font-semibold">
                                        Billing Customer
                                    </label>
                                    <Select
                                        options={getAvailableOptions(revCustomersOptions, revCustomer)}
                                        value={revCustomer}
                                        onChange={(selectedOptions: any) =>
                                            handleRevCustomer(selectedOptions)
                                        }
                                        className=""
                                        styles={DropdownStyles}
                                        // placeholder="Select Service Provider"
                                        isMulti
                                        menuPortalTarget={document.body}
                                        menuPosition="fixed"
                                        menuPlacement="auto"
                                    />
                                    {/* <VirtualizedSelect
                                        styles={getSelectStyles(theme)}
                                        menuPortalTarget={document.body}
                                        menuPosition="fixed"
                                        menuPlacement="auto"
                                        options={getAvailableOptions(revCustomersOptions, revCustomer)}
                                        value={revCustomer}
                                        onChange={(selectedOptions: any) =>
                                            handleRevCustomer(selectedOptions)
                                        }
                                        className="w-full"
                                        isMulti={true}
                                        placeholder="Please Select Customer"
                                        maxHeight={400} // Define the max height for the dropdown
                                    /> */}

                                {errors.revCustomer && (
                                    <div className="text-red-500 text-sm">{errors.revCustomer}</div>
                                )}
                                </div>
                            </>
                        )}

                        {!isAllChangeType && (
                            <div className="flex justify-center space-x-4 mt-4">
                            <button onClick={onBack} className="cancel-btn">
                                Back
                            </button>
                            <button onClick={handleContinue} className="save-btn">
                                {isSubmitScreen ? "Submit" : "Continue"}
                            </button>
                        </div>
                        )}
                        
                    </div>
                </>
            ) : (
                <SelectDevices
                    onContinue={onContinue}
                    onBack={handleBack}
                    service_provider={service_provider}
                    change_type={change_type}
                    changed_data={returnChangedData()}
                    onClose={() => {
                        setShowSelectDevices(false)
                        setIsRedirected(true)
                    }}
                    isNextScreen={isSubmitScreen}
                    setSelectedCustomers={setRevCustomer} 
                    onCancel={onClose}/>
            )}

            <PreviewModal
                service_provider={service_provider}
                change_type={change_type}
                iccids={activationPayload?.iccids}
                openPreviewModal={openPreviewModal}
                setPreviewModal={setPreviewModal}
            />
        </div>
    );
}
)

export default ChangeCustomerRatePlan;