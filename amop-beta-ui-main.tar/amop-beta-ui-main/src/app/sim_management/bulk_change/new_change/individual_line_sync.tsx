"use client";

import { FC, forwardRef, useEffect, useImperativeHandle, useState } from "react";
import { Checkbox, Input, Modal, Spin, Tooltip } from "antd";
import Select from "react-select";
import SelectDevices from "./select_devices";
import React from "react";
import { DropdownStyles } from "@/app/components/css/dropdown";
import { useAuth } from "@/app/components/auth_context";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import axios from "axios";
import { useFeatureStore } from "../../inventory/featureStore";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { useRouter } from "next/navigation";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { useAllChangeTypesStore } from "@/app/stores/allChangeTypesStore";
import { PerformanceLogStore } from "@/app/stores/performance_matrix_store";

interface IndividualLineSyncProps {
    onContinue: () => void;
    onBack: () => void;
    dropdown: any;
    service_provider: any;
    change_type: any;
    onClose: () => void;
}

export interface IndividualLineSyncContentRef {
  runValidation: () => Promise<void> | void;
  runSubmit: () => Promise<void> | void;
  returnUpdate: () => React.ReactNode | Promise<React.ReactNode>;
}

const IndividualLineSync = forwardRef<IndividualLineSyncContentRef, IndividualLineSyncProps>(
    ({ onContinue, onBack, dropdown, service_provider, change_type, onClose }, ref) => {
    const [errors, setErrors] = useState<string[]>([]);
    const [loading, setLoading] = useState(false);
    const { username, role, partner, token, selectedDb, firstLastName, sessionId, modulesVersionMap , metaData} = useAuth();
    const [BANError, setBANError] = useState<string>("");
    const [subscriberNumber, setSubscriberNumber] = useState<string>("");
    const [iccids, setIccids] = useState<string>("");
    const [errorMessage, setErrorMessage] = useState("");
    const { setRowId, setBulkRow, bulkChangeLimit, simIdentifierMap } = useFeatureStore();
    const router = useRouter();
    const initial_version_flag = modulesVersionMap?.["Sim Management-Bulk Change"] || false
    const isVersionEnabled = localStorage.getItem("switch_user_2_0_bulk_change") === "True";
    const switch_user_2_0 = isVersionEnabled && initial_version_flag ? "True" : "False"
    const { addExport, removeExport, exports } = exportLoadingStore();
    const { isAllChangeType,setIsValidated,setValidationTrigger,allChangeTypesDevices, setsuccessFullChangeTypes, activeChange, successFullChangeTypes,all_2_0_payloads, set_all_2_0_payloads   } = useAllChangeTypesStore();
    const [saveChanges, setSaveChanges] = useState<boolean>(true);
    const { getTargetTenantProvider, IsTargetTenantProvider } = PerformanceLogStore();
    const is_parent_provider_exists = IsTargetTenantProvider(service_provider)
    const providerName = getTargetTenantProvider(service_provider).toLowerCase() || service_provider;
    const isTeal = providerName.toLowerCase().includes("teal");
    const isKore = providerName.toLowerCase().includes("kore");


    useEffect(() => {
        if (isAllChangeType) {
            const devices = allChangeTypesDevices?.iccids || []
            const devicesString = devices.join('\n')
            if (allChangeTypesDevices?.isIccid) {
                setSubscriberNumber("")
                setIccids(devicesString);
            }
            else {
                setIccids("")
                setSubscriberNumber(devicesString);
            }
        }
    }, [isAllChangeType, allChangeTypesDevices]);
   
const handleContinue = async () => {

    if (!subscriberNumber && !iccids) {
        setErrorMessage("Please fill ICCID field or MSISDN field.")
    }
    else {
        setErrorMessage("")
        const isTMobile = providerName.toLowerCase().includes("t-mobile")
        const selected_devices = subscriberNumber ? subscriberNumber : iccids
        const iccidList = selected_devices
            .split(/\s*[\n,]\s*/)
            .map((line) => line.trim())
            .filter((line) => line.length > 0);

            const isTelegence = providerName.toLowerCase().includes("telegence");

        const newErrors: string[] = [];
        console.log("iccid list", iccidList)

        if (isTeal) {
            // For Teal: validate pairs of ICCID and EID
            if (iccidList.length % 2 !== 0) {
                newErrors.push(subscriberNumber ? "For Teal provider, please provide Subscriber Numbers , EIDs": iccids ? "For Teal provider, please provide ICCIDs , EIDs":"");
            } else {
                for (let i = 0; i < iccidList.length; i += 2) {
                    const iccid = iccidList[i];
                    const eid = iccidList[i + 1];
                    const label = subscriberNumber ? "Subscriber Number" : "ICCID";
                    // Validate ICCID (first in pair)
                    if (!/^\d+$/.test(iccid)) {
                        newErrors[i] = `${label} Number must contain numbers only`;
                    } else if ((iccid.length < 14 || iccid.length > 22 )&& !subscriberNumber) {
                        newErrors[i] = `${label} must be between 14 and 22 digits`;
                    }
                    else if((iccid.length < 10 || iccid.length > 18) && subscriberNumber){
                        newErrors[i] = `${label} must be between 10 and 18 digits`;
                    }

                    // Validate EID (second in pair)
                    if (eid) {
                        if (!/^\d+$/.test(eid)) {
                            newErrors[i + 1] = `EID must contain numbers only`;
                        } else if (eid.length !== 32) {
                            newErrors[i + 1] = `EID must be exactly 32 digits`;
                        }
                    }
                }
            }
        }
        else if (isKore) {
            // For Kore: validate pairs of ICCID and Subscription ID
            if (iccidList.length % 2 !== 0) {
                newErrors.push(subscriberNumber ? "For Kore provider, please provide Subsciber Number and Subscription ID in pairs (even number of entries required)" : "For Kore provider, please provide ICCID and Subscription ID in pairs (even number of entries required)");
            } else {
                for (let i = 0; i < iccidList.length; i += 2) {
                    const iccid = iccidList[i];
                    const subscriptionId = iccidList[i + 1];
                    const label = subscriberNumber ? "Subscriber Number" : "ICCID";

                    // Validate ICCID (first in pair)
                    if (!/^\d+$/.test(iccid)) {
                        newErrors[i] = `Line ${i + 1}: ${label} must contain numbers only`;
                    } else if ((iccid.length < 14 || iccid.length > 22) && !subscriberNumber) {
                        newErrors[i] = `Line ${i + 1}: ${label} must be between 14 and 22 digits`;
                    }
                     else if ((iccid.length < 10 || iccid.length > 18) && subscriberNumber) {
                        newErrors[i] = `Line ${i + 1}: ${label} must be between 10 and 18 digits`;
                    }

                    // Validate Subscription ID (second in pair)
                    if (subscriptionId) {
                        const korePattern = /^cmp-k1-subscription-\d{8}$/;
                        if (!korePattern.test(subscriptionId)) {
                            newErrors[i + 1] = `Line ${i + 2}: Subscription ID must be in format cmp-k1-subscription-XXXXXXXX (8 digits)`;
                        }
                    }
                }
            }
        }  
        else {
            // Existing validation for non-Teal providers
            iccidList.forEach((line, index) => {
                const label = subscriberNumber ? "Subscriber Number" : "ICCID";
                const minLength = subscriberNumber ? 10 : 14;
                const maxLength = subscriberNumber ? 18 : 22;

                if (line.length === 0) {
                    newErrors[index] = `${label} must not be empty`;
                } else if (!/^\d+$/.test(line) && !isTMobile) {
                    newErrors[index] = `Please enter numbers only for ${label}. Letters or special characters are not allowed`;
                }
                else if (!/^[a-zA-Z0-9]+$/.test(line) && isTMobile) {
                    newErrors[index] = `Please enter letters and numbers only for ${label}. Special characters are not allowed`;
                }
                else if (line.length < minLength || line.length > maxLength) {
                    newErrors[index] = `${label} must be between ${minLength} and ${maxLength} digits long`;
                }
            });
        }

        if (iccidList.length > bulkChangeLimit) {
            newErrors.push(`This request exceeds the allowed record limit of ${bulkChangeLimit} and cannot be processed`);
            console.log("Limit Exceeded");
        }
        
        setErrors(newErrors);
        console.log("new errors", newErrors)

        if (newErrors.length === 0 && !errorMessage && !BANError) {
            if (!isAllChangeType) {
                const writes_flag = await fetchCarrierWritesFlag()
                if (writes_flag) {
                    const modal = Modal.confirm({
                        title: "Carrier API Enabled",
                        content: "Carrier API settings are enabled. Submitting now will trigger the Carrier API directly. Do you want to proceed?",
                        centered: true,
                        okText: "Submit",
                        onOk: () => {
                            // modal.destroy(); // closes the modal
                            // handleCloseModal();

                            onsubmit();
                            submitCarrierStatus(writes_flag);
                        },
                        onCancel: onBack
                    });
                }
                else {
                    onsubmit();
                }
            }
            else {
                if (saveChanges) {
                    setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
                }
                setIsValidated(true)
                setValidationTrigger();
                return
            }
        }
        if (newErrors.length > 0) {
            if (saveChanges) {
                setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
            }
            setIsValidated(true)
            setValidationTrigger();
            setErrors(newErrors);
            return;
        }
    }

    setErrors([]);
};

    const fetchCarrierWritesFlag = async () => {
        let parsedData: any
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
            tenant_name: partner || "default_value",
            username,
            path: "/get_writes_enable_for_service_provider",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "Inventory",
            service_provider: service_provider || "",
            ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            environment: "BETA",
            change_type: change_type,
        };

        try {
            setLoading(true);
            const response = await axios.post(url, { data });
            parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === true) {
                const write_is_enabled = parsedData?.write_is_enabled || false;
                // setWritesFlag(write_is_enabled);
                return write_is_enabled;
            }
        } catch (error) {
            console.error("Error fetching data:", error);
            return false; // fallback in case of error
        } finally {
            // setLoading(false);
        }
    };
    const submitCarrierStatus = async ( write_is_enabled:boolean) => {
        let parsedData: any
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const iccidList = await getIccidList()
        const data = {
            tenant_name: partner || "default_value",
            username,
            path: "/insert_carrier_status_validation_audit",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "Inventory",
            service_provider: service_provider || "",
            ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            environment: "BETA",
            msisdn: [],
            iccid: iccidList,
            change_type: change_type,
            write_is_enabled:write_is_enabled,
        };

        try {
            // setLoading(true);
            const response = await axios.post(url, { data });
            parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === true) {

            }
        } catch (error) {
            console.error("Error fetching data:", error);
        } finally {
            // setLoading(false);
        }
    };
    const fetchDevices = async (devices_list: any[], deviceKey: string) => {
        try {
            setLoading(true);
            const url =
                ENV_ROUTES.BULKCHANGE_PROCESSOR;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_standard_iccid_msisdn_data",
                role_name: role,
                Partner: partner,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: service_provider,
                ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type,
                [deviceKey]: devices_list || []
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                // setLoading(false);
                Modal.error({
                    title: 'Submit Error',
                    content: parsedData.message || 'An error occurred while submitting data. Please try again.',
                    centered: true,
                });
                return []
            } else {
                const responseKey = deviceKey === "iccids" ? "msisdns" : "iccids"
                const devices = parsedData?.[responseKey] || []
                console.log("devices", devices)
                return devices
                // setLoading(false);
            }
        } catch (error) {
            Modal.error({
                title: 'Submit Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting data. Please try again.',
                centered: true,
            });
            return []
            // setLoading(false);
        }
        finally {
            // setLoading(false)
        }
    };
        type DeviceLists = {
            iccids: string[];
            eids?: string[];   
            subscriptionIds?: string[];
        };

 const getIccidList = async (): Promise<DeviceLists> => {
        // Pick devices based on subscriberNumber or iccids
        const devices_ = subscriberNumber ? subscriberNumber : iccids;

        // Find matching device type from the map
        const matchedDeviceTypeItem = simIdentifierMap.find((item: any) => {
            return (
                item.service_provider === service_provider &&
                item.change_type === change_type
            );
        });
        const matchedDeviceType = matchedDeviceTypeItem?.sim_identifier || ""
        // Decide expected type
        const selectDeviceType = subscriberNumber ? "msisdns" : "iccids";
        // Split devices into a list
        let deviceList = devices_
            .split(/\s*[\n,]\s*/)
            .map((line) => line.trim())
            .filter((line) => line.length > 0);
        let iccidList: string[] = [];
        let eidList: string[] = [];
        let subscriptionIdList: string[] = [];

        if (isTeal) {
            deviceList.forEach((value) => {
                if (/^\d{32}$/.test(value)) {
                    eidList.push(value);
                } else if (/^\d{10,22}$/.test(value)) {
                    iccidList.push(value);
                }
            });
        } else if (isKore) {
        // For Kore: separate ICCIDs and Subscription IDs based on pattern
        deviceList.forEach((value) => {
            if (/^cmp-k1-subscription-\d{8}$/.test(value)) {
                subscriptionIdList.push(value);
            } else if (/^\d{10,22}$/.test(value)) {
                iccidList.push(value);
            }
        });
        } else {
            iccidList = deviceList;
        }

        // Fetch devices only if types mismatch
        // if (matchedDeviceType !== selectDeviceType) {
        //     iccidList = await fetchDevices(iccidList, selectDeviceType);
        // }

        return { 
                iccids: iccidList, 
                eids: eidList.length > 0 ? eidList : undefined,
                subscriptionIds: subscriptionIdList.length > 0 ? subscriptionIdList : undefined
            };    
        };
    const call_2_0_submit = async (parsedData: any, payload: any,isRouteCall:boolean) => {
        try {
            const payload_data = { ...payload }
            const url = ENV_ROUTES.BULKCHANGE_PROCESSOR;
            const deviceKey = subscriberNumber ? "msisdns" : "iccids"
            const deleteKey = subscriberNumber ? "iccids" : "msisdns"
            delete payload_data[deleteKey]

            const payloadData = {
                ...payload_data,
                path: "/bulk_change_processor",
                request_received_at: getCurrentDateTime(),
                bulk_change_id: parsedData?.bulk_chnage_id_20,
                [deviceKey] : payload?.iccids,
            }
            const data = { ...payloadData };
            if(!isRouteCall){
                return data
            }
            const response = await axios.post(url, { data });
            const responseData = JSON.parse(response.data.body);
            if (responseData.flag === false) {
                console.log("Failure: 2.0 Bulk change update failed.");
            } else {
                console.log("Success: 2.0 Bulk change update successful.");
            }
        }
        catch (error) {
            console.error("Error running DB script:", error);
        } finally {
            setLoading(false);
        }
    }

    const call_2_0_sync = async (parsedData: any) => {
        try {
            const runDbScriptUrl = ENV_ROUTES.SIM_MANAGEMENT;
            const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
            const runDbScriptData = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/update_bulk_change_tables_10",
                role_name: role,
                module_name: "Bulk Change",
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                // service_provider_id: service_provider_id_,
                // bulkchange_id: parsedData?.bulkchange_id?.id,
                // data: parsedData?.data,
                data: {
                    bulk_change_id: parsedData?.bulk_chnage_id_20,
                },
                is_update: false,
                // bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
            };

            const runDbScriptResponse = await axios.post(runDbScriptUrl, { data: runDbScriptData });
            const runDbScriptResponseData = JSON.parse(runDbScriptResponse.data.body);

            if (runDbScriptResponseData.flag === false) {
                console.error("Data Fetch Error: " + runDbScriptResponseData.message);
            } else {
                console.log("Success: Bulk update successful.");
            }
        }
        catch (error) {
            console.error("Error running DB script:", error);
        } finally {
            setLoading(false);
        }
    }
    const bulkChangeInsert = async (payload: any) => {
        let partner_name = partner
        let db_name_ = selectedDb
        try {
            const url = ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner_name || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_bulk_change_insertion",
                role_name: role,
                module_name: "Bulk Change History",
                service_provider_name: service_provider,
                ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                request_received_at: getCurrentDateTime(),
                Partner: partner_name,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === false) {
                console.error("Error fetching bulk change data:", parsedData.message ||
                    "An error occurred while fetching bulk change data. Please try again.");
                return false
            } else {
                const statusFlag = parsedData?.bulk_change_data?.status || "";
                const response_data = parsedData?.bulk_change_data?.bulk_change_data || "{}";
                const parsedResp = JSON.parse(response_data)
                console.log("status_flag", statusFlag)
                const status_flag = statusFlag ? (statusFlag).toLowerCase() : ""

                if (status_flag && status_flag === "pending") {
                    return false
                }
                else if (status_flag && status_flag === "success") {
                    call_2_0_submit(parsedResp, payload,true)
                    call_2_0_sync(parsedResp)
                    return true
                }
                else if (status_flag && status_flag === "error") {
                    Modal.error({
                        title: 'Submit Error',
                        content: parsedData.message || 'An error occurred while submitting. Please try again.',
                        centered: true,
                    });
                    return true
                }
                else {
                    return false
                }
            }
        } catch (error) {
            console.error("Error fetching auto refresh data:", error);
            return false
        } finally {
        }
    };
    const bulkChangePolling = async (data: any) => {
        const result = await bulkChangeInsert(data);
        if (!result) {
            setTimeout(() => bulkChangePolling(data), 5000); // Try again after 5 seconds
        } else {
            removeExport("bulkChangeInsert");
            console.log("Auto-refresh complete.");
        }
        // if (window.location.pathname.includes("/sim_management/bulk_change")) {
        //     window.location.reload();
        // }
    };
    const onsubmit = async () => {
        let data: any
        const { iccids, eids ,subscriptionIds } = await getIccidList()

        try {
            
            setLoading(true);

            // Prepare payload for the first API
            const url = ENV_ROUTES.SIM_MANAGEMENT;
            data = {
                tenant_name: partner || "default_value",
                path: "/update_bulk_change_data",
                role_name: role,
                username: username,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: service_provider,
                ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type,
                created_by: firstLastName,
                iccids: iccids,
                ...(eids && { eids }),
                ...(subscriptionIds && { subscriptionIds }),

            };

            // Send request to the first API
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === false) {
                setLoading(false);
                Modal.error({
                    title: 'Submit Error',
                    content: parsedData.message || 'An error occurred while submitting. Please try again.',
                    centered: true,
                });
                return;
            }

            const bulkrow_ = parsedData?.bulkchange_id || {};
            const bulkRow: any = { row: bulkrow_ };
            setBulkRow(bulkRow);
            localStorage.setItem('bulk_row', JSON.stringify(bulkRow || "{}"));
            if (bulkRow) {
                if(!isAllChangeType){
                    router.push(`/sim_management/bulk_history`);
                }
            }

            if (!isAllChangeType) {
                call_2_0_submit(parsedData, data, true);
                call_2_0_sync(parsedData);
            }
            else {
                const payload_2_0_: any = await call_2_0_submit(parsedData, data, false)
                set_all_2_0_payloads((prev: any) => ({
                    ...prev,
                    [change_type]: { ...payload_2_0_ }
                }));
            }
        } catch (error) {
            const isTelegence = providerName.toLowerCase().includes("telegence");
            const isWebbing = providerName.toLowerCase().includes("webbing") || providerName.toLowerCase().includes("multi-carrier sim");
            const isVerizon = (providerName.toLowerCase().includes("verizon") || providerName.toLowerCase().includes("vzn") || providerName.toLowerCase().includes("vzwcr") || providerName.toLowerCase().includes("2215-so01"));
            const isPod19 = providerName.toLowerCase().includes("pod19");
            const isPondIOT = providerName.toLowerCase().includes("pond");
            if (switch_user_2_0 === "True" && (isTelegence || isWebbing || isVerizon || isPod19 || isPondIOT)) {
                onClose()
                setLoading(false)
                addExport("bulkChangeInsert", "Bulk Change Submission");
                bulkChangePolling(data)
            }
            else {
                Modal.error({
                    title: 'Submit Error',
                    content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting. Please try again.',
                    centered: true,
                });
            }
        } finally {
            setLoading(false);
        }
    };
    // const returnUpdatedValue = () =>{
    //     const devices = allChangeTypesDevices?.iccids
    //     return (
    //     <Tooltip title={`${devices.join(",")}`}>
    //         <span>
    //             {allChangeTypesDevices?.isIccid?`ICCIDs: ${devices}`:`MSISDNs: ${devices}`}
    //             {devices.join(",")}
    //             </span>
    //     </Tooltip>)
    // }

    const returnUpdatedValue = () => {
      const devices = allChangeTypesDevices?.iccids

      return (
        <div className="flex flex-col gap-2">
          <div className="flex grid grid-cols-2 ">
            <span className="font-semibold">{allChangeTypesDevices?.isIccid?"ICCIDs:":"MSISDNs:"}</span>
            <span>{devices.join(",")}</span>
          </div>
        </div>
      )
    }

    useImperativeHandle(ref, () => ({
        runValidation: handleContinue,
        runSubmit: onsubmit,
        returnUpdate: returnUpdatedValue,
    }));
   
    if (loading) {
        return (
            <>
                <div className="flex justify-center items-center h-[400px]">
                    <Spin size="large" />
                </div>
            </>
        );
    }

    return (
        <div>
            <>
                {isAllChangeType && (
                    <div className="flex justify-end px-4">
                        <span className="mr-2 font-semibold">Save Changes</span>
                        <Checkbox
                            checked={saveChanges}
                            onChange={(e) => {
                                if (!e.target.checked) {
                                    setsuccessFullChangeTypes(
                                        successFullChangeTypes.filter((c: any) => c !== activeChange)
                                    );
                                }
                                setSaveChanges(e.target.checked)
                            }}
                            className="custom-checkbox"
                        >

                        </Checkbox>
                    </div>
                )}
                <div className={`${!isAllChangeType?"flex flex-col space-y-4 my-4":"flex grid grid-cols-2 gap-4"}`}>
                    {/* Billing Account Number */}
                    <div className="flex flex-col space-y-2">
                        <label htmlFor="iccids" className="font-semibold">{isTeal ? "Devices (Start typing ICCID , EID)" : isKore ? "Devices (Start typing ICCID , Subscription ID)" :"Devices (Start typing ICCID)"}<span className='text-red-500'>*</span></label>
                        <Input.TextArea
                            id="iccids"
                            rows={!isAllChangeType?4:8}
                            placeholder={isTeal ? "Enter ICCIDs , EIDs here" : isKore ? "Enter ICCIDs , Subscription IDs here (Format: cmp-k1-subscription-XXXXXXXX)" : "Enter ICCIDs here"}
                            value={iccids}
                            onChange={(e) => {
                                setIccids(e.target.value);
                                if (e.target.value) setSubscriberNumber("");
                            }}
                            disabled={!!subscriberNumber || isAllChangeType}
                        />
                    </div>
                    <div className="flex flex-col space-y-2">
                        <label htmlFor="msisdns" className="font-semibold">{isTeal ? `Devices (Start typing Subscriber Number , EID)` : isKore ? "Devices (Start typing Subscriber Number , Subscription ID)" : "Devices (Start typing Subscriber Number)"}<span className='text-red-500'>*</span></label>
                        <Input.TextArea
                            id="msisdns"
                            rows={!isAllChangeType?4:8}
                            placeholder={isTeal ? "Enter Subscriber Numbers , EIDs here" : isKore ? "Enter Subscriber Numbers , Subscription ID  here" : "Enter Subscriber Numbers here"}
                            value={subscriberNumber}
                            onChange={(e) => {
                                setSubscriberNumber(e.target.value);
                                if (e.target.value) setIccids("");
                            }}
                            disabled={!!iccids || isAllChangeType}
                        />
                        {errors.some((err) => err) && (
                            <div className="mt-2 space-y-1">
                                {errors.map((err, idx) =>
                                    err ? (
                                        <div key={idx} className="text-red-500 text-sm">
                                            Line {idx + 1}: {err}
                                        </div>
                                    ) : null
                                )}
                            </div>
                        )}
                    </div>
                    {errorMessage && <div className="text-red-500 text-sm">{errorMessage}</div>}
                    {!isAllChangeType && (
                        <div className="flex justify-center space-x-4 mt-4">
                        <button onClick={onBack} className="cancel-btn">
                            Back
                        </button>
                        <button onClick={handleContinue} className="save-btn">
                            Submit
                        </button>
                    </div>
                    )}
                    
                </div>
            </>
        </div>
    );
}
)

export default IndividualLineSync;