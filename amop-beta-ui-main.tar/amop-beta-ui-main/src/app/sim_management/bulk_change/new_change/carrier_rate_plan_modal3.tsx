"use client";

import { FC, forwardRef, useEffect, useImperativeHandle, useState } from "react";
import { Input, Button, DatePicker, Checkbox, Modal, Spin, Tooltip } from "antd";
import { ArrowLeftIcon, ArrowRightIcon } from "@heroicons/react/24/outline";
import SelectDevices from "./select_devices";
import moment, { Moment } from "moment";
import Select from "react-select";
import { useFeatureStore } from "../../inventory/featureStore";
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { useRouter } from 'next/navigation';
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { DropdownStyles } from "@/app/components/css/dropdown";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { useAllChangeTypesStore } from "@/app/stores/allChangeTypesStore";
import { PerformanceLogStore } from "@/app/stores/performance_matrix_store";

interface CarrierRatePlanProps3 {
    onContinue: () => void;
    onBack: () => void;
    dropdown: any;
    service_provider: any;
    change_type: any
    onClose: () => void;
}

export interface CarrierRatePlan3ContentRef {
  runValidation: () => Promise<void> | void;
  runSubmit: () => Promise<void> | void;
  returnUpdate: () => React.ReactNode | Promise<React.ReactNode>;

}

const ChangeCarrierRatePlan3 = forwardRef<CarrierRatePlan3ContentRef, CarrierRatePlanProps3>(
    ({ onContinue, onBack, dropdown, service_provider, change_type, onClose }, ref) => {
    const [carrierRatePlan, setCarrierRatePlan] = useState<string | null>(null);
    const [optimizationGroup, setOptimizationGroup] = useState<string | null>(null);
    const [effectiveDateCheckbox, setEffectiveDateCheckbox] = useState<boolean>(false);
    // const [effectiveDate, setEffectiveDate] = useState<Date | null>(null);
    const [effectiveDate, setEffectiveDate] = useState<Moment | null>(null);
    const [subscriberNumber, setSubscriberNumber] = useState<string>("");
    const [iccids, setIccids] = useState<string>("");
    const [showSelectDevices, setShowSelectDevices] = useState(false);

    // Error state for individual fields
    const [carrierRatePlanError, setCarrierRatePlanError] = useState<string | null>(null);
    const [effectiveDateError, setEffectiveDateError] = useState<string | null>(null);
    const [subscriberNumberError, setSubscriberNumberError] = useState<string | null>(null);
    const [ratePlanOptions, setRatePlanOptions] = useState<any>([])
    const [optimizationOptions, setOptimizationOptions] = useState<any>([])
    const { setRowId, setBulkRow, bulkChangeLimit, simIdentifierMap } = useFeatureStore();
    const { username, role, partner, token, selectedDb,metaData, firstLastName, sessionId, modulesVersionMap } = useAuth();
    const [loading, setLoading] = useState(false);
    const router = useRouter();
    const initial_version_flag = modulesVersionMap?.["Sim Management-Bulk Change"] || false
    const isVersionEnabled = localStorage.getItem("switch_user_2_0_bulk_change") === "True";
    const switch_user_2_0 = isVersionEnabled && initial_version_flag ? "True" : "False"
    const { addExport, removeExport, exports } = exportLoadingStore();
    const { isAllChangeType,setIsValidated,setValidationTrigger,allChangeTypesDevices, setsuccessFullChangeTypes, activeChange, successFullChangeTypes,all_2_0_payloads, set_all_2_0_payloads  } = useAllChangeTypesStore();
    const [saveChanges, setSaveChanges] = useState<boolean>(true);
    const { getTargetTenantProvider, IsTargetTenantProvider } = PerformanceLogStore();
    const is_parent_provider_exists = IsTargetTenantProvider(service_provider)
    const providerName = getTargetTenantProvider(service_provider).toLowerCase() || service_provider;
    
        useEffect(() => {
            if (isAllChangeType) {
                const devices = allChangeTypesDevices?.iccids || []
                const devicesString = devices.join('\n')
                if (allChangeTypesDevices?.isIccid) {
                    setSubscriberNumber("")
                    setIccids(devicesString);
                }
                else {
                    setIccids("")
                    setSubscriberNumber(devicesString);
                }
            }
        }, [isAllChangeType, allChangeTypesDevices]);

    useEffect(() => {
        // console.log("dropdown", dropdown)
        const carrier_rate_plan_dropdown = dropdown?.carrier_rate_plan_dropdown || []
        setRatePlanOptions(carrier_rate_plan_dropdown)
        const optimization_group_dropdown = dropdown?.optimization_group_dropdown || []
        setOptimizationOptions(optimization_group_dropdown)
    }, [dropdown]);

    const disablePastDates = (current: any) => {
        // Disable all dates before today
        return current && current < new Date().setHours(0, 0, 0, 0);
    };

    const handleSubmit = async () => {
        let valid = true;
        const selected_devices = subscriberNumber ? subscriberNumber : iccids
        const lines = selected_devices.split(/\s*[\n,]\s*/).map(line => line.trim()).filter(line => line.length > 0);
        const validLines = iccids ? lines.every(line => /^[0-9]{14,22}$/.test(line)) : lines.every(line => /^[0-9]{10,18}$/.test(line));
        // Reset errors
        setCarrierRatePlanError(null);
        setEffectiveDateError(null);
        setSubscriberNumberError(null);

        // Validation
        if (!carrierRatePlan) {
            setCarrierRatePlanError("Carrier rate plan is required.");
            valid = false;
        }
        if (effectiveDateCheckbox && !effectiveDate) {
            setEffectiveDateError("Effective date is required when 'Effective date' is checked.");
            valid = false;
        }
        if (!subscriberNumber && !iccids) {
            setSubscriberNumberError("Please fill ICCID field or MSISDN field.")
            valid = false;
        }
        if (!validLines) {
            const error_msg = iccids ? "Each ICCID must be between 14 to 22 characters long and allow numbers only" : "Each Subscriber Number must be between 10 to 18 characters long and allow numbers only"
            setSubscriberNumberError(error_msg);
            valid = false;
        }
        if (lines.length > bulkChangeLimit) {
            setSubscriberNumberError(`This request exceeds the allowed record limit  of ${bulkChangeLimit} and cannot be processed`);
            console.log("Limit Exceeded");
            valid = false
        }

        if (!valid) {
            if (isAllChangeType) {
                setsuccessFullChangeTypes(
                    successFullChangeTypes.filter((c: any) => c !== activeChange)
                );
                if ((!carrierRatePlan && !optimizationGroup && !effectiveDate) || !saveChanges) {
                    setEffectiveDateError("");
                    setCarrierRatePlanError("");
                    setIsValidated(true)
                    setValidationTrigger();
                }
                else {
                    setIsValidated(false)
                    setValidationTrigger();
                }
            }
            return
        }
        if (isAllChangeType) {
            setEffectiveDateError("");
            setCarrierRatePlanError("");
            setIsValidated(true)
            setValidationTrigger();
            if(saveChanges){
                setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
            }
        }
        if (valid && !isAllChangeType) {
            const writes_flag = await fetchCarrierWritesFlag()
            if (writes_flag) {
                const modal = Modal.confirm({
                    title: "Carrier API Enabled",
                    content: "Carrier API settings are enabled. Submitting now will trigger the Carrier API directly.",
                    centered: true,
                    okText: "OK",
                    onOk: () => {
                        // Show second confirmation
                        Modal.confirm({
                            title: "Proceed Confirmation",
                            content: "Are you sure you want to proceed?",
                            centered: true,
                            okText: "Submit",
                            cancelText: "Cancel",
                            onOk: () => {
                                onsubmit();
                                submitCarrierStatus(writes_flag);
                            },
                        });
                    },
                    onCancel: onBack
                });
            }
            else {
                onsubmit();
            }
        }

    };

    const callMismatchICCID = async (parsedData: any) => {
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/bulk_change_validation_update",
            role_name: role,
            module_name: "Bulk Change",
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            bulkchange_id: parsedData?.bulkchange_id?.id,
            bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
        };

        const response = await axios.post(url, { data });
        const parsedResponse = JSON.parse(response.data.body);

        if (parsedResponse.flag === false) {
            console.error("Data Fetch Error mismatch ICCID: " + parsedResponse.message);
        } else {
            console.log("Success: Bulk update successful.");
        }
    }

    const callWebbingSync = async (data: any) => {
        const koreUrl = ENV_ROUTES.SM_BULK_CHANGE;
        let koreData = { ...data }
        koreData["path"] = "/start_sync"

        try {
            const koreResponse = await axios.post(koreUrl, { data: koreData });
            const koreResponseData = JSON.parse(koreResponse.data.body);

            if (koreResponseData.flag === false) {
                console.log("Data Fetch Error: " + koreResponseData.message);
            } else {
                console.log("Success: Bulk update successful.");
            }

        }
        catch {
            console.log("error in Start Sync");
        }
    }
    const call_2_0_sync = async (parsedData: any) => {
        try {
            const runDbScriptUrl = ENV_ROUTES.SIM_MANAGEMENT;
            const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
            const runDbScriptData = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/update_bulk_change_tables_10",
                role_name: role,
                module_name: "Bulk Change",
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                // service_provider_id: service_provider_id_,
                // bulkchange_id: parsedData?.bulkchange_id?.id,
                // data: parsedData?.data,
                data: {
                    bulk_change_id: parsedData?.bulk_chnage_id_20,
                },
                is_update: false,
                // bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
            };

            const runDbScriptResponse = await axios.post(runDbScriptUrl, { data: runDbScriptData });
            const runDbScriptResponseData = JSON.parse(runDbScriptResponse.data.body);

            if (runDbScriptResponseData.flag === false) {
                console.error("Data Fetch Error: " + runDbScriptResponseData.message);
            } else {
                console.log("Success: Bulk update successful.");
            }
        }
        catch (error) {
            console.error("Error running DB script:", error);
        } finally {
            setLoading(false);
        }
    }

    const fetchCarrierWritesFlag = async () => {
        let parsedData: any
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
            tenant_name: partner || "default_value",
            username,
            path: "/get_writes_enable_for_service_provider",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "Inventory",
            service_provider: service_provider || "",
            ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            environment: "BETA",
            change_type: change_type,
        };

        try {
            setLoading(true);
            const response = await axios.post(url, { data });
            parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === true) {
                const write_is_enabled = parsedData?.write_is_enabled || false;
                // setWritesFlag(write_is_enabled);
                return write_is_enabled;
            }
        } catch (error) {
            console.error("Error fetching data:", error);
            return false; // fallback in case of error
        } finally {
            setLoading(false);
        }
    };
    const submitCarrierStatus = async (write_is_enabled:boolean) => {
        let parsedData: any
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const iccidList = await getIccidList()
        const data = {
            tenant_name: partner || "default_value",
            username,
            path: "/insert_carrier_status_validation_audit",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "Inventory",
            service_provider: service_provider || "",
            ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            environment: "BETA",
            msisdn: service_provider.toLowerCase() === "webbing" || service_provider.toLowerCase() === "multi-carrier sim" ? [] : iccidList,
            iccid: service_provider.toLowerCase() === "webbing" || service_provider.toLowerCase() === "multi-carrier sim" ? iccidList : [],
            change_type: change_type,
            write_is_enabled:write_is_enabled,
        };

        try {
            // setLoading(true);
            const response = await axios.post(url, { data });
            parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === true) {

            }
        } catch (error) {
            console.error("Error fetching data:", error);
        } finally {
            // setLoading(false);
        }
    };

    const call_2_0_submit = async (parsedData: any, payload: any,isRouteCall: boolean) => {
        try {
            const url = ENV_ROUTES.BULKCHANGE_PROCESSOR;
            const prevChangedData = payload?.changed_data?.CarrierRatePlanUpdate || {}
            payload["effective_date"] = prevChangedData?.EffectiveDate || null
            if (providerName.toLowerCase().includes("telegence")) {
                payload["msisdns"] = payload?.iccids
                delete payload["iccids"]
            }
            delete payload["imeids"]
            const payloadData = {
                ...payload,
                path: "/bulk_change_processor",
                request_received_at: getCurrentDateTime(),
                bulk_change_id: parsedData?.bulk_chnage_id_20,
            }
            const data = { ...payloadData };
            if (!isRouteCall) {
                return data
            }
            const response = await axios.post(url, { data });
            const responseData = JSON.parse(response.data.body);
            if (responseData.flag === false) {
                console.log("Failure: 2.0 Bulk change update failed.");
            } else {
                console.log("Success: 2.0 Bulk change update successful.");
            }
        }
        catch (error) {
            console.error("Error running DB script:", error);
        } finally {
            setLoading(false);
        }
    }
    // Helper function to call run_db_script API
    const callRunDbScript = async (parsedData: any) => {
        try {
            const url = ENV_ROUTES.SIM_MANAGEMENT;
            const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
            const runDbScriptData = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/run_db_script",
                role_name: role,
                module_name: "Bulk Change",
                mod_pages: { start: 0, end: 100 },
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                service_provider_id: service_provider_id_,
                bulkchange_id: parsedData?.bulkchange_id?.id,
                data: parsedData?.data,
                bulk_chnage_id_20: parsedData?.bulk_chnage_id_20
            };

            const runDbScriptResponse = await axios.post(url, { data: runDbScriptData });
            const runDbScriptResponseData = JSON.parse(runDbScriptResponse.data.body);

            if (runDbScriptResponseData.flag === false) {
                console.error("Data Fetch Error: " + runDbScriptResponseData.message);
            } else {
                console.log("Success: Bulk update successful .");
            }
        } catch (error) {
            console.error("Error fetching data:", error);
        }
    };

    const bulkChangeInsert = async (payload: any) => {
        let partner_name = partner
        let db_name_ = selectedDb
        try {
            const url = ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner_name || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_bulk_change_insertion",
                role_name: role,
                module_name: "Bulk Change History",
                service_provider_name: service_provider,
                 ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                request_received_at: getCurrentDateTime(),
                Partner: partner_name,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === false) {
                console.error("Error fetching bulk change data:", parsedData.message ||
                    "An error occurred while fetching bulk change data. Please try again.");
                return false
            } else {
                const statusFlag = parsedData?.bulk_change_data?.status || "";
                const response_data = parsedData?.bulk_change_data?.bulk_change_data || "{}";
                const parsedResp = JSON.parse(response_data)
                console.log("status_flag", statusFlag)
                const status_flag = statusFlag ? (statusFlag).toLowerCase() : ""

                if (status_flag && status_flag === "pending") {
                    return false
                }
                else if (status_flag && status_flag === "success") {
                    call_2_0_submit(parsedResp, payload,true)
                    call_2_0_sync(parsedResp)
                    return true
                }
                else if (status_flag && status_flag === "error") {
                    Modal.error({
                        title: 'Submit Error',
                        content: parsedData.message || 'An error occurred while submitting. Please try again.',
                        centered: true,
                    });
                    return true
                }
                else {
                    return false
                }
            }
        } catch (error) {
            console.error("Error fetching auto refresh data:", error);
            return false
        } finally {
        }
    };
    const bulkChangePolling = async (data: any) => {
        const result = await bulkChangeInsert(data);
        if (!result) {
            setTimeout(() => bulkChangePolling(data), 5000); // Try again after 5 seconds
        } else {
            removeExport("bulkChangeInsert");
            console.log("Auto-refresh complete.");
        }
        // if (window.location.pathname.includes("/sim_management/bulk_change")) {
        //     window.location.reload();
        // }
    };

    const fetchDevices = async (devices_list: any[], deviceKey: string) => {
        try {
            setLoading(true);
            const url =
                ENV_ROUTES.BULKCHANGE_PROCESSOR;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_standard_iccid_msisdn_data",
                role_name: role,
                Partner: partner,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: service_provider,
                ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type,
                [deviceKey]: devices_list || []
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                // setLoading(false);
                Modal.error({
                    title: 'Submit Error',
                    content: parsedData.message || 'An error occurred while submitting data. Please try again.',
                    centered: true,
                });
                return []
            } else {
                const responseKey = deviceKey === "iccids" ? "msisdns" : "iccids"
                const devices = parsedData?.[responseKey] || []
                console.log("devices", devices)
                return devices
                // setLoading(false);
            }
        } catch (error) {
            Modal.error({
                title: 'Submit Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting data. Please try again.',
                centered: true,
            });
            return []
            // setLoading(false);
        }
        finally {
            // setLoading(false)
        }
    };

    const getIccidList = async (): Promise<string[]> => {
        // Pick devices based on subscriberNumber or iccids
        const devices_ = subscriberNumber ? subscriberNumber : iccids;

        // Find matching device type from the map
        const matchedDeviceTypeItem = simIdentifierMap.find((item: any) => {
            return (
                item.service_provider === service_provider &&
                item.change_type === change_type
            );
        });
        const matchedDeviceType = matchedDeviceTypeItem?.sim_identifier || ""
        // Decide expected type
        const selectDeviceType = subscriberNumber ? "msisdns" : "iccids";
        // Split devices into a list
        let iccidList = devices_
            .split(/\s*[\n,]\s*/)
            .map((line) => line.trim())
            .filter((line) => line.length > 0);

        // Fetch devices only if types mismatch
        if (matchedDeviceType !== selectDeviceType) {
            iccidList = await fetchDevices(iccidList, selectDeviceType);
        }

        return iccidList;
    };

    const onsubmit = async () => {
        const iccidList = await getIccidList()
        let data: any
        try {

            setLoading(true);
            const ratePlan_ = carrierRatePlan && carrierRatePlan !== 'No options' ? carrierRatePlan : null
            const ratePlanNameParts = (ratePlan_ || "").split(" -- ")
            const url = ENV_ROUTES.SIM_MANAGEMENT;
            data = {
                tenant_name: partner || "default_value",
                path: "/update_bulk_change_data",
                role_name: role,
                username: username,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: service_provider,
                ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type,
                created_by: firstLastName,
                iccids: iccidList,
                changed_data: {
                    // Devices: iccidList,
                    CarrierRatePlanUpdate: {
                        CarrierRatePlan: ratePlanNameParts.length > 0 ? ratePlanNameParts[0] : null,
                        EffectiveDate: effectiveDate,
                        OptimizationGroup: optimizationGroup && optimizationGroup !== 'No options' ? optimizationGroup : null,
                        SubscriberNumber: subscriberNumber,
                    }
                }
            };

            // Send request to the first API
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                setLoading(false);
                Modal.error({
                    title: 'Submit Error',
                    content: parsedData.message || 'An error occurred while submitting. Please try again.',
                    centered: true,
                });
                return;
            }

            const bulkrow_ = parsedData?.bulkchange_id || {};
            const bulkRow: any = { row: bulkrow_ };
            setBulkRow(bulkRow);
            localStorage.setItem('bulk_row', JSON.stringify(bulkRow || "{}"));
            if (bulkRow) {
                if(!isAllChangeType){
                    router.push(`/sim_management/bulk_history`);
                }
            }

            if ((service_provider.toLowerCase() === "webbing" || service_provider.toLowerCase() === "multi-carrier sim") && switch_user_2_0 !== "True") {
                const url = ENV_ROUTES.SM_BULK_CHANGE;
                const data: any = {
                    tenant_name: partner || "default_value",
                    path: "/update_webbing_carrier_rate_plan_name",
                    request_received_at: getCurrentDateTime(),
                    access_token: token,
                    db_name: selectedDb,
                ...metaData,
                    sessionID: sessionId,
                    service_provider: service_provider,
                    ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                    change_type: change_type,
                    bulk_change_id: parsedData?.bulkchange_id?.id,
                    data: parsedData?.data,
                    created_by: firstLastName,
                    iccids: iccidList,
                    changed_data: {
                        Devices: iccidList,
                        CarrierRatePlanUpdate: {
                            CarrierRatePlan: carrierRatePlan && carrierRatePlan !== 'No options' ? carrierRatePlan : null,
                            EffectiveDate: effectiveDate,
                            // OptimizationGroup: optimizationGroup && optimizationGroup !== 'No options' ? optimizationGroup : null,
                            // SubscriberNumber: subscriberNumber,
                        }
                    }
                }
                const webbing_response = await axios.post(url, { data });
                const webbing_parsedData = JSON.parse(webbing_response.data.body);

                if (webbing_parsedData.flag === false) {
                    console.error("Data Fetch Error: " + webbing_parsedData.message);
                } else {
                    console.log("Success: Bulk update successful.");
                }
                const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
                data["service_provider_id"] = service_provider_id_
                callWebbingSync(data)
            }
            // else {
            // Prepare payload for the new API call
            // const newApiData = {
            //     tenant_name: partner || "default_value",
            //     username: username,
            //     firstLastName: firstLastName,
            //     path: "/inventory_iccidds_imeids", // New API path
            //     service_provider: service_provider,
            //     role_name: role,
            //     module_name: "Bulk Change",
            //     mod_pages: { start: 0, end: 100 },
            //     access_token: token,
            //     db_name: selectedDb,
            //     sessionID: sessionId,
            //     request_received_at: getCurrentDateTime(),
            //     Partner: partner
            // };

            // // Call the new API to get ICCIDs and IMEIs
            // const newApiResponse = await axios.post(ENV_ROUTES.SIM_MANAGEMENT, { data: newApiData });
            // const newApiParsedData = JSON.parse(newApiResponse.data.body); // Parse the new API response

            // const AlliccidList =service_provider.toLowerCase() === "webbing" ? newApiParsedData.iccid:newApiParsedData.imei; // Adjust based on the actual structure of the response
            // const AllimeiList = newApiParsedData.imei; // Adjust based on the actual structure of the response

            // // Validate ICCIDs
            // const iccidMatch = iccidList.every(iccid => AlliccidList.includes(iccid));
            // if (!iccidMatch) {
            //     console.log("ICCID do not match.");
            //     callMismatchICCID(parsedData)
            //     return; // Exit if ICCIDs do not match
            // }

            // Proceed to call the run_db_script API
            if (switch_user_2_0 === "True") {
                if (!isAllChangeType) {
                    call_2_0_submit(parsedData, data, true);
                    call_2_0_sync(parsedData);
                }
                else {
                    const payload_2_0_: any = await call_2_0_submit(parsedData, data, false)
                    set_all_2_0_payloads((prev: any) => ({
                        ...prev,
                        [change_type]: { ...payload_2_0_ }
                    }));
                }
            }
            else {
                if (providerName.toLowerCase().includes("telegence")) {
                    await callRunDbScript(parsedData);
                }
            }

            // }

        } catch (error) {
            if (switch_user_2_0 === "True") {
                onClose()
                setLoading(false)
                addExport("bulkChangeInsert", "Bulk Change Submission");
                bulkChangePolling(data)
            }
            else {
                Modal.error({
                    title: 'Submit Error',
                    content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting. Please try again.',
                    centered: true,
                });
            }
        } finally {
            setLoading(false);
        }
    };

    const handleBack = () => {
        setShowSelectDevices(false);
    };
    const handleSelectRatePlan = (selectedOption: any) => {
        if (selectedOption) {
            const value = selectedOption?.value
            setCarrierRatePlan(value)
        }
        else {
            setCarrierRatePlan(null)

        }
    };
    const handleSelectOptimizationGroup = (selectedOption: any) => {
        if (selectedOption) {
            const value = selectedOption?.value
            setOptimizationGroup(value)
        }
        else {
            setOptimizationGroup(null)

        }
    };
    const returnChangedData = () => {
        const ratePlan_ = carrierRatePlan && carrierRatePlan !== 'No options' ? carrierRatePlan : null
        const ratePlanNameParts = (ratePlan_ || "").split(" -- ")
        const changedData = {
            CarrierRatePlanUpdate: {
                CarrierRatePlan: ratePlanNameParts.length > 0 ? ratePlanNameParts[0] : null,
                EffectiveDate: effectiveDate,
                OptimizationGroup: optimizationGroup && optimizationGroup !== 'No options' ? optimizationGroup : null,
                SubscriberNumber: subscriberNumber,
            }
        }
        return changedData
    };

    // const returnUpdatedValue = () =>{
    //     const ratePlan_ = carrierRatePlan && carrierRatePlan !== 'No options' ? carrierRatePlan : ""
    //     return (
    //     <Tooltip title={`${ratePlan_}`}>
    //         <span>
    //             {ratePlan_}
    //         </span>
    //     </Tooltip>)
    // }

    const returnUpdatedValue = () => {
            const ratePlan_ = carrierRatePlan && carrierRatePlan !== 'No options' ? carrierRatePlan : ""
            return (
                <div className="flex flex-col gap-2">
                    <div className="flex grid grid-cols-2 ">
                        <span className="font-semibold">Carrier Rate Plan:</span>
                        <span>{ratePlan_}</span>
                    </div>
                </div>
            )
        }

    useImperativeHandle(ref, () => ({
            runValidation: handleSubmit,
            runSubmit: onsubmit,
            returnUpdate: returnUpdatedValue,
        }));
        
    if (loading) {
        return (
            <div className="flex justify-center items-center h-[400px]">
                <Spin size="large" />
            </div>
        );
    }
    return (
        <div>
            {!showSelectDevices ? (
                <>
                    {isAllChangeType && (
                        <div className="flex justify-end px-4">
                            <span className="mr-2 font-semibold">Save Changes</span>
                            <Checkbox
                                checked={saveChanges}
                                onChange={(e) => {
                                    if (!e.target.checked) {
                                        setsuccessFullChangeTypes(
                                            successFullChangeTypes.filter((c: any) => c !== activeChange)
                                        );
                                    }
                                    setSaveChanges(e.target.checked)
                                }}
                                className="custom-checkbox"
                            >

                            </Checkbox>
                        </div>
                    )}
                
                <div className={`${!isAllChangeType?"flex flex-col space-y-4 mt-4":"flex grid grid-cols-2 gap-4"}`}>
                    {/* Carrier Rate Plan */}
                    <div className={`${!isAllChangeType?"flex flex-col space-y-1 mt-4":""}`}>
                        <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                            <label htmlFor="carrierRatePlan" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                Carrier Rate Plan<span className='text-red-500'>*</span>
                            </label>
                            <Select
                                id="carrierRatePlan"
                                placeholder="Select Carrier Rate Plan"
                                options={ratePlanOptions.length > 0 ? ratePlanOptions.map((option: string) => ({
                                    label: option,
                                    value: option,
                                })) : [{ value: 'No options', label: 'No options' }]}
                                value={carrierRatePlan === 'No options' ? null : { label: carrierRatePlan, value: carrierRatePlan }}
                                onChange={handleSelectRatePlan}
                                styles={DropdownStyles}
                                className={`${!isAllChangeType?"w-2/3":"w-full"}`}
                                isClearable
                                menuPortalTarget={document.body}
                                menuPosition="fixed"
                                menuPlacement="auto"
                            />
                        </div>
                        {carrierRatePlanError && (
                            <div className="text-red-500 text-sm mt-2">
                                {carrierRatePlanError}
                            </div>
                        )}
                    </div>

                    {/* Optimization Group */}
                    {(service_provider.toLowerCase() !== "webbing" || service_provider.toLowerCase() !== "multi-carrier sim") &&
                        <div className={`${!isAllChangeType?"flex flex-col space-y-4 mt-4":""}`}>
                            <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                <label htmlFor="optimizationGroup" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                    Optimization Group
                                </label>
                                <Select
                                    id="optimizationGroup"
                                    placeholder="Select Optimization Group"
                                    options={optimizationOptions.length > 0 ? optimizationOptions.map((option: string) => ({
                                        label: option,
                                        value: option,
                                    })) : [{ value: 'No options', label: 'No options' }]}
                                    value={optimizationGroup === 'No options' ? null : { label: optimizationGroup, value: optimizationGroup }}
                                    onChange={handleSelectOptimizationGroup}
                                    styles={DropdownStyles}
                                    className={`${!isAllChangeType?"w-2/3":"w-full"}`}
                                    isClearable
                                    menuPortalTarget={document.body}
                                    menuPosition="fixed"
                                    menuPlacement="auto"
                                />
                            </div>
                        </div>}


                    {/* Effective Date Checkbox */}
                    <div className={`${isAllChangeType?"flex items-center space-x-4":""}`}>
                    <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                        <div className="space-x-4 mt-2">
                            <label htmlFor="effectiveDateCheckbox" className={`${!isAllChangeType?"w-1/3 font-semibold":""}`}>
                            Effective Date
                        </label>
                        <Checkbox
                            id="effectiveDateCheckbox"
                            checked={effectiveDateCheckbox}
                            onChange={(e) => setEffectiveDateCheckbox(e.target.checked)}
                            
                        />
                        </div>
                       </div>
                        
                    </div>
    

                    {/* Effective Date */}
                    {effectiveDateCheckbox && (
                        <div className={`${!isAllChangeType?"flex flex-col space-y-1":""}`}>
                            <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                <label htmlFor="effectiveDate" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                    Effective Date <span className="text-red-500">*</span>
                                </label>
                                <DatePicker
                                    id="effectiveDate"
                                    value={effectiveDate}
                                    onChange={(date) => {
                                        if (date) {
                                            const safeDate = date.hour(12).minute(0).second(0).millisecond(0);
                                            console.log(safeDate)
                                            setEffectiveDate(safeDate);
                                        } else {
                                            setEffectiveDate(null);
                                        }
                                    }}
                                    className={`${!isAllChangeType?"w-2/3":"w-full"}`}
                                />
                            </div>
                            {effectiveDateError && (
                                <div className="text-red-500 text-sm">
                                    {effectiveDateError}
                                </div>
                            )}
                        </div>
                    )}

                    {/* ICCID */}
                    {!isAllChangeType && (
                        <div className="flex flex-col space-y-4">
                        <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                            <label htmlFor="iccid" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                ICCID<span className='text-red-500'>*</span>
                            </label>
                            <Input.TextArea
                                id="iccid"
                                value={iccids}
                                onChange={(e) => {
                                    setIccids(e.target.value);
                                    if (e.target.value) setSubscriberNumber("");
                                }}
                                rows={4}
                                // placeholder="Enter Subscriber Number(s)"
                                placeholder={
                                    "Enter ICCIDs here"
                                }
                                className={`${!isAllChangeType?"w-2/3":"w-full"}`}
                                disabled={!!subscriberNumber}

                            />
                        </div>
                        {/* Subscriber Number */}
                        <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                            <label htmlFor="subscriberNumber" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                Subscriber Number<span className='text-red-500'>*</span>
                            </label>
                            <Input.TextArea
                                id="subscriberNumber"
                                value={subscriberNumber}
                                onChange={(e) => {
                                    setSubscriberNumber(e.target.value);
                                    if (e.target.value) setIccids("");
                                }}
                                rows={4}
                                // placeholder="Enter Subscriber Number(s)"
                                placeholder={
                                    "Enter Subscriber Numbers here"
                                }
                                className={`${!isAllChangeType?"w-2/3":"w-full"}`}
                                disabled={!!iccids}
                            />
                        </div>
                        {subscriberNumberError && (
                            <div className="text-red-500 text-sm">
                                {subscriberNumberError}
                            </div>
                        )}
                    </div>
                    )}
                    

                    {/* Action Buttons */}
                    {!isAllChangeType && (
                        <div className="flex justify-center space-x-4 mt-4">
                        <button onClick={onBack} className="cancel-btn">
                            {/* <ArrowLeftIcon className="h-5 w-5 mr-2" /> */}
                            Back
                        </button>
                        <button onClick={handleSubmit} className="save-btn">
                            Submit
                        </button>
                    </div>
                    )}
                    
                </div>
                </>
            ) : (
                <SelectDevices onContinue={onContinue} onBack={handleBack} service_provider={service_provider} change_type={change_type} changed_data={returnChangedData()} onCancel={onClose} />
            )}
        </div>
    );
}
)

export default ChangeCarrierRatePlan3;
