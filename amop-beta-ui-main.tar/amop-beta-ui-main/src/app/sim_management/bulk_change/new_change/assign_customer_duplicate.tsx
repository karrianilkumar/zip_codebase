"use client";

import { FC, useCallback, useEffect, useState, forwardRef, useImperativeHandle  } from "react";
import Select, { MultiValue } from 'react-select';
import {
    DatePicker,
    Checkbox,
    Modal,
    Spin,
    Input,
    Tooltip,

} from "antd";
// import "tailwindcss/tailwind.css";
import { useRouter } from "next/navigation";
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { useFeatureStore } from "../../inventory/featureStore";
import VirtualizedSelect from "@/app/components/virtualized_dropdown";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import React from "react";
import { DropdownStyles } from "@/app/components/css/dropdown";
import PreviewModal from "./previewModal";
import { ArrowLeftIcon, ArrowRightIcon, EyeIcon } from "@heroicons/react/24/outline";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { useAllChangeTypesStore } from "@/app/stores/allChangeTypesStore";
import { PerformanceLogStore } from "@/app/stores/performance_matrix_store";
import { useInventoryAllChangeTypesStore } from "@/app/stores/inventorytAllChangeTypesStore";
import moment , { Moment } from "moment";

interface AssignCustomerContentProps {
    onContinue: (customerName: string) => void;
    onBack: () => void;
    dropdown: any;
    service_provider: any;
    change_type: any;
    isSubmitScreen: boolean;
    onClose: () => void;
}
interface ProductRate {
    product_id: number;
    description: string;
    rate: string | number; // Assuming rate can be a string or number
}

interface PackageRate {
    package_id: string;
    description: string;
}

interface RateDetail {
    subdescription: string;
    product_id: number;
    rate: string | number; // Assuming rate can be a string or number
}

type SelectOption = { value: string; label: string };
type OptionType = { value: string; label: string; };


export interface AssignCustomerContentRef {
  runValidation: () => Promise<void> | void;
  runSubmit: () => Promise<void> | void;
  returnUpdate: () => React.ReactNode | Promise<React.ReactNode>;
}

const AssignCustomerContent = forwardRef<AssignCustomerContentRef, AssignCustomerContentProps>(
    ({
        onContinue,
        onBack,
        dropdown,
        service_provider,
        change_type,
        isSubmitScreen,
        onClose
    }, ref) => {
    const [revCustomer, setRevCustomer] = useState<any>("");

    const [createServiceProduct, setCreateServiceProduct] = useState(false);
    const [prorate, setProrate] = useState(false);
    const [useCarrierActivation, setUseCarrierActivation] = useState(false);
    const [customerRatePlan, setCustomerRatePlan] = useState<any | null>(
        null
    );
    
    const [effectiveDate, setEffectiveDate] = useState<moment.Moment | null>(null);
    const [isCustomDateChecked, setIsCusomDateChecked] = useState<boolean>(false);
    const [selectedDateOption, setSelectedDateOption] = useState<string | null>(null);
    const [effectiveDateOptions, setEffectiveDateOptions] = useState<any[]>([]);
    const [effectiveDateOptionsMap, setEffectiveDateOptionsMap] = useState<any>({});
    const [customerPool, setCustomerPool] = useState<SelectOption | null>(null);
    const [subscriberNumber, setSubscriberNumber] = useState<string>("");
    const [devices, setDevices] = useState<any[]>([]);
    const [iccids, setIccids] = useState<string>("");
    const [serviceType, setServiceType] = useState<string>("");
    const [revIOProduct, setRevIOProduct] = useState<any[]>([]); // Initialize as an empty array

    const [revIOPackage, setRevIOPackage] = useState<string>("");
    const [providerPackageMap, setProviderPackageMap] = useState<any>([]);
    const [description, setDescription] = useState("");
    const [errors, setErrors] = useState<any>([]);
    const [revCustomersOptions, setRevCustomersOptions] = useState<any>([]);
    const [revIOProviderOptions, setRevIOProviderOptions] = useState<any>([]);
    const [serviceTypeOptions, setServiceTypeOptions] = useState<any>([]);
    const [customerRatePlansOptions, setCustomerRatePlanOptions] = useState<any>(
        []
    );
    const [customerRatePoolOptions, setCustomerRatePoolOptions] = useState<any>(
        []
    );
    const [loading, setLoading] = useState(false);
    const router = useRouter();
    const { username, role, partner, token, selectedDb,metaData, firstLastName, sessionId, modulesVersionMap } = useAuth();
    const { setBulkRow, bulkChangeLimit, simIdentifierMap } = useFeatureStore();
    const [revIOProviderId, setRevIOProviderId] = useState<number | null>(null);
    const [selectedProduct, setSelectedProduct] = useState<MultiValue<{ label: string; value: number }>>([]); // Update type here
    const [selectedPackage, setSelectedPackage] = useState<any | null>(null);
    const [selectedRates, setSelectedRates] = useState<{ [key: string]: string | number }>({});
    const [productOptions, setProductOptions] = useState<any[]>([]);
    const [packageOptions, setPackageOptions] = useState<any[]>([]);
    const [productRateMap, setProductRateMap] = useState<any[]>([]);
    const [packageRateMap, setPackageRateMap] = useState<any[]>([]);

    const [productError, setProductError] = useState(false);
    const [iccidError, setIccidError] = useState("");
    // Add state for package product IDs
    const [packageProductIds, setPackageProductIds] = useState<number[]>([]);
    const [isRedirected, setIsRedirected] = useState(false);
    const [activationFlag, setActivationFlag] = useState(false);
    const [revMultiCustomersOptions, setRevMultiCustomersOptions] = useState<any>([]);
    const [revMultiCustomer, setRevMultiCustomer] = useState<any[]>([]);
    const [openPreviewModal, setPreviewModal] = useState<boolean>(false);
    const initial_version_flag = modulesVersionMap?.["Sim Management-Bulk Change"] || false
    const isVersionEnabled = localStorage.getItem("switch_user_2_0_bulk_change") === "True";
    const switch_user_2_0 = isVersionEnabled && initial_version_flag ? "True" : "False"
    const handlePreviewOpen = async () => {
        setPreviewModal(true)
    };
    const { addExport, removeExport, exports } = exportLoadingStore();
    const [theme, setTheme] = useState('normal');
    const { isAllChangeType,setIsValidated,setValidationTrigger,allChangeTypesDevices, setsuccessFullChangeTypes, activeChange, successFullChangeTypes, all_2_0_payloads, set_all_2_0_payloads } = useAllChangeTypesStore();
    const [saveChanges, setSaveChanges] = useState<boolean>(true);
    const { getTargetTenantProvider, IsTargetTenantProvider } = PerformanceLogStore();
    const is_parent_provider_exists = IsTargetTenantProvider(service_provider)
    const providerName = getTargetTenantProvider(service_provider).toLowerCase() || service_provider;
    const {setAssignCustomerData } = useInventoryAllChangeTypesStore();

    const handleRevMultiCustomer = useCallback(
        (selectedOptions: any) => {
            setRevMultiCustomer(selectedOptions);
            if (isSubmitScreen) {
                if (createServiceProduct && selectedOptions.length === 0) {
                    setErrors((prev: any) => ({
                        ...prev,
                        revCustomer: "Please select Billing Customer"
                    }))
                } else {
                    setErrors((prev: any) => ({
                        ...prev,
                        revCustomer: ""
                    }))
                }
            }

        },
        [createServiceProduct]
    );

    useEffect(() => {
        if (typeof window !== 'undefined') {
            try {
                const storedTheme = localStorage.getItem('app_theme');
                if (storedTheme) setTheme(storedTheme);
            } catch (e) {
                console.warn("Error reading theme from localStorage:", e);
            }
        }
    }, []);

     useEffect(() => {
            if(isAllChangeType){
                const devices = allChangeTypesDevices?.iccids || []
                const devicesString = devices.join('\n')
                if(allChangeTypesDevices?.isIccid){
                    setSubscriberNumber("")
                    setIccids(devicesString);
                }
                else{
                    setIccids("")
                    setSubscriberNumber(devicesString);
                }
            }
        }, [isAllChangeType , allChangeTypesDevices]);

    const fetchCustomerOptions = async () => {
        try {
            setLoading(true);
            const url =
                ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                path: "/get_assign_customer_bulk_change_data",
                request_received_at: getCurrentDateTime(),
                username: username,
                firstLastName: firstLastName,
                role_name: role,
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: service_provider,
                 ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                setLoading(false);
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                const options_ = parsedData?.dropdown_data?.rev_customer_dropdown || []
                setRevCustomersOptions(options_)
                if (isSubmitScreen) {
                    const formatted_options = options_.map((opt: any) => ({ label: opt, value: opt }))
                    setRevMultiCustomersOptions(formatted_options)
                }
                setLoading(false);
            }
        } catch (error) {
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        }
    };
    const fetchCustomerRatePlanOptions = async () => {
        try {
            setLoading(true);
            const url =
                ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                path: "/get_customer_rate_plan_bulk_change_data",
                request_received_at: getCurrentDateTime(),
                username: username,
                firstLastName: firstLastName,
                role_name: role,
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: service_provider,
                 ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                setLoading(false);
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                const options_ = parsedData?.dropdown_data?.customer_rate_plan_dropdown || [];
                setCustomerRatePlanOptions(options_);

                setLoading(false);
            }
        } catch (error) {
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        }
    };
    const fetchCustomerRatePoolOptions = async () => {
        try {
            setLoading(true);
            const url =
                ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                path: "/get_customer_rate_pool_bulk_change_data",
                request_received_at: getCurrentDateTime(),
                username: username,
                firstLastName: firstLastName,
                role_name: role,
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: service_provider,
                 ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                setLoading(false);
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                const options_ = parsedData?.dropdown_data?.customer_rate_pool_dropdown || [];
                setCustomerRatePoolOptions(options_);
                setLoading(false);
            }
        } catch (error) {
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        }
    };
    const fetchServiceTypeOptions = async () => {
        try {
            setLoading(true);
            const url =
                ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                path: "/get_rev_service_type_bulk_change_data",
                request_received_at: getCurrentDateTime(),
                username: username,
                firstLastName: firstLastName,
                role_name: role,
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: service_provider,
                 ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                setLoading(false);
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                const options_ = parsedData?.dropdown_data?.rev_service_type || [];
                setServiceTypeOptions(options_);
                setLoading(false);
            }
        } catch (error) {
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        }
    };
    const fetchRevProviderOptions = async () => {
        try {
            setLoading(true);
            const url =
                ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                path: "/get_rev_provider_bulk_change_data",
                request_received_at: getCurrentDateTime(),
                username: username,
                firstLastName: firstLastName,
                role_name: role,
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: service_provider,
                 ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                setLoading(false);
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                const rev_provider = parsedData?.dropdown_data?.rev_provider || {};
                const revProviderOptions = Object.entries(rev_provider).flatMap(
                    ([description, providerIds]) => {
                        // Type assertion to ensure providerIds is an array of numbers
                        const ids = providerIds as number[];
                        return ids.map(provider_id => ({
                            label: description,
                            value: provider_id, // Use the provider ID as the value
                        }));
                    }
                );
                setRevIOProviderOptions(revProviderOptions);
                setLoading(false);
            }
        } catch (error) {
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        }
    };
    const fetchRevProductOptions = async () => {
        try {
            setLoading(true);
            const url =
                ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                path: "/get_rev_product_bulk_change_data",
                request_received_at: getCurrentDateTime(),
                username: username,
                firstLastName: firstLastName,
                role_name: role,
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: service_provider,
                ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                setLoading(false);
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                const options_ = parsedData?.dropdown_data || []
                setProductOptions(options_)
                setLoading(false);
            }
        } catch (error) {
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        }
    };
    const fetchRevPackagerOptions = async () => {
        try {
            setLoading(true);
            const url =
                ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                path: "/get_rev_package_bulk_change_data",
                request_received_at: getCurrentDateTime(),
                username: username,
                firstLastName: firstLastName,
                role_name: role,
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: service_provider,
                ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                setLoading(false);
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                const options_ = parsedData?.dropdown_data || []
                setPackageOptions(options_)
                setLoading(false);
            }
        } catch (error) {
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        }
    };
    const fetchRevProductRateOptions = async () => {
        try {
            setLoading(true);
            const url =
                ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                path: "/get_rev_product_rate_bulk_change_data",
                request_received_at: getCurrentDateTime(),
                username: username,
                firstLastName: firstLastName,
                role_name: role,
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: service_provider,
                ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                setLoading(false);
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                const rev_product_rate: ProductRate[] = parsedData?.dropdown_data?.rev_product_rate || [];
                // const rev_package_rate: [PackageRate, RateDetail[]][] = dropdown.rev_package_rate || [];
                setProductRateMap(rev_product_rate)
                // Set product options
                const productOptions_ = rev_product_rate.map(product => ({
                    label: `${product.description} - ${product.product_id}`,
                    value: product.product_id,
                }));
                setProductOptions(productOptions_);
                setLoading(false);
            }
        } catch (error) {
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        }
    };
    const fetchRevPackageRateOptions = async () => {
        try {
            setLoading(true);
            const url =
                ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                path: "/get_rev_package_rate_bulk_change_data",
                request_received_at: getCurrentDateTime(),
                username: username,
                firstLastName: firstLastName,
                role_name: role,
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: service_provider,
                ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                setLoading(false);
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                const rev_package_rate = parsedData?.dropdown_data?.rev_package_rate || [];
                setPackageRateMap(rev_package_rate)
                setProviderPackageMap(rev_package_rate);
                setLoading(false);
            }
        } catch (error) {
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        }
    };

    useEffect(() => {
        // console.log("dropdown", dropdown);
        // const rev_customer_dropdown = dropdown?.rev_customer_dropdown || [];
        // setRevCustomersOptions(rev_customer_dropdown);
        // console.log(dropdown?.rev_provider);
        // // Update this part to handle the new structure of rev_provider
        // const rev_provider = dropdown?.rev_provider || {};
        // const revProviderOptions = Object.entries(rev_provider).flatMap(
        //   ([description, providerIds]) => {
        //     // Type assertion to ensure providerIds is an array of numbers
        //     const ids = providerIds as number[];
        //     return ids.map(provider_id => ({
        //       label: description,
        //       value: provider_id, // Use the provider ID as the value
        //     }));
        //   }
        // );
        // console.log("revProviderOptions", revProviderOptions);
        // setRevIOProviderOptions(revProviderOptions);
        // setRevIOProviderOptions(revProviderOptions);

        // const rev_service_type = dropdown?.rev_service_type || [];
        // setServiceTypeOptions(rev_service_type);

        // const rev_package_rate = dropdown?.rev_package_rate || [];
        // setProviderPackageMap(rev_package_rate);

        // const customer_rate_plan_dropdown =
        //   dropdown?.customer_rate_plan_dropdown || [];
        // setCustomerRatePlanOptions(customer_rate_plan_dropdown);

        // const customer_rate_pool_dropdown =
        //   dropdown?.customer_rate_pool_dropdown || [];
        // setCustomerRatePoolOptions(customer_rate_pool_dropdown);
        // //product rates
        // const rev_product_rate: ProductRate[] = dropdown.rev_product_rate || [];
        // // const rev_package_rate: [PackageRate, RateDetail[]][] = dropdown.rev_package_rate || [];

        // // Set product options
        // const productOptions_ = rev_product_rate.map(product => ({
        //   label: `${product.description} - ${product.product_id}`,
        //   value: product.product_id,
        // }));
        // setProductOptions(productOptions_);

        // // Set package options
        // // const packageOptions_ = rev_package_rate.map(pkg => ({
        // //   label: `${pkg[0].description} - ${pkg[0].package_id}`,
        // //   value: pkg[0].package_id,
        // // }));
        // // setPackageOptions(packageOptions_);
        fetchCustomerOptions()
        fetchCustomerRatePlanOptions()
        fetchCustomerRatePoolOptions()
        // fetchRevPackageRateOptions()
        // fetchServiceTypeOptions()
        // fetchRevProductRateOptions()
        // fetchRevProviderOptions()
    }, [dropdown]);
    // Options for dropdowns

    useEffect(() => {
        if (createServiceProduct) {
            fetchRevProviderOptions()
            fetchServiceTypeOptions()
            fetchRevPackageRateOptions()
            fetchRevProductRateOptions()
        }
    }, [createServiceProduct])

    const messageStyle = {
        fontSize: "14px",
        fontWeight: "bold",
        padding: "16px",
    };


    // Update handlers to handle null values when clearing
    const handleSelectChange = useCallback(
        (newValue: any) => {
            setRevCustomer(newValue?.value || "");
            if (!isSubmitScreen) {
                if (createServiceProduct && !newValue) {
                    // setErrors("Please select Billing Customer");
                    setErrors((prev: any) => ({
                        ...prev,
                        revCustomer: "Please select Billing Customer"
                    }))
                } else {
                    // setErrors("");
                    setErrors((prev: any) => ({
                        ...prev,
                        revCustomer: ""
                    }))
                }
            }
        },
        [createServiceProduct]
    );


    useEffect(() => {
      if (dropdown) {
        
        const billing_start_dates_options_map = dropdown?.billing_start_dates || {};
        setEffectiveDateOptionsMap(billing_start_dates_options_map)
        setEffectiveDateOptions([
            ...Object.keys(billing_start_dates_options_map).map((option: string) => ({
                label: option,
                value: option,
            }))
        ]);
      }
    }, [dropdown]);

const handleSelectEffectiveDate = (selectedOption: any) => {
        setIsCusomDateChecked(false)
        setEffectiveDate(null)
        if (selectedOption) {
            const value = selectedOption?.value || "";
            setSelectedDateOption(value)
            const mappedDate = effectiveDateOptionsMap[value] || null
            const normalizedValue = value.toLowerCase()
            if(normalizedValue.includes("bill")){
                setEffectiveDate(mappedDate)
            }
            else if(normalizedValue.includes("current")){
                setEffectiveDate(moment());
            }
            else if(normalizedValue.includes("custom")){
                setIsCusomDateChecked(true)
            }

        }
        else {
            setEffectiveDate(null)
            setSelectedDateOption(null)
        }
    };


    // Function for handling provider change
    
    const handleProviderChange = (selectedOption: any) => {
        console.log(selectedOption, "Show the selected option")
        if (selectedOption) {
            setSelectedPackage(null)
            const value = selectedOption.value || ""
            setRevIOProviderId(value)


            // Filter packages with matching provider_id and push descriptions
            const packageOptions_ = providerPackageMap
                .filter((pkg: any) => pkg[0].provider_id === value)
                .map((pkg: any) => ({
                    label: `${pkg[0].description} - ${pkg[0].package_id}`,
                    value: pkg[0].package_id,
                }));
            //  const packageOptions_ = rev_package_rate.map(pkg => ({
            //   label: `${pkg[0].description} - ${pkg[0].package_id}`,
            //   value: pkg[0].package_id,
            // }));
            setPackageOptions(packageOptions_)
            console.log(value, "Filtered package options");
        }
        else if (selectedOption === null) {
            setRevIOProviderId(null)
        }

    };


    const handleselectServiceType = (selectedOption: any) => {
        setServiceType(selectedOption?.value || "");
    };

    const handleProductChange = (newValue: MultiValue<{ label: string; value: number }>) => {
        setSelectedProduct(newValue);
        const productIds = newValue.map(option => option.value);
        setRevIOProduct(productIds); // Update revIOProduct with the array of product IDs
        console.log("productRateMap", productRateMap)

        // Update rates based on selected products
        const newRates: { [key: string]: string | number } = {};
        const productDescriptions = newValue.map(option => {
            const productRate = (productRateMap).find((product: ProductRate) => product.product_id === option.value);
            console.log("productRate", productRate)

            if (productRate) {
                newRates[productRate.description] = productRate.rate || "";
                return productRate.description; // Collect product descriptions
            }
            return null;
        }).filter(Boolean); // Filter out null values

        console.log("productDescriptions", productDescriptions)
        setSelectedRates(newRates);

        // Set the description to the concatenated product descriptions
        // setDescription(productDescriptions.join(", "));

        // Clear package selection when products are selected
        setSelectedPackage(null);
        setRevIOPackage("");
    };

    // Update the handlePackageChange function
    const handlePackageChange = (selectedOption: any) => {
        setSelectedPackage(selectedOption);
        if (selectedOption) {
            setRevIOPackage(selectedOption.value);
            const packageInfo = packageRateMap.find(
                (pkg: [PackageRate, RateDetail[]]) => pkg[0].package_id === selectedOption.value
            );

            if (packageInfo) {
                const rates: RateDetail[] = packageInfo[1];
                const newRates: { [key: string]: string | number } = {};
                const productIdsSet: Set<number> = new Set(); // Use a Set to store unique product IDs

                rates.forEach(rate => {
                    newRates[rate.subdescription] = rate.rate || "";
                    if (rate.product_id) {
                        productIdsSet.add(rate.product_id); // Add product_id to the Set
                    }
                });

                const productIds = Array.from(productIdsSet); // Convert Set back to an array
                console.log(productIds, "After pushing unique product IDs");
                console.log(newRates, "newRates");


                setSelectedRates(prevRates => ({
                    // ...prevRates,
                    ...newRates,
                }));
                setPackageProductIds(productIds); // Store unique package product IDs

                // Set the description to the package description
                // setDescription(packageInfo[0].description); // Set the description to the package description
            }
            // Clear product selection when package is selected
            setSelectedProduct([]);
            setRevIOProduct([]);
        } else {
            setRevIOPackage("");
            setSelectedRates({});
            setPackageProductIds([]); // Clear package product IDs
            setDescription(""); // Clear description if no package is selected
        }
    };

    const fetchActivationFlag = async (value: string) => {
        const customerRatePlan_ = (value && value !== 'No options') ? value : null
        let ratePlanNameParts = []
        ratePlanNameParts = (customerRatePlan_ || "").split(" -- ")
        const customer_rate_plan_ = ratePlanNameParts && ratePlanNameParts.length > 0 ? ratePlanNameParts[0] : null
        try {
            setLoading(true);
            const url =
                ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                path: "/crp_carrier_activation_flag",
                request_received_at: getCurrentDateTime(),
                username: username,
                firstLastName: firstLastName,
                role_name: role,
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: service_provider,
                ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type,
                customer_rate_plan: customer_rate_plan_,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                setLoading(false);
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                const activation_flag = parsedData?.use_carrier_activation || false
                if ((role?.toLowerCase() === "super admin" || role?.toLowerCase() === "partner admin")) {
                    setActivationFlag(activation_flag)
                    // if (activation_flag) {
                    //     setUseCarrierActivation(true)
                    // }
                }

                setLoading(false);
            }
        } catch (error) {
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        }
    };

    const handleCustomerRatePlanChange = (selectedOption: any) => {
        setCustomerRatePlan(selectedOption?.value || null);
        if (isSubmitScreen) {
            fetchActivationFlag(selectedOption?.value || "")
        }
    };

    const handleCustomerRatePoolChange = (selectedOption: any) => {
        setCustomerPool(selectedOption?.value || null);
    };

    const callKoreSync = async (data: any) => {
        const koreUrl = ENV_ROUTES.SM_BULK_CHANGE;
        let koreData = { ...data }
        koreData["path"] = "/start_sync"

        const koreResponse = await axios.post(koreUrl, { data: koreData });
        const koreResponseData = JSON.parse(koreResponse.data.body);

        if (koreResponseData.flag === false) {
            console.error("Data Fetch Error: " + koreResponseData.message);
        } else {
            console.log("Success: Bulk update successful.");
        }

    }

    const callProcessServiceNumbers = async (parsedData: any) => {
        try {
            const url = ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/process_service_numbers",
                role_name: role,
                module_name: "Revenue Assurance",
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                bulkchange_id: parsedData?.bulk_chnage_id_20,
                service_ids: parsedData?.service_numbers || []

            };

            const response = await axios.post(url, { data });
            const responseData = JSON.parse(response.data.body);

            if (responseData.flag === false) {
                console.log("callProcessServiceNumbers failed")
            } else {
                console.log("callProcessServiceNumbers success")
            }
        } catch (error) {
            console.error("Error fetching data:", error);
        } finally {
        }

    }
    const callMismatchICCID = async (parsedData: any) => {
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/bulk_change_validation_update",
            role_name: role,
            module_name: "Bulk Change",
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            bulkchange_id: parsedData?.bulkchange_id?.id,
            bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
        };

        const response = await axios.post(url, { data });
        const parsedResponse = JSON.parse(response.data.body);

        if (parsedResponse.flag === false) {
            console.error("Data Fetch Error mismatch ICCID: " + parsedResponse.message);
        } else {
            console.log("Success: Bulk update successful.");
        }
    }

    const callSyncLambda = async () => {
        try {
            const url = ENV_ROUTES.OPTIMIZATION_SYNC_LAMBDA;
            const data = {
                key_name: "bulk_change_rev_sync",
                path: "/lambda_sync_jobs_",
                tenant_name: partner || "default_value",
                service_provider: service_provider || "",
                ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
            };

            const response = await axios.post(url, { data });
            const responseData = JSON.parse(response.data.body);

            if (responseData.flag === false) {
                console.error("Data Fetch Error: " + responseData.message);
            } else {
                console.log("Success: Inventory lambda sync successful.");
            }
        } catch (error) {
            console.error("Error fetching data:", error);
        }

    }

        const isFutureDate = (
            effectiveDate: string | Date | moment.Moment | null
        ): boolean => {
            if (!effectiveDate) return false;

            const date = moment.isMoment(effectiveDate)
                ? effectiveDate.clone()
                : moment.utc(effectiveDate);

            if (!date.isValid()) return false;
            return date.startOf("day").isAfter(moment().startOf("day"));
        };

    const call_2_0_submit = async (parsedData: any, payload: any,isRouteCall:boolean) => {
        try {
            const url = ENV_ROUTES.BULKCHANGE_PROCESSOR;
            const prevChangedData = payload?.changed_data || {}
            const isTelegence = providerName.toLowerCase().includes("telegence");
            const isVerizon = (providerName.toLowerCase().includes("verizon") || providerName.toLowerCase().includes("vzn") || providerName.toLowerCase().includes("vzwcr") || providerName.toLowerCase().includes("2215-so01"));
            const isWebbing = providerName.toLowerCase().includes("webbing") || providerName.toLowerCase().includes("multi-carrier sim") || providerName.toLowerCase().includes("multi-carrier sim");
            // if (isTelegence || isVerizon) {
            //     delete payload["changed_data"]
            // }

            let path_ = isFutureDate(effectiveDate) ? "/schedule_bulk_change_execution" : "/bulk_change_processor"
            const payloadData = {
                ...payload,
                path: path_,
                request_received_at: getCurrentDateTime(),
                bulk_change_id: parsedData?.bulk_chnage_id_20,
            }
            const data = { ...payloadData };
            if(!isRouteCall){
                 return {
                    ... data,
                    ...(isFutureDate(effectiveDate) && {is_future : true})
                };
            }
            const response = await axios.post(url, { data });
            const responseData = JSON.parse(response.data.body);
            if (responseData.flag === false) {
                console.log("Failure: 2.0 Bulk change update failed.");
            } else {
                console.log("Success: 2.0 Bulk change update successful.");
            }
        }
        catch (error) {
            console.error("Error running DB script:", error);
        } finally {
            setLoading(false);
        }
    }
    const call_2_0_sync = async (parsedData: any) => {
        try {
            const runDbScriptUrl = ENV_ROUTES.SIM_MANAGEMENT;
            const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
            const runDbScriptData = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/update_bulk_change_tables_10",
                role_name: role,
                module_name: "Bulk Change",
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                // service_provider_id: service_provider_id_,
                // bulkchange_id: parsedData?.bulkchange_id?.id,
                // data: parsedData?.data,
                data: {
                    bulk_change_id: parsedData?.bulk_chnage_id_20,
                },
                is_update: false,
                // bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
            };

            const runDbScriptResponse = await axios.post(runDbScriptUrl, { data: runDbScriptData });
            const runDbScriptResponseData = JSON.parse(runDbScriptResponse.data.body);

            if (runDbScriptResponseData.flag === false) {
                console.error("Data Fetch Error: " + runDbScriptResponseData.message);
            } else {
                console.log("Success: Bulk update successful.");
            }
        }
        catch (error) {
            console.error("Error running DB script:", error);
        } finally {
            setLoading(false);
        }
    }

    const callRunDbScript = async (parsedData: any) => {
        try {
            const runDbScriptUrl = ENV_ROUTES.SIM_MANAGEMENT;
            const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
            const runDbScriptData = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/run_db_script",
                role_name: role,
                module_name: "Bulk Change",
                mod_pages: { start: 0, end: 100 },
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                service_provider_id: service_provider_id_,
                bulkchange_id: parsedData?.bulkchange_id?.id,
                data: parsedData?.data,
                bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
                use_carrier_activation: useCarrierActivation,
            };

            const runDbScriptResponse = await axios.post(runDbScriptUrl, { data: runDbScriptData });
            const runDbScriptResponseData = JSON.parse(runDbScriptResponse.data.body);

            if (runDbScriptResponseData.flag === false) {
                console.error("Error running DB script:", runDbScriptResponseData.message);
            } else {
                console.log("DB script executed successfully");
            }
        } catch (error) {
            console.error("Error running DB script:", error);
        } finally {
            setLoading(false);
        }
    }

    const fetchCarrierWritesFlag = async () => {
        let parsedData: any
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
            tenant_name: partner || "default_value",
            username,
            path: "/get_writes_enable_for_service_provider",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "Inventory",
            service_provider: service_provider || "",
            ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            environment: "BETA",
            change_type: change_type,
        };

        try {
            setLoading(true);
            const response = await axios.post(url, { data });
            parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === true) {
                const write_is_enabled = parsedData?.write_is_enabled || false;
                // setWritesFlag(write_is_enabled);
                return write_is_enabled;
            }
        } catch (error) {
            console.error("Error fetching data:", error);
            return false; // fallback in case of error
        } finally {
            // setLoading(false);
        }
    };
    const submitCarrierStatus = async ( write_is_enabled:boolean) => {
        let parsedData: any
        const iccidList = await getIccidList()
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
            tenant_name: partner || "default_value",
            username,
            path: "/insert_carrier_status_validation_audit",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "Inventory",
            service_provider: service_provider || "",
            ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            environment: "BETA",
            msisdn: [],
            iccid: iccidList,
            change_type: change_type,
            write_is_enabled:write_is_enabled,
        };

        try {
            // setLoading(true);
            const response = await axios.post(url, { data });
            parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === true) {

            }
        } catch (error) {
            console.error("Error fetching data:", error);
        } finally {
            // setLoading(false);
        }
    };

    const fetchTaggedCustomers = async (iccids: any) => {
        try {
            const isTelegence = providerName?.toLowerCase().includes("telegence")
            // setLoading(true);
            const url =
                ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                path: "/customers_tagged_iccids",
                request_received_at: getCurrentDateTime(),
                username: username,
                firstLastName: firstLastName,
                role_name: role,
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: service_provider,
                ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type,
                iccids: iccids

            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                // setLoading(false);
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                const options_ = parsedData?.tagged_customers || []
                const formatted_options = options_.map((opt: any) => ({ label: opt, value: opt }))
                setRevMultiCustomer(formatted_options)
                // setLoading(false);
            }
        } catch (error) {
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        }
    };

    const callBPSync = async (parsedData: any, payload: any) => {
        const isTelegence = providerName.toLowerCase().includes("telegence");
        const isWebbing = providerName.toLowerCase().includes("webbing") || providerName.toLowerCase().includes("multi-carrier sim");
        const payload_data = { ...payload }
        try {
            const customerRatePlan_ = (customerRatePlan && customerRatePlan !== 'No options') ? customerRatePlan : null
            let ratePlanNameParts = []
            ratePlanNameParts = (customerRatePlan_ || "").split(" -- ")
            // const customer_rate_plan_ = ratePlanNameParts && ratePlanNameParts.length > 0 ? ratePlanNameParts[0] : null
            if (isTelegence) {
                payload_data["msisdns"] = payload_data?.iccids
                delete payload_data["iccids"]
                delete payload_data["imeids"]
            }
            else {
                delete payload_data["imeids"]
            }
            delete payload_data["changed_data"]
            const url = ENV_ROUTES.SM_BULK_CHANGE;
            const payloadData = {
                ...payload_data,
                path: "/bulk_update_customer_rate_plan_bp",
                request_received_at: getCurrentDateTime(),
                bulk_change_id: parsedData?.bulk_chnage_id_20,
                customer_rate_plan: ratePlanNameParts && ratePlanNameParts.length > 0 ? ratePlanNameParts[0] : null,
                customer_rate_plan_id: ratePlanNameParts && ratePlanNameParts.length > 0 ? ratePlanNameParts[1] : null
                // changed_data: { ...newChangedData }
            }
            const data = { ...payloadData };
            const response = await axios.post(url, { data });
            const responseData = JSON.parse(response.data.body);
            if (responseData.flag === false) {
                console.log("Failure: 2.0 Bulk change update failed.");
            } else {
                console.log("Success: 2.0 Bulk change update successful.");
            }
        }
        catch (error) {
            console.error("Error running DB script:", error);
        } finally {
        }
    }

    const bulkChangeInsert = async (payload: any) => {
        let partner_name = partner
        let db_name_ = selectedDb
        try {
            const url = ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner_name || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_bulk_change_insertion",
                role_name: role,
                module_name: "Bulk Change History",
                service_provider_name: service_provider,
                 ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                request_received_at: getCurrentDateTime(),
                Partner: partner_name,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === false) {
                console.error("Error fetching bulk change data:", parsedData.message ||
                    "An error occurred while fetching bulk change data. Please try again.");
                return false
            } else {
                const statusFlag = parsedData?.bulk_change_data?.status || "";
                const response_data = parsedData?.bulk_change_data?.bulk_change_data || "{}";
                const parsedResp = JSON.parse(response_data)
                console.log("status_flag", statusFlag)
                const status_flag = statusFlag ? (statusFlag).toLowerCase() : ""

                if (status_flag && status_flag === "pending") {
                    return false
                }
                else if (status_flag && status_flag === "success") {
                    call_2_0_submit(parsedResp, payload, true)
                    call_2_0_sync(parsedResp)
                    return true
                }
                else if (status_flag && status_flag === "error") {
                    Modal.error({
                        title: 'Submit Error',
                        content: parsedData.message || 'An error occurred while submitting. Please try again.',
                        centered: true,
                    });
                    return true
                }
                else {
                    return false
                }
            }
        } catch (error) {
            console.error("Error fetching auto refresh data:", error);
            return false
        } finally {
        }
    };
    const bulkChangePolling = async (data: any) => {
        const result = await bulkChangeInsert(data);
        if (!result) {
            setTimeout(() => bulkChangePolling(data), 5000); // Try again after 5 seconds
        } else {
            removeExport("bulkChangeInsert");
            console.log("Auto-refresh complete.");
        }
        // if (window.location.pathname.includes("/sim_management/bulk_change")) {
        //     window.location.reload();
        // }
    };

    const fetchDevices = async (devices_list: any[], deviceKey: string) => {
        try {
            setLoading(true);
            const url =
                ENV_ROUTES.BULKCHANGE_PROCESSOR;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_standard_iccid_msisdn_data",
                role_name: role,
                Partner: partner,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: service_provider,
                ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type,
                [deviceKey]: devices_list || []
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                // setLoading(false);
                Modal.error({
                    title: 'Submit Error',
                    content: parsedData.message || 'An error occurred while submitting data. Please try again.',
                    centered: true,
                });
                return []
            } else {
                const responseKey = deviceKey === "iccids" ? "msisdns" : "iccids"
                const devices = parsedData?.[responseKey] || []
                console.log("devices", devices)
                return devices
                // setLoading(false);
            }
        } catch (error) {
            Modal.error({
                title: 'Submit Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting data. Please try again.',
                centered: true,
            });
            return []
            // setLoading(false);
        }
        finally {
            setLoading(false)
        }
    };

    const getIccidList = async (): Promise<string[]> => {
        // Pick devices based on subscriberNumber or iccids
        const devices_ = subscriberNumber ? subscriberNumber : iccids;

        // Find matching device type from the map
        const matchedDeviceTypeItem = simIdentifierMap.find((item: any) => {
            return (
                item.service_provider === service_provider &&
                item.change_type === change_type
            );
        });
        const matchedDeviceType = matchedDeviceTypeItem?.sim_identifier || ""
        // Decide expected type
        const selectDeviceType = subscriberNumber ? "msisdns" : "iccids";
        // Split devices into a list
        let iccidList = devices_
            .split(/\s*[\n,]\s*/)
            .map((line) => line.trim())
            .filter((line) => line.length > 0);

        // Fetch devices only if types mismatch
        if (matchedDeviceType !== selectDeviceType) {
            iccidList = await fetchDevices(iccidList, selectDeviceType);
        }

        return iccidList;
    };

    const onsubmit = async () => {
        let hasError = false;
        let data
        try {
            let customer_name_
            let selected_customer
            let original_customer


            if (isSubmitScreen) {
                let selected_customers = revMultiCustomer.length > 0 ? revMultiCustomer.map((opt: any) => (opt?.value || "")) : null
                customer_name_ = selected_customers ? selected_customers[0].toLowerCase() : ""
                selected_customer = selected_customers ? selected_customers[0].toLowerCase() : ""
                original_customer = selected_customers ? selected_customers[0] : ""

            }
            else {
                customer_name_ = revCustomer ? revCustomer.toLowerCase() : ""
                selected_customer = revCustomer ? revCustomer.toLowerCase() : ""
                original_customer = revCustomer ? revCustomer : ""
            }
            if (customer_name_.endsWith(" -- bp") || customer_name_.endsWith(" -- revio")) {
                customer_name_ = original_customer.replace(" -- BP", "").replace(" -- RevIO", "");
            }
            setLoading(true);
            // Extract rates from selectedRates and convert to an array
            const rateList = Object.values(selectedRates).map(rate => Number(rate));
            console.log(rateList, "Show the rate lists");
            // Determine which product IDs to send based on whether package or products are selected
            const productList = selectedPackage ? packageProductIds : revIOProduct;
            console.log(productList, "show the product list");
            const selected_devices = subscriberNumber ? subscriberNumber : iccids
            const iccidList = await getIccidList()
            console.log(iccidList, "show the iccid list");
            const url = ENV_ROUTES.SIM_MANAGEMENT;
            data = {
                tenant_name: partner || "default_value",
                path: "/update_bulk_change_data",
                role_name: role,
                username: username,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: service_provider,
                ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type,
                created_by: firstLastName,
                iccids: iccidList,
                billing_platform: selected_customer.toLowerCase().endsWith(" -- bp") ? true : false,
                use_carrier_activation: useCarrierActivation,
                changed_data: {
                    // rev_customer: revCustomer,
                    // create_service_product: ,
                    // rev_io_provider_id: revIOProviderId,
                    // service_type: serviceType,
                    // rev_io_product: revIOProduct,
                    // rev_io_package: revIOPackage,
                    // iccids: ,
                    // customer_pool: ,
                    // effective_date: ,
                    // customer_rate_plan: ,
                    // description: ,
                    // use_carrier_activation: useCarrierActivation,
                    // prorate: ,

                    Number: "",
                    // iccids: iccidList,
                    ICCID: "",
                    CreateRevService: createServiceProduct || false,
                    IntegrationAuthenticationId: "",
                    AddCarrierRatePlan: false,
                    CarrierRatePlan: null,
                    CommPlan: "",
                    UseAgentAccount: false,
                    JasperDeviceID: "",
                    SiteId: null,
                    AddCustomerRatePlan: false,
                    // CustomerRatePlan:customerRatePlan&&customerRatePlan?.value==='No options'?customerRatePlan:null,
                    // CustomerRatePool:customerPool&&customerPool?.value==='No options'?customerPool:null,
                    CustomerRatePlan: customerRatePlan ? customerRatePlan : null, // Ensure this is correct
                    CustomerRatePool: customerPool ? customerPool : null, // Ensure this is correct
                    DeviceId: null,
                    RevCustomerId: customer_name_ || "",
                    ProviderId: revIOProviderId || "",
                    ServiceTypeId: serviceType || "",
                    RevProductId: productList, // Send the appropriate product list
                    RevPackageId: revIOPackage || "",
                    RateList: rateList,
                    Prorate: prorate,
                    useCarrierActivation: useCarrierActivation || false,
                    Description: description,
                    EffectiveDate: effectiveDate,
                    ActivatedDate: effectiveDate,
                    UsagePlanGroupId: null
                },
            };

            // Send request to the first API
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                setLoading(false);
                Modal.error({
                    title: "Submit Error",
                    content:
                        parsedData.message ||
                        "An error occurred while submitting. Please try again.",
                    centered: true,
                });
                return; // Exit if there's an error
            } else {
                if (isSubmitScreen) {
                    callBPSync(parsedData, data)
                }
                const bulkrow_ = parsedData?.bulkchange_id || {};
                const bulkRow: any = { row: bulkrow_ };
                setBulkRow(bulkRow);
                localStorage.setItem('bulk_row', JSON.stringify(bulkRow || "{}"));
                if (bulkRow) {
                    if (!isAllChangeType) {
                        router.push(`/sim_management/bulk_history`);
                    }
                }

                if (service_provider.toLowerCase().includes("kore") && switch_user_2_0 !== "True") {
                    const koreUrl = ENV_ROUTES.SM_BULK_CHANGE;
                    const koreData: any = {
                        tenant_name: partner || "default_value",
                        path: "/update_assign_customer",
                        request_received_at: getCurrentDateTime(),
                        access_token: token,
                        db_name: selectedDb,
                ...metaData,
                        sessionID: sessionId,
                        service_provider: service_provider,
                        ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                        change_type: change_type,
                        created_by: firstLastName,
                        iccids: iccidList,
                        bulk_change_id: parsedData?.bulkchange_id?.id,
                        data: parsedData?.data,
                        customer_rate_plan: customerRatePlan ? customerRatePlan : null, // Ensure this is correct
                        customer_rate_pool: customerPool ? customerPool : null, // Ensure this is correct
                        effective_date: effectiveDate,
                    }

                    const koreResponse = await axios.post(koreUrl, { data: koreData });
                    const koreResponseData = JSON.parse(koreResponse.data.body);

                    if (koreResponseData.flag === false) {
                        console.error("Data Fetch Error: " + koreResponseData.message);
                    } else {
                        console.log("Success: Bulk update successful.");
                    }
                    const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
                    koreData["service_provider_id"] = service_provider_id_
                    callKoreSync(koreData)
                }
                else {
                    // Prepare payload for the new API call
                    // const newApiData = {
                    //   tenant_name: partner || "default_value",
                    //   username: username,
                    //   firstLastName: firstLastName,
                    //   path: "/inventory_iccidds_imeids", // New API path
                    //   service_provider: service_provider,
                    //   role_name: role,
                    //   module_name: "Bulk Change",
                    //   mod_pages: { start: 0, end: 100 },
                    //   access_token: token,
                    //   db_name: selectedDb,
                    //   sessionID: sessionId,
                    //   request_received_at: getCurrentDateTime(),
                    //   Partner: partner
                    // };

                    // // Call the new API to get ICCIDs and IMEIs
                    // const newApiResponse = await axios.post(ENV_ROUTES.SIM_MANAGEMENT, { data: newApiData });
                    // const newApiParsedData = JSON.parse(newApiResponse.data.body); // Parse the new API response

                    // const AlliccidList = newApiParsedData.iccid; // Adjust based on the actual structure of the response
                    // const AllimeiList = newApiParsedData.imei; // Adjust based on the actual structure of the response

                    // // Validate ICCIDs
                    // const iccidMatch = iccidList.every(iccid => AlliccidList.includes(iccid));
                    // if (!iccidMatch) {
                    //   console.log("ICCID do not match.");
                    //   callMismatchICCID(parsedData)
                    //   return; // Exit if ICCIDs do not match
                    // }

                    if (createServiceProduct) {
                        callProcessServiceNumbers(parsedData)
                    }
                    // Proceed to call run_db_script API
                    const isTelegence = providerName.toLowerCase().includes("telegence");
                    const isWebbing = providerName.toLowerCase().includes("webbing") || providerName.toLowerCase().includes("multi-carrier sim");
                    const isWingtel = partner?.toLowerCase() === "wingtel";
                    const isVerizon = (providerName.toLowerCase().includes("verizon") || providerName.toLowerCase().includes("vzn") || providerName.toLowerCase().includes("vzwcr") || providerName.toLowerCase().includes("2215-so01"));
                    const hasModuleStatus = dropdown?.module_status;
                    const isBpCustomer = selected_customer.toLowerCase().endsWith(" -- bp");
                    const isPod19 = providerName.toLowerCase().includes("pod19");
                    const isJasper = providerName.toLowerCase().includes("jasper");
                    const isPondIOT = providerName.toLowerCase().includes("pond");
                    const isKore = providerName.toLowerCase().includes("kore");
                    const isTeal = providerName.toLowerCase().includes("teal")
                    const isRogers = providerName.toLowerCase().includes("rogers")
                    if ((switch_user_2_0 === "True" || isWebbing)) {
                        if(!isAllChangeType){
                            call_2_0_submit(parsedData, data, true);
                            call_2_0_sync(parsedData);
                        }
                        else{
                            const payload_2_0_:any = await call_2_0_submit(parsedData, data, false)
                            const all_2_0_payloads_ = {... all_2_0_payloads,[change_type]:{...payload_2_0_}}
                            set_all_2_0_payloads((prev: any) => ({
                                ...prev,
                                [change_type]: { ...payload_2_0_ }
                            }));
                        }
                        
                    } else {
                        if (hasModuleStatus && !isWingtel) {
                            //   if (isBpCustomer) {
                            //     callSyncLambda();
                            //   } else {
                            //     callRunDbScript(parsedData);
                            //   }
                            // } else {
                            //   callSyncLambda();
                            // }
                            if (!isBpCustomer) {
                                callRunDbScript(parsedData);
                            }
                        }
                    }

                }
            }
        } catch (error) {
            const isTelegence = providerName.toLowerCase().includes("telegence");
            const isWebbing = providerName.toLowerCase().includes("webbing") || providerName.toLowerCase().includes("multi-carrier sim");
            const isVerizon = (providerName.toLowerCase().includes("verizon") || providerName.toLowerCase().includes("vzn") || providerName.toLowerCase().includes("vzwcr") || providerName.toLowerCase().includes("2215-so01"));
            const isPod19 = providerName.toLowerCase().includes("pod19");
            const isJasper = providerName.toLowerCase().includes("jasper");
            const isPondIOT = providerName.toLowerCase().includes("pond");
            const isKore = providerName.toLowerCase().includes("kore");
            const isTeal = providerName.toLowerCase().includes("teal")
            const isRogers = providerName.toLowerCase().includes("rogers")
            if ((switch_user_2_0 === "True" && (isTelegence || isVerizon || isPod19 || isPondIOT || isJasper || isKore || isTeal || isRogers)) || isWebbing) {
                onClose()
                setLoading(false)
                addExport("bulkChangeInsert", "Bulk Change Submission");
                bulkChangePolling(data)
            }
            else {
                Modal.error({
                    title: 'Submit Error',
                    content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting. Please try again.',
                    centered: true,
                });
            }
        } finally {
            setLoading(false);
        }
    };
    const handleICCIDChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        const isTMobile = providerName.toLowerCase().includes("t-mobile")
        const isTeal = providerName.toLowerCase().includes("teal")
        const value = e.target.value; // Get the current value
        const regex = isTMobile ? /^[a-zA-Z0-9\n,]*$/ : /^[0-9\n,]*$/;
        const isValid = regex.test(value);
        if (!isValid) {
            setIccidError(
                isTMobile
                    ? "only letters, numbers, newlines, and commas are allowed."
                    : "Only numbers, newlines, and commas are allowed."
            );
        } else {
            setIccidError(""); // Clear error if valid
        }
        const cleanedValue = value.replace(isTMobile ? /[^a-zA-Z0-9\n,]/g : /[^0-9\n,]/g, "");
        setIccids(cleanedValue);


    };

    const handleMSISDNChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
        const value = e.target.value; // Get the current value
        const isValid = /^[0-9\n,]*$/.test(value); // Check if the value contains only numbers, newlines, or commas

        if (!isValid) {
            setIccidError("Only numbers, newlines, and commas are allowed."); // Set error message
        } else {
            setIccidError(""); // Clear error message if valid
        }

        setSubscriberNumber(value.replace(/[^0-9\n,]/g, '')); // Allow only numbers, newlines, and commas
    };

        const confirmCarrierActivation = () => {
            return new Promise<boolean>((resolve) => {
                Modal.confirm({
                    title: "Warning",
                    content: "Are you sure you want to proceed with Carrier Activation Date",
                    centered: true,
                    onOk: () => resolve(true),
                    onCancel: () => resolve(false),
                });
            });
        };
    

    // Update handleContinue function with improved validation
    const handleContinue = async (mode: string) => {
        console.log("Continue button clicked", mode);
        const newErrors: any = {};

        if(!isAllChangeType){
            if (mode === "submit" && customerRatePlan && !effectiveDate && !useCarrierActivation) {
            Modal.warning({
                title: "Warning",
                content: "Either Carrier Activation or Effective Date is required.",
                centered: true,
            });
            return
        }
        if (useCarrierActivation) {
            const proceed = await confirmCarrierActivation();
            if (!proceed) return; // Stop execution
        }
        }

        if (mode === "submit") {
            if (!isSubmitScreen && !revCustomer) {
                newErrors.revCustomer = "Billing customer is required.";
            }
            if (isSubmitScreen && revMultiCustomer && revMultiCustomer.length > 1) {
                newErrors.revCustomer = "Single Billing customer is allowed.";
            }
            if (isSubmitScreen && revMultiCustomer && revMultiCustomer.length == 0) {
                newErrors.revCustomer = "Billing customer is required.";
            }

            if (createServiceProduct) {
                if (!revIOProviderId) {
                    newErrors.revIOProviderId = "Billing Provider is required.";
                }

                if (!serviceType) {
                    newErrors.serviceType = "Service type is required.";
                }

                // Updated validation logic for product/package selection
                const hasProducts = Array.isArray(revIOProduct) && revIOProduct.length > 0;
                const hasPackage = revIOPackage !== "" && revIOPackage !== undefined;

                if (!hasProducts && !hasPackage) {
                    newErrors.productOrPackage = "Please select either Billing Product or Billing Package";
                    setProductError(true); // Set the product error state to show the error message
                } else {
                    setProductError(false);
                }
            }
            // Check if Customer Rate Plan is selected and validate effective date
            if (customerRatePlan && !useCarrierActivation) {
                if (!effectiveDate) {
                    newErrors.effectiveDate = "Effective date is required when a Customer Rate Plan is selected.";
                }
            }
        }

        if (!subscriberNumber && !iccids) {
            newErrors.devices = "Please fill ICCID field or MSISDN field."
        }
        else {
            const deviceErrors: any = []
            const isTMobile = providerName.toLowerCase().includes("t-mobile")
            const isTeal = providerName.toLowerCase().includes("teal")            
            const selected_devices = subscriberNumber ? subscriberNumber : iccids
            const iccidList = selected_devices
                .split(/\s*[\n,]\s*/)
                .map((line) => line.trim())
                .filter((line) => line.length > 0);
            
            iccidList.forEach((line, index) => {
                const label = subscriberNumber ? "Subscriber Number" : "ICCID";
                const minLength = subscriberNumber ? 10 : 14;
                const maxLength = subscriberNumber ? 18 : isTeal ? 32 : 22;

                if (line.length === 0) {
                    deviceErrors[index] = `${label} must not be empty`;
                } else if (!/^\d+$/.test(line) && !isTMobile) {
                    deviceErrors[index] = `Please enter numbers only for ${label}. Letters or special characters are not allowed`;
                } 
                else if (!/^[a-zA-Z0-9]+$/.test(line) && isTMobile) {
                    deviceErrors[index] = `Please enter letters and numbers only for ${label}.special characters are not allowed`;
                }
                else if (line.length < minLength || line.length > maxLength) {
                    deviceErrors[index] = `${label} must be between ${minLength} and ${maxLength} digits long`;
                }
                if (iccidList.length > bulkChangeLimit) {
                    deviceErrors.push(`This request exceeds the allowed record limit  of ${bulkChangeLimit} and cannot be processed`);
                    console.log("Limit Exceeded");
                }
            });
            if (iccidList.length > bulkChangeLimit) {
                newErrors.devices = `This request exceeds the allowed record limit  of ${bulkChangeLimit} and cannot be processed`;
                console.log("Limit Exceeded");
            }
            if (deviceErrors.length > 0) {
                newErrors.devices = [...new Set(deviceErrors)]
            }
            else {
                delete newErrors?.devices
            }
        }

        if (Object.keys(newErrors).length > 0) {
                console.log("new errors", newErrors)
                setsuccessFullChangeTypes(
                    successFullChangeTypes.filter((c: any) => c !== activeChange)
                );
            if(isAllChangeType){
                if ((revMultiCustomer.length === 0 && !revCustomer && !createServiceProduct && !customerRatePlan && !customerPool &&!effectiveDate) || !saveChanges) {
                    setErrors({});
                    setIsValidated(true)
                    setValidationTrigger();
                    return
                }
                else{
                    setIsValidated(false)
                    setErrors(newErrors);
                    setValidationTrigger();
                    return
                }

            }else{
                console.log("new errors", newErrors)
                setErrors(newErrors);
                return;
            }
            
        }

        if (isSubmitScreen && !isAllChangeType && mode !== "submit") {
            const selected_devices = subscriberNumber ? subscriberNumber : iccids
            const iccidList = await getIccidList()
            fetchTaggedCustomers(iccidList)
        }

        setErrors({});
        if (saveChanges && isAllChangeType) {
            if (mode === "submit" && customerRatePlan && !effectiveDate && !useCarrierActivation) {
                Modal.warning({
                    title: "Warning",
                    content: "Either Carrier Activation or Effective Date is required.",
                    centered: true,
                });
                return
            }
            if (useCarrierActivation) {
                const proceed = await confirmCarrierActivation();
                if (!proceed) return; // Stop execution
            }
            let customer_name_
            let selected_customer
            let original_customer


            if (isSubmitScreen) {
                let selected_customers = revMultiCustomer.length > 0 ? revMultiCustomer.map((opt: any) => (opt?.value || "")) : null
                customer_name_ = selected_customers ? selected_customers[0].toLowerCase() : ""
                selected_customer = selected_customers ? selected_customers[0].toLowerCase() : ""
                original_customer = selected_customers ? selected_customers[0] : ""

            }
            else {
                customer_name_ = revCustomer ? revCustomer.toLowerCase() : ""
                selected_customer = revCustomer ? revCustomer.toLowerCase() : ""
                original_customer = revCustomer ? revCustomer : ""
            }
            if (customer_name_.endsWith(" -- bp") || customer_name_.endsWith(" -- revio")) {
                customer_name_ = original_customer.replace(" -- BP", "").replace(" -- RevIO", "");
            }
            
            const formData_ = {
                customer_rate_plan_name: customerRatePlan ? customerRatePlan : null, // Ensure this is correct
                customer_rate_pool_name: customerPool ? customerPool : null, // Ensure this is correct
                customer_name: customer_name_?.split(" -- ")?.[0] || null,                
                effective_date: effectiveDate,
            }
            console.log("formData_",formData_)
            setAssignCustomerData(formData_)
            setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
        }
        setIsValidated(true)
        setValidationTrigger()
        if(!isAllChangeType){
            if (mode === "submit") {
            const writes_flag = await fetchCarrierWritesFlag()
            if (writes_flag) {
                const modal = Modal.confirm({
                    title: "Carrier API Enabled",
                    content: "Carrier API settings are enabled. Submitting now will trigger the Carrier API directly. Do you want to proceed?",
                    centered: true,
                    okText: "Submit",
                    onOk: () => {
                        // modal.destroy(); // closes the modal
                        // handleCloseModal();

                        onsubmit();
                        submitCarrierStatus(writes_flag);
                    },
                    onCancel: onBack
                });
            }
            else {
                onsubmit();
            }
        }
        else {
            setIsRedirected(true)
        }
        }
        

    };

    const handleCheckboxChange = (e: {
        target: { checked: boolean | ((prevState: boolean) => boolean) };
    }) => {
        setRevIOProviderId(null)
        setServiceType("")
        setSelectedPackage("")
        setSelectedProduct([])
        setRevIOPackage("")
        setRevIOProduct([])
        setDescription("")
        setSelectedRates({})
        if (!activationFlag) {
            setUseCarrierActivation(false)
        }
        if (!revCustomer && e.target.checked && !isSubmitScreen) {
            // setErrors("Please select Billing customer");
            setErrors((prev: any) => ({
                ...prev,
                revCustomer: "Please select Billing Customer"
            }))
        }
        else if (revMultiCustomer.length === 0 && isSubmitScreen && e.target.checked) {
            // setErrors("Please select Billing customer");
            setErrors((prev: any) => ({
                ...prev,
                revCustomer: "Please select Billing Customer"
            }))
        } else {
            setCreateServiceProduct(e.target.checked);
            setProrate(true)
            setErrors("");
            setErrors((prev: any) => ({
                ...prev,
                revCustomer: ""
            }))
        }
    };

    // const returnUpdatedValue = () =>{
    //     let selected_customer =""

    //         if (isSubmitScreen) {
    //             let selected_customers = revMultiCustomer.length > 0 ? revMultiCustomer.map((opt: any) => (opt?.value || "")) : null
    //             selected_customer = selected_customers ? selected_customers.join(", ") :""

    //         }
    //         else {
    //             selected_customer = revCustomer ? revCustomer : ""
    //         }
    //     return (
    //     <Tooltip title={`${selected_customer}`}>
    //         <span>
    //             {selected_customer}
    //             </span>
    //     </Tooltip>)
    // }
    const returnUpdatedValue = () => {
            let selected_customer =""

            if (isSubmitScreen) {
                let selected_customers = revMultiCustomer.length > 0 ? revMultiCustomer.map((opt: any) => (opt?.value || "")) : null
                selected_customer = selected_customers ? selected_customers.join(", ") :""

            }
            else {
                selected_customer = revCustomer ? revCustomer : ""
            }
            return (
                <div className="flex flex-col gap-2">
                    <div className="flex grid grid-cols-2 ">
                        <span className="font-semibold">Customer Name</span>
                        <span>{selected_customer}</span>
                    </div>
                </div>
            )
        }

    useImperativeHandle(ref, () => ({
      runValidation: () => handleContinue("submit") ,
      runSubmit: onsubmit,
      returnUpdate: returnUpdatedValue
    }));

    const modalWidth =
        typeof window !== "undefined" ? (window.innerWidth * 2.5) / 4 : 0;
    const modalHeight =
        typeof window !== "undefined" ? (window.innerHeight * 2.5) / 4 : 0;

    if (loading) {
        return (
            <>
                <div className="flex justify-center items-center h-[400px]">
                    <Spin size="large" />
                </div>
            </>
        );
    }


    const selectStyles = {
        ...DropdownStyles,
        menu: (base: any) => ({
            ...base,
            zIndex: 9999, // Ensure dropdown appears above modal
            position: 'relative'
        }),
        menuPortal: (base: any) => ({
            ...base,
            zIndex: 9999 // Ensure dropdown portal appears above modal
        }),
        container: (base: any) => ({
            ...base,
            zIndex: 1000 // Container z-index
        })
    };

    const getSelectStyles = (theme: string) => {
        let bgColor = 'white';
        let optionBg = '#F9FAFB';
        let selectedOptionBg = '#BFDBFE';
        let textColor = 'black';

        if (theme === 'dark') {
            bgColor = '#2d2f52';
            optionBg = '#031731';
            selectedOptionBg = '#5e5bb3';
            textColor = 'white';
        } else if (theme === 'red') {
            selectedOptionBg = '#FCA5A5';
        } else if (theme === 'green') {
            selectedOptionBg = '#6EE7B7';
        } else if (theme === 'blue') {
            selectedOptionBg = '#BFDBFE';
        }

        return {
            menu: (base: any) => ({
                ...base,
                maxHeight: 400,
                zIndex: 9999,
                backgroundColor: optionBg,
            }),
            menuPortal: (base: any) => ({
                ...base,
                zIndex: 9999,
            }),
            container: (base: any) => ({
                ...base,
                zIndex: 1000,
            }),
            control: (base: any) => ({
                ...base,
                // height: "40px",
                backgroundColor: bgColor,
                color: textColor,
                border: "1px solid #d1d5db",
                fontSize: "16px",
            }),
            singleValue: (provided: any) => ({
                ...provided,
                color: textColor,
            }),
            option: (base: any, state: any) => ({
                ...base,
                whiteSpace: "nowrap",
                textOverflow: "ellipsis",
                padding: "8px 10px",
                fontSize: "16px",
                color: textColor,
                backgroundColor: state.isSelected ? selectedOptionBg : optionBg,
                ":hover": {
                    backgroundColor: selectedOptionBg,
                },
            }),
            input: (base: any) => ({
                ...base,
                color: textColor,
            }),
        };
    };


    const getAvailableOptions = (allOptions: any[], selectedOptions: any[]) => {
        const selectedValues = selectedOptions.map((opt) => JSON.stringify(opt.value));
        return allOptions.filter(
            (opt) => !selectedValues.includes(JSON.stringify(opt.value))
        );
    };
    return (
        <div
            style={{
                maxHeight: modalHeight,
                overflowY: "auto",
                overflowX: "hidden",
            }}>
            {(isSubmitScreen && !isRedirected && !isAllChangeType) ? (
                <>
                    <div className="flex flex-col space-y-4 p-2">
                        <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                            <label className={`${!isAllChangeType?"w-1/4 font-semibold":"field-label"}`}>
                                Devices (Start typing ICCIDs)<span className="text-red-500">*</span>
                            </label>
                            <Input.TextArea
                                value={iccids}
                                onChange={handleICCIDChange}
                                className="!w-3/4 border border-gray-300 rounded-md p-2"
                                rows={4}
                                placeholder="Enter ICCID(s)"
                                disabled={!!subscriberNumber}
                            />
                        </div>
                        <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                            <label className={`${!isAllChangeType?"w-1/4 font-semibold":"field-label"}`}>
                                Devices (Start typing Subscriber Numbers)<span className="text-red-500">*</span>
                            </label>
                            <Input.TextArea
                                value={subscriberNumber}
                                onChange={handleMSISDNChange}
                                className="w-3/4 border border-gray-300 rounded-md p-2"
                                rows={4}
                                placeholder="Enter Subscriber Number(s)"
                                disabled={!!iccids}
                            />
                        </div>
                    </div>

                    {iccidError && (
                        <div className="text-red-500 text-sm">{iccidError}</div>
                    )}
                    {errors.devices && (
                        <div className="text-red-500 text-sm">{errors.devices}</div>
                    )}
                    {!isAllChangeType && (
                        <div className="flex justify-center space-x-4 !mt-[20px]">
                        <button className="cancel-btn" onClick={onBack}>
                            Back
                        </button>
                        <button className="save-btn" onClick={() => { handleContinue("redirect") }}>
                            Continue
                        </button>
                    </div>
                    )}
                    
                </>
            ) : (
                <>
                    <div className="flex justify-end space-x-4 px-2">
                        {(useCarrierActivation && isSubmitScreen) && (
                            <button onClick={handlePreviewOpen} className="save-btn">
                                <EyeIcon className="h-5 w-5 mr-2" />Preview
                            </button>
                        )}
                    </div>
                    {isAllChangeType && (
                        <div className="flex justify-end px-4">
                            <span className="mr-2 font-semibold">Save Changes</span>
                            <Checkbox
                                checked={saveChanges}
                                onChange={(e) => {
                                    if (!e.target.checked) {
                                        setsuccessFullChangeTypes(
                                            successFullChangeTypes.filter((c: any) => c !== activeChange)
                                        );
                                    }
                                    setSaveChanges(e.target.checked)
                                }}
                                className="custom-checkbox"
                            >

                            </Checkbox>
                        </div>
                    )}
                <div className={`${!isAllChangeType?"space-y-2 h-auto m-2":"flex grid grid-cols-2 gap-4 px-2"}`}>

                    {/* <div className="flex justify-end">
        <Button className="save-btn" onClick={handleUploadClick}>
          <ArrowUpTrayIcon className="h-5 w-5 text-black-500 mr-2" />
          <span>Switch to Upload</span>
        </Button>

        <Modal
          title="Upload Files"
          visible={isUploadModalVisible}
          onCancel={handleUploadModalClose}
          footer={null} // No default footer buttons
          centered
          width={370}
        >
          <div className="flex flex-col gap-4">
            <div className="flex gap-4 justify-center p-4">
              <Upload {...uploadProps} className="upload-wrapper">
                <button
                  className="upload-btn disabled:cursor-not-allowed"
                  style={{
                    height: "40px",
                    display: "inline-flex",
                    alignItems: "center",
                  }}
                >
                  <span className="mr-2">
                    <UploadOutlined />
                  </span>
                  Upload
                </button>
              </Upload>
              <button
                onClick={handleDownloadTemplate}
                className="upload-btn disabled:cursor-not-allowed"
                // disabled={!appendChecked && !overwriteChecked}
              >
                <span className="mr-2">
                  <DownloadOutlined />
                </span>
                Download Template
              </button>
            </div>
          </div>
        </Modal>
      </div> */}
                    {isSubmitScreen ? (
                        <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                            <label className={`${!isAllChangeType?"w-1/4 font-semibold":"field-label"}`}>
                                Billing Customer<span className="text-red-500">*</span>
                            </label>
                            <Select
                                options={getAvailableOptions(revMultiCustomersOptions, revMultiCustomer)}
                                value={revMultiCustomer}
                                onChange={(selectedOptions: any) =>
                                    handleRevMultiCustomer(selectedOptions)
                                }
                                className={`${!isAllChangeType?"w-3/4":""}`}
                                styles={getSelectStyles(theme)}
                                isMulti
                                menuPortalTarget={document.body}
                                menuPosition="fixed"
                                menuPlacement="auto"
                            />
                            {(errors.revCustomer && isAllChangeType) && (
                        <span className="text-red-500 text-sm">{errors.revCustomer}</span>
                    )}
                        </div>

                    ) : (
                        <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                            <label className={`${!isAllChangeType?"w-1/4 font-semibold":"field-label"}`}>
                                Billing Customer<span className="text-red-500">*</span>
                            </label>
                            <VirtualizedSelect
                                value={{ label: revCustomer, value: revCustomer }}
                                styles={getSelectStyles(theme)}
                                menuPortalTarget={document.body}
                                menuPosition="fixed"
                                menuPlacement="auto"
                                onChange={handleSelectChange}
                                options={revCustomersOptions.map((option: string) => ({
                                    label: option,
                                    value: option,
                                }))}
                                className={`${!isAllChangeType?"w-3/4":""}`}
                                isMulti={false}
                                placeholder="Please Select Customer"
                                maxHeight={400} // Define the max height for the dropdown
                            />
                            {(errors.revCustomer && isAllChangeType) && (
                        <span className="text-red-500 text-sm">{errors.revCustomer}</span>
                    )}
                        </div>
                    )}

                    {(errors.revCustomer && !isAllChangeType) && (
                        <div className="text-red-500 text-sm">{errors.revCustomer}</div>
                    )}
                    {(dropdown?.module_status && (partner && partner.toLowerCase() !== "wingtel")) &&

                        <div className={`${!isAllChangeType?"flex items-center space-x-4":"mt-4 relative top-[25%]"}`}>
                            <label className={`${!isAllChangeType?"w-1/4 font-semibold":"mr-2"}`}>Create Service/Product</label>
                            <Checkbox
                                checked={createServiceProduct}
                                onChange={handleCheckboxChange}
                                className="w-6 h-6 accent-blue-500"
                            />
                        </div>}

                    {createServiceProduct && (
                        // <div className="space-y-4">
                            <>
                            <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                <label className={`${!isAllChangeType?"w-1/4 font-semibold":"field-label"}`}>
                                    Billing Provider<span className="text-red-500">*</span>
                                </label>
                                <Select
                                    value={
                                        revIOProviderId
                                            ? {
                                                label: revIOProviderOptions.find(
                                                    (option: any) => option.value === revIOProviderId
                                                )?.label,
                                                value: revIOProviderId,
                                            }
                                            : null
                                    }
                                    isClearable
                                    onChange={(selectedOption) => {
                                        handleProviderChange(selectedOption)
                                    }}
                                    styles={getSelectStyles(theme)}
                                    menuPortalTarget={document.body}
                                    menuPosition="fixed"
                                    menuPlacement="auto"
                                    options={
                                        revIOProviderOptions.length > 0
                                            ? revIOProviderOptions
                                            : [{ label: "No options", value: "No options" }]
                                    }
                                    className={`${!isAllChangeType?"w-3/4":""}`}
                                    placeholder="Please Select a Billing Provider"
                                />
                                        {(errors.revIOProviderId && isAllChangeType) && (
                                            <span className="text-red-500 text-sm">{errors.revIOProviderId}</span>
                                        )}
                                    </div>
                                    {(errors.revIOProviderId && !isAllChangeType) && (
                                        <div className="text-red-500 text-sm ml-[25%]">{errors.revIOProviderId}</div>
                                    )}

                            <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                <label className={`${!isAllChangeType?"w-1/4 font-semibold":"field-label"}`}>
                                    Service Type<span className="text-red-500">*</span>
                                </label>
                                <Select
                                    value={serviceType ? { label: serviceType, value: serviceType } : null}
                                    isClearable
                                    onChange={handleselectServiceType}
                                    styles={getSelectStyles(theme)}
                                    menuPortalTarget={document.body}
                                    menuPosition="fixed"
                                    menuPlacement="auto"
                                    options={
                                        serviceTypeOptions.length > 0
                                            ? serviceTypeOptions.map((option: string) => ({
                                                label: option,
                                                value: option,
                                            }))
                                            : [{ label: "No options", value: "No options" }]
                                    }
                                    className={`${!isAllChangeType?"w-3/4":""}`}
                                    placeholder="Please Select a Service Type"
                                />
                                {(errors.serviceType && isAllChangeType) && (
                                <span className="text-red-500 text-sm">{errors.serviceType}</span>
                            )}
                            </div>
                            {(errors.serviceType && !isAllChangeType) && (
                                <div className="text-red-500 text-sm ml-[25%]">{errors.serviceType}</div>
                            )}
                            <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                <label className={`${!isAllChangeType?"w-1/4 font-semibold":"field-label"}`}>
                                    Billing Product<span className="text-red-500">*</span>
                                </label>
                                <div className={`${isAllChangeType?"flex space-x-4":"w-3/4"}`}>
                                <Select
                                    className={`${!isAllChangeType?"w-full":"w-[95%]"}`}
                                    // options={productOptions}
                                    // options={productOptions.sort((a, b) => a.label.localeCompare(b.label))}
                                    options={[
                                        ...new Map(productOptions.map((item) => [item.label, item])).values(),
                                    ].sort((a, b) => a.label.localeCompare(b.label))}
                                    value={selectedProduct}
                                    onChange={handleProductChange}
                                    isDisabled={!!selectedPackage}
                                    isMulti
                                    styles={DropdownStyles}
                                    // menuPortalTarget={document.body}
                                    // menuPosition="fixed"
                                    // menuPlacement="auto"
                                    isClearable
                                />
                                {isAllChangeType && (
                                    <span className="font-semibold">
                                        OR
                                    </span>
                                )}
                                </div>
                                {((errors.productOrPackage || productError) && isAllChangeType) && (
                                <span className="text-red-500 text-sm">{errors.productOrPackage}</span>
                            )}
                            
                            </div>
                            {!isAllChangeType && (
                                 <div className="flex items-center space-x-4">
                                <span className="w-1/4 font-semibold">
                                    OR
                                </span>
                            </div>
                            )}

                           

                            <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                <label className={`${!isAllChangeType?"w-1/4 font-semibold":"field-label"}`}>
                                    Billing Package<span className="text-red-500">*</span>
                                </label>
                                <Select
                                    className={`${!isAllChangeType?"w-3/4":""}`}
                                    // options={packageOptions}
                                    // options={packageOptions.sort((a, b) => a.label.localeCompare(b.label))}
                                    options={[
                                        ...new Map(packageOptions.map((item) => [item.label, item])).values(),
                                    ].sort((a, b) => a.label.localeCompare(b.label))}
                                    value={selectedPackage}
                                    onChange={handlePackageChange}
                                    isDisabled={selectedProduct.length > 0}
                                    isClearable
                                    styles={DropdownStyles}
                                // menuPortalTarget={document.body}
                                // menuPosition="fixed"
                                // menuPlacement="auto"
                                />
                            </div>



                            {((errors.productOrPackage || productError) && !isAllChangeType) && (
                                <div className="text-red-500 text-sm ml-[25%]">{errors.productOrPackage}</div>
                            )}
                            <div>
                                <label className={`${!isAllChangeType?"w-1/4 font-semibold":"field-label"}`}>
                                    Rates
                                </label>
                                {Object.keys(selectedRates).length > 0 && (
                                    <div className="grid grid-cols-2 gap-4">
                                        {Object.entries(selectedRates).map(([description, rate], index) => (
                                            <React.Fragment key={index}>
                                                <div className="text-left pr-4">{description}:</div>
                                                <div>
                                                    <input
                                                        type="number"
                                                        value={rate === "" ? "" : rate}
                                                        min="0"
                                                        step="0.01"
                                                        className="w-[100px] border border-gray-400 rounded pl-2"
                                                        onChange={(e) => {
                                                            const newRate = e.target.value;
                                                            setSelectedRates((prevRates) => ({
                                                                ...prevRates,
                                                                [description]: newRate,
                                                            }));
                                                        }}
                                                    />
                                                </div>
                                            </React.Fragment>
                                        ))}
                                    </div>
                                )}
                            </div>



                            <div className={`${!isAllChangeType?"flex items-center space-x-4":"relative top-[25%]"}`}>
                                <label className={`${!isAllChangeType?"w-1/4 font-semibold":"mr-2"}`}>Prorate</label>

                                <Checkbox
                                    // defaultChecked={true}
                                    checked={prorate}
                                    onChange={(e) => setProrate(e.target.checked)}
                                ></Checkbox>
                            </div>

                            {createServiceProduct && (
                                // <div className="space-y-4 mt-4">
                                <>
                                    {(prorate || customerRatePlan || (!prorate && !createServiceProduct)) && (
                                                <>
                                                    <div className={`${!isAllChangeType ? "flex items-center space-x-4" : ""}`}>

                                                        <label htmlFor="effectiveDateDrp" className={`${!isAllChangeType ? "w-1/4 font-semibold" : "field-label"}`}>Effective Date</label>
                                                        <Select
                                                            id="effectiveDateDrp"
                                                            placeholder="Select..."
                                                            options={effectiveDateOptions}
                                                            value={{ label: selectedDateOption, value: selectedDateOption }}
                                                            onChange={handleSelectEffectiveDate}
                                                            isClearable
                                                            styles={getSelectStyles(theme)}
                                                            menuPortalTarget={document.body}
                                                            menuPosition="fixed"
                                                            menuPlacement="auto"
                                                            isDisabled={useCarrierActivation}
                                                            className={`${!isAllChangeType?"w-3/4":""}`}

                                                        />
                                                    </div>
                                                    {isCustomDateChecked && (
                                                        <div className={`${!isAllChangeType ? "flex items-center space-x-4" : ""}`}>
                                                            <label className={`${!isAllChangeType ? "w-1/4 font-semibold" : "field-label"}`}>
                                                                Effective Date
                                                                {/* <span className="text-red-500">*</span> */}
                                                            </label>
                                                            <DatePicker
                                                                value={effectiveDate}
                                                                onChange={(date: any) => {
                                                                    if (date) {
                                                                        const safeDate = date.hour(12).minute(0).second(0).millisecond(0);
                                                                        console.log(safeDate)
                                                                        setEffectiveDate(safeDate);
                                                                    } else {
                                                                        setEffectiveDate(null);
                                                                    }
                                                                }}
                                                                // className={`${!isAllChangeType?"w-3/4":""}`}
                                                                className={`${!isAllChangeType ? "w-3/4" : ""} ${(useCarrierActivation && !isAllChangeType) ? 'non-editable-input' : 'input'}`}
                                                                format="MM/DD/YYYY"
                                                                placeholder="MM/DD/YYYY"
                                                                // disabledDate={(date) => date.isBefore(dayjs(), "day")} // Disable previous dates
                                                                disabled={useCarrierActivation}
                                                            />
                                                        </div>
                                                    )}
                                                </>
                                            
                                        // </div>
                                    )}
                                    {errors.effectiveDate && (
                                        <div className="text-red-500 text-sm">{errors.effectiveDate}</div>
                                    )}
                                </>
                                // </div>
                            )}

                            {(prorate) && (role?.toLowerCase() === "super admin" || role?.toLowerCase() === "partner admin") && (
                                <div className="flex items-center space-x-4 mt-4">
                                    <label className={`${!isAllChangeType?"w-1/4 font-semibold":"field-label"}`}>
                                        Use Carrier Activation?
                                    </label>

                                    <Checkbox
                                        checked={useCarrierActivation}
                                        onChange={(e) => setUseCarrierActivation(e.target.checked)}
                                    ></Checkbox>
                                </div>
                            )}
                            <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                <label className={`${!isAllChangeType?"w-1/4 font-semibold":"field-label"}`}>Product Description</label>
                                <textarea
                                    rows={2}
                                    value={description}
                                    onChange={(e) => setDescription(e.target.value)}
                                    className={`${!isAllChangeType?"w-3/4":"w-full"} border border-gray-300 rounded-md p-2`}
                                    placeholder="Enter Description"
                                    disabled={!createServiceProduct} // Disable if createServiceProduct is false
                                />
                            </div>
                            </>
                        
                        // </div>

                    )}

                    <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                        <label className={`${!isAllChangeType?"w-1/4 font-semibold":"field-label"}`}>Customer Rate Plan</label>
                        <Select
                            value={
                                customerRatePlan
                                    ? { label: customerRatePlan, value: customerRatePlan }
                                    : null
                            }
                            isClearable
                            onChange={handleCustomerRatePlanChange}
                            styles={getSelectStyles(theme)}
                            menuPortalTarget={document.body}
                            menuPosition="fixed"
                            menuPlacement="auto"
                            options={
                                customerRatePlansOptions.length > 0
                                    ? customerRatePlansOptions.map((option: string) => ({
                                        label: option,
                                        value: option,
                                    }))
                                    : [{ label: "No options", value: "No options" }]
                            }
                            className={`${!isAllChangeType?"w-3/4":""}`}
                            placeholder="Select a Rate Plan"
                        />
                    </div>

                    {!createServiceProduct && (
                        <div className={`${!isAllChangeType?"space-y-4 mt-4":""}`}>
                            {(prorate || customerRatePlan || (!prorate && !createServiceProduct)) && (
                               <>
                                                    <div className={`${!isAllChangeType ? "flex items-center space-x-4" : ""}`}>

                                                        <label htmlFor="effectiveDateDrp" className={`${!isAllChangeType ? "w-1/4 font-semibold" : "field-label"}`}>Effective Date</label>
                                                        <Select
                                                            id="effectiveDateDrp"
                                                            placeholder="Select..."
                                                            options={effectiveDateOptions}
                                                            value={{ label: selectedDateOption, value: selectedDateOption }}
                                                            onChange={handleSelectEffectiveDate}
                                                            className={`${!isAllChangeType?"w-3/4":""}`}
                                                            isClearable
                                                            styles={getSelectStyles(theme)}
                                                            menuPortalTarget={document.body}
                                                            menuPosition="fixed"
                                                            menuPlacement="auto"
                                                            isDisabled={useCarrierActivation}
                                                        />
                                                    </div>
                                                    {isCustomDateChecked && (
                                                        <div className={`${!isAllChangeType ? "flex items-center space-x-4" : ""}`}>
                                                            <label className={`${!isAllChangeType ? "w-1/4 font-semibold" : "field-label"}`}>
                                                                Effective Date
                                                                {/* <span className="text-red-500">*</span> */}
                                                            </label>
                                                            <DatePicker
                                                                value={effectiveDate}
                                                                onChange={(date: any) => {
                                                                    if (date) {
                                                                        const safeDate = date.hour(12).minute(0).second(0).millisecond(0);
                                                                        console.log(safeDate)
                                                                        setEffectiveDate(safeDate);
                                                                    } else {
                                                                        setEffectiveDate(null);
                                                                    }
                                                                }}
                                                                // className={`${!isAllChangeType?"w-3/4":""}`}
                                                                className={`${!isAllChangeType ? "w-3/4" : ""} ${(useCarrierActivation && !isAllChangeType) ? 'non-editable-input' : 'input'}`}
                                                                format="MM/DD/YYYY"
                                                                placeholder="MM/DD/YYYY"
                                                                // disabledDate={(date) => date.isBefore(dayjs(), "day")} // Disable previous dates
                                                                disabled={useCarrierActivation}
                                                            />
                                                        </div>
                                                    )}
                                                </>
                            )}
                            {errors.effectiveDate && (
                                <div className="text-red-500 text-sm">{errors.effectiveDate}</div>
                            )}
                            {activationFlag && (role?.toLowerCase() === "super admin" || role?.toLowerCase() === "partner admin") && (
                                <div className="flex items-center space-x-4 mt-4">
                                    <label className={`${!isAllChangeType?"w-1/4 font-semibold":"field-label"}`}>
                                        Use Carrier Activation?
                                    </label>

                                    <Checkbox
                                        checked={useCarrierActivation}
                                        onChange={(e) => setUseCarrierActivation(e.target.checked)}
                                    ></Checkbox>
                                </div>
                            )}
                        </div>
                    )}

                    <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                        <label className={`${!isAllChangeType?"w-1/4 font-semibold":"field-label"}`}>Customer Pool</label>
                        <Select

                            value={
                                customerPool
                                    ? { label: customerPool, value: customerPool }
                                    : null
                            }
                            onChange={handleCustomerRatePoolChange}
                            styles={getSelectStyles(theme)}
                            menuPortalTarget={document.body}
                            menuPosition="fixed"
                            menuPlacement="auto"
                            options={
                                customerRatePoolOptions.length > 0
                                    ? customerRatePoolOptions.map((option: string) => ({
                                        label: option,
                                        value: option,
                                    }))
                                    : [{ label: "No options", value: "No options" }]
                            }
                            className={`${!isAllChangeType?"w-3/4":""}`}
                            placeholder="Select a Pool"
                            isClearable
                        />
                    </div>

                    {(!isSubmitScreen && !isAllChangeType) && (
                        <>
                            <div className="flex flex-col space-y-4">
                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label className={`${!isAllChangeType?"w-1/4 font-semibold":"field-label"}`}>
                                        Devices (Start typing ICCIDs)<span className="text-red-500">*</span>
                                    </label>
                                    <Input.TextArea
                                        value={iccids}
                                        onChange={handleICCIDChange}
                                        className="w-3/4 border border-gray-300 rounded-md p-2"
                                        rows={4}
                                        placeholder="Enter ICCID(s)"
                                        disabled={!!subscriberNumber}
                                    />
                                </div>
                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label className={`${!isAllChangeType?"w-1/4 font-semibold":"field-label"}`}>
                                        Devices (Start typing Subscriber Numbers)<span className="text-red-500">*</span>
                                    </label>
                                    <Input.TextArea
                                        value={subscriberNumber}
                                        onChange={handleMSISDNChange}
                                        className="w-3/4 border border-gray-300 rounded-md p-2"
                                        rows={4}
                                        placeholder="Enter Subscriber Number(s)"
                                        disabled={!!iccids}
                                    />
                                </div>
                            </div>

                            {iccidError && (
                                <div className="text-red-500 text-sm">{iccidError}</div>
                            )}
                            {errors.devices && (
                                <div className="text-red-500 text-sm">{errors.devices}</div>
                            )}
                        </>
                    )}
                    {!isAllChangeType && (
                        <div className="flex justify-center space-x-4 !mt-[20px]">
                        <button className="cancel-btn" onClick={onBack}>
                            Cancel
                        </button>
                        <button className="save-btn" onClick={() => { handleContinue("submit") }}>
                            Submit
                        </button>
                    </div>
                    )}
                    
                
                </div>
                </>
            )}
            <PreviewModal
                service_provider={service_provider}
                change_type={change_type}
                getIccids={getIccidList}
                openPreviewModal={openPreviewModal}
                setPreviewModal={setPreviewModal}
            />
        </div>
    );
}
)

export default AssignCustomerContent;
