/* eslint-disable react/jsx-key */
"use client";

import { FC, useState, useEffect, forwardRef, useImperativeHandle } from "react";
import { Input, Button, Modal, Spin } from "antd";
import { MinusCircleOutlined } from "@ant-design/icons";
import { ArrowLeftIcon, ArrowRightIcon } from "@heroicons/react/24/outline";
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { useRouter } from 'next/navigation';
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { Checkbox } from "antd"; // Import Checkbox from Ant Design
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { useAllChangeTypesStore } from "@/app/stores/allChangeTypesStore";
import { PerformanceLogStore } from "@/app/stores/performance_matrix_store";

interface ArchiveSummaryContentProps {
    onContinue: (iccids: string[]) => void;
    onBack: () => void;
    iccids: string[];
    service_provider: any;
    change_type: any
    onCancel: () => void;
}

export interface ArchiveSummaryContentRef {
  runSubmit: () => Promise<void> | void;
}

const ArchiveSummaryContent = forwardRef<ArchiveSummaryContentRef, ArchiveSummaryContentProps>(({ onContinue, onBack, iccids, service_provider, change_type, onCancel }, ref) => {
    const [bulkError, setBulkError] = useState<string | null>(null);
    const [showSummary, setShowSummary] = useState(false);
    const [previousContent, setPreviousContent] = useState<string[]>([]);
    const [loading, setLoading] = useState(false);
    const [isChecked, setIsChecked] = useState(false); // State for checkbox
    const { username, role, partner, token, selectedDb, firstLastName, sessionId, modulesVersionMap, metaData } = useAuth();
    const router = useRouter();
    const { setRowId, setBulkRow } = useFeatureStore();
    const initial_version_flag = modulesVersionMap?.["Sim Management-Bulk Change"] || false
    const isVersionEnabled = localStorage.getItem("switch_user_2_0_bulk_change") === "True";
    const switch_user_2_0 = isVersionEnabled && initial_version_flag ? "True" : "False"
    const { addExport, removeExport, exports } = exportLoadingStore();
    const { isAllChangeType,all_2_0_payloads, set_all_2_0_payloads } = useAllChangeTypesStore();
    const { getTargetTenantProvider, IsTargetTenantProvider } = PerformanceLogStore();
    const is_parent_provider_exists = IsTargetTenantProvider(service_provider)
    const providerName = getTargetTenantProvider(service_provider).toLowerCase() || service_provider;
    
    const handleBackClick = () => {
        setShowSummary(false);
        setPreviousContent(iccids);
        onBack();
    };



    // const onsubmit = async () => {
    //     try {
    //         setLoading(true);
    //         const url =ENV_ROUTES.SIM_MANAGEMENT
    //         const data = {
    //             tenant_name: partner || "default_value",
    //             path: "/update_bulk_change_data",
    //             request_received_at: getCurrentDateTime(),
    //             access_token: token,
    //             db_name:selectedDb,
    //             sessionID: sessionId,
    //             service_provider: service_provider,
    //             change_type: change_type,
    //             created_by: firstLastName,
    //             iccids: iccids,
    //             changed_data: {
    //                 // ProcessChanges:false,
    //                 OverrideValidation:false,
    //                 Devices:iccids
    //             }
    //         };

    //         const response = await axios.post(url, { data });
    //         const parsedData = JSON.parse(response.data.body);
    //         if (parsedData.flag === false) {
    //             setLoading(false);
    //             Modal.error({
    //                 title: 'Submit Error',
    //                 content: parsedData.message || 'An error occurred while submitting. Please try again.',
    //                 centered: true,
    //                 onOk: () => {
    //                     onCancel();
    //                 }
    //             });
    //         } else {
    //             const bulkrow_ = parsedData?.bulkchange_id || {}
    //             const bulkRow:any={row:bulkrow_}
    //             setBulkRow(bulkRow)
    //             localStorage.setItem('bulk_row',JSON.stringify(bulkRow || "{}"));
    //             setLoading(false);
    //             if(bulkRow){
    //                 router.push(`/sim_management/bulk_history`);
    //             }
    //             // onCancel()
    //             const AlliccidList = parsedData.iccid;
    //             const AllimeiList = parsedData.imei;
    //             const iccidMatch = iccids.every(iccid => AlliccidList.includes(iccid));
    //             if (!iccidMatch ) {

    //               console.log("ICCID  do not match.");

    //             } else {
    //             try {
    //                 const url = ENV_ROUTES.SIM_MANAGEMENT
    //                 const data = {
    //                   tenant_name: partner || "default_value",
    //                   username: username,
    //                   firstLastName:firstLastName,
    //                   path: "/run_db_script",
    //                   role_name: role,
    //                   module_name: "Bulk Change",
    //                   mod_pages: {
    //                     start: 0,
    //                     end: 100,
    //                   },
    //                   access_token: token,
    //                   db_name: selectedDb,
    //                   sessionID: sessionId,
    //                   request_received_at: getCurrentDateTime(),
    //                   Partner: partner,
    //                   bulkchange_id:parsedData?.bulkchange_id?.id,
    //                   data:parsedData?.data,
    //                   bulk_chnage_id_20:parsedData?.bulk_chnage_id_20

    //                 };

    //                 const response = await axios.post(url, { data });
    //                 const responseData = JSON.parse(response.data.body);

    //                 if (responseData.flag === false) {
    //                 //   Modal.error({
    //                 //     title: "Data Fetch Error",
    //                 //     content:
    //                 //     responseData.message ||
    //                 //       "An error occurred while fetching updating. Please try again.",
    //                 //     centered: true,
    //                 //   });
    //                 } else {
    //        console.log("success")
    //                 }
    //               } catch (error) {
    //                 console.error("Error fetching data:", error);
    //                 // Modal.error({
    //                 //   title: "Data Fetch Error",
    //                 //   content:
    //                 //     error instanceof Error
    //                 //       ? error.message
    //                 //       : "An unexpected error occurred while updating. Please try again.",
    //                 //   centered: true,
    //                 // });
    //               } finally {
    //               }
    //             }
    //         }
    //     } catch (error) {
    //         Modal.error({
    //             title: 'Submit Error',
    //             content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting. Please try again.',
    //             centered: true,
    //         });
    //     }
    // };

    const callKoreSync = async (data: any) => {
        const koreUrl = ENV_ROUTES.SM_BULK_CHANGE;
        let koreData = { ...data }
        koreData["path"] = "/start_sync"

        const koreResponse = await axios.post(koreUrl, { data: koreData });
        const koreResponseData = JSON.parse(koreResponse.data.body);

        if (koreResponseData.flag === false) {
            console.error("Data Fetch Error: " + koreResponseData.message);
        } else {
            console.log("Success: Bulk update successful.");
        }

    }

    const callMismatchICCID = async (parsedData: any) => {
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/bulk_change_validation_update",
            role_name: role,
            module_name: "Bulk Change",
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            bulkchange_id: parsedData?.bulkchange_id?.id,
            bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
        };

        const response = await axios.post(url, { data });
        const parsedResponse = JSON.parse(response.data.body);

        if (parsedResponse.flag === false) {
            console.error("Data Fetch Error mismatch ICCID: " + parsedResponse.message);
        } else {
            console.log("Success: Bulk update successful.");
        }
    }

    const callRunDbScript = async (parsedData: any) => {
        try {
            const runDbScriptUrl = ENV_ROUTES.SIM_MANAGEMENT;
            const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
            const runDbScriptData = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/run_db_script",
                role_name: role,
                module_name: "Bulk Change",
                mod_pages: {
                    start: 0,
                    end: 100,
                },
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                service_provider_id: service_provider_id_,
                bulkchange_id: parsedData?.bulkchange_id?.id,
                data: parsedData?.data,
                bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
            };

            const runDbScriptResponse = await axios.post(runDbScriptUrl, { data: runDbScriptData });
            const runDbScriptResponseData = JSON.parse(runDbScriptResponse.data.body);

            if (runDbScriptResponseData.flag === false) {
                console.error("Data Fetch Error: " + runDbScriptResponseData.message);
            } else {
                console.log("Success: Bulk update successful.");
            }
        }
        catch (error) {
            console.error("Error running DB script:", error);
        } finally {
            setLoading(false);
        }
    }

    const call_2_0_sync = async (parsedData: any) => {
        try {
            const runDbScriptUrl = ENV_ROUTES.SIM_MANAGEMENT;
            const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
            const runDbScriptData = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/update_bulk_change_tables_10",
                role_name: role,
                module_name: "Bulk Change",
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                // service_provider_id: service_provider_id_,
                // bulkchange_id: parsedData?.bulkchange_id?.id,
                // data: parsedData?.data,
                data: {
                    bulk_change_id: parsedData?.bulk_chnage_id_20,
                },
                is_update: false,
                // bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
            };

            const runDbScriptResponse = await axios.post(runDbScriptUrl, { data: runDbScriptData });
            const runDbScriptResponseData = JSON.parse(runDbScriptResponse.data.body);

            if (runDbScriptResponseData.flag === false) {
                console.error("Data Fetch Error: " + runDbScriptResponseData.message);
            } else {
                console.log("Success: Bulk update successful.");
            }
        }
        catch (error) {
            console.error("Error running DB script:", error);
        } finally {
            setLoading(false);
        }
    }
    const call_2_0_submit = async (parsedData: any, payload: any,isRouteCall:boolean) => {
        try {
            const isTelegence = providerName.toLowerCase().includes("telegence");
            if (isTelegence) {
                payload["msisdns"] = payload?.iccids
                delete payload["iccids"]
                delete payload["imeids"]
            }
            const url = ENV_ROUTES.BULKCHANGE_PROCESSOR;
            const payloadData = {
                ...payload,
                path: "/bulk_change_processor",
                request_received_at: getCurrentDateTime(),
                bulk_change_id: parsedData?.bulk_chnage_id_20,
            }
            const data = { ...payloadData };
            if(!isRouteCall){
                return data
            }
            const response = await axios.post(url, { data });
            const responseData = JSON.parse(response.data.body);
            if (responseData.flag === false) {
                console.log("Failure: 2.0 Bulk change update failed.");
            } else {
                console.log("Success: 2.0 Bulk change update successful.");
            }
        }
        catch (error) {
            console.error("Error running DB script:", error);
        } finally {
            setLoading(false);
        }
    }
    const fetchCarrierWritesFlag = async () => {
        let parsedData: any
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
            tenant_name: partner || "default_value",
            username,
            path: "/get_writes_enable_for_service_provider",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "Inventory",
            service_provider: service_provider || "",
             ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
            ...metaData,
            sessionID: sessionId,
            environment: "BETA",
            change_type: change_type,
        };

        try {
            setLoading(true);
            const response = await axios.post(url, { data });
            parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === true) {
                const write_is_enabled = parsedData?.write_is_enabled || false;
                // setWritesFlag(write_is_enabled);
                return write_is_enabled;
            }
        } catch (error) {
            console.error("Error fetching data:", error);
            return false; // fallback in case of error
        } finally {
            setLoading(false);
        }
    };
    const submitCarrierStatus = async (write_is_enabled:boolean) => {
        let parsedData: any
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
            tenant_name: partner || "default_value",
            username,
            path: "/insert_carrier_status_validation_audit",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "Inventory",
            service_provider: service_provider || "",
             ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            environment: "BETA",
            msisdn: [],
            iccid: iccids,
            change_type: change_type,
            write_is_enabled:write_is_enabled,
        };

        try {
            // setLoading(true);
            const response = await axios.post(url, { data });
            parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === true) {

            }
        } catch (error) {
            console.error("Error fetching data:", error);
        } finally {
            // setLoading(false);
        }
    };

    const bulkChangeInsert = async (payload: any) => {
        let partner_name = partner
        let db_name_ = selectedDb
        try {
            const url = ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner_name || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_bulk_change_insertion",
                role_name: role,
                module_name: "Bulk Change History",
                service_provider_name: service_provider,
                 ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                request_received_at: getCurrentDateTime(),
                Partner: partner_name,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === false) {
                console.error("Error fetching bulk change data:", parsedData.message ||
                    "An error occurred while fetching bulk change data. Please try again.");
                return false
            } else {
                const statusFlag = parsedData?.bulk_change_data?.status || "";
                const response_data = parsedData?.bulk_change_data?.bulk_change_data || "{}";
                const parsedResp = JSON.parse(response_data)
                console.log("status_flag", statusFlag)
                const status_flag = statusFlag ? (statusFlag).toLowerCase() : ""

                if (status_flag && status_flag === "pending") {
                    return false
                }
                else if (status_flag && status_flag === "success") {
                    call_2_0_submit(parsedResp, payload,true);
                    call_2_0_sync(parsedResp)
                    return true
                }
                else if (status_flag && status_flag === "error") {
                    Modal.error({
                        title: 'Submit Error',
                        content: parsedData.message || 'An error occurred while submitting. Please try again.',
                        centered: true,
                    });
                    return true
                }
                else {
                    return false
                }
            }
        } catch (error) {
            console.error("Error fetching auto refresh data:", error);
            return false
        } finally {
        }
    };
    const bulkChangePolling = async (data: any) => {
        const result = await bulkChangeInsert(data);
        if (!result) {
            setTimeout(() => bulkChangePolling(data), 5000); // Try again after 5 seconds
        } else {
            removeExport("bulkChangeInsert");
            console.log("Auto-refresh complete.");
        }
        // if (window.location.pathname.includes("/sim_management/bulk_change")) {
        //     window.location.reload();
        // }
    };

    const onsubmit = async () => {
        let data
        try {
            setLoading(true);
            const url = ENV_ROUTES.SIM_MANAGEMENT;
            data = {
                tenant_name: partner || "default_value",
                path: "/update_bulk_change_data",
                role_name: role,
                username: username,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: service_provider,
                ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type,
                created_by: firstLastName,
                iccids: iccids,
                changed_data: {
                    // ProcessChanges: false,
                    OverrideValidation: false,
                    Devices: iccids
                }
            };

            // Send request to the first API
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                setLoading(false);
                Modal.error({
                    title: 'Submit Error',
                    content: parsedData.message || 'An error occurred while submitting. Please try again.',
                    centered: true,
                    onOk: () => {
                        onCancel();
                    }
                });
                return; // Exit if there's an error
            } else {
                const bulkrow_ = parsedData?.bulkchange_id || {};
                const bulkRow: any = { row: bulkrow_ };
                setBulkRow(bulkRow);
                localStorage.setItem('bulk_row', JSON.stringify(bulkRow || "{}"));
                setLoading(false);
                if (bulkRow) {
                    if (!isAllChangeType) {
                        router.push(`/sim_management/bulk_history`);
                    }
                }
                if (service_provider.toLowerCase().includes("kore") && switch_user_2_0 !== "True") {
                    const koreUrl = ENV_ROUTES.SM_BULK_CHANGE;
                    const koreData: any = {
                        tenant_name: partner || "default_value",
                        path: "/update_archive_status",
                        request_received_at: getCurrentDateTime(),
                        access_token: token,
                        db_name: selectedDb,
                ...metaData,
                        sessionID: sessionId,
                        service_provider: service_provider,
                         ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                        change_type: change_type,
                        bulk_change_id: parsedData?.bulkchange_id?.id,
                        data: parsedData?.data,
                        created_by: firstLastName,
                        iccids: iccids,
                        changed_data: {
                            // ProcessChanges: false,
                            OverrideValidation: false,
                            Devices: iccids
                        }
                    };

                    const koreResponse = await axios.post(koreUrl, { data: koreData });
                    const koreResponseData = JSON.parse(koreResponse.data.body);

                    if (koreResponseData.flag === false) {
                        console.error("Data Fetch Error: " + koreResponseData.message);
                    } else {
                        console.log("Success: Bulk update successful.");
                    }
                    const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
                    koreData["service_provider_id"] = service_provider_id_
                    callKoreSync(koreData)

                }
                else {

                    // Prepare payload for the new API call
                    // const newApiData = {
                    //     tenant_name: partner || "default_value",
                    //     username: username,
                    //     firstLastName: firstLastName,
                    //     path: "/inventory_iccidds_imeids", // New API path
                    //     service_provider: service_provider,
                    //     role_name: role,
                    //     module_name: "Bulk Change",
                    //     mod_pages: { start: 0, end: 100 },
                    //     access_token: token,
                    //     db_name: selectedDb,
                    //     sessionID: sessionId,
                    //     request_received_at: getCurrentDateTime(),
                    //     Partner: partner
                    // };

                    // // Call the new API to get ICCIDs and IMEIs
                    // const newApiResponse = await axios.post(ENV_ROUTES.SIM_MANAGEMENT, { data: newApiData });
                    // const newApiParsedData = JSON.parse(newApiResponse.data.body); // Parse the new API response

                    // const AlliccidList = newApiParsedData.iccid; // Adjust based on the actual structure of the response
                    // const AllimeiList = newApiParsedData.imei; // Adjust based on the actual structure of the response

                    // // Validate ICCIDs
                    // const iccidMatch = iccids.every(iccid => AlliccidList.includes(iccid));
                    // if (!iccidMatch) {
                    //     console.log("ICCID do not match.");
                    //     callMismatchICCID(parsedData)
                    //     return; // Exit if ICCIDs do not match
                    // }
                    // Proceed to call run_db_script API
                    const isTelegence = providerName.toLowerCase().includes("telegence");
                    const isVerizon = (providerName.toLowerCase().includes("verizon") || service_provider.toLowerCase().includes("vzn") || service_provider.toLowerCase().includes("vzwcr") || service_provider.toLowerCase().includes("2215-so01"));
                    const isPod19 = providerName.toLowerCase().includes("pod19");
                    const isJasper = providerName.toLowerCase().includes("jasper");
                    const isKore = providerName.toLowerCase().includes("kore");
                    const isRogers = providerName.toLowerCase().includes("rogers");
                    
                    if (switch_user_2_0 === "True" && (isTelegence || isVerizon || isPod19 || isJasper || isKore || isRogers)) {
                         if(!isAllChangeType){
                            call_2_0_submit(parsedData, data, true);
                            call_2_0_sync(parsedData);
                        }
                        else{
                            const payload_2_0_:any = await call_2_0_submit(parsedData, data, false)
                            set_all_2_0_payloads((prev: any) => ({
                                ...prev,
                                [change_type]: { ...payload_2_0_ }
                            }));                        }
                    }
                    else {
                        callRunDbScript(parsedData)
                    }

                }
            }
        } catch (error) {
            const isTelegence = providerName.toLowerCase().includes("telegence");
            const isVerizon = (providerName.toLowerCase().includes("verizon") || providerName.toLowerCase().includes("vzn") || providerName.toLowerCase().includes("vzwcr") || providerName.toLowerCase().includes("2215-so01"));
            const isPod19 = providerName.toLowerCase().includes("pod19");
            const isJasper = providerName.toLowerCase().includes("jasper");
            const isKore = providerName.toLowerCase().includes("kore");
            const isRogers = providerName.toLowerCase().includes("rogers");
            if (switch_user_2_0 === "True" && (isTelegence || isVerizon || isPod19 || isJasper || isKore || isRogers)) {
                onCancel()
                setLoading(false)
                addExport("bulkChangeInsert", "Bulk Change Submission");
                bulkChangePolling(data)
            }
            else {
                Modal.error({
                    title: 'Submit Error',
                    content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting. Please try again.',
                    centered: true,
                });
            }
        } finally {
            setLoading(false);
        }
    };

    const handleSubmit = async () => {
        const writes_flag = await fetchCarrierWritesFlag()

        if (writes_flag) {
            const modal = Modal.confirm({
                title: "Carrier API Enabled",
                content: "Carrier API settings are enabled. Submitting now will trigger the Carrier API directly. Do you want to proceed?",
                centered: true,
                okText: "Submit",
                onOk: () => {
                    // modal.destroy(); // closes the modal
                    // handleCloseModal();

                    onsubmit();

                    submitCarrierStatus(writes_flag);
                },
                onCancel: onCancel,
            });
        }
        else {
            onsubmit();

        }
    };

    const handleCheckboxChange = (e: any) => {
        setIsChecked(e.target.checked); // Update the state when checkbox is checked/unchecked
    };
    useImperativeHandle(ref, () => ({
        runSubmit: onsubmit,
    }));
    if (loading) {
        return (
            <div className="flex justify-center items-center h-[400px]">
                <Spin size="large" />
            </div>
        );
    }
    return (
        <div>
            <div className="flex justify-between w-full">
                <div className="w-[50%]" style={{ flex: 1, paddingRight: '16px' }}>
                    <h2 className="font-[600]">Bulk Change Summary</h2>
                    <div className="shadow w-full h-[300px] p-4 overflow-y-auto">
                        <div className="grid grid-cols-1">
                            {iccids.map((iccid, index) => (
                                <div key={index} className="mb-4">
                                    <span className="text-gray-400 font-[500]">SIM {index + 1}</span> :<span> {iccid}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
                <div className="w-[50%] mb-4" style={{ flex: 1 }}>
                    <h2 className="font-[600]">Confirmation</h2>
                    <div className="bg-[#FFFBE6] p-4 mb-4 border border-[#ffe58f] archive-summary-warning">
                        Warning: Are you sure that the final bill has been sent for all of these devices? These devices will no longer be available in AMOP.
                    </div>
                    <span className="ml-4">Selected devices are valid and ready to be archived!</span>
                    {/* <Checkbox className="ml-4 mt-8" onChange={handleCheckboxChange}>Process immediately</Checkbox> Checkbox added */}

                </div>
            </div>
            <div className="flex justify-between">
                <div className="justify-start mt-4">
                    <button onClick={handleBackClick} className="cancel-btn">
                        {/* <ArrowLeftIcon className="h-5 w-5 mr-2" /> */}
                        Back
                    </button>
                </div>
                <div className="flex mt-4 space-x-2">
                    <button onClick={onCancel} className="cancel-btn">Cancel</button>
                    <button onClick={handleSubmit} className="save-btn">Submit</button>
                </div>
            </div>
        </div>
    );
}
)

export default ArchiveSummaryContent;
