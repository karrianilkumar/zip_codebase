"use client";

import { FC, useState, lazy, Suspense, useEffect, Key, useRef, useMemo } from "react";
import { message, Modal, notification, Spin, Table, Tooltip } from "antd";
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import React from "react";
import { useRouter } from 'next/navigation';
import { PerformanceLogStore } from "@/app/stores/performance_matrix_store";
import { ChevronLeft, ChevronRight, InfoIcon } from "lucide-react";
import { useAllChangeTypesStore } from "@/app/stores/allChangeTypesStore";
import { ArchiveContentRef } from "./archive_modal_main";
import { ActivateServiceContentRef } from "./activate_service_main";
import { DeviceContentRef } from "./all_change_types_devices";
import { AssignCustomerContentRef } from "./assign_customer_duplicate";
import { CarrierRatePlan1ContentRef } from "./carrier_rate_plan_modal1";
import { CarrierRatePlan2ContentRef } from "./carrier_rate_plan_modal2";
import { CarrierRatePlan3ContentRef } from "./carrier_rate_plan_modal3";
import { CustomerRatePlanContentRef } from "./customer_rate_plan_modal_main";
import { EditUsernameContentRef } from "./edit_username_modal_main";
import { IndividualLineSyncContentRef } from "./individual_line_sync";
import { UpdateFeaturesContentRef } from "./update_features_main";
import { Activated1ContentRef } from "./update_device_status_1";
import { Activated2ContentRef } from "./update_device_status_main";
import { RefreshALineContentRef } from "./refresh_line_main";
import { ChangeCommPlanContentRef } from "./change_communication_plan";
import { ChangeICCIDContentRef } from "./change_iccid_modal_main";
import { ChangePhoneNumberContentRef } from "./change_phone_numbers_main";
import { UpdatePPUAddressContentRef } from "./update_ppu_address_main";
import { SendSMSContentRef } from "./send_sms_main";
import { VoiceMailPswdContentRef } from "./reset_voicemail_password_main";
import { PrivateNetworkContentRef } from "./private_network_main";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { useRowWrapFlags } from "@/app/stores/useRowWrapFlags";
import { ArrowUpTrayIcon } from "@heroicons/react/24/outline";
import UploadComponent2 from "./upload_component_2";
import { useInventoryAllChangeTypesStore } from "@/app/stores/inventorytAllChangeTypesStore";
import { set } from "lodash";
import { fireSideCannons } from "@/app/components/confetti";
import { useFeatureStore } from "../../inventory/featureStore";


const messageStyle = {
    fontSize: '14px',
    fontWeight: 'bold',
    padding: '16px',
};
const AllChangeTypesDevices = lazy(() => import("./all_change_types_devices"));
const ArchiveContent = lazy(() => import("./archive_modal_main"));
const AssignCustomerContent = lazy(() => import("./assign_customer_duplicate"));
const ChangeCarrierRatePlan1 = lazy(() => import("./carrier_rate_plan_modal1"));
const ChangeCarrierRatePlan2 = lazy(() => import("./carrier_rate_plan_modal2"));
const ChangeCarrierRatePlan3 = lazy(() => import("./carrier_rate_plan_modal3"));
const ChangeCustomerRatePlan = lazy(() => import("./customer_rate_plan_modal_main"));
const EditUsername = lazy(() => import("./edit_username_modal_main"));
const ChangeICCIDContent = lazy(() => import("./change_iccid_modal_main"));
const ChangePhoneNumber = lazy(() => import("./change_phone_numbers_main"));
const ChangeDeviceStatus = lazy(() => import("./update_device_status_main"));
const ChangeDeviceStatus1 = lazy(() => import("./update_device_status_1"));
const NewService = lazy(() => import("./activate_service_main"));
const UpdatePPUAddress = lazy(() => import("./update_ppu_address_main"));
const UpdateFeatures = lazy(() => import("./update_features_main"));
const RefreshLine = lazy(() => import("./refresh_line_main"));
const ChangeCommPlan = lazy(() => import("./change_communication_plan"));
const IndividualLineSync = lazy(() => import("./individual_line_sync"));
const SendSMS = lazy(() => import("./send_sms_main"));
const ResetVoiceMailPswd = lazy(() => import("./reset_voicemail_password_main"));
const PrivateNetwork = lazy(() => import("./private_network_main"));


interface NewChangeProps {
    originalChangeTypeOptions: any[]
    selectedServiceProvider: any
    handleCancel: () => void;
    handleFinish: () => void;
    onBack: () => void;
    isBPEnabled: boolean;
    activationData: any;
    refreshData: () => void
}

const AllChangeTypes: React.FC<NewChangeProps> = ({ originalChangeTypeOptions, selectedServiceProvider, handleCancel, handleFinish, isBPEnabled, onBack, activationData, refreshData }) => {
    const [selectedAction, setSelectedAction] = useState<string>("");
    const [selectedTempAction, setSelectedTempAction] = useState<string>("Devices");
    const [changeTypeOptions, setChangeTypeOptions] = useState<any>([])
    const [dropdownData, setDropdownData] = useState<any>([])
    const [screenOrder, setScreenOrder] = useState<any>([])
    const [loading, setLoading] = useState(false);
    const { username, role, partner, token, selectedDb, firstLastName, sessionId, metaData } = useAuth();
    const { getTargetTenantProvider, IsTargetTenantProvider } = PerformanceLogStore();
    const is_parent_provider_exists = IsTargetTenantProvider(selectedServiceProvider)
    const { isValidated, setActiveChange, validationTrigger, successFullChangeTypes, successFullScreenOrders, setsuccessFullScreenOrders, allChangeTypesDevices, allchangeTypesDevicesRows, setAllChangeTypesDevices, setsuccessFullChangeTypes, all_2_0_payloads } = useAllChangeTypesStore();
    const [activeScreen, setActiveScreen] = useState<string>(screenOrder?.[0] || "");
    const [isSubmitModalVisible, setIsSubmitModalVisible] = useState(false);
    const [isSubmitClicked, setIsSubmitClicked] = useState(false);
    const { addExport, removeExport, exports } = exportLoadingStore();
    const router = useRouter();
    const containerRef = useRef<HTMLDivElement>(null);
    const itemRefs = useRef<HTMLDivElement[]>([]);
    const { isRowStart, isRowEnd, recompute } = useRowWrapFlags(containerRef, itemRefs, [changeTypeOptions]);
    const [targetStatus, setTargetStatus] = useState<string>("");
    const [isCheckBoxChecked, setIsCheckboxChecked] = useState<boolean>(false);
    const [IPOptions, setIPOptions] = useState<any>([]);
    const { customerRatePlanData, assignCustomerData } = useInventoryAllChangeTypesStore();

    //Sequence validation
    const [isSequenceModalVisible, setIsSequenceModalVisible] = useState(false);
    const { simIdentifierMap } = useFeatureStore();

    const [isContinueClicked, setIsContinueClicked] = useState<boolean>(false);
    const filtered_change_types = originalChangeTypeOptions.filter((option: any) => (option !== "All Change Types"))
    const [selectedChangeTypes, setSelectedChangeTypes] = useState<
        { type: string; order: number }[]
    >([]);

    type SequenceType = {
        type: string;
        order: number;
    };

    const getSequenceForProvider = (
        provider: string
    ): SequenceType[] => {
        const uniqueMap = new Map<string, number>();

        simIdentifierMap.forEach((item: any) => {
            if (item.service_provider === provider) {
                // keep the lowest sequence if duplicates exist
                if (
                    !uniqueMap.has(item.change_type) ||
                    item.change_type_sequence < uniqueMap.get(item.change_type)!
                ) {
                    uniqueMap.set(item.change_type, item.change_type_sequence);
                }
            }
        });

        return Array.from(uniqueMap.entries())
            .map(([type, order]) => ({ type, order }))
            .sort((a, b) => a.order - b.order);
    };
    const handleChangeTypeToggle = (type: string) => {
        setSelectedChangeTypes(prev => {
            const exists = prev.find(item => item.type === type);

            if (exists) {
                // ❌ Remove and re-order
                const filtered = prev.filter(item => item.type !== type);

                return filtered.map((item, index) => ({
                    ...item,
                    order: index + 1,
                }));
            } else {
                // ✅ Add with next order
                return [
                    ...prev,
                    { type, order: prev.length + 1 }
                ];
            }
        });
    };

    const isOrderValid = (
        original: { type: string; order: number }[],
        selected: { type: string; order: number }[]
    ) => {
        // Create a lookup map from original
        const orderMap = new Map<string, number>();
        original.forEach((item) => {
            orderMap.set(item.type, item.order);
        });

        // Check if selected is in increasing order based on original
        for (let i = 1; i < selected.length; i++) {
            const prev = orderMap.get(selected[i - 1].type);
            const curr = orderMap.get(selected[i].type);

            if (prev === undefined || curr === undefined || prev > curr) {
                return false;
            }
        }

        return true;
    };

    const handleOncontinue = () => {
        const originalOrder = getSequenceForProvider(selectedServiceProvider || "")

        const isValid = isOrderValid(originalOrder, selectedChangeTypes);

        if (!isValid) {
            Modal.warning({
                title: 'Sequence Validation',
                content: "The selected change types do not follow the required execution sequence.Please update your selection to proceed.",
                centered: true,
                width: 600,
            });

            return;
        }

        console.log("getSequenceForProvider", originalOrder);
        console.log("selectedChangeTypes", selectedChangeTypes);

        console.log("getSequenceForProvider", originalOrder)
        console.log("selectedChangeTypes", selectedChangeTypes)
        setIsContinueClicked(true)
        setChangeTypeOptions(["Devices", ...selectedChangeTypes.map((type: any) => (type?.type))])
        setScreenOrder(["devices"])
        setSelectedAction("Devices")
        setsuccessFullChangeTypes([])
        fetchOptionsMappings()
    }


    const fetchOptionsMappings = async () => {
        try {
            const url =
                ENV_ROUTES.MODULE_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                path: "/get_private_network_pdp_apn_ip_mappings",
                request_received_at: getCurrentDateTime(),
                username: username,
                firstLastName: firstLastName,
                role_name: role,
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: selectedServiceProvider,
                ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(selectedServiceProvider) : "" },
                change_type: "All Change Types"
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                // const apn_pdp_map = parsedData?.apn_pdp_map || {};
                // setApnPdpMap(apn_pdp_map)
                // const pdp_ip_map = parsedData?.pdp_ip_map || {};
                // setPdpIpMap(pdp_ip_map)

                // const apn_options = Object.keys(apn_pdp_map) || []
                // setApnOptions(apn_options)

                // const pdp_options = parsedData?.pdp || [];
                // setPdpOptions(pdp_options)

                const ip_options = parsedData?.ip_addresses || {};
                setIPOptions(ip_options)
            }
        } catch (error) {
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        }
    };

    useEffect(() => {
        console.log("successFullChangeTypes", successFullChangeTypes);

        const activeScreenName = changeTypeMap[activeScreen];
        console.log("activeScreenName", activeScreenName);

        const currentOrders = useAllChangeTypesStore.getState().successFullScreenOrders;
        console.log("successFullChangeTypes", successFullChangeTypes)
        console.log("currentOrders", currentOrders)

        const newOrders = new Set(currentOrders); // use Set to avoid duplicates

        if (successFullChangeTypes.includes(activeScreenName)) {
            newOrders.add(activeScreen);
        } else {
            newOrders.delete(activeScreen);
        }

        console.log("newOrders after modification", Array.from(newOrders));
        setsuccessFullScreenOrders(Array.from(newOrders));
    }, [successFullChangeTypes]);



    useEffect(() => {
        setActiveScreen(screenOrder?.[0] || "")
    }, [screenOrder])

    useEffect(() => {
        setActiveChange(selectedAction || "Devices")
    }, [selectedAction])

    const scroll = (direction: "left" | "right") => {
        if (containerRef.current) {
            const scrollAmount = direction === "left" ? -300 : 300;
            containerRef.current.scrollBy({ left: scrollAmount, behavior: "smooth" });
        }
    };
    const isAdmin = role?.toLowerCase() === "super admin" || role?.toLowerCase() === "partner admin"
    const parseList = (value: any) => {
        if (typeof value === 'string') {
            let parsedPlans: any[];
            try {
                parsedPlans = JSON.parse(value)
            }
            catch (err) {
                console.log(err)
                parsedPlans = []
            }
            return Array.isArray(parsedPlans) ? parsedPlans : [];
        }
        if (Array.isArray(value)) {
            return value;
        }
        return [];
    };

    const fetchCarrierWritesFlag = async () => {
        let parsedData: any
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
            tenant_name: partner || "default_value",
            username,
            path: "/get_writes_enable_for_service_provider",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "Inventory",
            service_provider: selectedServiceProvider || "",
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
            ...metaData,
            sessionID: sessionId,
            environment: "BETA",
            change_type: "All Change Types",
        };

        try {
            setLoading(true);
            const response = await axios.post(url, { data });
            parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === true) {
                const write_is_enabled = parsedData?.write_is_enabled || false;
                // setWritesFlag(write_is_enabled);
                return write_is_enabled;
            }
        } catch (error) {
            console.error("Error fetching data:", error);
            return false; // fallback in case of error
        } finally {
            setLoading(false);
        }
    };
    const submitCarrierStatus = async (write_is_enabled: boolean) => {
        const devices = allChangeTypesDevices?.iccids || []
        let parsedData: any
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
            tenant_name: partner || "default_value",
            username,
            path: "/insert_carrier_status_validation_audit",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "Inventory",
            service_provider: selectedServiceProvider || "",
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
            ...metaData,
            sessionID: sessionId,
            environment: "BETA",
            ...(allChangeTypesDevices?.isIccid ? {
                msisdn: [],
                iccid: [...devices]
            } : {
                msisdn: [...devices],
                iccid: []
            }),
            change_type: "All Change Types",
            write_is_enabled: write_is_enabled,
        };

        try {
            // setLoading(true);
            const response = await axios.post(url, { data });
            parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === true) {

            }
        } catch (error) {
            console.error("Error fetching data:", error);
        } finally {
            // setLoading(false);
        }
    };
    const fetchChangeType = async (change_type: string) => {
        try {
            setLoading(true);
            const url =
                ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner || "default_value",
                path: "/get_new_bulk_change_data",
                request_received_at: getCurrentDateTime(),
                username: username,
                firstLastName: firstLastName,
                role_name: role,
                Partner: partner,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: selectedServiceProvider,
                change_type: change_type,
                parent_provider_name: getTargetTenantProvider(selectedServiceProvider || "") || ""
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                setLoading(false);
                Modal.error({
                    title: 'Data Fetch Error',
                    content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                    centered: true,
                });
            } else {
                const screen_order_ = parsedData?.response_data?.screen_names_seq || []
                const parsedOrder = parseList(screen_order_)
                setScreenOrder(parsedOrder)
                const dropdownData_ = parsedData?.response_data?.dropdown_data || {}
                setDropdownData(dropdownData_)
                setLoading(false);
            }
        } catch (error) {
            Modal.error({
                title: 'Data Fetch Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                centered: true,
            });
        }
    };
    const submitAllPayloads = async (all_2_0_payloads_: any) => {
        let parsedData: any
        const url = ENV_ROUTES.BULKCHANGE_PROCESSOR;
        const data = {
            tenant_name: partner || "default_value",
            username,
            path: "/all_change_types_scheduler",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "Bulk Change",
            service_provider: selectedServiceProvider || "",
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
            ...metaData,
            sessionID: sessionId,
            change_type: "All Change Types",
            All_change_types: { ...all_2_0_payloads_ }
        };

        try {
            // setLoading(true);
            const response = await axios.post(url, { data });
            parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === true) {
                console.log("submitAllPayloads success")
            }
        } catch (error) {
            console.error("submitAllPayloads failed");
            return false;
        } finally {
            // setLoading(false);
        }
    };

    const handleChangeTypeClick = (changeType: string) => {
        setSelectedAction(changeType)
        if (changeType === "Devices") {
            setScreenOrder(["devices"])
        }
        else {
            fetchChangeType(changeType)
        }
    };

    const archiveRef = useRef<ArchiveContentRef>(null);
    const activeRef = useRef<ActivateServiceContentRef>(null);
    const devicesRef = useRef<DeviceContentRef>(null);
    const assignCustomerRef = useRef<AssignCustomerContentRef>(null);
    const carrier1Ref = useRef<CarrierRatePlan1ContentRef>(null);
    const carrier2Ref = useRef<CarrierRatePlan2ContentRef>(null);
    const carrier3Ref = useRef<CarrierRatePlan3ContentRef>(null);
    const customerRef = useRef<CustomerRatePlanContentRef>(null);
    const editUserNameRef = useRef<EditUsernameContentRef>(null);
    const lineSyncRef = useRef<IndividualLineSyncContentRef>(null);
    const featuresRef = useRef<UpdateFeaturesContentRef>(null);
    const deviceStatus1Ref = useRef<Activated1ContentRef>(null);
    const deviceStatus2Ref = useRef<Activated2ContentRef>(null);
    const refreshLineRef = useRef<RefreshALineContentRef>(null);
    const commPlanRef = useRef<ChangeCommPlanContentRef>(null);
    const changeICCIDRef = useRef<ChangeICCIDContentRef>(null);
    const phoneNumberRef = useRef<ChangePhoneNumberContentRef>(null);
    const ppuAddressRef = useRef<UpdatePPUAddressContentRef>(null);
    const sendSMSRef = useRef<SendSMSContentRef>(null);
    const voiceMailRef = useRef<VoiceMailPswdContentRef>(null);
    const privateNetworkRef = useRef<PrivateNetworkContentRef>(null);

    const refMap: Record<string, React.RefObject<any>> = {
        "archive-main": archiveRef,
        "new-service-main": activeRef,
        "devices": devicesRef,
        "assign-customer-main": assignCustomerRef,
        "update-features": featuresRef,
        "carrier-rate-plan-1": carrier1Ref,
        "carrier-rate-plan-2": carrier2Ref,
        "carrier-rate-plan-3": carrier3Ref,
        "customer-rate-plan-main": customerRef,
        "edit-username-main": editUserNameRef,
        "iccid-imei-main": changeICCIDRef,
        "change-phone-number-main": phoneNumberRef,
        "device-status-main": deviceStatus2Ref,
        "device-status-1": deviceStatus1Ref,
        "update-ppu-address": ppuAddressRef,
        "refresh-aline": refreshLineRef,
        "communication-plan-main": commPlanRef,
        "individual-line-sync": lineSyncRef,
        "send-sms-main": sendSMSRef,
        "reset-voice-mail-password-main": voiceMailRef,
        "private-network-main": privateNetworkRef,

    };
    const changeTypeMap: Record<string, string> = {
        "archive-main": "Archive",
        "new-service-main": "Activate New Service",
        "devices": "Devices",
        "assign-customer-main": "Assign Customer",
        "update-features": "Update Features",
        "carrier-rate-plan-1": "Change Carrier Rate Plan",
        "carrier-rate-plan-2": "Change Carrier Rate Plan",
        "carrier-rate-plan-3": "Change Carrier Rate Plan",
        "customer-rate-plan-main": "Change Customer Rate Plan",
        "edit-username-main": "Edit Username/Cost Center",
        "iccid-imei-main": "Change ICCID/IMEI",
        "change-phone-number-main": "Change Phone Number",
        "device-status-main": "Update Device Status",
        "device-status-1": "Update Device Status",
        "update-ppu-address": "Update PPU address",
        "refresh-aline": "Refresh A Line",
        "communication-plan-main": "Change Communication Plan",
        "individual-line-sync": "Line Sync",
        "send-sms-main": "Send SMS",
        "reset-voice-mail-password-main": "Reset Voicemail Password",
        "private-network-main": "Change Private Static IP Address",
    };


    const onSubmitClick = async () => {
        setSelectedTempAction(selectedAction)
        validationCheck(selectedAction, "submit")

    }

    const confirmSubmit = async () => {
        try {
            addExport("bulkChangeInsert", "Bulk Change Submission");
            handleCancel();

            console.log("successFullScreenOrders", successFullScreenOrders);

            // Remove duplicates
            let successScreens: any[] = [...new Set(successFullScreenOrders)];

            // Remove "devices"
            successScreens = successScreens.filter(
                (type) => type.toLowerCase() !== "devices"
            );

            // Extract "line sync" (case insensitive)
            const hasLineSync = successScreens.some(
                (type) => type.toLowerCase() === "individual-line-sync"
            );

            // Remove line sync from normal execution flow
            // successScreens = successScreens.filter(
            //     (type) => type.toLowerCase() !== "individual-line-sync"
            // );

            // const orderedPayload: Record<string, any> = {};

            // Step 1: Create a lookup for order
            const orderMap = new Map<string, number>();
            selectedChangeTypes.forEach(({ type, order }) => {
                orderMap.set(type, order);
            });

            // Step 1: Run all submits FIRST (sequential)
            for (const changeType of successScreens) {
                const ref = refMap[changeType];

                if (ref?.current?.runSubmit) {
                    console.log("Submitting for changeType:", changeType);
                    await ref.current.runSubmit();
                }
            }

            // ✅ Step 2: wait for store updates to flush (IMPORTANT)
            await Promise.resolve();
            // (or: await new Promise(res => setTimeout(res, 0));)

            // ✅ Step 3: Get latest store AFTER flush
            const latestPayloads = useAllChangeTypesStore.getState().all_2_0_payloads;
            console.log("latestPayloads", latestPayloads)

            // Step 4: Collect valid items
            const tempArray: {
                type: string;
                order: number;
                payload: any;
            }[] = [];

            for (const changeType of successScreens) {
                const readableType = changeTypeMap[changeType];

                if (!readableType || !orderMap.has(readableType)) continue;

                const payload = latestPayloads?.[readableType];

                console.log("payload_2_0", readableType, payload);

                if (payload && Object.keys(payload).length > 0) {
                    tempArray.push({
                        type: readableType,
                        order: orderMap.get(readableType)!,
                        payload: { ...payload },
                    });
                }
            }

            // Step 5: Sort by order
            tempArray.sort((a, b) => a.order - b.order);

            // Step 6: Convert to required object format
            const orderedPayload: Record<string, any> = {};

            tempArray.forEach((item, index) => {
                orderedPayload[(index + 1).toString()] = {
                    ...item.payload,
                };
            });

            console.log("Final Ordered Payload:", orderedPayload);
            submitAllPayloads(orderedPayload)

            // ✅ If line sync exists → wait 15s after all submits
            // if (hasLineSync) {
            //     console.log("Waiting 15s before running Line Sync...");

            //     await new Promise((resolve) => setTimeout(resolve, 15000));

            //     const lineSyncRef = refMap["individual-line-sync"] || refMap["Line Sync"];
            //     if (lineSyncRef?.current?.runSubmit) {
            //         console.log("Submitting for Line Sync after delay");
            //         await lineSyncRef.current.runSubmit();
            //     }
            // }
        }
        catch (err) {
            console.log("error occured while submitting all change types", err);
        }
        finally {
            removeExport("bulkChangeInsert");
            notification.success({
                message: "Success",
                description: "Successfully submitted!",
                style: messageStyle,
                placement: "top",
            });
            fireSideCannons();
            refreshData();
        }
    };


    const handleSubmit = async () => {
        const writes_flag = await fetchCarrierWritesFlag()
        if (writes_flag) {
            const modal = Modal.confirm({
                title: "Carrier API Enabled",
                content: "Carrier API settings are enabled. Submitting now will trigger the Carrier API directly. Do you want to proceed?",
                centered: true,
                okText: "Submit",
                onOk: () => {
                    // modal.destroy(); // closes the modal
                    // handleCloseModal();
                    setIsSubmitModalVisible(false)
                    confirmSubmit();
                    submitCarrierStatus(writes_flag);
                },
                onCancel: () => {
                    setIsSubmitModalVisible(false)
                }
            });
        }
        else {
            confirmSubmit();
        }

    };


    const ipv4Regex = /^(\d{1,3}\.){3}\d{1,3}$/;
    const isValidIPv4 = (ip: string) => {
        if (!ipv4Regex.test(ip)) return false;
        return ip.split(".").every(p => {
            if (!/^\d+$/.test(p)) return false;
            const n = Number(p);
            return Number.isInteger(n) && n >= 0 && n <= 255;
        });
    };
    const ipv4ToUint32 = (ip: string) => {
        const [a, b, c, d] = ip.split(".").map(Number);
        return ((a << 24) >>> 0) + (b << 16) + (c << 8) + d;
    };

    // IPv6: expand compressed forms into 8 hextets of 4 hex digits
    const expandIPv6 = (input: string): string[] | null => {
        const raw = input.trim();
        if (!raw) return null;
        // split on :: (0..1 times)
        if (raw.includes("::")) {
            const [left, right] = raw.split("::");
            const leftParts = left ? left.split(":").filter(Boolean) : [];
            const rightParts = right ? right.split(":").filter(Boolean) : [];
            if (leftParts.some(p => p.length > 4) || rightParts.some(p => p.length > 4)) return null;
            const missing = 8 - (leftParts.length + rightParts.length);
            if (missing < 0) return null;
            const mid = new Array(missing).fill("0");
            const parts = [...leftParts, ...mid, ...rightParts].map(p => p || "0");
            if (parts.length !== 8) return null;
            return parts.map(p => p.padStart(4, "0").toUpperCase());
        } else {
            const parts = raw.split(":");
            if (parts.length !== 8) return null;
            if (parts.some(p => p.length === 0 || p.length > 4)) return null;
            return parts.map(p => p.padStart(4, "0").toUpperCase());
        }
    };

    // Detect IPv6 (rough)
    const looksLikeIPv6 = (s: string) => s.includes(":");

    // Convert expanded 8 hextets -> BigInt
    const ipv6PartsToBigInt = (parts: string[]) => {
        // each part is 4 hex digits -> 16 bits
        let acc = BigInt(0);
        for (let i = 0; i < 8; i++) {
            const v = BigInt(parseInt(parts[i], 16) & 0xFFFF);
            acc = (acc << BigInt(16)) + v;
        }
        return acc;
    };
    const parseSavedRange = (ipRange: string) => {
        if (!ipRange) return { ok: false as const };

        const parts = ipRange.split("-");
        if (parts.length !== 2) return { ok: false as const };

        const s = parts[0].trim();
        const e = parts[1].trim();

        // IPv4 branch
        if (!looksLikeIPv6(s) && !looksLikeIPv6(e)) {
            if (!isValidIPv4(s) || !isValidIPv4(e)) return { ok: false as const };
            const sN = ipv4ToUint32(s);
            const eN = ipv4ToUint32(e);
            const start = Math.min(sN, eN);
            const end = Math.max(sN, eN);
            return { ok: true as const, family: "ipv4" as const, startNum: start, endNum: end };
        }

        // IPv6 branch
        const sExp = expandIPv6(s);
        const eExp = expandIPv6(e);
        if (!sExp || !eExp) return { ok: false as const };
        const sBig = ipv6PartsToBigInt(sExp);
        const eBig = ipv6PartsToBigInt(eExp);
        const startBig = sBig <= eBig ? sBig : eBig;
        const endBig = sBig <= eBig ? eBig : sBig;
        return { ok: true as const, family: "ipv6" as const, startBig, endBig };
    };


    interface IPValidation {
        valid: boolean;
        error: string;
    }

    const unavailableIPError = async (
        ipList: string | string[],
        changeType: string
    ): Promise<IPValidation> => {
        try {
            setLoading(true);

            const url = ENV_ROUTES.MODULE_MANAGEMENT;

            const data = {
                tenant_name: partner || "default_value",
                username,
                firstLastName,
                path: "/validate_ips_availability",
                role_name: role,
                Partner: partner,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                change_type: changeType || "",
                ip_list: ipList || [],
                service_provider: selectedServiceProvider || "",
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);

            // ❌ Invalid cases
            if (parsedData.flag === false || parsedData?.validation) {
                return {
                    valid: false,
                    error: parsedData?.message || "Enter IP address within the available IP list",
                };
            }

            // ✅ Success case
            return {
                valid: true,
                error: "",
            };

        } catch (error) {
            return {
                valid: false,
                error: "Enter IP address within the available IP list",
            };
        } finally {
            setLoading(false);
        }
    };

    const validateFieldIp = async (
        value: string[],
        ipRange: string | string[]
    ): Promise<IPValidation> => {

        // const v = String(value ?? "").trim();

        if (!value || value.length === 0) {
            return { valid: false, error: "Enter a valid IP address" };
        }

        return await unavailableIPError(value, "All Change Types");
    };
    const validateFieldIp_ = (
        value: string,
        ipRange: string | string[]
    ): { valid: boolean; error: string } => {
        const v = String(value ?? "").trim();
        if (!v) return { valid: false, error: "Enter a valid IP address" };

        // Normalize ranges to array of non-empty strings
        const ranges = (Array.isArray(ipRange) ? ipRange : [ipRange])
            .map(r => String(r ?? "").trim())
            .filter(r => r.length > 0);

        if (ranges.length === 0) {
            return {
                valid: false,
                error: "Enter IP address within the given IP range",
            };
        }

        const isV6 = looksLikeIPv6(v);

        // ================= IPv6 =================
        if (isV6) {
            const expanded = expandIPv6(v);
            if (!expanded) {
                return { valid: false, error: "Enter a valid IP address" };
            }

            // Parse all ranges that are valid IPv6
            const parsedV6Ranges = ranges
                .map(r => parseSavedRange(r))
                .filter(p => p.ok && p.family === "ipv6");

            if (parsedV6Ranges.length === 0) {
                return {
                    valid: false,
                    error: "Enter IP address within the given IP range",
                };
            }

            const vBig = ipv6PartsToBigInt(expanded);

            const inAnyRange = parsedV6Ranges.some(p => {
                return vBig >= p.startBig && vBig <= p.endBig;
            });

            if (!inAnyRange) {
                return {
                    valid: false,
                    error: "Enter IP address within the given IP range",
                };
            }

            return { valid: true, error: "" };
        }

        // ================= IPv4 =================
        if (!isValidIPv4(v)) {
            return { valid: false, error: "Enter a valid IP address" };
        }

        const allowedIps = (Array.isArray(ipRange) ? ipRange : [ipRange])
            .map(ip => String(ip).trim())
            .filter(Boolean);

        const exists = allowedIps.includes(v);

        if (!exists) {
            return {
                valid: false,
                error: "Enter IP address within the available IP list",
            };
        }
        return { valid: true, error: "" };
    };
    const validationCheck = async (changeType: string, mode: string) => {
        if (mode === "submit") {
            setIsSubmitClicked(true)
        }
        else {
            setIsSubmitClicked(false)
        }
        setSelectedTempAction(changeType);

        // Find the matching ref dynamically
        const currentRef = refMap[activeScreen];

        // Run validation if ref exists and has the method
        if (currentRef?.current?.runValidation) {
            await currentRef.current.runValidation();
        }

        console.log("isValidated", isValidated, changeType, validationTrigger);
    };
    type ValidateResult = {
        errors: string[];
    };
    const COMMON_FIELDS_MAP: Record<string, string[]> = {
        "Assign Customer|Change Customer Rate Plan": [
            "customer_name",
            "customer_rate_plan_name",
            "customer_rate_pool_name",
            "effective_date"
        ],
        // Add more common field mappings as needed
        // "ChangeType1|ChangeType2": ["field1", "field2"]
    };
    const ALLOWED_TYPES = [
        "Assign Customer",
        "Change Customer Rate Plan",
    ];

    // Helper function to get field display name
    const getFieldDisplayName = (fieldName: string): string => {
        const displayNames: Record<string, string> = {
            customer_name: "Customer Name",
            customer_rate_plan_name: "Customer Rate Plan",
            customer_rate_pool_name: "Customer Rate Pool",
            effective_date: "Effective Date"
            // Add more field display names as needed
        };
        return displayNames[fieldName] || fieldName;
    };
    const validateCommonFields = (): { isValid: boolean; errors: string[] } => {
        console.log("customerRatePlanData", customerRatePlanData)
        console.log("assignCustomerData", assignCustomerData)

        const errors: string[] = [];
        const processedPairs = new Set<string>(); // Track processed pairs to avoid duplicates

        const selectedTypes = Array.from(
            new Set(successFullChangeTypes as string[])
        ).filter(type => ALLOWED_TYPES.includes(type));

        if (selectedTypes.length < 2) {
            return { isValid: true, errors: [] };
        }

        // Check each pair of change types for common fields
        for (let i = 0; i < selectedTypes.length; i++) {
            for (let j = i + 1; j < selectedTypes.length; j++) {
                const type1: string = selectedTypes[i];
                const type2: string = selectedTypes[j];

                // Create a unique key for this pair (sorted alphabetically to avoid duplicates)
                const pairKey = [type1, type2].sort().join('|');

                // Skip if we've already processed this pair
                if (processedPairs.has(pairKey)) {
                    continue;
                }

                processedPairs.add(pairKey);

                const mismatchedFields: string[] = [];

                /* -------------------------------
                   SPECIAL CASE:
                   Customer Rate Plan Name
                -------------------------------- */
                const isCustomerRatePlanPair =
                    (type1 === "Change Customer Rate Plan" && type2 === "Assign Customer") ||
                    (type1 === "Assign Customer" && type2 === "Change Customer Rate Plan");

                if (
                    isCustomerRatePlanPair &&
                    (customerRatePlanData?.customer_rate_plan_name == null || customerRatePlanData?.customer_rate_plan_name == -1) &&
                    assignCustomerData?.customer_rate_plan_name != null
                ) {
                    mismatchedFields.push("Customer Rate Plan Name");
                }
                if (
                    isCustomerRatePlanPair &&
                    (customerRatePlanData?.customer_rate_pool_name == null || customerRatePlanData?.customer_rate_pool_name == -1) &&
                    assignCustomerData?.customer_rate_pool_name != null
                ) {
                    mismatchedFields.push("Customer Rate Pool Name");
                }
                const key1 = `${type1}|${type2}`;
                const key2 = `${type2}|${type1}`;

                const commonFields = COMMON_FIELDS_MAP[key1] || COMMON_FIELDS_MAP[key2];

                if (commonFields && commonFields.length > 0) {
                    // Get data for both change types
                    const data1 = customerRatePlanData;
                    const data2 = assignCustomerData;

                    if (!data1 || !data2) continue;

                    const normalizeValue = (val: any, field: string) => {
                        if (val === null || val === undefined || val === "" || val === "None") {
                            return null;
                        }
                        if (field === "effective_date") {
                            try {
                                return new Date(val).toISOString().split("T")[0];
                            } catch {
                                return null;
                            }
                        }

                        return val;
                    };

                    commonFields.forEach(field => {
                        if (
                            isCustomerRatePlanPair &&
                            (field === "customer_rate_plan_name" || field === "customer_rate_pool_name") &&
                            (
                                customerRatePlanData?.[field] == null ||
                                customerRatePlanData?.[field] === -1 || customerRatePlanData[field] === -2
                            )
                        ) {
                            // handled by special case above
                            return;
                        }
                        const normalizedValue1 = normalizeValue(data1[field], field);
                        const normalizedValue2 = normalizeValue(data2[field], field);

                        // Skip if either side is empty
                        if (normalizedValue1 === null || normalizedValue2 === null) return;

                        if (normalizedValue1 !== normalizedValue2) {
                            const displayName = getFieldDisplayName(field);
                            if (!mismatchedFields.includes(displayName)) {
                                mismatchedFields.push(displayName);
                            }
                        }
                    });
                }

                if (mismatchedFields.length > 0) {
                    errors.push(
                        `${type1} and ${type2} have mismatched values for: ${mismatchedFields.join(", ")}`
                    );
                }
            }
        }

        return {
            isValid: errors.length === 0,
            errors
        };
    };
    const validateDeviceRows = async (
        rows: string[],
        isIMEI: boolean,
        isIPRequired: boolean,
        isIPOptional: boolean,
        IPOptions: string[]
    ): Promise<ValidateResult> => {
        const errors: string[] = [];
        const seenIccids = new Map<string, number>();
        const ipList: any = []

        const baseFormat = allChangeTypesDevices?.isIccid ? "ICCID" : "MSISDN"
        rows.forEach((row, index) => {
            const lineNo = index + 1;
            const parts = row.split(",").map(p => p.trim());

            const minCount =
                1 +
                (isIMEI ? 1 : 0) +
                (isIPRequired ? 1 : 0);

            const maxCount =
                1 +
                (isIMEI ? 1 : 0) +
                ((isIPRequired || isIPOptional) ? 1 : 0);

            /* ---------- STRUCTURE ---------- */
            if (parts.length < minCount) {
                const missing: string[] = [];

                const isIpFormat = (value: string) =>
                    /^(\d{1,3}\.){3}\d{1,3}$/.test(value);

                if (!parts[0]) missing.push("ICCID");

                if (isIMEI) {
                    if (!parts[1]) {
                        missing.push("IMEI");
                    } else if (isIpFormat(parts[1])) {
                        missing.push("IMEI");
                    }
                }

                if (isIPRequired) {
                    const ip = isIMEI
                        ? (parts[2] || (parts[1] && isIpFormat(parts[1]) ? parts[1] : null))
                        : parts[1];

                    if (!ip) missing.push("IP Address");
                }

                errors.push(`Line ${lineNo}: Missing ${missing.join(", ")}`);
                return;
            }

            if (parts.length > maxCount) {
                errors.push(
                    `Line ${lineNo}: Too many values. Expected format: ` +
                    (isIMEI && (isIPRequired || isIPOptional)
                        ? `${baseFormat}, IMEI, IP`
                        : isIMEI
                            ? `${baseFormat}, IMEI`
                            : (isIPRequired || isIPOptional)
                                ? `${baseFormat}, IP`
                                : `${baseFormat}`)
                );
                return;
            }

            /* ---------- EXTRACT ---------- */
            const iccid = parts[0];
            const imei = isIMEI ? parts[1] : null;

            const ip =
                (isIPRequired || isIPOptional)
                    ? parts[isIMEI ? 2 : 1]
                    : null;

            /* ---------- ICCID ---------- */
            if (!iccid) {
                errors.push(`Line ${lineNo}: ICCID is required`);
                return;
            }

            if (!/^\d+$/.test(iccid)) {
                errors.push(`Line ${lineNo}: ICCID must contain numbers only`);
            }

            if (seenIccids.has(iccid)) {
                errors.push(
                    `Line ${lineNo}: Duplicate ICCID (already entered in Line ${seenIccids.get(iccid)})`
                );
            } else {
                seenIccids.set(iccid, lineNo);
            }

            /* ---------- IMEI ---------- */
            if (isIMEI) {
                if (!imei) {
                    errors.push(`Line ${lineNo}: IMEI is required`);
                } else if (!/^\d+$/.test(imei)) {
                    errors.push(`Line ${lineNo}: IMEI must contain numbers only`);
                } else if (imei.length < 14 || imei.length > 22) {
                    errors.push(`Line ${lineNo}: IMEI must be between 14 and 22 digits`);
                }
            }

            /* ---------- IP ---------- */
            if ((isIPRequired || isIPOptional) && ip) {
                if (!ipList.includes(ip)) {
                    ipList.push(ip);
                }
                // const ipResult = validateFieldIp(ip, privateNetworkRef?.current?.IPOptions || []);
                // if (!ipResult.valid) {
                //     errors.push(`Line ${lineNo}: ${ipResult.error}`);
                // }
            }

            if (isIPRequired && !ip) {
                errors.push(`Line ${lineNo}: IP Address is required`);
            }
        });
        const ipResult = await validateFieldIp(ipList, IPOptions || []);
        console.log("ipResult", ipResult);

        if (!ipResult.valid) {
            errors.push(
                ipResult.error || "Enter IP address within the available IP list"
            );
        }

        console.log("errors:", errors);
        return { errors };
    };


    useEffect(() => {
        const runValidation = async () => {
            if (isValidated) {
                handleChangeTypeClick(selectedTempAction)
                if (isSubmitClicked) {
                    const uniqueCount = new Set(successFullChangeTypes).size;
                    if (uniqueCount > 1) {
                        setTimeout(() => {
                            console.log("successFullScreenOrders", successFullScreenOrders)

                            // handleSubmit()
                        }, 2000);
                        console.log("allChangeTypesDevices", allchangeTypesDevicesRows);
                        console.log("targetStatus:", targetStatus);
                        const commonFieldValidation = validateCommonFields();
                        const uniqueChangeTypes = [...new Set(successFullChangeTypes)];

                        if (uniqueChangeTypes.includes("Change Carrier Rate Plan") &&
                            uniqueChangeTypes.includes("Change Communication Plan")) {
                            const carrierRatePlanData = carrier1Ref?.current?.returnCommonFieldsData || {};
                            const carrierCommPlan = carrierRatePlanData?.communication_plan

                            const commPlanData = commPlanRef?.current?.returnCommonFieldsData?.() || {};
                            const CommPlan = commPlanData?.communication_plan

                            if (carrierCommPlan && CommPlan && carrierCommPlan !== CommPlan) {
                                commonFieldValidation.isValid = false
                                commonFieldValidation.errors.push(
                                    `Change Carrier Rate Plan and Change Communication Plan have mismatched values for: Communication Plan`
                                );
                            }
                        }
                        if (!commonFieldValidation.isValid) {
                            // Show error modal with all mismatched fields
                            Modal.warning({
                                title: 'Common Fields Validation',
                                content: (
                                    <div>
                                        <ul className="list-none pl-0">
                                            {commonFieldValidation.errors.map((error, index) => (
                                                <li key={index} className="mb-2">{error}</li>
                                            ))}
                                        </ul>
                                    </div>
                                ),
                                centered: true,
                                width: 600,
                            });


                            return; // Stop submission
                        }

                        const sp = selectedServiceProvider.toLowerCase();
                        const isIMEIRequired =
                            (sp === "kore" &&
                                successFullChangeTypes.includes("Update Device Status") &&
                                (targetStatus === "Activate" || targetStatus === "Active")) ||
                            ((sp.includes("verizon") || sp.includes("vzn") || sp.includes("vzwcr") || sp.includes("2215-so01")) &&
                                (targetStatus === "Active" || targetStatus === "Pending activation")) ||
                            (sp.includes("telegence") &&
                                successFullChangeTypes.includes("Activate New Service"));

                        const isIPRequired =
                            (sp.includes("telegence") &&
                                (
                                    (successFullChangeTypes.includes("Activate New Service") && isCheckBoxChecked) ||
                                    successFullChangeTypes.includes("Change Private Static IP Address")
                                )) || successFullChangeTypes.includes("Change Private Static IP Address")

                        /** Verizon: IP is OPTIONAL */
                        const isIPOptional =
                            (sp.includes("verizon") || sp.includes("vzn") || sp.includes("vzwcr") || sp.includes("2215-so01")) && !isIPRequired;

                        if (!allchangeTypesDevicesRows) return;

                        const result: any = await validateDeviceRows(
                            allchangeTypesDevicesRows.rows,
                            isIMEIRequired,
                            isIPRequired,
                            isIPOptional,
                            IPOptions
                        );

                        console.log("result:", result)

                        if (result.errors.length > 0) {
                            Modal.error({
                                title: "Devices – Validation Errors",
                                content: (
                                    <div className="flex flex-col gap-1">
                                        {result.errors.map((err: any, i: number) => (
                                            <div key={i}>• {err}</div>
                                        ))}
                                    </div>
                                ),
                                centered: true,
                            });
                            return;
                        }
                        const iccidList: string[] = [];
                        const imeiList: string[] = [];
                        const iccid_ip_map: Record<string, string> = {};
                        const isIccid = allchangeTypesDevicesRows?.isIccid ?? true;


                        if (!allchangeTypesDevicesRows?.rows?.length) return;

                        allchangeTypesDevicesRows.rows.forEach((row: string) => {
                            const parts = row.split(",").map(p => p.trim());

                            const iccid = parts[0];
                            const imei = isIMEIRequired ? parts[1] : undefined;
                            const ip = (isIPRequired || isIPOptional)
                                ? parts[isIMEIRequired ? 2 : 1]
                                : undefined;

                            if (iccid) iccidList.push(iccid);
                            if (isIMEIRequired && imei) imeiList.push(imei);
                            if ((isIPRequired || isIPOptional) && iccid && ip) {
                                iccid_ip_map[iccid] = ip;
                            }
                        });
                        console.log("iccid_ip_map", iccid_ip_map)
                        setAllChangeTypesDevices({
                            iccids: iccidList,
                            imeids: imeiList,
                            isIccid: isIccid,
                            iccid_ip_map: iccid_ip_map
                        });
                        setIsSubmitModalVisible(true)
                    }
                    else {
                        message.error("Please fill in atleast one change type")
                    }

                }

            }
        }
        runValidation()
    }, [validationTrigger])

    const renderContent = () => {
        // if (!selectedServiceProvider || !selectedAction) return null;

        // const mapping = screen_mapping.find(
        //     (item) =>
        //         item.service_provider === selectedServiceProvider &&
        //         item.change_type === selectedAction
        // );

        // if (!mapping) return null;
        return (
            <>
                <div className={`flex justify-center items-center h-[200px] ${loading ? "" : "hidden"}`}>
                    <Spin size="large" />
                </div>
                <div className={(activeScreen === "devices" && !loading) ? "" : "hidden"}>
                    <AllChangeTypesDevices
                        ref={devicesRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Devices"}
                        onClose={handleCancel}
                        changeTypeOptions={changeTypeOptions}
                    />
                </div>
                <div className={(activeScreen === "archive-main" && !loading) ? "" : "hidden"}>
                    <ArchiveContent
                        ref={archiveRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Archive"}
                        onCancel={handleCancel}
                    />
                </div>
                <div className={(activeScreen === "assign-customer-main" && !loading) ? "" : "hidden"}>
                    <AssignCustomerContent
                        ref={assignCustomerRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Assign Customer"}
                        isSubmitScreen={isBPEnabled}
                        onClose={handleCancel}
                    />
                </div>
                <div className={(activeScreen === "carrier-rate-plan-1" && !loading) ? "" : "hidden"}>
                    <ChangeCarrierRatePlan1
                        ref={carrier1Ref}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Change Carrier Rate Plan"}
                        onClose={handleCancel} />
                </div>
                <div className={(activeScreen === "carrier-rate-plan-2" && !loading) ? "" : "hidden"}>
                    <ChangeCarrierRatePlan2
                        ref={carrier2Ref}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Change Carrier Rate Plan"}
                        onClose={handleCancel} />
                </div>

                <div className={(activeScreen === "carrier-rate-plan-3" && !loading) ? "" : "hidden"}>
                    <ChangeCarrierRatePlan3
                        ref={carrier3Ref}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Change Carrier Rate Plan"}
                        onClose={handleCancel} />
                </div>
                <div className={(activeScreen === "customer-rate-plan-main" && !loading) ? "" : "hidden"}>
                    <ChangeCustomerRatePlan
                        ref={customerRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Change Customer Rate Plan"}
                        isSubmitScreen={isBPEnabled}
                        onClose={handleCancel} />
                </div>

                <div className={(activeScreen === "edit-username-main" && !loading) ? "" : "hidden"}>
                    <EditUsername
                        ref={editUserNameRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Edit Username/Cost Center"}
                        onClose={handleCancel} />
                </div>

                <div className={(activeScreen === "iccid-imei-main" && !loading) ? "" : "hidden"}>
                    <ChangeICCIDContent
                        ref={changeICCIDRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Change ICCID/IMEI"}
                        onClose={handleCancel} />
                </div>

                <div className={(activeScreen === "change-phone-number-main" && !loading) ? "" : "hidden"}>
                    <ChangePhoneNumber
                        ref={phoneNumberRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Change Phone Number"}
                        onClose={handleCancel} />
                </div>

                <div className={(activeScreen === "device-status-main" && !loading) ? "" : "hidden"}>
                    <ChangeDeviceStatus
                        ref={deviceStatus2Ref}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Update Device Status"}
                        onClose={handleCancel} />
                </div>

                <div className={(activeScreen === "device-status-1" && !loading) ? "" : "hidden"}>
                    <ChangeDeviceStatus1
                        ref={deviceStatus1Ref}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Update Device Status"}
                        onClose={handleCancel}
                        onTargetStatusChange={setTargetStatus} />
                </div>

                <div className={(activeScreen === "new-service-main" && !loading) ? "" : "hidden"}>
                    <NewService
                        ref={activeRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Activate New Service"}
                        activationData={activationData}
                        isSubmitScreen={!isAdmin}
                        onClose={handleCancel}
                        setIsCheckboxChecked={setIsCheckboxChecked} />
                </div>

                <div className={(activeScreen === "update-ppu-address" && !loading) ? "" : "hidden"}>
                    <UpdatePPUAddress
                        ref={ppuAddressRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Update PPU address"}
                        isSubmitScreen={false}
                        onClose={handleCancel} />
                </div>

                <div className={(activeScreen === "update-features" && !loading) ? "" : "hidden"}>
                    <UpdateFeatures
                        ref={featuresRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Update Features"}
                        onClose={handleCancel} />
                </div>
                <div className={(activeScreen === "refresh-aline" && !loading) ? "" : "hidden"}>
                    <RefreshLine
                        ref={refreshLineRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Refresh A Line"}
                        onClose={handleCancel} />
                </div>
                <div className={(activeScreen === "communication-plan-main" && !loading) ? "" : "hidden"}>
                    <ChangeCommPlan
                        ref={commPlanRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Change Communication Plan"}
                        onClose={handleCancel} />
                </div>
                <div className={(activeScreen === "individual-line-sync" && !loading) ? "" : "hidden"}>
                    <IndividualLineSync
                        ref={lineSyncRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Line Sync"}
                        onClose={handleCancel} />
                </div>
                <div className={(activeScreen === "send-sms-main" && !loading) ? "" : "hidden"}>
                    <SendSMS
                        ref={sendSMSRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Send SMS"}
                        onClose={handleCancel} />
                </div>
                <div className={(activeScreen === "reset-voice-mail-password-main" && !loading) ? "" : "hidden"}>
                    <ResetVoiceMailPswd
                        ref={voiceMailRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Reset Voicemail Password"}
                        onClose={handleCancel} />
                </div>
                <div className={(activeScreen === "private-network-main" && !loading) ? "" : "hidden"}>
                    <PrivateNetwork
                        ref={privateNetworkRef}
                        onContinue={handleFinish}
                        onBack={onBack}
                        dropdown={dropdownData}
                        service_provider={selectedServiceProvider}
                        change_type={"Change Private Static IP Address"}
                        onClose={handleCancel} />
                </div>
            </>
        )
    }

    const modalWidth = typeof window !== 'undefined' ? (window.innerWidth * 2.7) / 4 : 0;
    const selectionModalWidth = typeof window !== 'undefined' ? (window.innerWidth * 1.2) / 4 : 0;
    const modalHeight =
        typeof window !== "undefined" ? (window.innerHeight * 1) / 4 : 0;
    // if (loading) {
    //     return (
    //         <>
    //             <div className="flex justify-center items-center h-[400px] w-[700px]">
    //                 <Spin size="large" />
    //             </div>
    //         </>
    //     );
    // }

    const getBGColor = (changeType: string) => {
        if (changeType === selectedAction) {
            return "bg-blue-300"
        }
        else if (successFullChangeTypes.includes(changeType)) {
            return "bg-green-400"
        }
        else {
            return "bg-gray-500"
        }
    }
    // Define columns for the Modal table
    const columns = [
        {
            title: "Change Type",
            dataIndex: "changeType",
            key: "changeType",
            width: "30%",
        },
        {
            title: <div className="text-center">Updated Value</div>,
            dataIndex: "updatedValue",
            key: "updatedValue",
            render: (value: React.ReactNode) => value,
            width: "70%",
            //  align: "center",
        },
    ];

    // Build table data dynamically
    const dataSource = useMemo(() => {
        return [...new Set(successFullChangeTypes)]
            .filter(type => type !== "Devices")
            .map((type, index) => {

                // ✅ SPECIAL CASE: Change Private Static IP Address
                if (type === "Change Private Static IP Address") {
                    const ips = Object.values(
                        allChangeTypesDevices?.iccid_ip_map || {}
                    );

                    return {
                        key: index,
                        changeType: type,
                        updatedValue: (
                            <div className="flex grid grid-cols-2">
                                <span className="font-semibold">IP Address:</span>
                                <span>{ips.join(", ")}</span>
                            </div>
                        ),
                    };
                }

                // ✅ DEFAULT FLOW (other change types)
                const matchingKeys = Object.keys(changeTypeMap).filter(
                    key => changeTypeMap[key] === type
                );

                const validKey = matchingKeys.find(key =>
                    successFullScreenOrders?.includes(key)
                );

                const ref = validKey ? refMap[validKey] : null;

                let updatedValue: React.ReactNode = null;

                try {
                    const value = ref?.current?.returnUpdate?.();
                    if (value && !(value instanceof Promise)) {
                        updatedValue = value;
                    }
                } catch (err) {
                    console.error(`Error getting updated value for ${type}`, err);
                }

                return {
                    key: index,
                    changeType: type,
                    updatedValue,
                };
            });
    }, [
        successFullChangeTypes,
        allChangeTypesDevices?.iccid_ip_map, // 🔥 THIS IS CRITICAL
        successFullScreenOrders,
    ]);


    // const isRowEnd = (index: number) => {
    //     const current = itemRefs.current[index];
    //     const next = itemRefs.current[index + 1];

    //     // Last item always ends a row
    //     if (!next) return true;

    //     // If next item jumps to a new row → current is row-end
    //     return next.offsetTop > current.offsetTop;
    // };

    // const isRowStart = (index: number) => {
    //     const current = itemRefs.current[index];
    //     const prev = itemRefs.current[index - 1];

    //     // First item is always row-start
    //     if (index === 0) return true;

    //     // If this item jumps to a new line → row start
    //     if (prev && current.offsetTop > prev.offsetTop) return true;

    //     return false;
    // };


    return (
        <>
            <div className="pt-3">

                {isContinueClicked ? (
                    <div style={{ width: modalWidth }}>
                        <div className="flex justify-center mb-2">
                            {/* <button onClick={() => scroll("left")} className="bulkchange-navigation">
                        <ChevronLeft />
                    </button> */}


                            <div className="bulkchange-actions-container" ref={containerRef}>
                                {changeTypeOptions.map((item: any, index: number) => (
                                    <div
                                        key={item.id}
                                        className="bulkchange-action-box"
                                        ref={(el) => { itemRefs.current[index] = el!; }}
                                    >
                                        <div className="bulkchange-action">
                                            {item}
                                        </div>
                                        {/* <div className=""> */}
                                        <div
                                            className={`bulkchange-status-circle ${getBGColor(item)} hover:cursor-pointer`}
                                            onClick={() => {
                                                if (!loading) {
                                                    validationCheck(item, "navigation")
                                                }
                                            }}></div>
                                        {/* </div> */}
                                        {/* {(index !== changeTypeOptions.length - 1 && index !== 0) && (
                                    <div className="bulkchange-horizontal-dotted-line"></div>
                                )}
                                {index === changeTypeOptions.length - 1 && (
                                    <div className="last-bulkchange-horizontal-dotted-line"></div>
                                )}
                                {index === 0 && (
                                    <div className="start-bulkchange-horizontal-dotted-line"></div>
                                )} */}

                                        {/* Dynamically hide dotted line when item is last in that row */}
                                        {(!isRowEnd[index] && !isRowStart[index]) && (
                                            <div className="bulkchange-horizontal-dotted-line" />
                                        )}

                                        {(isRowStart[index] && !isRowEnd[index]) && (
                                            <div className="start-bulkchange-horizontal-dotted-line" />
                                        )}

                                        {(isRowEnd[index] && !isRowStart[index]) && (
                                            <div className="last-bulkchange-horizontal-dotted-line" />
                                        )}

                                    </div>
                                ))}
                            </div>
                            {/* <button onClick={() => scroll("right")} className="bulkchange-navigation">
                        <ChevronRight />
                    </button> */}

                        </div>

                        <div style={{ minHeight: `${modalHeight}px` }}>
                            {renderContent()}

                        </div>
                        <div className="flex justify-center space-x-4 mt-4">
                            <button onClick={() => setIsContinueClicked(false)} className="cancel-btn">
                                {/* <ArrowLeftIcon className="h-5 w-5 mr-2" /> */}
                                Back
                            </button>
                            <button className={`${(successFullChangeTypes.length < 1 || loading) ? "cancel-btn cursor-not-allowed" : "save-btn"}`} onClick={onSubmitClick} disabled={successFullChangeTypes.length < 1 || loading}>
                                Submit
                                {/* <ArrowRightIcon className="h-5 w-5 ml-2" /> */}
                            </button>
                        </div>
                    </div>
                ) : (
                    <div style={{ width: selectionModalWidth }}>
                        <div className="flex justify-between">
                            <span>Select the change types to be completed :</span>
                            <Tooltip title="Change Types Sequence Details">
                                <InfoIcon
                                    className="h-5 w-5 text-gray-500 cursor-pointer"
                                    onClick={() => setIsSequenceModalVisible(true)}
                                />
                            </Tooltip>
                        </div>
                        <div className="mt-4">
                            {filtered_change_types.map((type: string) => {
                                const selectedItem = selectedChangeTypes.find(
                                    item => item.type === type
                                );

                                return (
                                    <label
                                        key={type}
                                        className="flex items-center space-x-2 cursor-pointer hover:bg-gray-100 hover:!text-black p-1"
                                    >
                                        <input
                                            type="checkbox"
                                            checked={!!selectedItem}
                                            onChange={() => handleChangeTypeToggle(type)}
                                            className="h-4 w-4 cursor-pointer"
                                        />

                                        {selectedItem && (
                                            <span className="text-xs font-semibold bg-blue-500 text-white rounded-full px-2 py-0.5">
                                                {/* <span className="text-xs font-semibold bg-[#bfdbfe] text-black rounded-full px-2 py-0.5"> */}
                                                {selectedItem.order}
                                            </span>
                                        )}

                                        <span className="text-sm">{type}</span>
                                    </label>
                                );
                            })}
                        </div>
                        <div className="flex justify-center space-x-4 mt-4">
                            <button onClick={onBack} className="cancel-btn">
                                {/* <ArrowLeftIcon className="h-5 w-5 mr-2" /> */}
                                Back
                            </button>
                            <button
                                className={`${selectedChangeTypes.length === 0 ? "cancel-btn cursor-not-allowed" : "save-btn"}`}
                                onClick={handleOncontinue}
                                disabled={selectedChangeTypes.length === 0}>
                                Continue
                                {/* <ArrowRightIcon className="h-5 w-5 ml-2" /> */}
                            </button>
                        </div>
                    </div>
                )}

            </div >

            <Modal
                title="Successful Change Types"
                visible={isSubmitModalVisible}
                onCancel={() => setIsSubmitModalVisible(false)}
                footer={
                    <div className="justify-center flex space-x-4">
                        <button
                            onClick={() => setIsSubmitModalVisible(false)}
                            className="cancel-btn"
                        >
                            Cancel
                        </button>
                        <button onClick={handleSubmit} className="save-btn">
                            Submit
                        </button>
                    </div>
                }
                centered
                width={800}
            >
                <>
                    {loading ? (
                        <div className={`flex justify-center items-center h-[400px]`}>
                            <Spin size="large" />
                        </div>
                    ) : (
                        successFullChangeTypes.length > 0 ? (
                            <div style={{ maxHeight: "500px", overflowY: "auto" }}>
                                <Table
                                    columns={columns}
                                    dataSource={dataSource}
                                    pagination={false}
                                    bordered
                                    scroll={{ y: 400 }}
                                    className="no-row-hover"
                                />
                            </div>
                        ) : (
                            <p className="text-center text-gray-500">No successful change types found.</p>
                        )
                    )}

                </>
            </Modal>

            <Modal
                title="Sequence Details"
                visible={isSequenceModalVisible}
                onCancel={() => setIsSequenceModalVisible(false)}
                centered
                footer={null}
            >
                <>
                    <div className="flex justify-between">
                        <span className="text-blue-500">Below is the sequence of change types that should be followed for successful operation.
                            The system will process the selected change types based on this order to avoid failures.</span>
                    </div>
                    <div className="mt-4">
                        {(getSequenceForProvider(selectedServiceProvider || "") || []).map((item: any, index: number) => {
                            return (
                                <label
                                    key={`${item?.order}_${index}`}
                                    className="flex items-center space-x-2 cursor-pointer hover:bg-gray-100 hover:!text-black p-1"
                                >
                                    <span className="text-sm">{item?.order}. {item?.type || ""}</span>
                                </label>
                            );
                        })}
                    </div>
                </>
            </Modal>

        </>

    );
};

export default AllChangeTypes;