import React, { FC, useState } from 'react';
import { Modal, Button, Upload, notification, Spin, message } from 'antd';
import { DownloadOutlined, UploadOutlined } from '@ant-design/icons';
import { UploadOutlined as UploadIcon } from '@ant-design/icons';

import * as XLSX from 'xlsx';
import { ENV_ROUTES } from '@/app/components/routes/route_constants';
import { useAuth } from '@/app/components/auth_context';
import { getCurrentDateTime } from '@/app/components/header_constants';
import axios from 'axios';
import { useRouter } from 'next/navigation';
import { useFeatureStore } from '../../inventory/featureStore';
import { PerformanceLogStore } from '@/app/stores/performance_matrix_store';
import { exportLoadingStore } from '@/app/stores/ExportLoadingStore';
import { useAllChangeTypesStore } from '@/app/stores/allChangeTypesStore';
import moment from 'moment';

const messageStyle = {
  fontSize: "14px",
  fontWeight: "bold",
  padding: "16px",
};

interface Upload2Props {
  service_provider: any;
  change_type: any;
  changed_data?: any;
  onSave?:any
}

const UploadComponent2: FC<Upload2Props> = ({ service_provider, change_type, changed_data,onSave }) => {
  const [isImportModalOpen, setImportModalOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const { username, partner, role, token, selectedDb, firstLastName, sessionId, modulesVersionMap, metaData } = useAuth();
  const [uploadKey, setUploadKey] = useState(Date.now());
  const changeType = change_type.toLowerCase() || ""
  const moduleName = changeType === "change customer rate plan" ? "Bulk Customer Rate Plan" : changeType === "update device status" ? 'Bulk Update Device Status' : changeType === "all change types" ? "All Change Type" : changeType === "change private static ip address" ? "Bulk Ip Address Update" :
  changeType === "Change Private Static IP Address"? "Bulk Ip Address Update" : "Bulk Change"
  const uploadModalName = changeType === "change customer rate plan" ? "Upload Customer Rate Plan" : changeType === "update device status" ? 'Bulk Upload Device Status' : "Bulk Upload"
  const router = useRouter();
  const initial_version_flag = modulesVersionMap?.["Sim Management-Bulk Change"] || false
  const isVersionEnabled = localStorage.getItem("switch_user_2_0_bulk_change") === "True";
  const switch_user_2_0 = isVersionEnabled && initial_version_flag ? "True" : "False"
  const { setBulkRow, simIdentifierMap } = useFeatureStore();
  const { getTargetTenantProvider, IsTargetTenantProvider } = PerformanceLogStore();
  const is_parent_provider_exists = IsTargetTenantProvider(service_provider)
  const providerName = getTargetTenantProvider(service_provider).toLowerCase() || service_provider;
  const { addExport, removeExport, exports } = exportLoadingStore();
  const { isAllChangeType, allChangeTypesDevices } = useAllChangeTypesStore();
  const [changedData2, setChangedData2] = useState<any>({});

  const isIMEI =
    (
      service_provider === "kore" &&
      changeType === "update device status" &&
      (changed_data?.UpdateStatus === "Activate" ||
        changed_data?.UpdateStatus === "Active")
    ) ||
    (
      ((service_provider.includes("verizon") || providerName.toLowerCase().includes("vzn")) &&
        (changed_data?.UpdateStatus === "Active" ||
          changed_data?.UpdateStatus === "Pending activation"))
    )
  const handleImportModalOpen = () => {
    setImportModalOpen(true);
  };

  const handleImportModalClose = () => {
    setImportModalOpen(false);
  };

  //Bulk upload modal

  const downloadBlob = (base64Blob: string) => {
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    const blobObject = new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blobObject);
    // link.download = `${moduleName === "Bulk Change" ? "Bulk Activate New Service" : "Bulk Change"}.xlsx`;
    link.download = `${
  moduleName === "Bulk Change"
    ? "Bulk Activate New Service"
    : moduleName === "Bulk Ip Address Update"
    ? "Bulk IP Upload"
    :changeType === "change customer rate plan" 
    ? "Bulk Customer Rate Plan"
    : "Bulk Change"
}.xlsx`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handleUploadClick = () => {
    handleImportModalOpen();

  }
  const handleDownloadTemplate = async () => {
    const path_ = change_type === "All Change Types" ? "/generate_combined_templates" : "/download_bulk_upload_template"
    setLoading(true);
    const url =changeType === 'all change types' ? ENV_ROUTES.BULKCHANGE_PROCESSOR :ENV_ROUTES.SIM_MANAGEMENT;
    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: path_,
      module_name: moduleName,
      table_name: "",
      role_name: role,
      service_provider: service_provider,
      ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" },
      Partner: partner,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
    };

    const response = await axios.post(url, { data });
    const resp = JSON.parse(response.data.body);
    console.log(resp);
    if (response.data.statusCode === 200) {
      if (resp.flag === true) {
        const blob = resp.blob;
        notification.success({
          message: 'Success',
          description: 'Successfully exported the record!',
          style: messageStyle,
          placement: 'top',
        });
        downloadBlob(blob);

        setLoading(false);
        handleImportModalClose()
      } else {
        console.log('Error message:', resp.message);
        Modal.error({
          title: 'Export Error',
          content: resp.message,
          centered: true,
        });
        setLoading(false);
      }
    } else {
      console.log('Unexpected status code:', response.data.statusCode);
      Modal.error({
        title: 'Export Error',
        content: resp.message,
        centered: true,
      });
      setLoading(false);
    }
  };

  const callBPSync = async (parsedData: any, payload: any, changed_data: any) => {
    const payload_data = { ...payload }
    const changedData = { ...changed_data }
    const CustomerRatePlanUpdate = changedData?.CustomerRatePlanUpdate || {}
    try {
      let prevChangedData
      let lowerCase_customer_name_
      let customerNameParts = []
      let original_customer
      lowerCase_customer_name_ = CustomerRatePlanUpdate.customerName ? CustomerRatePlanUpdate.customerName.toLowerCase() : ""
      original_customer = CustomerRatePlanUpdate.customerName ? CustomerRatePlanUpdate.customerName : ""
      if (lowerCase_customer_name_.endsWith(" -- bp") || lowerCase_customer_name_.endsWith(" -- revio")) {
        original_customer = original_customer.replace(" -- BP", "").replace(" -- RevIO", "");
      }
      if (original_customer) {
        customerNameParts = (original_customer || "").split(" -- ")
      }
      delete payload_data["changed_data"]
      const url = ENV_ROUTES.SM_BULK_CHANGE;
      const payloadData = {
        ...payload_data,
        path: "/bulk_update_assign_customer_bp",
        request_received_at: getCurrentDateTime(),
        bulk_change_id: parsedData?.bulk_chnage_id_20,
        customer_name: customerNameParts && customerNameParts.length > 0 ? customerNameParts[0] : null,
        customer_id: customerNameParts && customerNameParts.length > 0 ? customerNameParts[1] : null
        // changed_data: { ...newChangedData }
      }
      const data = { ...payloadData };
      const response = await axios.post(url, { data });
      const responseData = JSON.parse(response.data.body);
      if (responseData.flag === false) {
        console.log("Failure: 2.0 Bulk change update failed.");
      } else {
        console.log("Success: 2.0 Bulk change update successful.");
      }
    }
    catch (error) {
      console.error("Error running DB script:", error);
    } finally {
    }
  }
  const callRunDbScript = async (parsedData: any) => {
    try {
      const runDbData = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/run_db_script", // Always use this path
        role_name: role,
        module_name: "Bulk Change",
        mod_pages: {
          start: 0,
          end: 100,
        },
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        bulkchange_id: parsedData?.bulkchange_id?.id,
        data: parsedData?.data,
        bulk_chnage_id_20: parsedData?.bulk_chnage_id_20
      };

      console.log("Run DB Data", runDbData);

      // Send the second request
      await axios.post(ENV_ROUTES.SIM_MANAGEMENT, { data: runDbData });
      console.log("Run DB script executed successfully.");
    } catch (error) {
      console.error("Error executing run_db_script:", error);
      // Optionally handle the error here, e.g., show a notification
    }
  };

  const callKoreSync = async (data: any) => {
    const koreUrl = ENV_ROUTES.SM_BULK_CHANGE;
    let koreData = { ...data }
    koreData["path"] = "/start_sync"

    try {
      const koreResponse = await axios.post(koreUrl, { data: koreData });
      const koreResponseData = JSON.parse(koreResponse.data.body);

      if (koreResponseData.flag === false) {
        console.log("Data Fetch Error: " + koreResponseData.message);
      } else {
        console.log("Success: Bulk update successful.");
      }

    }
    catch {
      console.log("error in Start Sync");
    }
  }
  const callSyncLambda = async () => {
    try {
      const url = ENV_ROUTES.OPTIMIZATION_SYNC_LAMBDA;
      const data = {
        key_name: "bulk_chnage_history",
        path: "/lambda_sync_jobs_",
        tenant_name: partner
      };

      const response = await axios.post(url, { data });
      const responseData = JSON.parse(response.data.body);

      if (responseData.flag === false) {
        console.error("Data Fetch Error: " + responseData.message);
      } else {
        console.log("Success: Bulk update successful.");
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };
  const call_2_0_sync = async (parsedData: any) => {
    try {
      const runDbScriptUrl = ENV_ROUTES.SIM_MANAGEMENT;
      const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
      const runDbScriptData = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/update_bulk_change_tables_10",
        role_name: role,
        module_name: "Bulk Change",
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        // service_provider_id: service_provider_id_,
        // bulkchange_id: parsedData?.bulkchange_id?.id,
        // data: parsedData?.data,
        data: {
          bulk_change_id: parsedData?.bulk_chnage_id_20,
        },
        is_update: false,
        // bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
      };

      const runDbScriptResponse = await axios.post(runDbScriptUrl, { data: runDbScriptData });
      const runDbScriptResponseData = JSON.parse(runDbScriptResponse.data.body);

      if (runDbScriptResponseData.flag === false) {
        console.error("Data Fetch Error: " + runDbScriptResponseData.message);
      } else {
        console.log("Success: Bulk update successful.");
      }
    }
    catch (error) {
      console.error("Error running DB script:", error);
    } finally {
      // setLoading(false);
    }
  }

  const isFutureDate = (effectiveDate: any): boolean => {
    if (!effectiveDate) return false;

    const date = moment(effectiveDate);
    if (!date.isValid()) return false;

    return date.isAfter(moment(), "day");
  };

  const call_2_0_submit = async (parsedData: any, payload: any, changed_data: any , change_type_:any) => {
    const isTelegence = providerName.toLowerCase().includes("telegence");
    const isWebbing = providerName.toLowerCase().includes("webbing");
    const isVerizon = (providerName.toLowerCase().includes("verizon") || providerName.toLowerCase().includes("vzn"));
    try {
      let prevChangedData
      let newChangedData
      let selectedEffectiveDate = null
      const selectedChangeType = changeType !== "all change types" ? changeType : change_type_.toLowerCase()
      delete payload["imeids"]
      delete payload["imei"]
      console.log("selectedChangeType",selectedChangeType)
      if (selectedChangeType === "activate new service"){
            delete payload["imeids"]
      }
      else if (selectedChangeType === "assign customer"){
        prevChangedData = {... payload?.changed_data}
        selectedEffectiveDate = prevChangedData?.EffectiveDate || null
        if (isTelegence || isVerizon) {
                delete payload["changed_data"]
            }
      }
      else if (selectedChangeType === "change customer rate plan") {
        let ratePlanNameParts = ""
        let ratePoolNameParts = ""
        prevChangedData = payload?.changed_data?.CustomerRatePlanUpdate || {}
        selectedEffectiveDate = prevChangedData?.EffectiveDate || null
        if (prevChangedData?.CustomerRatePlanId && prevChangedData?.CustomerRatePlanId !== -1) {
          ratePlanNameParts = (prevChangedData?.CustomerRatePlanId || "").split(" -- ")

        }
        if (prevChangedData?.CustomerRatePoolId && prevChangedData?.CustomerRatePoolId !== -1) {
          ratePoolNameParts = (prevChangedData?.CustomerRatePoolId || "").split(" -- ")

        }

        newChangedData = {
          customer_rate_plan_name: ratePlanNameParts && ratePlanNameParts.length > 0 ? ratePlanNameParts[0] : null,
          customer_rate_pool_name: ratePoolNameParts && ratePoolNameParts.length > 0 ? ratePoolNameParts[0] : null,
          effective_date: prevChangedData?.EffectiveDate || "",
        }
        if (isTelegence) {
          payload["msisdns"] = payload?.iccids
          delete payload["iccids"]
        }

      }
      else if (selectedChangeType === "change carrier rate plan") {
        let prevChangedData = payload?.changed_data?.CarrierRatePlanUpdate || {}
        payload["effective_date"] = prevChangedData.EffectiveDate || null
        delete payload["changed_data"]
        if (isTelegence) {
          payload["msisdns"] = payload?.iccids
          delete payload["iccids"]
        }
      }
      else if (selectedChangeType === "change iccid/imei"){
        if(isTelegence || isVerizon){
          payload["msisdns"] = payload?.changed_data?.Request?.OldICCID || [];
          delete payload["iccids"];
        }
      }
      else if (selectedChangeType === "change phone number"){
                payload["msisdns"] = payload?.iccids
                delete payload["iccids"]
      }
      else if (selectedChangeType === "change private static ip address"){
        prevChangedData = payload?.changed_data 
        newChangedData = { ...prevChangedData}
        if(isTelegence){
          payload["msisdns"] = payload?.iccids;
          delete payload["iccids"];
        }

      }
      else if(selectedChangeType === "edit username/cost center"){
        if (isTelegence) {
                payload["msisdns"] = payload?.iccids || []
                delete payload["changed_data"]
                delete payload["iccids"]
            }
      }
      else  if(selectedChangeType === "reset voicemail password"){
        prevChangedData = payload?.changed_data || {}
        newChangedData = { ...prevChangedData }
        if (isTelegence) {
          payload["msisdns"] = payload?.iccids
          delete payload["iccids"]
        }
      }
      else if (selectedChangeType === "refresh a line"){
                payload["msisdns"] = payload?.iccids
                delete payload["iccids"]
      }
      else if (selectedChangeType === "update device status") {
        console.log("changed_data", changedData2)
        prevChangedData = payload?.changed_data || {}
        newChangedData = { ...prevChangedData }
        payload["sim_status"] = changed_data?.sim_status || ""
        payload["device_status_id"] = changed_data?.device_status_id || "22"
        // payload["publicIpRestriction"] = changed_data?.publicIpRestriction || ""
        delete payload["imeids"]
        delete newChangedData["sim_status"]
        delete newChangedData["device_status_id"]
        // delete newChangedData["publicIpRestriction"]
        if (isTelegence) {
          payload["msisdns"] = payload?.iccids
          payload["effective_date"] = changed_data?.effectiveDate || null
          payload["effective_date"] = changed_data?.effectiveDate || null
          delete payload["iccids"]
          delete newChangedData["effectiveDate"]
        }
      }
      else if (selectedChangeType === "update features" || selectedChangeType === "update ppu address") {
        payload["msisdns"] = payload?.iccids
        delete payload["imeids"]
        delete payload["iccids"]
        if (selectedChangeType === "update features") {
          delete payload["changed_data"]
        }
      }
      else if(selectedChangeType === "line sync"){
        if(isTelegence){
          payload["msisdns"] = payload?.iccids;
          delete payload["iccids"];
        }
      }
      else {
        prevChangedData = payload?.changed_data || {}
        newChangedData = { ...prevChangedData }
      }

      let path_ = ((selectedChangeType === "change customer rate plan" || selectedChangeType === "assign customer") && isFutureDate(selectedEffectiveDate || null) )? "/schedule_bulk_change_execution" : "/bulk_change_processor"
      const url = ENV_ROUTES.BULKCHANGE_PROCESSOR;
      const payloadData = {
        ...payload,
        path: path_,
        request_received_at: getCurrentDateTime(),
        bulk_change_id: parsedData?.bulk_chnage_id_20,
        // changed_data: { ...newChangedData }
        changed_data: { ...newChangedData }
      }
      const data = { ...payloadData };
      const response = await axios.post(url, { data });
      const responseData = JSON.parse(response.data.body);
      if (responseData.flag === false) {
        console.log("Failure: 2.0 Bulk change update failed.");
      } else {
        console.log("Success: 2.0 Bulk change update successful.");
      }
    }
    catch (error) {
      console.error("Error running 2_0_submit:", error);
    } finally {
      // setLoading(false);
    }
  }
  const callRestoreCancelledSync = async (payload: any, parsedData: any, changeType_?: string) => {
    const url = ENV_ROUTES.SM_BULK_CHANGE;
    const data_ = {
      tenant_name: partner || "default_value",
      path: "/telegence_bc_update_device_status_restore_cancelled",
      role_name: role,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
      service_provider: service_provider,
      ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" },
      change_type: change_type.toLowerCase() === "all change types" ? changeType_ : change_type,
      created_by: firstLastName,
      msisdns: payload.iccids,
      bulk_change_id: parsedData?.bulk_chnage_id_20,
      tenant_id: parsedData?.tenant_id,
    };


    try {
      const koreResponse = await axios.post(url, { data: data_ });
      const koreResponseData = JSON.parse(koreResponse.data.body);

      if (koreResponseData.flag === false) {
        console.log("Data Fetch Error: " + koreResponseData.message);
      } else {
        console.log("Success: Bulk update successful.");
      }

    }
    catch {
      console.log("error in Start Sync");
    }
  }
  const bulkChangeInsert = async (payload: any, changeType_: any) => {
    let partner_name = partner
    let db_name_ = selectedDb
    try {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner_name || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_bulk_change_insertion",
        role_name: role,
        module_name: "Bulk Change History",
        service_provider_name: service_provider,
        ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" },
        change_type: change_type.toLowerCase() === "all change types" ? changeType_ : change_type,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        request_received_at: getCurrentDateTime(),
        Partner: partner_name,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        console.error("Error fetching bulk change data:", parsedData.message ||
          "An error occurred while fetching bulk change data. Please try again.");
        return false
      } else {
        const statusFlag = parsedData?.bulk_change_data?.status || "";
        const response_data = parsedData?.bulk_change_data?.bulk_change_data || "{}";
        const parsedResp = JSON.parse(response_data)
        console.log("status_flag", statusFlag)
        const status_flag = statusFlag ? (statusFlag).toLowerCase() : ""

        if (status_flag && status_flag === "pending") {
          return false
        }
        else if (status_flag && status_flag === "success") {
          call_2_0_submit(parsedResp, payload, changed_data,changeType_)
          call_2_0_sync(parsedResp)
          return true
        }
        else if (status_flag && status_flag === "error") {
          Modal.error({
            title: 'Submit Error',
            content: parsedData.message || 'An error occurred while submitting. Please try again.',
            centered: true,
          });
          return true
        }
        else {
          return false
        }
      }
    } catch (error) {
      console.error("Error fetching auto refresh data:", error);
      return false
    } finally {
    }
  };
  const bulkChangePolling = async (data: any,changeType_:any) => {
    const result = await bulkChangeInsert(data,changeType_);
    if (!result) {
      setTimeout(() => bulkChangePolling(data,changeType_), 5000); // Try again after 5 seconds
    } else {
      removeExport("bulkChangeInsert");
      console.log("Auto-refresh complete.");
    }
    // if (window.location.pathname.includes("/sim_management/bulk_change")) {
    //     window.location.reload();
    // }
  };
  const fetchDevices = async (devices_list: any, deviceKey: string, changeType_?: string) => {
    try {
      setLoading(true);
      const url =
        ENV_ROUTES.BULKCHANGE_PROCESSOR;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_standard_iccid_msisdn_data",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        service_provider: service_provider,
        ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" },
        change_type: change_type.toLowerCase() === "all change types" ? changeType_ : change_type,
        [deviceKey]: devices_list || []
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        // setLoading(false);
        Modal.error({
          title: 'Submit Error',
          content: parsedData.message || 'An error occurred while submitting data. Please try again.',
          centered: true,
        });
        return []
      } else {
        let responseKey = deviceKey === "iccids" ? "msisdns" : "iccids"
        if (isIMEI) {
          responseKey = deviceKey === "iccids_imei_map" ? "msisdns_imei_map" : "iccids_imei_map"
        }
        let devices = parsedData?.[responseKey] || []
        if (isIMEI) {
          devices = devices ? Object.keys(devices) : devices
        }
        console.log("devices", devices)
        return devices
        // setLoading(false);
      }
    } catch (error) {
      Modal.error({
        title: 'Submit Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting data. Please try again.',
        centered: true,
      });
      return []
      // setLoading(false);
    }
    finally {
      // setLoading(false)
    }
  };
  const getIccidList = async (iccids_: any[], isMSISDN: boolean, changeType_?: string): Promise<string[]> => {
    // Pick devices based on subscriberNumber or iccids
    const devices_ = iccids_;

    // Find matching device type from the map
    const matchedDeviceTypeItem = simIdentifierMap.find((item: any) => {
      return (
        item.service_provider === service_provider &&
        item.change_type === changeType_
      );
    });
    const matchedDeviceType = matchedDeviceTypeItem?.sim_identifier || ""
    // Decide expected type
    const selectDeviceType = isMSISDN ? "msisdns" : "iccids";
    const selectedIMEIType = isMSISDN ? "msisdns_imei_map" : "iccids_imei_map"
    // Split devices into a list
    let iccidList: any = devices_

    let iccidMap: Record<string, string> = {};

    if (isIMEI) {
      // Convert flat list into key-value pairs
      for (let i = 0; i < iccidList.length; i += 2) {
        const iccidOrMsisdn = iccidList[i].toString();
        const imei = iccidList[i + 1] || ""; // safeguard in case odd count
        iccidMap[iccidOrMsisdn.toString()] = imei;
      }
    }

    console.log("iccidMap", iccidMap)
    console.log("iccidList", iccidList)


    // Fetch devices only if types mismatch
    if (matchedDeviceType !== selectDeviceType) {
      const deviceType = isIMEI ? selectedIMEIType : selectDeviceType
      const deviceList = isIMEI ? iccidMap : iccidList
      iccidList = await fetchDevices(deviceList, deviceType, changeType_);
    }
    else {
      iccidList = iccids_
    }

    return iccidList;
  };
  const onsubmit = async (payload: any, changed_data: any, response: any, changeType_?: any) => {
    let data: any
    const billing_platform_flag = response?.billing_platform_flag || false
    // setLoading(true);
    try {
      let changedData = changed_data ? { ...changed_data } : {};
      const overwrite_flag = changed_data?.overwrite || false
      if (change_type.toLowerCase() === "update device status") {
        delete changedData["effectiveDate"]
        delete changedData["sim_status"]
        delete changedData["device_status_id"]
      }

      if (change_type.toLowerCase() === "change customer rate plan") {
        let lowerCase_customer_name_
        let customerNameParts = []
        let original_customer

        const CustomerRatePlanUpdate = changedData?.CustomerRatePlanUpdate || {}
        changedData.CustomerRatePlanUpdate = { ...CustomerRatePlanUpdate };
        if (billing_platform_flag) {
          lowerCase_customer_name_ = CustomerRatePlanUpdate.customerName ? CustomerRatePlanUpdate.customerName.toLowerCase() : ""
          original_customer = CustomerRatePlanUpdate.customerName ? CustomerRatePlanUpdate.customerName : ""
          if (lowerCase_customer_name_.endsWith(" -- bp") || lowerCase_customer_name_.endsWith(" -- revio")) {
            original_customer = original_customer.replace(" -- BP", "").replace(" -- RevIO", "");
          }
          if (original_customer) {
            customerNameParts = (original_customer || "").split(" -- ")
          }

          changedData.CustomerRatePlanUpdate.customerName = customerNameParts && customerNameParts.length > 0 ? customerNameParts[0] : null
        }
      }

      const isActivateNewService = change_type.toLowerCase() === "all change types" ? changeType_ : change_type
        // change_type.toLowerCase() === "activate new service";
      // Prepare payload for the first API
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      data = {
        tenant_name: partner || "default_value",
        path: "/update_bulk_change_data",
        role_name: role,
        username: username,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        service_provider: service_provider,
        ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" },
        // change_type: change_type,
        change_type: change_type.toLowerCase() === "all change types" ? changeType_ : change_type,
        created_by: firstLastName,
        ... (isActivateNewService.toLowerCase() === "activate new service" ? {
          customer_name: response?.customer_name || "",
          customer_id: response?.customer_id || "",
          customer_rate_plan_name_update: response?.customer_rate_plan_name_update || "",
        } : {}),
        ... (isActivateNewService.toLowerCase() === "assign customer" ? {
          billing_platform: response?.biling_platform || false,
          use_carrier_activation: response?.use_carrier_activation || false,
        } : {}),
        ...(isActivateNewService.toLowerCase() === "activate new service" && {
          Devices: payload.iccids || [],
        }),
        ... (isActivateNewService.toLowerCase() === "activate new service" ? {
          iccids: payload.iccids || [],
          imei: payload.imeids || []
        } : {
          iccids: payload.iccids || [],
          imeids: payload.imeids || []
        }),
        ...(payload?.iccid_ip_map && {iccid_ip_map:payload?.iccid_ip_map}),
        ... ({
          changed_data: {
            OverrideValidation: false,
            ...(!isActivateNewService && {
              Devices: payload.iccids || [],
            }),
            ...changedData
          }
        }),
      };

      // Send request to the first API
      const response_data = await axios.post(url, { data });
      const parsedData = JSON.parse(response_data.data.body);

      if (parsedData.flag === false) {
        setLoading(false);
        Modal.error({
          title: 'Submit Error',
          content: parsedData.message || 'An error occurred while submitting. Please try again.',
          centered: true,
        });
        return;
      }
      if (billing_platform_flag) {
        callBPSync(parsedData, data, changed_data)
      }
      const bulkrow_ = parsedData?.bulkchange_id || {};
      const bulkRow: any = { row: bulkrow_ };
      setBulkRow(bulkRow);
      localStorage.setItem('bulk_row', JSON.stringify(bulkRow || "{}"));
      if (bulkRow) {
        if (!isAllChangeType) {
          router.push(`/sim_management/bulk_history`);
        }
      }

      let type = change_type.toLowerCase()
      if (providerName.toLowerCase().includes("telegence") && change_type === "Update Device Status" && changedData2?.UpdateStatus === "M") {
        if (switch_user_2_0 === "True") {
          call_2_0_submit(parsedData, data, changed_data, changeType_)
          call_2_0_sync(parsedData)
        }
        else {
          callRestoreCancelledSync(payload, parsedData, changeType_)
        }
      }
      else {
        if (switch_user_2_0 === "True") {
          call_2_0_submit(parsedData, data, changed_data,changeType_)
          call_2_0_sync(parsedData)
        }
        else {
          await callRunDbScript(parsedData);
        }
        // if (change_type === "Change Customer Rate Plan") {
        //   await callSyncLambda()
        // }
      }
      // notification.success({
      //   message: "Success",
      //   description: "Successfully saved the record!",
      //   style: messageStyle,
      //   placement: "top",
      // });
      if(typeof onSave === "function"){
        onSave()
      }
    } catch (error) {
      console.log("error",error)
      const isTelegence = providerName.toLowerCase().includes("telegence");
      const isWebbing = providerName.toLowerCase().includes("webbing") || providerName.toLowerCase().includes("multi-carrier sim");
      const isVerizon = (providerName.toLowerCase().includes("verizon") || providerName.toLowerCase().includes("vzn") || providerName.toLowerCase().includes("vzwcr") || providerName.toLowerCase().includes("2215-so01"));
      const isPod19 = providerName.toLowerCase().includes("pod19");
      const isPondIOT = providerName.toLowerCase().includes("pond");
      const isJasper = providerName.toLowerCase().includes("jasper");
      const isKore = providerName.toLowerCase().includes("kore");
      const isTeal = providerName.toLowerCase().includes("teal");
      const isRogers = providerName.toLowerCase().includes("rogers");
      if (switch_user_2_0 === "True") {
        // onCancel()
        setLoading(false)
        addExport("bulkChangeInsert", "Bulk Change Submission");
        bulkChangePolling(data,changeType_)
      }
      else {
        Modal.error({
          title: 'Submit Error',
          content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting. Please try again.',
          centered: true,
        });
      }
    } finally {
      // setLoading(false);
    }
  };
  const handleUpload = async (blob: string) => {
    try {
      setLoading(true)
      const url =changeType === 'all change types' ? ENV_ROUTES.BULKCHANGE_PROCESSOR :ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: changeType === 'all change types' ? '/bulk_upload_all_change_types_from_excel' : changeType === "change private static ip address" ? '/bulk_upload_apn_pdp_ip_mapping': changeType === "update device status" ? "/bulk_update_device_status_from_excel": "/update_bulk_change_excel",
        module_name: moduleName,
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        service_provider: service_provider,
        ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" },
        change_type: change_type.toLowerCase() === "all change types" ? changeType : change_type,
        created_by: firstLastName,
        changed_data: { ...changed_data },
        Devices: [],
        iccids: [],
        imei: [],
        upload_xlx: true,
        blob_data: blob,
      };

      const response = await axios.post(url, { data });

      const resp = JSON.parse(response.data.body);
      if (response.data.statusCode === 200) {
        if (resp.flag === true) {
          const parsedData_ = resp.data || {}
          console.log("Initial request successful:", parsedData_);


          setChangedData2(resp.data || {})

          if (change_type === "All Change Types") {
            const items = Object.values(resp.data || {}) as any[];

            let successShown = false;

            for (const item of items) {
              if (!item?.result?.flag) continue;

              const resultData = item.result;
              if (!resultData?.data) continue;

              const isMSISDN_ = resultData.data.is_msisdns || false;
              const changeType = item.change_type || "";

              const selectedDevices = await getIccidList(
                resultData.data.iccids || [],
                isMSISDN_,
                changeType
              );

              const payloadAllChangeTypes = {
                iccids: selectedDevices || [],
                imeids: resultData.data.imeids || [],
                ...(resultData.data.iccid_ip_map && {
                  iccid_ip_map: resultData.data.iccid_ip_map,
                }),
              };

              await onsubmit(
                payloadAllChangeTypes,
                resultData.data.changed_data,
                resultData.data,
                changeType
              );

              // ✅ Show success message ONLY ONCE
              if (!successShown) {
                successShown = true;
                notification.success({
                  message: 'Success',
                  description: 'All bulk changes are successfully uploaded!',
                  placement: 'top',
                });
              }
            }
          }

          else {
            const isMSISDN = resp?.data?.is_msisdns || false
            const selectedDevices = await getIccidList(resp.data.iccids, isMSISDN,change_type)

            const payload = {
              iccids: selectedDevices || [],
              imeids: resp.data.imeids || [],
              ...(resp.data?.iccid_ip_map && {iccid_ip_map : resp.data?.iccid_ip_map})
            }
            await onsubmit(payload, resp?.data.changed_data, resp?.data);
          }


          // All items were successful
          handleImportModalClose();
          // notification.success({
          //   message: 'Success',
          //   description: 'All bulk changes are successfully uploaded!',
          //   placement: 'top',
          // });
        }
        else {
          if (resp.error_type && resp.error_type == "Warning") {
            handleImportModalClose()
            console.log("parsedData.error_type", resp.error_type)
            Modal.warning({
              title: 'Warning',
              // content: resp.message || 'An error occurred while submitting data. Please try again.',
              content: (
                <div>
                  {(resp.message || 'An error occurred while submitting data. Please try again.')
                    .split('\n')
                    .map((line: string, index: number) => (
                      <div key={index}>{line}</div>
                    ))}
                </div>
              ),
              centered: true,
            });
          }
          else {
            Modal.error({
              title: "Import Error",
              content:
                resp.message ||
                "An error occurred while submitting Partners bieng Providers data. Please try again.",
              centered: true,
            });
          }

          // If the top-level flag is false, show error modal
          // Modal.error({
          //   title: 'Import Error',
          //   content: resp.message,
          //   centered: true,
          // });
        }
      } else {
        if (resp.error_type && resp.error_type == "Warning") {
          handleImportModalClose()
          console.log("parsedData.error_type", resp.error_type)
          Modal.warning({
            title: 'Warning',
              // content: resp.message || 'An error occurred while submitting data. Please try again.',
              content: (
                <div>
                  {(resp.message || 'An error occurred while submitting data. Please try again.')
                    .split('\n')
                    .map((line: string, index: number) => (
                      <div key={index}>{line}</div>
                    ))}
                </div>
              ),
              centered: true,
          });
        }
        else {
          Modal.error({
            title: "Import Error",
            content:
              resp.message ||
              "An error occurred while submitting Partners bieng Providers data. Please try again.",
            centered: true,
          });
        }
        // Modal.error({
        //   title: 'Import Error',
        //   content: resp.message,
        //   centered: true,
        // });
      }
    } catch (error) {
      console.error('Error during file upload:', error);
      Modal.error({
        title: 'Import Error',
        content: 'There was an error uploading the file.',
        centered: true,
      });

    }
    finally {
      setLoading(false)
    }
  }
  const handleChange = (info: any) => {
    if (info.file.status === 'done') {
      let blob;
      const file = info.file.originFileObj; // Get the file object
      const reader = new FileReader();
      reader.onload = (e: any) => {
        // Get the file data URL (Base64 string)
        blob = e.target.result;
        handleUpload(blob)
        setUploadKey(Date.now());
      };

      if (blob) {
      }

      reader.readAsDataURL(file); // Read the file as data URL
    } else if (info.file.status === 'error') {
      // Handle upload error
      message.error('Upload failed.');
    }
    else if (info.file.status === 'removed') {

    }
  };
  const uploadProps = {
    key: uploadKey,
    accept: '.xlsx, .xls',
    beforeUpload: (file: any) => {
      // Check if file is an Excel file
      const isExcel = file.type === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || file.type === 'application/vnd.ms-excel';
      if (!isExcel) {
        message.error('You can only upload Excel files!');
      }
      return isExcel;
    },
    onChange: handleChange,
  };

  return (
    <div >
      <div className={`${changeType === "all change types" ? "flex flex-col items-end justify-center mr-8" : "flex flex-col items-end justify-center"}`}>
        <Button onClick={handleImportModalOpen} className='save-btn bulkchange-upload-btn'>
          <UploadIcon />Upload
        </Button>
      </div>
      <Modal
        title={uploadModalName}
        visible={isImportModalOpen}
        onCancel={handleImportModalClose}
        footer={null}
        centered
        width={500}
        bodyStyle={{
          overflowX: "auto", // ✅ allow horizontal scroll if still overflows
        }}
      >
        {loading ? (
          <div className="flex justify-center items-center h-24">
            <Spin size="large" />
          </div>
        ) : (
          <div className="flex flex-col gap-4">
            <div className="flex flex-col md:flex-row gap-4 justify-center m-auto p-4">
              <Upload {...uploadProps} className="w-full md:w-auto">
                <button className="w-[200px] md:w-full upload-btn disabled:cursor-not-allowed">
                  <span className="mr-2"><UploadOutlined /></span>
                  Upload
                </button>
              </Upload>
              <button
                onClick={handleDownloadTemplate}
                className=" w-[200px] md:w-full upload-btn disabled:cursor-not-allowed"
              // disabled={!appendChecked && !overwriteChecked}
              >
                <span className="mr-2"><DownloadOutlined /></span>
                Download Template
              </button>
            </div>
          </div>
        )}
        {/* <div className="flex flex-col items-center justify-center h-[150px]">
          <div className="flex gap-8 px-2 w-fit mb-3"> */}

      </Modal>
    </div>
  );
};

export default UploadComponent2;
