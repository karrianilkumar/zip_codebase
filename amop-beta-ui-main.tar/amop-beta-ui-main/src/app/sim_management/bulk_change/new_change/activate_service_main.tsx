import { FC, forwardRef, useEffect, useImperativeHandle, useState } from "react";
import { Input, Button, Select, Checkbox, Modal, Spin, Tooltip } from "antd";
import ReactSelect from 'react-select';
import { ArrowLeftIcon, ArrowRightIcon, ChevronDownIcon } from "@heroicons/react/24/outline";
import SelectDevices from "./activate_new_select_devices";
import moment from "moment";
import { DatePicker } from "antd/lib";
import UploadComponent from "./upload_component";
import React from "react";
import ActivateSelectDevices from "./activate_new_select_devices";
import { useAuth } from "@/app/components/auth_context";
import { DropdownStyles } from "@/app/components/css/dropdown";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { useFeatureStore } from "../../inventory/featureStore";
import { useRouter } from 'next/navigation';
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { useAllChangeTypesStore } from "@/app/stores/allChangeTypesStore";
import { PerformanceLogStore } from "@/app/stores/performance_matrix_store";
import UploadComponent2 from "./upload_component_2";

interface Activated1Props {
    onContinue: () => void;
    onBack: () => void;
    dropdown: any;
    service_provider: any;
    change_type: any;
    activationData?: any;
    isSubmitScreen: boolean;
    onSave?: () => void;
    onClose: () => void;
    setIsCheckboxChecked?: (checked: boolean) => void;
}

export interface ActivateServiceContentRef {
  runValidation: () => Promise<void> | void;
  runSubmit: () => Promise<void> | void;
  returnUpdate: () => React.ReactNode | Promise<React.ReactNode>; 
}

const ActivateService = forwardRef<ActivateServiceContentRef, Activated1Props>(({ onContinue, onBack, dropdown, service_provider, change_type, activationData, isSubmitScreen, onSave, onClose ,setIsCheckboxChecked}, ref) => {
    const [dropdownData, setDropdownData] = useState<any>(dropdown || {});
    const [billingAccountNumber, setBillingAccountNumber] = useState<string | undefined>(undefined);
    const [ratePlanCode, setSelectedRatePlanCode] = useState<{ label: string, value: string } | null>(null);
    const [selectedFeatureCode, setSelectedFeatureCode] = useState<string[]>([]);
    const [ratePlanGroup, setSelectedRatePlanGroup] = useState<string>("");
    const [customerRatePlan, setCustomerRatePlan] = useState<string>("");
    const [customerRatePlanOptions, setCustomerRatePlanOptions] = useState<any>([]);
    const [city, setCity] = useState<string>("");
    const [streetName, setStreetName] = useState<string>("");
    const [streetNumber, setStreetNumber] = useState<any>("");

    const [streetDirection, setStreetDirection] = useState<string>("");

    const [selectedRatePool, setSelectedRatePool] = useState<string | undefined>(undefined);
    // const [staticIpAddress, setStaticIpAddress] = useState<string | undefined>("restricted");
    const [mdnZipCode, setMdnZipCode] = useState<string>("");
    const [selectedcustomer, setSelectedCustomer] = useState<string>("");
    const [showSelectDevices, setShowSelectDevices] = useState(false);
    const [isRedirected, setIsRedirected] = useState(false);
    const [errors, setErrors] = useState<{ [key: string]: string }>({});
    const [staticIpAddressCheckbox, setStaticIpAddressCheckbox] = useState<boolean>(false);
    const [subscribeFirstName, setSubscribeFirstName] = useState<string>("");
    const [subscribeLastName, setSubscribeLastName] = useState<string>("");
    const [zipCode, setZipCode] = useState<any | null>(null);
    const [ratePlanOptions, setRatePlanOptions] = useState<any>([]);
    const [featureCodeOptions, setFeatureCodeOptions] = useState<any>([]);
    const [ratePlanGroupOptions, setRatePlanGroupOptions] = useState<any>([]);
    const [ratePoolOptions, setRatePoolOptions] = useState<any>([]);
    const [assignCustomerOptions, setCustomerOptions] = useState<any>([]);
    const [pdpOptions, setPdpOptions] = useState<any>([]);
    const [apnOptions, setApnOptions] = useState<any>([]);
    const [selectedPDP, setSelectedPDP] = useState<string>("");
    const [selectedAPN, setSelectedAPN] = useState<string>("");
    const [LTEDevice, setLTEDevice] = useState(false);
    const [selectedState, setSelectedState] = useState<string>('');
    const [stateOptions, setStateOptions] = useState<any>([]);
    const [selectedStateCode, setSelectedStateCode] = useState("");

    const [applicableRatePlanForAll, setApplicableRatePlanForAll] = useState(true);
    const [isStaticIPChecked, setIsStaticIPChecked] = useState(false);
    const [qualicationToken, setQualificationToken] = useState<any>("");
    const { username, role, partner, token, selectedDb, metaData, firstLastName, sessionId, modulesVersionMap } = useAuth();
    const [loading, setLoading] = useState(false);
    const router = useRouter();
    const { setRowId, setBulkRow, activationPayload } = useFeatureStore();
    const initial_version_flag = modulesVersionMap?.["Sim Management-Bulk Change"] || false
    const isVersionEnabled = localStorage.getItem("switch_user_2_0_bulk_change") === "True";
    const switch_user_2_0 = isVersionEnabled && initial_version_flag ? "True" : "False"
    const { addExport, removeExport, exports } = exportLoadingStore();
    const { isAllChangeType, setIsValidated, setValidationTrigger,setsuccessFullChangeTypes, activeChange, successFullChangeTypes, allChangeTypesDevices, set_all_2_0_payloads } = useAllChangeTypesStore();
    const [saveChanges, setSaveChanges] = useState<boolean>(true);
    const [addressOptions, setAddressOptions] = useState<any[]>([]);
    const { getTargetTenantProvider, IsTargetTenantProvider } = PerformanceLogStore();
    const is_parent_provider_exists = IsTargetTenantProvider(service_provider)
    const [ isRedirectedFromSQ , setIsRedirectedFromSQ ] = useState(false)
    const [apnPdpMap, setApnPdpMap] = useState<any>({});
    
    useEffect(() => {
        if (activationData) {
            console.log("activationdata",activationData)
            // setQualificationToken(activationData[0]?.qualification_token || "")
            // setBillingAccountNumber(activationData?.billingAccountNumber || undefined);
            // setSelectedRatePlanCode(activationData?.ratePlanCode || null);
            // setSelectedFeatureCode(activationData?.featureCode || []);
            // setSelectedRatePlanGroup(activationData?.ratePlanGroup || "");
            // setCity(activationData?.city || "");
            // setStreetName(activationData?.street_name || "");
            // setStreetNumber(activationData?.street_number || "");
            // setStreetDirection(activationData?.streetDirection || "");
            // setSelectedRatePool(activationData?.ratePool || undefined);
            // setMdnZipCode(activationData?.mdnZipCode || "");
            // setSelectedCustomer(activationData?.customer || "");
            // setStaticIpAddressCheckbox(activationData?.staticIpAddressCheckbox || false);
            // setSubscribeFirstName(activationData?.subscribeFirstName || "");
            // setSubscribeLastName(activationData?.subscribeLastName || "");
            // setZipCode(activationData?.zip_code || null);
            // // setRatePlanOptions(activationData?.customer_rate_plan_dropdown || []);
            // setSelectedStateCode(activationData?.state || "");
            // // setStateOptions(activationData?.stateOptions || []);
            // setApplicableRatePlanForAll(
            //     activationData?.applicableRatePlanForAll !== undefined
            //         ? activationData?.applicableRatePlanForAll
            //         : true
            // );
            if(activationData?.length > 1){
                setIsRedirectedFromSQ(true)
            }
            else{
            setQualificationToken(activationData[0]?.qualification_token || "")
             setCity(activationData[0]?.city || "");
            setStreetName(activationData[0]?.street_name || "");
            setStreetNumber(activationData[0]?.street_number || "");
            setStreetDirection(activationData[0]?.streetDirection || "");
            setZipCode(activationData[0]?.zip_code || null);
            setSelectedStateCode(activationData[0]?.state || "");
            }
        }

    }, [activationData]);
    useEffect(() => {
    if (isRedirectedFromSQ && activationData?.length > 1) {
        const combinedAddresses = activationData.map((item: any) => ({
        label: `${item.street_number || ""}, ${item.street_name || ""}, ${item.city || ""}, ${item.state || ""}, ${item.zip_code || ""}, ${item.country || ""}`,
        value: item.street_number || "", // or item.id if preferred
        fullData: item, // keep entire record for auto-fill
        }));
        setAddressOptions(combinedAddresses);
    }
    }, [isRedirectedFromSQ, activationData]);


    useEffect(() => {
        console.log("isSubmitScreen", isSubmitScreen)
        console.log("isRedirected", isRedirected)
        console.log("condition", isSubmitScreen && !isRedirected)


        if (isSubmitScreen && !isRedirected && !isAllChangeType) {
            setShowSelectDevices(true)
        }
    }, [isSubmitScreen, isRedirected])

    useEffect(()=>{
        if(isAllChangeType){
            setDropdownData(dropdown)
        }
    },[dropdown,isAllChangeType])

    useEffect(() => {
        const rev_customer_dropdown = dropdownData?.rev_customer_dropdown || []
        setCustomerOptions(rev_customer_dropdown)

        const customer_rate_plan_group = dropdownData?.customer_rate_plan_group || []
        setRatePlanGroupOptions(customer_rate_plan_group)

        const customer_rate_pool_dropdown = dropdownData?.customer_rate_pool_dropdown || []
        setRatePoolOptions(customer_rate_pool_dropdown)

        const new_customer_rate_plan_dropdown = dropdownData?.carrier_rate_plan_dropdown || []
        // console.log("new_customer_rate_plan_dropdown",new_customer_rate_plan_dropdown)
        setCustomerRatePlanOptions(new_customer_rate_plan_dropdown)

        const features_codes = dropdownData?.features_codes || []
        setFeatureCodeOptions(features_codes)

        const state = dropdownData?.state || [];

        // Map state array to options with 'name' as label and 'code' as value
        const stateOptions = state.map((item: any) => ({
            label: item.name,  // Display state name in the dropdown
            value: item.code,  // Use state code as the value
        }));

        setStateOptions(stateOptions);
        // if (activationData) {
        //     setRatePlanOptions(activationData.customer_rate_plan_dropdown || []);
        // }
        // else {
            const customer_rate_plan_dropdown = dropdownData?.customer_rate_plan_dropdown || []
            setRatePlanOptions(customer_rate_plan_dropdown)

        // }



    }, [dropdownData]);
    const isAdmin = role?.toLowerCase() === "super admin" || role?.toLowerCase() === "partner admin"
    const staticAllowedRoles = role?.toLowerCase() === "super admin" || role?.toLowerCase() === "partner admin" || role?.toLowerCase() === "agent partner admin" || role?.toLowerCase() === "agent"

    // const fetchStaticOptions = async () => {
    //     try {
    //         const url =
    //             ENV_ROUTES.SIM_MANAGEMENT;
    //         const data = {
    //             tenant_name: partner || "default_value",
    //             path: "/get_static_ip_setting_values",
    //             request_received_at: getCurrentDateTime(),
    //             username: username,
    //             firstLastName: firstLastName,
    //             role_name: role,
    //             Partner: partner,
    //             access_token: token,
    //             db_name: selectedDb,
    //             ...metaData,
    //             sessionID: sessionId,
    //             service_provider: service_provider,
    //             ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
    //             change_type: change_type
    //         };

    //         const response = await axios.post(url, { data });
    //         const parsedData = JSON.parse(response.data.body);
    //         if (parsedData.flag === false) {
    //             Modal.error({
    //                 title: 'Data Fetch Error',
    //                 content: parsedData.message || 'An error occurred while fetching data. Please try again.',
    //                 centered: true,
    //             });
    //         } else {
    //             const pdpname_list = parsedData?.pdpname_list || [];
    //             setPdpOptions(pdpname_list)
    //             const selected_pdp = pdpname_list.length > 0 ? pdpname_list[0] : ""
    //             setSelectedPDP(selected_pdp)
    //             const static_ip_apn_list = parsedData?.static_ip_apn_list || [];
    //             setApnOptions(static_ip_apn_list)
    //             const selected_apn = static_ip_apn_list.length > 0 ? static_ip_apn_list[0] : ""
    //             setSelectedAPN(selected_apn)
    //         }
    //     } catch (error) {
    //         Modal.error({
    //             title: 'Data Fetch Error',
    //             content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
    //             centered: true,
    //         });
    //     }
    // };

    const fetchStaticOptions = async () => {
                try {
                    const url =
                        ENV_ROUTES.MODULE_MANAGEMENT;
                    const data = {
                        tenant_name: partner || "default_value",
                        path: "/get_private_network_pdp_apn_ip_mappings",
                        request_received_at: getCurrentDateTime(),
                        username: username,
                        firstLastName: firstLastName,
                        role_name: role,
                        Partner: partner,
                        access_token: token,
                        db_name: selectedDb,
                        ...metaData,
                        sessionID: sessionId,
                        service_provider: service_provider,
                        ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" },
                        change_type: change_type
                    };
    
                    const response = await axios.post(url, { data });
                    const parsedData = JSON.parse(response.data.body);
                    if (parsedData.flag === false) {
                        Modal.error({
                            title: 'Data Fetch Error',
                            content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                            centered: true,
                        });
                    } else {
                        const apn_pdp_map = parsedData?.apn_pdp_map || {};
                        setApnPdpMap(apn_pdp_map)
                        const apn_options = Object.keys(apn_pdp_map) || []
                        setApnOptions(apn_options)
                        const pdp_options = parsedData?.pdp || [];
                        // setPdpOptions(pdp_options)
                    }
                } catch (error) {
                    Modal.error({
                        title: 'Data Fetch Error',
                        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                        centered: true,
                    });
                }
            };

   const bulkChangeInsert = async (payload:any) => {
    let partner_name = partner
    let db_name_ = selectedDb
    try {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner_name || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_bulk_change_insertion",
        role_name: role,
        module_name: "Bulk Change History",
        service_provider_name:service_provider,
        ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
        change_type:change_type,
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
        request_received_at: getCurrentDateTime(),
        Partner: partner_name,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        console.error("Error fetching bulk change data:", parsedData.message ||
          "An error occurred while fetching bulk change data. Please try again.");
          return false
      } else {
        const statusFlag = parsedData?.bulk_change_data?.status || "";
        const response_data = parsedData?.bulk_change_data?.bulk_change_data || "{}";
        const parsedResp = JSON.parse(response_data)
        console.log("status_flag", statusFlag)
        const status_flag = statusFlag ? (statusFlag).toLowerCase() : ""

        if(status_flag && status_flag==="pending"){
          return false
        }
        else if (status_flag && status_flag==="success"){
            call_2_0_submit(parsedResp, payload,true)
            call_2_0_sync(parsedResp)
            return true
        }
        else if (status_flag && status_flag==="error"){
            Modal.error({
                title: 'Submit Error',
                content: parsedData.message || 'An error occurred while submitting. Please try again.',
                centered: true,
            });
            return true
        }
        else{
          return false
        }
      }
    } catch (error) {
      console.error("Error fetching auto refresh data:", error);
      return false
    } finally {
    }
  };
  const bulkChangePolling = async (data:any) => {
    const result = await bulkChangeInsert(data);
    if (!result) {
      setTimeout(() => bulkChangePolling(data), 5000); // Try again after 5 seconds
    } else {
      removeExport("bulkChangeInsert");
      console.log("Auto-refresh complete.");
    }
    // if (window.location.pathname.includes("/sim_management/bulk_change")) {
    //     window.location.reload();
    // }
  };

    const onsubmit = async (payload: { iccids: any; imeis: any; iccid_ip_map?:any}) => {

        const returnChangedData_ = returnChangedData()

        const changed_data: any = {
            ...returnChangedData_,
            ApplicableRatePlanForAll: applicableRatePlanForAll,
            // RatePlanCodeList: ratePlanOptions, // assuming ratePlanOptions is the list of rate plan codes
        }
        let data: any
        try {
            const assignCustomer = changed_data["assign_customer"] || null
            const assignCustomerParts = assignCustomer ? assignCustomer.split("--") : []
            console.log("assignCustomer", assignCustomer)
            delete changed_data?.assign_customer
            const changedData = changed_data ? changed_data : {};
            console.log("ratePlanCode", ratePlanCode)

            const ratePlanCodeLabel_ = ratePlanCode?.label || ratePlanCode || null
            setLoading(true);

            const url = ENV_ROUTES.SIM_MANAGEMENT;

            // Prepare the data object for the initial request
            data = {
                tenant_name: partner || "default_value",
                path: "/update_bulk_change_data", // This path is used for the first request
                role_name: role,
                username: username,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: service_provider,
                ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type,
                created_by: firstLastName,
                customer_name: assignCustomer ? assignCustomerParts[0].trim() : null,
                customer_id: assignCustomer ? assignCustomerParts[1].trim() : null,
                customer_rate_plan_name_update:ratePlanCodeLabel_,
                changed_data: {
                    ...changedData
                },
                Devices: payload.iccids,
                iccids: payload.iccids,
                imei: payload.imeis,
                ...(payload?.iccid_ip_map &&
                Object.keys(payload.iccid_ip_map).length > 0
                ? { iccid_ip_map: payload.iccid_ip_map }
                : {}
            )
            };

            console.log("Initial Data", data);

            // Send the initial request
            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === false) {
                setLoading(false);
                Modal.error({
                    title: 'Submit Error',
                    content: parsedData.message || 'An error occurred while updating data. Please try again.',
                    centered: true,
                });
            } else {
                console.log("Initial request successful:", parsedData);

                // Navigate to the bulk history page
                const bulkrow_ = parsedData?.bulkchange_id || {};
                const bulkRow: any = { row: bulkrow_ };
                setBulkRow(bulkRow);
                localStorage.setItem('bulk_row', JSON.stringify(bulkRow || "{}"));
                if(!isAllChangeType){
                    router.push(`/sim_management/bulk_history`);
                }

                // Call the run_db_script without waiting for the response
                if (switch_user_2_0 === "True") {
                    if (!isAllChangeType) {
                        call_2_0_submit(parsedData, data, true);
                        call_2_0_sync(parsedData);
                    }
                    else {
                        const payload_2_0_: any = await call_2_0_submit(parsedData, data, false)
                        set_all_2_0_payloads((prev: any) => ({
                            ...prev,
                            [change_type]: { ...payload_2_0_ }
                        }));
                    }

                }
                else {
                    callRunDbScript(parsedData);
                }
            }
        } catch (error) {
             if (switch_user_2_0 === "True") {
                onClose()
                setLoading(false)
                addExport("bulkChangeInsert", "Bulk Change Submission");
                bulkChangePolling(data)
            }
            else {
                Modal.error({
                    title: 'Submit Error',
                    content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting. Please try again.',
                    centered: true,
                });
            }
        } finally {
            setLoading(false);
        }
    };

    const fetchCarrierWritesFlag = async () => {
    let parsedData: any
    const url = ENV_ROUTES.SIM_MANAGEMENT;
    const data = {
      tenant_name: partner || "default_value",
      username,
      path: "/get_writes_enable_for_service_provider",
      role_name: role,
      parent_module: "Sim Management",
      module_name: "Inventory",
      service_provider: service_provider || "",
      ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
                ...metaData,
      sessionID: sessionId,
      environment: "BETA",
      change_type: change_type,
    };

    try {
      setLoading(true);
      const response = await axios.post(url, { data });
      parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === true) {
        const write_is_enabled = parsedData?.write_is_enabled || false;
        // setWritesFlag(write_is_enabled);
        return write_is_enabled;
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      return false; // fallback in case of error
    } finally {
      setLoading(false);
    }
  };
  const submitCarrierStatus = async (payload: { iccids: any; imeis: any; },write_is_enabled:boolean) => {
    let parsedData: any
    const url = ENV_ROUTES.SIM_MANAGEMENT;
    const data = {
      tenant_name: partner || "default_value",
      username,
      path: "/insert_carrier_status_validation_audit",
      role_name: role,
      parent_module: "Sim Management",
      module_name: "Inventory",
      service_provider: service_provider || "",
      ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
                ...metaData,
      sessionID: sessionId,
      environment: "BETA",
      msisdn:[],
      iccid: payload?.iccids,
      change_type: change_type,
      write_is_enabled:write_is_enabled,
    };

    try {
      // setLoading(true);
      const response = await axios.post(url, { data });
      parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === true) {

      }
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      // setLoading(false);
    }
  };

    const call_2_0_submit = async (parsedData: any , payload:any,isRouteCall: boolean) => {
        try {
            const url = ENV_ROUTES.BULKCHANGE_PROCESSOR;
            const prevChangedData = payload?.changed_data || {}
            delete payload["imeids"]
            
            const payloadData={
                ...payload , 
                path:"/bulk_change_processor",
                request_received_at:getCurrentDateTime(),
                bulk_change_id:parsedData?.bulk_chnage_id_20,
            }
            const data = {...payloadData};
            if (!isRouteCall) {
              return data
            }
            const response = await axios.post(url, { data });
            const responseData = JSON.parse(response.data.body);
            if (responseData.flag === false) {
               console.log("Failure: 2.0 Bulk change update failed.");
            } else {
                console.log("Success: 2.0 Bulk change update successful.");
        }
    }
        catch (error) {
            console.error("Error running DB script:", error);
        } finally {
            setLoading(false);
        }
    }
  const call_2_0_sync = async (parsedData: any) => {
        try {
            const runDbScriptUrl = ENV_ROUTES.SIM_MANAGEMENT;
            const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
            const runDbScriptData = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/update_bulk_change_tables_10",
                role_name: role,
                module_name: "Bulk Change",
                access_token: token,
                db_name: selectedDb,
                sessionID: sessionId,
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                // service_provider_id: service_provider_id_,
                // bulkchange_id: parsedData?.bulkchange_id?.id,
                // data: parsedData?.data,
                data:{
                    bulk_change_id: parsedData?.bulk_chnage_id_20,
                },
                is_update: false,
                // bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
            };

            const runDbScriptResponse = await axios.post(runDbScriptUrl, { data: runDbScriptData });
            const runDbScriptResponseData = JSON.parse(runDbScriptResponse.data.body);

            if (runDbScriptResponseData.flag === false) {
                console.error("Data Fetch Error: " + runDbScriptResponseData.message);
            } else {
                console.log("Success: Bulk update successful.");
            }
        }
        catch (error) {
            console.error("Error running DB script:", error);
        } finally {
            setLoading(false);
        }
    }

    const callRunDbScript = async (parsedData: any) => {
        try {
            const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
            const runDbData = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/run_db_script", // Always use this path
                role_name: role,
                module_name: "Bulk Change",
                mod_pages: {
                    start: 0,
                    end: 100,
                },
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                service_provider_id: service_provider_id_,
                bulkchange_id: parsedData?.bulkchange_id?.id,
                data: parsedData?.data,
                bulk_chnage_id_20: parsedData?.bulk_chnage_id_20
            };

            console.log("Run DB Data", runDbData);

            // Send the second request
            await axios.post(ENV_ROUTES.SIM_MANAGEMENT, { data: runDbData });
            console.log("Run DB script executed successfully.");
        } catch (error) {
            console.error("Error executing run_db_script:", error);
            // Optionally handle the error here, e.g., show a notification
        }
    };

    const handleContinue = async() => {
        const newErrors: { [key: string]: string } = {};

        // Check for errors in the required fields
        if (!billingAccountNumber && isAdmin) newErrors.billingAccountNumber = "Billing account number is required.";
        if (!subscribeFirstName) newErrors.subscribeFirstName = "Subscribe first name is required.";
        if (!subscribeLastName) newErrors.subscribeLastName = "Subscribe last name is required.";
        if (!streetNumber) newErrors.streetNumber = "Street number is required.";
        if (!streetName) newErrors.streetName = "Street name is required.";
        if (!city) newErrors.city = "City is required.";
        if (!zipCode) newErrors.zipCode = "Zip code is required.";
        if (zipCode) {
            const regex = /^\d{5}$/; // Only 5 numerical values

            if (!regex.test(zipCode)) {
                newErrors.zipCode = "Zip code must be exactly 5 digits."
            }
        }
        // Additional validations can be added here if needed
        const ratePlanError_ = isAdmin ? "Rate plan code is required." : "Customer Rate Plan is required."
        if (!ratePlanCode) newErrors.ratePlanCode = ratePlanError_;
        // if (staticIpAddressCheckbox) newErrors.staticIpAddress = "Static IP Address is required.";
        if (!selectedStateCode) {
            newErrors.state = "State is required.";
        }
        // If there are errors, set them in the state; otherwise, proceed
        if (Object.keys(newErrors).length > 0) {
            if (isAllChangeType) {
                setsuccessFullChangeTypes(
                    successFullChangeTypes.filter((c: any) => c !== activeChange)
                );
                if ((!billingAccountNumber && !ratePlanCode && selectedFeatureCode && selectedFeatureCode.length === 0 &&!ratePlanGroup && !city && !streetName && !streetNumber && !streetDirection && !selectedRatePool && !selectedcustomer && !subscribeFirstName && !subscribeLastName && !zipCode && !selectedPDP && !selectedAPN && !LTEDevice && !selectedStateCode) || !saveChanges) {
                    setIsValidated(true)
                    setValidationTrigger();
                    setErrors({});
                }
                else{
                    setIsValidated(false)
                    setErrors(newErrors);
                    setValidationTrigger();
                }

            }else{
                setErrors(newErrors);
            }
            
            
        } else {
            if(saveChanges){
                setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
            }
            setIsValidated(true)
            setValidationTrigger()
            setErrors({});
            // setShowSelectDevices(true);
            // if (staticIpAddressCheckbox) {
            //     fetchStaticOptions()
            //     setIsStaticIPChecked(true)
            // }
            // else {
                if(!isAllChangeType){
                    if (isSubmitScreen) {
                    const writes_flag = await fetchCarrierWritesFlag()
      
          if (writes_flag) {
                const modal = Modal.confirm({
                  title: "Carrier API Enabled",
                  content: "Carrier API settings are enabled. Submitting now will trigger the Carrier API directly. Do you want to proceed?",
                  centered: true,
                  okText: "Submit",
                  onOk: () => {
                    // modal.destroy(); // closes the modal
                    // handleCloseModal();
                    
                    onsubmit(activationPayload);
                    submitCarrierStatus(activationPayload,writes_flag);
                  },
                  onCancel: () => {
                            setShowSelectDevices(false)
                            setIsRedirected(true)
                        },
                });
              }
              else{
                onsubmit(activationPayload);
              }
                    // onsubmit(activationPayload)
                }
                else {
                    setShowSelectDevices(true);
                }
                }
                

            // }
        }
    };

    const handleStaticIPContinue = () => {
        const newErrors: { [key: string]: string } = {};

        // Check for errors in the required fields
        if (!selectedPDP) newErrors.pdp = "PDP Name is required.";
        if (!selectedAPN) newErrors.apn = "Static IP APN is required.";

        if (Object.keys(newErrors).length > 0) {
            setErrors(newErrors);
        } else {
            setErrors({});
            setShowSelectDevices(true);
        }
    };

    const onStaticIPBack = () => {
        setIsStaticIPChecked(false)
    }
    const handleSelectedRatePlanChange = (selectedOption: any) => {
        console.log("selected...", selectedOption); // will now log { label, value }
        if (selectedOption) {
            setSelectedRatePlanCode(selectedOption);
        }
    };
    const handleSelectedFeatureChange = (values: string[]) => {
        setSelectedFeatureCode(values);
    };

    const handleRatePlanChange = (selectedOption: any) => {
        if (selectedOption) {
            const value = selectedOption
            setSelectedRatePlanGroup(value)
        }
    }

    const handleCustomerRatePlanChange = (selectedOption: any) => {
        if (selectedOption) {
            const value = selectedOption
            setCustomerRatePlan(value)
        }
        else{
            setCustomerRatePlan("")
        }
    }

    const handleRatePoolChange = (selectedOption: any) => {
        if (selectedOption) {
            const value = selectedOption
            setSelectedRatePool(value)
        }
    }
    const handleSelectedCustomerChange = (selectedOption: any) => {
        console.log("rate plan code", ratePlanCode)
        if (selectedOption) {
            const value = selectedOption
            setSelectedCustomer(value)
        }
    }
    const handleSelectedPDPChange = (selectedOption: any) => {
        console.log("selected PDP", selectedOption)
        if (selectedOption) {
            const value = selectedOption
            setSelectedPDP(value)
        }
    }

    const handleSelectedAPNChange = (selectedOption: any) => {
            setSelectedPDP("")
            if (selectedOption) {
                const value = selectedOption
                setSelectedAPN(value)
                const pdp_options = apnPdpMap[value] || []
                setPdpOptions(pdp_options)
            }
            else {
                setSelectedAPN("")
                setPdpOptions([])
            }
        };
        
    // const handleSelectedAPNChange = (selectedOption: any) => {
    //     console.log("selected APN", selectedOption)
    //     if (selectedOption) {
    //         const value = selectedOption
    //         setSelectedAPN(value)
    //     }
    // }
    // const handleSelectedStateChange = (selectedOption: any) => {
    //     if (selectedOption) {
    //         const value = selectedOption
    //         setSelectedState(value);
    //     }
    // };
    
    const handleSelectedStateChange = (value: any , option:any) => {
        // 'value' is the state code, so set it to selectedStateCode
         setSelectedState(option.label); 
        setSelectedStateCode(value);
    };
    const handleBack = () => {
        setShowSelectDevices(false);
    };
    const returnChangedData = () => {
        const ratePlanCode_ = ratePlanCode?.value || ratePlanCode || null
        const changedData = {
            assign_customer: selectedcustomer || null,
            TelegenceActivationRequest: {
                billingAccount: {
                    id: isAdmin ? billingAccountNumber : dropdownData?.user_billing_account_number || "287256845357"
                },
                relatedParty: [
                    {
                        id: "",
                        role: "subscriber",
                        firstName: subscribeFirstName || "",
                        lastName: subscribeLastName || "",
                        address: {
                            streetNumber: streetNumber || "",
                            streetDirection: streetDirection || "",
                            streetName: streetName || "",
                            streetType: "",
                            city: city || "",
                            state: selectedStateCode || "",
                            zipCode: zipCode || ""
                        }
                    }
                ],
                service: {
                    category: {
                        id: "",
                        name: ""
                    },
                    name: "",
                    serviceSpecification: {
                        id: "12",
                        href: "Mobility Services"
                    },
                    serviceQualification: {},
                    serviceCharacteristic: [
                        { name: "serviceZipCode", value: zipCode },
                        { name: "singleUserCode", value: null },
                        { name: "equipmentType", value: "G" },
                        { name: "deviceTechnologyType", value: "UMTS" },
                        { name: "IMEI", value: "" },
                        { name: "sim", value: "" },
                        // Add offeringCode entries from selectedFeatureCode
                        ...(selectedFeatureCode && selectedFeatureCode.length>0 ?
                        selectedFeatureCode.map((fullValue, index) => {
                            const parts = fullValue.split('--');
                            const code = parts.length > 1 ? parts[1].trim() : fullValue.trim(); // fallback to fullValue if '--' is missing

                            return {
                                name: `offeringCode${index + 1}`,
                                value: code,
                            };
                        }):[]),

                    ],
                    status: "",
                    subscriberNumber: ""
                }
            },
            CarrierDataGroup: "",
            CarrierRatePool: selectedRatePool && selectedRatePool !== 'No options' ? selectedRatePool : "",
            AddCustomerRatePlan: false,
            CustomerRatePlan: typeof ratePlanCode_ === "string" && !ratePlanCode_.startsWith("missing-code") ? ratePlanCode_ : null,
            CustomerRatePlanId: customerRatePlan && customerRatePlan !== 'No options' ? customerRatePlan : "",
            // CustomerRatePool: selectedRatePool && selectedRatePool !== 'No options' ? selectedRatePool : null,
            ...staticIpAddressCheckbox ? {
                StaticIPProvision: {
                    PDPName: selectedPDP || null,
                    IPAddressCode: "T01", // Defaulted to T01
                    LteIndicator: LTEDevice,
                    DefaultAPN: false, //Defaulted to false
                    StaticIPAPN: selectedAPN || null
                }
            } : { StaticIPProvision: null }

        }
        return changedData
    };
    
    const AllChangeTypeSubmit = () => {
        const payload_: any = {
            iccids: allChangeTypesDevices?.iccids || [],
            imeis: allChangeTypesDevices?.imeids || [],
            ...(allChangeTypesDevices?.iccid_ip_map &&
                Object.keys(allChangeTypesDevices.iccid_ip_map).length > 0
                ? { iccid_ip_map: allChangeTypesDevices.iccid_ip_map }
                : {}),

        }
        onsubmit(payload_)
    }


    const returnUpdatedValue = () => {
        const devices = allChangeTypesDevices?.iccids
        const newValue: any = {
            "firstName": subscribeFirstName,
            "lastName": subscribeLastName,
            "streetNumber": streetNumber,
            "streetName": streetName,
            "streetDirection": streetDirection,
            "city": city,
            "state": selectedState,
            "zipCode": zipCode,
        }
        const displayOrder = [
            "firstName",
            "lastName",
            "streetNumber",
            "streetName",
            "streetDirection",
            "city",
            "state",
            "zipCode",
        ];
        const tooltipContent = (
            <div style={{ padding: "4px 8px" }}>
                {displayOrder.map((key) => (
                    <div key={key} style={{ display: "flex", marginBottom: 2 }}>
                        <strong style={{ marginRight: 6, textTransform: "capitalize" }}>
                            {key.replace(/([A-Z])/g, " $1").trim()}&nbsp;&nbsp;:&nbsp;
                        </strong>
                        <span>
                            {newValue[key] !== undefined && newValue[key] !== ""
                                ? String(newValue[key])
                                : "N/A"}
                        </span>
                    </div>
                ))}
            </div>
        );
        return (
            <div className="flex flex-col gap-2">
                <div className="flex grid grid-cols-2 ">
                    <span className="font-semibold">Billing Account Number:</span>
                    <span>{billingAccountNumber}</span>
                    <span className="font-semibold">Rate Plan Code:</span>
                    <span>{ratePlanCode && ratePlanCode?.value ? ratePlanCode?.value : ""}</span>
                </div>
                <div className="flex justify-start"> {/* Center horizontally */}
                    <Tooltip title={tooltipContent}>
                        <span className="cursor-pointer font-semibold">Address Details</span>
                    </Tooltip>
                </div>
            </div>
        )
    }
    useImperativeHandle(ref, () => ({
        runValidation: handleContinue,
        runSubmit: AllChangeTypeSubmit,
        returnUpdate: returnUpdatedValue
    }));

    if (loading) {
        return (
            <div className="flex justify-center items-center h-[400px]">
                <Spin size="large" />
            </div>
        );
    }

    return (
        <div className="ActiveNewService px-3">
            {!showSelectDevices ? (
                <>
                    <div className="flex justify-end space-x-4 px-4">
                        {isAllChangeType && (
                            <div className="mt-3">
                                <span className="mr-2 font-semibold">Save Changes</span>
                                <Checkbox
                                    checked={saveChanges}
                                    onChange={(e) => {
                                        if (!e.target.checked) {
                                            setsuccessFullChangeTypes(
                                                successFullChangeTypes.filter((c: any) => c !== activeChange)
                                            );
                                        }
                                        setSaveChanges(e.target.checked)
                                    }}
                                    className="custom-checkbox"
                                >

                                </Checkbox>
                            </div>
                            
                        )}
                        {!isAllChangeType && (
                            switch_user_2_0 === "True" ? (
                                <UploadComponent2
                                    service_provider={service_provider}
                                    change_type={change_type}
                                    changed_data={{
                                        ...returnChangedData(),
                                        ApplicableRatePlanForAll: applicableRatePlanForAll
                                    }} />
                            ) : (
                                <UploadComponent
                                    service_provider={service_provider}
                                    change_type={change_type}
                                    changed_data={{
                                        ...returnChangedData(),
                                    }} />
                            )
                        )}
                       
                    </div>
                    <div className={`${!isAllChangeType?"flex flex-col space-y-4 my-4":"flex grid grid-cols-2 gap-4"}`}>
                        {<>
                            {isAdmin &&
                                <>
                                    {/* Billing Account Number */}
                                    <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                        <label htmlFor="billingAccountNumber" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                            Billing Account Number<span className="text-red-500">*</span>
                                        </label>
                                        <Input
                                            id="billingAccountNumber"
                                            // placeholder="Enter Billing Account Number"
                                            value={billingAccountNumber}
                                            onChange={(e) => setBillingAccountNumber(e.target.value)}
                                            className={`${!isAllChangeType?"w-2/3 ActiveServiceinput":"input"}`} />
                                            {(errors.billingAccountNumber && isAllChangeType) && <span className="text-red-500">{errors.billingAccountNumber}</span>}
                                    </div>
                                    {(errors.billingAccountNumber && !isAllChangeType) && <div className="text-red-500">{errors.billingAccountNumber}</div>}
                                </>}
                            <>
                                {/* Rate Plan Code */}
                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="ratePlanCode" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        {isAdmin ? "Rate Plan Code" : "Customer Rate Plan"}<span className="text-red-500">*</span>
                                    </label>
                                    <Select
                                    labelInValue
                                        showSearch
                                        value={
                                            ratePlanCode?.value === 'No options'
                                                ? null
                                                : ratePlanCode // Now this will always be in { label, value } format
                                        }
                                        id="ratePlanCode"
                                        placeholder={isAdmin ? 'Select Rate Plan Code' : 'Select Customer Rate Plan'}
                                        options={
                                            ratePlanOptions.length > 0
                                                ? ratePlanOptions.map((option: any, index: number) => {
                                                    if (isAdmin) {
                                                        return {
                                                            label: option,
                                                            value: option, // keep it same, but now it's wrapped in an object
                                                            key:`${option}-${index}`,
                                                        };
                                                    } else {
                                                        return {
                                                            label: option.rate_plan || `Unnamed Plan ${index}`,
                                                            value: option.code ?? `missing-code-${index}`,
                                                            key:`${option.code}-${index}`,
                                                        };
                                                    }
                                                })
                                                : [{ value: 'No options', label: 'No options' }]
                                        }
                                        onChange={handleSelectedRatePlanChange}
                                        suffixIcon={<ChevronDownIcon className="w-4 h-4 text-gray-600 arrow " />}
                                        className={`${!isAllChangeType?"w-2/3 mb-2":"w-full mb-3"}`}
                                    />
                                    {(errors.ratePlanCode && isAllChangeType) && <span className="text-red-500">{errors.ratePlanCode}</span>}
                                </div>
                                {(errors.ratePlanCode && !isAllChangeType) && <div className="text-red-500">{errors.ratePlanCode}</div>}

                                {/*Customer Rate Plan*/}
                                {isAdmin && (
                                    <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                        <label htmlFor="customerRatePlan" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                            Customer Rate Plan
                                        </label>
                                        <Select
                                            allowClear
                                            showSearch
                                            value={customerRatePlan === 'No options' ? null : { label: customerRatePlan, value: customerRatePlan }}
                                            id="customerRatePlan"
                                            placeholder="Select Customer Rate Plan"
                                            options={customerRatePlanOptions.length > 0 ? customerRatePlanOptions.map((option: string) => ({
                                                label: option,
                                                value: option,
                                            })) : [{ value: 'No options', label: 'No options' }]}
                                            onChange={handleCustomerRatePlanChange}
                                            suffixIcon={
                                                <ChevronDownIcon className="w-4 h-4 text-gray-600 arrow " />
                                            }
                                            // className="w-2/3 mt-1 mb-2"
                                            className={`custom-clear-select ${!isAllChangeType?"w-2/3 mt-1 mb-2":"w-full"}`} />
                                    </div>
                                )}
                                
                            </>

                            {/* Feature Codes */}
                            <div className={`${!isAllChangeType ? "flex items-center space-x-4 mt-3":""}`}>
                                <label htmlFor="featureCodes" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                    Feature Codes
                                </label>
                                <ReactSelect
                                    isMulti
                                    value={selectedFeatureCode.map((code) => ({
                                        label: code,
                                        value: code,
                                    }))}
                                    onChange={(selectedOptions) => {
                                        setSelectedFeatureCode(selectedOptions.map((opt) => opt.value));
                                    }}
                                    options={
                                        featureCodeOptions.length > 0
                                            ? featureCodeOptions.map((option: any) => ({
                                                label: option,
                                                value: option,
                                            }))
                                            : [{ label: 'No options', value: 'No options' }]
                                    }
                                    // className="w-2/3 mt-1 mb-2"
                                    className={`${!isAllChangeType?"w-2/3 mt-1 mb-2":"w-full"}`}
                                    styles={DropdownStyles}
                                />
                                {(errors.featureCodes && isAllChangeType) && <span className="text-red-500">{errors.featureCodes}</span>}
                            </div>
                            {(errors.featureCodes && !isAllChangeType) && <div className="text-red-500">{errors.featureCodes}</div>}

                            {isAdmin &&
                                <>
                                    {/* Rate Plan Group */}
                                    <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                        <label htmlFor="ratePlanGroup" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                            Rate Plan Group
                                        </label>
                                        <Select
                                            showSearch
                                            value={ratePlanGroup === 'No options' ? null : { label: ratePlanGroup, value: ratePlanGroup }}
                                            id="ratePlanGroup"
                                            // placeholder="Select Rate Plan Group"
                                            options={ratePlanGroupOptions.length > 0 ? ratePlanGroupOptions.map((option: string) => ({
                                                label: option,
                                                value: option,
                                            })) : [{ value: 'No options', label: 'No options' }]}
                                            onChange={handleRatePlanChange}
                                            suffixIcon={
                                                <ChevronDownIcon className="w-4 h-4 text-gray-600 arrow " />
                                            }
                                            // className="w-2/3 mt-1 mb-2"
                                            className={`${!isAllChangeType?"w-2/3 mt-1 mb-2":"w-full"}`} />
                                            {(errors.ratePlanGroup && isAllChangeType) && <span className="text-red-500">{errors.ratePlanGroup}</span>}
                                    </div>
                                    {(errors.ratePlanGroup && !isAllChangeType) && <div className="text-red-500">{errors.ratePlanGroup}</div>}

                                    {/* Rate Pool */}
                                    <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                        <label htmlFor="ratePool" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                            Rate Pool
                                        </label>
                                        <Select
                                            showSearch
                                            value={selectedRatePool === 'No options' ? null : { label: selectedRatePool, value: selectedRatePool }}
                                            id="ratePool"
                                            // placeholder="Select Rate Pool"
                                            options={ratePoolOptions.length > 0 ? ratePoolOptions.map((option: string) => ({
                                                label: option,
                                                value: option,
                                            })) : [{ value: 'No options', label: 'No options' }]}
                                            onChange={handleRatePoolChange}
                                            suffixIcon={
                                                <ChevronDownIcon className="w-4 h-4 text-gray-600 arrow " />
                                            }
                                            // className="w-2/3 mt-1 mb-2" 
                                            className={`${!isAllChangeType?"w-2/3 mt-1 mb-2":"w-full"}`}/>
                                            {(errors.ratePool && isAllChangeType) && <span className="text-red-500">{errors.ratePool}</span>}
                                    </div>
                                    {(errors.ratePool && !isAllChangeType) && <div className="text-red-500">{errors.ratePool}</div>}
                                </>
                            }

                            {/* Assign Customer */}
                            <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                <label htmlFor="assignCustomer" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                    Assign Customer
                                </label>
                                <Select
                                    value={selectedcustomer === 'No options' ? null : { label: selectedcustomer, value: selectedcustomer }}
                                    showSearch
                                    id="assignCustomer"
                                    // placeholder="Select Customer"
                                    options={assignCustomerOptions.length > 0 ? assignCustomerOptions.map((option: string) => ({
                                        label: option,
                                        value: option,
                                    })) : [{ value: 'No options', label: 'No options' }]}
                                    onChange={handleSelectedCustomerChange}
                                    suffixIcon={
                                        <ChevronDownIcon className="w-4 h-4 text-gray-600 arrow " />
                                    }
                                    // className="w-2/3 mt-1 mb-2 " 
                                    className={`${!isAllChangeType?"w-2/3 mt-1 mb-2":"w-full"}`}/>
                                    {(errors.assignCustomer && isAllChangeType) && <span className="text-red-500">{errors.assignCustomer}</span>}
                            </div>
                            {(errors.assignCustomer && !isAllChangeType) && <div className="text-red-500">{errors.assignCustomer}</div>}

                            {/* Static IP Address */}
                            {staticAllowedRoles &&
                                <>
                                    <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                        <label htmlFor="staticIpAddress" className={`${!isAllChangeType?"w-1/3 font-semibold mt-3":"field-label"}`}>
                                            Private Statics IP address
                                        </label>
                                        <input
                                            id="staticIpAddressCheckbox"
                                            type="checkbox"
                                            checked={staticIpAddressCheckbox}
                                            onChange={(e) => {
                                                setStaticIpAddressCheckbox(e.target.checked)
                                                setIsCheckboxChecked?.(e.target.checked)
                                                fetchStaticOptions()
                                            }}
                                            className="ml-2 ActiveServiceinput" />
                                    </div>
                                    {errors.staticIpAddress && <div className="text-red-500">{errors.staticIpAddress}</div>}

                                    {/* {(staticIpAddressCheckbox) && ( */}
                                    {/* <> */}

                                    {/* Static IP APN
                                        <div className={`${!isAllChangeType ? "flex items-center space-x-4" : ""}`}>
                                            <label htmlFor="apn" className={`${!isAllChangeType ? "w-1/3 font-semibold" : "field-label"}`}>
                                                Private Static APN<span className="text-red-500">*</span>
                                            </label>
                                            <Select
                                                value={selectedAPN === 'No options' ? null : { label: selectedAPN, value: selectedAPN }}
                                                showSearch
                                                id="apn"
                                                // placeholder="Select Customer"
                                                options={apnOptions.length > 0 ? apnOptions.map((option: string) => ({
                                                    label: option,
                                                    value: option,
                                                })) : [{ value: 'No options', label: 'No options' }]}
                                                onChange={handleSelectedAPNChange}
                                                suffixIcon={
                                                    <ChevronDownIcon className="w-4 h-4 text-gray-600 arrow " />
                                                }
                                                // className="w-2/3 mt-1 mb-2 " 
                                                className={`${!isAllChangeType ? "w-2/3 mt-1 mb-2 " : "w-full"}`} />
                                        </div>
                                        {errors.apn && <div className="text-red-500">{errors.apn}</div>}
                                        PDP Name
                                        <div className={`${!isAllChangeType ? "flex items-center space-x-4" : ""}`}>
                                            <label htmlFor="pdpName" className={`${!isAllChangeType ? "w-1/3 font-semibold" : "field-label"}`}>
                                                PDP Name<span className="text-red-500">*</span>
                                            </label>
                                            <Select
                                                value={selectedPDP === 'No options' ? null : { label: selectedPDP, value: selectedPDP }}
                                                showSearch
                                                id="pdpName"
                                                // placeholder="Select Customer"
                                                options={pdpOptions.length > 0 ? pdpOptions.map((option: string) => ({
                                                    label: option,
                                                    value: option,
                                                })) : [{ value: 'No options', label: 'No options' }]}
                                                onChange={handleSelectedPDPChange}
                                                suffixIcon={
                                                    <ChevronDownIcon className="w-4 h-4 text-gray-600 arrow " />
                                                }
                                                // className="w-2/3 mt-1 mb-2 " 
                                                className={`${!isAllChangeType ? "w-2/3 mt-1 mb-2 " : "w-full"}`} />
                                        </div>
                                        {errors.pdp && <div className="text-red-500">{errors.pdp}</div>}

                                         */}

                                        {/* <div className={`${!isAllChangeType ? "flex items-center space-x-4" : ""}`}>
                                            <label htmlFor="lte" className={`${!isAllChangeType ? "w-1/3 font-semibold" : "field-label"}`}>
                                                LTE Device?
                                            </label>
                                            <Checkbox
                                                id="lte"
                                                checked={LTEDevice}
                                                onChange={(e) => setLTEDevice(e.target.checked)}
                                            />
                                        </div> */}
                                    {/* </> */}
                                    {/* ) } */}
                                </>
                            }


                            {/* Subscribe First Name */}
                            <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                <label htmlFor="subscribeFirstName" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                    Subscriber First Name<span className="text-red-500">*</span>
                                </label>
                                <Input
                                    id="subscribeFirstName"
                                    // placeholder="Enter First Name"
                                    value={subscribeFirstName}
                                    onChange={(e) => setSubscribeFirstName(e.target.value)}
                                    // className="w-2/3 ActiveServiceinput" 
                                    className={`${!isAllChangeType?"w-2/3 ActiveServiceinput":"input"}`}/>
                                    {(errors.subscribeFirstName && isAllChangeType) && <span className="text-red-500">{errors.subscribeFirstName}</span>}
                            </div>
                            {(errors.subscribeFirstName && !isAllChangeType) && <div className="text-red-500">{errors.subscribeFirstName}</div>}

                            {/* Subscribe Last Name */}
                            <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                <label htmlFor="subscribeLastName" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                    Subscriber Last Name<span className="text-red-500">*</span>
                                </label>
                                <Input
                                    id="subscribeLastName"
                                    // placeholder="Enter Last Name"
                                    value={subscribeLastName}
                                    onChange={(e) => setSubscribeLastName(e.target.value)}
                                    // className="w-2/3 ActiveServiceinput" 
                                    className={`${!isAllChangeType?"w-2/3 ActiveServiceinput":"input"}`}/>
                                    {(errors.subscribeLastName && isAllChangeType) && <span className="text-red-500">{errors.subscribeLastName}</span>}
                            </div>
                            {(errors.subscribeLastName && !isAllChangeType) && <div className="text-red-500">{errors.subscribeLastName}</div>}

                            {/* Street Number */}
                            <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                <label htmlFor="streetNumber" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                    Street Number<span className="text-red-500">*</span>
                                </label>
                                {isRedirectedFromSQ ? (
                                    <>
                                    <Select
                                        id="streetNumber"
                                        className={`${!isAllChangeType?"w-[295px] mb-2":"w-full mb-3"}`}
                                        value={streetNumber}
                                        onChange={(value, option: any) => {
                                            setStreetNumber(value);
                                            const selectedRow = option.fullData;
                                            if (selectedRow) {
                                                setStreetName(selectedRow.street_name || "");
                                                setCity(selectedRow.city || "");
                                                setZipCode(selectedRow.zip_code || "");
                                                setQualificationToken(selectedRow.qualification_token || "");
                                                setSelectedStateCode(selectedRow.state)
                                            }
                                            }}                                        
                                        options={addressOptions}
                                        placeholder="Select Address"
                                        showSearch
                                        filterOption={(input, option) =>
                                            (option?.label ?? "").toLowerCase().includes(input.toLowerCase())
                                        }
                                    />
                                    </>
                                ) : (
                                    <Input
                                    id="streetNumber"
                                    value={streetNumber}
                                    disabled ={activationData}
                                    onChange={(e) => setStreetNumber(e.target.value)}
                                    className={`${!isAllChangeType ? "w-2/3 ActiveServiceinput" : "input"}`}
                                    />
                                )}
                                    {(errors.streetNumber && isAllChangeType) && <span className="text-red-500">{errors.streetNumber}</span>}
                            </div>
                            {(errors.streetNumber && !isAllChangeType) && <div className="text-red-500">{errors.streetNumber}</div>}
                            {isRedirectedFromSQ &&(
                                <span className="italic">Select a street number to auto-fill address fields. Enter Street Direction manually if applicable</span>)}

                            {/* Street Direction */}
                            <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                <label htmlFor="streetDirection" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                    Street Direction
                                </label>
                                <Input
                                    id="streetDirection"
                                    // placeholder="Enter Street Direction"
                                    value={streetDirection}
                                    onChange={(e) => setStreetDirection(e.target.value)}
                                    // className="w-2/3 ActiveServiceinput" 
                                    className={`${!isAllChangeType?"w-2/3 ActiveServiceinput":"input"}`}/>
                                    {(errors.streetDirection && isAllChangeType) && <span className="text-red-500">{errors.streetDirection}</span>}
                            </div>
                            {(errors.streetDirection && !isAllChangeType) && <div className="text-red-500">{errors.streetDirection}</div>}

                            {/* Street Name */}
                            <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                <label htmlFor="streetName" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                    Street Name<span className="text-red-500">*</span>
                                </label>
                                <Input
                                    id="streetName"
                                    // placeholder="Enter Street Name"
                                    value={streetName}
                                    disabled ={activationData}
                                    onChange={(e) => setStreetName(e.target.value)}
                                    // className="w-2/3 ActiveServiceinput" 
                                    className={`${!isAllChangeType?"w-2/3 ActiveServiceinput":"input"}`}/>
                                    {(errors.streetName && isAllChangeType)&& <span className="text-red-500">{errors.streetName}</span>}
                            </div>
                            {(errors.streetName && !isAllChangeType)&& <div className="text-red-500">{errors.streetName}</div>}

                            {/* City */}
                            <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                <label htmlFor="city" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                    City<span className="text-red-500">*</span>
                                </label>
                                <Input
                                    id="city"
                                    // placeholder="Enter City"
                                    value={city}
                                    disabled ={activationData}
                                    onChange={(e) => setCity(e.target.value)}
                                    // className="w-2/3 ActiveServiceinput"
                                    className={`${!isAllChangeType?"w-2/3 ActiveServiceinput":"input"}`} />
                                    {(errors.city && isAllChangeType) && <span className="text-red-500">{errors.city}</span>}
                            </div>
                            {(errors.city && !isAllChangeType) && <div className="text-red-500">{errors.city}</div>}

                            {/* State */}
                            <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                <label htmlFor="state" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                    State<span className="text-red-500">*</span>
                                </label>
                                <Select
                                    showSearch
                                    value={selectedStateCode || null}
                                    id="state"
                                    // placeholder="Select State"
                                    options={stateOptions.length > 0 ? stateOptions : [{ value: 'No options', label: 'No options' }]}
                                    onChange={handleSelectedStateChange}
                                    suffixIcon={
                                        <ChevronDownIcon className="w-4 h-4 arrow  text-gray-600" />
                                    }
                                    disabled ={activationData}
                                    // className="w-2/3 mb-2"
                                    className={`${!isAllChangeType?"w-2/3 mb-2":"w-full mb-3"}`} />
                                    {(errors.state && isAllChangeType) && <span className="text-red-500">{errors.state}</span>}
                            </div>
                            {(errors.state && !isAllChangeType) && <div className="text-red-500">{errors.state}</div>}

                            {/* Zip Code */}
                            <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                <label htmlFor="zipCode" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                    Zip Code<span className="text-red-500">*</span>
                                </label>
                                <Input
                                    id="zipCode"
                                    // placeholder="Enter Zip Code"
                                    value={zipCode}
                                    disabled ={activationData}
                                    onChange={(e) => setZipCode(e.target.value)}
                                    // className="w-2/3  mt-1 ActiveServiceinput"
                                    className={`${!isAllChangeType?"w-2/3  mt-1 ActiveServiceinput":"input"}`} />
                                    {(errors.zipCode && isAllChangeType) && <span className="text-red-500">{errors.zipCode}</span>}
                            </div>
                            {(errors.zipCode && !isAllChangeType) && <div className="text-red-500">{errors.zipCode}</div>}

                            <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                <label htmlFor="applicableRatePlanForAll" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                    Apply Rate Plan For All
                                </label>
                                <Checkbox
                                    id="applicableRatePlanForAll"
                                    checked={applicableRatePlanForAll}
                                    onChange={(e) => setApplicableRatePlanForAll(e.target.checked)}
                                />
                            </div>
                            {activationData && (
                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="streetNumber" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        Qualification Token<span className="text-red-500">*</span>
                                    </label>
                                    <Input
                                        id="streetNumber"
                                        disabled ={activationData}
                                        // placeholder="Enter Street Number"
                                        value={qualicationToken}
                                        onChange={(e) => setQualificationToken(e.target.value)}
                                        // className="w-2/3 ActiveServiceinput"
                                        className={`${!isAllChangeType?"w-2/3 ActiveServiceinput":"input"}`} 
                                        style={{
                                            color: "black",
                                            opacity: 1, // ensures text color stays visible even when disabled
                                        }} />
                                </div>

                            )}

                        
                        </>}
                        {/* Action Buttons */}
                        {!isAllChangeType && (
                        <div className="justify-center flex space-x-4 mt-4">
                            <button onClick={onBack} className="cancel-btn">
                                {/* <ArrowLeftIcon className="h-5 w-5 mr-2" /> */}
                                Back
                            </button>
                            <button onClick={handleContinue} className="save-btn">
                                {isSubmitScreen ? "Submit" : "Continue"}
                                {/* <ArrowRightIcon className="h-5 w-5 mr-2" /> */}
                            </button>
                        </div>
                        )}
                        
                    </div></>
            )
            //  : (!showSelectDevices && isStaticIPChecked && !isAllChangeType) ? (
            //     <>
            //         <div className="flex flex-col space-y-4 my-4">
            //             {/* PDP Name */}
            //             <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
            //                 <label htmlFor="pdpName" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
            //                     PDP Name<span className="text-red-500">*</span>
            //                 </label>
            //                 <Select
            //                     value={selectedPDP === 'No options' ? null : { label: selectedPDP, value: selectedPDP }}
            //                     showSearch
            //                     id="pdpName"
            //                     // placeholder="Select Customer"
            //                     options={pdpOptions.length > 0 ? pdpOptions.map((option: string) => ({
            //                         label: option,
            //                         value: option,
            //                     })) : [{ value: 'No options', label: 'No options' }]}
            //                     onChange={handleSelectedPDPChange}
            //                     suffixIcon={
            //                         <ChevronDownIcon className="w-4 h-4 text-gray-600 arrow " />
            //                     }
            //                     // className="w-2/3 mt-1 mb-2 " 
            //                     className={`${!isAllChangeType?"w-2/3 mt-1 mb-2 ":"w-full"}`}/>
            //             </div>
            //             {errors.pdp && <div className="text-red-500">{errors.pdp}</div>}

            //             {/* Static IP APN */}
            //             <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
            //                 <label htmlFor="apn" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
            //                     Static IP APN<span className="text-red-500">*</span>
            //                 </label>
            //                 <Select
            //                     value={selectedAPN === 'No options' ? null : { label: selectedAPN, value: selectedAPN }}
            //                     showSearch
            //                     id="apn"
            //                     // placeholder="Select Customer"
            //                     options={apnOptions.length > 0 ? apnOptions.map((option: string) => ({
            //                         label: option,
            //                         value: option,
            //                     })) : [{ value: 'No options', label: 'No options' }]}
            //                     onChange={handleSelectedAPNChange}
            //                     suffixIcon={
            //                         <ChevronDownIcon className="w-4 h-4 text-gray-600 arrow " />
            //                     }
            //                     // className="w-2/3 mt-1 mb-2 " 
            //                     className={`${!isAllChangeType?"w-2/3 mt-1 mb-2 ":"w-full"}`}/>
            //             </div>
            //             {errors.apn && <div className="text-red-500">{errors.apn}</div>}

            //             <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
            //                 <label htmlFor="lte" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
            //                     LTE Device?
            //                 </label>
            //                 <Checkbox
            //                     id="lte"
            //                     checked={LTEDevice}
            //                     onChange={(e) => setLTEDevice(e.target.checked)}
            //                 />
            //             </div>
            //             {/* Action Buttons */}
            //             <div className="justify-center flex space-x-4 mt-4">
            //                 <button onClick={onStaticIPBack} className="cancel-btn">
            //                     {/* <ArrowLeftIcon className="h-5 w-5 mr-2" /> */}
            //                     Back
            //                 </button>
            //                 <button onClick={handleStaticIPContinue} className="save-btn">
            //                     Continue
            //                     {/* <ArrowRightIcon className="h-5 w-5 mr-2" /> */}
            //                 </button>
            //             </div>
            //         </div>
            //     </>
            // )
                : (
                    <ActivateSelectDevices
                        onContinue={onContinue}
                        onBack={onBack}
                        service_provider={service_provider}
                        change_type={change_type}
                        changed_data={{
                            ...returnChangedData(),
                            staticIpAddressCheckbox:staticIpAddressCheckbox,
                            ApplicableRatePlanForAll: applicableRatePlanForAll,
                            // RatePlanCodeList: ratePlanOptions, // assuming ratePlanOptions is the list of rate plan codes
                        }}
                        isNextScreen={!isAdmin}
                        onClose={() => {
                            setShowSelectDevices(false)
                            setIsRedirected(true)
                        }}
                        setDropdownData={setDropdownData}
                        onCancel={onClose}
                    />
                )}
        </div>
    );
}
)

export default ActivateService;
