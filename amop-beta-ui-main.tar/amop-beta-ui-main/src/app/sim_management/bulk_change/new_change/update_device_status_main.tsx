"use client";

import { FC, forwardRef, useEffect, useImperativeHandle, useRef, useState } from "react";
import { Button, Checkbox, Tooltip } from "antd";
import { ArrowLeftIcon, ArrowRightIcon } from "@heroicons/react/24/outline";
import SelectDevices from "./select_devices";
import Select from "react-select";
import { DropdownStyles } from "@/app/components/css/dropdown";
import { useAllChangeTypesStore } from "@/app/stores/allChangeTypesStore";
import { SelectContentRef } from "./select_devices";
import { PerformanceLogStore } from "@/app/stores/performance_matrix_store";
import UploadComponent2 from "./upload_component_2";

interface UpdateStatusProps {
    onContinue: () => void;
    onBack: () => void;
    dropdown: any;
    service_provider: any;
    change_type: any
    onClose: () => void;
}


// Define your options array

const statusOptions = [
    { value: "Activated", label: "Activated" },
    { value: "Activation Ready", label: "Activation Ready" },
    { value: "Deactivated", label: "Deactivated" },
    { value: "Retired", label: "Retired" },
];
export interface Activated2ContentRef {
  runValidation: () => Promise<void> | void;
  runSubmit: () => Promise<void> | void;
  returnUpdate: () => React.ReactNode | Promise<React.ReactNode>;
}

const UpdateStatus = forwardRef<Activated2ContentRef, UpdateStatusProps>(
    ({ onContinue, onBack, dropdown, service_provider, change_type,onClose }, ref) => {
    const [targetStatus, setTargetStatus] = useState<string | undefined>(undefined);
    const [showSelectDevices, setShowSelectDevices] = useState(false);
    const [statusOptions, setStatusOptions] = useState<any>([])
    const [errorMessage, setErrorMessage] = useState("");
    const [provileError, setProfileError] = useState("");


    const [selectedProfile, setSelectedProfile] = useState<string | null>(null);
    // const [selectedReasonCodeID, setSelectedReasonCodeID] = useState<string | null>(null);
    const [profileOptions, setProfileOptions] = useState<any>([]);
    const [statusMap, setStatusMap] = useState<any>([]);
    const [selectedStatus, setSelectedStatus] = useState<string | null>(null);
    const [selectedStatusID, setSelectedStatusId] = useState<string | null>(null);
    const { isAllChangeType,setIsValidated,setValidationTrigger, setsuccessFullChangeTypes, activeChange, successFullChangeTypes  } = useAllChangeTypesStore();
    const selectDevicesRef = useRef<SelectContentRef>(null);
    const [saveChanges, setSaveChanges] = useState<boolean>(true);
    const { getTargetTenantProvider, IsTargetTenantProvider } = PerformanceLogStore();
    const is_parent_provider_exists = IsTargetTenantProvider(service_provider)
    const providerName = getTargetTenantProvider(service_provider).toLowerCase() || service_provider;
    useEffect(() => {
        // console.log("dropdown", dropdown)
        const Device_Status_dropdown = dropdown?.Device_Status_dropdown || []
        setStatusMap(Device_Status_dropdown || [])
        const statusOptions = Device_Status_dropdown.map((option: any) => (option.display_name));
        setStatusOptions(statusOptions)

        const active_profile_dropdown = dropdown?.activation_profiles || []
        setProfileOptions(active_profile_dropdown)

    }, [dropdown]);
        const handleContinue = () => {
            if (targetStatus) {
                setErrorMessage('')
                if (isAllChangeType) {
                    if(saveChanges){
                        setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
                    }
                    setIsValidated(true)
                    setValidationTrigger()
                }
                else {
                    setShowSelectDevices(true);
                }
            } else {
                // Handle the case where no status is selected
                setErrorMessage('Target Status is required')
                setShowSelectDevices(false);
                if (isAllChangeType) {
                    setsuccessFullChangeTypes(
                        successFullChangeTypes.filter((c: any) => c !== activeChange)
                    );
                    setErrorMessage('');
                    setIsValidated(true)
                    setValidationTrigger();
                }
            }
            if (service_provider.toLowerCase().includes("kore") && (targetStatus?.toLowerCase() === "activate" || targetStatus?.toLowerCase() === "active")) {
                if (selectedProfile) {
                    setProfileError('')
                    if (isAllChangeType) {
                        if(saveChanges){
                            setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
                        }
                        setIsValidated(true)
                        setValidationTrigger()
                    }
                    else {
                        setShowSelectDevices(true);
                    }
                } else {
                    // Handle the case where no status is selected
                    setProfileError('Kore Activation Profile is required')
                    setShowSelectDevices(false);
                    if (isAllChangeType) {
                        setsuccessFullChangeTypes(
                            successFullChangeTypes.filter((c: any) => c !== activeChange)
                        );
                        setIsValidated(false)
                        setValidationTrigger();
                    }
                }
            }

        };
    const handleBack = () => {
        setShowSelectDevices(false);
    };
    const handleSelectStatus = (selectedOption: any) => {
        if (selectedOption) {

            const value = selectedOption?.value
            setTargetStatus(value)
            const selectedItem = statusMap.find((item: any) => item.display_name === selectedOption.value);
            setSelectedStatusId(selectedItem?.id || "22"); // `id`
            setSelectedStatus(selectedItem?.status || "A"); // `status`
            
            
            setErrorMessage('')
        }
        else{
            setSelectedStatusId(null);
            setSelectedStatus("");
        }
    };

    const handleSelectActivationProfile = (selectedOption: any) => {
        if (selectedOption) {
            const value = selectedOption?.value
            setSelectedProfile(value)
            setProfileError('')
        }
        else{
            setSelectedProfile(null)
        }
    };
    const returnChangedData = () => {
        const changedData = {
            UpdateStatus: targetStatus,
            sim_status:targetStatus,
            device_status_id:selectedStatusID,
            ...(service_provider.toLowerCase().includes("kore") && (targetStatus?.toLowerCase() === "activate" || targetStatus?.toLowerCase() === "active") && { activation_profile: selectedProfile}),
            // PostUpdateStatusId: 8,
            Request: {
                // ICCID: "89148000001474951901",
                RatePlanCode:null,
                MdnZipCode: null,
                thingSpacePPU: {
                    FirstName: null,
                    LastName: null,
                    AddressLine:null,
                    City: null,
                    State:null,
                    ZipCode:null,
                    Country: null
                }
            },
            // IntegrationAuthenticationId: 0
        }
        return changedData
    };

    // const returnUpdatedValue = () =>{
    //     return (
    //     <Tooltip title={`${targetStatus}`}>
    //         <span>
    //             {targetStatus}
    //         </span>
    //     </Tooltip>)
    // }

    const returnUpdatedValue = () => {
            return (
                <div className="flex flex-col gap-2">
                    <div className="flex grid grid-cols-2 ">
                        <span className="font-semibold">Status:</span>
                        <span>{targetStatus}</span>
                    </div>
                </div>
            )
        }

        useImperativeHandle(ref, () => ({
            runValidation: handleContinue,
            runSubmit: () => {
            selectDevicesRef.current?.runSubmit();
        },
        returnUpdate: returnUpdatedValue
        }));
            
    return (
        <div>
            {/* {!showSelectDevices ? ( */}
                <div className={showSelectDevices ? "hidden" : "block"}>
                {isAllChangeType && (
                    <div className="flex justify-end px-4">
                        <span className="mr-2 font-semibold">Save Changes</span>
                        <Checkbox
                            checked={saveChanges}
                            onChange={(e) => {
                                if (!e.target.checked) {
                                    setsuccessFullChangeTypes(
                                        successFullChangeTypes.filter((c: any) => c !== activeChange)
                                    );
                                }
                                setSaveChanges(e.target.checked)
                            }}
                            className="custom-checkbox"
                        >

                        </Checkbox>
                    </div>
                )}
                { !isAllChangeType && (
                    <UploadComponent2
                        service_provider={service_provider}
                        change_type={change_type}
                        changed_data={{
                            ...returnChangedData(),
                        }} />
                )}
                <div className={`${!isAllChangeType?"flex flex-col space-y-4 my-4":"flex grid grid-cols-2 gap-4"}`}>
                    <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                        <label htmlFor="targetStatus" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                            Target Status <span className="text-red-500">*</span>
                        </label>
                        <Select
                            options={statusOptions.map((option: string) => ({
                                label: option,
                                value: option,
                            }))}
                            value={{ label: targetStatus, value: targetStatus }}
                            onChange={handleSelectStatus}
                            className="w-full"
                            styles={DropdownStyles}
                            menuPortalTarget={document.body}
                            menuPosition="fixed"
                            menuPlacement="auto"
                        />

                    </div>
                    {errorMessage && <div className="text-red-500 text-sm">{errorMessage}</div>}

                    {service_provider.toLowerCase().includes("kore") && (targetStatus?.toLowerCase() === "activate" || targetStatus?.toLowerCase() === "active") && (
                            <>
                                <div className={`${!isAllChangeType?"flex items-center space-x-4":""}`}>
                                    <label htmlFor="reasonCode" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>
                                        Kore Activation Profile<span className="text-red-500">*</span>
                                    </label>
                                    <Select
                                        value={{ label: selectedProfile, value: selectedProfile }}
                                        options={profileOptions.map((option: string) => ({
                                            label: option,
                                            value: option,
                                        }))}
                                        onChange={handleSelectActivationProfile}
                                        className="w-full"
                                        styles={DropdownStyles}
                                        menuPortalTarget={document.body}
                                        menuPosition="fixed"
                                        menuPlacement="auto"
                                    />
                                </div>
                                {provileError && <div className="text-red-500 text-sm">{provileError}</div>}
                            </>
                        )}
                    {/* Action Buttons */}
                    {!isAllChangeType && (
                        <div className="flex justify-center space-x-4 mt-4">
                        <button onClick={onBack} className="cancel-btn">
                            {/* <ArrowLeftIcon className="h-5 w-5 mr-2" /> */}
                            Back
                        </button>
                        <button onClick={handleContinue} className="save-btn">
                            Continue
                            {/* <ArrowRightIcon className="h-5 w-5 mr-2" /> */}
                        </button>
                    </div>
                    )}
                    
                </div>
                </div>
            {/* ) : ( */}
                <div className={showSelectDevices ? "block" : "hidden"}>
                <SelectDevices ref={selectDevicesRef} onContinue={handleContinue} onBack={handleBack} service_provider={service_provider} change_type={change_type} changed_data={returnChangedData()} onCancel={onClose}/>
                </div>
            {/* )} */}
        </div>
    );
}
)

export default UpdateStatus;
