"use client";

import { FC, forwardRef, useEffect, useImperativeHandle, useState } from "react";
import { Checkbox, Input, Modal, Spin } from "antd";
import { useRouter } from "next/navigation";
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { useFeatureStore } from "../../inventory/featureStore";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import React from "react";
import Select from "react-select";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { useAllChangeTypesStore } from "@/app/stores/allChangeTypesStore";
import { PerformanceLogStore } from "@/app/stores/performance_matrix_store";

interface EditUsernameProps {
    onContinue: (phoneNumbers: string[]) => void;
    onBack: () => void;
    dropdown: any;
    service_provider: any;
    change_type: any
    onClose: () => void;
}

export interface EditUsernameContentRef {
  runValidation: () => Promise<void> | void;
  runSubmit: () => Promise<void> | void;
  returnUpdate: () => React.ReactNode | Promise<React.ReactNode>;

}

const EditUsername = forwardRef<EditUsernameContentRef, EditUsernameProps>(
    ({ onContinue, onBack, dropdown, service_provider, change_type, onClose }, ref) => {
    const [contactName, setContactName] = useState<string>("");
    const [costCenter, setCostCenter] = useState<string>("");
    const [subscriberNumber, setSubscriberNumber] = useState<string>("");
    const [iccids, setIccids] = useState<string>("");
    const [loading, setLoading] = useState(false);
    const router = useRouter();
    const [errorMessage, setErrorMessage] = useState("");
    const { username, role, partner, token, selectedDb, firstLastName, sessionId, modulesVersionMap,metaData } = useAuth();
    const { setRowId, setBulkRow, bulkChangeLimit, simIdentifierMap } = useFeatureStore();
    const [costCenterOptions, setCostCenterOptions] = useState<any>([]);
    const [errors, setErrors] = useState<string[]>([]);
    const [mandatoryError, setMandatoryError] = useState<string>("");


    const initial_version_flag = modulesVersionMap?.["Sim Management-Bulk Change"] || false
    const isVersionEnabled = localStorage.getItem("switch_user_2_0_bulk_change") === "True";
    const switch_user_2_0 = isVersionEnabled && initial_version_flag ? "True" : "False"
    const { addExport, removeExport, exports } = exportLoadingStore();
    const { isAllChangeType,setIsValidated,setValidationTrigger,allChangeTypesDevices, setsuccessFullChangeTypes, activeChange, successFullChangeTypes,all_2_0_payloads, set_all_2_0_payloads  } = useAllChangeTypesStore();
    const [saveChanges, setSaveChanges] = useState<boolean>(true);

    const { getTargetTenantProvider, IsTargetTenantProvider } = PerformanceLogStore();
    const is_parent_provider_exists = IsTargetTenantProvider(service_provider)
    const providerName = getTargetTenantProvider(service_provider).toLowerCase() || service_provider;

    useEffect(() => {
        // console.log("dropdown", dropdown)
        const cost_centers = dropdown?.cost_centers || []
        setCostCenterOptions(cost_centers)

    }, [dropdown]);

        useEffect(() => {
            if (isAllChangeType) {
                const devices = allChangeTypesDevices?.iccids || []
                const devicesString = devices.join('\n')
                if (allChangeTypesDevices?.isIccid) {
                    setSubscriberNumber("")
                    setIccids(devicesString);
                }
                else {
                    setIccids("")
                    setSubscriberNumber(devicesString);
                }
            }
        }, [isAllChangeType, allChangeTypesDevices]);
    
    // const onsubmit = async () => {
    //     try {
    //         setLoading(true);
    //         const iccidList = phoneNumbers
    //         .split("\n")
    //         .map((line) => line.trim())
    //         .filter((line) => line.length > 0);
    //         const url =ENV_ROUTES.SIM_MANAGEMENT
    //         const data = {
    //             tenant_name: partner || "default_value",
    //             path: "/update_bulk_change_data",
    //             request_received_at: getCurrentDateTime(),
    //             access_token: token,
    //             db_name:selectedDb,
    //             sessionID: sessionId,
    //             service_provider: service_provider,
    //             change_type: change_type,
    //             created_by:firstLastName,
    //             iccids:iccidList,
    //             changed_data:{
    //                 ContactName:contactName,
    //                 CostCenter1:costCenter,
    //             }
    //         };
    //         const submitData =  await axios.post(url, { data });
    //         const response = await axios.post(url, { data });
    //         const parsedData = JSON.parse(response.data.body);
    //         if (parsedData.flag === false) {
    //             setLoading(false);
    //             Modal.error({
    //                 title: 'Submit Error',
    //                 content: parsedData.message || 'An error occurred while submitting. Please try again.',
    //                 centered: true,
    //             });
    //         } else {
    //             const bulkrow_ = parsedData?.bulkchange_id || {}
    //             const bulkRow:any = { row: bulkrow_ }
    //             setBulkRow(bulkRow)
    //             localStorage.setItem('bulk_row',JSON.stringify(bulkRow || "{}"));
    //             if(bulkRow){
    //                 router.push(`/sim_management/bulk_history`);
    //             }
    //             const AlliccidList = parsedData.iccid;
    //             const AllimeiList = parsedData.imei;
    //             const iccidMatch = iccidList.every(iccid => AlliccidList.includes(iccid));
    //             if (!iccidMatch ) {

    //               console.log("ICCID  do not match.");

    //             } else {
    //             setLoading(false);
    //             try {
    //                 const url =ENV_ROUTES.SIM_MANAGEMENT
    //                 const data = {
    //                   tenant_name: partner || "default_value",
    //                   username: username,
    //                   firstLastName: firstLastName,
    //                   path: "/run_db_script",
    //                   role_name: role,
    //                   module_name: "Bulk Change",
    //                   mod_pages: {
    //                     start: 0,
    //                     end: 100,
    //                   },
    //                   access_token: token,
    //                   db_name: selectedDb,
    //                   sessionID: sessionId,
    //                   request_received_at: getCurrentDateTime(),
    //                   Partner: partner,
    //                   bulkchange_id:parsedData?.bulkchange_id?.id,
    //                   data:parsedData?.data,
    //                   bulk_chnage_id_20:parsedData?.bulk_chnage_id_20

    //                 };

    //                 const response = await axios.post(url, { data });
    //                 const responseData = JSON.parse(response.data.body);

    //                 if (responseData.flag === false) {
    //                   // Modal.error({
    //                   //   title: "Data Fetch Error",
    //                   //   content:
    //                   //   responseData.message ||
    //                   //     "An error occurred while fetching updating. Please try again.",
    //                   //   centered: true,
    //                   // });
    //                 } else {
    //        console.log("success")
    //                 }
    //               } catch (error) {
    //                 console.error("Error fetching data:", error);
    //                 // Modal.error({
    //                 //   title: "Data Fetch Error",
    //                 //   content:
    //                 //     error instanceof Error
    //                 //       ? error.message
    //                 //       : "An unexpected error occurred while updating. Please try again.",
    //                 //   centered: true,
    //                 // });
    //               } finally {
    //               }
    //             }
    //         }
    //     } catch (error) {
    //         Modal.error({
    //             title: 'Submit Error',
    //             content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting. Please try again.',
    //             centered: true,
    //         });
    //     }
    //     finally{
    //         setLoading(false);
    //     }
    // };

    const callKoreSync = async (data: any) => {
        const koreUrl = ENV_ROUTES.SM_BULK_CHANGE;
        let koreData = { ...data }
        koreData["path"] = "/start_sync"

        const koreResponse = await axios.post(koreUrl, { data: koreData });
        const koreResponseData = JSON.parse(koreResponse.data.body);

        if (koreResponseData.flag === false) {
            console.error("Data Fetch Error: " + koreResponseData.message);
        } else {
            console.log("Success: Bulk update successful.");
        }

    }

    const callMismatchICCID = async (parsedData: any) => {
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
            tenant_name: partner || "default_value",
            username: username,
            firstLastName: firstLastName,
            path: "/bulk_change_validation_update",
            role_name: role,
            module_name: "Bulk Change",
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            bulkchange_id: parsedData?.bulkchange_id?.id,
            bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
        };

        const response = await axios.post(url, { data });
        const parsedResponse = JSON.parse(response.data.body);

        if (parsedResponse.flag === false) {
            console.error("Data Fetch Error mismatch ICCID: " + parsedResponse.message);
        } else {
            console.log("Success: Bulk update successful.");
        }
    }

    const callSyncLambda = async () => {
        try {
            const url = ENV_ROUTES.OPTIMIZATION_SYNC_LAMBDA;
            const data = {
                key_name: "bulk_change_rev_sync",
                path: "/lambda_sync_jobs_",
                tenant_name: partner || "default_value",
                service_provider: service_provider || "",
                ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,

            };

            const response = await axios.post(url, { data });
            const responseData = JSON.parse(response.data.body);

            if (responseData.flag === false) {
                console.error("Data Fetch Error: " + responseData.message);
            } else {
                console.log("Success: Inventory lambda sync successful.");
            }
        } catch (error) {
            console.error("Error fetching data:", error);
        }

    }
    const callRunDbScript = async (parsedData: any) => {
        try {
            const url = ENV_ROUTES.SIM_MANAGEMENT;
            const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
            const runDbScriptData = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/run_db_script",
                role_name: role,
                module_name: "Bulk Change",
                mod_pages: {
                    start: 0,
                    end: 100,
                },
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                service_provider_id: service_provider_id_,
                bulkchange_id: parsedData?.bulkchange_id?.id,
                data: parsedData?.data,
                bulk_chnage_id_20: parsedData?.bulk_chnage_id_20
            };

            const runDbScriptResponse = await axios.post(url, { data: runDbScriptData });
            const runDbScriptResponseData = JSON.parse(runDbScriptResponse.data.body);

            if (runDbScriptResponseData.flag === false) {
                // Handle error for run_db_script API
            } else {
                console.log("success");
            }
        } catch (error) {
            console.error("Error fetching data:", error);
        }
    }

    const fetchCarrierWritesFlag = async () => {
        let parsedData: any
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const data = {
            tenant_name: partner || "default_value",
            username,
            path: "/get_writes_enable_for_service_provider",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "Inventory",
            service_provider: service_provider || "",
            ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            environment: "BETA",
            change_type: change_type,
        };

        try {
            setLoading(true);
            const response = await axios.post(url, { data });
            parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === true) {
                const write_is_enabled = parsedData?.write_is_enabled || false;
                // setWritesFlag(write_is_enabled);
                return write_is_enabled;
            }
        } catch (error) {
            console.error("Error fetching data:", error);
            return false; // fallback in case of error
        } finally {
            // setLoading(false);
        }
    };
    const submitCarrierStatus = async (write_is_enabled:boolean) => {
        let parsedData: any
        const url = ENV_ROUTES.SIM_MANAGEMENT;
        const iccidList = await getIccidList()
        const data = {
            tenant_name: partner || "default_value",
            username,
            path: "/insert_carrier_status_validation_audit",
            role_name: role,
            parent_module: "Sim Management",
            module_name: "Inventory",
            service_provider: service_provider || "",
            ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
            request_received_at: getCurrentDateTime(),
            Partner: partner,
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            environment: "BETA",
            msisdn: [],
            iccid: iccidList,
            change_type: change_type,
            write_is_enabled:write_is_enabled,
        };

        try {
            // setLoading(true);
            const response = await axios.post(url, { data });
            parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === true) {

            }
        } catch (error) {
            console.error("Error fetching data:", error);
        } finally {
            // setLoading(false);
        }
    };

    const call_2_0_submit = async (parsedData: any, payload: any,isRouteCall:boolean) => {
        try {
            const isTelegence = providerName.toLowerCase().includes("telegence");
            const isPod19 = providerName.toLowerCase().includes("pod19");
            const url = ENV_ROUTES.BULKCHANGE_PROCESSOR;
            const prevChangedData = payload?.changed_data || {}
            if (isTelegence) {
                payload["msisdns"] = payload?.iccids || []
                delete payload["changed_data"]
                delete payload["iccids"]
            }

            const payloadData = {
                ...payload,
                path: "/bulk_change_processor",
                request_received_at: getCurrentDateTime(),
                bulk_change_id: parsedData?.bulk_chnage_id_20,
            }
            const data = { ...payloadData };
            if(!isRouteCall){
                return data
            }
            const response = await axios.post(url, { data });
            const responseData = JSON.parse(response.data.body);
            if (responseData.flag === false) {
                console.log("Failure: 2.0 Bulk change update failed.");
            } else {
                console.log("Success: 2.0 Bulk change update successful.");
            }
        }
        catch (error) {
            console.error("Error running DB script:", error);
        } finally {
            setLoading(false);
        }
    }
    const call_2_0_sync = async (parsedData: any) => {
        try {
            const runDbScriptUrl = ENV_ROUTES.SIM_MANAGEMENT;
            const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
            const runDbScriptData = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/update_bulk_change_tables_10",
                role_name: role,
                module_name: "Bulk Change",
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                // service_provider_id: service_provider_id_,
                // bulkchange_id: parsedData?.bulkchange_id?.id,
                // data: parsedData?.data,
                data: {
                    bulk_change_id: parsedData?.bulk_chnage_id_20,
                },
                is_update: false,
                // bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
            };

            const runDbScriptResponse = await axios.post(runDbScriptUrl, { data: runDbScriptData });
            const runDbScriptResponseData = JSON.parse(runDbScriptResponse.data.body);

            if (runDbScriptResponseData.flag === false) {
                console.error("Data Fetch Error: " + runDbScriptResponseData.message);
            } else {
                console.log("Success: Bulk update successful.");
            }
        }
        catch (error) {
            console.error("Error running DB script:", error);
        } finally {
            setLoading(false);
        }
    }

    const bulkChangeInsert = async (payload: any) => {
        let partner_name = partner
        let db_name_ = selectedDb
        try {
            const url = ENV_ROUTES.SIM_MANAGEMENT;
            const data = {
                tenant_name: partner_name || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_bulk_change_insertion",
                role_name: role,
                module_name: "Bulk Change History",
                service_provider_name: service_provider,
                ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type,
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                request_received_at: getCurrentDateTime(),
                Partner: partner_name,
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);

            if (parsedData.flag === false) {
                console.error("Error fetching bulk change data:", parsedData.message ||
                    "An error occurred while fetching bulk change data. Please try again.");
                return false
            } else {
                const statusFlag = parsedData?.bulk_change_data?.status || "";
                const response_data = parsedData?.bulk_change_data?.bulk_change_data || "{}";
                const parsedResp = JSON.parse(response_data)
                console.log("status_flag", statusFlag)
                const status_flag = statusFlag ? (statusFlag).toLowerCase() : ""

                if (status_flag && status_flag === "pending") {
                    return false
                }
                else if (status_flag && status_flag === "success") {
                    call_2_0_submit(parsedResp, payload,true);
                    call_2_0_sync(parsedResp)
                    return true
                }
                else if (status_flag && status_flag === "error") {
                    Modal.error({
                        title: 'Submit Error',
                        content: parsedData.message || 'An error occurred while submitting. Please try again.',
                        centered: true,
                    });
                    return true
                }
                else {
                    return false
                }
            }
        } catch (error) {
            console.error("Error fetching auto refresh data:", error);
            return false
        } finally {
        }
    };
    const bulkChangePolling = async (data: any) => {
        const result = await bulkChangeInsert(data);
        if (!result) {
            setTimeout(() => bulkChangePolling(data), 5000); // Try again after 5 seconds
        } else {
            removeExport("bulkChangeInsert");
            console.log("Auto-refresh complete.");
        }
        // if (window.location.pathname.includes("/sim_management/bulk_change")) {
        //     window.location.reload();
        // }
    };

    const fetchDevices = async (devices_list: any[], deviceKey: string) => {
        try {
            setLoading(true);
            const url =
                ENV_ROUTES.BULKCHANGE_PROCESSOR;
            const data = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/get_standard_iccid_msisdn_data",
                role_name: role,
                Partner: partner,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: service_provider,
                ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type,
                [deviceKey]: devices_list || []
            };

            const response = await axios.post(url, { data });
            const parsedData = JSON.parse(response.data.body);
            if (parsedData.flag === false) {
                // setLoading(false);
                Modal.error({
                    title: 'Submit Error',
                    content: parsedData.message || 'An error occurred while submitting data. Please try again.',
                    centered: true,
                });
                return []
            } else {
                const responseKey = deviceKey === "iccids" ? "msisdns" : "iccids"
                const devices = parsedData?.[responseKey] || []
                console.log("devices", devices)
                return devices
                // setLoading(false);
            }
        } catch (error) {
            Modal.error({
                title: 'Submit Error',
                content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting data. Please try again.',
                centered: true,
            });
            return []
            // setLoading(false);
        }
        finally {
            // setLoading(false)
        }
    };

    const getIccidList = async (): Promise<string[]> => {
        // Pick devices based on subscriberNumber or iccids
        const devices_ = subscriberNumber ? subscriberNumber : iccids;

        // Find matching device type from the map
        const matchedDeviceTypeItem = simIdentifierMap.find((item: any) => {
            return (
                item.service_provider === service_provider &&
                item.change_type === change_type
            );
        });
        const matchedDeviceType = matchedDeviceTypeItem?.sim_identifier || ""
        // Decide expected type
        const selectDeviceType = subscriberNumber ? "msisdns" : "iccids";
        // Split devices into a list
        let iccidList = devices_
            .split(/\s*[\n,]\s*/)
            .map((line) => line.trim())
            .filter((line) => line.length > 0);

        // Fetch devices only if types mismatch
        if (matchedDeviceType !== selectDeviceType) {
            iccidList = await fetchDevices(iccidList, selectDeviceType);
        }

        return iccidList;
    };

    const onsubmit = async () => {
        let data: any
        try {
            setLoading(true);
            const iccidList = await getIccidList()

            const url = ENV_ROUTES.SIM_MANAGEMENT;
            data = {
                tenant_name: partner || "default_value",
                path: "/update_bulk_change_data",
                role_name: role,
                username: username,
                request_received_at: getCurrentDateTime(),
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                service_provider: service_provider,
                ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                change_type: change_type,
                created_by: firstLastName,
                iccids: iccidList,
                changed_data: {
                    ContactName: contactName,
                    CostCenter1: costCenter,
                }
            };

            // Call the first API
            const submitResponse = await axios.post(url, { data });
            const parsedData = JSON.parse(submitResponse.data.body);
            if (parsedData.flag === false) {
                setLoading(false);
                Modal.error({
                    title: 'Submit Error',
                    content: parsedData.message || 'An error occurred while submitting. Please try again.',
                    centered: true,
                });
                return;
            }

            const bulkrow_ = parsedData?.bulkchange_id || {};
            const bulkRow = { row: bulkrow_ };
            setBulkRow(bulkRow);
            localStorage.setItem('bulk_row', JSON.stringify(bulkRow || "{}"));

            if (bulkRow) {
                if(!isAllChangeType){
                    router.push(`/sim_management/bulk_history`);
                }
            }

            if ((service_provider.toLowerCase().includes("kore") || service_provider.toLowerCase() === "webbing" || service_provider.toLowerCase() === "multi-carrier sim") && switch_user_2_0 !== "True") {
                const koreUrl = ENV_ROUTES.SM_BULK_CHANGE;
                const koreData: any = {
                    tenant_name: partner || "default_value",
                    path: service_provider.toLowerCase().includes("kore") ? "/update_edit_cost_center" : "/update_webbing_user_name",
                    request_received_at: getCurrentDateTime(),
                    access_token: token,
                    db_name: selectedDb,
                ...metaData,
                    sessionID: sessionId,
                    service_provider: service_provider,
                    ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
                    change_type: change_type,
                    bulk_change_id: parsedData?.bulkchange_id?.id || 0,
                    data: parsedData?.data,
                    created_by: firstLastName,
                    iccids: iccidList,
                    changed_data: {
                        ContactName: contactName,
                        ...service_provider.toLowerCase().includes("kore") ? { CostCenter1: costCenter } : {},
                    }
                };

                const koreResponse = await axios.post(koreUrl, { data: koreData });
                const koreResponseData = JSON.parse(koreResponse.data.body);

                if (koreResponseData.flag === false) {
                    console.error("Data Fetch Error: " + koreResponseData.message);
                } else {
                    console.log("Success: Bulk update successful.");
                }
                const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
                koreData["service_provider_id"] = service_provider_id_
                callKoreSync(koreData)
            }
            else {
                // Prepare data for the new API call
                // const newApiData = {
                //     tenant_name: partner || "default_value",
                //     username: username,
                //     firstLastName: firstLastName,
                //     path: "/inventory_iccidds_imeids", // Updated path
                //     service_provider: service_provider,
                //     role_name: role,
                //     module_name: "Bulk Change",
                //     mod_pages: {
                //         start: 0,
                //         end: 100,
                //     },
                //     access_token: token,
                //     db_name: selectedDb,
                //     sessionID: sessionId,
                //     request_received_at: getCurrentDateTime(),
                //     Partner: partner
                // };

                // // Call the new API to get ICCIDs and IMEIs
                // const newApiResponse = await axios.post(ENV_ROUTES.SIM_MANAGEMENT, { data: newApiData });

                // // Parse the response from the new API
                // const newApiDataResponse = JSON.parse(newApiResponse.data.body); // Parse the new API response
                // const AlliccidList = newApiDataResponse.iccid; // Adjust based on the actual structure of the response
                // const AllimeiList = newApiDataResponse.imei; // Adjust based on the actual structure of the response

                // // Validate ICCIDs
                // const iccidMatch =service_provider.tolLowerCase().includes("AT&T - Telegence") ?AllimeiList.every((imei:any) => AlliccidList.includes(imei)):iccidList.every(iccid => AlliccidList.includes(iccid));
                // if (!iccidMatch) {
                //     console.log("ICCID do not match.");
                //     callMismatchICCID(parsedData)
                //     return; // Exit if ICCIDs do not match
                // }

                // Proceed to call the run_db_script API
                const isTelegence = providerName.toLowerCase().includes("telegence");
                const isPod19 = providerName.toLowerCase().includes("pod19");
                const isJasper = providerName.toLowerCase().includes("jasper");
                const isKore = providerName.toLowerCase().includes("kore");
                const isRogers = providerName.toLowerCase().includes("rogers");
                if (switch_user_2_0 === "True") {
                    if (!isAllChangeType) {
                        call_2_0_submit(parsedData, data, true);
                        call_2_0_sync(parsedData);
                    }
                    else {
                        const payload_2_0_: any = await call_2_0_submit(parsedData, data, false)
                        set_all_2_0_payloads((prev: any) => ({
                            ...prev,
                            [change_type]: { ...payload_2_0_ }
                        }));
                    }
                } else {
                    if (dropdown?.module_status && (partner && partner.toLowerCase() !== "wingtel")) {
                        callRunDbScript(parsedData)
                    }
                    // else {
                    //     callSyncLambda()
                    // }
                }

            }

        } catch (error) {
            const isTelegence = providerName.toLowerCase().includes("telegence");
            const isPod19 = providerName.toLowerCase().includes("pod19");
            const isJasper = providerName.toLowerCase().includes("jasper");
            const isKore = providerName.toLowerCase().includes("kore");
            const isRogers = providerName.toLowerCase().includes("rogers");
            if (switch_user_2_0 === "True") {
                onClose()
                setLoading(false)
                addExport("bulkChangeInsert", "Bulk Change Submission");
                bulkChangePolling(data)
            }
            else {
                Modal.error({
                    title: 'Submit Error',
                    content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting. Please try again.',
                    centered: true,
                });
            }
        } finally {
            setLoading(false);
        }
    };
    const handleSubmit = async () => {
        let hasError = false
        let mandatoryError_ = ""
        if (!costCenter && !contactName) {
            console.log("entered")
            setMandatoryError("Please enter either Cost Center or Contact Name")
            mandatoryError_ = "Enter either Cost Center or Contact Name"
        }
        else {
            setMandatoryError("")
            mandatoryError_ = ""
        }
        if (!subscriberNumber && !iccids) {
            setErrorMessage("Please fill ICCID field or MSISDN field.")
        }
        else {
            setErrorMessage("")
            const isTMobile = providerName.toLowerCase().includes("t-mobile")
            const isTeal = providerName.toLowerCase().includes("teal")
            const selected_devices = subscriberNumber ? subscriberNumber : iccids
            const iccidList = selected_devices
                .split(/\s*[\n,]\s*/)
                .map((line) => line.trim())
                .filter((line) => line.length > 0);

            const isTelegence = providerName.toLowerCase().includes("telegence");

            const newErrors: string[] = [];

            iccidList.forEach((line, index) => {
                const label = subscriberNumber ? "Subscriber Number" : "ICCID";
                const minLength = subscriberNumber ? 10 : 14;
                const maxLength = subscriberNumber ? 18 : isTeal ? 32 : 22;
                if (line.length === 0) {
                    newErrors[index] = `${label} must not be empty`;
                } else if (!/^\d+$/.test(line) && !isTMobile) {
                    newErrors[index] = `Please enter numbers only for ${label}. Letters or special characters are not allowed`;
                } 
                else if (!/^[a-zA-Z0-9]+$/.test(line) && isTMobile){
                    newErrors[index] = `Please enter letters and numbers only for ${label}. Special characters are not allowed`;
                }else if (line.length < minLength || line.length > maxLength) {
                    newErrors[index] = `${label} must be between ${minLength} and ${maxLength} digits long`;
                }
            });
            if (iccidList.length > bulkChangeLimit) {
                newErrors.push(`This request exceeds the allowed record limit  of ${bulkChangeLimit} and cannot be processed`);
                console.log("Limit Exceeded");
            }
            setErrors(newErrors);

            if (newErrors.length === 0 && (!mandatoryError_ || isAllChangeType)) {
                console.log("newErrors if",newErrors)
                setMandatoryError("")
                if(!isAllChangeType){
                    const writes_flag = await fetchCarrierWritesFlag()
                if (writes_flag) {
                    const modal = Modal.confirm({
                        title: "Carrier API Enabled",
                        content: "Carrier API settings are enabled. Submitting now will trigger the Carrier API directly. Do you want to proceed?",
                        centered: true,
                        okText: "Submit",
                        onOk: () => {
                            // modal.destroy(); // closes the modal
                            // handleCloseModal();

                            onsubmit();
                            submitCarrierStatus(writes_flag);
                        },
                        onCancel: onBack
                    });
                }
                else {
                    onsubmit();
                }
                // onsubmit()
                }
                else{
                   if (costCenter || contactName) {
                    if(saveChanges){
                        setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
                    }
                    setIsValidated(true)
                    setValidationTrigger();
                    return
                }
                else{
                    setsuccessFullChangeTypes(
                        successFullChangeTypes.filter((c: any) => c !== activeChange)
                    );
                    setIsValidated(true)
                    setValidationTrigger();
                    return
                }
                }
                
            }
            console.log("newErrors",newErrors)

        }
    };

        const returnUpdatedValue = () => {
            return (
                <div className="flex flex-col gap-2">
                    <div className="flex grid grid-cols-2 ">
                        <span className="font-semibold">Contact Name:</span>
                        <span>{contactName || ""}</span>
                        <span className="font-semibold">Cost Center:</span>
                        <span>{costCenter || ""}</span>
                    </div>
                </div>
            )
        }
    useImperativeHandle(ref, () => ({
        runValidation: handleSubmit,
        runSubmit: onsubmit,
        returnUpdate: returnUpdatedValue,
    }));
            
    if (loading) {
        return (
            <>
                <div className="flex justify-center items-center h-[400px]">
                    <Spin size="large" />
                </div>
            </>
        );
    }
    return (
        <>
            {isAllChangeType && (
                <div className="flex justify-end px-4">
                    <span className="mr-2 font-semibold">Save Changes</span>
                    <Checkbox
                        checked={saveChanges}
                        onChange={(e) => {
                            if (!e.target.checked) {
                                setsuccessFullChangeTypes(
                                    successFullChangeTypes.filter((c: any) => c !== activeChange)
                                );
                            }
                            setSaveChanges(e.target.checked)
                        }}
                        className="custom-checkbox"
                    >

                    </Checkbox>
                </div>
            )}
        <div className={`${!isAllChangeType?"flex flex-col space-y-4 mt-4":"flex grid grid-cols-2 gap-4"}`}>
            <div className={`${!isAllChangeType?"flex flex-col space-y-4 mt-4":""}`}>
                <label htmlFor="contactName" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>Contact Name</label>
                <Input
                    id="contactName"
                    placeholder="Enter Contact Name"
                    value={contactName}
                    onChange={(e) => setContactName(e.target.value)}
                    className="input"
                />
            </div>
            {(service_provider.toLowerCase() !== "webbing" || service_provider.toLowerCase() !== "multi-carrier sim") &&

                <div className={`${!isAllChangeType?"flex flex-col space-y-4 mt-4":""}`}>
                    <label htmlFor="costCenter" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>Cost Center</label>
                    {service_provider.toLowerCase().includes("kore") ? (
                        <Select
                            id="cost_center"
                            className="mt-1"
                            options={costCenterOptions.map((option: any) => ({ value: option, label: option }))}
                            value={{ value: costCenter, label: costCenter }}
                            onChange={(selectedOption) =>
                                setCostCenter(selectedOption ? selectedOption.value : "")
                            }
                            isClearable
                            placeholder="Select Cost Center"
                            isLoading={loading}
                            menuPortalTarget={document.body}
                            menuPosition="fixed"
                            menuPlacement="auto"
                        />
                    ) : (
                        <Input
                            id="costCenter"
                            placeholder="Enter Cost Center"
                            value={costCenter}
                            onChange={(e) => setCostCenter(e.target.value)}
                            className="input"
                        />
                    )
                    }

                </div>}

            {mandatoryError && (<span className="text-red-500">{mandatoryError}</span>)}


            {!isAllChangeType && (
                <>
                    <div className={`${!isAllChangeType?"flex flex-col space-y-4 mt-4":"flex grid grid-cols-2 gap-4"}`}>
                        <label htmlFor="iccids" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>{`Devices (Start typing ICCID)`}<span className='text-red-500'>*</span></label>
                        <Input.TextArea
                            id="iccids"
                            rows={4}
                            placeholder={"Enter ICCIDs here"}
                            value={iccids}
                            onChange={(e) => {
                                setIccids(e.target.value);
                                if (e.target.value) setSubscriberNumber("");
                            }}
                            disabled={!!subscriberNumber}
                        />
                    </div>
                    <div className={`${!isAllChangeType?"flex flex-col space-y-4 mt-4":"flex grid grid-cols-2 gap-4"}`}>
                        <label htmlFor="msisdns" className={`${!isAllChangeType?"w-1/3 font-semibold":"field-label"}`}>{`Devices (Start typing Subscriber Number)`}<span className='text-red-500'>*</span></label>
                        <Input.TextArea
                            id="msisdns"
                            rows={4}
                            placeholder={"Enter Subscriber Numbers here"}
                            value={subscriberNumber}
                            onChange={(e) => {
                                setSubscriberNumber(e.target.value);
                                if (e.target.value) setIccids("");
                            }}
                            disabled={!!iccids}
                        />
                        {errors.some((err) => err) && (
                            <div className="mt-2 space-y-1">
                                {errors.map((err, idx) =>
                                    err ? (
                                        <div key={idx} className="text-red-500 text-sm">
                                            Line {idx + 1}: {err}
                                        </div>
                                    ) : null
                                )}
                            </div>
                        )}
                    </div>
                    {errorMessage && <div className="text-red-500 text-sm">{errorMessage}</div>}
                </>
            )}
            

            {!isAllChangeType && (
                <div className="flex justify-center space-x-4 mt-4">
                <button onClick={onBack} className="cancel-btn">
                    {/* <ArrowLeftIcon className="h-5 w-5 mr-2" /> */}
                    Back
                </button>
                <button onClick={handleSubmit} className="save-btn">
                    Submit
                    {/* <ArrowRightIcon className="h-5 w-5 ml-2" /> */}
                </button>
            </div>
            )}
            
        </div>
        </>
    );
}
)

export default EditUsername;
