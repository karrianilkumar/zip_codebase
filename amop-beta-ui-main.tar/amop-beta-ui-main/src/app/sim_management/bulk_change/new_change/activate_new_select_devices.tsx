import { FC, useEffect, useState } from "react";
import { Input, Button, Modal, Spin, Select, Tooltip } from "antd";
import ReactSelect from "react-select";
import { useAuth } from "@/app/components/auth_context";
import { useRouter } from 'next/navigation';
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { PerformanceLogStore } from "@/app/stores/performance_matrix_store";
import { InfoIcon } from "lucide-react";
import PrivateNetworkPreviewModal from "./private_network_preview";
import { DropdownStyles } from "@/app/components/css/dropdown";
import { useAllChangeTypesStore } from "@/app/stores/allChangeTypesStore";


interface SelectDevicesProps {
  onContinue: () => void;
  onBack: () => void;
  service_provider: any;
  change_type: any;
  changed_data?: any;
  isNextScreen?: boolean;
  onClose: () => void;
  setDropdownData: (dropdown: any) => void;
  onCancel: () => void;
}

interface Data {
  tenant_name: string;
  path: string;
  request_received_at: string;
  access_token: string | null;
  db_name: string | null;
  service_provider: any;
  sessionID: string | null;
  change_type: any;
  created_by: string | null;
  changed_data: any;
  // iccids?: string[]; // Add the 'iccids' property with optional type
  // iccidList?: { iccid: string; ratePlanCode: string }[]; // Add the 'iccidList' property with optional type
}

const ActivateSelectDevices: FC<SelectDevicesProps> = ({
  onContinue,
  onBack,
  onClose,
  service_provider,
  change_type,
  changed_data: {
    ApplicableRatePlanForAll,
    staticIpAddressCheckbox,
    // RatePlanCodeList,
    Devices,
    ...returnChangedData
  },
  isNextScreen,
  setDropdownData,
  onCancel
}) => {
  console.log("Show returned data",returnChangedData)
  const [iccid, setIccid] = useState([{ iccid: '', ratePlanCode: '' }]);
  const [iccidText, setIccidText] = useState('');
  const [validIccid, setValidIccid] = useState<string[]>([]);
  const [validImei, setValidImei] = useState<string[]>([]);


  const [newIMEI, setNewIMEI] = useState("");
  const [errors, setErrors] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [processImmediately, setProcessImmediately] = useState(false); // State for checkbox
  const { username, role, partner, token, selectedDb, firstLastName, sessionId, modulesVersionMap, metaData } = useAuth();
  const router = useRouter();
  const { setRowId, setBulkRow, setsetActivationPayload ,bulkChangeLimit} = useFeatureStore();
  const [iccidList, setIccidList] = useState([{ iccid: '', ratePlanCode: '' }]);
  const [iccidError, setIccidError] = useState("");
  const [pdpOptions, setPdpOptions] = useState<any>([]);
  const [pdpIpMap, setPdpIpMap] = useState<any>({});
  const [selectedPDP, setSelectedPDP] = useState<string | null>(null);
  const [IPOptions, setIPOptions] = useState<any>([]);
  const isTelegence = service_provider.toLowerCase().includes("telegence");
  const [infoFlag,setInfoFlag] = useState<boolean>(false);
  const initial_version_flag = modulesVersionMap?.["Sim Management-Bulk Change"] || false
  const isVersionEnabled = localStorage.getItem("switch_user_2_0_bulk_change") === "True";
  const switch_user_2_0 = isVersionEnabled && initial_version_flag ? "True" : "False"
  const { addExport, removeExport, exports } = exportLoadingStore();

  const { getTargetTenantProvider, IsTargetTenantProvider } = PerformanceLogStore();
  const is_parent_provider_exists = IsTargetTenantProvider(service_provider)
  const [openPreviewModal, setPreviewModal] = useState<boolean>(false);
  const { isAllChangeType, set_all_2_0_payloads } = useAllChangeTypesStore();
  
  useEffect(() => {
    fetchOptionsMappings()
  }, [service_provider])
  // const onsubmit = async (payload: { iccids: any; imeis: any; }) => {
  //   try {
  //     const changedData = returnChangedData ? returnChangedData : {};
  //     setLoading(true);

  //     const url = ENV_ROUTES.SIM_MANAGEMENT;

  //     // Prepare the data object
  //     const data: any = {
  //       tenant_name: partner || "default_value",
  //       path: "/update_bulk_change_data", // Default path
  //       request_received_at: getCurrentDateTime(),
  //       access_token: token,
  //       db_name: selectedDb,
  //       sessionID: sessionId,
  //       service_provider: service_provider,
  //       change_type: change_type,
  //       created_by: firstLastName,
  //       changed_data: {
  //         ...changedData
  //       },
  //     };

  //     // Handle ICCID and IMEI logic based on ApplicableRatePlanForAll
  //     if (ApplicableRatePlanForAll) {
  //       // if (validIccid.length !== validImei.length) {
  //       //   setErrorMessage("The number of IMEIs must match the number of ICCIDs.");
  //       //   return;
  //       // }
  //       data.Devices=payload.iccids;
  //       data.iccids = payload.iccids; // Use the payload
  //       data.imei = payload.imeis;
  //       console.log("Devices",data.Devices);
  //       console.log("data", data)
  //     } else {
  //       // When ApplicableRatePlanForAll is false
  //       const validIccidList = iccidList.filter(item => item.iccid && item.ratePlanCode);
  //       data.iccidList = validIccidList;
  //       data.iccids = validIccid;
  //       data.Devices = payload.iccids;
  //       console.log("Devices",data.Devices);
  //       console.log("data", data)
  //       const imeis = newIMEI
  //         .split(/[\n,]/)
  //         .map(line => line.trim())
  //         .filter(line => line.length > 0);

  //       data.IMEI = imeis;

  //       // Check if IMEI is provided for each device
  //       for (const item of iccidList) {
  //         if (!item.iccid || !item.ratePlanCode) {
  //           setErrorMessage("ICCID and Rate Plan Code are required.");
  //           return;
  //         }
  //       }
  //     }

  //     // Send the initial request
  //     const response = await axios.post(url, { data });
  //     const parsedData = JSON.parse(response.data.body);

  //     if (parsedData.flag === false) {
  //       setLoading(false);
  //       Modal.error({
  //         title: 'Submit Error',
  //         content: parsedData.message || 'An error occurred while updating data. Please try again.',
  //         centered: true,
  //       });
  //     } else {
  //       const AlliccidList = parsedData.iccid;
  //       const AllimeiList = parsedData.imei;

  //       // Check if all ICCID and IMEI values match
  //       const iccidMatch = payload.iccids.every((iccid: string) => AlliccidList.includes(iccid));
  //       const imeiMatch = payload.imeis.every((imei: string) => AllimeiList.includes(imei));

  //       if (iccidMatch && imeiMatch) {
  //         console.log("All ICCID and IMEI values match.");

  //         // Prepare data for the second request
  //         const data = {
  //           tenant_name: partner || "default_value",
  //           username: username,
  //           firstLastName: firstLastName,
  //           path: "/run_db_script", // Change to the correct path
  //           role_name: role,
  //           module_name: "Bulk Change",
  //           mod_pages: {
  //             start: 0,
  //             end: 100,
  //           },
  //           access_token: token,
  //           db_name: selectedDb,
  //           sessionID: sessionId,
  //           request_received_at: getCurrentDateTime(),
  //           Partner: partner,
  //           bulkchange_id: parsedData?.bulkchange_id?.id,
  //           data: parsedData?.data,
  //           bulk_chnage_id_20: parsedData?.bulk_chnage_id_20
  //         };

  //         // Send the second request
  //         const runDbResponse = await axios.post(url, { data: data });
  //         const runDbResponseData = JSON.parse(runDbResponse.data.body);

  //         if (runDbResponseData.flag === false) {
  //           // Handle error for the second request
  //           Modal.error({
  //             title: "Data Fetch Error",
  //             // content: runDbResponse .message || "An error occurred while fetching updating. Please try again.",
  //             centered: true,
  //           });
  //         } else {
  //           console.log("Run DB script executed successfully.");
  //           const bulkrow_ = parsedData?.bulkchange_id || {};
  //           const bulkRow: any = { row: bulkrow_ };
  //           setBulkRow(bulkRow);
  //           localStorage.setItem('bulk_row', JSON.stringify(bulkRow || "{}"));

  //           // Navigate to the bulk history page
  //           if(bulkRow){
  //             router.push(`/sim_management/bulk_history`);
  //           }
  //         }
          
  //       } else {
  //         console.log("All ICCID and IMEI values do not match. Submission completed without running the script.");
  //         const bulkrow_ = parsedData?.bulkchange_id || {};
  //         const bulkRow: any = { row: bulkrow_ };
  //         setBulkRow(bulkRow);
  //         localStorage.setItem('bulk_row', JSON.stringify(bulkRow || "{}"));

  //         router.push(`/sim_management/bulk_history`);
  //       }
  //     }
  //   } catch (error) {
  //     Modal.error({
  //       title: 'Submit Error',
  //       content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting. Please try again.',
  //       centered: true,
  //     });
  //   } finally {
  //     setLoading(false);
  //   }
  // };

  // const onsubmit = async (payload: { iccids: any; imeis: any; }) => {
  //   try {
  //     const changedData = returnChangedData ? returnChangedData : {};
  //     setLoading(true);
  
  //     const url = ENV_ROUTES.SIM_MANAGEMENT;
  
  //     // Prepare the data object for the initial request
  //     const data: any = {
  //       tenant_name: partner || "default_value",
  //       path: "/update_bulk_change_data", // This path is used for the first request
  //       request_received_at: getCurrentDateTime(),
  //       access_token: token,
  //       db_name: selectedDb,
  //       sessionID: sessionId,
  //       service_provider: service_provider,
  //       change_type: change_type,
  //       created_by: firstLastName,
  //       changed_data: {
  //         ...changedData
  //       },
  //       Devices: payload.iccids,
  //       iccids: payload.iccids,
  //       imei: payload.imeis,
  //     };
  
  //     console.log("Initial Data", data);
  
  //     // Send the initial request
  //     const response = await axios.post(url, { data });
  //     const parsedData = JSON.parse(response.data.body);
  
  //     if (parsedData.flag === false) {
  //       setLoading(false);
  //       Modal.error({
  //         title: 'Submit Error',
  //         content: parsedData.message || 'An error occurred while updating data. Please try again.',
  //         centered: true,
  //       });
  //     } else {
  //       console.log("Initial request successful:", parsedData);
  
  //       // Always call the /run_db_script path
  //       const runDbData = {
  //         tenant_name: partner || "default_value",
  //         username: username,
  //         firstLastName: firstLastName,
  //         path: "/run_db_script", // Always use this path
  //         role_name: role,
  //         module_name: "Bulk Change",
  //         mod_pages: {
  //           start: 0,
  //           end: 100,
  //         },
  //         access_token: token,
  //         db_name: selectedDb,
  //         sessionID: sessionId,
  //         request_received_at: getCurrentDateTime(),
  //         Partner: partner,
  //         bulkchange_id: parsedData?.bulkchange_id?.id,
  //         data: parsedData?.data,
  //         bulk_chnage_id_20: parsedData?.bulk_chnage_id_20
  //       };
  
  //       console.log("Run DB Data", runDbData);
  
  //       // Send the second request
  //       const runDbResponse = await axios.post(url, { data: runDbData });
  //       const runDbResponseData = JSON.parse(runDbResponse.data.body);
  
  //       if (runDbResponseData.flag === false) {
  //         // Handle error for the second request
  //         Modal.error({
  //           title: "Data Fetch Error",
  //           centered: true,
  //         });
  //       } else {
  //         console.log("Run DB script executed successfully.");
  //         const bulkrow_ = parsedData?.bulkchange_id || {};
  //         const bulkRow: any = { row: bulkrow_ };
  //         setBulkRow(bulkRow);
  //         localStorage.setItem('bulk_row', JSON.stringify(bulkRow || "{}"));
  
  //         // Navigate to the bulk history page
  //         if (bulkRow) {
  //           router.push(`/sim_management/bulk_history`);
  //         }
  //       }
  //     }
  //   } catch (error) {
  //     Modal.error({
  //       title: 'Submit Error',
  //       content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting. Please try again.',
  //       centered: true,
  //     });
  //   } finally {
  //     setLoading(false);
  //   }
  // };

  const bulkChangeInsert = async (payload:any) => {
    let partner_name = partner
    let db_name_ = selectedDb
    try {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner_name || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_bulk_change_insertion",
        role_name: role,
        module_name: "Bulk Change History",
        service_provider_name:service_provider,
        ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
        change_type:change_type,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        request_received_at: getCurrentDateTime(),
        Partner: partner_name,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        console.error("Error fetching bulk change data:", parsedData.message ||
          "An error occurred while fetching bulk change data. Please try again.");
          return false
      } else {
        const statusFlag = parsedData?.bulk_change_data?.status || "";
        const response_data = parsedData?.bulk_change_data?.bulk_change_data || "{}";
        const parsedResp = JSON.parse(response_data)
        console.log("status_flag", statusFlag)
        const status_flag = statusFlag ? (statusFlag).toLowerCase() : ""

        if(status_flag && status_flag==="pending"){
          return false
        }
        else if (status_flag && status_flag==="success"){
            call_2_0_submit(parsedResp, payload,true)
            call_2_0_sync(parsedResp)
            return true
        }
        else if (status_flag && status_flag==="error"){
            Modal.error({
                title: 'Submit Error',
                content: parsedData.message || 'An error occurred while submitting. Please try again.',
                centered: true,
            });
            return true
        }
        else{
          return false
        }
      }
    } catch (error) {
      console.error("Error fetching auto refresh data:", error);
      return false
    } finally {
    }
  };
  const bulkChangePolling = async (data:any) => {
    const result = await bulkChangeInsert(data);
    if (!result) {
      setTimeout(() => bulkChangePolling(data), 5000); // Try again after 5 seconds
    } else {
      removeExport("bulkChangeInsert");
      console.log("Auto-refresh complete.");
    }
    // if (window.location.pathname.includes("/sim_management/bulk_change")) {
    //     window.location.reload();
    // }
  };

  const onsubmit = async (payload: { iccids: any; imeis: any; iccid_ip_map?: any}) => {
    let data:any
    try {
      const assignCustomer=returnChangedData["assign_customer"] || null
      const assignCustomerParts=(assignCustomer || "") ? assignCustomer.split("--") : []
      console.log("assignCustomer",assignCustomer)
      delete returnChangedData["assign_customer"]
      const changedData = returnChangedData ? returnChangedData : {};
      setLoading(true);
  
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      // Prepare the data object for the initial request
      data = {
        tenant_name: partner || "default_value",
        path: "/update_bulk_change_data", // This path is used for the first request
        role_name: role,
        username: username,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        service_provider: service_provider,
        ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
        change_type: change_type,
        created_by: firstLastName,
        customer_name:assignCustomer?assignCustomerParts[0].trim() :null,
        customer_id :assignCustomer?assignCustomerParts[1].trim() :null ,
        billing_platform:assignCustomer&&(assignCustomerParts[2]) &&assignCustomerParts[2].trim() === "BP" ? true :false,

        changed_data: {
          ...changedData,
          static_ip_address_checkbox:staticIpAddressCheckbox
        },
        Devices: payload.iccids,
        iccids: payload.iccids,
        imei: payload.imeis,
        ...(payload.iccid_ip_map && Object.keys(payload.iccid_ip_map).length > 0
          ? { iccid_ip_map: payload.iccid_ip_map }
          : {}),
      };
  
      console.log("Initial Data", data);
  
      // Send the initial request
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
  
      if (parsedData.flag === false) {
        setLoading(false);
        Modal.error({
          title: 'Submit Error',
          content: parsedData.message || 'An error occurred while updating data. Please try again.',
          centered: true,
        });
      } else {
        console.log("Initial request successful:", parsedData);
  
        // Navigate to the bulk history page
        const bulkrow_ = parsedData?.bulkchange_id || {};
        const bulkRow: any = { row: bulkrow_ };
        setBulkRow(bulkRow);
        localStorage.setItem('bulk_row', JSON.stringify(bulkRow || "{}"));
        router.push(`/sim_management/bulk_history`);

        // Call the run_db_script without waiting for the response
        if(switch_user_2_0==="True"){
          if (!isAllChangeType) {
            call_2_0_submit(parsedData, data, true);
            call_2_0_sync(parsedData);
          }
          else {
            const payload_2_0_: any = await call_2_0_submit(parsedData, data, false)
            set_all_2_0_payloads((prev: any) => ({
              ...prev,
              [change_type]: { ...payload_2_0_ }
            }));
          }
          }
          else{
            callRunDbScript(parsedData);
          }
      }
    } catch (error) {
      
      if (switch_user_2_0 === "True") {
        onClose()
        setLoading(false)
        addExport("bulkChangeInsert", "Bulk Change Submission");
        bulkChangePolling(data)
      }
      else {
        Modal.error({
          title: 'Submit Error',
          content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting. Please try again.',
          centered: true,
        });
      }
    } finally {
      setLoading(false);
    }
  };
  const fetchCarrierWritesFlag = async () => {
    let parsedData: any
    const url = ENV_ROUTES.SIM_MANAGEMENT;
    const data = {
      tenant_name: partner || "default_value",
      username,
      path: "/get_writes_enable_for_service_provider",
      role_name: role,
      parent_module: "Sim Management",
      module_name: "Inventory",
      service_provider: service_provider || "",
      ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
        ...metaData,
      sessionID: sessionId,
      environment: "BETA",
      change_type: change_type,
    };

    try {
      setLoading(true);
      const response = await axios.post(url, { data });
      parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === true) {
        const write_is_enabled = parsedData?.write_is_enabled || false;
        // setWritesFlag(write_is_enabled);
        return write_is_enabled;
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      return false; // fallback in case of error
    } finally {
      // setLoading(false);
    }
  };
  const submitCarrierStatus = async (payload: { iccids: any; imeis: any},write_is_enabled:boolean) => {
    let parsedData: any
    const url = ENV_ROUTES.SIM_MANAGEMENT;
    const data = {
      tenant_name: partner || "default_value",
      username,
      path: "/insert_carrier_status_validation_audit",
      role_name: role,
      parent_module: "Sim Management",
      module_name: "Inventory",
      service_provider: service_provider || "",
      ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
        ...metaData,
      sessionID: sessionId,
      environment: "BETA",
      msisdn:[],
      iccid: payload?.iccids,
      change_type: change_type,
      write_is_enabled:write_is_enabled,
    };

    try {
      // setLoading(true);
      const response = await axios.post(url, { data });
      parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === true) {

      }
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      // setLoading(false);
    }
  };

  const call_2_0_submit = async (parsedData: any , payload:any,isRouteCall: boolean) => {
        try {
            const url = ENV_ROUTES.BULKCHANGE_PROCESSOR;
            const prevChangedData = payload?.changed_data || {}
            delete payload["imei"]
            delete payload["changed_data"]
            delete payload["Devices"]
            
            const payloadData={
                ...payload , 
                path:"/bulk_change_processor",
                request_received_at:getCurrentDateTime(),
                bulk_change_id:parsedData?.bulk_chnage_id_20,
            }
            const data = {...payloadData};
            if (!isRouteCall) {
              return data
            }
            const response = await axios.post(url, { data });
            const responseData = JSON.parse(response.data.body);
            if (responseData.flag === false) {
               console.log("Failure: 2.0 Bulk change update failed.");
            } else {
                console.log("Success: 2.0 Bulk change update successful.");
        }
    }
        catch (error) {
            console.error("Error running DB script:", error);
        } finally {
            setLoading(false);
        }
    }
  const call_2_0_sync = async (parsedData: any) => {
        try {
            const runDbScriptUrl = ENV_ROUTES.SIM_MANAGEMENT;
            const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
            const runDbScriptData = {
                tenant_name: partner || "default_value",
                username: username,
                firstLastName: firstLastName,
                path: "/update_bulk_change_tables_10",
                role_name: role,
                module_name: "Bulk Change",
                access_token: token,
                db_name: selectedDb,
                ...metaData,
                sessionID: sessionId,
                request_received_at: getCurrentDateTime(),
                Partner: partner,
                // service_provider_id: service_provider_id_,
                // bulkchange_id: parsedData?.bulkchange_id?.id,
                // data: parsedData?.data,
                data:{
                    bulk_change_id: parsedData?.bulk_chnage_id_20,
                },
                is_update: false,
                // bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
            };

            const runDbScriptResponse = await axios.post(runDbScriptUrl, { data: runDbScriptData });
            const runDbScriptResponseData = JSON.parse(runDbScriptResponse.data.body);

            if (runDbScriptResponseData.flag === false) {
                console.error("Data Fetch Error: " + runDbScriptResponseData.message);
            } else {
                console.log("Success: Bulk update successful.");
            }
        }
        catch (error) {
            console.error("Error running DB script:", error);
        } finally {
            setLoading(false);
        }
    }
  
  const callRunDbScript = async (parsedData:any) => {
    try {
      const service_provider_id_=parsedData?.bulkchange_id?.service_provider_id || 1
      const runDbData = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/run_db_script", // Always use this path
        role_name: role,
        module_name: "Bulk Change",
        mod_pages: {
          start: 0,
          end: 100,
        },
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        service_provider_id:service_provider_id_,
        bulkchange_id: parsedData?.bulkchange_id?.id,
        data: parsedData?.data,
        bulk_chnage_id_20: parsedData?.bulk_chnage_id_20
      };
  
      console.log("Run DB Data", runDbData);

  
      // Send the second request
      await axios.post(ENV_ROUTES.SIM_MANAGEMENT, { data: runDbData });
      console.log("Run DB script executed successfully.");
    } catch (error) {
      console.error("Error executing run_db_script:", error);
      // Optionally handle the error here, e.g., show a notification
    }
  };
  
  const handleAddIccid = () => {
    setIccidList([...iccidList, { iccid: '', ratePlanCode: '' }]);
  };

  const handleRemoveIccid = (index: number) => {
    setIccidList(iccidList.filter((_, i) => i !== index));
  };

  const handleIccidChange = (index: number, value: string) => {
    const newIccidList = [...iccidList];
    newIccidList[index].iccid = value;
    setIccidList(newIccidList);
  };

  // const handleRatePlanCodeChange = (index: number, value: string) => {
  //   const newIccidList = [...iccidList];
  //   newIccidList[index].ratePlanCode = value;
  //   setIccidList(newIccidList);
  //   setErrorMessage("");
  // };

  const fetchData = async (payload: { iccids: any; imeis: any; }) => {
    try {
      setLoading(true);
      const url =
        ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        path: "/get_new_bulk_change_data",
        request_received_at: getCurrentDateTime(),
        username: username,
        firstLastName: firstLastName,
        role_name: role,
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        service_provider: service_provider,
        ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
        change_type: change_type,
        imei: payload?.imeis || [],
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        setLoading(false);
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
        return false
      } else {
        const dropdownData_ = parsedData?.response_data?.dropdown_data || {}
        console.log("dropdownData_",dropdownData_)
        setDropdownData(dropdownData_)
        setLoading(false);
        return true
      }
    } catch (error) {
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
      setLoading(false);
      return false
    }
  };
  // IPv4
  const ipv4Regex = /^(\d{1,3}\.){3}\d{1,3}$/;
  const isValidIPv4 = (ip: string) => {
    if (!ipv4Regex.test(ip)) return false;
    return ip.split(".").every(p => {
      if (!/^\d+$/.test(p)) return false;
      const n = Number(p);
      return Number.isInteger(n) && n >= 0 && n <= 255;
    });
  };
  const ipv4ToUint32 = (ip: string) => {
    const [a, b, c, d] = ip.split(".").map(Number);
    return ((a << 24) >>> 0) + (b << 16) + (c << 8) + d;
  };

  // IPv6: expand compressed forms into 8 hextets of 4 hex digits
  const expandIPv6 = (input: string): string[] | null => {
    const raw = input.trim();
    if (!raw) return null;
    // split on :: (0..1 times)
    if (raw.includes("::")) {
      const [left, right] = raw.split("::");
      const leftParts = left ? left.split(":").filter(Boolean) : [];
      const rightParts = right ? right.split(":").filter(Boolean) : [];
      if (leftParts.some(p => p.length > 4) || rightParts.some(p => p.length > 4)) return null;
      const missing = 8 - (leftParts.length + rightParts.length);
      if (missing < 0) return null;
      const mid = new Array(missing).fill("0");
      const parts = [...leftParts, ...mid, ...rightParts].map(p => p || "0");
      if (parts.length !== 8) return null;
      return parts.map(p => p.padStart(4, "0").toUpperCase());
    } else {
      const parts = raw.split(":");
      if (parts.length !== 8) return null;
      if (parts.some(p => p.length === 0 || p.length > 4)) return null;
      return parts.map(p => p.padStart(4, "0").toUpperCase());
    }
  };

  // Detect IPv6 (rough)
  const looksLikeIPv6 = (s: string) => s.includes(":");

  // Convert expanded 8 hextets -> BigInt
  const ipv6PartsToBigInt = (parts: string[]) => {
    // each part is 4 hex digits -> 16 bits
    let acc = BigInt(0);
    for (let i = 0; i < 8; i++) {
      const v = BigInt(parseInt(parts[i], 16) & 0xFFFF);
      acc = (acc << BigInt(16)) + v;
    }
    return acc;
  };
  const parseSavedRange = (ipRange: string) => {
    if (!ipRange) return { ok: false as const };

    const parts = ipRange.split("-");
    if (parts.length !== 2) return { ok: false as const };

    const s = parts[0].trim();
    const e = parts[1].trim();

    // IPv4 branch
    if (!looksLikeIPv6(s) && !looksLikeIPv6(e)) {
      if (!isValidIPv4(s) || !isValidIPv4(e)) return { ok: false as const };
      const sN = ipv4ToUint32(s);
      const eN = ipv4ToUint32(e);
      const start = Math.min(sN, eN);
      const end = Math.max(sN, eN);
      return { ok: true as const, family: "ipv4" as const, startNum: start, endNum: end };
    }

    // IPv6 branch
    const sExp = expandIPv6(s);
    const eExp = expandIPv6(e);
    if (!sExp || !eExp) return { ok: false as const };
    const sBig = ipv6PartsToBigInt(sExp);
    const eBig = ipv6PartsToBigInt(eExp);
    const startBig = sBig <= eBig ? sBig : eBig;
    const endBig = sBig <= eBig ? eBig : sBig;
    return { ok: true as const, family: "ipv6" as const, startBig, endBig };
  };

  interface IPValidation {
    valid: boolean;
    error: string;
  }

  const unavailableIPError = async (
    ipList: string | string[],
    changeType: string
  ): Promise<IPValidation> => {
    try {
      setLoading(true);

      const url = ENV_ROUTES.MODULE_MANAGEMENT;

      const data = {
        tenant_name: partner || "default_value",
        username,
        firstLastName,
        path: "/validate_ips_availability",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        change_type: changeType || "",
        ip_list: ipList || [],
        service_provider: service_provider || "",
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      // ❌ Invalid cases
      if (parsedData.flag === false || parsedData?.validation) {
        return {
          valid: false,
          error: parsedData?.message || "Enter IP address within the available IP list",
        };
      }

      // ✅ Success case
      return {
        valid: true,
        error: "",
      };

    } catch (error) {
      return {
        valid: false,
        error: "Enter IP address within the available IP list",
      };
    } finally {
      setLoading(false);
    }
  };

  const validateFieldIp = async (
    value: string[],
    ipRange: string | string[]
  ): Promise<IPValidation> => {

    // const v = String(value ?? "").trim();

    if (!value || value.length === 0) {
      return { valid: false, error: "Enter a valid IP address" };
    }

    return await unavailableIPError(value, change_type);
  };

  const validateFieldIp_ = (
    value: string,
    ipRange: string | string[]
  ): { valid: boolean; error: string } => {
    const v = String(value ?? "").trim();
    if (!v) return { valid: false, error: "Enter a valid IP address" };

    // Normalize ranges to array of non-empty strings
    const ranges = (Array.isArray(ipRange) ? ipRange : [ipRange])
      .map(r => String(r ?? "").trim())
      .filter(r => r.length > 0);

    if (ranges.length === 0) {
      return {
        valid: false,
        error: "Enter IP address within the given IP range",
      };
    }

    const isV6 = looksLikeIPv6(v);

    // ================= IPv6 =================
    if (isV6) {
      const expanded = expandIPv6(v);
      if (!expanded) {
        return { valid: false, error: "Enter a valid IP address" };
      }

      // Parse all ranges that are valid IPv6
      const parsedV6Ranges = ranges
        .map(r => parseSavedRange(r))
        .filter(p => p.ok && p.family === "ipv6");

      if (parsedV6Ranges.length === 0) {
        return {
          valid: false,
          error: "Enter IP address within the given IP range",
        };
      }

      const vBig = ipv6PartsToBigInt(expanded);

      const inAnyRange = parsedV6Ranges.some(p => {
        return vBig >= p.startBig && vBig <= p.endBig;
      });

      if (!inAnyRange) {
        return {
          valid: false,
          error: "Enter IP address within the given IP range",
        };
      }

      return { valid: true, error: "" };
    }

    // ================= IPv4 =================
    if (!isValidIPv4(v)) {
      return { valid: false, error: "Enter a valid IP address" };
    }

    // Parse all ranges that are valid IPv4
    const parsedV4Ranges = ranges
      .map(r => parseSavedRange(r))
      .filter(p => p.ok && p.family === "ipv4");

    if (parsedV4Ranges.length === 0) {
      return {
        valid: false,
        error: "Enter IP address within the given IP range",
      };
    }

    const vN = ipv4ToUint32(v);

    const inAnyRange = parsedV4Ranges.some(p => {
      return vN >= p.startNum && vN <= p.endNum;
    });

    if (!inAnyRange) {
      return {
        valid: false,
        error: "Enter IP address within the given IP range",
      };
    }

    return { valid: true, error: "" };
  };
  const fetchOptionsMappings = async () => {
    try {
      const url =
        ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        path: "/get_private_network_pdp_apn_ip_mappings",
        request_received_at: getCurrentDateTime(),
        username: username,
        firstLastName: firstLastName,
        role_name: role,
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        service_provider: service_provider,
        ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" },
        change_type: change_type
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        const pdp_ip_map = parsedData?.pdp_ip_map || {};
        setPdpIpMap(pdp_ip_map)

        // const apn_options = Object.keys(apn_pdp_map) || []
        // setApnOptions(apn_options)

        const pdp_options = parsedData?.pdp || [];
        setPdpOptions(pdp_options)

        const ip_options = parsedData?.ip_addresses || {};
        setIPOptions(ip_options)
        console.log("ip_options", ip_options)
      }
    } catch (error) {
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    }
  };
 const handleSubmit = async () => {
   if (ApplicableRatePlanForAll) {
     if (staticIpAddressCheckbox) {

       const errors: string[] = [];

       if (!iccidText || iccidText.trim() === "") {
         setErrors(["Please fill in Devices."]);
         return;
       }

       setErrors([]);
       setIccidError("");

       const lines = iccidText
         .split("\n")
         .map(l => l.trim())
         .filter(Boolean);

       const iccids: string[] = [];
       const imeis: string[] = [];
       const iccid_ip_map: Record<string, string> = {};
       const seenIccids = new Set<string>();
       const ipList:any = []


       lines.forEach((line, index) => {
         const lineNo = index + 1;
         const parts = line.split(",").map(p => p.trim());

         if (parts.length !== 3) {
           errors.push(`Line ${lineNo}: Use format ICCID,IMEI,IP`);
           return;
         }

         const [iccidVal, imeiVal, ipVal] = parts;

         /* ---------- ICCID ---------- */
         if (!/^\d+$/.test(iccidVal)) {
           errors.push(`Line ${lineNo}: ICCID must contain numbers only`);
         } else if (iccidVal.length < 14 || iccidVal.length > 22) {
           errors.push(`Line ${lineNo}: ICCID must be between 14 and 22 digits`);
         }

         if (seenIccids.has(iccidVal)) {
           errors.push(`Line ${lineNo}: Duplicate ICCID`);
         } else {
           seenIccids.add(iccidVal);
         }

         /* ---------- IMEI ---------- */
         if (!/^\d+$/.test(imeiVal)) {
           errors.push(`Line ${lineNo}: IMEI must contain numbers only`);
         } else if (imeiVal.length < 12 || imeiVal.length > 22) {
           errors.push(`Line ${lineNo}: IMEI must be between 12 and 22 digits`);
         }

         /* ---------- IP ---------- */
         if (!ipVal) {
           errors.push(`Line ${lineNo}: IP Address is required`);
         } else {
           if (!ipList.includes(ipVal)) {
            ipList.push(ipVal);
          }
          //  const ipResult = validateFieldIp(ipVal, IPOptions || []);
          //  if (!ipResult.valid) {
          //    errors.push(`Line ${lineNo}: ${ipResult.error}`);
          //  }
         }

         // collect valid values
         iccids.push(iccidVal);
         imeis.push(imeiVal);
         iccid_ip_map[iccidVal] = ipVal;
       });
       const ipResult: any = await validateFieldIp(ipList, IPOptions || []);
        if (!ipResult?.valid) {
          errors.push(
          ipResult?.result || "Enter IP address within the available IP list"
        );
        }
       /* ---------- BULK LIMIT ---------- */
       if (iccids.length > bulkChangeLimit) {
         errors.push(
           `This request exceeds the allowed record limit of ${bulkChangeLimit}`
         );
       }

       /* ---------- STOP ON ERRORS ---------- */
       if (errors.length > 0) {
         setErrors(errors);
         return;
       }

       setErrors([]);

       /* ---------- PAYLOAD ---------- */
       const payload = {
         iccids,
         imeis,
         iccid_ip_map,
         Devices: iccids,
       };

       console.log("Payload:", payload);

       setsetActivationPayload(payload);

       /* ---------- FLOW ---------- */
       if (isNextScreen) {
         const isIMEIValidated = await fetchData(payload);
         if (isIMEIValidated) onClose();
         return;
       }

       const writes_flag = await fetchCarrierWritesFlag();

       if (writes_flag) {
         Modal.confirm({
           title: "Carrier API Enabled",
           content:
             "Carrier API settings are enabled. Submitting now will trigger the Carrier API directly. Do you want to proceed?",
           centered: true,
           okText: "Submit",
           onOk: () => {
             onsubmit(payload);
             submitCarrierStatus(payload, writes_flag);
           },
           onCancel: onClose,
         });
       } else {
         onsubmit(payload);
       }
     }
     else{
      let hasError = false;
  
      // Validate and split the input into an array
      const inputValues = iccidText
        .split(/\s*[\n,]\s*/) // Split by new line or comma
        .map((item) => item.trim()) // Trim spaces from each item
        .filter((item) => item.length > 0); // Remove empty strings
  
      // Check if input is empty
      if (inputValues.length === 0) {
        setIccidError("ICCID is required.");
        console.log("Validation failed: ICCID is required.");
        hasError = true;
      }
  
      const iccids: string[] = [];
      const imeis: string[] = [];
      if (inputValues.length % 2 !== 0) {
      setIccidError("Please fill in both values separated by a comma.");
      return;
    }
      // Separate input into ICCIDs and IMEIs alternately
      for (let i = 0; i < inputValues.length; i++) {
        const value = inputValues[i];

        if (i % 2 === 0) {
          // Even index: ICCID
          if (!/^\d+$/.test(value)) {
            setIccidError("Please enter numbers only for ICCID. Letters or special characters are not allowed");
            console.log("Validation failed: ICCID contains non-numeric characters.");
            hasError = true;
            break;
          } else if (value.length < 14 || value.length > 22) {
            setIccidError("Each ICCID must be between 14 and 22 digits long.");
            console.log("Validation failed: ICCID has invalid length.");
            hasError = true;
            break;
          } else {
            iccids.push(value);
          }
        } else {
          // Odd index: IMEI
          if (!/^\d+$/.test(value)) {
            setIccidError("IMEI must contain digits only.");
            console.log("Validation failed: IMEI contains non-numeric characters.");
            hasError = true;
            break;
          } else if (value.length < 12 || value.length > 22) {
            setIccidError("Each IMEI must be between 12 and 22 digits long.");
            console.log("Validation failed: IMEI has invalid length.");
            hasError = true;
            break;
          } else {
            imeis.push(value);
          }
        }
      }

      if (iccids.length > bulkChangeLimit || imeis.length > bulkChangeLimit){
        setIccidError(`This request exceeds the allowed record limit  of ${bulkChangeLimit} and cannot be processed`);
        console.log("Limit Exceeded");
        hasError = true;
      }
  
      if (hasError) {
        return; // Exit if any validation error occurred
      } else {
        setIccidError(""); // Clear error if validation passed
      }
  
      console.log("Valid ICCIDs: ", iccids);
      console.log("Valid IMEIs: ", imeis);
  
      // Prepare the payload
      const payload = {
        iccids: iccids, 
        imeis: imeis,
        Devices: iccids,
      };
  
      console.log("Payload:", payload);
      setsetActivationPayload(payload)
      if(isNextScreen){
      const isIMEIValidated = await fetchData(payload)
      console.log("isIMEIValidated",isIMEIValidated)
      if(isIMEIValidated){
        onClose()
      }
      return
    }else{
      // Pass payload to the submit function
       const writes_flag = await fetchCarrierWritesFlag()
      
          if (writes_flag) {
                const modal = Modal.confirm({
                  title: "Carrier API Enabled",
                  content: "Carrier API settings are enabled. Submitting now will trigger the Carrier API directly. Do you want to proceed?",
                  centered: true,
                  okText: "Submit",
                  onOk: () => {
                    // modal.destroy(); // closes the modal
                    // handleCloseModal();
                    
                    onsubmit(payload);
                    submitCarrierStatus(payload,writes_flag);
                  },
                  onCancel: onClose,
                });
              }
              else{
                onsubmit(payload);
              }
      
    }
     }
   }
};

const handlePreviewOpen = async () => {
            setPreviewModal(true)
        };
const handlePDPNameSelect = (selectedOption: any) => {
  if (selectedOption) {
    const value = selectedOption?.value
    setSelectedPDP(value)

    const ip_options = pdpIpMap[value] || []
    setIPOptions(ip_options)
  }
  else {
    setSelectedPDP(null)
    setIPOptions([])

  }
};
  if (loading) {
    return (
      <div className="flex justify-center items-center h-[400px]">
        <Spin size="large" />
      </div>
    );
  }

  return (
    <div className="flex flex-col space-y-4 mt-4">
      <h2 className="text-500 font-semibold">Select devices</h2>
      {ApplicableRatePlanForAll ? (
        <>
          {/* Combined ICCID & IMEI field */}
          <div className="flex flex-col space-y-2">
            {staticIpAddressCheckbox && (<div
              className="flex flex-col space-y-2">
                <label htmlFor="pdpName" className={"font-semibold"}>
                {`${isTelegence ? "PDP Name" : "PDP ID"}`}
              </label>
              <ReactSelect
                id="pdpName"
                placeholder={`Select ${isTelegence ? "PDP Name" : "PDP ID"
                  }`}
                options={pdpOptions.map((option: string) => ({
                  label: option,
                  value: option,
                }))}
                value={{ label: selectedPDP, value: selectedPDP }}
                onChange={handlePDPNameSelect}
                styles={DropdownStyles}
                className="w-full"
                isClearable
              />
              {(!selectedPDP && (
                <span className="text-blue-500">* Please select a PDP to view available IP addresses.</span>
              ))}
            </div>)}
            <div className="flex items-center justify-between">
              <label htmlFor="iccid-imei" className="font-semibold">
                {staticIpAddressCheckbox ? "ICCID , IMEI & IP" : "ICCID & IMEI"} 
                <span className="text-red-500">*</span></label>
            {staticIpAddressCheckbox && selectedPDP && (  
              <Tooltip title="Preview or view IP details">
                <InfoIcon
                  className="h-5 w-5 text-gray-500 cursor-pointer"
                  onClick={() => {handlePreviewOpen(),setInfoFlag(true)}}
                />
              </Tooltip>)}
            </div>
            <Input.TextArea
              id="iccid-imei"
              rows={6}
              placeholder={ 
                staticIpAddressCheckbox ? "Enter ICCIDs, IMEIs and IP Address separated by a comma (e.g., ICCID,IMEI,IP)":
              "Enter ICCID and IMEI (one per line, separated by comma)"}
              value={iccidText}
              onChange={(e) => setIccidText(e.target.value)} />
            {iccidError && <div className="text-red-500 text-sm">{iccidError}</div>}
          </div>
        </>
      ) : (
        iccidList.map((item, index) => (
          <div key={index} className="flex space-x-4">
            <Input
              value={item.iccid}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleIccidChange(index, e.target.value)}
              placeholder="ICCID"
              className="w-1/2 h-10"
              required
            />
            {/* <Select
              showSearch
              value={item.ratePlanCode}
              onChange={(value: string) => handleRatePlanCodeChange(index, value)}
              // options={RatePlanCodeList?.map((ratePlanCode: string) => ({ value: ratePlanCode, label: ratePlanCode }))}
              options={RatePlanCodeList?.map((ratePlanCode: string) => ({ value: ratePlanCode, label: ratePlanCode }))}
              className="w-1/2 h-10"
            /> */}
            {iccidList.length > 1 && (
              <Button onClick={() => handleRemoveIccid(index)}>Remove</Button>
            )}
          </div>
        ))
      )}
      {!ApplicableRatePlanForAll && <Button onClick={handleAddIccid}>Add</Button>}
      {errors.length > 0 && (
        <div className="mt-2">
          {errors.map((err, i) => (
            <div key={i} className="text-red-500 text-sm">
              {err}
            </div>
          ))}
        </div>
      )}

      <div className="flex justify-center space-x-4 mt-4">
        <button
          onClick={onBack}
          className="cancel-btn"
        >
          {/* <ArrowLeftIcon className="h-5 w-5 mr-2" /> */}
          Back
        </button>
        <button
          onClick={handleSubmit}
          className="save-btn"
        >
          {isNextScreen?"Continue":"Submit"}
        </button>
      </div>
      <PrivateNetworkPreviewModal
        service_provider={service_provider}
        change_type={change_type}
        openPreviewModal={openPreviewModal}
        setPreviewModal={setPreviewModal}
        selectedPDP={selectedPDP || ""}
      />
    </div>
    

  );
};

export default ActivateSelectDevices;
