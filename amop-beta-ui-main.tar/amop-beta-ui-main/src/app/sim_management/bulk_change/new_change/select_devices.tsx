"use client";

import { FC, forwardRef, useEffect, useImperativeHandle, useRef, useState } from "react";
import { Input, Button, Modal, Spin, Checkbox, Tooltip } from "antd";
import { ArrowLeftIcon } from "@heroicons/react/24/outline";
import { useAuth } from "@/app/components/auth_context";
import { useRouter } from 'next/navigation';
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { TargetStatus } from "@/components/activate-iccid/target-status";
import { json } from "stream/consumers";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import UploadComponent from "./upload_component";
import { useAllChangeTypesStore } from "@/app/stores/allChangeTypesStore";
import { PerformanceLogStore } from "@/app/stores/performance_matrix_store";
import UploadComponent2 from "./upload_component_2";
import { InfoIcon } from "lucide-react";
import PrivateNetworkPreviewModal from "./private_network_preview";
import moment , { Moment } from "moment";
import Select from "react-select";
import { DropdownStyles } from "@/app/components/css/dropdown";

interface SelectDevicesProps {
  onContinue: () => void;
  onBack: () => void;
  service_provider: any;
  change_type: any;
  changed_data?: any;
  isNextScreen?: boolean;
  onClose?: () => void;
  setSelectedCustomers?: (value: any[]) => void;
  onCancel: () => void;
  targetStatus? : string;
}

export interface SelectContentRef {
  runSubmit: () => Promise<void> | void;
}

const SelectDevices = forwardRef<SelectContentRef, SelectDevicesProps>(
  ({ onContinue, onBack, service_provider, change_type, changed_data, isNextScreen, onClose, setSelectedCustomers, onCancel,targetStatus }, ref) => {
  const [iccid, setIccid] = useState("");
  const [newIMEI, setNewIMEI] = useState("");
  const [loading, setLoading] = useState(false);
  const { username, role, partner, token, selectedDb, metaData, firstLastName, sessionId, modulesVersionMap } = useAuth();
  const router = useRouter();
  const { setRowId, setBulkRow, setsetActivationPayload, bulkChangeLimit, simIdentifierMap } = useFeatureStore();
  const [isIMEI, setIsIMEI] = useState<boolean>(false)
  const [isIpField, setIsIpField] = useState<boolean>(false)
  const [openPreviewModal, setPreviewModal] = useState<boolean>(false);
  const [errors, setErrors] = useState<string[]>([]);
  const [subscriberNumber, setSubscriberNumber] = useState<string>("");
  const initial_version_flag = modulesVersionMap?.["Sim Management-Bulk Change"] || false
  const isVersionEnabled = localStorage.getItem("switch_user_2_0_bulk_change") === "True";
  const switch_user_2_0 = isVersionEnabled && initial_version_flag ? "True" : "False"
  const { addExport, removeExport, exports } = exportLoadingStore();
  const { isAllChangeType, allChangeTypesDevices ,SelectedPDPGlobal, all_2_0_payloads, set_all_2_0_payloads } = useAllChangeTypesStore();
  const [iccidError, setIccidError] = useState("");
  const [imeiError, setImeiError] = useState("");
  const { getTargetTenantProvider, IsTargetTenantProvider } = PerformanceLogStore();
  const is_parent_provider_exists = IsTargetTenantProvider(service_provider)
  const providerName = getTargetTenantProvider(service_provider).toLowerCase() || service_provider;
  const [pdpOptions, setPdpOptions] = useState<any>([]);
  const [pdpIpMap, setPdpIpMap] = useState<any>({});
  const [selectedPDP, setSelectedPDP] = useState<string | null>(null);
  const [IPOptions, setIPOptions] = useState<any>([]);
  const hasFetchedRef = useRef(false);
  const isTelegence = providerName.toLowerCase().includes("telegence");
  const [infoFlag,setInfoFlag] = useState<boolean>(false);

  
  // const onsubmit = async (payload: any) => {
  //   try {
  //     const changedData = changed_data ? changed_data : {};
  //     setLoading(true);


  //     // Prepare payload
  //     const url = ENV_ROUTES.SIM_MANAGEMENT;
  //     const data = {
  //       tenant_name: partner || "default_value",
  //       path: "/update_bulk_change_data",
  //       request_received_at: getCurrentDateTime(),
  //       access_token: token,
  //       db_name: selectedDb,
  //       sessionID: sessionId,
  //       service_provider: service_provider,
  //       change_type: change_type,
  //       created_by: firstLastName,
  //       iccids: payload.iccids,
  //       imeids: payload.imeis,
  //       changed_data: {
  //         OverrideValidation: false,
  //         Devices: payload.iccids,
  //         ...changedData
  //       }
  //     };

  //     // Send request to backend
  //     const response = await axios.post(url, { data });
  //     const parsedData = JSON.parse(response.data.body);

  //     if (parsedData.flag === false) {
  //       setLoading(false);
  //       Modal.error({
  //         title: 'Submit Error',
  //         content: parsedData.message || 'An error occurred while submitting. Please try again.',
  //         centered: true,
  //       });
  //     } else {
  //       const bulkrow_ = parsedData?.bulkchange_id || {};
  //       const bulkRow: any = { row: bulkrow_ };
  //       setBulkRow(bulkRow);
  //       localStorage.setItem('bulk_row', JSON.stringify(bulkRow || "{}"));
  //       if (bulkRow) {
  //         router.push(`/sim_management/bulk_history`);
  //       }

  //       const AlliccidList = parsedData.iccid;
  //       const AllimeiList = parsedData.imei;

  //       // Compare ICCID and IMEI values against the lists
  //       const iccidMatch = payload.iccids.every((iccid: any) => AlliccidList.includes(iccid));
  //       const imeiMatch = payload.imeis.every((imei: any) => AllimeiList.includes(imei));

  //       if (
  //         (service_provider === "Verizon - ThingSpace IoT" && (changed_data.UpdateStatus === "Active" || changed_data.UpdateStatus === "Pending activation")) ||
  //         (service_provider === "Verizon - ThingSpace PN" && (changed_data.UpdateStatus === "Active" || changed_data.UpdateStatus === "Pending activation")) ||
  //         service_provider.includes("AT&T - Telegence")
  //       ) {
  //         if (!iccidMatch || !imeiMatch) {
  //           console.log("All ICCID and IMEI values do not match.");
  //         } else {
  //           try {
  //             const url = ENV_ROUTES.SIM_MANAGEMENT;
  //             const data = {
  //               tenant_name: partner || "default_value",
  //               username: username,
  //               firstLastName: firstLastName,
  //               path: "/run_db_script",
  //               role_name: role,
  //               module_name: "Bulk Change",
  //               mod_pages: { start: 0, end: 100 },
  //               access_token: token,
  //               db_name: selectedDb,
  //               sessionID: sessionId,
  //               request_received_at: getCurrentDateTime(),
  //               Partner: partner,
  //               bulkchange_id: parsedData?.bulkchange_id?.id,
  //               data: parsedData?.data,
  //               bulk_chnage_id_20: parsedData?.bulk_chnage_id_20
  //             };

  //             const response = await axios.post(url, { data });
  //             const responseData = JSON.parse(response.data.body);

  //             if (responseData.flag === false) {
  //               console.error("Data Fetch Error: " + responseData.message);
  //             } else {
  //               console.log("Success: Bulk update successful.");
  //             }
  //           } catch (error) {
  //             console.error("Error fetching data:", error);
  //           }
  //         }
  //       } else {
  //         if (!iccidMatch) {
  //           console.log("All ICCID values do not match.");
  //         } else {
  //           console.log("All ICCID values match.");
  //           try {
  //             const url = ENV_ROUTES.SIM_MANAGEMENT;
  //             const data = {
  //               tenant_name: partner || "default_value",
  //               username: username,
  //               firstLastName: firstLastName,
  //               path: "/run_db_script",
  //               role_name: role,
  //               module_name: "Bulk Change",
  //               mod_pages: { start: 0, end: 100 },
  //               access_token: token,
  //               db_name: selectedDb,
  //               sessionID: sessionId,
  //               request_received_at: getCurrentDateTime(),
  //               Partner: partner,
  //               bulkchange_id: parsedData?.bulkchange_id?.id,
  //               data: parsedData?.data,
  //               bulk_chnage_id_20: parsedData?.bulk_chnage_id_20
  //             };

  //             const response = await axios.post(url, { data });
  //             const responseData = JSON.parse(response.data.body);

  //             if (responseData.flag === false) {
  //               console.error("Data Fetch Error: " + responseData.message);
  //             } else {
  //               console.log("Success: Bulk update successful.");
  //             }
  //           } catch (error) {
  //             console.error("Error fetching data:", error);
  //           }
  //         }
  //       }
  //     }
  //   } catch (error) {
  //     Modal.error({
  //       title: 'Submit Error',
  //       content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting. Please try again.',
  //       centered: true,
  //     });
  //   } finally {
  //     setLoading(false);
  //   }
  // };
const fetchOptionsMappings = async () => {
            try {
                const url =
                    ENV_ROUTES.MODULE_MANAGEMENT;
                const data = {
                    tenant_name: partner || "default_value",
                    path: "/get_private_network_pdp_apn_ip_mappings",
                    request_received_at: getCurrentDateTime(),
                    username: username,
                    firstLastName: firstLastName,
                    role_name: role,
                    Partner: partner,
                    access_token: token,
                    db_name: selectedDb,
                    ...metaData,
                    sessionID: sessionId,
                    service_provider: service_provider,
                    selected_pdp: isAllChangeType ?SelectedPDPGlobal : selectedPDP,
                    info_flag:infoFlag,
                    ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" },
                    change_type: change_type
                };

                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);
                if (parsedData.flag === false) {
                    Modal.error({
                        title: 'Data Fetch Error',
                        content: parsedData.message || 'An error occurred while fetching data. Please try again.',
                        centered: true,
                    });
                } else {
                    // const apn_pdp_map = parsedData?.apn_pdp_map || {};
                    // setApnPdpMap(apn_pdp_map)
                    const pdp_ip_map = parsedData?.pdp_ip_map || {};
                    setPdpIpMap(pdp_ip_map)

                    // const apn_options = Object.keys(apn_pdp_map) || []
                    // setApnOptions(apn_options)

                    const pdp_options = parsedData?.pdp || [];
                    setPdpOptions(pdp_options)

                    const ip_options = parsedData?.ip_addresses || {};
                    setIPOptions(ip_options)
                }
            } catch (error) {
                Modal.error({
                    title: 'Data Fetch Error',
                    content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
                    centered: true,
                });
            }
        };
  const callKoreSync = async (data: any) => {
    const koreUrl = ENV_ROUTES.SM_BULK_CHANGE;
    let koreData = { ...data }
    koreData["path"] = "/start_sync"

    try {
      const koreResponse = await axios.post(koreUrl, { data: koreData });
      const koreResponseData = JSON.parse(koreResponse.data.body);

      if (koreResponseData.flag === false) {
        console.log("Data Fetch Error: " + koreResponseData.message);
      } else {
        console.log("Success: Bulk update successful.");
      }

    }
    catch {
      console.log("error in Start Sync");
    }
  }

  const callRestoreCancelledSync = async (payload: any, parsedData: any) => {
    const url = ENV_ROUTES.SM_BULK_CHANGE;
    const data_ = {
      tenant_name: partner || "default_value",
      path: "/telegence_bc_update_device_status_restore_cancelled",
      role_name: role,
      request_received_at: getCurrentDateTime(),
      access_token: token,
      db_name: selectedDb,
                ...metaData,
      sessionID: sessionId,
      service_provider: service_provider,
      ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
      change_type: change_type,
      created_by: firstLastName,
      msisdns: payload.iccids,
      bulk_change_id: parsedData?.bulk_chnage_id_20,
      tenant_id: parsedData?.tenant_id,
    };


    try {
      const koreResponse = await axios.post(url, { data: data_ });
      const koreResponseData = JSON.parse(koreResponse.data.body);

      if (koreResponseData.flag === false) {
        console.log("Data Fetch Error: " + koreResponseData.message);
      } else {
        console.log("Success: Bulk update successful.");
      }

    }
    catch {
      console.log("error in Start Sync");
    }
  }

  const callMismatchICCID = async (parsedData: any) => {
    const url = ENV_ROUTES.SIM_MANAGEMENT;
    const data = {
      tenant_name: partner || "default_value",
      username: username,
      firstLastName: firstLastName,
      path: "/bulk_change_validation_update",
      role_name: role,
      module_name: "Bulk Change",
      access_token: token,
      db_name: selectedDb,
                ...metaData,
      sessionID: sessionId,
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      bulkchange_id: parsedData?.bulkchange_id?.id,
      bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
    };

    const response = await axios.post(url, { data });
    const parsedResponse = JSON.parse(response.data.body);

    if (parsedResponse.flag === false) {
      console.error("Data Fetch Error mismatch ICCID: " + parsedResponse.message);
    } else {
      console.log("Success: Bulk update successful.");
    }
  }

  const fetchCarrierWritesFlag = async () => {
    let parsedData: any
    const url = ENV_ROUTES.SIM_MANAGEMENT;
    const data = {
      tenant_name: partner || "default_value",
      username,
      path: "/get_writes_enable_for_service_provider",
      role_name: role,
      parent_module: "Sim Management",
      module_name: "Inventory",
      service_provider: service_provider || "",
      ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
                ...metaData,
      sessionID: sessionId,
      environment: "BETA",
      change_type: change_type,
    };

    try {
      setLoading(true);
      const response = await axios.post(url, { data });
      parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === true) {
        const write_is_enabled = parsedData?.write_is_enabled || false;
        // setWritesFlag(write_is_enabled);
        return write_is_enabled;
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      return false; // fallback in case of error
    } finally {
      setLoading(false);
    }
  };
  const submitCarrierStatus = async (payload: any, write_is_enabled:boolean) => {
    let parsedData: any
    const url = ENV_ROUTES.SIM_MANAGEMENT;
    const isMSISDN = (providerName.includes("telegence") && (change_type === "Change Customer Rate Plan" || change_type === "Update Device Status" || change_type === "Update PPU address" || change_type === "Update Features" || change_type === "Refresh A Line"))
    const data = {
      tenant_name: partner || "default_value",
      username,
      path: "/insert_carrier_status_validation_audit",
      role_name: role,
      parent_module: "Sim Management",
      module_name: "Inventory",
      service_provider: service_provider || "",
      ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
                ...metaData,
      sessionID: sessionId,
      environment: "BETA",
      msisdn: isMSISDN ? payload?.iccids : [],
      iccid: !isMSISDN ? payload?.iccids : [],
      change_type: change_type,
       write_is_enabled:write_is_enabled,

    };

    try {
      // setLoading(true);
      const response = await axios.post(url, { data });
      parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === true) {

      }
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      // setLoading(false);
    }
  };

  const bulkChangeInsert = async (payload: any) => {
    let partner_name = partner
    let db_name_ = selectedDb
    try {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner_name || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_bulk_change_insertion",
        role_name: role,
        module_name: "Bulk Change History",
        service_provider_name: service_provider,
        ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
        change_type: change_type,
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
        request_received_at: getCurrentDateTime(),
        Partner: partner_name,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        console.error("Error fetching bulk change data:", parsedData.message ||
          "An error occurred while fetching bulk change data. Please try again.");
        return false
      } else {
        const statusFlag = parsedData?.bulk_change_data?.status || "";
        const response_data = parsedData?.bulk_change_data?.bulk_change_data || "{}";
        const parsedResp = JSON.parse(response_data)
        console.log("status_flag", statusFlag)
        const status_flag = statusFlag ? (statusFlag).toLowerCase() : ""

        if (status_flag && status_flag === "pending") {
          return false
        }
        else if (status_flag && status_flag === "success") {
          call_2_0_submit(parsedResp, payload,true)
          call_2_0_sync(parsedResp)
          return true
        }
        else if (status_flag && status_flag === "error") {
          Modal.error({
            title: 'Submit Error',
            content: parsedData.message || 'An error occurred while submitting. Please try again.',
            centered: true,
          });
          return true
        }
        else {
          return false
        }
      }
    } catch (error) {
      console.error("Error fetching auto refresh data:", error);
      return false
    } finally {
    }
  };
  const bulkChangePolling = async (data: any) => {
    const result = await bulkChangeInsert(data);
    if (!result) {
      setTimeout(() => bulkChangePolling(data), 5000); // Try again after 5 seconds
    } else {
      removeExport("bulkChangeInsert");
      console.log("Auto-refresh complete.");
    }
    // if (window.location.pathname.includes("/sim_management/bulk_change")) {
    //     window.location.reload();
    // }
  };

  const onsubmit = async (payload: any) => {
    console.log("onsubmit called",change_type)
    let data: any
    try {
      const changedData = changed_data ? { ...changed_data } : {};
      const overwrite_flag = changed_data?.overwrite || false
      if (change_type.toLowerCase() === "update device status") {
        delete changedData["effectiveDate"]
        delete changedData["sim_status"]
        delete changedData["account_number"]
        delete changedData["device_status_id"]
      }
      if (change_type.toLowerCase() === "update features") {
        delete changedData["overwrite"]
      }
      setLoading(true);

      // Prepare payload for the first API
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const finalPayload = {
        // ...payload,

        ...(
          isAllChangeType
            ? (
              allChangeTypesDevices?.iccid_ip_map &&
                Object.keys(allChangeTypesDevices.iccid_ip_map).length > 0
                ? { iccid_ip_map: allChangeTypesDevices.iccid_ip_map }
                : {}
            )
            : (
              payload?.iccid_ip_map &&
                Object.keys(payload.iccid_ip_map).length > 0
                ? { iccid_ip_map: payload.iccid_ip_map }
                : {}
            )
        ),
      };

      data = {
        tenant_name: partner || "default_value",
        path: "/update_bulk_change_data",
        role_name: role,
        username: username,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
        service_provider: service_provider,
        ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
        change_type: change_type,
        created_by: firstLastName,
        ... ((change_type === "Update Features")
          ? { overwrite: overwrite_flag }
          : {}),
        ... ((change_type === "Update PPU address" || change_type === "Update Features" || change_type === "Refresh A Line")
          ? { iccids: payload.iccids }
          : {
            iccids: payload.iccids,
            imeids: payload.imeis,
            ...finalPayload
          }),

        ... ((change_type === "Update PPU address" || change_type === "Update Features" || change_type === "Refresh A Line")
          ? { changed_data: { ...changedData } }
          : {
            changed_data: {
              OverrideValidation: false,
              Devices: payload.iccids,
              ...changedData
            }
          }),
      };

      // Send request to the first API
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        setLoading(false);
        Modal.error({
          title: 'Submit Error',
          content: parsedData.message || 'An error occurred while submitting. Please try again.',
          centered: true,
        });
        return;
      }

      const bulkrow_ = parsedData?.bulkchange_id || {};
      const bulkRow: any = { row: bulkrow_ };
      setBulkRow(bulkRow);
      localStorage.setItem('bulk_row', JSON.stringify(bulkRow || "{}"));
      if (bulkRow) {
        if (!isAllChangeType) {
          router.push(`/sim_management/bulk_history`);
        }
      }

      let type = change_type.toLowerCase()

      if ((service_provider.toLowerCase() === "kore" || (service_provider.toLowerCase() === "webbing" && type !== "change customer rate plan" ))  && switch_user_2_0 !== "True") {
        let path
        if (service_provider.toLowerCase() === "kore") {
          path = type && type === "update device status" ? "/update_device_status" : "/update_customer_rate_plan";
        }
        else {
          path = type && type === "update device status" ? "/webbing_update_device_status" : "/update_customer_rate_plan";
        }

        // Prepare payload for the first API
        const url = ENV_ROUTES.SM_BULK_CHANGE;
        let data: any;
        if (type && type === "update device status") {
          data = {
            tenant_name: partner || "default_value",
            path: path,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            service_provider: service_provider,
            ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
            change_type: change_type,
            bulk_change_id: parsedData?.bulkchange_id?.id,
            data: parsedData?.data,
            created_by: firstLastName,
            iccids: payload.iccids,
            imeids: payload.imeis,
            updated_status: changedData?.UpdateStatus || null,
            changed_data: {
              OverrideValidation: false,
              Devices: payload.iccids,
              ...changedData
            }
          };
        }
        else {
          let changed_customer_rate_plan_data = { ...changedData }
          // changed_customer_rate_plan_data["CustomerRatePlanUpdate"]["CustomerRatePlanId"] = changed_customer_rate_plan_data["CustomerRatePlanUpdate"]["CustomerRatePlanId"] && changed_customer_rate_plan_data["CustomerRatePlanUpdate"]["CustomerRatePlanId"] !== -1 ? changed_customer_rate_plan_data["CustomerRatePlanUpdate"]["CustomerRatePlanId"] : ""
          // changed_customer_rate_plan_data["CustomerRatePlanUpdate"]["CustomerRatePoolId"] = changed_customer_rate_plan_data["CustomerRatePlanUpdate"]["CustomerRatePoolId"] && changed_customer_rate_plan_data["CustomerRatePlanUpdate"]["CustomerRatePoolId"] !== -1 ? changed_customer_rate_plan_data["CustomerRatePlanUpdate"]["CustomerRatePoolId"] : ""

          data = {
            tenant_name: partner || "default_value",
            path: path,
            request_received_at: getCurrentDateTime(),
            access_token: token,
            db_name: selectedDb,
                ...metaData,
            sessionID: sessionId,
            service_provider: service_provider,
            ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
            change_type: change_type,
            bulk_change_id: parsedData?.bulkchange_id?.id,
            data: parsedData?.data,
            created_by: firstLastName,
            iccids: payload.iccids,
            imeids: payload.imeis,
            changed_data: {
              OverrideValidation: false,
              Devices: payload.iccids,
              ...changed_customer_rate_plan_data,
            },
            updated_data: {
              CustomerRatePlanUpdate: {
                effective_date: changed_customer_rate_plan_data?.CustomerRatePlanUpdate?.EffectiveDate || "",
                customer_rate_plan_name: changed_customer_rate_plan_data?.CustomerRatePlanUpdate?.CustomerRatePlanId || "",
                customer_rate_pool_name: changed_customer_rate_plan_data?.CustomerRatePlanUpdate?.CustomerRatePoolId || "",

              }
            }
          };

        }
        const kore_response = await axios.post(url, { data });
        const kore_parsedData = JSON.parse(kore_response.data.body);

        if (kore_parsedData.flag === false) {
          console.error("Data Fetch Error: " + kore_parsedData.message);
        } else {
          console.log("Success: Bulk update successful.");
        }
        const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
        data["service_provider_id"] = service_provider_id_
        callKoreSync(data)
      }
      else if (providerName.toLowerCase().includes("telegence") && change_type === "Update Device Status" && changed_data?.UpdateStatus === "M") {
        if (switch_user_2_0 === "True") {
          if (!isAllChangeType) {
            call_2_0_submit(parsedData, data, true);
            call_2_0_sync(parsedData);
          }
          else {
            const payload_2_0_: any = await call_2_0_submit(parsedData, data, false)
            set_all_2_0_payloads((prev: any) => ({
            ...prev,
            [change_type]: { ...payload_2_0_ }
          }));
          }
        }
        else {
          callRestoreCancelledSync(payload, parsedData)
        }
      }
      else if (change_type === "Update PPU address" || change_type === "Update Features" || change_type === "Refresh A Line") {
        if(!isAllChangeType){
          call_2_0_submit_ppu_address(parsedData, data, true)
          call_2_0_sync(parsedData)
        }
        else{
          const payload_2_0_: any = await call_2_0_submit_ppu_address(parsedData, data, false)
          set_all_2_0_payloads((prev: any) => ({
            ...prev,
            [change_type]: { ...payload_2_0_ }
          }));
        }
        
      }
      else if ((service_provider.toLowerCase() === "webbing" && type === "change customer rate plan")) {
        if (!isAllChangeType) {
          call_2_0_submit(parsedData, data, true);
          call_2_0_sync(parsedData);
        }
        else {
          const payload_2_0_: any = await call_2_0_submit(parsedData, data, false)
          set_all_2_0_payloads((prev: any) => ({
            ...prev,
            [change_type]: { ...payload_2_0_ }
          }));
        }
      }
      else {
        // Prepare payload for the new API call
        // const newApiData = {
        //   tenant_name: partner || "default_value",
        //   username: username,
        //   firstLastName: firstLastName,
        //   path: "/inventory_iccidds_imeids", // New API path
        //   service_provider:service_provider,
        //   role_name: role,
        //   module_name: "Bulk Change",
        //   mod_pages: { start: 0, end: 100 },
        //   access_token: token,
        //   db_name: selectedDb,
        //   sessionID: sessionId,
        //   request_received_at: getCurrentDateTime(),
        //   Partner: partner
        // };
        //   // Call the new API to get ICCIDs and IMEIs
        // const newApiResponse = await axios.post(ENV_ROUTES.SIM_MANAGEMENT, { data: newApiData });
        // const newApiParsedData = JSON.parse(newApiResponse.data.body); // Parse the new API response

        // const AlliccidList = newApiParsedData.iccid; // Adjust based on the actual structure of the response
        // const AllimeiList = newApiParsedData.imei; // Adjust based on the actual structure of the response
        // const AllmssidnList = newApiParsedData.imei; // Adjust based on the actual structure of the response

        // console.log("AllmssidnList",AllmssidnList)

        // Compare ICCID and IMEI values against the lists
        // const iccidMatch = (payload.iccids.every((iccid: any) => AlliccidList.includes(iccid)) || (service_provider.includes("Verizon") && (changed_data?.UpdateStatus?.toLowerCase() === "inventory")));
        // const imeiMatch = (payload.imeis.every((imei: any) => AllimeiList.includes(imei)) || (service_provider.includes("Verizon") && (changed_data?.UpdateStatus?.toLowerCase() === "inventory")));
        // const mssidnMatch = (payload.iccids.every((iccid: any) => AllmssidnList.includes(iccid)) && (service_provider.includes("AT&T - Telegence") && (change_type === "Change Customer Rate Plan" || change_type === "Update Device Status")));

        // if (
        //   (service_provider === "Verizon - ThingSpace IoT" && (changed_data?.UpdateStatus === "Active" || changed_data?.UpdateStatus === "Pending activation" || (changed_data?.UpdateStatus?.toLowerCase() === "inventory"))) ||
        //   (service_provider === "Verizon - ThingSpace PN" && (changed_data?.UpdateStatus === "Active" || changed_data?.UpdateStatus === "Pending activation" || (changed_data?.UpdateStatus?.toLowerCase() === "inventory"))) || (
        //     service_provider.includes("AT&T - Telegence") && change_type !== "Change Customer Rate Plan"&& change_type !== "Update Device Status")
        // ) {
        //   if (!iccidMatch || !imeiMatch) {
        //     console.log("All ICCID and IMEI values do not match.");
        //     callMismatchICCID(parsedData)
        //   } else {
        // Call run_db_script API
        const isTelegence = providerName.toLowerCase().includes("telegence");
        const isWebbing = providerName.toLowerCase().includes("webbing") || providerName.toLowerCase().includes("multi-carrier sim");
        const isVerizon = (providerName.toLowerCase().includes("verizon") || providerName.toLowerCase().includes("vzn") || providerName.toLowerCase().includes("vzwcr") || providerName.toLowerCase().includes("2215-so01"));
        const isPod19 = providerName.toLowerCase().includes("pod19");
        const isPondIOT = providerName.toLowerCase().includes("pond");
        const isJasper = providerName.toLowerCase().includes("jasper");
        const isTeal = providerName.toLowerCase().includes("teal");
        const isKore = providerName.toLowerCase().includes("kore");
        const isRogers = providerName.toLowerCase().includes("rogers");
        if (switch_user_2_0 === "True") {
          if (!isAllChangeType) {
            call_2_0_submit(parsedData, data, true);
            call_2_0_sync(parsedData);
          }
          else {
            const payload_2_0_: any = await call_2_0_submit(parsedData, data, false)
            set_all_2_0_payloads((prev: any) => ({
              ...prev,
              [change_type]: { ...payload_2_0_ }
            }));
          }
        }
        else {
          await callRunDbScript(parsedData);
        }

        // if (change_type === "Change Customer Rate Plan") {
        //   await callSyncLambda()
        // }
        // }
        // }
        // else if (service_provider.includes("AT&T - Telegence") && (change_type === "Change Customer Rate Plan" || change_type === "Update Device Status")) {
        //   if (!mssidnMatch) {
        //     console.log("All MSSIDN values do not match.");
        //     callMismatchICCID(parsedData)
        //   } else {
        //     console.log("All MSSIDN values match.");
        //     // Call run_db_script API
        //     await callRunDbScript(parsedData);
        //     await callSyncLambda()
        //   }
        // }
        // else {
        //   if (!iccidMatch) {
        //     console.log("All ICCID values do not match.");
        //     callMismatchICCID(parsedData)
        //   } else {
        //     console.log("All ICCID values match.");
        //     // Call run_db_script API
        //     await callRunDbScript(parsedData);
        //     if(change_type === "Change Customer Rate Plan"){
        //       await callSyncLambda()
        //     }
        //   }
        // }
      }
    } catch (error) {
      const isTelegence = providerName.toLowerCase().includes("telegence");
      const isWebbing = providerName.toLowerCase().includes("webbing");
      const isVerizon = (providerName.toLowerCase().includes("verizon") || providerName.toLowerCase().includes("vzn") || providerName.toLowerCase().includes("vzwcr") || providerName.toLowerCase().includes("2215-so01"));
      const isPod19 = providerName.toLowerCase().includes("pod19");
      const isPondIOT = providerName.toLowerCase().includes("pond");
      const isJasper = providerName.toLowerCase().includes("jasper");
      const isKore = providerName.toLowerCase().includes("kore");
      const isTeal = providerName.toLowerCase().includes("teal");
      const isRogers = providerName.toLowerCase().includes("rogers");
      if (switch_user_2_0 === "True" && (isTelegence || isWebbing || isVerizon || isPod19 || isPondIOT || isJasper || isKore || isTeal || isRogers)) {
        onCancel()
        setLoading(false)
        addExport("bulkChangeInsert", "Bulk Change Submission");
        bulkChangePolling(data)
      }
      else {
        Modal.error({
          title: 'Submit Error',
          content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting. Please try again.',
          centered: true,
        });
      }
    } finally {
      setLoading(false);
    }
  };

  const callSyncLambda = async () => {
    try {
      const url = ENV_ROUTES.OPTIMIZATION_SYNC_LAMBDA;
      const data = {
        key_name: "bulk_chnage_history",
        path: "/lambda_sync_jobs_",
        tenant_name: partner
      };

      const response = await axios.post(url, { data });
      const responseData = JSON.parse(response.data.body);

      if (responseData.flag === false) {
        console.error("Data Fetch Error: " + responseData.message);
      } else {
        console.log("Success: Bulk update successful.");
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };
  const call_2_0_submit_ppu_address = async (parsedData: any, payload: any,isRouteCall: boolean) => {
    try {
      const payload_data = { ...payload }
      const url = ENV_ROUTES.BULKCHANGE_PROCESSOR;
      const prevChangedData = payload_data?.changed_data || {}
      payload_data["msisdns"] = payload_data?.iccids
      delete payload_data["imeids"]
      delete payload_data["iccids"]
      if (change_type === "Update Features") {
        delete payload_data["changed_data"]
      }
      const payloadData = {
        ...payload_data,
        path: "/bulk_change_processor",
        request_received_at: getCurrentDateTime(),
        bulk_change_id: parsedData?.bulk_chnage_id_20,
      }
      const data = { ...payloadData };
      if (!isRouteCall) {
        return data
      }
      const response = await axios.post(url, { data });
      const responseData = JSON.parse(response.data.body);
      if (responseData.flag === false) {
        console.log("Failure: 2.0 Bulk change update failed.");
      } else {
        console.log("Success: 2.0 Bulk change update successful.");
      }
    }
    catch (error) {
      console.error("Error running DB script:", error);
    } finally {
      setLoading(false);
    }
  }
  const call_2_0_sync = async (parsedData: any) => {
    try {
      const runDbScriptUrl = ENV_ROUTES.SIM_MANAGEMENT;
      const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
      const runDbScriptData = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/update_bulk_change_tables_10",
        role_name: role,
        module_name: "Bulk Change",
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        // service_provider_id: service_provider_id_,
        // bulkchange_id: parsedData?.bulkchange_id?.id,
        // data: parsedData?.data,
        data: {
          bulk_change_id: parsedData?.bulk_chnage_id_20,
        },
        is_update: false,
        // bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
      };

      const runDbScriptResponse = await axios.post(runDbScriptUrl, { data: runDbScriptData });
      const runDbScriptResponseData = JSON.parse(runDbScriptResponse.data.body);

      if (runDbScriptResponseData.flag === false) {
        console.error("Data Fetch Error: " + runDbScriptResponseData.message);
      } else {
        console.log("Success: Bulk update successful.");
      }
    }
    catch (error) {
      console.error("Error running DB script:", error);
    } finally {
      setLoading(false);
    }
  }

    const isFutureDate = (
      effectiveDate: string | Date | moment.Moment | null
    ): boolean => {
      if (!effectiveDate) return false;

      const date = moment.isMoment(effectiveDate)
        ? effectiveDate.clone()
        : moment.utc(effectiveDate);

      if (!date.isValid()) return false;
      return date.startOf("day").isAfter(moment().startOf("day"));
    };

  const call_2_0_submit = async (parsedData: any, payload: any,isRouteCall: boolean) => {
    const isTelegence = providerName.toLowerCase().includes("telegence");
    const isWebbing = providerName.toLowerCase().includes("webbing");
    const isVerizon = (providerName.toLowerCase().includes("verizon") || providerName.toLowerCase().includes("vzn") || providerName.toLowerCase().includes("vzwcr") || providerName.toLowerCase().includes("2215-so01"));
    try {
      let prevChangedData
      let newChangedData
      const changeType = change_type ? change_type.toLowerCase() : ""
      delete payload["imeids"]
      if(changeType === "reset voicemail password"){
        if (isTelegence) {
          payload["msisdns"] = payload?.iccids
          delete payload["iccids"]
        }
      }
      if (changeType === "change customer rate plan") {
        let ratePlanNameParts = ""
        let ratePoolNameParts = ""
        prevChangedData = payload?.changed_data?.CustomerRatePlanUpdate || {}
        if (prevChangedData?.CustomerRatePlanId && prevChangedData?.CustomerRatePlanId !== -1 && prevChangedData?.CustomerRatePlanId !== -2) {
          ratePlanNameParts = (prevChangedData?.CustomerRatePlanId || "").split(" -- ")

        }
        if (prevChangedData?.CustomerRatePoolId && prevChangedData?.CustomerRatePoolId !== -1 && prevChangedData?.CustomerRatePoolId !== -2) {
          ratePoolNameParts = (prevChangedData?.CustomerRatePoolId || "").split(" -- ")

        }

        newChangedData = {
          customer_rate_plan_name: ratePlanNameParts && ratePlanNameParts.length > 0 ? ratePlanNameParts[0] : null,
          customer_rate_pool_name: ratePoolNameParts && ratePoolNameParts.length > 0 ? ratePoolNameParts[0] : null,
          ...isVerizon ? {
            EffectiveDate: prevChangedData?.EffectiveDate || "",
          } : {
            effective_date: prevChangedData?.EffectiveDate || "",
          },
        }
        if (isTelegence) {
          payload["msisdns"] = payload?.iccids
          delete payload["iccids"]
        }

      }
      else if (changeType === "update device status") {
        console.log("changed_data", changed_data)
        prevChangedData = payload?.changed_data || {}
        newChangedData = { ...prevChangedData }
        payload["sim_status"] = changed_data?.sim_status || ""
        payload["device_status_id"] = changed_data?.device_status_id || "22"
        // payload["publicIpRestriction"] = changed_data?.publicIpRestriction || ""
        delete payload["imeids"]
        delete newChangedData["sim_status"]
        delete newChangedData["device_status_id"]
        // delete newChangedData["publicIpRestriction"]
        const isActiveStatus = (changed_data?.sim_status || "")?.toLowerCase()==="active"
        if (isVerizon && isActiveStatus) {
          payload["account_number"] = changed_data?.account_number || ""
        }
        if (isTelegence) {
          payload["msisdns"] = payload?.iccids
          payload["effective_date"] = changed_data?.effectiveDate || null
          payload["effective_date"] = changed_data?.effectiveDate || null
          delete payload["iccids"]
          delete newChangedData["effectiveDate"]
        }
      }
      else if (changeType === "change carrier rate plan") {
        let prevChangedData = payload?.changed_data?.CarrierRatePlanUpdate || {}
        payload["effective_date"] = prevChangedData.EffectiveDate || null
        delete payload["changed_data"]
      }
      else {
        prevChangedData = payload?.changed_data || {}
        newChangedData = { ...prevChangedData }
      }
      let path_ = (changeType === "change customer rate plan" && isFutureDate(prevChangedData?.EffectiveDate || null) )? "/schedule_bulk_change_execution" : "/bulk_change_processor"
      const url = ENV_ROUTES.BULKCHANGE_PROCESSOR;
      const payloadData = {
        ...payload,
        path: path_,
        request_received_at: getCurrentDateTime(),
        bulk_change_id: parsedData?.bulk_chnage_id_20,
        // changed_data: { ...newChangedData }
        changed_data: { ...newChangedData }
      }
      const data = { ...payloadData };
      if (!isRouteCall) {
        return data
      }
      const response = await axios.post(url, { data });
      const responseData = JSON.parse(response.data.body);
      if (responseData.flag === false) {
        console.log("Failure: 2.0 Bulk change update failed.");
      } else {
        console.log("Success: 2.0 Bulk change update successful.");
      }
    }
    catch (error) {
      console.error("Error running DB script:", error);
    } finally {
      setLoading(false);
    }
  }
  // Helper function to call run_db_script API
  const callRunDbScript = async (parsedData: any) => {
    const service_provider_id_ = parsedData?.bulkchange_id?.service_provider_id || 1
    const verizon_inventory_flag_condition = ((providerName.toLowerCase()).includes("verizon") || providerName.toLowerCase().includes("vzn")) && change_type === "Update Device Status" && (changed_data?.UpdateStatus).toLowerCase() === "inventory"
    console.log("parsedData", parsedData)
    try {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/run_db_script",
        role_name: role,
        module_name: "Bulk Change",
        mod_pages: { start: 0, end: 100 },
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        service_provider_id: service_provider_id_,
        bulkchange_id: parsedData?.bulkchange_id?.id,
        data: parsedData?.data,
        bulk_chnage_id_20: parsedData?.bulk_chnage_id_20,
        verizon_inventory_flag: verizon_inventory_flag_condition
      };

      const response = await axios.post(url, { data });
      const responseData = JSON.parse(response.data.body);

      if (responseData.flag === false) {
        console.error("Data Fetch Error: " + responseData.message);
      } else {
        console.log("Success: Bulk update successful.");
      }
    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const fetchDevices = async (devices_list: any, deviceKey: string) => {
    try {
      setLoading(true);
      const url =
        ENV_ROUTES.BULKCHANGE_PROCESSOR;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_standard_iccid_msisdn_data",
        role_name: role,
        Partner: partner,
        request_received_at: getCurrentDateTime(),
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
        service_provider: service_provider,
        ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
        change_type: change_type,
        [deviceKey]: devices_list || []
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        // setLoading(false);
        Modal.error({
          title: 'Submit Error',
          content: parsedData.message || 'An error occurred while submitting data. Please try again.',
          centered: true,
        });
        return []
      } else {
        let responseKey = deviceKey === "iccids" ? "msisdns" : "iccids"
        if (isIMEI) {
          responseKey = deviceKey === "iccids_imei_map" ? "msisdns_imei_map" : "iccids_imei_map"
        }
        let devices = parsedData?.[responseKey] || []
        if (isIMEI) {
          devices = devices ? Object.keys(devices) : devices
        }
        console.log("devices", devices)
        return devices
        // setLoading(false);
      }
    } catch (error) {
      Modal.error({
        title: 'Submit Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while submitting data. Please try again.',
        centered: true,
      });
      return []
      // setLoading(false);
    }
    finally {
      // setLoading(false)
    }
  };

  const getIccidList = async (iccids_: any[]): Promise<string[]> => {
    // Pick devices based on subscriberNumber or iccids
    const devices_ = subscriberNumber ? subscriberNumber : iccid;

    // Find matching device type from the map
    const matchedDeviceTypeItem = simIdentifierMap.find((item: any) => {
      return (
        item.service_provider === service_provider &&
        item.change_type === change_type
      );
    });
    const matchedDeviceType = matchedDeviceTypeItem?.sim_identifier || ""
    // Decide expected type
    const selectDeviceType = subscriberNumber ? "msisdns" : "iccids";
    const selectedIMEIType = subscriberNumber ? "msisdns_imei_map" : "iccids_imei_map"
    // Split devices into a list
    let iccidList: any = devices_
      .split(/\s*[\n,]\s*/)
      .map((line) => line.trim())
      .filter((line) => line.length > 0);

    let iccidMap: Record<string, string> = {};

    if (isIMEI) {
      // Convert flat list into key-value pairs
      for (let i = 0; i < iccidList.length; i += 2) {
        const iccidOrMsisdn = iccidList[i].toString();
        const imei = iccidList[i + 1] || ""; // safeguard in case odd count
        iccidMap[iccidOrMsisdn.toString()] = imei;
      }
    }

    console.log("iccidMap", iccidMap)
    console.log("iccidList", iccidList)


    // Fetch devices only if types mismatch
    if (matchedDeviceType !== selectDeviceType) {
      const deviceType = isIMEI ? selectedIMEIType : selectDeviceType
      const deviceList = isIMEI ? iccidMap : iccidList
      iccidList = await fetchDevices(deviceList, deviceType);
    }
    else {
      iccidList = iccids_
    }

    return iccidList;
    };
    const ipv4Regex = /^(\d{1,3}\.){3}\d{1,3}$/;
    const isValidIPv4 = (ip: string) => {
      if (!ipv4Regex.test(ip)) return false;
      return ip.split(".").every(p => {
        if (!/^\d+$/.test(p)) return false;
        const n = Number(p);
        return Number.isInteger(n) && n >= 0 && n <= 255;
      });
    };
    const ipv4ToUint32 = (ip: string) => {
      const [a, b, c, d] = ip.split(".").map(Number);
      return ((a << 24) >>> 0) + (b << 16) + (c << 8) + d;
    };

    // IPv6: expand compressed forms into 8 hextets of 4 hex digits
    const expandIPv6 = (input: string): string[] | null => {
      const raw = input.trim();
      if (!raw) return null;
      // split on :: (0..1 times)
      if (raw.includes("::")) {
        const [left, right] = raw.split("::");
        const leftParts = left ? left.split(":").filter(Boolean) : [];
        const rightParts = right ? right.split(":").filter(Boolean) : [];
        if (leftParts.some(p => p.length > 4) || rightParts.some(p => p.length > 4)) return null;
        const missing = 8 - (leftParts.length + rightParts.length);
        if (missing < 0) return null;
        const mid = new Array(missing).fill("0");
        const parts = [...leftParts, ...mid, ...rightParts].map(p => p || "0");
        if (parts.length !== 8) return null;
        return parts.map(p => p.padStart(4, "0").toUpperCase());
      } else {
        const parts = raw.split(":");
        if (parts.length !== 8) return null;
        if (parts.some(p => p.length === 0 || p.length > 4)) return null;
        return parts.map(p => p.padStart(4, "0").toUpperCase());
      }
    };

    // Detect IPv6 (rough)
    const looksLikeIPv6 = (s: string) => s.includes(":");

    // Convert expanded 8 hextets -> BigInt
    const ipv6PartsToBigInt = (parts: string[]) => {
      // each part is 4 hex digits -> 16 bits
      let acc = BigInt(0);
      for (let i = 0; i < 8; i++) {
        const v = BigInt(parseInt(parts[i], 16) & 0xFFFF);
        acc = (acc << BigInt(16)) + v;
      }
      return acc;
    };
    const parseSavedRange = (ipRange: string) => {
      if (!ipRange) return { ok: false as const };

      const parts = ipRange.split("-");
      if (parts.length !== 2) return { ok: false as const };

      const s = parts[0].trim();
      const e = parts[1].trim();

      // IPv4 branch
      if (!looksLikeIPv6(s) && !looksLikeIPv6(e)) {
        if (!isValidIPv4(s) || !isValidIPv4(e)) return { ok: false as const };
        const sN = ipv4ToUint32(s);
        const eN = ipv4ToUint32(e);
        const start = Math.min(sN, eN);
        const end = Math.max(sN, eN);
        return { ok: true as const, family: "ipv4" as const, startNum: start, endNum: end };
      }

      // IPv6 branch
      const sExp = expandIPv6(s);
      const eExp = expandIPv6(e);
      if (!sExp || !eExp) return { ok: false as const };
      const sBig = ipv6PartsToBigInt(sExp);
      const eBig = ipv6PartsToBigInt(eExp);
      const startBig = sBig <= eBig ? sBig : eBig;
      const endBig = sBig <= eBig ? eBig : sBig;
      return { ok: true as const, family: "ipv6" as const, startBig, endBig };
    };

    interface IPValidation {
      valid: boolean;
      error: string;
    }

    const unavailableIPError = async (
      ipList: string | string[],
      changeType: string
    ): Promise<IPValidation> => {
      try {
        setLoading(true);

        const url = ENV_ROUTES.MODULE_MANAGEMENT;

        const data = {
          tenant_name: partner || "default_value",
          username,
          firstLastName,
          path: "/validate_ips_availability",
          role_name: role,
          Partner: partner,
          request_received_at: getCurrentDateTime(),
          access_token: token,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          change_type: changeType || "",
          ip_list: ipList || [],
          service_provider: service_provider || "",
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);

        // ❌ Invalid cases
        if (parsedData.flag === false || parsedData?.validation) {
          return {
            valid: false,
            error: parsedData?.message || "Enter IP address within the available IP list",
          };
        }

        // ✅ Success case
        return {
          valid: true,
          error: "",
        };

      } catch (error) {
        return {
          valid: false,
          error: "Enter IP address within the available IP list",
        };
      } finally {
        setLoading(false);
      }
    };

    const validateFieldIp = async (
      value: string[],
      ipRange: string | string[]
    ): Promise<IPValidation> => {

      // const v = String(value ?? "").trim();

      if (!value || value.length === 0) {
        return { valid: false, error: "Enter a valid IP address" };
      }

      return await unavailableIPError(value, change_type);
    };

    const validateFieldIp_ = (
      value: string,
      ipRange: string | string[]
    ): { valid: boolean; error: string } => {
      const v = String(value ?? "").trim();
      if (!v) return { valid: false, error: "Enter a valid IP address" };

      // Normalize ranges to array of non-empty strings
      const ranges = (Array.isArray(ipRange) ? ipRange : [ipRange])
        .map(r => String(r ?? "").trim())
        .filter(r => r.length > 0);

      if (ranges.length === 0) {
        return {
          valid: false,
          error: "Enter IP address within the given IP range",
        };
      }

      const isV6 = looksLikeIPv6(v);

      // ================= IPv6 =================
      if (isV6) {
        const expanded = expandIPv6(v);
        if (!expanded) {
          return { valid: false, error: "Enter a valid IP address" };
        }

        // Parse all ranges that are valid IPv6
        const parsedV6Ranges = ranges
          .map(r => parseSavedRange(r))
          .filter(p => p.ok && p.family === "ipv6");

        if (parsedV6Ranges.length === 0) {
          return {
            valid: false,
            error: "Enter IP address within the given IP range",
          };
        }

        const vBig = ipv6PartsToBigInt(expanded);

        const inAnyRange = parsedV6Ranges.some(p => {
          return vBig >= p.startBig && vBig <= p.endBig;
        });

        if (!inAnyRange) {
          return {
            valid: false,
            error: "Enter IP address within the given IP range",
          };
        }

        return { valid: true, error: "" };
      }

      // ================= IPv4 =================
      if (!isValidIPv4(v)) {
        return { valid: false, error: "Enter a valid IP address" };
      }

      // Parse all ranges that are valid IPv4
      const parsedV4Ranges = ranges
        .map(r => parseSavedRange(r))
        .filter(p => p.ok && p.family === "ipv4");

      if (parsedV4Ranges.length === 0) {
        return {
          valid: false,
          error: "Enter IP address within the given IP range",
        };
      }

      const vN = ipv4ToUint32(v);

      const inAnyRange = parsedV4Ranges.some(p => {
        return vN >= p.startNum && vN <= p.endNum;
      });

      if (!inAnyRange) {
        return {
          valid: false,
          error: "Enter IP address within the given IP range",
        };
      }

      return { valid: true, error: "" };
    };
    const handleSubmit = async () => {
      if(targetStatus?.toLowerCase() === "active" && isIpField){

      const errors: string[] = [];
      console.log("iccids", iccid)
      if (!iccid || iccid.trim() === "") {
        setErrors(["Please fill in Devices."]); // ✅ THIS
        return;
      }
      setIccidError("");
      setImeiError("");

      const lines = iccid
        .split("\n")
        .map(l => l.trim())
        .filter(Boolean);

      const seenIccids = new Set<string>();
      const seenIps = new Set<string>();
      const ipList:any = []


      lines.forEach((line, index) => {
        const lineNo = index + 1;
        const parts = line.split(",").map(p => p.trim());

        // -------- Format check --------
        if (parts.length < 2 || parts.length > 3) {
          errors.push(`Line ${lineNo}: Use format ICCID,IMEI or ICCID,IMEI,IP`);
          return;
        }


        const iccidVal = parts[0];
        const imeiVal = parts[1];
        const ipVal = parts[2] || "";

        // -------- ICCID --------
        if (!/^\d+$/.test(iccidVal)) {
          errors.push(`Line ${lineNo}: ICCID must contain numbers only`);
        } else if (iccidVal.length < 14 || iccidVal.length > 22) {
          errors.push(`Line ${lineNo}: ICCID must be between 14 and 22 digits`);
        }

        if (seenIccids.has(iccidVal)) {
          errors.push(`Line ${lineNo}: Duplicate ICCID`);
        } else {
          seenIccids.add(iccidVal);
        }

        // -------- IMEI --------
        if (!/^\d+$/.test(imeiVal)) {
          errors.push(`Line ${lineNo}: IMEI must contain numbers only`);
        } else if (imeiVal.length < 12 || imeiVal.length > 22) {
          errors.push(`Line ${lineNo}: IMEI must be between 12 and 22 digits`);
        }

        // -------- IP --------
        if (ipVal && ipVal.trim() !== "") {
          if (!ipList.includes(ipVal)) {
            ipList.push(ipVal);
          }
          // const ipResult:any = validateFieldIp(ipVal, IPOptions || []);
          // if (!ipResult.valid) {
          //   errors.push(`Line ${lineNo}: ${ipResult.error}`);
          // }
          // if (seenIps.has(ipVal)) {
          //   errors.push(`Line ${lineNo}: Duplicate IP address`);
          // } else {
          //   seenIps.add(ipVal);
          // }
        }
      });

        const ipResult: any = await validateFieldIp(ipList, IPOptions || []);
        if (!ipResult?.valid) {
          errors.push(
          ipResult?.result || "Enter IP address within the available IP list"
        );
        }
      // -------- Bulk limit --------
      if (lines.length > bulkChangeLimit) {
        errors.push(
          `This request exceeds the allowed record limit of ${bulkChangeLimit}`
        );
      }

      // -------- STOP ON ERRORS --------
      if (errors.length > 0) {
        setErrors(errors);   // 🔥 THIS WAS MISSING
        return;
      }

      // -------- CLEAR ERRORS --------
      setErrors([]);

      const iccids_: string[] = [];
      const imeis_: string[] = [];
      const iccid_ip_map: Record<string, string> = {};

      lines.forEach(line => {
        const [iccidVal, imeiVal, ipVal] = line.split(",").map(v => v.trim());

        iccids_.push(iccidVal);
        imeis_.push(imeiVal);

        // 🔥 map ICCID → IP
        iccid_ip_map[iccidVal] = ipVal;
      });
      const selectedDevices = await getIccidList(iccids_);

      const payload = {
        iccids: selectedDevices,
        imeis: imeis_,
        iccid_ip_map, // ✅ added
      };
      console.log("paylaod", payload)
      setsetActivationPayload(payload)
      if (isNextScreen) {
        fetchTaggedCustomers(payload)
      }
      if (isNextScreen) {
        if (typeof onClose === "function") {
          onClose()
        }
        return
      }

      if (typeof onsubmit === "function") {
        const writes_flag = await fetchCarrierWritesFlag()
        if (writes_flag) {
          const modal = Modal.confirm({
            title: "Carrier API Enabled",
            content: "Carrier API settings are enabled. Submitting now will trigger the Carrier API directly. Do you want to proceed?",
            centered: true,
            okText: "Submit",
            onOk: () => {
              // modal.destroy(); // closes the modal
              // handleCloseModal();

              onsubmit(payload);
              submitCarrierStatus(payload,writes_flag);
            },
            onCancel: onBack
          });
        }
        else {
          onsubmit(payload);
        }
        // onsubmit(payload);
      } else {
        console.error("onsubmit is not a function.");
      }
      }
      else{
    let hasError = false;
    if (!subscriberNumber && !iccid) {
      setIccidError("Please fill in Devices.")
      return
    }
    else {
      setIccidError("")
    }
    console.log("handle submit")
    // Split and process input, ensuring no unwanted commas or spaces
    const selected_devices = subscriberNumber ? subscriberNumber : iccid
    const inputLines = selected_devices
      .split(/\s*[\n,]\s*/) // Split on newlines or commas
      .map((line) => line.trim())
      .filter((line) => line.length > 0); // Remove empty lines



    const iccids: string[] = [];
    const imeis: string[] = [];

    if (isIMEI) {
      let hasExtraValues = false;
      const devicesList = inputLines
        .map(line => {
          const values = line
            .split(",")
            .map(val => val.trim())
            .filter(Boolean);

          if (values.length > 2) {
            hasExtraValues = true;
          }

          return values.slice(0, 2);
        })
        .flat();
      if ((devicesList.length > 0 && (devicesList.length) % 2 !== 0 || hasExtraValues)) {
        setIccidError("Please fill in both values separated by a comma.")
        return
      }
      // If the field is for both ICCID and IMEI, split the input into two lists
      for (let i = 0; i < inputLines.length; i++) {
        if (i % 2 === 0) {
          iccids.push(inputLines[i]); // Even index: ICCID
        } else {
          imeis.push(inputLines[i]); // Odd index: IMEI
        }
      }
    } else {
      iccids.push(...inputLines); // All values are treated as ICCIDs
    }
    // Check if input is empty
    if (iccids.length === 0) {
      setIccidError("Please fill ICCID field or MSISDN field.");
      hasError = true;
    } else {
      // Validate ICCID format
      if (subscriberNumber && subscriberNumber !== "") {
        let invalidIccidFound = false;
        let invalidIccid = false;
        let nonNumericIccid = false;

        for (const line of iccids) {
          const strLine = String(line);
          if (!/^\d+$/.test(strLine)) {
            nonNumericIccid = true;
            break;
          } else if (strLine.length < 10 || strLine.length > 18) {
            invalidIccid = true;
            break;
          }
        }

        if (nonNumericIccid) {
          setIccidError("Please enter numbers only for Subscriber Number. Letters or special characters are not allowed");
          hasError = true;
          console.log("Validation failed: Non-numeric Subscriber Number.");
        } else if (invalidIccid) {
          setIccidError("Each Subscriber Number must be between 10 to 18 digits long.");
          hasError = true;
          console.log("Validation failed: Invalid Subscriber Number length.");
        } else {
          setIccidError("");
        }

        if (isIMEI) {
          let invalidImei = false;
          let nonNumericImei = false;

          for (const line of imeis) {
            const strLine = String(line);
            if (!/^\d+$/.test(strLine)) {
              nonNumericImei = true;
              break;
            } else if (strLine.length < 12 || strLine.length > 22) {
              invalidImei = true;
              break;
            }
          }

          if (nonNumericImei) {
            setImeiError("Please enter numbers only for IMEI.Letters or special characters are not allowed");
            hasError = true;
            console.log("Validation failed: Non-numeric IMEI.");
          } else if (invalidImei) {
            setImeiError("Each IMEI must be between 12 to 22 digits long.");
            hasError = true;
            console.log("Validation failed: Invalid IMEI length.");
          } else {
            setImeiError("");
          }
        }
      }
      else {

        let invalidIccid = false;
        let nonNumericIccid = false;

        const isTMobile = providerName.toLowerCase().includes("t-mobile")
        const isTeal = providerName.toLowerCase().includes("teal")
        for (const line of iccids) {
          const strLine = String(line);
          if ((!/^\d+$/.test(strLine) && !isTMobile)) {
            nonNumericIccid = true;
            break;
          }
          if (!/^[a-zA-Z0-9]+$/.test(strLine) && isTMobile) {
            nonNumericIccid = true;
            break;
          }
          else if (strLine.length < 14 || (strLine.length > 22 && !isTeal) || (isTeal && strLine.length > 32)) {
            invalidIccid = true;
            break;
          }
        }

        if (nonNumericIccid) {
          if(isTMobile){
            setIccidError("ICCID must only contain letters and numbers. Special characters are not allowed");
            hasError = true;
            console.log("Validation failed: Non-numeric ICCID.");
          }
          else {
            setIccidError("Please enter numbers only for ICCID.Letters or special characters are not allowed");
            hasError = true;
            console.log("Validation failed: Non-numeric ICCID.");
          }
        } else if (invalidIccid) {
          setIccidError(`Each ICCID must be between 14 to ${isTeal ? "32":"22"} digits long.`);
          hasError = true;
          console.log("Validation failed: Invalid ICCID length.");
        } else {
          setIccidError("");
        }

        if (isIMEI) {
          let invalidImei = false;
          let nonNumericImei = false;

          for (const line of imeis) {
            const strLine = String(line);
            if (!/^\d+$/.test(strLine)) {
              nonNumericImei = true;
              break;
            } else if (strLine.length < 12 || strLine.length > 22) {
              invalidImei = true;
              break;
            }
          }

          if (nonNumericImei) {
            setImeiError("Please enter numbers only for IMEI.Letters or special characters are not allowed");
            hasError = true;
            console.log("Validation failed: Non-numeric IMEI.");
          } else if (invalidImei) {
            setImeiError("Each IMEI must be between 12 to 22 digits long.");
            hasError = true;
            console.log("Validation failed: Invalid IMEI length.");
          } else {
            setImeiError("");
          }
        }
      }

    }
    if (hasError) {
      console.log("has error")
      return;
    } else {
      setIccidError(""); // Clear error message if all validations pass
      setImeiError("")
    }


    console.log("ICCID List:", iccids);
    console.log("IMEI List:", imeis);

    if (iccids.length > bulkChangeLimit || imeis.length > bulkChangeLimit) {
      setIccidError(`This request exceeds the allowed record limit  of ${bulkChangeLimit} and cannot be processed`);
      console.log("Limit Exceeded");
      hasError = true;
    }

    if (hasError) {
      console.log("Validation failed.");
      return;
    }

    const selectedDevices = await getIccidList(iccids)

    const payload: any = {
      iccids: selectedDevices,
      imeis: imeis,
    };

    console.log("Payload to be sent:", payload);
    setsetActivationPayload(payload)
    if (isNextScreen) {
      fetchTaggedCustomers(payload)
    }
    if (isNextScreen) {
      if (typeof onClose === "function") {
        onClose()
      }
      return
    }

    if (typeof onsubmit === "function") {
      const writes_flag = await fetchCarrierWritesFlag()
      if (writes_flag) {
        const modal = Modal.confirm({
          title: "Carrier API Enabled",
          content: "Carrier API settings are enabled. Submitting now will trigger the Carrier API directly. Do you want to proceed?",
          centered: true,
          okText: "Submit",
          onOk: () => {
            // modal.destroy(); // closes the modal
            // handleCloseModal();

            onsubmit(payload);
            submitCarrierStatus(payload,writes_flag);
          },
          onCancel: onBack
        });
      }
      else {
        onsubmit(payload);
      }
      // onsubmit(payload);
    } else {
      console.error("onsubmit is not a function.");
    }
      }
    };

    useEffect(() => {
      if (isAllChangeType) {
        const devices = allChangeTypesDevices?.iccids || []
        const devicesString = devices.join('\n')
        if (allChangeTypesDevices?.isIccid) {
          setSubscriberNumber("")
          setIccid(devicesString);
        }
        else {
          setIccid("")
          setSubscriberNumber(devicesString);
        }
      }
    }, [isAllChangeType, allChangeTypesDevices]);

  useEffect (() =>{
    if (hasFetchedRef.current) return;
    hasFetchedRef.current = true;

    const fetchOptionsData = async () => {
      try {
        setLoading(true)
        await fetchOptionsMappings()
        // await fetchPDPOptions()
      }
      catch (err) {
        console.log("error fetching dropdown data", err)
      }
      finally {
        setLoading(false)
      }
    }
    fetchOptionsData()
  },[])
  useEffect(() => {
    
    // console.log('Changed Data:', changed_data);

    const changeType = change_type?.toLowerCase() || ""
    const SP = providerName.toLowerCase() || ""
    const isIMEI_ =
      (
        SP === "kore" &&
        changeType === "update device status" &&
        (changed_data?.UpdateStatus === "Activate" ||
          changed_data?.UpdateStatus === "Active")
      ) ||
      (
        ((providerName.toLowerCase().includes("verizon") || 
        providerName.toLowerCase().includes("vzn") || providerName.toLowerCase().includes("vzwcr") || 
        providerName.toLowerCase().includes("2215-so01")) &&
          (changed_data?.UpdateStatus === "Active" ||
            changed_data?.UpdateStatus === "Pending activation"))
      )
        const isIpFieldOptional_ = (providerName.toLowerCase().includes("verizon") || 
        providerName.toLowerCase().includes("vzn") || providerName.toLowerCase().includes("vzwcr") || 
        providerName.toLowerCase().includes("2215-so01")) &&  (changed_data?.UpdateStatus === "Active");
        setIsIpField(isIpFieldOptional_)
        setIsIMEI(isIMEI_)

  }, [changed_data]);

  const fetchTaggedCustomers = async (payload: any) => {
    try {
      const isTelegence = providerName?.toLowerCase().includes("telegence")
      setLoading(true);
      const url =
        ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        path: "/customers_tagged_iccids",
        request_received_at: getCurrentDateTime(),
        username: username,
        firstLastName: firstLastName,
        role_name: role,
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
                ...metaData,
        sessionID: sessionId,
        service_provider: service_provider,
        ...{ parent_provider_name: is_parent_provider_exists ? getTargetTenantProvider(service_provider) : "" } ,
        change_type: change_type,
        ...(isTelegence ? { msisdns: payload?.iccids || [] } : { iccids: payload?.iccids || [] })

      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      if (parsedData.flag === false) {
        setLoading(false);
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        const options_ = parsedData?.tagged_customers || []
        const formatted_options = options_.map((opt: any) => ({ label: opt, value: opt }))
        if (typeof setSelectedCustomers === "function") {
          setSelectedCustomers(formatted_options)
        }
        setLoading(false);
      }
    } catch (error) {
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    }
  };

  useImperativeHandle(ref, () => ({
    runSubmit:async() => { 
      console.log("runSubmit in select devices")
      const selectedDevices = await getIccidList(allChangeTypesDevices?.iccids || [])
      console.log("selectedDevices",selectedDevices)
      console.log("allChangeTypesDevices?.iccids",allChangeTypesDevices?.iccids)
      onsubmit({...allChangeTypesDevices , iccids :[...selectedDevices] }) },
  }));
const handlePreviewOpen = async () => {
            setPreviewModal(true)
        };
const handlePDPNameSelect = (selectedOption: any) => {
  if (selectedOption) {
    const value = selectedOption?.value
    setSelectedPDP(value)

    const ip_options = pdpIpMap[value] || []
    setIPOptions(ip_options)
  }
  else {
    setSelectedPDP(null)
    setIPOptions([])

  }
};

  if (loading) {
    return (
      <div className="flex justify-center items-center h-[400px]">
        <Spin size="large" />
      </div>
    );
  }

  return (

    <div className="flex flex-col mt-2">
      {(isNextScreen && (change_type.toLowerCase() === "change customer rate plan")) && (
        switch_user_2_0 === "True" ? (
          <UploadComponent2
            service_provider={service_provider}
            change_type={change_type}
            changed_data={{
              ...changed_data,
            }} />
        ) : (
          <UploadComponent
            service_provider={service_provider}
            change_type={change_type}
            changed_data={{
              ...changed_data,
            }} />
        )
      )}
      <h2 className="text-500 font-semibold">Select Devices</h2>
      {/* <div className="bg-[#FFEDA6] mb-2 p-2 border border-[#FFCE0E] rounded text-center">
        <h3 className="font-[13px]">
          Processing Time will be approximately 2 minutes to process 100 Bulk Change requests.
        </h3>
      </div>
      <div>
        <div>
          <label className="font-bold mr-2">Processing Time:</label>
          <span>10 requests per 1 second</span>
        </div>
        <div>
          <label className="font-bold mr-2">Maximum Requests allowed:</label>
          <span>100 Requests</span>
        </div>
      </div> */}
      {/* ICCID & IMEI Field (Conditionally Combined) */}
      <div className="space-y-4 flex flex-col">
       {targetStatus?.toLowerCase() === "active" && isIpField && ( <div className="flex flex-col space-y-2">
          <label htmlFor="pdpName" className={`${!isAllChangeType ? "w-1/3 font-semibold" : "field-label"}`}>
            {`${isTelegence ? "PDP Name" : "PDP ID"}`}
          </label>
          <Select
            id="pdpName"
            placeholder={`Select ${isTelegence ? "PDP Name" : "PDP ID"}`}
            options={pdpOptions.map((option: string) => ({
              label: option,
              value: option,
            }))}
            value={{ label: selectedPDP, value: selectedPDP }}
            onChange={handlePDPNameSelect}
            styles={DropdownStyles}
            className="w-full"
            isClearable
            menuPortalTarget={document.body}
            menuPosition="fixed"
            menuPlacement="auto"
          />
          {(!selectedPDP && !isAllChangeType && (
            <span className="text-blue-500">* Please select a PDP to view available IP addresses.</span>
          ))}
        </div>)}
        <div className="flex flex-col space-y-2">
          <div className="flex items-center justify-between">
          <label htmlFor="iccid-imei" className="font-semibold">
            {isIpField && isIMEI ? "ICCID, IMEI & IP (Optional)":isIpField ? "ICCID & IP (Optional)" : isIMEI ? "ICCID & IMEI" : "ICCID"}
            <span className="text-red-500">*</span>
          </label>
            {targetStatus?.toLowerCase() === "active" && isIpField && selectedPDP && (<Tooltip title="Preview or view IP details">
              <InfoIcon
                className="h-5 w-5 text-gray-500 cursor-pointer"
                onClick={()=>{handlePreviewOpen(),setInfoFlag(true)}}
              />
            </Tooltip>)}
          </div>
          <Input.TextArea
            id="iccid-imei"
            rows={6}
            placeholder={
              isIpField && isIMEI ? "Enter ICCIDs,IMEIs and IP Address (Optional) separated by a comma (e.g., ICCID,IMEI,IP)":
              isIpField ? "Enter ICCIDs and IP Address (Optional) separated by a comma (e.g., ICCID,IP)":
              isIMEI ? "Enter ICCIDs and IMEIs separated by a comma (e.g., ICCID, IMEI)" 
              : "Enter ICCIDs here"
            }
            value={iccid}
            onChange={(e) => {
              setIccid(e.target.value);
              if (e.target.value) setSubscriberNumber("");
            }}
            disabled={!!subscriberNumber}
          />
        </div>
        <PrivateNetworkPreviewModal
          service_provider={service_provider}
          change_type={change_type}  
          openPreviewModal={openPreviewModal}
          setPreviewModal={setPreviewModal}
          selectedPDP={selectedPDP || ""}
        />
        {!isIMEI && (
          <div className="flex flex-col space-y-2">
            <label htmlFor="msisdn-imei" className="font-semibold">
              {isIpField && isIMEI ? "MSISDN, IMEI & IP (Optional)": isIpField ? "MSISDN & IP (Optional)" : "MSISDN"}
              <span className="text-red-500">*</span>
            </label>
            <Input.TextArea
              id="iccid-imei"
              rows={6}
              placeholder={
                isIpField && isIMEI? "Enter ICCIDs,IMEIs and IP Address (Optional) separated by a comma (e.g., ICCID,IMEI,IP)"
                : isIpField ? "Enter ICCIDs and IP Address (Optional) separated by a comma (e.g., ICCID,IP)" : "Enter MSISDNs here"
              }
              value={subscriberNumber}
              onChange={(e) => {
                setSubscriberNumber(e.target.value);
                if (e.target.value) setIccid("");
              }}
              disabled={!!iccid}
            />
          </div>
        )}

        {errors.length > 0 && (
          <div className="mt-2 space-y-1">
            {errors.map((err, i) => (
              <div key={i} className="text-red-500 text-sm">
                {err}
              </div>
            ))}
          </div>
        )}
        {iccidError && <div className="text-red-500 text-sm">{iccidError}</div>}
        {imeiError && <div className="text-red-500 text-sm">{imeiError}</div>}
      </div>



      {/* Buttons */}
      <div className="flex justify-center space-x-4 mt-4">
        <button onClick={onBack} className="cancel-btn">
          Back
        </button>
        <button onClick={handleSubmit} className="save-btn">
          {isNextScreen ? "Continue" : "Submit"}
        </button>
      </div>
    </div>



  );
}
)

export default SelectDevices;
