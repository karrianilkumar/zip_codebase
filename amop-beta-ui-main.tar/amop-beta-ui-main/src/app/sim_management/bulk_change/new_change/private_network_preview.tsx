import React, { useEffect, useState } from "react";
import { Input, Modal, Spin, Table, Tooltip } from "antd";
import type { ColumnsType } from "antd/es/table";
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { CheckCircleIcon, XCircleIcon } from "@heroicons/react/24/outline";
import * as XLSX from "xlsx";
import { PerformanceLogStore } from "@/app/stores/performance_matrix_store";
import Select from "react-select";
import { DropdownStyles } from "@/app/components/css/dropdown";
import { useAllChangeTypesStore } from "@/app/stores/allChangeTypesStore";
interface TableDataResponse<T> {
    data: T[];
}

interface SyncStatusData {
    key: string;
    no: number;
    syncName: string;
    syncType: string;
    status: string;
    dateTime: string;
}

interface UserLogData {
    key: string;
    no: number;
    userName: string;
    loginTime: string;
    logoutTime: string;
}

interface PreviewModalProps {
    change_type: string;
    service_provider: string;
    openPreviewModal: boolean;
    setPreviewModal: (val: boolean) => void;
    selectedPDP?: string;
}

const PrivateNetworkPreviewModal: React.FC<PreviewModalProps> = ({ change_type, service_provider, openPreviewModal, setPreviewModal ,selectedPDP}) => {
    const { username, role, token, partner, selectedDb, firstLastName, sessionId, metaData } = useAuth();
    const [loading, setLoading] = useState(false);
    const [tableData, setTableData] = useState<any>([]);
    const [currentPage, setCurrentPage] = useState(1);
    const [searchTerm, setSearchTerm] = useState("");
    const { getTargetTenantProvider, IsTargetTenantProvider } = PerformanceLogStore();
    const is_parent_provider_exists = IsTargetTenantProvider(service_provider)
    const pageSize = 10;
    const filteredData = tableData.filter((item: any) => {
        const values = Object.values(item).join(" ").toLowerCase();
        return values.includes(searchTerm.toLowerCase());
    });
    const providerName = getTargetTenantProvider(service_provider).toLowerCase() || service_provider;
    const isTelegence = providerName.includes("telegence");
    const [pdpOptions, setPdpOptions] = useState<any>([]);
    const [IPOptions, setIPOptions] = useState<any>([]);
    const [selectedPDP_, setSelectedPDP_] = useState<string | null>(null);
    const [pdpIpMap, setPdpIpMap] = useState<any>({});
    const {isAllChangeType , setSelectedPDPGlobal,setSelectedAPNGlobal} = useAllChangeTypesStore()
    const paginatedData = filteredData.slice((currentPage - 1) * pageSize, currentPage * pageSize);
    const headerMap: any = {
    // "service_provider": [
    //     "Service Provider",
    //     "1"
    // ],
    "apn": [
        "APN",
        "2"
    ],
    "pdp": [
        "PDP",
        "3"
    ],
    "available_ip": [
        "Available IP Address",
        "4"
    ],
    // "ip_version": [
    //     "IP Version",
    //     "5"
    // ]
}

    const columns = Object.keys(headerMap)
    .sort((a, b) => Number(headerMap[a][1]) - Number(headerMap[b][1]))
    .map((key: string) => ({
        title: headerMap[key][0],
        dataIndex: key,
        key: key,
        width: 180,
        render: (text: any) => (
            <Tooltip title={text}>
                <div className="cell-ellipsis">
                    {text && text !== "None" && text !== "null" ? text : ""}
                </div>
            </Tooltip>
        )
    }));


    const closeModal = () => {
        setPreviewModal(false)

    }

 const fetchPreviewTableData = async () => {
      try {
        setLoading(true)
        const url = ENV_ROUTES.MODULE_MANAGEMENT;
        const data = {
          tenant_name: partner || "default_value",
          path: "/get_private_network_pdp_apn_ip_mappings",
          request_received_at: getCurrentDateTime(),
          username: username,
          firstLastName: firstLastName,
          role_name: role,
          Partner: partner,
          access_token: token,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          service_provider: service_provider,
          selected_pdp: isAllChangeType ? selectedPDP_ : selectedPDP,
          info_flag: true,
          ...{
            parent_provider_name: is_parent_provider_exists
              ? getTargetTenantProvider(service_provider)
              : "",
          },
        };

        const response = await axios.post(url, { data });
        const parsedData = JSON.parse(response.data.body);
        if (parsedData.flag === false) {
          Modal.error({
            title: "Data Fetch Error",
            content:
              parsedData.message ||
              "An error occurred while fetching data. Please try again.",
            centered: true,
          });
        } else {
          const tableData_ = parsedData?.private_network_table || [];
          if((isAllChangeType && selectedPDP_ !== null) || selectedPDP!==null){
            console.log("tableData_",tableData_)
            setTableData(tableData_)
            setSelectedAPNGlobal(tableData_ && tableData_.length>0 &&tableData_[0]?.apn) // setting fetched apn for selected PDP
          }
          else{
            setTableData([])
          }
          
          const pdp_options = parsedData?.pdp || [];
          setPdpOptions(pdp_options)

          const pdp_ip_map = parsedData?.pdp_ip_map || {};
          setPdpIpMap(pdp_ip_map)
         
        }
      } catch (error) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            error instanceof Error
              ? error.message
              : "An unexpected error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
      finally{
        setLoading(false)
      }
    };
    const handlePDPNameSelect = (selectedOption: any) => {
            if (selectedOption) {
                const value = selectedOption?.value
                setSelectedPDP_(value)
                setSelectedPDPGlobal(value)

                const ip_options = pdpIpMap[value] || []
                setIPOptions(ip_options)
            }
            else {
                setSelectedPDP_(null)
                setIPOptions([])

            }
        };
    useEffect(() => {
        const fetchInitialData = async () => {
            try {
                // Call your main data fetching function
                if (openPreviewModal) {
                    await fetchPreviewTableData();
                }
            } catch (error) {
                console.error("Error fetching SSM parameters or data:", error);
            }
        };

        fetchInitialData();
    }, [service_provider, openPreviewModal,selectedPDP_]);

    const paginationConfig = {
        current: currentPage,
        pageSize: pageSize,
        total: filteredData.length,
        showSizeChanger: false,
        showLessItems: false,
        showPrevNextJumpers: true,
        onChange: (page: number) => setCurrentPage(page),
    };

    const multiplyFactor = (typeof window !== "undefined" && window.innerWidth < 700) ? 3 : 2
    const modalHeight =
        typeof window !== "undefined" ? (window.innerHeight * 3) / 4 : 0;
    const modalWidth =
        typeof window !== "undefined" ? (window.innerWidth * multiplyFactor) / 4 : 0;

    return (

        <div>
            <Modal
                open={openPreviewModal}
                title={`Devices Preview`}
                maskClosable={false}
                centered
                width={modalWidth}
                styles={{
                    body: {
                        height: modalHeight,
                        padding: "0px",
                    },
                }}
                footer={null}
                onCancel={() => { setPreviewModal(false),setSelectedPDP_(null) }}
            >
                <>
                    {loading ? (
                        <div className="flex justify-center items-center h-[400px]">
                            <Spin size="large" />
                        </div>
                    ) : (
                        <div className="mb-8">
                            <div className="flex md:flex-row md:items-center md:justify-between space-y-4 mb-4">

                                {/* <TableSearch
                                searchTerm={searchTerm}
                                setSearchTerm={setSearchTerm}
                                tableName={"Customer_Rate_Plan"}
                                headerMap={headerMap}
                            /> */}
                                <Input.Search
                                    placeholder="Search..."
                                    allowClear
                                    value={searchTerm}
                                    onChange={(e) => {
                                        setSearchTerm(e.target.value);
                                        setCurrentPage(1); // Reset to page 1 on new search
                                    }}
                                    style={{ width: 300 }}
                                    className="mt-4 "
                                />
                                {isAllChangeType && (<div className="flex flex-col space-y-2 w-[320px]">
                                    <span className="text-blue-500">* Please select a PDP to view available IP addresses. </span>
                                    <Select
                                        id="pdpName"
                                        placeholder={`Select ${isTelegence ? "PDP Name" : "PDP ID"}`}
                                        options={pdpOptions.map((option: string) => ({
                                            label: option,
                                            value: option,
                                        }))}
                                        value={
                                        selectedPDP_
                                            ? { label: selectedPDP_, value: selectedPDP_ }
                                            : null
                                        }                                        
                                        onChange={handlePDPNameSelect}
                                        styles={DropdownStyles}
                                        className="w-full"
                                        isClearable
                                        menuPortalTarget={document.body}
                                        menuPosition="fixed"
                                        menuPlacement="auto"
                                    />
                                </div>)}
                            </div>
                            <div className="">
                                <Table
                                    columns={columns || []}
                                    dataSource={paginatedData}
                                    loading={loading}
                                    size="middle"
                                    scroll={{ y: modalHeight-170 }}
                                    pagination={paginationConfig}
                                />
                            </div>
                        </div>
                    )}

                </>
            </Modal>

        </div>


    );
};

export default PrivateNetworkPreviewModal;
