"use client";

import { FC, forwardRef, useImperativeHandle, useState } from "react";
import { Input, Tooltip } from "antd";
import React from "react";
import { useFeatureStore } from "../../inventory/featureStore";
import { useAllChangeTypesStore } from "@/app/stores/allChangeTypesStore";
import { PerformanceLogStore } from "@/app/stores/performance_matrix_store";
import { InfoIcon } from "lucide-react";
import PrivateNetworkPreviewModal from "./private_network_preview";

interface DeviceContentProps {
    onContinue: () => void;
    onBack: () => void;
    dropdown: any;
    service_provider: any;
    change_type: any;
    onClose: () => void;
    changeTypeOptions: any;
}
export interface DeviceContentRef {
    runValidation: () => Promise<void> | void;
}

const AllChangeTypesDevices = forwardRef<DeviceContentRef, DeviceContentProps>(
    ({ onContinue, onBack, dropdown, service_provider, change_type, onClose,changeTypeOptions }, ref) => {
        const [errors, setErrors] = useState<string[]>([]);
        const [subscriberNumber, setSubscriberNumber] = useState<string>("");
        const [iccids, setIccids] = useState<string>("");
        const [errorMessage, setErrorMessage] = useState("");
        const { bulkChangeLimit } = useFeatureStore();
         const { getTargetTenantProvider, IsTargetTenantProvider } = PerformanceLogStore();
         const is_parent_provider_exists = IsTargetTenantProvider(service_provider)
        const providerName = getTargetTenantProvider(service_provider).toLowerCase() || service_provider;
        const isTelegence = providerName.toLowerCase().includes("telegence");
        const isVerizon = providerName.toLowerCase().includes("verizon") || providerName.toLowerCase().includes("vzn") || providerName.toLowerCase().includes("vzwcr") || providerName.toLowerCase().includes("2215-so01")
        const isKore = providerName.toLowerCase().includes("kore");
        const [openPreviewModal, setPreviewModal] = useState<boolean>(false);
        const {
            setIsValidated,
            setValidationTrigger,
            setAllChangeTypesDevices,
            setsuccessFullChangeTypes,
            activeChange,
            successFullChangeTypes,
            setallchangeTypesDevicesRows
        } = useAllChangeTypesStore();
    const hasPrivateStaticIP = changeTypeOptions.includes("Change Private Static IP Address");

        const handleContinue = async () => {
            setAllChangeTypesDevices({});

            if (!subscriberNumber && !iccids) {
                setErrorMessage("Please fill in ICCID field or MSISDN field.");
                setErrors([])
                return;
            }

            setErrorMessage("");
            const isTMobile = providerName.toLowerCase().includes("t-mobile");
            const isTeal = providerName.toLowerCase().includes("teal");

            const selected_devices = subscriberNumber ? subscriberNumber : iccids;
            const rows = selected_devices
                .split(/\s*[\n]\s*/)
                .map((line) => line.trim())
                .filter((line) => line.length > 0);
            setallchangeTypesDevicesRows(rows, !!iccids); 
            const newErrors: string[] = [];
            const iccidList: string[] = [];
            const imeiList: string[] = [];
            
            rows.forEach((line, index) => {
                // Split by comma to separate ICCID/MSISDN and IMEI if present
                const parts = line.split(",").map((p) => p.trim());
                const mainId = parts[0];
                const imei = parts[1];

                const label = subscriberNumber ? "Subscriber Number" : "ICCID";
                const minLength = subscriberNumber ? 10 : 14;
                const maxLength = subscriberNumber ? 18 : isTeal ? 32 : 22;

                // Validate ICCID / MSISDN
                if (mainId.length === 0) {
                    newErrors[index] = `${label} must not be empty`;
                } else if (!/^\d+$/.test(mainId) && !isTMobile) {
                    newErrors[index] = `Please enter numbers only for ${label}. Letters or special characters are not allowed`;
                } else if (!/^[a-zA-Z0-9]+$/.test(mainId) && isTMobile) {
                    newErrors[index] = `Please enter letters and numbers only for ${label}. Special characters are not allowed`;
                } else if (mainId.length < minLength || mainId.length > maxLength) {
                    newErrors[index] = `${label} must be between ${minLength} and ${maxLength} digits long`;
                } else {
                    iccidList.push(mainId);
                }

                // Validate IMEI if provided
                // if (imei) {
                //     if (!/^\d+$/.test(imei)) {
                //         newErrors[index] = (newErrors[index] ? newErrors[index] + " | " : "") + "IMEI must contain only numbers";
                //     } else if (imei.length < 14 || imei.length > 22) {
                //         newErrors[index] = (newErrors[index] ? newErrors[index] + " | " : "") + "IMEI must be between 18 and 22 digits long";
                //     } else {
                //         imeiList.push(imei);
                //     }
                // }
            });

            if (rows.length > bulkChangeLimit) {
                newErrors.push(`This request exceeds the allowed record limit of ${bulkChangeLimit} and cannot be processed`);
            }

            setErrors(newErrors);

            if (newErrors.length === 0) {
                setAllChangeTypesDevices({
                    iccids: iccidList,
                    imei: imeiList,
                    isIccid: !!iccids
                });
                setIsValidated(true);
                setValidationTrigger();
                setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
            } else {
                setsuccessFullChangeTypes(successFullChangeTypes.filter((c: any) => c !== activeChange));
                setIsValidated(false);
                setValidationTrigger();
            }
        };

        useImperativeHandle(ref, () => ({
            runValidation: handleContinue,
        }));
        const handlePreviewOpen = async () => {
            setPreviewModal(true)
        };

        return (
            <div>
                <div className="flex grid grid-cols-2 gap-4 my-4">
                    {/* ICCID */}
                    <div className="flex flex-col space-y-2">
                        <div className="flex items-center justify-between">
                            <label htmlFor="iccids" className="font-semibold">
                                ICCID<span className="text-red-500">*</span>
                            </label>
                            <Tooltip title="Preview or view IP details">
                                <InfoIcon
                                    className="h-5 w-5 text-gray-500 cursor-pointer"
                                    onClick={handlePreviewOpen}
                                />
                            </Tooltip>
                        </div>
                        <Input.TextArea
                            id="iccids"
                            rows={4}
                            placeholder={"Enter ICCIDs here"}
                            value={iccids}
                            onChange={(e) => {
                                setIccids(e.target.value);
                                if (e.target.value) setSubscriberNumber("");
                            }}
                            disabled={!!subscriberNumber}
                        />
                    </div>

                    {/* MSISDN */}
                    <div className="flex flex-col space-y-2">
                        <label htmlFor="msisdns" className="font-semibold">
                            MSISDN<span className="text-red-500">*</span>
                        </label>
                        <Input.TextArea
                            id="msisdns"
                            rows={4}
                            placeholder={"Enter MSISDNs here"}
                            value={subscriberNumber}
                            onChange={(e) => {
                                setSubscriberNumber(e.target.value);
                                if (e.target.value) setIccids("");
                            }}
                            disabled={!!iccids}
                        />

                    </div>
                </div>
                <div>
                    {errors.some((err) => err) && (
                        <div className="mt-2 space-y-1">
                            {errors.map((err, idx) =>
                                err ? (
                                    <div key={idx} className="text-red-500 text-sm">
                                        Line {idx + 1}: {err}
                                    </div>
                                ) : null
                            )}
                        </div>
                    )}
                    {errorMessage && <div className="text-red-500 text-sm">{errorMessage}</div>}
                    {(isKore|| isVerizon) && <div className="text-blue-500 text-sm">{"For Update Device Status (Active) requests, please enter ICCID and IMEI separated by a comma"}</div>}
                    {isTelegence && <div className="text-blue-500 text-sm">{"For Activate New Service request, please enter ICCID and IMEI separated by a comma"}</div>}
                    {hasPrivateStaticIP && <div className="text-blue-500 text-sm">{"For Change Private Static IP Address, please enter ICCID and IP Address separated by a comma"}</div>}
                </div>
                <PrivateNetworkPreviewModal
                    service_provider={service_provider}
                    change_type={change_type}
                    openPreviewModal={openPreviewModal}
                    setPreviewModal={setPreviewModal}
                />
            </div>
            
        );
    }
);

export default AllChangeTypesDevices;
