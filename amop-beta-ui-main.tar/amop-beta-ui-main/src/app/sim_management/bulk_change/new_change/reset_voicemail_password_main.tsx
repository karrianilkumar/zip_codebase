"use client";

import { FC, forwardRef, useEffect, useImperativeHandle, useRef, useState } from "react";
import { Button, Checkbox, DatePicker, Input, Modal, Spin, Tooltip } from "antd";
import Select from "react-select";
import { ArrowLeftIcon, ArrowRightIcon } from "@heroicons/react/24/outline";
import SelectDevices from "./select_devices";
import dayjs from 'dayjs'; // Import dayjs
import Partner from "@/app/partner/partner_info/page";
import { useAuth } from "@/app/components/auth_context";
import { DropdownStyles } from "@/app/components/css/dropdown";
import { useAllChangeTypesStore } from "@/app/stores/allChangeTypesStore";
import { SelectContentRef } from "./select_devices";
import { PerformanceLogStore } from "@/app/stores/performance_matrix_store";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { getCurrentDateTime } from "@/app/components/header_constants";
import axios from "axios";

interface VoiceMailPswdProps {
    onContinue: () => void;
    onBack: () => void;
    dropdown: any;
    service_provider: any;
    change_type: any;
    onClose: () => void;
}
export interface VoiceMailPswdContentRef {
    runValidation: () => Promise<void> | void;
    runSubmit: () => Promise<void> | void;
    returnUpdate: () => React.ReactNode | Promise<React.ReactNode>;
}

const ResetVoiceMailPswd = forwardRef<VoiceMailPswdContentRef, VoiceMailPswdProps>(
    ({ onContinue, onBack, dropdown, service_provider, change_type, onClose }, ref) => {
        const [loading, setLoading] = useState(false);
        const { username, role, partner, token, selectedDb, metaData, firstLastName, sessionId, modulesVersionMap } = useAuth();
        const [billingAccountNumber, setBillingAccountNumber] = useState<string | undefined>(undefined);
        const [BANError, setBANError] = useState<string | null>(null);
        const [BANOptions, setBANOptions] = useState<any>([])
        // const [fieldName, setFieldName] = useState<string | undefined>(undefined);
        // const [fieldNameError, setFieldNameError] = useState<string | null>(null);
        const [newPIN, setNewPIN] = useState<string | undefined>(undefined);
        const { isAllChangeType, setIsValidated, setValidationTrigger, allChangeTypesDevices, setsuccessFullChangeTypes, activeChange, successFullChangeTypes } = useAllChangeTypesStore();
        const selectDevicesRef = useRef<SelectContentRef>(null);
        const [saveChanges, setSaveChanges] = useState<boolean>(true);
        const [showSelectDevices, setShowSelectDevices] = useState(false);
        const isSuperAdmin = role?.toLowerCase() === "super admin";
        useEffect(() => {
            if (!isAllChangeType) {
                setBillingAccountNumber(undefined)
            }
            fetchBANs()

        }, [dropdown]);

        const fetchBANs = async () => {
            try {
                setLoading(true);
                const url =
                    ENV_ROUTES.SIM_MANAGEMENT;
                const data = {
                    tenant_name: partner || "default_value",
                    username: username,
                    firstLastName: firstLastName,
                    path: "/get_user_billing_account_number",
                    role_name: role,
                    Partner: partner,
                    request_received_at: getCurrentDateTime(),
                    access_token: token,
                    db_name: selectedDb,
                    ...metaData,
                    sessionID: sessionId,
                };

                const response = await axios.post(url, { data });
                const parsedData = JSON.parse(response.data.body);
                if (parsedData.flag === false) {
                    Modal.error({
                        title: 'Submit Error',
                        content: parsedData.message || 'An error occurred while submitting data. Please try again.',
                        centered: true,
                    });
                } else {
                    const ban_options = parsedData?.data || []
                    setBANOptions(ban_options)
                    if(!isSuperAdmin){
                        setBillingAccountNumber(ban_options[0] || "");
                    }
                }
            } catch (error) {
                Modal.error({
                    title: 'Submit Error',
                    content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching BANs. Please try again.',
                    centered: true,
                });
            }
            finally {
                setLoading(false)
            }
        };

        const handleContinue = () => {
            let valid = true;
            setBANError(null);
            // setFieldNameError(null);

            if (!billingAccountNumber && isSuperAdmin) {
                setBANError("Billing Account Number is required.");
                valid = false;
            }
            // if (!fieldName) {
            //     setFieldNameError("Voicemail Field Name is required.");
            //     valid = false;
            // }


            if (!valid) {
                if (isAllChangeType) {
                    setsuccessFullChangeTypes(
                        successFullChangeTypes.filter((c: any) => c !== activeChange)
                    );
                    if ((!billingAccountNumber && !newPIN) || !saveChanges) {
                        setBANError("");
                        // setFieldNameError("");
                        setIsValidated(true)
                        setValidationTrigger();
                    }
                    else {
                        setIsValidated(false)
                        setValidationTrigger();
                    }
                }
                return
            }

            if (isAllChangeType) {
                setBANError("");
                // setFieldNameError("");
                setIsValidated(true)
                setValidationTrigger();
                if (saveChanges) {
                    setsuccessFullChangeTypes([...successFullChangeTypes, activeChange]);
                }
            }
            else {
                setShowSelectDevices(true);
            }

        };

        const handleBack = () => {
            // Update parent state with values from SelectDevices
            setBillingAccountNumber(billingAccountNumber);
            // setFieldName(fieldName);
            setNewPIN(newPIN);
            setShowSelectDevices(false);
        };

        const returnUpdatedValue = () => {
            return (
                <div className="flex flex-col gap-2">
                    <div className="flex grid grid-cols-2 ">
                        <span className="font-semibold">Billing Account Number:</span>
                        <span>{billingAccountNumber}</span>
                    </div>
                </div>
            )
        }

        useImperativeHandle(ref, () => ({
            runValidation: handleContinue,
            runSubmit: () => {
                selectDevicesRef.current?.runSubmit();
            },
            returnUpdate: returnUpdatedValue
        }));

        const handleSelectBAN = (selectedOption: any | null) => {
            if (selectedOption) {
                const value = selectedOption?.value
                setBillingAccountNumber(value)

            }
            else {
                setBillingAccountNumber(undefined);
            }
        };

        const returnChangedData = () => {
            const changedData = {
                billingAccount: {
                    id: billingAccountNumber || ""
                },
                serviceCharacteristic: [
                    {
                        name: "newPin",
                        value: newPIN || ""
                    }
                ]
            }
            return changedData
        };

        if (loading) {
            return (
                <>
                    <div className="flex justify-center items-center h-[300px]">
                        <Spin size="large" />
                    </div>
                </>
            );
        }
        
        return (
            <div>
                {/* {!showSelectDevices ? ( */}
                <div className={showSelectDevices ? "hidden" : "block"}>
                    {isAllChangeType && (
                        <div className="flex justify-end px-4">
                            <span className="mr-2 font-semibold">Save Changes</span>
                            <Checkbox
                                checked={saveChanges}
                                onChange={(e) => {
                                    if (!e.target.checked) {
                                        setsuccessFullChangeTypes(
                                            successFullChangeTypes.filter((c: any) => c !== activeChange)
                                        );
                                    }
                                    setSaveChanges(e.target.checked)
                                }}
                                className="custom-checkbox"
                            >

                            </Checkbox>
                        </div>
                    )}
                    <div className={`${!isAllChangeType ? "flex flex-col space-y-4 mt-4" : "flex grid grid-cols-2 gap-4"}`}>
                        {/* Billing Account Number */}
                        { isSuperAdmin && (<div className="flex flex-col space-y-2">
                            <label htmlFor="billingAccountNumber" className="field-label">
                                Billing Account Number<span className="text-red-500">*</span>
                            </label>
                            {BANOptions.length === 0 ? (
                                <Input
                                    id="billingAccountNumber"
                                    // placeholder="Enter Billing Account Number"
                                    value={billingAccountNumber}
                                    onChange={(e) => setBillingAccountNumber(e.target.value)}
                                    className="input" />
                            ) : (
                                <Select
                                    id="billingAccountNumber"
                                    placeholder="Select Carrier Rate Plan"
                                    options={BANOptions.length > 0 ? BANOptions.map((option: string) => ({
                                        label: option,
                                        value: option,
                                    })) : [{ value: 'No options', label: 'No options' }]}
                                    value={{ label: billingAccountNumber, value: billingAccountNumber }}
                                    onChange={handleSelectBAN}
                                    isClearable
                                    className="w-full"
                                    styles={DropdownStyles}
                                    menuPortalTarget={document.body}
                                    menuPosition="fixed"
                                    menuPlacement="auto"
                                />
                            )}

                            {(BANError && isAllChangeType) && (
                                <span className="text-red-500">{BANError}</span>
                            )}
                        </div>)}
                        {(BANError && !isAllChangeType) && (
                            <span className="text-red-500">{BANError}</span>
                        )}
                        {/* Voicemail Field Name */}
                        {/* <div className="flex flex-col space-y-2">
                            <label htmlFor="fieldName" className="field-label">
                                Voicemail Field Name<span className="text-red-500">*</span>
                            </label>
                            <Input
                                id="fieldName"
                                value={fieldName}
                                onChange={(e) => setFieldName(e.target.value)}
                                className="input" />
                        </div> */}
                        {/* New Voicemail PIN */}
                        <div className="flex flex-col space-y-2">
                            <label htmlFor="newPIN" className="field-label">
                                New Voicemail PIN
                            </label>
                            <Input
                                id="newPIN"
                                value={newPIN}
                                onChange={(e) => setNewPIN(e.target.value)}
                                className="input" />
                        </div>

                        {/* Action Buttons */}
                        {!isAllChangeType && (
                            <div className="flex justify-center space-x-4 mt-4">
                                <button onClick={onBack} className="cancel-btn">
                                    {/* <ArrowLeftIcon className="h-5 w-5 mr-2" /> */}
                                    Back
                                </button>
                                <button onClick={handleContinue} className="save-btn">
                                    Continue
                                    {/* <ArrowRightIcon className="h-5 w-5 ml-2" /> */}
                                </button>
                            </div>
                        )}

                    </div>
                </div>
                {/* ) : ( */}
                <div className={showSelectDevices ? "block" : "hidden"}>
                    <SelectDevices
                        ref={selectDevicesRef}
                        onContinue={onContinue}
                        onBack={handleBack}
                        service_provider={service_provider}
                        change_type={change_type}
                        changed_data={returnChangedData()}
                        onCancel={onClose}
                    />
                </div>
                {/* )} */}
            </div>
        );
    }
)

export default ResetVoiceMailPswd;
