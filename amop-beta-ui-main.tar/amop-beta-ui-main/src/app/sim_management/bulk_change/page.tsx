"use client";
import React, { useEffect, useState, lazy, Suspense, useRef, useCallback } from "react";
import {
  PlusIcon,
  ArrowDownTrayIcon,
} from "@heroicons/react/24/outline";
import { Button, Modal, Spin, DatePicker, notification, Switch } from "antd";
import { useAuth } from "@/app/components/auth_context";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import dayjs, { Dayjs } from "dayjs";
import { useFeatureStore } from "@/app/sim_management/inventory/featureStore";
import { useBulkChangeModalStore } from "./bulk-changes-store/bulk-change-modal.store";
import { BulkChangeModal } from "./bulk-changes/bulk-change-modal";
import { DoubleLeftOutlined } from "@ant-design/icons";

import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";

// import { NewChange } from "./new_change/page";
import NewChange from "./new_change/page";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useRouter } from "next/router";
import { useSearchParams } from "next/navigation";
import { useCustomerRatePlanStore } from "@/app/stores/customerRateplanStore";
import TableComponent from "@/app/components/TableComponent/page";
import { useSearchStore } from "@/app/stores/searchStore";
import { fireSideCannons } from "@/app/components/confetti";

// import { useLogging } from "@/app/components/contexts/LoggingContext";
const { RangePicker } = DatePicker;
// const TableComponent = lazy(() => import("@/app/components/TableComponent/page"));
const CreateModal = lazy(() => import("@/app/components/createPopup"));
const ColumnFilter = lazy(() => import("@/app/components/columnfilter"));
const TableSearch = lazy(() => import("@/app/components/entire_table_search"));
const AdvancedMultiFilter = lazy(() => import("@/app/components/advanced_search"));

const SimManagementBulkChange: React.FC = () => {
  const [isExportModalOpen, setExportModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const { username, partner, role, settabledata, token, selectedDb, advancedStoredpagination, storedpagination, tenantId, tenantName, firstLastName, sessionId, combineAdnvaceStoredpagination, setCombineAdnvaceStoredpagination ,dynamicColumns,setDynamicColumns,modulesVersionMap, setModulesVersionMap, metaData} = useAuth();
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  const [features, setFeatures] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [dateRange, setDateRange] = useState<[Dayjs | null, Dayjs | null]>([null, null]);
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  // const { showAdvanced, setShowAdvanced} = useCustomerRatePlanStore();
  // const { features: moduleFeatures, setFeatures: setModuleFeatures, setICCID, setBulkRow } = useFeatureStore();
  const { setVisible: setBulkChangeModalVisible } = useBulkChangeModalStore();
  const hasFetchedData = useRef(false);
  // const { logs, addLog, getTotalTime } = useLogging();
  const [performanceMatrix, setPerformanceMatrix] = useState<any>({});
  const [isLogModalOpen, setIsLogModalOpen] = useState(false); // State to manage log modal visibility
  const [logs, setLogs] = useState<{ step: string; time: string }[]>([]); // State for logs
  const [latestNavClick, setLatestNavClick] = useState<{ label: string; clickTime: string } | null>(null);
  //export functionality
  const [exportLoading, setExportLoading] = useState(false);

  const searchParams = useSearchParams();
  const [isNewChangeOpen, setIsNewChangeOpen] = useState(false);
  const [qualificationId, setQualificationId] = useState<any>("");
  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  const { addExport, removeExport,exports } = exportLoadingStore();
  const { setAdvancedSearchData, isRedirectedFromDetails } = useSearchStore();
  const switch_user_2_0 = localStorage.getItem("switch_user_2_0");
  const [switchVersion, setSwitchVersion] = useState(false);
  const isSuperAdmin = role?.toLowerCase() === "super admin";

  const {
    iccid,
    bulkRow,
    features: moduleFeatures,
    setFeatures: setModuleFeatures,
    setICCID,
    setBulkRow,
    setBulkChangeLimit
  } = useFeatureStore();

  //to get open the newChange popup if the url has qualificationId
  useEffect(() => {
    const qualificationId = searchParams.get('qualificationId');
    if (qualificationId) {
      setIsNewChangeOpen(true);
      setQualificationId(qualificationId);
    }
  }, [searchParams]);

  //For 2.0 flow flags
  useEffect(() => {
    const initial_version_flag = modulesVersionMap?.["Sim Management-Bulk Change"] || false
    if (!initial_version_flag || initial_version_flag === "False" || initial_version_flag === "None") {
      setSwitchVersion(false)
    }
    else {
      setSwitchVersion(true)
    }
    saveVersionFlag()

  }, [modulesVersionMap]);

const saveVersionFlag = async () => {
    let parsedData: any
    const url = ENV_ROUTES.MODULE_MANAGEMENT;
    const data = {
      tenant_name: partner || "default_value",
      username,
      path: "/update_version_flag",
      role_name: role,
      request_received_at: getCurrentDateTime(),
      Partner: partner,
      access_token: token,
      db_name: selectedDb,
      ...metaData,
      sessionID: sessionId,
      version_flag: modulesVersionMap,
    };

    try {
      const response = await axios.post(url, { data });
      parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === true) {
        console.log("successfully saved version flag")
      }
    } catch (error) {
      console.error("Error saving version flag:", error);
      return false; // fallback in case of error
    } finally {
    }
  };
  
  const handleVersionChange = (checked: any) => {
    setSwitchVersion(checked)
    const value_ = checked ? "True" : "False"
    setModulesVersionMap((prev: any) => {
      const updated = { ...prev, "Sim Management-Bulk Change": checked };
      localStorage.setItem("switch_user_20_modules_json", JSON.stringify(updated));
      return updated;
    });
  };

  type HeaderMap = Record<string, [string, number]>;
  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);


  const handleFilter = useCallback((advancedFilters: any) => {
    console.log(advancedFilters);
    setAdvancedFilters(advancedFilters)
  }, []);

  const handleReset = useCallback((EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  }, []);

  useEffect(() => {
        setDynamicColumns((prev:any)=>({...prev,"Bulk Change":visibleColumns}))
      }, [visibleColumns]);

      // Create a new function that accepts the version map as parameter
const saveVersionFlagWithMap = async (versionMap: any) => {
  let parsedData: any;
  const url = ENV_ROUTES.MODULE_MANAGEMENT;
  const data = {
    tenant_name: partner || "default_value",
    username,
    path: "/update_version_flag",
    role_name: role,
    request_received_at: getCurrentDateTime(),
    Partner: partner,
    access_token: token,
    db_name: selectedDb,
    ...metaData,
    sessionID: sessionId,
    version_flag: versionMap, // Use the passed version map
  };

  try {
    const response = await axios.post(url, { data });
    parsedData = JSON.parse(response.data.body);

    if (parsedData.flag === true) {
      console.log("Successfully saved version flag for Bulk Change 2.0");
    }
  } catch (error) {
    console.error("Error saving version flag:", error);
    return false;
  }
};

  const fetchData = useCallback(async () => {
    setIsNewChangeOpen(false)
    localStorage.setItem("current_bulk_history_active_module", "Bulk Change");
    setCombineAdnvaceStoredpagination(null)
    setBulkRow(null)
    // localStorage.removeItem('bulk_row');
    setICCID("");
    // localStorage.removeItem('iccid');
    setLoading(true);
    try {
      const url = ENV_ROUTES.SIM_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/get_bulk_change_list_view_data",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Bulk Change",
        feature_module_name: "Bulk Change",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };
      console.log(getCurrentDateTime(), "Show the log time request sent from ui to lambda");
      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);
      setPerformanceMatrix(JSON.parse(response.data.performance_matrix));
      console.log(getCurrentDateTime(), "Show the log time response sent from lambda to ui");
      if (parsedData.flag === false) {
        Modal.error({
          title: 'Data Fetch Error',
          content: parsedData.message || 'An error occurred while fetching data. Please try again.',
          centered: true,
        });
      } else {
        const headersMap_ = parsedData?.headers_map?.["Bulk Change"]?.header_map || {}
        const sortedheaderMap = sortHeaderMap(headersMap_)
        setHeaderMap(sortedheaderMap)
        const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : []
        setHeaders(headers_)
        const dynamic_cols=dynamicColumns?.["Bulk Change"] && dynamicColumns["Bulk Change"].length>0 ?dynamicColumns["Bulk Change"] :headers_ || headers_
        setVisibleColumns(dynamic_cols)
        const tableData_ = parsedData?.data?.sim_management_bulk_change || []
        // setTableData(tableData_)
       const features_ = parsedData?.headers_map?.["Bulk Change"]?.module_features || []
        setFeatures(features_)
        setModuleFeatures(features_)
        localStorage.setItem('switch_user_2_0_bulk_change', "True");
        handleVersionChange(true)
        // if (!isSuperAdmin) {
        //   if (Array.isArray(features_) && features_.some(f => f.toLowerCase() === "bulk change 2.0")) {
        //     handleVersionChange(true)
        //     localStorage.setItem('switch_user_2_0_bulk_change', "True");
        //   }
        //   else {
        //     handleVersionChange(false)
        //     localStorage.setItem('switch_user_2_0_bulk_change', "False");
        //   }
        // }
        // else {
        //   localStorage.setItem('switch_user_2_0_bulk_change', switch_user_2_0 || "False");
        // }
      

        const pagination_ = parsedData?.pages || {}
        // setPagination(pagination_)
        if(!isRedirectedFromDetails){
            setPagination(pagination_);
            setTableData(tableData_);
        }
        const bulk_change_limit = parsedData?.bulk_change_limit || {}
        setBulkChangeLimit(bulk_change_limit)
        // console.log("resp", parsedData)
      }
      // addLog('BulkChange Table Data Processing Data Completed');
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: 'Data Fetch Error',
        content: error instanceof Error ? error.message : 'An unexpected error occurred while fetching data. Please try again.',
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  }, [username, partner, role, token, sortHeaderMap, setModuleFeatures]);

  useEffect(() => {
    if (!hasFetchedData.current) {
      fetchData();
      hasFetchedData.current = true;
    }
  }, [fetchData]);

  const messageStyle = {
    fontSize: '14px',
    fontWeight: 'bold',
    padding: '16px',
  };

  const closeLogModal = () => {
    setIsLogModalOpen(false);
  };

  const handleExportModalOpen = () => {
    setExportModalOpen(true);
  };

  const handleExportModalClose = () => {
    setExportModalOpen(false);
    console.log("Modal closed, resetting date range.");
  };

  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }

  const ExportWithoutSearch = async () => {
    // // setExportLoading(true)
    // addExport(key, heading);
    try {
    const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
      return new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          reject(new Error("Request timed out"));
        }, timeout);

        promise
          .then((res) => {
            clearTimeout(timer);
            resolve(res);
          })
          .catch((err) => {
            clearTimeout(timer);
            reject(err);
          });
      });
    };
   
      // setExportLoading(true)
    // addExport(key, heading);
      
      const url = ENV_ROUTES.MODULE_MANAGEMENT;
      const data = {
        tenant_name: partner || "default_value",
        username,
        path: "/export_to_s3_bucket",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Bulk Change",
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        start_date: getFirstDayOfCurrentMonth(),
        end_date: getLastDayOfCurrentMonth(),
      };
      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000); // Timeout of 10 seconds
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }

      // Wait for 20 seconds before polling
      await new Promise((resolve) => setTimeout(resolve, 20000));
      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      // setExportLoading(false);
      // removeExport(key);

    }
  }
  const pollExportStatus = async () => {
    // Polling for the second API
  const export_url = ENV_ROUTES.MODULE_MANAGEMENT;
  const export_data = {
    tenant_name: partner || "default_value",
    username,
    path: "/get_export_status",
    role_name: role,
    parent_module: "Sim Management",
    module_name: "Bulk Change",
    request_received_at: getCurrentDateTime(),
    Partner: partner,
    access_token: token,
    db_name: selectedDb,
    ...metaData,
    sessionID: sessionId,
  };
    try {
      const export_response = await axios.post(export_url, { data: export_data });
      const export_parsedData = JSON.parse(export_response.data.body);

      if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
        const s3Url = export_parsedData?.export_status_data?.url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
                          .then(response => response.blob())
                          .then(blob => {
                            const url = window.URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = 'Bulk Change.xlsx';
                            a.click();
                            a.remove();
                            window.URL.revokeObjectURL(url);
                            notification.success({
                              message: "Success",
                              description: "Successfully exported the record!",
                              style: messageStyle,
                              placement: "top",
                            });
                            fireSideCannons()
                          })
                        .catch((err) => {
                          console.log("error",err)
                          Modal.error({
                            title: "Export Error",
                            content: "An error occurred while exporting data. Please try again.",
                            centered: true,
                          });
                        });
        } else {
          Modal.error({
            title: "Export Error",
            content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
        return true; // Stop polling
      }

      if (export_parsedData?.export_status_data?.status_flag === "Failure") {
        Modal.error({
          title: "Export Error",
          content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
        return true; // Stop polling
      }
      if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
                Modal.info({
                  title: "Export Error",
                  content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
                  centered: true,
                });
                return true; // Stop polling
              }

      return false; // Continue polling
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
      return true; // Stop polling
    }
  };

  const startPolling = async () => {
    let isPollingComplete = false;

    while (!isPollingComplete) {
      isPollingComplete = await pollExportStatus();
      if (!isPollingComplete) {
        await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
      }
    }
  };

  const handleExport = async (key: string, heading: string) => {
    try {
      addExport(key, heading);
      let parsedData
      let url
      let data: any
      let response
      if(combineAdnvaceStoredpagination){
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          path: "/search_export",
          search: "combined",
          filters: advancedMultiFilters,
          search_word: searchTerm,
          search_all_columns: "True",
          tenant_id: tenantId,
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          index_name: "sim_management_bulk_change",
          module_name: "Bulk Change",
        };
        console.log("combineAdnvaceStoredpagination",data)
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);
      }
      else if (advancedStoredpagination && !storedpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          module_name: "Bulk Change",
          search: "advanced",
          filters: advancedMultiFilters,
          index_name: "sim_management_bulk_change",
          pages: {
            start: 0,
            end: 100
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          tenant_id: tenantId,
          // }
        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

      }
      else if (storedpagination && !advancedStoredpagination) {
        url = ENV_ROUTES.OPEN_SEARCH;
        data = {
          // data: {
          path: "/search_export",
          module_name: "Bulk Change",
          search_word: searchTerm,
          search_all_columns: "True",
          index_name: "sim_management_bulk_change",
          search: "whole",
          pages: {
            start: 0,
            end: 100,
          },
          partner: partner,
          username: username,
          db_name: selectedDb,
          ...metaData,
          sessionID: sessionId,
          tenant_id: tenantId,
        }
        response = await axios.post(url, { data });
        parsedData = JSON.parse(response.data.body);

      }
      else {
        await ExportWithoutSearch();
      }

      if (advancedStoredpagination || storedpagination || combineAdnvaceStoredpagination) {
        if (parsedData.flag === true) {
          const s3Url = parsedData?.download_url || null;
          if (s3Url) {
            // window.location.href = s3Url;
            // // setExportLoading(false)
            // notification.success({
            //   message: 'Success',
            //   description: 'Successfully exported the record!',
            //   style: messageStyle,
            //   placement: 'top',
            // });
            fetch(s3Url)
                            .then(response => response.blob())
                            .then(blob => {
                              const url = window.URL.createObjectURL(blob);
                              const a = document.createElement('a');
                              a.href = url;
                              a.download = 'Bulk Change.xlsx';
                              a.click();
                              a.remove();
                              window.URL.revokeObjectURL(url);
                              notification.success({
                                message: "Success",
                                description: "Successfully exported the record!",
                                style: messageStyle,
                                placement: "top",
                              });
                              fireSideCannons()
                            })
                          .catch((err) => {
                            console.log("error",err)
                            Modal.error({
                              title: "Export Error",
                              content: "An error occurred while exporting data. Please try again.",
                              centered: true,
                            });
                          });
          }
          else {
            // setExportLoading(false)
            removeExport(key);
            Modal.error({
              title: "Export Error",
              content: parsedData.message || "An error occurred while exporting data. Please try again.",
              centered: true,
            });
          }


        } else {
          // setExportLoading(false)
          removeExport(key);
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      }

    } catch (error) {
      console.log("catch")
      await startPolling()
      removeExport(key);
      // setLoading(false);
      // Modal.error({
      //   title: "Export Error",
      //   content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
      //   centered: true,
      // });
    } finally {
      setExportLoading(false)
       removeExport(key);

    }
  };

  const downloadBlob = (base64Blob: string) => {
    const byteCharacters = atob(base64Blob);
    const byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    const byteArray = new Uint8Array(byteNumbers);

    const blobObject = new Blob([byteArray], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blobObject);
    link.download = 'Bulk Change.xlsx';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  // Add log after Suspense
  // useEffect(() => {
  //   addLog("Component rendered");
  // }, []);
  useEffect(() => {
    if (!loading) {
      console.log("Data Displayed in UI", getCurrentDateTime());
    }
  }, [loading]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }

  const disableFutureDates = (current: any) => {
    console.log("future dates:", current && current > dayjs().endOf('day'));
    return current && current > dayjs().endOf('day');
  };



  return (
    <>
      <Suspense fallback={<div className="flex justify-center items-center h-screen"><Spin size="large" /></div>}>
        <div className="relative">
          <div className="pr-4 pl-4 pt-2 flex  md:flex-row md:items-center md:justify-between mt-1 mb-4 space-y-4">
            {/* Search and Advanced Filter Container */}
            <div className="flex space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last">
              {features.includes("Search-Bulk change") && (
                <TableSearch
                  searchTerm={searchTerm}
                  setSearchTerm={setSearchTerm}
                  tableName={"sim_management_bulk_change"}
                  headerMap={headerMap}
                />
              )}
              {features.includes("Advanced filter-Bulk change") && (
                <AdvancedMultiFilter
                  showAdvanced={showAdvanced}
                  setShowAdvanced={setShowAdvanced}
                  onFilter={handleFilter}
                  onReset={handleReset}
                  headers={headers}
                  headerMap={headerMap}
                  tableName={"sim_management_bulk_change"}
                />
              )}
            </div>
  
            {/* Export and ColumnFilter Container (Visible only on medium and larger screens) */}
            <div className="hidden md:flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-first pb-2 md:pb-4">
              {features.includes("New change-Bulk change") && (
                <NewChange isNavigated={isNewChangeOpen} qualification_id={qualificationId} features={features} refreshData = {fetchData}/>
              )}
              {features.includes("Export-Bulk change") && (
                <button
                  className="save-btn flex items-center"
                  onClick={() => {
                    if (!exports.some((exportItem) => exportItem.popupHeading === "Bulk Change")) {
                      handleExport("bulk change", "Bulk Change");
                    }
                  }}
                >
                  <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                  <span>Export</span>
                </button>
              )}
              <ColumnFilter
                headers={headers}
                visibleColumns={visibleColumns}
                setVisibleColumns={setVisibleColumns}
                headerMap={headerMap}
              />
              {/* {(switch_user_2_0 === "True" && isSuperAdmin) && (
              <div className='!mt-[10px]'>
                <span className="font-semibold ml:2 md:ml-4">1.0</span>
                <Switch
                  checked={switchVersion}
                  onChange={handleVersionChange}
                  className="scale-[0.8] md:scale-[1.3] ml-4 custom-switch"
                />
                <span className="font-semibold ml:2 md:ml-4">2.0</span>
              </div>
            )} */}

            </div>
          </div>
  
          <div className={`${showAdvanced ? "mt-[70px]" : ""}`}>
            <TableComponent
              headers={headers}
              headerMap={headerMap}
              initialData={tableData}
              searchQuery={searchTerm}
              visibleColumns={visibleColumns}
              itemsPerPage={100}
              popupHeading="Bulk Change"
              pagination={pagination}
              advancedFilters={filteredData}
              height={showAdvanced ? 280 : 230}
            />
          </div>
  
          {/* Sticky Footer for Small Screens */}
          <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
            {features.includes("New change-Bulk change") && (
              <NewChange isNavigated={isNewChangeOpen} qualification_id={qualificationId} features={features}  refreshData = {fetchData}/>
            )}
            {features.includes("Export-Bulk change") && (
              <button
                className="save-btn"
                onClick={() => {
                  if (!exports.some((exportItem) => exportItem.popupHeading === "Bulk Change")) {
                    handleExport("bulk change", "Bulk Change");
                  }
                }}
              >
                <ArrowDownTrayIcon className="h-5 w-5 text-black-500" />
              </button>
            )}
            <ColumnFilter
              headers={headers}
              visibleColumns={visibleColumns}
              setVisibleColumns={setVisibleColumns}
              headerMap={headerMap}
            />
          </div>
        </div>
      </Suspense>
    </>
  );
};

export default SimManagementBulkChange;
