import React, { useCallback, useEffect, useState } from "react";
import { Modal, Spin, Table } from "antd";
import type { ColumnsType } from "antd/es/table";
import axios from "axios";
import { useAuth } from "../components/auth_context";
import { ENV_ROUTES } from "../components/routes/route_constants";
import { getCurrentDateTime } from "../components/header_constants";
import TableSearch from "../components/entire_table_search";
import AdvancedMultiFilter from "../components/advanced_search";
import Select from "react-select";
import { DropdownStyles } from "../components/css/dropdown";
import WholeTableSearch from "../billing/killbill_components/whole__search";
import AdvancedMultiFilter2 from "../billing/killbill_components/advanced__search";
import InventoryTableComponent from "../components/inventoryTableComponent/page";
import TableComponent from "../components/TableComponent/page";
import { useChargesModalDataStore } from "../billing/killbill_stores/chargesModalData_store";

interface TableDataResponse<T> {
  columns: ColumnsType<T>;
  data: T[];
  headermap?: Record<string, [string, string | number]>;
  headers?: string[];
}

interface SyncStatusData {
  key: string;
  no: number;
  syncName: string;
  syncType: string;
  status: string;
  dateTime: string;
}
interface RevIOStatusData {
   key: string;
  no: number;
  syncName: string;
  syncType: string;
  status: string;
  dateTime: string;
}

interface UserLogData {
  key: string;
  no: number;
  userName: string;
  loginTime: string;
  logoutTime: string;
}

interface DasboardTableProps {
  selectedServiceProvider: string;
  startDate: string;
  endDate: string;
  serviceProvider: string;
  dashboardFeatures?: string[];
}


const DashboardTables: React.FC<DasboardTableProps> = ({ selectedServiceProvider, startDate, endDate, serviceProvider, dashboardFeatures = [], }) => {
  const { username, role, token, partner, selectedDb,metaData, firstLastName, sessionId,settabledata} = useAuth();
  const [loading, setLoading] = useState(false);
  const [syncTableData, setSyncTableData] =
    useState<TableDataResponse<SyncStatusData> | null>(null);
  const [carrierSyncTableData, setCarrierSyncTableData] = useState<TableDataResponse<SyncStatusData> | null>(null);
  const [revIOSyncTableData, setRevIOSyncTableData] = useState<TableDataResponse<RevIOStatusData> | null>(null);
  const [userTableData, setUserTableData] = useState<TableDataResponse<UserLogData> | null>(null);
    const [features, setFeatures] = useState<string[]>(dashboardFeatures);
    const [carrierSearchTerm, setCarrierSearchTerm] = useState("");
    const [revioSearchTerm, setRevioSearchTerm] = useState("");
    const [showAdvanced, setShowAdvanced] = useState(false);
    const [revioshowAdvanced, setRevioShowAdvanced] = useState(false);
    const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
    const [carrierFilteredData, setCarrierFilteredData] = useState([]);
    const [revioFilteredData, setRevioFilteredData] = useState([]);
    const [selectedCarrierStatus, setSelectedCarrierStatus] = useState<string>("All");
    const [selectedRevioStatus, setSelectedRevioStatus] = useState<string>("All");
    const [carrierpagination, setCarrierPagination] = useState<any>({});
    const [reviopagination, setRevioPagination] = useState<any>({});
    const {setChargesTableData,chargesTableData} = useChargesModalDataStore();
    
    const statusOptions = [
      { label: "All", value: "All" },
      { label: "Success", value: "Success" },
      { label: "Failed", value: "Failed" },
      { label: "In Progress", value: "In Progress" }

    ];
    type HeaderMap = Record<string, [string, number]>;

    const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
      const entries = Object.entries(headerMap) as [string, [string, number]][];
      entries.sort((a, b) => a[1][1] - b[1][1]);
      return Object.fromEntries(entries) as HeaderMap;
    }, []);
    

useEffect(() => {
  if (dashboardFeatures.length === 0) {
    const stored = JSON.parse(localStorage.getItem("dashboardFeatures") || "[]");
    setFeatures(stored);
  } else {
    setFeatures(dashboardFeatures);
  }
}, [dashboardFeatures]);
useEffect(() => {
  console.log("Features enabled for Dashboard:", features);
  fetchCarrierSyncData();
  fetchRevIOSyncData();
  setSelectedCarrierStatus("All");
  setSelectedRevioStatus("All");
},[serviceProvider])

  const handleFilter = useCallback((advancedFilters: any) => {
    console.log(advancedFilters);
    setAdvancedFilters(advancedFilters)
  }, []);

  const handleCarrierReset = useCallback((EmptyFilters: any) => {
    console.log(EmptyFilters);
    setCarrierFilteredData(EmptyFilters);
  }, []);
    const handleRevioReset = useCallback((EmptyFilters: any) => {
    console.log(EmptyFilters);
    setRevioFilteredData(EmptyFilters);
  }, []);


  const fetchSyncTableData = async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.DASHBOARD;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        start_date: startDate,
        end_date: endDate,
        service_provider: serviceProvider,
        path: "/daily_sync_card", //
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Dashboard",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      } else {

        if (parsedData.columns && parsedData.data) {
          setSyncTableData({
            columns: parsedData.columns,
            data: parsedData.data,
          });
        } else {
          console.error("Expected columns and data in parsedData are missing");
        }

      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };

  const fetchUserlogTableData = async () => {
    setLoading(true);
    try {
      const url = ENV_ROUTES.DASHBOARD;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        start_date: startDate,
        end_date: endDate,
        service_provider: serviceProvider,
        path: "/live_sessions_table",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Dashboard",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      } else {

        if (parsedData.columns && parsedData.data) {
          setUserTableData({
            columns: parsedData.columns,
            data: parsedData.data,
          });
        }
      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
   const fetchCarrierSyncData = async (sync_status?: string) => {
    setLoading(true);
    settabledata([]);
    try {
      const url = ENV_ROUTES.DASHBOARD;
      const data = {
        tenant_name: selectedServiceProvider || "default_value",
        username: username,
        firstLastName: firstLastName,
        start_date: startDate,
        end_date: endDate,
        sync_status: sync_status || "All",
        service_provider: serviceProvider,
        path: "/get_carrier_sync_dashboard_data",
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Dashboard",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        feature_module_name:"Dashboard",
        parent_module_name:"Dashboard",
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      } else {
        
        if (parsedData.data) {

          const carrierData = parsedData.data || [];

          // For Carrier Sync
          const header_map_carrier = parsedData.headers_map?.['Carrier Sync']?.header_map || {};
          const sortedheaderMap_carrier = sortHeaderMap(header_map_carrier);
          const headers_carrier = Object.keys(sortedheaderMap_carrier).length > 0 ? Object.keys(sortedheaderMap_carrier) : [];
          const sortedHeaderEntries_carrier = Object.entries(header_map_carrier)
            .sort(([, a]: any, [, b]: any) => Number(a[1]) - Number(b[1]));
          const columns_carrier = sortedHeaderEntries_carrier.map(([key, value]: any) => ({
            title: value[0],   
            dataIndex: key,
            key: key,
          }));

         
          const carrier_dataSource = carrierData.map((item: any, index: number) => ({
            ...item,
            key: index,
          })) || [];
         
          const pagination_ = parsedData?.pages || {};
          setCarrierPagination(pagination_);
          setCarrierSyncTableData({
            columns: columns_carrier,
            data: carrier_dataSource,
            headermap: sortedheaderMap_carrier,
            headers: headers_carrier,
          });
        

        } else {
          console.error("Expected columns and data in parsedData are missing");
        }

      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
   const fetchRevIOSyncData = async (sync_status?: string) => {
    setLoading(true);
    setRevIOSyncTableData(null);
    try {
      const url = ENV_ROUTES.DASHBOARD;
      const data = {
        tenant_name: selectedServiceProvider || "default_value",
        username: username,
        firstLastName: firstLastName,
        start_date: startDate,
        end_date: endDate,
        service_provider: serviceProvider,
        sync_status: sync_status || "All",
        path: "/get_revio_sync_dashboard_data", 
        role_name: role,
        parent_module: "Sim Management",
        module_name: "Dashboard",
        mod_pages: {
          start: 0,
          end: 100,
        },
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        sessionID: sessionId,
        feature_module_name:"Dashboard",
        parent_module_name:"Dashboard",
      };

      const response = await axios.post(url, { data });
      const parsedData = JSON.parse(response.data.body);

      if (parsedData.flag === false) {
        Modal.error({
          title: "Data Fetch Error",
          content:
            parsedData.message ||
            "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      } else {
        
        if (parsedData.data) {

          const revioData = parsedData.data || [];

          // For Rev.io Sync
          const header_map_revio = parsedData.headers_map?.['Rev.io Sync']?.header_map || {};
          const sortedheaderMap_revio = sortHeaderMap(header_map_revio);
          const headers_revio = Object.keys(sortedheaderMap_revio).length > 0 ? Object.keys(sortedheaderMap_revio) : [];
          const sortedHeaderEntries_revio = Object.entries(header_map_revio)
            .sort(([, a]: any, [, b]: any) => Number(a[1]) - Number(b[1]));
          const columns_revio = sortedHeaderEntries_revio.map(([key, value]: any) => ({
            title: value[0],   
            dataIndex: key,
            key: key,
          }));

          const revio_dataSource = revioData.map((item: any, index: number) => ({
            ...item,
            key: index,
          })) || [];
          const pagination_ = parsedData?.pages || {};
          setRevioPagination(pagination_);
          setChargesTableData(revio_dataSource || {});
          setRevIOSyncTableData({
            columns: columns_revio,
            data: revio_dataSource,
            headermap: sortedheaderMap_revio,
            headers: headers_revio
          })

        } else {
          console.error("Expected columns and data in parsedData are missing");
        }

      }
    } catch (error) {
      console.error("Error fetching data:", error);
      Modal.error({
        title: "Data Fetch Error",
        content:
          error instanceof Error
            ? error.message
            : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
  

  const fetchAllData = async () => {
    setLoading(true);
    await Promise.all([fetchSyncTableData(), fetchUserlogTableData(),serviceProvider !== "Rev.io" && fetchCarrierSyncData(),fetchRevIOSyncData()]);
    setLoading(false);
  };

  // useEffect(() => {
  //   fetchAllData();
  // }, [selectedServiceProvider, startDate, endDate]); 
  useEffect(() => {
    const fetchDataWithSSM = async () => {
      try {
        // console.log("Fetching SSM parameters...");
        // await fetchSSMParameters(); // Ensure SSM parameters are fetched first
        // console.log("SSM parameters fetched successfully");
  
        // Call your main data fetching function
        await fetchAllData();
      } catch (error) {
        console.error("Error fetching SSM parameters or data:", error);
      }
    };
  
    fetchDataWithSSM();
  }, [selectedServiceProvider, serviceProvider, startDate, endDate]);
  

  const paginationConfig = {
    pageSize: 50,
    showSizeChanger: false, 
  };
   if (loading) {
      return (
        <div className="flex justify-center items-center h-screen">
          <Spin size="large" />
        </div>
      );
    }

  return (
        <div className="dashboard-tables ">
          {features.includes("Carrier Syncs-Dashboard") && serviceProvider !== "Rev.io" &&(
            <div className="table-section graph relative">
              <h2 style={{ fontFamily: "Calibri, sans-serif" }} className="pl-4">Carrier Syncs</h2>

              <div className="pr-4 pl-4  pt-2 flex  md:flex-row md:items-center md:justify-between mt-1 mb-4 space-y-4">

                <div className="flex space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last ">
                  <TableSearch
                    searchTerm={carrierSearchTerm}
                    setSearchTerm={setCarrierSearchTerm}
                    tableName={"Carrier Syncs"}
                    headerMap={carrierSyncTableData?.headermap || {}}
                    filters={{
                      sync_status: selectedCarrierStatus,
                      service_provider: serviceProvider,
                      tenant_name: selectedServiceProvider,
                      start_date: startDate,
                      end_date: endDate
                    }}
                  />
                  <AdvancedMultiFilter
                    showAdvanced={showAdvanced}
                    setShowAdvanced={setShowAdvanced}
                    onFilter={handleFilter}
                    onReset={handleCarrierReset}
                    headers={carrierSyncTableData?.headers || []}
                    headerMap={carrierSyncTableData?.headermap || {}}
                    tableName={"Carrier Syncs"}
                    filters={{
                      sync_status: selectedCarrierStatus,
                      service_provider: serviceProvider,
                      tenant_name: selectedServiceProvider,
                      start_date: startDate,
                      end_date: endDate
                    }}
                  />
                </div>

                <Select
                  value={{ label: selectedCarrierStatus, value: selectedCarrierStatus }}
                  onChange={(opt) => {
                    const value = opt?.value ?? "";
                    setSelectedCarrierStatus(value);
                    fetchCarrierSyncData(value);
                  }}
                  options={statusOptions}
                  placeholder="Service Provider"
                  className="min-w-[150px]"
                  styles={{
                    ...DropdownStyles,
                    control: (base, state) => ({
                      ...DropdownStyles.control(base, state),
                      paddingRight: "0px", // reduce gap
                    }),
                    indicatorsContainer: (base) => ({
                      ...base,
                      paddingRight: "0px", // reduce arrow space
                    }),
                    singleValue: (base) => ({
                      ...DropdownStyles.singleValue(base),
                      marginRight: "0px", // bring text closer
                    }),
                    menuPortal: (base) => ({
                      ...base,
                      zIndex: 9999,
                      position: "fixed",
                    }),
                    menu: (base) => ({
                      ...base,
                      zIndex: 9999,
                    }),
                  }}

                  components={{
                    IndicatorSeparator: () => null
                  }}
                  menuPlacement="auto"
                  menuPortalTarget={document.body}
                />
              </div>

                <div className={`over ${showAdvanced ? "mt-[90px]" : ""}`}>

                {/* <Table
                  columns={carrierSyncTableData?.columns || []}
                  dataSource={carrierSyncTableData?.data || []}
                  loading={loading}
                  pagination={paginationConfig}
                  size="middle"
                  scroll={{ y: 300 }}
                /> */}
                <InventoryTableComponent
                  headers={carrierSyncTableData?.headers || []}
                  headerMap={carrierSyncTableData?.headermap || {}}
                  initialData={carrierSyncTableData?.data || []}
                  searchQuery={carrierSearchTerm}
                  visibleColumns={carrierSyncTableData?.headers || []}
                  itemsPerPage={100}
                  popupHeading="Carrier Syncs"
                  pagination={carrierpagination}
                  advancedFilters={carrierFilteredData}
                  height={showAdvanced ? 280 : 230}
                  syncsData={{
                    start_date: startDate,
                    end_date: endDate,
                    sync_status: selectedCarrierStatus,
                    selectedServiceProvider: serviceProvider,
                    tenant_name: selectedServiceProvider,
                  }}
                // setSelectedData={setselectedRows}
                />
              </div>
            </div>
          )}
          {features.includes("Rev.io Syncs-Dashboard") && (
            <div className="table-section graph relative"  style={{ marginTop: serviceProvider !== "Rev.io" ? "2rem" : 0 }}>
              <h2 style={{ fontFamily: "Calibri, sans-serif" }} className="pl-4">Rev.io Syncs </h2>
              <div className="pr-4 pl-4  pt-2 flex  md:flex-row md:items-center md:justify-between mt-1 mb-4 space-y-4">

                <div className="flex space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last ">
                  <WholeTableSearch
                    searchTerm={revioSearchTerm}
                    setSearchTerm={setRevioSearchTerm}
                    tableName={"Rev.io Syncs"}
                    headerMap={revIOSyncTableData?.headermap || {}}
                   filters={{
                      sync_status: selectedRevioStatus,
                      service_provider: serviceProvider,
                      tenant_name: selectedServiceProvider,
                      start_date: startDate,
                      end_date: endDate
                    }}


                  />
                  <AdvancedMultiFilter2
                    showAdvanced={revioshowAdvanced}
                    setShowAdvanced={setRevioShowAdvanced}
                    onFilter={handleFilter}
                    onReset={handleRevioReset}
                    headers={revIOSyncTableData?.headers || []}
                    headerMap={revIOSyncTableData?.headermap || {}}
                    tableName={"Rev.io Syncs"}
                    filters={{
                        sync_status: selectedRevioStatus,
                        service_provider: serviceProvider,
                        tenant_name: selectedServiceProvider,
                        start_date: startDate,
                        end_date: endDate
                      }}
                  />
                </div>
                  <Select
                  value={{ label: selectedRevioStatus, value: selectedRevioStatus }}
                  onChange={(opt) => {
                    const value = opt?.value ?? "";
                    setSelectedRevioStatus(value);
                    fetchRevIOSyncData(value);
                  }}
                  options={statusOptions}
                  placeholder="Service Provider"
                  className="min-w-[150px]"
                  styles={{
                    ...DropdownStyles,
                    control: (base, state) => ({
                      ...DropdownStyles.control(base, state),
                      paddingRight: "0px", // reduce gap
                    }),
                    indicatorsContainer: (base) => ({
                      ...base,
                      paddingRight: "0px", // reduce arrow space
                    }),
                    singleValue: (base) => ({
                      ...DropdownStyles.singleValue(base),
                      marginRight: "0px", // bring text closer
                    }),
                    menuPortal: (base) => ({
                      ...base,
                      zIndex: 9999,
                      position: "fixed",
                    }),
                    menu: (base) => ({
                      ...base,
                      zIndex: 9999,
                    }),
                  }}

                  components={{
                    IndicatorSeparator: () => null
                  }}
                  menuPlacement="auto"
                  menuPortalTarget={document.body}
                />
              </div>
              <div className={`over ${revioshowAdvanced ? "mt-[90px]" : ""}`}>
                {/* <Table
                  columns={revIOSyncTableData?.columns || []}
                  dataSource={revIOSyncTableData?.data || []}
                  loading={loading}
                  pagination={paginationConfig}
                  size="middle"
                  scroll={{ y: 300 }}
                /> */}
              <TableComponent
                headers={revIOSyncTableData?.headers || []}
                headerMap={revIOSyncTableData?.headermap || {}}
                initialData={chargesTableData || []}
                searchQuery={revioSearchTerm}
                visibleColumns={revIOSyncTableData?.headers || []}
                itemsPerPage={100}
                // allowedActions={[""]}
                popupHeading="Rev.io Syncs"
                pagination={reviopagination}
                advancedFilters={revioFilteredData}
                height={revioshowAdvanced ? 290 : 220}
                syncsData={{
                    start_date: startDate,
                    end_date: endDate,
                    sync_status: selectedRevioStatus,
                    selectedServiceProvider: serviceProvider,
                    tenant_name: selectedServiceProvider,
                  }}
              />
              </div>
            </div>
          )}
          {features.includes("Sync Status-Dashboard") && (
          <div className="table-section graph" style={{ marginTop: "2rem" }}>
            <h2 style={{fontFamily: "Calibri, sans-serif" }}>Sync Status</h2>
            <div className="over">
            <Table
              columns={syncTableData?.columns || []}
              dataSource={syncTableData?.data || []}
              loading={loading}
              pagination={paginationConfig}
              size="middle"
              scroll={{ y: 300 }}
            />
            </div>
          </div>
          )}
          {features.includes("User Log-Dashboard") && (
          <div className="table-section graph" style={{ marginTop: "2rem" }}>
            <h2 style={{fontFamily: "Calibri, sans-serif" }}>User Log</h2>
            <Table
              columns={userTableData?.columns || []}
              dataSource={userTableData?.data || []}
              pagination={paginationConfig}
              loading={loading}
              size="middle"
              scroll={{ y: 300 }}
            />
          </div>
          )}

          {/* <style jsx>{`
            .dashboard-tables {
              padding: 20px;
            }
            .table-section {
              background: white;
              padding: 20px;
              border-radius: 8px;
              box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            }
            h2 {
              margin-bottom: 16px;
              font-size: 20px;
              font-weight: 600;
            }
      :global(.custom-table) {
        font-family: Calibri, sans-serif;
      }
      :global(.custom-table .ant-table) {
        font-family: Calibri, sans-serif;
      }
      :global(.custom-table .ant-table-thead > tr > th) {
        font-family: Calibri, sans-serif;
      }
      :global(.custom-table .ant-table-tbody > tr > td) {
        font-family: Calibri, sans-serif;
      }
      :global(.custom-table .ant-pagination-item),
      :global(.custom-table .ant-pagination-prev),
      :global(.custom-table .ant-pagination-next),
      :global(.custom-table .ant-pagination-jump-prev),
      :global(.custom-table .ant-pagination-jump-next) {
        font-family: Calibri, sans-serif;
      }
        }
          `}</style> */}
        </div>
    //   )}
    // </>
  );
};

export default DashboardTables;
