import React, { useEffect, useState } from "react";
import axios from "axios";
import { useAuth } from "@/app/components/auth_context";
import { Spin } from "antd";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { serviceProviders } from "../constants/partnercarrier";

interface ConfigTypes {
  title: string;
  height: number;
  width: number;
  count: number | string;
}

interface DasboardCardsProps {
  selectedServiceProvider: string;
  startDate: string;
  endDate: string;
  serviceProvider: string;
  dashboardFeatures?: string[];
}



const DashbaordCards: React.FC<DasboardCardsProps> = ({ selectedServiceProvider, startDate, endDate, serviceProvider, dashboardFeatures = []}) => {
  const [loading, setLoading] = useState(false);
  const [datalog, setData] = useState<ConfigTypes[]>([]);
  const { token, partner ,selectedDb,metaData,sessionId,username,role} = useAuth();

  // useEffect(() => {
  //   const fetchData = async () => {
  //     setLoading(true);
  //     try {
  //       const url =ENV_ROUTES.DASHBOARD;
  //       const requestPaths = [
  //         { path: "/count_of_service_provider" },
  //         { path: "/count_of_active_customers" },
  //         { path: "/count_of_active_sims" },
  //         { path: "/count_of_pending_sim_activations" },
  //       ];

  //       const promises = requestPaths.map(({ path }) => {
  //         const requestData = {
  //             partner: partner,
  //             start_date: startDate,
  //             end_date: endDate,
  //             service_provider: serviceProvider,
  //             path: path,
  //             access_token: token,
  //             db_name:selectedDb,
  //             sessionID: sessionId,
  //         };

  //         return axios.post(url, { data: requestData }).then(response => {
  //           const parsedData = JSON.parse(response.data.body);
  //           const { data } = parsedData;
  //           return {
  //             title: data.title,
  //             count: parsedData.data.data, 
  //             height: parsedData.data.height,
  //             width: parsedData.data.width  
  //           };
  //         });
  //       });

  //       const results = await Promise.all(promises);
  //       setData(results);
  //     } catch (error) {
  //       console.error("Error fetching data:", error);
  //     } finally {
  //       setLoading(false);
  //     }
  //   };

  //   fetchData();
  // }, [token, selectedServiceProvider, startDate, endDate]); 
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
  
      try {
        // console.log("Fetching SSM parameters...");
        // await fetchSSMParameters(); // Ensure SSM parameters are fetched first
        // console.log("SSM parameters fetched successfully");
  
        const url = ENV_ROUTES.DASHBOARD;
       const allCards = [
  { path: "/count_of_service_provider", feature: "No:of service providers-Dashboard" },
  { path: "/count_of_active_customers", feature: "No:of active customers-Dashboard" },
  { path: "/count_of_active_sims", feature: "No:of active SIMs-Dashboard" },
  { path: "/count_of_pending_sim_activations", feature: "Pending SIM activations-Dashboard" },
];

// ✅ Get allowed features from props or localStorage
const storedFeatures =
  dashboardFeatures.length > 0
    ? dashboardFeatures
    : JSON.parse(localStorage.getItem("dashboardFeatures") || "[]");

const requestPaths = allCards.filter((card) =>
  storedFeatures.includes(card.feature)
);


        const promises = requestPaths.map(({ path }) => {
          const requestData = {
            partner: partner,
            tenant_name:partner,
            start_date: startDate,
            end_date: endDate,
            service_provider: serviceProvider,
            path: path,
            role_name:role,
            username: username,
            access_token: token,
            db_name: selectedDb,
            ...metaData,
            sessionID: sessionId,
          };
  
          return axios.post(url, { data: requestData }).then((response) => {
            const parsedData = JSON.parse(response.data.body);
            const { data } = parsedData;
            return {
              title: data.title,
              count: parsedData.data.data,
              height: parsedData.data.height,
              width: parsedData.data.width,
            };
          });
        });
  
        const results = await Promise.all(promises);
        setData(results);
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };
  
    fetchData();
  }, [token, selectedServiceProvider, startDate, endDate]);
  

  if (loading) {
    return (
      <div className="flex justify-center items-center h-screen">
        <Spin size="large" />
      </div>
    );
  }
  const isSmallScreen = typeof window !== "undefined" && window.innerWidth < 700;

  return (
    <div className="ml-1 py-2 px-6 w-full">
      <div className="grid grid-cols-2 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {datalog.map((item, index) => {
          return (
            <div
              key={index}
              className="chart w-full"
              style={
                isSmallScreen
                  ? { width: "150px", height: "100px" }
                  : { width: `${item.width}px`, height: `${item.height}px` }
              }
            >
              <div className="p-2 mt-0">
                <div className="flex flex-col sm:text-left text-center">
                  <h2 style={{ fontFamily: "Calibri, sans-serif", fontSize: "18px" }}>
                    {item.title}
                  </h2>
                  <p className="chart-count">
                    <span style={{ fontSize: "18px" }}>{item.count}</span>
                  </p>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};


export default DashbaordCards;
