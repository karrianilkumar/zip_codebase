
import { Modal, notification, Spin } from "antd";
import React, { Suspense, useCallback, useEffect, useRef, useState } from "react";
import KillbillTableComponent from "./table__component";
import { ArrowDownTrayIcon } from "@heroicons/react/24/outline";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import axios from "axios";
import { getCurrentDateTime } from "@/app/components/header_constants";
import { exportLoadingStore } from "@/app/stores/ExportLoadingStore";
import { useAuth } from "@/app/components/auth_context";
import { Tabs } from "antd";
import { useCustomerProfileStore } from "../killbill_stores/customer_profile_store";
import BillingPlatformTableComponent2 from "./table__component_2";
import EditableTableComponent from "./editable_table_component";
import TableComponent from "@/app/components/TableComponent/page";
import TableSearch from "@/app/components/entire_table_search";
import AdvancedMultiFilter from "@/app/components/advanced_search";
import WholeTableSearch from "./whole__search";
import AdvancedMultiFilter2 from "./advanced__search";
import { useChargesModalDataStore } from "../killbill_stores/chargesModalData_store";
import { useSearchStore } from "@/app/stores/searchStore";
import { fireSideCannons } from "@/app/components/confetti";

const { TabPane } = Tabs;
interface ChargesPopupProps {
  row: any;
  isOpen: boolean;
  onClose: () => void;
  popupheading: string;
}
interface ChargeOverview {
  bill_details: Record<string, number>;
  usage_details: Record<string, number>;
}


const ChargesPopup: React.FC<ChargesPopupProps> = ({
  row,
  onClose,
  isOpen, popupheading
}) => {
  const tenant_id_ = localStorage.getItem("tenant_id") || "0";
  const [loading, setLoading] = useState(false);
  // const [exportLoading, setExportLoading] = useState(false);
  const { addExport, removeExport } = exportLoadingStore();
  const [searchTerm, setSearchTerm] = useState("");
  const [filteredData, setFilteredData] = useState([]);
  const [showAdvanced, setShowAdvanced] = useState(false);

  const [chargeSearchTerm, setChargeSearchTerm] = useState("");
  const [chargeFilteredData, setChargeFilteredData] = useState([]);
  const [chargeShowAdvanced, setChargeShowAdvanced] = useState(false);

  const [creditSearchTerm, setCreditSearchTerm] = useState("");
  const [creditFilteredData, setCreditFilteredData] = useState([]);
  const [creditShowAdvanced, setCreditShowAdvanced] = useState(false);

  const [recurringSearchTerm, setRecurringSearchTerm] = useState("");
  const [recurringFilteredData, setRecurringFilteredData] = useState([]);
  const [recurringShowAdvanced, setRecurringShowAdvanced] = useState(false);

  const { setChargeDetailsSearchData, setChargeDetailsTableData, setChargesDetailsPagination, setCreditDetailsTableData, setCreditDetailsPagination, setCreditDetailsSearchData, setRecurringChargesPagination, setRecurringChargesSearchData, setRecurringChargesTableData, chargesDetailsPagination, creditDetailsPagination, recurringChargesPagination } = useSearchStore();
   const [visibleColumns, setVisibleColumns] = useState<string[]>([]);
  const [chargesVisibleColumns, setChargesVisibleColumns] = useState<string[]>([]);
  const [creditVisibleColumns, setCreditVisibleColumns] = useState<string[]>([]);
  const [recurringVisibleColumns, setRecurringVisibleColumns] = useState<string[]>([]);

  const [createModalData, setcreateModalData] = useState<any[]>([]);
  const [allowedActions, setAllowedActions] = useState<any[]>([]);
  const [generalFields, setgeneralFields] = useState<any[]>([])
  const { username, partner, role, token, selectedDb, metaData, selectedBillingDb, sessionId, settabledata, advancedStoredpagination, storedpagination, combineAdnvaceStoredpagination, tenantName, tenantId, firstLastName, setStoredPagination, setAdvancedStoredPagination } = useAuth();
  const { setChargesTableData, chargesTableData, setUsageDetailsTableData, setCreditTableData, setChargeByServiceTableData, setRecurringChargeData, creditTableData, usageDetailsTableData, chargeByServiceTableData, recurringChargeData } = useChargesModalDataStore();
  const hasFetchedChargeOverview = useRef(false);
  const hasFetchedChargeByService = useRef(false);
  const hasFetchedUsageDetails = useRef(false)
  const [activeTab, setActiveTab] = useState("1"); // Track active tab
  const [pagination, setPagination] = useState<any>({});
  const [chargePagination, setChargeTablePagination] = useState<any>({});
  const [CreditPagination, setCreditTablePagination] = useState<any>({});
  const [recurringPagination, setRecurringChargePagination] = useState<any>({});
  const [tableData, setTableData] = useState<any>([]);
  // const [usageDetailsTableData, setUsageDetailsTableData] = useState<any>([])
  // const [CreditTableData, setCreditTableData] = useState<any>([]);
  // const [chargeByServiceTableData,setChargeByServicetableData] = useState<any>([]);
  // const [recuringChargeData, setRecurringChargeData] = useState<any>([]);
  const [totalUsageData, setTotalUsageData] = useState<{
    total_usage: number;
    total_tax: number;
  }>({
    total_usage: 0,
    total_tax: 0,
  });
  const parseAmount = (value: unknown): number => {
    if (value === null || value === undefined) return 0;

    if (typeof value === "number") {
      return Number.isFinite(value) ? value : 0;
    }

    if (typeof value === "string") {
      const cleaned = value.replace(/,/g, "").trim();
      if (cleaned === "") return 0;

      const num = Number(cleaned);
      return Number.isFinite(num) ? num : 0;
    }

    return 0;
  };

  const [recurringTotal, setRecurringTotal] = useState<number>(0);
  const [chargesTotal, setChargesTotal] = useState<number>(0);
  const [creditsTotal, setCreditsTotal] = useState<number>(0);
  const totalChargeReveiwAmount_ =
    recurringTotal + chargesTotal + creditsTotal;


  const [overViewData, setOverViewData] = useState<ChargeOverview>({
    bill_details: {},
    usage_details: {},
  });
  const [features, setFeatures] = useState<string[]>([]);
  const [features2, setFeatures2] = useState<string[]>([]);
  const [headers, setHeaders] = useState<any[]>([]);
  const [usageHeaders, setUsageHeaders] = useState<any[]>([]);
  const [headerMap, setHeaderMap] = useState<any>({});
  const [usageHeaderMap, setUsageHeaderMap] = useState<any>({});

  const modalHeight = typeof window !== "undefined" ? window.innerHeight * 0.5 : 0; // 50% of viewport height
  type HeaderMap = Record<string, [string, number]>;
  const { setAccountNumber, accountNumber, setBillId, BillId } = useCustomerProfileStore();
  const [totalAmount, setTotalAmount] = useState<number>(0)
  const [totalTaxes, setTotalTaxes] = useState<number>(0)

  const [advancedMultiFilters, setAdvancedFilters] = useState<any>({});
  const [chargeAdvancedMultiFilters, setChargeAdvancedFilters] = useState<any>({});
  const [creditAdvancedMultiFilters, setCreditAdvancedFilters] = useState<any>({});
  const [recurringadvancedMultiFilters, setRecurringAdvancedFilters] = useState<any>({});


  const sortHeaderMap = useCallback((headerMap: HeaderMap): HeaderMap => {
    const entries = Object.entries(headerMap) as [string, [string, number]][];
    entries.sort((a, b) => a[1][1] - b[1][1]);
    return Object.fromEntries(entries) as HeaderMap;
  }, []);


  // eslint-disable-next-line react-hooks/exhaustive-deps
  const fetchChargeDetails = async () => {
    setShowAdvanced(false);
    // settabledata([])
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/charge_overview_account_charges",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Charge Overview",
        // sub_module: "Charge Overview",
        mod_pages: {
          start: 0,
          end: 100,
        },
        bill_id: BillId,
        accoun_number: accountNumber,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        tenant_id: tenant_id_,
        main_module_name: "Customer Profiles",
        feature_module_name: "Charge Overview",
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)

      if (parsedData.flag === true) {
        setLoading(false);
        const headersMap_ = parsedData?.header_map?.["Charge Overview"]?.header_map || {};
        const sortedheaderMap = sortHeaderMap(headersMap_);
        setHeaderMap(sortedheaderMap);
        const generalFields_ = parsedData || {}
        setgeneralFields(generalFields_)

        const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
        console.log("headers", headers_)
        setHeaders(headers_);
        setChargesVisibleColumns(headers_);
        setFeatures2(parsedData?.header_map?.["Charge Overview"]?.module_features || []);

        setChargeTablePagination(parsedData?.pages || {});
        setChargesTableData(parsedData?.data || []);
        setTableData(parsedData)
        // setChargesTotal(parsedData?.total)
        setChargesTotal(parseAmount(parsedData?.total));


      } else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
  const fetchCreditDetails = async () => {
    // settabledata([])
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/charge_overview_account_credits",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Charge Overview",
        // sub_module: "Charge Overview",
        mod_pages: {
          start: 0,
          end: 100,
        },
        bill_id: BillId,
        accoun_number: accountNumber,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        tenant_id: tenant_id_,
        main_module_name: "Customer Profiles",
        feature_module_name: "Charge Overview",
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)

      if (parsedData.flag === true) {
        setLoading(false);
        const headersMap_ = parsedData?.header_map?.["Charge Overview"]?.header_map || {};
        const sortedheaderMap = sortHeaderMap(headersMap_);
        setHeaderMap(sortedheaderMap);
        const generalFields_ = parsedData || {}
        setgeneralFields(generalFields_)

        const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
        console.log("headers", headers_)
        setHeaders(headers_);
        setCreditVisibleColumns(headers_);
        setFeatures2(parsedData?.header_map?.["Charge Overview"]?.module_features || []);

        setCreditTablePagination(parsedData?.pages || {});
        setCreditTableData(parsedData?.data || []);
        // setCreditsTotal(parsedData?.total ?? 0);
        setCreditsTotal(parseAmount(parsedData?.total));




      } else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
  const fetchRecurringChargeDetails = async () => {
    // settabledata([])
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    let parsedData: any;
    try {
      setLoading(true);
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/charge_overview_recurring_charges",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Charge Overview",
        // sub_module: "Charge Overview",
        mod_pages: {
          start: 0,
          end: 100,
        },
        bill_id: BillId,
        accoun_number: accountNumber,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        tenant_id: tenant_id_,
        main_module_name: "Customer Profiles",
        feature_module_name: "Charge Overview",
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)

      if (parsedData.flag === true) {
        setLoading(false);
        const headersMap_ = parsedData?.header_map?.["Charge Overview"]?.header_map || {};
        const sortedheaderMap = sortHeaderMap(headersMap_);
        setHeaderMap(sortedheaderMap);
        const generalFields_ = parsedData || {}
        setgeneralFields(generalFields_)

        const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
        console.log("headers", headers_)
        setHeaders(headers_);
        setRecurringVisibleColumns(headers_);
        setFeatures2(parsedData?.header_map?.["Charge Overview"]?.module_features || []);

        setRecurringChargePagination(parsedData?.pages || {});
        setRecurringChargeData(parsedData?.data || []);
        // setRecurringTotal(parsedData?.total ?? 0);
        setRecurringTotal(parseAmount(parsedData?.total));



      } else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
  const fetchChargeByService = async () => {
    setShowAdvanced(false);
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    let parsedData: any;
    try {
      setLoading(true);
      // const LAMBDA = popupheading === "Billing"?"BP_BILLING_PAYMENTS":"BP_CUSTOMER_PROFILES"
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/charge_by_service_list_view",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Charge By Service",
        mod_pages: {
          start: 0,
          end: 100,
        },
        bill_id: BillId,
        account_number: accountNumber,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        main_module_name: "Customer Profiles",
        feature_module_name: "Charge By Service",
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)

      if (parsedData.flag === true) {
        // Log data and set loading to false immediately to stop the loader
        console.log("table response:", parsedData);
        setLoading(false); // Ensure this happens right away

        // Defer other state updates using a timeout to decouple them from the main thread
        setTimeout(() => {
          if (popupheading === "Billing") {
            const headersMap_ = parsedData?.header_map?.["Charge By Service"]?.header_map || {};
            const sortedheaderMap = sortHeaderMap(headersMap_);
            setHeaderMap(sortedheaderMap);
            const generalFields_ = parsedData || {}
            setgeneralFields(generalFields_)

            const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
            console.log("headers", headers_)
            setHeaders(headers_);
            setVisibleColumns(headers_);
            setFeatures2(parsedData?.header_map?.["Charge By Service"]?.module_features || []);
            const createModalData_ = parsedData?.header_map?.["Charge By Service"]?.pop_up || []

            setcreateModalData(createModalData_)
            setPagination(parsedData?.pages || {});
            setChargeByServiceTableData(parsedData?.data?.charge_by_service || []);
            setTotalAmount(parsedData?.data?.total || 0)
            setTotalTaxes(parsedData?.data?.total_taxes || 0)

          }
          else {

            const headersMap_ = parsedData?.header_map?.["Charge By Service"]?.header_map || {};
            const sortedheaderMap = sortHeaderMap(headersMap_);
            setHeaderMap(sortedheaderMap);
            const generalFields_ = parsedData || {}
            setgeneralFields(generalFields_)

            const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
            console.log("headers", headers_)
            setHeaders(headers_);
            setVisibleColumns(headers_);
            setFeatures2(parsedData?.header_map?.["Charge By Service"]?.module_features || []);
            const createModalData_ = parsedData?.header_map?.["Charge By Service"]?.pop_up || []

            setcreateModalData(createModalData_)
            setPagination(parsedData?.pages || {});
            setChargeByServiceTableData(parsedData?.data?.charge_by_service || []);
            setTotalAmount(parsedData?.data?.total || 0)
            setTotalTaxes(parsedData?.data?.total_taxes || 0)
          }


          // Defer heavy state updates to allow the UI to remain responsive
          // setTimeout(() => {
          //   setTableData(parsedData?.inventory_data || []);
          // }, 0);
        }, 0);
        // requestIdleCallback(() => {
        //   setTableData(parsedData?.inventory_data || []);
        //   console.log("table response:", getCurrentDateTime());
        // });
      } else {
        setLoading(false);
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
  const fetchUsageDetails = async () => {
    setShowAdvanced(false);
    setStoredPagination(null);
    setAdvancedStoredPagination(null);
    let parsedData: any;
    try {
      setLoading(true);
      // const LAMBDA = popupheading === "Billing"?"BP_BILLING_PAYMENTS":"BP_CUSTOMER_PROFILES"
      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username: username,
        firstLastName: firstLastName,
        path: "/usage_sms_charges_list_view",
        role_name: role,
        parent_module: "Billing Platform",
        module_name: "Usage Details",
        mod_pages: {
          start: 0,
          end: 100,
        },
        bill_id: BillId,
        account_number: accountNumber,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        billing_db_name: selectedBillingDb,
        sessionID: sessionId,
        main_module_name: "Customer Profiles",
        feature_module_name: "Usage Details",
      };

      const response = await axios.post(url, { data });
      console.log(response)
      parsedData = JSON.parse(response.data.body);
      console.log(parsedData)

      if (parsedData.flag === true) {
        // Log data and set loading to false immediately to stop the loader
        console.log("table response:", parsedData);

        const headersMap_ = parsedData?.header_map?.["Usage SMS Charges"]?.header_map || {};
        const sortedheaderMap = sortHeaderMap(headersMap_);
        setUsageHeaderMap(sortedheaderMap);
        const generalFields_ = parsedData || {}
        setgeneralFields(generalFields_)

        const headers_ = Object.keys(sortedheaderMap).length > 0 ? Object.keys(sortedheaderMap) : [];
        console.log("headers", headers_)
        setUsageHeaders(headers_);
        setVisibleColumns(headers_);

        setPagination(parsedData?.pages || {});
        setUsageDetailsTableData(parsedData?.data?.usage_sms_charges || []);
        setTotalUsageData({
          total_usage: parsedData?.total_usage ?? 0,
          total_tax: parsedData?.total_tax ?? 0,
        });

      }
      else {
        console.log("flag set to false")
        Modal.error({
          title: "Data Fetch Error",
          content: parsedData.message || "An error occurred while fetching data. Please try again.",
          centered: true,
        });
      }
      setLoading(false);

    } catch (error) {
      setLoading(false);
      Modal.error({
        title: "Data Fetch Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    if (isOpen) {
      setChargeDetailsSearchData({})
      setChargeDetailsTableData([])
      setChargesDetailsPagination(null)

      setCreditDetailsSearchData({})
      setCreditDetailsTableData([])
      setCreditDetailsPagination(null)

      setRecurringChargesSearchData({})
      setRecurringChargesTableData([])
      setRecurringChargesPagination(null)

      if (activeTab === "1") {
        fetchChargeDetails();
        fetchCreditDetails();
        fetchRecurringChargeDetails();
        hasFetchedChargeOverview.current = true;
      }
      else if (activeTab === "2") {
        fetchUsageDetails();
        hasFetchedUsageDetails.current = true;
      }
      else if (activeTab === "3") {
        fetchChargeByService();
        hasFetchedChargeByService.current = true;
      }
    }
  }, [isOpen, activeTab]);

    useEffect(() => {
    const handleScroll = (e: Event) => {
      const target = e.target as HTMLElement;
      // Allow scrolling inside the dropdown menu itself
      if (target.closest('.ant-select-dropdown') || 
          target.closest('.ant-picker-dropdown')) {
        return;
      }

      // Close all open dropdowns immediately when scrolling starts
      const dropdowns = document.querySelectorAll('.ant-select-dropdown:not(.ant-select-dropdown-hidden)');
      
      if (dropdowns.length > 0) {
        // Simulate click outside to close dropdowns
        const clickEvent = new MouseEvent('mousedown', {
          view: window,
          bubbles: true,
          cancelable: true
        });
        document.body.dispatchEvent(clickEvent);
      }
    };
    if (isOpen) {
      // Get all scrollable containers
      const modalBody = document.querySelector('.ant-modal-body');
      const scrollContainers = document.querySelectorAll('.overflow-y-auto, .overflow-auto, .flex-1');
      
      if (modalBody) {
        modalBody.addEventListener('scroll', handleScroll, true);
      }
      
      scrollContainers.forEach(container => {
        container.addEventListener('scroll', handleScroll, true);
      });

      return () => {
        if (modalBody) {
          modalBody.removeEventListener('scroll', handleScroll, true);
        }
        scrollContainers.forEach(container => {
          container.removeEventListener('scroll', handleScroll, true);
        });
      };
    }
  }, [isOpen]);
  const handleFilter = useCallback((advancedFilters: any) => {
    console.log(advancedFilters);
    setAdvancedFilters(advancedFilters)

  }, []);

  const handleReset = useCallback((EmptyFilters: any) => {
    console.log(EmptyFilters);
    setFilteredData(EmptyFilters);
  }, []);

  const handleChargeFilter = useCallback((advancedFilters: any) => {
    console.log(advancedFilters);
    setChargeAdvancedFilters(advancedFilters)

  }, []);

  const handleChargeReset = useCallback((EmptyFilters: any) => {
    console.log(EmptyFilters);
    setChargeFilteredData(EmptyFilters);
  }, []);

  const handleCreditFilter = useCallback((advancedFilters: any) => {
    console.log(advancedFilters);
    setCreditAdvancedFilters(advancedFilters)

  }, []);

  const handleCreditReset = useCallback((EmptyFilters: any) => {
    console.log(EmptyFilters);
    setCreditFilteredData(EmptyFilters);
  }, []);

  const handleRecurringFilter = useCallback((advancedFilters: any) => {
    console.log(advancedFilters);
    setRecurringAdvancedFilters(advancedFilters)

  }, []);

  const handleRecurringReset = useCallback((EmptyFilters: any) => {
    console.log(EmptyFilters);
    setRecurringFilteredData(EmptyFilters);
  }, []);

  function getFirstDayOfCurrentMonth() {
    const now = new Date();
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return `${firstDay.getFullYear()}-${String(firstDay.getMonth() + 1).padStart(2, '0')}-${String(firstDay.getDate()).padStart(2, '0')} 00:00:00`;
  }

  function getLastDayOfCurrentMonth() {
    const now = new Date();
    const lastDay = new Date(now.getFullYear(), now.getMonth() + 1, 0);
    return `${lastDay.getFullYear()}-${String(lastDay.getMonth() + 1).padStart(2, '0')}-${String(lastDay.getDate()).padStart(2, '0')} 23:59:59`;
  }

  const handleChargesExport = async (key: string, heading: string) => {
    const tenant_id_ = localStorage.getItem("tenant_id") || "0";

    try {
      addExport(key, heading);

      let parsedData;
      let url;
      let data: any;
      let response;
      const moduleName = key;

      if (chargesDetailsPagination) {
        if (combineAdnvaceStoredpagination) {
          console.log("combineAdnvaceStoredpagination", combineAdnvaceStoredpagination)
          url = ENV_ROUTES.OPEN_SEARCH;
          data = {
            path: "/search_export",
            search: "combined",
            filters: chargeAdvancedMultiFilters,
            search_word: chargeSearchTerm,
            search_all_columns: "True",
            // tenant_id: tenantId,
            pages: {
              start: 0,
              end: 100,
            },
            partner: partner,
            username: username,
            db_name: selectedBillingDb,
            ...metaData,
            // billing_db_name: selectedBillingDb,
            sessionID: sessionId,
            tenant_id: tenant_id_,
            index_name: "Charge Details",
            module_name: moduleName,
            account_number: accountNumber,
            bill_id: BillId,
          };
          console.log("combineAdnvaceStoredpagination", data)
          response = await axios.post(url, { data });
          parsedData = JSON.parse(response.data.body);
        }
        else if (advancedStoredpagination && !storedpagination) {
          console.log("advancedStoredpagination", advancedStoredpagination)
          url = ENV_ROUTES.OPEN_SEARCH;
          data = {
            path: "/search_export",
            search: "advanced",
            filters: chargeAdvancedMultiFilters,
            username: username,
            index_name: "Charge Details",
            module_name: moduleName,
            pages: { start: 0, end: 100 },
            partner,
            db_name: selectedBillingDb,
            ...metaData,
            // billing_db_name: selectedBillingDb,
            sessionID: sessionId,
            tenant_id: tenant_id_,
            account_number: accountNumber,
            bill_id: BillId,
          };
          response = await axios.post(url, { data });
          parsedData = JSON.parse(response.data.body);
        }
        else if (storedpagination && !advancedStoredpagination) {
          console.log("storedpagination", storedpagination)
          url = ENV_ROUTES.OPEN_SEARCH;
          data = {
            path: "/search_export",
            search_word: chargeSearchTerm,
            username: username,
            search_all_columns: "True",
            index_name: "Charge Details",
            module_name: moduleName,
            search: "whole",
            pages: { start: 0, end: 100 },
            partner,
            db_name: selectedBillingDb,
            ...metaData,
            // billing_db_name: selectedBillingDb,
            sessionID: sessionId,
            tenant_id: tenant_id_,
            account_number: accountNumber,
            bill_id: BillId,
          };
          response = await axios.post(url, { data });
          parsedData = JSON.parse(response.data.body);
        } else {
          await ExportWithoutSearch(key);
          return;
        }
      }
      else {
        await ExportWithoutSearch(key);
        return;
      }


      if (parsedData.flag) {
        const s3Url = parsedData?.download_url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the  record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
            .then(response => response.blob())
            .then(blob => {
              const url = window.URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = `${key}.xlsx`;
              a.click();
              a.remove();
              window.URL.revokeObjectURL(url);
              notification.success({
                message: "Success",
                description: "Successfully exported the record!",
                style: messageStyle,
                placement: "top",
              });
              fireSideCannons()
            })
            .catch((err) => {
              console.log("error", err)
              Modal.error({
                title: "Export Error",
                content: "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            });
        } else {
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      } else {
        Modal.error({
          title: "Export Error",
          content: parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      removeExport(key);
    }
  };
  const handleCreditsExport = async (key: string, heading: string) => {
    const tenant_id_ = localStorage.getItem("tenant_id") || "0";

    try {
      addExport(key, heading);

      let parsedData;
      let url;
      let data: any;
      let response;
      const moduleName = key;

      if (creditDetailsPagination) {
        if (combineAdnvaceStoredpagination) {
          console.log("combineAdnvaceStoredpagination", combineAdnvaceStoredpagination)
          url = ENV_ROUTES.OPEN_SEARCH;
          data = {
            path: "/search_export",
            search: "combined",
            filters: creditAdvancedMultiFilters,
            search_word: creditSearchTerm,
            search_all_columns: "True",
            // tenant_id: tenantId,
            pages: {
              start: 0,
              end: 100,
            },
            partner: partner,
            username: username,
            db_name: selectedBillingDb,
            ...metaData,
            // billing_db_name: selectedBillingDb,
            sessionID: sessionId,
            tenant_id: tenant_id_,
            index_name: "Credit Details",
            module_name: moduleName,
            account_number: accountNumber,
            bill_id: BillId,
          };
          console.log("combineAdnvaceStoredpagination", data)
          response = await axios.post(url, { data });
          parsedData = JSON.parse(response.data.body);
        }
        else if (advancedStoredpagination && !storedpagination) {
          console.log("advancedStoredpagination", advancedStoredpagination)
          url = ENV_ROUTES.OPEN_SEARCH;
          data = {
            path: "/search_export",
            search: "advanced",
            filters: creditAdvancedMultiFilters,
            username: username,
            index_name: "Credit Details",
            module_name: moduleName,
            pages: { start: 0, end: 100 },
            partner,
            db_name: selectedBillingDb,
            ...metaData,
            // billing_db_name: selectedBillingDb,
            sessionID: sessionId,
            tenant_id: tenant_id_,
            account_number: accountNumber,
            bill_id: BillId,
          };
          response = await axios.post(url, { data });
          parsedData = JSON.parse(response.data.body);
        }
        else if (storedpagination && !advancedStoredpagination) {
          console.log("storedpagination", storedpagination)
          url = ENV_ROUTES.OPEN_SEARCH;
          data = {
            path: "/search_export",
            search_word: creditSearchTerm,
            username: username,
            search_all_columns: "True",
            index_name: "Credit Details",
            module_name: moduleName,
            search: "whole",
            pages: { start: 0, end: 100 },
            partner,
            db_name: selectedBillingDb,
            ...metaData,
            // billing_db_name: selectedBillingDb,
            sessionID: sessionId,
            tenant_id: tenant_id_,
            account_number: accountNumber,
            bill_id: BillId,
          };
          response = await axios.post(url, { data });
          parsedData = JSON.parse(response.data.body);
        } else {
          await ExportWithoutSearch(key);
          return;
        }
      }
      else {
        await ExportWithoutSearch(key);
        return;
      }


      if (parsedData.flag) {
        const s3Url = parsedData?.download_url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the  record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
            .then(response => response.blob())
            .then(blob => {
              const url = window.URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = `${key}.xlsx`;
              a.click();
              a.remove();
              window.URL.revokeObjectURL(url);
              notification.success({
                message: "Success",
                description: "Successfully exported the record!",
                style: messageStyle,
                placement: "top",
              });
              fireSideCannons()
            })
            .catch((err) => {
              console.log("error", err)
              Modal.error({
                title: "Export Error",
                content: "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            });
        } else {
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      } else {
        Modal.error({
          title: "Export Error",
          content: parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      removeExport(key);
    }
  };
  const handleRecurringChargesExport = async (key: string, heading: string) => {
    const tenant_id_ = localStorage.getItem("tenant_id") || "0";

    try {
      addExport(key, heading);

      let parsedData;
      let url;
      let data: any;
      let response;
      const moduleName = key;

      if (recurringChargesPagination) {
        if (combineAdnvaceStoredpagination) {
          console.log("combineAdnvaceStoredpagination", combineAdnvaceStoredpagination)
          url = ENV_ROUTES.OPEN_SEARCH;
          data = {
            path: "/search_export",
            search: "combined",
            filters: recurringadvancedMultiFilters,
            search_word: recurringSearchTerm,
            search_all_columns: "True",
            // tenant_id: tenantId,
            pages: {
              start: 0,
              end: 100,
            },
            partner: partner,
            username: username,
            db_name: selectedBillingDb,
            ...metaData,
            // billing_db_name: selectedBillingDb,
            sessionID: sessionId,
            tenant_id: tenant_id_,
            index_name: "Recurring Charge Details",
            module_name: moduleName,
            account_number: accountNumber,
            bill_id: BillId,
          };
          console.log("combineAdnvaceStoredpagination", data)
          response = await axios.post(url, { data });
          parsedData = JSON.parse(response.data.body);
        }
        else if (advancedStoredpagination && !storedpagination) {
          console.log("advancedStoredpagination", advancedStoredpagination)
          url = ENV_ROUTES.OPEN_SEARCH;
          data = {
            path: "/search_export",
            search: "advanced",
            filters: recurringadvancedMultiFilters,
            username: username,
            index_name: "Recurring Charge Details",
            module_name: moduleName,
            pages: { start: 0, end: 100 },
            partner,
            db_name: selectedBillingDb,
            ...metaData,
            // billing_db_name: selectedBillingDb,
            sessionID: sessionId,
            tenant_id: tenant_id_,
            account_number: accountNumber,
            bill_id: BillId,
          };
          response = await axios.post(url, { data });
          parsedData = JSON.parse(response.data.body);
        }
        else if (storedpagination && !advancedStoredpagination) {
          console.log("storedpagination", storedpagination)
          url = ENV_ROUTES.OPEN_SEARCH;
          data = {
            path: "/search_export",
            search_word: recurringSearchTerm,
            username: username,
            search_all_columns: "True",
            index_name: "Recurring Charge Details",
            module_name: moduleName,
            search: "whole",
            pages: { start: 0, end: 100 },
            partner,
            db_name: selectedBillingDb,
            ...metaData,
            // billing_db_name: selectedBillingDb,
            sessionID: sessionId,
            tenant_id: tenant_id_,
            account_number: accountNumber,
            bill_id: BillId,
          };
          response = await axios.post(url, { data });
          parsedData = JSON.parse(response.data.body);
        } else {
          await ExportWithoutSearch(key);
          return;
        }
      }
      else {
        await ExportWithoutSearch(key);
        return;
      }


      if (parsedData.flag) {
        const s3Url = parsedData?.download_url || null;
        if (s3Url) {
          // window.location.href = s3Url;
          // notification.success({
          //   message: "Success",
          //   description: "Successfully exported the  record!",
          //   style: messageStyle,
          //   placement: "top",
          // });
          fetch(s3Url)
            .then(response => response.blob())
            .then(blob => {
              const url = window.URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = `${key}.xlsx`;
              a.click();
              a.remove();
              window.URL.revokeObjectURL(url);
              notification.success({
                message: "Success",
                description: "Successfully exported the record!",
                style: messageStyle,
                placement: "top",
              });
              fireSideCannons()
            })
            .catch((err) => {
              console.log("error", err)
              Modal.error({
                title: "Export Error",
                content: "An error occurred while exporting data. Please try again.",
                centered: true,
              });
            });
        } else {
          Modal.error({
            title: "Export Error",
            content: parsedData.message || "An error occurred while exporting data. Please try again.",
            centered: true,
          });
        }
      } else {
        Modal.error({
          title: "Export Error",
          content: parsedData.message || "An error occurred while exporting data. Please try again.",
          centered: true,
        });
      }
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred while fetching data. Please try again.",
        centered: true,
      });
    } finally {
      removeExport(key);
    }
  };
 const handleExport = async (key: string, heading: string) => {
  const tenant_id_ = localStorage.getItem("tenant_id") || "0";

  try {
    addExport(key, heading);

    let url = ENV_ROUTES.OPEN_SEARCH;
    let data: any = null;

    // 🔹 1. Build export payload based on search state
    if (combineAdnvaceStoredpagination) {
      data = {
        path: "/search_export",
        search: "combined",
        filters: advancedMultiFilters,
        search_word: searchTerm,
        search_all_columns: "True",
        pages: { start: 0, end: 100 },
        partner,
        username,
        db_name: selectedBillingDb,
        ...metaData,
        sessionID: sessionId,
        tenant_id: tenant_id_,
        index_name: key,
        module_name: key,
        account_number: accountNumber,
        bill_id: BillId,
      };
    } else if (advancedStoredpagination && !storedpagination) {
      data = {
        path: "/search_export",
        search: "advanced",
        filters: advancedMultiFilters,
        pages: { start: 0, end: 100 },
        partner,
        username,
        db_name: selectedBillingDb,
        ...metaData,
        sessionID: sessionId,
        tenant_id: tenant_id_,
        index_name: key,
        module_name: key,
        account_number: accountNumber,
        bill_id: BillId,
      };
    } else if (storedpagination && !advancedStoredpagination) {
      data = {
        path: "/search_export",
        search: "whole",
        search_word: searchTerm,
        search_all_columns: "True",
        pages: { start: 0, end: 100 },
        partner,
        username,
        db_name: selectedBillingDb,
        ...metaData,
        sessionID: sessionId,
        tenant_id: tenant_id_,
        index_name: key,
        module_name: key,
        account_number: accountNumber,
        bill_id: BillId,
      };
    } else {
      // 🔹 No search applied
      await ExportWithoutSearch(key);
      return;
    }

    // 🔹 2. Trigger export (fire-and-forget with timeout)
    try {
      await Promise.race([
        axios.post(url, { data }),
        new Promise((_, reject) =>
          setTimeout(() => reject(new Error("Export trigger timeout")), 10000)
        ),
      ]);
    } catch (err) {
      console.warn("Export trigger failed or timed out:", err);
    }

    // 🔹 3. Poll export status (common for ALL cases)
    const pollExportStatus = async (): Promise<boolean> => {
      try {
        const export_url = ENV_ROUTES.MODULE_MANAGEMENT;
        const export_data = {
          module_name:"Charge By Service",
          tenant_name: partner || "default_value",
          ...data,
          access_token: token,
          path: "/get_export_status",
        };

        const res = await axios.post(export_url, { data: export_data });
        const parsed = JSON.parse(res.data.body);
        const status = parsed?.export_status_data?.status_flag;

        if (parsed?.flag && status === "Success") {
          const s3Url = parsed?.export_status_data?.url;
          if (!s3Url) throw new Error("Download URL missing");

          const blob = await fetch(s3Url).then((r) => r.blob());
          const downloadUrl = window.URL.createObjectURL(blob);

          const a = document.createElement("a");
          a.href = downloadUrl;
          a.download = `${key}.xlsx`;
          document.body.appendChild(a);
          a.click();
          a.remove();

          window.URL.revokeObjectURL(downloadUrl);

          notification.success({
            message: "Success",
            description: "Export completed successfully",
            style: messageStyle,
            placement: "top",
          });
          fireSideCannons();

          return true; // stop polling
        }

        if (status === "Failure" || status === "No Data Found for export") {
          Modal.error({
            title: "Export Error",
            content: parsed.message || status,
            centered: true,
          });
          return true; // stop polling
        }

        return false; // continue polling
      } catch (error) {
        Modal.error({
          title: "Export Error",
          content:
            error instanceof Error
              ? error.message
              : "An unexpected error occurred during export",
          centered: true,
        });
        return true;
      }
    };

    // 🔹 4. Start polling loop (5 sec interval)
    let completed = false;
    while (!completed) {
      completed = await pollExportStatus();
      if (!completed) {
        await new Promise((resolve) => setTimeout(resolve, 5000));
      }
    }
  } catch (error) {
    Modal.error({
      title: "Export Error",
      content:
        error instanceof Error
          ? error.message
          : "An unexpected error occurred while exporting",
      centered: true,
    });
  } finally {
    removeExport(key);
  }
};

  const ExportWithoutSearch = async (key: string) => {
    addExport(key, key)

    try {

      let path = "/charge_overview_export"
      if (key === "Charge By Service") {
        path = "/charge_by_service_export"
      }
      else if (key === "Usage Details") {
        path = "/usage_sms_charges_export"
      }
      else if (key === "Charge Overview") {
        path = "/export_charge_overview_to_s3"
      }
      else if (key === "Charge Overview Account Charges") {
        path = "/charge_overview_account_charges_export"
      }
      else if (key === "Charge Overview Recurring Charges") {
        path = "/charge_overview_recurring_charges_export"
      }
      else if (key === "Charge Overview Account Credits") {
        path = "/charge_overview_account_credits_export"
      }
      else {
        path = "/charge_overview_export"
      }
      // const path =
      //   key === "Charge By Service"
      //     ? "/charge_by_service_export"
      //     : key === "Usage Details" ? "/usage_sms_charges_export"
      //       : key === "Charge Overview" ? "/export_charge_overview_to_s3" : "/charge_overview_export";
      const callWithTimeout = async (promise: Promise<any>, timeout: number) => {
        return new Promise((resolve, reject) => {
          const timer = setTimeout(() => {
            reject(new Error("Request timed out"));
          }, timeout);

          promise
            .then((res) => {
              clearTimeout(timer);
              resolve(res);
            })
            .catch((err) => {
              clearTimeout(timer);
              reject(err);
            });
        });
      };

      const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const data = {
        tenant_name: partner || "default_value",
        username,
        path,
        role_name: role,
        bill_id: BillId,
        account_number: popupheading === "Billing" ? "" : accountNumber,
        parent_module: "Billing Platform",
        module_name: key,
        request_received_at: getCurrentDateTime(),
        Partner: partner,
        access_token: token,
        db_name: selectedDb,
        ...metaData,
        billing_db_name: selectedBillingDb,
        tenant_id: tenant_id_,
        sessionID: sessionId,
        feature_module_name: key,
        main_module_name: "Customer Profiles",
        start_date: getFirstDayOfCurrentMonth(),
        end_date: getLastDayOfCurrentMonth(),
        killbill_flag: "True"
      };

      // First API call with a timeout of 10 seconds
      try {
        await callWithTimeout(axios.post(url, { data }), 10000);
      } catch (err) {
        console.warn("First API request failed or timed out:", err);
      }

      // Wait for 20 seconds before polling
      // await new Promise((resolve) => setTimeout(resolve, 20000));

      const export_url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
      const export_data = {
        ...data,
        path: "/get_export_status",
      };

      const pollExportStatus = async () => {
        try {
          const export_response = await axios.post(export_url, { data: export_data });
          const export_parsedData = JSON.parse(export_response.data.body);

          if (export_parsedData.flag && export_parsedData?.export_status_data?.status_flag === "Success") {
            const s3Url = export_parsedData?.export_status_data?.url || null;
            if (s3Url) {
              const fileName = `${key}.xlsx`; // Customize here if CSV needed
              fetch(s3Url)
                .then((response) => response.blob())
                .then((blob) => {
                  const downloadUrl = window.URL.createObjectURL(blob);
                  const link = document.createElement("a");
                  link.href = downloadUrl;
                  link.download = fileName;
                  document.body.appendChild(link);
                  link.click();
                  link.remove();

                  notification.success({
                    message: "Success",
                    description: "Successfully exported the  record!",
                    style: messageStyle,
                    placement: "top",
                  });
                  fireSideCannons();
                })
                .catch(() => {
                  Modal.error({
                    title: "Export Error",
                    content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
                    centered: true,
                  });
                });
            }
            return true; // Stop polling
          }

          if (export_parsedData?.export_status_data?.status_flag === "Failure") {
            Modal.error({
              title: "Export Error",
              content: export_parsedData.message || "An error occurred while exporting data. Please try again.",
              centered: true,
            });
            return true; // Stop polling
          }
          if (export_parsedData?.export_status_data?.status_flag === "No Data Found for export") {
            Modal.error({
              title: "Export Error",
              content: export_parsedData.export_status_data?.status_flag || "An error occurred while exporting data. Please try again.",
              centered: true,
            });
            return true; // Stop polling
          }

          return false; // Continue polling
        } catch (error) {
          Modal.error({
            title: "Export Error",
            content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
            centered: true,
          });
          return true; // Stop polling
        }
      };

      const startPolling = async () => {
        let isPollingComplete = false;

        while (!isPollingComplete) {
          isPollingComplete = await pollExportStatus();
          if (!isPollingComplete) {
            await new Promise((resolve) => setTimeout(resolve, 5000)); // Wait for 5 seconds
          }
        }
      };

      await startPolling();
    } catch (error) {
      Modal.error({
        title: "Export Error",
        content: error instanceof Error ? error.message : "An unexpected error occurred. Please try again.",
        centered: true,
      });
    } finally {
      removeExport(key);
    }
  };

  if (!isOpen) return null;
  const messageStyle = {
    fontSize: "14px",
    fontWeight: "normal",
    padding: "16px",
  };

  const handleCancel = () => {
    setHeaders([]) // Clear new field input
    // setTableData([])
    onClose();
  };
  const handleTabChange = async (key: any) => {
    // setLoading(true); // Show loader
    // // Simulate data fetching delay (replace with actual API call if needed)
    // await new Promise((resolve) => setTimeout(resolve, 500));

    setActiveTab(key);
    setLoading(false); // Hide loader
  };

  const formatLabel = (key: string) =>
    key
      .replace(/_/g, " ")
      .replace(/\b\w/g, char => char.toUpperCase());

  // const formatAmount = (value: number) =>
  //   `$${Number(value).toFixed(2)}`;
  const formatAmount = (value: number) =>
    `$${Number(value).toLocaleString("en-US", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })}`;

  return (
    <Modal
      open={isOpen}
      onCancel={handleCancel}
      centered
      footer={null}
      width="900px"
      bodyStyle={{
        height: window.innerHeight - 80,
        display: "flex",
        flexDirection: "column",
        overflow: "auto"
      }}
    >
      <Tabs
        defaultActiveKey="1"
        activeKey={activeTab}
        onChange={handleTabChange}
        className="flex-1"
        tabBarExtraContent={ activeTab === "1" ? {
          right: (
            <div className="pr-8 mb-2">
              <button
                className="save-btn flex items-center"
                onClick={() => handleExport("Charge Overview", "Charge Overview")}
              >
                <ArrowDownTrayIcon className="h-5 w-5 mr-2" />
                <span>Export</span>
              </button>
            </div>
          ),
        }: undefined}>
        {/* Charge Overview */}
        <TabPane tab="Charge Overview" key="1">

          <div className="flex flex-col h-[70vh]">

            {loading ? (
              <div className="flex flex-1 justify-center items-center">
                <Spin size="large" />
              </div>
            ) : (
              <div className="flex-1 overflow-y-auto px-2 space-y-2">

                {/* ================= Charge Details ================= */}
                <div className="relative">
                   <div className="flex tabs-sub-headings items-center justify-between">
                      <h3 className="text-lg font-semibold">Charge Details</h3>
                    </div>
                  <div className="p-4 flex md:flex-row md:items-center md:justify-between space-y-6 md:space-y-0">
                    {/* Search and Advanced Filter Container */}
                    <div className="flex  space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last">
                      {(
                        <TableSearch
                          searchTerm={chargeSearchTerm}
                          setSearchTerm={setChargeSearchTerm}
                          tableName={"Charge Details"}
                          headerMap={headerMap}
                        />
                      )}
                      {(
                        <AdvancedMultiFilter
                          showAdvanced={chargeShowAdvanced}
                          setShowAdvanced={setChargeShowAdvanced}
                          onFilter={handleChargeFilter}
                          onReset={handleChargeReset}
                          headers={headers}
                          headerMap={headerMap}
                          tableName={"Charge Details"}
                        />
                      )}
                    </div>
                    <div className="hidden md:flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2 md:order-none order-first ml-4">
                      {(
                        <button
                          className="save-btn"
                          onClick={() => handleChargesExport("Charge Overview Account Charges", "Charge Overview Account Charges")}
                        >
                          <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                          <span>Export</span>
                        </button>
                      )}

                    </div>
                  </div>
                  <div className={`${chargeShowAdvanced ? 'mt-[70px]' : ''}`}>
                    {/* Header */}
                   
                    {/* Fee Details */}
                    {/* LEFT: Fee details */}
                    <div className="flex-1">
                        {tableData?.fee_details &&
                          Object.keys(tableData.fee_details).length > 0 && (
                            <div className="flex gap-6 rounded-md pb-2">
                              {Object.entries(tableData.fee_details).map(([key, value]) => (
                                <div key={key} className="flex items-center gap-2">
                                  <span className="text-sm">
                                    {formatLabel(key)}:
                                  </span>
                                  <span className="font-medium">
                                    {formatAmount(parseAmount(value))}
                                  </span>
                                </div>
                              ))}
                            </div>
                          )}
                    </div>

                    <KillbillTableComponent
                      headers={headers}
                      headerMap={headerMap}
                      initialData={chargesTableData}
                      searchQuery={chargeSearchTerm}
                      visibleColumns={chargesVisibleColumns}
                      itemsPerPage={100}
                      allowedActions={allowedActions}
                      popupHeading="Charge Details"
                      pagination={chargePagination}
                      advancedFilters={chargeFilteredData}
                      createModalData={createModalData}
                      generalFields={generalFields}
                      height={300}
                      isChargesModalOpen={true}
                    />
                  </div>
                </div>

                {/* ================= Credit Details ================= */}
                <div>
                  {/* Header */}

                  <div className="flex tabs-sub-headings items-center justify-between mb-3">
                    <h3 className="text-lg font-semibold">Credit Details</h3>
                  </div>

                  <div className="relative mb-4">
                    <div className="flex md:flex-row md:items-center md:justify-between space-y-6 md:space-y-0">
                      {/* Search and Advanced Filter Container */}
                      <div className="flex space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last pb-2">
                        {(
                          <TableSearch
                            searchTerm={creditSearchTerm}
                            setSearchTerm={setCreditSearchTerm}
                            tableName={"Credit Details"}
                            headerMap={headerMap}
                          />
                        )}
                        {(
                          <AdvancedMultiFilter
                            showAdvanced={creditShowAdvanced}
                            setShowAdvanced={setCreditShowAdvanced}
                            onFilter={handleCreditFilter}
                            onReset={handleCreditReset}
                            headers={headers}
                            headerMap={headerMap}
                            tableName={"Credit Details"}
                          />
                        )}
                      </div>
                      <div className="hidden md:flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2 md:order-none order-first ml-4">
                        {(
                          <button
                            className="save-btn"
                            onClick={() => handleCreditsExport("Charge Overview Account Credits", "Charge Overview Account Credits")}
                          >
                            <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                            <span>Export</span>
                          </button>
                        )}

                      </div>
                    </div>
                    <div className={`${creditShowAdvanced ? "mt-[70px]" : ""}`}>
                      <EditableTableComponent
                        headers={headers}
                        headerMap={headerMap}
                        initialData={creditTableData}
                        searchQuery={creditSearchTerm}
                        visibleColumns={creditVisibleColumns}
                        itemsPerPage={100}
                        popupHeading="Credit Details"
                        pagination={CreditPagination}
                        advancedFilters={creditFilteredData}
                        createModalData={createModalData}
                        generalFields={generalFields}
                        height={300}
                      />
                    </div>
                  </div>

                </div>
                <div>
                  {/* Header */}
                  <div className="flex tabs-sub-headings items-center justify-between mb-3">
                    <h3 className="text-lg font-semibold">Recurring Charge Details</h3>
                  </div>
                  <div className="relative">
                    <div className="flex md:flex-row md:items-center md:justify-between space-y-6 md:space-y-0">
                      {/* Search and Advanced Filter Container */}
                      <div className="flex space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last pb-2">
                        {(
                          <TableSearch
                            searchTerm={recurringSearchTerm}
                            setSearchTerm={setRecurringSearchTerm}
                            tableName={"Recurring Charge Details"}
                            headerMap={headerMap}
                          />
                        )}
                        {(
                          <AdvancedMultiFilter
                            showAdvanced={recurringShowAdvanced}
                            setShowAdvanced={setRecurringShowAdvanced}
                            onFilter={handleRecurringFilter}
                            onReset={handleRecurringReset}
                            headers={headers}
                            headerMap={headerMap}
                            tableName={"Recurring Charge Details"}
                          />
                        )}
                      </div>
                      <div className="hidden md:flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-2 md:order-none order-first ml-4">
                        {(
                          <button
                            className="save-btn"
                            onClick={() => handleRecurringChargesExport("Charge Overview Recurring Charges", "Charge Overview Recurring Charges")}
                          >
                            <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                            <span>Export</span>
                          </button>
                        )}

                      </div>
                    </div>
                    <div className={`${recurringShowAdvanced ? "mt-[70px]" : ""}`}>
                      <BillingPlatformTableComponent2
                        headers={headers}
                        headerMap={headerMap}
                        initialData={recurringChargeData}
                        searchQuery={recurringSearchTerm}
                        visibleColumns={recurringVisibleColumns}
                        itemsPerPage={100}
                        allowedActions={allowedActions}
                        popupHeading="Recurring Charge Details"
                        pagination={recurringPagination}
                        advancedFilters={recurringFilteredData}
                        createModalData={createModalData}
                        generalFields={generalFields}
                        height={300}
                      />
                    </div>
                  </div>


                </div>
                <div className="flex flex-col items-start mt-[-35px]">
                 <div className="flex items-center justify-between w-[20px] whitespace-nowrap">
                  <strong>Total Amount: &nbsp;</strong>
                  <span>{formatAmount(totalChargeReveiwAmount_)}</span>
                </div>
               </div>


              </div>
            )}
          </div>
        </TabPane>



        {/* Usage Details */}
        <TabPane tab="Usage Details" key="2">
          {/* <div className="flex flex-col h-full"> */}
          <div className="flex-1 overflow-auto">
            {loading ? (
              <div className="flex justify-center items-center" style={{ height: "350px" }}>
                <Spin size="large" />
              </div>
            ) : (
              <div className="relative">
                <div className="pr-4 pl-4 flex md:flex-row md:items-center md:justify-between space-y-2">
                  {/* Search and Advanced Filter Container */}
                  <div className="flex  space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last ">
                    {(
                      <TableSearch
                        searchTerm={searchTerm}
                        setSearchTerm={setSearchTerm}
                        tableName={"Usage Details"}
                        headerMap={usageHeaderMap}
                      />
                    )}
                    {(
                      <AdvancedMultiFilter
                        showAdvanced={showAdvanced}
                        setShowAdvanced={setShowAdvanced}
                        onFilter={handleFilter}
                        onReset={handleReset}
                        headers={usageHeaders}
                        headerMap={usageHeaderMap}
                        tableName={"Usage Details"}
                      />
                    )}

                  </div>
                  {/* Export and ColumnFilter Container */}
                  <div className="hidden md:flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2  md:order-none order-first pb-2 md:pb-4">
                    {(
                      <button className="save-btn" onClick={() => handleExport("Usage Details", "Usage Details")}>
                        <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                        <span>Export</span>
                      </button>
                    )}

                  </div>

                </div>
                {/* Sticky Footer for Small Screens */}
                <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
                  {(
                    <button className="save-btn" onClick={() => handleExport("Usage Details", "Usage Details")}>
                      <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                    </button>
                  )}

                </div>
                <div className={`${showAdvanced ? 'mt-[70px]' : ''}`}>
                  <TableComponent
                    headers={usageHeaders}
                    headerMap={usageHeaderMap}
                    initialData={usageDetailsTableData}
                    searchQuery={searchTerm}
                    visibleColumns={visibleColumns}
                    itemsPerPage={100}
                    popupHeading={"Usage Details"}
                    pagination={pagination}
                    advancedFilters={filteredData}
                    createModalData={createModalData}
                    generalFields={generalFields}
                    height={300}
                  />
                </div>
              </div>
            )}
          </div>
          {!loading && (
            <div className="flex flex-col items-start mt-0 lg:mt-[-35px]">
              <div className="flex justify-between w-[140px]">
                <p><strong>Total Usage :</strong></p>
                <p>{totalUsageData.total_usage !== 0 ? `$${totalUsageData.total_usage}` : totalUsageData.total_usage}</p>
              </div>
              <div className="flex justify-between w-[140px]">
                <p><strong>Total Tax:</strong></p>
                <p>{totalUsageData.total_tax !== 0 ? `$${totalUsageData.total_tax}` : totalUsageData.total_tax}</p>
              </div>
            </div>
          )}
          {/* </div> */}
        </TabPane>
        {/* Charge By Service */}
        <TabPane tab="Charges By Service" key="3">
          <div className="flex-1 overflow-auto">
            {loading ? (
              <div className="flex justify-center items-center" style={{ height: "350px" }}>
                <Spin size="large" />
              </div>
            ) : (
              <div className="relative">
                <div className="pr-4 pl-4 flex md:flex-row md:items-center md:justify-between space-y-2">
                  {/* Search and Advanced Filter Container */}
                  <div className="flex  space-x-2 md:flex-row md:space-y-0 md:space-x-2 md:order-none order-last ">
                    {(
                      <TableSearch
                        searchTerm={searchTerm}
                        setSearchTerm={setSearchTerm}
                        tableName={"Charge By Service"}
                        headerMap={headerMap}
                      />
                    )}
                    {(
                      <AdvancedMultiFilter
                        showAdvanced={showAdvanced}
                        setShowAdvanced={setShowAdvanced}
                        onFilter={handleFilter}
                        onReset={handleReset}
                        headers={headers}
                        headerMap={headerMap}
                        tableName={"Charge By Service"}
                      />
                    )}

                  </div>
                  {/* Export and ColumnFilter Container */}
                  <div className="hidden md:flex flex-col space-y-2 md:flex-row md:space-y-0 md:space-x-2  md:order-none order-first pb-2 md:pb-4">
                    {(features2.includes("Export-Billing Charge By Service") || features2.includes("Export-Charge By Service")) && (
                      <button className="save-btn" onClick={() => handleExport("Charge By Service", "Charge By Service")}>
                        <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                        <span>Export</span>
                      </button>
                    )}

                  </div>

                </div>
                {/* Sticky Footer for Small Screens */}
                <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 flex justify-around items-center p-2 z-50">
                  {(features2.includes("Export-Billing Charge By Service") || features2.includes("Export-Charge By Service")) && (
                    <button className="save-btn" onClick={() => handleExport("Charge By Service", "Charge By Service")}>
                      <ArrowDownTrayIcon className="h-5 w-5 text-black-500 mr-2" />
                    </button>
                  )}

                </div>
                <div className={`${showAdvanced ? 'mt-[70px]' : ''}`}>
                  <KillbillTableComponent
                    headers={headers}
                    headerMap={headerMap}
                    initialData={chargeByServiceTableData}
                    searchQuery={searchTerm}
                    visibleColumns={visibleColumns}
                    itemsPerPage={100}
                    allowedActions={allowedActions}
                    popupHeading={"Charge By Service"}
                    pagination={pagination}
                    advancedFilters={filteredData}
                    createModalData={createModalData}
                    generalFields={generalFields}
                    height={300}
                    isChargesModalOpen={true}
                  />


                </div>
              </div>
            )}
          </div>
          {!loading && (
            <div className="flex flex-col items-start mt-0 lg:mt-[-35px]">
              <div className="flex justify-between w-[140px]">
                <p><strong>Total:</strong></p>
                <p>${totalAmount !== 0 ? `${totalAmount}` : totalAmount}</p>
              </div>
              <div className="flex justify-between w-[140px]">
                <p><strong>Total Taxes:</strong></p>
                <p>${totalTaxes !== 0 ? `${totalTaxes}` : totalTaxes}</p>
              </div>
            </div>
          )}
        </TabPane>
      </Tabs>
    </Modal>


  );

};


export default ChargesPopup;

