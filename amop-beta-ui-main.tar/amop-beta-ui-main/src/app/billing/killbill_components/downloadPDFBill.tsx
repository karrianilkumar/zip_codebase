"use client";
import { useCallback, useEffect, useRef, useState, lazy } from "react";
import axios from "axios";
import { ENV_ROUTES } from "@/app/components/routes/route_constants";
import { useCustomerProfileStore } from "../killbill_stores/customer_profile_store";
// import CreateTemplate from "../generate_bill/createTemplate";
// import { useTemplateStore } from "../killbill_stores/templateStore";
import { useAuth } from "@/app/components/auth_context";
// const MultiTemplate = lazy(() => import("@/app/billing/multiGenerateBill/createMultiTemplate"));
// const InvoiceTemplate = lazy(() => import("@/app/billing/generate_bill/invoiceTemplate"));

interface DownloadPDFBillProps {
    isOpen: boolean;
    onClose: () => void;
    rowData: any;
}

const DownloadPDFBill: React.FC<DownloadPDFBillProps> = ({ isOpen, onClose, rowData }) => {
    console.log(rowData, "Show row data");
    const [loading, setLoading] = useState(false);
    const [invoiceData, setInvoiceData] = useState(null);
    const [template, setTemplate] = useState(null);
    const { accountNumber } = useCustomerProfileStore();
    const hasFetchedData = useRef(false);
    // const { templateData } = useTemplateStore();

    const path = "/generate_bill_pdf";
    const { partner } = useAuth();

   
    // Fetch data when modal opens or rowData changes
    
    const fetchInvoiceData = useCallback(async () => {
        setLoading(true);
        const url = ENV_ROUTES.BP_CUSTOMER_PROFILES;
    
        const data = {
            account_number: accountNumber ? accountNumber : rowData?.account_number,
            id: rowData?.id,
            path: path,
            tenant_name: partner || "default_value",
          main_module_name: "Customer Profiles",
        };
    
        try {
            const response = await axios.post(url, { data });
            console.log(response, "Show data");
            console.log(response.data.data, "show response data");
    
            // Parse fetchedData
            const fetchedData = JSON?.parse(response?.data?.data);
            console.log(fetchedData, "show fetched Data");
            setInvoiceData(fetchedData);
    
            // Safely handle pdf_template
            let templateData_ = null;
            if (response?.data?.pdf_template) {
                try {
                    // Check if pdf_template is already an array or object (no need to parse)
                    if (typeof response.data.pdf_template === 'object') {
                        templateData_ = response.data.pdf_template; // Use as-is if it's already parsed
                    } else {
                        // Try parsing if it's a string
                        templateData_ = JSON.parse(response.data.pdf_template);
                    }
                } catch (parseError) {
                    console.error('Error parsing pdf_template:', parseError);
                    templateData_ = []; // Fallback to empty array or handle as needed
                }
            } else {
                console.warn('pdf_template is undefined or null');
                templateData_ = []; // Fallback to empty array or handle as needed
            }
    
            console.log(templateData_, "Show... template dataaaaa");
            setTemplate(templateData_);
    
        } catch (error) {
            console.error('Error fetching invoice data:', error);
        } finally {
            setLoading(false);
        }
    }, [accountNumber, rowData?.id, path, partner]);
    useEffect(() => {
        if (isOpen) {
            hasFetchedData.current = false; // Reset ref when modal opens
            setInvoiceData(null); // Clear previous data
            fetchInvoiceData();
        }
    }, [isOpen, rowData, fetchInvoiceData]);

    // Reset state when modal closes
    useEffect(() => {
        if (!isOpen) {
            setInvoiceData(null); // Clear invoice data on close
            hasFetchedData.current = false; // Reset ref on close
        }
    }, [isOpen]);

    // Only render when modal is open
    if (!isOpen) return null;

    return (
        <div>
            {loading && (
            <div className="opt-details-export-processing-div">
                    PDF Downloading...
                </div>
                )}
            {/* {invoiceData && (
                <MultiTemplate
                    invoiceData={invoiceData} 
                    downloadPDF={true} 
                    templateData={template} 
                />
            )} */}
           
        </div>
    );
}

export default DownloadPDFBill;
